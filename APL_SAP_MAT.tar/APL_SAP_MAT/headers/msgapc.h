/*
 *  FILE: msgapc.h
 */

#ifndef msgapc_H
#define msgapc_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _ActivateVewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AddStructureOptionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr strcOptObj, ObjectPtr vewObj, ObjectPtr dialogObj,
   ObjectPtr * strcOptRel, integer * mfail);

MTIstatus _AllwSetProcPreciseRev
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects objectSet, string relationship, ObjectPtr genContextObj,
   SetOfObjects * otherSideObjSet, SetOfObjects * relObjSet, integer * mfail);

MTIstatus _AssignEOLDateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stPtRqObj,
   string EOLDate, integer * mfail);

MTIstatus _AssignEOLDateDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AssignItmToViewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _AssignObjToViewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr vewObj, integer * mfail);

MTIstatus _BaselineItem4AtClass
   (MTIstring _class, boolean getParent, ObjectPtr part,
   SetOfObjects * busItems, SetOfObjects * dataItems, integer * mfail);

MTIstatus _BaselineItemP2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr part,
   SetOfObjects * busItems, SetOfObjects * dataItems, integer * mfail);

MTIstatus _CheckEffAgainstCntxtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr effRelObj,
   ObjectPtr contextObj, boolean * isEffective, integer * mfail);

MTIstatus _ChgCertificatStatusDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ChgCertificationStatusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   string sCertificationStatus, integer * mfail);

MTIstatus _ChgVendorStatusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   string sVendorStatus, integer * mfail);

MTIstatus _ChgVendorStatusDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ChkEffAgainstCntxtPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr effRelObj,
   ObjectPtr contextObj, boolean * isEffective, integer * mfail);

MTIstatus _ClearStructureOptionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr strcOptObj, ObjectPtr vewObj, integer * mfail);

MTIstatus _ComparePreciseRevision
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, string preciseRevision, string currentRevision,
   string prcRevOperand, boolean * result, integer * mfail);

MTIstatus _ConstructArgsForAsgnVwAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * dialogObj, integer * mfail);

MTIstatus _CreatePrepareRelation
   (MTIstring _class, boolean getParent, string relationName,
   ObjectPtr createArgs, ObjectPtr leftPdmRoot, ObjectPtr rightPdmItem,
   ObjectPtr * relation, integer * mfail);

MTIstatus _CreateRevEff
   (MTIstring _class, boolean getParent, string revEffClass,
   ObjectPtr strucBI, ObjectPtr cfgItem, ObjectPtr createArgs,
   ObjectPtr * revEff, integer * mfail);

MTIstatus _CreateRevEff2
   (MTIstring _class, boolean getParent, string revEffClass,
   ObjectPtr strucBI, ObjectPtr cfgItem, ObjectPtr vew,
   ObjectPtr createArgs, ObjectPtr * revEff, integer * mfail);

MTIstatus _CreateStructEff
   (MTIstring _class, boolean getParent, string strcEffClass,
   ObjectPtr strucBI, ObjectPtr itemMstr, string findNumber,
   ObjectPtr cfgItem, ObjectPtr createArgs, ObjectPtr * strucEff,
   integer * mfail);

MTIstatus _CreateStructEff2
   (MTIstring _class, boolean getParent, string strcEffClass,
   ObjectPtr strucBI, ObjectPtr itemMstr, string findNumber,
   ObjectPtr cfgItem, ObjectPtr vew, ObjectPtr createArgs,
   ObjectPtr * strucEff, integer * mfail);

MTIstatus _CreateStructRelation
   (MTIstring _class, boolean getParent, string strucApcClass,
   ObjectPtr strucBI, ObjectPtr itemMstr, ObjectPtr createArgs,
   ObjectPtr * strucRelation, integer * mfail);

MTIstatus _CreateStructRelation2
   (MTIstring _class, boolean getParent, string strucApcClass,
   ObjectPtr strucBI, ObjectPtr itemMstr, ObjectPtr vew,
   ObjectPtr createArgs, ObjectPtr * strucRelation, integer * mfail);

MTIstatus _CreateSubPartObject
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr strucBIObj, ObjectPtr itemMstrObj, string findNumber,
   ObjectPtr partMstrObj, ObjectPtr vewObj, ObjectPtr dialogObj,
   ObjectPtr * relObj, integer * mfail);

MTIstatus _CreateViewDepObject
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr strucBIObj, ObjectPtr itemMstrObj, ObjectPtr vewObj,
   ObjectPtr dialogObj, ObjectPtr * relObj, integer * mfail);

MTIstatus _DeactivateVewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DeleteRevEffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revEff,
   integer * mfail);

MTIstatus _DeleteRevEff2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revEff,
   ObjectPtr vew, integer * mfail);

MTIstatus _DeleteStructEffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr strucEff,
   integer * mfail);

MTIstatus _DeleteStructEff2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr strucEff,
   ObjectPtr vew, integer * mfail);

MTIstatus _DeleteStructRelationAtClass
   (MTIstring _class, boolean getParent, ObjectPtr strucRelation,
   integer * mfail);

MTIstatus _DeleteStructRelation2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr strucRelation,
   ObjectPtr vew, integer * mfail);

MTIstatus _DeleteSubPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr subPart,
   integer * mfail);

MTIstatus _DeleteSubPart2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr subPart,
   ObjectPtr vew, integer * mfail);

MTIstatus _DeleteViewDepObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr vewObj, integer * mfail);

MTIstatus _DoAsgEOLDateFailClnupAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   ObjectPtr assignEOLDateDlg, integer * mfail);

MTIstatus _DoAssignEOLDatePostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   ObjectPtr assignEOLDateDlg, integer * mfail);

MTIstatus _DoAssignEOLDatePreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   ObjectPtr assignEOLDateDlg, integer * mfail);

MTIstatus _DoCertStatFailCleanupAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgCertStatusPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgCertificatStatPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgVendorStatusPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgVndStatusPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoDetectRecursionInPSAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string attribName, SetOfStrings * recLineElems, integer * mfail);

MTIstatus _DoValBOMEditUpdPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DoViewDepCreateForAuxAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr strBIObj, integer * mfail);

MTIstatus _DoVndStatFailCleanupAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoesRelClassPrcForCcs
   (MTIstring _class, boolean getParent, string className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassPrcForCvs
   (MTIstring _class, boolean getParent, string className,
   integer * answer, integer * mfail);

MTIstatus _FormatDisplayQuantity
   (MTIstring _class, boolean getParent, string className,
   float inputQuantity, string * formatedDisplayQty, integer * mfail);

MTIstatus _FormatDisplayQuantity2
   (MTIstring _class, boolean getParent, string className,
   string inputQuantity, string * formatedDisplayQty, integer * mfail);

MTIstatus _FreezeViewObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr vewObj, integer * mfail);

MTIstatus _GetAssignEOLDlgNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   string * assignEOLDlgName, integer * mfail);

MTIstatus _GetAssociatedDocItemsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * docObjSet, integer * mfail);

MTIstatus _GetAssociatedPsmPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * partObjSet, integer * mfail);

MTIstatus _GetCertStatDialogNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   string * dialogName, integer * mfail);

MTIstatus _GetContentsFilterAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings includeClasses, SetOfStrings excludeClasses, boolean latest,
   boolean available, boolean topLevel, SetOfObjects * folderContents,
   integer * mfail);

MTIstatus _GetEffDateFromCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, string * configIdPref, string * effDatePref,
   integer * mfail);

MTIstatus _GetEffUnitFromCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, string * configIdPref, string * effUnitPref,
   integer * mfail);

MTIstatus _GetIncZeroQtyFromCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, boolean * includeZeroQty, integer * mfail);

MTIstatus _GetNavViewFromCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, string * viewNetworkPref, string * viewNamePref,
   integer * mfail);

MTIstatus _GetPartsForImplosionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr genContextObj, boolean useLatest, integer currentLevel,
   SetOfObjects droppedObjectSet, SetOfObjects * otherSideObjSet, SetOfObjects * relObjSet,
   integer * mfail);

MTIstatus _GetStrcOptListFromCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, SetOfStrings * strcOptListPref, integer * mfail);

MTIstatus _GetViewListToWorkInAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer viewActionType, SetOfObjects * vewObjList, integer * mfail);

MTIstatus _GetVndStatDialogNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   string * dialogName, integer * mfail);

MTIstatus _InsertLevelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr insertLvlDlgObj, integer * mfail);

MTIstatus _InsertLevel2PostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   SetOfObjects selectedStrcRels, ObjectPtr newObject, ObjectPtr newLeftRelDlg,
   ObjectPtr newRightRelDlg, ObjectPtr vewObject, SetOfObjects newRelSet,
   integer * mfail);

MTIstatus _InsertLevel2PreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   SetOfObjects selectedStrcRels, ObjectPtr newObject, ObjectPtr newLeftRelDlg,
   ObjectPtr newRightRelDlg, ObjectPtr vewObject, SetOfObjects newRelSet,
   integer * mfail);

MTIstatus _InsertLevelSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects topLvlProdElmObjSet, SetOfObjects insertLvlDlgObjSet, integer * mfail);

MTIstatus _IsPartEndItemImplosionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isEndItem, integer * mfail);

MTIstatus _IsPartStatusApprovedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnCmMfPtObj,
   boolean * isApproved, integer * mfail);

MTIstatus _IsVendorStatusApprovedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   boolean * isApproved, integer * mfail);

MTIstatus _IsVendorStatusInReviewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   boolean * isInReview, integer * mfail);

MTIstatus _IsVendorStatusPreferrdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   boolean * isPreferred, integer * mfail);

MTIstatus _MakeConfigItemObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr * cfgItemObj, integer * mfail);

MTIstatus _MakeOnAssemblyAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElemObj,
   ObjectPtr makeOnAssmDlgObj, integer * mfail);

MTIstatus _MakeOnAssemblyPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr selectedStrcRel, ObjectPtr elemToRemove, SetOfObjects subStructureRelSet,
   SetOfObjects newRelSet, integer * mfail);

MTIstatus _MakeOnAssemblyPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr selectedStrcRel, ObjectPtr elemToRemove, SetOfObjects subStructureRelSet,
   SetOfObjects newRelSet, integer * mfail);

MTIstatus _MakeOnAssemblySet
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects topLvlProdElmObjSet, SetOfObjects makeOnAssmDlgObjSet, integer * mfail);

MTIstatus _ProcEffRelsForCntxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr contextObj, SetOfObjects * relObjSet, integer * mfail);

MTIstatus _ProcExtractTransform
   (MTIstring _class, boolean getParent, string className,
   string obid, SetOfStrings instIdSet, NVSET * transforms,
   integer * mfail);

MTIstatus _ProcRelForChgCertStatAtClass
   (MTIstring _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr dialogObj, ObjectPtr supplierObj, integer * mfail);

MTIstatus _ProcRelForChgVndStatAtClass
   (MTIstring _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr dialogObj, ObjectPtr vendorObj, integer * mfail);

MTIstatus _PropagateAbsoluteOccAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sourceFactory,
   ObjectPtr destFactory, integer * mfail);

MTIstatus _PropagateOccurrencesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sourceObj,
   ObjectPtr destObj, boolean copyRelativeOcc, boolean copyAbsoluteOcc,
   integer * mfail);

MTIstatus _PropagateRelativeOccAtClass
   (MTIstring _class, boolean getParent, ObjectPtr oldRelObj,
   ObjectPtr newRelObj, ObjectPtr newOccFactory, ObjectPtr otherSideFactoryObj,
   integer * mfail);

MTIstatus _RetrieveViewIdListPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   NVSET * eligibleViewIdList, integer * mfail);

MTIstatus _SendAuxViewDepRelDelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr strBIApcObj, ObjectPtr itemMstrObj, string deletedFindNumber,
   string affectedViewMask, integer * mfail);

MTIstatus _SetEffDateInCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, string configIdPref, string effDatePref,
   integer * mfail);

MTIstatus _SetEffUnitInCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, string configIdPref, string effUnitPref,
   integer * mfail);

MTIstatus _SetEffectivityPrefAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean global, string cfgItemId, string effectiveDate,
   string effectiveUnit, integer * mfail);

MTIstatus _SetEffectivityPrefPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _SetIncZeroQtyInCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, boolean includeZeroQty, integer * mfail);

MTIstatus _SetIncludeZeroQtyPrefAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean global, boolean value, integer * mfail);

MTIstatus _SetNavViewInCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, string viewNetworkPref, string viewNamePref,
   integer * mfail);

MTIstatus _SetNavigateViewPrefAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean global, string network, string name,
   integer * mfail);

MTIstatus _SetNavigateViewPrefPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _SetStrcOptListInCtxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, SetOfStrings strcOptListPref, integer * mfail);

MTIstatus _SetStrcOptListPrefAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean global, SetOfStrings optionList, integer * mfail);

MTIstatus _SetStrcOptListPrefPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _SetStructureOptionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr strcOptObj, ObjectPtr vewObj, ObjectPtr dialogObj,
   integer * mfail);

MTIstatus _SetViewPrefAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean global, string network, string name,
   integer * mfail);

MTIstatus _SetViewPrefPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _SplitBOMAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr splitBOMDlgObj, integer * mfail);

MTIstatus _SplitBOMPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr selectedStrcRel, integer quantity, SetOfStrings occurrenceIds,
   SetOfObjects newRelSet, integer * mfail);

MTIstatus _SplitBOMPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr selectedStrcRel, integer quantity, SetOfStrings occurrenceIds,
   SetOfObjects newRelSet, integer * mfail);

MTIstatus _SplitBOMSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects topLvlProdElmObjSet, SetOfObjects splitBOMDlgObjSet, integer * mfail);

MTIstatus _UpdateRevEffObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr vewObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _UpdateStrcEffObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr vewObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _UpdateStructurObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr vewObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _UpdateSubPartObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr vewObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _UpdateViewDepObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr vewObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValCntnsItmForCntnsRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr containsItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValComPrtForDelRprsntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr comPrtObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValCpgForCreRpsRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComPrtObj,
   ObjectPtr reprsntsObj, integer * mfail);

MTIstatus _ValForAssignEOLDateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   integer * mfail);

MTIstatus _ValForChgCertStatusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   integer * mfail);

MTIstatus _ValForChgVndStatusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   integer * mfail);

MTIstatus _ValGSplrForDelSupSvcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr supplierObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValGdmForCrePdsRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gdiMstrObj,
   ObjectPtr prtDstMrObj, integer * mfail);

MTIstatus _ValGdmForDelPrtDstMrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr distMstrObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValGmmForCrePmmRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gmfMstrObj,
   ObjectPtr prtMfrMrObj, integer * mfail);

MTIstatus _ValGmmForDelPrtMfrMrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr mfgMstrObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValGmpForCrePmmRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnMfgPrtObj,
   ObjectPtr prtMfrMrObj, integer * mfail);

MTIstatus _ValGmpForCreRpsRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnMfgPrtObj,
   ObjectPtr reprsntsObj, integer * mfail);

MTIstatus _ValGspForCreSpcRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr supSvcObj, integer * mfail);

MTIstatus _ValGumForCrePssRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gspMstrObj,
   ObjectPtr prtSupMrObj, integer * mfail);

MTIstatus _ValGumForDelPrtSupMrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr supplierMObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValItemForHasPkgRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr busItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValLeftPrtMrForCreAltRAtClass
   (MTIstring _class, boolean getParent, ObjectPtr leftPartMstr,
   ObjectPtr altPartRel, integer * mfail);

MTIstatus _ValMPartForDelPrtMfrMrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr mfgPrtObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValMfgPrtForDelRprsntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr mfgPrtObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPartForDelPrtDstMrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prtObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPartForDelPrtSupMrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr PartObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPkgForCreCntnsRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr pkgItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPkgForCreHasPkgRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr pkgItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPrtForCrePdsRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   ObjectPtr prtDstMrObj, integer * mfail);

MTIstatus _ValPrtForCrePssRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   ObjectPtr prtSupMrObj, integer * mfail);

MTIstatus _ValPrtForCreSubPrtRAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   ObjectPtr subPartRel, integer * mfail);

MTIstatus _ValPrtMrForCreAsmStrcRAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partMstrObj,
   ObjectPtr assmStrcRel, integer * mfail);

MTIstatus _ValPrtMrForCreSubPrtRAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partMasterObj,
   ObjectPtr subPartRel, integer * mfail);

MTIstatus _ValRghtPrtMrForCreAltRAtClass
   (MTIstring _class, boolean getParent, ObjectPtr rightPartMstr,
   ObjectPtr altPartRel, integer * mfail);

MTIstatus _ValSgdForCreVsdRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stGenDocObj,
   ObjectPtr vndStDocObj, integer * mfail);

MTIstatus _ValSgdForDelVndStDocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stGenDocObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValStyForCreSpcRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr svcTypeObj,
   ObjectPtr supSvcObj, integer * mfail);

MTIstatus _ValSvcTypeForDelSupSvcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr svcTypeObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValVnmForCreVsdRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vndMstrObj,
   ObjectPtr vndStDocObj, integer * mfail);

MTIstatus _ValVnmForDelVndStDocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorMObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValidatePrcRevAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relObj, SetOfStrings * badArgs, integer * mfail);

#ifdef _LCINTERP_
}
#else

/*
 *  Unpublished Messages
 */

MTIstatus _ActivateVewNetNDNPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _AddEffRelItmMstrSql
   (MTIstring _class, boolean getParent, string className,
   string relationship, SqlPtr sql, integer * mfail);

MTIstatus _AddOccurrence
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr dialogObj, ObjectPtr leftObj, ObjectPtr rightObj,
   ObjectPtr * relationObj, integer * mfail);

MTIstatus _AddStrcOptsToQuantity
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr variantObj, ObjectPtr relObj, string * newQuantity,
   integer * mfail);

MTIstatus _AddToReportImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   MTIstring partNumber, SetOfObjects revEffObjSet, SetOfObjects usageEffObjSet,
   SetOfObjects * reportEffObjSet, integer * mfail);

MTIstatus _AddVewContextToSql
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, string relationship, SqlPtr sql,
   integer * mfail);

MTIstatus _AdjustQueryForSvcType
   (MTIstring _class, boolean getParent, string className,
   integer scope, ObjectPtr queryArgs, SetOfObjects * objects,
   integer * mfail);

MTIstatus _AllowsEditHasRevEffsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AllowsEditUsesPartMstrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AllowsFreezeForViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AlwPrcExpRelObjsForOpt
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects itemObjSet, string relationship, ObjectPtr genContextObj,
   SetOfObjects * relObjSet, integer * mfail);

MTIstatus _ApplyCtxtToQuantity
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr variantObj, ObjectPtr relObj, string * newQuantity,
   integer * mfail);

MTIstatus _AsRevRevDb
   (MTIstring _class, boolean getParent, string className,
   boolean action, integer * mfail);

MTIstatus _AssignEOLDateDPIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   integer * mfail);

MTIstatus _AssignEOLDateIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   ObjectPtr assignEOLDateDlg, integer * mfail);

MTIstatus _AssignToViewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AuxViewDepRelCopy
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr strBIApcObj, ObjectPtr itemMstrObj, string oldFindNumber,
   string newFindNumber, string affectedViewMask, integer * mfail);

MTIstatus _AuxViewDepRelDel
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr strBIApcObj, ObjectPtr itemMstrObj, string deletedFindNumber,
   string affectedViewMask, integer * mfail);

MTIstatus _AuxViewUpdFindNumberAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string newFindNumber, integer * mfail);

MTIstatus _BOMEdit
   (MTIstring _class, boolean getParent, string className,
   integer failPreference, ObjectPtr BOMEditSetDlg, integer * mfail);

MTIstatus _BOMEditAdd
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr BOMEditDlg, ObjectPtr ViewObj, integer * mfail);

MTIstatus _BOMEditRemove
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr BOMEditDlg, ObjectPtr ViewObj, integer * mfail);

MTIstatus _BOMEditReplace
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr BOMEditDlg, ObjectPtr ViewObj, integer * mfail);

MTIstatus _BOMEditReplaceParent
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr BOMEditDlg, ObjectPtr ViewObj, integer * mfail);

MTIstatus _BOMEditReplaceRelationAtClass
   (MTIstring _class, boolean getParent, ObjectPtr replacingObj,
   ObjectPtr existingRelationObj, ObjectPtr EditDialogObj, ObjectPtr ViewObj,
   string relationAttrs, integer * mfail);

MTIstatus _BOMEditUpdate
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr BOMEditDlg, ObjectPtr ViewObj, integer * mfail);

MTIstatus _BOMGradingXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _BaselineItemIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr part,
   SetOfObjects * busItems, SetOfObjects * dataItems, integer * mfail);

MTIstatus _BldDynObjSetsForEffRel
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects itemObjSet, string relationship, integer scope,
   SetOfObjects * relObjSet, SetOfObjects * otherSideObjSet, integer * mfail);

MTIstatus _BldDynSetsForStrcOptR
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects itemObjSet, string relationship, integer scope,
   SetOfObjects * relObjSet, SetOfObjects * otherSideObjSet, integer * mfail);

MTIstatus _BldStrcOptROBIDAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemMstrObj, ObjectPtr strcOptObj, ObjectPtr strucApcObj,
   integer * mfail);

MTIstatus _BldStrcOptValsForDyn
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings strcOptValueList, ObjectPtr newRelObj, integer * mfail);

MTIstatus _BuildCIFromItemMstr
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemMstrObj, ObjectPtr * cfgDialogObj, ObjectPtr * cfgItemObj,
   integer * mfail);

MTIstatus _BuildDialogInfoForApp
   (MTIstring _class, boolean getParent, string className,
   string dlgConst, ObjectPtr parentStrucBIObj, ObjectPtr interfaceObj,
   ObjectPtr * dialogObj, integer * mfail);

MTIstatus _BuildInterfaceForApp
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr parentStrucBIObj, ObjectPtr childStrucBIObj, string interfaceClassName,
   ObjectPtr * interfaceObj, integer * mfail);

MTIstatus _BuildListOfViewNames
   (MTIstring _class, boolean getParent, string className,
   boolean forNetwork, string viewNetwork, boolean getOnlyActive,
   string viewMask, SetOfStrings * values, integer * mfail);

MTIstatus _BuildListOfViewNtwks
   (MTIstring _class, boolean getParent, string className,
   boolean getOnlyActivated, SetOfStrings * values, integer * mfail);

MTIstatus _BuildStructuresForApp
   (MTIstring _class, boolean getParent, string className,
   string applicationOwner, ObjectPtr parentStrucBIObj, SetOfObjects childStrucBIObjSet,
   SetOfObjects interfaceObjSet, integer * mfail);

MTIstatus _BuildVewNtwkMapping
   (MTIstring _class, boolean getParent, string className,
   boolean retrieveOnlyNtwkInfo, string curVewNtwkBitPos, string newVewNtwkBitPos,
   string newStartingBitPos, NVSET * strtBitPosMapSet, NVSET * curVewMaskMapSet,
   NVSET * frozVewMaskMapSet, NVSET * ntwkVewMaskMapSet, integer * mfail);

MTIstatus _CanAuxViewDepRelBeCpyAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects existingRelsSet, string affectedViewMask, string * newViewMask,
   boolean * shouldCopy, integer * mfail);

MTIstatus _ChangeVewForVewNetwork
   (MTIstring _class, boolean getParent, string className,
   boolean addingVew, ObjectPtr predVewObj, ObjectPtr succVewObj,
   integer * mfail);

MTIstatus _CheckForEffRange
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, SetOfObjects effRelObjSet, integer itemSide,
   ObjectPtr genContextObj, boolean * effExists, boolean * effStarted,
   boolean * effEnded, integer * mfail);

MTIstatus _CheckIfCfgItemExists
   (MTIstring _class, boolean getParent, string className,
   string cfgItemId, boolean mustBeActive, ObjectPtr * cfgItemObj,
   integer * mfail);

MTIstatus _CheckIfNetworkUsed
   (MTIstring _class, boolean getParent, string className,
   string vewNtwkBitPos, ObjectPtr * foundObject, string * foundDbName,
   integer * mfail);

MTIstatus _CheckIfStrcOptExists
   (MTIstring _class, boolean getParent, string className,
   string strcOptName, integer * mfail);

MTIstatus _CheckIfValidCfgItems
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings cfgItemIdSet, integer * mfail);

MTIstatus _CheckIfValidStrcOpt
   (MTIstring _class, boolean getParent, string className,
   string strcOptName, integer * mfail);

MTIstatus _CheckIfValidVew
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, string viewName, ObjectPtr * vewObj,
   integer * mfail);

MTIstatus _CheckIfValidVewNetwork
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, ObjectPtr * vewObj, integer * mfail);

MTIstatus _CheckIfVewExists
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, string viewName, integer * mfail);

MTIstatus _CheckNIAccessForVewDep
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr objectToCheck, boolean isForVewDepMessage, integer * mfail);

MTIstatus _CheckRealOutOfDateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr realRelObj, integer * mfail);

MTIstatus _ChgCertificatStatDPIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   integer * mfail);

MTIstatus _ChgCertificatStatusIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ChgVendorStatusDPIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   integer * mfail);

MTIstatus _ChgVendorStatusIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ChkVewDepRelOnRefresh
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr originalObj, ObjectPtr refreshedObj, boolean * found,
   integer * mfail);

MTIstatus _ClearVewContextInfo
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr obj, integer * mfail);

MTIstatus _CompareAssembliesXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr contextObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr dialogObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _CompareAttrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr cmprObj, string host, string usr,
   string fullPath, integer maxLevel, integer * mfail);

MTIstatus _CompareAttrsStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, ObjectPtr cmprObj, integer * mfail);

MTIstatus _CompareStructAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr cmprObj, string host, string usr,
   string fullPath, integer maxLevel, integer * mfail);

MTIstatus _CompareStructStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, ObjectPtr cmprObj, integer * mfail);

MTIstatus _ConsolidateVewDepPredAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr leftObj, ObjectPtr rightObj, boolean * relConsolidated,
   integer * mfail);

MTIstatus _ConstrainRelViewMaskAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ConvertQtyToDisplay
   (MTIstring _class, boolean getParent, string className,
   string neutralQty, string unit, string * displayQty,
   integer * mfail);

MTIstatus _ConvertQtyToNeutral
   (MTIstring _class, boolean getParent, string className,
   string displayQty, string unit, string * neutralQty,
   integer * mfail);

MTIstatus _ConvertViewBitToName
   (MTIstring _class, boolean getParent, string className,
   string viewBitPos, string * viewNetwork, string * viewName,
   integer * mfail);

MTIstatus _ConvertViewNameToBit
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, string viewName, string * viewBitPos,
   integer * mfail);

MTIstatus _CopyAuxViewDepRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string affectedViewMask, string oldFindNumber, string newFindNumber,
   integer * mfail);

MTIstatus _CopyPlmToArgObjInt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr plmObj, ObjectPtr argsObj, integer * mfail);

MTIstatus _CpyInfoForVewDepRefrshAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr realRelObj, boolean * found, integer * mfail);

MTIstatus _CpyVewContextInfo
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr fromObj, boolean forExpand, ObjectPtr toObj,
   integer * mfail);

MTIstatus _CreCreDlgForIntUnitsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr DIntArgsObj, ObjectPtr * creDlgObj, integer * mfail);

MTIstatus _CreOrUpdAssmStrcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prntProdElemObj,
   ObjectPtr chldProdElemObj, ObjectPtr * assmStrcObj, integer * mfail);

MTIstatus _CreateReportObjImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   MTIstring itemType, MTIstring level, MTIstring parentPart,
   MTIstring usageStart, MTIstring usageEnd, MTIstring authorityStart,
   MTIstring authortyEnd, MTIstring cfgItemId, ObjectPtr * rptObj,
   integer * mfail);

MTIstatus _CreateStructureForApp
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr parentStrucBIObj, ObjectPtr childItemMstrObj, ObjectPtr interfaceObj,
   ObjectPtr * relObj, integer * mfail);

MTIstatus _DGetLVS4ActViewNtwksAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVS4AllViewNtwksAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVS4CreVewToVewsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVS4QryListViewsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVS4ViewInNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVS4WorkingViewsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSAllRevisionsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCertStatusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSPackageTypeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSVndStatusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetPVS4ViewInNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DeactivateVewNetNDNPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DeleteOccurrence2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DeleteStructureForAppAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr parentStrucBIObj, integer * mfail);

MTIstatus _DetectRecursivePSAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * asmPath, SetOfStrings * recLineElems, SetOfStrings * inpSet,
   SetOfObjects itemObjs, SetOfObjects relObjs, string attribName,
   string relClass, string relnShipName, integer * mfail);

MTIstatus _DoActivateVewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignEOLDateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   ObjectPtr assignEOLDateDlg, integer * mfail);

MTIstatus _DoAssignEOLDatePostIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   ObjectPtr assignEOLDateDlg, integer * mfail);

MTIstatus _DoAssignEOLDatePreIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   ObjectPtr assignEOLDateDlg, integer * mfail);

MTIstatus _DoAssignToViewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAuxViewDepDeleteAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string deletedViewMask, integer * mfail);

MTIstatus _DoAuxViewDepUpdateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, string changedViewMask, integer * mfail);

MTIstatus _DoChgCertStatusPostIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgCertStatusPreIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgCertStatusRelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoChgCertificatStatusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgVendorStatusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgVndStatPostIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgVndStatPreIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgVndStatusRelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoDeactivateVewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DoExpandRevEffectivityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer newWindow, ObjectPtr genContextObj, integer * mfail);

MTIstatus _DoFreezeOfRelObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoFreezeViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DoFreezeViewOfRelObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DoGenerateBOMAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, string host, string usr,
   string fullPath, integer maxLevel, integer * mfail);

MTIstatus _DoGenerateBOMStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, ObjectPtr dialogObj, integer maxLevel,
   integer * mfail);

MTIstatus _DoGenerateBOMXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * prtObjSet, SetOfObjects * relObjSet, ObjectPtr dialogObj,
   integer maxLevel, integer * mfail);

MTIstatus _DoGenerateBOMXML2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer maxLevel, SetOfStrings auxMessages,
   string converterClass, ObjectPtr converterDialog, ObjectPtr outputHandler,
   integer * mfail);

MTIstatus _DoGenerateCmprAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, string host, string usr,
   string fullPath, integer maxLevel, integer * mfail);

MTIstatus _DoGenerateCmprStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoGeneratePartsListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, string host, string usr,
   string fullPath, integer * mfail);

MTIstatus _DoGeneratePartsListStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoGenerateRecDecAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, string host, string usr,
   string fullPath, integer * mfail);

MTIstatus _DoGenerateRecDecStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoGenerateRecDecXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfObjects * prtObjSet, SetOfObjects * relObjSet,
   integer * mfail);

MTIstatus _DoGenerateWusdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, string host, string usr,
   string fullPath, integer maxLevel, integer * mfail);

MTIstatus _DoGenerateWusdStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, ObjectPtr dialogObj, integer maxLevel,
   integer * mfail);

MTIstatus _DoGenerateWusdXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer maxLevel, SetOfObjects * prtObjSet,
   SetOfObjects * relObjSet, integer * mfail);

MTIstatus _DoMarkVewNetworkUnusedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DoMigOrRemVewNtwkInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string hostName, string directory, boolean migratingViewNetwork,
   string newViewNetworkName, integer * mfail);

MTIstatus _DoMigOrRemViewMasks
   (MTIstring _class, boolean getParent, string className,
   string hostName, string directory, SetOfStrings dbNameSet,
   SetOfStrings queryClassSet, string viewMaskAttr, string curVewNtwkBitPos,
   NVSET ntwkViewMaskMapSet, boolean migrate, string newVewNtwkBitPos,
   NVSET strtBitPosMapSet, NVSET viewMaskMapSet, integer * mfail);

MTIstatus _DoMigrateBusItemAttrs
   (MTIstring _class, boolean getParent, string className,
   string hostName, string directory, SetOfStrings dbNameSet,
   SetOfStrings queryClassSet, string curVewNtwkBitPos, string newVewNtwkBitPos,
   NVSET strtBitPosMapSet, integer * mfail);

MTIstatus _DoPrepareAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoRelateRevEffectivityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DoRelateStrucEffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _DoRelateStrucOptionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _DoRelateSubPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _DoRemoveBusItemAttrs
   (MTIstring _class, boolean getParent, string className,
   string hostName, string directory, SetOfStrings dbNameSet,
   SetOfStrings queryClassSet, string newVewNtwkBitPos, integer * mfail);

MTIstatus _DoRevisePrtStDocPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   integer * mfail);

MTIstatus _DoSetupSubPartForChges
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr strBIApcObj, integer * mfail);

MTIstatus _DoViewDepCreateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr bgObj, integer * mfail);

MTIstatus _DoViewDepDeleteAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string viewContextBitPosition, boolean * deleteRelation, string * changedViewMask,
   integer * mfail);

MTIstatus _DoViewDepUpdateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string viewContextBitPosition, string * changedViewMask, integer * mfail);

MTIstatus _DoesRelNeedViewInfo
   (MTIstring _class, boolean getParent, string className,
   integer * needViewInfoType, integer * mfail);

MTIstatus _DupViewDepRelPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr leftObj, ObjectPtr rightObj, integer * mfail);

MTIstatus _DuplicateViewDepERORelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sourceObj, ObjectPtr newObj, ObjectPtr * newRelObj,
   integer * mfail);

MTIstatus _DuplicateViewDepRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sourceObj, ObjectPtr newObj, integer * mfail);

MTIstatus _EffectivityImplosion
   (MTIstring _class, boolean getParent, string msgClassName,
   SetOfObjects selectedItems, ObjectPtr dialogObj, SetOfStrings * AttrListForDisplay,
   SetOfObjects * outputSet, integer * mfail);

MTIstatus _ExpandItem3
   (MTIstring _class, boolean getParent, string relationClass,
   ObjectPtr strucBi, string relationship, ObjectPtr cfgCntxt,
   integer scope, SetOfObjects * relations, SetOfObjects * pdmItems,
   integer * mfail);

MTIstatus _ExpandItemInt
   (MTIstring _class, boolean getParent, string relationClass,
   ObjectPtr strucBi, string relationship, ObjectPtr cfgCntxt,
   integer scope, SetOfObjects * relations, SetOfObjects * pdmItems,
   integer * mfail);

MTIstatus _ExpandRevEffectivityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer newWindow, ObjectPtr genContextObj, integer * mfail);

MTIstatus _FilterItmTmplSetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr reportObjMgmtArgs,
   SetOfObjects * relTemplateSet, integer * mfail);

MTIstatus _FilterStrucApcsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string deletedFindNumber, string deletedViewMask, string * affectedViewMask,
   boolean * deleteAuxRels, integer * mfail);

MTIstatus _FindConstrainedRelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * relations, integer * mfail);

MTIstatus _FindDocMstr
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr qryDef, ObjectPtr * docMstrObj, integer * mfail);

MTIstatus _FindObjForPrepareAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr * prepareObj, integer * mfail);

MTIstatus _FindPartMstr
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr qryDef, ObjectPtr * partMstrObj, integer * mfail);

MTIstatus _FindUnusedCfgItems
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings cfgItemIdSet, SetOfObjects * unusedCfgItems, integer * mfail);

MTIstatus _FindVewDepRelships
   (MTIstring _class, boolean getParent, string className,
   string classNameId, string * classNameUsed, string * strucBIRelship,
   string * otherRelship, integer * mfail);

MTIstatus _FreezeViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenSuppliedPartsXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GenerateBOMAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenerateBOMStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _GenerateBOMXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GenerateCmprAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenerateCmprStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _GenerateDetailsXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string relationClass, string relationshipName, string lineSeparator,
   ObjectPtr taskObject, ObjectPtr argsObj, ObjectPtr * resultXMLObj,
   boolean * needToTranslit, integer * mfail);

MTIstatus _GenerateDocDetailsRptAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _GenerateDocDetailsXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GeneratePartDetailsRptAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _GeneratePartDetailsXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GeneratePartsListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GeneratePartsListStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _GeneratePartsListXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GenerateRecDecAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenerateRecDecStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _GenerateRecDecXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GenerateWusdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenerateWusdStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _GenerateWusdXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GetActiveBaseVewObjSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * vewNetworkObjSet, integer * mfail);

MTIstatus _GetAllAnstrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr chldProdElemObj,
   SetOfObjects * prntProdElemObjs, integer * mfail);

MTIstatus _GetAllFirstLvlObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prodElemObj,
   SetOfObjects * chldProdElemObjs, SetOfObjects * chldPEOccObjs, integer * mfail);

MTIstatus _GetAllOffrdSvcObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * serviceObjs, SetOfObjects * relObjs, integer * mfail);

MTIstatus _GetAllPartRevEffImplAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * thisSet, integer * mfail);

MTIstatus _GetAllServiceNames
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllVewObjSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * vewObjSet, integer * mfail);

MTIstatus _GetAllVewsInNetwork
   (MTIstring _class, boolean getParent, string className,
   string viewNetworkBitPos, SetOfObjects * vewNetworkSet, integer * mfail);

MTIstatus _GetAltPrtsForBOMXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   SetOfObjects partSet, ObjectPtr argsObj, SetOfObjects * altPrtSet,
   SetOfObjects * altPrtRelSet, integer * mfail);

MTIstatus _GetAppPrefMfrForMfgPrtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnMfgPrtObj,
   SetOfObjects * mfrObjs, SetOfObjects * mfrRels, integer * mfail);

MTIstatus _GetAssmStrcFrmPelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr parentObj,
   ObjectPtr childObj, ObjectPtr * assmStrcObj, integer * mfail);

MTIstatus _GetAuxViewDepRels
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr strBIApcObj, ObjectPtr itemMstrObj, string findNumber,
   string affectedViewMask, SetOfObjects * relObjSet, integer * mfail);

MTIstatus _GetBaseVewObjByNtwk
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, ObjectPtr * vewObj, integer * mfail);

MTIstatus _GetCfgItemObjById
   (MTIstring _class, boolean getParent, string className,
   string cfgItemId, ObjectPtr * cfgItemObj, integer * mfail);

MTIstatus _GetContigViewMaskSet
   (MTIstring _class, boolean getParent, string className,
   string viewMask, SetOfObjects vewNetworkSet, SetOfStrings * contigViewMaskSet,
   integer * mfail);

MTIstatus _GetCorrespondingViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects vewSet, ObjectPtr * vewObj, integer * mfail);

MTIstatus _GetCreationViewMask
   (MTIstring _class, boolean getParent, string className,
   string viewBitPos, string * creationViewMask, integer * mfail);

MTIstatus _GetDbBaseVewObjByNtwk
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, ObjectPtr * vewObj, integer * mfail);

MTIstatus _GetDbVewObjByViewBit
   (MTIstring _class, boolean getParent, string className,
   string viewBitPos, ObjectPtr * vewObj, integer * mfail);

MTIstatus _GetDbVewObjByViewName
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, string viewName, ObjectPtr * vewObj,
   integer * mfail);

MTIstatus _GetDbVewSetByViewName
   (MTIstring _class, boolean getParent, string className,
   string viewName, SetOfObjects * viewObjs, integer * mfail);

MTIstatus _GetDbViewsForNetwork
   (MTIstring _class, boolean getParent, string className,
   string viewNetworkBitPos, SetOfObjects * vewNetworkSet, integer * mfail);

MTIstatus _GetDistribrsForBOMXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   SetOfObjects partSet, ObjectPtr argsObj, SetOfObjects * distrObjSet,
   SetOfObjects * distrByRelSet, integer * mfail);

MTIstatus _GetEditViewRelRuleMsg
   (MTIstring _class, boolean getParent, string className,
   string * ruleMsg, integer * mfail);

MTIstatus _GetEffBasedOnCntxt
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects itemObjSet, string relationship, ObjectPtr contextObj,
   SetOfObjects * effRelObjSet, integer * itemSide, integer * mfail);

MTIstatus _GetEffDynToRealInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * realRelClassName, integer * realRelBISide, string * realRelBIRelship,
   ObjectPtr * realRelBIObj, integer * mfail);

MTIstatus _GetEligibleViewIdList
   (MTIstring _class, boolean getParent, string className,
   integer eligibleViewType, string viewNetworkBitPos, string startingViewBitPos,
   string frozenViewMask, NVSET * eligibleViewIdList, integer * mfail);

MTIstatus _GetEndItemRangesImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects rptSet, SetOfObjects * rangeSet, integer * mfail);

MTIstatus _GetFirstItemRangesImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects rptSet, SetOfObjects * rangeSet, integer * mfail);

MTIstatus _GetFolderContentForSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects folders, SetOfStrings includeClasses, SetOfStrings excludeClasses,
   boolean latest, boolean available, boolean topLevel,
   SetOfObjects * folderContents, integer * mfail);

MTIstatus _GetFrozenViewMask
   (MTIstring _class, boolean getParent, string className,
   string currentViewBitPos, string * frozenViewMask, integer * mfail);

MTIstatus _GetInRevwMfrForMfgPrtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnMfgPrtObj,
   SetOfObjects * mfrObjs, SetOfObjects * mfrRels, integer * mfail);

MTIstatus _GetLastItemRangesImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects rptSet, boolean * multiLevels, SetOfObjects * rangeSet,
   integer * mfail);

MTIstatus _GetLatestPartsImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects * partSet, integer * mfail);

MTIstatus _GetMfrForMfgPrtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnMfgPrtObj,
   SetOfObjects * mfrObjs, SetOfObjects * mfrRels, integer * mfail);

MTIstatus _GetNavViewContextAtClass
   (MTIstring _class, boolean getParent, ObjectPtr contextObj,
   string relationship, boolean * cfgCtxDisabled, string * currentViewBitPos,
   string * currentViewNetwork, string * currentViewName, integer * mfail);

MTIstatus _GetNewViewInfoFrmDlgAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * viewNetworkName, string * startingViewName, integer * mfail);

MTIstatus _GetParamsForILVAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr insertLevelDlgObj, ObjectPtr * newObject, string * newObjClass,
   ObjectPtr * newLeftRelDlg, string * newLeftRelClass, ObjectPtr * newRightRelDlg,
   string * newRightRelClass, SetOfObjects * selectedStrcRels, ObjectPtr * vewObject,
   integer * mfail);

MTIstatus _GetParamsForMOAAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr makeOnAssmDlgObj, ObjectPtr * elemToRemove, ObjectPtr * selectedStrcRel,
   ObjectPtr * vewObject, integer * mfail);

MTIstatus _GetParamsForSBMAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlPrdElmObj,
   ObjectPtr splitBOMDlgObj, ObjectPtr * structureRelation, string * quantity,
   SetOfStrings * occurrenceIds, ObjectPtr * vewObject, boolean * freeOccIds,
   integer * mfail);

MTIstatus _GetPreciseRelations
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr leftObject, string leftOBID, string currentViewBitPos,
   SetOfObjects * relationSet, integer * mfail);

MTIstatus _GetRealEffRelationAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * realRelObj, integer * mfail);

MTIstatus _GetRealEffSideRelShip
   (MTIstring _class, boolean getParent, string className,
   string dynamicRelship, integer * realRelSide, string * realRelship,
   integer * mfail);

MTIstatus _GetReprsAppMfgPrtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComPrtObj,
   SetOfObjects * mfgPrtObjs, SetOfObjects * reprsRels, integer * mfail);

MTIstatus _GetReprsMfgPrtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComPrtObj,
   SetOfObjects * mfgPrtObjs, SetOfObjects * reprsRels, integer * mfail);

MTIstatus _GetSelectedTblRowsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   SetOfStrings * allSelctdSvcs, SetOfStrings * offrdSvcs, SetOfStrings * aprvdSvcs,
   SetOfStrings * prefrdSvcs, integer * mfail);

MTIstatus _GetSpecialCreViewMask
   (MTIstring _class, boolean getParent, string className,
   string viewNetworkBitPos, string oldCreViewMask, SetOfStrings viewMaskSet,
   string * newCreViewMask, integer * mfail);

MTIstatus _GetStrcOptObjByName
   (MTIstring _class, boolean getParent, string className,
   string strcOptName, ObjectPtr * strcOptObj, integer * mfail);

MTIstatus _GetStrcOptRFromStruc
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr strucApc, string strcOptName, ObjectPtr * strucOptR,
   integer * mfail);

MTIstatus _GetStrucApcFromFindNum
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr strBIApcObj, ObjectPtr itemMstrObj, string findNumber,
   SetOfObjects * strucApcObjSet, integer * mfail);

MTIstatus _GetStructObjForView
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects strucObjs, ObjectPtr viewObj, ObjectPtr * selectedObj,
   integer * mfail);

MTIstatus _GetStructureOptionRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr strcOptObj, ObjectPtr vewObj, ObjectPtr * strcOptRObj,
   integer * mfail);

MTIstatus _GetSubstPrtsForBOMXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   SetOfObjects partSet, ObjectPtr argsObj, SetOfObjects * subPrtSet,
   SetOfObjects * subPrtRelSet, integer * mfail);

MTIstatus _GetSuppDocForVendorAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   SetOfObjects * suppDocObjs, SetOfObjects * suppDocRels, integer * mfail);

MTIstatus _GetSuppliersForBOMXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   SetOfObjects partSet, ObjectPtr argsObj, SetOfObjects * suppObjSet,
   SetOfObjects * suppByRelSet, integer * mfail);

MTIstatus _GetUnusedBaseVewObjSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * vewNetworkObjSet, integer * mfail);

MTIstatus _GetUpdateViewMasks
   (MTIstring _class, boolean getParent, string className,
   string currentViewBitPos, string currentViewMask, string * changedViewMask,
   string * unchangedViewMask, integer * mfail);

MTIstatus _GetUsedBaseVewObjSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * vewNetworkObjSet, integer * mfail);

MTIstatus _GetVewDepRObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * strBIApcObj, ObjectPtr * itemMstrObj, integer * mfail);

MTIstatus _GetVewDepRealRelForDynAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * realRelObj, integer * mfail);

MTIstatus _GetVewNetworkIdList
   (MTIstring _class, boolean getParent, string className,
   NVSET * vewNetworkIdList, integer * mfail);

MTIstatus _GetVewObjByViewBit
   (MTIstring _class, boolean getParent, string className,
   string viewBitPos, ObjectPtr * vewObj, integer * mfail);

MTIstatus _GetVewObjByViewName
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, string viewName, ObjectPtr * vewObj,
   integer * mfail);

MTIstatus _GetVewPredecessor
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr vewObj, ObjectPtr * predVewObj, integer * mfail);

MTIstatus _GetVewPredecessorBit
   (MTIstring _class, boolean getParent, string className,
   string viewBitPos, string * predViewBitPos, integer * mfail);

MTIstatus _GetVewSuccessors
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr vewObj, SetOfObjects * vewSuccessorObjSet, integer * mfail);

MTIstatus _GetViewActionConfirmAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * cancel, integer * mfail);

MTIstatus _GetViewDepChangeInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string viewContextBitPosition, string * changedViewMask, string * unchangedViewMask,
   integer * mfail);

MTIstatus _GetViewDepObjsInSesObj
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr * itemObj, ObjectPtr * relObj, integer * mfail);

MTIstatus _GetViewsToWorkInAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer viewActionType, SetOfObjects * vewObjList, integer * mfail);

MTIstatus _InflateEffDisplayInfo
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr effRelObj, integer * mfail);

MTIstatus _InflateForStrucRelateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _InflatePreviousVewInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _InflateSuppObjs
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr genContextObj, SetOfObjects partObjSet, integer * mfail);

MTIstatus _InflateSvcTypes
   (MTIstring _class, boolean getParent, string className,
   integer scope, SetOfObjects * objects, integer * mfail);

MTIstatus _InflateViewNetworkInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _InsertLevelPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   SetOfObjects selectedStrcRels, ObjectPtr newAssmObj, ObjectPtr newRelDlg,
   SetOfObjects newRelSet, integer * mfail);

MTIstatus _InsertLevelPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   SetOfObjects selectedStrcRels, ObjectPtr newAssmObj, ObjectPtr newRelDlg,
   SetOfObjects newRelSet, integer * mfail);

MTIstatus _IntInsertLevelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr insertLvlDlgObj, integer * mfail);

MTIstatus _IntInsertLevel2PostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   SetOfObjects selectedStrcRels, ObjectPtr newObject, ObjectPtr newLeftRelDlg,
   ObjectPtr newRightRelDlg, ObjectPtr vewObject, SetOfObjects newRelSet,
   integer * mfail);

MTIstatus _IntMakeOnAssemblyAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr makeOnAssmDlgObj, integer * mfail);

MTIstatus _IntMakeOnAssemblyPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr selectedStrcRel, ObjectPtr elemToRemove, SetOfObjects subStructureRelSet,
   SetOfObjects newRelSet, integer * mfail);

MTIstatus _IntMakeOnAssemblyProcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr thisSubStructureRelObj, integer relQuantity, string assocStrucOccClassName,
   ObjectPtr parentFactory, ObjectPtr childFactory, SetOfObjects existingObjs,
   SetOfObjects newStructurRelDialogSet, integer * mfail);

MTIstatus _IntSplitBOMAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr splitBOMDlgObj, integer * mfail);

MTIstatus _IntSplitBOMPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr oldRelsEroRightObj, ObjectPtr oldRelsEroObj, SetOfObjects newRelSet,
   integer * mfail);

MTIstatus _IntSplitBOMPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr selectedStrcRel, ObjectPtr * oldRelsEroRightObj, ObjectPtr * oldRelsEroObj,
   integer * mfail);

MTIstatus _IsCreRelAllowCondProcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr relObj,
   string creRelAllowedCondConstant, integer * mfail);

MTIstatus _IsEffOverlappingAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr cmpEffRelObj, boolean * overlapped, integer * mfail);

MTIstatus _IsFindNumberUniqueIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr relObj,
   string findNumber, integer * mfail);

MTIstatus _IsFirstLevelChildAtClass
   (MTIstring _class, boolean getParent, ObjectPtr parentElemObj,
   ObjectPtr childObj, boolean includeAssmStrc, boolean * isChild,
   ObjectPtr * assmStrcObj, integer * mfail);

MTIstatus _IsMaxViewsMet
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _IsObjectViewDependentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isViewDependent, integer * mfail);

MTIstatus _IsSupplierFoundRecurs
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects partObjSet, boolean * isFound, integer * mfail);

MTIstatus _IsVewNameUnique
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, string viewName, ObjectPtr dupObj,
   integer * mfail);

MTIstatus _IsVewNetworkUnique
   (MTIstring _class, boolean getParent, string className,
   string viewNetwork, ObjectPtr dupObj, integer * mfail);

MTIstatus _MakeConfigItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _MakeDbCopyOfViewDepRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string viewMask, integer * mfail);

MTIstatus _MarkCfgItemInUse
   (MTIstring _class, boolean getParent, string className,
   string cfgItemId, integer * mfail);

MTIstatus _MarkCfgItemInUseByObj
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr cfgItemObj, integer * mfail);

MTIstatus _MarkStrcOptInUse
   (MTIstring _class, boolean getParent, string className,
   string strcOptName, integer * mfail);

MTIstatus _MarkVewContextForEdit
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr contextObj, ObjectPtr itemObj, string relationship,
   SetOfObjects * relObjsSet, integer * mfail);

MTIstatus _MarkVewContextForExp
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr contextObj, ObjectPtr itemObj, string relationship,
   SetOfObjects * relObjsSet, integer * mfail);

MTIstatus _MarkVewForInUse
   (MTIstring _class, boolean getParent, string className,
   string viewNetworkBitPos, boolean inUse, integer * mfail);

MTIstatus _MarkVewNetForActivate
   (MTIstring _class, boolean getParent, string className,
   string viewNetworkBitPos, boolean isActivated, string newViewNetwork,
   integer * mfail);

MTIstatus _MarkVewNetworkUnusedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _MergeEndItemSetImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects * endItemsSet, integer * mfail);

MTIstatus _MergeEndItemUsageImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects * completeReportSet, integer * mfail);

MTIstatus _MigrateViewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PERevRevDb
   (MTIstring _class, boolean getParent, string className,
   boolean action, integer * mfail);

MTIstatus _PrepareAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PrepareDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PrepareDisplayQtysAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr variantObj, integer * mfail);

MTIstatus _ProcERORelForAsgnToVewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string curVewNtwkBitPos, NVSET curVewMaskMapSet, integer * mfail);

MTIstatus _ProcExpForCfgItems
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr variantObj, string relationship, SetOfObjects * relObjs,
   integer * mfail);

MTIstatus _ProcExpForRevEffs
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects itemObjSet, ObjectPtr variantObj, string relationship,
   SetOfObjects * relObjSet, integer * mfail);

MTIstatus _ProcExpForStrcEffs
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr variantObj, SetOfObjects itemObjSet, string relationship,
   SetOfObjects * relObjSet, integer * mfail);

MTIstatus _ProcExpForStrcOpts
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr variantObj, SetOfObjects * relObjs, integer * mfail);

MTIstatus _ProcExpForZeroQty
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr variantObj, SetOfObjects * relObjSet, integer * mfail);

MTIstatus _ProcExpRelsObjsForCond
   (MTIstring _class, boolean getParent, string className,
   string condId, SetOfObjects * relObjSet, SetOfObjects * otherSideObjSet,
   integer * mfail);

MTIstatus _ProcExtractWorkflowAtClass
   (MTIstring _class, boolean getParent, ObjectPtr object,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ProcObjForAssignToVewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string curVewNtwkBitPos, string newVewNtwkBitPos, NVSET strtBitPosMapSet,
   NVSET curVewMaskMapSet, NVSET frozVewMaskMapSet, NVSET ntwkVewMaskMapSet,
   boolean mrkInUse, boolean isLocalObjUpdated, integer * mfail);

MTIstatus _ProcOneObjForAsgnToVewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string newVewNtwkBitPos, NVSET strtBitPosMapSet, NVSET frozVewMaskMapSet,
   boolean isLocalObjUpdated, integer * mfail);

MTIstatus _ProcOneRelForAsgnToVewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string curVewNtwkBitPos, NVSET curVewMaskMapSet, integer * mfail);

MTIstatus _ProcRelsForAssignToVewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string curVewNtwkBitPos, NVSET curVewMaskMapSet, integer * mfail);

MTIstatus _ProcRelsForExpVewCntxt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr contextObj, string relationship, SetOfObjects * relObjs,
   integer * mfail);

MTIstatus _ProcRelsInVewForPaging
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr contextObj, string relationship, SetOfObjects * relObjs,
   SetOfObjects * otherSideObjs, integer * mfail);

MTIstatus _ProcessBOMAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * asmPath, ObjectPtr dialogObj, SetOfObjects itemObjs,
   SetOfObjects relObjs, integer maxLevel, integer level,
   integer offst, string host, string usr,
   string fullPath, integer * mfail);

MTIstatus _ProcessBOMStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, SetOfStrings * asmPath, ObjectPtr dialogObj,
   SetOfObjects itemObjs, SetOfObjects relObjs, integer maxLevel,
   integer level, integer offst, integer * mfail);

MTIstatus _ProcessBOMXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * prtObjSet, SetOfObjects * relOjSet, SetOfStrings * asmPath,
   ObjectPtr dialogObj, SetOfObjects itemObjs, SetOfObjects relObjs,
   integer maxLevel, integer level, integer * mfail);

MTIstatus _ProcessBOMXML2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr topLevelObj, SetOfStrings asmPath, ObjectPtr dialogObj,
   SetOfObjects itemObjs, SetOfObjects relObjs, integer maxLevel,
   integer level, SetOfStrings auxMessages, string converterClass,
   ObjectPtr converterDialog, ObjectPtr outputHandler, integer * mfail);

MTIstatus _ProcessImpsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string sParentPart, string sCfgItemEffType, ObjectPtr genContextObj,
   ObjectPtr psContextObj, SetOfStrings ssCfgItemId, boolean useLatest,
   boolean doDetailedReport, integer currentLevel, SetOfObjects droppedObjectSet,
   SetOfStrings parents, SetOfObjects * outputSet, integer * mfail);

MTIstatus _ProcessRecDecAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * asmPath, boolean * recFound, ObjectPtr dialogObj,
   SetOfObjects itemObjs, SetOfObjects relObjs, string host,
   string usr, string fullPath, integer * mfail);

MTIstatus _ProcessRecDecStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, SetOfObjects * asmPath, boolean * recFound,
   ObjectPtr dialogObj, SetOfObjects itemObjs, SetOfObjects relObjs,
   integer * mfail);

MTIstatus _ProcessRecDecXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * prtObjSet, SetOfObjects * relOjSet, SetOfStrings * relPath,
   boolean * recFound, ObjectPtr dialogObj, SetOfObjects itemObjs,
   SetOfObjects relObjs, boolean firstLevel, integer * mfail);

MTIstatus _ProcessWusdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * asmPath, ObjectPtr dialogObj, SetOfObjects itemObjs,
   SetOfObjects relObjs, integer maxLevel, integer level,
   integer offst, string host, string usr,
   string fullPath, integer * mfail);

MTIstatus _ProcessWusdStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * inpSet, SetOfStrings * asmPath, ObjectPtr dialogObj,
   SetOfObjects itemObjs, SetOfObjects relObjs, integer maxLevel,
   integer level, integer offst, integer * mfail);

MTIstatus _ProcessWusdXMLAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * prtObjSet, SetOfObjects * relOjSet, SetOfStrings itemPath,
   ObjectPtr dialogObj, SetOfObjects itemObjs, SetOfObjects relObjs,
   integer maxLevel, integer level, integer * mfail);

MTIstatus _PropagateStrcEffForILV
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects oldStrcRelObjs, SetOfObjects newStrcRelObjs, ObjectPtr vewObj,
   integer * mfail);

MTIstatus _PropagateStrcEffForSBM
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects newStrcRels, SetOfObjects strcEffRels, ObjectPtr vewObj,
   integer * mfail);

MTIstatus _QueryCfgItemIdsImplAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   SetOfStrings * cfgItemIdStrSet, MTIstring * cfgItemEffType, integer * mfail);

MTIstatus _QueryMatchStrucApcsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string matchingFindNumber, string matchingViewMask, SetOfObjects * matchingStrucApcs,
   integer * mfail);

MTIstatus _QueryPartEffsImplAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr genContextObj, SetOfStrings cfgItemIdStrSet, SetOfObjects otherSideObjSet,
   SetOfObjects * partEffObjSet, integer * mfail);

MTIstatus _QueryRevEffsImplAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings cfgItemIdStrSet, boolean useCustom, SetOfObjects * revEffObjSet,
   integer * mfail);

MTIstatus _RefreshItForApcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _RelateRevEffectivityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _RelateStrcEffectivityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _RelateStrucEffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _RelateStrucOptionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _RelateSubPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _RemoveOneObjFromVewNetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   NVSET ntwkVewMaskMapSet, boolean isLocalObjUpdated, integer * mfail);

MTIstatus _RemoveOneRelFromVewNetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string curVewNtwkBitPos, NVSET ntwkVewMaskMapSet, integer * mfail);

MTIstatus _RemoveRelsFromVewNetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   NVSET ntwkVewMaskMapSet, integer * mfail);

MTIstatus _RemoveVewNtwkInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ReplacePartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr replaceThis,
   ObjectPtr replaceWith, SetOfObjects affectedAssms, ObjectPtr vewObj,
   integer * mfail);

MTIstatus _RetrieveViewIdListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string ruleMsg, integer eligibleViewType, NVSET * eligibleViewIdList,
   integer * mfail);

MTIstatus _RetrieveViewIdListRuleAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string ruleMsg, integer eligibleViewType, NVSET * eligibleViewIdList,
   integer * mfail);

MTIstatus _RetrieveWorkingViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string ruleMsg, integer eligibleViewType, boolean forceDialog,
   boolean * cancel, integer * mfail);

MTIstatus _RetrieveWorkingViewObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string ruleMsg, integer eligibleViewType, ObjectPtr vewObj,
   integer * mfail);

MTIstatus _SaveRevisionOfStrucBI
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _SendAuxViewDepRelCopyAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr strBIApcObj, ObjectPtr itemMstrObj, string oldFindNumber,
   string newFindNumber, string affectedViewMask, integer * mfail);

MTIstatus _SetCfgItemCreateDialogAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _SetEndItemRevsImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects * outputSet, integer * mfail);

MTIstatus _SetEndItemUsageImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects * usageEffObjSet, integer * mfail);

MTIstatus _SetFirstLevelUsageImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects * completeReportSet, integer * mfail);

MTIstatus _SetMergeRevUsageImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects * rptSet, integer * mfail);

MTIstatus _SetReportStandardImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfObjects completeReportSet, SetOfObjects * outputSet, integer * mfail);

MTIstatus _SetRptFromPartEffsImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr thisObj, MTIstring sParentPart, MTIstring cfgItemEffType,
   SetOfStrings cfgItemIdStrSet, SetOfObjects partEffObjSet, boolean doDetailedReport,
   integer currentLevel, SetOfObjects * usageEffObjSet, integer * mfail);

MTIstatus _SetStructureOptionIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr strcOptObj, ObjectPtr vewObj, ObjectPtr dialogObj,
   boolean isUpdateDialog, ObjectPtr * strcOptRel, integer * mfail);

MTIstatus _SetStyTblDfltsForUpdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string originClassName, ObjectPtr originObject, integer * mfail);

MTIstatus _SetSvcTypeTblDefaultsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr originObject, integer * mfail);

MTIstatus _SetUpRelCreateDlgWithSeedDlg
   (MTIstring _class, boolean getParent, string relClassName,
   ObjectPtr seedDlg, ObjectPtr leftObj, ObjectPtr rightObj,
   ObjectPtr * newDlg, integer * mfail);

MTIstatus _SetVewDepExpandDisplay
   (MTIstring _class, boolean getParent, string className,
   string relationship, ObjectPtr genContextObj, integer * mfail);

MTIstatus _SetVewDepRelateDisplay
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr backgroundObj, integer * mfail);

MTIstatus _SetViewDepObjsInSesObj
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, ObjectPtr relObj, integer * mfail);

MTIstatus _SetupSubPartForChangesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _SetupWithVewForChangesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string relClassName, boolean useDialogs, ObjectPtr vewObj,
   boolean * cancel, integer * mfail);

MTIstatus _SortRptByConfigImpl
   (MTIstring _class, boolean getParent, MTIstring className,
   SetOfStrings cfgItemIdStrSet, SetOfObjects * reportSet, integer * mfail);

MTIstatus _SplitAllowPrcRevRels
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects objectSet, string relationship, ObjectPtr genContextObj,
   SetOfObjects * relObjSet, integer * mfail);

MTIstatus _UpdProcStrcOptValuesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer updateType, ObjectPtr dialogObj, SetOfStrings * valueSet,
   integer * mfail);

MTIstatus _UpdateOffrdSvcRelationAtClass
   (MTIstring _class, boolean getParent, ObjectPtr relation,
   string prefInd, integer * mfail);

MTIstatus _UpdateStrucRelObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer updateType, ObjectPtr dialogObj, integer * mfail);

MTIstatus _UpdateStructureForAppAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr parentStrucBIObj, ObjectPtr interfaceObj, integer * mfail);

MTIstatus _UpgradeMfgPartData
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _UpgradeMfgPartObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr mfgPartObj,
   string orgznID, string orgznType, integer * mfail);

MTIstatus _UpgradeMptForMigration
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _UpgradeSupForMigration
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _UpgradeSupplierData
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _UpgradeSupplierObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr suppObj,
   integer * mfail);

MTIstatus _ValBuildVewNtwkMapping
   (MTIstring _class, boolean getParent, string className,
   string curVewNtwkBitPos, string newVewNtwkBitPos, string newStartingBitPos,
   integer * mfail);

MTIstatus _ValCertiStatusAttrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   string originClassName, ObjectPtr originObject, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValDoAssignEOLDateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   ObjectPtr assignEOLDateDlg, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValDomForAsgnToVewNtwkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForAsgEOLDateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForCertStatAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForCreateCIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForFreezeViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForVndStatAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValEffForOverlappingAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr cfgItemObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValExpRevEffectivityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr genContextObj, integer * mfail);

MTIstatus _ValForAssignEOLDateExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr gnComMfgPart,
   integer * mfail);

MTIstatus _ValForAssignToVewNtwkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForChgCertStatusExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   integer * mfail);

MTIstatus _ValForChgVndStatusExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   integer * mfail);

MTIstatus _ValForEffCreAndUpdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValForMigOrRemVewNtwkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean migratingViewNetwork, integer * mfail);

MTIstatus _ValForMrkVewNtwkUnusedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValFreezeOfRelObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ValFreezeViewOfRelObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValObjsForSuppAccess
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * someObjects, integer * mfail);

MTIstatus _ValRelRevEffectivityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValRelStrucEffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _ValRelStrucOptionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _ValRelateSubPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr selectedRelObj, ObjectPtr selectedItmObj, integer * mfail);

MTIstatus _ValRestrcActForOccQtyAtClass
   (MTIstring _class, boolean getParent, ObjectPtr strucRel,
   integer * mfail);

MTIstatus _ValUsrForViewAllVndrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vndrMstrObj,
   string relship, boolean * isValid, integer * mfail);

MTIstatus _ValVendorStatusAttrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   string originClassName, ObjectPtr originObject, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidateCADConsistencyAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemToExport,
   integer * mfail);

MTIstatus _ValidateDoChgCertStatAtClass
   (MTIstring _class, boolean getParent, ObjectPtr genSplrObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidateDoChgVndStatAtClass
   (MTIstring _class, boolean getParent, ObjectPtr vendorObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidateEffUnitNumber
   (MTIstring _class, boolean getParent, string className,
   string unitType, string unitNumber, integer * mfail);

MTIstatus _ValidateForActVewNtwkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForAsgnVwExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForCreateCIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForDactVewNtwkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForFreezeViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForILVAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   string newObjClass, string newLeftRelClass, string newRightRelClass,
   SetOfObjects selectedStrcRels, ObjectPtr vewObject, integer * mfail);

MTIstatus _ValidateForMOAAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdELemObj,
   ObjectPtr elemToRemove, ObjectPtr relationToRemove, SetOfObjects strucRelationSet,
   ObjectPtr vewObject, integer * mfail);

MTIstatus _ValidateForPrepareAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForSBMAtClass
   (MTIstring _class, boolean getParent, ObjectPtr topLvlProdElmObj,
   ObjectPtr structureRelation, string quantity, SetOfStrings occurrenceIds,
   ObjectPtr vewObject, integer * mfail);

MTIstatus _ValidateFrozenForSwkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr leftObj, ObjectPtr rightObj, integer * mfail);

MTIstatus _ValidateObjForRevEffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr genContextObj, boolean * isValid, integer * mfail);
/*
 *  Protected Messages
 */
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define ActivateVewNetNDNP(thisObj, dialogObj, mfail) \
        _ActivateVewNetNDNPAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ActivateVewNetNDNPAtClass(class, thisObj, dialogObj, mfail) \
        _ActivateVewNetNDNPAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ActivateVewNetNDNPAtParent(class, thisObj, dialogObj, mfail) \
        _ActivateVewNetNDNPAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ActivateVewNetwork(thisObj, mfail) \
        _ActivateVewNetworkAtClass(NULL, FALSE, thisObj, mfail)
#define ActivateVewNetworkAtClass(class, thisObj, mfail) \
        _ActivateVewNetworkAtClass(class, FALSE, thisObj, mfail)
#define ActivateVewNetworkAtParent(class, thisObj, mfail) \
        _ActivateVewNetworkAtClass(class, TRUE, thisObj, mfail)

#define AddEffRelItmMstrSql(className, relationship, sql, mfail) \
        _AddEffRelItmMstrSql(className, FALSE, className, relationship, sql, mfail)
#define AddEffRelItmMstrSqlAtParent(_class, className, relationship, sql, mfail) \
        _AddEffRelItmMstrSql(_class, TRUE, className, relationship, sql, mfail)

#define AddOccurrence(className, dialogObj, leftObj, rightObj, relationObj, mfail) \
        _AddOccurrence(className, FALSE, className, dialogObj, leftObj, rightObj, relationObj, mfail)
#define AddOccurrenceAtParent(_class, className, dialogObj, leftObj, rightObj, relationObj, mfail) \
        _AddOccurrence(_class, TRUE, className, dialogObj, leftObj, rightObj, relationObj, mfail)

#define AddStrcOptsToQuantity(className, variantObj, relObj, newQuantity, mfail) \
        _AddStrcOptsToQuantity(className, FALSE, className, variantObj, relObj, newQuantity, mfail)
#define AddStrcOptsToQuantityAtParent(_class, className, variantObj, relObj, newQuantity, mfail) \
        _AddStrcOptsToQuantity(_class, TRUE, className, variantObj, relObj, newQuantity, mfail)

#define AddStructureOption(thisObj, strcOptObj, vewObj, dialogObj, strcOptRel, mfail) \
        _AddStructureOptionAtClass(NULL, FALSE, thisObj, strcOptObj, vewObj, dialogObj, strcOptRel, mfail)
#define AddStructureOptionAtClass(class, thisObj, strcOptObj, vewObj, dialogObj, strcOptRel, mfail) \
        _AddStructureOptionAtClass(class, FALSE, thisObj, strcOptObj, vewObj, dialogObj, strcOptRel, mfail)
#define AddStructureOptionAtParent(class, thisObj, strcOptObj, vewObj, dialogObj, strcOptRel, mfail) \
        _AddStructureOptionAtClass(class, TRUE, thisObj, strcOptObj, vewObj, dialogObj, strcOptRel, mfail)

#define AddToReportImpl(className, partNumber, revEffObjSet, usageEffObjSet, reportEffObjSet, mfail) \
        _AddToReportImpl(className, FALSE, className, partNumber, revEffObjSet, usageEffObjSet, reportEffObjSet, mfail)
#define AddToReportImplAtParent(_class, className, partNumber, revEffObjSet, usageEffObjSet, reportEffObjSet, mfail) \
        _AddToReportImpl(_class, TRUE, className, partNumber, revEffObjSet, usageEffObjSet, reportEffObjSet, mfail)

#define AddVewContextToSql(className, itemObj, relationship, sql, mfail) \
        _AddVewContextToSql(className, FALSE, className, itemObj, relationship, sql, mfail)
#define AddVewContextToSqlAtParent(_class, className, itemObj, relationship, sql, mfail) \
        _AddVewContextToSql(_class, TRUE, className, itemObj, relationship, sql, mfail)

#define AdjustQueryForSvcType(className, scope, queryArgs, objects, mfail) \
        _AdjustQueryForSvcType(className, FALSE, className, scope, queryArgs, objects, mfail)
#define AdjustQueryForSvcTypeAtParent(_class, className, scope, queryArgs, objects, mfail) \
        _AdjustQueryForSvcType(_class, TRUE, className, scope, queryArgs, objects, mfail)

#define AllowsEditHasRevEffs(thisObj, mfail) \
        _AllowsEditHasRevEffsAtClass(NULL, FALSE, thisObj, mfail)
#define AllowsEditHasRevEffsAtClass(class, thisObj, mfail) \
        _AllowsEditHasRevEffsAtClass(class, FALSE, thisObj, mfail)
#define AllowsEditHasRevEffsAtParent(class, thisObj, mfail) \
        _AllowsEditHasRevEffsAtClass(class, TRUE, thisObj, mfail)

#define AllowsEditUsesPartMstr(thisObj, mfail) \
        _AllowsEditUsesPartMstrAtClass(NULL, FALSE, thisObj, mfail)
#define AllowsEditUsesPartMstrAtClass(class, thisObj, mfail) \
        _AllowsEditUsesPartMstrAtClass(class, FALSE, thisObj, mfail)
#define AllowsEditUsesPartMstrAtParent(class, thisObj, mfail) \
        _AllowsEditUsesPartMstrAtClass(class, TRUE, thisObj, mfail)

#define AllowsFreezeForView(thisObj, mfail) \
        _AllowsFreezeForViewAtClass(NULL, FALSE, thisObj, mfail)
#define AllowsFreezeForViewAtClass(class, thisObj, mfail) \
        _AllowsFreezeForViewAtClass(class, FALSE, thisObj, mfail)
#define AllowsFreezeForViewAtParent(class, thisObj, mfail) \
        _AllowsFreezeForViewAtClass(class, TRUE, thisObj, mfail)

#define AllwSetProcPreciseRev(className, objectSet, relationship, genContextObj, otherSideObjSet, relObjSet, mfail) \
        _AllwSetProcPreciseRev(className, FALSE, className, objectSet, relationship, genContextObj, otherSideObjSet, relObjSet, mfail)
#define AllwSetProcPreciseRevAtParent(_class, className, objectSet, relationship, genContextObj, otherSideObjSet, relObjSet, mfail) \
        _AllwSetProcPreciseRev(_class, TRUE, className, objectSet, relationship, genContextObj, otherSideObjSet, relObjSet, mfail)

#define AlwPrcExpRelObjsForOpt(className, itemObjSet, relationship, genContextObj, relObjSet, mfail) \
        _AlwPrcExpRelObjsForOpt(className, FALSE, className, itemObjSet, relationship, genContextObj, relObjSet, mfail)
#define AlwPrcExpRelObjsForOptAtParent(_class, className, itemObjSet, relationship, genContextObj, relObjSet, mfail) \
        _AlwPrcExpRelObjsForOpt(_class, TRUE, className, itemObjSet, relationship, genContextObj, relObjSet, mfail)

#define ApplyCtxtToQuantity(className, variantObj, relObj, newQuantity, mfail) \
        _ApplyCtxtToQuantity(className, FALSE, className, variantObj, relObj, newQuantity, mfail)
#define ApplyCtxtToQuantityAtParent(_class, className, variantObj, relObj, newQuantity, mfail) \
        _ApplyCtxtToQuantity(_class, TRUE, className, variantObj, relObj, newQuantity, mfail)

#define AsRevRevDb(className, action, mfail) \
        _AsRevRevDb(className, FALSE, className, action, mfail)
#define AsRevRevDbAtParent(_class, className, action, mfail) \
        _AsRevRevDb(_class, TRUE, className, action, mfail)

#define AssignEOLDate(stPtRqObj, EOLDate, mfail) \
        _AssignEOLDateAtClass(NULL, FALSE, stPtRqObj, EOLDate, mfail)
#define AssignEOLDateAtClass(class, stPtRqObj, EOLDate, mfail) \
        _AssignEOLDateAtClass(class, FALSE, stPtRqObj, EOLDate, mfail)
#define AssignEOLDateAtParent(class, stPtRqObj, EOLDate, mfail) \
        _AssignEOLDateAtClass(class, TRUE, stPtRqObj, EOLDate, mfail)

#define AssignEOLDateDP(thisObj, mfail) \
        _AssignEOLDateDPAtClass(NULL, FALSE, thisObj, mfail)
#define AssignEOLDateDPAtClass(class, thisObj, mfail) \
        _AssignEOLDateDPAtClass(class, FALSE, thisObj, mfail)
#define AssignEOLDateDPAtParent(class, thisObj, mfail) \
        _AssignEOLDateDPAtClass(class, TRUE, thisObj, mfail)

#define AssignEOLDateDPInt(gnComMfgPart, mfail) \
        _AssignEOLDateDPIntAtClass(NULL, FALSE, gnComMfgPart, mfail)
#define AssignEOLDateDPIntAtClass(class, gnComMfgPart, mfail) \
        _AssignEOLDateDPIntAtClass(class, FALSE, gnComMfgPart, mfail)
#define AssignEOLDateDPIntAtParent(class, gnComMfgPart, mfail) \
        _AssignEOLDateDPIntAtClass(class, TRUE, gnComMfgPart, mfail)

#define AssignEOLDateInt(gnComMfgPart, assignEOLDateDlg, mfail) \
        _AssignEOLDateIntAtClass(NULL, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define AssignEOLDateIntAtClass(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _AssignEOLDateIntAtClass(class, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define AssignEOLDateIntAtParent(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _AssignEOLDateIntAtClass(class, TRUE, gnComMfgPart, assignEOLDateDlg, mfail)

#define AssignItmToViewNetwork(thisObj, dialogObj, mfail) \
        _AssignItmToViewNetworkAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define AssignItmToViewNetworkAtClass(class, thisObj, dialogObj, mfail) \
        _AssignItmToViewNetworkAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define AssignItmToViewNetworkAtParent(class, thisObj, dialogObj, mfail) \
        _AssignItmToViewNetworkAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define AssignObjToViewNetwork(thisObj, vewObj, mfail) \
        _AssignObjToViewNetworkAtClass(NULL, FALSE, thisObj, vewObj, mfail)
#define AssignObjToViewNetworkAtClass(class, thisObj, vewObj, mfail) \
        _AssignObjToViewNetworkAtClass(class, FALSE, thisObj, vewObj, mfail)
#define AssignObjToViewNetworkAtParent(class, thisObj, vewObj, mfail) \
        _AssignObjToViewNetworkAtClass(class, TRUE, thisObj, vewObj, mfail)

#define AssignToViewNetwork(thisObj, mfail) \
        _AssignToViewNetworkAtClass(NULL, FALSE, thisObj, mfail)
#define AssignToViewNetworkAtClass(class, thisObj, mfail) \
        _AssignToViewNetworkAtClass(class, FALSE, thisObj, mfail)
#define AssignToViewNetworkAtParent(class, thisObj, mfail) \
        _AssignToViewNetworkAtClass(class, TRUE, thisObj, mfail)

#define AuxViewDepRelCopy(className, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail) \
        _AuxViewDepRelCopy(className, FALSE, className, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail)
#define AuxViewDepRelCopyAtParent(_class, className, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail) \
        _AuxViewDepRelCopy(_class, TRUE, className, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail)

#define AuxViewDepRelDel(className, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail) \
        _AuxViewDepRelDel(className, FALSE, className, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail)
#define AuxViewDepRelDelAtParent(_class, className, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail) \
        _AuxViewDepRelDel(_class, TRUE, className, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail)

#define AuxViewUpdFindNumber(thisObj, newFindNumber, mfail) \
        _AuxViewUpdFindNumberAtClass(NULL, FALSE, thisObj, newFindNumber, mfail)
#define AuxViewUpdFindNumberAtClass(class, thisObj, newFindNumber, mfail) \
        _AuxViewUpdFindNumberAtClass(class, FALSE, thisObj, newFindNumber, mfail)
#define AuxViewUpdFindNumberAtParent(class, thisObj, newFindNumber, mfail) \
        _AuxViewUpdFindNumberAtClass(class, TRUE, thisObj, newFindNumber, mfail)

#define BOMEdit(className, failPreference, BOMEditSetDlg, mfail) \
        _BOMEdit(className, FALSE, className, failPreference, BOMEditSetDlg, mfail)
#define BOMEditAtParent(_class, className, failPreference, BOMEditSetDlg, mfail) \
        _BOMEdit(_class, TRUE, className, failPreference, BOMEditSetDlg, mfail)

#define BOMEditAdd(className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditAdd(className, FALSE, className, BOMEditDlg, ViewObj, mfail)
#define BOMEditAddAtParent(_class, className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditAdd(_class, TRUE, className, BOMEditDlg, ViewObj, mfail)

#define BOMEditRemove(className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditRemove(className, FALSE, className, BOMEditDlg, ViewObj, mfail)
#define BOMEditRemoveAtParent(_class, className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditRemove(_class, TRUE, className, BOMEditDlg, ViewObj, mfail)

#define BOMEditReplace(className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditReplace(className, FALSE, className, BOMEditDlg, ViewObj, mfail)
#define BOMEditReplaceAtParent(_class, className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditReplace(_class, TRUE, className, BOMEditDlg, ViewObj, mfail)

#define BOMEditReplaceParent(className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditReplaceParent(className, FALSE, className, BOMEditDlg, ViewObj, mfail)
#define BOMEditReplaceParentAtParent(_class, className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditReplaceParent(_class, TRUE, className, BOMEditDlg, ViewObj, mfail)

#define BOMEditReplaceRelation(replacingObj, existingRelationObj, EditDialogObj, ViewObj, relationAttrs, mfail) \
        _BOMEditReplaceRelationAtClass(NULL, FALSE, replacingObj, existingRelationObj, EditDialogObj, ViewObj, relationAttrs, mfail)
#define BOMEditReplaceRelationAtClass(class, replacingObj, existingRelationObj, EditDialogObj, ViewObj, relationAttrs, mfail) \
        _BOMEditReplaceRelationAtClass(class, FALSE, replacingObj, existingRelationObj, EditDialogObj, ViewObj, relationAttrs, mfail)
#define BOMEditReplaceRelationAtParent(class, replacingObj, existingRelationObj, EditDialogObj, ViewObj, relationAttrs, mfail) \
        _BOMEditReplaceRelationAtClass(class, TRUE, replacingObj, existingRelationObj, EditDialogObj, ViewObj, relationAttrs, mfail)

#define BOMEditUpdate(className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditUpdate(className, FALSE, className, BOMEditDlg, ViewObj, mfail)
#define BOMEditUpdateAtParent(_class, className, BOMEditDlg, ViewObj, mfail) \
        _BOMEditUpdate(_class, TRUE, className, BOMEditDlg, ViewObj, mfail)

#define BOMGradingXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _BOMGradingXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define BOMGradingXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _BOMGradingXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define BOMGradingXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _BOMGradingXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define BaselineItem4(part, busItems, dataItems, mfail) \
        _BaselineItem4AtClass(NULL, FALSE, part, busItems, dataItems, mfail)
#define BaselineItem4AtClass(class, part, busItems, dataItems, mfail) \
        _BaselineItem4AtClass(class, FALSE, part, busItems, dataItems, mfail)
#define BaselineItem4AtParent(class, part, busItems, dataItems, mfail) \
        _BaselineItem4AtClass(class, TRUE, part, busItems, dataItems, mfail)

#define BaselineItemInt(part, busItems, dataItems, mfail) \
        _BaselineItemIntAtClass(NULL, FALSE, part, busItems, dataItems, mfail)
#define BaselineItemIntAtClass(class, part, busItems, dataItems, mfail) \
        _BaselineItemIntAtClass(class, FALSE, part, busItems, dataItems, mfail)
#define BaselineItemIntAtParent(class, part, busItems, dataItems, mfail) \
        _BaselineItemIntAtClass(class, TRUE, part, busItems, dataItems, mfail)

#define BaselineItemP2(part, busItems, dataItems, mfail) \
        _BaselineItemP2AtClass(NULL, FALSE, part, busItems, dataItems, mfail)
#define BaselineItemP2AtClass(class, part, busItems, dataItems, mfail) \
        _BaselineItemP2AtClass(class, FALSE, part, busItems, dataItems, mfail)
#define BaselineItemP2AtParent(class, part, busItems, dataItems, mfail) \
        _BaselineItemP2AtClass(class, TRUE, part, busItems, dataItems, mfail)

#define BldDynObjSetsForEffRel(className, itemObjSet, relationship, scope, relObjSet, otherSideObjSet, mfail) \
        _BldDynObjSetsForEffRel(className, FALSE, className, itemObjSet, relationship, scope, relObjSet, otherSideObjSet, mfail)
#define BldDynObjSetsForEffRelAtParent(_class, className, itemObjSet, relationship, scope, relObjSet, otherSideObjSet, mfail) \
        _BldDynObjSetsForEffRel(_class, TRUE, className, itemObjSet, relationship, scope, relObjSet, otherSideObjSet, mfail)

#define BldDynSetsForStrcOptR(className, itemObjSet, relationship, scope, relObjSet, otherSideObjSet, mfail) \
        _BldDynSetsForStrcOptR(className, FALSE, className, itemObjSet, relationship, scope, relObjSet, otherSideObjSet, mfail)
#define BldDynSetsForStrcOptRAtParent(_class, className, itemObjSet, relationship, scope, relObjSet, otherSideObjSet, mfail) \
        _BldDynSetsForStrcOptR(_class, TRUE, className, itemObjSet, relationship, scope, relObjSet, otherSideObjSet, mfail)

#define BldStrcOptROBID(thisObj, itemMstrObj, strcOptObj, strucApcObj, mfail) \
        _BldStrcOptROBIDAtClass(NULL, FALSE, thisObj, itemMstrObj, strcOptObj, strucApcObj, mfail)
#define BldStrcOptROBIDAtClass(class, thisObj, itemMstrObj, strcOptObj, strucApcObj, mfail) \
        _BldStrcOptROBIDAtClass(class, FALSE, thisObj, itemMstrObj, strcOptObj, strucApcObj, mfail)
#define BldStrcOptROBIDAtParent(class, thisObj, itemMstrObj, strcOptObj, strucApcObj, mfail) \
        _BldStrcOptROBIDAtClass(class, TRUE, thisObj, itemMstrObj, strcOptObj, strucApcObj, mfail)

#define BldStrcOptValsForDyn(className, strcOptValueList, newRelObj, mfail) \
        _BldStrcOptValsForDyn(className, FALSE, className, strcOptValueList, newRelObj, mfail)
#define BldStrcOptValsForDynAtParent(_class, className, strcOptValueList, newRelObj, mfail) \
        _BldStrcOptValsForDyn(_class, TRUE, className, strcOptValueList, newRelObj, mfail)

#define BuildCIFromItemMstr(className, itemMstrObj, cfgDialogObj, cfgItemObj, mfail) \
        _BuildCIFromItemMstr(className, FALSE, className, itemMstrObj, cfgDialogObj, cfgItemObj, mfail)
#define BuildCIFromItemMstrAtParent(_class, className, itemMstrObj, cfgDialogObj, cfgItemObj, mfail) \
        _BuildCIFromItemMstr(_class, TRUE, className, itemMstrObj, cfgDialogObj, cfgItemObj, mfail)

#define BuildDialogInfoForApp(className, dlgConst, parentStrucBIObj, interfaceObj, dialogObj, mfail) \
        _BuildDialogInfoForApp(className, FALSE, className, dlgConst, parentStrucBIObj, interfaceObj, dialogObj, mfail)
#define BuildDialogInfoForAppAtParent(_class, className, dlgConst, parentStrucBIObj, interfaceObj, dialogObj, mfail) \
        _BuildDialogInfoForApp(_class, TRUE, className, dlgConst, parentStrucBIObj, interfaceObj, dialogObj, mfail)

#define BuildInterfaceForApp(className, parentStrucBIObj, childStrucBIObj, interfaceClassName, interfaceObj, mfail) \
        _BuildInterfaceForApp(className, FALSE, className, parentStrucBIObj, childStrucBIObj, interfaceClassName, interfaceObj, mfail)
#define BuildInterfaceForAppAtParent(_class, className, parentStrucBIObj, childStrucBIObj, interfaceClassName, interfaceObj, mfail) \
        _BuildInterfaceForApp(_class, TRUE, className, parentStrucBIObj, childStrucBIObj, interfaceClassName, interfaceObj, mfail)

#define BuildListOfViewNames(className, forNetwork, viewNetwork, getOnlyActive, viewMask, values, mfail) \
        _BuildListOfViewNames(className, FALSE, className, forNetwork, viewNetwork, getOnlyActive, viewMask, values, mfail)
#define BuildListOfViewNamesAtParent(_class, className, forNetwork, viewNetwork, getOnlyActive, viewMask, values, mfail) \
        _BuildListOfViewNames(_class, TRUE, className, forNetwork, viewNetwork, getOnlyActive, viewMask, values, mfail)

#define BuildListOfViewNtwks(className, getOnlyActivated, values, mfail) \
        _BuildListOfViewNtwks(className, FALSE, className, getOnlyActivated, values, mfail)
#define BuildListOfViewNtwksAtParent(_class, className, getOnlyActivated, values, mfail) \
        _BuildListOfViewNtwks(_class, TRUE, className, getOnlyActivated, values, mfail)

#define BuildStructuresForApp(className, applicationOwner, parentStrucBIObj, childStrucBIObjSet, interfaceObjSet, mfail) \
        _BuildStructuresForApp(className, FALSE, className, applicationOwner, parentStrucBIObj, childStrucBIObjSet, interfaceObjSet, mfail)
#define BuildStructuresForAppAtParent(_class, className, applicationOwner, parentStrucBIObj, childStrucBIObjSet, interfaceObjSet, mfail) \
        _BuildStructuresForApp(_class, TRUE, className, applicationOwner, parentStrucBIObj, childStrucBIObjSet, interfaceObjSet, mfail)

#define BuildVewNtwkMapping(className, retrieveOnlyNtwkInfo, curVewNtwkBitPos, newVewNtwkBitPos, newStartingBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mfail) \
        _BuildVewNtwkMapping(className, FALSE, className, retrieveOnlyNtwkInfo, curVewNtwkBitPos, newVewNtwkBitPos, newStartingBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mfail)
#define BuildVewNtwkMappingAtParent(_class, className, retrieveOnlyNtwkInfo, curVewNtwkBitPos, newVewNtwkBitPos, newStartingBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mfail) \
        _BuildVewNtwkMapping(_class, TRUE, className, retrieveOnlyNtwkInfo, curVewNtwkBitPos, newVewNtwkBitPos, newStartingBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mfail)

#define CanAuxViewDepRelBeCpy(thisObj, existingRelsSet, affectedViewMask, newViewMask, shouldCopy, mfail) \
        _CanAuxViewDepRelBeCpyAtClass(NULL, FALSE, thisObj, existingRelsSet, affectedViewMask, newViewMask, shouldCopy, mfail)
#define CanAuxViewDepRelBeCpyAtClass(class, thisObj, existingRelsSet, affectedViewMask, newViewMask, shouldCopy, mfail) \
        _CanAuxViewDepRelBeCpyAtClass(class, FALSE, thisObj, existingRelsSet, affectedViewMask, newViewMask, shouldCopy, mfail)
#define CanAuxViewDepRelBeCpyAtParent(class, thisObj, existingRelsSet, affectedViewMask, newViewMask, shouldCopy, mfail) \
        _CanAuxViewDepRelBeCpyAtClass(class, TRUE, thisObj, existingRelsSet, affectedViewMask, newViewMask, shouldCopy, mfail)

#define ChangeVewForVewNetwork(className, addingVew, predVewObj, succVewObj, mfail) \
        _ChangeVewForVewNetwork(className, FALSE, className, addingVew, predVewObj, succVewObj, mfail)
#define ChangeVewForVewNetworkAtParent(_class, className, addingVew, predVewObj, succVewObj, mfail) \
        _ChangeVewForVewNetwork(_class, TRUE, className, addingVew, predVewObj, succVewObj, mfail)

#define CheckEffAgainstCntxt(effRelObj, contextObj, isEffective, mfail) \
        _CheckEffAgainstCntxtAtClass(NULL, FALSE, effRelObj, contextObj, isEffective, mfail)
#define CheckEffAgainstCntxtAtClass(class, effRelObj, contextObj, isEffective, mfail) \
        _CheckEffAgainstCntxtAtClass(class, FALSE, effRelObj, contextObj, isEffective, mfail)
#define CheckEffAgainstCntxtAtParent(class, effRelObj, contextObj, isEffective, mfail) \
        _CheckEffAgainstCntxtAtClass(class, TRUE, effRelObj, contextObj, isEffective, mfail)

#define CheckForEffRange(className, itemObj, effRelObjSet, itemSide, genContextObj, effExists, effStarted, effEnded, mfail) \
        _CheckForEffRange(className, FALSE, className, itemObj, effRelObjSet, itemSide, genContextObj, effExists, effStarted, effEnded, mfail)
#define CheckForEffRangeAtParent(_class, className, itemObj, effRelObjSet, itemSide, genContextObj, effExists, effStarted, effEnded, mfail) \
        _CheckForEffRange(_class, TRUE, className, itemObj, effRelObjSet, itemSide, genContextObj, effExists, effStarted, effEnded, mfail)

#define CheckIfCfgItemExists(className, cfgItemId, mustBeActive, cfgItemObj, mfail) \
        _CheckIfCfgItemExists(className, FALSE, className, cfgItemId, mustBeActive, cfgItemObj, mfail)
#define CheckIfCfgItemExistsAtParent(_class, className, cfgItemId, mustBeActive, cfgItemObj, mfail) \
        _CheckIfCfgItemExists(_class, TRUE, className, cfgItemId, mustBeActive, cfgItemObj, mfail)

#define CheckIfNetworkUsed(className, vewNtwkBitPos, foundObject, foundDbName, mfail) \
        _CheckIfNetworkUsed(className, FALSE, className, vewNtwkBitPos, foundObject, foundDbName, mfail)
#define CheckIfNetworkUsedAtParent(_class, className, vewNtwkBitPos, foundObject, foundDbName, mfail) \
        _CheckIfNetworkUsed(_class, TRUE, className, vewNtwkBitPos, foundObject, foundDbName, mfail)

#define CheckIfStrcOptExists(className, strcOptName, mfail) \
        _CheckIfStrcOptExists(className, FALSE, className, strcOptName, mfail)
#define CheckIfStrcOptExistsAtParent(_class, className, strcOptName, mfail) \
        _CheckIfStrcOptExists(_class, TRUE, className, strcOptName, mfail)

#define CheckIfValidCfgItems(className, cfgItemIdSet, mfail) \
        _CheckIfValidCfgItems(className, FALSE, className, cfgItemIdSet, mfail)
#define CheckIfValidCfgItemsAtParent(_class, className, cfgItemIdSet, mfail) \
        _CheckIfValidCfgItems(_class, TRUE, className, cfgItemIdSet, mfail)

#define CheckIfValidStrcOpt(className, strcOptName, mfail) \
        _CheckIfValidStrcOpt(className, FALSE, className, strcOptName, mfail)
#define CheckIfValidStrcOptAtParent(_class, className, strcOptName, mfail) \
        _CheckIfValidStrcOpt(_class, TRUE, className, strcOptName, mfail)

#define CheckIfValidVew(className, viewNetwork, viewName, vewObj, mfail) \
        _CheckIfValidVew(className, FALSE, className, viewNetwork, viewName, vewObj, mfail)
#define CheckIfValidVewAtParent(_class, className, viewNetwork, viewName, vewObj, mfail) \
        _CheckIfValidVew(_class, TRUE, className, viewNetwork, viewName, vewObj, mfail)

#define CheckIfValidVewNetwork(className, viewNetwork, vewObj, mfail) \
        _CheckIfValidVewNetwork(className, FALSE, className, viewNetwork, vewObj, mfail)
#define CheckIfValidVewNetworkAtParent(_class, className, viewNetwork, vewObj, mfail) \
        _CheckIfValidVewNetwork(_class, TRUE, className, viewNetwork, vewObj, mfail)

#define CheckIfVewExists(className, viewNetwork, viewName, mfail) \
        _CheckIfVewExists(className, FALSE, className, viewNetwork, viewName, mfail)
#define CheckIfVewExistsAtParent(_class, className, viewNetwork, viewName, mfail) \
        _CheckIfVewExists(_class, TRUE, className, viewNetwork, viewName, mfail)

#define CheckNIAccessForVewDep(className, objectToCheck, isForVewDepMessage, mfail) \
        _CheckNIAccessForVewDep(className, FALSE, className, objectToCheck, isForVewDepMessage, mfail)
#define CheckNIAccessForVewDepAtParent(_class, className, objectToCheck, isForVewDepMessage, mfail) \
        _CheckNIAccessForVewDep(_class, TRUE, className, objectToCheck, isForVewDepMessage, mfail)

#define CheckRealOutOfDate(thisObj, realRelObj, mfail) \
        _CheckRealOutOfDateAtClass(NULL, FALSE, thisObj, realRelObj, mfail)
#define CheckRealOutOfDateAtClass(class, thisObj, realRelObj, mfail) \
        _CheckRealOutOfDateAtClass(class, FALSE, thisObj, realRelObj, mfail)
#define CheckRealOutOfDateAtParent(class, thisObj, realRelObj, mfail) \
        _CheckRealOutOfDateAtClass(class, TRUE, thisObj, realRelObj, mfail)

#define ChgCertificatStatDPInt(genSplrObj, mfail) \
        _ChgCertificatStatDPIntAtClass(NULL, FALSE, genSplrObj, mfail)
#define ChgCertificatStatDPIntAtClass(class, genSplrObj, mfail) \
        _ChgCertificatStatDPIntAtClass(class, FALSE, genSplrObj, mfail)
#define ChgCertificatStatDPIntAtParent(class, genSplrObj, mfail) \
        _ChgCertificatStatDPIntAtClass(class, TRUE, genSplrObj, mfail)

#define ChgCertificatStatusDP(thisObj, mfail) \
        _ChgCertificatStatusDPAtClass(NULL, FALSE, thisObj, mfail)
#define ChgCertificatStatusDPAtClass(class, thisObj, mfail) \
        _ChgCertificatStatusDPAtClass(class, FALSE, thisObj, mfail)
#define ChgCertificatStatusDPAtParent(class, thisObj, mfail) \
        _ChgCertificatStatusDPAtClass(class, TRUE, thisObj, mfail)

#define ChgCertificatStatusInt(genSplrObj, dialogObj, mfail) \
        _ChgCertificatStatusIntAtClass(NULL, FALSE, genSplrObj, dialogObj, mfail)
#define ChgCertificatStatusIntAtClass(class, genSplrObj, dialogObj, mfail) \
        _ChgCertificatStatusIntAtClass(class, FALSE, genSplrObj, dialogObj, mfail)
#define ChgCertificatStatusIntAtParent(class, genSplrObj, dialogObj, mfail) \
        _ChgCertificatStatusIntAtClass(class, TRUE, genSplrObj, dialogObj, mfail)

#define ChgCertificationStatus(genSplrObj, sCertificationStatus, mfail) \
        _ChgCertificationStatusAtClass(NULL, FALSE, genSplrObj, sCertificationStatus, mfail)
#define ChgCertificationStatusAtClass(class, genSplrObj, sCertificationStatus, mfail) \
        _ChgCertificationStatusAtClass(class, FALSE, genSplrObj, sCertificationStatus, mfail)
#define ChgCertificationStatusAtParent(class, genSplrObj, sCertificationStatus, mfail) \
        _ChgCertificationStatusAtClass(class, TRUE, genSplrObj, sCertificationStatus, mfail)

#define ChgVendorStatus(vendorObj, sVendorStatus, mfail) \
        _ChgVendorStatusAtClass(NULL, FALSE, vendorObj, sVendorStatus, mfail)
#define ChgVendorStatusAtClass(class, vendorObj, sVendorStatus, mfail) \
        _ChgVendorStatusAtClass(class, FALSE, vendorObj, sVendorStatus, mfail)
#define ChgVendorStatusAtParent(class, vendorObj, sVendorStatus, mfail) \
        _ChgVendorStatusAtClass(class, TRUE, vendorObj, sVendorStatus, mfail)

#define ChgVendorStatusDP(thisObj, mfail) \
        _ChgVendorStatusDPAtClass(NULL, FALSE, thisObj, mfail)
#define ChgVendorStatusDPAtClass(class, thisObj, mfail) \
        _ChgVendorStatusDPAtClass(class, FALSE, thisObj, mfail)
#define ChgVendorStatusDPAtParent(class, thisObj, mfail) \
        _ChgVendorStatusDPAtClass(class, TRUE, thisObj, mfail)

#define ChgVendorStatusDPInt(vendorObj, mfail) \
        _ChgVendorStatusDPIntAtClass(NULL, FALSE, vendorObj, mfail)
#define ChgVendorStatusDPIntAtClass(class, vendorObj, mfail) \
        _ChgVendorStatusDPIntAtClass(class, FALSE, vendorObj, mfail)
#define ChgVendorStatusDPIntAtParent(class, vendorObj, mfail) \
        _ChgVendorStatusDPIntAtClass(class, TRUE, vendorObj, mfail)

#define ChgVendorStatusInt(vendorObj, dialogObj, mfail) \
        _ChgVendorStatusIntAtClass(NULL, FALSE, vendorObj, dialogObj, mfail)
#define ChgVendorStatusIntAtClass(class, vendorObj, dialogObj, mfail) \
        _ChgVendorStatusIntAtClass(class, FALSE, vendorObj, dialogObj, mfail)
#define ChgVendorStatusIntAtParent(class, vendorObj, dialogObj, mfail) \
        _ChgVendorStatusIntAtClass(class, TRUE, vendorObj, dialogObj, mfail)

#define ChkEffAgainstCntxtPost(effRelObj, contextObj, isEffective, mfail) \
        _ChkEffAgainstCntxtPostAtClass(NULL, FALSE, effRelObj, contextObj, isEffective, mfail)
#define ChkEffAgainstCntxtPostAtClass(class, effRelObj, contextObj, isEffective, mfail) \
        _ChkEffAgainstCntxtPostAtClass(class, FALSE, effRelObj, contextObj, isEffective, mfail)
#define ChkEffAgainstCntxtPostAtParent(class, effRelObj, contextObj, isEffective, mfail) \
        _ChkEffAgainstCntxtPostAtClass(class, TRUE, effRelObj, contextObj, isEffective, mfail)

#define ChkVewDepRelOnRefresh(className, originalObj, refreshedObj, found, mfail) \
        _ChkVewDepRelOnRefresh(className, FALSE, className, originalObj, refreshedObj, found, mfail)
#define ChkVewDepRelOnRefreshAtParent(_class, className, originalObj, refreshedObj, found, mfail) \
        _ChkVewDepRelOnRefresh(_class, TRUE, className, originalObj, refreshedObj, found, mfail)

#define ClearStructureOption(thisObj, strcOptObj, vewObj, mfail) \
        _ClearStructureOptionAtClass(NULL, FALSE, thisObj, strcOptObj, vewObj, mfail)
#define ClearStructureOptionAtClass(class, thisObj, strcOptObj, vewObj, mfail) \
        _ClearStructureOptionAtClass(class, FALSE, thisObj, strcOptObj, vewObj, mfail)
#define ClearStructureOptionAtParent(class, thisObj, strcOptObj, vewObj, mfail) \
        _ClearStructureOptionAtClass(class, TRUE, thisObj, strcOptObj, vewObj, mfail)

#define ClearVewContextInfo(className, obj, mfail) \
        _ClearVewContextInfo(className, FALSE, className, obj, mfail)
#define ClearVewContextInfoAtParent(_class, className, obj, mfail) \
        _ClearVewContextInfo(_class, TRUE, className, obj, mfail)

#define CompareAssembliesXML(contextObj, lineSeparator, taskObject, dialogObj, resultXMLObj, needToTranslit, mfail) \
        _CompareAssembliesXMLAtClass(NULL, FALSE, contextObj, lineSeparator, taskObject, dialogObj, resultXMLObj, needToTranslit, mfail)
#define CompareAssembliesXMLAtClass(class, contextObj, lineSeparator, taskObject, dialogObj, resultXMLObj, needToTranslit, mfail) \
        _CompareAssembliesXMLAtClass(class, FALSE, contextObj, lineSeparator, taskObject, dialogObj, resultXMLObj, needToTranslit, mfail)
#define CompareAssembliesXMLAtParent(class, contextObj, lineSeparator, taskObject, dialogObj, resultXMLObj, needToTranslit, mfail) \
        _CompareAssembliesXMLAtClass(class, TRUE, contextObj, lineSeparator, taskObject, dialogObj, resultXMLObj, needToTranslit, mfail)

#define CompareAttrs(thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail) \
        _CompareAttrsAtClass(NULL, FALSE, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail)
#define CompareAttrsAtClass(class, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail) \
        _CompareAttrsAtClass(class, FALSE, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail)
#define CompareAttrsAtParent(class, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail) \
        _CompareAttrsAtClass(class, TRUE, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail)

#define CompareAttrsStr(thisObj, inpSet, cmprObj, mfail) \
        _CompareAttrsStrAtClass(NULL, FALSE, thisObj, inpSet, cmprObj, mfail)
#define CompareAttrsStrAtClass(class, thisObj, inpSet, cmprObj, mfail) \
        _CompareAttrsStrAtClass(class, FALSE, thisObj, inpSet, cmprObj, mfail)
#define CompareAttrsStrAtParent(class, thisObj, inpSet, cmprObj, mfail) \
        _CompareAttrsStrAtClass(class, TRUE, thisObj, inpSet, cmprObj, mfail)

#define ComparePreciseRevision(className, itemObj, preciseRevision, currentRevision, prcRevOperand, result, mfail) \
        _ComparePreciseRevision(className, FALSE, className, itemObj, preciseRevision, currentRevision, prcRevOperand, result, mfail)
#define ComparePreciseRevisionAtParent(_class, className, itemObj, preciseRevision, currentRevision, prcRevOperand, result, mfail) \
        _ComparePreciseRevision(_class, TRUE, className, itemObj, preciseRevision, currentRevision, prcRevOperand, result, mfail)

#define CompareStruct(thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail) \
        _CompareStructAtClass(NULL, FALSE, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail)
#define CompareStructAtClass(class, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail) \
        _CompareStructAtClass(class, FALSE, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail)
#define CompareStructAtParent(class, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail) \
        _CompareStructAtClass(class, TRUE, thisObj, cmprObj, host, usr, fullPath, maxLevel, mfail)

#define CompareStructStr(thisObj, inpSet, cmprObj, mfail) \
        _CompareStructStrAtClass(NULL, FALSE, thisObj, inpSet, cmprObj, mfail)
#define CompareStructStrAtClass(class, thisObj, inpSet, cmprObj, mfail) \
        _CompareStructStrAtClass(class, FALSE, thisObj, inpSet, cmprObj, mfail)
#define CompareStructStrAtParent(class, thisObj, inpSet, cmprObj, mfail) \
        _CompareStructStrAtClass(class, TRUE, thisObj, inpSet, cmprObj, mfail)

#define ConsolidateVewDepPred(thisObj, leftObj, rightObj, relConsolidated, mfail) \
        _ConsolidateVewDepPredAtClass(NULL, FALSE, thisObj, leftObj, rightObj, relConsolidated, mfail)
#define ConsolidateVewDepPredAtClass(class, thisObj, leftObj, rightObj, relConsolidated, mfail) \
        _ConsolidateVewDepPredAtClass(class, FALSE, thisObj, leftObj, rightObj, relConsolidated, mfail)
#define ConsolidateVewDepPredAtParent(class, thisObj, leftObj, rightObj, relConsolidated, mfail) \
        _ConsolidateVewDepPredAtClass(class, TRUE, thisObj, leftObj, rightObj, relConsolidated, mfail)

#define ConstrainRelViewMask(thisObj, mfail) \
        _ConstrainRelViewMaskAtClass(NULL, FALSE, thisObj, mfail)
#define ConstrainRelViewMaskAtClass(class, thisObj, mfail) \
        _ConstrainRelViewMaskAtClass(class, FALSE, thisObj, mfail)
#define ConstrainRelViewMaskAtParent(class, thisObj, mfail) \
        _ConstrainRelViewMaskAtClass(class, TRUE, thisObj, mfail)

#define ConstructArgsForAsgnVw(thisObj, dialogObj, mfail) \
        _ConstructArgsForAsgnVwAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ConstructArgsForAsgnVwAtClass(class, thisObj, dialogObj, mfail) \
        _ConstructArgsForAsgnVwAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ConstructArgsForAsgnVwAtParent(class, thisObj, dialogObj, mfail) \
        _ConstructArgsForAsgnVwAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ConvertQtyToDisplay(className, neutralQty, unit, displayQty, mfail) \
        _ConvertQtyToDisplay(className, FALSE, className, neutralQty, unit, displayQty, mfail)
#define ConvertQtyToDisplayAtParent(_class, className, neutralQty, unit, displayQty, mfail) \
        _ConvertQtyToDisplay(_class, TRUE, className, neutralQty, unit, displayQty, mfail)

#define ConvertQtyToNeutral(className, displayQty, unit, neutralQty, mfail) \
        _ConvertQtyToNeutral(className, FALSE, className, displayQty, unit, neutralQty, mfail)
#define ConvertQtyToNeutralAtParent(_class, className, displayQty, unit, neutralQty, mfail) \
        _ConvertQtyToNeutral(_class, TRUE, className, displayQty, unit, neutralQty, mfail)

#define ConvertViewBitToName(className, viewBitPos, viewNetwork, viewName, mfail) \
        _ConvertViewBitToName(className, FALSE, className, viewBitPos, viewNetwork, viewName, mfail)
#define ConvertViewBitToNameAtParent(_class, className, viewBitPos, viewNetwork, viewName, mfail) \
        _ConvertViewBitToName(_class, TRUE, className, viewBitPos, viewNetwork, viewName, mfail)

#define ConvertViewNameToBit(className, viewNetwork, viewName, viewBitPos, mfail) \
        _ConvertViewNameToBit(className, FALSE, className, viewNetwork, viewName, viewBitPos, mfail)
#define ConvertViewNameToBitAtParent(_class, className, viewNetwork, viewName, viewBitPos, mfail) \
        _ConvertViewNameToBit(_class, TRUE, className, viewNetwork, viewName, viewBitPos, mfail)

#define CopyAuxViewDepRel(thisObj, affectedViewMask, oldFindNumber, newFindNumber, mfail) \
        _CopyAuxViewDepRelAtClass(NULL, FALSE, thisObj, affectedViewMask, oldFindNumber, newFindNumber, mfail)
#define CopyAuxViewDepRelAtClass(class, thisObj, affectedViewMask, oldFindNumber, newFindNumber, mfail) \
        _CopyAuxViewDepRelAtClass(class, FALSE, thisObj, affectedViewMask, oldFindNumber, newFindNumber, mfail)
#define CopyAuxViewDepRelAtParent(class, thisObj, affectedViewMask, oldFindNumber, newFindNumber, mfail) \
        _CopyAuxViewDepRelAtClass(class, TRUE, thisObj, affectedViewMask, oldFindNumber, newFindNumber, mfail)

#define CopyPlmToArgObjInt(className, plmObj, argsObj, mfail) \
        _CopyPlmToArgObjInt(className, FALSE, className, plmObj, argsObj, mfail)
#define CopyPlmToArgObjIntAtParent(_class, className, plmObj, argsObj, mfail) \
        _CopyPlmToArgObjInt(_class, TRUE, className, plmObj, argsObj, mfail)

#define CpyInfoForVewDepRefrsh(thisObj, realRelObj, found, mfail) \
        _CpyInfoForVewDepRefrshAtClass(NULL, FALSE, thisObj, realRelObj, found, mfail)
#define CpyInfoForVewDepRefrshAtClass(class, thisObj, realRelObj, found, mfail) \
        _CpyInfoForVewDepRefrshAtClass(class, FALSE, thisObj, realRelObj, found, mfail)
#define CpyInfoForVewDepRefrshAtParent(class, thisObj, realRelObj, found, mfail) \
        _CpyInfoForVewDepRefrshAtClass(class, TRUE, thisObj, realRelObj, found, mfail)

#define CpyVewContextInfo(className, fromObj, forExpand, toObj, mfail) \
        _CpyVewContextInfo(className, FALSE, className, fromObj, forExpand, toObj, mfail)
#define CpyVewContextInfoAtParent(_class, className, fromObj, forExpand, toObj, mfail) \
        _CpyVewContextInfo(_class, TRUE, className, fromObj, forExpand, toObj, mfail)

#define CreCreDlgForIntUnits(thisObj, DIntArgsObj, creDlgObj, mfail) \
        _CreCreDlgForIntUnitsAtClass(NULL, FALSE, thisObj, DIntArgsObj, creDlgObj, mfail)
#define CreCreDlgForIntUnitsAtClass(class, thisObj, DIntArgsObj, creDlgObj, mfail) \
        _CreCreDlgForIntUnitsAtClass(class, FALSE, thisObj, DIntArgsObj, creDlgObj, mfail)
#define CreCreDlgForIntUnitsAtParent(class, thisObj, DIntArgsObj, creDlgObj, mfail) \
        _CreCreDlgForIntUnitsAtClass(class, TRUE, thisObj, DIntArgsObj, creDlgObj, mfail)

#define CreOrUpdAssmStrc(prntProdElemObj, chldProdElemObj, assmStrcObj, mfail) \
        _CreOrUpdAssmStrcAtClass(NULL, FALSE, prntProdElemObj, chldProdElemObj, assmStrcObj, mfail)
#define CreOrUpdAssmStrcAtClass(class, prntProdElemObj, chldProdElemObj, assmStrcObj, mfail) \
        _CreOrUpdAssmStrcAtClass(class, FALSE, prntProdElemObj, chldProdElemObj, assmStrcObj, mfail)
#define CreOrUpdAssmStrcAtParent(class, prntProdElemObj, chldProdElemObj, assmStrcObj, mfail) \
        _CreOrUpdAssmStrcAtClass(class, TRUE, prntProdElemObj, chldProdElemObj, assmStrcObj, mfail)

#define CreatePrepareRelation(relationName, createArgs, leftPdmRoot, rightPdmItem, relation, mfail) \
        _CreatePrepareRelation(relationName, FALSE, relationName, createArgs, leftPdmRoot, rightPdmItem, relation, mfail)
#define CreatePrepareRelationAtParent(_class, relationName, createArgs, leftPdmRoot, rightPdmItem, relation, mfail) \
        _CreatePrepareRelation(_class, TRUE, relationName, createArgs, leftPdmRoot, rightPdmItem, relation, mfail)

#define CreateReportObjImpl(className, itemType, level, parentPart, usageStart, usageEnd, authorityStart, authortyEnd, cfgItemId, rptObj, mfail) \
        _CreateReportObjImpl(className, FALSE, className, itemType, level, parentPart, usageStart, usageEnd, authorityStart, authortyEnd, cfgItemId, rptObj, mfail)
#define CreateReportObjImplAtParent(_class, className, itemType, level, parentPart, usageStart, usageEnd, authorityStart, authortyEnd, cfgItemId, rptObj, mfail) \
        _CreateReportObjImpl(_class, TRUE, className, itemType, level, parentPart, usageStart, usageEnd, authorityStart, authortyEnd, cfgItemId, rptObj, mfail)

#define CreateRevEff(revEffClass, strucBI, cfgItem, createArgs, revEff, mfail) \
        _CreateRevEff(revEffClass, FALSE, revEffClass, strucBI, cfgItem, createArgs, revEff, mfail)
#define CreateRevEffAtParent(_class, revEffClass, strucBI, cfgItem, createArgs, revEff, mfail) \
        _CreateRevEff(_class, TRUE, revEffClass, strucBI, cfgItem, createArgs, revEff, mfail)

#define CreateRevEff2(revEffClass, strucBI, cfgItem, vew, createArgs, revEff, mfail) \
        _CreateRevEff2(revEffClass, FALSE, revEffClass, strucBI, cfgItem, vew, createArgs, revEff, mfail)
#define CreateRevEff2AtParent(_class, revEffClass, strucBI, cfgItem, vew, createArgs, revEff, mfail) \
        _CreateRevEff2(_class, TRUE, revEffClass, strucBI, cfgItem, vew, createArgs, revEff, mfail)

#define CreateStructEff(strcEffClass, strucBI, itemMstr, findNumber, cfgItem, createArgs, strucEff, mfail) \
        _CreateStructEff(strcEffClass, FALSE, strcEffClass, strucBI, itemMstr, findNumber, cfgItem, createArgs, strucEff, mfail)
#define CreateStructEffAtParent(_class, strcEffClass, strucBI, itemMstr, findNumber, cfgItem, createArgs, strucEff, mfail) \
        _CreateStructEff(_class, TRUE, strcEffClass, strucBI, itemMstr, findNumber, cfgItem, createArgs, strucEff, mfail)

#define CreateStructEff2(strcEffClass, strucBI, itemMstr, findNumber, cfgItem, vew, createArgs, strucEff, mfail) \
        _CreateStructEff2(strcEffClass, FALSE, strcEffClass, strucBI, itemMstr, findNumber, cfgItem, vew, createArgs, strucEff, mfail)
#define CreateStructEff2AtParent(_class, strcEffClass, strucBI, itemMstr, findNumber, cfgItem, vew, createArgs, strucEff, mfail) \
        _CreateStructEff2(_class, TRUE, strcEffClass, strucBI, itemMstr, findNumber, cfgItem, vew, createArgs, strucEff, mfail)

#define CreateStructRelation(strucApcClass, strucBI, itemMstr, createArgs, strucRelation, mfail) \
        _CreateStructRelation(strucApcClass, FALSE, strucApcClass, strucBI, itemMstr, createArgs, strucRelation, mfail)
#define CreateStructRelationAtParent(_class, strucApcClass, strucBI, itemMstr, createArgs, strucRelation, mfail) \
        _CreateStructRelation(_class, TRUE, strucApcClass, strucBI, itemMstr, createArgs, strucRelation, mfail)

#define CreateStructRelation2(strucApcClass, strucBI, itemMstr, vew, createArgs, strucRelation, mfail) \
        _CreateStructRelation2(strucApcClass, FALSE, strucApcClass, strucBI, itemMstr, vew, createArgs, strucRelation, mfail)
#define CreateStructRelation2AtParent(_class, strucApcClass, strucBI, itemMstr, vew, createArgs, strucRelation, mfail) \
        _CreateStructRelation2(_class, TRUE, strucApcClass, strucBI, itemMstr, vew, createArgs, strucRelation, mfail)

#define CreateStructureForApp(className, parentStrucBIObj, childItemMstrObj, interfaceObj, relObj, mfail) \
        _CreateStructureForApp(className, FALSE, className, parentStrucBIObj, childItemMstrObj, interfaceObj, relObj, mfail)
#define CreateStructureForAppAtParent(_class, className, parentStrucBIObj, childItemMstrObj, interfaceObj, relObj, mfail) \
        _CreateStructureForApp(_class, TRUE, className, parentStrucBIObj, childItemMstrObj, interfaceObj, relObj, mfail)

#define CreateSubPartObject(className, strucBIObj, itemMstrObj, findNumber, partMstrObj, vewObj, dialogObj, relObj, mfail) \
        _CreateSubPartObject(className, FALSE, className, strucBIObj, itemMstrObj, findNumber, partMstrObj, vewObj, dialogObj, relObj, mfail)
#define CreateSubPartObjectAtParent(_class, className, strucBIObj, itemMstrObj, findNumber, partMstrObj, vewObj, dialogObj, relObj, mfail) \
        _CreateSubPartObject(_class, TRUE, className, strucBIObj, itemMstrObj, findNumber, partMstrObj, vewObj, dialogObj, relObj, mfail)

#define CreateViewDepObject(className, strucBIObj, itemMstrObj, vewObj, dialogObj, relObj, mfail) \
        _CreateViewDepObject(className, FALSE, className, strucBIObj, itemMstrObj, vewObj, dialogObj, relObj, mfail)
#define CreateViewDepObjectAtParent(_class, className, strucBIObj, itemMstrObj, vewObj, dialogObj, relObj, mfail) \
        _CreateViewDepObject(_class, TRUE, className, strucBIObj, itemMstrObj, vewObj, dialogObj, relObj, mfail)

#define DGetLVS4ActViewNtwks(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4ActViewNtwksAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4ActViewNtwksAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4ActViewNtwksAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4ActViewNtwksAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4ActViewNtwksAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVS4AllViewNtwks(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4AllViewNtwksAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4AllViewNtwksAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4AllViewNtwksAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4AllViewNtwksAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4AllViewNtwksAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVS4CreVewToVews(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4CreVewToVewsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4CreVewToVewsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4CreVewToVewsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4CreVewToVewsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4CreVewToVewsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVS4QryListViews(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4QryListViewsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4QryListViewsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4QryListViewsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4QryListViewsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4QryListViewsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVS4ViewInNetwork(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4ViewInNetworkAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4ViewInNetworkAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4ViewInNetworkAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4ViewInNetworkAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4ViewInNetworkAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVS4WorkingViews(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4WorkingViewsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4WorkingViewsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4WorkingViewsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVS4WorkingViewsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVS4WorkingViewsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSAllRevisions(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllRevisionsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAllRevisionsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllRevisionsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAllRevisionsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllRevisionsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCertStatus(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCertStatusAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCertStatusAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCertStatusAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCertStatusAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCertStatusAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSPackageType(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSPackageTypeAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSPackageTypeAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSPackageTypeAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSPackageTypeAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSPackageTypeAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSVndStatus(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSVndStatusAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSVndStatusAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSVndStatusAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSVndStatusAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSVndStatusAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetPVS4ViewInNetwork(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetPVS4ViewInNetworkAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetPVS4ViewInNetworkAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetPVS4ViewInNetworkAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetPVS4ViewInNetworkAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetPVS4ViewInNetworkAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DeactivateVewNetNDNP(thisObj, mfail) \
        _DeactivateVewNetNDNPAtClass(NULL, FALSE, thisObj, mfail)
#define DeactivateVewNetNDNPAtClass(class, thisObj, mfail) \
        _DeactivateVewNetNDNPAtClass(class, FALSE, thisObj, mfail)
#define DeactivateVewNetNDNPAtParent(class, thisObj, mfail) \
        _DeactivateVewNetNDNPAtClass(class, TRUE, thisObj, mfail)

#define DeactivateVewNetwork(thisObj, mfail) \
        _DeactivateVewNetworkAtClass(NULL, FALSE, thisObj, mfail)
#define DeactivateVewNetworkAtClass(class, thisObj, mfail) \
        _DeactivateVewNetworkAtClass(class, FALSE, thisObj, mfail)
#define DeactivateVewNetworkAtParent(class, thisObj, mfail) \
        _DeactivateVewNetworkAtClass(class, TRUE, thisObj, mfail)

#define DeleteOccurrence2(thisObj, mfail) \
        _DeleteOccurrence2AtClass(NULL, FALSE, thisObj, mfail)
#define DeleteOccurrence2AtClass(class, thisObj, mfail) \
        _DeleteOccurrence2AtClass(class, FALSE, thisObj, mfail)
#define DeleteOccurrence2AtParent(class, thisObj, mfail) \
        _DeleteOccurrence2AtClass(class, TRUE, thisObj, mfail)

#define DeleteRevEff(revEff, mfail) \
        _DeleteRevEffAtClass(NULL, FALSE, revEff, mfail)
#define DeleteRevEffAtClass(class, revEff, mfail) \
        _DeleteRevEffAtClass(class, FALSE, revEff, mfail)
#define DeleteRevEffAtParent(class, revEff, mfail) \
        _DeleteRevEffAtClass(class, TRUE, revEff, mfail)

#define DeleteRevEff2(revEff, vew, mfail) \
        _DeleteRevEff2AtClass(NULL, FALSE, revEff, vew, mfail)
#define DeleteRevEff2AtClass(class, revEff, vew, mfail) \
        _DeleteRevEff2AtClass(class, FALSE, revEff, vew, mfail)
#define DeleteRevEff2AtParent(class, revEff, vew, mfail) \
        _DeleteRevEff2AtClass(class, TRUE, revEff, vew, mfail)

#define DeleteStructEff(strucEff, mfail) \
        _DeleteStructEffAtClass(NULL, FALSE, strucEff, mfail)
#define DeleteStructEffAtClass(class, strucEff, mfail) \
        _DeleteStructEffAtClass(class, FALSE, strucEff, mfail)
#define DeleteStructEffAtParent(class, strucEff, mfail) \
        _DeleteStructEffAtClass(class, TRUE, strucEff, mfail)

#define DeleteStructEff2(strucEff, vew, mfail) \
        _DeleteStructEff2AtClass(NULL, FALSE, strucEff, vew, mfail)
#define DeleteStructEff2AtClass(class, strucEff, vew, mfail) \
        _DeleteStructEff2AtClass(class, FALSE, strucEff, vew, mfail)
#define DeleteStructEff2AtParent(class, strucEff, vew, mfail) \
        _DeleteStructEff2AtClass(class, TRUE, strucEff, vew, mfail)

#define DeleteStructRelation(strucRelation, mfail) \
        _DeleteStructRelationAtClass(NULL, FALSE, strucRelation, mfail)
#define DeleteStructRelationAtClass(class, strucRelation, mfail) \
        _DeleteStructRelationAtClass(class, FALSE, strucRelation, mfail)
#define DeleteStructRelationAtParent(class, strucRelation, mfail) \
        _DeleteStructRelationAtClass(class, TRUE, strucRelation, mfail)

#define DeleteStructRelation2(strucRelation, vew, mfail) \
        _DeleteStructRelation2AtClass(NULL, FALSE, strucRelation, vew, mfail)
#define DeleteStructRelation2AtClass(class, strucRelation, vew, mfail) \
        _DeleteStructRelation2AtClass(class, FALSE, strucRelation, vew, mfail)
#define DeleteStructRelation2AtParent(class, strucRelation, vew, mfail) \
        _DeleteStructRelation2AtClass(class, TRUE, strucRelation, vew, mfail)

#define DeleteStructureForApp(thisObj, parentStrucBIObj, mfail) \
        _DeleteStructureForAppAtClass(NULL, FALSE, thisObj, parentStrucBIObj, mfail)
#define DeleteStructureForAppAtClass(class, thisObj, parentStrucBIObj, mfail) \
        _DeleteStructureForAppAtClass(class, FALSE, thisObj, parentStrucBIObj, mfail)
#define DeleteStructureForAppAtParent(class, thisObj, parentStrucBIObj, mfail) \
        _DeleteStructureForAppAtClass(class, TRUE, thisObj, parentStrucBIObj, mfail)

#define DeleteSubPart(subPart, mfail) \
        _DeleteSubPartAtClass(NULL, FALSE, subPart, mfail)
#define DeleteSubPartAtClass(class, subPart, mfail) \
        _DeleteSubPartAtClass(class, FALSE, subPart, mfail)
#define DeleteSubPartAtParent(class, subPart, mfail) \
        _DeleteSubPartAtClass(class, TRUE, subPart, mfail)

#define DeleteSubPart2(subPart, vew, mfail) \
        _DeleteSubPart2AtClass(NULL, FALSE, subPart, vew, mfail)
#define DeleteSubPart2AtClass(class, subPart, vew, mfail) \
        _DeleteSubPart2AtClass(class, FALSE, subPart, vew, mfail)
#define DeleteSubPart2AtParent(class, subPart, vew, mfail) \
        _DeleteSubPart2AtClass(class, TRUE, subPart, vew, mfail)

#define DeleteViewDepObject(thisObj, vewObj, mfail) \
        _DeleteViewDepObjectAtClass(NULL, FALSE, thisObj, vewObj, mfail)
#define DeleteViewDepObjectAtClass(class, thisObj, vewObj, mfail) \
        _DeleteViewDepObjectAtClass(class, FALSE, thisObj, vewObj, mfail)
#define DeleteViewDepObjectAtParent(class, thisObj, vewObj, mfail) \
        _DeleteViewDepObjectAtClass(class, TRUE, thisObj, vewObj, mfail)

#define DetectRecursivePS(thisObj, asmPath, recLineElems, inpSet, itemObjs, relObjs, attribName, relClass, relnShipName, mfail) \
        _DetectRecursivePSAtClass(NULL, FALSE, thisObj, asmPath, recLineElems, inpSet, itemObjs, relObjs, attribName, relClass, relnShipName, mfail)
#define DetectRecursivePSAtClass(class, thisObj, asmPath, recLineElems, inpSet, itemObjs, relObjs, attribName, relClass, relnShipName, mfail) \
        _DetectRecursivePSAtClass(class, FALSE, thisObj, asmPath, recLineElems, inpSet, itemObjs, relObjs, attribName, relClass, relnShipName, mfail)
#define DetectRecursivePSAtParent(class, thisObj, asmPath, recLineElems, inpSet, itemObjs, relObjs, attribName, relClass, relnShipName, mfail) \
        _DetectRecursivePSAtClass(class, TRUE, thisObj, asmPath, recLineElems, inpSet, itemObjs, relObjs, attribName, relClass, relnShipName, mfail)

#define DoActivateVewNetwork(thisObj, dialogObj, mfail) \
        _DoActivateVewNetworkAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoActivateVewNetworkAtClass(class, thisObj, dialogObj, mfail) \
        _DoActivateVewNetworkAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoActivateVewNetworkAtParent(class, thisObj, dialogObj, mfail) \
        _DoActivateVewNetworkAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoAsgEOLDateFailClnup(gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAsgEOLDateFailClnupAtClass(NULL, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAsgEOLDateFailClnupAtClass(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAsgEOLDateFailClnupAtClass(class, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAsgEOLDateFailClnupAtParent(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAsgEOLDateFailClnupAtClass(class, TRUE, gnComMfgPart, assignEOLDateDlg, mfail)

#define DoAssignEOLDate(gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDateAtClass(NULL, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDateAtClass(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDateAtClass(class, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDateAtParent(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDateAtClass(class, TRUE, gnComMfgPart, assignEOLDateDlg, mfail)

#define DoAssignEOLDatePost(gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePostAtClass(NULL, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDatePostAtClass(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePostAtClass(class, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDatePostAtParent(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePostAtClass(class, TRUE, gnComMfgPart, assignEOLDateDlg, mfail)

#define DoAssignEOLDatePostInt(gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePostIntAtClass(NULL, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDatePostIntAtClass(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePostIntAtClass(class, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDatePostIntAtParent(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePostIntAtClass(class, TRUE, gnComMfgPart, assignEOLDateDlg, mfail)

#define DoAssignEOLDatePre(gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePreAtClass(NULL, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDatePreAtClass(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePreAtClass(class, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDatePreAtParent(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePreAtClass(class, TRUE, gnComMfgPart, assignEOLDateDlg, mfail)

#define DoAssignEOLDatePreInt(gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePreIntAtClass(NULL, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDatePreIntAtClass(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePreIntAtClass(class, FALSE, gnComMfgPart, assignEOLDateDlg, mfail)
#define DoAssignEOLDatePreIntAtParent(class, gnComMfgPart, assignEOLDateDlg, mfail) \
        _DoAssignEOLDatePreIntAtClass(class, TRUE, gnComMfgPart, assignEOLDateDlg, mfail)

#define DoAssignToViewNetwork(thisObj, dialogObj, mfail) \
        _DoAssignToViewNetworkAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoAssignToViewNetworkAtClass(class, thisObj, dialogObj, mfail) \
        _DoAssignToViewNetworkAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoAssignToViewNetworkAtParent(class, thisObj, dialogObj, mfail) \
        _DoAssignToViewNetworkAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoAuxViewDepDelete(thisObj, deletedViewMask, mfail) \
        _DoAuxViewDepDeleteAtClass(NULL, FALSE, thisObj, deletedViewMask, mfail)
#define DoAuxViewDepDeleteAtClass(class, thisObj, deletedViewMask, mfail) \
        _DoAuxViewDepDeleteAtClass(class, FALSE, thisObj, deletedViewMask, mfail)
#define DoAuxViewDepDeleteAtParent(class, thisObj, deletedViewMask, mfail) \
        _DoAuxViewDepDeleteAtClass(class, TRUE, thisObj, deletedViewMask, mfail)

#define DoAuxViewDepUpdate(thisObj, dialogObj, changedViewMask, mfail) \
        _DoAuxViewDepUpdateAtClass(NULL, FALSE, thisObj, dialogObj, changedViewMask, mfail)
#define DoAuxViewDepUpdateAtClass(class, thisObj, dialogObj, changedViewMask, mfail) \
        _DoAuxViewDepUpdateAtClass(class, FALSE, thisObj, dialogObj, changedViewMask, mfail)
#define DoAuxViewDepUpdateAtParent(class, thisObj, dialogObj, changedViewMask, mfail) \
        _DoAuxViewDepUpdateAtClass(class, TRUE, thisObj, dialogObj, changedViewMask, mfail)

#define DoCertStatFailCleanup(genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoCertStatFailCleanupAtClass(NULL, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoCertStatFailCleanupAtClass(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoCertStatFailCleanupAtClass(class, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoCertStatFailCleanupAtParent(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoCertStatFailCleanupAtClass(class, TRUE, genSplrObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgCertStatusPost(genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPostAtClass(NULL, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertStatusPostAtClass(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPostAtClass(class, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertStatusPostAtParent(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPostAtClass(class, TRUE, genSplrObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgCertStatusPostInt(genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPostIntAtClass(NULL, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertStatusPostIntAtClass(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPostIntAtClass(class, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertStatusPostIntAtParent(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPostIntAtClass(class, TRUE, genSplrObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgCertStatusPreInt(genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPreIntAtClass(NULL, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertStatusPreIntAtClass(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPreIntAtClass(class, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertStatusPreIntAtParent(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertStatusPreIntAtClass(class, TRUE, genSplrObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgCertStatusRels(genSplrObj, dialogObj, mfail) \
        _DoChgCertStatusRelsAtClass(NULL, FALSE, genSplrObj, dialogObj, mfail)
#define DoChgCertStatusRelsAtClass(class, genSplrObj, dialogObj, mfail) \
        _DoChgCertStatusRelsAtClass(class, FALSE, genSplrObj, dialogObj, mfail)
#define DoChgCertStatusRelsAtParent(class, genSplrObj, dialogObj, mfail) \
        _DoChgCertStatusRelsAtClass(class, TRUE, genSplrObj, dialogObj, mfail)

#define DoChgCertificatStatPre(genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertificatStatPreAtClass(NULL, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertificatStatPreAtClass(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertificatStatPreAtClass(class, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertificatStatPreAtParent(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertificatStatPreAtClass(class, TRUE, genSplrObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgCertificatStatus(genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertificatStatusAtClass(NULL, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertificatStatusAtClass(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertificatStatusAtClass(class, FALSE, genSplrObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgCertificatStatusAtParent(class, genSplrObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgCertificatStatusAtClass(class, TRUE, genSplrObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgVendorStatus(vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVendorStatusAtClass(NULL, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVendorStatusAtClass(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVendorStatusAtClass(class, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVendorStatusAtParent(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVendorStatusAtClass(class, TRUE, vendorObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgVendorStatusPre(vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVendorStatusPreAtClass(NULL, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVendorStatusPreAtClass(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVendorStatusPreAtClass(class, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVendorStatusPreAtParent(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVendorStatusPreAtClass(class, TRUE, vendorObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgVndStatPostInt(vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatPostIntAtClass(NULL, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVndStatPostIntAtClass(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatPostIntAtClass(class, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVndStatPostIntAtParent(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatPostIntAtClass(class, TRUE, vendorObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgVndStatPreInt(vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatPreIntAtClass(NULL, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVndStatPreIntAtClass(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatPreIntAtClass(class, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVndStatPreIntAtParent(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatPreIntAtClass(class, TRUE, vendorObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgVndStatusPost(vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatusPostAtClass(NULL, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVndStatusPostAtClass(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatusPostAtClass(class, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoChgVndStatusPostAtParent(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChgVndStatusPostAtClass(class, TRUE, vendorObj, dialogObj, extraStr, extraObj, mfail)

#define DoChgVndStatusRels(vendorObj, dialogObj, mfail) \
        _DoChgVndStatusRelsAtClass(NULL, FALSE, vendorObj, dialogObj, mfail)
#define DoChgVndStatusRelsAtClass(class, vendorObj, dialogObj, mfail) \
        _DoChgVndStatusRelsAtClass(class, FALSE, vendorObj, dialogObj, mfail)
#define DoChgVndStatusRelsAtParent(class, vendorObj, dialogObj, mfail) \
        _DoChgVndStatusRelsAtClass(class, TRUE, vendorObj, dialogObj, mfail)

#define DoDeactivateVewNetwork(thisObj, mfail) \
        _DoDeactivateVewNetworkAtClass(NULL, FALSE, thisObj, mfail)
#define DoDeactivateVewNetworkAtClass(class, thisObj, mfail) \
        _DoDeactivateVewNetworkAtClass(class, FALSE, thisObj, mfail)
#define DoDeactivateVewNetworkAtParent(class, thisObj, mfail) \
        _DoDeactivateVewNetworkAtClass(class, TRUE, thisObj, mfail)

#define DoDetectRecursionInPS(thisObj, attribName, recLineElems, mfail) \
        _DoDetectRecursionInPSAtClass(NULL, FALSE, thisObj, attribName, recLineElems, mfail)
#define DoDetectRecursionInPSAtClass(class, thisObj, attribName, recLineElems, mfail) \
        _DoDetectRecursionInPSAtClass(class, FALSE, thisObj, attribName, recLineElems, mfail)
#define DoDetectRecursionInPSAtParent(class, thisObj, attribName, recLineElems, mfail) \
        _DoDetectRecursionInPSAtClass(class, TRUE, thisObj, attribName, recLineElems, mfail)

#define DoExpandRevEffectivity(thisObj, newWindow, genContextObj, mfail) \
        _DoExpandRevEffectivityAtClass(NULL, FALSE, thisObj, newWindow, genContextObj, mfail)
#define DoExpandRevEffectivityAtClass(class, thisObj, newWindow, genContextObj, mfail) \
        _DoExpandRevEffectivityAtClass(class, FALSE, thisObj, newWindow, genContextObj, mfail)
#define DoExpandRevEffectivityAtParent(class, thisObj, newWindow, genContextObj, mfail) \
        _DoExpandRevEffectivityAtClass(class, TRUE, thisObj, newWindow, genContextObj, mfail)

#define DoFreezeOfRelObj(thisObj, itemObj, mfail) \
        _DoFreezeOfRelObjAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoFreezeOfRelObjAtClass(class, thisObj, itemObj, mfail) \
        _DoFreezeOfRelObjAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoFreezeOfRelObjAtParent(class, thisObj, itemObj, mfail) \
        _DoFreezeOfRelObjAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoFreezeView(thisObj, mfail) \
        _DoFreezeViewAtClass(NULL, FALSE, thisObj, mfail)
#define DoFreezeViewAtClass(class, thisObj, mfail) \
        _DoFreezeViewAtClass(class, FALSE, thisObj, mfail)
#define DoFreezeViewAtParent(class, thisObj, mfail) \
        _DoFreezeViewAtClass(class, TRUE, thisObj, mfail)

#define DoFreezeViewOfRelObjs(thisObj, mfail) \
        _DoFreezeViewOfRelObjsAtClass(NULL, FALSE, thisObj, mfail)
#define DoFreezeViewOfRelObjsAtClass(class, thisObj, mfail) \
        _DoFreezeViewOfRelObjsAtClass(class, FALSE, thisObj, mfail)
#define DoFreezeViewOfRelObjsAtParent(class, thisObj, mfail) \
        _DoFreezeViewOfRelObjsAtClass(class, TRUE, thisObj, mfail)

#define DoGenerateBOM(thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateBOMAtClass(NULL, FALSE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)
#define DoGenerateBOMAtClass(class, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateBOMAtClass(class, FALSE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)
#define DoGenerateBOMAtParent(class, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateBOMAtClass(class, TRUE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)

#define DoGenerateBOMStr(thisObj, inpSet, dialogObj, maxLevel, mfail) \
        _DoGenerateBOMStrAtClass(NULL, FALSE, thisObj, inpSet, dialogObj, maxLevel, mfail)
#define DoGenerateBOMStrAtClass(class, thisObj, inpSet, dialogObj, maxLevel, mfail) \
        _DoGenerateBOMStrAtClass(class, FALSE, thisObj, inpSet, dialogObj, maxLevel, mfail)
#define DoGenerateBOMStrAtParent(class, thisObj, inpSet, dialogObj, maxLevel, mfail) \
        _DoGenerateBOMStrAtClass(class, TRUE, thisObj, inpSet, dialogObj, maxLevel, mfail)

#define DoGenerateBOMXML(thisObj, prtObjSet, relObjSet, dialogObj, maxLevel, mfail) \
        _DoGenerateBOMXMLAtClass(NULL, FALSE, thisObj, prtObjSet, relObjSet, dialogObj, maxLevel, mfail)
#define DoGenerateBOMXMLAtClass(class, thisObj, prtObjSet, relObjSet, dialogObj, maxLevel, mfail) \
        _DoGenerateBOMXMLAtClass(class, FALSE, thisObj, prtObjSet, relObjSet, dialogObj, maxLevel, mfail)
#define DoGenerateBOMXMLAtParent(class, thisObj, prtObjSet, relObjSet, dialogObj, maxLevel, mfail) \
        _DoGenerateBOMXMLAtClass(class, TRUE, thisObj, prtObjSet, relObjSet, dialogObj, maxLevel, mfail)

#define DoGenerateBOMXML2(thisObj, dialogObj, maxLevel, auxMessages, converterClass, converterDialog, outputHandler, mfail) \
        _DoGenerateBOMXML2AtClass(NULL, FALSE, thisObj, dialogObj, maxLevel, auxMessages, converterClass, converterDialog, outputHandler, mfail)
#define DoGenerateBOMXML2AtClass(class, thisObj, dialogObj, maxLevel, auxMessages, converterClass, converterDialog, outputHandler, mfail) \
        _DoGenerateBOMXML2AtClass(class, FALSE, thisObj, dialogObj, maxLevel, auxMessages, converterClass, converterDialog, outputHandler, mfail)
#define DoGenerateBOMXML2AtParent(class, thisObj, dialogObj, maxLevel, auxMessages, converterClass, converterDialog, outputHandler, mfail) \
        _DoGenerateBOMXML2AtClass(class, TRUE, thisObj, dialogObj, maxLevel, auxMessages, converterClass, converterDialog, outputHandler, mfail)

#define DoGenerateCmpr(thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateCmprAtClass(NULL, FALSE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)
#define DoGenerateCmprAtClass(class, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateCmprAtClass(class, FALSE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)
#define DoGenerateCmprAtParent(class, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateCmprAtClass(class, TRUE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)

#define DoGenerateCmprStr(thisObj, inpSet, dialogObj, mfail) \
        _DoGenerateCmprStrAtClass(NULL, FALSE, thisObj, inpSet, dialogObj, mfail)
#define DoGenerateCmprStrAtClass(class, thisObj, inpSet, dialogObj, mfail) \
        _DoGenerateCmprStrAtClass(class, FALSE, thisObj, inpSet, dialogObj, mfail)
#define DoGenerateCmprStrAtParent(class, thisObj, inpSet, dialogObj, mfail) \
        _DoGenerateCmprStrAtClass(class, TRUE, thisObj, inpSet, dialogObj, mfail)

#define DoGeneratePartsList(thisObj, dialogObj, host, usr, fullPath, mfail) \
        _DoGeneratePartsListAtClass(NULL, FALSE, thisObj, dialogObj, host, usr, fullPath, mfail)
#define DoGeneratePartsListAtClass(class, thisObj, dialogObj, host, usr, fullPath, mfail) \
        _DoGeneratePartsListAtClass(class, FALSE, thisObj, dialogObj, host, usr, fullPath, mfail)
#define DoGeneratePartsListAtParent(class, thisObj, dialogObj, host, usr, fullPath, mfail) \
        _DoGeneratePartsListAtClass(class, TRUE, thisObj, dialogObj, host, usr, fullPath, mfail)

#define DoGeneratePartsListStr(thisObj, inpSet, dialogObj, mfail) \
        _DoGeneratePartsListStrAtClass(NULL, FALSE, thisObj, inpSet, dialogObj, mfail)
#define DoGeneratePartsListStrAtClass(class, thisObj, inpSet, dialogObj, mfail) \
        _DoGeneratePartsListStrAtClass(class, FALSE, thisObj, inpSet, dialogObj, mfail)
#define DoGeneratePartsListStrAtParent(class, thisObj, inpSet, dialogObj, mfail) \
        _DoGeneratePartsListStrAtClass(class, TRUE, thisObj, inpSet, dialogObj, mfail)

#define DoGenerateRecDec(thisObj, dialogObj, host, usr, fullPath, mfail) \
        _DoGenerateRecDecAtClass(NULL, FALSE, thisObj, dialogObj, host, usr, fullPath, mfail)
#define DoGenerateRecDecAtClass(class, thisObj, dialogObj, host, usr, fullPath, mfail) \
        _DoGenerateRecDecAtClass(class, FALSE, thisObj, dialogObj, host, usr, fullPath, mfail)
#define DoGenerateRecDecAtParent(class, thisObj, dialogObj, host, usr, fullPath, mfail) \
        _DoGenerateRecDecAtClass(class, TRUE, thisObj, dialogObj, host, usr, fullPath, mfail)

#define DoGenerateRecDecStr(thisObj, inpSet, dialogObj, mfail) \
        _DoGenerateRecDecStrAtClass(NULL, FALSE, thisObj, inpSet, dialogObj, mfail)
#define DoGenerateRecDecStrAtClass(class, thisObj, inpSet, dialogObj, mfail) \
        _DoGenerateRecDecStrAtClass(class, FALSE, thisObj, inpSet, dialogObj, mfail)
#define DoGenerateRecDecStrAtParent(class, thisObj, inpSet, dialogObj, mfail) \
        _DoGenerateRecDecStrAtClass(class, TRUE, thisObj, inpSet, dialogObj, mfail)

#define DoGenerateRecDecXML(thisObj, dialogObj, prtObjSet, relObjSet, mfail) \
        _DoGenerateRecDecXMLAtClass(NULL, FALSE, thisObj, dialogObj, prtObjSet, relObjSet, mfail)
#define DoGenerateRecDecXMLAtClass(class, thisObj, dialogObj, prtObjSet, relObjSet, mfail) \
        _DoGenerateRecDecXMLAtClass(class, FALSE, thisObj, dialogObj, prtObjSet, relObjSet, mfail)
#define DoGenerateRecDecXMLAtParent(class, thisObj, dialogObj, prtObjSet, relObjSet, mfail) \
        _DoGenerateRecDecXMLAtClass(class, TRUE, thisObj, dialogObj, prtObjSet, relObjSet, mfail)

#define DoGenerateWusd(thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateWusdAtClass(NULL, FALSE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)
#define DoGenerateWusdAtClass(class, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateWusdAtClass(class, FALSE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)
#define DoGenerateWusdAtParent(class, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail) \
        _DoGenerateWusdAtClass(class, TRUE, thisObj, dialogObj, host, usr, fullPath, maxLevel, mfail)

#define DoGenerateWusdStr(thisObj, inpSet, dialogObj, maxLevel, mfail) \
        _DoGenerateWusdStrAtClass(NULL, FALSE, thisObj, inpSet, dialogObj, maxLevel, mfail)
#define DoGenerateWusdStrAtClass(class, thisObj, inpSet, dialogObj, maxLevel, mfail) \
        _DoGenerateWusdStrAtClass(class, FALSE, thisObj, inpSet, dialogObj, maxLevel, mfail)
#define DoGenerateWusdStrAtParent(class, thisObj, inpSet, dialogObj, maxLevel, mfail) \
        _DoGenerateWusdStrAtClass(class, TRUE, thisObj, inpSet, dialogObj, maxLevel, mfail)

#define DoGenerateWusdXML(thisObj, dialogObj, maxLevel, prtObjSet, relObjSet, mfail) \
        _DoGenerateWusdXMLAtClass(NULL, FALSE, thisObj, dialogObj, maxLevel, prtObjSet, relObjSet, mfail)
#define DoGenerateWusdXMLAtClass(class, thisObj, dialogObj, maxLevel, prtObjSet, relObjSet, mfail) \
        _DoGenerateWusdXMLAtClass(class, FALSE, thisObj, dialogObj, maxLevel, prtObjSet, relObjSet, mfail)
#define DoGenerateWusdXMLAtParent(class, thisObj, dialogObj, maxLevel, prtObjSet, relObjSet, mfail) \
        _DoGenerateWusdXMLAtClass(class, TRUE, thisObj, dialogObj, maxLevel, prtObjSet, relObjSet, mfail)

#define DoMarkVewNetworkUnused(thisObj, mfail) \
        _DoMarkVewNetworkUnusedAtClass(NULL, FALSE, thisObj, mfail)
#define DoMarkVewNetworkUnusedAtClass(class, thisObj, mfail) \
        _DoMarkVewNetworkUnusedAtClass(class, FALSE, thisObj, mfail)
#define DoMarkVewNetworkUnusedAtParent(class, thisObj, mfail) \
        _DoMarkVewNetworkUnusedAtClass(class, TRUE, thisObj, mfail)

#define DoMigOrRemVewNtwkInfo(thisObj, hostName, directory, migratingViewNetwork, newViewNetworkName, mfail) \
        _DoMigOrRemVewNtwkInfoAtClass(NULL, FALSE, thisObj, hostName, directory, migratingViewNetwork, newViewNetworkName, mfail)
#define DoMigOrRemVewNtwkInfoAtClass(class, thisObj, hostName, directory, migratingViewNetwork, newViewNetworkName, mfail) \
        _DoMigOrRemVewNtwkInfoAtClass(class, FALSE, thisObj, hostName, directory, migratingViewNetwork, newViewNetworkName, mfail)
#define DoMigOrRemVewNtwkInfoAtParent(class, thisObj, hostName, directory, migratingViewNetwork, newViewNetworkName, mfail) \
        _DoMigOrRemVewNtwkInfoAtClass(class, TRUE, thisObj, hostName, directory, migratingViewNetwork, newViewNetworkName, mfail)

#define DoMigOrRemViewMasks(className, hostName, directory, dbNameSet, queryClassSet, viewMaskAttr, curVewNtwkBitPos, ntwkViewMaskMapSet, migrate, newVewNtwkBitPos, strtBitPosMapSet, viewMaskMapSet, mfail) \
        _DoMigOrRemViewMasks(className, FALSE, className, hostName, directory, dbNameSet, queryClassSet, viewMaskAttr, curVewNtwkBitPos, ntwkViewMaskMapSet, migrate, newVewNtwkBitPos, strtBitPosMapSet, viewMaskMapSet, mfail)
#define DoMigOrRemViewMasksAtParent(_class, className, hostName, directory, dbNameSet, queryClassSet, viewMaskAttr, curVewNtwkBitPos, ntwkViewMaskMapSet, migrate, newVewNtwkBitPos, strtBitPosMapSet, viewMaskMapSet, mfail) \
        _DoMigOrRemViewMasks(_class, TRUE, className, hostName, directory, dbNameSet, queryClassSet, viewMaskAttr, curVewNtwkBitPos, ntwkViewMaskMapSet, migrate, newVewNtwkBitPos, strtBitPosMapSet, viewMaskMapSet, mfail)

#define DoMigrateBusItemAttrs(className, hostName, directory, dbNameSet, queryClassSet, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, mfail) \
        _DoMigrateBusItemAttrs(className, FALSE, className, hostName, directory, dbNameSet, queryClassSet, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, mfail)
#define DoMigrateBusItemAttrsAtParent(_class, className, hostName, directory, dbNameSet, queryClassSet, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, mfail) \
        _DoMigrateBusItemAttrs(_class, TRUE, className, hostName, directory, dbNameSet, queryClassSet, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, mfail)

#define DoPrepare(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoPrepareAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoPrepareAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoPrepareAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoPrepareAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoPrepareAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoRelateRevEffectivity(thisObj, mfail) \
        _DoRelateRevEffectivityAtClass(NULL, FALSE, thisObj, mfail)
#define DoRelateRevEffectivityAtClass(class, thisObj, mfail) \
        _DoRelateRevEffectivityAtClass(class, FALSE, thisObj, mfail)
#define DoRelateRevEffectivityAtParent(class, thisObj, mfail) \
        _DoRelateRevEffectivityAtClass(class, TRUE, thisObj, mfail)

#define DoRelateStrucEff(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateStrucEffAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define DoRelateStrucEffAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateStrucEffAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define DoRelateStrucEffAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateStrucEffAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define DoRelateStrucOption(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateStrucOptionAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define DoRelateStrucOptionAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateStrucOptionAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define DoRelateStrucOptionAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateStrucOptionAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define DoRelateSubPart(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateSubPartAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define DoRelateSubPartAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateSubPartAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define DoRelateSubPartAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _DoRelateSubPartAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define DoRemoveBusItemAttrs(className, hostName, directory, dbNameSet, queryClassSet, newVewNtwkBitPos, mfail) \
        _DoRemoveBusItemAttrs(className, FALSE, className, hostName, directory, dbNameSet, queryClassSet, newVewNtwkBitPos, mfail)
#define DoRemoveBusItemAttrsAtParent(_class, className, hostName, directory, dbNameSet, queryClassSet, newVewNtwkBitPos, mfail) \
        _DoRemoveBusItemAttrs(_class, TRUE, className, hostName, directory, dbNameSet, queryClassSet, newVewNtwkBitPos, mfail)

#define DoRevisePrtStDocPost(partObj, mfail) \
        _DoRevisePrtStDocPostAtClass(NULL, FALSE, partObj, mfail)
#define DoRevisePrtStDocPostAtClass(class, partObj, mfail) \
        _DoRevisePrtStDocPostAtClass(class, FALSE, partObj, mfail)
#define DoRevisePrtStDocPostAtParent(class, partObj, mfail) \
        _DoRevisePrtStDocPostAtClass(class, TRUE, partObj, mfail)

#define DoSetupSubPartForChges(className, strBIApcObj, mfail) \
        _DoSetupSubPartForChges(className, FALSE, className, strBIApcObj, mfail)
#define DoSetupSubPartForChgesAtParent(_class, className, strBIApcObj, mfail) \
        _DoSetupSubPartForChges(_class, TRUE, className, strBIApcObj, mfail)

#define DoValBOMEditUpdPre(thisObj, mfail) \
        _DoValBOMEditUpdPreAtClass(NULL, FALSE, thisObj, mfail)
#define DoValBOMEditUpdPreAtClass(class, thisObj, mfail) \
        _DoValBOMEditUpdPreAtClass(class, FALSE, thisObj, mfail)
#define DoValBOMEditUpdPreAtParent(class, thisObj, mfail) \
        _DoValBOMEditUpdPreAtClass(class, TRUE, thisObj, mfail)

#define DoViewDepCreate(thisObj, bgObj, mfail) \
        _DoViewDepCreateAtClass(NULL, FALSE, thisObj, bgObj, mfail)
#define DoViewDepCreateAtClass(class, thisObj, bgObj, mfail) \
        _DoViewDepCreateAtClass(class, FALSE, thisObj, bgObj, mfail)
#define DoViewDepCreateAtParent(class, thisObj, bgObj, mfail) \
        _DoViewDepCreateAtClass(class, TRUE, thisObj, bgObj, mfail)

#define DoViewDepCreateForAux(thisObj, strBIObj, mfail) \
        _DoViewDepCreateForAuxAtClass(NULL, FALSE, thisObj, strBIObj, mfail)
#define DoViewDepCreateForAuxAtClass(class, thisObj, strBIObj, mfail) \
        _DoViewDepCreateForAuxAtClass(class, FALSE, thisObj, strBIObj, mfail)
#define DoViewDepCreateForAuxAtParent(class, thisObj, strBIObj, mfail) \
        _DoViewDepCreateForAuxAtClass(class, TRUE, thisObj, strBIObj, mfail)

#define DoViewDepDelete(thisObj, viewContextBitPosition, deleteRelation, changedViewMask, mfail) \
        _DoViewDepDeleteAtClass(NULL, FALSE, thisObj, viewContextBitPosition, deleteRelation, changedViewMask, mfail)
#define DoViewDepDeleteAtClass(class, thisObj, viewContextBitPosition, deleteRelation, changedViewMask, mfail) \
        _DoViewDepDeleteAtClass(class, FALSE, thisObj, viewContextBitPosition, deleteRelation, changedViewMask, mfail)
#define DoViewDepDeleteAtParent(class, thisObj, viewContextBitPosition, deleteRelation, changedViewMask, mfail) \
        _DoViewDepDeleteAtClass(class, TRUE, thisObj, viewContextBitPosition, deleteRelation, changedViewMask, mfail)

#define DoViewDepUpdate(thisObj, viewContextBitPosition, changedViewMask, mfail) \
        _DoViewDepUpdateAtClass(NULL, FALSE, thisObj, viewContextBitPosition, changedViewMask, mfail)
#define DoViewDepUpdateAtClass(class, thisObj, viewContextBitPosition, changedViewMask, mfail) \
        _DoViewDepUpdateAtClass(class, FALSE, thisObj, viewContextBitPosition, changedViewMask, mfail)
#define DoViewDepUpdateAtParent(class, thisObj, viewContextBitPosition, changedViewMask, mfail) \
        _DoViewDepUpdateAtClass(class, TRUE, thisObj, viewContextBitPosition, changedViewMask, mfail)

#define DoVndStatFailCleanup(vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoVndStatFailCleanupAtClass(NULL, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoVndStatFailCleanupAtClass(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoVndStatFailCleanupAtClass(class, FALSE, vendorObj, dialogObj, extraStr, extraObj, mfail)
#define DoVndStatFailCleanupAtParent(class, vendorObj, dialogObj, extraStr, extraObj, mfail) \
        _DoVndStatFailCleanupAtClass(class, TRUE, vendorObj, dialogObj, extraStr, extraObj, mfail)

#define DoesRelClassPrcForCcs(className, answer, mfail) \
        _DoesRelClassPrcForCcs(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForCcsAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForCcs(_class, TRUE, className, answer, mfail)

#define DoesRelClassPrcForCvs(className, answer, mfail) \
        _DoesRelClassPrcForCvs(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForCvsAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForCvs(_class, TRUE, className, answer, mfail)

#define DoesRelNeedViewInfo(className, needViewInfoType, mfail) \
        _DoesRelNeedViewInfo(className, FALSE, className, needViewInfoType, mfail)
#define DoesRelNeedViewInfoAtParent(_class, className, needViewInfoType, mfail) \
        _DoesRelNeedViewInfo(_class, TRUE, className, needViewInfoType, mfail)

#define DupViewDepRelPre(thisObj, leftObj, rightObj, mfail) \
        _DupViewDepRelPreAtClass(NULL, FALSE, thisObj, leftObj, rightObj, mfail)
#define DupViewDepRelPreAtClass(class, thisObj, leftObj, rightObj, mfail) \
        _DupViewDepRelPreAtClass(class, FALSE, thisObj, leftObj, rightObj, mfail)
#define DupViewDepRelPreAtParent(class, thisObj, leftObj, rightObj, mfail) \
        _DupViewDepRelPreAtClass(class, TRUE, thisObj, leftObj, rightObj, mfail)

#define DuplicateViewDepERORel(thisObj, sourceObj, newObj, newRelObj, mfail) \
        _DuplicateViewDepERORelAtClass(NULL, FALSE, thisObj, sourceObj, newObj, newRelObj, mfail)
#define DuplicateViewDepERORelAtClass(class, thisObj, sourceObj, newObj, newRelObj, mfail) \
        _DuplicateViewDepERORelAtClass(class, FALSE, thisObj, sourceObj, newObj, newRelObj, mfail)
#define DuplicateViewDepERORelAtParent(class, thisObj, sourceObj, newObj, newRelObj, mfail) \
        _DuplicateViewDepERORelAtClass(class, TRUE, thisObj, sourceObj, newObj, newRelObj, mfail)

#define DuplicateViewDepRel(thisObj, sourceObj, newObj, mfail) \
        _DuplicateViewDepRelAtClass(NULL, FALSE, thisObj, sourceObj, newObj, mfail)
#define DuplicateViewDepRelAtClass(class, thisObj, sourceObj, newObj, mfail) \
        _DuplicateViewDepRelAtClass(class, FALSE, thisObj, sourceObj, newObj, mfail)
#define DuplicateViewDepRelAtParent(class, thisObj, sourceObj, newObj, mfail) \
        _DuplicateViewDepRelAtClass(class, TRUE, thisObj, sourceObj, newObj, mfail)

#define EffectivityImplosion(msgClassName, selectedItems, dialogObj, AttrListForDisplay, outputSet, mfail) \
        _EffectivityImplosion(msgClassName, FALSE, msgClassName, selectedItems, dialogObj, AttrListForDisplay, outputSet, mfail)
#define EffectivityImplosionAtParent(_class, msgClassName, selectedItems, dialogObj, AttrListForDisplay, outputSet, mfail) \
        _EffectivityImplosion(_class, TRUE, msgClassName, selectedItems, dialogObj, AttrListForDisplay, outputSet, mfail)

#define ExpandItem3(relationClass, strucBi, relationship, cfgCntxt, scope, relations, pdmItems, mfail) \
        _ExpandItem3(relationClass, FALSE, relationClass, strucBi, relationship, cfgCntxt, scope, relations, pdmItems, mfail)
#define ExpandItem3AtParent(_class, relationClass, strucBi, relationship, cfgCntxt, scope, relations, pdmItems, mfail) \
        _ExpandItem3(_class, TRUE, relationClass, strucBi, relationship, cfgCntxt, scope, relations, pdmItems, mfail)

#define ExpandItemInt(relationClass, strucBi, relationship, cfgCntxt, scope, relations, pdmItems, mfail) \
        _ExpandItemInt(relationClass, FALSE, relationClass, strucBi, relationship, cfgCntxt, scope, relations, pdmItems, mfail)
#define ExpandItemIntAtParent(_class, relationClass, strucBi, relationship, cfgCntxt, scope, relations, pdmItems, mfail) \
        _ExpandItemInt(_class, TRUE, relationClass, strucBi, relationship, cfgCntxt, scope, relations, pdmItems, mfail)

#define ExpandRevEffectivity(thisObj, newWindow, genContextObj, mfail) \
        _ExpandRevEffectivityAtClass(NULL, FALSE, thisObj, newWindow, genContextObj, mfail)
#define ExpandRevEffectivityAtClass(class, thisObj, newWindow, genContextObj, mfail) \
        _ExpandRevEffectivityAtClass(class, FALSE, thisObj, newWindow, genContextObj, mfail)
#define ExpandRevEffectivityAtParent(class, thisObj, newWindow, genContextObj, mfail) \
        _ExpandRevEffectivityAtClass(class, TRUE, thisObj, newWindow, genContextObj, mfail)

#define FilterItmTmplSet(reportObjMgmtArgs, relTemplateSet, mfail) \
        _FilterItmTmplSetAtClass(NULL, FALSE, reportObjMgmtArgs, relTemplateSet, mfail)
#define FilterItmTmplSetAtClass(class, reportObjMgmtArgs, relTemplateSet, mfail) \
        _FilterItmTmplSetAtClass(class, FALSE, reportObjMgmtArgs, relTemplateSet, mfail)
#define FilterItmTmplSetAtParent(class, reportObjMgmtArgs, relTemplateSet, mfail) \
        _FilterItmTmplSetAtClass(class, TRUE, reportObjMgmtArgs, relTemplateSet, mfail)

#define FilterStrucApcs(thisObj, deletedFindNumber, deletedViewMask, affectedViewMask, deleteAuxRels, mfail) \
        _FilterStrucApcsAtClass(NULL, FALSE, thisObj, deletedFindNumber, deletedViewMask, affectedViewMask, deleteAuxRels, mfail)
#define FilterStrucApcsAtClass(class, thisObj, deletedFindNumber, deletedViewMask, affectedViewMask, deleteAuxRels, mfail) \
        _FilterStrucApcsAtClass(class, FALSE, thisObj, deletedFindNumber, deletedViewMask, affectedViewMask, deleteAuxRels, mfail)
#define FilterStrucApcsAtParent(class, thisObj, deletedFindNumber, deletedViewMask, affectedViewMask, deleteAuxRels, mfail) \
        _FilterStrucApcsAtClass(class, TRUE, thisObj, deletedFindNumber, deletedViewMask, affectedViewMask, deleteAuxRels, mfail)

#define FindConstrainedRels(thisObj, relations, mfail) \
        _FindConstrainedRelsAtClass(NULL, FALSE, thisObj, relations, mfail)
#define FindConstrainedRelsAtClass(class, thisObj, relations, mfail) \
        _FindConstrainedRelsAtClass(class, FALSE, thisObj, relations, mfail)
#define FindConstrainedRelsAtParent(class, thisObj, relations, mfail) \
        _FindConstrainedRelsAtClass(class, TRUE, thisObj, relations, mfail)

#define FindDocMstr(className, qryDef, docMstrObj, mfail) \
        _FindDocMstr(className, FALSE, className, qryDef, docMstrObj, mfail)
#define FindDocMstrAtParent(_class, className, qryDef, docMstrObj, mfail) \
        _FindDocMstr(_class, TRUE, className, qryDef, docMstrObj, mfail)

#define FindObjForPrepare(thisObj, dialogObj, prepareObj, mfail) \
        _FindObjForPrepareAtClass(NULL, FALSE, thisObj, dialogObj, prepareObj, mfail)
#define FindObjForPrepareAtClass(class, thisObj, dialogObj, prepareObj, mfail) \
        _FindObjForPrepareAtClass(class, FALSE, thisObj, dialogObj, prepareObj, mfail)
#define FindObjForPrepareAtParent(class, thisObj, dialogObj, prepareObj, mfail) \
        _FindObjForPrepareAtClass(class, TRUE, thisObj, dialogObj, prepareObj, mfail)

#define FindPartMstr(className, qryDef, partMstrObj, mfail) \
        _FindPartMstr(className, FALSE, className, qryDef, partMstrObj, mfail)
#define FindPartMstrAtParent(_class, className, qryDef, partMstrObj, mfail) \
        _FindPartMstr(_class, TRUE, className, qryDef, partMstrObj, mfail)

#define FindUnusedCfgItems(className, cfgItemIdSet, unusedCfgItems, mfail) \
        _FindUnusedCfgItems(className, FALSE, className, cfgItemIdSet, unusedCfgItems, mfail)
#define FindUnusedCfgItemsAtParent(_class, className, cfgItemIdSet, unusedCfgItems, mfail) \
        _FindUnusedCfgItems(_class, TRUE, className, cfgItemIdSet, unusedCfgItems, mfail)

#define FindVewDepRelships(className, classNameId, classNameUsed, strucBIRelship, otherRelship, mfail) \
        _FindVewDepRelships(className, FALSE, className, classNameId, classNameUsed, strucBIRelship, otherRelship, mfail)
#define FindVewDepRelshipsAtParent(_class, className, classNameId, classNameUsed, strucBIRelship, otherRelship, mfail) \
        _FindVewDepRelships(_class, TRUE, className, classNameId, classNameUsed, strucBIRelship, otherRelship, mfail)

#define FormatDisplayQuantity(className, inputQuantity, formatedDisplayQty, mfail) \
        _FormatDisplayQuantity(className, FALSE, className, inputQuantity, formatedDisplayQty, mfail)
#define FormatDisplayQuantityAtParent(_class, className, inputQuantity, formatedDisplayQty, mfail) \
        _FormatDisplayQuantity(_class, TRUE, className, inputQuantity, formatedDisplayQty, mfail)

#define FormatDisplayQuantity2(className, inputQuantity, formatedDisplayQty, mfail) \
        _FormatDisplayQuantity2(className, FALSE, className, inputQuantity, formatedDisplayQty, mfail)
#define FormatDisplayQuantity2AtParent(_class, className, inputQuantity, formatedDisplayQty, mfail) \
        _FormatDisplayQuantity2(_class, TRUE, className, inputQuantity, formatedDisplayQty, mfail)

#define FreezeView(thisObj, mfail) \
        _FreezeViewAtClass(NULL, FALSE, thisObj, mfail)
#define FreezeViewAtClass(class, thisObj, mfail) \
        _FreezeViewAtClass(class, FALSE, thisObj, mfail)
#define FreezeViewAtParent(class, thisObj, mfail) \
        _FreezeViewAtClass(class, TRUE, thisObj, mfail)

#define FreezeViewObject(thisObj, vewObj, mfail) \
        _FreezeViewObjectAtClass(NULL, FALSE, thisObj, vewObj, mfail)
#define FreezeViewObjectAtClass(class, thisObj, vewObj, mfail) \
        _FreezeViewObjectAtClass(class, FALSE, thisObj, vewObj, mfail)
#define FreezeViewObjectAtParent(class, thisObj, vewObj, mfail) \
        _FreezeViewObjectAtClass(class, TRUE, thisObj, vewObj, mfail)

#define GenSuppliedPartsXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenSuppliedPartsXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenSuppliedPartsXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenSuppliedPartsXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenSuppliedPartsXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenSuppliedPartsXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GenerateBOM(thisObj, mfail) \
        _GenerateBOMAtClass(NULL, FALSE, thisObj, mfail)
#define GenerateBOMAtClass(class, thisObj, mfail) \
        _GenerateBOMAtClass(class, FALSE, thisObj, mfail)
#define GenerateBOMAtParent(class, thisObj, mfail) \
        _GenerateBOMAtClass(class, TRUE, thisObj, mfail)

#define GenerateBOMStr(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateBOMStrAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateBOMStrAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateBOMStrAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateBOMStrAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateBOMStrAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define GenerateBOMXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateBOMXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateBOMXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateBOMXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateBOMXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateBOMXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GenerateCmpr(thisObj, mfail) \
        _GenerateCmprAtClass(NULL, FALSE, thisObj, mfail)
#define GenerateCmprAtClass(class, thisObj, mfail) \
        _GenerateCmprAtClass(class, FALSE, thisObj, mfail)
#define GenerateCmprAtParent(class, thisObj, mfail) \
        _GenerateCmprAtClass(class, TRUE, thisObj, mfail)

#define GenerateCmprStr(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateCmprStrAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateCmprStrAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateCmprStrAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateCmprStrAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateCmprStrAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define GenerateDetailsXML(thisObj, relationClass, relationshipName, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateDetailsXMLAtClass(NULL, FALSE, thisObj, relationClass, relationshipName, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateDetailsXMLAtClass(class, thisObj, relationClass, relationshipName, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateDetailsXMLAtClass(class, FALSE, thisObj, relationClass, relationshipName, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateDetailsXMLAtParent(class, thisObj, relationClass, relationshipName, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateDetailsXMLAtClass(class, TRUE, thisObj, relationClass, relationshipName, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GenerateDocDetailsRpt(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateDocDetailsRptAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateDocDetailsRptAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateDocDetailsRptAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateDocDetailsRptAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateDocDetailsRptAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define GenerateDocDetailsXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateDocDetailsXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateDocDetailsXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateDocDetailsXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateDocDetailsXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateDocDetailsXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GeneratePartDetailsRpt(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GeneratePartDetailsRptAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GeneratePartDetailsRptAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GeneratePartDetailsRptAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GeneratePartDetailsRptAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GeneratePartDetailsRptAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define GeneratePartDetailsXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GeneratePartDetailsXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GeneratePartDetailsXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GeneratePartDetailsXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GeneratePartDetailsXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GeneratePartDetailsXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GeneratePartsList(thisObj, mfail) \
        _GeneratePartsListAtClass(NULL, FALSE, thisObj, mfail)
#define GeneratePartsListAtClass(class, thisObj, mfail) \
        _GeneratePartsListAtClass(class, FALSE, thisObj, mfail)
#define GeneratePartsListAtParent(class, thisObj, mfail) \
        _GeneratePartsListAtClass(class, TRUE, thisObj, mfail)

#define GeneratePartsListStr(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GeneratePartsListStrAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GeneratePartsListStrAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GeneratePartsListStrAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GeneratePartsListStrAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GeneratePartsListStrAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define GeneratePartsListXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GeneratePartsListXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GeneratePartsListXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GeneratePartsListXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GeneratePartsListXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GeneratePartsListXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GenerateRecDec(thisObj, mfail) \
        _GenerateRecDecAtClass(NULL, FALSE, thisObj, mfail)
#define GenerateRecDecAtClass(class, thisObj, mfail) \
        _GenerateRecDecAtClass(class, FALSE, thisObj, mfail)
#define GenerateRecDecAtParent(class, thisObj, mfail) \
        _GenerateRecDecAtClass(class, TRUE, thisObj, mfail)

#define GenerateRecDecStr(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateRecDecStrAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateRecDecStrAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateRecDecStrAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateRecDecStrAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateRecDecStrAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define GenerateRecDecXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateRecDecXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateRecDecXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateRecDecXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateRecDecXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateRecDecXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GenerateWusd(thisObj, mfail) \
        _GenerateWusdAtClass(NULL, FALSE, thisObj, mfail)
#define GenerateWusdAtClass(class, thisObj, mfail) \
        _GenerateWusdAtClass(class, FALSE, thisObj, mfail)
#define GenerateWusdAtParent(class, thisObj, mfail) \
        _GenerateWusdAtClass(class, TRUE, thisObj, mfail)

#define GenerateWusdStr(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateWusdStrAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateWusdStrAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateWusdStrAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define GenerateWusdStrAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _GenerateWusdStrAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define GenerateWusdXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateWusdXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateWusdXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateWusdXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenerateWusdXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenerateWusdXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GetActiveBaseVewObjSet(className, vewNetworkObjSet, mfail) \
        _GetActiveBaseVewObjSet(className, FALSE, className, vewNetworkObjSet, mfail)
#define GetActiveBaseVewObjSetAtParent(_class, className, vewNetworkObjSet, mfail) \
        _GetActiveBaseVewObjSet(_class, TRUE, className, vewNetworkObjSet, mfail)

#define GetAllAnstrs(chldProdElemObj, prntProdElemObjs, mfail) \
        _GetAllAnstrsAtClass(NULL, FALSE, chldProdElemObj, prntProdElemObjs, mfail)
#define GetAllAnstrsAtClass(class, chldProdElemObj, prntProdElemObjs, mfail) \
        _GetAllAnstrsAtClass(class, FALSE, chldProdElemObj, prntProdElemObjs, mfail)
#define GetAllAnstrsAtParent(class, chldProdElemObj, prntProdElemObjs, mfail) \
        _GetAllAnstrsAtClass(class, TRUE, chldProdElemObj, prntProdElemObjs, mfail)

#define GetAllFirstLvlObjs(prodElemObj, chldProdElemObjs, chldPEOccObjs, mfail) \
        _GetAllFirstLvlObjsAtClass(NULL, FALSE, prodElemObj, chldProdElemObjs, chldPEOccObjs, mfail)
#define GetAllFirstLvlObjsAtClass(class, prodElemObj, chldProdElemObjs, chldPEOccObjs, mfail) \
        _GetAllFirstLvlObjsAtClass(class, FALSE, prodElemObj, chldProdElemObjs, chldPEOccObjs, mfail)
#define GetAllFirstLvlObjsAtParent(class, prodElemObj, chldProdElemObjs, chldPEOccObjs, mfail) \
        _GetAllFirstLvlObjsAtClass(class, TRUE, prodElemObj, chldProdElemObjs, chldPEOccObjs, mfail)

#define GetAllOffrdSvcObjs(thisObj, serviceObjs, relObjs, mfail) \
        _GetAllOffrdSvcObjsAtClass(NULL, FALSE, thisObj, serviceObjs, relObjs, mfail)
#define GetAllOffrdSvcObjsAtClass(class, thisObj, serviceObjs, relObjs, mfail) \
        _GetAllOffrdSvcObjsAtClass(class, FALSE, thisObj, serviceObjs, relObjs, mfail)
#define GetAllOffrdSvcObjsAtParent(class, thisObj, serviceObjs, relObjs, mfail) \
        _GetAllOffrdSvcObjsAtClass(class, TRUE, thisObj, serviceObjs, relObjs, mfail)

#define GetAllPartRevEffImpl(thisObj, thisSet, mfail) \
        _GetAllPartRevEffImplAtClass(NULL, FALSE, thisObj, thisSet, mfail)
#define GetAllPartRevEffImplAtClass(class, thisObj, thisSet, mfail) \
        _GetAllPartRevEffImplAtClass(class, FALSE, thisObj, thisSet, mfail)
#define GetAllPartRevEffImplAtParent(class, thisObj, thisSet, mfail) \
        _GetAllPartRevEffImplAtClass(class, TRUE, thisObj, thisSet, mfail)

#define GetAllServiceNames(className, values, mfail) \
        _GetAllServiceNames(className, FALSE, className, values, mfail)
#define GetAllServiceNamesAtParent(_class, className, values, mfail) \
        _GetAllServiceNames(_class, TRUE, className, values, mfail)

#define GetAllVewObjSet(className, vewObjSet, mfail) \
        _GetAllVewObjSet(className, FALSE, className, vewObjSet, mfail)
#define GetAllVewObjSetAtParent(_class, className, vewObjSet, mfail) \
        _GetAllVewObjSet(_class, TRUE, className, vewObjSet, mfail)

#define GetAllVewsInNetwork(className, viewNetworkBitPos, vewNetworkSet, mfail) \
        _GetAllVewsInNetwork(className, FALSE, className, viewNetworkBitPos, vewNetworkSet, mfail)
#define GetAllVewsInNetworkAtParent(_class, className, viewNetworkBitPos, vewNetworkSet, mfail) \
        _GetAllVewsInNetwork(_class, TRUE, className, viewNetworkBitPos, vewNetworkSet, mfail)

#define GetAltPrtsForBOMXML(partObj, partSet, argsObj, altPrtSet, altPrtRelSet, mfail) \
        _GetAltPrtsForBOMXMLAtClass(NULL, FALSE, partObj, partSet, argsObj, altPrtSet, altPrtRelSet, mfail)
#define GetAltPrtsForBOMXMLAtClass(class, partObj, partSet, argsObj, altPrtSet, altPrtRelSet, mfail) \
        _GetAltPrtsForBOMXMLAtClass(class, FALSE, partObj, partSet, argsObj, altPrtSet, altPrtRelSet, mfail)
#define GetAltPrtsForBOMXMLAtParent(class, partObj, partSet, argsObj, altPrtSet, altPrtRelSet, mfail) \
        _GetAltPrtsForBOMXMLAtClass(class, TRUE, partObj, partSet, argsObj, altPrtSet, altPrtRelSet, mfail)

#define GetAppPrefMfrForMfgPrt(gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetAppPrefMfrForMfgPrtAtClass(NULL, FALSE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)
#define GetAppPrefMfrForMfgPrtAtClass(class, gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetAppPrefMfrForMfgPrtAtClass(class, FALSE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)
#define GetAppPrefMfrForMfgPrtAtParent(class, gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetAppPrefMfrForMfgPrtAtClass(class, TRUE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)

#define GetAssignEOLDlgName(gnComMfgPart, assignEOLDlgName, mfail) \
        _GetAssignEOLDlgNameAtClass(NULL, FALSE, gnComMfgPart, assignEOLDlgName, mfail)
#define GetAssignEOLDlgNameAtClass(class, gnComMfgPart, assignEOLDlgName, mfail) \
        _GetAssignEOLDlgNameAtClass(class, FALSE, gnComMfgPart, assignEOLDlgName, mfail)
#define GetAssignEOLDlgNameAtParent(class, gnComMfgPart, assignEOLDlgName, mfail) \
        _GetAssignEOLDlgNameAtClass(class, TRUE, gnComMfgPart, assignEOLDlgName, mfail)

#define GetAssmStrcFrmPel(parentObj, childObj, assmStrcObj, mfail) \
        _GetAssmStrcFrmPelAtClass(NULL, FALSE, parentObj, childObj, assmStrcObj, mfail)
#define GetAssmStrcFrmPelAtClass(class, parentObj, childObj, assmStrcObj, mfail) \
        _GetAssmStrcFrmPelAtClass(class, FALSE, parentObj, childObj, assmStrcObj, mfail)
#define GetAssmStrcFrmPelAtParent(class, parentObj, childObj, assmStrcObj, mfail) \
        _GetAssmStrcFrmPelAtClass(class, TRUE, parentObj, childObj, assmStrcObj, mfail)

#define GetAssociatedDocItems(thisObj, docObjSet, mfail) \
        _GetAssociatedDocItemsAtClass(NULL, FALSE, thisObj, docObjSet, mfail)
#define GetAssociatedDocItemsAtClass(class, thisObj, docObjSet, mfail) \
        _GetAssociatedDocItemsAtClass(class, FALSE, thisObj, docObjSet, mfail)
#define GetAssociatedDocItemsAtParent(class, thisObj, docObjSet, mfail) \
        _GetAssociatedDocItemsAtClass(class, TRUE, thisObj, docObjSet, mfail)

#define GetAssociatedPsmPart(thisObj, partObjSet, mfail) \
        _GetAssociatedPsmPartAtClass(NULL, FALSE, thisObj, partObjSet, mfail)
#define GetAssociatedPsmPartAtClass(class, thisObj, partObjSet, mfail) \
        _GetAssociatedPsmPartAtClass(class, FALSE, thisObj, partObjSet, mfail)
#define GetAssociatedPsmPartAtParent(class, thisObj, partObjSet, mfail) \
        _GetAssociatedPsmPartAtClass(class, TRUE, thisObj, partObjSet, mfail)

#define GetAuxViewDepRels(className, strBIApcObj, itemMstrObj, findNumber, affectedViewMask, relObjSet, mfail) \
        _GetAuxViewDepRels(className, FALSE, className, strBIApcObj, itemMstrObj, findNumber, affectedViewMask, relObjSet, mfail)
#define GetAuxViewDepRelsAtParent(_class, className, strBIApcObj, itemMstrObj, findNumber, affectedViewMask, relObjSet, mfail) \
        _GetAuxViewDepRels(_class, TRUE, className, strBIApcObj, itemMstrObj, findNumber, affectedViewMask, relObjSet, mfail)

#define GetBaseVewObjByNtwk(className, viewNetwork, vewObj, mfail) \
        _GetBaseVewObjByNtwk(className, FALSE, className, viewNetwork, vewObj, mfail)
#define GetBaseVewObjByNtwkAtParent(_class, className, viewNetwork, vewObj, mfail) \
        _GetBaseVewObjByNtwk(_class, TRUE, className, viewNetwork, vewObj, mfail)

#define GetCertStatDialogName(genSplrObj, dialogName, mfail) \
        _GetCertStatDialogNameAtClass(NULL, FALSE, genSplrObj, dialogName, mfail)
#define GetCertStatDialogNameAtClass(class, genSplrObj, dialogName, mfail) \
        _GetCertStatDialogNameAtClass(class, FALSE, genSplrObj, dialogName, mfail)
#define GetCertStatDialogNameAtParent(class, genSplrObj, dialogName, mfail) \
        _GetCertStatDialogNameAtClass(class, TRUE, genSplrObj, dialogName, mfail)

#define GetCfgItemObjById(className, cfgItemId, cfgItemObj, mfail) \
        _GetCfgItemObjById(className, FALSE, className, cfgItemId, cfgItemObj, mfail)
#define GetCfgItemObjByIdAtParent(_class, className, cfgItemId, cfgItemObj, mfail) \
        _GetCfgItemObjById(_class, TRUE, className, cfgItemId, cfgItemObj, mfail)

#define GetContentsFilter(itemObj, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail) \
        _GetContentsFilterAtClass(NULL, FALSE, itemObj, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail)
#define GetContentsFilterAtClass(class, itemObj, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail) \
        _GetContentsFilterAtClass(class, FALSE, itemObj, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail)
#define GetContentsFilterAtParent(class, itemObj, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail) \
        _GetContentsFilterAtClass(class, TRUE, itemObj, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail)

#define GetContigViewMaskSet(className, viewMask, vewNetworkSet, contigViewMaskSet, mfail) \
        _GetContigViewMaskSet(className, FALSE, className, viewMask, vewNetworkSet, contigViewMaskSet, mfail)
#define GetContigViewMaskSetAtParent(_class, className, viewMask, vewNetworkSet, contigViewMaskSet, mfail) \
        _GetContigViewMaskSet(_class, TRUE, className, viewMask, vewNetworkSet, contigViewMaskSet, mfail)

#define GetCorrespondingView(thisObj, vewSet, vewObj, mfail) \
        _GetCorrespondingViewAtClass(NULL, FALSE, thisObj, vewSet, vewObj, mfail)
#define GetCorrespondingViewAtClass(class, thisObj, vewSet, vewObj, mfail) \
        _GetCorrespondingViewAtClass(class, FALSE, thisObj, vewSet, vewObj, mfail)
#define GetCorrespondingViewAtParent(class, thisObj, vewSet, vewObj, mfail) \
        _GetCorrespondingViewAtClass(class, TRUE, thisObj, vewSet, vewObj, mfail)

#define GetCreationViewMask(className, viewBitPos, creationViewMask, mfail) \
        _GetCreationViewMask(className, FALSE, className, viewBitPos, creationViewMask, mfail)
#define GetCreationViewMaskAtParent(_class, className, viewBitPos, creationViewMask, mfail) \
        _GetCreationViewMask(_class, TRUE, className, viewBitPos, creationViewMask, mfail)

#define GetDbBaseVewObjByNtwk(className, viewNetwork, vewObj, mfail) \
        _GetDbBaseVewObjByNtwk(className, FALSE, className, viewNetwork, vewObj, mfail)
#define GetDbBaseVewObjByNtwkAtParent(_class, className, viewNetwork, vewObj, mfail) \
        _GetDbBaseVewObjByNtwk(_class, TRUE, className, viewNetwork, vewObj, mfail)

#define GetDbVewObjByViewBit(className, viewBitPos, vewObj, mfail) \
        _GetDbVewObjByViewBit(className, FALSE, className, viewBitPos, vewObj, mfail)
#define GetDbVewObjByViewBitAtParent(_class, className, viewBitPos, vewObj, mfail) \
        _GetDbVewObjByViewBit(_class, TRUE, className, viewBitPos, vewObj, mfail)

#define GetDbVewObjByViewName(className, viewNetwork, viewName, vewObj, mfail) \
        _GetDbVewObjByViewName(className, FALSE, className, viewNetwork, viewName, vewObj, mfail)
#define GetDbVewObjByViewNameAtParent(_class, className, viewNetwork, viewName, vewObj, mfail) \
        _GetDbVewObjByViewName(_class, TRUE, className, viewNetwork, viewName, vewObj, mfail)

#define GetDbVewSetByViewName(className, viewName, viewObjs, mfail) \
        _GetDbVewSetByViewName(className, FALSE, className, viewName, viewObjs, mfail)
#define GetDbVewSetByViewNameAtParent(_class, className, viewName, viewObjs, mfail) \
        _GetDbVewSetByViewName(_class, TRUE, className, viewName, viewObjs, mfail)

#define GetDbViewsForNetwork(className, viewNetworkBitPos, vewNetworkSet, mfail) \
        _GetDbViewsForNetwork(className, FALSE, className, viewNetworkBitPos, vewNetworkSet, mfail)
#define GetDbViewsForNetworkAtParent(_class, className, viewNetworkBitPos, vewNetworkSet, mfail) \
        _GetDbViewsForNetwork(_class, TRUE, className, viewNetworkBitPos, vewNetworkSet, mfail)

#define GetDistribrsForBOMXML(partObj, partSet, argsObj, distrObjSet, distrByRelSet, mfail) \
        _GetDistribrsForBOMXMLAtClass(NULL, FALSE, partObj, partSet, argsObj, distrObjSet, distrByRelSet, mfail)
#define GetDistribrsForBOMXMLAtClass(class, partObj, partSet, argsObj, distrObjSet, distrByRelSet, mfail) \
        _GetDistribrsForBOMXMLAtClass(class, FALSE, partObj, partSet, argsObj, distrObjSet, distrByRelSet, mfail)
#define GetDistribrsForBOMXMLAtParent(class, partObj, partSet, argsObj, distrObjSet, distrByRelSet, mfail) \
        _GetDistribrsForBOMXMLAtClass(class, TRUE, partObj, partSet, argsObj, distrObjSet, distrByRelSet, mfail)

#define GetEditViewRelRuleMsg(className, ruleMsg, mfail) \
        _GetEditViewRelRuleMsg(className, FALSE, className, ruleMsg, mfail)
#define GetEditViewRelRuleMsgAtParent(_class, className, ruleMsg, mfail) \
        _GetEditViewRelRuleMsg(_class, TRUE, className, ruleMsg, mfail)

#define GetEffBasedOnCntxt(className, itemObjSet, relationship, contextObj, effRelObjSet, itemSide, mfail) \
        _GetEffBasedOnCntxt(className, FALSE, className, itemObjSet, relationship, contextObj, effRelObjSet, itemSide, mfail)
#define GetEffBasedOnCntxtAtParent(_class, className, itemObjSet, relationship, contextObj, effRelObjSet, itemSide, mfail) \
        _GetEffBasedOnCntxt(_class, TRUE, className, itemObjSet, relationship, contextObj, effRelObjSet, itemSide, mfail)

#define GetEffDateFromCtxt(className, genContextObj, configIdPref, effDatePref, mfail) \
        _GetEffDateFromCtxt(className, FALSE, className, genContextObj, configIdPref, effDatePref, mfail)
#define GetEffDateFromCtxtAtParent(_class, className, genContextObj, configIdPref, effDatePref, mfail) \
        _GetEffDateFromCtxt(_class, TRUE, className, genContextObj, configIdPref, effDatePref, mfail)

#define GetEffDynToRealInfo(thisObj, realRelClassName, realRelBISide, realRelBIRelship, realRelBIObj, mfail) \
        _GetEffDynToRealInfoAtClass(NULL, FALSE, thisObj, realRelClassName, realRelBISide, realRelBIRelship, realRelBIObj, mfail)
#define GetEffDynToRealInfoAtClass(class, thisObj, realRelClassName, realRelBISide, realRelBIRelship, realRelBIObj, mfail) \
        _GetEffDynToRealInfoAtClass(class, FALSE, thisObj, realRelClassName, realRelBISide, realRelBIRelship, realRelBIObj, mfail)
#define GetEffDynToRealInfoAtParent(class, thisObj, realRelClassName, realRelBISide, realRelBIRelship, realRelBIObj, mfail) \
        _GetEffDynToRealInfoAtClass(class, TRUE, thisObj, realRelClassName, realRelBISide, realRelBIRelship, realRelBIObj, mfail)

#define GetEffUnitFromCtxt(className, genContextObj, configIdPref, effUnitPref, mfail) \
        _GetEffUnitFromCtxt(className, FALSE, className, genContextObj, configIdPref, effUnitPref, mfail)
#define GetEffUnitFromCtxtAtParent(_class, className, genContextObj, configIdPref, effUnitPref, mfail) \
        _GetEffUnitFromCtxt(_class, TRUE, className, genContextObj, configIdPref, effUnitPref, mfail)

#define GetEligibleViewIdList(className, eligibleViewType, viewNetworkBitPos, startingViewBitPos, frozenViewMask, eligibleViewIdList, mfail) \
        _GetEligibleViewIdList(className, FALSE, className, eligibleViewType, viewNetworkBitPos, startingViewBitPos, frozenViewMask, eligibleViewIdList, mfail)
#define GetEligibleViewIdListAtParent(_class, className, eligibleViewType, viewNetworkBitPos, startingViewBitPos, frozenViewMask, eligibleViewIdList, mfail) \
        _GetEligibleViewIdList(_class, TRUE, className, eligibleViewType, viewNetworkBitPos, startingViewBitPos, frozenViewMask, eligibleViewIdList, mfail)

#define GetEndItemRangesImpl(className, rptSet, rangeSet, mfail) \
        _GetEndItemRangesImpl(className, FALSE, className, rptSet, rangeSet, mfail)
#define GetEndItemRangesImplAtParent(_class, className, rptSet, rangeSet, mfail) \
        _GetEndItemRangesImpl(_class, TRUE, className, rptSet, rangeSet, mfail)

#define GetFirstItemRangesImpl(className, rptSet, rangeSet, mfail) \
        _GetFirstItemRangesImpl(className, FALSE, className, rptSet, rangeSet, mfail)
#define GetFirstItemRangesImplAtParent(_class, className, rptSet, rangeSet, mfail) \
        _GetFirstItemRangesImpl(_class, TRUE, className, rptSet, rangeSet, mfail)

#define GetFolderContentForSet(className, folders, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail) \
        _GetFolderContentForSet(className, FALSE, className, folders, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail)
#define GetFolderContentForSetAtParent(_class, className, folders, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail) \
        _GetFolderContentForSet(_class, TRUE, className, folders, includeClasses, excludeClasses, latest, available, topLevel, folderContents, mfail)

#define GetFrozenViewMask(className, currentViewBitPos, frozenViewMask, mfail) \
        _GetFrozenViewMask(className, FALSE, className, currentViewBitPos, frozenViewMask, mfail)
#define GetFrozenViewMaskAtParent(_class, className, currentViewBitPos, frozenViewMask, mfail) \
        _GetFrozenViewMask(_class, TRUE, className, currentViewBitPos, frozenViewMask, mfail)

#define GetInRevwMfrForMfgPrt(gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetInRevwMfrForMfgPrtAtClass(NULL, FALSE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)
#define GetInRevwMfrForMfgPrtAtClass(class, gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetInRevwMfrForMfgPrtAtClass(class, FALSE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)
#define GetInRevwMfrForMfgPrtAtParent(class, gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetInRevwMfrForMfgPrtAtClass(class, TRUE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)

#define GetIncZeroQtyFromCtxt(className, genContextObj, includeZeroQty, mfail) \
        _GetIncZeroQtyFromCtxt(className, FALSE, className, genContextObj, includeZeroQty, mfail)
#define GetIncZeroQtyFromCtxtAtParent(_class, className, genContextObj, includeZeroQty, mfail) \
        _GetIncZeroQtyFromCtxt(_class, TRUE, className, genContextObj, includeZeroQty, mfail)

#define GetLastItemRangesImpl(className, rptSet, multiLevels, rangeSet, mfail) \
        _GetLastItemRangesImpl(className, FALSE, className, rptSet, multiLevels, rangeSet, mfail)
#define GetLastItemRangesImplAtParent(_class, className, rptSet, multiLevels, rangeSet, mfail) \
        _GetLastItemRangesImpl(_class, TRUE, className, rptSet, multiLevels, rangeSet, mfail)

#define GetLatestPartsImpl(className, partSet, mfail) \
        _GetLatestPartsImpl(className, FALSE, className, partSet, mfail)
#define GetLatestPartsImplAtParent(_class, className, partSet, mfail) \
        _GetLatestPartsImpl(_class, TRUE, className, partSet, mfail)

#define GetMfrForMfgPrt(gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetMfrForMfgPrtAtClass(NULL, FALSE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)
#define GetMfrForMfgPrtAtClass(class, gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetMfrForMfgPrtAtClass(class, FALSE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)
#define GetMfrForMfgPrtAtParent(class, gnMfgPrtObj, mfrObjs, mfrRels, mfail) \
        _GetMfrForMfgPrtAtClass(class, TRUE, gnMfgPrtObj, mfrObjs, mfrRels, mfail)

#define GetNavViewContext(contextObj, relationship, cfgCtxDisabled, currentViewBitPos, currentViewNetwork, currentViewName, mfail) \
        _GetNavViewContextAtClass(NULL, FALSE, contextObj, relationship, cfgCtxDisabled, currentViewBitPos, currentViewNetwork, currentViewName, mfail)
#define GetNavViewContextAtClass(class, contextObj, relationship, cfgCtxDisabled, currentViewBitPos, currentViewNetwork, currentViewName, mfail) \
        _GetNavViewContextAtClass(class, FALSE, contextObj, relationship, cfgCtxDisabled, currentViewBitPos, currentViewNetwork, currentViewName, mfail)
#define GetNavViewContextAtParent(class, contextObj, relationship, cfgCtxDisabled, currentViewBitPos, currentViewNetwork, currentViewName, mfail) \
        _GetNavViewContextAtClass(class, TRUE, contextObj, relationship, cfgCtxDisabled, currentViewBitPos, currentViewNetwork, currentViewName, mfail)

#define GetNavViewFromCtxt(className, genContextObj, viewNetworkPref, viewNamePref, mfail) \
        _GetNavViewFromCtxt(className, FALSE, className, genContextObj, viewNetworkPref, viewNamePref, mfail)
#define GetNavViewFromCtxtAtParent(_class, className, genContextObj, viewNetworkPref, viewNamePref, mfail) \
        _GetNavViewFromCtxt(_class, TRUE, className, genContextObj, viewNetworkPref, viewNamePref, mfail)

#define GetNewViewInfoFrmDlg(thisObj, viewNetworkName, startingViewName, mfail) \
        _GetNewViewInfoFrmDlgAtClass(NULL, FALSE, thisObj, viewNetworkName, startingViewName, mfail)
#define GetNewViewInfoFrmDlgAtClass(class, thisObj, viewNetworkName, startingViewName, mfail) \
        _GetNewViewInfoFrmDlgAtClass(class, FALSE, thisObj, viewNetworkName, startingViewName, mfail)
#define GetNewViewInfoFrmDlgAtParent(class, thisObj, viewNetworkName, startingViewName, mfail) \
        _GetNewViewInfoFrmDlgAtClass(class, TRUE, thisObj, viewNetworkName, startingViewName, mfail)

#define GetParamsForILV(topLvlProdElmObj, insertLevelDlgObj, newObject, newObjClass, newLeftRelDlg, newLeftRelClass, newRightRelDlg, newRightRelClass, selectedStrcRels, vewObject, mfail) \
        _GetParamsForILVAtClass(NULL, FALSE, topLvlProdElmObj, insertLevelDlgObj, newObject, newObjClass, newLeftRelDlg, newLeftRelClass, newRightRelDlg, newRightRelClass, selectedStrcRels, vewObject, mfail)
#define GetParamsForILVAtClass(class, topLvlProdElmObj, insertLevelDlgObj, newObject, newObjClass, newLeftRelDlg, newLeftRelClass, newRightRelDlg, newRightRelClass, selectedStrcRels, vewObject, mfail) \
        _GetParamsForILVAtClass(class, FALSE, topLvlProdElmObj, insertLevelDlgObj, newObject, newObjClass, newLeftRelDlg, newLeftRelClass, newRightRelDlg, newRightRelClass, selectedStrcRels, vewObject, mfail)
#define GetParamsForILVAtParent(class, topLvlProdElmObj, insertLevelDlgObj, newObject, newObjClass, newLeftRelDlg, newLeftRelClass, newRightRelDlg, newRightRelClass, selectedStrcRels, vewObject, mfail) \
        _GetParamsForILVAtClass(class, TRUE, topLvlProdElmObj, insertLevelDlgObj, newObject, newObjClass, newLeftRelDlg, newLeftRelClass, newRightRelDlg, newRightRelClass, selectedStrcRels, vewObject, mfail)

#define GetParamsForMOA(topLvlProdElmObj, makeOnAssmDlgObj, elemToRemove, selectedStrcRel, vewObject, mfail) \
        _GetParamsForMOAAtClass(NULL, FALSE, topLvlProdElmObj, makeOnAssmDlgObj, elemToRemove, selectedStrcRel, vewObject, mfail)
#define GetParamsForMOAAtClass(class, topLvlProdElmObj, makeOnAssmDlgObj, elemToRemove, selectedStrcRel, vewObject, mfail) \
        _GetParamsForMOAAtClass(class, FALSE, topLvlProdElmObj, makeOnAssmDlgObj, elemToRemove, selectedStrcRel, vewObject, mfail)
#define GetParamsForMOAAtParent(class, topLvlProdElmObj, makeOnAssmDlgObj, elemToRemove, selectedStrcRel, vewObject, mfail) \
        _GetParamsForMOAAtClass(class, TRUE, topLvlProdElmObj, makeOnAssmDlgObj, elemToRemove, selectedStrcRel, vewObject, mfail)

#define GetParamsForSBM(topLvlPrdElmObj, splitBOMDlgObj, structureRelation, quantity, occurrenceIds, vewObject, freeOccIds, mfail) \
        _GetParamsForSBMAtClass(NULL, FALSE, topLvlPrdElmObj, splitBOMDlgObj, structureRelation, quantity, occurrenceIds, vewObject, freeOccIds, mfail)
#define GetParamsForSBMAtClass(class, topLvlPrdElmObj, splitBOMDlgObj, structureRelation, quantity, occurrenceIds, vewObject, freeOccIds, mfail) \
        _GetParamsForSBMAtClass(class, FALSE, topLvlPrdElmObj, splitBOMDlgObj, structureRelation, quantity, occurrenceIds, vewObject, freeOccIds, mfail)
#define GetParamsForSBMAtParent(class, topLvlPrdElmObj, splitBOMDlgObj, structureRelation, quantity, occurrenceIds, vewObject, freeOccIds, mfail) \
        _GetParamsForSBMAtClass(class, TRUE, topLvlPrdElmObj, splitBOMDlgObj, structureRelation, quantity, occurrenceIds, vewObject, freeOccIds, mfail)

#define GetPartsForImplosion(thisObj, genContextObj, useLatest, currentLevel, droppedObjectSet, otherSideObjSet, relObjSet, mfail) \
        _GetPartsForImplosionAtClass(NULL, FALSE, thisObj, genContextObj, useLatest, currentLevel, droppedObjectSet, otherSideObjSet, relObjSet, mfail)
#define GetPartsForImplosionAtClass(class, thisObj, genContextObj, useLatest, currentLevel, droppedObjectSet, otherSideObjSet, relObjSet, mfail) \
        _GetPartsForImplosionAtClass(class, FALSE, thisObj, genContextObj, useLatest, currentLevel, droppedObjectSet, otherSideObjSet, relObjSet, mfail)
#define GetPartsForImplosionAtParent(class, thisObj, genContextObj, useLatest, currentLevel, droppedObjectSet, otherSideObjSet, relObjSet, mfail) \
        _GetPartsForImplosionAtClass(class, TRUE, thisObj, genContextObj, useLatest, currentLevel, droppedObjectSet, otherSideObjSet, relObjSet, mfail)

#define GetPreciseRelations(classname, leftObject, leftOBID, currentViewBitPos, relationSet, mfail) \
        _GetPreciseRelations(classname, FALSE, classname, leftObject, leftOBID, currentViewBitPos, relationSet, mfail)
#define GetPreciseRelationsAtParent(_class, classname, leftObject, leftOBID, currentViewBitPos, relationSet, mfail) \
        _GetPreciseRelations(_class, TRUE, classname, leftObject, leftOBID, currentViewBitPos, relationSet, mfail)

#define GetRealEffRelation(thisObj, realRelObj, mfail) \
        _GetRealEffRelationAtClass(NULL, FALSE, thisObj, realRelObj, mfail)
#define GetRealEffRelationAtClass(class, thisObj, realRelObj, mfail) \
        _GetRealEffRelationAtClass(class, FALSE, thisObj, realRelObj, mfail)
#define GetRealEffRelationAtParent(class, thisObj, realRelObj, mfail) \
        _GetRealEffRelationAtClass(class, TRUE, thisObj, realRelObj, mfail)

#define GetRealEffSideRelShip(className, dynamicRelship, realRelSide, realRelship, mfail) \
        _GetRealEffSideRelShip(className, FALSE, className, dynamicRelship, realRelSide, realRelship, mfail)
#define GetRealEffSideRelShipAtParent(_class, className, dynamicRelship, realRelSide, realRelship, mfail) \
        _GetRealEffSideRelShip(_class, TRUE, className, dynamicRelship, realRelSide, realRelship, mfail)

#define GetReprsAppMfgPrt(gnComPrtObj, mfgPrtObjs, reprsRels, mfail) \
        _GetReprsAppMfgPrtAtClass(NULL, FALSE, gnComPrtObj, mfgPrtObjs, reprsRels, mfail)
#define GetReprsAppMfgPrtAtClass(class, gnComPrtObj, mfgPrtObjs, reprsRels, mfail) \
        _GetReprsAppMfgPrtAtClass(class, FALSE, gnComPrtObj, mfgPrtObjs, reprsRels, mfail)
#define GetReprsAppMfgPrtAtParent(class, gnComPrtObj, mfgPrtObjs, reprsRels, mfail) \
        _GetReprsAppMfgPrtAtClass(class, TRUE, gnComPrtObj, mfgPrtObjs, reprsRels, mfail)

#define GetReprsMfgPrt(gnComPrtObj, mfgPrtObjs, reprsRels, mfail) \
        _GetReprsMfgPrtAtClass(NULL, FALSE, gnComPrtObj, mfgPrtObjs, reprsRels, mfail)
#define GetReprsMfgPrtAtClass(class, gnComPrtObj, mfgPrtObjs, reprsRels, mfail) \
        _GetReprsMfgPrtAtClass(class, FALSE, gnComPrtObj, mfgPrtObjs, reprsRels, mfail)
#define GetReprsMfgPrtAtParent(class, gnComPrtObj, mfgPrtObjs, reprsRels, mfail) \
        _GetReprsMfgPrtAtClass(class, TRUE, gnComPrtObj, mfgPrtObjs, reprsRels, mfail)

#define GetSelectedTblRows(dialogObj, allSelctdSvcs, offrdSvcs, aprvdSvcs, prefrdSvcs, mfail) \
        _GetSelectedTblRowsAtClass(NULL, FALSE, dialogObj, allSelctdSvcs, offrdSvcs, aprvdSvcs, prefrdSvcs, mfail)
#define GetSelectedTblRowsAtClass(class, dialogObj, allSelctdSvcs, offrdSvcs, aprvdSvcs, prefrdSvcs, mfail) \
        _GetSelectedTblRowsAtClass(class, FALSE, dialogObj, allSelctdSvcs, offrdSvcs, aprvdSvcs, prefrdSvcs, mfail)
#define GetSelectedTblRowsAtParent(class, dialogObj, allSelctdSvcs, offrdSvcs, aprvdSvcs, prefrdSvcs, mfail) \
        _GetSelectedTblRowsAtClass(class, TRUE, dialogObj, allSelctdSvcs, offrdSvcs, aprvdSvcs, prefrdSvcs, mfail)

#define GetSpecialCreViewMask(className, viewNetworkBitPos, oldCreViewMask, viewMaskSet, newCreViewMask, mfail) \
        _GetSpecialCreViewMask(className, FALSE, className, viewNetworkBitPos, oldCreViewMask, viewMaskSet, newCreViewMask, mfail)
#define GetSpecialCreViewMaskAtParent(_class, className, viewNetworkBitPos, oldCreViewMask, viewMaskSet, newCreViewMask, mfail) \
        _GetSpecialCreViewMask(_class, TRUE, className, viewNetworkBitPos, oldCreViewMask, viewMaskSet, newCreViewMask, mfail)

#define GetStrcOptListFromCtxt(className, genContextObj, strcOptListPref, mfail) \
        _GetStrcOptListFromCtxt(className, FALSE, className, genContextObj, strcOptListPref, mfail)
#define GetStrcOptListFromCtxtAtParent(_class, className, genContextObj, strcOptListPref, mfail) \
        _GetStrcOptListFromCtxt(_class, TRUE, className, genContextObj, strcOptListPref, mfail)

#define GetStrcOptObjByName(className, strcOptName, strcOptObj, mfail) \
        _GetStrcOptObjByName(className, FALSE, className, strcOptName, strcOptObj, mfail)
#define GetStrcOptObjByNameAtParent(_class, className, strcOptName, strcOptObj, mfail) \
        _GetStrcOptObjByName(_class, TRUE, className, strcOptName, strcOptObj, mfail)

#define GetStrcOptRFromStruc(className, strucApc, strcOptName, strucOptR, mfail) \
        _GetStrcOptRFromStruc(className, FALSE, className, strucApc, strcOptName, strucOptR, mfail)
#define GetStrcOptRFromStrucAtParent(_class, className, strucApc, strcOptName, strucOptR, mfail) \
        _GetStrcOptRFromStruc(_class, TRUE, className, strucApc, strcOptName, strucOptR, mfail)

#define GetStrucApcFromFindNum(className, strBIApcObj, itemMstrObj, findNumber, strucApcObjSet, mfail) \
        _GetStrucApcFromFindNum(className, FALSE, className, strBIApcObj, itemMstrObj, findNumber, strucApcObjSet, mfail)
#define GetStrucApcFromFindNumAtParent(_class, className, strBIApcObj, itemMstrObj, findNumber, strucApcObjSet, mfail) \
        _GetStrucApcFromFindNum(_class, TRUE, className, strBIApcObj, itemMstrObj, findNumber, strucApcObjSet, mfail)

#define GetStructObjForView(className, strucObjs, viewObj, selectedObj, mfail) \
        _GetStructObjForView(className, FALSE, className, strucObjs, viewObj, selectedObj, mfail)
#define GetStructObjForViewAtParent(_class, className, strucObjs, viewObj, selectedObj, mfail) \
        _GetStructObjForView(_class, TRUE, className, strucObjs, viewObj, selectedObj, mfail)

#define GetStructureOptionRel(thisObj, strcOptObj, vewObj, strcOptRObj, mfail) \
        _GetStructureOptionRelAtClass(NULL, FALSE, thisObj, strcOptObj, vewObj, strcOptRObj, mfail)
#define GetStructureOptionRelAtClass(class, thisObj, strcOptObj, vewObj, strcOptRObj, mfail) \
        _GetStructureOptionRelAtClass(class, FALSE, thisObj, strcOptObj, vewObj, strcOptRObj, mfail)
#define GetStructureOptionRelAtParent(class, thisObj, strcOptObj, vewObj, strcOptRObj, mfail) \
        _GetStructureOptionRelAtClass(class, TRUE, thisObj, strcOptObj, vewObj, strcOptRObj, mfail)

#define GetSubstPrtsForBOMXML(partObj, partSet, argsObj, subPrtSet, subPrtRelSet, mfail) \
        _GetSubstPrtsForBOMXMLAtClass(NULL, FALSE, partObj, partSet, argsObj, subPrtSet, subPrtRelSet, mfail)
#define GetSubstPrtsForBOMXMLAtClass(class, partObj, partSet, argsObj, subPrtSet, subPrtRelSet, mfail) \
        _GetSubstPrtsForBOMXMLAtClass(class, FALSE, partObj, partSet, argsObj, subPrtSet, subPrtRelSet, mfail)
#define GetSubstPrtsForBOMXMLAtParent(class, partObj, partSet, argsObj, subPrtSet, subPrtRelSet, mfail) \
        _GetSubstPrtsForBOMXMLAtClass(class, TRUE, partObj, partSet, argsObj, subPrtSet, subPrtRelSet, mfail)

#define GetSuppDocForVendor(vendorObj, suppDocObjs, suppDocRels, mfail) \
        _GetSuppDocForVendorAtClass(NULL, FALSE, vendorObj, suppDocObjs, suppDocRels, mfail)
#define GetSuppDocForVendorAtClass(class, vendorObj, suppDocObjs, suppDocRels, mfail) \
        _GetSuppDocForVendorAtClass(class, FALSE, vendorObj, suppDocObjs, suppDocRels, mfail)
#define GetSuppDocForVendorAtParent(class, vendorObj, suppDocObjs, suppDocRels, mfail) \
        _GetSuppDocForVendorAtClass(class, TRUE, vendorObj, suppDocObjs, suppDocRels, mfail)

#define GetSuppliersForBOMXML(partObj, partSet, argsObj, suppObjSet, suppByRelSet, mfail) \
        _GetSuppliersForBOMXMLAtClass(NULL, FALSE, partObj, partSet, argsObj, suppObjSet, suppByRelSet, mfail)
#define GetSuppliersForBOMXMLAtClass(class, partObj, partSet, argsObj, suppObjSet, suppByRelSet, mfail) \
        _GetSuppliersForBOMXMLAtClass(class, FALSE, partObj, partSet, argsObj, suppObjSet, suppByRelSet, mfail)
#define GetSuppliersForBOMXMLAtParent(class, partObj, partSet, argsObj, suppObjSet, suppByRelSet, mfail) \
        _GetSuppliersForBOMXMLAtClass(class, TRUE, partObj, partSet, argsObj, suppObjSet, suppByRelSet, mfail)

#define GetUnusedBaseVewObjSet(className, vewNetworkObjSet, mfail) \
        _GetUnusedBaseVewObjSet(className, FALSE, className, vewNetworkObjSet, mfail)
#define GetUnusedBaseVewObjSetAtParent(_class, className, vewNetworkObjSet, mfail) \
        _GetUnusedBaseVewObjSet(_class, TRUE, className, vewNetworkObjSet, mfail)

#define GetUpdateViewMasks(className, currentViewBitPos, currentViewMask, changedViewMask, unchangedViewMask, mfail) \
        _GetUpdateViewMasks(className, FALSE, className, currentViewBitPos, currentViewMask, changedViewMask, unchangedViewMask, mfail)
#define GetUpdateViewMasksAtParent(_class, className, currentViewBitPos, currentViewMask, changedViewMask, unchangedViewMask, mfail) \
        _GetUpdateViewMasks(_class, TRUE, className, currentViewBitPos, currentViewMask, changedViewMask, unchangedViewMask, mfail)

#define GetUsedBaseVewObjSet(className, vewNetworkObjSet, mfail) \
        _GetUsedBaseVewObjSet(className, FALSE, className, vewNetworkObjSet, mfail)
#define GetUsedBaseVewObjSetAtParent(_class, className, vewNetworkObjSet, mfail) \
        _GetUsedBaseVewObjSet(_class, TRUE, className, vewNetworkObjSet, mfail)

#define GetVewDepRObjs(thisObj, strBIApcObj, itemMstrObj, mfail) \
        _GetVewDepRObjsAtClass(NULL, FALSE, thisObj, strBIApcObj, itemMstrObj, mfail)
#define GetVewDepRObjsAtClass(class, thisObj, strBIApcObj, itemMstrObj, mfail) \
        _GetVewDepRObjsAtClass(class, FALSE, thisObj, strBIApcObj, itemMstrObj, mfail)
#define GetVewDepRObjsAtParent(class, thisObj, strBIApcObj, itemMstrObj, mfail) \
        _GetVewDepRObjsAtClass(class, TRUE, thisObj, strBIApcObj, itemMstrObj, mfail)

#define GetVewDepRealRelForDyn(thisObj, realRelObj, mfail) \
        _GetVewDepRealRelForDynAtClass(NULL, FALSE, thisObj, realRelObj, mfail)
#define GetVewDepRealRelForDynAtClass(class, thisObj, realRelObj, mfail) \
        _GetVewDepRealRelForDynAtClass(class, FALSE, thisObj, realRelObj, mfail)
#define GetVewDepRealRelForDynAtParent(class, thisObj, realRelObj, mfail) \
        _GetVewDepRealRelForDynAtClass(class, TRUE, thisObj, realRelObj, mfail)

#define GetVewNetworkIdList(className, vewNetworkIdList, mfail) \
        _GetVewNetworkIdList(className, FALSE, className, vewNetworkIdList, mfail)
#define GetVewNetworkIdListAtParent(_class, className, vewNetworkIdList, mfail) \
        _GetVewNetworkIdList(_class, TRUE, className, vewNetworkIdList, mfail)

#define GetVewObjByViewBit(className, viewBitPos, vewObj, mfail) \
        _GetVewObjByViewBit(className, FALSE, className, viewBitPos, vewObj, mfail)
#define GetVewObjByViewBitAtParent(_class, className, viewBitPos, vewObj, mfail) \
        _GetVewObjByViewBit(_class, TRUE, className, viewBitPos, vewObj, mfail)

#define GetVewObjByViewName(className, viewNetwork, viewName, vewObj, mfail) \
        _GetVewObjByViewName(className, FALSE, className, viewNetwork, viewName, vewObj, mfail)
#define GetVewObjByViewNameAtParent(_class, className, viewNetwork, viewName, vewObj, mfail) \
        _GetVewObjByViewName(_class, TRUE, className, viewNetwork, viewName, vewObj, mfail)

#define GetVewPredecessor(className, vewObj, predVewObj, mfail) \
        _GetVewPredecessor(className, FALSE, className, vewObj, predVewObj, mfail)
#define GetVewPredecessorAtParent(_class, className, vewObj, predVewObj, mfail) \
        _GetVewPredecessor(_class, TRUE, className, vewObj, predVewObj, mfail)

#define GetVewPredecessorBit(className, viewBitPos, predViewBitPos, mfail) \
        _GetVewPredecessorBit(className, FALSE, className, viewBitPos, predViewBitPos, mfail)
#define GetVewPredecessorBitAtParent(_class, className, viewBitPos, predViewBitPos, mfail) \
        _GetVewPredecessorBit(_class, TRUE, className, viewBitPos, predViewBitPos, mfail)

#define GetVewSuccessors(className, vewObj, vewSuccessorObjSet, mfail) \
        _GetVewSuccessors(className, FALSE, className, vewObj, vewSuccessorObjSet, mfail)
#define GetVewSuccessorsAtParent(_class, className, vewObj, vewSuccessorObjSet, mfail) \
        _GetVewSuccessors(_class, TRUE, className, vewObj, vewSuccessorObjSet, mfail)

#define GetViewActionConfirm(thisObj, cancel, mfail) \
        _GetViewActionConfirmAtClass(NULL, FALSE, thisObj, cancel, mfail)
#define GetViewActionConfirmAtClass(class, thisObj, cancel, mfail) \
        _GetViewActionConfirmAtClass(class, FALSE, thisObj, cancel, mfail)
#define GetViewActionConfirmAtParent(class, thisObj, cancel, mfail) \
        _GetViewActionConfirmAtClass(class, TRUE, thisObj, cancel, mfail)

#define GetViewDepChangeInfo(thisObj, viewContextBitPosition, changedViewMask, unchangedViewMask, mfail) \
        _GetViewDepChangeInfoAtClass(NULL, FALSE, thisObj, viewContextBitPosition, changedViewMask, unchangedViewMask, mfail)
#define GetViewDepChangeInfoAtClass(class, thisObj, viewContextBitPosition, changedViewMask, unchangedViewMask, mfail) \
        _GetViewDepChangeInfoAtClass(class, FALSE, thisObj, viewContextBitPosition, changedViewMask, unchangedViewMask, mfail)
#define GetViewDepChangeInfoAtParent(class, thisObj, viewContextBitPosition, changedViewMask, unchangedViewMask, mfail) \
        _GetViewDepChangeInfoAtClass(class, TRUE, thisObj, viewContextBitPosition, changedViewMask, unchangedViewMask, mfail)

#define GetViewDepObjsInSesObj(className, itemObj, relObj, mfail) \
        _GetViewDepObjsInSesObj(className, FALSE, className, itemObj, relObj, mfail)
#define GetViewDepObjsInSesObjAtParent(_class, className, itemObj, relObj, mfail) \
        _GetViewDepObjsInSesObj(_class, TRUE, className, itemObj, relObj, mfail)

#define GetViewListToWorkIn(thisObj, viewActionType, vewObjList, mfail) \
        _GetViewListToWorkInAtClass(NULL, FALSE, thisObj, viewActionType, vewObjList, mfail)
#define GetViewListToWorkInAtClass(class, thisObj, viewActionType, vewObjList, mfail) \
        _GetViewListToWorkInAtClass(class, FALSE, thisObj, viewActionType, vewObjList, mfail)
#define GetViewListToWorkInAtParent(class, thisObj, viewActionType, vewObjList, mfail) \
        _GetViewListToWorkInAtClass(class, TRUE, thisObj, viewActionType, vewObjList, mfail)

#define GetViewsToWorkIn(thisObj, viewActionType, vewObjList, mfail) \
        _GetViewsToWorkInAtClass(NULL, FALSE, thisObj, viewActionType, vewObjList, mfail)
#define GetViewsToWorkInAtClass(class, thisObj, viewActionType, vewObjList, mfail) \
        _GetViewsToWorkInAtClass(class, FALSE, thisObj, viewActionType, vewObjList, mfail)
#define GetViewsToWorkInAtParent(class, thisObj, viewActionType, vewObjList, mfail) \
        _GetViewsToWorkInAtClass(class, TRUE, thisObj, viewActionType, vewObjList, mfail)

#define GetVndStatDialogName(vendorObj, dialogName, mfail) \
        _GetVndStatDialogNameAtClass(NULL, FALSE, vendorObj, dialogName, mfail)
#define GetVndStatDialogNameAtClass(class, vendorObj, dialogName, mfail) \
        _GetVndStatDialogNameAtClass(class, FALSE, vendorObj, dialogName, mfail)
#define GetVndStatDialogNameAtParent(class, vendorObj, dialogName, mfail) \
        _GetVndStatDialogNameAtClass(class, TRUE, vendorObj, dialogName, mfail)

#define InflateEffDisplayInfo(className, effRelObj, mfail) \
        _InflateEffDisplayInfo(className, FALSE, className, effRelObj, mfail)
#define InflateEffDisplayInfoAtParent(_class, className, effRelObj, mfail) \
        _InflateEffDisplayInfo(_class, TRUE, className, effRelObj, mfail)

#define InflateForStrucRelate(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _InflateForStrucRelateAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define InflateForStrucRelateAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _InflateForStrucRelateAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define InflateForStrucRelateAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _InflateForStrucRelateAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define InflatePreviousVewInfo(thisObj, mfail) \
        _InflatePreviousVewInfoAtClass(NULL, FALSE, thisObj, mfail)
#define InflatePreviousVewInfoAtClass(class, thisObj, mfail) \
        _InflatePreviousVewInfoAtClass(class, FALSE, thisObj, mfail)
#define InflatePreviousVewInfoAtParent(class, thisObj, mfail) \
        _InflatePreviousVewInfoAtClass(class, TRUE, thisObj, mfail)

#define InflateSuppObjs(className, genContextObj, partObjSet, mfail) \
        _InflateSuppObjs(className, FALSE, className, genContextObj, partObjSet, mfail)
#define InflateSuppObjsAtParent(_class, className, genContextObj, partObjSet, mfail) \
        _InflateSuppObjs(_class, TRUE, className, genContextObj, partObjSet, mfail)

#define InflateSvcTypes(className, scope, objects, mfail) \
        _InflateSvcTypes(className, FALSE, className, scope, objects, mfail)
#define InflateSvcTypesAtParent(_class, className, scope, objects, mfail) \
        _InflateSvcTypes(_class, TRUE, className, scope, objects, mfail)

#define InflateViewNetworkInfo(thisObj, mfail) \
        _InflateViewNetworkInfoAtClass(NULL, FALSE, thisObj, mfail)
#define InflateViewNetworkInfoAtClass(class, thisObj, mfail) \
        _InflateViewNetworkInfoAtClass(class, FALSE, thisObj, mfail)
#define InflateViewNetworkInfoAtParent(class, thisObj, mfail) \
        _InflateViewNetworkInfoAtClass(class, TRUE, thisObj, mfail)

#define InsertLevel(topLvlProdElmObj, insertLvlDlgObj, mfail) \
        _InsertLevelAtClass(NULL, FALSE, topLvlProdElmObj, insertLvlDlgObj, mfail)
#define InsertLevelAtClass(class, topLvlProdElmObj, insertLvlDlgObj, mfail) \
        _InsertLevelAtClass(class, FALSE, topLvlProdElmObj, insertLvlDlgObj, mfail)
#define InsertLevelAtParent(class, topLvlProdElmObj, insertLvlDlgObj, mfail) \
        _InsertLevelAtClass(class, TRUE, topLvlProdElmObj, insertLvlDlgObj, mfail)

#define InsertLevel2Post(topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _InsertLevel2PostAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)
#define InsertLevel2PostAtClass(class, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _InsertLevel2PostAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)
#define InsertLevel2PostAtParent(class, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _InsertLevel2PostAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)

#define InsertLevel2Pre(topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _InsertLevel2PreAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)
#define InsertLevel2PreAtClass(class, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _InsertLevel2PreAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)
#define InsertLevel2PreAtParent(class, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _InsertLevel2PreAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)

#define InsertLevelPost(topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail) \
        _InsertLevelPostAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail)
#define InsertLevelPostAtClass(class, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail) \
        _InsertLevelPostAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail)
#define InsertLevelPostAtParent(class, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail) \
        _InsertLevelPostAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail)

#define InsertLevelPre(topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail) \
        _InsertLevelPreAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail)
#define InsertLevelPreAtClass(class, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail) \
        _InsertLevelPreAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail)
#define InsertLevelPreAtParent(class, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail) \
        _InsertLevelPreAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRels, newAssmObj, newRelDlg, newRelSet, mfail)

#define InsertLevelSet(className, topLvlProdElmObjSet, insertLvlDlgObjSet, mfail) \
        _InsertLevelSet(className, FALSE, className, topLvlProdElmObjSet, insertLvlDlgObjSet, mfail)
#define InsertLevelSetAtParent(_class, className, topLvlProdElmObjSet, insertLvlDlgObjSet, mfail) \
        _InsertLevelSet(_class, TRUE, className, topLvlProdElmObjSet, insertLvlDlgObjSet, mfail)

#define IntInsertLevel(topLvlProdElmObj, insertLvlDlgObj, mfail) \
        _IntInsertLevelAtClass(NULL, FALSE, topLvlProdElmObj, insertLvlDlgObj, mfail)
#define IntInsertLevelAtClass(class, topLvlProdElmObj, insertLvlDlgObj, mfail) \
        _IntInsertLevelAtClass(class, FALSE, topLvlProdElmObj, insertLvlDlgObj, mfail)
#define IntInsertLevelAtParent(class, topLvlProdElmObj, insertLvlDlgObj, mfail) \
        _IntInsertLevelAtClass(class, TRUE, topLvlProdElmObj, insertLvlDlgObj, mfail)

#define IntInsertLevel2Post(topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _IntInsertLevel2PostAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)
#define IntInsertLevel2PostAtClass(class, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _IntInsertLevel2PostAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)
#define IntInsertLevel2PostAtParent(class, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail) \
        _IntInsertLevel2PostAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRels, newObject, newLeftRelDlg, newRightRelDlg, vewObject, newRelSet, mfail)

#define IntMakeOnAssembly(topLvlProdElmObj, makeOnAssmDlgObj, mfail) \
        _IntMakeOnAssemblyAtClass(NULL, FALSE, topLvlProdElmObj, makeOnAssmDlgObj, mfail)
#define IntMakeOnAssemblyAtClass(class, topLvlProdElmObj, makeOnAssmDlgObj, mfail) \
        _IntMakeOnAssemblyAtClass(class, FALSE, topLvlProdElmObj, makeOnAssmDlgObj, mfail)
#define IntMakeOnAssemblyAtParent(class, topLvlProdElmObj, makeOnAssmDlgObj, mfail) \
        _IntMakeOnAssemblyAtClass(class, TRUE, topLvlProdElmObj, makeOnAssmDlgObj, mfail)

#define IntMakeOnAssemblyPost(topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _IntMakeOnAssemblyPostAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)
#define IntMakeOnAssemblyPostAtClass(class, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _IntMakeOnAssemblyPostAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)
#define IntMakeOnAssemblyPostAtParent(class, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _IntMakeOnAssemblyPostAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)

#define IntMakeOnAssemblyProc(topLvlProdElmObj, thisSubStructureRelObj, relQuantity, assocStrucOccClassName, parentFactory, childFactory, existingObjs, newStructurRelDialogSet, mfail) \
        _IntMakeOnAssemblyProcAtClass(NULL, FALSE, topLvlProdElmObj, thisSubStructureRelObj, relQuantity, assocStrucOccClassName, parentFactory, childFactory, existingObjs, newStructurRelDialogSet, mfail)
#define IntMakeOnAssemblyProcAtClass(class, topLvlProdElmObj, thisSubStructureRelObj, relQuantity, assocStrucOccClassName, parentFactory, childFactory, existingObjs, newStructurRelDialogSet, mfail) \
        _IntMakeOnAssemblyProcAtClass(class, FALSE, topLvlProdElmObj, thisSubStructureRelObj, relQuantity, assocStrucOccClassName, parentFactory, childFactory, existingObjs, newStructurRelDialogSet, mfail)
#define IntMakeOnAssemblyProcAtParent(class, topLvlProdElmObj, thisSubStructureRelObj, relQuantity, assocStrucOccClassName, parentFactory, childFactory, existingObjs, newStructurRelDialogSet, mfail) \
        _IntMakeOnAssemblyProcAtClass(class, TRUE, topLvlProdElmObj, thisSubStructureRelObj, relQuantity, assocStrucOccClassName, parentFactory, childFactory, existingObjs, newStructurRelDialogSet, mfail)

#define IntSplitBOM(topLvlProdElmObj, splitBOMDlgObj, mfail) \
        _IntSplitBOMAtClass(NULL, FALSE, topLvlProdElmObj, splitBOMDlgObj, mfail)
#define IntSplitBOMAtClass(class, topLvlProdElmObj, splitBOMDlgObj, mfail) \
        _IntSplitBOMAtClass(class, FALSE, topLvlProdElmObj, splitBOMDlgObj, mfail)
#define IntSplitBOMAtParent(class, topLvlProdElmObj, splitBOMDlgObj, mfail) \
        _IntSplitBOMAtClass(class, TRUE, topLvlProdElmObj, splitBOMDlgObj, mfail)

#define IntSplitBOMPost(topLvlProdElmObj, oldRelsEroRightObj, oldRelsEroObj, newRelSet, mfail) \
        _IntSplitBOMPostAtClass(NULL, FALSE, topLvlProdElmObj, oldRelsEroRightObj, oldRelsEroObj, newRelSet, mfail)
#define IntSplitBOMPostAtClass(class, topLvlProdElmObj, oldRelsEroRightObj, oldRelsEroObj, newRelSet, mfail) \
        _IntSplitBOMPostAtClass(class, FALSE, topLvlProdElmObj, oldRelsEroRightObj, oldRelsEroObj, newRelSet, mfail)
#define IntSplitBOMPostAtParent(class, topLvlProdElmObj, oldRelsEroRightObj, oldRelsEroObj, newRelSet, mfail) \
        _IntSplitBOMPostAtClass(class, TRUE, topLvlProdElmObj, oldRelsEroRightObj, oldRelsEroObj, newRelSet, mfail)

#define IntSplitBOMPre(topLvlProdElmObj, selectedStrcRel, oldRelsEroRightObj, oldRelsEroObj, mfail) \
        _IntSplitBOMPreAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRel, oldRelsEroRightObj, oldRelsEroObj, mfail)
#define IntSplitBOMPreAtClass(class, topLvlProdElmObj, selectedStrcRel, oldRelsEroRightObj, oldRelsEroObj, mfail) \
        _IntSplitBOMPreAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRel, oldRelsEroRightObj, oldRelsEroObj, mfail)
#define IntSplitBOMPreAtParent(class, topLvlProdElmObj, selectedStrcRel, oldRelsEroRightObj, oldRelsEroObj, mfail) \
        _IntSplitBOMPreAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRel, oldRelsEroRightObj, oldRelsEroObj, mfail)

#define IsCreRelAllowCondProc(relObj, creRelAllowedCondConstant, mfail) \
        _IsCreRelAllowCondProcAtClass(NULL, FALSE, relObj, creRelAllowedCondConstant, mfail)
#define IsCreRelAllowCondProcAtClass(class, relObj, creRelAllowedCondConstant, mfail) \
        _IsCreRelAllowCondProcAtClass(class, FALSE, relObj, creRelAllowedCondConstant, mfail)
#define IsCreRelAllowCondProcAtParent(class, relObj, creRelAllowedCondConstant, mfail) \
        _IsCreRelAllowCondProcAtClass(class, TRUE, relObj, creRelAllowedCondConstant, mfail)

#define IsEffOverlapping(thisObj, cmpEffRelObj, overlapped, mfail) \
        _IsEffOverlappingAtClass(NULL, FALSE, thisObj, cmpEffRelObj, overlapped, mfail)
#define IsEffOverlappingAtClass(class, thisObj, cmpEffRelObj, overlapped, mfail) \
        _IsEffOverlappingAtClass(class, FALSE, thisObj, cmpEffRelObj, overlapped, mfail)
#define IsEffOverlappingAtParent(class, thisObj, cmpEffRelObj, overlapped, mfail) \
        _IsEffOverlappingAtClass(class, TRUE, thisObj, cmpEffRelObj, overlapped, mfail)

#define IsFindNumberUniqueInt(relObj, findNumber, mfail) \
        _IsFindNumberUniqueIntAtClass(NULL, FALSE, relObj, findNumber, mfail)
#define IsFindNumberUniqueIntAtClass(class, relObj, findNumber, mfail) \
        _IsFindNumberUniqueIntAtClass(class, FALSE, relObj, findNumber, mfail)
#define IsFindNumberUniqueIntAtParent(class, relObj, findNumber, mfail) \
        _IsFindNumberUniqueIntAtClass(class, TRUE, relObj, findNumber, mfail)

#define IsFirstLevelChild(parentElemObj, childObj, includeAssmStrc, isChild, assmStrcObj, mfail) \
        _IsFirstLevelChildAtClass(NULL, FALSE, parentElemObj, childObj, includeAssmStrc, isChild, assmStrcObj, mfail)
#define IsFirstLevelChildAtClass(class, parentElemObj, childObj, includeAssmStrc, isChild, assmStrcObj, mfail) \
        _IsFirstLevelChildAtClass(class, FALSE, parentElemObj, childObj, includeAssmStrc, isChild, assmStrcObj, mfail)
#define IsFirstLevelChildAtParent(class, parentElemObj, childObj, includeAssmStrc, isChild, assmStrcObj, mfail) \
        _IsFirstLevelChildAtClass(class, TRUE, parentElemObj, childObj, includeAssmStrc, isChild, assmStrcObj, mfail)

#define IsMaxViewsMet(className, mfail) \
        _IsMaxViewsMet(className, FALSE, className, mfail)
#define IsMaxViewsMetAtParent(_class, className, mfail) \
        _IsMaxViewsMet(_class, TRUE, className, mfail)

#define IsObjectViewDependent(thisObj, isViewDependent, mfail) \
        _IsObjectViewDependentAtClass(NULL, FALSE, thisObj, isViewDependent, mfail)
#define IsObjectViewDependentAtClass(class, thisObj, isViewDependent, mfail) \
        _IsObjectViewDependentAtClass(class, FALSE, thisObj, isViewDependent, mfail)
#define IsObjectViewDependentAtParent(class, thisObj, isViewDependent, mfail) \
        _IsObjectViewDependentAtClass(class, TRUE, thisObj, isViewDependent, mfail)

#define IsPartEndItemImplosion(thisObj, isEndItem, mfail) \
        _IsPartEndItemImplosionAtClass(NULL, FALSE, thisObj, isEndItem, mfail)
#define IsPartEndItemImplosionAtClass(class, thisObj, isEndItem, mfail) \
        _IsPartEndItemImplosionAtClass(class, FALSE, thisObj, isEndItem, mfail)
#define IsPartEndItemImplosionAtParent(class, thisObj, isEndItem, mfail) \
        _IsPartEndItemImplosionAtClass(class, TRUE, thisObj, isEndItem, mfail)

#define IsPartStatusApproved(gnCmMfPtObj, isApproved, mfail) \
        _IsPartStatusApprovedAtClass(NULL, FALSE, gnCmMfPtObj, isApproved, mfail)
#define IsPartStatusApprovedAtClass(class, gnCmMfPtObj, isApproved, mfail) \
        _IsPartStatusApprovedAtClass(class, FALSE, gnCmMfPtObj, isApproved, mfail)
#define IsPartStatusApprovedAtParent(class, gnCmMfPtObj, isApproved, mfail) \
        _IsPartStatusApprovedAtClass(class, TRUE, gnCmMfPtObj, isApproved, mfail)

#define IsSupplierFoundRecurs(className, partObjSet, isFound, mfail) \
        _IsSupplierFoundRecurs(className, FALSE, className, partObjSet, isFound, mfail)
#define IsSupplierFoundRecursAtParent(_class, className, partObjSet, isFound, mfail) \
        _IsSupplierFoundRecurs(_class, TRUE, className, partObjSet, isFound, mfail)

#define IsVendorStatusApproved(vendorObj, isApproved, mfail) \
        _IsVendorStatusApprovedAtClass(NULL, FALSE, vendorObj, isApproved, mfail)
#define IsVendorStatusApprovedAtClass(class, vendorObj, isApproved, mfail) \
        _IsVendorStatusApprovedAtClass(class, FALSE, vendorObj, isApproved, mfail)
#define IsVendorStatusApprovedAtParent(class, vendorObj, isApproved, mfail) \
        _IsVendorStatusApprovedAtClass(class, TRUE, vendorObj, isApproved, mfail)

#define IsVendorStatusInReview(vendorObj, isInReview, mfail) \
        _IsVendorStatusInReviewAtClass(NULL, FALSE, vendorObj, isInReview, mfail)
#define IsVendorStatusInReviewAtClass(class, vendorObj, isInReview, mfail) \
        _IsVendorStatusInReviewAtClass(class, FALSE, vendorObj, isInReview, mfail)
#define IsVendorStatusInReviewAtParent(class, vendorObj, isInReview, mfail) \
        _IsVendorStatusInReviewAtClass(class, TRUE, vendorObj, isInReview, mfail)

#define IsVendorStatusPreferrd(vendorObj, isPreferred, mfail) \
        _IsVendorStatusPreferrdAtClass(NULL, FALSE, vendorObj, isPreferred, mfail)
#define IsVendorStatusPreferrdAtClass(class, vendorObj, isPreferred, mfail) \
        _IsVendorStatusPreferrdAtClass(class, FALSE, vendorObj, isPreferred, mfail)
#define IsVendorStatusPreferrdAtParent(class, vendorObj, isPreferred, mfail) \
        _IsVendorStatusPreferrdAtClass(class, TRUE, vendorObj, isPreferred, mfail)

#define IsVewNameUnique(className, viewNetwork, viewName, dupObj, mfail) \
        _IsVewNameUnique(className, FALSE, className, viewNetwork, viewName, dupObj, mfail)
#define IsVewNameUniqueAtParent(_class, className, viewNetwork, viewName, dupObj, mfail) \
        _IsVewNameUnique(_class, TRUE, className, viewNetwork, viewName, dupObj, mfail)

#define IsVewNetworkUnique(className, viewNetwork, dupObj, mfail) \
        _IsVewNetworkUnique(className, FALSE, className, viewNetwork, dupObj, mfail)
#define IsVewNetworkUniqueAtParent(_class, className, viewNetwork, dupObj, mfail) \
        _IsVewNetworkUnique(_class, TRUE, className, viewNetwork, dupObj, mfail)

#define MakeConfigItem(thisObj, mfail) \
        _MakeConfigItemAtClass(NULL, FALSE, thisObj, mfail)
#define MakeConfigItemAtClass(class, thisObj, mfail) \
        _MakeConfigItemAtClass(class, FALSE, thisObj, mfail)
#define MakeConfigItemAtParent(class, thisObj, mfail) \
        _MakeConfigItemAtClass(class, TRUE, thisObj, mfail)

#define MakeConfigItemObject(thisObj, dialogObj, cfgItemObj, mfail) \
        _MakeConfigItemObjectAtClass(NULL, FALSE, thisObj, dialogObj, cfgItemObj, mfail)
#define MakeConfigItemObjectAtClass(class, thisObj, dialogObj, cfgItemObj, mfail) \
        _MakeConfigItemObjectAtClass(class, FALSE, thisObj, dialogObj, cfgItemObj, mfail)
#define MakeConfigItemObjectAtParent(class, thisObj, dialogObj, cfgItemObj, mfail) \
        _MakeConfigItemObjectAtClass(class, TRUE, thisObj, dialogObj, cfgItemObj, mfail)

#define MakeDbCopyOfViewDepRel(thisObj, viewMask, mfail) \
        _MakeDbCopyOfViewDepRelAtClass(NULL, FALSE, thisObj, viewMask, mfail)
#define MakeDbCopyOfViewDepRelAtClass(class, thisObj, viewMask, mfail) \
        _MakeDbCopyOfViewDepRelAtClass(class, FALSE, thisObj, viewMask, mfail)
#define MakeDbCopyOfViewDepRelAtParent(class, thisObj, viewMask, mfail) \
        _MakeDbCopyOfViewDepRelAtClass(class, TRUE, thisObj, viewMask, mfail)

#define MakeOnAssembly(topLvlProdElemObj, makeOnAssmDlgObj, mfail) \
        _MakeOnAssemblyAtClass(NULL, FALSE, topLvlProdElemObj, makeOnAssmDlgObj, mfail)
#define MakeOnAssemblyAtClass(class, topLvlProdElemObj, makeOnAssmDlgObj, mfail) \
        _MakeOnAssemblyAtClass(class, FALSE, topLvlProdElemObj, makeOnAssmDlgObj, mfail)
#define MakeOnAssemblyAtParent(class, topLvlProdElemObj, makeOnAssmDlgObj, mfail) \
        _MakeOnAssemblyAtClass(class, TRUE, topLvlProdElemObj, makeOnAssmDlgObj, mfail)

#define MakeOnAssemblyPost(topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _MakeOnAssemblyPostAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)
#define MakeOnAssemblyPostAtClass(class, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _MakeOnAssemblyPostAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)
#define MakeOnAssemblyPostAtParent(class, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _MakeOnAssemblyPostAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)

#define MakeOnAssemblyPre(topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _MakeOnAssemblyPreAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)
#define MakeOnAssemblyPreAtClass(class, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _MakeOnAssemblyPreAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)
#define MakeOnAssemblyPreAtParent(class, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail) \
        _MakeOnAssemblyPreAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRel, elemToRemove, subStructureRelSet, newRelSet, mfail)

#define MakeOnAssemblySet(classname, topLvlProdElmObjSet, makeOnAssmDlgObjSet, mfail) \
        _MakeOnAssemblySet(classname, FALSE, classname, topLvlProdElmObjSet, makeOnAssmDlgObjSet, mfail)
#define MakeOnAssemblySetAtParent(_class, classname, topLvlProdElmObjSet, makeOnAssmDlgObjSet, mfail) \
        _MakeOnAssemblySet(_class, TRUE, classname, topLvlProdElmObjSet, makeOnAssmDlgObjSet, mfail)

#define MarkCfgItemInUse(className, cfgItemId, mfail) \
        _MarkCfgItemInUse(className, FALSE, className, cfgItemId, mfail)
#define MarkCfgItemInUseAtParent(_class, className, cfgItemId, mfail) \
        _MarkCfgItemInUse(_class, TRUE, className, cfgItemId, mfail)

#define MarkCfgItemInUseByObj(className, cfgItemObj, mfail) \
        _MarkCfgItemInUseByObj(className, FALSE, className, cfgItemObj, mfail)
#define MarkCfgItemInUseByObjAtParent(_class, className, cfgItemObj, mfail) \
        _MarkCfgItemInUseByObj(_class, TRUE, className, cfgItemObj, mfail)

#define MarkStrcOptInUse(className, strcOptName, mfail) \
        _MarkStrcOptInUse(className, FALSE, className, strcOptName, mfail)
#define MarkStrcOptInUseAtParent(_class, className, strcOptName, mfail) \
        _MarkStrcOptInUse(_class, TRUE, className, strcOptName, mfail)

#define MarkVewContextForEdit(className, contextObj, itemObj, relationship, relObjsSet, mfail) \
        _MarkVewContextForEdit(className, FALSE, className, contextObj, itemObj, relationship, relObjsSet, mfail)
#define MarkVewContextForEditAtParent(_class, className, contextObj, itemObj, relationship, relObjsSet, mfail) \
        _MarkVewContextForEdit(_class, TRUE, className, contextObj, itemObj, relationship, relObjsSet, mfail)

#define MarkVewContextForExp(className, contextObj, itemObj, relationship, relObjsSet, mfail) \
        _MarkVewContextForExp(className, FALSE, className, contextObj, itemObj, relationship, relObjsSet, mfail)
#define MarkVewContextForExpAtParent(_class, className, contextObj, itemObj, relationship, relObjsSet, mfail) \
        _MarkVewContextForExp(_class, TRUE, className, contextObj, itemObj, relationship, relObjsSet, mfail)

#define MarkVewForInUse(className, viewNetworkBitPos, inUse, mfail) \
        _MarkVewForInUse(className, FALSE, className, viewNetworkBitPos, inUse, mfail)
#define MarkVewForInUseAtParent(_class, className, viewNetworkBitPos, inUse, mfail) \
        _MarkVewForInUse(_class, TRUE, className, viewNetworkBitPos, inUse, mfail)

#define MarkVewNetForActivate(className, viewNetworkBitPos, isActivated, newViewNetwork, mfail) \
        _MarkVewNetForActivate(className, FALSE, className, viewNetworkBitPos, isActivated, newViewNetwork, mfail)
#define MarkVewNetForActivateAtParent(_class, className, viewNetworkBitPos, isActivated, newViewNetwork, mfail) \
        _MarkVewNetForActivate(_class, TRUE, className, viewNetworkBitPos, isActivated, newViewNetwork, mfail)

#define MarkVewNetworkUnused(thisObj, mfail) \
        _MarkVewNetworkUnusedAtClass(NULL, FALSE, thisObj, mfail)
#define MarkVewNetworkUnusedAtClass(class, thisObj, mfail) \
        _MarkVewNetworkUnusedAtClass(class, FALSE, thisObj, mfail)
#define MarkVewNetworkUnusedAtParent(class, thisObj, mfail) \
        _MarkVewNetworkUnusedAtClass(class, TRUE, thisObj, mfail)

#define MergeEndItemSetImpl(className, endItemsSet, mfail) \
        _MergeEndItemSetImpl(className, FALSE, className, endItemsSet, mfail)
#define MergeEndItemSetImplAtParent(_class, className, endItemsSet, mfail) \
        _MergeEndItemSetImpl(_class, TRUE, className, endItemsSet, mfail)

#define MergeEndItemUsageImpl(className, completeReportSet, mfail) \
        _MergeEndItemUsageImpl(className, FALSE, className, completeReportSet, mfail)
#define MergeEndItemUsageImplAtParent(_class, className, completeReportSet, mfail) \
        _MergeEndItemUsageImpl(_class, TRUE, className, completeReportSet, mfail)

#define MigrateViewNetwork(thisObj, mfail) \
        _MigrateViewNetworkAtClass(NULL, FALSE, thisObj, mfail)
#define MigrateViewNetworkAtClass(class, thisObj, mfail) \
        _MigrateViewNetworkAtClass(class, FALSE, thisObj, mfail)
#define MigrateViewNetworkAtParent(class, thisObj, mfail) \
        _MigrateViewNetworkAtClass(class, TRUE, thisObj, mfail)

#define PERevRevDb(className, action, mfail) \
        _PERevRevDb(className, FALSE, className, action, mfail)
#define PERevRevDbAtParent(_class, className, action, mfail) \
        _PERevRevDb(_class, TRUE, className, action, mfail)

#define Prepare(thisObj, mfail) \
        _PrepareAtClass(NULL, FALSE, thisObj, mfail)
#define PrepareAtClass(class, thisObj, mfail) \
        _PrepareAtClass(class, FALSE, thisObj, mfail)
#define PrepareAtParent(class, thisObj, mfail) \
        _PrepareAtClass(class, TRUE, thisObj, mfail)

#define PrepareDP(thisObj, mfail) \
        _PrepareDPAtClass(NULL, FALSE, thisObj, mfail)
#define PrepareDPAtClass(class, thisObj, mfail) \
        _PrepareDPAtClass(class, FALSE, thisObj, mfail)
#define PrepareDPAtParent(class, thisObj, mfail) \
        _PrepareDPAtClass(class, TRUE, thisObj, mfail)

#define PrepareDisplayQtys(thisObj, variantObj, mfail) \
        _PrepareDisplayQtysAtClass(NULL, FALSE, thisObj, variantObj, mfail)
#define PrepareDisplayQtysAtClass(class, thisObj, variantObj, mfail) \
        _PrepareDisplayQtysAtClass(class, FALSE, thisObj, variantObj, mfail)
#define PrepareDisplayQtysAtParent(class, thisObj, variantObj, mfail) \
        _PrepareDisplayQtysAtClass(class, TRUE, thisObj, variantObj, mfail)

#define ProcERORelForAsgnToVew(thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcERORelForAsgnToVewAtClass(NULL, FALSE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)
#define ProcERORelForAsgnToVewAtClass(class, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcERORelForAsgnToVewAtClass(class, FALSE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)
#define ProcERORelForAsgnToVewAtParent(class, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcERORelForAsgnToVewAtClass(class, TRUE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)

#define ProcEffRelsForCntxt(className, contextObj, relObjSet, mfail) \
        _ProcEffRelsForCntxt(className, FALSE, className, contextObj, relObjSet, mfail)
#define ProcEffRelsForCntxtAtParent(_class, className, contextObj, relObjSet, mfail) \
        _ProcEffRelsForCntxt(_class, TRUE, className, contextObj, relObjSet, mfail)

#define ProcExpForCfgItems(className, variantObj, relationship, relObjs, mfail) \
        _ProcExpForCfgItems(className, FALSE, className, variantObj, relationship, relObjs, mfail)
#define ProcExpForCfgItemsAtParent(_class, className, variantObj, relationship, relObjs, mfail) \
        _ProcExpForCfgItems(_class, TRUE, className, variantObj, relationship, relObjs, mfail)

#define ProcExpForRevEffs(className, itemObjSet, variantObj, relationship, relObjSet, mfail) \
        _ProcExpForRevEffs(className, FALSE, className, itemObjSet, variantObj, relationship, relObjSet, mfail)
#define ProcExpForRevEffsAtParent(_class, className, itemObjSet, variantObj, relationship, relObjSet, mfail) \
        _ProcExpForRevEffs(_class, TRUE, className, itemObjSet, variantObj, relationship, relObjSet, mfail)

#define ProcExpForStrcEffs(className, variantObj, itemObjSet, relationship, relObjSet, mfail) \
        _ProcExpForStrcEffs(className, FALSE, className, variantObj, itemObjSet, relationship, relObjSet, mfail)
#define ProcExpForStrcEffsAtParent(_class, className, variantObj, itemObjSet, relationship, relObjSet, mfail) \
        _ProcExpForStrcEffs(_class, TRUE, className, variantObj, itemObjSet, relationship, relObjSet, mfail)

#define ProcExpForStrcOpts(className, variantObj, relObjs, mfail) \
        _ProcExpForStrcOpts(className, FALSE, className, variantObj, relObjs, mfail)
#define ProcExpForStrcOptsAtParent(_class, className, variantObj, relObjs, mfail) \
        _ProcExpForStrcOpts(_class, TRUE, className, variantObj, relObjs, mfail)

#define ProcExpForZeroQty(className, variantObj, relObjSet, mfail) \
        _ProcExpForZeroQty(className, FALSE, className, variantObj, relObjSet, mfail)
#define ProcExpForZeroQtyAtParent(_class, className, variantObj, relObjSet, mfail) \
        _ProcExpForZeroQty(_class, TRUE, className, variantObj, relObjSet, mfail)

#define ProcExpRelsObjsForCond(className, condId, relObjSet, otherSideObjSet, mfail) \
        _ProcExpRelsObjsForCond(className, FALSE, className, condId, relObjSet, otherSideObjSet, mfail)
#define ProcExpRelsObjsForCondAtParent(_class, className, condId, relObjSet, otherSideObjSet, mfail) \
        _ProcExpRelsObjsForCond(_class, TRUE, className, condId, relObjSet, otherSideObjSet, mfail)

#define ProcExtractTransform(className, obid, instIdSet, transforms, mfail) \
        _ProcExtractTransform(className, FALSE, className, obid, instIdSet, transforms, mfail)
#define ProcExtractTransformAtParent(_class, className, obid, instIdSet, transforms, mfail) \
        _ProcExtractTransform(_class, TRUE, className, obid, instIdSet, transforms, mfail)

#define ProcExtractWorkflow(object, dialogObj, mfail) \
        _ProcExtractWorkflowAtClass(NULL, FALSE, object, dialogObj, mfail)
#define ProcExtractWorkflowAtClass(class, object, dialogObj, mfail) \
        _ProcExtractWorkflowAtClass(class, FALSE, object, dialogObj, mfail)
#define ProcExtractWorkflowAtParent(class, object, dialogObj, mfail) \
        _ProcExtractWorkflowAtClass(class, TRUE, object, dialogObj, mfail)

#define ProcObjForAssignToVew(thisObj, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mrkInUse, isLocalObjUpdated, mfail) \
        _ProcObjForAssignToVewAtClass(NULL, FALSE, thisObj, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mrkInUse, isLocalObjUpdated, mfail)
#define ProcObjForAssignToVewAtClass(class, thisObj, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mrkInUse, isLocalObjUpdated, mfail) \
        _ProcObjForAssignToVewAtClass(class, FALSE, thisObj, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mrkInUse, isLocalObjUpdated, mfail)
#define ProcObjForAssignToVewAtParent(class, thisObj, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mrkInUse, isLocalObjUpdated, mfail) \
        _ProcObjForAssignToVewAtClass(class, TRUE, thisObj, curVewNtwkBitPos, newVewNtwkBitPos, strtBitPosMapSet, curVewMaskMapSet, frozVewMaskMapSet, ntwkVewMaskMapSet, mrkInUse, isLocalObjUpdated, mfail)

#define ProcOneObjForAsgnToVew(thisObj, newVewNtwkBitPos, strtBitPosMapSet, frozVewMaskMapSet, isLocalObjUpdated, mfail) \
        _ProcOneObjForAsgnToVewAtClass(NULL, FALSE, thisObj, newVewNtwkBitPos, strtBitPosMapSet, frozVewMaskMapSet, isLocalObjUpdated, mfail)
#define ProcOneObjForAsgnToVewAtClass(class, thisObj, newVewNtwkBitPos, strtBitPosMapSet, frozVewMaskMapSet, isLocalObjUpdated, mfail) \
        _ProcOneObjForAsgnToVewAtClass(class, FALSE, thisObj, newVewNtwkBitPos, strtBitPosMapSet, frozVewMaskMapSet, isLocalObjUpdated, mfail)
#define ProcOneObjForAsgnToVewAtParent(class, thisObj, newVewNtwkBitPos, strtBitPosMapSet, frozVewMaskMapSet, isLocalObjUpdated, mfail) \
        _ProcOneObjForAsgnToVewAtClass(class, TRUE, thisObj, newVewNtwkBitPos, strtBitPosMapSet, frozVewMaskMapSet, isLocalObjUpdated, mfail)

#define ProcOneRelForAsgnToVew(thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcOneRelForAsgnToVewAtClass(NULL, FALSE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)
#define ProcOneRelForAsgnToVewAtClass(class, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcOneRelForAsgnToVewAtClass(class, FALSE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)
#define ProcOneRelForAsgnToVewAtParent(class, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcOneRelForAsgnToVewAtClass(class, TRUE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)

#define ProcRelForChgCertStat(relObj, dialogObj, supplierObj, mfail) \
        _ProcRelForChgCertStatAtClass(NULL, FALSE, relObj, dialogObj, supplierObj, mfail)
#define ProcRelForChgCertStatAtClass(class, relObj, dialogObj, supplierObj, mfail) \
        _ProcRelForChgCertStatAtClass(class, FALSE, relObj, dialogObj, supplierObj, mfail)
#define ProcRelForChgCertStatAtParent(class, relObj, dialogObj, supplierObj, mfail) \
        _ProcRelForChgCertStatAtClass(class, TRUE, relObj, dialogObj, supplierObj, mfail)

#define ProcRelForChgVndStat(relObj, dialogObj, vendorObj, mfail) \
        _ProcRelForChgVndStatAtClass(NULL, FALSE, relObj, dialogObj, vendorObj, mfail)
#define ProcRelForChgVndStatAtClass(class, relObj, dialogObj, vendorObj, mfail) \
        _ProcRelForChgVndStatAtClass(class, FALSE, relObj, dialogObj, vendorObj, mfail)
#define ProcRelForChgVndStatAtParent(class, relObj, dialogObj, vendorObj, mfail) \
        _ProcRelForChgVndStatAtClass(class, TRUE, relObj, dialogObj, vendorObj, mfail)

#define ProcRelsForAssignToVew(thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcRelsForAssignToVewAtClass(NULL, FALSE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)
#define ProcRelsForAssignToVewAtClass(class, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcRelsForAssignToVewAtClass(class, FALSE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)
#define ProcRelsForAssignToVewAtParent(class, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail) \
        _ProcRelsForAssignToVewAtClass(class, TRUE, thisObj, curVewNtwkBitPos, curVewMaskMapSet, mfail)

#define ProcRelsForExpVewCntxt(className, contextObj, relationship, relObjs, mfail) \
        _ProcRelsForExpVewCntxt(className, FALSE, className, contextObj, relationship, relObjs, mfail)
#define ProcRelsForExpVewCntxtAtParent(_class, className, contextObj, relationship, relObjs, mfail) \
        _ProcRelsForExpVewCntxt(_class, TRUE, className, contextObj, relationship, relObjs, mfail)

#define ProcRelsInVewForPaging(className, contextObj, relationship, relObjs, otherSideObjs, mfail) \
        _ProcRelsInVewForPaging(className, FALSE, className, contextObj, relationship, relObjs, otherSideObjs, mfail)
#define ProcRelsInVewForPagingAtParent(_class, className, contextObj, relationship, relObjs, otherSideObjs, mfail) \
        _ProcRelsInVewForPaging(_class, TRUE, className, contextObj, relationship, relObjs, otherSideObjs, mfail)

#define ProcessBOM(thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail) \
        _ProcessBOMAtClass(NULL, FALSE, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail)
#define ProcessBOMAtClass(class, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail) \
        _ProcessBOMAtClass(class, FALSE, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail)
#define ProcessBOMAtParent(class, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail) \
        _ProcessBOMAtClass(class, TRUE, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail)

#define ProcessBOMStr(thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail) \
        _ProcessBOMStrAtClass(NULL, FALSE, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail)
#define ProcessBOMStrAtClass(class, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail) \
        _ProcessBOMStrAtClass(class, FALSE, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail)
#define ProcessBOMStrAtParent(class, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail) \
        _ProcessBOMStrAtClass(class, TRUE, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail)

#define ProcessBOMXML(thisObj, prtObjSet, relOjSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail) \
        _ProcessBOMXMLAtClass(NULL, FALSE, thisObj, prtObjSet, relOjSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail)
#define ProcessBOMXMLAtClass(class, thisObj, prtObjSet, relOjSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail) \
        _ProcessBOMXMLAtClass(class, FALSE, thisObj, prtObjSet, relOjSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail)
#define ProcessBOMXMLAtParent(class, thisObj, prtObjSet, relOjSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail) \
        _ProcessBOMXMLAtClass(class, TRUE, thisObj, prtObjSet, relOjSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail)

#define ProcessBOMXML2(thisObj, topLevelObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, auxMessages, converterClass, converterDialog, outputHandler, mfail) \
        _ProcessBOMXML2AtClass(NULL, FALSE, thisObj, topLevelObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, auxMessages, converterClass, converterDialog, outputHandler, mfail)
#define ProcessBOMXML2AtClass(class, thisObj, topLevelObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, auxMessages, converterClass, converterDialog, outputHandler, mfail) \
        _ProcessBOMXML2AtClass(class, FALSE, thisObj, topLevelObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, auxMessages, converterClass, converterDialog, outputHandler, mfail)
#define ProcessBOMXML2AtParent(class, thisObj, topLevelObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, auxMessages, converterClass, converterDialog, outputHandler, mfail) \
        _ProcessBOMXML2AtClass(class, TRUE, thisObj, topLevelObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, auxMessages, converterClass, converterDialog, outputHandler, mfail)

#define ProcessImps(thisObj, sParentPart, sCfgItemEffType, genContextObj, psContextObj, ssCfgItemId, useLatest, doDetailedReport, currentLevel, droppedObjectSet, parents, outputSet, mfail) \
        _ProcessImpsAtClass(NULL, FALSE, thisObj, sParentPart, sCfgItemEffType, genContextObj, psContextObj, ssCfgItemId, useLatest, doDetailedReport, currentLevel, droppedObjectSet, parents, outputSet, mfail)
#define ProcessImpsAtClass(class, thisObj, sParentPart, sCfgItemEffType, genContextObj, psContextObj, ssCfgItemId, useLatest, doDetailedReport, currentLevel, droppedObjectSet, parents, outputSet, mfail) \
        _ProcessImpsAtClass(class, FALSE, thisObj, sParentPart, sCfgItemEffType, genContextObj, psContextObj, ssCfgItemId, useLatest, doDetailedReport, currentLevel, droppedObjectSet, parents, outputSet, mfail)
#define ProcessImpsAtParent(class, thisObj, sParentPart, sCfgItemEffType, genContextObj, psContextObj, ssCfgItemId, useLatest, doDetailedReport, currentLevel, droppedObjectSet, parents, outputSet, mfail) \
        _ProcessImpsAtClass(class, TRUE, thisObj, sParentPart, sCfgItemEffType, genContextObj, psContextObj, ssCfgItemId, useLatest, doDetailedReport, currentLevel, droppedObjectSet, parents, outputSet, mfail)

#define ProcessRecDec(thisObj, asmPath, recFound, dialogObj, itemObjs, relObjs, host, usr, fullPath, mfail) \
        _ProcessRecDecAtClass(NULL, FALSE, thisObj, asmPath, recFound, dialogObj, itemObjs, relObjs, host, usr, fullPath, mfail)
#define ProcessRecDecAtClass(class, thisObj, asmPath, recFound, dialogObj, itemObjs, relObjs, host, usr, fullPath, mfail) \
        _ProcessRecDecAtClass(class, FALSE, thisObj, asmPath, recFound, dialogObj, itemObjs, relObjs, host, usr, fullPath, mfail)
#define ProcessRecDecAtParent(class, thisObj, asmPath, recFound, dialogObj, itemObjs, relObjs, host, usr, fullPath, mfail) \
        _ProcessRecDecAtClass(class, TRUE, thisObj, asmPath, recFound, dialogObj, itemObjs, relObjs, host, usr, fullPath, mfail)

#define ProcessRecDecStr(thisObj, inpSet, asmPath, recFound, dialogObj, itemObjs, relObjs, mfail) \
        _ProcessRecDecStrAtClass(NULL, FALSE, thisObj, inpSet, asmPath, recFound, dialogObj, itemObjs, relObjs, mfail)
#define ProcessRecDecStrAtClass(class, thisObj, inpSet, asmPath, recFound, dialogObj, itemObjs, relObjs, mfail) \
        _ProcessRecDecStrAtClass(class, FALSE, thisObj, inpSet, asmPath, recFound, dialogObj, itemObjs, relObjs, mfail)
#define ProcessRecDecStrAtParent(class, thisObj, inpSet, asmPath, recFound, dialogObj, itemObjs, relObjs, mfail) \
        _ProcessRecDecStrAtClass(class, TRUE, thisObj, inpSet, asmPath, recFound, dialogObj, itemObjs, relObjs, mfail)

#define ProcessRecDecXML(thisObj, prtObjSet, relOjSet, relPath, recFound, dialogObj, itemObjs, relObjs, firstLevel, mfail) \
        _ProcessRecDecXMLAtClass(NULL, FALSE, thisObj, prtObjSet, relOjSet, relPath, recFound, dialogObj, itemObjs, relObjs, firstLevel, mfail)
#define ProcessRecDecXMLAtClass(class, thisObj, prtObjSet, relOjSet, relPath, recFound, dialogObj, itemObjs, relObjs, firstLevel, mfail) \
        _ProcessRecDecXMLAtClass(class, FALSE, thisObj, prtObjSet, relOjSet, relPath, recFound, dialogObj, itemObjs, relObjs, firstLevel, mfail)
#define ProcessRecDecXMLAtParent(class, thisObj, prtObjSet, relOjSet, relPath, recFound, dialogObj, itemObjs, relObjs, firstLevel, mfail) \
        _ProcessRecDecXMLAtClass(class, TRUE, thisObj, prtObjSet, relOjSet, relPath, recFound, dialogObj, itemObjs, relObjs, firstLevel, mfail)

#define ProcessWusd(thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail) \
        _ProcessWusdAtClass(NULL, FALSE, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail)
#define ProcessWusdAtClass(class, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail) \
        _ProcessWusdAtClass(class, FALSE, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail)
#define ProcessWusdAtParent(class, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail) \
        _ProcessWusdAtClass(class, TRUE, thisObj, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, host, usr, fullPath, mfail)

#define ProcessWusdStr(thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail) \
        _ProcessWusdStrAtClass(NULL, FALSE, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail)
#define ProcessWusdStrAtClass(class, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail) \
        _ProcessWusdStrAtClass(class, FALSE, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail)
#define ProcessWusdStrAtParent(class, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail) \
        _ProcessWusdStrAtClass(class, TRUE, thisObj, inpSet, asmPath, dialogObj, itemObjs, relObjs, maxLevel, level, offst, mfail)

#define ProcessWusdXML(thisObj, prtObjSet, relOjSet, itemPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail) \
        _ProcessWusdXMLAtClass(NULL, FALSE, thisObj, prtObjSet, relOjSet, itemPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail)
#define ProcessWusdXMLAtClass(class, thisObj, prtObjSet, relOjSet, itemPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail) \
        _ProcessWusdXMLAtClass(class, FALSE, thisObj, prtObjSet, relOjSet, itemPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail)
#define ProcessWusdXMLAtParent(class, thisObj, prtObjSet, relOjSet, itemPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail) \
        _ProcessWusdXMLAtClass(class, TRUE, thisObj, prtObjSet, relOjSet, itemPath, dialogObj, itemObjs, relObjs, maxLevel, level, mfail)

#define PropagateAbsoluteOcc(sourceFactory, destFactory, mfail) \
        _PropagateAbsoluteOccAtClass(NULL, FALSE, sourceFactory, destFactory, mfail)
#define PropagateAbsoluteOccAtClass(class, sourceFactory, destFactory, mfail) \
        _PropagateAbsoluteOccAtClass(class, FALSE, sourceFactory, destFactory, mfail)
#define PropagateAbsoluteOccAtParent(class, sourceFactory, destFactory, mfail) \
        _PropagateAbsoluteOccAtClass(class, TRUE, sourceFactory, destFactory, mfail)

#define PropagateOccurrences(sourceObj, destObj, copyRelativeOcc, copyAbsoluteOcc, mfail) \
        _PropagateOccurrencesAtClass(NULL, FALSE, sourceObj, destObj, copyRelativeOcc, copyAbsoluteOcc, mfail)
#define PropagateOccurrencesAtClass(class, sourceObj, destObj, copyRelativeOcc, copyAbsoluteOcc, mfail) \
        _PropagateOccurrencesAtClass(class, FALSE, sourceObj, destObj, copyRelativeOcc, copyAbsoluteOcc, mfail)
#define PropagateOccurrencesAtParent(class, sourceObj, destObj, copyRelativeOcc, copyAbsoluteOcc, mfail) \
        _PropagateOccurrencesAtClass(class, TRUE, sourceObj, destObj, copyRelativeOcc, copyAbsoluteOcc, mfail)

#define PropagateRelativeOcc(oldRelObj, newRelObj, newOccFactory, otherSideFactoryObj, mfail) \
        _PropagateRelativeOccAtClass(NULL, FALSE, oldRelObj, newRelObj, newOccFactory, otherSideFactoryObj, mfail)
#define PropagateRelativeOccAtClass(class, oldRelObj, newRelObj, newOccFactory, otherSideFactoryObj, mfail) \
        _PropagateRelativeOccAtClass(class, FALSE, oldRelObj, newRelObj, newOccFactory, otherSideFactoryObj, mfail)
#define PropagateRelativeOccAtParent(class, oldRelObj, newRelObj, newOccFactory, otherSideFactoryObj, mfail) \
        _PropagateRelativeOccAtClass(class, TRUE, oldRelObj, newRelObj, newOccFactory, otherSideFactoryObj, mfail)

#define PropagateStrcEffForILV(className, oldStrcRelObjs, newStrcRelObjs, vewObj, mfail) \
        _PropagateStrcEffForILV(className, FALSE, className, oldStrcRelObjs, newStrcRelObjs, vewObj, mfail)
#define PropagateStrcEffForILVAtParent(_class, className, oldStrcRelObjs, newStrcRelObjs, vewObj, mfail) \
        _PropagateStrcEffForILV(_class, TRUE, className, oldStrcRelObjs, newStrcRelObjs, vewObj, mfail)

#define PropagateStrcEffForSBM(className, newStrcRels, strcEffRels, vewObj, mfail) \
        _PropagateStrcEffForSBM(className, FALSE, className, newStrcRels, strcEffRels, vewObj, mfail)
#define PropagateStrcEffForSBMAtParent(_class, className, newStrcRels, strcEffRels, vewObj, mfail) \
        _PropagateStrcEffForSBM(_class, TRUE, className, newStrcRels, strcEffRels, vewObj, mfail)

#define QueryCfgItemIdsImpl(dialogObj, cfgItemIdStrSet, cfgItemEffType, mfail) \
        _QueryCfgItemIdsImplAtClass(NULL, FALSE, dialogObj, cfgItemIdStrSet, cfgItemEffType, mfail)
#define QueryCfgItemIdsImplAtClass(class, dialogObj, cfgItemIdStrSet, cfgItemEffType, mfail) \
        _QueryCfgItemIdsImplAtClass(class, FALSE, dialogObj, cfgItemIdStrSet, cfgItemEffType, mfail)
#define QueryCfgItemIdsImplAtParent(class, dialogObj, cfgItemIdStrSet, cfgItemEffType, mfail) \
        _QueryCfgItemIdsImplAtClass(class, TRUE, dialogObj, cfgItemIdStrSet, cfgItemEffType, mfail)

#define QueryMatchStrucApcs(thisObj, matchingFindNumber, matchingViewMask, matchingStrucApcs, mfail) \
        _QueryMatchStrucApcsAtClass(NULL, FALSE, thisObj, matchingFindNumber, matchingViewMask, matchingStrucApcs, mfail)
#define QueryMatchStrucApcsAtClass(class, thisObj, matchingFindNumber, matchingViewMask, matchingStrucApcs, mfail) \
        _QueryMatchStrucApcsAtClass(class, FALSE, thisObj, matchingFindNumber, matchingViewMask, matchingStrucApcs, mfail)
#define QueryMatchStrucApcsAtParent(class, thisObj, matchingFindNumber, matchingViewMask, matchingStrucApcs, mfail) \
        _QueryMatchStrucApcsAtClass(class, TRUE, thisObj, matchingFindNumber, matchingViewMask, matchingStrucApcs, mfail)

#define QueryPartEffsImpl(thisObj, genContextObj, cfgItemIdStrSet, otherSideObjSet, partEffObjSet, mfail) \
        _QueryPartEffsImplAtClass(NULL, FALSE, thisObj, genContextObj, cfgItemIdStrSet, otherSideObjSet, partEffObjSet, mfail)
#define QueryPartEffsImplAtClass(class, thisObj, genContextObj, cfgItemIdStrSet, otherSideObjSet, partEffObjSet, mfail) \
        _QueryPartEffsImplAtClass(class, FALSE, thisObj, genContextObj, cfgItemIdStrSet, otherSideObjSet, partEffObjSet, mfail)
#define QueryPartEffsImplAtParent(class, thisObj, genContextObj, cfgItemIdStrSet, otherSideObjSet, partEffObjSet, mfail) \
        _QueryPartEffsImplAtClass(class, TRUE, thisObj, genContextObj, cfgItemIdStrSet, otherSideObjSet, partEffObjSet, mfail)

#define QueryRevEffsImpl(thisObj, cfgItemIdStrSet, useCustom, revEffObjSet, mfail) \
        _QueryRevEffsImplAtClass(NULL, FALSE, thisObj, cfgItemIdStrSet, useCustom, revEffObjSet, mfail)
#define QueryRevEffsImplAtClass(class, thisObj, cfgItemIdStrSet, useCustom, revEffObjSet, mfail) \
        _QueryRevEffsImplAtClass(class, FALSE, thisObj, cfgItemIdStrSet, useCustom, revEffObjSet, mfail)
#define QueryRevEffsImplAtParent(class, thisObj, cfgItemIdStrSet, useCustom, revEffObjSet, mfail) \
        _QueryRevEffsImplAtClass(class, TRUE, thisObj, cfgItemIdStrSet, useCustom, revEffObjSet, mfail)

#define RefreshItForApc(thisObj, mfail) \
        _RefreshItForApcAtClass(NULL, FALSE, thisObj, mfail)
#define RefreshItForApcAtClass(class, thisObj, mfail) \
        _RefreshItForApcAtClass(class, FALSE, thisObj, mfail)
#define RefreshItForApcAtParent(class, thisObj, mfail) \
        _RefreshItForApcAtClass(class, TRUE, thisObj, mfail)

#define RelateRevEffectivity(thisObj, mfail) \
        _RelateRevEffectivityAtClass(NULL, FALSE, thisObj, mfail)
#define RelateRevEffectivityAtClass(class, thisObj, mfail) \
        _RelateRevEffectivityAtClass(class, FALSE, thisObj, mfail)
#define RelateRevEffectivityAtParent(class, thisObj, mfail) \
        _RelateRevEffectivityAtClass(class, TRUE, thisObj, mfail)

#define RelateStrcEffectivity(thisObj, mfail) \
        _RelateStrcEffectivityAtClass(NULL, FALSE, thisObj, mfail)
#define RelateStrcEffectivityAtClass(class, thisObj, mfail) \
        _RelateStrcEffectivityAtClass(class, FALSE, thisObj, mfail)
#define RelateStrcEffectivityAtParent(class, thisObj, mfail) \
        _RelateStrcEffectivityAtClass(class, TRUE, thisObj, mfail)

#define RelateStrucEff(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateStrucEffAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define RelateStrucEffAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateStrucEffAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define RelateStrucEffAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateStrucEffAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define RelateStrucOption(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateStrucOptionAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define RelateStrucOptionAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateStrucOptionAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define RelateStrucOptionAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateStrucOptionAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define RelateSubPart(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateSubPartAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define RelateSubPartAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateSubPartAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define RelateSubPartAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _RelateSubPartAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define RemoveOneObjFromVewNet(thisObj, ntwkVewMaskMapSet, isLocalObjUpdated, mfail) \
        _RemoveOneObjFromVewNetAtClass(NULL, FALSE, thisObj, ntwkVewMaskMapSet, isLocalObjUpdated, mfail)
#define RemoveOneObjFromVewNetAtClass(class, thisObj, ntwkVewMaskMapSet, isLocalObjUpdated, mfail) \
        _RemoveOneObjFromVewNetAtClass(class, FALSE, thisObj, ntwkVewMaskMapSet, isLocalObjUpdated, mfail)
#define RemoveOneObjFromVewNetAtParent(class, thisObj, ntwkVewMaskMapSet, isLocalObjUpdated, mfail) \
        _RemoveOneObjFromVewNetAtClass(class, TRUE, thisObj, ntwkVewMaskMapSet, isLocalObjUpdated, mfail)

#define RemoveOneRelFromVewNet(thisObj, curVewNtwkBitPos, ntwkVewMaskMapSet, mfail) \
        _RemoveOneRelFromVewNetAtClass(NULL, FALSE, thisObj, curVewNtwkBitPos, ntwkVewMaskMapSet, mfail)
#define RemoveOneRelFromVewNetAtClass(class, thisObj, curVewNtwkBitPos, ntwkVewMaskMapSet, mfail) \
        _RemoveOneRelFromVewNetAtClass(class, FALSE, thisObj, curVewNtwkBitPos, ntwkVewMaskMapSet, mfail)
#define RemoveOneRelFromVewNetAtParent(class, thisObj, curVewNtwkBitPos, ntwkVewMaskMapSet, mfail) \
        _RemoveOneRelFromVewNetAtClass(class, TRUE, thisObj, curVewNtwkBitPos, ntwkVewMaskMapSet, mfail)

#define RemoveRelsFromVewNet(thisObj, ntwkVewMaskMapSet, mfail) \
        _RemoveRelsFromVewNetAtClass(NULL, FALSE, thisObj, ntwkVewMaskMapSet, mfail)
#define RemoveRelsFromVewNetAtClass(class, thisObj, ntwkVewMaskMapSet, mfail) \
        _RemoveRelsFromVewNetAtClass(class, FALSE, thisObj, ntwkVewMaskMapSet, mfail)
#define RemoveRelsFromVewNetAtParent(class, thisObj, ntwkVewMaskMapSet, mfail) \
        _RemoveRelsFromVewNetAtClass(class, TRUE, thisObj, ntwkVewMaskMapSet, mfail)

#define RemoveVewNtwkInfo(thisObj, mfail) \
        _RemoveVewNtwkInfoAtClass(NULL, FALSE, thisObj, mfail)
#define RemoveVewNtwkInfoAtClass(class, thisObj, mfail) \
        _RemoveVewNtwkInfoAtClass(class, FALSE, thisObj, mfail)
#define RemoveVewNtwkInfoAtParent(class, thisObj, mfail) \
        _RemoveVewNtwkInfoAtClass(class, TRUE, thisObj, mfail)

#define ReplacePart(replaceThis, replaceWith, affectedAssms, vewObj, mfail) \
        _ReplacePartAtClass(NULL, FALSE, replaceThis, replaceWith, affectedAssms, vewObj, mfail)
#define ReplacePartAtClass(class, replaceThis, replaceWith, affectedAssms, vewObj, mfail) \
        _ReplacePartAtClass(class, FALSE, replaceThis, replaceWith, affectedAssms, vewObj, mfail)
#define ReplacePartAtParent(class, replaceThis, replaceWith, affectedAssms, vewObj, mfail) \
        _ReplacePartAtClass(class, TRUE, replaceThis, replaceWith, affectedAssms, vewObj, mfail)

#define RetrieveViewIdList(thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail) \
        _RetrieveViewIdListAtClass(NULL, FALSE, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail)
#define RetrieveViewIdListAtClass(class, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail) \
        _RetrieveViewIdListAtClass(class, FALSE, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail)
#define RetrieveViewIdListAtParent(class, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail) \
        _RetrieveViewIdListAtClass(class, TRUE, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail)

#define RetrieveViewIdListPost(thisObj, eligibleViewIdList, mfail) \
        _RetrieveViewIdListPostAtClass(NULL, FALSE, thisObj, eligibleViewIdList, mfail)
#define RetrieveViewIdListPostAtClass(class, thisObj, eligibleViewIdList, mfail) \
        _RetrieveViewIdListPostAtClass(class, FALSE, thisObj, eligibleViewIdList, mfail)
#define RetrieveViewIdListPostAtParent(class, thisObj, eligibleViewIdList, mfail) \
        _RetrieveViewIdListPostAtClass(class, TRUE, thisObj, eligibleViewIdList, mfail)

#define RetrieveViewIdListRule(thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail) \
        _RetrieveViewIdListRuleAtClass(NULL, FALSE, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail)
#define RetrieveViewIdListRuleAtClass(class, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail) \
        _RetrieveViewIdListRuleAtClass(class, FALSE, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail)
#define RetrieveViewIdListRuleAtParent(class, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail) \
        _RetrieveViewIdListRuleAtClass(class, TRUE, thisObj, ruleMsg, eligibleViewType, eligibleViewIdList, mfail)

#define RetrieveWorkingView(thisObj, ruleMsg, eligibleViewType, forceDialog, cancel, mfail) \
        _RetrieveWorkingViewAtClass(NULL, FALSE, thisObj, ruleMsg, eligibleViewType, forceDialog, cancel, mfail)
#define RetrieveWorkingViewAtClass(class, thisObj, ruleMsg, eligibleViewType, forceDialog, cancel, mfail) \
        _RetrieveWorkingViewAtClass(class, FALSE, thisObj, ruleMsg, eligibleViewType, forceDialog, cancel, mfail)
#define RetrieveWorkingViewAtParent(class, thisObj, ruleMsg, eligibleViewType, forceDialog, cancel, mfail) \
        _RetrieveWorkingViewAtClass(class, TRUE, thisObj, ruleMsg, eligibleViewType, forceDialog, cancel, mfail)

#define RetrieveWorkingViewObj(thisObj, ruleMsg, eligibleViewType, vewObj, mfail) \
        _RetrieveWorkingViewObjAtClass(NULL, FALSE, thisObj, ruleMsg, eligibleViewType, vewObj, mfail)
#define RetrieveWorkingViewObjAtClass(class, thisObj, ruleMsg, eligibleViewType, vewObj, mfail) \
        _RetrieveWorkingViewObjAtClass(class, FALSE, thisObj, ruleMsg, eligibleViewType, vewObj, mfail)
#define RetrieveWorkingViewObjAtParent(class, thisObj, ruleMsg, eligibleViewType, vewObj, mfail) \
        _RetrieveWorkingViewObjAtClass(class, TRUE, thisObj, ruleMsg, eligibleViewType, vewObj, mfail)

#define SaveRevisionOfStrucBI(className, itemObj, mfail) \
        _SaveRevisionOfStrucBI(className, FALSE, className, itemObj, mfail)
#define SaveRevisionOfStrucBIAtParent(_class, className, itemObj, mfail) \
        _SaveRevisionOfStrucBI(_class, TRUE, className, itemObj, mfail)

#define SendAuxViewDepRelCopy(thisObj, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail) \
        _SendAuxViewDepRelCopyAtClass(NULL, FALSE, thisObj, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail)
#define SendAuxViewDepRelCopyAtClass(class, thisObj, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail) \
        _SendAuxViewDepRelCopyAtClass(class, FALSE, thisObj, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail)
#define SendAuxViewDepRelCopyAtParent(class, thisObj, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail) \
        _SendAuxViewDepRelCopyAtClass(class, TRUE, thisObj, strBIApcObj, itemMstrObj, oldFindNumber, newFindNumber, affectedViewMask, mfail)

#define SendAuxViewDepRelDel(thisObj, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail) \
        _SendAuxViewDepRelDelAtClass(NULL, FALSE, thisObj, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail)
#define SendAuxViewDepRelDelAtClass(class, thisObj, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail) \
        _SendAuxViewDepRelDelAtClass(class, FALSE, thisObj, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail)
#define SendAuxViewDepRelDelAtParent(class, thisObj, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail) \
        _SendAuxViewDepRelDelAtClass(class, TRUE, thisObj, strBIApcObj, itemMstrObj, deletedFindNumber, affectedViewMask, mfail)

#define SetCfgItemCreateDialog(thisObj, dialogObj, mfail) \
        _SetCfgItemCreateDialogAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define SetCfgItemCreateDialogAtClass(class, thisObj, dialogObj, mfail) \
        _SetCfgItemCreateDialogAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define SetCfgItemCreateDialogAtParent(class, thisObj, dialogObj, mfail) \
        _SetCfgItemCreateDialogAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define SetEffDateInCtxt(className, genContextObj, configIdPref, effDatePref, mfail) \
        _SetEffDateInCtxt(className, FALSE, className, genContextObj, configIdPref, effDatePref, mfail)
#define SetEffDateInCtxtAtParent(_class, className, genContextObj, configIdPref, effDatePref, mfail) \
        _SetEffDateInCtxt(_class, TRUE, className, genContextObj, configIdPref, effDatePref, mfail)

#define SetEffUnitInCtxt(className, genContextObj, configIdPref, effUnitPref, mfail) \
        _SetEffUnitInCtxt(className, FALSE, className, genContextObj, configIdPref, effUnitPref, mfail)
#define SetEffUnitInCtxtAtParent(_class, className, genContextObj, configIdPref, effUnitPref, mfail) \
        _SetEffUnitInCtxt(_class, TRUE, className, genContextObj, configIdPref, effUnitPref, mfail)

#define SetEffectivityPref(thisObj, global, cfgItemId, effectiveDate, effectiveUnit, mfail) \
        _SetEffectivityPrefAtClass(NULL, FALSE, thisObj, global, cfgItemId, effectiveDate, effectiveUnit, mfail)
#define SetEffectivityPrefAtClass(class, thisObj, global, cfgItemId, effectiveDate, effectiveUnit, mfail) \
        _SetEffectivityPrefAtClass(class, FALSE, thisObj, global, cfgItemId, effectiveDate, effectiveUnit, mfail)
#define SetEffectivityPrefAtParent(class, thisObj, global, cfgItemId, effectiveDate, effectiveUnit, mfail) \
        _SetEffectivityPrefAtClass(class, TRUE, thisObj, global, cfgItemId, effectiveDate, effectiveUnit, mfail)

#define SetEffectivityPrefP(thisObj, mfail) \
        _SetEffectivityPrefPAtClass(NULL, FALSE, thisObj, mfail)
#define SetEffectivityPrefPAtClass(class, thisObj, mfail) \
        _SetEffectivityPrefPAtClass(class, FALSE, thisObj, mfail)
#define SetEffectivityPrefPAtParent(class, thisObj, mfail) \
        _SetEffectivityPrefPAtClass(class, TRUE, thisObj, mfail)

#define SetEndItemRevsImpl(className, outputSet, mfail) \
        _SetEndItemRevsImpl(className, FALSE, className, outputSet, mfail)
#define SetEndItemRevsImplAtParent(_class, className, outputSet, mfail) \
        _SetEndItemRevsImpl(_class, TRUE, className, outputSet, mfail)

#define SetEndItemUsageImpl(className, usageEffObjSet, mfail) \
        _SetEndItemUsageImpl(className, FALSE, className, usageEffObjSet, mfail)
#define SetEndItemUsageImplAtParent(_class, className, usageEffObjSet, mfail) \
        _SetEndItemUsageImpl(_class, TRUE, className, usageEffObjSet, mfail)

#define SetFirstLevelUsageImpl(className, completeReportSet, mfail) \
        _SetFirstLevelUsageImpl(className, FALSE, className, completeReportSet, mfail)
#define SetFirstLevelUsageImplAtParent(_class, className, completeReportSet, mfail) \
        _SetFirstLevelUsageImpl(_class, TRUE, className, completeReportSet, mfail)

#define SetIncZeroQtyInCtxt(className, genContextObj, includeZeroQty, mfail) \
        _SetIncZeroQtyInCtxt(className, FALSE, className, genContextObj, includeZeroQty, mfail)
#define SetIncZeroQtyInCtxtAtParent(_class, className, genContextObj, includeZeroQty, mfail) \
        _SetIncZeroQtyInCtxt(_class, TRUE, className, genContextObj, includeZeroQty, mfail)

#define SetIncludeZeroQtyPref(thisObj, global, value, mfail) \
        _SetIncludeZeroQtyPrefAtClass(NULL, FALSE, thisObj, global, value, mfail)
#define SetIncludeZeroQtyPrefAtClass(class, thisObj, global, value, mfail) \
        _SetIncludeZeroQtyPrefAtClass(class, FALSE, thisObj, global, value, mfail)
#define SetIncludeZeroQtyPrefAtParent(class, thisObj, global, value, mfail) \
        _SetIncludeZeroQtyPrefAtClass(class, TRUE, thisObj, global, value, mfail)

#define SetMergeRevUsageImpl(className, rptSet, mfail) \
        _SetMergeRevUsageImpl(className, FALSE, className, rptSet, mfail)
#define SetMergeRevUsageImplAtParent(_class, className, rptSet, mfail) \
        _SetMergeRevUsageImpl(_class, TRUE, className, rptSet, mfail)

#define SetNavViewInCtxt(className, genContextObj, viewNetworkPref, viewNamePref, mfail) \
        _SetNavViewInCtxt(className, FALSE, className, genContextObj, viewNetworkPref, viewNamePref, mfail)
#define SetNavViewInCtxtAtParent(_class, className, genContextObj, viewNetworkPref, viewNamePref, mfail) \
        _SetNavViewInCtxt(_class, TRUE, className, genContextObj, viewNetworkPref, viewNamePref, mfail)

#define SetNavigateViewPref(thisObj, global, network, name, mfail) \
        _SetNavigateViewPrefAtClass(NULL, FALSE, thisObj, global, network, name, mfail)
#define SetNavigateViewPrefAtClass(class, thisObj, global, network, name, mfail) \
        _SetNavigateViewPrefAtClass(class, FALSE, thisObj, global, network, name, mfail)
#define SetNavigateViewPrefAtParent(class, thisObj, global, network, name, mfail) \
        _SetNavigateViewPrefAtClass(class, TRUE, thisObj, global, network, name, mfail)

#define SetNavigateViewPrefP(thisObj, mfail) \
        _SetNavigateViewPrefPAtClass(NULL, FALSE, thisObj, mfail)
#define SetNavigateViewPrefPAtClass(class, thisObj, mfail) \
        _SetNavigateViewPrefPAtClass(class, FALSE, thisObj, mfail)
#define SetNavigateViewPrefPAtParent(class, thisObj, mfail) \
        _SetNavigateViewPrefPAtClass(class, TRUE, thisObj, mfail)

#define SetReportStandardImpl(className, completeReportSet, outputSet, mfail) \
        _SetReportStandardImpl(className, FALSE, className, completeReportSet, outputSet, mfail)
#define SetReportStandardImplAtParent(_class, className, completeReportSet, outputSet, mfail) \
        _SetReportStandardImpl(_class, TRUE, className, completeReportSet, outputSet, mfail)

#define SetRptFromPartEffsImpl(className, thisObj, sParentPart, cfgItemEffType, cfgItemIdStrSet, partEffObjSet, doDetailedReport, currentLevel, usageEffObjSet, mfail) \
        _SetRptFromPartEffsImpl(className, FALSE, className, thisObj, sParentPart, cfgItemEffType, cfgItemIdStrSet, partEffObjSet, doDetailedReport, currentLevel, usageEffObjSet, mfail)
#define SetRptFromPartEffsImplAtParent(_class, className, thisObj, sParentPart, cfgItemEffType, cfgItemIdStrSet, partEffObjSet, doDetailedReport, currentLevel, usageEffObjSet, mfail) \
        _SetRptFromPartEffsImpl(_class, TRUE, className, thisObj, sParentPart, cfgItemEffType, cfgItemIdStrSet, partEffObjSet, doDetailedReport, currentLevel, usageEffObjSet, mfail)

#define SetStrcOptListInCtxt(className, genContextObj, strcOptListPref, mfail) \
        _SetStrcOptListInCtxt(className, FALSE, className, genContextObj, strcOptListPref, mfail)
#define SetStrcOptListInCtxtAtParent(_class, className, genContextObj, strcOptListPref, mfail) \
        _SetStrcOptListInCtxt(_class, TRUE, className, genContextObj, strcOptListPref, mfail)

#define SetStrcOptListPref(thisObj, global, optionList, mfail) \
        _SetStrcOptListPrefAtClass(NULL, FALSE, thisObj, global, optionList, mfail)
#define SetStrcOptListPrefAtClass(class, thisObj, global, optionList, mfail) \
        _SetStrcOptListPrefAtClass(class, FALSE, thisObj, global, optionList, mfail)
#define SetStrcOptListPrefAtParent(class, thisObj, global, optionList, mfail) \
        _SetStrcOptListPrefAtClass(class, TRUE, thisObj, global, optionList, mfail)

#define SetStrcOptListPrefP(thisObj, mfail) \
        _SetStrcOptListPrefPAtClass(NULL, FALSE, thisObj, mfail)
#define SetStrcOptListPrefPAtClass(class, thisObj, mfail) \
        _SetStrcOptListPrefPAtClass(class, FALSE, thisObj, mfail)
#define SetStrcOptListPrefPAtParent(class, thisObj, mfail) \
        _SetStrcOptListPrefPAtClass(class, TRUE, thisObj, mfail)

#define SetStructureOption(thisObj, strcOptObj, vewObj, dialogObj, mfail) \
        _SetStructureOptionAtClass(NULL, FALSE, thisObj, strcOptObj, vewObj, dialogObj, mfail)
#define SetStructureOptionAtClass(class, thisObj, strcOptObj, vewObj, dialogObj, mfail) \
        _SetStructureOptionAtClass(class, FALSE, thisObj, strcOptObj, vewObj, dialogObj, mfail)
#define SetStructureOptionAtParent(class, thisObj, strcOptObj, vewObj, dialogObj, mfail) \
        _SetStructureOptionAtClass(class, TRUE, thisObj, strcOptObj, vewObj, dialogObj, mfail)

#define SetStructureOptionInt(thisObj, strcOptObj, vewObj, dialogObj, isUpdateDialog, strcOptRel, mfail) \
        _SetStructureOptionIntAtClass(NULL, FALSE, thisObj, strcOptObj, vewObj, dialogObj, isUpdateDialog, strcOptRel, mfail)
#define SetStructureOptionIntAtClass(class, thisObj, strcOptObj, vewObj, dialogObj, isUpdateDialog, strcOptRel, mfail) \
        _SetStructureOptionIntAtClass(class, FALSE, thisObj, strcOptObj, vewObj, dialogObj, isUpdateDialog, strcOptRel, mfail)
#define SetStructureOptionIntAtParent(class, thisObj, strcOptObj, vewObj, dialogObj, isUpdateDialog, strcOptRel, mfail) \
        _SetStructureOptionIntAtClass(class, TRUE, thisObj, strcOptObj, vewObj, dialogObj, isUpdateDialog, strcOptRel, mfail)

#define SetStyTblDfltsForUpd(thisObj, originClassName, originObject, mfail) \
        _SetStyTblDfltsForUpdAtClass(NULL, FALSE, thisObj, originClassName, originObject, mfail)
#define SetStyTblDfltsForUpdAtClass(class, thisObj, originClassName, originObject, mfail) \
        _SetStyTblDfltsForUpdAtClass(class, FALSE, thisObj, originClassName, originObject, mfail)
#define SetStyTblDfltsForUpdAtParent(class, thisObj, originClassName, originObject, mfail) \
        _SetStyTblDfltsForUpdAtClass(class, TRUE, thisObj, originClassName, originObject, mfail)

#define SetSvcTypeTblDefaults(thisObj, originObject, mfail) \
        _SetSvcTypeTblDefaultsAtClass(NULL, FALSE, thisObj, originObject, mfail)
#define SetSvcTypeTblDefaultsAtClass(class, thisObj, originObject, mfail) \
        _SetSvcTypeTblDefaultsAtClass(class, FALSE, thisObj, originObject, mfail)
#define SetSvcTypeTblDefaultsAtParent(class, thisObj, originObject, mfail) \
        _SetSvcTypeTblDefaultsAtClass(class, TRUE, thisObj, originObject, mfail)

#define SetUpRelCreateDlgWithSeedDlg(relClassName, seedDlg, leftObj, rightObj, newDlg, mfail) \
        _SetUpRelCreateDlgWithSeedDlg(relClassName, FALSE, relClassName, seedDlg, leftObj, rightObj, newDlg, mfail)
#define SetUpRelCreateDlgWithSeedDlgAtParent(_class, relClassName, seedDlg, leftObj, rightObj, newDlg, mfail) \
        _SetUpRelCreateDlgWithSeedDlg(_class, TRUE, relClassName, seedDlg, leftObj, rightObj, newDlg, mfail)

#define SetVewDepExpandDisplay(className, relationship, genContextObj, mfail) \
        _SetVewDepExpandDisplay(className, FALSE, className, relationship, genContextObj, mfail)
#define SetVewDepExpandDisplayAtParent(_class, className, relationship, genContextObj, mfail) \
        _SetVewDepExpandDisplay(_class, TRUE, className, relationship, genContextObj, mfail)

#define SetVewDepRelateDisplay(className, backgroundObj, mfail) \
        _SetVewDepRelateDisplay(className, FALSE, className, backgroundObj, mfail)
#define SetVewDepRelateDisplayAtParent(_class, className, backgroundObj, mfail) \
        _SetVewDepRelateDisplay(_class, TRUE, className, backgroundObj, mfail)

#define SetViewDepObjsInSesObj(className, itemObj, relObj, mfail) \
        _SetViewDepObjsInSesObj(className, FALSE, className, itemObj, relObj, mfail)
#define SetViewDepObjsInSesObjAtParent(_class, className, itemObj, relObj, mfail) \
        _SetViewDepObjsInSesObj(_class, TRUE, className, itemObj, relObj, mfail)

#define SetViewPref(thisObj, global, network, name, mfail) \
        _SetViewPrefAtClass(NULL, FALSE, thisObj, global, network, name, mfail)
#define SetViewPrefAtClass(class, thisObj, global, network, name, mfail) \
        _SetViewPrefAtClass(class, FALSE, thisObj, global, network, name, mfail)
#define SetViewPrefAtParent(class, thisObj, global, network, name, mfail) \
        _SetViewPrefAtClass(class, TRUE, thisObj, global, network, name, mfail)

#define SetViewPrefP(thisObj, mfail) \
        _SetViewPrefPAtClass(NULL, FALSE, thisObj, mfail)
#define SetViewPrefPAtClass(class, thisObj, mfail) \
        _SetViewPrefPAtClass(class, FALSE, thisObj, mfail)
#define SetViewPrefPAtParent(class, thisObj, mfail) \
        _SetViewPrefPAtClass(class, TRUE, thisObj, mfail)

#define SetupSubPartForChanges(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _SetupSubPartForChangesAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define SetupSubPartForChangesAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _SetupSubPartForChangesAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define SetupSubPartForChangesAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _SetupSubPartForChangesAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define SetupWithVewForChanges(thisObj, relClassName, useDialogs, vewObj, cancel, mfail) \
        _SetupWithVewForChangesAtClass(NULL, FALSE, thisObj, relClassName, useDialogs, vewObj, cancel, mfail)
#define SetupWithVewForChangesAtClass(class, thisObj, relClassName, useDialogs, vewObj, cancel, mfail) \
        _SetupWithVewForChangesAtClass(class, FALSE, thisObj, relClassName, useDialogs, vewObj, cancel, mfail)
#define SetupWithVewForChangesAtParent(class, thisObj, relClassName, useDialogs, vewObj, cancel, mfail) \
        _SetupWithVewForChangesAtClass(class, TRUE, thisObj, relClassName, useDialogs, vewObj, cancel, mfail)

#define SortRptByConfigImpl(className, cfgItemIdStrSet, reportSet, mfail) \
        _SortRptByConfigImpl(className, FALSE, className, cfgItemIdStrSet, reportSet, mfail)
#define SortRptByConfigImplAtParent(_class, className, cfgItemIdStrSet, reportSet, mfail) \
        _SortRptByConfigImpl(_class, TRUE, className, cfgItemIdStrSet, reportSet, mfail)

#define SplitAllowPrcRevRels(className, objectSet, relationship, genContextObj, relObjSet, mfail) \
        _SplitAllowPrcRevRels(className, FALSE, className, objectSet, relationship, genContextObj, relObjSet, mfail)
#define SplitAllowPrcRevRelsAtParent(_class, className, objectSet, relationship, genContextObj, relObjSet, mfail) \
        _SplitAllowPrcRevRels(_class, TRUE, className, objectSet, relationship, genContextObj, relObjSet, mfail)

#define SplitBOM(topLvlProdElmObj, splitBOMDlgObj, mfail) \
        _SplitBOMAtClass(NULL, FALSE, topLvlProdElmObj, splitBOMDlgObj, mfail)
#define SplitBOMAtClass(class, topLvlProdElmObj, splitBOMDlgObj, mfail) \
        _SplitBOMAtClass(class, FALSE, topLvlProdElmObj, splitBOMDlgObj, mfail)
#define SplitBOMAtParent(class, topLvlProdElmObj, splitBOMDlgObj, mfail) \
        _SplitBOMAtClass(class, TRUE, topLvlProdElmObj, splitBOMDlgObj, mfail)

#define SplitBOMPost(topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail) \
        _SplitBOMPostAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail)
#define SplitBOMPostAtClass(class, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail) \
        _SplitBOMPostAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail)
#define SplitBOMPostAtParent(class, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail) \
        _SplitBOMPostAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail)

#define SplitBOMPre(topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail) \
        _SplitBOMPreAtClass(NULL, FALSE, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail)
#define SplitBOMPreAtClass(class, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail) \
        _SplitBOMPreAtClass(class, FALSE, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail)
#define SplitBOMPreAtParent(class, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail) \
        _SplitBOMPreAtClass(class, TRUE, topLvlProdElmObj, selectedStrcRel, quantity, occurrenceIds, newRelSet, mfail)

#define SplitBOMSet(className, topLvlProdElmObjSet, splitBOMDlgObjSet, mfail) \
        _SplitBOMSet(className, FALSE, className, topLvlProdElmObjSet, splitBOMDlgObjSet, mfail)
#define SplitBOMSetAtParent(_class, className, topLvlProdElmObjSet, splitBOMDlgObjSet, mfail) \
        _SplitBOMSet(_class, TRUE, className, topLvlProdElmObjSet, splitBOMDlgObjSet, mfail)

#define UpdProcStrcOptValues(thisObj, updateType, dialogObj, valueSet, mfail) \
        _UpdProcStrcOptValuesAtClass(NULL, FALSE, thisObj, updateType, dialogObj, valueSet, mfail)
#define UpdProcStrcOptValuesAtClass(class, thisObj, updateType, dialogObj, valueSet, mfail) \
        _UpdProcStrcOptValuesAtClass(class, FALSE, thisObj, updateType, dialogObj, valueSet, mfail)
#define UpdProcStrcOptValuesAtParent(class, thisObj, updateType, dialogObj, valueSet, mfail) \
        _UpdProcStrcOptValuesAtClass(class, TRUE, thisObj, updateType, dialogObj, valueSet, mfail)

#define UpdateOffrdSvcRelation(relation, prefInd, mfail) \
        _UpdateOffrdSvcRelationAtClass(NULL, FALSE, relation, prefInd, mfail)
#define UpdateOffrdSvcRelationAtClass(class, relation, prefInd, mfail) \
        _UpdateOffrdSvcRelationAtClass(class, FALSE, relation, prefInd, mfail)
#define UpdateOffrdSvcRelationAtParent(class, relation, prefInd, mfail) \
        _UpdateOffrdSvcRelationAtClass(class, TRUE, relation, prefInd, mfail)

#define UpdateRevEffObject(thisObj, vewObj, dialogObj, mfail) \
        _UpdateRevEffObjectAtClass(NULL, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateRevEffObjectAtClass(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateRevEffObjectAtClass(class, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateRevEffObjectAtParent(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateRevEffObjectAtClass(class, TRUE, thisObj, vewObj, dialogObj, mfail)

#define UpdateStrcEffObject(thisObj, vewObj, dialogObj, mfail) \
        _UpdateStrcEffObjectAtClass(NULL, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateStrcEffObjectAtClass(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateStrcEffObjectAtClass(class, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateStrcEffObjectAtParent(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateStrcEffObjectAtClass(class, TRUE, thisObj, vewObj, dialogObj, mfail)

#define UpdateStrucRelObj(thisObj, updateType, dialogObj, mfail) \
        _UpdateStrucRelObjAtClass(NULL, FALSE, thisObj, updateType, dialogObj, mfail)
#define UpdateStrucRelObjAtClass(class, thisObj, updateType, dialogObj, mfail) \
        _UpdateStrucRelObjAtClass(class, FALSE, thisObj, updateType, dialogObj, mfail)
#define UpdateStrucRelObjAtParent(class, thisObj, updateType, dialogObj, mfail) \
        _UpdateStrucRelObjAtClass(class, TRUE, thisObj, updateType, dialogObj, mfail)

#define UpdateStructurObject(thisObj, vewObj, dialogObj, mfail) \
        _UpdateStructurObjectAtClass(NULL, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateStructurObjectAtClass(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateStructurObjectAtClass(class, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateStructurObjectAtParent(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateStructurObjectAtClass(class, TRUE, thisObj, vewObj, dialogObj, mfail)

#define UpdateStructureForApp(thisObj, parentStrucBIObj, interfaceObj, mfail) \
        _UpdateStructureForAppAtClass(NULL, FALSE, thisObj, parentStrucBIObj, interfaceObj, mfail)
#define UpdateStructureForAppAtClass(class, thisObj, parentStrucBIObj, interfaceObj, mfail) \
        _UpdateStructureForAppAtClass(class, FALSE, thisObj, parentStrucBIObj, interfaceObj, mfail)
#define UpdateStructureForAppAtParent(class, thisObj, parentStrucBIObj, interfaceObj, mfail) \
        _UpdateStructureForAppAtClass(class, TRUE, thisObj, parentStrucBIObj, interfaceObj, mfail)

#define UpdateSubPartObject(thisObj, vewObj, dialogObj, mfail) \
        _UpdateSubPartObjectAtClass(NULL, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateSubPartObjectAtClass(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateSubPartObjectAtClass(class, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateSubPartObjectAtParent(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateSubPartObjectAtClass(class, TRUE, thisObj, vewObj, dialogObj, mfail)

#define UpdateViewDepObject(thisObj, vewObj, dialogObj, mfail) \
        _UpdateViewDepObjectAtClass(NULL, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateViewDepObjectAtClass(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateViewDepObjectAtClass(class, FALSE, thisObj, vewObj, dialogObj, mfail)
#define UpdateViewDepObjectAtParent(class, thisObj, vewObj, dialogObj, mfail) \
        _UpdateViewDepObjectAtClass(class, TRUE, thisObj, vewObj, dialogObj, mfail)

#define UpgradeMfgPartData(className, mfail) \
        _UpgradeMfgPartData(className, FALSE, className, mfail)
#define UpgradeMfgPartDataAtParent(_class, className, mfail) \
        _UpgradeMfgPartData(_class, TRUE, className, mfail)

#define UpgradeMfgPartObj(mfgPartObj, orgznID, orgznType, mfail) \
        _UpgradeMfgPartObjAtClass(NULL, FALSE, mfgPartObj, orgznID, orgznType, mfail)
#define UpgradeMfgPartObjAtClass(class, mfgPartObj, orgznID, orgznType, mfail) \
        _UpgradeMfgPartObjAtClass(class, FALSE, mfgPartObj, orgznID, orgznType, mfail)
#define UpgradeMfgPartObjAtParent(class, mfgPartObj, orgznID, orgznType, mfail) \
        _UpgradeMfgPartObjAtClass(class, TRUE, mfgPartObj, orgznID, orgznType, mfail)

#define UpgradeMptForMigration(className, parameterSet, outputSet, mfail) \
        _UpgradeMptForMigration(className, FALSE, className, parameterSet, outputSet, mfail)
#define UpgradeMptForMigrationAtParent(_class, className, parameterSet, outputSet, mfail) \
        _UpgradeMptForMigration(_class, TRUE, className, parameterSet, outputSet, mfail)

#define UpgradeSupForMigration(className, parameterSet, outputSet, mfail) \
        _UpgradeSupForMigration(className, FALSE, className, parameterSet, outputSet, mfail)
#define UpgradeSupForMigrationAtParent(_class, className, parameterSet, outputSet, mfail) \
        _UpgradeSupForMigration(_class, TRUE, className, parameterSet, outputSet, mfail)

#define UpgradeSupplierData(className, mfail) \
        _UpgradeSupplierData(className, FALSE, className, mfail)
#define UpgradeSupplierDataAtParent(_class, className, mfail) \
        _UpgradeSupplierData(_class, TRUE, className, mfail)

#define UpgradeSupplierObj(suppObj, mfail) \
        _UpgradeSupplierObjAtClass(NULL, FALSE, suppObj, mfail)
#define UpgradeSupplierObjAtClass(class, suppObj, mfail) \
        _UpgradeSupplierObjAtClass(class, FALSE, suppObj, mfail)
#define UpgradeSupplierObjAtParent(class, suppObj, mfail) \
        _UpgradeSupplierObjAtClass(class, TRUE, suppObj, mfail)

#define ValBuildVewNtwkMapping(className, curVewNtwkBitPos, newVewNtwkBitPos, newStartingBitPos, mfail) \
        _ValBuildVewNtwkMapping(className, FALSE, className, curVewNtwkBitPos, newVewNtwkBitPos, newStartingBitPos, mfail)
#define ValBuildVewNtwkMappingAtParent(_class, className, curVewNtwkBitPos, newVewNtwkBitPos, newStartingBitPos, mfail) \
        _ValBuildVewNtwkMapping(_class, TRUE, className, curVewNtwkBitPos, newVewNtwkBitPos, newStartingBitPos, mfail)

#define ValCertiStatusAttr(dialogObj, originClassName, originObject, badArgs, mfail) \
        _ValCertiStatusAttrAtClass(NULL, FALSE, dialogObj, originClassName, originObject, badArgs, mfail)
#define ValCertiStatusAttrAtClass(class, dialogObj, originClassName, originObject, badArgs, mfail) \
        _ValCertiStatusAttrAtClass(class, FALSE, dialogObj, originClassName, originObject, badArgs, mfail)
#define ValCertiStatusAttrAtParent(class, dialogObj, originClassName, originObject, badArgs, mfail) \
        _ValCertiStatusAttrAtClass(class, TRUE, dialogObj, originClassName, originObject, badArgs, mfail)

#define ValCntnsItmForCntnsRel(containsItem, relObj, mfail) \
        _ValCntnsItmForCntnsRelAtClass(NULL, FALSE, containsItem, relObj, mfail)
#define ValCntnsItmForCntnsRelAtClass(class, containsItem, relObj, mfail) \
        _ValCntnsItmForCntnsRelAtClass(class, FALSE, containsItem, relObj, mfail)
#define ValCntnsItmForCntnsRelAtParent(class, containsItem, relObj, mfail) \
        _ValCntnsItmForCntnsRelAtClass(class, TRUE, containsItem, relObj, mfail)

#define ValComPrtForDelRprsnt(comPrtObj, relObj, mfail) \
        _ValComPrtForDelRprsntAtClass(NULL, FALSE, comPrtObj, relObj, mfail)
#define ValComPrtForDelRprsntAtClass(class, comPrtObj, relObj, mfail) \
        _ValComPrtForDelRprsntAtClass(class, FALSE, comPrtObj, relObj, mfail)
#define ValComPrtForDelRprsntAtParent(class, comPrtObj, relObj, mfail) \
        _ValComPrtForDelRprsntAtClass(class, TRUE, comPrtObj, relObj, mfail)

#define ValCpgForCreRpsRel(gnComPrtObj, reprsntsObj, mfail) \
        _ValCpgForCreRpsRelAtClass(NULL, FALSE, gnComPrtObj, reprsntsObj, mfail)
#define ValCpgForCreRpsRelAtClass(class, gnComPrtObj, reprsntsObj, mfail) \
        _ValCpgForCreRpsRelAtClass(class, FALSE, gnComPrtObj, reprsntsObj, mfail)
#define ValCpgForCreRpsRelAtParent(class, gnComPrtObj, reprsntsObj, mfail) \
        _ValCpgForCreRpsRelAtClass(class, TRUE, gnComPrtObj, reprsntsObj, mfail)

#define ValDoAssignEOLDate(gnComMfgPart, assignEOLDateDlg, refresh, badArgs, mfail) \
        _ValDoAssignEOLDateAtClass(NULL, FALSE, gnComMfgPart, assignEOLDateDlg, refresh, badArgs, mfail)
#define ValDoAssignEOLDateAtClass(class, gnComMfgPart, assignEOLDateDlg, refresh, badArgs, mfail) \
        _ValDoAssignEOLDateAtClass(class, FALSE, gnComMfgPart, assignEOLDateDlg, refresh, badArgs, mfail)
#define ValDoAssignEOLDateAtParent(class, gnComMfgPart, assignEOLDateDlg, refresh, badArgs, mfail) \
        _ValDoAssignEOLDateAtClass(class, TRUE, gnComMfgPart, assignEOLDateDlg, refresh, badArgs, mfail)

#define ValDomForAsgnToVewNtwk(thisObj, isLocal, mfail) \
        _ValDomForAsgnToVewNtwkAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomForAsgnToVewNtwkAtClass(class, thisObj, isLocal, mfail) \
        _ValDomForAsgnToVewNtwkAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomForAsgnToVewNtwkAtParent(class, thisObj, isLocal, mfail) \
        _ValDomForAsgnToVewNtwkAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForAsgEOLDate(gnComMfgPart, isLocal, mfail) \
        _ValDomainForAsgEOLDateAtClass(NULL, FALSE, gnComMfgPart, isLocal, mfail)
#define ValDomainForAsgEOLDateAtClass(class, gnComMfgPart, isLocal, mfail) \
        _ValDomainForAsgEOLDateAtClass(class, FALSE, gnComMfgPart, isLocal, mfail)
#define ValDomainForAsgEOLDateAtParent(class, gnComMfgPart, isLocal, mfail) \
        _ValDomainForAsgEOLDateAtClass(class, TRUE, gnComMfgPart, isLocal, mfail)

#define ValDomainForCertStat(genSplrObj, isLocal, mfail) \
        _ValDomainForCertStatAtClass(NULL, FALSE, genSplrObj, isLocal, mfail)
#define ValDomainForCertStatAtClass(class, genSplrObj, isLocal, mfail) \
        _ValDomainForCertStatAtClass(class, FALSE, genSplrObj, isLocal, mfail)
#define ValDomainForCertStatAtParent(class, genSplrObj, isLocal, mfail) \
        _ValDomainForCertStatAtClass(class, TRUE, genSplrObj, isLocal, mfail)

#define ValDomainForCreateCI(thisObj, isLocal, mfail) \
        _ValDomainForCreateCIAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCreateCIAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForCreateCIAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCreateCIAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForCreateCIAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForFreezeView(thisObj, isLocal, mfail) \
        _ValDomainForFreezeViewAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForFreezeViewAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForFreezeViewAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForFreezeViewAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForFreezeViewAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForVndStat(vendorObj, isLocal, mfail) \
        _ValDomainForVndStatAtClass(NULL, FALSE, vendorObj, isLocal, mfail)
#define ValDomainForVndStatAtClass(class, vendorObj, isLocal, mfail) \
        _ValDomainForVndStatAtClass(class, FALSE, vendorObj, isLocal, mfail)
#define ValDomainForVndStatAtParent(class, vendorObj, isLocal, mfail) \
        _ValDomainForVndStatAtClass(class, TRUE, vendorObj, isLocal, mfail)

#define ValEffForOverlapping(thisObj, cfgItemObj, dialogObj, mfail) \
        _ValEffForOverlappingAtClass(NULL, FALSE, thisObj, cfgItemObj, dialogObj, mfail)
#define ValEffForOverlappingAtClass(class, thisObj, cfgItemObj, dialogObj, mfail) \
        _ValEffForOverlappingAtClass(class, FALSE, thisObj, cfgItemObj, dialogObj, mfail)
#define ValEffForOverlappingAtParent(class, thisObj, cfgItemObj, dialogObj, mfail) \
        _ValEffForOverlappingAtClass(class, TRUE, thisObj, cfgItemObj, dialogObj, mfail)

#define ValExpRevEffectivity(thisObj, genContextObj, mfail) \
        _ValExpRevEffectivityAtClass(NULL, FALSE, thisObj, genContextObj, mfail)
#define ValExpRevEffectivityAtClass(class, thisObj, genContextObj, mfail) \
        _ValExpRevEffectivityAtClass(class, FALSE, thisObj, genContextObj, mfail)
#define ValExpRevEffectivityAtParent(class, thisObj, genContextObj, mfail) \
        _ValExpRevEffectivityAtClass(class, TRUE, thisObj, genContextObj, mfail)

#define ValForAssignEOLDate(gnComMfgPart, mfail) \
        _ValForAssignEOLDateAtClass(NULL, FALSE, gnComMfgPart, mfail)
#define ValForAssignEOLDateAtClass(class, gnComMfgPart, mfail) \
        _ValForAssignEOLDateAtClass(class, FALSE, gnComMfgPart, mfail)
#define ValForAssignEOLDateAtParent(class, gnComMfgPart, mfail) \
        _ValForAssignEOLDateAtClass(class, TRUE, gnComMfgPart, mfail)

#define ValForAssignEOLDateExt(gnComMfgPart, mfail) \
        _ValForAssignEOLDateExtAtClass(NULL, FALSE, gnComMfgPart, mfail)
#define ValForAssignEOLDateExtAtClass(class, gnComMfgPart, mfail) \
        _ValForAssignEOLDateExtAtClass(class, FALSE, gnComMfgPart, mfail)
#define ValForAssignEOLDateExtAtParent(class, gnComMfgPart, mfail) \
        _ValForAssignEOLDateExtAtClass(class, TRUE, gnComMfgPart, mfail)

#define ValForAssignToVewNtwk(thisObj, mfail) \
        _ValForAssignToVewNtwkAtClass(NULL, FALSE, thisObj, mfail)
#define ValForAssignToVewNtwkAtClass(class, thisObj, mfail) \
        _ValForAssignToVewNtwkAtClass(class, FALSE, thisObj, mfail)
#define ValForAssignToVewNtwkAtParent(class, thisObj, mfail) \
        _ValForAssignToVewNtwkAtClass(class, TRUE, thisObj, mfail)

#define ValForChgCertStatus(genSplrObj, mfail) \
        _ValForChgCertStatusAtClass(NULL, FALSE, genSplrObj, mfail)
#define ValForChgCertStatusAtClass(class, genSplrObj, mfail) \
        _ValForChgCertStatusAtClass(class, FALSE, genSplrObj, mfail)
#define ValForChgCertStatusAtParent(class, genSplrObj, mfail) \
        _ValForChgCertStatusAtClass(class, TRUE, genSplrObj, mfail)

#define ValForChgCertStatusExt(genSplrObj, mfail) \
        _ValForChgCertStatusExtAtClass(NULL, FALSE, genSplrObj, mfail)
#define ValForChgCertStatusExtAtClass(class, genSplrObj, mfail) \
        _ValForChgCertStatusExtAtClass(class, FALSE, genSplrObj, mfail)
#define ValForChgCertStatusExtAtParent(class, genSplrObj, mfail) \
        _ValForChgCertStatusExtAtClass(class, TRUE, genSplrObj, mfail)

#define ValForChgVndStatus(vendorObj, mfail) \
        _ValForChgVndStatusAtClass(NULL, FALSE, vendorObj, mfail)
#define ValForChgVndStatusAtClass(class, vendorObj, mfail) \
        _ValForChgVndStatusAtClass(class, FALSE, vendorObj, mfail)
#define ValForChgVndStatusAtParent(class, vendorObj, mfail) \
        _ValForChgVndStatusAtClass(class, TRUE, vendorObj, mfail)

#define ValForChgVndStatusExt(vendorObj, mfail) \
        _ValForChgVndStatusExtAtClass(NULL, FALSE, vendorObj, mfail)
#define ValForChgVndStatusExtAtClass(class, vendorObj, mfail) \
        _ValForChgVndStatusExtAtClass(class, FALSE, vendorObj, mfail)
#define ValForChgVndStatusExtAtParent(class, vendorObj, mfail) \
        _ValForChgVndStatusExtAtClass(class, TRUE, vendorObj, mfail)

#define ValForEffCreAndUpd(thisObj, dialogObj, mfail) \
        _ValForEffCreAndUpdAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ValForEffCreAndUpdAtClass(class, thisObj, dialogObj, mfail) \
        _ValForEffCreAndUpdAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ValForEffCreAndUpdAtParent(class, thisObj, dialogObj, mfail) \
        _ValForEffCreAndUpdAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ValForMigOrRemVewNtwk(thisObj, migratingViewNetwork, mfail) \
        _ValForMigOrRemVewNtwkAtClass(NULL, FALSE, thisObj, migratingViewNetwork, mfail)
#define ValForMigOrRemVewNtwkAtClass(class, thisObj, migratingViewNetwork, mfail) \
        _ValForMigOrRemVewNtwkAtClass(class, FALSE, thisObj, migratingViewNetwork, mfail)
#define ValForMigOrRemVewNtwkAtParent(class, thisObj, migratingViewNetwork, mfail) \
        _ValForMigOrRemVewNtwkAtClass(class, TRUE, thisObj, migratingViewNetwork, mfail)

#define ValForMrkVewNtwkUnused(thisObj, mfail) \
        _ValForMrkVewNtwkUnusedAtClass(NULL, FALSE, thisObj, mfail)
#define ValForMrkVewNtwkUnusedAtClass(class, thisObj, mfail) \
        _ValForMrkVewNtwkUnusedAtClass(class, FALSE, thisObj, mfail)
#define ValForMrkVewNtwkUnusedAtParent(class, thisObj, mfail) \
        _ValForMrkVewNtwkUnusedAtClass(class, TRUE, thisObj, mfail)

#define ValFreezeOfRelObj(thisObj, itemObj, mfail) \
        _ValFreezeOfRelObjAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ValFreezeOfRelObjAtClass(class, thisObj, itemObj, mfail) \
        _ValFreezeOfRelObjAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ValFreezeOfRelObjAtParent(class, thisObj, itemObj, mfail) \
        _ValFreezeOfRelObjAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ValFreezeViewOfRelObjs(thisObj, mfail) \
        _ValFreezeViewOfRelObjsAtClass(NULL, FALSE, thisObj, mfail)
#define ValFreezeViewOfRelObjsAtClass(class, thisObj, mfail) \
        _ValFreezeViewOfRelObjsAtClass(class, FALSE, thisObj, mfail)
#define ValFreezeViewOfRelObjsAtParent(class, thisObj, mfail) \
        _ValFreezeViewOfRelObjsAtClass(class, TRUE, thisObj, mfail)

#define ValGSplrForDelSupSvc(supplierObj, relObj, mfail) \
        _ValGSplrForDelSupSvcAtClass(NULL, FALSE, supplierObj, relObj, mfail)
#define ValGSplrForDelSupSvcAtClass(class, supplierObj, relObj, mfail) \
        _ValGSplrForDelSupSvcAtClass(class, FALSE, supplierObj, relObj, mfail)
#define ValGSplrForDelSupSvcAtParent(class, supplierObj, relObj, mfail) \
        _ValGSplrForDelSupSvcAtClass(class, TRUE, supplierObj, relObj, mfail)

#define ValGdmForCrePdsRel(gdiMstrObj, prtDstMrObj, mfail) \
        _ValGdmForCrePdsRelAtClass(NULL, FALSE, gdiMstrObj, prtDstMrObj, mfail)
#define ValGdmForCrePdsRelAtClass(class, gdiMstrObj, prtDstMrObj, mfail) \
        _ValGdmForCrePdsRelAtClass(class, FALSE, gdiMstrObj, prtDstMrObj, mfail)
#define ValGdmForCrePdsRelAtParent(class, gdiMstrObj, prtDstMrObj, mfail) \
        _ValGdmForCrePdsRelAtClass(class, TRUE, gdiMstrObj, prtDstMrObj, mfail)

#define ValGdmForDelPrtDstMr(distMstrObj, relObj, mfail) \
        _ValGdmForDelPrtDstMrAtClass(NULL, FALSE, distMstrObj, relObj, mfail)
#define ValGdmForDelPrtDstMrAtClass(class, distMstrObj, relObj, mfail) \
        _ValGdmForDelPrtDstMrAtClass(class, FALSE, distMstrObj, relObj, mfail)
#define ValGdmForDelPrtDstMrAtParent(class, distMstrObj, relObj, mfail) \
        _ValGdmForDelPrtDstMrAtClass(class, TRUE, distMstrObj, relObj, mfail)

#define ValGmmForCrePmmRel(gmfMstrObj, prtMfrMrObj, mfail) \
        _ValGmmForCrePmmRelAtClass(NULL, FALSE, gmfMstrObj, prtMfrMrObj, mfail)
#define ValGmmForCrePmmRelAtClass(class, gmfMstrObj, prtMfrMrObj, mfail) \
        _ValGmmForCrePmmRelAtClass(class, FALSE, gmfMstrObj, prtMfrMrObj, mfail)
#define ValGmmForCrePmmRelAtParent(class, gmfMstrObj, prtMfrMrObj, mfail) \
        _ValGmmForCrePmmRelAtClass(class, TRUE, gmfMstrObj, prtMfrMrObj, mfail)

#define ValGmmForDelPrtMfrMr(mfgMstrObj, relObj, mfail) \
        _ValGmmForDelPrtMfrMrAtClass(NULL, FALSE, mfgMstrObj, relObj, mfail)
#define ValGmmForDelPrtMfrMrAtClass(class, mfgMstrObj, relObj, mfail) \
        _ValGmmForDelPrtMfrMrAtClass(class, FALSE, mfgMstrObj, relObj, mfail)
#define ValGmmForDelPrtMfrMrAtParent(class, mfgMstrObj, relObj, mfail) \
        _ValGmmForDelPrtMfrMrAtClass(class, TRUE, mfgMstrObj, relObj, mfail)

#define ValGmpForCrePmmRel(gnMfgPrtObj, prtMfrMrObj, mfail) \
        _ValGmpForCrePmmRelAtClass(NULL, FALSE, gnMfgPrtObj, prtMfrMrObj, mfail)
#define ValGmpForCrePmmRelAtClass(class, gnMfgPrtObj, prtMfrMrObj, mfail) \
        _ValGmpForCrePmmRelAtClass(class, FALSE, gnMfgPrtObj, prtMfrMrObj, mfail)
#define ValGmpForCrePmmRelAtParent(class, gnMfgPrtObj, prtMfrMrObj, mfail) \
        _ValGmpForCrePmmRelAtClass(class, TRUE, gnMfgPrtObj, prtMfrMrObj, mfail)

#define ValGmpForCreRpsRel(gnMfgPrtObj, reprsntsObj, mfail) \
        _ValGmpForCreRpsRelAtClass(NULL, FALSE, gnMfgPrtObj, reprsntsObj, mfail)
#define ValGmpForCreRpsRelAtClass(class, gnMfgPrtObj, reprsntsObj, mfail) \
        _ValGmpForCreRpsRelAtClass(class, FALSE, gnMfgPrtObj, reprsntsObj, mfail)
#define ValGmpForCreRpsRelAtParent(class, gnMfgPrtObj, reprsntsObj, mfail) \
        _ValGmpForCreRpsRelAtClass(class, TRUE, gnMfgPrtObj, reprsntsObj, mfail)

#define ValGspForCreSpcRel(genSplrObj, supSvcObj, mfail) \
        _ValGspForCreSpcRelAtClass(NULL, FALSE, genSplrObj, supSvcObj, mfail)
#define ValGspForCreSpcRelAtClass(class, genSplrObj, supSvcObj, mfail) \
        _ValGspForCreSpcRelAtClass(class, FALSE, genSplrObj, supSvcObj, mfail)
#define ValGspForCreSpcRelAtParent(class, genSplrObj, supSvcObj, mfail) \
        _ValGspForCreSpcRelAtClass(class, TRUE, genSplrObj, supSvcObj, mfail)

#define ValGumForCrePssRel(gspMstrObj, prtSupMrObj, mfail) \
        _ValGumForCrePssRelAtClass(NULL, FALSE, gspMstrObj, prtSupMrObj, mfail)
#define ValGumForCrePssRelAtClass(class, gspMstrObj, prtSupMrObj, mfail) \
        _ValGumForCrePssRelAtClass(class, FALSE, gspMstrObj, prtSupMrObj, mfail)
#define ValGumForCrePssRelAtParent(class, gspMstrObj, prtSupMrObj, mfail) \
        _ValGumForCrePssRelAtClass(class, TRUE, gspMstrObj, prtSupMrObj, mfail)

#define ValGumForDelPrtSupMr(supplierMObj, relObj, mfail) \
        _ValGumForDelPrtSupMrAtClass(NULL, FALSE, supplierMObj, relObj, mfail)
#define ValGumForDelPrtSupMrAtClass(class, supplierMObj, relObj, mfail) \
        _ValGumForDelPrtSupMrAtClass(class, FALSE, supplierMObj, relObj, mfail)
#define ValGumForDelPrtSupMrAtParent(class, supplierMObj, relObj, mfail) \
        _ValGumForDelPrtSupMrAtClass(class, TRUE, supplierMObj, relObj, mfail)

#define ValItemForHasPkgRel(busItem, relObj, mfail) \
        _ValItemForHasPkgRelAtClass(NULL, FALSE, busItem, relObj, mfail)
#define ValItemForHasPkgRelAtClass(class, busItem, relObj, mfail) \
        _ValItemForHasPkgRelAtClass(class, FALSE, busItem, relObj, mfail)
#define ValItemForHasPkgRelAtParent(class, busItem, relObj, mfail) \
        _ValItemForHasPkgRelAtClass(class, TRUE, busItem, relObj, mfail)

#define ValLeftPrtMrForCreAltR(leftPartMstr, altPartRel, mfail) \
        _ValLeftPrtMrForCreAltRAtClass(NULL, FALSE, leftPartMstr, altPartRel, mfail)
#define ValLeftPrtMrForCreAltRAtClass(class, leftPartMstr, altPartRel, mfail) \
        _ValLeftPrtMrForCreAltRAtClass(class, FALSE, leftPartMstr, altPartRel, mfail)
#define ValLeftPrtMrForCreAltRAtParent(class, leftPartMstr, altPartRel, mfail) \
        _ValLeftPrtMrForCreAltRAtClass(class, TRUE, leftPartMstr, altPartRel, mfail)

#define ValMPartForDelPrtMfrMr(mfgPrtObj, relObj, mfail) \
        _ValMPartForDelPrtMfrMrAtClass(NULL, FALSE, mfgPrtObj, relObj, mfail)
#define ValMPartForDelPrtMfrMrAtClass(class, mfgPrtObj, relObj, mfail) \
        _ValMPartForDelPrtMfrMrAtClass(class, FALSE, mfgPrtObj, relObj, mfail)
#define ValMPartForDelPrtMfrMrAtParent(class, mfgPrtObj, relObj, mfail) \
        _ValMPartForDelPrtMfrMrAtClass(class, TRUE, mfgPrtObj, relObj, mfail)

#define ValMfgPrtForDelRprsnt(mfgPrtObj, relObj, mfail) \
        _ValMfgPrtForDelRprsntAtClass(NULL, FALSE, mfgPrtObj, relObj, mfail)
#define ValMfgPrtForDelRprsntAtClass(class, mfgPrtObj, relObj, mfail) \
        _ValMfgPrtForDelRprsntAtClass(class, FALSE, mfgPrtObj, relObj, mfail)
#define ValMfgPrtForDelRprsntAtParent(class, mfgPrtObj, relObj, mfail) \
        _ValMfgPrtForDelRprsntAtClass(class, TRUE, mfgPrtObj, relObj, mfail)

#define ValObjsForSuppAccess(className, someObjects, mfail) \
        _ValObjsForSuppAccess(className, FALSE, className, someObjects, mfail)
#define ValObjsForSuppAccessAtParent(_class, className, someObjects, mfail) \
        _ValObjsForSuppAccess(_class, TRUE, className, someObjects, mfail)

#define ValPartForDelPrtDstMr(prtObj, relObj, mfail) \
        _ValPartForDelPrtDstMrAtClass(NULL, FALSE, prtObj, relObj, mfail)
#define ValPartForDelPrtDstMrAtClass(class, prtObj, relObj, mfail) \
        _ValPartForDelPrtDstMrAtClass(class, FALSE, prtObj, relObj, mfail)
#define ValPartForDelPrtDstMrAtParent(class, prtObj, relObj, mfail) \
        _ValPartForDelPrtDstMrAtClass(class, TRUE, prtObj, relObj, mfail)

#define ValPartForDelPrtSupMr(PartObj, relObj, mfail) \
        _ValPartForDelPrtSupMrAtClass(NULL, FALSE, PartObj, relObj, mfail)
#define ValPartForDelPrtSupMrAtClass(class, PartObj, relObj, mfail) \
        _ValPartForDelPrtSupMrAtClass(class, FALSE, PartObj, relObj, mfail)
#define ValPartForDelPrtSupMrAtParent(class, PartObj, relObj, mfail) \
        _ValPartForDelPrtSupMrAtClass(class, TRUE, PartObj, relObj, mfail)

#define ValPkgForCreCntnsRel(pkgItem, relObj, mfail) \
        _ValPkgForCreCntnsRelAtClass(NULL, FALSE, pkgItem, relObj, mfail)
#define ValPkgForCreCntnsRelAtClass(class, pkgItem, relObj, mfail) \
        _ValPkgForCreCntnsRelAtClass(class, FALSE, pkgItem, relObj, mfail)
#define ValPkgForCreCntnsRelAtParent(class, pkgItem, relObj, mfail) \
        _ValPkgForCreCntnsRelAtClass(class, TRUE, pkgItem, relObj, mfail)

#define ValPkgForCreHasPkgRel(pkgItem, relObj, mfail) \
        _ValPkgForCreHasPkgRelAtClass(NULL, FALSE, pkgItem, relObj, mfail)
#define ValPkgForCreHasPkgRelAtClass(class, pkgItem, relObj, mfail) \
        _ValPkgForCreHasPkgRelAtClass(class, FALSE, pkgItem, relObj, mfail)
#define ValPkgForCreHasPkgRelAtParent(class, pkgItem, relObj, mfail) \
        _ValPkgForCreHasPkgRelAtClass(class, TRUE, pkgItem, relObj, mfail)

#define ValPrtForCrePdsRel(partObj, prtDstMrObj, mfail) \
        _ValPrtForCrePdsRelAtClass(NULL, FALSE, partObj, prtDstMrObj, mfail)
#define ValPrtForCrePdsRelAtClass(class, partObj, prtDstMrObj, mfail) \
        _ValPrtForCrePdsRelAtClass(class, FALSE, partObj, prtDstMrObj, mfail)
#define ValPrtForCrePdsRelAtParent(class, partObj, prtDstMrObj, mfail) \
        _ValPrtForCrePdsRelAtClass(class, TRUE, partObj, prtDstMrObj, mfail)

#define ValPrtForCrePssRel(partObj, prtSupMrObj, mfail) \
        _ValPrtForCrePssRelAtClass(NULL, FALSE, partObj, prtSupMrObj, mfail)
#define ValPrtForCrePssRelAtClass(class, partObj, prtSupMrObj, mfail) \
        _ValPrtForCrePssRelAtClass(class, FALSE, partObj, prtSupMrObj, mfail)
#define ValPrtForCrePssRelAtParent(class, partObj, prtSupMrObj, mfail) \
        _ValPrtForCrePssRelAtClass(class, TRUE, partObj, prtSupMrObj, mfail)

#define ValPrtForCreSubPrtR(partObj, subPartRel, mfail) \
        _ValPrtForCreSubPrtRAtClass(NULL, FALSE, partObj, subPartRel, mfail)
#define ValPrtForCreSubPrtRAtClass(class, partObj, subPartRel, mfail) \
        _ValPrtForCreSubPrtRAtClass(class, FALSE, partObj, subPartRel, mfail)
#define ValPrtForCreSubPrtRAtParent(class, partObj, subPartRel, mfail) \
        _ValPrtForCreSubPrtRAtClass(class, TRUE, partObj, subPartRel, mfail)

#define ValPrtMrForCreAsmStrcR(partMstrObj, assmStrcRel, mfail) \
        _ValPrtMrForCreAsmStrcRAtClass(NULL, FALSE, partMstrObj, assmStrcRel, mfail)
#define ValPrtMrForCreAsmStrcRAtClass(class, partMstrObj, assmStrcRel, mfail) \
        _ValPrtMrForCreAsmStrcRAtClass(class, FALSE, partMstrObj, assmStrcRel, mfail)
#define ValPrtMrForCreAsmStrcRAtParent(class, partMstrObj, assmStrcRel, mfail) \
        _ValPrtMrForCreAsmStrcRAtClass(class, TRUE, partMstrObj, assmStrcRel, mfail)

#define ValPrtMrForCreSubPrtR(partMasterObj, subPartRel, mfail) \
        _ValPrtMrForCreSubPrtRAtClass(NULL, FALSE, partMasterObj, subPartRel, mfail)
#define ValPrtMrForCreSubPrtRAtClass(class, partMasterObj, subPartRel, mfail) \
        _ValPrtMrForCreSubPrtRAtClass(class, FALSE, partMasterObj, subPartRel, mfail)
#define ValPrtMrForCreSubPrtRAtParent(class, partMasterObj, subPartRel, mfail) \
        _ValPrtMrForCreSubPrtRAtClass(class, TRUE, partMasterObj, subPartRel, mfail)

#define ValRelRevEffectivity(thisObj, mfail) \
        _ValRelRevEffectivityAtClass(NULL, FALSE, thisObj, mfail)
#define ValRelRevEffectivityAtClass(class, thisObj, mfail) \
        _ValRelRevEffectivityAtClass(class, FALSE, thisObj, mfail)
#define ValRelRevEffectivityAtParent(class, thisObj, mfail) \
        _ValRelRevEffectivityAtClass(class, TRUE, thisObj, mfail)

#define ValRelStrucEff(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelStrucEffAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define ValRelStrucEffAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelStrucEffAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define ValRelStrucEffAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelStrucEffAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define ValRelStrucOption(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelStrucOptionAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define ValRelStrucOptionAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelStrucOptionAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define ValRelStrucOptionAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelStrucOptionAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define ValRelateSubPart(thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelateSubPartAtClass(NULL, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define ValRelateSubPartAtClass(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelateSubPartAtClass(class, FALSE, thisObj, selectedRelObj, selectedItmObj, mfail)
#define ValRelateSubPartAtParent(class, thisObj, selectedRelObj, selectedItmObj, mfail) \
        _ValRelateSubPartAtClass(class, TRUE, thisObj, selectedRelObj, selectedItmObj, mfail)

#define ValRestrcActForOccQty(strucRel, mfail) \
        _ValRestrcActForOccQtyAtClass(NULL, FALSE, strucRel, mfail)
#define ValRestrcActForOccQtyAtClass(class, strucRel, mfail) \
        _ValRestrcActForOccQtyAtClass(class, FALSE, strucRel, mfail)
#define ValRestrcActForOccQtyAtParent(class, strucRel, mfail) \
        _ValRestrcActForOccQtyAtClass(class, TRUE, strucRel, mfail)

#define ValRghtPrtMrForCreAltR(rightPartMstr, altPartRel, mfail) \
        _ValRghtPrtMrForCreAltRAtClass(NULL, FALSE, rightPartMstr, altPartRel, mfail)
#define ValRghtPrtMrForCreAltRAtClass(class, rightPartMstr, altPartRel, mfail) \
        _ValRghtPrtMrForCreAltRAtClass(class, FALSE, rightPartMstr, altPartRel, mfail)
#define ValRghtPrtMrForCreAltRAtParent(class, rightPartMstr, altPartRel, mfail) \
        _ValRghtPrtMrForCreAltRAtClass(class, TRUE, rightPartMstr, altPartRel, mfail)

#define ValSgdForCreVsdRel(stGenDocObj, vndStDocObj, mfail) \
        _ValSgdForCreVsdRelAtClass(NULL, FALSE, stGenDocObj, vndStDocObj, mfail)
#define ValSgdForCreVsdRelAtClass(class, stGenDocObj, vndStDocObj, mfail) \
        _ValSgdForCreVsdRelAtClass(class, FALSE, stGenDocObj, vndStDocObj, mfail)
#define ValSgdForCreVsdRelAtParent(class, stGenDocObj, vndStDocObj, mfail) \
        _ValSgdForCreVsdRelAtClass(class, TRUE, stGenDocObj, vndStDocObj, mfail)

#define ValSgdForDelVndStDoc(stGenDocObj, relObj, mfail) \
        _ValSgdForDelVndStDocAtClass(NULL, FALSE, stGenDocObj, relObj, mfail)
#define ValSgdForDelVndStDocAtClass(class, stGenDocObj, relObj, mfail) \
        _ValSgdForDelVndStDocAtClass(class, FALSE, stGenDocObj, relObj, mfail)
#define ValSgdForDelVndStDocAtParent(class, stGenDocObj, relObj, mfail) \
        _ValSgdForDelVndStDocAtClass(class, TRUE, stGenDocObj, relObj, mfail)

#define ValStyForCreSpcRel(svcTypeObj, supSvcObj, mfail) \
        _ValStyForCreSpcRelAtClass(NULL, FALSE, svcTypeObj, supSvcObj, mfail)
#define ValStyForCreSpcRelAtClass(class, svcTypeObj, supSvcObj, mfail) \
        _ValStyForCreSpcRelAtClass(class, FALSE, svcTypeObj, supSvcObj, mfail)
#define ValStyForCreSpcRelAtParent(class, svcTypeObj, supSvcObj, mfail) \
        _ValStyForCreSpcRelAtClass(class, TRUE, svcTypeObj, supSvcObj, mfail)

#define ValSvcTypeForDelSupSvc(svcTypeObj, relObj, mfail) \
        _ValSvcTypeForDelSupSvcAtClass(NULL, FALSE, svcTypeObj, relObj, mfail)
#define ValSvcTypeForDelSupSvcAtClass(class, svcTypeObj, relObj, mfail) \
        _ValSvcTypeForDelSupSvcAtClass(class, FALSE, svcTypeObj, relObj, mfail)
#define ValSvcTypeForDelSupSvcAtParent(class, svcTypeObj, relObj, mfail) \
        _ValSvcTypeForDelSupSvcAtClass(class, TRUE, svcTypeObj, relObj, mfail)

#define ValUsrForViewAllVndrs(vndrMstrObj, relship, isValid, mfail) \
        _ValUsrForViewAllVndrsAtClass(NULL, FALSE, vndrMstrObj, relship, isValid, mfail)
#define ValUsrForViewAllVndrsAtClass(class, vndrMstrObj, relship, isValid, mfail) \
        _ValUsrForViewAllVndrsAtClass(class, FALSE, vndrMstrObj, relship, isValid, mfail)
#define ValUsrForViewAllVndrsAtParent(class, vndrMstrObj, relship, isValid, mfail) \
        _ValUsrForViewAllVndrsAtClass(class, TRUE, vndrMstrObj, relship, isValid, mfail)

#define ValVendorStatusAttr(dialogObj, originClassName, originObject, badArgs, mfail) \
        _ValVendorStatusAttrAtClass(NULL, FALSE, dialogObj, originClassName, originObject, badArgs, mfail)
#define ValVendorStatusAttrAtClass(class, dialogObj, originClassName, originObject, badArgs, mfail) \
        _ValVendorStatusAttrAtClass(class, FALSE, dialogObj, originClassName, originObject, badArgs, mfail)
#define ValVendorStatusAttrAtParent(class, dialogObj, originClassName, originObject, badArgs, mfail) \
        _ValVendorStatusAttrAtClass(class, TRUE, dialogObj, originClassName, originObject, badArgs, mfail)

#define ValVnmForCreVsdRel(vndMstrObj, vndStDocObj, mfail) \
        _ValVnmForCreVsdRelAtClass(NULL, FALSE, vndMstrObj, vndStDocObj, mfail)
#define ValVnmForCreVsdRelAtClass(class, vndMstrObj, vndStDocObj, mfail) \
        _ValVnmForCreVsdRelAtClass(class, FALSE, vndMstrObj, vndStDocObj, mfail)
#define ValVnmForCreVsdRelAtParent(class, vndMstrObj, vndStDocObj, mfail) \
        _ValVnmForCreVsdRelAtClass(class, TRUE, vndMstrObj, vndStDocObj, mfail)

#define ValVnmForDelVndStDoc(vendorMObj, relObj, mfail) \
        _ValVnmForDelVndStDocAtClass(NULL, FALSE, vendorMObj, relObj, mfail)
#define ValVnmForDelVndStDocAtClass(class, vendorMObj, relObj, mfail) \
        _ValVnmForDelVndStDocAtClass(class, FALSE, vendorMObj, relObj, mfail)
#define ValVnmForDelVndStDocAtParent(class, vendorMObj, relObj, mfail) \
        _ValVnmForDelVndStDocAtClass(class, TRUE, vendorMObj, relObj, mfail)

#define ValidateCADConsistency(itemToExport, mfail) \
        _ValidateCADConsistencyAtClass(NULL, FALSE, itemToExport, mfail)
#define ValidateCADConsistencyAtClass(class, itemToExport, mfail) \
        _ValidateCADConsistencyAtClass(class, FALSE, itemToExport, mfail)
#define ValidateCADConsistencyAtParent(class, itemToExport, mfail) \
        _ValidateCADConsistencyAtClass(class, TRUE, itemToExport, mfail)

#define ValidateDoChgCertStat(genSplrObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgCertStatAtClass(NULL, FALSE, genSplrObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChgCertStatAtClass(class, genSplrObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgCertStatAtClass(class, FALSE, genSplrObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChgCertStatAtParent(class, genSplrObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgCertStatAtClass(class, TRUE, genSplrObj, dialogObj, refresh, badArgs, mfail)

#define ValidateDoChgVndStat(vendorObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgVndStatAtClass(NULL, FALSE, vendorObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChgVndStatAtClass(class, vendorObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgVndStatAtClass(class, FALSE, vendorObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChgVndStatAtParent(class, vendorObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgVndStatAtClass(class, TRUE, vendorObj, dialogObj, refresh, badArgs, mfail)

#define ValidateEffUnitNumber(className, unitType, unitNumber, mfail) \
        _ValidateEffUnitNumber(className, FALSE, className, unitType, unitNumber, mfail)
#define ValidateEffUnitNumberAtParent(_class, className, unitType, unitNumber, mfail) \
        _ValidateEffUnitNumber(_class, TRUE, className, unitType, unitNumber, mfail)

#define ValidateForActVewNtwk(thisObj, mfail) \
        _ValidateForActVewNtwkAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForActVewNtwkAtClass(class, thisObj, mfail) \
        _ValidateForActVewNtwkAtClass(class, FALSE, thisObj, mfail)
#define ValidateForActVewNtwkAtParent(class, thisObj, mfail) \
        _ValidateForActVewNtwkAtClass(class, TRUE, thisObj, mfail)

#define ValidateForAsgnVwExt(thisObj, mfail) \
        _ValidateForAsgnVwExtAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForAsgnVwExtAtClass(class, thisObj, mfail) \
        _ValidateForAsgnVwExtAtClass(class, FALSE, thisObj, mfail)
#define ValidateForAsgnVwExtAtParent(class, thisObj, mfail) \
        _ValidateForAsgnVwExtAtClass(class, TRUE, thisObj, mfail)

#define ValidateForCreateCI(thisObj, mfail) \
        _ValidateForCreateCIAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForCreateCIAtClass(class, thisObj, mfail) \
        _ValidateForCreateCIAtClass(class, FALSE, thisObj, mfail)
#define ValidateForCreateCIAtParent(class, thisObj, mfail) \
        _ValidateForCreateCIAtClass(class, TRUE, thisObj, mfail)

#define ValidateForDactVewNtwk(thisObj, mfail) \
        _ValidateForDactVewNtwkAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForDactVewNtwkAtClass(class, thisObj, mfail) \
        _ValidateForDactVewNtwkAtClass(class, FALSE, thisObj, mfail)
#define ValidateForDactVewNtwkAtParent(class, thisObj, mfail) \
        _ValidateForDactVewNtwkAtClass(class, TRUE, thisObj, mfail)

#define ValidateForFreezeView(thisObj, mfail) \
        _ValidateForFreezeViewAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForFreezeViewAtClass(class, thisObj, mfail) \
        _ValidateForFreezeViewAtClass(class, FALSE, thisObj, mfail)
#define ValidateForFreezeViewAtParent(class, thisObj, mfail) \
        _ValidateForFreezeViewAtClass(class, TRUE, thisObj, mfail)

#define ValidateForILV(topLvlProdElmObj, newObjClass, newLeftRelClass, newRightRelClass, selectedStrcRels, vewObject, mfail) \
        _ValidateForILVAtClass(NULL, FALSE, topLvlProdElmObj, newObjClass, newLeftRelClass, newRightRelClass, selectedStrcRels, vewObject, mfail)
#define ValidateForILVAtClass(class, topLvlProdElmObj, newObjClass, newLeftRelClass, newRightRelClass, selectedStrcRels, vewObject, mfail) \
        _ValidateForILVAtClass(class, FALSE, topLvlProdElmObj, newObjClass, newLeftRelClass, newRightRelClass, selectedStrcRels, vewObject, mfail)
#define ValidateForILVAtParent(class, topLvlProdElmObj, newObjClass, newLeftRelClass, newRightRelClass, selectedStrcRels, vewObject, mfail) \
        _ValidateForILVAtClass(class, TRUE, topLvlProdElmObj, newObjClass, newLeftRelClass, newRightRelClass, selectedStrcRels, vewObject, mfail)

#define ValidateForMOA(topLvlProdELemObj, elemToRemove, relationToRemove, strucRelationSet, vewObject, mfail) \
        _ValidateForMOAAtClass(NULL, FALSE, topLvlProdELemObj, elemToRemove, relationToRemove, strucRelationSet, vewObject, mfail)
#define ValidateForMOAAtClass(class, topLvlProdELemObj, elemToRemove, relationToRemove, strucRelationSet, vewObject, mfail) \
        _ValidateForMOAAtClass(class, FALSE, topLvlProdELemObj, elemToRemove, relationToRemove, strucRelationSet, vewObject, mfail)
#define ValidateForMOAAtParent(class, topLvlProdELemObj, elemToRemove, relationToRemove, strucRelationSet, vewObject, mfail) \
        _ValidateForMOAAtClass(class, TRUE, topLvlProdELemObj, elemToRemove, relationToRemove, strucRelationSet, vewObject, mfail)

#define ValidateForPrepare(thisObj, mfail) \
        _ValidateForPrepareAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForPrepareAtClass(class, thisObj, mfail) \
        _ValidateForPrepareAtClass(class, FALSE, thisObj, mfail)
#define ValidateForPrepareAtParent(class, thisObj, mfail) \
        _ValidateForPrepareAtClass(class, TRUE, thisObj, mfail)

#define ValidateForSBM(topLvlProdElmObj, structureRelation, quantity, occurrenceIds, vewObject, mfail) \
        _ValidateForSBMAtClass(NULL, FALSE, topLvlProdElmObj, structureRelation, quantity, occurrenceIds, vewObject, mfail)
#define ValidateForSBMAtClass(class, topLvlProdElmObj, structureRelation, quantity, occurrenceIds, vewObject, mfail) \
        _ValidateForSBMAtClass(class, FALSE, topLvlProdElmObj, structureRelation, quantity, occurrenceIds, vewObject, mfail)
#define ValidateForSBMAtParent(class, topLvlProdElmObj, structureRelation, quantity, occurrenceIds, vewObject, mfail) \
        _ValidateForSBMAtClass(class, TRUE, topLvlProdElmObj, structureRelation, quantity, occurrenceIds, vewObject, mfail)

#define ValidateFrozenForSwk(thisObj, leftObj, rightObj, mfail) \
        _ValidateFrozenForSwkAtClass(NULL, FALSE, thisObj, leftObj, rightObj, mfail)
#define ValidateFrozenForSwkAtClass(class, thisObj, leftObj, rightObj, mfail) \
        _ValidateFrozenForSwkAtClass(class, FALSE, thisObj, leftObj, rightObj, mfail)
#define ValidateFrozenForSwkAtParent(class, thisObj, leftObj, rightObj, mfail) \
        _ValidateFrozenForSwkAtClass(class, TRUE, thisObj, leftObj, rightObj, mfail)

#define ValidateObjForRevEff(itemObj, genContextObj, isValid, mfail) \
        _ValidateObjForRevEffAtClass(NULL, FALSE, itemObj, genContextObj, isValid, mfail)
#define ValidateObjForRevEffAtClass(class, itemObj, genContextObj, isValid, mfail) \
        _ValidateObjForRevEffAtClass(class, FALSE, itemObj, genContextObj, isValid, mfail)
#define ValidateObjForRevEffAtParent(class, itemObj, genContextObj, isValid, mfail) \
        _ValidateObjForRevEffAtClass(class, TRUE, itemObj, genContextObj, isValid, mfail)

#define ValidatePrcRev(thisObj, relObj, badArgs, mfail) \
        _ValidatePrcRevAtClass(NULL, FALSE, thisObj, relObj, badArgs, mfail)
#define ValidatePrcRevAtClass(class, thisObj, relObj, badArgs, mfail) \
        _ValidatePrcRevAtClass(class, FALSE, thisObj, relObj, badArgs, mfail)
#define ValidatePrcRevAtParent(class, thisObj, relObj, badArgs, mfail) \
        _ValidatePrcRevAtClass(class, TRUE, thisObj, relObj, badArgs, mfail)
#endif /* for msgapc_H */

