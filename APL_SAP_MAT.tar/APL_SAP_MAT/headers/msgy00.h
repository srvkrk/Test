/*
 *  FILE: msgy00.h
 */

#ifndef msgy00_H
#define msgy00_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

#ifdef _LCINTERP_
}
#else

/*
 *  Unpublished Messages
 */

MTIstatus _y00About
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _y00ConstructClass
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr * classObj, integer * mfail);

MTIstatus _y00ConstructMODeLCmp
   (MTIstring _class, boolean getParent, string classname,
   string name, ObjectPtr * classObj, integer * mfail);

MTIstatus _y00ContractRuleDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _y00DumpAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _y00DumpSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _y00ExpandBrwComponentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr BrcObj,
   integer side, SetOfObjects * otherSideObjSet, SetOfObjects * relObjSet,
   integer * mfail);

MTIstatus _y00ExpandRuleDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _y00FilterRules
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr qrydef, SetOfObjects * ruleSet, integer * mfail);

MTIstatus _y00RemoveGhostDP
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _y00RemoveRedundantDP
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _y00SetDefaultsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr classObj,
   string name, integer * mfail);
/*
 *  Protected Messages
 */
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define y00About(className, mfail) \
        _y00About(className, FALSE, className, mfail)
#define y00AboutAtParent(_class, className, mfail) \
        _y00About(_class, TRUE, className, mfail)

#define y00ConstructClass(classname, classObj, mfail) \
        _y00ConstructClass(classname, FALSE, classname, classObj, mfail)
#define y00ConstructClassAtParent(_class, classname, classObj, mfail) \
        _y00ConstructClass(_class, TRUE, classname, classObj, mfail)

#define y00ConstructMODeLCmp(classname, name, classObj, mfail) \
        _y00ConstructMODeLCmp(classname, FALSE, classname, name, classObj, mfail)
#define y00ConstructMODeLCmpAtParent(_class, classname, name, classObj, mfail) \
        _y00ConstructMODeLCmp(_class, TRUE, classname, name, classObj, mfail)

#define y00ContractRuleDP(thisObj, mfail) \
        _y00ContractRuleDPAtClass(NULL, FALSE, thisObj, mfail)
#define y00ContractRuleDPAtClass(class, thisObj, mfail) \
        _y00ContractRuleDPAtClass(class, FALSE, thisObj, mfail)
#define y00ContractRuleDPAtParent(class, thisObj, mfail) \
        _y00ContractRuleDPAtClass(class, TRUE, thisObj, mfail)

#define y00Dump(thisObj, mfail) \
        _y00DumpAtClass(NULL, FALSE, thisObj, mfail)
#define y00DumpAtClass(class, thisObj, mfail) \
        _y00DumpAtClass(class, FALSE, thisObj, mfail)
#define y00DumpAtParent(class, thisObj, mfail) \
        _y00DumpAtClass(class, TRUE, thisObj, mfail)

#define y00DumpSet(className, SelectedItems, mfail) \
        _y00DumpSet(className, FALSE, className, SelectedItems, mfail)
#define y00DumpSetAtParent(_class, className, SelectedItems, mfail) \
        _y00DumpSet(_class, TRUE, className, SelectedItems, mfail)

#define y00ExpandBrwComponent(BrcObj, side, otherSideObjSet, relObjSet, mfail) \
        _y00ExpandBrwComponentAtClass(NULL, FALSE, BrcObj, side, otherSideObjSet, relObjSet, mfail)
#define y00ExpandBrwComponentAtClass(class, BrcObj, side, otherSideObjSet, relObjSet, mfail) \
        _y00ExpandBrwComponentAtClass(class, FALSE, BrcObj, side, otherSideObjSet, relObjSet, mfail)
#define y00ExpandBrwComponentAtParent(class, BrcObj, side, otherSideObjSet, relObjSet, mfail) \
        _y00ExpandBrwComponentAtClass(class, TRUE, BrcObj, side, otherSideObjSet, relObjSet, mfail)

#define y00ExpandRuleDP(thisObj, mfail) \
        _y00ExpandRuleDPAtClass(NULL, FALSE, thisObj, mfail)
#define y00ExpandRuleDPAtClass(class, thisObj, mfail) \
        _y00ExpandRuleDPAtClass(class, FALSE, thisObj, mfail)
#define y00ExpandRuleDPAtParent(class, thisObj, mfail) \
        _y00ExpandRuleDPAtClass(class, TRUE, thisObj, mfail)

#define y00FilterRules(classname, qrydef, ruleSet, mfail) \
        _y00FilterRules(classname, FALSE, classname, qrydef, ruleSet, mfail)
#define y00FilterRulesAtParent(_class, classname, qrydef, ruleSet, mfail) \
        _y00FilterRules(_class, TRUE, classname, qrydef, ruleSet, mfail)

#define y00RemoveGhostDP(className, mfail) \
        _y00RemoveGhostDP(className, FALSE, className, mfail)
#define y00RemoveGhostDPAtParent(_class, className, mfail) \
        _y00RemoveGhostDP(_class, TRUE, className, mfail)

#define y00RemoveRedundantDP(className, mfail) \
        _y00RemoveRedundantDP(className, FALSE, className, mfail)
#define y00RemoveRedundantDPAtParent(_class, className, mfail) \
        _y00RemoveRedundantDP(_class, TRUE, className, mfail)

#define y00SetDefaults(classObj, name, mfail) \
        _y00SetDefaultsAtClass(NULL, FALSE, classObj, name, mfail)
#define y00SetDefaultsAtClass(class, classObj, name, mfail) \
        _y00SetDefaultsAtClass(class, FALSE, classObj, name, mfail)
#define y00SetDefaultsAtParent(class, classObj, name, mfail) \
        _y00SetDefaultsAtClass(class, TRUE, classObj, name, mfail)
#endif /* for msgy00_H */

