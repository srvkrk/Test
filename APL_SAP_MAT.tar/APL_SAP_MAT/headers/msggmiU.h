/*
 *  FILE: msggmiU.h
 */

#ifndef msggmiU_H
#define msggmiU_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

#ifdef _LCINTERP_
}
#else

/*
 *  Unpublished Messages
 */

MTIstatus _g3AssemblyReadAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   ObjectPtr * ctItemObj, integer * mfail);

MTIstatus _g3BrowseRelDocsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3CatPrdV5Support
   (MTIstring _class, boolean getParent, string className,
   boolean * bCatPrdV5Supp, integer * mfail);

MTIstatus _g3CatPrdV5Workloc
   (MTIstring _class, boolean getParent, string classname,
   string * sCatPrdV5WL, integer * mfail);

MTIstatus _g3CatPrtSupport
   (MTIstring _class, boolean getParent, string className,
   boolean * bCatV5Supp, integer * mfail);

MTIstatus _g3CatV4Support
   (MTIstring _class, boolean getParent, string className,
   boolean * bCatPrdV4Supp, integer * mfail);

MTIstatus _g3CatV5DrwSupport
   (MTIstring _class, boolean getParent, string className,
   boolean * bCatV5DrwSupp, integer * mfail);

MTIstatus _g3CheckExtensionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * extOk, integer * mfail);

MTIstatus _g3CheckIfDocInScopeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr GenItemObj, integer * inScope, integer * mfail);

MTIstatus _g3CheckIfItemInScopeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * inScope, integer * mfail);

MTIstatus _g3CheckIfWBExists
   (MTIstring _class, boolean getParent, string className,
   boolean * exists, integer * mfail);

MTIstatus _g3CheckModels
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * modelSet, SetOfObjects * posSet, integer * mfail);

MTIstatus _g3CheckedOutModels
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects objSet, integer * objNum, integer * mfail);

MTIstatus _g3ChngCommState
   (MTIstring _class, boolean getParent, string className,
   string commState, integer * mfail);

MTIstatus _g3ChooseIconAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer iconNumber, integer * mfail);

MTIstatus _g3CloseGenWB
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _g3CreateDocRepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WorkBnchObj, ObjectPtr * ItemObj, integer * mfail);

MTIstatus _g3CreateGIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WorkBnchObj, ObjectPtr * GIObj, integer * mfail);

MTIstatus _g3CreateGIPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3CreateGIRelationsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr PartObj, ObjectPtr WkBenchObj, ObjectPtr CatiaItemObj,
   ObjectPtr relationObj, ObjectPtr * pNewRelObj, SetOfObjects CatiaModObjSet,
   SetOfObjects ModPosObjSet, ObjectPtr ctxObj, integer * mfail);

MTIstatus _g3CreateItDpRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr CatiaItemObj, ObjectPtr relationObj, ObjectPtr * NewRelObj,
   ObjectPtr ctxObj, integer * mfail);

MTIstatus _g3CreateModRepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WorkBnchObj, ObjectPtr * ItemObj, integer * mfail);

MTIstatus _g3CreateOBIDAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3CreateObject
   (MTIstring _class, boolean getParent, string classOfNewObj,
   ObjectPtr dialogObj, ObjectPtr * newObj, integer * mfail);

MTIstatus _g3CreateRelToModAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr modObj, integer * mfail);

MTIstatus _g3CreateRelToModRepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr modObj, ObjectPtr posObj, ObjectPtr WkBnchObj,
   ObjectPtr * ModRepObj, ObjectPtr * ModRepRelObj, integer * mfail);

MTIstatus _g3CreateRelationObj
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr dialogObj, ObjectPtr leftObject, ObjectPtr rightObject,
   ObjectPtr * relationObject, string attrNameC, integer * mfail);

MTIstatus _g3CreateRootGIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WorkBnchObj, ObjectPtr * GIObj, integer * mfail);

MTIstatus _g3CreateSpecificRelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3CreateTopLevelRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3CreateWidgetIdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3CreateWidgetIds
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects itemSet, integer * mfail);

MTIstatus _g3DelGItoModRepRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3DelMoRFromDoRObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3DelModRepFromCtxObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3DelModRepFromDocRepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr ModRepObj, integer * mfail);

MTIstatus _g3DelModRepFromGenItmAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr ModRepObj, integer * mfail);

MTIstatus _g3DelModRepFromTmpObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3DeleteMultipleObjs
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects objsToDelete, integer * mfail);

MTIstatus _g3DeleteObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3DeleteOldWkBnch
   (MTIstring _class, boolean getParent, string classname,
   integer * mfail);

MTIstatus _g3DeleteRelationObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3DropAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr droppedItemObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _g3DropAllowed
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects SelectedItems, integer * allowed, integer * mfail);

MTIstatus _g3DropOnGenWB
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr backgroundObj, string relationship, string sourceWindowId,
   SetOfObjects droppedItems, integer * mfail);

MTIstatus _g3ExpSelSubsetMulLevelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects droppedPartSet, integer * mfail);

MTIstatus _g3ExpandBranchAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3ExpandBranchMultiAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3ExpandBranchMultiIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string expandInfo, integer * mfail);

MTIstatus _g3ExpandBranchMultiNIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer indicate, boolean bVisuMode, integer * mfail);

MTIstatus _g3ExpandBranchVisuAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3ExpandInWindowAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3ExpandModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3ExpandModelNIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3ExpandMultiLevAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3ExpandOnlyModelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3ExpandRelationCriAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects * otherSideObjSet, SetOfObjects * relObjSet, integer * mfail);

MTIstatus _g3ExpandRelsOfPart
   (MTIstring _class, boolean getParent, string ClassName,
   ObjectPtr object, string relClass, string relShip,
   SetOfObjects * docs, SetOfObjects * docRels, integer * mfail);

MTIstatus _g3ExpandSelectedSubsetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects PosObjects, SetOfObjects SonObjects, integer * mfail);

MTIstatus _g3FilterAllowedItems
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * DroppedItems, integer * mfail);

MTIstatus _g3FilterClgDataWithSeq
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * catalogSet, integer * mfail);

MTIstatus _g3FilterDataWithSeq
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * objectSet, integer * mfail);

MTIstatus _g3FilterDocs
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr GenItemObj, SetOfObjects * docSet, integer * mfail);

MTIstatus _g3FilterDocsInScope
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr GenItemObj, SetOfObjects * docSet, integer * mfail);

MTIstatus _g3FilterDocsWithRev
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * docSet, integer * mfail);

MTIstatus _g3FilterDocsWithSeq
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * docSet, integer * mfail);

MTIstatus _g3FilterHighestSeq
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects IndepBinSet, ObjectPtr * IndepBin, integer * mfail);

MTIstatus _g3FilterItmsOfCrntWkBAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects Items_to_filter, SetOfObjects * Items_in_wkbnch, integer * mfail);

MTIstatus _g3FilterModels
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * modelSet, SetOfObjects * posSet, boolean bVisuMode,
   integer * mfail);

MTIstatus _g3FilterModelsForPubl
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * modSet, SetOfObjects * posSet, integer * mfail);

MTIstatus _g3FilterModelsInScope
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * modSet, SetOfObjects * posSet, integer * mfail);

MTIstatus _g3FilterModelsWithSeq
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * modSet, SetOfObjects * posSet, integer * mfail);

MTIstatus _g3FilterModelsWithType
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * modSet, SetOfObjects * posSet, boolean bVisuMode,
   integer * mfail);

MTIstatus _g3FilterPrcDataWithSeq
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * processSet, integer * mfail);

MTIstatus _g3FilterPrdDataWithSeq
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * productSet, integer * mfail);

MTIstatus _g3FindRelevantDocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer DocType, ObjectPtr * RelevDoc, integer * mfail);

MTIstatus _g3GetAllDocsOfPart
   (MTIstring _class, boolean getParent, string ClassName,
   ObjectPtr PartObj, ObjectPtr GenItemObj, SetOfObjects * docs,
   integer * mfail);

MTIstatus _g3GetAllModelsOfDoc
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr this, ObjectPtr WorkBnchObj, SetOfObjects * modelSet,
   SetOfObjects * posSet, integer * mfail);

MTIstatus _g3GetAllModelsOfDocCus
   (MTIstring _class, boolean getParent, string classname,
   string expandInfo, ObjectPtr this, ObjectPtr WorkBnchObj,
   SetOfObjects * modelSet, SetOfObjects * posSet, integer * mfail);

MTIstatus _g3GetAllProcessFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr WorkBnchObj, ObjectPtr GenItemObj, SetOfObjects * processesOfPart,
   integer * mfail);

MTIstatus _g3GetAndFilterModelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WorkBnchObj, ObjectPtr GenItemObj, string NeededClass,
   SetOfObjects * modelsOfPart, SetOfObjects * posOfPart, integer * mfail);

MTIstatus _g3GetBlackBoxDocumentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr * pBlackBoxDoc, integer * mfail);

MTIstatus _g3GetBlackBoxFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   SetOfObjects * pBlackBoxObjs, SetOfObjects * pBlackBoxRels, integer * mfail);

MTIstatus _g3GetClassOfWkBnchItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WorkBnchObj, string * WkBnchItem, integer * mfail);

MTIstatus _g3GetDocFromDocRepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr * DocObj, integer * mfail);

MTIstatus _g3GetDocOfModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr * objDoc, integer * mfail);

MTIstatus _g3GetDocsOfPartInScope
   (MTIstring _class, boolean getParent, string ClassName,
   ObjectPtr PartObj, ObjectPtr GenItemObj, SetOfObjects * docs,
   integer * mfail);

MTIstatus _g3GetDocumentNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string * sDocumentName, integer * mfail);

MTIstatus _g3GetDynamicObject
   (MTIstring _class, boolean getParent, string classname,
   string obid, ObjectPtr * itemObj, ObjectPtr * relObj,
   integer * mfail);

MTIstatus _g3GetExpandLevel
   (MTIstring _class, boolean getParent, string className,
   integer * expLevel, integer * mfail);

MTIstatus _g3GetInstanceDescriptAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, string * sInstDescript, integer * mfail);

MTIstatus _g3GetInstanceNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * sInstanceName, integer * mfail);

MTIstatus _g3GetMaxExpLevel
   (MTIstring _class, boolean getParent, string ClassName,
   integer * ExpLevel, integer * mfail);

MTIstatus _g3GetModelFromModelRepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ModRepObj,
   ObjectPtr * modelOfItem, integer * mfail);

MTIstatus _g3GetModelsAndModRepsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr GenItemObj,
   SetOfObjects * modelsOfPart, SetOfObjects * ModRepObjSet, integer * mfail);

MTIstatus _g3GetModelsForDisplayAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WorkBnchObj, ObjectPtr GenItemObj, SetOfObjects * modelsOfPart,
   SetOfObjects * posOfPart, boolean * p_bShowFlag, boolean bVisuMode,
   integer * mfail);

MTIstatus _g3GetModelsViaModRepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr GenItemObj,
   SetOfObjects * modelsOfPart, integer * mfail);

MTIstatus _g3GetObjViaObidAndDB
   (MTIstring _class, boolean getParent, string className,
   string ClassOfObjToBeFound, string obid, string databaseName,
   string relclassname, string relationshipname, string relobid,
   ObjectPtr * itemObj, ObjectPtr * relObj, integer * mfail);

MTIstatus _g3GetObjectViaObid
   (MTIstring _class, boolean getParent, string className,
   string ClassOfObjToBeFound, string obid, string relclassname,
   string relationshipname, string relobid, ObjectPtr * itemObj,
   ObjectPtr * relObj, integer * mfail);

MTIstatus _g3GetOccNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string * OccName, integer * mfail);

MTIstatus _g3GetParentParts
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects sourcePartSet, SetOfObjects * currentExpandObjSet, SetOfObjects * currentExpandRelObjSet,
   integer * mfail);

MTIstatus _g3GetPartFromGenItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr * PartObj, integer * mfail);

MTIstatus _g3GetPartsInAssSet
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects assObjSet, SetOfObjects * partsInAss, SetOfObjects * partRels,
   integer * mfail);

MTIstatus _g3GetPartsInAssSetCus
   (MTIstring _class, boolean getParent, string classname,
   string expandInfo, SetOfObjects assObjSet, SetOfObjects * partsInAss,
   SetOfObjects * partRels, integer * mfail);

MTIstatus _g3GetPartsInAssembly
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr assObj, SetOfObjects * partsInAss, SetOfObjects * partRels,
   integer * mfail);

MTIstatus _g3GetPartsInAssemblyCu
   (MTIstring _class, boolean getParent, string classname,
   string expandInfo, ObjectPtr assObj, SetOfObjects * partsInAss,
   SetOfObjects * partRels, integer * mfail);

MTIstatus _g3GetPortAndHost
   (MTIstring _class, boolean getParent, string ClassName,
   string * Host, string * HostIp, string * Port,
   integer * mfail);

MTIstatus _g3GetPrdPartFrGenItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr * PartObj, integer * mfail);

MTIstatus _g3GetProcessFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr WorkBnchObj, SetOfObjects * processesOfPart, integer * mfail);

MTIstatus _g3GetProductDocumentsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr WorkBnchObj, SetOfObjects * productsOfPart, integer * mfail);

MTIstatus _g3GetProductFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr WorkBnchObj, SetOfObjects * productsOfPart, integer * mfail);

MTIstatus _g3GetProductInfo
   (MTIstring _class, boolean getParent, string className,
   string * vProductInfo, integer * mfail);

MTIstatus _g3GetQuantityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * sQuantity, integer * mfail);

MTIstatus _g3GetRelatedModelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WorkBnchObj, ObjectPtr GenItemObj, SetOfObjects * modelsOfPart,
   SetOfObjects * posOfPart, boolean bVisuMode, integer * mfail);

MTIstatus _g3GetRelevantRelOBID
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr this, string * relationOBID, integer * mfail);

MTIstatus _g3GetRelevantSonObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects DroppedObjects, SetOfObjects * SonObjects, SetOfObjects * PosObjects,
   integer * mfail);

MTIstatus _g3GetRemRelevRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr assmObj,
   ObjectPtr itemRel, ObjectPtr * itemObj, ObjectPtr * relevRelObj,
   integer * mfail);

MTIstatus _g3GetRootItem
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr * pRootItemObj, integer * mfail);

MTIstatus _g3GetShowModelsFlag
   (MTIstring _class, boolean getParent, string classname,
   string showModelFlag, boolean * bShow, integer * mfail);

MTIstatus _g3GetSwapFlag
   (MTIstring _class, boolean getParent, string classname,
   string modelOBID, string * swapFlag, integer * mfail);

MTIstatus _g3GetTempItem
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr * pRootItemObj, integer * mfail);

MTIstatus _g3GetTrafoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings * valueSet, integer * mfail);

MTIstatus _g3GetWBClassFrmItmAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string * className, integer * mfail);

MTIstatus _g3GetWBSysVars
   (MTIstring _class, boolean getParent, string classname,
   string * winId, integer * mfail);

MTIstatus _g3GlobPtrDel
   (MTIstring _class, boolean getParent, string className,
   string objName, integer * mfail);

MTIstatus _g3GlobPtrGet
   (MTIstring _class, boolean getParent, string className,
   string objName, ObjectPtr * objPtr, integer * mfail);

MTIstatus _g3GlobPtrPut
   (MTIstring _class, boolean getParent, string className,
   string objName, ObjectPtr objPtr, integer * mfail);

MTIstatus _g3GlobVarGet
   (MTIstring _class, boolean getParent, string className,
   string objName, string attribute, string * value,
   integer * mfail);

MTIstatus _g3GlobVarPut
   (MTIstring _class, boolean getParent, string className,
   string objName, string attribute, string value,
   integer * mfail);

MTIstatus _g3HasVisualization
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects modelSet, SetOfObjects posSet, boolean * bHasVisualization,
   integer * mfail);

MTIstatus _g3HelpOnProduct
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _g3HideAllModelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3HideAllSubBranchesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects objsToDelete, integer * mfail);

MTIstatus _g3HideThisBranchAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3HideThisBranchNIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer indicate, integer * mfail);

MTIstatus _g3HideThisDocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3HideThisModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _g3HideThisModelNIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3IsProcessElementAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr WorkBnchObj, boolean * bIsProcessElement, integer * mfail);

MTIstatus _g3IsProductViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr WorkBnchObj, boolean * bIsProductView, integer * mfail);

MTIstatus _g3IsResourceViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr WorkBnchObj, boolean * bIsResourceView, integer * mfail);

MTIstatus _g3IsVisualizationAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * bIsVisualization, integer * mfail);

MTIstatus _g3LaunchWbnch
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _g3LaunchWbnchObject
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr * BrowserItem, ObjectPtr * BackgroundItem, integer * mfail);

MTIstatus _g3PermsOfItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * perm1, integer * mfail);

MTIstatus _g3ProcessDroppedItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _g3ProcessGIMultiAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer level, ObjectPtr ctitem_obj, SetOfStrings asmPath,
   ObjectPtr WkBnchObj, ObjectPtr ctxObj, boolean bVisuMode,
   integer * mfail);

MTIstatus _g3ProcessGISetMulti
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfObjects Parts, integer level, SetOfObjects ctitem_objs,
   ObjectPtr WkBnchObj, ObjectPtr ctxObj, boolean bVisuMode,
   integer * mfail);

MTIstatus _g3ProcessGISingleAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr ctitem_obj, ObjectPtr WkBnchObj, ObjectPtr ctxObj,
   integer * mfail);

MTIstatus _g3ReStoreCtx
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr * ctxObj, integer * mfail);

MTIstatus _g3RemoveBlackBoxObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * modelSet, SetOfObjects * posSet, integer * mfail);

MTIstatus _g3SetAttrsFromRelationAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr Relation, integer * mfail);

MTIstatus _g3SetBasedAllowedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean * bAllowed, integer * mfail);

MTIstatus _g3SetCheckDefaultAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, SetOfObjects * models, integer * mfail);

MTIstatus _g3SetCommVars
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _g3SetDroppedOnGenWB
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects SelectedItems, ObjectPtr WkBnchObj, ObjectPtr commObj,
   ObjectPtr BackgroundItem, integer * mfail);

MTIstatus _g3SetGIAttrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr PartObj, integer * mfail);

MTIstatus _g3SetGIAttrsPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr PartObj, integer * mfail);

MTIstatus _g3SetGIPartNumberAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr * GIObj, integer * mfail);

MTIstatus _g3SetGIRelAttrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr RelObj, integer * mfail);

MTIstatus _g3SetInstanceNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string sInstanceName, integer * mfail);

MTIstatus _g3SetOccNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string OccName, integer * mfail);

MTIstatus _g3SetSpecificAttrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ModRepObj,
   ObjectPtr modObj, integer * mfail);

MTIstatus _g3SetSwapFlag
   (MTIstring _class, boolean getParent, string classname,
   string modelOBID, string swapFlag, integer * mfail);

MTIstatus _g3StoreCtx
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr ctxObj, integer * mfail);

MTIstatus _g3SupplyObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean supplyFlag, ObjectPtr * supplyVL, ObjectPtr * pSupCpy,
   integer * mfail);

MTIstatus _g3ToggleShowModels
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _g3UpdateObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr ctxObj, integer * mfail);

MTIstatus _g3UpdateTrafoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings rcvstr, integer * mfail);

MTIstatus _g3ValForUpdTrafoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _g3ValidateForExpandAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr genContextObj, integer * mfail);

MTIstatus _x3IsComponentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr PartObj,
   boolean * bIsComponent, integer * mfail);
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define g3AssemblyRead(this, WkBnchObj, commObj, BackgroundItem, ctItemObj, mfail) \
        _g3AssemblyReadAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, ctItemObj, mfail)
#define g3AssemblyReadAtClass(class, this, WkBnchObj, commObj, BackgroundItem, ctItemObj, mfail) \
        _g3AssemblyReadAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, ctItemObj, mfail)
#define g3AssemblyReadAtParent(class, this, WkBnchObj, commObj, BackgroundItem, ctItemObj, mfail) \
        _g3AssemblyReadAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, ctItemObj, mfail)

#define g3BrowseRelDocs(thisObj, mfail) \
        _g3BrowseRelDocsAtClass(NULL, FALSE, thisObj, mfail)
#define g3BrowseRelDocsAtClass(class, thisObj, mfail) \
        _g3BrowseRelDocsAtClass(class, FALSE, thisObj, mfail)
#define g3BrowseRelDocsAtParent(class, thisObj, mfail) \
        _g3BrowseRelDocsAtClass(class, TRUE, thisObj, mfail)

#define g3CatPrdV5Support(className, bCatPrdV5Supp, mfail) \
        _g3CatPrdV5Support(className, FALSE, className, bCatPrdV5Supp, mfail)
#define g3CatPrdV5SupportAtParent(_class, className, bCatPrdV5Supp, mfail) \
        _g3CatPrdV5Support(_class, TRUE, className, bCatPrdV5Supp, mfail)

#define g3CatPrdV5Workloc(classname, sCatPrdV5WL, mfail) \
        _g3CatPrdV5Workloc(classname, FALSE, classname, sCatPrdV5WL, mfail)
#define g3CatPrdV5WorklocAtParent(_class, classname, sCatPrdV5WL, mfail) \
        _g3CatPrdV5Workloc(_class, TRUE, classname, sCatPrdV5WL, mfail)

#define g3CatPrtSupport(className, bCatV5Supp, mfail) \
        _g3CatPrtSupport(className, FALSE, className, bCatV5Supp, mfail)
#define g3CatPrtSupportAtParent(_class, className, bCatV5Supp, mfail) \
        _g3CatPrtSupport(_class, TRUE, className, bCatV5Supp, mfail)

#define g3CatV4Support(className, bCatPrdV4Supp, mfail) \
        _g3CatV4Support(className, FALSE, className, bCatPrdV4Supp, mfail)
#define g3CatV4SupportAtParent(_class, className, bCatPrdV4Supp, mfail) \
        _g3CatV4Support(_class, TRUE, className, bCatPrdV4Supp, mfail)

#define g3CatV5DrwSupport(className, bCatV5DrwSupp, mfail) \
        _g3CatV5DrwSupport(className, FALSE, className, bCatV5DrwSupp, mfail)
#define g3CatV5DrwSupportAtParent(_class, className, bCatV5DrwSupp, mfail) \
        _g3CatV5DrwSupport(_class, TRUE, className, bCatV5DrwSupp, mfail)

#define g3CheckExtension(this, extOk, mfail) \
        _g3CheckExtensionAtClass(NULL, FALSE, this, extOk, mfail)
#define g3CheckExtensionAtClass(class, this, extOk, mfail) \
        _g3CheckExtensionAtClass(class, FALSE, this, extOk, mfail)
#define g3CheckExtensionAtParent(class, this, extOk, mfail) \
        _g3CheckExtensionAtClass(class, TRUE, this, extOk, mfail)

#define g3CheckIfDocInScope(this, GenItemObj, inScope, mfail) \
        _g3CheckIfDocInScopeAtClass(NULL, FALSE, this, GenItemObj, inScope, mfail)
#define g3CheckIfDocInScopeAtClass(class, this, GenItemObj, inScope, mfail) \
        _g3CheckIfDocInScopeAtClass(class, FALSE, this, GenItemObj, inScope, mfail)
#define g3CheckIfDocInScopeAtParent(class, this, GenItemObj, inScope, mfail) \
        _g3CheckIfDocInScopeAtClass(class, TRUE, this, GenItemObj, inScope, mfail)

#define g3CheckIfItemInScope(this, inScope, mfail) \
        _g3CheckIfItemInScopeAtClass(NULL, FALSE, this, inScope, mfail)
#define g3CheckIfItemInScopeAtClass(class, this, inScope, mfail) \
        _g3CheckIfItemInScopeAtClass(class, FALSE, this, inScope, mfail)
#define g3CheckIfItemInScopeAtParent(class, this, inScope, mfail) \
        _g3CheckIfItemInScopeAtClass(class, TRUE, this, inScope, mfail)

#define g3CheckIfWBExists(className, exists, mfail) \
        _g3CheckIfWBExists(className, FALSE, className, exists, mfail)
#define g3CheckIfWBExistsAtParent(_class, className, exists, mfail) \
        _g3CheckIfWBExists(_class, TRUE, className, exists, mfail)

#define g3CheckModels(classname, modelSet, posSet, mfail) \
        _g3CheckModels(classname, FALSE, classname, modelSet, posSet, mfail)
#define g3CheckModelsAtParent(_class, classname, modelSet, posSet, mfail) \
        _g3CheckModels(_class, TRUE, classname, modelSet, posSet, mfail)

#define g3CheckedOutModels(classname, objSet, objNum, mfail) \
        _g3CheckedOutModels(classname, FALSE, classname, objSet, objNum, mfail)
#define g3CheckedOutModelsAtParent(_class, classname, objSet, objNum, mfail) \
        _g3CheckedOutModels(_class, TRUE, classname, objSet, objNum, mfail)

#define g3ChngCommState(className, commState, mfail) \
        _g3ChngCommState(className, FALSE, className, commState, mfail)
#define g3ChngCommStateAtParent(_class, className, commState, mfail) \
        _g3ChngCommState(_class, TRUE, className, commState, mfail)

#define g3ChooseIcon(this, iconNumber, mfail) \
        _g3ChooseIconAtClass(NULL, FALSE, this, iconNumber, mfail)
#define g3ChooseIconAtClass(class, this, iconNumber, mfail) \
        _g3ChooseIconAtClass(class, FALSE, this, iconNumber, mfail)
#define g3ChooseIconAtParent(class, this, iconNumber, mfail) \
        _g3ChooseIconAtClass(class, TRUE, this, iconNumber, mfail)

#define g3CloseGenWB(className, mfail) \
        _g3CloseGenWB(className, FALSE, className, mfail)
#define g3CloseGenWBAtParent(_class, className, mfail) \
        _g3CloseGenWB(_class, TRUE, className, mfail)

#define g3CreateDocRep(this, WorkBnchObj, ItemObj, mfail) \
        _g3CreateDocRepAtClass(NULL, FALSE, this, WorkBnchObj, ItemObj, mfail)
#define g3CreateDocRepAtClass(class, this, WorkBnchObj, ItemObj, mfail) \
        _g3CreateDocRepAtClass(class, FALSE, this, WorkBnchObj, ItemObj, mfail)
#define g3CreateDocRepAtParent(class, this, WorkBnchObj, ItemObj, mfail) \
        _g3CreateDocRepAtClass(class, TRUE, this, WorkBnchObj, ItemObj, mfail)

#define g3CreateGI(this, WorkBnchObj, GIObj, mfail) \
        _g3CreateGIAtClass(NULL, FALSE, this, WorkBnchObj, GIObj, mfail)
#define g3CreateGIAtClass(class, this, WorkBnchObj, GIObj, mfail) \
        _g3CreateGIAtClass(class, FALSE, this, WorkBnchObj, GIObj, mfail)
#define g3CreateGIAtParent(class, this, WorkBnchObj, GIObj, mfail) \
        _g3CreateGIAtClass(class, TRUE, this, WorkBnchObj, GIObj, mfail)

#define g3CreateGIPost(this, mfail) \
        _g3CreateGIPostAtClass(NULL, FALSE, this, mfail)
#define g3CreateGIPostAtClass(class, this, mfail) \
        _g3CreateGIPostAtClass(class, FALSE, this, mfail)
#define g3CreateGIPostAtParent(class, this, mfail) \
        _g3CreateGIPostAtClass(class, TRUE, this, mfail)

#define g3CreateGIRelations(this, PartObj, WkBenchObj, CatiaItemObj, relationObj, pNewRelObj, CatiaModObjSet, ModPosObjSet, ctxObj, mfail) \
        _g3CreateGIRelationsAtClass(NULL, FALSE, this, PartObj, WkBenchObj, CatiaItemObj, relationObj, pNewRelObj, CatiaModObjSet, ModPosObjSet, ctxObj, mfail)
#define g3CreateGIRelationsAtClass(class, this, PartObj, WkBenchObj, CatiaItemObj, relationObj, pNewRelObj, CatiaModObjSet, ModPosObjSet, ctxObj, mfail) \
        _g3CreateGIRelationsAtClass(class, FALSE, this, PartObj, WkBenchObj, CatiaItemObj, relationObj, pNewRelObj, CatiaModObjSet, ModPosObjSet, ctxObj, mfail)
#define g3CreateGIRelationsAtParent(class, this, PartObj, WkBenchObj, CatiaItemObj, relationObj, pNewRelObj, CatiaModObjSet, ModPosObjSet, ctxObj, mfail) \
        _g3CreateGIRelationsAtClass(class, TRUE, this, PartObj, WkBenchObj, CatiaItemObj, relationObj, pNewRelObj, CatiaModObjSet, ModPosObjSet, ctxObj, mfail)

#define g3CreateItDpRel(this, CatiaItemObj, relationObj, NewRelObj, ctxObj, mfail) \
        _g3CreateItDpRelAtClass(NULL, FALSE, this, CatiaItemObj, relationObj, NewRelObj, ctxObj, mfail)
#define g3CreateItDpRelAtClass(class, this, CatiaItemObj, relationObj, NewRelObj, ctxObj, mfail) \
        _g3CreateItDpRelAtClass(class, FALSE, this, CatiaItemObj, relationObj, NewRelObj, ctxObj, mfail)
#define g3CreateItDpRelAtParent(class, this, CatiaItemObj, relationObj, NewRelObj, ctxObj, mfail) \
        _g3CreateItDpRelAtClass(class, TRUE, this, CatiaItemObj, relationObj, NewRelObj, ctxObj, mfail)

#define g3CreateModRep(this, WorkBnchObj, ItemObj, mfail) \
        _g3CreateModRepAtClass(NULL, FALSE, this, WorkBnchObj, ItemObj, mfail)
#define g3CreateModRepAtClass(class, this, WorkBnchObj, ItemObj, mfail) \
        _g3CreateModRepAtClass(class, FALSE, this, WorkBnchObj, ItemObj, mfail)
#define g3CreateModRepAtParent(class, this, WorkBnchObj, ItemObj, mfail) \
        _g3CreateModRepAtClass(class, TRUE, this, WorkBnchObj, ItemObj, mfail)

#define g3CreateOBID(this, mfail) \
        _g3CreateOBIDAtClass(NULL, FALSE, this, mfail)
#define g3CreateOBIDAtClass(class, this, mfail) \
        _g3CreateOBIDAtClass(class, FALSE, this, mfail)
#define g3CreateOBIDAtParent(class, this, mfail) \
        _g3CreateOBIDAtClass(class, TRUE, this, mfail)

#define g3CreateObject(classOfNewObj, dialogObj, newObj, mfail) \
        _g3CreateObject(classOfNewObj, FALSE, classOfNewObj, dialogObj, newObj, mfail)
#define g3CreateObjectAtParent(_class, classOfNewObj, dialogObj, newObj, mfail) \
        _g3CreateObject(_class, TRUE, classOfNewObj, dialogObj, newObj, mfail)

#define g3CreateRelToMod(this, modObj, mfail) \
        _g3CreateRelToModAtClass(NULL, FALSE, this, modObj, mfail)
#define g3CreateRelToModAtClass(class, this, modObj, mfail) \
        _g3CreateRelToModAtClass(class, FALSE, this, modObj, mfail)
#define g3CreateRelToModAtParent(class, this, modObj, mfail) \
        _g3CreateRelToModAtClass(class, TRUE, this, modObj, mfail)

#define g3CreateRelToModRep(this, modObj, posObj, WkBnchObj, ModRepObj, ModRepRelObj, mfail) \
        _g3CreateRelToModRepAtClass(NULL, FALSE, this, modObj, posObj, WkBnchObj, ModRepObj, ModRepRelObj, mfail)
#define g3CreateRelToModRepAtClass(class, this, modObj, posObj, WkBnchObj, ModRepObj, ModRepRelObj, mfail) \
        _g3CreateRelToModRepAtClass(class, FALSE, this, modObj, posObj, WkBnchObj, ModRepObj, ModRepRelObj, mfail)
#define g3CreateRelToModRepAtParent(class, this, modObj, posObj, WkBnchObj, ModRepObj, ModRepRelObj, mfail) \
        _g3CreateRelToModRepAtClass(class, TRUE, this, modObj, posObj, WkBnchObj, ModRepObj, ModRepRelObj, mfail)

#define g3CreateRelationObj(className, dialogObj, leftObject, rightObject, relationObject, attrNameC, mfail) \
        _g3CreateRelationObj(className, FALSE, className, dialogObj, leftObject, rightObject, relationObject, attrNameC, mfail)
#define g3CreateRelationObjAtParent(_class, className, dialogObj, leftObject, rightObject, relationObject, attrNameC, mfail) \
        _g3CreateRelationObj(_class, TRUE, className, dialogObj, leftObject, rightObject, relationObject, attrNameC, mfail)

#define g3CreateRootGI(this, WorkBnchObj, GIObj, mfail) \
        _g3CreateRootGIAtClass(NULL, FALSE, this, WorkBnchObj, GIObj, mfail)
#define g3CreateRootGIAtClass(class, this, WorkBnchObj, GIObj, mfail) \
        _g3CreateRootGIAtClass(class, FALSE, this, WorkBnchObj, GIObj, mfail)
#define g3CreateRootGIAtParent(class, this, WorkBnchObj, GIObj, mfail) \
        _g3CreateRootGIAtClass(class, TRUE, this, WorkBnchObj, GIObj, mfail)

#define g3CreateSpecificRels(this, mfail) \
        _g3CreateSpecificRelsAtClass(NULL, FALSE, this, mfail)
#define g3CreateSpecificRelsAtClass(class, this, mfail) \
        _g3CreateSpecificRelsAtClass(class, FALSE, this, mfail)
#define g3CreateSpecificRelsAtParent(class, this, mfail) \
        _g3CreateSpecificRelsAtClass(class, TRUE, this, mfail)

#define g3CreateTopLevelRel(this, mfail) \
        _g3CreateTopLevelRelAtClass(NULL, FALSE, this, mfail)
#define g3CreateTopLevelRelAtClass(class, this, mfail) \
        _g3CreateTopLevelRelAtClass(class, FALSE, this, mfail)
#define g3CreateTopLevelRelAtParent(class, this, mfail) \
        _g3CreateTopLevelRelAtClass(class, TRUE, this, mfail)

#define g3CreateWidgetId(this, mfail) \
        _g3CreateWidgetIdAtClass(NULL, FALSE, this, mfail)
#define g3CreateWidgetIdAtClass(class, this, mfail) \
        _g3CreateWidgetIdAtClass(class, FALSE, this, mfail)
#define g3CreateWidgetIdAtParent(class, this, mfail) \
        _g3CreateWidgetIdAtClass(class, TRUE, this, mfail)

#define g3CreateWidgetIds(className, itemSet, mfail) \
        _g3CreateWidgetIds(className, FALSE, className, itemSet, mfail)
#define g3CreateWidgetIdsAtParent(_class, className, itemSet, mfail) \
        _g3CreateWidgetIds(_class, TRUE, className, itemSet, mfail)

#define g3DelGItoModRepRel(thisObj, mfail) \
        _g3DelGItoModRepRelAtClass(NULL, FALSE, thisObj, mfail)
#define g3DelGItoModRepRelAtClass(class, thisObj, mfail) \
        _g3DelGItoModRepRelAtClass(class, FALSE, thisObj, mfail)
#define g3DelGItoModRepRelAtParent(class, thisObj, mfail) \
        _g3DelGItoModRepRelAtClass(class, TRUE, thisObj, mfail)

#define g3DelMoRFromDoRObj(this, mfail) \
        _g3DelMoRFromDoRObjAtClass(NULL, FALSE, this, mfail)
#define g3DelMoRFromDoRObjAtClass(class, this, mfail) \
        _g3DelMoRFromDoRObjAtClass(class, FALSE, this, mfail)
#define g3DelMoRFromDoRObjAtParent(class, this, mfail) \
        _g3DelMoRFromDoRObjAtClass(class, TRUE, this, mfail)

#define g3DelModRepFromCtxObj(this, mfail) \
        _g3DelModRepFromCtxObjAtClass(NULL, FALSE, this, mfail)
#define g3DelModRepFromCtxObjAtClass(class, this, mfail) \
        _g3DelModRepFromCtxObjAtClass(class, FALSE, this, mfail)
#define g3DelModRepFromCtxObjAtParent(class, this, mfail) \
        _g3DelModRepFromCtxObjAtClass(class, TRUE, this, mfail)

#define g3DelModRepFromDocRep(this, ModRepObj, mfail) \
        _g3DelModRepFromDocRepAtClass(NULL, FALSE, this, ModRepObj, mfail)
#define g3DelModRepFromDocRepAtClass(class, this, ModRepObj, mfail) \
        _g3DelModRepFromDocRepAtClass(class, FALSE, this, ModRepObj, mfail)
#define g3DelModRepFromDocRepAtParent(class, this, ModRepObj, mfail) \
        _g3DelModRepFromDocRepAtClass(class, TRUE, this, ModRepObj, mfail)

#define g3DelModRepFromGenItm(this, ModRepObj, mfail) \
        _g3DelModRepFromGenItmAtClass(NULL, FALSE, this, ModRepObj, mfail)
#define g3DelModRepFromGenItmAtClass(class, this, ModRepObj, mfail) \
        _g3DelModRepFromGenItmAtClass(class, FALSE, this, ModRepObj, mfail)
#define g3DelModRepFromGenItmAtParent(class, this, ModRepObj, mfail) \
        _g3DelModRepFromGenItmAtClass(class, TRUE, this, ModRepObj, mfail)

#define g3DelModRepFromTmpObj(this, mfail) \
        _g3DelModRepFromTmpObjAtClass(NULL, FALSE, this, mfail)
#define g3DelModRepFromTmpObjAtClass(class, this, mfail) \
        _g3DelModRepFromTmpObjAtClass(class, FALSE, this, mfail)
#define g3DelModRepFromTmpObjAtParent(class, this, mfail) \
        _g3DelModRepFromTmpObjAtClass(class, TRUE, this, mfail)

#define g3DeleteMultipleObjs(className, objsToDelete, mfail) \
        _g3DeleteMultipleObjs(className, FALSE, className, objsToDelete, mfail)
#define g3DeleteMultipleObjsAtParent(_class, className, objsToDelete, mfail) \
        _g3DeleteMultipleObjs(_class, TRUE, className, objsToDelete, mfail)

#define g3DeleteObject(thisObj, mfail) \
        _g3DeleteObjectAtClass(NULL, FALSE, thisObj, mfail)
#define g3DeleteObjectAtClass(class, thisObj, mfail) \
        _g3DeleteObjectAtClass(class, FALSE, thisObj, mfail)
#define g3DeleteObjectAtParent(class, thisObj, mfail) \
        _g3DeleteObjectAtClass(class, TRUE, thisObj, mfail)

#define g3DeleteOldWkBnch(classname, mfail) \
        _g3DeleteOldWkBnch(classname, FALSE, classname, mfail)
#define g3DeleteOldWkBnchAtParent(_class, classname, mfail) \
        _g3DeleteOldWkBnch(_class, TRUE, classname, mfail)

#define g3DeleteRelationObject(thisObj, mfail) \
        _g3DeleteRelationObjectAtClass(NULL, FALSE, thisObj, mfail)
#define g3DeleteRelationObjectAtClass(class, thisObj, mfail) \
        _g3DeleteRelationObjectAtClass(class, FALSE, thisObj, mfail)
#define g3DeleteRelationObjectAtParent(class, thisObj, mfail) \
        _g3DeleteRelationObjectAtClass(class, TRUE, thisObj, mfail)

#define g3Drop(this, droppedItemObj, commObj, BackgroundItem, mfail) \
        _g3DropAtClass(NULL, FALSE, this, droppedItemObj, commObj, BackgroundItem, mfail)
#define g3DropAtClass(class, this, droppedItemObj, commObj, BackgroundItem, mfail) \
        _g3DropAtClass(class, FALSE, this, droppedItemObj, commObj, BackgroundItem, mfail)
#define g3DropAtParent(class, this, droppedItemObj, commObj, BackgroundItem, mfail) \
        _g3DropAtClass(class, TRUE, this, droppedItemObj, commObj, BackgroundItem, mfail)

#define g3DropAllowed(classname, SelectedItems, allowed, mfail) \
        _g3DropAllowed(classname, FALSE, classname, SelectedItems, allowed, mfail)
#define g3DropAllowedAtParent(_class, classname, SelectedItems, allowed, mfail) \
        _g3DropAllowed(_class, TRUE, classname, SelectedItems, allowed, mfail)

#define g3DropOnGenWB(className, backgroundObj, relationship, sourceWindowId, droppedItems, mfail) \
        _g3DropOnGenWB(className, FALSE, className, backgroundObj, relationship, sourceWindowId, droppedItems, mfail)
#define g3DropOnGenWBAtParent(_class, className, backgroundObj, relationship, sourceWindowId, droppedItems, mfail) \
        _g3DropOnGenWB(_class, TRUE, className, backgroundObj, relationship, sourceWindowId, droppedItems, mfail)

#define g3ExpSelSubsetMulLevel(this, droppedPartSet, mfail) \
        _g3ExpSelSubsetMulLevelAtClass(NULL, FALSE, this, droppedPartSet, mfail)
#define g3ExpSelSubsetMulLevelAtClass(class, this, droppedPartSet, mfail) \
        _g3ExpSelSubsetMulLevelAtClass(class, FALSE, this, droppedPartSet, mfail)
#define g3ExpSelSubsetMulLevelAtParent(class, this, droppedPartSet, mfail) \
        _g3ExpSelSubsetMulLevelAtClass(class, TRUE, this, droppedPartSet, mfail)

#define g3ExpandBranch(thisObj, mfail) \
        _g3ExpandBranchAtClass(NULL, FALSE, thisObj, mfail)
#define g3ExpandBranchAtClass(class, thisObj, mfail) \
        _g3ExpandBranchAtClass(class, FALSE, thisObj, mfail)
#define g3ExpandBranchAtParent(class, thisObj, mfail) \
        _g3ExpandBranchAtClass(class, TRUE, thisObj, mfail)

#define g3ExpandBranchMulti(thisObj, mfail) \
        _g3ExpandBranchMultiAtClass(NULL, FALSE, thisObj, mfail)
#define g3ExpandBranchMultiAtClass(class, thisObj, mfail) \
        _g3ExpandBranchMultiAtClass(class, FALSE, thisObj, mfail)
#define g3ExpandBranchMultiAtParent(class, thisObj, mfail) \
        _g3ExpandBranchMultiAtClass(class, TRUE, thisObj, mfail)

#define g3ExpandBranchMultiInt(this, expandInfo, mfail) \
        _g3ExpandBranchMultiIntAtClass(NULL, FALSE, this, expandInfo, mfail)
#define g3ExpandBranchMultiIntAtClass(class, this, expandInfo, mfail) \
        _g3ExpandBranchMultiIntAtClass(class, FALSE, this, expandInfo, mfail)
#define g3ExpandBranchMultiIntAtParent(class, this, expandInfo, mfail) \
        _g3ExpandBranchMultiIntAtClass(class, TRUE, this, expandInfo, mfail)

#define g3ExpandBranchMultiNI(this, indicate, bVisuMode, mfail) \
        _g3ExpandBranchMultiNIAtClass(NULL, FALSE, this, indicate, bVisuMode, mfail)
#define g3ExpandBranchMultiNIAtClass(class, this, indicate, bVisuMode, mfail) \
        _g3ExpandBranchMultiNIAtClass(class, FALSE, this, indicate, bVisuMode, mfail)
#define g3ExpandBranchMultiNIAtParent(class, this, indicate, bVisuMode, mfail) \
        _g3ExpandBranchMultiNIAtClass(class, TRUE, this, indicate, bVisuMode, mfail)

#define g3ExpandBranchVisu(thisObj, mfail) \
        _g3ExpandBranchVisuAtClass(NULL, FALSE, thisObj, mfail)
#define g3ExpandBranchVisuAtClass(class, thisObj, mfail) \
        _g3ExpandBranchVisuAtClass(class, FALSE, thisObj, mfail)
#define g3ExpandBranchVisuAtParent(class, thisObj, mfail) \
        _g3ExpandBranchVisuAtClass(class, TRUE, thisObj, mfail)

#define g3ExpandInWindow(thisObj, mfail) \
        _g3ExpandInWindowAtClass(NULL, FALSE, thisObj, mfail)
#define g3ExpandInWindowAtClass(class, thisObj, mfail) \
        _g3ExpandInWindowAtClass(class, FALSE, thisObj, mfail)
#define g3ExpandInWindowAtParent(class, thisObj, mfail) \
        _g3ExpandInWindowAtClass(class, TRUE, thisObj, mfail)

#define g3ExpandModel(this, mfail) \
        _g3ExpandModelAtClass(NULL, FALSE, this, mfail)
#define g3ExpandModelAtClass(class, this, mfail) \
        _g3ExpandModelAtClass(class, FALSE, this, mfail)
#define g3ExpandModelAtParent(class, this, mfail) \
        _g3ExpandModelAtClass(class, TRUE, this, mfail)

#define g3ExpandModelNI(this, mfail) \
        _g3ExpandModelNIAtClass(NULL, FALSE, this, mfail)
#define g3ExpandModelNIAtClass(class, this, mfail) \
        _g3ExpandModelNIAtClass(class, FALSE, this, mfail)
#define g3ExpandModelNIAtParent(class, this, mfail) \
        _g3ExpandModelNIAtClass(class, TRUE, this, mfail)

#define g3ExpandMultiLev(this, mfail) \
        _g3ExpandMultiLevAtClass(NULL, FALSE, this, mfail)
#define g3ExpandMultiLevAtClass(class, this, mfail) \
        _g3ExpandMultiLevAtClass(class, FALSE, this, mfail)
#define g3ExpandMultiLevAtParent(class, this, mfail) \
        _g3ExpandMultiLevAtClass(class, TRUE, this, mfail)

#define g3ExpandOnlyModels(thisObj, mfail) \
        _g3ExpandOnlyModelsAtClass(NULL, FALSE, thisObj, mfail)
#define g3ExpandOnlyModelsAtClass(class, thisObj, mfail) \
        _g3ExpandOnlyModelsAtClass(class, FALSE, thisObj, mfail)
#define g3ExpandOnlyModelsAtParent(class, thisObj, mfail) \
        _g3ExpandOnlyModelsAtClass(class, TRUE, thisObj, mfail)

#define g3ExpandRelationCri(this, otherSideObjSet, relObjSet, mfail) \
        _g3ExpandRelationCriAtClass(NULL, FALSE, this, otherSideObjSet, relObjSet, mfail)
#define g3ExpandRelationCriAtClass(class, this, otherSideObjSet, relObjSet, mfail) \
        _g3ExpandRelationCriAtClass(class, FALSE, this, otherSideObjSet, relObjSet, mfail)
#define g3ExpandRelationCriAtParent(class, this, otherSideObjSet, relObjSet, mfail) \
        _g3ExpandRelationCriAtClass(class, TRUE, this, otherSideObjSet, relObjSet, mfail)

#define g3ExpandRelsOfPart(ClassName, object, relClass, relShip, docs, docRels, mfail) \
        _g3ExpandRelsOfPart(ClassName, FALSE, ClassName, object, relClass, relShip, docs, docRels, mfail)
#define g3ExpandRelsOfPartAtParent(_class, ClassName, object, relClass, relShip, docs, docRels, mfail) \
        _g3ExpandRelsOfPart(_class, TRUE, ClassName, object, relClass, relShip, docs, docRels, mfail)

#define g3ExpandSelectedSubset(this, PosObjects, SonObjects, mfail) \
        _g3ExpandSelectedSubsetAtClass(NULL, FALSE, this, PosObjects, SonObjects, mfail)
#define g3ExpandSelectedSubsetAtClass(class, this, PosObjects, SonObjects, mfail) \
        _g3ExpandSelectedSubsetAtClass(class, FALSE, this, PosObjects, SonObjects, mfail)
#define g3ExpandSelectedSubsetAtParent(class, this, PosObjects, SonObjects, mfail) \
        _g3ExpandSelectedSubsetAtClass(class, TRUE, this, PosObjects, SonObjects, mfail)

#define g3FilterAllowedItems(classname, DroppedItems, mfail) \
        _g3FilterAllowedItems(classname, FALSE, classname, DroppedItems, mfail)
#define g3FilterAllowedItemsAtParent(_class, classname, DroppedItems, mfail) \
        _g3FilterAllowedItems(_class, TRUE, classname, DroppedItems, mfail)

#define g3FilterClgDataWithSeq(classname, catalogSet, mfail) \
        _g3FilterClgDataWithSeq(classname, FALSE, classname, catalogSet, mfail)
#define g3FilterClgDataWithSeqAtParent(_class, classname, catalogSet, mfail) \
        _g3FilterClgDataWithSeq(_class, TRUE, classname, catalogSet, mfail)

#define g3FilterDataWithSeq(classname, objectSet, mfail) \
        _g3FilterDataWithSeq(classname, FALSE, classname, objectSet, mfail)
#define g3FilterDataWithSeqAtParent(_class, classname, objectSet, mfail) \
        _g3FilterDataWithSeq(_class, TRUE, classname, objectSet, mfail)

#define g3FilterDocs(classname, GenItemObj, docSet, mfail) \
        _g3FilterDocs(classname, FALSE, classname, GenItemObj, docSet, mfail)
#define g3FilterDocsAtParent(_class, classname, GenItemObj, docSet, mfail) \
        _g3FilterDocs(_class, TRUE, classname, GenItemObj, docSet, mfail)

#define g3FilterDocsInScope(classname, GenItemObj, docSet, mfail) \
        _g3FilterDocsInScope(classname, FALSE, classname, GenItemObj, docSet, mfail)
#define g3FilterDocsInScopeAtParent(_class, classname, GenItemObj, docSet, mfail) \
        _g3FilterDocsInScope(_class, TRUE, classname, GenItemObj, docSet, mfail)

#define g3FilterDocsWithRev(classname, docSet, mfail) \
        _g3FilterDocsWithRev(classname, FALSE, classname, docSet, mfail)
#define g3FilterDocsWithRevAtParent(_class, classname, docSet, mfail) \
        _g3FilterDocsWithRev(_class, TRUE, classname, docSet, mfail)

#define g3FilterDocsWithSeq(classname, docSet, mfail) \
        _g3FilterDocsWithSeq(classname, FALSE, classname, docSet, mfail)
#define g3FilterDocsWithSeqAtParent(_class, classname, docSet, mfail) \
        _g3FilterDocsWithSeq(_class, TRUE, classname, docSet, mfail)

#define g3FilterHighestSeq(className, IndepBinSet, IndepBin, mfail) \
        _g3FilterHighestSeq(className, FALSE, className, IndepBinSet, IndepBin, mfail)
#define g3FilterHighestSeqAtParent(_class, className, IndepBinSet, IndepBin, mfail) \
        _g3FilterHighestSeq(_class, TRUE, className, IndepBinSet, IndepBin, mfail)

#define g3FilterItmsOfCrntWkB(this, Items_to_filter, Items_in_wkbnch, mfail) \
        _g3FilterItmsOfCrntWkBAtClass(NULL, FALSE, this, Items_to_filter, Items_in_wkbnch, mfail)
#define g3FilterItmsOfCrntWkBAtClass(class, this, Items_to_filter, Items_in_wkbnch, mfail) \
        _g3FilterItmsOfCrntWkBAtClass(class, FALSE, this, Items_to_filter, Items_in_wkbnch, mfail)
#define g3FilterItmsOfCrntWkBAtParent(class, this, Items_to_filter, Items_in_wkbnch, mfail) \
        _g3FilterItmsOfCrntWkBAtClass(class, TRUE, this, Items_to_filter, Items_in_wkbnch, mfail)

#define g3FilterModels(classname, modelSet, posSet, bVisuMode, mfail) \
        _g3FilterModels(classname, FALSE, classname, modelSet, posSet, bVisuMode, mfail)
#define g3FilterModelsAtParent(_class, classname, modelSet, posSet, bVisuMode, mfail) \
        _g3FilterModels(_class, TRUE, classname, modelSet, posSet, bVisuMode, mfail)

#define g3FilterModelsForPubl(classname, modSet, posSet, mfail) \
        _g3FilterModelsForPubl(classname, FALSE, classname, modSet, posSet, mfail)
#define g3FilterModelsForPublAtParent(_class, classname, modSet, posSet, mfail) \
        _g3FilterModelsForPubl(_class, TRUE, classname, modSet, posSet, mfail)

#define g3FilterModelsInScope(classname, modSet, posSet, mfail) \
        _g3FilterModelsInScope(classname, FALSE, classname, modSet, posSet, mfail)
#define g3FilterModelsInScopeAtParent(_class, classname, modSet, posSet, mfail) \
        _g3FilterModelsInScope(_class, TRUE, classname, modSet, posSet, mfail)

#define g3FilterModelsWithSeq(classname, modSet, posSet, mfail) \
        _g3FilterModelsWithSeq(classname, FALSE, classname, modSet, posSet, mfail)
#define g3FilterModelsWithSeqAtParent(_class, classname, modSet, posSet, mfail) \
        _g3FilterModelsWithSeq(_class, TRUE, classname, modSet, posSet, mfail)

#define g3FilterModelsWithType(classname, modSet, posSet, bVisuMode, mfail) \
        _g3FilterModelsWithType(classname, FALSE, classname, modSet, posSet, bVisuMode, mfail)
#define g3FilterModelsWithTypeAtParent(_class, classname, modSet, posSet, bVisuMode, mfail) \
        _g3FilterModelsWithType(_class, TRUE, classname, modSet, posSet, bVisuMode, mfail)

#define g3FilterPrcDataWithSeq(classname, processSet, mfail) \
        _g3FilterPrcDataWithSeq(classname, FALSE, classname, processSet, mfail)
#define g3FilterPrcDataWithSeqAtParent(_class, classname, processSet, mfail) \
        _g3FilterPrcDataWithSeq(_class, TRUE, classname, processSet, mfail)

#define g3FilterPrdDataWithSeq(classname, productSet, mfail) \
        _g3FilterPrdDataWithSeq(classname, FALSE, classname, productSet, mfail)
#define g3FilterPrdDataWithSeqAtParent(_class, classname, productSet, mfail) \
        _g3FilterPrdDataWithSeq(_class, TRUE, classname, productSet, mfail)

#define g3FindRelevantDoc(this, DocType, RelevDoc, mfail) \
        _g3FindRelevantDocAtClass(NULL, FALSE, this, DocType, RelevDoc, mfail)
#define g3FindRelevantDocAtClass(class, this, DocType, RelevDoc, mfail) \
        _g3FindRelevantDocAtClass(class, FALSE, this, DocType, RelevDoc, mfail)
#define g3FindRelevantDocAtParent(class, this, DocType, RelevDoc, mfail) \
        _g3FindRelevantDocAtClass(class, TRUE, this, DocType, RelevDoc, mfail)

#define g3GetAllDocsOfPart(ClassName, PartObj, GenItemObj, docs, mfail) \
        _g3GetAllDocsOfPart(ClassName, FALSE, ClassName, PartObj, GenItemObj, docs, mfail)
#define g3GetAllDocsOfPartAtParent(_class, ClassName, PartObj, GenItemObj, docs, mfail) \
        _g3GetAllDocsOfPart(_class, TRUE, ClassName, PartObj, GenItemObj, docs, mfail)

#define g3GetAllModelsOfDoc(classname, this, WorkBnchObj, modelSet, posSet, mfail) \
        _g3GetAllModelsOfDoc(classname, FALSE, classname, this, WorkBnchObj, modelSet, posSet, mfail)
#define g3GetAllModelsOfDocAtParent(_class, classname, this, WorkBnchObj, modelSet, posSet, mfail) \
        _g3GetAllModelsOfDoc(_class, TRUE, classname, this, WorkBnchObj, modelSet, posSet, mfail)

#define g3GetAllModelsOfDocCus(classname, expandInfo, this, WorkBnchObj, modelSet, posSet, mfail) \
        _g3GetAllModelsOfDocCus(classname, FALSE, classname, expandInfo, this, WorkBnchObj, modelSet, posSet, mfail)
#define g3GetAllModelsOfDocCusAtParent(_class, classname, expandInfo, this, WorkBnchObj, modelSet, posSet, mfail) \
        _g3GetAllModelsOfDocCus(_class, TRUE, classname, expandInfo, this, WorkBnchObj, modelSet, posSet, mfail)

#define g3GetAllProcessFiles(thisPtr, WorkBnchObj, GenItemObj, processesOfPart, mfail) \
        _g3GetAllProcessFilesAtClass(NULL, FALSE, thisPtr, WorkBnchObj, GenItemObj, processesOfPart, mfail)
#define g3GetAllProcessFilesAtClass(class, thisPtr, WorkBnchObj, GenItemObj, processesOfPart, mfail) \
        _g3GetAllProcessFilesAtClass(class, FALSE, thisPtr, WorkBnchObj, GenItemObj, processesOfPart, mfail)
#define g3GetAllProcessFilesAtParent(class, thisPtr, WorkBnchObj, GenItemObj, processesOfPart, mfail) \
        _g3GetAllProcessFilesAtClass(class, TRUE, thisPtr, WorkBnchObj, GenItemObj, processesOfPart, mfail)

#define g3GetAndFilterModels(this, WorkBnchObj, GenItemObj, NeededClass, modelsOfPart, posOfPart, mfail) \
        _g3GetAndFilterModelsAtClass(NULL, FALSE, this, WorkBnchObj, GenItemObj, NeededClass, modelsOfPart, posOfPart, mfail)
#define g3GetAndFilterModelsAtClass(class, this, WorkBnchObj, GenItemObj, NeededClass, modelsOfPart, posOfPart, mfail) \
        _g3GetAndFilterModelsAtClass(class, FALSE, this, WorkBnchObj, GenItemObj, NeededClass, modelsOfPart, posOfPart, mfail)
#define g3GetAndFilterModelsAtParent(class, this, WorkBnchObj, GenItemObj, NeededClass, modelsOfPart, posOfPart, mfail) \
        _g3GetAndFilterModelsAtClass(class, TRUE, this, WorkBnchObj, GenItemObj, NeededClass, modelsOfPart, posOfPart, mfail)

#define g3GetBlackBoxDocument(thisPtr, pBlackBoxDoc, mfail) \
        _g3GetBlackBoxDocumentAtClass(NULL, FALSE, thisPtr, pBlackBoxDoc, mfail)
#define g3GetBlackBoxDocumentAtClass(class, thisPtr, pBlackBoxDoc, mfail) \
        _g3GetBlackBoxDocumentAtClass(class, FALSE, thisPtr, pBlackBoxDoc, mfail)
#define g3GetBlackBoxDocumentAtParent(class, thisPtr, pBlackBoxDoc, mfail) \
        _g3GetBlackBoxDocumentAtClass(class, TRUE, thisPtr, pBlackBoxDoc, mfail)

#define g3GetBlackBoxFiles(thisPtr, pBlackBoxObjs, pBlackBoxRels, mfail) \
        _g3GetBlackBoxFilesAtClass(NULL, FALSE, thisPtr, pBlackBoxObjs, pBlackBoxRels, mfail)
#define g3GetBlackBoxFilesAtClass(class, thisPtr, pBlackBoxObjs, pBlackBoxRels, mfail) \
        _g3GetBlackBoxFilesAtClass(class, FALSE, thisPtr, pBlackBoxObjs, pBlackBoxRels, mfail)
#define g3GetBlackBoxFilesAtParent(class, thisPtr, pBlackBoxObjs, pBlackBoxRels, mfail) \
        _g3GetBlackBoxFilesAtClass(class, TRUE, thisPtr, pBlackBoxObjs, pBlackBoxRels, mfail)

#define g3GetClassOfWkBnchItem(this, WorkBnchObj, WkBnchItem, mfail) \
        _g3GetClassOfWkBnchItemAtClass(NULL, FALSE, this, WorkBnchObj, WkBnchItem, mfail)
#define g3GetClassOfWkBnchItemAtClass(class, this, WorkBnchObj, WkBnchItem, mfail) \
        _g3GetClassOfWkBnchItemAtClass(class, FALSE, this, WorkBnchObj, WkBnchItem, mfail)
#define g3GetClassOfWkBnchItemAtParent(class, this, WorkBnchObj, WkBnchItem, mfail) \
        _g3GetClassOfWkBnchItemAtClass(class, TRUE, this, WorkBnchObj, WkBnchItem, mfail)

#define g3GetDocFromDocRep(this, DocObj, mfail) \
        _g3GetDocFromDocRepAtClass(NULL, FALSE, this, DocObj, mfail)
#define g3GetDocFromDocRepAtClass(class, this, DocObj, mfail) \
        _g3GetDocFromDocRepAtClass(class, FALSE, this, DocObj, mfail)
#define g3GetDocFromDocRepAtParent(class, this, DocObj, mfail) \
        _g3GetDocFromDocRepAtClass(class, TRUE, this, DocObj, mfail)

#define g3GetDocOfModel(this, objDoc, mfail) \
        _g3GetDocOfModelAtClass(NULL, FALSE, this, objDoc, mfail)
#define g3GetDocOfModelAtClass(class, this, objDoc, mfail) \
        _g3GetDocOfModelAtClass(class, FALSE, this, objDoc, mfail)
#define g3GetDocOfModelAtParent(class, this, objDoc, mfail) \
        _g3GetDocOfModelAtClass(class, TRUE, this, objDoc, mfail)

#define g3GetDocsOfPartInScope(ClassName, PartObj, GenItemObj, docs, mfail) \
        _g3GetDocsOfPartInScope(ClassName, FALSE, ClassName, PartObj, GenItemObj, docs, mfail)
#define g3GetDocsOfPartInScopeAtParent(_class, ClassName, PartObj, GenItemObj, docs, mfail) \
        _g3GetDocsOfPartInScope(_class, TRUE, ClassName, PartObj, GenItemObj, docs, mfail)

#define g3GetDocumentName(this, sDocumentName, mfail) \
        _g3GetDocumentNameAtClass(NULL, FALSE, this, sDocumentName, mfail)
#define g3GetDocumentNameAtClass(class, this, sDocumentName, mfail) \
        _g3GetDocumentNameAtClass(class, FALSE, this, sDocumentName, mfail)
#define g3GetDocumentNameAtParent(class, this, sDocumentName, mfail) \
        _g3GetDocumentNameAtClass(class, TRUE, this, sDocumentName, mfail)

#define g3GetDynamicObject(classname, obid, itemObj, relObj, mfail) \
        _g3GetDynamicObject(classname, FALSE, classname, obid, itemObj, relObj, mfail)
#define g3GetDynamicObjectAtParent(_class, classname, obid, itemObj, relObj, mfail) \
        _g3GetDynamicObject(_class, TRUE, classname, obid, itemObj, relObj, mfail)

#define g3GetExpandLevel(className, expLevel, mfail) \
        _g3GetExpandLevel(className, FALSE, className, expLevel, mfail)
#define g3GetExpandLevelAtParent(_class, className, expLevel, mfail) \
        _g3GetExpandLevel(_class, TRUE, className, expLevel, mfail)

#define g3GetInstanceDescript(thisObj, itemObj, sInstDescript, mfail) \
        _g3GetInstanceDescriptAtClass(NULL, FALSE, thisObj, itemObj, sInstDescript, mfail)
#define g3GetInstanceDescriptAtClass(class, thisObj, itemObj, sInstDescript, mfail) \
        _g3GetInstanceDescriptAtClass(class, FALSE, thisObj, itemObj, sInstDescript, mfail)
#define g3GetInstanceDescriptAtParent(class, thisObj, itemObj, sInstDescript, mfail) \
        _g3GetInstanceDescriptAtClass(class, TRUE, thisObj, itemObj, sInstDescript, mfail)

#define g3GetInstanceName(thisObj, sInstanceName, mfail) \
        _g3GetInstanceNameAtClass(NULL, FALSE, thisObj, sInstanceName, mfail)
#define g3GetInstanceNameAtClass(class, thisObj, sInstanceName, mfail) \
        _g3GetInstanceNameAtClass(class, FALSE, thisObj, sInstanceName, mfail)
#define g3GetInstanceNameAtParent(class, thisObj, sInstanceName, mfail) \
        _g3GetInstanceNameAtClass(class, TRUE, thisObj, sInstanceName, mfail)

#define g3GetMaxExpLevel(ClassName, ExpLevel, mfail) \
        _g3GetMaxExpLevel(ClassName, FALSE, ClassName, ExpLevel, mfail)
#define g3GetMaxExpLevelAtParent(_class, ClassName, ExpLevel, mfail) \
        _g3GetMaxExpLevel(_class, TRUE, ClassName, ExpLevel, mfail)

#define g3GetModelFromModelRep(ModRepObj, modelOfItem, mfail) \
        _g3GetModelFromModelRepAtClass(NULL, FALSE, ModRepObj, modelOfItem, mfail)
#define g3GetModelFromModelRepAtClass(class, ModRepObj, modelOfItem, mfail) \
        _g3GetModelFromModelRepAtClass(class, FALSE, ModRepObj, modelOfItem, mfail)
#define g3GetModelFromModelRepAtParent(class, ModRepObj, modelOfItem, mfail) \
        _g3GetModelFromModelRepAtClass(class, TRUE, ModRepObj, modelOfItem, mfail)

#define g3GetModelsAndModReps(GenItemObj, modelsOfPart, ModRepObjSet, mfail) \
        _g3GetModelsAndModRepsAtClass(NULL, FALSE, GenItemObj, modelsOfPart, ModRepObjSet, mfail)
#define g3GetModelsAndModRepsAtClass(class, GenItemObj, modelsOfPart, ModRepObjSet, mfail) \
        _g3GetModelsAndModRepsAtClass(class, FALSE, GenItemObj, modelsOfPart, ModRepObjSet, mfail)
#define g3GetModelsAndModRepsAtParent(class, GenItemObj, modelsOfPart, ModRepObjSet, mfail) \
        _g3GetModelsAndModRepsAtClass(class, TRUE, GenItemObj, modelsOfPart, ModRepObjSet, mfail)

#define g3GetModelsForDisplay(this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, p_bShowFlag, bVisuMode, mfail) \
        _g3GetModelsForDisplayAtClass(NULL, FALSE, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, p_bShowFlag, bVisuMode, mfail)
#define g3GetModelsForDisplayAtClass(class, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, p_bShowFlag, bVisuMode, mfail) \
        _g3GetModelsForDisplayAtClass(class, FALSE, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, p_bShowFlag, bVisuMode, mfail)
#define g3GetModelsForDisplayAtParent(class, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, p_bShowFlag, bVisuMode, mfail) \
        _g3GetModelsForDisplayAtClass(class, TRUE, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, p_bShowFlag, bVisuMode, mfail)

#define g3GetModelsViaModRep(GenItemObj, modelsOfPart, mfail) \
        _g3GetModelsViaModRepAtClass(NULL, FALSE, GenItemObj, modelsOfPart, mfail)
#define g3GetModelsViaModRepAtClass(class, GenItemObj, modelsOfPart, mfail) \
        _g3GetModelsViaModRepAtClass(class, FALSE, GenItemObj, modelsOfPart, mfail)
#define g3GetModelsViaModRepAtParent(class, GenItemObj, modelsOfPart, mfail) \
        _g3GetModelsViaModRepAtClass(class, TRUE, GenItemObj, modelsOfPart, mfail)

#define g3GetObjViaObidAndDB(className, ClassOfObjToBeFound, obid, databaseName, relclassname, relationshipname, relobid, itemObj, relObj, mfail) \
        _g3GetObjViaObidAndDB(className, FALSE, className, ClassOfObjToBeFound, obid, databaseName, relclassname, relationshipname, relobid, itemObj, relObj, mfail)
#define g3GetObjViaObidAndDBAtParent(_class, className, ClassOfObjToBeFound, obid, databaseName, relclassname, relationshipname, relobid, itemObj, relObj, mfail) \
        _g3GetObjViaObidAndDB(_class, TRUE, className, ClassOfObjToBeFound, obid, databaseName, relclassname, relationshipname, relobid, itemObj, relObj, mfail)

#define g3GetObjectViaObid(className, ClassOfObjToBeFound, obid, relclassname, relationshipname, relobid, itemObj, relObj, mfail) \
        _g3GetObjectViaObid(className, FALSE, className, ClassOfObjToBeFound, obid, relclassname, relationshipname, relobid, itemObj, relObj, mfail)
#define g3GetObjectViaObidAtParent(_class, className, ClassOfObjToBeFound, obid, relclassname, relationshipname, relobid, itemObj, relObj, mfail) \
        _g3GetObjectViaObid(_class, TRUE, className, ClassOfObjToBeFound, obid, relclassname, relationshipname, relobid, itemObj, relObj, mfail)

#define g3GetOccName(this, OccName, mfail) \
        _g3GetOccNameAtClass(NULL, FALSE, this, OccName, mfail)
#define g3GetOccNameAtClass(class, this, OccName, mfail) \
        _g3GetOccNameAtClass(class, FALSE, this, OccName, mfail)
#define g3GetOccNameAtParent(class, this, OccName, mfail) \
        _g3GetOccNameAtClass(class, TRUE, this, OccName, mfail)

#define g3GetParentParts(classname, sourcePartSet, currentExpandObjSet, currentExpandRelObjSet, mfail) \
        _g3GetParentParts(classname, FALSE, classname, sourcePartSet, currentExpandObjSet, currentExpandRelObjSet, mfail)
#define g3GetParentPartsAtParent(_class, classname, sourcePartSet, currentExpandObjSet, currentExpandRelObjSet, mfail) \
        _g3GetParentParts(_class, TRUE, classname, sourcePartSet, currentExpandObjSet, currentExpandRelObjSet, mfail)

#define g3GetPartFromGenItem(itemObj, PartObj, mfail) \
        _g3GetPartFromGenItemAtClass(NULL, FALSE, itemObj, PartObj, mfail)
#define g3GetPartFromGenItemAtClass(class, itemObj, PartObj, mfail) \
        _g3GetPartFromGenItemAtClass(class, FALSE, itemObj, PartObj, mfail)
#define g3GetPartFromGenItemAtParent(class, itemObj, PartObj, mfail) \
        _g3GetPartFromGenItemAtClass(class, TRUE, itemObj, PartObj, mfail)

#define g3GetPartsInAssSet(classname, assObjSet, partsInAss, partRels, mfail) \
        _g3GetPartsInAssSet(classname, FALSE, classname, assObjSet, partsInAss, partRels, mfail)
#define g3GetPartsInAssSetAtParent(_class, classname, assObjSet, partsInAss, partRels, mfail) \
        _g3GetPartsInAssSet(_class, TRUE, classname, assObjSet, partsInAss, partRels, mfail)

#define g3GetPartsInAssSetCus(classname, expandInfo, assObjSet, partsInAss, partRels, mfail) \
        _g3GetPartsInAssSetCus(classname, FALSE, classname, expandInfo, assObjSet, partsInAss, partRels, mfail)
#define g3GetPartsInAssSetCusAtParent(_class, classname, expandInfo, assObjSet, partsInAss, partRels, mfail) \
        _g3GetPartsInAssSetCus(_class, TRUE, classname, expandInfo, assObjSet, partsInAss, partRels, mfail)

#define g3GetPartsInAssembly(classname, assObj, partsInAss, partRels, mfail) \
        _g3GetPartsInAssembly(classname, FALSE, classname, assObj, partsInAss, partRels, mfail)
#define g3GetPartsInAssemblyAtParent(_class, classname, assObj, partsInAss, partRels, mfail) \
        _g3GetPartsInAssembly(_class, TRUE, classname, assObj, partsInAss, partRels, mfail)

#define g3GetPartsInAssemblyCu(classname, expandInfo, assObj, partsInAss, partRels, mfail) \
        _g3GetPartsInAssemblyCu(classname, FALSE, classname, expandInfo, assObj, partsInAss, partRels, mfail)
#define g3GetPartsInAssemblyCuAtParent(_class, classname, expandInfo, assObj, partsInAss, partRels, mfail) \
        _g3GetPartsInAssemblyCu(_class, TRUE, classname, expandInfo, assObj, partsInAss, partRels, mfail)

#define g3GetPortAndHost(ClassName, Host, HostIp, Port, mfail) \
        _g3GetPortAndHost(ClassName, FALSE, ClassName, Host, HostIp, Port, mfail)
#define g3GetPortAndHostAtParent(_class, ClassName, Host, HostIp, Port, mfail) \
        _g3GetPortAndHost(_class, TRUE, ClassName, Host, HostIp, Port, mfail)

#define g3GetPrdPartFrGenItem(itemObj, PartObj, mfail) \
        _g3GetPrdPartFrGenItemAtClass(NULL, FALSE, itemObj, PartObj, mfail)
#define g3GetPrdPartFrGenItemAtClass(class, itemObj, PartObj, mfail) \
        _g3GetPrdPartFrGenItemAtClass(class, FALSE, itemObj, PartObj, mfail)
#define g3GetPrdPartFrGenItemAtParent(class, itemObj, PartObj, mfail) \
        _g3GetPrdPartFrGenItemAtClass(class, TRUE, itemObj, PartObj, mfail)

#define g3GetProcessFiles(thisPtr, WorkBnchObj, processesOfPart, mfail) \
        _g3GetProcessFilesAtClass(NULL, FALSE, thisPtr, WorkBnchObj, processesOfPart, mfail)
#define g3GetProcessFilesAtClass(class, thisPtr, WorkBnchObj, processesOfPart, mfail) \
        _g3GetProcessFilesAtClass(class, FALSE, thisPtr, WorkBnchObj, processesOfPart, mfail)
#define g3GetProcessFilesAtParent(class, thisPtr, WorkBnchObj, processesOfPart, mfail) \
        _g3GetProcessFilesAtClass(class, TRUE, thisPtr, WorkBnchObj, processesOfPart, mfail)

#define g3GetProductDocuments(thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetProductDocumentsAtClass(NULL, FALSE, thisPtr, WorkBnchObj, productsOfPart, mfail)
#define g3GetProductDocumentsAtClass(class, thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetProductDocumentsAtClass(class, FALSE, thisPtr, WorkBnchObj, productsOfPart, mfail)
#define g3GetProductDocumentsAtParent(class, thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetProductDocumentsAtClass(class, TRUE, thisPtr, WorkBnchObj, productsOfPart, mfail)

#define g3GetProductFiles(thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetProductFilesAtClass(NULL, FALSE, thisPtr, WorkBnchObj, productsOfPart, mfail)
#define g3GetProductFilesAtClass(class, thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetProductFilesAtClass(class, FALSE, thisPtr, WorkBnchObj, productsOfPart, mfail)
#define g3GetProductFilesAtParent(class, thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetProductFilesAtClass(class, TRUE, thisPtr, WorkBnchObj, productsOfPart, mfail)

#define g3GetProductInfo(className, vProductInfo, mfail) \
        _g3GetProductInfo(className, FALSE, className, vProductInfo, mfail)
#define g3GetProductInfoAtParent(_class, className, vProductInfo, mfail) \
        _g3GetProductInfo(_class, TRUE, className, vProductInfo, mfail)

#define g3GetQuantity(thisObj, sQuantity, mfail) \
        _g3GetQuantityAtClass(NULL, FALSE, thisObj, sQuantity, mfail)
#define g3GetQuantityAtClass(class, thisObj, sQuantity, mfail) \
        _g3GetQuantityAtClass(class, FALSE, thisObj, sQuantity, mfail)
#define g3GetQuantityAtParent(class, thisObj, sQuantity, mfail) \
        _g3GetQuantityAtClass(class, TRUE, thisObj, sQuantity, mfail)

#define g3GetRelatedModels(this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, bVisuMode, mfail) \
        _g3GetRelatedModelsAtClass(NULL, FALSE, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, bVisuMode, mfail)
#define g3GetRelatedModelsAtClass(class, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, bVisuMode, mfail) \
        _g3GetRelatedModelsAtClass(class, FALSE, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, bVisuMode, mfail)
#define g3GetRelatedModelsAtParent(class, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, bVisuMode, mfail) \
        _g3GetRelatedModelsAtClass(class, TRUE, this, WorkBnchObj, GenItemObj, modelsOfPart, posOfPart, bVisuMode, mfail)

#define g3GetRelevantRelOBID(className, this, relationOBID, mfail) \
        _g3GetRelevantRelOBID(className, FALSE, className, this, relationOBID, mfail)
#define g3GetRelevantRelOBIDAtParent(_class, className, this, relationOBID, mfail) \
        _g3GetRelevantRelOBID(_class, TRUE, className, this, relationOBID, mfail)

#define g3GetRelevantSonObjs(this, DroppedObjects, SonObjects, PosObjects, mfail) \
        _g3GetRelevantSonObjsAtClass(NULL, FALSE, this, DroppedObjects, SonObjects, PosObjects, mfail)
#define g3GetRelevantSonObjsAtClass(class, this, DroppedObjects, SonObjects, PosObjects, mfail) \
        _g3GetRelevantSonObjsAtClass(class, FALSE, this, DroppedObjects, SonObjects, PosObjects, mfail)
#define g3GetRelevantSonObjsAtParent(class, this, DroppedObjects, SonObjects, PosObjects, mfail) \
        _g3GetRelevantSonObjsAtClass(class, TRUE, this, DroppedObjects, SonObjects, PosObjects, mfail)

#define g3GetRemRelevRel(assmObj, itemRel, itemObj, relevRelObj, mfail) \
        _g3GetRemRelevRelAtClass(NULL, FALSE, assmObj, itemRel, itemObj, relevRelObj, mfail)
#define g3GetRemRelevRelAtClass(class, assmObj, itemRel, itemObj, relevRelObj, mfail) \
        _g3GetRemRelevRelAtClass(class, FALSE, assmObj, itemRel, itemObj, relevRelObj, mfail)
#define g3GetRemRelevRelAtParent(class, assmObj, itemRel, itemObj, relevRelObj, mfail) \
        _g3GetRemRelevRelAtClass(class, TRUE, assmObj, itemRel, itemObj, relevRelObj, mfail)

#define g3GetRootItem(className, pRootItemObj, mfail) \
        _g3GetRootItem(className, FALSE, className, pRootItemObj, mfail)
#define g3GetRootItemAtParent(_class, className, pRootItemObj, mfail) \
        _g3GetRootItem(_class, TRUE, className, pRootItemObj, mfail)

#define g3GetShowModelsFlag(classname, showModelFlag, bShow, mfail) \
        _g3GetShowModelsFlag(classname, FALSE, classname, showModelFlag, bShow, mfail)
#define g3GetShowModelsFlagAtParent(_class, classname, showModelFlag, bShow, mfail) \
        _g3GetShowModelsFlag(_class, TRUE, classname, showModelFlag, bShow, mfail)

#define g3GetSwapFlag(classname, modelOBID, swapFlag, mfail) \
        _g3GetSwapFlag(classname, FALSE, classname, modelOBID, swapFlag, mfail)
#define g3GetSwapFlagAtParent(_class, classname, modelOBID, swapFlag, mfail) \
        _g3GetSwapFlag(_class, TRUE, classname, modelOBID, swapFlag, mfail)

#define g3GetTempItem(className, pRootItemObj, mfail) \
        _g3GetTempItem(className, FALSE, className, pRootItemObj, mfail)
#define g3GetTempItemAtParent(_class, className, pRootItemObj, mfail) \
        _g3GetTempItem(_class, TRUE, className, pRootItemObj, mfail)

#define g3GetTrafo(this, valueSet, mfail) \
        _g3GetTrafoAtClass(NULL, FALSE, this, valueSet, mfail)
#define g3GetTrafoAtClass(class, this, valueSet, mfail) \
        _g3GetTrafoAtClass(class, FALSE, this, valueSet, mfail)
#define g3GetTrafoAtParent(class, this, valueSet, mfail) \
        _g3GetTrafoAtClass(class, TRUE, this, valueSet, mfail)

#define g3GetWBClassFrmItm(this, className, mfail) \
        _g3GetWBClassFrmItmAtClass(NULL, FALSE, this, className, mfail)
#define g3GetWBClassFrmItmAtClass(class, this, className, mfail) \
        _g3GetWBClassFrmItmAtClass(class, FALSE, this, className, mfail)
#define g3GetWBClassFrmItmAtParent(class, this, className, mfail) \
        _g3GetWBClassFrmItmAtClass(class, TRUE, this, className, mfail)

#define g3GetWBSysVars(classname, winId, mfail) \
        _g3GetWBSysVars(classname, FALSE, classname, winId, mfail)
#define g3GetWBSysVarsAtParent(_class, classname, winId, mfail) \
        _g3GetWBSysVars(_class, TRUE, classname, winId, mfail)

#define g3GlobPtrDel(className, objName, mfail) \
        _g3GlobPtrDel(className, FALSE, className, objName, mfail)
#define g3GlobPtrDelAtParent(_class, className, objName, mfail) \
        _g3GlobPtrDel(_class, TRUE, className, objName, mfail)

#define g3GlobPtrGet(className, objName, objPtr, mfail) \
        _g3GlobPtrGet(className, FALSE, className, objName, objPtr, mfail)
#define g3GlobPtrGetAtParent(_class, className, objName, objPtr, mfail) \
        _g3GlobPtrGet(_class, TRUE, className, objName, objPtr, mfail)

#define g3GlobPtrPut(className, objName, objPtr, mfail) \
        _g3GlobPtrPut(className, FALSE, className, objName, objPtr, mfail)
#define g3GlobPtrPutAtParent(_class, className, objName, objPtr, mfail) \
        _g3GlobPtrPut(_class, TRUE, className, objName, objPtr, mfail)

#define g3GlobVarGet(className, objName, attribute, value, mfail) \
        _g3GlobVarGet(className, FALSE, className, objName, attribute, value, mfail)
#define g3GlobVarGetAtParent(_class, className, objName, attribute, value, mfail) \
        _g3GlobVarGet(_class, TRUE, className, objName, attribute, value, mfail)

#define g3GlobVarPut(className, objName, attribute, value, mfail) \
        _g3GlobVarPut(className, FALSE, className, objName, attribute, value, mfail)
#define g3GlobVarPutAtParent(_class, className, objName, attribute, value, mfail) \
        _g3GlobVarPut(_class, TRUE, className, objName, attribute, value, mfail)

#define g3HasVisualization(className, modelSet, posSet, bHasVisualization, mfail) \
        _g3HasVisualization(className, FALSE, className, modelSet, posSet, bHasVisualization, mfail)
#define g3HasVisualizationAtParent(_class, className, modelSet, posSet, bHasVisualization, mfail) \
        _g3HasVisualization(_class, TRUE, className, modelSet, posSet, bHasVisualization, mfail)

#define g3HelpOnProduct(className, mfail) \
        _g3HelpOnProduct(className, FALSE, className, mfail)
#define g3HelpOnProductAtParent(_class, className, mfail) \
        _g3HelpOnProduct(_class, TRUE, className, mfail)

#define g3HideAllModels(thisObj, mfail) \
        _g3HideAllModelsAtClass(NULL, FALSE, thisObj, mfail)
#define g3HideAllModelsAtClass(class, thisObj, mfail) \
        _g3HideAllModelsAtClass(class, FALSE, thisObj, mfail)
#define g3HideAllModelsAtParent(class, thisObj, mfail) \
        _g3HideAllModelsAtClass(class, TRUE, thisObj, mfail)

#define g3HideAllSubBranches(this, objsToDelete, mfail) \
        _g3HideAllSubBranchesAtClass(NULL, FALSE, this, objsToDelete, mfail)
#define g3HideAllSubBranchesAtClass(class, this, objsToDelete, mfail) \
        _g3HideAllSubBranchesAtClass(class, FALSE, this, objsToDelete, mfail)
#define g3HideAllSubBranchesAtParent(class, this, objsToDelete, mfail) \
        _g3HideAllSubBranchesAtClass(class, TRUE, this, objsToDelete, mfail)

#define g3HideThisBranch(thisObj, mfail) \
        _g3HideThisBranchAtClass(NULL, FALSE, thisObj, mfail)
#define g3HideThisBranchAtClass(class, thisObj, mfail) \
        _g3HideThisBranchAtClass(class, FALSE, thisObj, mfail)
#define g3HideThisBranchAtParent(class, thisObj, mfail) \
        _g3HideThisBranchAtClass(class, TRUE, thisObj, mfail)

#define g3HideThisBranchNI(this, indicate, mfail) \
        _g3HideThisBranchNIAtClass(NULL, FALSE, this, indicate, mfail)
#define g3HideThisBranchNIAtClass(class, this, indicate, mfail) \
        _g3HideThisBranchNIAtClass(class, FALSE, this, indicate, mfail)
#define g3HideThisBranchNIAtParent(class, this, indicate, mfail) \
        _g3HideThisBranchNIAtClass(class, TRUE, this, indicate, mfail)

#define g3HideThisDoc(thisObj, mfail) \
        _g3HideThisDocAtClass(NULL, FALSE, thisObj, mfail)
#define g3HideThisDocAtClass(class, thisObj, mfail) \
        _g3HideThisDocAtClass(class, FALSE, thisObj, mfail)
#define g3HideThisDocAtParent(class, thisObj, mfail) \
        _g3HideThisDocAtClass(class, TRUE, thisObj, mfail)

#define g3HideThisModel(thisObj, mfail) \
        _g3HideThisModelAtClass(NULL, FALSE, thisObj, mfail)
#define g3HideThisModelAtClass(class, thisObj, mfail) \
        _g3HideThisModelAtClass(class, FALSE, thisObj, mfail)
#define g3HideThisModelAtParent(class, thisObj, mfail) \
        _g3HideThisModelAtClass(class, TRUE, thisObj, mfail)

#define g3HideThisModelNI(this, mfail) \
        _g3HideThisModelNIAtClass(NULL, FALSE, this, mfail)
#define g3HideThisModelNIAtClass(class, this, mfail) \
        _g3HideThisModelNIAtClass(class, FALSE, this, mfail)
#define g3HideThisModelNIAtParent(class, this, mfail) \
        _g3HideThisModelNIAtClass(class, TRUE, this, mfail)

#define g3IsProcessElement(thisObj, WorkBnchObj, bIsProcessElement, mfail) \
        _g3IsProcessElementAtClass(NULL, FALSE, thisObj, WorkBnchObj, bIsProcessElement, mfail)
#define g3IsProcessElementAtClass(class, thisObj, WorkBnchObj, bIsProcessElement, mfail) \
        _g3IsProcessElementAtClass(class, FALSE, thisObj, WorkBnchObj, bIsProcessElement, mfail)
#define g3IsProcessElementAtParent(class, thisObj, WorkBnchObj, bIsProcessElement, mfail) \
        _g3IsProcessElementAtClass(class, TRUE, thisObj, WorkBnchObj, bIsProcessElement, mfail)

#define g3IsProductView(thisObj, WorkBnchObj, bIsProductView, mfail) \
        _g3IsProductViewAtClass(NULL, FALSE, thisObj, WorkBnchObj, bIsProductView, mfail)
#define g3IsProductViewAtClass(class, thisObj, WorkBnchObj, bIsProductView, mfail) \
        _g3IsProductViewAtClass(class, FALSE, thisObj, WorkBnchObj, bIsProductView, mfail)
#define g3IsProductViewAtParent(class, thisObj, WorkBnchObj, bIsProductView, mfail) \
        _g3IsProductViewAtClass(class, TRUE, thisObj, WorkBnchObj, bIsProductView, mfail)

#define g3IsResourceView(thisObj, WorkBnchObj, bIsResourceView, mfail) \
        _g3IsResourceViewAtClass(NULL, FALSE, thisObj, WorkBnchObj, bIsResourceView, mfail)
#define g3IsResourceViewAtClass(class, thisObj, WorkBnchObj, bIsResourceView, mfail) \
        _g3IsResourceViewAtClass(class, FALSE, thisObj, WorkBnchObj, bIsResourceView, mfail)
#define g3IsResourceViewAtParent(class, thisObj, WorkBnchObj, bIsResourceView, mfail) \
        _g3IsResourceViewAtClass(class, TRUE, thisObj, WorkBnchObj, bIsResourceView, mfail)

#define g3IsVisualization(thisObj, bIsVisualization, mfail) \
        _g3IsVisualizationAtClass(NULL, FALSE, thisObj, bIsVisualization, mfail)
#define g3IsVisualizationAtClass(class, thisObj, bIsVisualization, mfail) \
        _g3IsVisualizationAtClass(class, FALSE, thisObj, bIsVisualization, mfail)
#define g3IsVisualizationAtParent(class, thisObj, bIsVisualization, mfail) \
        _g3IsVisualizationAtClass(class, TRUE, thisObj, bIsVisualization, mfail)

#define g3LaunchWbnch(className, mfail) \
        _g3LaunchWbnch(className, FALSE, className, mfail)
#define g3LaunchWbnchAtParent(_class, className, mfail) \
        _g3LaunchWbnch(_class, TRUE, className, mfail)

#define g3LaunchWbnchObject(classname, BrowserItem, BackgroundItem, mfail) \
        _g3LaunchWbnchObject(classname, FALSE, classname, BrowserItem, BackgroundItem, mfail)
#define g3LaunchWbnchObjectAtParent(_class, classname, BrowserItem, BackgroundItem, mfail) \
        _g3LaunchWbnchObject(_class, TRUE, classname, BrowserItem, BackgroundItem, mfail)

#define g3PermsOfItem(this, perm1, mfail) \
        _g3PermsOfItemAtClass(NULL, FALSE, this, perm1, mfail)
#define g3PermsOfItemAtClass(class, this, perm1, mfail) \
        _g3PermsOfItemAtClass(class, FALSE, this, perm1, mfail)
#define g3PermsOfItemAtParent(class, this, perm1, mfail) \
        _g3PermsOfItemAtClass(class, TRUE, this, perm1, mfail)

#define g3ProcessDroppedItem(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _g3ProcessDroppedItemAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define g3ProcessDroppedItemAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _g3ProcessDroppedItemAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define g3ProcessDroppedItemAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _g3ProcessDroppedItemAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define g3ProcessGIMulti(this, level, ctitem_obj, asmPath, WkBnchObj, ctxObj, bVisuMode, mfail) \
        _g3ProcessGIMultiAtClass(NULL, FALSE, this, level, ctitem_obj, asmPath, WkBnchObj, ctxObj, bVisuMode, mfail)
#define g3ProcessGIMultiAtClass(class, this, level, ctitem_obj, asmPath, WkBnchObj, ctxObj, bVisuMode, mfail) \
        _g3ProcessGIMultiAtClass(class, FALSE, this, level, ctitem_obj, asmPath, WkBnchObj, ctxObj, bVisuMode, mfail)
#define g3ProcessGIMultiAtParent(class, this, level, ctitem_obj, asmPath, WkBnchObj, ctxObj, bVisuMode, mfail) \
        _g3ProcessGIMultiAtClass(class, TRUE, this, level, ctitem_obj, asmPath, WkBnchObj, ctxObj, bVisuMode, mfail)

#define g3ProcessGISetMulti(ClassName, Parts, level, ctitem_objs, WkBnchObj, ctxObj, bVisuMode, mfail) \
        _g3ProcessGISetMulti(ClassName, FALSE, ClassName, Parts, level, ctitem_objs, WkBnchObj, ctxObj, bVisuMode, mfail)
#define g3ProcessGISetMultiAtParent(_class, ClassName, Parts, level, ctitem_objs, WkBnchObj, ctxObj, bVisuMode, mfail) \
        _g3ProcessGISetMulti(_class, TRUE, ClassName, Parts, level, ctitem_objs, WkBnchObj, ctxObj, bVisuMode, mfail)

#define g3ProcessGISingle(this, ctitem_obj, WkBnchObj, ctxObj, mfail) \
        _g3ProcessGISingleAtClass(NULL, FALSE, this, ctitem_obj, WkBnchObj, ctxObj, mfail)
#define g3ProcessGISingleAtClass(class, this, ctitem_obj, WkBnchObj, ctxObj, mfail) \
        _g3ProcessGISingleAtClass(class, FALSE, this, ctitem_obj, WkBnchObj, ctxObj, mfail)
#define g3ProcessGISingleAtParent(class, this, ctitem_obj, WkBnchObj, ctxObj, mfail) \
        _g3ProcessGISingleAtClass(class, TRUE, this, ctitem_obj, WkBnchObj, ctxObj, mfail)

#define g3ReStoreCtx(className, ctxObj, mfail) \
        _g3ReStoreCtx(className, FALSE, className, ctxObj, mfail)
#define g3ReStoreCtxAtParent(_class, className, ctxObj, mfail) \
        _g3ReStoreCtx(_class, TRUE, className, ctxObj, mfail)

#define g3RemoveBlackBoxObjs(thisObj, modelSet, posSet, mfail) \
        _g3RemoveBlackBoxObjsAtClass(NULL, FALSE, thisObj, modelSet, posSet, mfail)
#define g3RemoveBlackBoxObjsAtClass(class, thisObj, modelSet, posSet, mfail) \
        _g3RemoveBlackBoxObjsAtClass(class, FALSE, thisObj, modelSet, posSet, mfail)
#define g3RemoveBlackBoxObjsAtParent(class, thisObj, modelSet, posSet, mfail) \
        _g3RemoveBlackBoxObjsAtClass(class, TRUE, thisObj, modelSet, posSet, mfail)

#define g3SetAttrsFromRelation(this, Relation, mfail) \
        _g3SetAttrsFromRelationAtClass(NULL, FALSE, this, Relation, mfail)
#define g3SetAttrsFromRelationAtClass(class, this, Relation, mfail) \
        _g3SetAttrsFromRelationAtClass(class, FALSE, this, Relation, mfail)
#define g3SetAttrsFromRelationAtParent(class, this, Relation, mfail) \
        _g3SetAttrsFromRelationAtClass(class, TRUE, this, Relation, mfail)

#define g3SetBasedAllowed(this, bAllowed, mfail) \
        _g3SetBasedAllowedAtClass(NULL, FALSE, this, bAllowed, mfail)
#define g3SetBasedAllowedAtClass(class, this, bAllowed, mfail) \
        _g3SetBasedAllowedAtClass(class, FALSE, this, bAllowed, mfail)
#define g3SetBasedAllowedAtParent(class, this, bAllowed, mfail) \
        _g3SetBasedAllowedAtClass(class, TRUE, this, bAllowed, mfail)

#define g3SetCheckDefault(this, WkBnchObj, models, mfail) \
        _g3SetCheckDefaultAtClass(NULL, FALSE, this, WkBnchObj, models, mfail)
#define g3SetCheckDefaultAtClass(class, this, WkBnchObj, models, mfail) \
        _g3SetCheckDefaultAtClass(class, FALSE, this, WkBnchObj, models, mfail)
#define g3SetCheckDefaultAtParent(class, this, WkBnchObj, models, mfail) \
        _g3SetCheckDefaultAtClass(class, TRUE, this, WkBnchObj, models, mfail)

#define g3SetCommVars(className, mfail) \
        _g3SetCommVars(className, FALSE, className, mfail)
#define g3SetCommVarsAtParent(_class, className, mfail) \
        _g3SetCommVars(_class, TRUE, className, mfail)

#define g3SetDroppedOnGenWB(classname, SelectedItems, WkBnchObj, commObj, BackgroundItem, mfail) \
        _g3SetDroppedOnGenWB(classname, FALSE, classname, SelectedItems, WkBnchObj, commObj, BackgroundItem, mfail)
#define g3SetDroppedOnGenWBAtParent(_class, classname, SelectedItems, WkBnchObj, commObj, BackgroundItem, mfail) \
        _g3SetDroppedOnGenWB(_class, TRUE, classname, SelectedItems, WkBnchObj, commObj, BackgroundItem, mfail)

#define g3SetGIAttrs(this, PartObj, mfail) \
        _g3SetGIAttrsAtClass(NULL, FALSE, this, PartObj, mfail)
#define g3SetGIAttrsAtClass(class, this, PartObj, mfail) \
        _g3SetGIAttrsAtClass(class, FALSE, this, PartObj, mfail)
#define g3SetGIAttrsAtParent(class, this, PartObj, mfail) \
        _g3SetGIAttrsAtClass(class, TRUE, this, PartObj, mfail)

#define g3SetGIAttrsPost(this, PartObj, mfail) \
        _g3SetGIAttrsPostAtClass(NULL, FALSE, this, PartObj, mfail)
#define g3SetGIAttrsPostAtClass(class, this, PartObj, mfail) \
        _g3SetGIAttrsPostAtClass(class, FALSE, this, PartObj, mfail)
#define g3SetGIAttrsPostAtParent(class, this, PartObj, mfail) \
        _g3SetGIAttrsPostAtClass(class, TRUE, this, PartObj, mfail)

#define g3SetGIPartNumber(this, GIObj, mfail) \
        _g3SetGIPartNumberAtClass(NULL, FALSE, this, GIObj, mfail)
#define g3SetGIPartNumberAtClass(class, this, GIObj, mfail) \
        _g3SetGIPartNumberAtClass(class, FALSE, this, GIObj, mfail)
#define g3SetGIPartNumberAtParent(class, this, GIObj, mfail) \
        _g3SetGIPartNumberAtClass(class, TRUE, this, GIObj, mfail)

#define g3SetGIRelAttrs(this, RelObj, mfail) \
        _g3SetGIRelAttrsAtClass(NULL, FALSE, this, RelObj, mfail)
#define g3SetGIRelAttrsAtClass(class, this, RelObj, mfail) \
        _g3SetGIRelAttrsAtClass(class, FALSE, this, RelObj, mfail)
#define g3SetGIRelAttrsAtParent(class, this, RelObj, mfail) \
        _g3SetGIRelAttrsAtClass(class, TRUE, this, RelObj, mfail)

#define g3SetInstanceName(thisObj, sInstanceName, mfail) \
        _g3SetInstanceNameAtClass(NULL, FALSE, thisObj, sInstanceName, mfail)
#define g3SetInstanceNameAtClass(class, thisObj, sInstanceName, mfail) \
        _g3SetInstanceNameAtClass(class, FALSE, thisObj, sInstanceName, mfail)
#define g3SetInstanceNameAtParent(class, thisObj, sInstanceName, mfail) \
        _g3SetInstanceNameAtClass(class, TRUE, thisObj, sInstanceName, mfail)

#define g3SetOccName(this, OccName, mfail) \
        _g3SetOccNameAtClass(NULL, FALSE, this, OccName, mfail)
#define g3SetOccNameAtClass(class, this, OccName, mfail) \
        _g3SetOccNameAtClass(class, FALSE, this, OccName, mfail)
#define g3SetOccNameAtParent(class, this, OccName, mfail) \
        _g3SetOccNameAtClass(class, TRUE, this, OccName, mfail)

#define g3SetSpecificAttrs(ModRepObj, modObj, mfail) \
        _g3SetSpecificAttrsAtClass(NULL, FALSE, ModRepObj, modObj, mfail)
#define g3SetSpecificAttrsAtClass(class, ModRepObj, modObj, mfail) \
        _g3SetSpecificAttrsAtClass(class, FALSE, ModRepObj, modObj, mfail)
#define g3SetSpecificAttrsAtParent(class, ModRepObj, modObj, mfail) \
        _g3SetSpecificAttrsAtClass(class, TRUE, ModRepObj, modObj, mfail)

#define g3SetSwapFlag(classname, modelOBID, swapFlag, mfail) \
        _g3SetSwapFlag(classname, FALSE, classname, modelOBID, swapFlag, mfail)
#define g3SetSwapFlagAtParent(_class, classname, modelOBID, swapFlag, mfail) \
        _g3SetSwapFlag(_class, TRUE, classname, modelOBID, swapFlag, mfail)

#define g3StoreCtx(className, ctxObj, mfail) \
        _g3StoreCtx(className, FALSE, className, ctxObj, mfail)
#define g3StoreCtxAtParent(_class, className, ctxObj, mfail) \
        _g3StoreCtx(_class, TRUE, className, ctxObj, mfail)

#define g3SupplyObject(this, supplyFlag, supplyVL, pSupCpy, mfail) \
        _g3SupplyObjectAtClass(NULL, FALSE, this, supplyFlag, supplyVL, pSupCpy, mfail)
#define g3SupplyObjectAtClass(class, this, supplyFlag, supplyVL, pSupCpy, mfail) \
        _g3SupplyObjectAtClass(class, FALSE, this, supplyFlag, supplyVL, pSupCpy, mfail)
#define g3SupplyObjectAtParent(class, this, supplyFlag, supplyVL, pSupCpy, mfail) \
        _g3SupplyObjectAtClass(class, TRUE, this, supplyFlag, supplyVL, pSupCpy, mfail)

#define g3ToggleShowModels(className, mfail) \
        _g3ToggleShowModels(className, FALSE, className, mfail)
#define g3ToggleShowModelsAtParent(_class, className, mfail) \
        _g3ToggleShowModels(_class, TRUE, className, mfail)

#define g3UpdateObject(this, ctxObj, mfail) \
        _g3UpdateObjectAtClass(NULL, FALSE, this, ctxObj, mfail)
#define g3UpdateObjectAtClass(class, this, ctxObj, mfail) \
        _g3UpdateObjectAtClass(class, FALSE, this, ctxObj, mfail)
#define g3UpdateObjectAtParent(class, this, ctxObj, mfail) \
        _g3UpdateObjectAtClass(class, TRUE, this, ctxObj, mfail)

#define g3UpdateTrafo(this, rcvstr, mfail) \
        _g3UpdateTrafoAtClass(NULL, FALSE, this, rcvstr, mfail)
#define g3UpdateTrafoAtClass(class, this, rcvstr, mfail) \
        _g3UpdateTrafoAtClass(class, FALSE, this, rcvstr, mfail)
#define g3UpdateTrafoAtParent(class, this, rcvstr, mfail) \
        _g3UpdateTrafoAtClass(class, TRUE, this, rcvstr, mfail)

#define g3ValForUpdTrafo(this, mfail) \
        _g3ValForUpdTrafoAtClass(NULL, FALSE, this, mfail)
#define g3ValForUpdTrafoAtClass(class, this, mfail) \
        _g3ValForUpdTrafoAtClass(class, FALSE, this, mfail)
#define g3ValForUpdTrafoAtParent(class, this, mfail) \
        _g3ValForUpdTrafoAtClass(class, TRUE, this, mfail)

#define g3ValidateForExpand(thisObj, genContextObj, mfail) \
        _g3ValidateForExpandAtClass(NULL, FALSE, thisObj, genContextObj, mfail)
#define g3ValidateForExpandAtClass(class, thisObj, genContextObj, mfail) \
        _g3ValidateForExpandAtClass(class, FALSE, thisObj, genContextObj, mfail)
#define g3ValidateForExpandAtParent(class, thisObj, genContextObj, mfail) \
        _g3ValidateForExpandAtClass(class, TRUE, thisObj, genContextObj, mfail)

#define x3IsComponent(PartObj, bIsComponent, mfail) \
        _x3IsComponentAtClass(NULL, FALSE, PartObj, bIsComponent, mfail)
#define x3IsComponentAtClass(class, PartObj, bIsComponent, mfail) \
        _x3IsComponentAtClass(class, FALSE, PartObj, bIsComponent, mfail)
#define x3IsComponentAtParent(class, PartObj, bIsComponent, mfail) \
        _x3IsComponentAtClass(class, TRUE, PartObj, bIsComponent, mfail)
#endif /* for msggmi_H */

