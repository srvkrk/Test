extern SetOfStrings PartNum;

char* subString(char*,int,int);
status getData(string SubStr1,integer* mfail)
{
	status			dstat		= OKAY;
   	char			*mod_name 	= "getData";
		
	string str					= NULL;
	*mfail 						= USC_OKAY;
	

	str	=nlsStrAlloc(300);
	nlsStrCpy(str,SubStr1);

	printf("\nString Recieved: %s\n",str);fflush(stdout);
	low_set_add_str_unique(PartNum,str);

	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
	return( dstat );
}

void GetfullpathString(string ownername,string worklocation,string relativepath,SetOfStrings PartNum,string *FullPath)
{
				string  worklocationDup		=	NULL;
				string  ownernameDup	=	NULL;
				string  Address		=	NULL;
				string  relativepathDup		=	NULL;
				string  fullpath		=	NULL;
				string keyvaluestr							=   NULL;
				int		ii				=	0;
				int		length		=	0;
				int		lengthkeyval		=	0;
				int		indicator		=	0;
				
				Address=nlsStrAlloc(100);
				fullpath=nlsStrAlloc(150);
				keyvaluestr	=	nlsStrAlloc(150);
				
				low_trimb(ownername);
				low_trimb(worklocation);

				ownernameDup=nlsStrDup(ownername);
				worklocationDup=nlsStrDup(worklocation);
				relativepathDup=nlsStrDup(relativepath);

				nlsStrCpy(Address,ownernameDup);
				nlsStrCat(Address,":");
				nlsStrCat(Address,worklocation);

				printf("Address=%s\n",Address);fflush(stdout);
				length=nlsStrLen(Address);

				for (ii=0;ii<low_set_size(PartNum) ; ii++)
			{
				
				nlsStrCpy(keyvaluestr,low_set_get(PartNum,ii));

				printf("keyvaluestr=%s\n",keyvaluestr);
				if(nlsStrStr(keyvaluestr,Address)!=NULL)
				{
						lengthkeyval=nlsStrLen(keyvaluestr);
						
						fullpath=subString(keyvaluestr,length+1,lengthkeyval);
						
						printf("Base Path Value =%s\n",fullpath);fflush(stdout);
						nlsStrCat(fullpath,"/");
						printf("After cat fullpath=%s\n",fullpath);
						nlsStrCat(fullpath,relativepathDup);
						printf("After cat 1 fullpath=%s\n ",fullpath);
						nlsStrCpy(*FullPath,fullpath);
						printf("my full path value is =%s ",*FullPath);fflush(stdout);
						indicator=1;
						break;
				}


			}

				if(!indicator)
				{
					printf("Full Path Not Found for ownername=%s,worklocation=%s,relativepath=%s\n",ownername,worklocation,relativepath);
				}
				printf("\n************Now i WIll Print Value of FUll Path ***************\n");fflush(stdout);
				printf("*****  FullPathValue *** =%s\n",*FullPath);fflush(stdout);

		
}
