/**********************************************************************/
/*                                                                    */
/* wmapi2.h                                                           */
/*                                                                    */
/* Workflow application programming interface include file. This is   */
/* the file supplied by the Workflow Management Coalition.            */
/* It contains standard parameters, function and value definitions.   */
/* Errors and inconsistencies have been corrected by SAP AG.          */
/* (WAPI interface 2, Version 1.1, January 1997).                     */
/*                                                                    */
/* Author:		Workflow Management Coalition                           */
/* Modifier:	Stefan Maier, SAP AG.                                   */
/*                                                                    */
/* Standard C code (fully portable)                                   */
/*                                                                    */
/**********************************************************************/


/* SAP: File name modified to wmapi2.h and #ifndef adapted to it */
#ifndef WMAPI2_H
#define WMAPI2_H


/* SAP: To have a uniform writing all "work_item"s have been replaced
        by "workitem". */


/* WM*  - all global Workflow Management symbols start with WM
   WMT* - all type definitions start with WMT */

/**********************************************************************/
/*                                                                    */
/* Basic Type Definitions:                                            */
/*                                                                    */
/* Before including this file, the following types have to be type    */
/* defined by the vendor according to the current platform            */
/* definitions. All other WORKFLOW MANAGEMENT types are derived from  */
/* these basic types.                                                 */
/*                                                                    */  
/* WMTInt8       signed    8 bit value representation                 */
/* WMTInt16      signed   16 bit value representation                 */
/* WMTInt32      signed   32 bit value representation                 */
/*                                                                    */
/* WMTUInt8      unsigned  8 bit value representation                 */
/* WMTUInt16     unsigned 16 bit value representation                 */
/* WMTUInt32     unsigned 32 bit value representation                 */
/*                                                                    */
/* WMTPInt8       8 bit pointer value representation                  */
/* WMTPInt16     16 bit pointer value representation                  */
/* WMTPInt32     32 bit pointer value representation                  */
/*                                                                    */
/**********************************************************************/


#include "wmtbasic.h"


/**********************************************************************/
/* This section defines all the structures used by the interface 2    */
/* API.                                                               */
/**********************************************************************/
		 

/* WMTErrRetType */
typedef struct
{
  WMTInt16          main_code;
  WMTInt16          sub_code;

} WMTErrRetType;


/* WMTConnectInfo */
typedef struct
{
  WMTText           user_identification[NAME_STRING_SIZE];
  WMTText           password[NAME_STRING_SIZE];    
  WMTText           engine_name[NAME_STRING_SIZE];
  WMTText           scope[NAME_STRING_SIZE];

} WMTConnectInfo;

typedef WMTConnectInfo *WMTPConnectInfo;


/* WMTSessionHandle */
typedef struct
{
  WMTUInt32         session_id;
  WMTPPrivate       pprivate;

} WMTSessionHandle;

typedef WMTSessionHandle *WMTPSessionHandle;


/* WMTFilter */
typedef struct
{
  WMTInt32          filter_type;
  WMTInt32          filter_length;
  WMTText           attribute_name [NAME_STRING_SIZE];
  WMTUInt32         comparison;
  WMTPText          filter_string;

} WMTFilter;  

typedef WMTFilter *WMTPFilter;


/**********************************************************************/
/* The first 255 filter types (0x00000001 to 0x000000FF) will be      */
/* reserved.                                                          */   
/* These will be used for filtering on attributes of process control  */
/* data and process relevant data.                                    */
/**********************************************************************/


/* WMTQueryHandle */
typedef struct
{
  WMTUInt32         query_handle;

} WMTQueryHandle;

typedef WMTQueryHandle *WMTPQueryHandle;


/* WMTWflParticipant */
typedef struct
{
  WMTText           wf_participant[NAME_STRING_SIZE];

} WMTWflParticipant;

typedef WMTWflParticipant *WMTPWflParticipant;


/* WMTProcDefID */
typedef struct
{
  WMTText           proc_def_id[UNIQUE_ID_SIZE];

}WMTProcDefID;

typedef WMTProcDefID *WMTPProcDefID;


/* WMTActivityID */
/* SAP: NAME_STRING_SIZE has been replaced by UNIQUE_ID_SIZE */
typedef struct
{
  WMTText           activity_id[UNIQUE_ID_SIZE];

}WMTActivityID;

typedef WMTActivityID *WMTPActivityID;


/* WMTProcDefState */
typedef struct
{
  WMTText           proc_def_state[NAME_STRING_SIZE];

} WMTProcDefState;

typedef WMTProcDefState *WMTPProcDefState;


/* WMTProcDef */
typedef struct
{
  WMTText           process_name[NAME_STRING_SIZE];
  WMTProcDefID      proc_def_id;
  WMTProcDefState   state;

} WMTProcDef;

typedef WMTProcDef *WMTPProcDef;


/* WMTProcInstID */
typedef struct
{
  WMTText           proc_inst_id[UNIQUE_ID_SIZE];

} WMTProcInstID;

typedef WMTProcInstID *WMTPProcInstID;


/* WMTProcInstState */
typedef struct
{
  WMTText           proc_inst_state[NAME_STRING_SIZE];

} WMTProcInstState;

typedef WMTProcInstState *WMTPProcInstState;


/* WMTProcInst */
typedef struct
{

  WMTText           process_name[NAME_STRING_SIZE];
  WMTProcInstID     proc_inst_id;
  WMTProcDefID      proc_def_id;
  WMTProcInstState  state;
  WMTInt32          priority;
  WMTWflParticipant proc_participants[20];
  
} WMTProcInst;

typedef WMTProcInst *WMTPProcInst;


/* WMTActivityInstID */
typedef struct
{
  WMTText           activity_inst_id[UNIQUE_ID_SIZE];

} WMTActivityInstID;

typedef WMTActivityInstID *WMTPActivityInstID;


/* WMTActivityInstState */
typedef struct
{
  WMTText           activity_inst_state[NAME_STRING_SIZE];

} WMTActivityInstState;

typedef WMTActivityInstState *WMTPActivityInstState;


/* WMTActivityInst */
typedef struct
{
  WMTText					      activity_name[NAME_STRING_SIZE];
  WMTActivityInstID		  activity_inst_id;
  WMTProcInstID				  proc_inst_id;
  WMTActivityInstState  state;
  WMTInt32					    priority;
  WMTWflParticipant			activity_participants[10];

} WMTActivityInst;

typedef WMTActivityInst *WMTPActivityInst;


/* WMTWorkItemID */
typedef struct
{
  WMTText               workitem_id[UNIQUE_ID_SIZE];

} WMTWorkItemID;

typedef WMTWorkItemID *WMTPWorkItemID;


/* WMTWorkItem */
typedef struct
{
  WMTText               workitem_name[NAME_STRING_SIZE];
  WMTWorkItemID         workitem_id;
  WMTActivityInstID     activity_inst_id;
  WMTProcInstID         proc_inst_id;
  WMTInt32              priority;
  WMTWflParticipant     participant;

} WMTWorkItem;

typedef WMTWorkItem *WMTPWorkItem;


/* WMTAttrName */
typedef WMTText WMTAttrName[NAME_STRING_SIZE];

typedef WMTAttrName *WMTPAttrName;

  
/**********************************************************************/
/*                                                                    */
/*  WAPI - Interface 2 function declarations.                         */
/*                                                                    */
/*  The definitions include specification of parameters with          */
/*  indication of the direction of data passing:                      */
/*                                                                    */
/*	in	for parameters with data being passed to the API fuction      */
/*	out	for parameters with data being passed from the API function   */
/*                                                                    */
/**********************************************************************/

#define in
#define out 					

/* WMConnect */
WMTErrRetType WMConnect (
  in  WMTPConnectInfo pconnect_info,
  out WMTPSessionHandle psession_handle);


/* WMDisconnect */
WMTErrRetType WMDisconnect (
  in  WMTPSessionHandle psession_handle);


/* WMOpenProcessDefinitionList */
WMTErrRetType WMOpenProcessDefinitionList (
  in  WMTPSessionHandle psession_handle,
  in  WMTPFilter pproc_def_filter, 
  in  WMTBoolean count_flag,
  out WMTPQueryHandle pquery_handle, 
  out WMTPInt32 pcount);


/* WMFetchProcessDefinition */
WMTErrRetType WMFetchProcessDefinition (
  in  WMTPSessionHandle psession_handle,
  in  WMTPQueryHandle pquery_handle,
  out WMTPProcDef pproc_def_buf_ptr);


/* WMCloseProcessDefinitionList */
WMTErrRetType WMCloseProcessDefinitionList(
  in  WMTPSessionHandle psession_handle,
  in  WMTPQueryHandle pquery_handle);


/* WMOpenProcessDefinitionStatesList */
/* SAP: Last param -> datatype changed to WMTPInt32 */
WMTErrRetType WMOpenProcessDefinitionStatesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcDefID pproc_def_id, 
  in  WMTPFilter pproc_def_state_filter, 
  in  WMTBoolean count_flag, 
  out WMTPQueryHandle pquery_handle,
  out WMTPInt32 pcount);


/* WMFetchProcessDefinitionState */
WMTErrRetType WMFetchProcessDefinitionState (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle,
  out WMTPProcDefState pproc_def_state);


/* WMCloseProcessDefinitionStatesList */
WMTErrRetType WMCloseProcessDefinitionStatesList (
  in  WMTPSessionHandle psession_handle,
  in  WMTPQueryHandle pquery_handle);


/* WMChangeProcessDefinitionState */
WMTErrRetType WMChangeProcessDefinitionState (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcDefID pproc_def_id, 
  in  WMTPProcDefState pproc_def_state);


/* WMCreateProcessInstance */
WMTErrRetType WMCreateProcessInstance (
  in  WMTPSessionHandle psession_handle,
  in  WMTPProcDefID pproc_def_id,
  in  WMTPText pproc_inst_name,
  out WMTPProcInstID pproc_inst_id);


/* WMStartProcess */
WMTErrRetType WMStartProcess (
  in  WMTPSessionHandle psession_handle,
  in  WMTPProcInstID  pproc_inst_id, 
  out WMTPProcInstID  pnew_proc_inst_id );


/* WMTerminateProcessInstance */
WMTErrRetType WMTerminateProcessInstance (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id); 


/* WMOpenProcessInstanceStatesList */
WMTErrRetType WMOpenProcessInstanceStatesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPFilter pproc_inst_state_filter, 
  in  WMTBoolean count_flag, 
  out WMTPQueryHandle pquery_handle, 
  out WMTPInt32 pcount);


/* WMFetchProcessInstanceState */
WMTErrRetType WMFetchProcessInstanceState (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle, 
  out WMTPProcInstState pproc_inst_state);


/* WMCloseProcessInstanceStatesList */
WMTErrRetType WMCloseProcessInstanceStatesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle);


/* WMChangeProcessInstanceState */
WMTErrRetType WMChangeProcessInstanceState (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPProcInstState pproc_inst_state);


/* WMOpenProcessInstanceAttributesList */
WMTErrRetType WMOpenProcessInstanceAttributesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPFilter pproc_inst_attr_filter, 
  in  WMTBoolean count_flag, 
  out WMTPQueryHandle pquery_handle, 
  out WMTPInt32 pcount);


/* WMFetchProcessInstanceAttribute */
WMTErrRetType WMFetchProcessInstanceAttribute (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle,
  out WMTPAttrName pattribute_name,
  out WMTPInt32 pattribute_type,
  out WMTPInt32 pattribute_length,
  out WMTPText pattribute_value,
  in  WMTInt32 buffer_size); 


/* WMCloseProcessInstanceAttributesList */
WMTErrRetType WMCloseProcessInstanceAttributesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle);


/* WMGetProcessInstanceAttributeValue */
WMTErrRetType WMGetProcessInstanceAttributeValue (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPAttrName pattribute_name,
  out WMTPInt32 pattribute_type,
  out WMTPInt32 pattribute_length,
  out WMTPText pattribute_value,
  in  WMTInt32 buffer_size);


/* WMAssignProcessInstanceAttribute */
WMTErrRetType WMAssignProcessInstanceAttribute (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPAttrName pattribute_name,
  in  WMTInt32 attribute_type,
  in  WMTInt32 attribute_length,
  in  WMTPText pattribute_value);


/* WMOpenActivityInstanceStatesList */
WMTErrRetType WMOpenActivityInstanceStatesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPActivityInstID pactivity_inst_id, 
  in  WMTPFilter pact_inst_state_filter, 
  in  WMTBoolean count_flag, 
  out WMTPQueryHandle pquery_handle, 
  out WMTPInt32 pcount);


/* WMFetchActivityInstanceState */
WMTErrRetType WMFetchActivityInstanceState (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle,
  out WMTPActivityInstState pactivity_inst_state);


/* WMCloseActivityInstanceStatesList */
WMTErrRetType WMCloseActivityInstanceStatesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle);


/* WMChangeActivityInstanceState */
WMTErrRetType WMChangeActivityInstanceState (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPActivityInstID pactivity_inst_id,
  in  WMTPActivityInstState pactivity_inst_state);


/* WMOpenActivityInstanceAttributesList */
WMTErrRetType WMOpenActivityInstanceAttributesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPActivityInstID pactivity_inst_id, 
  in  WMTPFilter pact_inst_attr_filter, 
  in  WMTBoolean count_flag, 
  out WMTPQueryHandle pquery_handle, 
  out WMTPInt32 pcount);


/* WMFetchActivityInstanceAttribute */
WMTErrRetType WMFetchActivityInstanceAttribute (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle,
  out WMTPAttrName pattribute_name,
  out WMTPInt32 pattribute_type,
  out WMTPInt32 pattribute_length,
  out WMTPText pattribute_value,
  in  WMTInt32 buffer_size); 


/* WMCloseActivityInstanceAttributesList */
WMTErrRetType WMCloseActivityInstanceAttributesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle);


/* WMGetActivityInstanceAttributeValue */
WMTErrRetType WMGetActivityInstanceAttributeValue (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPActivityInstID pactivity_inst_id, 
  in  WMTPAttrName pattribute_name,
  out WMTPInt32 pattribute_type,
  out WMTPInt32 pattribute_length,
  out WMTPText pattribute_value,
  in  WMTInt32 buffer_size);


/* WMAssignActivityInstanceAttribute */
/* SAP: Second param changed from WMTPProcDefID pproc_def_id to
        WMTPProcInstID pproc_inst_id */
WMTErrRetType WMAssignActivityInstanceAttribute (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPActivityInstID pactivity_inst_id, 
  in  WMTPAttrName pattribute_name,
  in  WMTInt32 attribute_type,
  in  WMTInt32 attribute_length,
  in  WMTPText pattribute_value);


/* WMOpenProcessInstancesList */
WMTErrRetType WMOpenProcessInstancesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPFilter pproc_inst_filter, 
  in  WMTBoolean count_flag, 
  out WMTPQueryHandle pquery_handle, 
  out WMTPInt32 pcount);


/* WMFetchProcessInstance */
WMTErrRetType WMFetchProcessInstance (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPQueryHandle pquery_handle,
  out WMTPProcInst pproc_inst_buf_ptr);


/* WMCloseProcessInstancesList */
WMTErrRetType WMCloseProcessInstancesList (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPQueryHandle pquery_handle);


/* WMGetProcessInstance */
WMTErrRetType WMGetProcessInstance (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPProcInstID pproc_inst_id, 
  out WMTPProcInst pproc_inst);


/* WMOpenActivityInstancesList */
WMTErrRetType WMOpenActivityInstancesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPFilter pactivity_inst_filter, 
  in  WMTBoolean count_flag, 
  out WMTPQueryHandle pquery_handle,
  out WMTPInt32 pcount);


/* WMFetchActivityInstance */
WMTErrRetType WMFetchActivityInstance (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPQueryHandle pquery_handle, 
  out WMTPActivityInst pactivity_inst);


/* WMCloseActivityInstancesList */
WMTErrRetType WMCloseActivityInstancesList (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPQueryHandle pquery_handle);


/* WMGetActivityInstance */
WMTErrRetType WMGetActivityInstance (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPActivityInstID pactivity_inst_id, 
  out WMTPActivityInst pactivity_inst );


/* WMOpenWorkList */
WMTErrRetType WMOpenWorkList (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPFilter pworklist_filter, 
  in  WMTBoolean count_flag,
  out WMTPQueryHandle pquery_handle,
  out WMTPInt32 pcount);


/* WMFetchWorkItem */
WMTErrRetType WMFetchWorkItem (
  in  WMTPSessionHandle psession_handle,
  in  WMTPQueryHandle pquery_handle, 
  out WMTPWorkItem pworkitem); 


/* WMCloseWorkList */
WMTErrRetType WMCloseWorkList (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPQueryHandle pquery_handle);


/* WMGetWorkItem */
WMTErrRetType WMGetWorkItem (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPWorkItemID pworkitem_id, 
  out WMTPWorkItem pworkitem );


/* WMCompleteWorkItem */
WMTErrRetType WMCompleteWorkItem (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPProcInstID pproc_inst_id,   
  in  WMTPWorkItemID pworkitem_id);


/* WMReassignWorkItem */
WMTErrRetType WMReassignWorkItem (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPWflParticipant psource_user, 
  in  WMTPWflParticipant ptarget_user,
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPWorkItemID pworkitem_id); 


/* WMOpenWorkItemAttributesList */
WMTErrRetType WMOpenWorkItemAttributesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPWorkItemID pworkitem_id, 
  in  WMTPFilter pworkitem_attr_filter, 
  in  WMTBoolean count_flag, 
  out WMTPQueryHandle pquery_handle, 
  out WMTPInt32 pcount);


/* WMFetchWorkItemAttribute */
WMTErrRetType WMFetchWorkItemAttribute (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle, 
  out WMTPAttrName pattribute_name,
  out WMTPInt32 pattribute_type,
  out WMTPInt32 pattribute_length,
  out WMTPText pattribute_value,
  in  WMTInt32 buffer_size); 


/* WMCloseWorkItemAttributesList */
WMTErrRetType WMCloseWorkItemAttributesList (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPQueryHandle pquery_handle);


/* WMGetWorkItemAttributeValue */
WMTErrRetType WMGetWorkItemAttributeValue (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id, 
  in  WMTPWorkItemID pworkitem_id, 
  in  WMTPAttrName pattribute_name,
  out WMTPInt32 pattribute_type,
  out WMTPInt32 pattribute_length,
  out WMTPText pattribute_value,
  in  WMTInt32 buffer_size);


/* WMAssignWorkItemAttribute */
WMTErrRetType WMAssignWorkItemAttribute (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcInstID pproc_inst_id,   
  in  WMTPWorkItemID pworkitem_id, 
  in  WMTPAttrName pattribute_name,
  in  WMTInt32 attribute_type,
  in  WMTInt32 attribute_length,
  in  WMTPText pattribute_value);


/* WMChangeProcessInstancesState */
WMTErrRetType WMChangeProcessInstancesState (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcDefID pproc_def_id, 
  in  WMTPFilter pproc_inst_filter,
  in  WMTPProcInstState pproc_inst_state);


/* WMChangeActivityInstancesState */
WMTErrRetType WMChangeActivityInstancesState (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcDefID pproc_def_id, 
  in  WMTPActivityID pactivity_def_id, 
  in  WMTPFilter pact_inst_filter,
  in  WMTPActivityInstState pactivity_inst_state);


/* WMTerminateProcessInstances */
WMTErrRetType WMTerminateProcessInstances (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcDefID pproc_def_id,
  in  WMTPFilter pproc_inst_filter);


/* WMAssignProcessInstancesAttribute */
WMTErrRetType WMAssignProcessInstancesAttribute (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcDefID pproc_def_id, 
  in  WMTPFilter pproc_inst_filter,
  in  WMTPAttrName pattribute_name,
  in  WMTInt32 attribute_type,
  in  WMTInt32 attribute_length,
  in  WMTPText pattribute_value);


/* WMAssignActivityInstancesAttribute */
WMTErrRetType WMAssignActivityInstancesAttribute (
  in  WMTPSessionHandle psession_handle, 
  in  WMTPProcDefID pproc_def_id, 
  in  WMTPActivityID pactivity_def_id, 
  in  WMTPFilter pact_inst_filter,
  in  WMTPAttrName pattribute_name,
  in  WMTInt32 attribute_type,
  in  WMTInt32 attribute_length,
  in  WMTPText pattribute_value);


/* WMAbortProcessInstances */
WMTErrRetType WMAbortProcessInstances (
  in  WMTPSessionHandle psession_handle,  
  in  WMTPProcDefID pproc_def_id,
  in  WMTPFilter pproc_inst_filter); 


/* WMAbortProcessInstance */
WMTErrRetType WMAbortProcessInstance (
  in  WMTPSessionHandle psession_handle,
  in  WMTPProcInstID pproc_inst_id);

#endif
