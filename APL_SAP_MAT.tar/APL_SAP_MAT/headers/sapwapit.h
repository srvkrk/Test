/**********************************************************************/
/*                                                                    */
/* (C) Copyright  SAP AG, Walldorf 1997                               */
/*                                                                    */
/* sapwapit.h                                                         */
/*                                                                    */
/* Workflow application programming interface. New datatypes for the  */
/* SAP WAPI functions SAPWapiStartWorkFlow and SAPWapiCreateEvent.		*/
/* (WAPI interface 2, Version 1.1, March 1997).                       */
/*                                                                    */
/* Author:		Stefan Maier																					  */
/* Reviewer:	Rainer Weber																						*/
/*                                                                    */
/* Standard C code (fully portable)                                   */
/*                                                                    */
/**********************************************************************/


#ifndef SAPWAPIT_H
#define SAPWAPIT_H


/* Include files */
#include "wmapi2.h"
#include "wmconste.h"


/*************************************************************/
/* Datatypes for SAPWapiStartWorkFlow and SAPWapiCreateEvent */
/*************************************************************/


/* Get & assign of attribute values */
typedef struct
{
  WMTText             item_id[UNIQUE_ID_SIZE];

} SAPWapiTItemID;

typedef SAPWapiTItemID* SAPWapiTPItemID;


/* R/3 Task definition */
typedef struct
{
	WMTText							task_id[UNIQUE_ID_SIZE];

} SAPWapiTTaskID;

typedef SAPWapiTTaskID* SAPWapiTPTaskID;

/* SAPWapiTMessage */
/* Note: This struct will be transferred to the user via 
         SAPWapiStartWorkFlow. Therefore the element array sizes of 
         SWR_MESSAG have been increased by 1 (to append a NULL_BYTE). */
typedef struct
{
  WMTText   msg_type[2];
  WMTText   line[274];

} SAPWapiTMessage;

typedef SAPWapiTMessage* SAPWapiTPMessage;

/* SAPWapiTContainer */
/* Note: This struct must be transferred to the function 
         SAPWapiStartWorkFlow via the user. Therefore the element array 
         sizes of SWR_CONT have been increased by 1 (to append a 
         NULL_BYTE). */
typedef struct
{
  WMTText   element[33];
  WMTText   value[256];

} SAPWapiTContainer;

typedef SAPWapiTContainer* SAPWapiTPContainer;

/* New types for SAPWapiCreateEvent */

/* SAPWapiTObjectType */
typedef WMTText SAPWapiTObjectType[SAP_WAPI_SIZE_OBJECT_TYPE + 1];

typedef SAPWapiTObjectType* SAPWapiTPObjectType;

/* SAPWapiTObjectKey */
typedef WMTText SAPWapiTObjectKey[SAP_WAPI_SIZE_OBJECT_KEY + 1];

typedef SAPWapiTObjectKey* SAPWapiTPObjectKey;

/* SAPWapiTEvent */
typedef WMTText SAPWapiTEvent[SAP_WAPI_SIZE_EVENT + 1];

typedef SAPWapiTEvent* SAPWapiTPEvent;

/* SAPWapiTEventID */
typedef WMTText SAPWapiTEventID[SAP_WAPI_SIZE_EVENT_ID + 1];

typedef SAPWapiTEventID* SAPWapiTPEventID;


#endif
