#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned long magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[9];
};
static struct sqlcxp sqlfpn =
{
    8,
    "Part3.pc"
};


static unsigned long sqlctx = 19187;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   unused;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   unsigned char  **sqphsv;
   unsigned int   *sqphsl;
            short **sqpind;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned char  *sqhstv[7];
   unsigned int   sqhstl[7];
            short *sqindv[7];
   unsigned int   sqharm[7];
   unsigned int   *sqharc[7];
} sqlstm = {8,7};

/* Prototypes */
extern sqlcxt (/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2t(/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuft(/*_ void **, char * _*/);
extern sqlgs2t(/*_ void **, char * _*/);
extern sqlorat(/*_ void **, unsigned long *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern void sqliem(/*_ char *, int * _*/);

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static short sqlcud0[] =
{8,4098,
2,0,0,1,0,0,539,62,0,3,3,0,1,0,1,9,0,0,1,9,0,0,1,10,0,0,
28,0,0,2,36,0,516,76,0,1,0,0,1,0,2,9,0,0,
46,0,0,3,63,0,515,78,0,2,2,0,1,0,1,9,0,0,1,9,0,0,
68,0,0,4,75,0,515,85,0,3,3,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,
94,0,0,5,38,0,517,89,0,1,1,0,1,0,1,9,0,0,
112,0,0,6,113,0,515,93,0,5,5,0,1,0,1,9,0,0,1,3,0,0,1,9,0,0,1,9,0,0,1,9,0,0,
146,0,0,7,141,0,515,110,0,7,7,0,1,0,1,9,0,0,1,9,0,0,1,4,0,0,1,3,0,0,1,9,0,0,1,
9,0,0,1,9,0,0,
188,0,0,8,75,0,515,112,0,2,2,0,1,0,1,9,0,0,1,9,0,0,
210,0,0,9,0,0,542,114,0,0,0,0,1,0,
};


 #include <stdio.h>
#include <AZ_ato.h>
#include <ZZ_sqlerr.h>
#define TRUE 1
#define FALSE 0



/* EXEC SQL BEGIN DECLARE SECTION ; */ 

	/* VARCHAR uid[20] ; */ 
struct { unsigned short len; unsigned char arr[20]; } uid;

	/* VARCHAR pwd[20] ; */ 
struct { unsigned short len; unsigned char arr[20]; } pwd;

	/* VARCHAR user_password[1] ; */ 
struct { unsigned short len; unsigned char arr[1]; } user_password;

        /* varchar userid[10], password[15] ; */ 
struct { unsigned short len; unsigned char arr[10]; } userid;

struct { unsigned short len; unsigned char arr[15]; } password;

	char PartNumber[20];
	char Nomenclature[20];

	/* VARCHAR OPartNumber[14]; */ 
struct { unsigned short len; unsigned char arr[14]; } OPartNumber;

	/* VARCHAR ONomenclature[40]; */ 
struct { unsigned short len; unsigned char arr[40]; } ONomenclature;

	/* VARCHAR ODmlNo[10]; */ 
struct { unsigned short len; unsigned char arr[10]; } ODmlNo;

	/* VARCHAR OErcEffDate[10]; */ 
struct { unsigned short len; unsigned char arr[10]; } OErcEffDate;

	/* VARCHAR OParent[14]; */ 
struct { unsigned short len; unsigned char arr[14]; } OParent;

	/* VARCHAR OChild[14]; */ 
struct { unsigned short len; unsigned char arr[14]; } OChild;

	/* VARCHAR ODmlGroup[14]; */ 
struct { unsigned short len; unsigned char arr[14]; } ODmlGroup;

	/* VARCHAR ODmlType[14]; */ 
struct { unsigned short len; unsigned char arr[2]; } ODmlType;

	int OMainSrl;
	int OGroupId ;
	int OSheetNo ;
	double OQty;

 
#ifndef SQLCA
#define SQLCA 1
 
struct   sqlca
         {
         /* ub1 */ char    sqlcaid[8];
         /* b4  */ long    sqlabc;
         /* b4  */ long    sqlcode;
         struct
           {
           /* ub2 */ unsigned short sqlerrml;
           /* ub1 */ char           sqlerrmc[70];
           } sqlerrm;
         /* ub1 */ char    sqlerrp[8];
         /* b4  */ long    sqlerrd[6];
         /* ub1 */ char    sqlwarn[8];
         /* ub1 */ char    sqlext[8];
         };

#ifndef SQLCA_NONE 
#ifdef   SQLCA_STORAGE_CLASS
SQLCA_STORAGE_CLASS struct sqlca sqlca
#else
         struct sqlca sqlca
#endif
 
#ifdef  SQLCA_INIT
         = {
         {'S', 'Q', 'L', 'C', 'A', ' ', ' ', ' '},
         sizeof(struct sqlca),
         0,
         { 0, {0}},
         {'N', 'O', 'T', ' ', 'S', 'E', 'T', ' '},
         {0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0}
         }
#endif
         ;
#endif
 
#endif
 
/* end SQLCA */

void sql_error(char msg[]);

int valid;

void sql_error(char msg[]) 
{
    char err_msg[128];
    size_t buf_len, msg_len;
/* EXEC SQL whenever sqlerror continue; */ 
/* print error message */
    printf("\n%s\n", msg);
    buf_len = sizeof (err_msg);
    sqlglm(err_msg, &buf_len, &msg_len);
    printf("%.*s\n", msg_len, err_msg);
}  


