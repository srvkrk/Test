/*
 *  FILE: msgcmiP.h
 */

#ifndef msgcmiP_H
#define msgcmiP_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _x3DocExpandExecFastAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string cmi_ID, SetOfStrings * xmlFile, integer * mfail);

MTIstatus _x3DocExpandFastAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string cmi_ID, SetOfStrings * xmlFile, integer * mfail);

MTIstatus _x3ExpandExecSetBased
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects topObjSet, SetOfObjects topRelSet, integer expandLevel,
   SetOfStrings cmi_ID_set, SetOfObjects * xmlFileSet, integer * mfail);

MTIstatus _x3ExpandSetBasedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer expandLevel, string cmi_ID, SetOfStrings * xmlFile,
   integer * mfail);

MTIstatus _x3UpdateForECMI
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings structureFile, SetOfStrings * ticketObject, integer * mfail);

MTIstatus _x3XMLModelInfoFastAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string cmi_ID, SetOfStrings * xmlFile, integer * mfail);

#ifdef _LCINTERP_
}
#else
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define x3DocExpandExecFast(thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandExecFastAtClass(NULL, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3DocExpandExecFastAtClass(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandExecFastAtClass(class, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3DocExpandExecFastAtParent(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandExecFastAtClass(class, TRUE, thisObj, cmi_ID, xmlFile, mfail)

#define x3DocExpandFast(thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandFastAtClass(NULL, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3DocExpandFastAtClass(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandFastAtClass(class, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3DocExpandFastAtParent(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandFastAtClass(class, TRUE, thisObj, cmi_ID, xmlFile, mfail)

#define x3ExpandExecSetBased(classname, topObjSet, topRelSet, expandLevel, cmi_ID_set, xmlFileSet, mfail) \
        _x3ExpandExecSetBased(classname, FALSE, classname, topObjSet, topRelSet, expandLevel, cmi_ID_set, xmlFileSet, mfail)
#define x3ExpandExecSetBasedAtParent(_class, classname, topObjSet, topRelSet, expandLevel, cmi_ID_set, xmlFileSet, mfail) \
        _x3ExpandExecSetBased(_class, TRUE, classname, topObjSet, topRelSet, expandLevel, cmi_ID_set, xmlFileSet, mfail)

#define x3ExpandSetBased(thisObj, expandLevel, cmi_ID, xmlFile, mfail) \
        _x3ExpandSetBasedAtClass(NULL, FALSE, thisObj, expandLevel, cmi_ID, xmlFile, mfail)
#define x3ExpandSetBasedAtClass(class, thisObj, expandLevel, cmi_ID, xmlFile, mfail) \
        _x3ExpandSetBasedAtClass(class, FALSE, thisObj, expandLevel, cmi_ID, xmlFile, mfail)
#define x3ExpandSetBasedAtParent(class, thisObj, expandLevel, cmi_ID, xmlFile, mfail) \
        _x3ExpandSetBasedAtClass(class, TRUE, thisObj, expandLevel, cmi_ID, xmlFile, mfail)

#define x3UpdateForECMI(ClassName, structureFile, ticketObject, mfail) \
        _x3UpdateForECMI(ClassName, FALSE, ClassName, structureFile, ticketObject, mfail)
#define x3UpdateForECMIAtParent(_class, ClassName, structureFile, ticketObject, mfail) \
        _x3UpdateForECMI(_class, TRUE, ClassName, structureFile, ticketObject, mfail)

#define x3XMLModelInfoFast(thisObj, cmi_ID, xmlFile, mfail) \
        _x3XMLModelInfoFastAtClass(NULL, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3XMLModelInfoFastAtClass(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3XMLModelInfoFastAtClass(class, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3XMLModelInfoFastAtParent(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3XMLModelInfoFastAtClass(class, TRUE, thisObj, cmi_ID, xmlFile, mfail)
#endif /* for msgcmi_H */

