/*
------------------------------------------------------------------------
  SAP AG - R/3 Remote Function Call Interface Generation
    RFC_ANSIC_CL_EXP EN 46C
    19.12.2007 16:54
    Complete ANSI C client example
    saprfccl.h
------------------------------------------------------------------------
*/

#ifndef SAPRFCcl_H
#define SAPRFCcl_H

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "saprfc.h"
#include "sapitab.h"

/*
------------------------------------------------------------------------

  Call function BAPI_MATERIAL_SAVEDATA
      exporting
        CLIENTDATA structure BAPI_MARA length 662 number of fields 89
        CLIENTDATAX structure BAPI_MARAX length 89 number of fields 89
        FLAG_CAD_CALL like BAPIMATHEAD_INP_FLD_CHECK default SPACE type RFC_CHAR length 1
        FLAG_ONLINE like BAPIMATHEAD_INP_FLD_CHECK default SPACE type RFC_CHAR length 1
        FORECASTPARAMETERS structure BAPI_MPOP length
47 number of fields 21
        FORECASTPARAMETERSX structure BAPI_MPOPX length 24 number of fields 21
        HEADDATA structure BAPIMATHEAD length 118 number of fields 19
        NO_DEQUEUE like BAPIMATHEAD_INP_FLD_CHECK default SPACE type RFC_CHAR length 1
        PLANNINGDATA structure BAPI_MPGD length
118 number of fields 7
        PLANNINGDATAX structure BAPI_MPGDX length 10 number of fields 7
        PLANTDATA structure BAPI_MARC length 773 number of fields 161
        PLANTDATAX structure BAPI_MARCX length 164 number of fields 161
        SALESDATA structure BAPI_MVKE length 227 number of fields 44
        SALESDATAX structure BAPI_MVKEX length 48 number of fields 44
        STORAGELOCATIONDATA structure BAPI_MARD length 48 number of fields 10
        STORAGELOCATIONDATAX structure BAPI_MARDX length 16 number of fields 10
        STORAGETYPEDATA structure BAPI_MLGT length 55 number of fields 10
        STORAGETYPEDATAX structure BAPI_MLGTX length 14 number of fields 10
        VALUATIONDATA structure BAPI_MBEW length 315 number of fields 49
        VALUATIONDATAX structure BAPI_MBEWX length 61 number of fields 49
        WAREHOUSENUMBERDATA structure BAPI_MLGN length 89 number of fields 29
        WAREHOUSENUMBERDATAX structure BAPI_MLGNX length 31 number of fields 29
      importing
        RETURN structure BAPIRET2 length 548 number of fields 14
      tables
        EXTENSIONIN structure BAPIPAREX length 990 number of fields 5
        EXTENSIONINX structure BAPIPAREXX length 990 number of fields 5
        INTERNATIONALARTNOS structure BAPI_MEAN length 27 number of fields 5
        MATERIALDESCRIPTION structure BAPI_MAKT length 44 number of fields 4
        MATERIALLONGTEXT structure BAPI_MLTX length 222 number of fields 8
        PRTDATA structure BAPI_MFHM length 69 number of fields 25
        PRTDATAX structure BAPI_MFHMX length 28 number of fields 25
        RETURNMESSAGES structure BAPI_MATRETURN2 length 548 number of fields 14
        TAXCLASSIFICATIONS structure BAPI_MLAN length 51 number of fields 21
        UNITSOFMEASURE structure BAPI_MARM length 92 number of fields 20
        UNITSOFMEASUREX structure BAPI_MARMX length 23 number of fields 19
      exceptions

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_BAPIMATHEAD_INP_FLD_CHECK
#define SAP_FT_BAPIMATHEAD_INP_FLD_CHECK
typedef RFC_CHAR BAPIMATHEAD_INP_FLD_CHECK[1];
#endif

/* structure type definition */

#ifndef SAP_ST_BAPI_MARA
#define SAP_ST_BAPI_MARA
typedef struct {
  RFC_CHAR DelFlag[1];
  RFC_CHAR MatlGroup[9];
  RFC_CHAR OldMatNo[18];
  RFC_CHAR BaseUom[3];
  RFC_CHAR BaseUomIso[3];
  RFC_CHAR PoUnit[3];
  RFC_CHAR PoUnitIso[3];
  RFC_CHAR Document[22];
  RFC_CHAR DocType[3];
  RFC_CHAR DocVers[2];
  RFC_CHAR DocFormat[4];
  RFC_CHAR DocChgNo[6];
  RFC_CHAR PageNo[3];
  RFC_NUM NoSheets[3];
  RFC_CHAR ProdMemo[18];
  RFC_CHAR Pageformat[4];
  RFC_CHAR SizeDim[32];
  RFC_CHAR BasicMatl[48];
  RFC_CHAR StdDescr[18];
  RFC_CHAR DsnOffice[3];
  RFC_CHAR PurValkey[4];
  RFC_BCD NetWeight[7];
  RFC_CHAR UnitOfWt[3];
  RFC_CHAR UnitOfWtIso[3];
  RFC_CHAR Container[2];
  RFC_CHAR StorConds[2];
  RFC_CHAR TempConds[2];
  RFC_CHAR TransGrp[4];
  RFC_CHAR HazMatNo[18];
  RFC_CHAR Division[2];
  RFC_CHAR Competitor[10];
  RFC_BCD QtyGrGi[7];
  RFC_CHAR ProcRule[1];
  RFC_CHAR SupSource[1];
  RFC_CHAR Season[4];
  RFC_CHAR LabelType[2];
  RFC_CHAR LabelForm[2];
  RFC_CHAR ProdHier[18];
  RFC_CHAR CadId[1];
  RFC_BCD AllowedWt[7];
  RFC_CHAR PackWtUn[3];
  RFC_CHAR PackWtUnIso[3];
  RFC_BCD AllwdVol[7];
  RFC_CHAR PackVoUn[3];
  RFC_CHAR PackVoUnIso[3];
  RFC_BCD WtTolLt[2];
  RFC_BCD VolTolLt[2];
  RFC_CHAR VarOrdUn[1];
  RFC_CHAR BatchMgmt[1];
  RFC_CHAR ShMatTyp[4];
  RFC_BCD FillLevel[2];
  RFC_INT2 StackFact;
  RFC_CHAR MatGrpSm[4];
  RFC_CHAR Authoritygroup[4];
  RFC_CHAR QmProcmnt[1];
  RFC_CHAR Catprofile[9];
  RFC_BCD Minremlife[3];
  RFC_BCD ShelfLife[3];
  RFC_BCD StorPct[2];
  RFC_CHAR PurStatus[2];
  RFC_CHAR SalStatus[2];
  RFC_DATE Pvalidfrom;
  RFC_DATE Svalidfrom;
  RFC_CHAR EnvtRlvt[1];
  RFC_CHAR ProdAlloc[18];
  RFC_CHAR QualDik[1];
  RFC_CHAR ManuMat[40];
  RFC_CHAR MfrNo[10];
  RFC_CHAR InvMatNo[18];
  RFC_CHAR ManufProf[4];
  RFC_CHAR Hazmatprof[3];
  RFC_CHAR HighVisc[1];
  RFC_CHAR Looseorliq[1];
  RFC_CHAR ClosedBox[1];
  RFC_CHAR AppdBRec[1];
  RFC_NUM Matcmpllvl[2];
  RFC_CHAR ParEff[1];
  RFC_CHAR RoundUpRuleExpirationDate[1];
  RFC_CHAR PeriodIndExpirationDate[1];
  RFC_CHAR ProdCompositionOnPackaging[1];
  RFC_CHAR ItemCat[4];
  RFC_CHAR HazMatNoExternal[40];
  RFC_CHAR HazMatNoGuid[32];
  RFC_CHAR HazMatNoVersion[10];
  RFC_CHAR InvMatNoExternal[40];
  RFC_CHAR InvMatNoGuid[32];
  RFC_CHAR InvMatNoVersion[10];
  RFC_CHAR MaterialFixed[1];
  RFC_CHAR CmRelevanceFlag[1];
 } BAPI_MARA;
#endif

#ifndef SAP_ST_BAPI_MARAX
#define SAP_ST_BAPI_MARAX
typedef struct {
  RFC_CHAR DelFlag[1];
  RFC_CHAR MatlGroup[1];
  RFC_CHAR OldMatNo[1];
  RFC_CHAR BaseUom[1];
  RFC_CHAR BaseUomIso[1];
  RFC_CHAR PoUnit[1];
  RFC_CHAR PoUnitIso[1];
  RFC_CHAR Document[1];
  RFC_CHAR DocType[1];
  RFC_CHAR DocVers[1];
  RFC_CHAR DocFormat[1];
  RFC_CHAR DocChgNo[1];
  RFC_CHAR PageNo[1];
  RFC_CHAR NoSheets[1];
  RFC_CHAR ProdMemo[1];
  RFC_CHAR Pageformat[1];
  RFC_CHAR SizeDim[1];
  RFC_CHAR BasicMatl[1];
  RFC_CHAR StdDescr[1];
  RFC_CHAR DsnOffice[1];
  RFC_CHAR PurValkey[1];
  RFC_CHAR NetWeight[1];
  RFC_CHAR UnitOfWt[1];
  RFC_CHAR UnitOfWtIso[1];
  RFC_CHAR Container[1];
  RFC_CHAR StorConds[1];
  RFC_CHAR TempConds[1];
  RFC_CHAR TransGrp[1];
  RFC_CHAR HazMatNo[1];
  RFC_CHAR Division[1];
  RFC_CHAR Competitor[1];
  RFC_CHAR QtyGrGi[1];
  RFC_CHAR ProcRule[1];
  RFC_CHAR SupSource[1];
  RFC_CHAR Season[1];
  RFC_CHAR LabelType[1];
  RFC_CHAR LabelForm[1];
  RFC_CHAR ProdHier[1];
  RFC_CHAR CadId[1];
  RFC_CHAR AllowedWt[1];
  RFC_CHAR PackWtUn[1];
  RFC_CHAR PackWtUnIso[1];
  RFC_CHAR AllwdVol[1];
  RFC_CHAR PackVoUn[1];
  RFC_CHAR PackVoUnIso[1];
  RFC_CHAR WtTolLt[1];
  RFC_CHAR VolTolLt[1];
  RFC_CHAR VarOrdUn[1];
  RFC_CHAR BatchMgmt[1];
  RFC_CHAR ShMatTyp[1];
  RFC_CHAR FillLevel[1];
  RFC_CHAR StackFact[1];
  RFC_CHAR MatGrpSm[1];
  RFC_CHAR Authoritygroup[1];
  RFC_CHAR QmProcmnt[1];
  RFC_CHAR Catprofile[1];
  RFC_CHAR Minremlife[1];
  RFC_CHAR ShelfLife[1];
  RFC_CHAR StorPct[1];
  RFC_CHAR PurStatus[1];
  RFC_CHAR SalStatus[1];
  RFC_CHAR Pvalidfrom[1];
  RFC_CHAR Svalidfrom[1];
  RFC_CHAR EnvtRlvt[1];
  RFC_CHAR ProdAlloc[1];
  RFC_CHAR QualDik[1];
  RFC_CHAR ManuMat[1];
  RFC_CHAR MfrNo[1];
  RFC_CHAR InvMatNo[1];
  RFC_CHAR ManufProf[1];
  RFC_CHAR Hazmatprof[1];
  RFC_CHAR HighVisc[1];
  RFC_CHAR Looseorliq[1];
  RFC_CHAR ClosedBox[1];
  RFC_CHAR AppdBRec[1];
  RFC_CHAR Matcmpllvl[1];
  RFC_CHAR ParEff[1];
  RFC_CHAR RoundUpRuleExpirationDate[1];
  RFC_CHAR PeriodIndExpirationDate[1];
  RFC_CHAR ProdCompositionOnPackaging[1];
  RFC_CHAR ItemCat[1];
  RFC_CHAR HazMatNoExternal[1];
  RFC_CHAR HazMatNoGuid[1];
  RFC_CHAR HazMatNoVersion[1];
  RFC_CHAR InvMatNoExternal[1];
  RFC_CHAR InvMatNoGuid[1];
  RFC_CHAR InvMatNoVersion[1];
  RFC_CHAR MaterialFixed[1];
  RFC_CHAR CmRelevanceFlag[1];
 } BAPI_MARAX;
#endif

#ifndef SAP_ST_BAPI_MPOP
#define SAP_ST_BAPI_MPOP
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR ForeProf[4];
  RFC_CHAR ModelSi[1];
  RFC_CHAR ModelSp[1];
  RFC_CHAR ParamOpt[1];
  RFC_CHAR OptimLev[1];
  RFC_CHAR Initialize[1];
  RFC_CHAR ForeModel[1];
  RFC_BCD AlphaFact[2];
  RFC_BCD BetaFact[2];
  RFC_BCD GammaFact[2];
  RFC_BCD DeltaFact[2];
  RFC_BCD Tracklimit[3];
  RFC_DATE ForeDate;
  RFC_BCD HistVals[2];
  RFC_BCD InitPds[2];
  RFC_BCD SeasonPds[2];
  RFC_BCD ExpostPds[2];
  RFC_BCD ForePds[2];
  RFC_BCD FixedPds[2];
  RFC_CHAR WtgGroup[2];
 } BAPI_MPOP;
#endif

#ifndef SAP_ST_BAPI_MPOPX
#define SAP_ST_BAPI_MPOPX
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR ForeProf[1];
  RFC_CHAR ModelSi[1];
  RFC_CHAR ModelSp[1];
  RFC_CHAR ParamOpt[1];
  RFC_CHAR OptimLev[1];
  RFC_CHAR Initialize[1];
  RFC_CHAR ForeModel[1];
  RFC_CHAR AlphaFact[1];
  RFC_CHAR BetaFact[1];
  RFC_CHAR GammaFact[1];
  RFC_CHAR DeltaFact[1];
  RFC_CHAR Tracklimit[1];
  RFC_CHAR ForeDate[1];
  RFC_CHAR HistVals[1];
  RFC_CHAR InitPds[1];
  RFC_CHAR SeasonPds[1];
  RFC_CHAR ExpostPds[1];
  RFC_CHAR ForePds[1];
  RFC_CHAR FixedPds[1];
  RFC_CHAR WtgGroup[1];
 } BAPI_MPOPX;
#endif

#ifndef SAP_ST_BAPIMATHEAD
#define SAP_ST_BAPIMATHEAD
typedef struct {
  RFC_CHAR Material[18];
  RFC_CHAR IndSector[1];
  RFC_CHAR MatlType[4];
  RFC_CHAR BasicView[1];
  RFC_CHAR SalesView[1];
  RFC_CHAR PurchaseView[1];
  RFC_CHAR MrpView[1];
  RFC_CHAR ForecastView[1];
  RFC_CHAR WorkSchedView[1];
  RFC_CHAR PrtView[1];
  RFC_CHAR StorageView[1];
  RFC_CHAR WarehouseView[1];
  RFC_CHAR QualityView[1];
  RFC_CHAR AccountView[1];
  RFC_CHAR CostView[1];
  RFC_CHAR InpFldCheck[1];
  RFC_CHAR MaterialExternal[40];
  RFC_CHAR MaterialGuid[32];
  RFC_CHAR MaterialVersion[10];
 } BAPIMATHEAD;
#endif

#ifndef SAP_ST_BAPI_MPGD
#define SAP_ST_BAPI_MPGD
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR PlngMatl[18];
  RFC_CHAR PlngPlant[4];
  RFC_CHAR Convfactor[10];
  RFC_CHAR PlngMatlExternal[40];
  RFC_CHAR PlngMatlGuid[32];
  RFC_CHAR PlngMatlVersion[10];
 } BAPI_MPGD;
#endif

#ifndef SAP_ST_BAPI_MPGDX
#define SAP_ST_BAPI_MPGDX
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR PlngMatl[1];
  RFC_CHAR PlngPlant[1];
  RFC_CHAR Convfactor[1];
  RFC_CHAR PlngMatlExternal[1];
  RFC_CHAR PlngMatlGuid[1];
  RFC_CHAR PlngMatlVersion[1];
 } BAPI_MPGDX;
#endif

#ifndef SAP_ST_BAPI_MARC
#define SAP_ST_BAPI_MARC
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR DelFlag[1];
  RFC_CHAR AbcId[1];
  RFC_CHAR CritPart[1];
  RFC_CHAR PurGroup[3];
  RFC_CHAR IssueUnit[3];
  RFC_CHAR IssueUnitIso[3];
  RFC_CHAR Mrpprofile[4];
  RFC_CHAR MrpType[2];
  RFC_CHAR MrpCtrler[3];
  RFC_BCD PlndDelry[2];
  RFC_BCD GrPrTime[2];
  RFC_CHAR PeriodInd[1];
  RFC_BCD AssyScrap[3];
  RFC_CHAR Lotsizekey[2];
  RFC_CHAR ProcType[1];
  RFC_CHAR Spproctype[2];
  RFC_BCD ReorderPt[7];
  RFC_BCD SafetyStk[7];
  RFC_BCD Minlotsize[7];
  RFC_BCD Maxlotsize[7];
  RFC_BCD FixedLot[7];
  RFC_BCD RoundVal[7];
  RFC_BCD MaxStock[7];
  RFC_BCD OrdCosts[12];
  RFC_CHAR DepReqId[1];
  RFC_CHAR StorCosts[1];
  RFC_CHAR AltBomId[1];
  RFC_CHAR Discontinu[1];
  RFC_DATE EffODay;
  RFC_CHAR FollowUp[18];
  RFC_CHAR GrpReqmts[1];
  RFC_CHAR MixedMrp[1];
  RFC_CHAR SmKey[3];
  RFC_CHAR Backflush[1];
  RFC_CHAR ProductionScheduler[3];
  RFC_BCD ProcTime[3];
  RFC_BCD Setuptime[3];
  RFC_BCD Interop[3];
  RFC_BCD BaseQty[7];
  RFC_BCD Inhseprodt[2];
  RFC_BCD Stgeperiod[3];
  RFC_CHAR StgePdUn[3];
  RFC_CHAR StgePdUnIso[3];
  RFC_BCD OverTol[2];
  RFC_CHAR Unlimited[1];
  RFC_BCD UnderTol[2];
  RFC_BCD Replentime[2];
  RFC_CHAR ReplacePt[1];
  RFC_CHAR IndPostToInspStock[1];
  RFC_CHAR CtrlKey[8];
  RFC_CHAR DocReqd[1];
  RFC_CHAR Loadinggrp[4];
  RFC_CHAR BatchMgmt[1];
  RFC_CHAR Quotausage[1];
  RFC_BCD ServLevel[2];
  RFC_CHAR SplitInd[1];
  RFC_CHAR Availcheck[2];
  RFC_CHAR FyVariant[2];
  RFC_CHAR CorrFact[1];
  RFC_BCD SetupTime[3];
  RFC_BCD BaseQtyPlan[7];
  RFC_BCD ShipProcTime[3];
  RFC_CHAR SupSource[1];
  RFC_CHAR AutoPOrd[1];
  RFC_CHAR Sourcelist[1];
  RFC_CHAR CommCode[17];
  RFC_CHAR Countryori[3];
  RFC_CHAR CountryoriIso[2];
  RFC_CHAR Regionorig[3];
  RFC_CHAR CommCoUn[3];
  RFC_CHAR CommCoUnIso[3];
  RFC_CHAR Expimpgrp[4];
  RFC_CHAR ProfitCtr[10];
  RFC_CHAR PpcPlCal[3];
  RFC_CHAR RepManuf[1];
  RFC_NUM PlTiFnce[3];
  RFC_CHAR Consummode[1];
  RFC_NUM BwdCons[3];
  RFC_NUM FwdCons[3];
  RFC_CHAR AlternativeBom[2];
  RFC_CHAR BomUsage[1];
  RFC_CHAR Planlistgrp[8];
  RFC_CHAR Planlistcnt[2];
  RFC_BCD LotSize[7];
  RFC_CHAR Specprocty[2];
  RFC_CHAR ProdUnit[3];
  RFC_CHAR ProdUnitIso[3];
  RFC_CHAR IssStLoc[4];
  RFC_CHAR MrpGroup[4];
  RFC_BCD CompScrap[3];
  RFC_CHAR CertType[4];
  RFC_BCD CycleTime[2];
  RFC_CHAR Covprofile[3];
  RFC_CHAR CcPhInv[1];
  RFC_CHAR VarianceKey[6];
  RFC_CHAR SernoProf[4];
  RFC_CHAR Repmanprof[4];
  RFC_CHAR NegStocks[1];
  RFC_CHAR QmRgmts[4];
  RFC_CHAR PlngCycle[3];
  RFC_CHAR RoundProf[4];
  RFC_CHAR Refmatcons[18];
  RFC_DATE DToRefM;
  RFC_BCD MultRefM[3];
  RFC_CHAR AutoReset[1];
  RFC_CHAR ExCertId[1];
  RFC_CHAR ExCertNoNew[8];
  RFC_DATE ExCertDt;
  RFC_CHAR MilitId[1];
  RFC_BCD InspInt[3];
  RFC_CHAR CoProduct[1];
  RFC_CHAR PlanStrgp[2];
  RFC_CHAR SlocExprc[4];
  RFC_CHAR BulkMat[1];
  RFC_CHAR CcFixed[1];
  RFC_CHAR DetermGrp[4];
  RFC_CHAR QmAuthgrp[6];
  RFC_CHAR TaskListType[1];
  RFC_CHAR PurStatus[2];
  RFC_CHAR Prodprof[6];
  RFC_CHAR SaftyTId[1];
  RFC_NUM Safetytime[2];
  RFC_CHAR PlordCtrl[2];
  RFC_CHAR Batchentry[1];
  RFC_DATE Pvalidfrom;
  RFC_CHAR Matfrgtgrp[8];
  RFC_CHAR Prodverscs[4];
  RFC_CHAR MatCfop[2];
  RFC_CHAR EuListNo[12];
  RFC_CHAR EuMatGrp[6];
  RFC_CHAR CasNo[15];
  RFC_CHAR ProdcomNo[9];
  RFC_CHAR CtrlCode[16];
  RFC_CHAR JitRelvt[1];
  RFC_CHAR MatGrpTrans[20];
  RFC_CHAR HandlgGrp[4];
  RFC_CHAR SupplyArea[10];
  RFC_CHAR FairShareRule[2];
  RFC_CHAR PushDistrib[1];
  RFC_BCD DeployHoriz[2];
  RFC_BCD MinLotSize[7];
  RFC_BCD MaxLotSize[7];
  RFC_BCD FixLotSize[7];
  RFC_BCD LotIncrement[7];
  RFC_CHAR ProdConvType[2];
  RFC_CHAR DistrProf[3];
  RFC_CHAR PeriodProfileSafetyTime[3];
  RFC_CHAR FxdPrice[1];
  RFC_CHAR AvailCheckAllProjSegments[1];
  RFC_CHAR Overallprf[6];
  RFC_CHAR MrpRelevancyDepRequirements[1];
  RFC_BCD MinSafetyStk[7];
  RFC_CHAR NoCosting[1];
  RFC_CHAR UnitGroup[4];
  RFC_CHAR FollowUpExternal[40];
  RFC_CHAR FollowUpGuid[32];
  RFC_CHAR FollowUpVersion[10];
  RFC_CHAR RefmatconsExternal[40];
  RFC_CHAR RefmatconsGuid[32];
  RFC_CHAR RefmatconsVersion[10];
 } BAPI_MARC;
#endif

#ifndef SAP_ST_BAPI_MARCX
#define SAP_ST_BAPI_MARCX
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR DelFlag[1];
  RFC_CHAR AbcId[1];
  RFC_CHAR CritPart[1];
  RFC_CHAR PurGroup[1];
  RFC_CHAR IssueUnit[1];
  RFC_CHAR IssueUnitIso[1];
  RFC_CHAR Mrpprofile[1];
  RFC_CHAR MrpType[1];
  RFC_CHAR MrpCtrler[1];
  RFC_CHAR PlndDelry[1];
  RFC_CHAR GrPrTime[1];
  RFC_CHAR PeriodInd[1];
  RFC_CHAR AssyScrap[1];
  RFC_CHAR Lotsizekey[1];
  RFC_CHAR ProcType[1];
  RFC_CHAR Spproctype[1];
  RFC_CHAR ReorderPt[1];
  RFC_CHAR SafetyStk[1];
  RFC_CHAR Minlotsize[1];
  RFC_CHAR Maxlotsize[1];
  RFC_CHAR FixedLot[1];
  RFC_CHAR RoundVal[1];
  RFC_CHAR MaxStock[1];
  RFC_CHAR OrdCosts[1];
  RFC_CHAR DepReqId[1];
  RFC_CHAR StorCosts[1];
  RFC_CHAR AltBomId[1];
  RFC_CHAR Discontinu[1];
  RFC_CHAR EffODay[1];
  RFC_CHAR FollowUp[1];
  RFC_CHAR GrpReqmts[1];
  RFC_CHAR MixedMrp[1];
  RFC_CHAR SmKey[1];
  RFC_CHAR Backflush[1];
  RFC_CHAR ProductionScheduler[1];
  RFC_CHAR ProcTime[1];
  RFC_CHAR Setuptime[1];
  RFC_CHAR Interop[1];
  RFC_CHAR BaseQty[1];
  RFC_CHAR Inhseprodt[1];
  RFC_CHAR Stgeperiod[1];
  RFC_CHAR StgePdUn[1];
  RFC_CHAR StgePdUnIso[1];
  RFC_CHAR OverTol[1];
  RFC_CHAR Unlimited[1];
  RFC_CHAR UnderTol[1];
  RFC_CHAR Replentime[1];
  RFC_CHAR ReplacePt[1];
  RFC_CHAR IndPostToInspStock[1];
  RFC_CHAR CtrlKey[1];
  RFC_CHAR DocReqd[1];
  RFC_CHAR Loadinggrp[1];
  RFC_CHAR BatchMgmt[1];
  RFC_CHAR Quotausage[1];
  RFC_CHAR ServLevel[1];
  RFC_CHAR SplitInd[1];
  RFC_CHAR Availcheck[1];
  RFC_CHAR FyVariant[1];
  RFC_CHAR CorrFact[1];
  RFC_CHAR SetupTime[1];
  RFC_CHAR BaseQtyPlan[1];
  RFC_CHAR ShipProcTime[1];
  RFC_CHAR SupSource[1];
  RFC_CHAR AutoPOrd[1];
  RFC_CHAR Sourcelist[1];
  RFC_CHAR CommCode[1];
  RFC_CHAR Countryori[1];
  RFC_CHAR CountryoriIso[1];
  RFC_CHAR Regionorig[1];
  RFC_CHAR CommCoUn[1];
  RFC_CHAR CommCoUnIso[1];
  RFC_CHAR Expimpgrp[1];
  RFC_CHAR ProfitCtr[1];
  RFC_CHAR PpcPlCal[1];
  RFC_CHAR RepManuf[1];
  RFC_CHAR PlTiFnce[1];
  RFC_CHAR Consummode[1];
  RFC_CHAR BwdCons[1];
  RFC_CHAR FwdCons[1];
  RFC_CHAR AlternativeBom[1];
  RFC_CHAR BomUsage[1];
  RFC_CHAR Planlistgrp[1];
  RFC_CHAR Planlistcnt[1];
  RFC_CHAR LotSize[1];
  RFC_CHAR Specprocty[1];
  RFC_CHAR ProdUnit[1];
  RFC_CHAR ProdUnitIso[1];
  RFC_CHAR IssStLoc[1];
  RFC_CHAR MrpGroup[1];
  RFC_CHAR CompScrap[1];
  RFC_CHAR CertType[1];
  RFC_CHAR CycleTime[1];
  RFC_CHAR Covprofile[1];
  RFC_CHAR CcPhInv[1];
  RFC_CHAR VarianceKey[1];
  RFC_CHAR SernoProf[1];
  RFC_CHAR Repmanprof[1];
  RFC_CHAR NegStocks[1];
  RFC_CHAR QmRgmts[1];
  RFC_CHAR PlngCycle[1];
  RFC_CHAR RoundProf[1];
  RFC_CHAR Refmatcons[1];
  RFC_CHAR DToRefM[1];
  RFC_CHAR MultRefM[1];
  RFC_CHAR AutoReset[1];
  RFC_CHAR ExCertId[1];
  RFC_CHAR ExCertNoNew[1];
  RFC_CHAR ExCertDt[1];
  RFC_CHAR MilitId[1];
  RFC_CHAR InspInt[1];
  RFC_CHAR CoProduct[1];
  RFC_CHAR PlanStrgp[1];
  RFC_CHAR SlocExprc[1];
  RFC_CHAR BulkMat[1];
  RFC_CHAR CcFixed[1];
  RFC_CHAR DetermGrp[1];
  RFC_CHAR QmAuthgrp[1];
  RFC_CHAR TaskListType[1];
  RFC_CHAR PurStatus[1];
  RFC_CHAR Prodprof[1];
  RFC_CHAR SaftyTId[1];
  RFC_CHAR Safetytime[1];
  RFC_CHAR PlordCtrl[1];
  RFC_CHAR Batchentry[1];
  RFC_CHAR Pvalidfrom[1];
  RFC_CHAR Matfrgtgrp[1];
  RFC_CHAR Prodverscs[1];
  RFC_CHAR MatCfop[1];
  RFC_CHAR EuListNo[1];
  RFC_CHAR EuMatGrp[1];
  RFC_CHAR CasNo[1];
  RFC_CHAR ProdcomNo[1];
  RFC_CHAR CtrlCode[1];
  RFC_CHAR JitRelvt[1];
  RFC_CHAR MatGrpTrans[1];
  RFC_CHAR HandlgGrp[1];
  RFC_CHAR SupplyArea[1];
  RFC_CHAR FairShareRule[1];
  RFC_CHAR PushDistrib[1];
  RFC_CHAR DeployHoriz[1];
  RFC_CHAR MinLotSize[1];
  RFC_CHAR MaxLotSize[1];
  RFC_CHAR FixLotSize[1];
  RFC_CHAR LotIncrement[1];
  RFC_CHAR ProdConvType[1];
  RFC_CHAR DistrProf[1];
  RFC_CHAR PeriodProfileSafetyTime[1];
  RFC_CHAR FxdPrice[1];
  RFC_CHAR AvailCheckAllProjSegments[1];
  RFC_CHAR Overallprf[1];
  RFC_CHAR MrpRelevancyDepRequirements[1];
  RFC_CHAR MinSafetyStk[1];
  RFC_CHAR NoCosting[1];
  RFC_CHAR UnitGroup[1];
  RFC_CHAR FollowUpExternal[1];
  RFC_CHAR FollowUpGuid[1];
  RFC_CHAR FollowUpVersion[1];
  RFC_CHAR RefmatconsExternal[1];
  RFC_CHAR RefmatconsGuid[1];
  RFC_CHAR RefmatconsVersion[1];
 } BAPI_MARCX;
#endif

#ifndef SAP_ST_BAPI_MVKE
#define SAP_ST_BAPI_MVKE
typedef struct {
  RFC_CHAR SalesOrg[4];
  RFC_CHAR DistrChan[2];
  RFC_CHAR DelFlag[1];
  RFC_CHAR MatlStats[1];
  RFC_CHAR RebateGrp[2];
  RFC_CHAR CommGroup[2];
  RFC_CHAR CashDisc[1];
  RFC_CHAR SalStatus[2];
  RFC_DATE ValidFrom;
  RFC_BCD MinOrder[7];
  RFC_BCD MinDely[7];
  RFC_BCD MinMto[7];
  RFC_BCD DelyUnit[7];
  RFC_CHAR DelyUom[3];
  RFC_CHAR DelyUomIso[3];
  RFC_CHAR SalesUnit[3];
  RFC_CHAR SalesUnitIso[3];
  RFC_CHAR ItemCat[4];
  RFC_CHAR DelygPlnt[4];
  RFC_CHAR ProdHier[18];
  RFC_CHAR PrRefMat[18];
  RFC_CHAR MatPrGrp[2];
  RFC_CHAR AcctAssgt[2];
  RFC_CHAR MatlGrp1[3];
  RFC_CHAR MatlGrp2[3];
  RFC_CHAR MatlGrp3[3];
  RFC_CHAR MatlGrp4[3];
  RFC_CHAR MatlGrp5[3];
  RFC_CHAR ProdAtt1[1];
  RFC_CHAR ProdAtt2[1];
  RFC_CHAR ProdAtt3[1];
  RFC_CHAR ProdAtt4[1];
  RFC_CHAR ProdAtt5[1];
  RFC_CHAR ProdAtt6[1];
  RFC_CHAR ProdAtt7[1];
  RFC_CHAR ProdAtt8[1];
  RFC_CHAR ProdAtt9[1];
  RFC_CHAR ProdAtt10[1];
  RFC_CHAR RoundProf[4];
  RFC_CHAR VarSalesUn[1];
  RFC_CHAR UnitGroup[4];
  RFC_CHAR PrRefMatExternal[40];
  RFC_CHAR PrRefMatGuid[32];
  RFC_CHAR PrRefMatVersion[10];
 } BAPI_MVKE;
#endif

#ifndef SAP_ST_BAPI_MVKEX
#define SAP_ST_BAPI_MVKEX
typedef struct {
  RFC_CHAR SalesOrg[4];
  RFC_CHAR DistrChan[2];
  RFC_CHAR DelFlag[1];
  RFC_CHAR MatlStats[1];
  RFC_CHAR RebateGrp[1];
  RFC_CHAR CommGroup[1];
  RFC_CHAR CashDisc[1];
  RFC_CHAR SalStatus[1];
  RFC_CHAR ValidFrom[1];
  RFC_CHAR MinOrder[1];
  RFC_CHAR MinDely[1];
  RFC_CHAR MinMto[1];
  RFC_CHAR DelyUnit[1];
  RFC_CHAR DelyUom[1];
  RFC_CHAR DelyUomIso[1];
  RFC_CHAR SalesUnit[1];
  RFC_CHAR SalesUnitIso[1];
  RFC_CHAR ItemCat[1];
  RFC_CHAR DelygPlnt[1];
  RFC_CHAR ProdHier[1];
  RFC_CHAR PrRefMat[1];
  RFC_CHAR MatPrGrp[1];
  RFC_CHAR AcctAssgt[1];
  RFC_CHAR MatlGrp1[1];
  RFC_CHAR MatlGrp2[1];
  RFC_CHAR MatlGrp3[1];
  RFC_CHAR MatlGrp4[1];
  RFC_CHAR MatlGrp5[1];
  RFC_CHAR ProdAtt1[1];
  RFC_CHAR ProdAtt2[1];
  RFC_CHAR ProdAtt3[1];
  RFC_CHAR ProdAtt4[1];
  RFC_CHAR ProdAtt5[1];
  RFC_CHAR ProdAtt6[1];
  RFC_CHAR ProdAtt7[1];
  RFC_CHAR ProdAtt8[1];
  RFC_CHAR ProdAtt9[1];
  RFC_CHAR ProdAtt10[1];
  RFC_CHAR RoundProf[1];
  RFC_CHAR VarSalesUn[1];
  RFC_CHAR UnitGroup[1];
  RFC_CHAR PrRefMatExternal[1];
  RFC_CHAR PrRefMatGuid[1];
  RFC_CHAR PrRefMatVersion[1];
 } BAPI_MVKEX;
#endif

#ifndef SAP_ST_BAPI_MARD
#define SAP_ST_BAPI_MARD
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR StgeLoc[4];
  RFC_CHAR DelFlag[1];
  RFC_CHAR MrpInd[1];
  RFC_CHAR SpecProc[2];
  RFC_BCD ReorderPt[7];
  RFC_BCD ReplQty[7];
  RFC_CHAR StgeBin[10];
  RFC_CHAR PickgArea[3];
  RFC_FLOAT InvCorrFac;
 } BAPI_MARD;
#endif

#ifndef SAP_ST_BAPI_MARDX
#define SAP_ST_BAPI_MARDX
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR StgeLoc[4];
  RFC_CHAR DelFlag[1];
  RFC_CHAR MrpInd[1];
  RFC_CHAR SpecProc[1];
  RFC_CHAR ReorderPt[1];
  RFC_CHAR ReplQty[1];
  RFC_CHAR StgeBin[1];
  RFC_CHAR PickgArea[1];
  RFC_CHAR InvCorrFac[1];
 } BAPI_MARDX;
#endif

#ifndef SAP_ST_BAPI_MLGT
#define SAP_ST_BAPI_MLGT
typedef struct {
  RFC_CHAR WhseNo[3];
  RFC_CHAR StgeType[3];
  RFC_CHAR DelFlag[1];
  RFC_CHAR StgeBin[10];
  RFC_BCD MaxSbQty[7];
  RFC_BCD MinSbQty[7];
  RFC_BCD CtrlQty[7];
  RFC_BCD ReplenQty[7];
  RFC_CHAR PickArea[3];
  RFC_BCD RoundQty[7];
 } BAPI_MLGT;
#endif

#ifndef SAP_ST_BAPI_MLGTX
#define SAP_ST_BAPI_MLGTX
typedef struct {
  RFC_CHAR WhseNo[3];
  RFC_CHAR StgeType[3];
  RFC_CHAR DelFlag[1];
  RFC_CHAR StgeBin[1];
  RFC_CHAR MaxSbQty[1];
  RFC_CHAR MinSbQty[1];
  RFC_CHAR CtrlQty[1];
  RFC_CHAR ReplenQty[1];
  RFC_CHAR PickArea[1];
  RFC_CHAR RoundQty[1];
 } BAPI_MLGTX;
#endif

#ifndef SAP_ST_BAPI_MBEW
#define SAP_ST_BAPI_MBEW
typedef struct {
  RFC_CHAR ValArea[4];
  RFC_CHAR ValType[10];
  RFC_CHAR DelFlag[1];
  RFC_CHAR PriceCtrl[1];
  RFC_BCD MovingPr[12];
  RFC_BCD StdPrice[12];
  RFC_BCD PriceUnit[3];
  RFC_CHAR ValClass[4];
  RFC_CHAR PrCtrlPp[1];
  RFC_BCD MovPrPp[12];
  RFC_BCD StdPrPp[12];
  RFC_BCD PrUnitPp[3];
  RFC_CHAR VclassPp[4];
  RFC_CHAR PrCtrlPy[1];
  RFC_BCD MovPrPy[12];
  RFC_BCD StdPrPy[12];
  RFC_CHAR VclassPy[4];
  RFC_BCD PrUnitPy[3];
  RFC_CHAR ValCat[1];
  RFC_BCD FuturePr[12];
  RFC_DATE ValidFrom;
  RFC_BCD Taxprice1[12];
  RFC_BCD Commprice1[12];
  RFC_BCD Taxprice3[12];
  RFC_BCD Commprice3[12];
  RFC_BCD PlndPrice[12];
  RFC_BCD Plndprice1[12];
  RFC_BCD Plndprice2[12];
  RFC_BCD Plndprice3[12];
  RFC_DATE Plndprdate1;
  RFC_DATE Plndprdate2;
  RFC_DATE Plndprdate3;
  RFC_CHAR LifoFifo[1];
  RFC_CHAR Poolnumber[4];
  RFC_BCD Taxprice2[12];
  RFC_BCD Commprice2[12];
  RFC_NUM DevalInd[2];
  RFC_CHAR OrigGroup[4];
  RFC_CHAR OverheadGrp[10];
  RFC_CHAR QtyStruct[1];
  RFC_CHAR MlActive[1];
  RFC_CHAR MlSettle[1];
  RFC_CHAR OrigMat[1];
  RFC_CHAR VmSoStk[4];
  RFC_CHAR VmPStock[4];
  RFC_CHAR MatlUsage[1];
  RFC_CHAR MatOrigin[1];
  RFC_CHAR InHouse[1];
  RFC_BCD TaxCmlUn[3];
 } BAPI_MBEW;
#endif

#ifndef SAP_ST_BAPI_MBEWX
#define SAP_ST_BAPI_MBEWX
typedef struct {
  RFC_CHAR ValArea[4];
  RFC_CHAR ValType[10];
  RFC_CHAR DelFlag[1];
  RFC_CHAR PriceCtrl[1];
  RFC_CHAR MovingPr[1];
  RFC_CHAR StdPrice[1];
  RFC_CHAR PriceUnit[1];
  RFC_CHAR ValClass[1];
  RFC_CHAR PrCtrlPp[1];
  RFC_CHAR MovPrPp[1];
  RFC_CHAR StdPrPp[1];
  RFC_CHAR PrUnitPp[1];
  RFC_CHAR VclassPp[1];
  RFC_CHAR PrCtrlPy[1];
  RFC_CHAR MovPrPy[1];
  RFC_CHAR StdPrPy[1];
  RFC_CHAR VclassPy[1];
  RFC_CHAR PrUnitPy[1];
  RFC_CHAR ValCat[1];
  RFC_CHAR FuturePr[1];
  RFC_CHAR ValidFrom[1];
  RFC_CHAR Taxprice1[1];
  RFC_CHAR Commprice1[1];
  RFC_CHAR Taxprice3[1];
  RFC_CHAR Commprice3[1];
  RFC_CHAR PlndPrice[1];
  RFC_CHAR Plndprice1[1];
  RFC_CHAR Plndprice2[1];
  RFC_CHAR Plndprice3[1];
  RFC_CHAR Plndprdate1[1];
  RFC_CHAR Plndprdate2[1];
  RFC_CHAR Plndprdate3[1];
  RFC_CHAR LifoFifo[1];
  RFC_CHAR Poolnumber[1];
  RFC_CHAR Taxprice2[1];
  RFC_CHAR Commprice2[1];
  RFC_CHAR DevalInd[1];
  RFC_CHAR OrigGroup[1];
  RFC_CHAR OverheadGrp[1];
  RFC_CHAR QtyStruct[1];
  RFC_CHAR MlActive[1];
  RFC_CHAR MlSettle[1];
  RFC_CHAR OrigMat[1];
  RFC_CHAR VmSoStk[1];
  RFC_CHAR VmPStock[1];
  RFC_CHAR MatlUsage[1];
  RFC_CHAR MatOrigin[1];
  RFC_CHAR InHouse[1];
  RFC_CHAR TaxCmlUn[1];
 } BAPI_MBEWX;
#endif

#ifndef SAP_ST_BAPI_MLGN
#define SAP_ST_BAPI_MLGN
typedef struct {
  RFC_CHAR WhseNo[3];
  RFC_CHAR DelFlag[1];
  RFC_CHAR Stgesector[3];
  RFC_CHAR Placement[3];
  RFC_CHAR Withdrawal[3];
  RFC_BCD LEquip1[7];
  RFC_BCD LEquip2[7];
  RFC_BCD LEquip3[7];
  RFC_CHAR LeqUnit1[3];
  RFC_CHAR LeqUnit1Iso[3];
  RFC_CHAR LeqUnit2[3];
  RFC_CHAR LeqUnit2Iso[3];
  RFC_CHAR LeqUnit3[3];
  RFC_CHAR LeqUnit3Iso[3];
  RFC_CHAR Unittype1[3];
  RFC_CHAR Unittype2[3];
  RFC_CHAR Unittype3[3];
  RFC_CHAR WmUnit[3];
  RFC_CHAR WmUnitIso[3];
  RFC_CHAR AddToStk[1];
  RFC_CHAR BlockStge[2];
  RFC_CHAR MsgToIm[1];
  RFC_CHAR SpecMvmt[1];
  RFC_BCD CapyUsage[6];
  RFC_CHAR ProcureUn[3];
  RFC_CHAR ProcureUnIso[3];
  RFC_CHAR StgeType[3];
  RFC_CHAR RefUnit[1];
  RFC_CHAR m_2stepPick[1];
 } BAPI_MLGN;
#endif

#ifndef SAP_ST_BAPI_MLGNX
#define SAP_ST_BAPI_MLGNX
typedef struct {
  RFC_CHAR WhseNo[3];
  RFC_CHAR DelFlag[1];
  RFC_CHAR Stgesector[1];
  RFC_CHAR Placement[1];
  RFC_CHAR Withdrawal[1];
  RFC_CHAR LEquip1[1];
  RFC_CHAR LEquip2[1];
  RFC_CHAR LEquip3[1];
  RFC_CHAR LeqUnit1[1];
  RFC_CHAR LeqUnit1Iso[1];
  RFC_CHAR LeqUnit2[1];
  RFC_CHAR LeqUnit2Iso[1];
  RFC_CHAR LeqUnit3[1];
  RFC_CHAR LeqUnit3Iso[1];
  RFC_CHAR Unittype1[1];
  RFC_CHAR Unittype2[1];
  RFC_CHAR Unittype3[1];
  RFC_CHAR WmUnit[1];
  RFC_CHAR WmUnitIso[1];
  RFC_CHAR AddToStk[1];
  RFC_CHAR BlockStge[1];
  RFC_CHAR MsgToIm[1];
  RFC_CHAR SpecMvmt[1];
  RFC_CHAR CapyUsage[1];
  RFC_CHAR ProcureUn[1];
  RFC_CHAR ProcureUnIso[1];
  RFC_CHAR StgeType[1];
  RFC_CHAR RefUnit[1];
  RFC_CHAR m_2stepPick[1];
 } BAPI_MLGNX;
#endif

#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct {
  RFC_CHAR Type[1];
  RFC_CHAR Id[20];
  RFC_NUM Number[3];
  RFC_CHAR Message[220];
  RFC_CHAR LogNo[20];
  RFC_NUM LogMsgNo[6];
  RFC_CHAR MessageV1[50];
  RFC_CHAR MessageV2[50];
  RFC_CHAR MessageV3[50];
  RFC_CHAR MessageV4[50];
  RFC_CHAR Parameter[32];
  RFC_INT Row;
  RFC_CHAR Field[30];
  RFC_CHAR System[10];
 } BAPIRET2;
#endif

#ifndef SAP_ST_BAPIPAREX
#define SAP_ST_BAPIPAREX
typedef struct {
  RFC_CHAR Structure[30];
  RFC_CHAR Valuepart1[240];
  RFC_CHAR Valuepart2[240];
  RFC_CHAR Valuepart3[240];
  RFC_CHAR Valuepart4[240];
 } BAPIPAREX;
#endif

#ifndef SAP_ST_BAPIPAREXX
#define SAP_ST_BAPIPAREXX
typedef struct {
  RFC_CHAR Structure[30];
  RFC_CHAR Valuepart1[240];
  RFC_CHAR Valuepart2[240];
  RFC_CHAR Valuepart3[240];
  RFC_CHAR Valuepart4[240];
 } BAPIPAREXX;
#endif

#ifndef SAP_ST_BAPI_MEAN
#define SAP_ST_BAPI_MEAN
typedef struct {
  RFC_CHAR Unit[3];
  RFC_CHAR UnitIso[3];
  RFC_CHAR EanUpc[18];
  RFC_CHAR EanCat[2];
  RFC_CHAR DelFlag[1];
 } BAPI_MEAN;
#endif

#ifndef SAP_ST_BAPI_MAKT
#define SAP_ST_BAPI_MAKT
typedef struct {
  RFC_CHAR Langu[1];
  RFC_CHAR LanguIso[2];
  RFC_CHAR MatlDesc[40];
  RFC_CHAR DelFlag[1];
 } BAPI_MAKT;
#endif

#ifndef SAP_ST_BAPI_MLTX
#define SAP_ST_BAPI_MLTX
typedef struct {
  RFC_CHAR Applobject[10];
  RFC_CHAR TextName[70];
  RFC_CHAR TextId[4];
  RFC_CHAR Langu[1];
  RFC_CHAR LanguIso[2];
  RFC_CHAR FormatCol[2];
  RFC_CHAR TextLine[132];
  RFC_CHAR DelFlag[1];
 } BAPI_MLTX;
#endif

#ifndef SAP_ST_BAPI_MFHM
#define SAP_ST_BAPI_MFHM
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR CreateLoadRecs[1];
  RFC_CHAR CtrlKey[4];
  RFC_CHAR CtrlKeyNoChg[1];
  RFC_CHAR GrpKey1[4];
  RFC_CHAR GrpKey2[4];
  RFC_CHAR PrtUsage[3];
  RFC_CHAR StdTextKey[7];
  RFC_CHAR RefKeyNoChg[1];
  RFC_CHAR StartRefDate[2];
  RFC_CHAR StRefDateNoChg[1];
  RFC_BCD StartOffset[3];
  RFC_CHAR StartOffsetUnit[3];
  RFC_CHAR StartOffsetUnitIso[3];
  RFC_CHAR StartOffsetNoChg[1];
  RFC_CHAR EndRefDate[2];
  RFC_CHAR EndRefDateNoChg[1];
  RFC_BCD EndOffset[3];
  RFC_CHAR EndOffsetUnit[3];
  RFC_CHAR EndOffsetUnitIso[3];
  RFC_CHAR EndOffsetNoChg[1];
  RFC_CHAR FormulaTotQty[6];
  RFC_CHAR FormulaTotQtyNoChg[1];
  RFC_CHAR FormulaTotUsage[6];
  RFC_CHAR FormulaTotUsageNoChg[1];
 } BAPI_MFHM;
#endif

#ifndef SAP_ST_BAPI_MFHMX
#define SAP_ST_BAPI_MFHMX
typedef struct {
  RFC_CHAR Plant[4];
  RFC_CHAR CreateLoadRecs[1];
  RFC_CHAR CtrlKey[1];
  RFC_CHAR CtrlKeyNoChg[1];
  RFC_CHAR GrpKey1[1];
  RFC_CHAR GrpKey2[1];
  RFC_CHAR PrtUsage[1];
  RFC_CHAR StdTextKey[1];
  RFC_CHAR RefKeyNoChg[1];
  RFC_CHAR StartRefDate[1];
  RFC_CHAR StRefDateNoChg[1];
  RFC_CHAR StartOffset[1];
  RFC_CHAR StartOffsetUnit[1];
  RFC_CHAR StartOffsetUnitIso[1];
  RFC_CHAR StartOffsetNoChg[1];
  RFC_CHAR EndRefDate[1];
  RFC_CHAR EndRefDateNoChg[1];
  RFC_CHAR EndOffset[1];
  RFC_CHAR EndOffsetUnit[1];
  RFC_CHAR EndOffsetUnitIso[1];
  RFC_CHAR EndOffsetNoChg[1];
  RFC_CHAR FormulaTotQty[1];
  RFC_CHAR FormulaTotQtyNoChg[1];
  RFC_CHAR FormulaTotUsage[1];
  RFC_CHAR FormulaTotUsageNoChg[1];
 } BAPI_MFHMX;
#endif

/*#ifndef SAP_ST_BAPI_MATRETURN2
#define SAP_ST_BAPI_MATRETURN2
typedef struct {
  RFC_CHAR Type[1];
  RFC_CHAR Id[20];
  RFC_NUM Number[3];
  RFC_CHAR Message[220];
  RFC_CHAR LogNo[20];
  RFC_NUM LogMsgNo[6];
  RFC_CHAR MessageV1[50];
  RFC_CHAR MessageV2[50];
  RFC_CHAR MessageV3[50];
  RFC_CHAR MessageV4[50];
  RFC_CHAR Parameter[32];
  RFC_INT Row;
  RFC_CHAR Field[30];
  RFC_CHAR System[10];
 } BAPI_MATRETURN2;
#endif
*/
#ifndef SAP_ST_BAPI_MLAN
#define SAP_ST_BAPI_MLAN
typedef struct {
  RFC_CHAR Depcountry[3];
  RFC_CHAR DepcountryIso[2];
  RFC_CHAR TaxType1[4];
  RFC_CHAR Taxclass1[1];
  RFC_CHAR TaxType2[4];
  RFC_CHAR Taxclass2[1];
  RFC_CHAR TaxType3[4];
  RFC_CHAR Taxclass3[1];
  RFC_CHAR TaxType4[4];
  RFC_CHAR Taxclass4[1];
  RFC_CHAR TaxType5[4];
  RFC_CHAR Taxclass5[1];
  RFC_CHAR TaxType6[4];
  RFC_CHAR Taxclass6[1];
  RFC_CHAR TaxType7[4];
  RFC_CHAR Taxclass7[1];
  RFC_CHAR TaxType8[4];
  RFC_CHAR Taxclass8[1];
  RFC_CHAR TaxType9[4];
  RFC_CHAR Taxclass9[1];
  RFC_CHAR TaxInd[1];
 } BAPI_MLAN;
#endif

#ifndef SAP_ST_BAPI_MARM
#define SAP_ST_BAPI_MARM
typedef struct {
  RFC_CHAR AltUnit[3];
  RFC_CHAR AltUnitIso[3];
  RFC_BCD Numerator[3];
  RFC_BCD Denominatr[3];
  RFC_CHAR EanUpc[18];
  RFC_CHAR EanCat[2];
  RFC_BCD Length[7];
  RFC_BCD Width[7];
  RFC_BCD Height[7];
  RFC_CHAR UnitDim[3];
  RFC_CHAR UnitDimIso[3];
  RFC_BCD Volume[7];
  RFC_CHAR Volumeunit[3];
  RFC_CHAR VolumeunitIso[3];
  RFC_BCD GrossWt[7];
  RFC_CHAR UnitOfWt[3];
  RFC_CHAR UnitOfWtIso[3];
  RFC_CHAR DelFlag[1];
  RFC_CHAR SubUom[3];
  RFC_CHAR SubUomIso[3];
 } BAPI_MARM;
#endif

#ifndef SAP_ST_BAPI_MARMX
#define SAP_ST_BAPI_MARMX
typedef struct {
  RFC_CHAR AltUnit[3];
  RFC_CHAR AltUnitIso[3];
  RFC_CHAR Numerator[1];
  RFC_CHAR Denominatr[1];
  RFC_CHAR EanUpc[1];
  RFC_CHAR EanCat[1];
  RFC_CHAR Length[1];
  RFC_CHAR Width[1];
  RFC_CHAR Height[1];
  RFC_CHAR UnitDim[1];
  RFC_CHAR UnitDimIso[1];
  RFC_CHAR Volume[1];
  RFC_CHAR Volumeunit[1];
  RFC_CHAR VolumeunitIso[1];
  RFC_CHAR GrossWt[1];
  RFC_CHAR UnitOfWt[1];
  RFC_CHAR UnitOfWtIso[1];
  RFC_CHAR SubUom[1];
  RFC_CHAR SubUomIso[1];
 } BAPI_MARMX;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_BAPI_MARA
#define SAP_TH_BAPI_MARA
static RFC_TYPEHANDLE handleOfBAPI_MARA;

static RFC_TYPE_ELEMENT typeOfBAPI_MARA[] = {
  {"DEL_FLAG", TYPC, 1, 0},
  {"MATL_GROUP", TYPC, 9, 0},
  {"OLD_MAT_NO", TYPC, 18, 0},
  {"BASE_UOM", TYPC, 3, 0},
  {"BASE_UOM_ISO", TYPC, 3, 0},
  {"PO_UNIT", TYPC, 3, 0},
  {"PO_UNIT_ISO", TYPC, 3, 0},
  {"DOCUMENT", TYPC, 22, 0},
  {"DOC_TYPE", TYPC, 3, 0},
  {"DOC_VERS", TYPC, 2, 0},
  {"DOC_FORMAT", TYPC, 4, 0},
  {"DOC_CHG_NO", TYPC, 6, 0},
  {"PAGE_NO", TYPC, 3, 0},
  {"NO_SHEETS", TYPNUM, 3, 0},
  {"PROD_MEMO", TYPC, 18, 0},
  {"PAGEFORMAT", TYPC, 4, 0},
  {"SIZE_DIM", TYPC, 32, 0},
  {"BASIC_MATL", TYPC, 48, 0},
  {"STD_DESCR", TYPC, 18, 0},
  {"DSN_OFFICE", TYPC, 3, 0},
  {"PUR_VALKEY", TYPC, 4, 0},
  {"NET_WEIGHT", TYPP, 7, 0},
  {"UNIT_OF_WT", TYPC, 3, 0},
  {"UNIT_OF_WT_ISO", TYPC, 3, 0},
  {"CONTAINER", TYPC, 2, 0},
  {"STOR_CONDS", TYPC, 2, 0},
  {"TEMP_CONDS", TYPC, 2, 0},
  {"TRANS_GRP", TYPC, 4, 0},
  {"HAZ_MAT_NO", TYPC, 18, 0},
  {"DIVISION", TYPC, 2, 0},
  {"COMPETITOR", TYPC, 10, 0},
  {"QTY_GR_GI", TYPP, 7, 0},
  {"PROC_RULE", TYPC, 1, 0},
  {"SUP_SOURCE", TYPC, 1, 0},
  {"SEASON", TYPC, 4, 0},
  {"LABEL_TYPE", TYPC, 2, 0},
  {"LABEL_FORM", TYPC, 2, 0},
  {"PROD_HIER", TYPC, 18, 0},
  {"CAD_ID", TYPC, 1, 0},
  {"ALLOWED_WT", TYPP, 7, 0},
  {"PACK_WT_UN", TYPC, 3, 0},
  {"PACK_WT_UN_ISO", TYPC, 3, 0},
  {"ALLWD_VOL", TYPP, 7, 0},
  {"PACK_VO_UN", TYPC, 3, 0},
  {"PACK_VO_UN_ISO", TYPC, 3, 0},
  {"WT_TOL_LT", TYPP, 2, 0},
  {"VOL_TOL_LT", TYPP, 2, 0},
  {"VAR_ORD_UN", TYPC, 1, 0},
  {"BATCH_MGMT", TYPC, 1, 0},
  {"SH_MAT_TYP", TYPC, 4, 0},
  {"FILL_LEVEL", TYPP, 2, 0},
  {"STACK_FACT", TYPINT2, sizeof(RFC_INT2), 0},
  {"MAT_GRP_SM", TYPC, 4, 0},
  {"AUTHORITYGROUP", TYPC, 4, 0},
  {"QM_PROCMNT", TYPC, 1, 0},
  {"CATPROFILE", TYPC, 9, 0},
  {"MINREMLIFE", TYPP, 3, 0},
  {"SHELF_LIFE", TYPP, 3, 0},
  {"STOR_PCT", TYPP, 2, 0},
  {"PUR_STATUS", TYPC, 2, 0},
  {"SAL_STATUS", TYPC, 2, 0},
  {"PVALIDFROM", TYPDATE, sizeof(RFC_DATE), 0},
  {"SVALIDFROM", TYPDATE, sizeof(RFC_DATE), 0},
  {"ENVT_RLVT", TYPC, 1, 0},
  {"PROD_ALLOC", TYPC, 18, 0},
  {"QUAL_DIK", TYPC, 1, 0},
  {"MANU_MAT", TYPC, 40, 0},
  {"MFR_NO", TYPC, 10, 0},
  {"INV_MAT_NO", TYPC, 18, 0},
  {"MANUF_PROF", TYPC, 4, 0},
  {"HAZMATPROF", TYPC, 3, 0},
  {"HIGH_VISC", TYPC, 1, 0},
  {"LOOSEORLIQ", TYPC, 1, 0},
  {"CLOSED_BOX", TYPC, 1, 0},
  {"APPD_B_REC", TYPC, 1, 0},
  {"MATCMPLLVL", TYPNUM, 2, 0},
  {"PAR_EFF", TYPC, 1, 0},
  {"ROUND_UP_RULE_EXPIRATION_DATE", TYPC, 1, 0},
  {"PERIOD_IND_EXPIRATION_DATE", TYPC, 1, 0},
  {"PROD_COMPOSITION_ON_PACKAGING", TYPC, 1, 0},
  {"ITEM_CAT", TYPC, 4, 0},
  {"HAZ_MAT_NO_EXTERNAL", TYPC, 40, 0},
  {"HAZ_MAT_NO_GUID", TYPC, 32, 0},
  {"HAZ_MAT_NO_VERSION", TYPC, 10, 0},
  {"INV_MAT_NO_EXTERNAL", TYPC, 40, 0},
  {"INV_MAT_NO_GUID", TYPC, 32, 0},
  {"INV_MAT_NO_VERSION", TYPC, 10, 0},
  {"MATERIAL_FIXED", TYPC, 1, 0},
  {"CM_RELEVANCE_FLAG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MARAX
#define SAP_TH_BAPI_MARAX
static RFC_TYPEHANDLE handleOfBAPI_MARAX;

static RFC_TYPE_ELEMENT typeOfBAPI_MARAX[] = {
  {"DEL_FLAG", TYPC, 1, 0},
  {"MATL_GROUP", TYPC, 1, 0},
  {"OLD_MAT_NO", TYPC, 1, 0},
  {"BASE_UOM", TYPC, 1, 0},
  {"BASE_UOM_ISO", TYPC, 1, 0},
  {"PO_UNIT", TYPC, 1, 0},
  {"PO_UNIT_ISO", TYPC, 1, 0},
  {"DOCUMENT", TYPC, 1, 0},
  {"DOC_TYPE", TYPC, 1, 0},
  {"DOC_VERS", TYPC, 1, 0},
  {"DOC_FORMAT", TYPC, 1, 0},
  {"DOC_CHG_NO", TYPC, 1, 0},
  {"PAGE_NO", TYPC, 1, 0},
  {"NO_SHEETS", TYPC, 1, 0},
  {"PROD_MEMO", TYPC, 1, 0},
  {"PAGEFORMAT", TYPC, 1, 0},
  {"SIZE_DIM", TYPC, 1, 0},
  {"BASIC_MATL", TYPC, 1, 0},
  {"STD_DESCR", TYPC, 1, 0},
  {"DSN_OFFICE", TYPC, 1, 0},
  {"PUR_VALKEY", TYPC, 1, 0},
  {"NET_WEIGHT", TYPC, 1, 0},
  {"UNIT_OF_WT", TYPC, 1, 0},
  {"UNIT_OF_WT_ISO", TYPC, 1, 0},
  {"CONTAINER", TYPC, 1, 0},
  {"STOR_CONDS", TYPC, 1, 0},
  {"TEMP_CONDS", TYPC, 1, 0},
  {"TRANS_GRP", TYPC, 1, 0},
  {"HAZ_MAT_NO", TYPC, 1, 0},
  {"DIVISION", TYPC, 1, 0},
  {"COMPETITOR", TYPC, 1, 0},
  {"QTY_GR_GI", TYPC, 1, 0},
  {"PROC_RULE", TYPC, 1, 0},
  {"SUP_SOURCE", TYPC, 1, 0},
  {"SEASON", TYPC, 1, 0},
  {"LABEL_TYPE", TYPC, 1, 0},
  {"LABEL_FORM", TYPC, 1, 0},
  {"PROD_HIER", TYPC, 1, 0},
  {"CAD_ID", TYPC, 1, 0},
  {"ALLOWED_WT", TYPC, 1, 0},
  {"PACK_WT_UN", TYPC, 1, 0},
  {"PACK_WT_UN_ISO", TYPC, 1, 0},
  {"ALLWD_VOL", TYPC, 1, 0},
  {"PACK_VO_UN", TYPC, 1, 0},
  {"PACK_VO_UN_ISO", TYPC, 1, 0},
  {"WT_TOL_LT", TYPC, 1, 0},
  {"VOL_TOL_LT", TYPC, 1, 0},
  {"VAR_ORD_UN", TYPC, 1, 0},
  {"BATCH_MGMT", TYPC, 1, 0},
  {"SH_MAT_TYP", TYPC, 1, 0},
  {"FILL_LEVEL", TYPC, 1, 0},
  {"STACK_FACT", TYPC, 1, 0},
  {"MAT_GRP_SM", TYPC, 1, 0},
  {"AUTHORITYGROUP", TYPC, 1, 0},
  {"QM_PROCMNT", TYPC, 1, 0},
  {"CATPROFILE", TYPC, 1, 0},
  {"MINREMLIFE", TYPC, 1, 0},
  {"SHELF_LIFE", TYPC, 1, 0},
  {"STOR_PCT", TYPC, 1, 0},
  {"PUR_STATUS", TYPC, 1, 0},
  {"SAL_STATUS", TYPC, 1, 0},
  {"PVALIDFROM", TYPC, 1, 0},
  {"SVALIDFROM", TYPC, 1, 0},
  {"ENVT_RLVT", TYPC, 1, 0},
  {"PROD_ALLOC", TYPC, 1, 0},
  {"QUAL_DIK", TYPC, 1, 0},
  {"MANU_MAT", TYPC, 1, 0},
  {"MFR_NO", TYPC, 1, 0},
  {"INV_MAT_NO", TYPC, 1, 0},
  {"MANUF_PROF", TYPC, 1, 0},
  {"HAZMATPROF", TYPC, 1, 0},
  {"HIGH_VISC", TYPC, 1, 0},
  {"LOOSEORLIQ", TYPC, 1, 0},
  {"CLOSED_BOX", TYPC, 1, 0},
  {"APPD_B_REC", TYPC, 1, 0},
  {"MATCMPLLVL", TYPC, 1, 0},
  {"PAR_EFF", TYPC, 1, 0},
  {"ROUND_UP_RULE_EXPIRATION_DATE", TYPC, 1, 0},
  {"PERIOD_IND_EXPIRATION_DATE", TYPC, 1, 0},
  {"PROD_COMPOSITION_ON_PACKAGING", TYPC, 1, 0},
  {"ITEM_CAT", TYPC, 1, 0},
  {"HAZ_MAT_NO_EXTERNAL", TYPC, 1, 0},
  {"HAZ_MAT_NO_GUID", TYPC, 1, 0},
  {"HAZ_MAT_NO_VERSION", TYPC, 1, 0},
  {"INV_MAT_NO_EXTERNAL", TYPC, 1, 0},
  {"INV_MAT_NO_GUID", TYPC, 1, 0},
  {"INV_MAT_NO_VERSION", TYPC, 1, 0},
  {"MATERIAL_FIXED", TYPC, 1, 0},
  {"CM_RELEVANCE_FLAG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MPOP
#define SAP_TH_BAPI_MPOP
static RFC_TYPEHANDLE handleOfBAPI_MPOP;

static RFC_TYPE_ELEMENT typeOfBAPI_MPOP[] = {
  {"PLANT", TYPC, 4, 0},
  {"FORE_PROF", TYPC, 4, 0},
  {"MODEL_SI", TYPC, 1, 0},
  {"MODEL_SP", TYPC, 1, 0},
  {"PARAM_OPT", TYPC, 1, 0},
  {"OPTIM_LEV", TYPC, 1, 0},
  {"INITIALIZE", TYPC, 1, 0},
  {"FORE_MODEL", TYPC, 1, 0},
  {"ALPHA_FACT", TYPP, 2, 0},
  {"BETA_FACT", TYPP, 2, 0},
  {"GAMMA_FACT", TYPP, 2, 0},
  {"DELTA_FACT", TYPP, 2, 0},
  {"TRACKLIMIT", TYPP, 3, 0},
  {"FORE_DATE", TYPDATE, sizeof(RFC_DATE), 0},
  {"HIST_VALS", TYPP, 2, 0},
  {"INIT_PDS", TYPP, 2, 0},
  {"SEASON_PDS", TYPP, 2, 0},
  {"EXPOST_PDS", TYPP, 2, 0},
  {"FORE_PDS", TYPP, 2, 0},
  {"FIXED_PDS", TYPP, 2, 0},
  {"WTG_GROUP", TYPC, 2, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MPOPX
#define SAP_TH_BAPI_MPOPX
static RFC_TYPEHANDLE handleOfBAPI_MPOPX;

static RFC_TYPE_ELEMENT typeOfBAPI_MPOPX[] = {
  {"PLANT", TYPC, 4, 0},
  {"FORE_PROF", TYPC, 1, 0},
  {"MODEL_SI", TYPC, 1, 0},
  {"MODEL_SP", TYPC, 1, 0},
  {"PARAM_OPT", TYPC, 1, 0},
  {"OPTIM_LEV", TYPC, 1, 0},
  {"INITIALIZE", TYPC, 1, 0},
  {"FORE_MODEL", TYPC, 1, 0},
  {"ALPHA_FACT", TYPC, 1, 0},
  {"BETA_FACT", TYPC, 1, 0},
  {"GAMMA_FACT", TYPC, 1, 0},
  {"DELTA_FACT", TYPC, 1, 0},
  {"TRACKLIMIT", TYPC, 1, 0},
  {"FORE_DATE", TYPC, 1, 0},
  {"HIST_VALS", TYPC, 1, 0},
  {"INIT_PDS", TYPC, 1, 0},
  {"SEASON_PDS", TYPC, 1, 0},
  {"EXPOST_PDS", TYPC, 1, 0},
  {"FORE_PDS", TYPC, 1, 0},
  {"FIXED_PDS", TYPC, 1, 0},
  {"WTG_GROUP", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPIMATHEAD
#define SAP_TH_BAPIMATHEAD
static RFC_TYPEHANDLE handleOfBAPIMATHEAD;

static RFC_TYPE_ELEMENT typeOfBAPIMATHEAD[] = {
  {"MATERIAL", TYPC, 18, 0},
  {"IND_SECTOR", TYPC, 1, 0},
  {"MATL_TYPE", TYPC, 4, 0},
  {"BASIC_VIEW", TYPC, 1, 0},
  {"SALES_VIEW", TYPC, 1, 0},
  {"PURCHASE_VIEW", TYPC, 1, 0},
  {"MRP_VIEW", TYPC, 1, 0},
  {"FORECAST_VIEW", TYPC, 1, 0},
  {"WORK_SCHED_VIEW", TYPC, 1, 0},
  {"PRT_VIEW", TYPC, 1, 0},
  {"STORAGE_VIEW", TYPC, 1, 0},
  {"WAREHOUSE_VIEW", TYPC, 1, 0},
  {"QUALITY_VIEW", TYPC, 1, 0},
  {"ACCOUNT_VIEW", TYPC, 1, 0},
  {"COST_VIEW", TYPC, 1, 0},
  {"INP_FLD_CHECK", TYPC, 1, 0},
  {"MATERIAL_EXTERNAL", TYPC, 40, 0},
  {"MATERIAL_GUID", TYPC, 32, 0},
  {"MATERIAL_VERSION", TYPC, 10, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MPGD
#define SAP_TH_BAPI_MPGD
static RFC_TYPEHANDLE handleOfBAPI_MPGD;

static RFC_TYPE_ELEMENT typeOfBAPI_MPGD[] = {
  {"PLANT", TYPC, 4, 0},
  {"PLNG_MATL", TYPC, 18, 0},
  {"PLNG_PLANT", TYPC, 4, 0},
  {"CONVFACTOR", TYPC, 10, 0},
  {"PLNG_MATL_EXTERNAL", TYPC, 40, 0},
  {"PLNG_MATL_GUID", TYPC, 32, 0},
  {"PLNG_MATL_VERSION", TYPC, 10, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MPGDX
#define SAP_TH_BAPI_MPGDX
static RFC_TYPEHANDLE handleOfBAPI_MPGDX;

static RFC_TYPE_ELEMENT typeOfBAPI_MPGDX[] = {
  {"PLANT", TYPC, 4, 0},
  {"PLNG_MATL", TYPC, 1, 0},
  {"PLNG_PLANT", TYPC, 1, 0},
  {"CONVFACTOR", TYPC, 1, 0},
  {"PLNG_MATL_EXTERNAL", TYPC, 1, 0},
  {"PLNG_MATL_GUID", TYPC, 1, 0},
  {"PLNG_MATL_VERSION", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MARC
#define SAP_TH_BAPI_MARC
static RFC_TYPEHANDLE handleOfBAPI_MARC;

static RFC_TYPE_ELEMENT typeOfBAPI_MARC[] = {
  {"PLANT", TYPC, 4, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"ABC_ID", TYPC, 1, 0},
  {"CRIT_PART", TYPC, 1, 0},
  {"PUR_GROUP", TYPC, 3, 0},
  {"ISSUE_UNIT", TYPC, 3, 0},
  {"ISSUE_UNIT_ISO", TYPC, 3, 0},
  {"MRPPROFILE", TYPC, 4, 0},
  {"MRP_TYPE", TYPC, 2, 0},
  {"MRP_CTRLER", TYPC, 3, 0},
  {"PLND_DELRY", TYPP, 2, 0},
  {"GR_PR_TIME", TYPP, 2, 0},
  {"PERIOD_IND", TYPC, 1, 0},
  {"ASSY_SCRAP", TYPP, 3, 0},
  {"LOTSIZEKEY", TYPC, 2, 0},
  {"PROC_TYPE", TYPC, 1, 0},
  {"SPPROCTYPE", TYPC, 2, 0},
  {"REORDER_PT", TYPP, 7, 0},
  {"SAFETY_STK", TYPP, 7, 0},
  {"MINLOTSIZE", TYPP, 7, 0},
  {"MAXLOTSIZE", TYPP, 7, 0},
  {"FIXED_LOT", TYPP, 7, 0},
  {"ROUND_VAL", TYPP, 7, 0},
  {"MAX_STOCK", TYPP, 7, 0},
  {"ORD_COSTS", TYPP, 12, 0},
  {"DEP_REQ_ID", TYPC, 1, 0},
  {"STOR_COSTS", TYPC, 1, 0},
  {"ALT_BOM_ID", TYPC, 1, 0},
  {"DISCONTINU", TYPC, 1, 0},
  {"EFF_O_DAY", TYPDATE, sizeof(RFC_DATE), 0},
  {"FOLLOW_UP", TYPC, 18, 0},
  {"GRP_REQMTS", TYPC, 1, 0},
  {"MIXED_MRP", TYPC, 1, 0},
  {"SM_KEY", TYPC, 3, 0},
  {"BACKFLUSH", TYPC, 1, 0},
  {"PRODUCTION_SCHEDULER", TYPC, 3, 0},
  {"PROC_TIME", TYPP, 3, 0},
  {"SETUPTIME", TYPP, 3, 0},
  {"INTEROP", TYPP, 3, 0},
  {"BASE_QTY", TYPP, 7, 0},
  {"INHSEPRODT", TYPP, 2, 0},
  {"STGEPERIOD", TYPP, 3, 0},
  {"STGE_PD_UN", TYPC, 3, 0},
  {"STGE_PD_UN_ISO", TYPC, 3, 0},
  {"OVER_TOL", TYPP, 2, 0},
  {"UNLIMITED", TYPC, 1, 0},
  {"UNDER_TOL", TYPP, 2, 0},
  {"REPLENTIME", TYPP, 2, 0},
  {"REPLACE_PT", TYPC, 1, 0},
  {"IND_POST_TO_INSP_STOCK", TYPC, 1, 0},
  {"CTRL_KEY", TYPC, 8, 0},
  {"DOC_REQD", TYPC, 1, 0},
  {"LOADINGGRP", TYPC, 4, 0},
  {"BATCH_MGMT", TYPC, 1, 0},
  {"QUOTAUSAGE", TYPC, 1, 0},
  {"SERV_LEVEL", TYPP, 2, 0},
  {"SPLIT_IND", TYPC, 1, 0},
  {"AVAILCHECK", TYPC, 2, 0},
  {"FY_VARIANT", TYPC, 2, 0},
  {"CORR_FACT", TYPC, 1, 0},
  {"SETUP_TIME", TYPP, 3, 0},
  {"BASE_QTY_PLAN", TYPP, 7, 0},
  {"SHIP_PROC_TIME", TYPP, 3, 0},
  {"SUP_SOURCE", TYPC, 1, 0},
  {"AUTO_P_ORD", TYPC, 1, 0},
  {"SOURCELIST", TYPC, 1, 0},
  {"COMM_CODE", TYPC, 17, 0},
  {"COUNTRYORI", TYPC, 3, 0},
  {"COUNTRYORI_ISO", TYPC, 2, 0},
  {"REGIONORIG", TYPC, 3, 0},
  {"COMM_CO_UN", TYPC, 3, 0},
  {"COMM_CO_UN_ISO", TYPC, 3, 0},
  {"EXPIMPGRP", TYPC, 4, 0},
  {"PROFIT_CTR", TYPC, 10, 0},
  {"PPC_PL_CAL", TYPC, 3, 0},
  {"REP_MANUF", TYPC, 1, 0},
  {"PL_TI_FNCE", TYPNUM, 3, 0},
  {"CONSUMMODE", TYPC, 1, 0},
  {"BWD_CONS", TYPNUM, 3, 0},
  {"FWD_CONS", TYPNUM, 3, 0},
  {"ALTERNATIVE_BOM", TYPC, 2, 0},
  {"BOM_USAGE", TYPC, 1, 0},
  {"PLANLISTGRP", TYPC, 8, 0},
  {"PLANLISTCNT", TYPC, 2, 0},
  {"LOT_SIZE", TYPP, 7, 0},
  {"SPECPROCTY", TYPC, 2, 0},
  {"PROD_UNIT", TYPC, 3, 0},
  {"PROD_UNIT_ISO", TYPC, 3, 0},
  {"ISS_ST_LOC", TYPC, 4, 0},
  {"MRP_GROUP", TYPC, 4, 0},
  {"COMP_SCRAP", TYPP, 3, 0},
  {"CERT_TYPE", TYPC, 4, 0},
  {"CYCLE_TIME", TYPP, 2, 0},
  {"COVPROFILE", TYPC, 3, 0},
  {"CC_PH_INV", TYPC, 1, 0},
  {"VARIANCE_KEY", TYPC, 6, 0},
  {"SERNO_PROF", TYPC, 4, 0},
  {"REPMANPROF", TYPC, 4, 0},
  {"NEG_STOCKS", TYPC, 1, 0},
  {"QM_RGMTS", TYPC, 4, 0},
  {"PLNG_CYCLE", TYPC, 3, 0},
  {"ROUND_PROF", TYPC, 4, 0},
  {"REFMATCONS", TYPC, 18, 0},
  {"D_TO_REF_M", TYPDATE, sizeof(RFC_DATE), 0},
  {"MULT_REF_M", TYPP, 3, 0},
  {"AUTO_RESET", TYPC, 1, 0},
  {"EX_CERT_ID", TYPC, 1, 0},
  {"EX_CERT_NO_NEW", TYPC, 8, 0},
  {"EX_CERT_DT", TYPDATE, sizeof(RFC_DATE), 0},
  {"MILIT_ID", TYPC, 1, 0},
  {"INSP_INT", TYPP, 3, 0},
  {"CO_PRODUCT", TYPC, 1, 0},
  {"PLAN_STRGP", TYPC, 2, 0},
  {"SLOC_EXPRC", TYPC, 4, 0},
  {"BULK_MAT", TYPC, 1, 0},
  {"CC_FIXED", TYPC, 1, 0},
  {"DETERM_GRP", TYPC, 4, 0},
  {"QM_AUTHGRP", TYPC, 6, 0},
  {"TASK_LIST_TYPE", TYPC, 1, 0},
  {"PUR_STATUS", TYPC, 2, 0},
  {"PRODPROF", TYPC, 6, 0},
  {"SAFTY_T_ID", TYPC, 1, 0},
  {"SAFETYTIME", TYPNUM, 2, 0},
  {"PLORD_CTRL", TYPC, 2, 0},
  {"BATCHENTRY", TYPC, 1, 0},
  {"PVALIDFROM", TYPDATE, sizeof(RFC_DATE), 0},
  {"MATFRGTGRP", TYPC, 8, 0},
  {"PRODVERSCS", TYPC, 4, 0},
  {"MAT_CFOP", TYPC, 2, 0},
  {"EU_LIST_NO", TYPC, 12, 0},
  {"EU_MAT_GRP", TYPC, 6, 0},
  {"CAS_NO", TYPC, 15, 0},
  {"PRODCOM_NO", TYPC, 9, 0},
  {"CTRL_CODE", TYPC, 16, 0},
  {"JIT_RELVT", TYPC, 1, 0},
  {"MAT_GRP_TRANS", TYPC, 20, 0},
  {"HANDLG_GRP", TYPC, 4, 0},
  {"SUPPLY_AREA", TYPC, 10, 0},
  {"FAIR_SHARE_RULE", TYPC, 2, 0},
  {"PUSH_DISTRIB", TYPC, 1, 0},
  {"DEPLOY_HORIZ", TYPP, 2, 0},
  {"MIN_LOT_SIZE", TYPP, 7, 0},
  {"MAX_LOT_SIZE", TYPP, 7, 0},
  {"FIX_LOT_SIZE", TYPP, 7, 0},
  {"LOT_INCREMENT", TYPP, 7, 0},
  {"PROD_CONV_TYPE", TYPC, 2, 0},
  {"DISTR_PROF", TYPC, 3, 0},
  {"PERIOD_PROFILE_SAFETY_TIME", TYPC, 3, 0},
  {"FXD_PRICE", TYPC, 1, 0},
  {"AVAIL_CHECK_ALL_PROJ_SEGMENTS", TYPC, 1, 0},
  {"OVERALLPRF", TYPC, 6, 0},
  {"MRP_RELEVANCY_DEP_REQUIREMENTS", TYPC, 1, 0},
  {"MIN_SAFETY_STK", TYPP, 7, 0},
  {"NO_COSTING", TYPC, 1, 0},
  {"UNIT_GROUP", TYPC, 4, 0},
  {"FOLLOW_UP_EXTERNAL", TYPC, 40, 0},
  {"FOLLOW_UP_GUID", TYPC, 32, 0},
  {"FOLLOW_UP_VERSION", TYPC, 10, 0},
  {"REFMATCONS_EXTERNAL", TYPC, 40, 0},
  {"REFMATCONS_GUID", TYPC, 32, 0},
  {"REFMATCONS_VERSION", TYPC, 10, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MARCX
#define SAP_TH_BAPI_MARCX
static RFC_TYPEHANDLE handleOfBAPI_MARCX;

static RFC_TYPE_ELEMENT typeOfBAPI_MARCX[] = {
  {"PLANT", TYPC, 4, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"ABC_ID", TYPC, 1, 0},
  {"CRIT_PART", TYPC, 1, 0},
  {"PUR_GROUP", TYPC, 1, 0},
  {"ISSUE_UNIT", TYPC, 1, 0},
  {"ISSUE_UNIT_ISO", TYPC, 1, 0},
  {"MRPPROFILE", TYPC, 1, 0},
  {"MRP_TYPE", TYPC, 1, 0},
  {"MRP_CTRLER", TYPC, 1, 0},
  {"PLND_DELRY", TYPC, 1, 0},
  {"GR_PR_TIME", TYPC, 1, 0},
  {"PERIOD_IND", TYPC, 1, 0},
  {"ASSY_SCRAP", TYPC, 1, 0},
  {"LOTSIZEKEY", TYPC, 1, 0},
  {"PROC_TYPE", TYPC, 1, 0},
  {"SPPROCTYPE", TYPC, 1, 0},
  {"REORDER_PT", TYPC, 1, 0},
  {"SAFETY_STK", TYPC, 1, 0},
  {"MINLOTSIZE", TYPC, 1, 0},
  {"MAXLOTSIZE", TYPC, 1, 0},
  {"FIXED_LOT", TYPC, 1, 0},
  {"ROUND_VAL", TYPC, 1, 0},
  {"MAX_STOCK", TYPC, 1, 0},
  {"ORD_COSTS", TYPC, 1, 0},
  {"DEP_REQ_ID", TYPC, 1, 0},
  {"STOR_COSTS", TYPC, 1, 0},
  {"ALT_BOM_ID", TYPC, 1, 0},
  {"DISCONTINU", TYPC, 1, 0},
  {"EFF_O_DAY", TYPC, 1, 0},
  {"FOLLOW_UP", TYPC, 1, 0},
  {"GRP_REQMTS", TYPC, 1, 0},
  {"MIXED_MRP", TYPC, 1, 0},
  {"SM_KEY", TYPC, 1, 0},
  {"BACKFLUSH", TYPC, 1, 0},
  {"PRODUCTION_SCHEDULER", TYPC, 1, 0},
  {"PROC_TIME", TYPC, 1, 0},
  {"SETUPTIME", TYPC, 1, 0},
  {"INTEROP", TYPC, 1, 0},
  {"BASE_QTY", TYPC, 1, 0},
  {"INHSEPRODT", TYPC, 1, 0},
  {"STGEPERIOD", TYPC, 1, 0},
  {"STGE_PD_UN", TYPC, 1, 0},
  {"STGE_PD_UN_ISO", TYPC, 1, 0},
  {"OVER_TOL", TYPC, 1, 0},
  {"UNLIMITED", TYPC, 1, 0},
  {"UNDER_TOL", TYPC, 1, 0},
  {"REPLENTIME", TYPC, 1, 0},
  {"REPLACE_PT", TYPC, 1, 0},
  {"IND_POST_TO_INSP_STOCK", TYPC, 1, 0},
  {"CTRL_KEY", TYPC, 1, 0},
  {"DOC_REQD", TYPC, 1, 0},
  {"LOADINGGRP", TYPC, 1, 0},
  {"BATCH_MGMT", TYPC, 1, 0},
  {"QUOTAUSAGE", TYPC, 1, 0},
  {"SERV_LEVEL", TYPC, 1, 0},
  {"SPLIT_IND", TYPC, 1, 0},
  {"AVAILCHECK", TYPC, 1, 0},
  {"FY_VARIANT", TYPC, 1, 0},
  {"CORR_FACT", TYPC, 1, 0},
  {"SETUP_TIME", TYPC, 1, 0},
  {"BASE_QTY_PLAN", TYPC, 1, 0},
  {"SHIP_PROC_TIME", TYPC, 1, 0},
  {"SUP_SOURCE", TYPC, 1, 0},
  {"AUTO_P_ORD", TYPC, 1, 0},
  {"SOURCELIST", TYPC, 1, 0},
  {"COMM_CODE", TYPC, 1, 0},
  {"COUNTRYORI", TYPC, 1, 0},
  {"COUNTRYORI_ISO", TYPC, 1, 0},
  {"REGIONORIG", TYPC, 1, 0},
  {"COMM_CO_UN", TYPC, 1, 0},
  {"COMM_CO_UN_ISO", TYPC, 1, 0},
  {"EXPIMPGRP", TYPC, 1, 0},
  {"PROFIT_CTR", TYPC, 1, 0},
  {"PPC_PL_CAL", TYPC, 1, 0},
  {"REP_MANUF", TYPC, 1, 0},
  {"PL_TI_FNCE", TYPC, 1, 0},
  {"CONSUMMODE", TYPC, 1, 0},
  {"BWD_CONS", TYPC, 1, 0},
  {"FWD_CONS", TYPC, 1, 0},
  {"ALTERNATIVE_BOM", TYPC, 1, 0},
  {"BOM_USAGE", TYPC, 1, 0},
  {"PLANLISTGRP", TYPC, 1, 0},
  {"PLANLISTCNT", TYPC, 1, 0},
  {"LOT_SIZE", TYPC, 1, 0},
  {"SPECPROCTY", TYPC, 1, 0},
  {"PROD_UNIT", TYPC, 1, 0},
  {"PROD_UNIT_ISO", TYPC, 1, 0},
  {"ISS_ST_LOC", TYPC, 1, 0},
  {"MRP_GROUP", TYPC, 1, 0},
  {"COMP_SCRAP", TYPC, 1, 0},
  {"CERT_TYPE", TYPC, 1, 0},
  {"CYCLE_TIME", TYPC, 1, 0},
  {"COVPROFILE", TYPC, 1, 0},
  {"CC_PH_INV", TYPC, 1, 0},
  {"VARIANCE_KEY", TYPC, 1, 0},
  {"SERNO_PROF", TYPC, 1, 0},
  {"REPMANPROF", TYPC, 1, 0},
  {"NEG_STOCKS", TYPC, 1, 0},
  {"QM_RGMTS", TYPC, 1, 0},
  {"PLNG_CYCLE", TYPC, 1, 0},
  {"ROUND_PROF", TYPC, 1, 0},
  {"REFMATCONS", TYPC, 1, 0},
  {"D_TO_REF_M", TYPC, 1, 0},
  {"MULT_REF_M", TYPC, 1, 0},
  {"AUTO_RESET", TYPC, 1, 0},
  {"EX_CERT_ID", TYPC, 1, 0},
  {"EX_CERT_NO_NEW", TYPC, 1, 0},
  {"EX_CERT_DT", TYPC, 1, 0},
  {"MILIT_ID", TYPC, 1, 0},
  {"INSP_INT", TYPC, 1, 0},
  {"CO_PRODUCT", TYPC, 1, 0},
  {"PLAN_STRGP", TYPC, 1, 0},
  {"SLOC_EXPRC", TYPC, 1, 0},
  {"BULK_MAT", TYPC, 1, 0},
  {"CC_FIXED", TYPC, 1, 0},
  {"DETERM_GRP", TYPC, 1, 0},
  {"QM_AUTHGRP", TYPC, 1, 0},
  {"TASK_LIST_TYPE", TYPC, 1, 0},
  {"PUR_STATUS", TYPC, 1, 0},
  {"PRODPROF", TYPC, 1, 0},
  {"SAFTY_T_ID", TYPC, 1, 0},
  {"SAFETYTIME", TYPC, 1, 0},
  {"PLORD_CTRL", TYPC, 1, 0},
  {"BATCHENTRY", TYPC, 1, 0},
  {"PVALIDFROM", TYPC, 1, 0},
  {"MATFRGTGRP", TYPC, 1, 0},
  {"PRODVERSCS", TYPC, 1, 0},
  {"MAT_CFOP", TYPC, 1, 0},
  {"EU_LIST_NO", TYPC, 1, 0},
  {"EU_MAT_GRP", TYPC, 1, 0},
  {"CAS_NO", TYPC, 1, 0},
  {"PRODCOM_NO", TYPC, 1, 0},
  {"CTRL_CODE", TYPC, 1, 0},
  {"JIT_RELVT", TYPC, 1, 0},
  {"MAT_GRP_TRANS", TYPC, 1, 0},
  {"HANDLG_GRP", TYPC, 1, 0},
  {"SUPPLY_AREA", TYPC, 1, 0},
  {"FAIR_SHARE_RULE", TYPC, 1, 0},
  {"PUSH_DISTRIB", TYPC, 1, 0},
  {"DEPLOY_HORIZ", TYPC, 1, 0},
  {"MIN_LOT_SIZE", TYPC, 1, 0},
  {"MAX_LOT_SIZE", TYPC, 1, 0},
  {"FIX_LOT_SIZE", TYPC, 1, 0},
  {"LOT_INCREMENT", TYPC, 1, 0},
  {"PROD_CONV_TYPE", TYPC, 1, 0},
  {"DISTR_PROF", TYPC, 1, 0},
  {"PERIOD_PROFILE_SAFETY_TIME", TYPC, 1, 0},
  {"FXD_PRICE", TYPC, 1, 0},
  {"AVAIL_CHECK_ALL_PROJ_SEGMENTS", TYPC, 1, 0},
  {"OVERALLPRF", TYPC, 1, 0},
  {"MRP_RELEVANCY_DEP_REQUIREMENTS", TYPC, 1, 0},
  {"MIN_SAFETY_STK", TYPC, 1, 0},
  {"NO_COSTING", TYPC, 1, 0},
  {"UNIT_GROUP", TYPC, 1, 0},
  {"FOLLOW_UP_EXTERNAL", TYPC, 1, 0},
  {"FOLLOW_UP_GUID", TYPC, 1, 0},
  {"FOLLOW_UP_VERSION", TYPC, 1, 0},
  {"REFMATCONS_EXTERNAL", TYPC, 1, 0},
  {"REFMATCONS_GUID", TYPC, 1, 0},
  {"REFMATCONS_VERSION", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MVKE
#define SAP_TH_BAPI_MVKE
static RFC_TYPEHANDLE handleOfBAPI_MVKE;

static RFC_TYPE_ELEMENT typeOfBAPI_MVKE[] = {
  {"SALES_ORG", TYPC, 4, 0},
  {"DISTR_CHAN", TYPC, 2, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"MATL_STATS", TYPC, 1, 0},
  {"REBATE_GRP", TYPC, 2, 0},
  {"COMM_GROUP", TYPC, 2, 0},
  {"CASH_DISC", TYPC, 1, 0},
  {"SAL_STATUS", TYPC, 2, 0},
  {"VALID_FROM", TYPDATE, sizeof(RFC_DATE), 0},
  {"MIN_ORDER", TYPP, 7, 0},
  {"MIN_DELY", TYPP, 7, 0},
  {"MIN_MTO", TYPP, 7, 0},
  {"DELY_UNIT", TYPP, 7, 0},
  {"DELY_UOM", TYPC, 3, 0},
  {"DELY_UOM_ISO", TYPC, 3, 0},
  {"SALES_UNIT", TYPC, 3, 0},
  {"SALES_UNIT_ISO", TYPC, 3, 0},
  {"ITEM_CAT", TYPC, 4, 0},
  {"DELYG_PLNT", TYPC, 4, 0},
  {"PROD_HIER", TYPC, 18, 0},
  {"PR_REF_MAT", TYPC, 18, 0},
  {"MAT_PR_GRP", TYPC, 2, 0},
  {"ACCT_ASSGT", TYPC, 2, 0},
  {"MATL_GRP_1", TYPC, 3, 0},
  {"MATL_GRP_2", TYPC, 3, 0},
  {"MATL_GRP_3", TYPC, 3, 0},
  {"MATL_GRP_4", TYPC, 3, 0},
  {"MATL_GRP_5", TYPC, 3, 0},
  {"PROD_ATT_1", TYPC, 1, 0},
  {"PROD_ATT_2", TYPC, 1, 0},
  {"PROD_ATT_3", TYPC, 1, 0},
  {"PROD_ATT_4", TYPC, 1, 0},
  {"PROD_ATT_5", TYPC, 1, 0},
  {"PROD_ATT_6", TYPC, 1, 0},
  {"PROD_ATT_7", TYPC, 1, 0},
  {"PROD_ATT_8", TYPC, 1, 0},
  {"PROD_ATT_9", TYPC, 1, 0},
  {"PROD_ATT10", TYPC, 1, 0},
  {"ROUND_PROF", TYPC, 4, 0},
  {"VAR_SALES_UN", TYPC, 1, 0},
  {"UNIT_GROUP", TYPC, 4, 0},
  {"PR_REF_MAT_EXTERNAL", TYPC, 40, 0},
  {"PR_REF_MAT_GUID", TYPC, 32, 0},
  {"PR_REF_MAT_VERSION", TYPC, 10, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MVKEX
#define SAP_TH_BAPI_MVKEX
static RFC_TYPEHANDLE handleOfBAPI_MVKEX;

static RFC_TYPE_ELEMENT typeOfBAPI_MVKEX[] = {
  {"SALES_ORG", TYPC, 4, 0},
  {"DISTR_CHAN", TYPC, 2, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"MATL_STATS", TYPC, 1, 0},
  {"REBATE_GRP", TYPC, 1, 0},
  {"COMM_GROUP", TYPC, 1, 0},
  {"CASH_DISC", TYPC, 1, 0},
  {"SAL_STATUS", TYPC, 1, 0},
  {"VALID_FROM", TYPC, 1, 0},
  {"MIN_ORDER", TYPC, 1, 0},
  {"MIN_DELY", TYPC, 1, 0},
  {"MIN_MTO", TYPC, 1, 0},
  {"DELY_UNIT", TYPC, 1, 0},
  {"DELY_UOM", TYPC, 1, 0},
  {"DELY_UOM_ISO", TYPC, 1, 0},
  {"SALES_UNIT", TYPC, 1, 0},
  {"SALES_UNIT_ISO", TYPC, 1, 0},
  {"ITEM_CAT", TYPC, 1, 0},
  {"DELYG_PLNT", TYPC, 1, 0},
  {"PROD_HIER", TYPC, 1, 0},
  {"PR_REF_MAT", TYPC, 1, 0},
  {"MAT_PR_GRP", TYPC, 1, 0},
  {"ACCT_ASSGT", TYPC, 1, 0},
  {"MATL_GRP_1", TYPC, 1, 0},
  {"MATL_GRP_2", TYPC, 1, 0},
  {"MATL_GRP_3", TYPC, 1, 0},
  {"MATL_GRP_4", TYPC, 1, 0},
  {"MATL_GRP_5", TYPC, 1, 0},
  {"PROD_ATT_1", TYPC, 1, 0},
  {"PROD_ATT_2", TYPC, 1, 0},
  {"PROD_ATT_3", TYPC, 1, 0},
  {"PROD_ATT_4", TYPC, 1, 0},
  {"PROD_ATT_5", TYPC, 1, 0},
  {"PROD_ATT_6", TYPC, 1, 0},
  {"PROD_ATT_7", TYPC, 1, 0},
  {"PROD_ATT_8", TYPC, 1, 0},
  {"PROD_ATT_9", TYPC, 1, 0},
  {"PROD_ATT10", TYPC, 1, 0},
  {"ROUND_PROF", TYPC, 1, 0},
  {"VAR_SALES_UN", TYPC, 1, 0},
  {"UNIT_GROUP", TYPC, 1, 0},
  {"PR_REF_MAT_EXTERNAL", TYPC, 1, 0},
  {"PR_REF_MAT_GUID", TYPC, 1, 0},
  {"PR_REF_MAT_VERSION", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MARD
#define SAP_TH_BAPI_MARD
static RFC_TYPEHANDLE handleOfBAPI_MARD;

static RFC_TYPE_ELEMENT typeOfBAPI_MARD[] = {
  {"PLANT", TYPC, 4, 0},
  {"STGE_LOC", TYPC, 4, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"MRP_IND", TYPC, 1, 0},
  {"SPEC_PROC", TYPC, 2, 0},
  {"REORDER_PT", TYPP, 7, 0},
  {"REPL_QTY", TYPP, 7, 0},
  {"STGE_BIN", TYPC, 10, 0},
  {"PICKG_AREA", TYPC, 3, 0},
  {"INV_CORR_FAC", TYPFLOAT, sizeof(double), 0},
 };
#endif

#ifndef SAP_TH_BAPI_MARDX
#define SAP_TH_BAPI_MARDX
static RFC_TYPEHANDLE handleOfBAPI_MARDX;

static RFC_TYPE_ELEMENT typeOfBAPI_MARDX[] = {
  {"PLANT", TYPC, 4, 0},
  {"STGE_LOC", TYPC, 4, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"MRP_IND", TYPC, 1, 0},
  {"SPEC_PROC", TYPC, 1, 0},
  {"REORDER_PT", TYPC, 1, 0},
  {"REPL_QTY", TYPC, 1, 0},
  {"STGE_BIN", TYPC, 1, 0},
  {"PICKG_AREA", TYPC, 1, 0},
  {"INV_CORR_FAC", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MLGT
#define SAP_TH_BAPI_MLGT
static RFC_TYPEHANDLE handleOfBAPI_MLGT;

static RFC_TYPE_ELEMENT typeOfBAPI_MLGT[] = {
  {"WHSE_NO", TYPC, 3, 0},
  {"STGE_TYPE", TYPC, 3, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"STGE_BIN", TYPC, 10, 0},
  {"MAX_SB_QTY", TYPP, 7, 0},
  {"MIN_SB_QTY", TYPP, 7, 0},
  {"CTRL_QTY", TYPP, 7, 0},
  {"REPLEN_QTY", TYPP, 7, 0},
  {"PICK_AREA", TYPC, 3, 0},
  {"ROUND_QTY", TYPP, 7, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MLGTX
#define SAP_TH_BAPI_MLGTX
static RFC_TYPEHANDLE handleOfBAPI_MLGTX;

static RFC_TYPE_ELEMENT typeOfBAPI_MLGTX[] = {
  {"WHSE_NO", TYPC, 3, 0},
  {"STGE_TYPE", TYPC, 3, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"STGE_BIN", TYPC, 1, 0},
  {"MAX_SB_QTY", TYPC, 1, 0},
  {"MIN_SB_QTY", TYPC, 1, 0},
  {"CTRL_QTY", TYPC, 1, 0},
  {"REPLEN_QTY", TYPC, 1, 0},
  {"PICK_AREA", TYPC, 1, 0},
  {"ROUND_QTY", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MBEW
#define SAP_TH_BAPI_MBEW
static RFC_TYPEHANDLE handleOfBAPI_MBEW;

static RFC_TYPE_ELEMENT typeOfBAPI_MBEW[] = {
  {"VAL_AREA", TYPC, 4, 0},
  {"VAL_TYPE", TYPC, 10, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"PRICE_CTRL", TYPC, 1, 0},
  {"MOVING_PR", TYPP, 12, 0},
  {"STD_PRICE", TYPP, 12, 0},
  {"PRICE_UNIT", TYPP, 3, 0},
  {"VAL_CLASS", TYPC, 4, 0},
  {"PR_CTRL_PP", TYPC, 1, 0},
  {"MOV_PR_PP", TYPP, 12, 0},
  {"STD_PR_PP", TYPP, 12, 0},
  {"PR_UNIT_PP", TYPP, 3, 0},
  {"VCLASS_PP", TYPC, 4, 0},
  {"PR_CTRL_PY", TYPC, 1, 0},
  {"MOV_PR_PY", TYPP, 12, 0},
  {"STD_PR_PY", TYPP, 12, 0},
  {"VCLASS_PY", TYPC, 4, 0},
  {"PR_UNIT_PY", TYPP, 3, 0},
  {"VAL_CAT", TYPC, 1, 0},
  {"FUTURE_PR", TYPP, 12, 0},
  {"VALID_FROM", TYPDATE, sizeof(RFC_DATE), 0},
  {"TAXPRICE_1", TYPP, 12, 0},
  {"COMMPRICE1", TYPP, 12, 0},
  {"TAXPRICE_3", TYPP, 12, 0},
  {"COMMPRICE3", TYPP, 12, 0},
  {"PLND_PRICE", TYPP, 12, 0},
  {"PLNDPRICE1", TYPP, 12, 0},
  {"PLNDPRICE2", TYPP, 12, 0},
  {"PLNDPRICE3", TYPP, 12, 0},
  {"PLNDPRDATE1", TYPDATE, sizeof(RFC_DATE), 0},
  {"PLNDPRDATE2", TYPDATE, sizeof(RFC_DATE), 0},
  {"PLNDPRDATE3", TYPDATE, sizeof(RFC_DATE), 0},
  {"LIFO_FIFO", TYPC, 1, 0},
  {"POOLNUMBER", TYPC, 4, 0},
  {"TAXPRICE_2", TYPP, 12, 0},
  {"COMMPRICE2", TYPP, 12, 0},
  {"DEVAL_IND", TYPNUM, 2, 0},
  {"ORIG_GROUP", TYPC, 4, 0},
  {"OVERHEAD_GRP", TYPC, 10, 0},
  {"QTY_STRUCT", TYPC, 1, 0},
  {"ML_ACTIVE", TYPC, 1, 0},
  {"ML_SETTLE", TYPC, 1, 0},
  {"ORIG_MAT", TYPC, 1, 0},
  {"VM_SO_STK", TYPC, 4, 0},
  {"VM_P_STOCK", TYPC, 4, 0},
  {"MATL_USAGE", TYPC, 1, 0},
  {"MAT_ORIGIN", TYPC, 1, 0},
  {"IN_HOUSE", TYPC, 1, 0},
  {"TAX_CML_UN", TYPP, 3, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MBEWX
#define SAP_TH_BAPI_MBEWX
static RFC_TYPEHANDLE handleOfBAPI_MBEWX;

static RFC_TYPE_ELEMENT typeOfBAPI_MBEWX[] = {
  {"VAL_AREA", TYPC, 4, 0},
  {"VAL_TYPE", TYPC, 10, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"PRICE_CTRL", TYPC, 1, 0},
  {"MOVING_PR", TYPC, 1, 0},
  {"STD_PRICE", TYPC, 1, 0},
  {"PRICE_UNIT", TYPC, 1, 0},
  {"VAL_CLASS", TYPC, 1, 0},
  {"PR_CTRL_PP", TYPC, 1, 0},
  {"MOV_PR_PP", TYPC, 1, 0},
  {"STD_PR_PP", TYPC, 1, 0},
  {"PR_UNIT_PP", TYPC, 1, 0},
  {"VCLASS_PP", TYPC, 1, 0},
  {"PR_CTRL_PY", TYPC, 1, 0},
  {"MOV_PR_PY", TYPC, 1, 0},
  {"STD_PR_PY", TYPC, 1, 0},
  {"VCLASS_PY", TYPC, 1, 0},
  {"PR_UNIT_PY", TYPC, 1, 0},
  {"VAL_CAT", TYPC, 1, 0},
  {"FUTURE_PR", TYPC, 1, 0},
  {"VALID_FROM", TYPC, 1, 0},
  {"TAXPRICE_1", TYPC, 1, 0},
  {"COMMPRICE1", TYPC, 1, 0},
  {"TAXPRICE_3", TYPC, 1, 0},
  {"COMMPRICE3", TYPC, 1, 0},
  {"PLND_PRICE", TYPC, 1, 0},
  {"PLNDPRICE1", TYPC, 1, 0},
  {"PLNDPRICE2", TYPC, 1, 0},
  {"PLNDPRICE3", TYPC, 1, 0},
  {"PLNDPRDATE1", TYPC, 1, 0},
  {"PLNDPRDATE2", TYPC, 1, 0},
  {"PLNDPRDATE3", TYPC, 1, 0},
  {"LIFO_FIFO", TYPC, 1, 0},
  {"POOLNUMBER", TYPC, 1, 0},
  {"TAXPRICE_2", TYPC, 1, 0},
  {"COMMPRICE2", TYPC, 1, 0},
  {"DEVAL_IND", TYPC, 1, 0},
  {"ORIG_GROUP", TYPC, 1, 0},
  {"OVERHEAD_GRP", TYPC, 1, 0},
  {"QTY_STRUCT", TYPC, 1, 0},
  {"ML_ACTIVE", TYPC, 1, 0},
  {"ML_SETTLE", TYPC, 1, 0},
  {"ORIG_MAT", TYPC, 1, 0},
  {"VM_SO_STK", TYPC, 1, 0},
  {"VM_P_STOCK", TYPC, 1, 0},
  {"MATL_USAGE", TYPC, 1, 0},
  {"MAT_ORIGIN", TYPC, 1, 0},
  {"IN_HOUSE", TYPC, 1, 0},
  {"TAX_CML_UN", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MLGN
#define SAP_TH_BAPI_MLGN
static RFC_TYPEHANDLE handleOfBAPI_MLGN;

static RFC_TYPE_ELEMENT typeOfBAPI_MLGN[] = {
  {"WHSE_NO", TYPC, 3, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"STGESECTOR", TYPC, 3, 0},
  {"PLACEMENT", TYPC, 3, 0},
  {"WITHDRAWAL", TYPC, 3, 0},
  {"L_EQUIP_1", TYPP, 7, 0},
  {"L_EQUIP_2", TYPP, 7, 0},
  {"L_EQUIP_3", TYPP, 7, 0},
  {"LEQ_UNIT_1", TYPC, 3, 0},
  {"LEQ_UNIT_1_ISO", TYPC, 3, 0},
  {"LEQ_UNIT_2", TYPC, 3, 0},
  {"LEQ_UNIT_2_ISO", TYPC, 3, 0},
  {"LEQ_UNIT_3", TYPC, 3, 0},
  {"LEQ_UNIT_3_ISO", TYPC, 3, 0},
  {"UNITTYPE_1", TYPC, 3, 0},
  {"UNITTYPE_2", TYPC, 3, 0},
  {"UNITTYPE_3", TYPC, 3, 0},
  {"WM_UNIT", TYPC, 3, 0},
  {"WM_UNIT_ISO", TYPC, 3, 0},
  {"ADD_TO_STK", TYPC, 1, 0},
  {"BLOCK_STGE", TYPC, 2, 0},
  {"MSG_TO_IM", TYPC, 1, 0},
  {"SPEC_MVMT", TYPC, 1, 0},
  {"CAPY_USAGE", TYPP, 6, 0},
  {"PROCURE_UN", TYPC, 3, 0},
  {"PROCURE_UN_ISO", TYPC, 3, 0},
  {"STGE_TYPE", TYPC, 3, 0},
  {"REF_UNIT", TYPC, 1, 0},
  {"2STEP_PICK", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MLGNX
#define SAP_TH_BAPI_MLGNX
static RFC_TYPEHANDLE handleOfBAPI_MLGNX;

static RFC_TYPE_ELEMENT typeOfBAPI_MLGNX[] = {
  {"WHSE_NO", TYPC, 3, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"STGESECTOR", TYPC, 1, 0},
  {"PLACEMENT", TYPC, 1, 0},
  {"WITHDRAWAL", TYPC, 1, 0},
  {"L_EQUIP_1", TYPC, 1, 0},
  {"L_EQUIP_2", TYPC, 1, 0},
  {"L_EQUIP_3", TYPC, 1, 0},
  {"LEQ_UNIT_1", TYPC, 1, 0},
  {"LEQ_UNIT_1_ISO", TYPC, 1, 0},
  {"LEQ_UNIT_2", TYPC, 1, 0},
  {"LEQ_UNIT_2_ISO", TYPC, 1, 0},
  {"LEQ_UNIT_3", TYPC, 1, 0},
  {"LEQ_UNIT_3_ISO", TYPC, 1, 0},
  {"UNITTYPE_1", TYPC, 1, 0},
  {"UNITTYPE_2", TYPC, 1, 0},
  {"UNITTYPE_3", TYPC, 1, 0},
  {"WM_UNIT", TYPC, 1, 0},
  {"WM_UNIT_ISO", TYPC, 1, 0},
  {"ADD_TO_STK", TYPC, 1, 0},
  {"BLOCK_STGE", TYPC, 1, 0},
  {"MSG_TO_IM", TYPC, 1, 0},
  {"SPEC_MVMT", TYPC, 1, 0},
  {"CAPY_USAGE", TYPC, 1, 0},
  {"PROCURE_UN", TYPC, 1, 0},
  {"PROCURE_UN_ISO", TYPC, 1, 0},
  {"STGE_TYPE", TYPC, 1, 0},
  {"REF_UNIT", TYPC, 1, 0},
  {"2STEP_PICK", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static RFC_TYPEHANDLE handleOfBAPIRET2;

static RFC_TYPE_ELEMENT typeOfBAPIRET2[] = {
  {"TYPE", TYPC, 1, 0},
  {"ID", TYPC, 20, 0},
  {"NUMBER", TYPNUM, 3, 0},
  {"MESSAGE", TYPC, 220, 0},
  {"LOG_NO", TYPC, 20, 0},
  {"LOG_MSG_NO", TYPNUM, 6, 0},
  {"MESSAGE_V1", TYPC, 50, 0},
  {"MESSAGE_V2", TYPC, 50, 0},
  {"MESSAGE_V3", TYPC, 50, 0},
  {"MESSAGE_V4", TYPC, 50, 0},
  {"PARAMETER", TYPC, 32, 0},
  {"ROW", TYPINT, sizeof(RFC_INT), 0},
  {"FIELD", TYPC, 30, 0},
  {"SYSTEM", TYPC, 10, 0},
 };
#endif

#ifndef SAP_TH_BAPIPAREX
#define SAP_TH_BAPIPAREX
static RFC_TYPEHANDLE handleOfBAPIPAREX;

static RFC_TYPE_ELEMENT typeOfBAPIPAREX[] = {
  {"STRUCTURE", TYPC, 30, 0},
  {"VALUEPART1", TYPC, 240, 0},
  {"VALUEPART2", TYPC, 240, 0},
  {"VALUEPART3", TYPC, 240, 0},
  {"VALUEPART4", TYPC, 240, 0},
 };
#endif

#ifndef SAP_TH_BAPIPAREXX
#define SAP_TH_BAPIPAREXX
static RFC_TYPEHANDLE handleOfBAPIPAREXX;

static RFC_TYPE_ELEMENT typeOfBAPIPAREXX[] = {
  {"STRUCTURE", TYPC, 30, 0},
  {"VALUEPART1", TYPC, 240, 0},
  {"VALUEPART2", TYPC, 240, 0},
  {"VALUEPART3", TYPC, 240, 0},
  {"VALUEPART4", TYPC, 240, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MEAN
#define SAP_TH_BAPI_MEAN
static RFC_TYPEHANDLE handleOfBAPI_MEAN;

static RFC_TYPE_ELEMENT typeOfBAPI_MEAN[] = {
  {"UNIT", TYPC, 3, 0},
  {"UNIT_ISO", TYPC, 3, 0},
  {"EAN_UPC", TYPC, 18, 0},
  {"EAN_CAT", TYPC, 2, 0},
  {"DEL_FLAG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MAKT
#define SAP_TH_BAPI_MAKT
static RFC_TYPEHANDLE handleOfBAPI_MAKT;

static RFC_TYPE_ELEMENT typeOfBAPI_MAKT[] = {
  {"LANGU", TYPC, 1, 0},
  {"LANGU_ISO", TYPC, 2, 0},
  {"MATL_DESC", TYPC, 40, 0},
  {"DEL_FLAG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MLTX
#define SAP_TH_BAPI_MLTX
static RFC_TYPEHANDLE handleOfBAPI_MLTX;

static RFC_TYPE_ELEMENT typeOfBAPI_MLTX[] = {
  {"APPLOBJECT", TYPC, 10, 0},
  {"TEXT_NAME", TYPC, 70, 0},
  {"TEXT_ID", TYPC, 4, 0},
  {"LANGU", TYPC, 1, 0},
  {"LANGU_ISO", TYPC, 2, 0},
  {"FORMAT_COL", TYPC, 2, 0},
  {"TEXT_LINE", TYPC, 132, 0},
  {"DEL_FLAG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MFHM
#define SAP_TH_BAPI_MFHM
static RFC_TYPEHANDLE handleOfBAPI_MFHM;

static RFC_TYPE_ELEMENT typeOfBAPI_MFHM[] = {
  {"PLANT", TYPC, 4, 0},
  {"CREATE_LOAD_RECS", TYPC, 1, 0},
  {"CTRL_KEY", TYPC, 4, 0},
  {"CTRL_KEY_NO_CHG", TYPC, 1, 0},
  {"GRP_KEY_1", TYPC, 4, 0},
  {"GRP_KEY_2", TYPC, 4, 0},
  {"PRT_USAGE", TYPC, 3, 0},
  {"STD_TEXT_KEY", TYPC, 7, 0},
  {"REF_KEY_NO_CHG", TYPC, 1, 0},
  {"START_REF_DATE", TYPC, 2, 0},
  {"ST_REF_DATE_NO_CHG", TYPC, 1, 0},
  {"START_OFFSET", TYPP, 3, 0},
  {"START_OFFSET_UNIT", TYPC, 3, 0},
  {"START_OFFSET_UNIT_ISO", TYPC, 3, 0},
  {"START_OFFSET_NO_CHG", TYPC, 1, 0},
  {"END_REF_DATE", TYPC, 2, 0},
  {"END_REF_DATE_NO_CHG", TYPC, 1, 0},
  {"END_OFFSET", TYPP, 3, 0},
  {"END_OFFSET_UNIT", TYPC, 3, 0},
  {"END_OFFSET_UNIT_ISO", TYPC, 3, 0},
  {"END_OFFSET_NO_CHG", TYPC, 1, 0},
  {"FORMULA_TOT_QTY", TYPC, 6, 0},
  {"FORMULA_TOT_QTY_NO_CHG", TYPC, 1, 0},
  {"FORMULA_TOT_USAGE", TYPC, 6, 0},
  {"FORMULA_TOT_USAGE_NO_CHG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MFHMX
#define SAP_TH_BAPI_MFHMX
static RFC_TYPEHANDLE handleOfBAPI_MFHMX;

static RFC_TYPE_ELEMENT typeOfBAPI_MFHMX[] = {
  {"PLANT", TYPC, 4, 0},
  {"CREATE_LOAD_RECS", TYPC, 1, 0},
  {"CTRL_KEY", TYPC, 1, 0},
  {"CTRL_KEY_NO_CHG", TYPC, 1, 0},
  {"GRP_KEY_1", TYPC, 1, 0},
  {"GRP_KEY_2", TYPC, 1, 0},
  {"PRT_USAGE", TYPC, 1, 0},
  {"STD_TEXT_KEY", TYPC, 1, 0},
  {"REF_KEY_NO_CHG", TYPC, 1, 0},
  {"START_REF_DATE", TYPC, 1, 0},
  {"ST_REF_DATE_NO_CHG", TYPC, 1, 0},
  {"START_OFFSET", TYPC, 1, 0},
  {"START_OFFSET_UNIT", TYPC, 1, 0},
  {"START_OFFSET_UNIT_ISO", TYPC, 1, 0},
  {"START_OFFSET_NO_CHG", TYPC, 1, 0},
  {"END_REF_DATE", TYPC, 1, 0},
  {"END_REF_DATE_NO_CHG", TYPC, 1, 0},
  {"END_OFFSET", TYPC, 1, 0},
  {"END_OFFSET_UNIT", TYPC, 1, 0},
  {"END_OFFSET_UNIT_ISO", TYPC, 1, 0},
  {"END_OFFSET_NO_CHG", TYPC, 1, 0},
  {"FORMULA_TOT_QTY", TYPC, 1, 0},
  {"FORMULA_TOT_QTY_NO_CHG", TYPC, 1, 0},
  {"FORMULA_TOT_USAGE", TYPC, 1, 0},
  {"FORMULA_TOT_USAGE_NO_CHG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MATRETURN2
#define SAP_TH_BAPI_MATRETURN2
//static RFC_TYPEHANDLE handleOfBAPI_MATRETURN2;

static RFC_TYPE_ELEMENT typeOfBAPI_MATRETURN2[] = {
  {"TYPE", TYPC, 1, 0},
  {"ID", TYPC, 20, 0},
  {"NUMBER", TYPNUM, 3, 0},
  {"MESSAGE", TYPC, 220, 0},
  {"LOG_NO", TYPC, 20, 0},
  {"LOG_MSG_NO", TYPNUM, 6, 0},
  {"MESSAGE_V1", TYPC, 50, 0},
  {"MESSAGE_V2", TYPC, 50, 0},
  {"MESSAGE_V3", TYPC, 50, 0},
  {"MESSAGE_V4", TYPC, 50, 0},
  {"PARAMETER", TYPC, 32, 0},
  {"ROW", TYPINT, sizeof(RFC_INT), 0},
  {"FIELD", TYPC, 30, 0},
  {"SYSTEM", TYPC, 10, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MLAN
#define SAP_TH_BAPI_MLAN
static RFC_TYPEHANDLE handleOfBAPI_MLAN;

static RFC_TYPE_ELEMENT typeOfBAPI_MLAN[] = {
  {"DEPCOUNTRY", TYPC, 3, 0},
  {"DEPCOUNTRY_ISO", TYPC, 2, 0},
  {"TAX_TYPE_1", TYPC, 4, 0},
  {"TAXCLASS_1", TYPC, 1, 0},
  {"TAX_TYPE_2", TYPC, 4, 0},
  {"TAXCLASS_2", TYPC, 1, 0},
  {"TAX_TYPE_3", TYPC, 4, 0},
  {"TAXCLASS_3", TYPC, 1, 0},
  {"TAX_TYPE_4", TYPC, 4, 0},
  {"TAXCLASS_4", TYPC, 1, 0},
  {"TAX_TYPE_5", TYPC, 4, 0},
  {"TAXCLASS_5", TYPC, 1, 0},
  {"TAX_TYPE_6", TYPC, 4, 0},
  {"TAXCLASS_6", TYPC, 1, 0},
  {"TAX_TYPE_7", TYPC, 4, 0},
  {"TAXCLASS_7", TYPC, 1, 0},
  {"TAX_TYPE_8", TYPC, 4, 0},
  {"TAXCLASS_8", TYPC, 1, 0},
  {"TAX_TYPE_9", TYPC, 4, 0},
  {"TAXCLASS_9", TYPC, 1, 0},
  {"TAX_IND", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MARM
#define SAP_TH_BAPI_MARM
static RFC_TYPEHANDLE handleOfBAPI_MARM;

static RFC_TYPE_ELEMENT typeOfBAPI_MARM[] = {
  {"ALT_UNIT", TYPC, 3, 0},
  {"ALT_UNIT_ISO", TYPC, 3, 0},
  {"NUMERATOR", TYPP, 3, 0},
  {"DENOMINATR", TYPP, 3, 0},
  {"EAN_UPC", TYPC, 18, 0},
  {"EAN_CAT", TYPC, 2, 0},
  {"LENGTH", TYPP, 7, 0},
  {"WIDTH", TYPP, 7, 0},
  {"HEIGHT", TYPP, 7, 0},
  {"UNIT_DIM", TYPC, 3, 0},
  {"UNIT_DIM_ISO", TYPC, 3, 0},
  {"VOLUME", TYPP, 7, 0},
  {"VOLUMEUNIT", TYPC, 3, 0},
  {"VOLUMEUNIT_ISO", TYPC, 3, 0},
  {"GROSS_WT", TYPP, 7, 0},
  {"UNIT_OF_WT", TYPC, 3, 0},
  {"UNIT_OF_WT_ISO", TYPC, 3, 0},
  {"DEL_FLAG", TYPC, 1, 0},
  {"SUB_UOM", TYPC, 3, 0},
  {"SUB_UOM_ISO", TYPC, 3, 0},
 };
#endif

#ifndef SAP_TH_BAPI_MARMX
#define SAP_TH_BAPI_MARMX
static RFC_TYPEHANDLE handleOfBAPI_MARMX;

static RFC_TYPE_ELEMENT typeOfBAPI_MARMX[] = {
  {"ALT_UNIT", TYPC, 3, 0},
  {"ALT_UNIT_ISO", TYPC, 3, 0},
  {"NUMERATOR", TYPC, 1, 0},
  {"DENOMINATR", TYPC, 1, 0},
  {"EAN_UPC", TYPC, 1, 0},
  {"EAN_CAT", TYPC, 1, 0},
  {"LENGTH", TYPC, 1, 0},
  {"WIDTH", TYPC, 1, 0},
  {"HEIGHT", TYPC, 1, 0},
  {"UNIT_DIM", TYPC, 1, 0},
  {"UNIT_DIM_ISO", TYPC, 1, 0},
  {"VOLUME", TYPC, 1, 0},
  {"VOLUMEUNIT", TYPC, 1, 0},
  {"VOLUMEUNIT_ISO", TYPC, 1, 0},
  {"GROSS_WT", TYPC, 1, 0},
  {"UNIT_OF_WT", TYPC, 1, 0},
  {"UNIT_OF_WT_ISO", TYPC, 1, 0},
  {"SUB_UOM", TYPC, 1, 0},
  {"SUB_UOM_ISO", TYPC, 1, 0},
 };
#endif

/* entries */



/*
------------------------------------------------------------------------

  Call function BAPI_MATERIAL_GET_DETAIL
      exporting
        MATERIAL like BAPIMATDET_MATERIAL  type RFC_CHAR length 18
        PLANT like BAPIMATALL_PLANT  type RFC_CHAR length 4
        VALUATIONAREA like BAPIMATALL_VAL_AREA  type RFC_CHAR length 4
        VALUATIONTYPE like BAPIMATALL_VAL_TYPE  type RFC_CHAR length 10
      importing
        MATERIALPLANTDATA structure BAPIMATDOC length
6 number of fields 2
        MATERIALVALUATIONDATA structure BAPIMATDOBEW length 36 number of fields 6
        MATERIAL_GENERAL_DATA structure BAPIMATDOA length 414 number of fields 41
        RETURN structure BAPIRETURN length 452 number of fields 9
      tables
      exceptions

------------------------------------------------------------------------
*/


#ifndef SAP_FT_BAPIMATDET_MATERIAL
#define SAP_FT_BAPIMATDET_MATERIAL
typedef RFC_CHAR BAPIMATDET_MATERIAL[18];
#endif

#ifndef SAP_FT_BAPIMATALL_PLANT
#define SAP_FT_BAPIMATALL_PLANT
typedef RFC_CHAR BAPIMATALL_PLANT[4];
#endif

#ifndef SAP_FT_BAPIMATALL_VAL_AREA
#define SAP_FT_BAPIMATALL_VAL_AREA
typedef RFC_CHAR BAPIMATALL_VAL_AREA[4];
#endif

#ifndef SAP_FT_BAPIMATALL_VAL_TYPE
#define SAP_FT_BAPIMATALL_VAL_TYPE
typedef RFC_CHAR BAPIMATALL_VAL_TYPE[10];
#endif

/* structure type definition */

#ifndef SAP_ST_BAPIMATDOC
#define SAP_ST_BAPIMATDOC
typedef struct {
  RFC_CHAR PurGroup[3];
  RFC_CHAR IssueUnit[3];
 } BAPIMATDOC;
#endif

#ifndef SAP_ST_BAPIMATDOBEW
#define SAP_ST_BAPIMATDOBEW
typedef struct {
  RFC_CHAR PriceCtrl[1];
  RFC_BCD MovingPr[12];
  RFC_BCD StdPrice[12];
  RFC_BCD PriceUnit[3];
  RFC_CHAR Currency[5];
  RFC_CHAR CurrencyIso[3];
 } BAPIMATDOBEW;
#endif

#ifndef SAP_ST_BAPIMATDOA
#define SAP_ST_BAPIMATDOA
typedef struct {
  RFC_CHAR MatlDesc[40];
  RFC_CHAR OldMatNo[18];
  RFC_CHAR MatlType[4];
  RFC_CHAR IndSector[1];
  RFC_CHAR Division[2];
  RFC_CHAR MatlGroup[9];
  RFC_CHAR ProdHier[18];
  RFC_CHAR BasicMatl[14];
  RFC_CHAR StdDescr[18];
  RFC_CHAR LabDesign[3];
  RFC_CHAR ProdMemo[18];
  RFC_CHAR Pageformat[4];
  RFC_CHAR Container[2];
  RFC_CHAR StorConds[2];
  RFC_CHAR TempConds[2];
  RFC_CHAR BaseUom[3];
  RFC_CHAR EanUpc[18];
  RFC_CHAR EanCat[2];
  RFC_CHAR SizeDim[32];
  RFC_BCD GrossWt[7];
  RFC_BCD NetWeight[7];
  RFC_CHAR UnitOfWt[3];
  RFC_BCD Volume[7];
  RFC_CHAR Volumeunit[3];
  RFC_BCD Length[7];
  RFC_BCD Width[7];
  RFC_BCD Height[7];
  RFC_CHAR UnitDim[3];
  RFC_CHAR ManuMat[40];
  RFC_CHAR MfrNo[10];
  RFC_CHAR BaseUomIso[3];
  RFC_CHAR UnitOfWtIso[3];
  RFC_CHAR VolumeunitIso[3];
  RFC_CHAR UnitDimIso[3];
  RFC_DATE CreatedOn;
  RFC_CHAR CreatedBy[12];
  RFC_DATE LastChnge;
  RFC_CHAR ChangedBy[12];
  RFC_CHAR MatlCat[2];
  RFC_CHAR Emptiesbom[1];
  RFC_CHAR BasicMatlNew[48];
 } BAPIMATDOA;
#endif

#ifndef SAP_ST_BAPIRETURN
#define SAP_ST_BAPIRETURN
typedef struct {
  RFC_CHAR Type[1];
  RFC_CHAR Code[5];
  RFC_CHAR Message[220];
  RFC_CHAR LogNo[20];
  RFC_NUM LogMsgNo[6];
  RFC_CHAR MessageV1[50];
  RFC_CHAR MessageV2[50];
  RFC_CHAR MessageV3[50];
  RFC_CHAR MessageV4[50];
 } BAPIRETURN;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_BAPIMATDOC
#define SAP_TH_BAPIMATDOC
static RFC_TYPEHANDLE handleOfBAPIMATDOC;

static RFC_TYPE_ELEMENT typeOfBAPIMATDOC[] = {
  {"PUR_GROUP", TYPC, 3, 0},
  {"ISSUE_UNIT", TYPC, 3, 0},
 };
#endif

#ifndef SAP_TH_BAPIMATDOBEW
#define SAP_TH_BAPIMATDOBEW
static RFC_TYPEHANDLE handleOfBAPIMATDOBEW;

static RFC_TYPE_ELEMENT typeOfBAPIMATDOBEW[] = {
  {"PRICE_CTRL", TYPC, 1, 0},
  {"MOVING_PR", TYPP, 12, 0},
  {"STD_PRICE", TYPP, 12, 0},
  {"PRICE_UNIT", TYPP, 3, 0},
  {"CURRENCY", TYPC, 5, 0},
  {"CURRENCY_ISO", TYPC, 3, 0},
 };
#endif

#ifndef SAP_TH_BAPIMATDOA
#define SAP_TH_BAPIMATDOA
static RFC_TYPEHANDLE handleOfBAPIMATDOA;

static RFC_TYPE_ELEMENT typeOfBAPIMATDOA[] = {
  {"MATL_DESC", TYPC, 40, 0},
  {"OLD_MAT_NO", TYPC, 18, 0},
  {"MATL_TYPE", TYPC, 4, 0},
  {"IND_SECTOR", TYPC, 1, 0},
  {"DIVISION", TYPC, 2, 0},
  {"MATL_GROUP", TYPC, 9, 0},
  {"PROD_HIER", TYPC, 18, 0},
  {"BASIC_MATL", TYPC, 14, 0},
  {"STD_DESCR", TYPC, 18, 0},
  {"LAB_DESIGN", TYPC, 3, 0},
  {"PROD_MEMO", TYPC, 18, 0},
  {"PAGEFORMAT", TYPC, 4, 0},
  {"CONTAINER", TYPC, 2, 0},
  {"STOR_CONDS", TYPC, 2, 0},
  {"TEMP_CONDS", TYPC, 2, 0},
  {"BASE_UOM", TYPC, 3, 0},
  {"EAN_UPC", TYPC, 18, 0},
  {"EAN_CAT", TYPC, 2, 0},
  {"SIZE_DIM", TYPC, 32, 0},
  {"GROSS_WT", TYPP, 7, 0},
  {"NET_WEIGHT", TYPP, 7, 0},
  {"UNIT_OF_WT", TYPC, 3, 0},
  {"VOLUME", TYPP, 7, 0},
  {"VOLUMEUNIT", TYPC, 3, 0},
  {"LENGTH", TYPP, 7, 0},
  {"WIDTH", TYPP, 7, 0},
  {"HEIGHT", TYPP, 7, 0},
  {"UNIT_DIM", TYPC, 3, 0},
  {"MANU_MAT", TYPC, 40, 0},
  {"MFR_NO", TYPC, 10, 0},
  {"BASE_UOM_ISO", TYPC, 3, 0},
  {"UNIT_OF_WT_ISO", TYPC, 3, 0},
  {"VOLUMEUNIT_ISO", TYPC, 3, 0},
  {"UNIT_DIM_ISO", TYPC, 3, 0},
  {"CREATED_ON", TYPDATE, sizeof(RFC_DATE), 0},
  {"CREATED_BY", TYPC, 12, 0},
  {"LAST_CHNGE", TYPDATE, sizeof(RFC_DATE), 0},
  {"CHANGED_BY", TYPC, 12, 0},
  {"MATL_CAT", TYPC, 2, 0},
  {"EMPTIESBOM", TYPC, 1, 0},
  {"BASIC_MATL_NEW", TYPC, 48, 0},
 };
#endif

#ifndef SAP_TH_BAPIRETURN
#define SAP_TH_BAPIRETURN
static RFC_TYPEHANDLE handleOfBAPIRETURN;

static RFC_TYPE_ELEMENT typeOfBAPIRETURN[] = {
  {"TYPE", TYPC, 1, 0},
  {"CODE", TYPC, 5, 0},
  {"MESSAGE", TYPC, 220, 0},
  {"LOG_NO", TYPC, 20, 0},
  {"LOG_MSG_NO", TYPNUM, 6, 0},
  {"MESSAGE_V1", TYPC, 50, 0},
  {"MESSAGE_V2", TYPC, 50, 0},
  {"MESSAGE_V3", TYPC, 50, 0},
  {"MESSAGE_V4", TYPC, 50, 0},
 };
#endif

/* entries */




/*
------------------------------------------------------------------------

  Call function CCAP_REV_LEVEL_MAINTAIN
      exporting
        CHANGE_NO like CCAPI_CHANGE_NO  type RFC_CHAR length 12
        DOCUMENT_NUMBER like CCAPI_DOC_NUMBER  type RFC_CHAR length 25
        DOCUMENT_PART like CCAPI_DOC_PART  type RFC_CHAR length 3
        DOCUMENT_TYPE like CCAPI_DOC_TYPE  type RFC_CHAR length 3
        DOCUMENT_VERSION like CCAPI_DOC_VERS  type RFC_CHAR length 2
        FLG_ALE like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_COMMIT_AND_WAIT like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_NO_COMMIT_WORK like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        MATERIAL like CCAPI_MATERIAL  type RFC_CHAR length 18
        REV_LEVEL_NEW like CCAPI_REV_LEVEL  type RFC_CHAR length 2
      importing
      tables
      exceptions
        CHANGE_NO_NOT_EXISTS
        ERROR
        REVISION_LEVEL_EXISTS

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_CCAPI_CHANGE_NO
#define SAP_FT_CCAPI_CHANGE_NO
typedef RFC_CHAR CCAPI_CHANGE_NO[12];
#endif

#ifndef SAP_FT_CCAPI_DOC_NUMBER
#define SAP_FT_CCAPI_DOC_NUMBER
typedef RFC_CHAR CCAPI_DOC_NUMBER[25];
#endif

#ifndef SAP_FT_CCAPI_DOC_PART
#define SAP_FT_CCAPI_DOC_PART
typedef RFC_CHAR CCAPI_DOC_PART[3];
#endif

#ifndef SAP_FT_CCAPI_DOC_TYPE
#define SAP_FT_CCAPI_DOC_TYPE
typedef RFC_CHAR CCAPI_DOC_TYPE[3];
#endif

#ifndef SAP_FT_CCAPI_DOC_VERS
#define SAP_FT_CCAPI_DOC_VERS
typedef RFC_CHAR CCAPI_DOC_VERS[2];
#endif

#ifndef SAP_FT_CSDATA_XFELD
#define SAP_FT_CSDATA_XFELD
typedef RFC_CHAR CSDATA_XFELD[1];
#endif

#ifndef SAP_FT_CCAPI_MATERIAL
#define SAP_FT_CCAPI_MATERIAL
typedef RFC_CHAR CCAPI_MATERIAL[18];
#endif

#ifndef SAP_FT_CCAPI_REV_LEVEL
#define SAP_FT_CCAPI_REV_LEVEL
typedef RFC_CHAR CCAPI_REV_LEVEL[2];
#endif



/*
------------------------------------------------------------------------

  Call function CCAP_ECN_CREATE
      exporting
        CHANGE_HEADER structure AENR_API01 length 167 number of fields 18
        FL_ALE like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_COMMIT_AND_WAIT like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_NO_COMMIT_WORK like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        OBJECT_BOM structure AENV_API01 length
6 number of fields 6
        OBJECT_BOM_CUS structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_DOC structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_EQUI structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_LOC structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_MAT structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_PSP structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_STD structure AENV_API01 length 6 number of fields 6
        OBJECT_CHAR structure AENV_API01 length 6 number of fields 6
        OBJECT_CLS structure AENV_API01 length 6 number of fields 6
        OBJECT_CLS_MAINT structure AENV_API01 length 6 number of fields 6
        OBJECT_CONF_PROF structure AENV_API01 length 6 number of fields 6
        OBJECT_DEP structure AENV_API01 length 6 number of fields 6
        OBJECT_DOC structure AENV_API01 length 6 number of fields 6
        OBJECT_HAZMAT structure AENV_API01 length 6 number of fields 6
        OBJECT_MAT structure AENV_API01 length 6 number of fields 6
        OBJECT_PHRASE structure AENV_API01 length 6 number of fields 6
        OBJECT_PVS structure AENV_API01 length 6 number of fields 6
        OBJECT_PVS_ALT structure AENV_API01 length 6 number of fields 6
        OBJECT_PVS_REL structure AENV_API01 length 6 number of fields 6
        OBJECT_PVS_VAR structure AENV_API01 length 6 number of fields 6
        OBJECT_SUBSTANCE structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_2 structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_A structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_E structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_M structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_N structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_Q structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_R structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_S structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_T structure AENV_API01 length 6 number of fields 6
        OBJECT_VALID_MATVERS structure AENV_API01 length 6 number of fields 6
        OBJECT_VAR_TAB structure AENV_API01 length 6 number of fields 6
        VALUE_ASSIGN structure AEEF_API01 length 132 number of fields 12
      importing
        CHANGE_NO like AENRB_AENNR type RFC_CHAR length 12
      tables
        ALT_DATES structure AEDT_API01 length 29
number of fields 3
        EFFECTIVITY structure AEEF_API01 length 132 number of fields 12
        OBJMGREC structure AEOI_API01 length 338 number of fields 30
        TEXTHEADER structure CCTHEAD length 83 number of fields 4
        TEXTLINES structure CCTLINE length 142 number of fields 3
      exceptions
        CHANGE_NO_ALREADY_EXISTS
        ERROR

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_CSDATA_XFELD
#define SAP_FT_CSDATA_XFELD
typedef RFC_CHAR CSDATA_XFELD[1];
#endif

#ifndef SAP_FT_AENRB_AENNR
#define SAP_FT_AENRB_AENNR
typedef RFC_CHAR AENRB_AENNR[12];
#endif

/* structure type definition */

#ifndef SAP_ST_AENR_API01
#define SAP_ST_AENR_API01
typedef struct {
  RFC_CHAR ChangeNo[12];
  RFC_NUM Status[2];
  RFC_CHAR AuthGroup[4];
  RFC_CHAR ValidFrom[10];
  RFC_CHAR Descript[40];
  RFC_CHAR ReasonChg[40];
  RFC_CHAR DeletionMark[1];
  RFC_CHAR IndateRule[10];
  RFC_CHAR OutdateRule[10];
  RFC_CHAR Function[1];
  RFC_CHAR ChangeLeader[12];
  RFC_CHAR EffectivityType[10];
  RFC_CHAR OverridingMark[1];
  RFC_NUM Rank[2];
  RFC_NUM ReleaseKey[2];
  RFC_CHAR StatusProfile[8];
  RFC_CHAR TechRel[1];
  RFC_CHAR BasicChange[1];
 } AENR_API01;
#endif

#ifndef SAP_ST_AENV_API01
#define SAP_ST_AENV_API01
typedef struct {
  RFC_CHAR Active[1];
  RFC_CHAR Locked[1];
  RFC_CHAR ObjRequ[1];
  RFC_CHAR MgtrecGen[1];
  RFC_CHAR GenNew[1];
  RFC_CHAR GenDialog[1];
 } AENV_API01;
#endif

#ifndef SAP_ST_AEEF_API01
#define SAP_ST_AEEF_API01
typedef struct {
  RFC_CHAR ValidFrom[10];
  RFC_CHAR ValidTo[10];
  RFC_CHAR DateMark[1];
  RFC_CHAR Material[18];
  RFC_CHAR SerialnrLow[18];
  RFC_CHAR SerialnrHigh[18];
  RFC_CHAR Class[18];
  RFC_CHAR Classty[3];
  RFC_CHAR Startup[30];
  RFC_CHAR Plant[4];
  RFC_CHAR SernrOi[1];
  RFC_CHAR FlDelete[1];
 } AEEF_API01;
#endif

#ifndef SAP_ST_AEDT_API01
#define SAP_ST_AEDT_API01
typedef struct {
  RFC_CHAR AltDate[18];
  RFC_CHAR ValidFrom[10];
  RFC_CHAR FlDelete[1];
 } AEDT_API01;
#endif

#ifndef SAP_ST_AEOI_API01
#define SAP_ST_AEOI_API01
typedef struct {
  RFC_CHAR AltDate[18];
  RFC_NUM ChgObjtyp[1];
  RFC_CHAR BomCat[1];
  RFC_CHAR BomStdObject[18];
  RFC_CHAR BomUsage[1];
  RFC_NUM Chgtypeobj[3];
  RFC_CHAR DescrObj[40];
  RFC_CHAR DocType[3];
  RFC_CHAR DocNumber[25];
  RFC_CHAR DocVers[2];
  RFC_CHAR DocPart[3];
  RFC_CHAR Equipment[18];
  RFC_CHAR FuncLoc[30];
  RFC_CHAR Material[18];
  RFC_CHAR Plant[4];
  RFC_CHAR PspElement[24];
  RFC_BYTE PvsGuid[16];
  RFC_CHAR PvsType[1];
  RFC_CHAR PvsNode[40];
  RFC_CHAR PvsClassNumber[18];
  RFC_CHAR PvsClassType[3];
  RFC_CHAR PvsVariant[8];
  RFC_CHAR SdOrder[10];
  RFC_NUM SdOrderI[6];
  RFC_NUM Textkey[8];
  RFC_CHAR TlistType[1];
  RFC_CHAR TlistGrp[8];
  RFC_CHAR ObjChglock[1];
  RFC_CHAR StatusProfObj[8];
  RFC_CHAR FlDelete[1];
 } AEOI_API01;
#endif

#ifndef SAP_ST_CCTHEAD
#define SAP_ST_CCTHEAD
typedef struct {
  RFC_NUM Textkey[8];
  RFC_CHAR Tdname[70];
  RFC_CHAR Tdid[4];
  RFC_CHAR Tdspras[1];
 } CCTHEAD;
#endif

#ifndef SAP_ST_CCTLINE
#define SAP_ST_CCTLINE
typedef struct {
  RFC_NUM Textkey[8];
  RFC_CHAR Tdformat[2];
  RFC_CHAR Tdline[132];
 } CCTLINE;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_AENR_API01
#define SAP_TH_AENR_API01
static RFC_TYPEHANDLE handleOfAENR_API01;

static RFC_TYPE_ELEMENT typeOfAENR_API01[] = {
  {"CHANGE_NO", TYPC, 12, 0},
  {"STATUS", TYPNUM, 2, 0},
  {"AUTH_GROUP", TYPC, 4, 0},
  {"VALID_FROM", TYPC, 10, 0},
  {"DESCRIPT", TYPC, 40, 0},
  {"REASON_CHG", TYPC, 40, 0},
  {"DELETION_MARK", TYPC, 1, 0},
  {"INDATE_RULE", TYPC, 10, 0},
  {"OUTDATE_RULE", TYPC, 10, 0},
  {"FUNCTION", TYPC, 1, 0},
  {"CHANGE_LEADER", TYPC, 12, 0},
  {"EFFECTIVITY_TYPE", TYPC, 10, 0},
  {"OVERRIDING_MARK", TYPC, 1, 0},
  {"RANK", TYPNUM, 2, 0},
  {"RELEASE_KEY", TYPNUM, 2, 0},
  {"STATUS_PROFILE", TYPC, 8, 0},
  {"TECH_REL", TYPC, 1, 0},
  {"BASIC_CHANGE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_AENV_API01
#define SAP_TH_AENV_API01
static RFC_TYPEHANDLE handleOfAENV_API01;

static RFC_TYPE_ELEMENT typeOfAENV_API01[] = {
  {"ACTIVE", TYPC, 1, 0},
  {"LOCKED", TYPC, 1, 0},
  {"OBJ_REQU", TYPC, 1, 0},
  {"MGTREC_GEN", TYPC, 1, 0},
  {"GEN_NEW", TYPC, 1, 0},
  {"GEN_DIALOG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_AEEF_API01
#define SAP_TH_AEEF_API01
static RFC_TYPEHANDLE handleOfAEEF_API01;

static RFC_TYPE_ELEMENT typeOfAEEF_API01[] = {
  {"VALID_FROM", TYPC, 10, 0},
  {"VALID_TO", TYPC, 10, 0},
  {"DATE_MARK", TYPC, 1, 0},
  {"MATERIAL", TYPC, 18, 0},
  {"SERIALNR_LOW", TYPC, 18, 0},
  {"SERIALNR_HIGH", TYPC, 18, 0},
  {"CLASS", TYPC, 18, 0},
  {"CLASSTY", TYPC, 3, 0},
  {"STARTUP", TYPC, 30, 0},
  {"PLANT", TYPC, 4, 0},
  {"SERNR_OI", TYPC, 1, 0},
  {"FL_DELETE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_AEDT_API01
#define SAP_TH_AEDT_API01
static RFC_TYPEHANDLE handleOfAEDT_API01;

static RFC_TYPE_ELEMENT typeOfAEDT_API01[] = {
  {"ALT_DATE", TYPC, 18, 0},
  {"VALID_FROM", TYPC, 10, 0},
  {"FL_DELETE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_AEOI_API01
#define SAP_TH_AEOI_API01
static RFC_TYPEHANDLE handleOfAEOI_API01;

static RFC_TYPE_ELEMENT typeOfAEOI_API01[] = {
  {"ALT_DATE", TYPC, 18, 0},
  {"CHG_OBJTYP", TYPNUM, 1, 0},
  {"BOM_CAT", TYPC, 1, 0},
  {"BOM_STD_OBJECT", TYPC, 18, 0},
  {"BOM_USAGE", TYPC, 1, 0},
  {"CHGTYPEOBJ", TYPNUM, 3, 0},
  {"DESCR_OBJ", TYPC, 40, 0},
  {"DOC_TYPE", TYPC, 3, 0},
  {"DOC_NUMBER", TYPC, 25, 0},
  {"DOC_VERS", TYPC, 2, 0},
  {"DOC_PART", TYPC, 3, 0},
  {"EQUIPMENT", TYPC, 18, 0},
  {"FUNC_LOC", TYPC, 30, 0},
  {"MATERIAL", TYPC, 18, 0},
  {"PLANT", TYPC, 4, 0},
  {"PSP_ELEMENT", TYPC, 24, 0},
  {"PVS_GUID", TYPX, 16, 0},
  {"PVS_TYPE", TYPC, 1, 0},
  {"PVS_NODE", TYPC, 40, 0},
  {"PVS_CLASS_NUMBER", TYPC, 18, 0},
  {"PVS_CLASS_TYPE", TYPC, 3, 0},
  {"PVS_VARIANT", TYPC, 8, 0},
  {"SD_ORDER", TYPC, 10, 0},
  {"SD_ORDER_I", TYPNUM, 6, 0},
  {"TEXTKEY", TYPNUM, 8, 0},
  {"TLIST_TYPE", TYPC, 1, 0},
  {"TLIST_GRP", TYPC, 8, 0},
  {"OBJ_CHGLOCK", TYPC, 1, 0},
  {"STATUS_PROF_OBJ", TYPC, 8, 0},
  {"FL_DELETE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_CCTHEAD
#define SAP_TH_CCTHEAD
static RFC_TYPEHANDLE handleOfCCTHEAD;

static RFC_TYPE_ELEMENT typeOfCCTHEAD[] = {
  {"TEXTKEY", TYPNUM, 8, 0},
  {"TDNAME", TYPC, 70, 0},
  {"TDID", TYPC, 4, 0},
  {"TDSPRAS", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_CCTLINE
#define SAP_TH_CCTLINE
static RFC_TYPEHANDLE handleOfCCTLINE;

static RFC_TYPE_ELEMENT typeOfCCTLINE[] = {
  {"TEXTKEY", TYPNUM, 8, 0},
  {"TDFORMAT", TYPC, 2, 0},
  {"TDLINE", TYPC, 132, 0},
 };
#endif

/* entries */



/*
------------------------------------------------------------------------

  Call function CCAP_ECN_MAINTAIN
      exporting
        CHANGE_HEADER structure AENR_API01 length 167 number of fields 18
        CHANGE_HEADER_CUS structure CCCI_AENR length 1 number of fields 1
        FL_ALE like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_CIF like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_COLLEC_INUPD_TASK like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_COMMIT_AND_WAIT like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_NO_COMMIT_WORK like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_SYNCH like CSDATA_XFELD default 'X' type RFC_CHAR length 1
        OBJECT_BOM structure AENV_API01 length
6 number of fields 6
        OBJECT_BOM_CUS structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_DOC structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_EQUI structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_LOC structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_MAT structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_PSP structure AENV_API01 length 6 number of fields 6
        OBJECT_BOM_STD structure AENV_API01 length 6 number of fields 6
        OBJECT_CHAR structure AENV_API01 length 6 number of fields 6
        OBJECT_CLS structure AENV_API01 length 6 number of fields 6
        OBJECT_CLS_MAINT structure AENV_API01 length 6 number of fields 6
        OBJECT_CONF_PROF structure AENV_API01 length 6 number of fields 6
        OBJECT_DEP structure AENV_API01 length 6 number of fields 6
        OBJECT_DOC structure AENV_API01 length 6 number of fields 6
        OBJECT_HAZMAT structure AENV_API01 length 6 number of fields 6
        OBJECT_MAT structure AENV_API01 length 6 number of fields 6
        OBJECT_PHRASE structure AENV_API01 length 6 number of fields 6
        OBJECT_PVS structure AENV_API01 length 6 number of fields 6
        OBJECT_PVS_ALT structure AENV_API01 length 6 number of fields 6
        OBJECT_PVS_REL structure AENV_API01 length 6 number of fields 6
        OBJECT_PVS_VAR structure AENV_API01 length 6 number of fields 6
        OBJECT_SUBSTANCE structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_2 structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_A structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_E structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_M structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_N structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_Q structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_R structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_S structure AENV_API01 length 6 number of fields 6
        OBJECT_TLIST_T structure AENV_API01 length 6 number of fields 6
        OBJECT_VALID_MATVERS structure AENV_API01 length 6 number of fields 6
        OBJECT_VAR_TAB structure AENV_API01 length 6 number of fields 6
        VALUE_ASSIGN structure AEEF_API01 length 132 number of fields 12
      importing
        CHANGE_NO like AENRB_AENNR type RFC_CHAR length 12
      tables
        ALT_DATES structure AEDT_API01 length 29
number of fields 3
        EFFECTIVITY structure AEEF_API01 length 132 number of fields 12
        LIST_OF_ECNS structure AENR_API01 length 167 number of fields 18
        OBJMGREC structure AEOI_API01 length 338 number of fields 30
        TEXTHEADER structure CCTHEAD length 83 number of fields 4
        TEXTLINES structure CCTLINE length 142 number of fields 3
      exceptions
        ERROR

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_CSDATA_XFELD
#define SAP_FT_CSDATA_XFELD
typedef RFC_CHAR CSDATA_XFELD[1];
#endif

#ifndef SAP_FT_AENRB_AENNR
#define SAP_FT_AENRB_AENNR
typedef RFC_CHAR AENRB_AENNR[12];
#endif

/* structure type definition */

#ifndef SAP_ST_AENR_API01
#define SAP_ST_AENR_API01
typedef struct {
  RFC_CHAR ChangeNo[12];
  RFC_NUM Status[2];
  RFC_CHAR AuthGroup[4];
  RFC_CHAR ValidFrom[10];
  RFC_CHAR Descript[40];
  RFC_CHAR ReasonChg[40];
  RFC_CHAR DeletionMark[1];
  RFC_CHAR IndateRule[10];
  RFC_CHAR OutdateRule[10];
  RFC_CHAR Function[1];
  RFC_CHAR ChangeLeader[12];
  RFC_CHAR EffectivityType[10];
  RFC_CHAR OverridingMark[1];
  RFC_NUM Rank[2];
  RFC_NUM ReleaseKey[2];
  RFC_CHAR StatusProfile[8];
  RFC_CHAR TechRel[1];
  RFC_CHAR BasicChange[1];
 } AENR_API01;
#endif

#ifndef SAP_ST_CCCI_AENR
#define SAP_ST_CCCI_AENR
typedef struct {
  RFC_CHAR Xflag[1];
 } CCCI_AENR;
#endif

#ifndef SAP_ST_AENV_API01
#define SAP_ST_AENV_API01
typedef struct {
  RFC_CHAR Active[1];
  RFC_CHAR Locked[1];
  RFC_CHAR ObjRequ[1];
  RFC_CHAR MgtrecGen[1];
  RFC_CHAR GenNew[1];
  RFC_CHAR GenDialog[1];
 } AENV_API01;
#endif

#ifndef SAP_ST_AEEF_API01
#define SAP_ST_AEEF_API01
typedef struct {
  RFC_CHAR ValidFrom[10];
  RFC_CHAR ValidTo[10];
  RFC_CHAR DateMark[1];
  RFC_CHAR Material[18];
  RFC_CHAR SerialnrLow[18];
  RFC_CHAR SerialnrHigh[18];
  RFC_CHAR Class[18];
  RFC_CHAR Classty[3];
  RFC_CHAR Startup[30];
  RFC_CHAR Plant[4];
  RFC_CHAR SernrOi[1];
  RFC_CHAR FlDelete[1];
 } AEEF_API01;
#endif

#ifndef SAP_ST_AEDT_API01
#define SAP_ST_AEDT_API01
typedef struct {
  RFC_CHAR AltDate[18];
  RFC_CHAR ValidFrom[10];
  RFC_CHAR FlDelete[1];
 } AEDT_API01;
#endif

#ifndef SAP_ST_AEOI_API01
#define SAP_ST_AEOI_API01
typedef struct {
  RFC_CHAR AltDate[18];
  RFC_NUM ChgObjtyp[1];
  RFC_CHAR BomCat[1];
  RFC_CHAR BomStdObject[18];
  RFC_CHAR BomUsage[1];
  RFC_NUM Chgtypeobj[3];
  RFC_CHAR DescrObj[40];
  RFC_CHAR DocType[3];
  RFC_CHAR DocNumber[25];
  RFC_CHAR DocVers[2];
  RFC_CHAR DocPart[3];
  RFC_CHAR Equipment[18];
  RFC_CHAR FuncLoc[30];
  RFC_CHAR Material[18];
  RFC_CHAR Plant[4];
  RFC_CHAR PspElement[24];
  RFC_BYTE PvsGuid[16];
  RFC_CHAR PvsType[1];
  RFC_CHAR PvsNode[40];
  RFC_CHAR PvsClassNumber[18];
  RFC_CHAR PvsClassType[3];
  RFC_CHAR PvsVariant[8];
  RFC_CHAR SdOrder[10];
  RFC_NUM SdOrderI[6];
  RFC_NUM Textkey[8];
  RFC_CHAR TlistType[1];
  RFC_CHAR TlistGrp[8];
  RFC_CHAR ObjChglock[1];
  RFC_CHAR StatusProfObj[8];
  RFC_CHAR FlDelete[1];
 } AEOI_API01;
#endif

#ifndef SAP_ST_CCTHEAD
#define SAP_ST_CCTHEAD
typedef struct {
  RFC_NUM Textkey[8];
  RFC_CHAR Tdname[70];
  RFC_CHAR Tdid[4];
  RFC_CHAR Tdspras[1];
 } CCTHEAD;
#endif

#ifndef SAP_ST_CCTLINE
#define SAP_ST_CCTLINE
typedef struct {
  RFC_NUM Textkey[8];
  RFC_CHAR Tdformat[2];
  RFC_CHAR Tdline[132];
 } CCTLINE;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_AENR_API01
#define SAP_TH_AENR_API01
static RFC_TYPEHANDLE handleOfAENR_API01;

static RFC_TYPE_ELEMENT typeOfAENR_API01[] = {
  {"CHANGE_NO", TYPC, 12, 0},
  {"STATUS", TYPNUM, 2, 0},
  {"AUTH_GROUP", TYPC, 4, 0},
  {"VALID_FROM", TYPC, 10, 0},
  {"DESCRIPT", TYPC, 40, 0},
  {"REASON_CHG", TYPC, 40, 0},
  {"DELETION_MARK", TYPC, 1, 0},
  {"INDATE_RULE", TYPC, 10, 0},
  {"OUTDATE_RULE", TYPC, 10, 0},
  {"FUNCTION", TYPC, 1, 0},
  {"CHANGE_LEADER", TYPC, 12, 0},
  {"EFFECTIVITY_TYPE", TYPC, 10, 0},
  {"OVERRIDING_MARK", TYPC, 1, 0},
  {"RANK", TYPNUM, 2, 0},
  {"RELEASE_KEY", TYPNUM, 2, 0},
  {"STATUS_PROFILE", TYPC, 8, 0},
  {"TECH_REL", TYPC, 1, 0},
  {"BASIC_CHANGE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_CCCI_AENR
#define SAP_TH_CCCI_AENR
static RFC_TYPEHANDLE handleOfCCCI_AENR;

static RFC_TYPE_ELEMENT typeOfCCCI_AENR[] = {
  {"XFLAG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_AENV_API01
#define SAP_TH_AENV_API01
static RFC_TYPEHANDLE handleOfAENV_API01;

static RFC_TYPE_ELEMENT typeOfAENV_API01[] = {
  {"ACTIVE", TYPC, 1, 0},
  {"LOCKED", TYPC, 1, 0},
  {"OBJ_REQU", TYPC, 1, 0},
  {"MGTREC_GEN", TYPC, 1, 0},
  {"GEN_NEW", TYPC, 1, 0},
  {"GEN_DIALOG", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_AEEF_API01
#define SAP_TH_AEEF_API01
static RFC_TYPEHANDLE handleOfAEEF_API01;

static RFC_TYPE_ELEMENT typeOfAEEF_API01[] = {
  {"VALID_FROM", TYPC, 10, 0},
  {"VALID_TO", TYPC, 10, 0},
  {"DATE_MARK", TYPC, 1, 0},
  {"MATERIAL", TYPC, 18, 0},
  {"SERIALNR_LOW", TYPC, 18, 0},
  {"SERIALNR_HIGH", TYPC, 18, 0},
  {"CLASS", TYPC, 18, 0},
  {"CLASSTY", TYPC, 3, 0},
  {"STARTUP", TYPC, 30, 0},
  {"PLANT", TYPC, 4, 0},
  {"SERNR_OI", TYPC, 1, 0},
  {"FL_DELETE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_AEDT_API01
#define SAP_TH_AEDT_API01
static RFC_TYPEHANDLE handleOfAEDT_API01;

static RFC_TYPE_ELEMENT typeOfAEDT_API01[] = {
  {"ALT_DATE", TYPC, 18, 0},
  {"VALID_FROM", TYPC, 10, 0},
  {"FL_DELETE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_AEOI_API01
#define SAP_TH_AEOI_API01
static RFC_TYPEHANDLE handleOfAEOI_API01;

static RFC_TYPE_ELEMENT typeOfAEOI_API01[] = {
  {"ALT_DATE", TYPC, 18, 0},
  {"CHG_OBJTYP", TYPNUM, 1, 0},
  {"BOM_CAT", TYPC, 1, 0},
  {"BOM_STD_OBJECT", TYPC, 18, 0},
  {"BOM_USAGE", TYPC, 1, 0},
  {"CHGTYPEOBJ", TYPNUM, 3, 0},
  {"DESCR_OBJ", TYPC, 40, 0},
  {"DOC_TYPE", TYPC, 3, 0},
  {"DOC_NUMBER", TYPC, 25, 0},
  {"DOC_VERS", TYPC, 2, 0},
  {"DOC_PART", TYPC, 3, 0},
  {"EQUIPMENT", TYPC, 18, 0},
  {"FUNC_LOC", TYPC, 30, 0},
  {"MATERIAL", TYPC, 18, 0},
  {"PLANT", TYPC, 4, 0},
  {"PSP_ELEMENT", TYPC, 24, 0},
  {"PVS_GUID", TYPX, 16, 0},
  {"PVS_TYPE", TYPC, 1, 0},
  {"PVS_NODE", TYPC, 40, 0},
  {"PVS_CLASS_NUMBER", TYPC, 18, 0},
  {"PVS_CLASS_TYPE", TYPC, 3, 0},
  {"PVS_VARIANT", TYPC, 8, 0},
  {"SD_ORDER", TYPC, 10, 0},
  {"SD_ORDER_I", TYPNUM, 6, 0},
  {"TEXTKEY", TYPNUM, 8, 0},
  {"TLIST_TYPE", TYPC, 1, 0},
  {"TLIST_GRP", TYPC, 8, 0},
  {"OBJ_CHGLOCK", TYPC, 1, 0},
  {"STATUS_PROF_OBJ", TYPC, 8, 0},
  {"FL_DELETE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_CCTHEAD
#define SAP_TH_CCTHEAD
static RFC_TYPEHANDLE handleOfCCTHEAD;

static RFC_TYPE_ELEMENT typeOfCCTHEAD[] = {
  {"TEXTKEY", TYPNUM, 8, 0},
  {"TDNAME", TYPC, 70, 0},
  {"TDID", TYPC, 4, 0},
  {"TDSPRAS", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_CCTLINE
#define SAP_TH_CCTLINE
static RFC_TYPEHANDLE handleOfCCTLINE;

static RFC_TYPE_ELEMENT typeOfCCTLINE[] = {
  {"TEXTKEY", TYPNUM, 8, 0},
  {"TDFORMAT", TYPC, 2, 0},
  {"TDLINE", TYPC, 132, 0},
 };
#endif

/* entries */



/*
------------------------------------------------------------------------

  Call function CCAP_ECN_HEADER_READ
      exporting
        CHANGE_NO like CCAPI_CHANGE_NO  type RFC_CHAR length 12
      importing
        CHANGE_HEADER structure AENR_API02 length
212 number of fields 22
      tables
      exceptions
        ERROR
        NO_RECORD_FOUND

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_CCAPI_CHANGE_NO
#define SAP_FT_CCAPI_CHANGE_NO
typedef RFC_CHAR CCAPI_CHANGE_NO[12];
#endif

/* structure type definition */

#ifndef SAP_ST_AENR_API02
#define SAP_ST_AENR_API02
typedef struct {
  RFC_CHAR ChangeNo[12];
  RFC_NUM Status[2];
  RFC_CHAR AuthGroup[4];
  RFC_CHAR ValidFrom[10];
  RFC_CHAR Descript[40];
  RFC_CHAR ReasonChg[40];
  RFC_CHAR CreatedOn[10];
  RFC_CHAR CreatedBy[12];
  RFC_CHAR ChangedOn[10];
  RFC_CHAR ChangedBy[12];
  RFC_CHAR DeletionMark[1];
  RFC_CHAR IndateRule[10];
  RFC_CHAR OutdateRule[10];
  RFC_CHAR Function[1];
  RFC_CHAR EffectivityType[10];
  RFC_CHAR OverridingMark[1];
  RFC_NUM Rank[2];
  RFC_NUM ReleaseKey[2];
  RFC_DATE ReleaseKeyChgdate;
  RFC_TIME ReleaseKeyChgtime;
  RFC_CHAR StatusProfile[8];
  RFC_CHAR TechRel[1];
 } AENR_API02;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_AENR_API02
#define SAP_TH_AENR_API02
static RFC_TYPEHANDLE handleOfAENR_API02;

static RFC_TYPE_ELEMENT typeOfAENR_API02[] = {
  {"CHANGE_NO", TYPC, 12, 0},
  {"STATUS", TYPNUM, 2, 0},
  {"AUTH_GROUP", TYPC, 4, 0},
  {"VALID_FROM", TYPC, 10, 0},
  {"DESCRIPT", TYPC, 40, 0},
  {"REASON_CHG", TYPC, 40, 0},
  {"CREATED_ON", TYPC, 10, 0},
  {"CREATED_BY", TYPC, 12, 0},
  {"CHANGED_ON", TYPC, 10, 0},
  {"CHANGED_BY", TYPC, 12, 0},
  {"DELETION_MARK", TYPC, 1, 0},
  {"INDATE_RULE", TYPC, 10, 0},
  {"OUTDATE_RULE", TYPC, 10, 0},
  {"FUNCTION", TYPC, 1, 0},
  {"EFFECTIVITY_TYPE", TYPC, 10, 0},
  {"OVERRIDING_MARK", TYPC, 1, 0},
  {"RANK", TYPNUM, 2, 0},
  {"RELEASE_KEY", TYPNUM, 2, 0},
  {"RELEASE_KEY_CHGDATE", TYPDATE, sizeof(RFC_DATE), 0},
  {"RELEASE_KEY_CHGTIME", TYPTIME, sizeof(RFC_TIME), 0},
  {"STATUS_PROFILE", TYPC, 8, 0},
  {"TECH_REL", TYPC, 1, 0},
 };
#endif

/* entries */





/*
------------------------------------------------------------------------

  Call function CAD_CREATE_BOM_WITH_SUB_ITEMS
      exporting
        I_AUTO_POSNR like DRAW_LOEDK default ' ' type RFC_CHAR length 1
        I_BOM_HEADER structure CAD_BICSK length
610 number of fields 44
      importing
        E_BOM_HEADER structure CAD_BICSK length 610 number of fields 44
        E_MESSAGE like MESSAGE_MSGTX type RFC_CHAR length 200
        E_MESSAGE_LEN like CAD_RETURN_MESSAGE_LEN type RFC_CHAR length 4
        E_RETURN like CAD_RETURN_VALUE type RFC_CHAR length 10
      tables
        BOM_ITEM structure CAD_BOM_ITEM length 602
number of fields 80
        BOM_SUB_ITEM structure CSSUBITEM length 85 number of fields 5
        DMS_CLASS_DATA structure CLS_CHARAC length 99 number of fields 5
        SAP_FIELD_DATA structure RFCDMSDATA length 330 number of fields 3
      exceptions

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_DRAW_LOEDK
#define SAP_FT_DRAW_LOEDK
typedef RFC_CHAR DRAW_LOEDK[1];
#endif

#ifndef SAP_FT_MESSAGE_MSGTX
#define SAP_FT_MESSAGE_MSGTX
typedef RFC_CHAR MESSAGE_MSGTX[200];
#endif

#ifndef SAP_FT_CAD_RETURN_MESSAGE_LEN
#define SAP_FT_CAD_RETURN_MESSAGE_LEN
typedef RFC_CHAR CAD_RETURN_MESSAGE_LEN[4];
#endif

#ifndef SAP_FT_CAD_RETURN_VALUE
#define SAP_FT_CAD_RETURN_VALUE
typedef RFC_CHAR CAD_RETURN_VALUE[10];
#endif

/* structure type definition */

#ifndef SAP_ST_CAD_BICSK
#define SAP_ST_CAD_BICSK
typedef struct {
  RFC_CHAR Stype[1];
  RFC_CHAR Tcode[20];
  RFC_CHAR Aennr[12];
  RFC_CHAR Bmein[3];
  RFC_CHAR Bmeng[17];
  RFC_CHAR Cadkz[1];
  RFC_CHAR Datub[10];
  RFC_CHAR Datuv[10];
  RFC_CHAR Emeng[17];
  RFC_CHAR Equnr[18];
  RFC_CHAR Exstl[18];
  RFC_CHAR Labor[3];
  RFC_CHAR Loekz[1];
  RFC_CHAR Losbs[17];
  RFC_CHAR Losvn[17];
  RFC_CHAR Matnr[18];
  RFC_CHAR Selal[2];
  RFC_CHAR Serge[30];
  RFC_CHAR Stktx[40];
  RFC_CHAR Stlal[2];
  RFC_CHAR Stlan[1];
  RFC_CHAR Stlbe[4];
  RFC_CHAR Stlst[2];
  RFC_CHAR Vmtnr[18];
  RFC_CHAR Werks[4];
  RFC_CHAR Ztext[40];
  RFC_CHAR Revlv[2];
  RFC_CHAR Tplnr[30];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Doktl[3];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Vbeln[10];
  RFC_NUM Vbpos[6];
  RFC_CHAR Stobj[18];
  RFC_CHAR Vdknr[25];
  RFC_CHAR Vdkar[3];
  RFC_CHAR Vdktl[3];
  RFC_CHAR Vdkvr[2];
  RFC_CHAR Veqnr[18];
  RFC_CHAR Vtpnr[30];
  RFC_CHAR Pspnr[24];
  RFC_CHAR Oitxt[40];
  RFC_CHAR MatnrLong[40];
 } CAD_BICSK;
#endif

#ifndef SAP_ST_CAD_BOM_ITEM
#define SAP_ST_CAD_BOM_ITEM
typedef struct {
  RFC_CHAR Upskz[1];
  RFC_CHAR Auskz[1];
  RFC_CHAR Alpos[1];
  RFC_CHAR Ausch[6];
  RFC_CHAR Avoau[6];
  RFC_CHAR Beikz[1];
  RFC_CHAR Cadpo[1];
  RFC_CHAR Ekgrp[3];
  RFC_CHAR Erskz[1];
  RFC_CHAR Fmeng[1];
  RFC_CHAR Idnrk[18];
  RFC_CHAR Lifnr[10];
  RFC_CHAR Lifzt[3];
  RFC_CHAR Matkl[9];
  RFC_CHAR Meins[3];
  RFC_CHAR Menge[18];
  RFC_CHAR Netau[1];
  RFC_CHAR Nfmat[18];
  RFC_CHAR Nlfzt[3];
  RFC_CHAR Peinh[6];
  RFC_CHAR Posnr[4];
  RFC_CHAR Postp[1];
  RFC_CHAR Preis[14];
  RFC_CHAR Potx1[40];
  RFC_CHAR Potx2[40];
  RFC_CHAR Pswrk[4];
  RFC_CHAR Rekrs[1];
  RFC_CHAR Rform[2];
  RFC_CHAR Roanz[17];
  RFC_CHAR Roame[3];
  RFC_CHAR Rokme[3];
  RFC_CHAR Romei[3];
  RFC_CHAR Romen[17];
  RFC_CHAR Roms1[17];
  RFC_CHAR Roms2[17];
  RFC_CHAR Roms3[17];
  RFC_CHAR Rvrel[1];
  RFC_CHAR Sakto[10];
  RFC_CHAR Sanfe[1];
  RFC_CHAR Sanin[1];
  RFC_CHAR Sanka[1];
  RFC_CHAR Sanko[1];
  RFC_CHAR Sanvs[1];
  RFC_CHAR Schgt[1];
  RFC_CHAR Selal[2];
  RFC_CHAR Selid[18];
  RFC_CHAR Selpo[4];
  RFC_CHAR Selsb[10];
  RFC_CHAR Sortf[10];
  RFC_CHAR Stkkz[1];
  RFC_CHAR Stktx[40];
  RFC_CHAR Stlal[2];
  RFC_CHAR Stlkz[1];
  RFC_CHAR Verti[4];
  RFC_CHAR Webaz[3];
  RFC_CHAR Waers[5];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Doktl[3];
  RFC_CHAR Ewahr[3];
  RFC_CHAR Ekorg[4];
  RFC_CHAR Lgort[4];
  RFC_CHAR Class[18];
  RFC_CHAR Klart[3];
  RFC_CHAR Potpr[1];
  RFC_CHAR Alpgr[2];
  RFC_CHAR Alpst[1];
  RFC_NUM Alprf[2];
  RFC_CHAR Dspst[2];
  RFC_CHAR Prvbe[10];
  RFC_CHAR Nfeag[2];
  RFC_CHAR Nfgrp[2];
  RFC_CHAR Kzkup[1];
  RFC_CHAR Intrm[18];
  RFC_CHAR Kzclb[1];
  RFC_CHAR Nlfzv[4];
  RFC_CHAR Nlfmv[3];
  RFC_CHAR Rfpnt[20];
  RFC_CHAR MatnrLong[40];
 } CAD_BOM_ITEM;
#endif

#ifndef SAP_ST_CSSUBITEM
#define SAP_ST_CSSUBITEM
typedef struct {
  RFC_CHAR Posid[4];
  RFC_CHAR Ebort[20];
  RFC_CHAR Upmng[17];
  RFC_CHAR Uposz[4];
  RFC_CHAR Uptxt[40];
 } CSSUBITEM;
#endif

#ifndef SAP_ST_CLS_CHARAC
#define SAP_ST_CLS_CHARAC
typedef struct {
  RFC_CHAR Atnam[30];
  RFC_CHAR Atbez[30];
  RFC_CHAR Atwrt[30];
  RFC_CHAR Dinkb[3];
  RFC_CHAR Unit[6];
 } CLS_CHARAC;
#endif

#ifndef SAP_ST_RFCDMSDATA
#define SAP_ST_RFCDMSDATA
typedef struct {
  RFC_CHAR Fieldmulti[40];
  RFC_CHAR Fieldname[35];
  RFC_CHAR Fieldvalue[255];
 } RFCDMSDATA;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_CAD_BICSK
#define SAP_TH_CAD_BICSK
static RFC_TYPEHANDLE handleOfCAD_BICSK;

static RFC_TYPE_ELEMENT typeOfCAD_BICSK[] = {
  {"STYPE", TYPC, 1, 0},
  {"TCODE", TYPC, 20, 0},
  {"AENNR", TYPC, 12, 0},
  {"BMEIN", TYPC, 3, 0},
  {"BMENG", TYPC, 17, 0},
  {"CADKZ", TYPC, 1, 0},
  {"DATUB", TYPC, 10, 0},
  {"DATUV", TYPC, 10, 0},
  {"EMENG", TYPC, 17, 0},
  {"EQUNR", TYPC, 18, 0},
  {"EXSTL", TYPC, 18, 0},
  {"LABOR", TYPC, 3, 0},
  {"LOEKZ", TYPC, 1, 0},
  {"LOSBS", TYPC, 17, 0},
  {"LOSVN", TYPC, 17, 0},
  {"MATNR", TYPC, 18, 0},
  {"SELAL", TYPC, 2, 0},
  {"SERGE", TYPC, 30, 0},
  {"STKTX", TYPC, 40, 0},
  {"STLAL", TYPC, 2, 0},
  {"STLAN", TYPC, 1, 0},
  {"STLBE", TYPC, 4, 0},
  {"STLST", TYPC, 2, 0},
  {"VMTNR", TYPC, 18, 0},
  {"WERKS", TYPC, 4, 0},
  {"ZTEXT", TYPC, 40, 0},
  {"REVLV", TYPC, 2, 0},
  {"TPLNR", TYPC, 30, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKTL", TYPC, 3, 0},
  {"DOKVR", TYPC, 2, 0},
  {"VBELN", TYPC, 10, 0},
  {"VBPOS", TYPNUM, 6, 0},
  {"STOBJ", TYPC, 18, 0},
  {"VDKNR", TYPC, 25, 0},
  {"VDKAR", TYPC, 3, 0},
  {"VDKTL", TYPC, 3, 0},
  {"VDKVR", TYPC, 2, 0},
  {"VEQNR", TYPC, 18, 0},
  {"VTPNR", TYPC, 30, 0},
  {"PSPNR", TYPC, 24, 0},
  {"OITXT", TYPC, 40, 0},
  {"MATNR_LONG", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CAD_BOM_ITEM
#define SAP_TH_CAD_BOM_ITEM
static RFC_TYPEHANDLE handleOfCAD_BOM_ITEM;

static RFC_TYPE_ELEMENT typeOfCAD_BOM_ITEM[] = {
  {"UPSKZ", TYPC, 1, 0},
  {"AUSKZ", TYPC, 1, 0},
  {"ALPOS", TYPC, 1, 0},
  {"AUSCH", TYPC, 6, 0},
  {"AVOAU", TYPC, 6, 0},
  {"BEIKZ", TYPC, 1, 0},
  {"CADPO", TYPC, 1, 0},
  {"EKGRP", TYPC, 3, 0},
  {"ERSKZ", TYPC, 1, 0},
  {"FMENG", TYPC, 1, 0},
  {"IDNRK", TYPC, 18, 0},
  {"LIFNR", TYPC, 10, 0},
  {"LIFZT", TYPC, 3, 0},
  {"MATKL", TYPC, 9, 0},
  {"MEINS", TYPC, 3, 0},
  {"MENGE", TYPC, 18, 0},
  {"NETAU", TYPC, 1, 0},
  {"NFMAT", TYPC, 18, 0},
  {"NLFZT", TYPC, 3, 0},
  {"PEINH", TYPC, 6, 0},
  {"POSNR", TYPC, 4, 0},
  {"POSTP", TYPC, 1, 0},
  {"PREIS", TYPC, 14, 0},
  {"POTX1", TYPC, 40, 0},
  {"POTX2", TYPC, 40, 0},
  {"PSWRK", TYPC, 4, 0},
  {"REKRS", TYPC, 1, 0},
  {"RFORM", TYPC, 2, 0},
  {"ROANZ", TYPC, 17, 0},
  {"ROAME", TYPC, 3, 0},
  {"ROKME", TYPC, 3, 0},
  {"ROMEI", TYPC, 3, 0},
  {"ROMEN", TYPC, 17, 0},
  {"ROMS1", TYPC, 17, 0},
  {"ROMS2", TYPC, 17, 0},
  {"ROMS3", TYPC, 17, 0},
  {"RVREL", TYPC, 1, 0},
  {"SAKTO", TYPC, 10, 0},
  {"SANFE", TYPC, 1, 0},
  {"SANIN", TYPC, 1, 0},
  {"SANKA", TYPC, 1, 0},
  {"SANKO", TYPC, 1, 0},
  {"SANVS", TYPC, 1, 0},
  {"SCHGT", TYPC, 1, 0},
  {"SELAL", TYPC, 2, 0},
  {"SELID", TYPC, 18, 0},
  {"SELPO", TYPC, 4, 0},
  {"SELSB", TYPC, 10, 0},
  {"SORTF", TYPC, 10, 0},
  {"STKKZ", TYPC, 1, 0},
  {"STKTX", TYPC, 40, 0},
  {"STLAL", TYPC, 2, 0},
  {"STLKZ", TYPC, 1, 0},
  {"VERTI", TYPC, 4, 0},
  {"WEBAZ", TYPC, 3, 0},
  {"WAERS", TYPC, 5, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKVR", TYPC, 2, 0},
  {"DOKTL", TYPC, 3, 0},
  {"EWAHR", TYPC, 3, 0},
  {"EKORG", TYPC, 4, 0},
  {"LGORT", TYPC, 4, 0},
  {"CLASS", TYPC, 18, 0},
  {"KLART", TYPC, 3, 0},
  {"POTPR", TYPC, 1, 0},
  {"ALPGR", TYPC, 2, 0},
  {"ALPST", TYPC, 1, 0},
  {"ALPRF", TYPNUM, 2, 0},
  {"DSPST", TYPC, 2, 0},
  {"PRVBE", TYPC, 10, 0},
  {"NFEAG", TYPC, 2, 0},
  {"NFGRP", TYPC, 2, 0},
  {"KZKUP", TYPC, 1, 0},
  {"INTRM", TYPC, 18, 0},
  {"KZCLB", TYPC, 1, 0},
  {"NLFZV", TYPC, 4, 0},
  {"NLFMV", TYPC, 3, 0},
  {"RFPNT", TYPC, 20, 0},
  {"MATNR_LONG", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CSSUBITEM
#define SAP_TH_CSSUBITEM
static RFC_TYPEHANDLE handleOfCSSUBITEM;

static RFC_TYPE_ELEMENT typeOfCSSUBITEM[] = {
  {"POSID", TYPC, 4, 0},
  {"EBORT", TYPC, 20, 0},
  {"UPMNG", TYPC, 17, 0},
  {"UPOSZ", TYPC, 4, 0},
  {"UPTXT", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CLS_CHARAC
#define SAP_TH_CLS_CHARAC
static RFC_TYPEHANDLE handleOfCLS_CHARAC;

static RFC_TYPE_ELEMENT typeOfCLS_CHARAC[] = {
  {"ATNAM", TYPC, 30, 0},
  {"ATBEZ", TYPC, 30, 0},
  {"ATWRT", TYPC, 30, 0},
  {"DINKB", TYPC, 3, 0},
  {"UNIT", TYPC, 6, 0},
 };
#endif

#ifndef SAP_TH_RFCDMSDATA
#define SAP_TH_RFCDMSDATA
static RFC_TYPEHANDLE handleOfRFCDMSDATA;

static RFC_TYPE_ELEMENT typeOfRFCDMSDATA[] = {
  {"FIELDMULTI", TYPC, 40, 0},
  {"FIELDNAME", TYPC, 35, 0},
  {"FIELDVALUE", TYPC, 255, 0},
 };
#endif

/* entries */




/*
------------------------------------------------------------------------

  Call function CAD_DISPLAY_BOM_WITH_SUB_ITEMS
      exporting
        I_BOM_ALTERNATIVE like RC29L_STLAL default SPACE type RFC_CHAR length 2
        I_BOM_TYPE like RC29L_STLAN default SPACE type RFC_CHAR length 1
        I_CHANGE_NUMBER like RC29L_AENNR default SPACE type RFC_CHAR length 12
        I_DISPLAY_FLAG like DRAW_LOEDK default 'X' type RFC_CHAR length 1
        I_MATERIAL like RC29L_MATNR  type RFC_CHAR length 18
        I_PLANT like RC29L_WERKS default SPACE type RFC_CHAR length 4
        I_REVISION_LEVEL like RC29L_REVLV default SPACE type RFC_CHAR length 2
        I_VALID_FROM like BICSK_DATUV  type RFC_CHAR length 10
      importing
        E_BOM_HEADER structure CAD_BICSK length
610 number of fields 44
        E_MESSAGE like MESSAGE_MSGTX type RFC_CHAR length 200
        E_MESSAGE_LEN like CAD_RETURN_MESSAGE_LEN type RFC_CHAR length 4
        E_RETURN like CAD_RETURN_VALUE type RFC_CHAR length 10
      tables
        BOM_ITEM structure CAD_BOM_ITEM length 602
number of fields 80
        BOM_SUB_ITEM structure CSSUBITEM length 85 number of fields 5
        DMS_CLASS_DATA structure CLS_CHARAC length 99 number of fields 5
        SAP_FIELD_DATA structure RFCDMSDATA length 330 number of fields 3
      exceptions

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_RC29L_STLAL
#define SAP_FT_RC29L_STLAL
typedef RFC_CHAR RC29L_STLAL[2];
#endif

#ifndef SAP_FT_RC29L_STLAN
#define SAP_FT_RC29L_STLAN
typedef RFC_CHAR RC29L_STLAN[1];
#endif

#ifndef SAP_FT_RC29L_AENNR
#define SAP_FT_RC29L_AENNR
typedef RFC_CHAR RC29L_AENNR[12];
#endif

#ifndef SAP_FT_DRAW_LOEDK
#define SAP_FT_DRAW_LOEDK
typedef RFC_CHAR DRAW_LOEDK[1];
#endif

#ifndef SAP_FT_RC29L_MATNR
#define SAP_FT_RC29L_MATNR
typedef RFC_CHAR RC29L_MATNR[18];
#endif

#ifndef SAP_FT_RC29L_WERKS
#define SAP_FT_RC29L_WERKS
typedef RFC_CHAR RC29L_WERKS[4];
#endif

#ifndef SAP_FT_RC29L_REVLV
#define SAP_FT_RC29L_REVLV
typedef RFC_CHAR RC29L_REVLV[2];
#endif

#ifndef SAP_FT_BICSK_DATUV
#define SAP_FT_BICSK_DATUV
typedef RFC_CHAR BICSK_DATUV[10];
#endif

#ifndef SAP_FT_MESSAGE_MSGTX
#define SAP_FT_MESSAGE_MSGTX
typedef RFC_CHAR MESSAGE_MSGTX[200];
#endif

#ifndef SAP_FT_CAD_RETURN_MESSAGE_LEN
#define SAP_FT_CAD_RETURN_MESSAGE_LEN
typedef RFC_CHAR CAD_RETURN_MESSAGE_LEN[4];
#endif

#ifndef SAP_FT_CAD_RETURN_VALUE
#define SAP_FT_CAD_RETURN_VALUE
typedef RFC_CHAR CAD_RETURN_VALUE[10];
#endif

/* structure type definition */

#ifndef SAP_ST_CAD_BICSK
#define SAP_ST_CAD_BICSK
typedef struct {
  RFC_CHAR Stype[1];
  RFC_CHAR Tcode[20];
  RFC_CHAR Aennr[12];
  RFC_CHAR Bmein[3];
  RFC_CHAR Bmeng[17];
  RFC_CHAR Cadkz[1];
  RFC_CHAR Datub[10];
  RFC_CHAR Datuv[10];
  RFC_CHAR Emeng[17];
  RFC_CHAR Equnr[18];
  RFC_CHAR Exstl[18];
  RFC_CHAR Labor[3];
  RFC_CHAR Loekz[1];
  RFC_CHAR Losbs[17];
  RFC_CHAR Losvn[17];
  RFC_CHAR Matnr[18];
  RFC_CHAR Selal[2];
  RFC_CHAR Serge[30];
  RFC_CHAR Stktx[40];
  RFC_CHAR Stlal[2];
  RFC_CHAR Stlan[1];
  RFC_CHAR Stlbe[4];
  RFC_CHAR Stlst[2];
  RFC_CHAR Vmtnr[18];
  RFC_CHAR Werks[4];
  RFC_CHAR Ztext[40];
  RFC_CHAR Revlv[2];
  RFC_CHAR Tplnr[30];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Doktl[3];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Vbeln[10];
  RFC_NUM Vbpos[6];
  RFC_CHAR Stobj[18];
  RFC_CHAR Vdknr[25];
  RFC_CHAR Vdkar[3];
  RFC_CHAR Vdktl[3];
  RFC_CHAR Vdkvr[2];
  RFC_CHAR Veqnr[18];
  RFC_CHAR Vtpnr[30];
  RFC_CHAR Pspnr[24];
  RFC_CHAR Oitxt[40];
  RFC_CHAR MatnrLong[40];
 } CAD_BICSK;
#endif

#ifndef SAP_ST_CAD_BOM_ITEM
#define SAP_ST_CAD_BOM_ITEM
typedef struct {
  RFC_CHAR Upskz[1];
  RFC_CHAR Auskz[1];
  RFC_CHAR Alpos[1];
  RFC_CHAR Ausch[6];
  RFC_CHAR Avoau[6];
  RFC_CHAR Beikz[1];
  RFC_CHAR Cadpo[1];
  RFC_CHAR Ekgrp[3];
  RFC_CHAR Erskz[1];
  RFC_CHAR Fmeng[1];
  RFC_CHAR Idnrk[18];
  RFC_CHAR Lifnr[10];
  RFC_CHAR Lifzt[3];
  RFC_CHAR Matkl[9];
  RFC_CHAR Meins[3];
  RFC_CHAR Menge[18];
  RFC_CHAR Netau[1];
  RFC_CHAR Nfmat[18];
  RFC_CHAR Nlfzt[3];
  RFC_CHAR Peinh[6];
  RFC_CHAR Posnr[4];
  RFC_CHAR Postp[1];
  RFC_CHAR Preis[14];
  RFC_CHAR Potx1[40];
  RFC_CHAR Potx2[40];
  RFC_CHAR Pswrk[4];
  RFC_CHAR Rekrs[1];
  RFC_CHAR Rform[2];
  RFC_CHAR Roanz[17];
  RFC_CHAR Roame[3];
  RFC_CHAR Rokme[3];
  RFC_CHAR Romei[3];
  RFC_CHAR Romen[17];
  RFC_CHAR Roms1[17];
  RFC_CHAR Roms2[17];
  RFC_CHAR Roms3[17];
  RFC_CHAR Rvrel[1];
  RFC_CHAR Sakto[10];
  RFC_CHAR Sanfe[1];
  RFC_CHAR Sanin[1];
  RFC_CHAR Sanka[1];
  RFC_CHAR Sanko[1];
  RFC_CHAR Sanvs[1];
  RFC_CHAR Schgt[1];
  RFC_CHAR Selal[2];
  RFC_CHAR Selid[18];
  RFC_CHAR Selpo[4];
  RFC_CHAR Selsb[10];
  RFC_CHAR Sortf[10];
  RFC_CHAR Stkkz[1];
  RFC_CHAR Stktx[40];
  RFC_CHAR Stlal[2];
  RFC_CHAR Stlkz[1];
  RFC_CHAR Verti[4];
  RFC_CHAR Webaz[3];
  RFC_CHAR Waers[5];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Doktl[3];
  RFC_CHAR Ewahr[3];
  RFC_CHAR Ekorg[4];
  RFC_CHAR Lgort[4];
  RFC_CHAR Class[18];
  RFC_CHAR Klart[3];
  RFC_CHAR Potpr[1];
  RFC_CHAR Alpgr[2];
  RFC_CHAR Alpst[1];
  RFC_NUM Alprf[2];
  RFC_CHAR Dspst[2];
  RFC_CHAR Prvbe[10];
  RFC_CHAR Nfeag[2];
  RFC_CHAR Nfgrp[2];
  RFC_CHAR Kzkup[1];
  RFC_CHAR Intrm[18];
  RFC_CHAR Kzclb[1];
  RFC_CHAR Nlfzv[4];
  RFC_CHAR Nlfmv[3];
  RFC_CHAR Rfpnt[20];
  RFC_CHAR MatnrLong[40];
 } CAD_BOM_ITEM;
#endif

#ifndef SAP_ST_CSSUBITEM
#define SAP_ST_CSSUBITEM
typedef struct {
  RFC_CHAR Posid[4];
  RFC_CHAR Ebort[20];
  RFC_CHAR Upmng[17];
  RFC_CHAR Uposz[4];
  RFC_CHAR Uptxt[40];
 } CSSUBITEM;
#endif

#ifndef SAP_ST_CLS_CHARAC
#define SAP_ST_CLS_CHARAC
typedef struct {
  RFC_CHAR Atnam[30];
  RFC_CHAR Atbez[30];
  RFC_CHAR Atwrt[30];
  RFC_CHAR Dinkb[3];
  RFC_CHAR Unit[6];
 } CLS_CHARAC;
#endif

#ifndef SAP_ST_RFCDMSDATA
#define SAP_ST_RFCDMSDATA
typedef struct {
  RFC_CHAR Fieldmulti[40];
  RFC_CHAR Fieldname[35];
  RFC_CHAR Fieldvalue[255];
 } RFCDMSDATA;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_CAD_BICSK
#define SAP_TH_CAD_BICSK
static RFC_TYPEHANDLE handleOfCAD_BICSK;

static RFC_TYPE_ELEMENT typeOfCAD_BICSK[] = {
  {"STYPE", TYPC, 1, 0},
  {"TCODE", TYPC, 20, 0},
  {"AENNR", TYPC, 12, 0},
  {"BMEIN", TYPC, 3, 0},
  {"BMENG", TYPC, 17, 0},
  {"CADKZ", TYPC, 1, 0},
  {"DATUB", TYPC, 10, 0},
  {"DATUV", TYPC, 10, 0},
  {"EMENG", TYPC, 17, 0},
  {"EQUNR", TYPC, 18, 0},
  {"EXSTL", TYPC, 18, 0},
  {"LABOR", TYPC, 3, 0},
  {"LOEKZ", TYPC, 1, 0},
  {"LOSBS", TYPC, 17, 0},
  {"LOSVN", TYPC, 17, 0},
  {"MATNR", TYPC, 18, 0},
  {"SELAL", TYPC, 2, 0},
  {"SERGE", TYPC, 30, 0},
  {"STKTX", TYPC, 40, 0},
  {"STLAL", TYPC, 2, 0},
  {"STLAN", TYPC, 1, 0},
  {"STLBE", TYPC, 4, 0},
  {"STLST", TYPC, 2, 0},
  {"VMTNR", TYPC, 18, 0},
  {"WERKS", TYPC, 4, 0},
  {"ZTEXT", TYPC, 40, 0},
  {"REVLV", TYPC, 2, 0},
  {"TPLNR", TYPC, 30, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKTL", TYPC, 3, 0},
  {"DOKVR", TYPC, 2, 0},
  {"VBELN", TYPC, 10, 0},
  {"VBPOS", TYPNUM, 6, 0},
  {"STOBJ", TYPC, 18, 0},
  {"VDKNR", TYPC, 25, 0},
  {"VDKAR", TYPC, 3, 0},
  {"VDKTL", TYPC, 3, 0},
  {"VDKVR", TYPC, 2, 0},
  {"VEQNR", TYPC, 18, 0},
  {"VTPNR", TYPC, 30, 0},
  {"PSPNR", TYPC, 24, 0},
  {"OITXT", TYPC, 40, 0},
  {"MATNR_LONG", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CAD_BOM_ITEM
#define SAP_TH_CAD_BOM_ITEM
static RFC_TYPEHANDLE handleOfCAD_BOM_ITEM;

static RFC_TYPE_ELEMENT typeOfCAD_BOM_ITEM[] = {
  {"UPSKZ", TYPC, 1, 0},
  {"AUSKZ", TYPC, 1, 0},
  {"ALPOS", TYPC, 1, 0},
  {"AUSCH", TYPC, 6, 0},
  {"AVOAU", TYPC, 6, 0},
  {"BEIKZ", TYPC, 1, 0},
  {"CADPO", TYPC, 1, 0},
  {"EKGRP", TYPC, 3, 0},
  {"ERSKZ", TYPC, 1, 0},
  {"FMENG", TYPC, 1, 0},
  {"IDNRK", TYPC, 18, 0},
  {"LIFNR", TYPC, 10, 0},
  {"LIFZT", TYPC, 3, 0},
  {"MATKL", TYPC, 9, 0},
  {"MEINS", TYPC, 3, 0},
  {"MENGE", TYPC, 18, 0},
  {"NETAU", TYPC, 1, 0},
  {"NFMAT", TYPC, 18, 0},
  {"NLFZT", TYPC, 3, 0},
  {"PEINH", TYPC, 6, 0},
  {"POSNR", TYPC, 4, 0},
  {"POSTP", TYPC, 1, 0},
  {"PREIS", TYPC, 14, 0},
  {"POTX1", TYPC, 40, 0},
  {"POTX2", TYPC, 40, 0},
  {"PSWRK", TYPC, 4, 0},
  {"REKRS", TYPC, 1, 0},
  {"RFORM", TYPC, 2, 0},
  {"ROANZ", TYPC, 17, 0},
  {"ROAME", TYPC, 3, 0},
  {"ROKME", TYPC, 3, 0},
  {"ROMEI", TYPC, 3, 0},
  {"ROMEN", TYPC, 17, 0},
  {"ROMS1", TYPC, 17, 0},
  {"ROMS2", TYPC, 17, 0},
  {"ROMS3", TYPC, 17, 0},
  {"RVREL", TYPC, 1, 0},
  {"SAKTO", TYPC, 10, 0},
  {"SANFE", TYPC, 1, 0},
  {"SANIN", TYPC, 1, 0},
  {"SANKA", TYPC, 1, 0},
  {"SANKO", TYPC, 1, 0},
  {"SANVS", TYPC, 1, 0},
  {"SCHGT", TYPC, 1, 0},
  {"SELAL", TYPC, 2, 0},
  {"SELID", TYPC, 18, 0},
  {"SELPO", TYPC, 4, 0},
  {"SELSB", TYPC, 10, 0},
  {"SORTF", TYPC, 10, 0},
  {"STKKZ", TYPC, 1, 0},
  {"STKTX", TYPC, 40, 0},
  {"STLAL", TYPC, 2, 0},
  {"STLKZ", TYPC, 1, 0},
  {"VERTI", TYPC, 4, 0},
  {"WEBAZ", TYPC, 3, 0},
  {"WAERS", TYPC, 5, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKVR", TYPC, 2, 0},
  {"DOKTL", TYPC, 3, 0},
  {"EWAHR", TYPC, 3, 0},
  {"EKORG", TYPC, 4, 0},
  {"LGORT", TYPC, 4, 0},
  {"CLASS", TYPC, 18, 0},
  {"KLART", TYPC, 3, 0},
  {"POTPR", TYPC, 1, 0},
  {"ALPGR", TYPC, 2, 0},
  {"ALPST", TYPC, 1, 0},
  {"ALPRF", TYPNUM, 2, 0},
  {"DSPST", TYPC, 2, 0},
  {"PRVBE", TYPC, 10, 0},
  {"NFEAG", TYPC, 2, 0},
  {"NFGRP", TYPC, 2, 0},
  {"KZKUP", TYPC, 1, 0},
  {"INTRM", TYPC, 18, 0},
  {"KZCLB", TYPC, 1, 0},
  {"NLFZV", TYPC, 4, 0},
  {"NLFMV", TYPC, 3, 0},
  {"RFPNT", TYPC, 20, 0},
  {"MATNR_LONG", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CSSUBITEM
#define SAP_TH_CSSUBITEM
static RFC_TYPEHANDLE handleOfCSSUBITEM;

static RFC_TYPE_ELEMENT typeOfCSSUBITEM[] = {
  {"POSID", TYPC, 4, 0},
  {"EBORT", TYPC, 20, 0},
  {"UPMNG", TYPC, 17, 0},
  {"UPOSZ", TYPC, 4, 0},
  {"UPTXT", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CLS_CHARAC
#define SAP_TH_CLS_CHARAC
static RFC_TYPEHANDLE handleOfCLS_CHARAC;

static RFC_TYPE_ELEMENT typeOfCLS_CHARAC[] = {
  {"ATNAM", TYPC, 30, 0},
  {"ATBEZ", TYPC, 30, 0},
  {"ATWRT", TYPC, 30, 0},
  {"DINKB", TYPC, 3, 0},
  {"UNIT", TYPC, 6, 0},
 };
#endif

#ifndef SAP_TH_RFCDMSDATA
#define SAP_TH_RFCDMSDATA
static RFC_TYPEHANDLE handleOfRFCDMSDATA;

static RFC_TYPE_ELEMENT typeOfRFCDMSDATA[] = {
  {"FIELDMULTI", TYPC, 40, 0},
  {"FIELDNAME", TYPC, 35, 0},
  {"FIELDVALUE", TYPC, 255, 0},
 };
#endif

/* entries */



/*
------------------------------------------------------------------------

  Call function CAD_CHANGE_BOM_WITH_SUB_ITEMS
      exporting
        I_BOM_HEADER structure CAD_BICSK length 610 number of fields 44
      importing
        E_BOM_HEADER structure CAD_BICSK length 610 number of fields 44
        E_MESSAGE like MESSAGE_MSGTX type RFC_CHAR length 200
        E_MESSAGE_LEN like CAD_RETURN_MESSAGE_LEN type RFC_CHAR length 4
        E_RETURN like CAD_RETURN_VALUE type RFC_CHAR length 10
      tables
        BOM_ITEM structure CAD_BOM_ITEM length 602
number of fields 80
        BOM_SUB_ITEM structure CSSUBITEM length 85 number of fields 5
        DMS_CLASS_DATA structure CLS_CHARAC length 99 number of fields 5
        SAP_FIELD_DATA structure RFCDMSDATA length 330 number of fields 3
      exceptions

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_MESSAGE_MSGTX
#define SAP_FT_MESSAGE_MSGTX
typedef RFC_CHAR MESSAGE_MSGTX[200];
#endif

#ifndef SAP_FT_CAD_RETURN_MESSAGE_LEN
#define SAP_FT_CAD_RETURN_MESSAGE_LEN
typedef RFC_CHAR CAD_RETURN_MESSAGE_LEN[4];
#endif

#ifndef SAP_FT_CAD_RETURN_VALUE
#define SAP_FT_CAD_RETURN_VALUE
typedef RFC_CHAR CAD_RETURN_VALUE[10];
#endif

/* structure type definition */

#ifndef SAP_ST_CAD_BICSK
#define SAP_ST_CAD_BICSK
typedef struct {
  RFC_CHAR Stype[1];
  RFC_CHAR Tcode[20];
  RFC_CHAR Aennr[12];
  RFC_CHAR Bmein[3];
  RFC_CHAR Bmeng[17];
  RFC_CHAR Cadkz[1];
  RFC_CHAR Datub[10];
  RFC_CHAR Datuv[10];
  RFC_CHAR Emeng[17];
  RFC_CHAR Equnr[18];
  RFC_CHAR Exstl[18];
  RFC_CHAR Labor[3];
  RFC_CHAR Loekz[1];
  RFC_CHAR Losbs[17];
  RFC_CHAR Losvn[17];
  RFC_CHAR Matnr[18];
  RFC_CHAR Selal[2];
  RFC_CHAR Serge[30];
  RFC_CHAR Stktx[40];
  RFC_CHAR Stlal[2];
  RFC_CHAR Stlan[1];
  RFC_CHAR Stlbe[4];
  RFC_CHAR Stlst[2];
  RFC_CHAR Vmtnr[18];
  RFC_CHAR Werks[4];
  RFC_CHAR Ztext[40];
  RFC_CHAR Revlv[2];
  RFC_CHAR Tplnr[30];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Doktl[3];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Vbeln[10];
  RFC_NUM Vbpos[6];
  RFC_CHAR Stobj[18];
  RFC_CHAR Vdknr[25];
  RFC_CHAR Vdkar[3];
  RFC_CHAR Vdktl[3];
  RFC_CHAR Vdkvr[2];
  RFC_CHAR Veqnr[18];
  RFC_CHAR Vtpnr[30];
  RFC_CHAR Pspnr[24];
  RFC_CHAR Oitxt[40];
  RFC_CHAR MatnrLong[40];
 } CAD_BICSK;
#endif

#ifndef SAP_ST_CAD_BOM_ITEM
#define SAP_ST_CAD_BOM_ITEM
typedef struct {
  RFC_CHAR Upskz[1];
  RFC_CHAR Auskz[1];
  RFC_CHAR Alpos[1];
  RFC_CHAR Ausch[6];
  RFC_CHAR Avoau[6];
  RFC_CHAR Beikz[1];
  RFC_CHAR Cadpo[1];
  RFC_CHAR Ekgrp[3];
  RFC_CHAR Erskz[1];
  RFC_CHAR Fmeng[1];
  RFC_CHAR Idnrk[18];
  RFC_CHAR Lifnr[10];
  RFC_CHAR Lifzt[3];
  RFC_CHAR Matkl[9];
  RFC_CHAR Meins[3];
  RFC_CHAR Menge[18];
  RFC_CHAR Netau[1];
  RFC_CHAR Nfmat[18];
  RFC_CHAR Nlfzt[3];
  RFC_CHAR Peinh[6];
  RFC_CHAR Posnr[4];
  RFC_CHAR Postp[1];
  RFC_CHAR Preis[14];
  RFC_CHAR Potx1[40];
  RFC_CHAR Potx2[40];
  RFC_CHAR Pswrk[4];
  RFC_CHAR Rekrs[1];
  RFC_CHAR Rform[2];
  RFC_CHAR Roanz[17];
  RFC_CHAR Roame[3];
  RFC_CHAR Rokme[3];
  RFC_CHAR Romei[3];
  RFC_CHAR Romen[17];
  RFC_CHAR Roms1[17];
  RFC_CHAR Roms2[17];
  RFC_CHAR Roms3[17];
  RFC_CHAR Rvrel[1];
  RFC_CHAR Sakto[10];
  RFC_CHAR Sanfe[1];
  RFC_CHAR Sanin[1];
  RFC_CHAR Sanka[1];
  RFC_CHAR Sanko[1];
  RFC_CHAR Sanvs[1];
  RFC_CHAR Schgt[1];
  RFC_CHAR Selal[2];
  RFC_CHAR Selid[18];
  RFC_CHAR Selpo[4];
  RFC_CHAR Selsb[10];
  RFC_CHAR Sortf[10];
  RFC_CHAR Stkkz[1];
  RFC_CHAR Stktx[40];
  RFC_CHAR Stlal[2];
  RFC_CHAR Stlkz[1];
  RFC_CHAR Verti[4];
  RFC_CHAR Webaz[3];
  RFC_CHAR Waers[5];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Doktl[3];
  RFC_CHAR Ewahr[3];
  RFC_CHAR Ekorg[4];
  RFC_CHAR Lgort[4];
  RFC_CHAR Class[18];
  RFC_CHAR Klart[3];
  RFC_CHAR Potpr[1];
  RFC_CHAR Alpgr[2];
  RFC_CHAR Alpst[1];
  RFC_NUM Alprf[2];
  RFC_CHAR Dspst[2];
  RFC_CHAR Prvbe[10];
  RFC_CHAR Nfeag[2];
  RFC_CHAR Nfgrp[2];
  RFC_CHAR Kzkup[1];
  RFC_CHAR Intrm[18];
  RFC_CHAR Kzclb[1];
  RFC_CHAR Nlfzv[4];
  RFC_CHAR Nlfmv[3];
  RFC_CHAR Rfpnt[20];
  RFC_CHAR MatnrLong[40];
 } CAD_BOM_ITEM;
#endif

#ifndef SAP_ST_CSSUBITEM
#define SAP_ST_CSSUBITEM
typedef struct {
  RFC_CHAR Posid[4];
  RFC_CHAR Ebort[20];
  RFC_CHAR Upmng[17];
  RFC_CHAR Uposz[4];
  RFC_CHAR Uptxt[40];
 } CSSUBITEM;
#endif

#ifndef SAP_ST_CLS_CHARAC
#define SAP_ST_CLS_CHARAC
typedef struct {
  RFC_CHAR Atnam[30];
  RFC_CHAR Atbez[30];
  RFC_CHAR Atwrt[30];
  RFC_CHAR Dinkb[3];
  RFC_CHAR Unit[6];
 } CLS_CHARAC;
#endif

#ifndef SAP_ST_RFCDMSDATA
#define SAP_ST_RFCDMSDATA
typedef struct {
  RFC_CHAR Fieldmulti[40];
  RFC_CHAR Fieldname[35];
  RFC_CHAR Fieldvalue[255];
 } RFCDMSDATA;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_CAD_BICSK
#define SAP_TH_CAD_BICSK
static RFC_TYPEHANDLE handleOfCAD_BICSK;

static RFC_TYPE_ELEMENT typeOfCAD_BICSK[] = {
  {"STYPE", TYPC, 1, 0},
  {"TCODE", TYPC, 20, 0},
  {"AENNR", TYPC, 12, 0},
  {"BMEIN", TYPC, 3, 0},
  {"BMENG", TYPC, 17, 0},
  {"CADKZ", TYPC, 1, 0},
  {"DATUB", TYPC, 10, 0},
  {"DATUV", TYPC, 10, 0},
  {"EMENG", TYPC, 17, 0},
  {"EQUNR", TYPC, 18, 0},
  {"EXSTL", TYPC, 18, 0},
  {"LABOR", TYPC, 3, 0},
  {"LOEKZ", TYPC, 1, 0},
  {"LOSBS", TYPC, 17, 0},
  {"LOSVN", TYPC, 17, 0},
  {"MATNR", TYPC, 18, 0},
  {"SELAL", TYPC, 2, 0},
  {"SERGE", TYPC, 30, 0},
  {"STKTX", TYPC, 40, 0},
  {"STLAL", TYPC, 2, 0},
  {"STLAN", TYPC, 1, 0},
  {"STLBE", TYPC, 4, 0},
  {"STLST", TYPC, 2, 0},
  {"VMTNR", TYPC, 18, 0},
  {"WERKS", TYPC, 4, 0},
  {"ZTEXT", TYPC, 40, 0},
  {"REVLV", TYPC, 2, 0},
  {"TPLNR", TYPC, 30, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKTL", TYPC, 3, 0},
  {"DOKVR", TYPC, 2, 0},
  {"VBELN", TYPC, 10, 0},
  {"VBPOS", TYPNUM, 6, 0},
  {"STOBJ", TYPC, 18, 0},
  {"VDKNR", TYPC, 25, 0},
  {"VDKAR", TYPC, 3, 0},
  {"VDKTL", TYPC, 3, 0},
  {"VDKVR", TYPC, 2, 0},
  {"VEQNR", TYPC, 18, 0},
  {"VTPNR", TYPC, 30, 0},
  {"PSPNR", TYPC, 24, 0},
  {"OITXT", TYPC, 40, 0},
  {"MATNR_LONG", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CAD_BOM_ITEM
#define SAP_TH_CAD_BOM_ITEM
static RFC_TYPEHANDLE handleOfCAD_BOM_ITEM;

static RFC_TYPE_ELEMENT typeOfCAD_BOM_ITEM[] = {
  {"UPSKZ", TYPC, 1, 0},
  {"AUSKZ", TYPC, 1, 0},
  {"ALPOS", TYPC, 1, 0},
  {"AUSCH", TYPC, 6, 0},
  {"AVOAU", TYPC, 6, 0},
  {"BEIKZ", TYPC, 1, 0},
  {"CADPO", TYPC, 1, 0},
  {"EKGRP", TYPC, 3, 0},
  {"ERSKZ", TYPC, 1, 0},
  {"FMENG", TYPC, 1, 0},
  {"IDNRK", TYPC, 18, 0},
  {"LIFNR", TYPC, 10, 0},
  {"LIFZT", TYPC, 3, 0},
  {"MATKL", TYPC, 9, 0},
  {"MEINS", TYPC, 3, 0},
  {"MENGE", TYPC, 18, 0},
  {"NETAU", TYPC, 1, 0},
  {"NFMAT", TYPC, 18, 0},
  {"NLFZT", TYPC, 3, 0},
  {"PEINH", TYPC, 6, 0},
  {"POSNR", TYPC, 4, 0},
  {"POSTP", TYPC, 1, 0},
  {"PREIS", TYPC, 14, 0},
  {"POTX1", TYPC, 40, 0},
  {"POTX2", TYPC, 40, 0},
  {"PSWRK", TYPC, 4, 0},
  {"REKRS", TYPC, 1, 0},
  {"RFORM", TYPC, 2, 0},
  {"ROANZ", TYPC, 17, 0},
  {"ROAME", TYPC, 3, 0},
  {"ROKME", TYPC, 3, 0},
  {"ROMEI", TYPC, 3, 0},
  {"ROMEN", TYPC, 17, 0},
  {"ROMS1", TYPC, 17, 0},
  {"ROMS2", TYPC, 17, 0},
  {"ROMS3", TYPC, 17, 0},
  {"RVREL", TYPC, 1, 0},
  {"SAKTO", TYPC, 10, 0},
  {"SANFE", TYPC, 1, 0},
  {"SANIN", TYPC, 1, 0},
  {"SANKA", TYPC, 1, 0},
  {"SANKO", TYPC, 1, 0},
  {"SANVS", TYPC, 1, 0},
  {"SCHGT", TYPC, 1, 0},
  {"SELAL", TYPC, 2, 0},
  {"SELID", TYPC, 18, 0},
  {"SELPO", TYPC, 4, 0},
  {"SELSB", TYPC, 10, 0},
  {"SORTF", TYPC, 10, 0},
  {"STKKZ", TYPC, 1, 0},
  {"STKTX", TYPC, 40, 0},
  {"STLAL", TYPC, 2, 0},
  {"STLKZ", TYPC, 1, 0},
  {"VERTI", TYPC, 4, 0},
  {"WEBAZ", TYPC, 3, 0},
  {"WAERS", TYPC, 5, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKVR", TYPC, 2, 0},
  {"DOKTL", TYPC, 3, 0},
  {"EWAHR", TYPC, 3, 0},
  {"EKORG", TYPC, 4, 0},
  {"LGORT", TYPC, 4, 0},
  {"CLASS", TYPC, 18, 0},
  {"KLART", TYPC, 3, 0},
  {"POTPR", TYPC, 1, 0},
  {"ALPGR", TYPC, 2, 0},
  {"ALPST", TYPC, 1, 0},
  {"ALPRF", TYPNUM, 2, 0},
  {"DSPST", TYPC, 2, 0},
  {"PRVBE", TYPC, 10, 0},
  {"NFEAG", TYPC, 2, 0},
  {"NFGRP", TYPC, 2, 0},
  {"KZKUP", TYPC, 1, 0},
  {"INTRM", TYPC, 18, 0},
  {"KZCLB", TYPC, 1, 0},
  {"NLFZV", TYPC, 4, 0},
  {"NLFMV", TYPC, 3, 0},
  {"RFPNT", TYPC, 20, 0},
  {"MATNR_LONG", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CSSUBITEM
#define SAP_TH_CSSUBITEM
static RFC_TYPEHANDLE handleOfCSSUBITEM;

static RFC_TYPE_ELEMENT typeOfCSSUBITEM[] = {
  {"POSID", TYPC, 4, 0},
  {"EBORT", TYPC, 20, 0},
  {"UPMNG", TYPC, 17, 0},
  {"UPOSZ", TYPC, 4, 0},
  {"UPTXT", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CLS_CHARAC
#define SAP_TH_CLS_CHARAC
static RFC_TYPEHANDLE handleOfCLS_CHARAC;

static RFC_TYPE_ELEMENT typeOfCLS_CHARAC[] = {
  {"ATNAM", TYPC, 30, 0},
  {"ATBEZ", TYPC, 30, 0},
  {"ATWRT", TYPC, 30, 0},
  {"DINKB", TYPC, 3, 0},
  {"UNIT", TYPC, 6, 0},
 };
#endif

#ifndef SAP_TH_RFCDMSDATA
#define SAP_TH_RFCDMSDATA
static RFC_TYPEHANDLE handleOfRFCDMSDATA;

static RFC_TYPE_ELEMENT typeOfRFCDMSDATA[] = {
  {"FIELDMULTI", TYPC, 40, 0},
  {"FIELDNAME", TYPC, 35, 0},
  {"FIELDVALUE", TYPC, 255, 0},
 };
#endif

/* entries */




/*
------------------------------------------------------------------------

  Call function CSAP_MAT_BOM_MAINTAIN
      exporting
        ALTERNATIVE like CSAP_MBOM_STLAL  type RFC_CHAR length 2
        BOM_USAGE like CSAP_MBOM_STLAN  type RFC_CHAR length 1
        CHANGE_NO like CSAP_MBOM_AENNR  type RFC_CHAR length 12
        FL_BOM_CREATE like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_CAD like CSDATA_CHAR1 default SPACE type RFC_CHAR length 1
        FL_COMMIT_AND_WAIT like CAPIFLAG_COMM_WAIT default 'X' type RFC_CHAR length 1
        FL_COMPLETE like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_DEFAULT_VALUES like CSDATA_XFELD default 'X' type RFC_CHAR length 1
        FL_IDENTIFY_BY_GUID like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_NEW_ITEM like CSDATA_XFELD default SPACE type RFC_CHAR length 1
        FL_NO_CHANGE_DOC like CAPIFLAG_NO_CHG_DOC default SPACE type RFC_CHAR length 1
        I_STKO structure STKO_API01 length
161 number of fields 11
        MATERIAL like CSAP_MBOM_MATNR  type RFC_CHAR length 18
        PLANT like CSAP_MBOM_WERKS  type RFC_CHAR length 4
        REVISION_LEVEL like CSAP_MBOM_REVLV  type RFC_CHAR length 2
        VALID_FROM like CSAP_MBOM_DATUV  type RFC_CHAR length 10
      importing
        FL_WARNING like CAPIFLAG_FLWARNING type RFC_CHAR length 1
        O_STKO structure STKO_API02 length
258 number of fields 21
      tables
        T_DEP_DATA structure CSDEP_DAT length 116 number of fields 14
        T_DEP_DESCR structure CSDEP_DESC length 129 number of fields 11
        T_DEP_DOC structure CSDEP_DOC length 236 number of fields 12
        T_DEP_ORDER structure CSDEP_ORD length 99 number of fields 8
        T_DEP_SOURCE structure CSDEP_SORC length 171 number of fields 9
        T_DMU_TMX structure CSDMU_TMX length 168 number of fields 20
        T_DOC_LINK structure CSDOC_LINK length 256 number of fields 24
        T_LTX_LINE structure CSLTX_LINE length 169 number of fields 7
        T_STPO structure STPO_API03 length 745 number of fields 97
        T_STPU structure STPU_API01 length 108 number of fields 12
      exceptions
        ERROR

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_CSAP_MBOM_STLAL
#define SAP_FT_CSAP_MBOM_STLAL
typedef RFC_CHAR CSAP_MBOM_STLAL[2];
#endif

#ifndef SAP_FT_CSAP_MBOM_STLAN
#define SAP_FT_CSAP_MBOM_STLAN
typedef RFC_CHAR CSAP_MBOM_STLAN[1];
#endif

#ifndef SAP_FT_CSAP_MBOM_AENNR
#define SAP_FT_CSAP_MBOM_AENNR
typedef RFC_CHAR CSAP_MBOM_AENNR[12];
#endif

#ifndef SAP_FT_CSDATA_XFELD
#define SAP_FT_CSDATA_XFELD
typedef RFC_CHAR CSDATA_XFELD[1];
#endif

#ifndef SAP_FT_CSDATA_CHAR1
#define SAP_FT_CSDATA_CHAR1
typedef RFC_CHAR CSDATA_CHAR1[1];
#endif

#ifndef SAP_FT_CAPIFLAG_COMM_WAIT
#define SAP_FT_CAPIFLAG_COMM_WAIT
typedef RFC_CHAR CAPIFLAG_COMM_WAIT[1];
#endif

#ifndef SAP_FT_CAPIFLAG_NO_CHG_DOC
#define SAP_FT_CAPIFLAG_NO_CHG_DOC
typedef RFC_CHAR CAPIFLAG_NO_CHG_DOC[1];
#endif

#ifndef SAP_FT_CSAP_MBOM_MATNR
#define SAP_FT_CSAP_MBOM_MATNR
typedef RFC_CHAR CSAP_MBOM_MATNR[18];
#endif

#ifndef SAP_FT_CSAP_MBOM_WERKS
#define SAP_FT_CSAP_MBOM_WERKS
typedef RFC_CHAR CSAP_MBOM_WERKS[4];
#endif

#ifndef SAP_FT_CSAP_MBOM_REVLV
#define SAP_FT_CSAP_MBOM_REVLV
typedef RFC_CHAR CSAP_MBOM_REVLV[2];
#endif

#ifndef SAP_FT_CSAP_MBOM_DATUV
#define SAP_FT_CSAP_MBOM_DATUV
typedef RFC_CHAR CSAP_MBOM_DATUV[10];
#endif

#ifndef SAP_FT_CAPIFLAG_FLWARNING
#define SAP_FT_CAPIFLAG_FLWARNING
typedef RFC_CHAR CAPIFLAG_FLWARNING[1];
#endif

/* structure type definition */

#ifndef SAP_ST_STKO_API01
#define SAP_ST_STKO_API01
typedef struct {
  RFC_CHAR BaseQuan[17];
  RFC_CHAR BaseUnit[3];
  RFC_NUM BomStatus[2];
  RFC_CHAR AltText[40];
  RFC_CHAR Laboratory[3];
  RFC_CHAR DeleteInd[1];
  RFC_CHAR BomText[40];
  RFC_CHAR BomGroup[18];
  RFC_CHAR AuthGroup[4];
  RFC_CHAR CadInd[1];
  RFC_CHAR IdGuid[32];
 } STKO_API01;
#endif

#ifndef SAP_ST_STKO_API02
#define SAP_ST_STKO_API02
typedef struct {
  RFC_CHAR BaseQuan[17];
  RFC_CHAR BaseUnit[3];
  RFC_NUM BomStatus[2];
  RFC_CHAR AltText[40];
  RFC_CHAR Laboratory[3];
  RFC_CHAR DeleteInd[1];
  RFC_CHAR BomText[40];
  RFC_CHAR BomGroup[18];
  RFC_CHAR AuthGroup[4];
  RFC_CHAR CadInd[1];
  RFC_CHAR IdGuid[32];
  RFC_CHAR BomNo[8];
  RFC_CHAR AleInd[1];
  RFC_CHAR ValidTo[10];
  RFC_CHAR ChgNoTo[12];
  RFC_CHAR CreatedOn[10];
  RFC_CHAR CreatedBy[12];
  RFC_CHAR ChangedOn[10];
  RFC_CHAR ChangedBy[12];
  RFC_CHAR ValidFrom[10];
  RFC_CHAR ChgNo[12];
 } STKO_API02;
#endif

#ifndef SAP_ST_CSDEP_DAT
#define SAP_ST_CSDEP_DAT
typedef struct {
  RFC_CHAR ObjectId[1];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR DepIntern[30];
  RFC_CHAR DepExtern[30];
  RFC_CHAR DepType[4];
  RFC_CHAR DepType2[1];
  RFC_CHAR SceFlag[1];
  RFC_CHAR Status[1];
  RFC_CHAR Group[10];
  RFC_CHAR WhrToUse[3];
  RFC_CHAR Fldelete[1];
 } CSDEP_DAT;
#endif

#ifndef SAP_ST_CSDEP_DESC
#define SAP_ST_CSDEP_DESC
typedef struct {
  RFC_CHAR ObjectId[1];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR DepIntern[30];
  RFC_CHAR DepExtern[30];
  RFC_CHAR Language[1];
  RFC_CHAR Descript[30];
  RFC_CHAR Fldelete[1];
  RFC_CHAR LanguageIso[2];
 } CSDEP_DESC;
#endif

#ifndef SAP_ST_CSDEP_DOC
#define SAP_ST_CSDEP_DOC
typedef struct {
  RFC_CHAR ObjectId[1];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR DepIntern[30];
  RFC_CHAR DepExtern[30];
  RFC_CHAR Language[1];
  RFC_NUM LineNo[4];
  RFC_CHAR TxtForm[2];
  RFC_CHAR TxtLine[132];
  RFC_CHAR LanguageIso[2];
 } CSDEP_DOC;
#endif

#ifndef SAP_ST_CSDEP_ORD
#define SAP_ST_CSDEP_ORD
typedef struct {
  RFC_CHAR ObjectId[1];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR DepIntern[30];
  RFC_CHAR DepExtern[30];
  RFC_NUM DepLineno[4];
 } CSDEP_ORD;
#endif

#ifndef SAP_ST_CSDEP_SORC
#define SAP_ST_CSDEP_SORC
typedef struct {
  RFC_CHAR ObjectId[1];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR DepIntern[30];
  RFC_CHAR DepExtern[30];
  RFC_NUM LineNo[4];
  RFC_CHAR Line[72];
 } CSDEP_SORC;
#endif

#ifndef SAP_ST_CSDMU_TMX
#define SAP_ST_CSDMU_TMX
typedef struct {
  RFC_CHAR ObjectId[1];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR Mandt[3];
  RFC_BYTE Tmxguid[16];
  RFC_FLOAT Locox;
  RFC_FLOAT Locoy;
  RFC_FLOAT Locoz;
  RFC_FLOAT Axis1x;
  RFC_FLOAT Axis1y;
  RFC_FLOAT Axis1z;
  RFC_FLOAT Axis2x;
  RFC_FLOAT Axis2y;
  RFC_FLOAT Axis2z;
  RFC_FLOAT Axis3x;
  RFC_FLOAT Axis3y;
  RFC_FLOAT Axis3z;
  RFC_FLOAT Scale;
 } CSDMU_TMX;
#endif

#ifndef SAP_ST_CSDOC_LINK
#define SAP_ST_CSDOC_LINK
typedef struct {
  RFC_CHAR ObjectId[1];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR Mandt[3];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Doktl[3];
  RFC_CHAR Dokob[10];
  RFC_NUM Obzae[4];
  RFC_CHAR Objky[50];
  RFC_CHAR Vrkstat[1];
  RFC_CHAR Vrkstat1[2];
  RFC_CHAR Vobj[30];
  RFC_CHAR Vkey[50];
  RFC_CHAR Vdir[1];
  RFC_CHAR Viewflag[1];
  RFC_CHAR Delflag[1];
  RFC_CHAR LongtextId[32];
  RFC_CHAR CadPos[1];
  RFC_CHAR CmFixed[1];
  RFC_CHAR Fldelete[1];
 } CSDOC_LINK;
#endif

#ifndef SAP_ST_CSLTX_LINE
#define SAP_ST_CSLTX_LINE
typedef struct {
  RFC_CHAR ObjectId[1];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR Tdformat[2];
  RFC_CHAR Tdline[132];
 } CSLTX_LINE;
#endif

#ifndef SAP_ST_STPO_API03
#define SAP_ST_STPO_API03
typedef struct {
  RFC_CHAR ItemCateg[1];
  RFC_CHAR ItemNo[4];
  RFC_CHAR Component[18];
  RFC_CHAR CompQty[18];
  RFC_CHAR CompUnit[3];
  RFC_CHAR FixedQty[1];
  RFC_CHAR ItemText1[40];
  RFC_CHAR ItemText2[40];
  RFC_CHAR Sortstring[10];
  RFC_CHAR RelCost[1];
  RFC_CHAR RelEngin[1];
  RFC_CHAR RelPmaint[1];
  RFC_CHAR RelProd[1];
  RFC_CHAR RelSales[1];
  RFC_CHAR SparePart[1];
  RFC_CHAR MatProvis[1];
  RFC_CHAR BulkMat[1];
  RFC_CHAR RecAllowd[1];
  RFC_CHAR CompScrap[6];
  RFC_CHAR OpScrap[6];
  RFC_CHAR OpNetInd[1];
  RFC_CHAR DistrKey[4];
  RFC_CHAR ExplType[2];
  RFC_CHAR Spproctype[2];
  RFC_CHAR Supplyarea[10];
  RFC_CHAR IssueLoc[4];
  RFC_CHAR LeadTime[4];
  RFC_CHAR OpLeadTm[4];
  RFC_CHAR OpLtUnit[3];
  RFC_CHAR CoProduct[1];
  RFC_CHAR DisconGrp[2];
  RFC_CHAR FollowGrp[2];
  RFC_CHAR AiGroup[2];
  RFC_CHAR AiStrateg[1];
  RFC_CHAR AiPrio[2];
  RFC_CHAR UsageProb[3];
  RFC_CHAR Refpoint[20];
  RFC_CHAR PmAssmbly[1];
  RFC_CHAR CostElem[10];
  RFC_CHAR DelivTime[3];
  RFC_CHAR GrpTime[3];
  RFC_CHAR MatGroup[9];
  RFC_CHAR Price[14];
  RFC_CHAR PriceUnit[6];
  RFC_CHAR Currency[5];
  RFC_CHAR PurchGrp[3];
  RFC_CHAR PurchOrg[4];
  RFC_CHAR Vendor[10];
  RFC_CHAR VsiNo[17];
  RFC_CHAR VsiQty[17];
  RFC_CHAR VsiSize1[17];
  RFC_CHAR VsiSize2[17];
  RFC_CHAR VsiSize3[17];
  RFC_CHAR VsiSzunit[3];
  RFC_CHAR VsiFormul[2];
  RFC_CHAR Document[25];
  RFC_CHAR DocType[3];
  RFC_CHAR DocPart[3];
  RFC_CHAR DocVers[2];
  RFC_CHAR Class[18];
  RFC_CHAR ClassType[3];
  RFC_CHAR ResItmCt[1];
  RFC_CHAR SelCond[1];
  RFC_CHAR ReqdComp[1];
  RFC_CHAR MultSelec[1];
  RFC_CHAR RelHlconf[1];
  RFC_CHAR CadInd[1];
  RFC_CHAR ItmIdent[8];
  RFC_CHAR ItemGuid[32];
  RFC_CHAR ValidFrom[10];
  RFC_CHAR ChangeNo[12];
  RFC_CHAR Identifier[10];
  RFC_CHAR BomNo[8];
  RFC_NUM ItemNode[8];
  RFC_NUM ItemCount[8];
  RFC_CHAR Recursive[1];
  RFC_NUM DepLink[18];
  RFC_CHAR AleInd[1];
  RFC_CHAR ValidTo[10];
  RFC_CHAR ChgNoTo[12];
  RFC_CHAR CreatedOn[10];
  RFC_CHAR CreatedBy[12];
  RFC_CHAR ChangedOn[10];
  RFC_CHAR ChangedBy[12];
  RFC_CHAR BomAlt[2];
  RFC_CHAR Fldelete[1];
  RFC_CHAR IdItmCtg[1];
  RFC_CHAR IdItemNo[4];
  RFC_CHAR IdComp[18];
  RFC_CHAR IdClass[18];
  RFC_CHAR IdClType[3];
  RFC_CHAR IdDoc[25];
  RFC_CHAR IdDocTyp[3];
  RFC_CHAR IdDocPrt[3];
  RFC_CHAR IdDocVrs[2];
  RFC_CHAR IdSort[10];
  RFC_CHAR IdGuid[32];
 } STPO_API03;
#endif

#ifndef SAP_ST_STPU_API01
#define SAP_ST_STPU_API01
typedef struct {
  RFC_INT Pointer;
  RFC_CHAR Mandt[3];
  RFC_CHAR Stlty[1];
  RFC_CHAR Stlnr[8];
  RFC_NUM Stlkn[8];
  RFC_NUM Stpoz[8];
  RFC_CHAR Uposz[4];
  RFC_BCD Upmng[7];
  RFC_CHAR Ebort[20];
  RFC_CHAR Uptxt[40];
  RFC_CHAR Vbkz[1];
  RFC_CHAR Selkz[1];
 } STPU_API01;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_STKO_API01
#define SAP_TH_STKO_API01
static RFC_TYPEHANDLE handleOfSTKO_API01;

static RFC_TYPE_ELEMENT typeOfSTKO_API01[] = {
  {"BASE_QUAN", TYPC, 17, 0},
  {"BASE_UNIT", TYPC, 3, 0},
  {"BOM_STATUS", TYPNUM, 2, 0},
  {"ALT_TEXT", TYPC, 40, 0},
  {"LABORATORY", TYPC, 3, 0},
  {"DELETE_IND", TYPC, 1, 0},
  {"BOM_TEXT", TYPC, 40, 0},
  {"BOM_GROUP", TYPC, 18, 0},
  {"AUTH_GROUP", TYPC, 4, 0},
  {"CAD_IND", TYPC, 1, 0},
  {"ID_GUID", TYPC, 32, 0},
 };
#endif

#ifndef SAP_TH_STKO_API02
#define SAP_TH_STKO_API02
static RFC_TYPEHANDLE handleOfSTKO_API02;

static RFC_TYPE_ELEMENT typeOfSTKO_API02[] = {
  {"BASE_QUAN", TYPC, 17, 0},
  {"BASE_UNIT", TYPC, 3, 0},
  {"BOM_STATUS", TYPNUM, 2, 0},
  {"ALT_TEXT", TYPC, 40, 0},
  {"LABORATORY", TYPC, 3, 0},
  {"DELETE_IND", TYPC, 1, 0},
  {"BOM_TEXT", TYPC, 40, 0},
  {"BOM_GROUP", TYPC, 18, 0},
  {"AUTH_GROUP", TYPC, 4, 0},
  {"CAD_IND", TYPC, 1, 0},
  {"ID_GUID", TYPC, 32, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ALE_IND", TYPC, 1, 0},
  {"VALID_TO", TYPC, 10, 0},
  {"CHG_NO_TO", TYPC, 12, 0},
  {"CREATED_ON", TYPC, 10, 0},
  {"CREATED_BY", TYPC, 12, 0},
  {"CHANGED_ON", TYPC, 10, 0},
  {"CHANGED_BY", TYPC, 12, 0},
  {"VALID_FROM", TYPC, 10, 0},
  {"CHG_NO", TYPC, 12, 0},
 };
#endif

#ifndef SAP_TH_CSDEP_DAT
#define SAP_TH_CSDEP_DAT
static RFC_TYPEHANDLE handleOfCSDEP_DAT;

static RFC_TYPE_ELEMENT typeOfCSDEP_DAT[] = {
  {"OBJECT_ID", TYPC, 1, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"DEP_INTERN", TYPC, 30, 0},
  {"DEP_EXTERN", TYPC, 30, 0},
  {"DEP_TYPE", TYPC, 4, 0},
  {"DEP_TYPE2", TYPC, 1, 0},
  {"SCE_FLAG", TYPC, 1, 0},
  {"STATUS", TYPC, 1, 0},
  {"GROUP", TYPC, 10, 0},
  {"WHR_TO_USE", TYPC, 3, 0},
  {"FLDELETE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_CSDEP_DESC
#define SAP_TH_CSDEP_DESC
static RFC_TYPEHANDLE handleOfCSDEP_DESC;

static RFC_TYPE_ELEMENT typeOfCSDEP_DESC[] = {
  {"OBJECT_ID", TYPC, 1, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"DEP_INTERN", TYPC, 30, 0},
  {"DEP_EXTERN", TYPC, 30, 0},
  {"LANGUAGE", TYPC, 1, 0},
  {"DESCRIPT", TYPC, 30, 0},
  {"FLDELETE", TYPC, 1, 0},
  {"LANGUAGE_ISO", TYPC, 2, 0},
 };
#endif

#ifndef SAP_TH_CSDEP_DOC
#define SAP_TH_CSDEP_DOC
static RFC_TYPEHANDLE handleOfCSDEP_DOC;

static RFC_TYPE_ELEMENT typeOfCSDEP_DOC[] = {
  {"OBJECT_ID", TYPC, 1, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"DEP_INTERN", TYPC, 30, 0},
  {"DEP_EXTERN", TYPC, 30, 0},
  {"LANGUAGE", TYPC, 1, 0},
  {"LINE_NO", TYPNUM, 4, 0},
  {"TXT_FORM", TYPC, 2, 0},
  {"TXT_LINE", TYPC, 132, 0},
  {"LANGUAGE_ISO", TYPC, 2, 0},
 };
#endif

#ifndef SAP_TH_CSDEP_ORD
#define SAP_TH_CSDEP_ORD
static RFC_TYPEHANDLE handleOfCSDEP_ORD;

static RFC_TYPE_ELEMENT typeOfCSDEP_ORD[] = {
  {"OBJECT_ID", TYPC, 1, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"DEP_INTERN", TYPC, 30, 0},
  {"DEP_EXTERN", TYPC, 30, 0},
  {"DEP_LINENO", TYPNUM, 4, 0},
 };
#endif

#ifndef SAP_TH_CSDEP_SORC
#define SAP_TH_CSDEP_SORC
static RFC_TYPEHANDLE handleOfCSDEP_SORC;

static RFC_TYPE_ELEMENT typeOfCSDEP_SORC[] = {
  {"OBJECT_ID", TYPC, 1, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"DEP_INTERN", TYPC, 30, 0},
  {"DEP_EXTERN", TYPC, 30, 0},
  {"LINE_NO", TYPNUM, 4, 0},
  {"LINE", TYPC, 72, 0},
 };
#endif

#ifndef SAP_TH_CSDMU_TMX
#define SAP_TH_CSDMU_TMX
static RFC_TYPEHANDLE handleOfCSDMU_TMX;

static RFC_TYPE_ELEMENT typeOfCSDMU_TMX[] = {
  {"OBJECT_ID", TYPC, 1, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"MANDT", TYPC, 3, 0},
  {"TMXGUID", TYPX, 16, 0},
  {"LOCOX", TYPFLOAT, sizeof(double), 0},
  {"LOCOY", TYPFLOAT, sizeof(double), 0},
  {"LOCOZ", TYPFLOAT, sizeof(double), 0},
  {"AXIS1X", TYPFLOAT, sizeof(double), 0},
  {"AXIS1Y", TYPFLOAT, sizeof(double), 0},
  {"AXIS1Z", TYPFLOAT, sizeof(double), 0},
  {"AXIS2X", TYPFLOAT, sizeof(double), 0},
  {"AXIS2Y", TYPFLOAT, sizeof(double), 0},
  {"AXIS2Z", TYPFLOAT, sizeof(double), 0},
  {"AXIS3X", TYPFLOAT, sizeof(double), 0},
  {"AXIS3Y", TYPFLOAT, sizeof(double), 0},
  {"AXIS3Z", TYPFLOAT, sizeof(double), 0},
  {"SCALE", TYPFLOAT, sizeof(double), 0},
 };
#endif

#ifndef SAP_TH_CSDOC_LINK
#define SAP_TH_CSDOC_LINK
static RFC_TYPEHANDLE handleOfCSDOC_LINK;

static RFC_TYPE_ELEMENT typeOfCSDOC_LINK[] = {
  {"OBJECT_ID", TYPC, 1, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"MANDT", TYPC, 3, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKVR", TYPC, 2, 0},
  {"DOKTL", TYPC, 3, 0},
  {"DOKOB", TYPC, 10, 0},
  {"OBZAE", TYPNUM, 4, 0},
  {"OBJKY", TYPC, 50, 0},
  {"VRKSTAT", TYPC, 1, 0},
  {"VRKSTAT1", TYPC, 2, 0},
  {"VOBJ", TYPC, 30, 0},
  {"VKEY", TYPC, 50, 0},
  {"VDIR", TYPC, 1, 0},
  {"VIEWFLAG", TYPC, 1, 0},
  {"DELFLAG", TYPC, 1, 0},
  {"LONGTEXT_ID", TYPC, 32, 0},
  {"CAD_POS", TYPC, 1, 0},
  {"CM_FIXED", TYPC, 1, 0},
  {"FLDELETE", TYPC, 1, 0},
 };
#endif

#ifndef SAP_TH_CSLTX_LINE
#define SAP_TH_CSLTX_LINE
static RFC_TYPEHANDLE handleOfCSLTX_LINE;

static RFC_TYPE_ELEMENT typeOfCSLTX_LINE[] = {
  {"OBJECT_ID", TYPC, 1, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"TDFORMAT", TYPC, 2, 0},
  {"TDLINE", TYPC, 132, 0},
 };
#endif

#ifndef SAP_TH_STPO_API03
#define SAP_TH_STPO_API03
static RFC_TYPEHANDLE handleOfSTPO_API03;

static RFC_TYPE_ELEMENT typeOfSTPO_API03[] = {
  {"ITEM_CATEG", TYPC, 1, 0},
  {"ITEM_NO", TYPC, 4, 0},
  {"COMPONENT", TYPC, 18, 0},
  {"COMP_QTY", TYPC, 18, 0},
  {"COMP_UNIT", TYPC, 3, 0},
  {"FIXED_QTY", TYPC, 1, 0},
  {"ITEM_TEXT1", TYPC, 40, 0},
  {"ITEM_TEXT2", TYPC, 40, 0},
  {"SORTSTRING", TYPC, 10, 0},
  {"REL_COST", TYPC, 1, 0},
  {"REL_ENGIN", TYPC, 1, 0},
  {"REL_PMAINT", TYPC, 1, 0},
  {"REL_PROD", TYPC, 1, 0},
  {"REL_SALES", TYPC, 1, 0},
  {"SPARE_PART", TYPC, 1, 0},
  {"MAT_PROVIS", TYPC, 1, 0},
  {"BULK_MAT", TYPC, 1, 0},
  {"REC_ALLOWD", TYPC, 1, 0},
  {"COMP_SCRAP", TYPC, 6, 0},
  {"OP_SCRAP", TYPC, 6, 0},
  {"OP_NET_IND", TYPC, 1, 0},
  {"DISTR_KEY", TYPC, 4, 0},
  {"EXPL_TYPE", TYPC, 2, 0},
  {"SPPROCTYPE", TYPC, 2, 0},
  {"SUPPLYAREA", TYPC, 10, 0},
  {"ISSUE_LOC", TYPC, 4, 0},
  {"LEAD_TIME", TYPC, 4, 0},
  {"OP_LEAD_TM", TYPC, 4, 0},
  {"OP_LT_UNIT", TYPC, 3, 0},
  {"CO_PRODUCT", TYPC, 1, 0},
  {"DISCON_GRP", TYPC, 2, 0},
  {"FOLLOW_GRP", TYPC, 2, 0},
  {"AI_GROUP", TYPC, 2, 0},
  {"AI_STRATEG", TYPC, 1, 0},
  {"AI_PRIO", TYPC, 2, 0},
  {"USAGE_PROB", TYPC, 3, 0},
  {"REFPOINT", TYPC, 20, 0},
  {"PM_ASSMBLY", TYPC, 1, 0},
  {"COST_ELEM", TYPC, 10, 0},
  {"DELIV_TIME", TYPC, 3, 0},
  {"GRP_TIME", TYPC, 3, 0},
  {"MAT_GROUP", TYPC, 9, 0},
  {"PRICE", TYPC, 14, 0},
  {"PRICE_UNIT", TYPC, 6, 0},
  {"CURRENCY", TYPC, 5, 0},
  {"PURCH_GRP", TYPC, 3, 0},
  {"PURCH_ORG", TYPC, 4, 0},
  {"VENDOR", TYPC, 10, 0},
  {"VSI_NO", TYPC, 17, 0},
  {"VSI_QTY", TYPC, 17, 0},
  {"VSI_SIZE1", TYPC, 17, 0},
  {"VSI_SIZE2", TYPC, 17, 0},
  {"VSI_SIZE3", TYPC, 17, 0},
  {"VSI_SZUNIT", TYPC, 3, 0},
  {"VSI_FORMUL", TYPC, 2, 0},
  {"DOCUMENT", TYPC, 25, 0},
  {"DOC_TYPE", TYPC, 3, 0},
  {"DOC_PART", TYPC, 3, 0},
  {"DOC_VERS", TYPC, 2, 0},
  {"CLASS", TYPC, 18, 0},
  {"CLASS_TYPE", TYPC, 3, 0},
  {"RES_ITM_CT", TYPC, 1, 0},
  {"SEL_COND", TYPC, 1, 0},
  {"REQD_COMP", TYPC, 1, 0},
  {"MULT_SELEC", TYPC, 1, 0},
  {"REL_HLCONF", TYPC, 1, 0},
  {"CAD_IND", TYPC, 1, 0},
  {"ITM_IDENT", TYPC, 8, 0},
  {"ITEM_GUID", TYPC, 32, 0},
  {"VALID_FROM", TYPC, 10, 0},
  {"CHANGE_NO", TYPC, 12, 0},
  {"IDENTIFIER", TYPC, 10, 0},
  {"BOM_NO", TYPC, 8, 0},
  {"ITEM_NODE", TYPNUM, 8, 0},
  {"ITEM_COUNT", TYPNUM, 8, 0},
  {"RECURSIVE", TYPC, 1, 0},
  {"DEP_LINK", TYPNUM, 18, 0},
  {"ALE_IND", TYPC, 1, 0},
  {"VALID_TO", TYPC, 10, 0},
  {"CHG_NO_TO", TYPC, 12, 0},
  {"CREATED_ON", TYPC, 10, 0},
  {"CREATED_BY", TYPC, 12, 0},
  {"CHANGED_ON", TYPC, 10, 0},
  {"CHANGED_BY", TYPC, 12, 0},
  {"BOM_ALT", TYPC, 2, 0},
  {"FLDELETE", TYPC, 1, 0},
  {"ID_ITM_CTG", TYPC, 1, 0},
  {"ID_ITEM_NO", TYPC, 4, 0},
  {"ID_COMP", TYPC, 18, 0},
  {"ID_CLASS", TYPC, 18, 0},
  {"ID_CL_TYPE", TYPC, 3, 0},
  {"ID_DOC", TYPC, 25, 0},
  {"ID_DOC_TYP", TYPC, 3, 0},
  {"ID_DOC_PRT", TYPC, 3, 0},
  {"ID_DOC_VRS", TYPC, 2, 0},
  {"ID_SORT", TYPC, 10, 0},
  {"ID_GUID", TYPC, 32, 0},
 };
#endif

#ifndef SAP_TH_STPU_API01
#define SAP_TH_STPU_API01
static RFC_TYPEHANDLE handleOfSTPU_API01;

static RFC_TYPE_ELEMENT typeOfSTPU_API01[] = {
  {"POINTER", TYPINT, sizeof(RFC_INT), 0},
  {"MANDT", TYPC, 3, 0},
  {"STLTY", TYPC, 1, 0},
  {"STLNR", TYPC, 8, 0},
  {"STLKN", TYPNUM, 8, 0},
  {"STPOZ", TYPNUM, 8, 0},
  {"UPOSZ", TYPC, 4, 0},
  {"UPMNG", TYPP, 7, 0},
  {"EBORT", TYPC, 20, 0},
  {"UPTXT", TYPC, 40, 0},
  {"VBKZ", TYPC, 1, 0},
  {"SELKZ", TYPC, 1, 0},
 };
#endif



/*
------------------------------------------------------------------------

  Call function RFC_CALL_TRANSACTION_USING
      exporting
        MODE like SYST_BATCH default 'N' type RFC_CHAR length 1
        TCODE like SYST_TCODE default 'SE38' type RFC_CHAR length 20
      importing
        SUBRC like SYST_SUBRC type RFC_INT length 4
      tables
        BT_DATA structure BDCDATA length 309
number of fields 5
        L_ERRORS structure BDCMSGCOLL length 625 number of fields 13
      exceptions
        AUTHORITY_NOT_AVAILABLE

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_SYST_BATCH
#define SAP_FT_SYST_BATCH
typedef RFC_CHAR SYST_BATCH[1];
#endif

#ifndef SAP_FT_SYST_TCODE
#define SAP_FT_SYST_TCODE
typedef RFC_CHAR SYST_TCODE[20];
#endif

#ifndef SAP_FT_SYST_SUBRC
#define SAP_FT_SYST_SUBRC
typedef RFC_INT SYST_SUBRC;
#endif

/* structure type definition */

#ifndef SAP_ST_BDCDATA
#define SAP_ST_BDCDATA
typedef struct {
  RFC_CHAR Program[40];
  RFC_NUM Dynpro[4];
  RFC_CHAR Dynbegin[1];
  RFC_CHAR Fnam[132];
  RFC_CHAR Fval[132];
 } BDCDATA;
#endif

#ifndef SAP_ST_BDCMSGCOLL
#define SAP_ST_BDCMSGCOLL
typedef struct {
  RFC_CHAR Tcode[20];
  RFC_CHAR Dyname[40];
  RFC_CHAR Dynumb[4];
  RFC_CHAR Msgtyp[1];
  RFC_CHAR Msgspra[1];
  RFC_CHAR Msgid[20];
  RFC_CHAR Msgnr[3];
  RFC_CHAR Msgv1[100];
  RFC_CHAR Msgv2[100];
  RFC_CHAR Msgv3[100];
  RFC_CHAR Msgv4[100];
  RFC_CHAR Env[4];
  RFC_CHAR Fldname[132];
 } BDCMSGCOLL;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_BDCDATA
#define SAP_TH_BDCDATA
static RFC_TYPEHANDLE handleOfBDCDATA;

static RFC_TYPE_ELEMENT typeOfBDCDATA[] = {
  {"PROGRAM", TYPC, 40, 0},
  {"DYNPRO", TYPNUM, 4, 0},
  {"DYNBEGIN", TYPC, 1, 0},
  {"FNAM", TYPC, 132, 0},
  {"FVAL", TYPC, 132, 0},
 };
#endif

#ifndef SAP_TH_BDCMSGCOLL
#define SAP_TH_BDCMSGCOLL
static RFC_TYPEHANDLE handleOfBDCMSGCOLL;

static RFC_TYPE_ELEMENT typeOfBDCMSGCOLL[] = {
  {"TCODE", TYPC, 20, 0},
  {"DYNAME", TYPC, 40, 0},
  {"DYNUMB", TYPC, 4, 0},
  {"MSGTYP", TYPC, 1, 0},
  {"MSGSPRA", TYPC, 1, 0},
  {"MSGID", TYPC, 20, 0},
  {"MSGNR", TYPC, 3, 0},
  {"MSGV1", TYPC, 100, 0},
  {"MSGV2", TYPC, 100, 0},
  {"MSGV3", TYPC, 100, 0},
  {"MSGV4", TYPC, 100, 0},
  {"ENV", TYPC, 4, 0},
  {"FLDNAME", TYPC, 132, 0},
 };
#endif


/*
------------------------------------------------------------------------

  Call function CCAP_ECN_HEADER_READ
      exporting
        CHANGE_NO like CCAPI_CHANGE_NO  type RFC_CHAR length 12
      importing
        CHANGE_HEADER structure AENR_API02 length
212 number of fields 22
      tables
      exceptions
        ERROR
        NO_RECORD_FOUND

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_CCAPI_CHANGE_NO
#define SAP_FT_CCAPI_CHANGE_NO
typedef RFC_CHAR CCAPI_CHANGE_NO[12];
#endif

/* structure type definition */

#ifndef SAP_ST_AENR_API02
#define SAP_ST_AENR_API02
typedef struct {
  RFC_CHAR ChangeNo[12];
  RFC_NUM Status[2];
  RFC_CHAR AuthGroup[4];
  RFC_CHAR ValidFrom[10];
  RFC_CHAR Descript[40];
  RFC_CHAR ReasonChg[40];
  RFC_CHAR CreatedOn[10];
  RFC_CHAR CreatedBy[12];
  RFC_CHAR ChangedOn[10];
  RFC_CHAR ChangedBy[12];
  RFC_CHAR DeletionMark[1];
  RFC_CHAR IndateRule[10];
  RFC_CHAR OutdateRule[10];
  RFC_CHAR Function[1];
  RFC_CHAR EffectivityType[10];
  RFC_CHAR OverridingMark[1];
  RFC_NUM Rank[2];
  RFC_NUM ReleaseKey[2];
  RFC_DATE ReleaseKeyChgdate;
  RFC_TIME ReleaseKeyChgtime;
  RFC_CHAR StatusProfile[8];
  RFC_CHAR TechRel[1];
 } AENR_API02;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_AENR_API02
#define SAP_TH_AENR_API02
static RFC_TYPEHANDLE handleOfAENR_API02;

static RFC_TYPE_ELEMENT typeOfAENR_API02[] = {
  {"CHANGE_NO", TYPC, 12, 0},
  {"STATUS", TYPNUM, 2, 0},
  {"AUTH_GROUP", TYPC, 4, 0},
  {"VALID_FROM", TYPC, 10, 0},
  {"DESCRIPT", TYPC, 40, 0},
  {"REASON_CHG", TYPC, 40, 0},
  {"CREATED_ON", TYPC, 10, 0},
  {"CREATED_BY", TYPC, 12, 0},
  {"CHANGED_ON", TYPC, 10, 0},
  {"CHANGED_BY", TYPC, 12, 0},
  {"DELETION_MARK", TYPC, 1, 0},
  {"INDATE_RULE", TYPC, 10, 0},
  {"OUTDATE_RULE", TYPC, 10, 0},
  {"FUNCTION", TYPC, 1, 0},
  {"EFFECTIVITY_TYPE", TYPC, 10, 0},
  {"OVERRIDING_MARK", TYPC, 1, 0},
  {"RANK", TYPNUM, 2, 0},
  {"RELEASE_KEY", TYPNUM, 2, 0},
  {"RELEASE_KEY_CHGDATE", TYPDATE, sizeof(RFC_DATE), 0},
  {"RELEASE_KEY_CHGTIME", TYPTIME, sizeof(RFC_TIME), 0},
  {"STATUS_PROFILE", TYPC, 8, 0},
  {"TECH_REL", TYPC, 1, 0},
 };
#endif


/*
------------------------------------------------------------------------

  Call function RFC_SYSTEM_INFO
      exporting
      importing
        CURRENT_RESOURCES like SYST_INDEX type RFC_INT length 4
        DIALOG_USER_TYPE like SYST_DEBUG type RFC_CHAR length 1
        MAXIMAL_RESOURCES like SYST_INDEX type RFC_INT length 4
        RECOMMENDED_DELAY like SYST_INDEX type RFC_INT length 4
        RFCSI_EXPORT structure RFCSI length
200 number of fields 19
        RFC_LOGIN_COMPLETE like SYST_DEBUG type RFC_CHAR length 1
      tables
      exceptions

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_SYST_INDEX
#define SAP_FT_SYST_INDEX
typedef RFC_INT SYST_INDEX;
#endif

#ifndef SAP_FT_SYST_DEBUG
#define SAP_FT_SYST_DEBUG
typedef RFC_CHAR SYST_DEBUG[1];
#endif

/* structure type definition */

#ifndef SAP_ST_RFCSI
#define SAP_ST_RFCSI
typedef struct {
  RFC_CHAR Rfcproto[3];
  RFC_CHAR Rfcchartyp[4];
  RFC_CHAR Rfcinttyp[3];
  RFC_CHAR Rfcflotyp[3];
  RFC_CHAR Rfcdest[32];
  RFC_CHAR Rfchost[8];
  RFC_CHAR Rfcsysid[8];
  RFC_CHAR Rfcdatabs[8];
  RFC_CHAR Rfcdbhost[32];
  RFC_CHAR Rfcdbsys[10];
  RFC_CHAR Rfcsaprl[4];
  RFC_CHAR Rfcmach[5];
  RFC_CHAR Rfcopsys[10];
  RFC_CHAR Rfctzone[6];
  RFC_CHAR Rfcdayst[1];
  RFC_CHAR Rfcipaddr[15];
  RFC_CHAR Rfckernrl[4];
  RFC_CHAR Rfchost2[32];
  RFC_CHAR RfcsiResv[12];
 } RFCSI;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_RFCSI
#define SAP_TH_RFCSI
static RFC_TYPEHANDLE handleOfRFCSI;

static RFC_TYPE_ELEMENT typeOfRFCSI[] = {
  {"RFCPROTO", TYPC, 3, 0},
  {"RFCCHARTYP", TYPC, 4, 0},
  {"RFCINTTYP", TYPC, 3, 0},
  {"RFCFLOTYP", TYPC, 3, 0},
  {"RFCDEST", TYPC, 32, 0},
  {"RFCHOST", TYPC, 8, 0},
  {"RFCSYSID", TYPC, 8, 0},
  {"RFCDATABS", TYPC, 8, 0},
  {"RFCDBHOST", TYPC, 32, 0},
  {"RFCDBSYS", TYPC, 10, 0},
  {"RFCSAPRL", TYPC, 4, 0},
  {"RFCMACH", TYPC, 5, 0},
  {"RFCOPSYS", TYPC, 10, 0},
  {"RFCTZONE", TYPC, 6, 0},
  {"RFCDAYST", TYPC, 1, 0},
  {"RFCIPADDR", TYPC, 15, 0},
  {"RFCKERNRL", TYPC, 4, 0},
  {"RFCHOST2", TYPC, 32, 0},
  {"RFCSI_RESV", TYPC, 12, 0},
 };
#endif


/*
------------------------------------------------------------------------

  Call function ZRFC_PRODUCTGROUP_MAINTAIN
      exporting
        PROD_DESC structure MAKTX length 40 number of fields 1
        PROD_GROUP structure MATNR length 18 number of fields 1
        WERKS structure WERKS_D length 4 number of fields 1
      importing
        MESSG structure MESSAGEINF length 280 number of fields 5
        RETVAL like SYST_SUBRC type RFC_INT length 4
      tables
        ERR_MATNR structure ZMATNR_RFC_PRODGRP length 19
number of fields 2
        MATNR structure ZMATNR_RFC_PRODGRP length 19 number of fields 2
      exceptions

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_SYST_SUBRC
#define SAP_FT_SYST_SUBRC
typedef RFC_INT SYST_SUBRC;
#endif

/* structure type definition */

#ifndef SAP_ST_MAKTX
#define SAP_ST_MAKTX
typedef struct {
  RFC_CHAR Maktx[40];
 } MAKTX;
#endif

#ifndef SAP_ST_MATNR
#define SAP_ST_MATNR
typedef struct {
  RFC_CHAR Matnr[18];
 } MATNR;
#endif

#ifndef SAP_ST_WERKS_D
#define SAP_ST_WERKS_D
typedef struct {
  RFC_CHAR WerksD[4];
 } WERKS_D;
#endif

#ifndef SAP_ST_MESSAGEINF
#define SAP_ST_MESSAGEINF
typedef struct {
  RFC_CHAR Msgty[1];
  RFC_CHAR Msgid[20];
  RFC_CHAR Msgno[3];
  RFC_CHAR Msspc[1];
  RFC_CHAR Msgtx[255];
 } MESSAGEINF;
#endif

#ifndef SAP_ST_ZMATNR_RFC_PRODGRP
#define SAP_ST_ZMATNR_RFC_PRODGRP
typedef struct {
  RFC_CHAR Matnr[18];
  RFC_CHAR Updopt[1];
 } ZMATNR_RFC_PRODGRP;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_MAKTX
#define SAP_TH_MAKTX
static RFC_TYPEHANDLE handleOfMAKTX;

static RFC_TYPE_ELEMENT typeOfMAKTX[] = {
  {"MAKTX", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_MATNR
#define SAP_TH_MATNR
static RFC_TYPEHANDLE handleOfMATNR;

static RFC_TYPE_ELEMENT typeOfMATNR[] = {
  {"MATNR", TYPC, 18, 0},
 };
#endif

#ifndef SAP_TH_WERKS_D
#define SAP_TH_WERKS_D
static RFC_TYPEHANDLE handleOfWERKS_D;

static RFC_TYPE_ELEMENT typeOfWERKS_D[] = {
  {"WERKS_D", TYPC, 4, 0},
 };
#endif

#ifndef SAP_TH_MESSAGEINF
#define SAP_TH_MESSAGEINF
static RFC_TYPEHANDLE handleOfMESSAGEINF;

static RFC_TYPE_ELEMENT typeOfMESSAGEINF[] = {
  {"MSGTY", TYPC, 1, 0},
  {"MSGID", TYPC, 20, 0},
  {"MSGNO", TYPC, 3, 0},
  {"MSSPC", TYPC, 1, 0},
  {"MSGTX", TYPC, 255, 0},
 };
#endif

#ifndef SAP_TH_ZMATNR_RFC_PRODGRP
#define SAP_TH_ZMATNR_RFC_PRODGRP
static RFC_TYPEHANDLE handleOfZMATNR_RFC_PRODGRP;

static RFC_TYPE_ELEMENT typeOfZMATNR_RFC_PRODGRP[] = {
  {"MATNR", TYPC, 18, 0},
  {"UPDOPT", TYPC, 1, 0},
 };
#endif



/*
------------------------------------------------------------------------

  Call function BAPI_ROUTING_EXISTENCE_CHECK
      exporting
        GROUP like BAPI1012_TSK_C_TASK_LIST_GROUP  type RFC_CHAR length 8
        GROUPCOUNTER like BAPI1012_TSK_C_GROUP_COUNTER  type RFC_CHAR length 2
        VALIDFROM like BAPI1012_TSK_C_VALID_FROM  type RFC_DATE length 8
        VALIDTODATE like BAPI1012_TSK_C_VALID_TO_DATE  type RFC_DATE length 8
      importing
      tables
        RETURN structure BAPIRET2 length 548
number of fields 14
      exceptions

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_BAPI1012_TSK_C_TASK_LIST_GROUP
#define SAP_FT_BAPI1012_TSK_C_TASK_LIST_GROUP
typedef RFC_CHAR BAPI1012_TSK_C_TASK_LIST_GROUP[8];
#endif

#ifndef SAP_FT_BAPI1012_TSK_C_GROUP_COUNTER
#define SAP_FT_BAPI1012_TSK_C_GROUP_COUNTER
typedef RFC_CHAR BAPI1012_TSK_C_GROUP_COUNTER[2];
#endif

#ifndef SAP_FT_BAPI1012_TSK_C_VALID_FROM
#define SAP_FT_BAPI1012_TSK_C_VALID_FROM
typedef RFC_DATE BAPI1012_TSK_C_VALID_FROM;
#endif

#ifndef SAP_FT_BAPI1012_TSK_C_VALID_TO_DATE
#define SAP_FT_BAPI1012_TSK_C_VALID_TO_DATE
typedef RFC_DATE BAPI1012_TSK_C_VALID_TO_DATE;
#endif

/* structure type definition */

#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct {
  RFC_CHAR Type[1];
  RFC_CHAR Id[20];
  RFC_NUM Number[3];
  RFC_CHAR Message[220];
  RFC_CHAR LogNo[20];
  RFC_NUM LogMsgNo[6];
  RFC_CHAR MessageV1[50];
  RFC_CHAR MessageV2[50];
  RFC_CHAR MessageV3[50];
  RFC_CHAR MessageV4[50];
  RFC_CHAR Parameter[32];
  RFC_INT Row;
  RFC_CHAR Field[30];
  RFC_CHAR System[10];
 } BAPIRET2;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static RFC_TYPEHANDLE handleOfBAPIRET2;

static RFC_TYPE_ELEMENT typeOfBAPIRET2[] = {
  {"TYPE", TYPC, 1, 0},
  {"ID", TYPC, 20, 0},
  {"NUMBER", TYPNUM, 3, 0},
  {"MESSAGE", TYPC, 220, 0},
  {"LOG_NO", TYPC, 20, 0},
  {"LOG_MSG_NO", TYPNUM, 6, 0},
  {"MESSAGE_V1", TYPC, 50, 0},
  {"MESSAGE_V2", TYPC, 50, 0},
  {"MESSAGE_V3", TYPC, 50, 0},
  {"MESSAGE_V4", TYPC, 50, 0},
  {"PARAMETER", TYPC, 32, 0},
  {"ROW", TYPINT, sizeof(RFC_INT), 0},
  {"FIELD", TYPC, 30, 0},
  {"SYSTEM", TYPC, 10, 0},
 };
#endif



/*
------------------------------------------------------------------------

  Call function BAPI_MESSAGE_GETDETAIL
      exporting
        ID like BAPIRET2_ID  type RFC_CHAR length 20
        LANGUAGE like BAPITGA_LANGU default SY-LANGU type RFC_CHAR length 1
        LINKPATTERN like BAPITGA_LINKMASK  type RFC_CHAR length 255
        MESSAGE_V1 like BAPIRET2_MESSAGE_V1  type RFC_CHAR length 50
        MESSAGE_V2 like BAPIRET2_MESSAGE_V2  type RFC_CHAR length 50
        MESSAGE_V3 like BAPIRET2_MESSAGE_V3  type RFC_CHAR length 50
        MESSAGE_V4 like BAPIRET2_MESSAGE_V4  type RFC_CHAR length 50
        NUMBER like BAPIRET2_NUMBER  type RFC_NUM length 3
        TEXTFORMAT like BAPITGA_TEXTFORMAT  type RFC_CHAR length 3
      importing
        MESSAGE like BAPIRET2_MESSAGE type RFC_CHAR length 220
        RETURN structure BAPIRET2 length
548 number of fields 14
      tables
        TEXT structure BAPITGB length 255 number of fields 1
      exceptions

------------------------------------------------------------------------
*/

/* field type definition */

#ifndef SAP_FT_BAPIRET2_ID
#define SAP_FT_BAPIRET2_ID
typedef RFC_CHAR BAPIRET2_ID[20];
#endif

#ifndef SAP_FT_BAPITGA_LANGU
#define SAP_FT_BAPITGA_LANGU
typedef RFC_CHAR BAPITGA_LANGU[1];
#endif

#ifndef SAP_FT_BAPITGA_LINKMASK
#define SAP_FT_BAPITGA_LINKMASK
typedef RFC_CHAR BAPITGA_LINKMASK[255];
#endif

#ifndef SAP_FT_BAPIRET2_MESSAGE_V1
#define SAP_FT_BAPIRET2_MESSAGE_V1
typedef RFC_CHAR BAPIRET2_MESSAGE_V1[50];
#endif

#ifndef SAP_FT_BAPIRET2_MESSAGE_V2
#define SAP_FT_BAPIRET2_MESSAGE_V2
typedef RFC_CHAR BAPIRET2_MESSAGE_V2[50];
#endif

#ifndef SAP_FT_BAPIRET2_MESSAGE_V3
#define SAP_FT_BAPIRET2_MESSAGE_V3
typedef RFC_CHAR BAPIRET2_MESSAGE_V3[50];
#endif

#ifndef SAP_FT_BAPIRET2_MESSAGE_V4
#define SAP_FT_BAPIRET2_MESSAGE_V4
typedef RFC_CHAR BAPIRET2_MESSAGE_V4[50];
#endif

#ifndef SAP_FT_BAPIRET2_NUMBER
#define SAP_FT_BAPIRET2_NUMBER
typedef RFC_NUM BAPIRET2_NUMBER[3];
#endif

#ifndef SAP_FT_BAPITGA_TEXTFORMAT
#define SAP_FT_BAPITGA_TEXTFORMAT
typedef RFC_CHAR BAPITGA_TEXTFORMAT[3];
#endif

#ifndef SAP_FT_BAPIRET2_MESSAGE
#define SAP_FT_BAPIRET2_MESSAGE
typedef RFC_CHAR BAPIRET2_MESSAGE[220];
#endif

/* structure type definition */

#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct {
  RFC_CHAR Type[1];
  RFC_CHAR Id[20];
  RFC_NUM Number[3];
  RFC_CHAR Message[220];
  RFC_CHAR LogNo[20];
  RFC_NUM LogMsgNo[6];
  RFC_CHAR MessageV1[50];
  RFC_CHAR MessageV2[50];
  RFC_CHAR MessageV3[50];
  RFC_CHAR MessageV4[50];
  RFC_CHAR Parameter[32];
  RFC_INT Row;
  RFC_CHAR Field[30];
  RFC_CHAR System[10];
 } BAPIRET2;
#endif

#ifndef SAP_ST_BAPITGB
#define SAP_ST_BAPITGB
typedef struct {
  RFC_CHAR Line[255];
 } BAPITGB;
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static RFC_TYPEHANDLE handleOfBAPIRET2;

static RFC_TYPE_ELEMENT typeOfBAPIRET2[] = {
  {"TYPE", TYPC, 1, 0},
  {"ID", TYPC, 20, 0},
  {"NUMBER", TYPNUM, 3, 0},
  {"MESSAGE", TYPC, 220, 0},
  {"LOG_NO", TYPC, 20, 0},
  {"LOG_MSG_NO", TYPNUM, 6, 0},
  {"MESSAGE_V1", TYPC, 50, 0},
  {"MESSAGE_V2", TYPC, 50, 0},
  {"MESSAGE_V3", TYPC, 50, 0},
  {"MESSAGE_V4", TYPC, 50, 0},
  {"PARAMETER", TYPC, 32, 0},
  {"ROW", TYPINT, sizeof(RFC_INT), 0},
  {"FIELD", TYPC, 30, 0},
  {"SYSTEM", TYPC, 10, 0},
 };
#endif

#ifndef SAP_TH_BAPITGB
#define SAP_TH_BAPITGB
static RFC_TYPEHANDLE handleOfBAPITGB;

static RFC_TYPE_ELEMENT typeOfBAPITGB[] = {
  {"LINE", TYPC, 255, 0},
 };
#endif

/* entries */


#ifndef ENTRIES
#define ENTRIES(tab) (sizeof(tab)/sizeof((tab)[0]))
#endif

#endif

/***********************************************************************************/

#define SETBCD(var,str,dec) str2nbcd(str,var,sizeof(var),dec)  
                                                      

#define GETCHAR(var,str) sprintf(str,"%.*s",sizeof(var),var)
/*#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var))); \       
                       if \                                                      
(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
Set Date*/

/**
#define SETTIME(var,str)memcpy(var,str,__min(strlen(str),sizeof(var))); \       
                       if  \                                                     
(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str)) 

**/

/*Set Float*/
#define SETFLOAT(var,str) *var=atof(str);
/*set int2*/
/**/
#define SETINT2(var,str) *var=atoi(str);
/*set int2*/
#if !defined(SAPonWINDOWS) && !defined(SAPonNT)
#define __min(a,b) (((a)<(b))?(a):(b))
#endif

#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var)

/*void OUTS(const char *text,const unsigned pos,const unsigned len,char *str)
{
  printf("%*.0s",pos,text); printf("%-*s : %s\n",len,text,str);
  /*if (outfile!=NULL) fprintf(outfile,"=%s\n>%s\n",text,str);
  return;
}*/



#define OUT(text,num) (printf("%s",text))



