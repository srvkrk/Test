struct QuerySruct
{
	string name;
	string value;
};

struct XMLBomData
{
     //SetOfObjects* objSO;
     string        opFileName;
     //ObjectPtr   * ParentPrt;
};


static string fileBuf;