/*
 *  FILE: msgtelU.h
 */

#ifndef msgtelU_H
#define msgtelU_H

#include <Mtimsgh.h>
#include <metadt.h>
/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _APLDmlPrintRptMailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _MulExpRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _MulImpRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _PostLCDocValidationsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _PreLCDocValidationsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _SnglExpMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _SnglImpMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5BOMEditorMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5CheckForDesignerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ChkDocDescribesPartAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5CkPartAssignedtoDMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5CnvrtDocMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5CreUpdBOMMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dialogObj, SetOfObjects chldObjSet, SetOfObjects relObjSet,
   integer * mfail);

MTIstatus _t5DMLPrintReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5DmlPDDAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5PartDocInfoRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5PartOwnerRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5PopulatepartsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, SetOfObjects originObjectSet,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _t5RenameDocAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

/*
 *  Unpublished Messages
 */

MTIstatus _ActivateTableAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _AraiLcmStateUpdMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _AraiLcmStateWrMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _AraiLcmStatusUpdMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _BomUpdateMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CatiaCreRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _CatiaDocLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _CatiaV5Chk
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _CatiaV5CreRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _CatiaV5DocLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _Catiachk
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _ChkBom
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _ClassValueQuery
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _ClsReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CmpArHdr
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _CopyArCls
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _CopyArDept
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _CopyArHdr
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _CopyHlgHdrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CopyHlgSubjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CopyNCreateHdr
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _CreAraiHdr
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _DUpdateAttrMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DmlLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _DynamiClassMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _GenRepCmpCertPdfAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenRepNoHdrPdfXAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GenerateReportDxAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenerateReportxAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetAllAnnexureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetAnnxReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetAnnxReportEurAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetAnnxReportEurWithoutCRepAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetAnnxReportGulfAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetAnnxReportGulfWithoutCRepAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetAnnxReportWithoutCRepAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetAttachmentAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _GetEurReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetGulfReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetLatestOwnershipAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetLinkAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetPartsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _GetReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetSubjectsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _GetTotAnnexureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GetUPLPartsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _GlobalUpdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _GulfSubjVerCmpMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _HLGLcmRELMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _HLGLcmRejMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _HLGLcmRevMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _HLGLcmWIPMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _HlgLcmStateWrMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _HlgMailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _JTLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _LoadDesignToolMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr brwObj, integer * mfail);

MTIstatus _LoadGrpMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr brwObj, integer * mfail);

MTIstatus _LoadPIMToolMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr brwObj, integer * mfail);

MTIstatus _LoadPartMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr brwObj, integer * mfail);

MTIstatus _MoveCadObj
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _MoveCadObjC
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _MoveCadObjP
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _ProeCreateRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _ProeDocLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _ProeLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _Proechk
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _RegCatiaFiles
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _RegCatiaV5Files
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _RegisterJTFiles
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _SMEpaPartXferAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ShutDownWarningMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _SubjVerCmpMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _SunchDocsMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr brwObj, integer * mfail);

MTIstatus _Superseade
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _SynchPartsMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr brwObj, integer * mfail);

MTIstatus _TCPartDocCreRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _TCPartLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _TCUsesPartsCreRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _Table8RepGenAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdateAllClausesAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdateHMAllClausesAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdateList
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _UpdateSingleClauseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _VersionReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _araiPendRepAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _dmlAddendaValSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _hlgDataLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _t0CheckAssgneeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0CheckAssignerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0CheckCondApprovedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0CheckReviewerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0CheckSeniorMemeberAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0ChkPrevGateAppAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0FreezeThruLCAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0GetACLUserAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetDeptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetDeptUpdateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetDivAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetIsuUsersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetIsuUsersForQryAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetNPIAccessRoleAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetNPICretitleAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetNPITitleAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetNPIUsersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetNotificationTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetNotifyUsersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetProjectMemberAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0GetSeniorMemberAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0IsuApproverMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0IsudeptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0LifeCycReviseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0NPIDocSignOffAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t0SubComMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0TransAxleMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t0TrfEffAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5APLEffAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5AddEpaTrackingMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5AddInValidPartMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5AffdPartsMsgProcAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ApproveStateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5AssemblyUpdMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5AssgDMURevMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5AssortedViewJTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5AssyTMatrixUpdMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5BaseCompareMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5BatchPrtMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ButtonMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, SetOfObjects originObjectSet,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _t5CVBUVehProcAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ChangeAssmDispInstAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ChkAPLAnaRevAssignedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5CloseDmlAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5CloseTaskAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5CmpCpyForAplAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5CmpPartMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5CmpStatusUpdMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ColourSchmNomenVSetMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5ContextBOMViewJTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5CreMBPAForExpMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5CreRelMepPartsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _t5CreateRelEPAAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5CustDocReplicationAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5CustPartReplicationAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5DComAgencyValueSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5DComTypeValueSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5DDrgDocCpyValueSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5DDrgDocValueSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5DMLFailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5DMUreviewAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5DPlantDeptVSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5DPlantVehTypeVSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5DataDownLoadMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _t5DcrReptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5DelAllPrtsMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _t5DesDocUpdMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5DlgShowMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr brwObj, integer * mfail);

MTIstatus _t5DmlDrwRlRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5DownLoadBomCadMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5DptDocClsMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5DrgDocUpdMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5DymDmlMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _t5DymVltMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _t5ECNApproveMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ECNRlzdProcAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ECNStateChngMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ECNStateChngSTDRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5EcnAplBomAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5EpaCreateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5EpaPartXferAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ErcAplStrMismatchAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ErcRlzdProcAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5FTPTransferMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5FinalizeTskAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5GenerateColorBOMAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5GetAttributesAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetDICrtrLglMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetDmlClassAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetEpaExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetLeftNRightAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetOperatorAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetPrtClassAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetStoreLocAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetSupplierCodeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GetclassesAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5GrpLoad
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _t5HlgHnumValSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5HlgMngrMailAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5HlgUpdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5IndentMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5IndentPrintMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5MBPAFormMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5MCNRlzdMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5MEpaComFormMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5MEpaCreFormMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5MainDMLFailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5MulDmlDrwRlRpt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects selectedItems, MTIconstString msgOptionTag, integer * mfail);

MTIstatus _t5MultiMain
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _t5NMEpaComFormMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5PartObsVaultMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5PartWIPVaultMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5PreviewDmlToDenisAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ProAsmAllRelationAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5PrtBrkDnAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5PrtCatCodeListAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5ReWipStateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5RelXORejMsgProcAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ReplacesPartNoSetMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5SLPartMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _t5SMRelMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5SMStateChngMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5SPTrnsferToRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5SendAPLMailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5SendMailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5SetPlanStCompleteAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ShowLtatBIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ShowLtatRefAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ShowPartHistoryMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ShowPdfFileMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5StdDmlXfrToDenisAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5StdEffMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5StdEffMsgAtPartLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5StdEffMsgAtPartLNonXAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5StdEffMsgWithSGRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5StdRestructMailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5StrUpdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5TaskApproveMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5TransferDmlToDenisAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5TranslateDocAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5TranslateDoc1AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5TranslateDoc2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5TranslateMatAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5UPLPartMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _t5UpdClsMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5UpdateLoadMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5VCGenerationAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ValCfgListAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5ValColSchAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5ValPrdFamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _t5ValTaskforSTDRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ValidateforSTDRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ViewAsStoredJTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ViewJTCollectionUnixAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ViewProeAssyJTUnixAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5ViewStampFailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5VltTrnsferToRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5WDPartEPAAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5WtRollUpAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5XfrAPLDmlToDenisAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5xfrMasterToRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _y00About
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _y00ConstructClass
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   ObjectPtr * classObj, integer * mfail);

MTIstatus _y00ConstructMODeLCmp
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   MTIconstString name, ObjectPtr * classObj, integer * mfail);

MTIstatus _y00ContractRuleDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _y00DumpAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _y00DumpSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _y00ExpandBrwComponentAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr BrcObj,
   integer side, SetOfObjects * otherSideObjSet, SetOfObjects * relObjSet,
   integer * mfail);

MTIstatus _y00ExpandRuleDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _y00FilterRules
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   ObjectPtr qrydef, SetOfObjects * ruleSet, integer * mfail);

MTIstatus _y00RemoveGhostDP
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _y00RemoveRedundantDP
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _y00SetDefaultsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr classObj,
   MTIconstString name, integer * mfail);
/*
 *  Message Macro Definitions.
 */

#define APLDmlPrintRptMailMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _APLDmlPrintRptMailMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define APLDmlPrintRptMailMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _APLDmlPrintRptMailMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define APLDmlPrintRptMailMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _APLDmlPrintRptMailMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define ActivateTable(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ActivateTableAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define ActivateTableAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ActivateTableAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define ActivateTableAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ActivateTableAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define AraiLcmStateUpdMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStateUpdMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define AraiLcmStateUpdMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStateUpdMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define AraiLcmStateUpdMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStateUpdMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define AraiLcmStateWrMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStateWrMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define AraiLcmStateWrMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStateWrMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define AraiLcmStateWrMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStateWrMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define AraiLcmStatusUpdMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStatusUpdMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define AraiLcmStatusUpdMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStatusUpdMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define AraiLcmStatusUpdMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _AraiLcmStatusUpdMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define BomUpdateMsg(thisObj, mfail) \
        _BomUpdateMsgAtClass(NULL, FALSE, thisObj, mfail)
#define BomUpdateMsgAtClass(class, thisObj, mfail) \
        _BomUpdateMsgAtClass(class, FALSE, thisObj, mfail)
#define BomUpdateMsgAtParent(class, thisObj, mfail) \
        _BomUpdateMsgAtClass(class, TRUE, thisObj, mfail)

#define CatiaCreRel(className, parameterSet, outputSet, mfail) \
        _CatiaCreRel(className, FALSE, className, parameterSet, outputSet, mfail)
#define CatiaCreRelAtParent(_class, className, parameterSet, outputSet, mfail) \
        _CatiaCreRel(_class, TRUE, className, parameterSet, outputSet, mfail)

#define CatiaDocLoad(className, parameterSet, outputSet, mfail) \
        _CatiaDocLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define CatiaDocLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _CatiaDocLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define CatiaV5Chk(className, parameterSet, outputSet, mfail) \
        _CatiaV5Chk(className, FALSE, className, parameterSet, outputSet, mfail)
#define CatiaV5ChkAtParent(_class, className, parameterSet, outputSet, mfail) \
        _CatiaV5Chk(_class, TRUE, className, parameterSet, outputSet, mfail)

#define CatiaV5CreRel(className, parameterSet, outputSet, mfail) \
        _CatiaV5CreRel(className, FALSE, className, parameterSet, outputSet, mfail)
#define CatiaV5CreRelAtParent(_class, className, parameterSet, outputSet, mfail) \
        _CatiaV5CreRel(_class, TRUE, className, parameterSet, outputSet, mfail)

#define CatiaV5DocLoad(className, parameterSet, outputSet, mfail) \
        _CatiaV5DocLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define CatiaV5DocLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _CatiaV5DocLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define Catiachk(className, parameterSet, outputSet, mfail) \
        _Catiachk(className, FALSE, className, parameterSet, outputSet, mfail)
#define CatiachkAtParent(_class, className, parameterSet, outputSet, mfail) \
        _Catiachk(_class, TRUE, className, parameterSet, outputSet, mfail)

#define ChkBom(className, parameterSet, outputSet, mfail) \
        _ChkBom(className, FALSE, className, parameterSet, outputSet, mfail)
#define ChkBomAtParent(_class, className, parameterSet, outputSet, mfail) \
        _ChkBom(_class, TRUE, className, parameterSet, outputSet, mfail)

#define ClassValueQuery(className, mfail) \
        _ClassValueQuery(className, FALSE, className, mfail)
#define ClassValueQueryAtParent(_class, className, mfail) \
        _ClassValueQuery(_class, TRUE, className, mfail)

#define ClsReport(thisObj, mfail) \
        _ClsReportAtClass(NULL, FALSE, thisObj, mfail)
#define ClsReportAtClass(class, thisObj, mfail) \
        _ClsReportAtClass(class, FALSE, thisObj, mfail)
#define ClsReportAtParent(class, thisObj, mfail) \
        _ClsReportAtClass(class, TRUE, thisObj, mfail)

#define CmpArHdr(className, mfail) \
        _CmpArHdr(className, FALSE, className, mfail)
#define CmpArHdrAtParent(_class, className, mfail) \
        _CmpArHdr(_class, TRUE, className, mfail)

#define CopyArCls(className, SelectedItems, mfail) \
        _CopyArCls(className, FALSE, className, SelectedItems, mfail)
#define CopyArClsAtParent(_class, className, SelectedItems, mfail) \
        _CopyArCls(_class, TRUE, className, SelectedItems, mfail)

#define CopyArDept(className, mfail) \
        _CopyArDept(className, FALSE, className, mfail)
#define CopyArDeptAtParent(_class, className, mfail) \
        _CopyArDept(_class, TRUE, className, mfail)

#define CopyArHdr(className, mfail) \
        _CopyArHdr(className, FALSE, className, mfail)
#define CopyArHdrAtParent(_class, className, mfail) \
        _CopyArHdr(_class, TRUE, className, mfail)

#define CopyHlgHdr(thisObj, mfail) \
        _CopyHlgHdrAtClass(NULL, FALSE, thisObj, mfail)
#define CopyHlgHdrAtClass(class, thisObj, mfail) \
        _CopyHlgHdrAtClass(class, FALSE, thisObj, mfail)
#define CopyHlgHdrAtParent(class, thisObj, mfail) \
        _CopyHlgHdrAtClass(class, TRUE, thisObj, mfail)

#define CopyHlgSubj(thisObj, mfail) \
        _CopyHlgSubjAtClass(NULL, FALSE, thisObj, mfail)
#define CopyHlgSubjAtClass(class, thisObj, mfail) \
        _CopyHlgSubjAtClass(class, FALSE, thisObj, mfail)
#define CopyHlgSubjAtParent(class, thisObj, mfail) \
        _CopyHlgSubjAtClass(class, TRUE, thisObj, mfail)

#define CopyNCreateHdr(className, mfail) \
        _CopyNCreateHdr(className, FALSE, className, mfail)
#define CopyNCreateHdrAtParent(_class, className, mfail) \
        _CopyNCreateHdr(_class, TRUE, className, mfail)

#define CreAraiHdr(className, mfail) \
        _CreAraiHdr(className, FALSE, className, mfail)
#define CreAraiHdrAtParent(_class, className, mfail) \
        _CreAraiHdr(_class, TRUE, className, mfail)

#define DUpdateAttrMsg(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DUpdateAttrMsgAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DUpdateAttrMsgAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DUpdateAttrMsgAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DUpdateAttrMsgAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DUpdateAttrMsgAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DmlLoad(className, parameterSet, outputSet, mfail) \
        _DmlLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define DmlLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _DmlLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define DynamiClassMsg(className, mfail) \
        _DynamiClassMsg(className, FALSE, className, mfail)
#define DynamiClassMsgAtParent(_class, className, mfail) \
        _DynamiClassMsg(_class, TRUE, className, mfail)

#define GenRepCmpCertPdf(thisObj, mfail) \
        _GenRepCmpCertPdfAtClass(NULL, FALSE, thisObj, mfail)
#define GenRepCmpCertPdfAtClass(class, thisObj, mfail) \
        _GenRepCmpCertPdfAtClass(class, FALSE, thisObj, mfail)
#define GenRepCmpCertPdfAtParent(class, thisObj, mfail) \
        _GenRepCmpCertPdfAtClass(class, TRUE, thisObj, mfail)

#define GenRepNoHdrPdfX(thisObj, mfail) \
        _GenRepNoHdrPdfXAtClass(NULL, FALSE, thisObj, mfail)
#define GenRepNoHdrPdfXAtClass(class, thisObj, mfail) \
        _GenRepNoHdrPdfXAtClass(class, FALSE, thisObj, mfail)
#define GenRepNoHdrPdfXAtParent(class, thisObj, mfail) \
        _GenRepNoHdrPdfXAtClass(class, TRUE, thisObj, mfail)

#define GenRptMsg(pdmItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenRptMsgAtClass(NULL, FALSE, pdmItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenRptMsgAtClass(class, pdmItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenRptMsgAtClass(class, FALSE, pdmItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenRptMsgAtParent(class, pdmItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenRptMsgAtClass(class, TRUE, pdmItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GenerateReportDx(thisObj, mfail) \
        _GenerateReportDxAtClass(NULL, FALSE, thisObj, mfail)
#define GenerateReportDxAtClass(class, thisObj, mfail) \
        _GenerateReportDxAtClass(class, FALSE, thisObj, mfail)
#define GenerateReportDxAtParent(class, thisObj, mfail) \
        _GenerateReportDxAtClass(class, TRUE, thisObj, mfail)

#define GenerateReportx(thisObj, mfail) \
        _GenerateReportxAtClass(NULL, FALSE, thisObj, mfail)
#define GenerateReportxAtClass(class, thisObj, mfail) \
        _GenerateReportxAtClass(class, FALSE, thisObj, mfail)
#define GenerateReportxAtParent(class, thisObj, mfail) \
        _GenerateReportxAtClass(class, TRUE, thisObj, mfail)

#define GetAllAnnexure(thisObj, mfail) \
        _GetAllAnnexureAtClass(NULL, FALSE, thisObj, mfail)
#define GetAllAnnexureAtClass(class, thisObj, mfail) \
        _GetAllAnnexureAtClass(class, FALSE, thisObj, mfail)
#define GetAllAnnexureAtParent(class, thisObj, mfail) \
        _GetAllAnnexureAtClass(class, TRUE, thisObj, mfail)

#define GetAnnxReport(thisObj, mfail) \
        _GetAnnxReportAtClass(NULL, FALSE, thisObj, mfail)
#define GetAnnxReportAtClass(class, thisObj, mfail) \
        _GetAnnxReportAtClass(class, FALSE, thisObj, mfail)
#define GetAnnxReportAtParent(class, thisObj, mfail) \
        _GetAnnxReportAtClass(class, TRUE, thisObj, mfail)

#define GetAnnxReportEur(thisObj, mfail) \
        _GetAnnxReportEurAtClass(NULL, FALSE, thisObj, mfail)
#define GetAnnxReportEurAtClass(class, thisObj, mfail) \
        _GetAnnxReportEurAtClass(class, FALSE, thisObj, mfail)
#define GetAnnxReportEurAtParent(class, thisObj, mfail) \
        _GetAnnxReportEurAtClass(class, TRUE, thisObj, mfail)

#define GetAnnxReportEurWithoutCRep(thisObj, mfail) \
        _GetAnnxReportEurWithoutCRepAtClass(NULL, FALSE, thisObj, mfail)
#define GetAnnxReportEurWithoutCRepAtClass(class, thisObj, mfail) \
        _GetAnnxReportEurWithoutCRepAtClass(class, FALSE, thisObj, mfail)
#define GetAnnxReportEurWithoutCRepAtParent(class, thisObj, mfail) \
        _GetAnnxReportEurWithoutCRepAtClass(class, TRUE, thisObj, mfail)

#define GetAnnxReportGulf(thisObj, mfail) \
        _GetAnnxReportGulfAtClass(NULL, FALSE, thisObj, mfail)
#define GetAnnxReportGulfAtClass(class, thisObj, mfail) \
        _GetAnnxReportGulfAtClass(class, FALSE, thisObj, mfail)
#define GetAnnxReportGulfAtParent(class, thisObj, mfail) \
        _GetAnnxReportGulfAtClass(class, TRUE, thisObj, mfail)

#define GetAnnxReportGulfWithoutCRep(thisObj, mfail) \
        _GetAnnxReportGulfWithoutCRepAtClass(NULL, FALSE, thisObj, mfail)
#define GetAnnxReportGulfWithoutCRepAtClass(class, thisObj, mfail) \
        _GetAnnxReportGulfWithoutCRepAtClass(class, FALSE, thisObj, mfail)
#define GetAnnxReportGulfWithoutCRepAtParent(class, thisObj, mfail) \
        _GetAnnxReportGulfWithoutCRepAtClass(class, TRUE, thisObj, mfail)

#define GetAnnxReportWithoutCRep(thisObj, mfail) \
        _GetAnnxReportWithoutCRepAtClass(NULL, FALSE, thisObj, mfail)
#define GetAnnxReportWithoutCRepAtClass(class, thisObj, mfail) \
        _GetAnnxReportWithoutCRepAtClass(class, FALSE, thisObj, mfail)
#define GetAnnxReportWithoutCRepAtParent(class, thisObj, mfail) \
        _GetAnnxReportWithoutCRepAtClass(class, TRUE, thisObj, mfail)

#define GetAttachment(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetAttachmentAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GetAttachmentAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetAttachmentAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GetAttachmentAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetAttachmentAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define GetEurReport(thisObj, mfail) \
        _GetEurReportAtClass(NULL, FALSE, thisObj, mfail)
#define GetEurReportAtClass(class, thisObj, mfail) \
        _GetEurReportAtClass(class, FALSE, thisObj, mfail)
#define GetEurReportAtParent(class, thisObj, mfail) \
        _GetEurReportAtClass(class, TRUE, thisObj, mfail)

#define GetGulfReport(thisObj, mfail) \
        _GetGulfReportAtClass(NULL, FALSE, thisObj, mfail)
#define GetGulfReportAtClass(class, thisObj, mfail) \
        _GetGulfReportAtClass(class, FALSE, thisObj, mfail)
#define GetGulfReportAtParent(class, thisObj, mfail) \
        _GetGulfReportAtClass(class, TRUE, thisObj, mfail)

#define GetLatestOwnership(thisObj, mfail) \
        _GetLatestOwnershipAtClass(NULL, FALSE, thisObj, mfail)
#define GetLatestOwnershipAtClass(class, thisObj, mfail) \
        _GetLatestOwnershipAtClass(class, FALSE, thisObj, mfail)
#define GetLatestOwnershipAtParent(class, thisObj, mfail) \
        _GetLatestOwnershipAtClass(class, TRUE, thisObj, mfail)

#define GetLink(thisObj, mfail) \
        _GetLinkAtClass(NULL, FALSE, thisObj, mfail)
#define GetLinkAtClass(class, thisObj, mfail) \
        _GetLinkAtClass(class, FALSE, thisObj, mfail)
#define GetLinkAtParent(class, thisObj, mfail) \
        _GetLinkAtClass(class, TRUE, thisObj, mfail)

#define GetParts(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetPartsAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GetPartsAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetPartsAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GetPartsAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetPartsAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define GetReport(thisObj, mfail) \
        _GetReportAtClass(NULL, FALSE, thisObj, mfail)
#define GetReportAtClass(class, thisObj, mfail) \
        _GetReportAtClass(class, FALSE, thisObj, mfail)
#define GetReportAtParent(class, thisObj, mfail) \
        _GetReportAtClass(class, TRUE, thisObj, mfail)

#define GetSubjects(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetSubjectsAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GetSubjectsAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetSubjectsAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GetSubjectsAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetSubjectsAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define GetTotAnnexure(thisObj, mfail) \
        _GetTotAnnexureAtClass(NULL, FALSE, thisObj, mfail)
#define GetTotAnnexureAtClass(class, thisObj, mfail) \
        _GetTotAnnexureAtClass(class, FALSE, thisObj, mfail)
#define GetTotAnnexureAtParent(class, thisObj, mfail) \
        _GetTotAnnexureAtClass(class, TRUE, thisObj, mfail)

#define GetUPLParts(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetUPLPartsAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GetUPLPartsAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetUPLPartsAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GetUPLPartsAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GetUPLPartsAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define GlobalUpd(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GlobalUpdAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GlobalUpdAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GlobalUpdAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define GlobalUpdAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _GlobalUpdAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define GulfSubjVerCmpMsg(thisObj, mfail) \
        _GulfSubjVerCmpMsgAtClass(NULL, FALSE, thisObj, mfail)
#define GulfSubjVerCmpMsgAtClass(class, thisObj, mfail) \
        _GulfSubjVerCmpMsgAtClass(class, FALSE, thisObj, mfail)
#define GulfSubjVerCmpMsgAtParent(class, thisObj, mfail) \
        _GulfSubjVerCmpMsgAtClass(class, TRUE, thisObj, mfail)

#define HLGLcmRELMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRELMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HLGLcmRELMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRELMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HLGLcmRELMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRELMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define HLGLcmRejMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRejMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HLGLcmRejMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRejMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HLGLcmRejMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRejMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define HLGLcmRevMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRevMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HLGLcmRevMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRevMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HLGLcmRevMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmRevMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define HLGLcmWIPMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmWIPMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HLGLcmWIPMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmWIPMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HLGLcmWIPMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HLGLcmWIPMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define HlgLcmStateWrMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _HlgLcmStateWrMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HlgLcmStateWrMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HlgLcmStateWrMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HlgLcmStateWrMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HlgLcmStateWrMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define HlgMailMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _HlgMailMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HlgMailMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HlgMailMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define HlgMailMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _HlgMailMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define JTLoad(className, parameterSet, outputSet, mfail) \
        _JTLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define JTLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _JTLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define LoadDesignToolMsg(className, brwObj, mfail) \
        _LoadDesignToolMsg(className, FALSE, className, brwObj, mfail)
#define LoadDesignToolMsgAtParent(_class, className, brwObj, mfail) \
        _LoadDesignToolMsg(_class, TRUE, className, brwObj, mfail)

#define LoadGrpMsg(className, brwObj, mfail) \
        _LoadGrpMsg(className, FALSE, className, brwObj, mfail)
#define LoadGrpMsgAtParent(_class, className, brwObj, mfail) \
        _LoadGrpMsg(_class, TRUE, className, brwObj, mfail)

#define LoadPIMToolMsg(className, brwObj, mfail) \
        _LoadPIMToolMsg(className, FALSE, className, brwObj, mfail)
#define LoadPIMToolMsgAtParent(_class, className, brwObj, mfail) \
        _LoadPIMToolMsg(_class, TRUE, className, brwObj, mfail)

#define LoadPartMsg(className, brwObj, mfail) \
        _LoadPartMsg(className, FALSE, className, brwObj, mfail)
#define LoadPartMsgAtParent(_class, className, brwObj, mfail) \
        _LoadPartMsg(_class, TRUE, className, brwObj, mfail)

#define MoveCadObj(className, parameterSet, outputSet, mfail) \
        _MoveCadObj(className, FALSE, className, parameterSet, outputSet, mfail)
#define MoveCadObjAtParent(_class, className, parameterSet, outputSet, mfail) \
        _MoveCadObj(_class, TRUE, className, parameterSet, outputSet, mfail)

#define MoveCadObjC(className, parameterSet, outputSet, mfail) \
        _MoveCadObjC(className, FALSE, className, parameterSet, outputSet, mfail)
#define MoveCadObjCAtParent(_class, className, parameterSet, outputSet, mfail) \
        _MoveCadObjC(_class, TRUE, className, parameterSet, outputSet, mfail)

#define MoveCadObjP(className, parameterSet, outputSet, mfail) \
        _MoveCadObjP(className, FALSE, className, parameterSet, outputSet, mfail)
#define MoveCadObjPAtParent(_class, className, parameterSet, outputSet, mfail) \
        _MoveCadObjP(_class, TRUE, className, parameterSet, outputSet, mfail)

#define MulExpRptMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulExpRptMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define MulExpRptMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulExpRptMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define MulExpRptMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulExpRptMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define MulImpRptMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulImpRptMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define MulImpRptMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulImpRptMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define MulImpRptMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulImpRptMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define PostLCDocValidations(obj, procHist, msgProc, exitState, advComments, mfail) \
        _PostLCDocValidationsAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PostLCDocValidationsAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PostLCDocValidationsAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PostLCDocValidationsAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PostLCDocValidationsAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define PreLCDocValidations(obj, procHist, msgProc, exitState, advComments, mfail) \
        _PreLCDocValidationsAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PreLCDocValidationsAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PreLCDocValidationsAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PreLCDocValidationsAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PreLCDocValidationsAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ProeCreateRel(className, parameterSet, outputSet, mfail) \
        _ProeCreateRel(className, FALSE, className, parameterSet, outputSet, mfail)
#define ProeCreateRelAtParent(_class, className, parameterSet, outputSet, mfail) \
        _ProeCreateRel(_class, TRUE, className, parameterSet, outputSet, mfail)

#define ProeDocLoad(className, parameterSet, outputSet, mfail) \
        _ProeDocLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define ProeDocLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _ProeDocLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define ProeLoad(className, parameterSet, outputSet, mfail) \
        _ProeLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define ProeLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _ProeLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define Proechk(className, parameterSet, outputSet, mfail) \
        _Proechk(className, FALSE, className, parameterSet, outputSet, mfail)
#define ProechkAtParent(_class, className, parameterSet, outputSet, mfail) \
        _Proechk(_class, TRUE, className, parameterSet, outputSet, mfail)

#define RegCatiaFiles(className, parameterSet, outputSet, mfail) \
        _RegCatiaFiles(className, FALSE, className, parameterSet, outputSet, mfail)
#define RegCatiaFilesAtParent(_class, className, parameterSet, outputSet, mfail) \
        _RegCatiaFiles(_class, TRUE, className, parameterSet, outputSet, mfail)

#define RegCatiaV5Files(className, parameterSet, outputSet, mfail) \
        _RegCatiaV5Files(className, FALSE, className, parameterSet, outputSet, mfail)
#define RegCatiaV5FilesAtParent(_class, className, parameterSet, outputSet, mfail) \
        _RegCatiaV5Files(_class, TRUE, className, parameterSet, outputSet, mfail)

#define RegisterJTFiles(className, parameterSet, outputSet, mfail) \
        _RegisterJTFiles(className, FALSE, className, parameterSet, outputSet, mfail)
#define RegisterJTFilesAtParent(_class, className, parameterSet, outputSet, mfail) \
        _RegisterJTFiles(_class, TRUE, className, parameterSet, outputSet, mfail)

#define SMEpaPartXfer(thisObj, mfail) \
        _SMEpaPartXferAtClass(NULL, FALSE, thisObj, mfail)
#define SMEpaPartXferAtClass(class, thisObj, mfail) \
        _SMEpaPartXferAtClass(class, FALSE, thisObj, mfail)
#define SMEpaPartXferAtParent(class, thisObj, mfail) \
        _SMEpaPartXferAtClass(class, TRUE, thisObj, mfail)

#define ShutDownWarningMsg(className, mfail) \
        _ShutDownWarningMsg(className, FALSE, className, mfail)
#define ShutDownWarningMsgAtParent(_class, className, mfail) \
        _ShutDownWarningMsg(_class, TRUE, className, mfail)

#define SnglExpMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglExpMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define SnglExpMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglExpMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define SnglExpMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglExpMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define SnglImpMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglImpMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define SnglImpMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglImpMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define SnglImpMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglImpMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define SubjVerCmpMsg(thisObj, mfail) \
        _SubjVerCmpMsgAtClass(NULL, FALSE, thisObj, mfail)
#define SubjVerCmpMsgAtClass(class, thisObj, mfail) \
        _SubjVerCmpMsgAtClass(class, FALSE, thisObj, mfail)
#define SubjVerCmpMsgAtParent(class, thisObj, mfail) \
        _SubjVerCmpMsgAtClass(class, TRUE, thisObj, mfail)

#define SunchDocsMsg(className, brwObj, mfail) \
        _SunchDocsMsg(className, FALSE, className, brwObj, mfail)
#define SunchDocsMsgAtParent(_class, className, brwObj, mfail) \
        _SunchDocsMsg(_class, TRUE, className, brwObj, mfail)

#define Superseade(className, parameterSet, outputSet, mfail) \
        _Superseade(className, FALSE, className, parameterSet, outputSet, mfail)
#define SuperseadeAtParent(_class, className, parameterSet, outputSet, mfail) \
        _Superseade(_class, TRUE, className, parameterSet, outputSet, mfail)

#define SynchPartsMsg(className, brwObj, mfail) \
        _SynchPartsMsg(className, FALSE, className, brwObj, mfail)
#define SynchPartsMsgAtParent(_class, className, brwObj, mfail) \
        _SynchPartsMsg(_class, TRUE, className, brwObj, mfail)

#define TCPartDocCreRel(className, parameterSet, outputSet, mfail) \
        _TCPartDocCreRel(className, FALSE, className, parameterSet, outputSet, mfail)
#define TCPartDocCreRelAtParent(_class, className, parameterSet, outputSet, mfail) \
        _TCPartDocCreRel(_class, TRUE, className, parameterSet, outputSet, mfail)

#define TCPartLoad(className, parameterSet, outputSet, mfail) \
        _TCPartLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define TCPartLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _TCPartLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define TCUsesPartsCreRel(className, parameterSet, outputSet, mfail) \
        _TCUsesPartsCreRel(className, FALSE, className, parameterSet, outputSet, mfail)
#define TCUsesPartsCreRelAtParent(_class, className, parameterSet, outputSet, mfail) \
        _TCUsesPartsCreRel(_class, TRUE, className, parameterSet, outputSet, mfail)

#define Table8RepGen(thisObj, mfail) \
        _Table8RepGenAtClass(NULL, FALSE, thisObj, mfail)
#define Table8RepGenAtClass(class, thisObj, mfail) \
        _Table8RepGenAtClass(class, FALSE, thisObj, mfail)
#define Table8RepGenAtParent(class, thisObj, mfail) \
        _Table8RepGenAtClass(class, TRUE, thisObj, mfail)

#define UpdateAllClauses(thisObj, mfail) \
        _UpdateAllClausesAtClass(NULL, FALSE, thisObj, mfail)
#define UpdateAllClausesAtClass(class, thisObj, mfail) \
        _UpdateAllClausesAtClass(class, FALSE, thisObj, mfail)
#define UpdateAllClausesAtParent(class, thisObj, mfail) \
        _UpdateAllClausesAtClass(class, TRUE, thisObj, mfail)

#define UpdateHMAllClauses(thisObj, mfail) \
        _UpdateHMAllClausesAtClass(NULL, FALSE, thisObj, mfail)
#define UpdateHMAllClausesAtClass(class, thisObj, mfail) \
        _UpdateHMAllClausesAtClass(class, FALSE, thisObj, mfail)
#define UpdateHMAllClausesAtParent(class, thisObj, mfail) \
        _UpdateHMAllClausesAtClass(class, TRUE, thisObj, mfail)

#define UpdateList(className, parameterSet, outputSet, mfail) \
        _UpdateList(className, FALSE, className, parameterSet, outputSet, mfail)
#define UpdateListAtParent(_class, className, parameterSet, outputSet, mfail) \
        _UpdateList(_class, TRUE, className, parameterSet, outputSet, mfail)

#define UpdateSingleClause(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _UpdateSingleClauseAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define UpdateSingleClauseAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _UpdateSingleClauseAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define UpdateSingleClauseAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _UpdateSingleClauseAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define VersionReport(thisObj, mfail) \
        _VersionReportAtClass(NULL, FALSE, thisObj, mfail)
#define VersionReportAtClass(class, thisObj, mfail) \
        _VersionReportAtClass(class, FALSE, thisObj, mfail)
#define VersionReportAtParent(class, thisObj, mfail) \
        _VersionReportAtClass(class, TRUE, thisObj, mfail)

#define araiPendRep(thisObj, mfail) \
        _araiPendRepAtClass(NULL, FALSE, thisObj, mfail)
#define araiPendRepAtClass(class, thisObj, mfail) \
        _araiPendRepAtClass(class, FALSE, thisObj, mfail)
#define araiPendRepAtParent(class, thisObj, mfail) \
        _araiPendRepAtClass(class, TRUE, thisObj, mfail)

#define dmlAddendaValSet(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _dmlAddendaValSetAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define dmlAddendaValSetAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _dmlAddendaValSetAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define dmlAddendaValSetAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _dmlAddendaValSetAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define hlgDataLoad(className, parameterSet, outputSet, mfail) \
        _hlgDataLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define hlgDataLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _hlgDataLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define t0CheckAssgnee(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckAssgneeAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckAssgneeAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckAssgneeAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckAssgneeAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckAssgneeAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0CheckAssigner(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckAssignerAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckAssignerAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckAssignerAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckAssignerAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckAssignerAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0CheckCondApproved(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckCondApprovedAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckCondApprovedAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckCondApprovedAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckCondApprovedAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckCondApprovedAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0CheckReviewer(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckReviewerAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckReviewerAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckReviewerAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckReviewerAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckReviewerAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0CheckSeniorMemeber(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckSeniorMemeberAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckSeniorMemeberAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckSeniorMemeberAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0CheckSeniorMemeberAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0CheckSeniorMemeberAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0ChkPrevGateApp(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0ChkPrevGateAppAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0ChkPrevGateAppAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0ChkPrevGateAppAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0ChkPrevGateAppAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0ChkPrevGateAppAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0FreezeThruLC(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0FreezeThruLCAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0FreezeThruLCAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0FreezeThruLCAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0FreezeThruLCAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0FreezeThruLCAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0GetACLUser(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetACLUserAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetACLUserAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetACLUserAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetACLUserAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetACLUserAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetDept(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDeptAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetDeptAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDeptAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetDeptAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDeptAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetDeptUpdate(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDeptUpdateAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetDeptUpdateAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDeptUpdateAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetDeptUpdateAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDeptUpdateAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetDiv(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDivAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetDivAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDivAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetDivAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetDivAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetIsuUsers(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetIsuUsersAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetIsuUsersAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetIsuUsersAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetIsuUsersAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetIsuUsersAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetIsuUsersForQry(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetIsuUsersForQryAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetIsuUsersForQryAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetIsuUsersForQryAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetIsuUsersForQryAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetIsuUsersForQryAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetNPIAccessRole(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPIAccessRoleAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNPIAccessRoleAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPIAccessRoleAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNPIAccessRoleAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPIAccessRoleAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetNPICretitle(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPICretitleAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNPICretitleAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPICretitleAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNPICretitleAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPICretitleAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetNPITitle(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPITitleAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNPITitleAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPITitleAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNPITitleAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPITitleAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetNPIUsers(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPIUsersAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNPIUsersAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPIUsersAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNPIUsersAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNPIUsersAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetNotificationTeam(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNotificationTeamAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNotificationTeamAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNotificationTeamAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNotificationTeamAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNotificationTeamAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetNotifyUsers(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNotifyUsersAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNotifyUsersAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNotifyUsersAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetNotifyUsersAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetNotifyUsersAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetProjectMember(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetProjectMemberAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetProjectMemberAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetProjectMemberAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetProjectMemberAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetProjectMemberAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0GetSeniorMember(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetSeniorMemberAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetSeniorMemberAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetSeniorMemberAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0GetSeniorMemberAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0GetSeniorMemberAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0IsuApproverMsg(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0IsuApproverMsgAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0IsuApproverMsgAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0IsuApproverMsgAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0IsuApproverMsgAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0IsuApproverMsgAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0IsudeptMsg(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0IsudeptMsgAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0IsudeptMsgAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0IsudeptMsgAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0IsudeptMsgAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0IsudeptMsgAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0LifeCycRevise(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0LifeCycReviseAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0LifeCycReviseAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0LifeCycReviseAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0LifeCycReviseAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0LifeCycReviseAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0NPIDocSignOff(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0NPIDocSignOffAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0NPIDocSignOffAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0NPIDocSignOffAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0NPIDocSignOffAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0NPIDocSignOffAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t0SubComMsg(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0SubComMsgAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0SubComMsgAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0SubComMsgAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0SubComMsgAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0SubComMsgAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0TransAxleMsg(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0TransAxleMsgAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0TransAxleMsgAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0TransAxleMsgAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t0TransAxleMsgAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t0TransAxleMsgAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t0TrfEff(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0TrfEffAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0TrfEffAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0TrfEffAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t0TrfEffAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t0TrfEffAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5APLEff(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5APLEffAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5APLEffAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5APLEffAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5APLEffAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5APLEffAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5AddEpaTrackingMsg(thisObj, mfail) \
        _t5AddEpaTrackingMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5AddEpaTrackingMsgAtClass(class, thisObj, mfail) \
        _t5AddEpaTrackingMsgAtClass(class, FALSE, thisObj, mfail)
#define t5AddEpaTrackingMsgAtParent(class, thisObj, mfail) \
        _t5AddEpaTrackingMsgAtClass(class, TRUE, thisObj, mfail)

#define t5AddInValidPartMsg(thisObj, mfail) \
        _t5AddInValidPartMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5AddInValidPartMsgAtClass(class, thisObj, mfail) \
        _t5AddInValidPartMsgAtClass(class, FALSE, thisObj, mfail)
#define t5AddInValidPartMsgAtParent(class, thisObj, mfail) \
        _t5AddInValidPartMsgAtClass(class, TRUE, thisObj, mfail)

#define t5AffdPartsMsgProc(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5AffdPartsMsgProcAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5AffdPartsMsgProcAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5AffdPartsMsgProcAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5AffdPartsMsgProcAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5AffdPartsMsgProcAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ApproveState(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ApproveStateAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ApproveStateAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ApproveStateAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ApproveStateAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ApproveStateAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5AssemblyUpdMsg(thisObj, mfail) \
        _t5AssemblyUpdMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5AssemblyUpdMsgAtClass(class, thisObj, mfail) \
        _t5AssemblyUpdMsgAtClass(class, FALSE, thisObj, mfail)
#define t5AssemblyUpdMsgAtParent(class, thisObj, mfail) \
        _t5AssemblyUpdMsgAtClass(class, TRUE, thisObj, mfail)

#define t5AssgDMURevMsg(thisObj, mfail) \
        _t5AssgDMURevMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5AssgDMURevMsgAtClass(class, thisObj, mfail) \
        _t5AssgDMURevMsgAtClass(class, FALSE, thisObj, mfail)
#define t5AssgDMURevMsgAtParent(class, thisObj, mfail) \
        _t5AssgDMURevMsgAtClass(class, TRUE, thisObj, mfail)

#define t5AssortedViewJT(thisObj, mfail) \
        _t5AssortedViewJTAtClass(NULL, FALSE, thisObj, mfail)
#define t5AssortedViewJTAtClass(class, thisObj, mfail) \
        _t5AssortedViewJTAtClass(class, FALSE, thisObj, mfail)
#define t5AssortedViewJTAtParent(class, thisObj, mfail) \
        _t5AssortedViewJTAtClass(class, TRUE, thisObj, mfail)

#define t5AssyTMatrixUpdMsg(thisObj, mfail) \
        _t5AssyTMatrixUpdMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5AssyTMatrixUpdMsgAtClass(class, thisObj, mfail) \
        _t5AssyTMatrixUpdMsgAtClass(class, FALSE, thisObj, mfail)
#define t5AssyTMatrixUpdMsgAtParent(class, thisObj, mfail) \
        _t5AssyTMatrixUpdMsgAtClass(class, TRUE, thisObj, mfail)

#define t5BOMEditorMsg(thisObj, mfail) \
        _t5BOMEditorMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5BOMEditorMsgAtClass(class, thisObj, mfail) \
        _t5BOMEditorMsgAtClass(class, FALSE, thisObj, mfail)
#define t5BOMEditorMsgAtParent(class, thisObj, mfail) \
        _t5BOMEditorMsgAtClass(class, TRUE, thisObj, mfail)

#define t5BaseCompareMsg(thisObj, mfail) \
        _t5BaseCompareMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5BaseCompareMsgAtClass(class, thisObj, mfail) \
        _t5BaseCompareMsgAtClass(class, FALSE, thisObj, mfail)
#define t5BaseCompareMsgAtParent(class, thisObj, mfail) \
        _t5BaseCompareMsgAtClass(class, TRUE, thisObj, mfail)

#define t5BatchPrtMsg(thisObj, mfail) \
        _t5BatchPrtMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5BatchPrtMsgAtClass(class, thisObj, mfail) \
        _t5BatchPrtMsgAtClass(class, FALSE, thisObj, mfail)
#define t5BatchPrtMsgAtParent(class, thisObj, mfail) \
        _t5BatchPrtMsgAtClass(class, TRUE, thisObj, mfail)

#define t5ButtonMsg(thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5ButtonMsgAtClass(NULL, FALSE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)
#define t5ButtonMsgAtClass(class, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5ButtonMsgAtClass(class, FALSE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)
#define t5ButtonMsgAtParent(class, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5ButtonMsgAtClass(class, TRUE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)

#define t5CVBUVehProc(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CVBUVehProcAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CVBUVehProcAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CVBUVehProcAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CVBUVehProcAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CVBUVehProcAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ChangeAssmDispInst(thisObj, mfail) \
        _t5ChangeAssmDispInstAtClass(NULL, FALSE, thisObj, mfail)
#define t5ChangeAssmDispInstAtClass(class, thisObj, mfail) \
        _t5ChangeAssmDispInstAtClass(class, FALSE, thisObj, mfail)
#define t5ChangeAssmDispInstAtParent(class, thisObj, mfail) \
        _t5ChangeAssmDispInstAtClass(class, TRUE, thisObj, mfail)

#define t5CheckForDesigner(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CheckForDesignerAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CheckForDesignerAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CheckForDesignerAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CheckForDesignerAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CheckForDesignerAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ChkAPLAnaRevAssigned(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkAPLAnaRevAssignedAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ChkAPLAnaRevAssignedAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkAPLAnaRevAssignedAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ChkAPLAnaRevAssignedAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkAPLAnaRevAssignedAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ChkDocDescribesPart(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkDocDescribesPartAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ChkDocDescribesPartAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkDocDescribesPartAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ChkDocDescribesPartAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkDocDescribesPartAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5CkPartAssignedtoDML(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CkPartAssignedtoDMLAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CkPartAssignedtoDMLAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CkPartAssignedtoDMLAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CkPartAssignedtoDMLAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CkPartAssignedtoDMLAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5CloseDml(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CloseDmlAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CloseDmlAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CloseDmlAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CloseDmlAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CloseDmlAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5CloseTask(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CloseTaskAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CloseTaskAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CloseTaskAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CloseTaskAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CloseTaskAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5CmpCpyForApl(thisObj, mfail) \
        _t5CmpCpyForAplAtClass(NULL, FALSE, thisObj, mfail)
#define t5CmpCpyForAplAtClass(class, thisObj, mfail) \
        _t5CmpCpyForAplAtClass(class, FALSE, thisObj, mfail)
#define t5CmpCpyForAplAtParent(class, thisObj, mfail) \
        _t5CmpCpyForAplAtClass(class, TRUE, thisObj, mfail)

#define t5CmpPartMsg(thisObj, mfail) \
        _t5CmpPartMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5CmpPartMsgAtClass(class, thisObj, mfail) \
        _t5CmpPartMsgAtClass(class, FALSE, thisObj, mfail)
#define t5CmpPartMsgAtParent(class, thisObj, mfail) \
        _t5CmpPartMsgAtClass(class, TRUE, thisObj, mfail)

#define t5CmpStatusUpdMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CmpStatusUpdMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CmpStatusUpdMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CmpStatusUpdMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CmpStatusUpdMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CmpStatusUpdMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5CnvrtDocMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5CnvrtDocMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5CnvrtDocMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5CnvrtDocMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5CnvrtDocMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5CnvrtDocMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5ColourSchmNomenVSetMsg(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ColourSchmNomenVSetMsgAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ColourSchmNomenVSetMsgAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ColourSchmNomenVSetMsgAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ColourSchmNomenVSetMsgAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ColourSchmNomenVSetMsgAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5ContextBOMViewJT(thisObj, mfail) \
        _t5ContextBOMViewJTAtClass(NULL, FALSE, thisObj, mfail)
#define t5ContextBOMViewJTAtClass(class, thisObj, mfail) \
        _t5ContextBOMViewJTAtClass(class, FALSE, thisObj, mfail)
#define t5ContextBOMViewJTAtParent(class, thisObj, mfail) \
        _t5ContextBOMViewJTAtClass(class, TRUE, thisObj, mfail)

#define t5CreMBPAForExpMsg(thisObj, mfail) \
        _t5CreMBPAForExpMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5CreMBPAForExpMsgAtClass(class, thisObj, mfail) \
        _t5CreMBPAForExpMsgAtClass(class, FALSE, thisObj, mfail)
#define t5CreMBPAForExpMsgAtParent(class, thisObj, mfail) \
        _t5CreMBPAForExpMsgAtClass(class, TRUE, thisObj, mfail)

#define t5CreRelMepParts(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _t5CreRelMepPartsAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define t5CreRelMepPartsAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _t5CreRelMepPartsAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define t5CreRelMepPartsAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _t5CreRelMepPartsAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define t5CreUpdBOMMsg(className, dialogObj, chldObjSet, relObjSet, mfail) \
        _t5CreUpdBOMMsg(className, FALSE, className, dialogObj, chldObjSet, relObjSet, mfail)
#define t5CreUpdBOMMsgAtParent(_class, className, dialogObj, chldObjSet, relObjSet, mfail) \
        _t5CreUpdBOMMsg(_class, TRUE, className, dialogObj, chldObjSet, relObjSet, mfail)

#define t5CreateRelEPA(thisObj, mfail) \
        _t5CreateRelEPAAtClass(NULL, FALSE, thisObj, mfail)
#define t5CreateRelEPAAtClass(class, thisObj, mfail) \
        _t5CreateRelEPAAtClass(class, FALSE, thisObj, mfail)
#define t5CreateRelEPAAtParent(class, thisObj, mfail) \
        _t5CreateRelEPAAtClass(class, TRUE, thisObj, mfail)

#define t5CustDocReplication(thisObj, mfail) \
        _t5CustDocReplicationAtClass(NULL, FALSE, thisObj, mfail)
#define t5CustDocReplicationAtClass(class, thisObj, mfail) \
        _t5CustDocReplicationAtClass(class, FALSE, thisObj, mfail)
#define t5CustDocReplicationAtParent(class, thisObj, mfail) \
        _t5CustDocReplicationAtClass(class, TRUE, thisObj, mfail)

#define t5CustPartReplication(thisObj, mfail) \
        _t5CustPartReplicationAtClass(NULL, FALSE, thisObj, mfail)
#define t5CustPartReplicationAtClass(class, thisObj, mfail) \
        _t5CustPartReplicationAtClass(class, FALSE, thisObj, mfail)
#define t5CustPartReplicationAtParent(class, thisObj, mfail) \
        _t5CustPartReplicationAtClass(class, TRUE, thisObj, mfail)

#define t5DComAgencyValueSet(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DComAgencyValueSetAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DComAgencyValueSetAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DComAgencyValueSetAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DComAgencyValueSetAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DComAgencyValueSetAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5DComTypeValueSet(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DComTypeValueSetAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DComTypeValueSetAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DComTypeValueSetAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DComTypeValueSetAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DComTypeValueSetAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5DDrgDocCpyValueSet(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DDrgDocCpyValueSetAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DDrgDocCpyValueSetAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DDrgDocCpyValueSetAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DDrgDocCpyValueSetAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DDrgDocCpyValueSetAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5DDrgDocValueSet(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DDrgDocValueSetAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DDrgDocValueSetAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DDrgDocValueSetAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DDrgDocValueSetAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DDrgDocValueSetAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5DMLFailMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5DMLFailMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5DMLFailMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5DMLFailMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5DMLFailMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5DMLFailMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5DMLPrintReport(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DMLPrintReportAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5DMLPrintReportAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DMLPrintReportAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5DMLPrintReportAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DMLPrintReportAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5DMUreview(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5DMUreviewAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5DMUreviewAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5DMUreviewAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5DMUreviewAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5DMUreviewAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5DPlantDeptVSet(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DPlantDeptVSetAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DPlantDeptVSetAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DPlantDeptVSetAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DPlantDeptVSetAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DPlantDeptVSetAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5DPlantVehTypeVSet(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DPlantVehTypeVSetAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DPlantVehTypeVSetAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DPlantVehTypeVSetAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5DPlantVehTypeVSetAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5DPlantVehTypeVSetAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5DataDownLoadMsg(className, SelectedItems, mfail) \
        _t5DataDownLoadMsg(className, FALSE, className, SelectedItems, mfail)
#define t5DataDownLoadMsgAtParent(_class, className, SelectedItems, mfail) \
        _t5DataDownLoadMsg(_class, TRUE, className, SelectedItems, mfail)

#define t5DcrRept(thisObj, mfail) \
        _t5DcrReptAtClass(NULL, FALSE, thisObj, mfail)
#define t5DcrReptAtClass(class, thisObj, mfail) \
        _t5DcrReptAtClass(class, FALSE, thisObj, mfail)
#define t5DcrReptAtParent(class, thisObj, mfail) \
        _t5DcrReptAtClass(class, TRUE, thisObj, mfail)

#define t5DelAllPrtsMsg(className, parameterSet, outputSet, mfail) \
        _t5DelAllPrtsMsg(className, FALSE, className, parameterSet, outputSet, mfail)
#define t5DelAllPrtsMsgAtParent(_class, className, parameterSet, outputSet, mfail) \
        _t5DelAllPrtsMsg(_class, TRUE, className, parameterSet, outputSet, mfail)

#define t5DesDocUpdMsg(thisObj, mfail) \
        _t5DesDocUpdMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5DesDocUpdMsgAtClass(class, thisObj, mfail) \
        _t5DesDocUpdMsgAtClass(class, FALSE, thisObj, mfail)
#define t5DesDocUpdMsgAtParent(class, thisObj, mfail) \
        _t5DesDocUpdMsgAtClass(class, TRUE, thisObj, mfail)

#define t5DlgShowMsg(className, brwObj, mfail) \
        _t5DlgShowMsg(className, FALSE, className, brwObj, mfail)
#define t5DlgShowMsgAtParent(_class, className, brwObj, mfail) \
        _t5DlgShowMsg(_class, TRUE, className, brwObj, mfail)

#define t5DmlDrwRlRpt(thisObj, mfail) \
        _t5DmlDrwRlRptAtClass(NULL, FALSE, thisObj, mfail)
#define t5DmlDrwRlRptAtClass(class, thisObj, mfail) \
        _t5DmlDrwRlRptAtClass(class, FALSE, thisObj, mfail)
#define t5DmlDrwRlRptAtParent(class, thisObj, mfail) \
        _t5DmlDrwRlRptAtClass(class, TRUE, thisObj, mfail)

#define t5DmlPDD(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DmlPDDAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5DmlPDDAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DmlPDDAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5DmlPDDAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DmlPDDAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5DownLoadBomCadMsg(thisObj, mfail) \
        _t5DownLoadBomCadMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5DownLoadBomCadMsgAtClass(class, thisObj, mfail) \
        _t5DownLoadBomCadMsgAtClass(class, FALSE, thisObj, mfail)
#define t5DownLoadBomCadMsgAtParent(class, thisObj, mfail) \
        _t5DownLoadBomCadMsgAtClass(class, TRUE, thisObj, mfail)

#define t5DptDocClsMsg(thisObj, mfail) \
        _t5DptDocClsMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5DptDocClsMsgAtClass(class, thisObj, mfail) \
        _t5DptDocClsMsgAtClass(class, FALSE, thisObj, mfail)
#define t5DptDocClsMsgAtParent(class, thisObj, mfail) \
        _t5DptDocClsMsgAtClass(class, TRUE, thisObj, mfail)

#define t5DrgDocUpdMsg(thisObj, mfail) \
        _t5DrgDocUpdMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5DrgDocUpdMsgAtClass(class, thisObj, mfail) \
        _t5DrgDocUpdMsgAtClass(class, FALSE, thisObj, mfail)
#define t5DrgDocUpdMsgAtParent(class, thisObj, mfail) \
        _t5DrgDocUpdMsgAtClass(class, TRUE, thisObj, mfail)

#define t5DymDmlMsg(className, mfail) \
        _t5DymDmlMsg(className, FALSE, className, mfail)
#define t5DymDmlMsgAtParent(_class, className, mfail) \
        _t5DymDmlMsg(_class, TRUE, className, mfail)

#define t5DymVltMsg(className, mfail) \
        _t5DymVltMsg(className, FALSE, className, mfail)
#define t5DymVltMsgAtParent(_class, className, mfail) \
        _t5DymVltMsg(_class, TRUE, className, mfail)

#define t5ECNApproveMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNApproveMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ECNApproveMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNApproveMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ECNApproveMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNApproveMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ECNRlzdProc(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNRlzdProcAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ECNRlzdProcAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNRlzdProcAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ECNRlzdProcAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNRlzdProcAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ECNStateChngMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNStateChngMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ECNStateChngMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNStateChngMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ECNStateChngMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNStateChngMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ECNStateChngSTDRel(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNStateChngSTDRelAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ECNStateChngSTDRelAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNStateChngSTDRelAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ECNStateChngSTDRelAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ECNStateChngSTDRelAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5EcnAplBom(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5EcnAplBomAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5EcnAplBomAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5EcnAplBomAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5EcnAplBomAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5EcnAplBomAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5EpaCreate(thisObj, mfail) \
        _t5EpaCreateAtClass(NULL, FALSE, thisObj, mfail)
#define t5EpaCreateAtClass(class, thisObj, mfail) \
        _t5EpaCreateAtClass(class, FALSE, thisObj, mfail)
#define t5EpaCreateAtParent(class, thisObj, mfail) \
        _t5EpaCreateAtClass(class, TRUE, thisObj, mfail)

#define t5EpaPartXfer(thisObj, mfail) \
        _t5EpaPartXferAtClass(NULL, FALSE, thisObj, mfail)
#define t5EpaPartXferAtClass(class, thisObj, mfail) \
        _t5EpaPartXferAtClass(class, FALSE, thisObj, mfail)
#define t5EpaPartXferAtParent(class, thisObj, mfail) \
        _t5EpaPartXferAtClass(class, TRUE, thisObj, mfail)

#define t5ErcAplStrMismatch(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ErcAplStrMismatchAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ErcAplStrMismatchAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ErcAplStrMismatchAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ErcAplStrMismatchAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ErcAplStrMismatchAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ErcRlzdProc(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ErcRlzdProcAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ErcRlzdProcAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ErcRlzdProcAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ErcRlzdProcAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ErcRlzdProcAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5FTPTransferMsg(thisObj, mfail) \
        _t5FTPTransferMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5FTPTransferMsgAtClass(class, thisObj, mfail) \
        _t5FTPTransferMsgAtClass(class, FALSE, thisObj, mfail)
#define t5FTPTransferMsgAtParent(class, thisObj, mfail) \
        _t5FTPTransferMsgAtClass(class, TRUE, thisObj, mfail)

#define t5FinalizeTsk(thisObj, mfail) \
        _t5FinalizeTskAtClass(NULL, FALSE, thisObj, mfail)
#define t5FinalizeTskAtClass(class, thisObj, mfail) \
        _t5FinalizeTskAtClass(class, FALSE, thisObj, mfail)
#define t5FinalizeTskAtParent(class, thisObj, mfail) \
        _t5FinalizeTskAtClass(class, TRUE, thisObj, mfail)

#define t5GenerateColorBOM(thisObj, mfail) \
        _t5GenerateColorBOMAtClass(NULL, FALSE, thisObj, mfail)
#define t5GenerateColorBOMAtClass(class, thisObj, mfail) \
        _t5GenerateColorBOMAtClass(class, FALSE, thisObj, mfail)
#define t5GenerateColorBOMAtParent(class, thisObj, mfail) \
        _t5GenerateColorBOMAtClass(class, TRUE, thisObj, mfail)

#define t5GetAttributes(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetAttributesAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetAttributesAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetAttributesAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetAttributesAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetAttributesAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GetDICrtrLglMsg(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetDICrtrLglMsgAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetDICrtrLglMsgAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetDICrtrLglMsgAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetDICrtrLglMsgAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetDICrtrLglMsgAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GetDmlClass(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetDmlClassAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetDmlClassAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetDmlClassAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetDmlClassAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetDmlClassAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GetEpaExt(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetEpaExtAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetEpaExtAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetEpaExtAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetEpaExtAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetEpaExtAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GetLeftNRight(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetLeftNRightAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetLeftNRightAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetLeftNRightAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetLeftNRightAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetLeftNRightAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GetOperator(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetOperatorAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetOperatorAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetOperatorAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetOperatorAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetOperatorAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GetPrtClass(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetPrtClassAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetPrtClassAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetPrtClassAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetPrtClassAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetPrtClassAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GetStoreLoc(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetStoreLocAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetStoreLocAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetStoreLocAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetStoreLocAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetStoreLocAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GetSupplierCode(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetSupplierCodeAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetSupplierCodeAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetSupplierCodeAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetSupplierCodeAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetSupplierCodeAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5Getclasses(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetclassesAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetclassesAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetclassesAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5GetclassesAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5GetclassesAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5GrpLoad(className, parameterSet, outputSet, mfail) \
        _t5GrpLoad(className, FALSE, className, parameterSet, outputSet, mfail)
#define t5GrpLoadAtParent(_class, className, parameterSet, outputSet, mfail) \
        _t5GrpLoad(_class, TRUE, className, parameterSet, outputSet, mfail)

#define t5HlgHnumValSet(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5HlgHnumValSetAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5HlgHnumValSetAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5HlgHnumValSetAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5HlgHnumValSetAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5HlgHnumValSetAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5HlgMngrMail(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5HlgMngrMailAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5HlgMngrMailAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5HlgMngrMailAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5HlgMngrMailAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5HlgMngrMailAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5HlgUpd(thisObj, mfail) \
        _t5HlgUpdAtClass(NULL, FALSE, thisObj, mfail)
#define t5HlgUpdAtClass(class, thisObj, mfail) \
        _t5HlgUpdAtClass(class, FALSE, thisObj, mfail)
#define t5HlgUpdAtParent(class, thisObj, mfail) \
        _t5HlgUpdAtClass(class, TRUE, thisObj, mfail)

#define t5IndentMsg(thisObj, mfail) \
        _t5IndentMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5IndentMsgAtClass(class, thisObj, mfail) \
        _t5IndentMsgAtClass(class, FALSE, thisObj, mfail)
#define t5IndentMsgAtParent(class, thisObj, mfail) \
        _t5IndentMsgAtClass(class, TRUE, thisObj, mfail)

#define t5IndentPrintMsg(thisObj, mfail) \
        _t5IndentPrintMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5IndentPrintMsgAtClass(class, thisObj, mfail) \
        _t5IndentPrintMsgAtClass(class, FALSE, thisObj, mfail)
#define t5IndentPrintMsgAtParent(class, thisObj, mfail) \
        _t5IndentPrintMsgAtClass(class, TRUE, thisObj, mfail)

#define t5MBPAFormMsg(thisObj, mfail) \
        _t5MBPAFormMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5MBPAFormMsgAtClass(class, thisObj, mfail) \
        _t5MBPAFormMsgAtClass(class, FALSE, thisObj, mfail)
#define t5MBPAFormMsgAtParent(class, thisObj, mfail) \
        _t5MBPAFormMsgAtClass(class, TRUE, thisObj, mfail)

#define t5MCNRlzdMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5MCNRlzdMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5MCNRlzdMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5MCNRlzdMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5MCNRlzdMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5MCNRlzdMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5MEpaComFormMsg(thisObj, mfail) \
        _t5MEpaComFormMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5MEpaComFormMsgAtClass(class, thisObj, mfail) \
        _t5MEpaComFormMsgAtClass(class, FALSE, thisObj, mfail)
#define t5MEpaComFormMsgAtParent(class, thisObj, mfail) \
        _t5MEpaComFormMsgAtClass(class, TRUE, thisObj, mfail)

#define t5MEpaCreFormMsg(thisObj, mfail) \
        _t5MEpaCreFormMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5MEpaCreFormMsgAtClass(class, thisObj, mfail) \
        _t5MEpaCreFormMsgAtClass(class, FALSE, thisObj, mfail)
#define t5MEpaCreFormMsgAtParent(class, thisObj, mfail) \
        _t5MEpaCreFormMsgAtClass(class, TRUE, thisObj, mfail)

#define t5MainDMLFailMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5MainDMLFailMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5MainDMLFailMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5MainDMLFailMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5MainDMLFailMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5MainDMLFailMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5MulDmlDrwRlRpt(className, selectedItems, msgOptionTag, mfail) \
        _t5MulDmlDrwRlRpt(className, FALSE, className, selectedItems, msgOptionTag, mfail)
#define t5MulDmlDrwRlRptAtParent(_class, className, selectedItems, msgOptionTag, mfail) \
        _t5MulDmlDrwRlRpt(_class, TRUE, className, selectedItems, msgOptionTag, mfail)

#define t5MultiMain(className, parameterSet, outputSet, mfail) \
        _t5MultiMain(className, FALSE, className, parameterSet, outputSet, mfail)
#define t5MultiMainAtParent(_class, className, parameterSet, outputSet, mfail) \
        _t5MultiMain(_class, TRUE, className, parameterSet, outputSet, mfail)

#define t5NMEpaComFormMsg(thisObj, mfail) \
        _t5NMEpaComFormMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5NMEpaComFormMsgAtClass(class, thisObj, mfail) \
        _t5NMEpaComFormMsgAtClass(class, FALSE, thisObj, mfail)
#define t5NMEpaComFormMsgAtParent(class, thisObj, mfail) \
        _t5NMEpaComFormMsgAtClass(class, TRUE, thisObj, mfail)

#define t5PartDocInfoRptMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartDocInfoRptMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5PartDocInfoRptMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartDocInfoRptMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5PartDocInfoRptMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartDocInfoRptMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5PartObsVaultMsg(thisObj, mfail) \
        _t5PartObsVaultMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5PartObsVaultMsgAtClass(class, thisObj, mfail) \
        _t5PartObsVaultMsgAtClass(class, FALSE, thisObj, mfail)
#define t5PartObsVaultMsgAtParent(class, thisObj, mfail) \
        _t5PartObsVaultMsgAtClass(class, TRUE, thisObj, mfail)

#define t5PartOwnerRptMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartOwnerRptMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5PartOwnerRptMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartOwnerRptMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5PartOwnerRptMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartOwnerRptMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5PartWIPVaultMsg(thisObj, mfail) \
        _t5PartWIPVaultMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5PartWIPVaultMsgAtClass(class, thisObj, mfail) \
        _t5PartWIPVaultMsgAtClass(class, FALSE, thisObj, mfail)
#define t5PartWIPVaultMsgAtParent(class, thisObj, mfail) \
        _t5PartWIPVaultMsgAtClass(class, TRUE, thisObj, mfail)

#define t5Populateparts(thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5PopulatepartsAtClass(NULL, FALSE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)
#define t5PopulatepartsAtClass(class, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5PopulatepartsAtClass(class, FALSE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)
#define t5PopulatepartsAtParent(class, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5PopulatepartsAtClass(class, TRUE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)

#define t5PreviewDmlToDenis(thisObj, mfail) \
        _t5PreviewDmlToDenisAtClass(NULL, FALSE, thisObj, mfail)
#define t5PreviewDmlToDenisAtClass(class, thisObj, mfail) \
        _t5PreviewDmlToDenisAtClass(class, FALSE, thisObj, mfail)
#define t5PreviewDmlToDenisAtParent(class, thisObj, mfail) \
        _t5PreviewDmlToDenisAtClass(class, TRUE, thisObj, mfail)

#define t5ProAsmAllRelation(thisObj, mfail) \
        _t5ProAsmAllRelationAtClass(NULL, FALSE, thisObj, mfail)
#define t5ProAsmAllRelationAtClass(class, thisObj, mfail) \
        _t5ProAsmAllRelationAtClass(class, FALSE, thisObj, mfail)
#define t5ProAsmAllRelationAtParent(class, thisObj, mfail) \
        _t5ProAsmAllRelationAtClass(class, TRUE, thisObj, mfail)

#define t5PrtBrkDn(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5PrtBrkDnAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5PrtBrkDnAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5PrtBrkDnAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5PrtBrkDnAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5PrtBrkDnAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5PrtCatCodeList(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5PrtCatCodeListAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5PrtCatCodeListAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5PrtCatCodeListAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5PrtCatCodeListAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5PrtCatCodeListAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5ReWipState(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ReWipStateAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ReWipStateAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ReWipStateAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ReWipStateAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ReWipStateAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5RelXORejMsgProc(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RelXORejMsgProcAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5RelXORejMsgProcAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RelXORejMsgProcAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5RelXORejMsgProcAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RelXORejMsgProcAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5RenameDoc(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RenameDocAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5RenameDocAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RenameDocAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5RenameDocAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RenameDocAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ReplacesPartNoSetMsg(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ReplacesPartNoSetMsgAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ReplacesPartNoSetMsgAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ReplacesPartNoSetMsgAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ReplacesPartNoSetMsgAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ReplacesPartNoSetMsgAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5SLPartMsg(className, mfail) \
        _t5SLPartMsg(className, FALSE, className, mfail)
#define t5SLPartMsgAtParent(_class, className, mfail) \
        _t5SLPartMsg(_class, TRUE, className, mfail)

#define t5SMRelMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SMRelMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SMRelMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SMRelMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SMRelMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SMRelMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5SMStateChngMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SMStateChngMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SMStateChngMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SMStateChngMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SMStateChngMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SMStateChngMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5SPTrnsferToRel(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SPTrnsferToRelAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SPTrnsferToRelAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SPTrnsferToRelAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SPTrnsferToRelAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SPTrnsferToRelAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5SendAPLMailMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SendAPLMailMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SendAPLMailMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SendAPLMailMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SendAPLMailMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SendAPLMailMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5SendMailMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SendMailMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SendMailMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SendMailMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SendMailMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SendMailMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5SetPlanStComplete(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SetPlanStCompleteAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SetPlanStCompleteAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SetPlanStCompleteAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5SetPlanStCompleteAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5SetPlanStCompleteAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ShowLtatBI(thisObj, mfail) \
        _t5ShowLtatBIAtClass(NULL, FALSE, thisObj, mfail)
#define t5ShowLtatBIAtClass(class, thisObj, mfail) \
        _t5ShowLtatBIAtClass(class, FALSE, thisObj, mfail)
#define t5ShowLtatBIAtParent(class, thisObj, mfail) \
        _t5ShowLtatBIAtClass(class, TRUE, thisObj, mfail)

#define t5ShowLtatRef(thisObj, mfail) \
        _t5ShowLtatRefAtClass(NULL, FALSE, thisObj, mfail)
#define t5ShowLtatRefAtClass(class, thisObj, mfail) \
        _t5ShowLtatRefAtClass(class, FALSE, thisObj, mfail)
#define t5ShowLtatRefAtParent(class, thisObj, mfail) \
        _t5ShowLtatRefAtClass(class, TRUE, thisObj, mfail)

#define t5ShowPartHistoryMsg(thisObj, mfail) \
        _t5ShowPartHistoryMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5ShowPartHistoryMsgAtClass(class, thisObj, mfail) \
        _t5ShowPartHistoryMsgAtClass(class, FALSE, thisObj, mfail)
#define t5ShowPartHistoryMsgAtParent(class, thisObj, mfail) \
        _t5ShowPartHistoryMsgAtClass(class, TRUE, thisObj, mfail)

#define t5ShowPdfFileMsg(thisObj, mfail) \
        _t5ShowPdfFileMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5ShowPdfFileMsgAtClass(class, thisObj, mfail) \
        _t5ShowPdfFileMsgAtClass(class, FALSE, thisObj, mfail)
#define t5ShowPdfFileMsgAtParent(class, thisObj, mfail) \
        _t5ShowPdfFileMsgAtClass(class, TRUE, thisObj, mfail)

#define t5StdDmlXfrToDenis(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdDmlXfrToDenisAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdDmlXfrToDenisAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdDmlXfrToDenisAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdDmlXfrToDenisAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdDmlXfrToDenisAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5StdEffMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdEffMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdEffMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5StdEffMsgAtPartL(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtPartLAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdEffMsgAtPartLAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtPartLAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdEffMsgAtPartLAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtPartLAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5StdEffMsgAtPartLNonX(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtPartLNonXAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdEffMsgAtPartLNonXAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtPartLNonXAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdEffMsgAtPartLNonXAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgAtPartLNonXAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5StdEffMsgWithSGR(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgWithSGRAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdEffMsgWithSGRAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgWithSGRAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdEffMsgWithSGRAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdEffMsgWithSGRAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5StdRestructMailMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdRestructMailMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdRestructMailMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdRestructMailMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5StdRestructMailMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5StdRestructMailMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5StrUpd(thisObj, mfail) \
        _t5StrUpdAtClass(NULL, FALSE, thisObj, mfail)
#define t5StrUpdAtClass(class, thisObj, mfail) \
        _t5StrUpdAtClass(class, FALSE, thisObj, mfail)
#define t5StrUpdAtParent(class, thisObj, mfail) \
        _t5StrUpdAtClass(class, TRUE, thisObj, mfail)

#define t5TaskApproveMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5TaskApproveMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5TaskApproveMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5TaskApproveMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5TaskApproveMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5TaskApproveMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5TransferDmlToDenis(thisObj, mfail) \
        _t5TransferDmlToDenisAtClass(NULL, FALSE, thisObj, mfail)
#define t5TransferDmlToDenisAtClass(class, thisObj, mfail) \
        _t5TransferDmlToDenisAtClass(class, FALSE, thisObj, mfail)
#define t5TransferDmlToDenisAtParent(class, thisObj, mfail) \
        _t5TransferDmlToDenisAtClass(class, TRUE, thisObj, mfail)

#define t5TranslateDoc(thisObj, mfail) \
        _t5TranslateDocAtClass(NULL, FALSE, thisObj, mfail)
#define t5TranslateDocAtClass(class, thisObj, mfail) \
        _t5TranslateDocAtClass(class, FALSE, thisObj, mfail)
#define t5TranslateDocAtParent(class, thisObj, mfail) \
        _t5TranslateDocAtClass(class, TRUE, thisObj, mfail)

#define t5TranslateDoc1(thisObj, mfail) \
        _t5TranslateDoc1AtClass(NULL, FALSE, thisObj, mfail)
#define t5TranslateDoc1AtClass(class, thisObj, mfail) \
        _t5TranslateDoc1AtClass(class, FALSE, thisObj, mfail)
#define t5TranslateDoc1AtParent(class, thisObj, mfail) \
        _t5TranslateDoc1AtClass(class, TRUE, thisObj, mfail)

#define t5TranslateDoc2(thisObj, mfail) \
        _t5TranslateDoc2AtClass(NULL, FALSE, thisObj, mfail)
#define t5TranslateDoc2AtClass(class, thisObj, mfail) \
        _t5TranslateDoc2AtClass(class, FALSE, thisObj, mfail)
#define t5TranslateDoc2AtParent(class, thisObj, mfail) \
        _t5TranslateDoc2AtClass(class, TRUE, thisObj, mfail)

#define t5TranslateMat(thisObj, mfail) \
        _t5TranslateMatAtClass(NULL, FALSE, thisObj, mfail)
#define t5TranslateMatAtClass(class, thisObj, mfail) \
        _t5TranslateMatAtClass(class, FALSE, thisObj, mfail)
#define t5TranslateMatAtParent(class, thisObj, mfail) \
        _t5TranslateMatAtClass(class, TRUE, thisObj, mfail)

#define t5UPLPartMsg(className, mfail) \
        _t5UPLPartMsg(className, FALSE, className, mfail)
#define t5UPLPartMsgAtParent(_class, className, mfail) \
        _t5UPLPartMsg(_class, TRUE, className, mfail)

#define t5UpdClsMsg(thisObj, mfail) \
        _t5UpdClsMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5UpdClsMsgAtClass(class, thisObj, mfail) \
        _t5UpdClsMsgAtClass(class, FALSE, thisObj, mfail)
#define t5UpdClsMsgAtParent(class, thisObj, mfail) \
        _t5UpdClsMsgAtClass(class, TRUE, thisObj, mfail)

#define t5UpdateLoadMsg(thisObj, mfail) \
        _t5UpdateLoadMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5UpdateLoadMsgAtClass(class, thisObj, mfail) \
        _t5UpdateLoadMsgAtClass(class, FALSE, thisObj, mfail)
#define t5UpdateLoadMsgAtParent(class, thisObj, mfail) \
        _t5UpdateLoadMsgAtClass(class, TRUE, thisObj, mfail)

#define t5VCGeneration(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5VCGenerationAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5VCGenerationAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5VCGenerationAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5VCGenerationAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5VCGenerationAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ValCfgList(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValCfgListAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ValCfgListAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValCfgListAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ValCfgListAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValCfgListAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5ValColSch(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValColSchAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ValColSchAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValColSchAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ValColSchAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValColSchAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5ValPrdFam(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValPrdFamAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ValPrdFamAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValPrdFamAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define t5ValPrdFamAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _t5ValPrdFamAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define t5ValTaskforSTDRel(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ValTaskforSTDRelAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ValTaskforSTDRelAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ValTaskforSTDRelAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ValTaskforSTDRelAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ValTaskforSTDRelAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ValidateforSTDRel(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ValidateforSTDRelAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ValidateforSTDRelAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ValidateforSTDRelAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ValidateforSTDRelAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ValidateforSTDRelAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ViewAsStoredJT(thisObj, mfail) \
        _t5ViewAsStoredJTAtClass(NULL, FALSE, thisObj, mfail)
#define t5ViewAsStoredJTAtClass(class, thisObj, mfail) \
        _t5ViewAsStoredJTAtClass(class, FALSE, thisObj, mfail)
#define t5ViewAsStoredJTAtParent(class, thisObj, mfail) \
        _t5ViewAsStoredJTAtClass(class, TRUE, thisObj, mfail)

#define t5ViewJTCollectionUnix(thisObj, mfail) \
        _t5ViewJTCollectionUnixAtClass(NULL, FALSE, thisObj, mfail)
#define t5ViewJTCollectionUnixAtClass(class, thisObj, mfail) \
        _t5ViewJTCollectionUnixAtClass(class, FALSE, thisObj, mfail)
#define t5ViewJTCollectionUnixAtParent(class, thisObj, mfail) \
        _t5ViewJTCollectionUnixAtClass(class, TRUE, thisObj, mfail)

#define t5ViewProeAssyJTUnix(thisObj, mfail) \
        _t5ViewProeAssyJTUnixAtClass(NULL, FALSE, thisObj, mfail)
#define t5ViewProeAssyJTUnixAtClass(class, thisObj, mfail) \
        _t5ViewProeAssyJTUnixAtClass(class, FALSE, thisObj, mfail)
#define t5ViewProeAssyJTUnixAtParent(class, thisObj, mfail) \
        _t5ViewProeAssyJTUnixAtClass(class, TRUE, thisObj, mfail)

#define t5ViewStampFailMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ViewStampFailMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ViewStampFailMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ViewStampFailMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ViewStampFailMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ViewStampFailMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5VltTrnsferToRel(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5VltTrnsferToRelAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5VltTrnsferToRelAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5VltTrnsferToRelAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5VltTrnsferToRelAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5VltTrnsferToRelAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5WDPartEPA(thisObj, mfail) \
        _t5WDPartEPAAtClass(NULL, FALSE, thisObj, mfail)
#define t5WDPartEPAAtClass(class, thisObj, mfail) \
        _t5WDPartEPAAtClass(class, FALSE, thisObj, mfail)
#define t5WDPartEPAAtParent(class, thisObj, mfail) \
        _t5WDPartEPAAtClass(class, TRUE, thisObj, mfail)

#define t5WtRollUp(thisObj, mfail) \
        _t5WtRollUpAtClass(NULL, FALSE, thisObj, mfail)
#define t5WtRollUpAtClass(class, thisObj, mfail) \
        _t5WtRollUpAtClass(class, FALSE, thisObj, mfail)
#define t5WtRollUpAtParent(class, thisObj, mfail) \
        _t5WtRollUpAtClass(class, TRUE, thisObj, mfail)

#define t5XfrAPLDmlToDenis(thisObj, mfail) \
        _t5XfrAPLDmlToDenisAtClass(NULL, FALSE, thisObj, mfail)
#define t5XfrAPLDmlToDenisAtClass(class, thisObj, mfail) \
        _t5XfrAPLDmlToDenisAtClass(class, FALSE, thisObj, mfail)
#define t5XfrAPLDmlToDenisAtParent(class, thisObj, mfail) \
        _t5XfrAPLDmlToDenisAtClass(class, TRUE, thisObj, mfail)

#define t5xfrMasterToRel(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5xfrMasterToRelAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5xfrMasterToRelAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5xfrMasterToRelAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5xfrMasterToRelAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5xfrMasterToRelAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define y00About(className, mfail) \
        _y00About(className, FALSE, className, mfail)
#define y00AboutAtParent(_class, className, mfail) \
        _y00About(_class, TRUE, className, mfail)

#define y00ConstructClass(classname, classObj, mfail) \
        _y00ConstructClass(classname, FALSE, classname, classObj, mfail)
#define y00ConstructClassAtParent(_class, classname, classObj, mfail) \
        _y00ConstructClass(_class, TRUE, classname, classObj, mfail)

#define y00ConstructMODeLCmp(classname, name, classObj, mfail) \
        _y00ConstructMODeLCmp(classname, FALSE, classname, name, classObj, mfail)
#define y00ConstructMODeLCmpAtParent(_class, classname, name, classObj, mfail) \
        _y00ConstructMODeLCmp(_class, TRUE, classname, name, classObj, mfail)

#define y00ContractRuleDP(thisObj, mfail) \
        _y00ContractRuleDPAtClass(NULL, FALSE, thisObj, mfail)
#define y00ContractRuleDPAtClass(class, thisObj, mfail) \
        _y00ContractRuleDPAtClass(class, FALSE, thisObj, mfail)
#define y00ContractRuleDPAtParent(class, thisObj, mfail) \
        _y00ContractRuleDPAtClass(class, TRUE, thisObj, mfail)

#define y00Dump(thisObj, mfail) \
        _y00DumpAtClass(NULL, FALSE, thisObj, mfail)
#define y00DumpAtClass(class, thisObj, mfail) \
        _y00DumpAtClass(class, FALSE, thisObj, mfail)
#define y00DumpAtParent(class, thisObj, mfail) \
        _y00DumpAtClass(class, TRUE, thisObj, mfail)

#define y00DumpSet(className, SelectedItems, mfail) \
        _y00DumpSet(className, FALSE, className, SelectedItems, mfail)
#define y00DumpSetAtParent(_class, className, SelectedItems, mfail) \
        _y00DumpSet(_class, TRUE, className, SelectedItems, mfail)

#define y00ExpandBrwComponent(BrcObj, side, otherSideObjSet, relObjSet, mfail) \
        _y00ExpandBrwComponentAtClass(NULL, FALSE, BrcObj, side, otherSideObjSet, relObjSet, mfail)
#define y00ExpandBrwComponentAtClass(class, BrcObj, side, otherSideObjSet, relObjSet, mfail) \
        _y00ExpandBrwComponentAtClass(class, FALSE, BrcObj, side, otherSideObjSet, relObjSet, mfail)
#define y00ExpandBrwComponentAtParent(class, BrcObj, side, otherSideObjSet, relObjSet, mfail) \
        _y00ExpandBrwComponentAtClass(class, TRUE, BrcObj, side, otherSideObjSet, relObjSet, mfail)

#define y00ExpandRuleDP(thisObj, mfail) \
        _y00ExpandRuleDPAtClass(NULL, FALSE, thisObj, mfail)
#define y00ExpandRuleDPAtClass(class, thisObj, mfail) \
        _y00ExpandRuleDPAtClass(class, FALSE, thisObj, mfail)
#define y00ExpandRuleDPAtParent(class, thisObj, mfail) \
        _y00ExpandRuleDPAtClass(class, TRUE, thisObj, mfail)

#define y00FilterRules(classname, qrydef, ruleSet, mfail) \
        _y00FilterRules(classname, FALSE, classname, qrydef, ruleSet, mfail)
#define y00FilterRulesAtParent(_class, classname, qrydef, ruleSet, mfail) \
        _y00FilterRules(_class, TRUE, classname, qrydef, ruleSet, mfail)

#define y00RemoveGhostDP(className, mfail) \
        _y00RemoveGhostDP(className, FALSE, className, mfail)
#define y00RemoveGhostDPAtParent(_class, className, mfail) \
        _y00RemoveGhostDP(_class, TRUE, className, mfail)

#define y00RemoveRedundantDP(className, mfail) \
        _y00RemoveRedundantDP(className, FALSE, className, mfail)
#define y00RemoveRedundantDPAtParent(_class, className, mfail) \
        _y00RemoveRedundantDP(_class, TRUE, className, mfail)

#define y00SetDefaults(classObj, name, mfail) \
        _y00SetDefaultsAtClass(NULL, FALSE, classObj, name, mfail)
#define y00SetDefaultsAtClass(class, classObj, name, mfail) \
        _y00SetDefaultsAtClass(class, FALSE, classObj, name, mfail)
#define y00SetDefaultsAtParent(class, classObj, name, mfail) \
        _y00SetDefaultsAtClass(class, TRUE, classObj, name, mfail)
#endif /* for msgtel_H */

