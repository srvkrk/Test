/* 
   PATCH:
   DATE : 24-SEP-94
   AUTHOR MSR
   SRFNO: DENOTH-026
   DESC : A new field delete_ind of 1 char has been added to the 
		  data structure expl_prt.  This delete_ind will be used
		  in exp_rep.pc for printing '***' for parts which have a
		  not null delete_ind. Relevant changes have been made in
		  DZ_explode1.pc, DZ_implode1.pc
*/

#define BO_CS( x )     (x == 10 || x == 11 || x == 12 || \
				    	x == 13 || x == 14 || x == 20 || \
					    x == 22 || x == 24 || x == 26 || \
						x == 45 || x == 46 || x == 47 || \
						x == 25 || x == 28 || x == 29 || \
						x == 40 || x == 41 || x == 48 || \
						x == 49 || x == 50 || x == 51 || \
						x == 58 || x == 59 || x == 81 ) 

#define MATL_CS  (cs == 10 || cs == 11 || cs == 12 || \
				    	  cs == 13 || cs == 17 || cs == 18 || \
							  cs == 22 || cs == 28  || cs == 40 || cs == 42 ||\
								cs == 45 || cs == 46 || cs == 48 || \
								cs == 50 || cs == 52 || cs == 55 || cs == 56 ||\
								cs == 58 || cs == 60 || cs == 81 ) 

#define BOUGHTOUT_CS (  cs == 10 ||cs == 11 || cs == 12 || cs == 13 \
                     || cs == 14 || cs == 20  \
                     || cs == 17 || cs == 22  \
                     || cs == 28 || cs == 40 || cs == 42||cs == 45 || cs == 46 \
                     || cs == 47 || cs == 48 || cs == 50 ||cs == 52|| cs == 55 \
                     || cs == 56 || cs == 57 || cs == 58 )

/* #define MATL_CS (  cs == 10 || cs == 11 || cs == 12 || cs == 13 \
               || cs == 17 || cs == 18 \
               || cs == 21 || cs == 22 || cs == 28 \
               || cs == 43 || cs == 45 || cs == 46 || cs == 53 \
               || cs == 55 || cs == 56 \
               || cs == 81 ) */

#define UCMATL_CS  (cs == 10 || cs == 11 || cs == 12 || \
				    	  cs == 13 || cs == 17 || \
							  cs == 22 || cs == 28  || cs == 40 || cs == 42 ||\
								cs == 45 || cs == 46 || cs == 48 || \
								cs == 50 || cs == 52 || cs == 55 || cs == 56 ||\
								cs == 58 || cs == 60 || cs == 81 ) 

#define UCBOUGHTOUT_CS (  cs == 10 || cs == 12 || cs == 13 \
                     || cs == 14 || cs ==18 || cs == 19  \
                     || cs == 20 || cs == 22  || cs == 24 || cs == 26 \
                     || cs == 28 || cs == 29 || cs == 45 || cs == 46 \
                     || cs == 47 || cs == 48 || cs == 49 || cs == 55 \
                     || cs == 56 || cs == 57 || cs == 58 || cs == 59 \
					 || cs == 81 || cs == 82 )

#define BOUGHTOUT 'S'
#define MATERIAL 'M'
#define BOTH 'B'
#define NONE 'N'

struct expl_prt	{
				 char assy_partno[15];
				 char comp_partno[15];
				 char loc[4];
  			 int  appl_cs1;          /* for cs change */
				 int  group_id ;
				 double qty;
				 char val_dml_group[4];
				 int  cs ;                /* for indent  */
				 int  cs2;
				 char  uq[2] ;
				 char acr_ind[3];
				 char initial_agency[3];
				 char major_change[2];
				 char replaces_partno[15];
				 char op_code[3];
				 char validating_epa[11];
				 char invalidating_epa[11];
				 char validating_dml[11];
				 char invalidating_dml[11];
				 char new_part[2];
				 char remark_codes[31];
				 int  serial;              
				 int  ins_level;
				 char description[41] ; 
				 double assy_qty;
				 char delete_ind; /* added by msr 24-SEP-94 */
				} ;


/* MSR   MIGRATION TO IBM R24 Wed Mar 29 16:06:07 IST 1995
struct expl_prt * DZ_explode(char *partno,int level,char *agency,char * date,char stop_cs, int consolidate,char application);

struct expl_prt * DZ_explode1(char *partno,int level,char *agency,char * date,char stop_cs, int consolidate,char application);
MSR   MIGRATION TO IBM R24 Wed Mar 29 16:06:07 IST 1995 */
/* 	partno : string of partnos with spaces as field separator 
		 agency : ie. STDSI APL ERC 
		 level  : stop level 1 for single level explosion 
							99 is the max. level 
		 date   : in yymmdd format 
	   stop_cs : 'M'  for  material  cs
								'S' bought out cs 
								'B'  both the cs 
							 anything else is treated as no stop cs condition 
	   consolidate : 1 for qty multiplication down the level 
	   application : 'I'(endent) for addition of qtys(multiplied) for assy_comp
												comb. anywhere 
								 : 'A'(pplicability matrix) ie alternates are not processed 
			 Explosion starts with the first record with level 0 and 
			 assy=comp=first part from *partno string to mark expl of first partno
			 like wise subsequent partnos are taken  */

/* MSR   MIGRATION TO IBM R24 Wed Mar 29 16:06:07 IST 1995
struct expl_prt * DZ_implode(char *partno,int level,char *agency,char * date,char stop_cs, int consolidate)  ;

struct expl_prt * DZ_implode1(char *partno,int level,char *agency,char * date,char stop_cs, int consolidate)  ;
MSR   MIGRATION TO IBM R24 Wed Mar 29 16:06:07 IST 1995 */
/* consolidate : 1 for sum of qty(multiplied) .only part having no impl 
									are reported */

/* MSR   MIGRATION TO IBM R24 Wed Mar 29 16:06:07 IST 1995
extern struct expl_prt *DZ_net_diff(
	char* D_assy1,int D_lvl1, char *D_ag1, char * D_dt1,
	char D_stop_cs1, double D_qty1, int D_cons1,
	char* D_assy2,int D_lvl2, char *D_ag2, char * D_dt2,
	char D_stop_cs2, double D_qty2, int D_cons2 
) ;
MSR   MIGRATION TO IBM R24 Wed Mar 29 16:06:07 IST 1995 */
