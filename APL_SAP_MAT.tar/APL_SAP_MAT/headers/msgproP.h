/*
 *  FILE: msgproP.h
 */

#ifndef msgproP_H
#define msgproP_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _DoRgstUnknownAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _FindInstObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects instObjs, integer * mfail);

MTIstatus _FindInstObjsSingleAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects instObjs, integer * mfail);

MTIstatus _ProGetRelatedPsmPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * partObjSet, integer * mfail);

#ifdef _LCINTERP_
}
#else
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define DoRgstUnknown(this, dialogObj, mfail) \
        _DoRgstUnknownAtClass(NULL, FALSE, this, dialogObj, mfail)
#define DoRgstUnknownAtClass(class, this, dialogObj, mfail) \
        _DoRgstUnknownAtClass(class, FALSE, this, dialogObj, mfail)
#define DoRgstUnknownAtParent(class, this, dialogObj, mfail) \
        _DoRgstUnknownAtClass(class, TRUE, this, dialogObj, mfail)

#define FindInstObjs(this, instObjs, mfail) \
        _FindInstObjsAtClass(NULL, FALSE, this, instObjs, mfail)
#define FindInstObjsAtClass(class, this, instObjs, mfail) \
        _FindInstObjsAtClass(class, FALSE, this, instObjs, mfail)
#define FindInstObjsAtParent(class, this, instObjs, mfail) \
        _FindInstObjsAtClass(class, TRUE, this, instObjs, mfail)

#define FindInstObjsSingle(this, instObjs, mfail) \
        _FindInstObjsSingleAtClass(NULL, FALSE, this, instObjs, mfail)
#define FindInstObjsSingleAtClass(class, this, instObjs, mfail) \
        _FindInstObjsSingleAtClass(class, FALSE, this, instObjs, mfail)
#define FindInstObjsSingleAtParent(class, this, instObjs, mfail) \
        _FindInstObjsSingleAtClass(class, TRUE, this, instObjs, mfail)

#define ProGetRelatedPsmPart(thisObj, partObjSet, mfail) \
        _ProGetRelatedPsmPartAtClass(NULL, FALSE, thisObj, partObjSet, mfail)
#define ProGetRelatedPsmPartAtClass(class, thisObj, partObjSet, mfail) \
        _ProGetRelatedPsmPartAtClass(class, FALSE, thisObj, partObjSet, mfail)
#define ProGetRelatedPsmPartAtParent(class, thisObj, partObjSet, mfail) \
        _ProGetRelatedPsmPartAtClass(class, TRUE, thisObj, partObjSet, mfail)
#endif /* for msgpro_H */

