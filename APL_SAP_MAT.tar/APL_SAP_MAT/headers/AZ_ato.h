		/* General Purpose header for Auto group */

# define SUCCESS 0
# define FAILURE -1
# define VARCPY(target,source) strncpy(target,source,strlen(source))
# define VARCMP(strin1,strin2) strncmp(strin1,strin2,strlen(strin2))
# define END_OF_CURSOR -5
# define SQL_NOTFOUND -2
# define STOVCPY(a,b) strcpy(a.arr,b);a.len=strlen(a.arr)
# define VTOSCPY(a,b) strncpy(a,b.arr,b.len);a[b.len]=NULL
# define VTOVCPY(a,b) strncpy(a.arr,b.arr,b.len);a.len=b.len 
# define SETCHARNULL(char_struct)	memset(char_struct,NULL,sizeof(char_struct))
# define SETVARCHARNULL(struct)	memset(struct.arr,NULL,sizeof(struct.arr));struct.len=0
# define YES 1
# define NO  0

int sql_status;	/* to check result of ZZ_sql_err()	*/

# define IF_FUNC_FAIL(val,msg)\
{\
   if(val == FAILURE)\
	{\
	   printf("%s\n",msg);\
	   return(FAILURE);\
	}\
}
# define IF_SQL_FAIL(msg)\
{\
   if(ZZ_sql_err() != SQL_SUCCESS)\
	{\
	   printf("%s",msg);\
	   return(FAILURE);\
	}\
}

