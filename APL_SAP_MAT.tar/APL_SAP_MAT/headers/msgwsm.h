/*
 *  FILE: msgwsm.h
 */

#ifndef msgwsm_H
#define msgwsm_H

#include <Mtimsgh.h>
#include <metadt.h>
/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _IdentifyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _IsPdpRelProcAllowedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, MTIconstString condId, boolean * condExists,
   integer * mfail);

MTIstatus _IsStateVecOkForRsltRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, boolean * condExists, integer * mfail);

MTIstatus _ValPrdPlnForCkoMkvRsltAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr rsltsRelObj, integer * mfail);

MTIstatus _ValPrdPlnForRevRsltAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr rsltsRelObj, integer * mfail);

MTIstatus _ValProdPlanForCreRsltsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr rsltsRelObj, integer * mfail);

MTIstatus _ValProdPlanForDelRsltsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr resultsRelObj, integer * mfail);

MTIstatus _ValRsltItForCkoMkvRsltAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr rsltsItemObj,
   ObjectPtr rsltsRelObj, boolean * buildRelation, boolean * deleteRelation,
   integer * mfail);

MTIstatus _ValRsltsItemForCreRsltAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr resultItem,
   ObjectPtr resultsRelObj, integer * mfail);

MTIstatus _ValRsltsItemForDelRsltAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr resultItem,
   ObjectPtr resultRelObj, integer * mfail);

MTIstatus _ValRsltsItemForRevRsltAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr rsltsItemObj,
   ObjectPtr rsltsRelObj, boolean * buildRelation, boolean * deleteRelation,
   integer * mfail);

/*
 *  Unpublished Messages
 */

MTIstatus _InflatResourceLstOnSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer scope, SetOfObjects * objects, integer * mfail);

MTIstatus _PrcRsltsForCoMkvRsltItAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr rsltsRelObj,
   ObjectPtr rsltsItemObj, boolean * buildRelation, boolean * deleteRelation,
   integer * mfail);

MTIstatus _ProcRsltsForRevRsltItmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr rsltsRelObj,
   ObjectPtr rsltsItemObj, boolean * buildRelation, boolean * deleteRelation,
   integer * mfail);

MTIstatus _ValPrdPlnForRsltsRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValPrdPlnIsFrzSupersedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);
/*
 *  Protected Messages
 */
/*
 *  Message Macro Definitions.
 */

#define Identify(pdpItem, mfail) \
        _IdentifyAtClass(NULL, FALSE, pdpItem, mfail)
#define IdentifyAtClass(class, pdpItem, mfail) \
        _IdentifyAtClass(class, FALSE, pdpItem, mfail)
#define IdentifyAtParent(class, pdpItem, mfail) \
        _IdentifyAtClass(class, TRUE, pdpItem, mfail)

#define InflatResourceLstOnSet(className, scope, objects, mfail) \
        _InflatResourceLstOnSet(className, FALSE, className, scope, objects, mfail)
#define InflatResourceLstOnSetAtParent(_class, className, scope, objects, mfail) \
        _InflatResourceLstOnSet(_class, TRUE, className, scope, objects, mfail)

#define IsPdpRelProcAllowed(pdpItem, relObj, condId, condExists, mfail) \
        _IsPdpRelProcAllowedAtClass(NULL, FALSE, pdpItem, relObj, condId, condExists, mfail)
#define IsPdpRelProcAllowedAtClass(class, pdpItem, relObj, condId, condExists, mfail) \
        _IsPdpRelProcAllowedAtClass(class, FALSE, pdpItem, relObj, condId, condExists, mfail)
#define IsPdpRelProcAllowedAtParent(class, pdpItem, relObj, condId, condExists, mfail) \
        _IsPdpRelProcAllowedAtClass(class, TRUE, pdpItem, relObj, condId, condExists, mfail)

#define IsStateVecOkForRsltRel(pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForRsltRelAtClass(NULL, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForRsltRelAtClass(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForRsltRelAtClass(class, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForRsltRelAtParent(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForRsltRelAtClass(class, TRUE, pdpItem, relObj, condExists, mfail)

#define PrcRsltsForCoMkvRsltIt(rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail) \
        _PrcRsltsForCoMkvRsltItAtClass(NULL, FALSE, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail)
#define PrcRsltsForCoMkvRsltItAtClass(class, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail) \
        _PrcRsltsForCoMkvRsltItAtClass(class, FALSE, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail)
#define PrcRsltsForCoMkvRsltItAtParent(class, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail) \
        _PrcRsltsForCoMkvRsltItAtClass(class, TRUE, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail)

#define ProcRsltsForRevRsltItm(rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail) \
        _ProcRsltsForRevRsltItmAtClass(NULL, FALSE, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail)
#define ProcRsltsForRevRsltItmAtClass(class, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail) \
        _ProcRsltsForRevRsltItmAtClass(class, FALSE, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail)
#define ProcRsltsForRevRsltItmAtParent(class, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail) \
        _ProcRsltsForRevRsltItmAtClass(class, TRUE, rsltsRelObj, rsltsItemObj, buildRelation, deleteRelation, mfail)

#define ValPrdPlnForCkoMkvRslt(pdpItem, rsltsRelObj, mfail) \
        _ValPrdPlnForCkoMkvRsltAtClass(NULL, FALSE, pdpItem, rsltsRelObj, mfail)
#define ValPrdPlnForCkoMkvRsltAtClass(class, pdpItem, rsltsRelObj, mfail) \
        _ValPrdPlnForCkoMkvRsltAtClass(class, FALSE, pdpItem, rsltsRelObj, mfail)
#define ValPrdPlnForCkoMkvRsltAtParent(class, pdpItem, rsltsRelObj, mfail) \
        _ValPrdPlnForCkoMkvRsltAtClass(class, TRUE, pdpItem, rsltsRelObj, mfail)

#define ValPrdPlnForRevRslt(pdpItem, rsltsRelObj, mfail) \
        _ValPrdPlnForRevRsltAtClass(NULL, FALSE, pdpItem, rsltsRelObj, mfail)
#define ValPrdPlnForRevRsltAtClass(class, pdpItem, rsltsRelObj, mfail) \
        _ValPrdPlnForRevRsltAtClass(class, FALSE, pdpItem, rsltsRelObj, mfail)
#define ValPrdPlnForRevRsltAtParent(class, pdpItem, rsltsRelObj, mfail) \
        _ValPrdPlnForRevRsltAtClass(class, TRUE, pdpItem, rsltsRelObj, mfail)

#define ValPrdPlnForRsltsRel(thisObj, mfail) \
        _ValPrdPlnForRsltsRelAtClass(NULL, FALSE, thisObj, mfail)
#define ValPrdPlnForRsltsRelAtClass(class, thisObj, mfail) \
        _ValPrdPlnForRsltsRelAtClass(class, FALSE, thisObj, mfail)
#define ValPrdPlnForRsltsRelAtParent(class, thisObj, mfail) \
        _ValPrdPlnForRsltsRelAtClass(class, TRUE, thisObj, mfail)

#define ValPrdPlnIsFrzSupersed(thisObj, mfail) \
        _ValPrdPlnIsFrzSupersedAtClass(NULL, FALSE, thisObj, mfail)
#define ValPrdPlnIsFrzSupersedAtClass(class, thisObj, mfail) \
        _ValPrdPlnIsFrzSupersedAtClass(class, FALSE, thisObj, mfail)
#define ValPrdPlnIsFrzSupersedAtParent(class, thisObj, mfail) \
        _ValPrdPlnIsFrzSupersedAtClass(class, TRUE, thisObj, mfail)

#define ValProdPlanForCreRslts(pdpItem, rsltsRelObj, mfail) \
        _ValProdPlanForCreRsltsAtClass(NULL, FALSE, pdpItem, rsltsRelObj, mfail)
#define ValProdPlanForCreRsltsAtClass(class, pdpItem, rsltsRelObj, mfail) \
        _ValProdPlanForCreRsltsAtClass(class, FALSE, pdpItem, rsltsRelObj, mfail)
#define ValProdPlanForCreRsltsAtParent(class, pdpItem, rsltsRelObj, mfail) \
        _ValProdPlanForCreRsltsAtClass(class, TRUE, pdpItem, rsltsRelObj, mfail)

#define ValProdPlanForDelRslts(pdpItem, resultsRelObj, mfail) \
        _ValProdPlanForDelRsltsAtClass(NULL, FALSE, pdpItem, resultsRelObj, mfail)
#define ValProdPlanForDelRsltsAtClass(class, pdpItem, resultsRelObj, mfail) \
        _ValProdPlanForDelRsltsAtClass(class, FALSE, pdpItem, resultsRelObj, mfail)
#define ValProdPlanForDelRsltsAtParent(class, pdpItem, resultsRelObj, mfail) \
        _ValProdPlanForDelRsltsAtClass(class, TRUE, pdpItem, resultsRelObj, mfail)

#define ValRsltItForCkoMkvRslt(rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail) \
        _ValRsltItForCkoMkvRsltAtClass(NULL, FALSE, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail)
#define ValRsltItForCkoMkvRsltAtClass(class, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail) \
        _ValRsltItForCkoMkvRsltAtClass(class, FALSE, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail)
#define ValRsltItForCkoMkvRsltAtParent(class, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail) \
        _ValRsltItForCkoMkvRsltAtClass(class, TRUE, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail)

#define ValRsltsItemForCreRslt(resultItem, resultsRelObj, mfail) \
        _ValRsltsItemForCreRsltAtClass(NULL, FALSE, resultItem, resultsRelObj, mfail)
#define ValRsltsItemForCreRsltAtClass(class, resultItem, resultsRelObj, mfail) \
        _ValRsltsItemForCreRsltAtClass(class, FALSE, resultItem, resultsRelObj, mfail)
#define ValRsltsItemForCreRsltAtParent(class, resultItem, resultsRelObj, mfail) \
        _ValRsltsItemForCreRsltAtClass(class, TRUE, resultItem, resultsRelObj, mfail)

#define ValRsltsItemForDelRslt(resultItem, resultRelObj, mfail) \
        _ValRsltsItemForDelRsltAtClass(NULL, FALSE, resultItem, resultRelObj, mfail)
#define ValRsltsItemForDelRsltAtClass(class, resultItem, resultRelObj, mfail) \
        _ValRsltsItemForDelRsltAtClass(class, FALSE, resultItem, resultRelObj, mfail)
#define ValRsltsItemForDelRsltAtParent(class, resultItem, resultRelObj, mfail) \
        _ValRsltsItemForDelRsltAtClass(class, TRUE, resultItem, resultRelObj, mfail)

#define ValRsltsItemForRevRslt(rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail) \
        _ValRsltsItemForRevRsltAtClass(NULL, FALSE, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail)
#define ValRsltsItemForRevRsltAtClass(class, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail) \
        _ValRsltsItemForRevRsltAtClass(class, FALSE, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail)
#define ValRsltsItemForRevRsltAtParent(class, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail) \
        _ValRsltsItemForRevRsltAtClass(class, TRUE, rsltsItemObj, rsltsRelObj, buildRelation, deleteRelation, mfail)
#endif /* for msgwsm_H */

