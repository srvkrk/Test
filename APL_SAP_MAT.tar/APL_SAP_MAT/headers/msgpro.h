/*
 *  FILE: msgpro.h
 */

#ifndef msgpro_H
#define msgpro_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _DoRgstUnknownAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _FindInstObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects instObjs, integer * mfail);

MTIstatus _FindInstObjsSingleAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects instObjs, integer * mfail);

MTIstatus _ProGetRelatedPsmPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * partObjSet, integer * mfail);

#ifdef _LCINTERP_
}
#else

/*
 *  Unpublished Messages
 */

MTIstatus _AddToIntegrateDirAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string readOnlyDir, integer * mfail);

MTIstatus _AddToWorkbenchDirAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean viewOnly, string workbenchDir, integer * mfail);

MTIstatus _CheckOutReadOnlyProObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr moveDialog, integer * mfail);

MTIstatus _CollectWorkbenchItemsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects itemSet, integer * mfail);

MTIstatus _ConstructProInst
   (MTIstring _class, boolean getParent, string className,
   integer * mfail, ObjectPtr * this);

MTIstatus _CopyProInstObjectsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr newObj, integer * mfail);

MTIstatus _CopyToObjHost
   (MTIstring _class, boolean getParent, string className,
   string workHost, string fileHost, string workPath,
   string filePath, integer * mfail);

MTIstatus _CreateCopyRelation
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr origObj, ObjectPtr newObj, integer * mfail);

MTIstatus _DisplayOption
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _DisplayWorkbenchItems
   (MTIstring _class, boolean getParent, string toolClassName,
   SetOfObjects workbenchSet, integer * mfail);

MTIstatus _DoProRgstUnknown
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr dialogObj, SetOfObjects dirContents, integer * mfail);

MTIstatus _DoPurgeProDirAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _DoPurgeProObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _DoRealPurgeProDir
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects dirContents, integer * mfail);

MTIstatus _DoRenameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string newName, integer * mfail);

MTIstatus _FindGenObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr * genObj, integer * mfail);

MTIstatus _FindGenObjectsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects * genObjs, integer * mfail);

MTIstatus _FindProDepObjectsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects * dependObjSet, SetOfObjects * relObjSet, integer * mfail);

MTIstatus _GetCurObjectInAnyLocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dependObj,
   ObjectPtr * latestObj, integer * mfail);

MTIstatus _GetCurObjectInSameLocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dependObj,
   ObjectPtr * latestObj, integer * mfail);

MTIstatus _GetInflatedHostPathAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string contextHost, string * host, string * path,
   integer * mfail);

MTIstatus _GetObjProVersionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * objVersion, integer * mfail);

MTIstatus _GetProCondition
   (MTIstring _class, boolean getParent, string className,
   string condName, boolean * condValue, boolean * condExists,
   integer * mfail);

MTIstatus _GetProDependentObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects * depObjSet, integer * mfail);

MTIstatus _GetProPrefs
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr * prefObj, integer * mfail);

MTIstatus _GetProRelationObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr dependObj, ObjectPtr * relObj, integer * mfail);

MTIstatus _GetRelatedProObj
   (MTIstring _class, boolean getParent, string className,
   boolean expand, integer scope, string relationship,
   ObjectPtr itemObj, ObjectPtr queryDefinition, SetOfObjects * itemObjs,
   SetOfObjects * relObjs, integer * mfail);

MTIstatus _HandleInterrupts
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _HideWorkbench
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _IsInstanceCheckedOutAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects dependObjSet, boolean * checkout, integer * mfail);

MTIstatus _IsObjExistInSetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects dependObjSet, boolean * objExist, integer * mfail);

MTIstatus _IsProInstRegisteredAtClass
   (MTIstring _class, boolean getParent, ObjectPtr obj,
   boolean * isReg, ObjectPtr * regObj, integer * mfail);

MTIstatus _IsProRelatedTo
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemToCheck, ObjectPtr itemObject, string relationship,
   boolean * answer, integer * mfail);

MTIstatus _IsProVersionSameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr obj1,
   ObjectPtr obj2, boolean * verSame, integer * mfail);

MTIstatus _MakeRelForProWorkB
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr leftObj, ObjectPtr rightObj, integer * mfail,
   ObjectPtr * this);

MTIstatus _PassMtiAttrsToProAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _ProAMGetProEAttributesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string ValueSetName, string LvAttribute, string RealClass,
   ObjectPtr RealObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _ProAMGetSubMTIAttrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string ValueSetName, string LvAttribute, string RealClass,
   ObjectPtr RealObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _ProCheckEditQueryAccesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * editOrViewFlag, integer * mfail);

MTIstatus _ProCheckInAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProCheckInIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProCheckInItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string destOwnerName, integer * mfail);

MTIstatus _ProCheckInNonIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProCheckOutAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr * newWorkItem, integer * mfail);

MTIstatus _ProCheckOutIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr * newWorkItem, integer * mfail);

MTIstatus _ProCheckOutItem2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   string workLoc, ObjectPtr * newWorkItem, integer * mfail);

MTIstatus _ProCheckOutNonIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr * newWorkItem, integer * mfail);

MTIstatus _ProCheckOutObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ProCirProInstObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr oldObj,
   ObjectPtr dlgObj, integer * mfail);

MTIstatus _ProCkConditionExists
   (MTIstring _class, boolean getParent, string className,
   string conditionName, boolean * answer, integer * mfail);

MTIstatus _ProClassify
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr unRegObj, float startProb, float * bestProbability,
   string * bestClass, integer * mfail);

MTIstatus _ProConnectHungProE
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _ProCreateHPGLPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string proWorkingDir, integer * mfail);

MTIstatus _ProCreateHPGLPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string proWorkingDir, integer * mfail);

MTIstatus _ProCreatePsmDocList
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects proparts, SetOfObjects psmObjs, SetOfObjects * psmdoc_proparts,
   SetOfStrings * list_strings, integer * mfail);

MTIstatus _ProCreatePsmRelationsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dataAssmObj,
   SetOfStrings QSet, SetOfObjects componentObjs, SetOfStrings * currentPartPaths,
   SetOfObjects * currentPartMstrs, ObjectPtr * psmAssmObj, integer * mfail);

MTIstatus _ProCreateTecDocObj
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * docObjs, integer * mfail);

MTIstatus _ProCreateTransRel
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr origObj, ObjectPtr newObj, integer * mfail);

MTIstatus _ProCreateUpdPsmRelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProCreateUpdatePsmRelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProCustomMessage1AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string proWorkingDir, ObjectPtr * outObj, integer * mfail);

MTIstatus _ProCustomMessage2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string proWorkingDir, ObjectPtr * outObj, integer * mfail);

MTIstatus _ProCustomMessage3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string proWorkingDir, ObjectPtr * outObj, integer * mfail);

MTIstatus _ProDeleteUnregObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean updateBrowser, integer * mfail);

MTIstatus _ProDoCheckOutAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, integer * mfail);

MTIstatus _ProDoTransferAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj, SetOfObjects rels,
   SetOfObjects leftSide, SetOfObjects rightSide, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProDocPrepInteractFlagAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, integer * uiFlag, integer * mfail);

MTIstatus _ProFndFitHostUsrPath
   (MTIstring _class, boolean getParent, string className,
   string host, string usr, string path,
   ObjectPtr * fileObj, integer * mfail);

MTIstatus _ProGetAttVal2CreBusItmAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr regDialogObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _ProGetAttVal2CrePSMItmAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, ObjectPtr regDialogObj, ObjectPtr dialogObj,
   integer * mfail);

MTIstatus _ProGetAttVal2QryBusObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * docName, integer * mfail);

MTIstatus _ProGetAttVal2QryPSMItmAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, string * docName, integer * mfail);

MTIstatus _ProGetBusObjForProFileAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr regDialogObj, ObjectPtr * docObj, integer * mfail);

MTIstatus _ProGetChekInRPredFrmScAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr * pred, integer * mfail);

MTIstatus _ProGetChekInRScFrmPredAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr * succ, integer * mfail);

MTIstatus _ProGetChkOutRPrdFrmScAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr * pred, integer * mfail);

MTIstatus _ProGetChkOutRScFrmPrdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr * succ, integer * mfail);

MTIstatus _ProGetDataForQueryBIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr regDialogObj, string * qryClassName, SetOfStrings * qryAttrSet,
   SetOfStrings * qryAttrValSet, integer * mfail);

MTIstatus _ProGetDataForQueryPSMAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, ObjectPtr regDialogObj, string * qryClassName,
   SetOfStrings * qryAttrSet, SetOfStrings * qryAttrValSet, integer * mfail);

MTIstatus _ProGetFSItemPathTailAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * pathTail, integer * mfail);

MTIstatus _ProGetMapObjTableData
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings * mtiClasses, SetOfStrings * mtiAttrNames, SetOfStrings * proAttrNames,
   SetOfStrings * directions, integer * mfail);

MTIstatus _ProGetPathHostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * fileHost, string * filePath, integer * mfail);

MTIstatus _ProGetPrepClassForBIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ugPartObj,
   ObjectPtr docObj, string * prepClassName, integer * mfail);

MTIstatus _ProGetPrepClassForDIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ugPartObj,
   string * prepClassName, integer * mfail);

MTIstatus _ProGetPsmObjToPrepareAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, ObjectPtr regDialogObj, ObjectPtr * psmObj,
   integer * mfail);

MTIstatus _ProGetRelObjExtDataAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * depObjs, SetOfObjects * relObjs, integer * mfail);

MTIstatus _ProGetRelObjExtInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * depObjs, SetOfObjects * relObjs, integer * mfail);

MTIstatus _ProGetSavedQueryObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * partObjs, integer * mfail);

MTIstatus _ProGetTemplatePathAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, string * proTemplate, integer * mfail);

MTIstatus _ProInvokeLCMBrw
   (MTIstring _class, boolean getParent, string classname,
   string tagname, integer * mfail);

MTIstatus _ProIsOwnedByVaultAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * vaultObj, boolean * answer, integer * mfail);

MTIstatus _ProIsRelHasCirDepObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * cirDeps, integer * mfail);

MTIstatus _ProMoveObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ProObjPrepInteractFlagAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * uiFlag, integer * mfail);

MTIstatus _ProOpenPSMPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProPSMListDlgAndGetObj
   (MTIstring _class, boolean getParent, string dialogClass,
   SetOfStrings extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProPrepDoCreateBIDlgAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, ObjectPtr regDialogObj, string * defaultClass,
   ObjectPtr * dialogObj, integer * intFlag, integer * mfail);

MTIstatus _ProPrepDoCreateDIDlgAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr regDialogObj, string * defaultClass, ObjectPtr * dialogObj,
   integer * intFlag, integer * mfail);

MTIstatus _ProPrepFileAndDocFuncAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr * docObj, ObjectPtr * psmObj,
   integer * mfail);

MTIstatus _ProPrepareAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProPrepareCheckPSMObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ugItmObj,
   ObjectPtr docItmObj, ObjectPtr psmItmObj, boolean * isMaster,
   integer * mfail);

MTIstatus _ProPrepareDocFuncAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr regDialogObj, ObjectPtr docObj, ObjectPtr * psmObj,
   integer * mfail);

MTIstatus _ProPrepareFileFuncAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr regDialogObj, ObjectPtr * docObj, integer * mfail);

MTIstatus _ProProcessDepsForCkiAtClass
   (MTIstring _class, boolean getParent, ObjectPtr oldObj,
   ObjectPtr dlgObj, integer * mfail);

MTIstatus _ProPsmSetViewNetworkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr psmObj,
   MTIstring curViewNetworkName, MTIstring curViewName, integer * mfail);

MTIstatus _ProQueryPrtsFromNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   SetOfObjects * proparts, SetOfObjects * setofpsmobjs, int * mfail);

MTIstatus _ProRelateGetRelatedObj
   (MTIstring _class, boolean getParent, string classname,
   string relateName, boolean expand, integer scope,
   string relationship, ObjectPtr itemObj, SetOfObjects * itemObjs,
   SetOfObjects * relObjs, integer * mfail);

MTIstatus _ProRetrieveIBISetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer direction, SetOfObjects * IBISet, integer * mfail);

MTIstatus _ProRetrievePSMCmpntSetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer direction, SetOfObjects * PSMCompSet, integer * mfail);

MTIstatus _ProReviseAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProShowListDlgGetObj
   (MTIstring _class, boolean getParent, string dialogClass,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProSubmitToLifeCycleAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProTransferObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ProUpdateBusItemsInDbAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects docItems, SetOfObjects partItems, integer * mfail);

MTIstatus _ProUpdateDbObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProUpdateDbPref
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _ProValidateTemplateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ProcessReadOnlyObjSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects originSet, string readOnlySaveDir, SetOfObjects * checkedOutSet,
   SetOfObjects * addToIntDirSet, integer * mfail);

MTIstatus _ProsetupDlgAndQuery
   (MTIstring _class, boolean getParent, string dialogClass,
   string originClass, ObjectPtr * dialogObj, SetOfStrings * inpExtraStrs,
   SetOfObjects * qryObjs, integer * mfail);

MTIstatus _ProsetupDlgforQrybyNm
   (MTIstring _class, boolean getParent, string dialogClass,
   string originClass, ObjectPtr * dialogObj, integer * mfail);

MTIstatus _PurgeProDirAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PurgeProObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PurgeUnregBkupAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects unRgstFiles, SetOfObjects rgstFiles, integer masterFileVersion,
   integer * mfail);

MTIstatus _PutDepObjsInWorkbenchAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean viewOnly, string workbenchDir, SetOfObjects curWorkbenchObjSet,
   SetOfObjects srepObjs, SetOfObjects * dependObjSet, SetOfObjects * relObjSet,
   integer * mfail);

MTIstatus _PutRootObjInWorkbenchAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean procRel, integer * mfail);

MTIstatus _QuitWorkbench
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _RefreshItObjProAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean updateBrowser, boolean displayError, boolean * found,
   ObjectPtr * inScopeObj, integer * mfail);

MTIstatus _RefreshWorkbench
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _RemoveFromWorkbenchAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _RemoveFromWorkbenchSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _RemoveProReprtFiles
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects dirContents, integer * mfail);

MTIstatus _RemoveProTrailFiles
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects dirContents, integer * mfail);

MTIstatus _RenameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _RenameProObjsInDir
   (MTIstring _class, boolean getParent, string className,
   string dirName, string baseProName, SetOfObjects * curObjSet,
   SetOfObjects * targetSet, integer * mfail);

MTIstatus _RgstUnknownAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _SearchUnregFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects * unRgstFiles, SetOfObjects * rgstFiles, integer * masterFileVersion,
   integer * mfail);

MTIstatus _ShowListInProWorkB
   (MTIstring _class, boolean getParent, string className,
   integer showType, SetOfObjects showObjSet, SetOfObjects showRelationSet,
   ObjectPtr backgroundObj, string backgroundRel, integer * mfail);

MTIstatus _ShowOneInProWorkB
   (MTIstring _class, boolean getParent, string className,
   integer showType, ObjectPtr showObj, ObjectPtr showRelationObj,
   ObjectPtr backgroundObj, string backgroundRel, integer * mfail);

MTIstatus _UpdateFamilyTableAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects instanceObjSet, integer * mfail);

MTIstatus _UpdateParentsRefsInMtiAtClass
   (MTIstring _class, boolean getParent, ObjectPtr oldObj,
   string newName, int * mfail);

MTIstatus _UpdateProDepObjectsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects dependObjSet, SetOfStrings depObjsClassSet, string WorkbenchDir,
   integer * mfail);

MTIstatus _UpdateProDepsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects dependObjSet, SetOfStrings externalRefs, integer * mfail);

MTIstatus _UpdateProObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string objClass, string WorkbenchDir, ObjectPtr * regObj,
   integer * mfail);

MTIstatus _UpdateWbDirectoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr newObj,
   integer * mfail);

MTIstatus _ValidateForProRenameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _ValidateOsNamForAction
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _ValidateProDepObjectsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects dependObjSet, integer * mfail);

MTIstatus _ValidateProInstObjectsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects instanceObjSet, integer * mfail);
/*
 *  Protected Messages
 */
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define AddToIntegrateDir(this, readOnlyDir, mfail) \
        _AddToIntegrateDirAtClass(NULL, FALSE, this, readOnlyDir, mfail)
#define AddToIntegrateDirAtClass(class, this, readOnlyDir, mfail) \
        _AddToIntegrateDirAtClass(class, FALSE, this, readOnlyDir, mfail)
#define AddToIntegrateDirAtParent(class, this, readOnlyDir, mfail) \
        _AddToIntegrateDirAtClass(class, TRUE, this, readOnlyDir, mfail)

#define AddToWorkbenchDir(this, viewOnly, workbenchDir, mfail) \
        _AddToWorkbenchDirAtClass(NULL, FALSE, this, viewOnly, workbenchDir, mfail)
#define AddToWorkbenchDirAtClass(class, this, viewOnly, workbenchDir, mfail) \
        _AddToWorkbenchDirAtClass(class, FALSE, this, viewOnly, workbenchDir, mfail)
#define AddToWorkbenchDirAtParent(class, this, viewOnly, workbenchDir, mfail) \
        _AddToWorkbenchDirAtClass(class, TRUE, this, viewOnly, workbenchDir, mfail)

#define CheckOutReadOnlyProObj(this, moveDialog, mfail) \
        _CheckOutReadOnlyProObjAtClass(NULL, FALSE, this, moveDialog, mfail)
#define CheckOutReadOnlyProObjAtClass(class, this, moveDialog, mfail) \
        _CheckOutReadOnlyProObjAtClass(class, FALSE, this, moveDialog, mfail)
#define CheckOutReadOnlyProObjAtParent(class, this, moveDialog, mfail) \
        _CheckOutReadOnlyProObjAtClass(class, TRUE, this, moveDialog, mfail)

#define CollectWorkbenchItems(this, itemSet, mfail) \
        _CollectWorkbenchItemsAtClass(NULL, FALSE, this, itemSet, mfail)
#define CollectWorkbenchItemsAtClass(class, this, itemSet, mfail) \
        _CollectWorkbenchItemsAtClass(class, FALSE, this, itemSet, mfail)
#define CollectWorkbenchItemsAtParent(class, this, itemSet, mfail) \
        _CollectWorkbenchItemsAtClass(class, TRUE, this, itemSet, mfail)

#define ConstructProInst(className, mfail, this) \
        _ConstructProInst(className, FALSE, className, mfail, this)
#define ConstructProInstAtParent(_class, className, mfail, this) \
        _ConstructProInst(_class, TRUE, className, mfail, this)

#define CopyProInstObjects(this, newObj, mfail) \
        _CopyProInstObjectsAtClass(NULL, FALSE, this, newObj, mfail)
#define CopyProInstObjectsAtClass(class, this, newObj, mfail) \
        _CopyProInstObjectsAtClass(class, FALSE, this, newObj, mfail)
#define CopyProInstObjectsAtParent(class, this, newObj, mfail) \
        _CopyProInstObjectsAtClass(class, TRUE, this, newObj, mfail)

#define CopyToObjHost(className, workHost, fileHost, workPath, filePath, mfail) \
        _CopyToObjHost(className, FALSE, className, workHost, fileHost, workPath, filePath, mfail)
#define CopyToObjHostAtParent(_class, className, workHost, fileHost, workPath, filePath, mfail) \
        _CopyToObjHost(_class, TRUE, className, workHost, fileHost, workPath, filePath, mfail)

#define CreateCopyRelation(className, origObj, newObj, mfail) \
        _CreateCopyRelation(className, FALSE, className, origObj, newObj, mfail)
#define CreateCopyRelationAtParent(_class, className, origObj, newObj, mfail) \
        _CreateCopyRelation(_class, TRUE, className, origObj, newObj, mfail)

#define DisplayOption(className, mfail) \
        _DisplayOption(className, FALSE, className, mfail)
#define DisplayOptionAtParent(_class, className, mfail) \
        _DisplayOption(_class, TRUE, className, mfail)

#define DisplayWorkbenchItems(toolClassName, workbenchSet, mfail) \
        _DisplayWorkbenchItems(toolClassName, FALSE, toolClassName, workbenchSet, mfail)
#define DisplayWorkbenchItemsAtParent(_class, toolClassName, workbenchSet, mfail) \
        _DisplayWorkbenchItems(_class, TRUE, toolClassName, workbenchSet, mfail)

#define DoProRgstUnknown(className, dialogObj, dirContents, mfail) \
        _DoProRgstUnknown(className, FALSE, className, dialogObj, dirContents, mfail)
#define DoProRgstUnknownAtParent(_class, className, dialogObj, dirContents, mfail) \
        _DoProRgstUnknown(_class, TRUE, className, dialogObj, dirContents, mfail)

#define DoPurgeProDir(this, mfail) \
        _DoPurgeProDirAtClass(NULL, FALSE, this, mfail)
#define DoPurgeProDirAtClass(class, this, mfail) \
        _DoPurgeProDirAtClass(class, FALSE, this, mfail)
#define DoPurgeProDirAtParent(class, this, mfail) \
        _DoPurgeProDirAtClass(class, TRUE, this, mfail)

#define DoPurgeProObj(this, mfail) \
        _DoPurgeProObjAtClass(NULL, FALSE, this, mfail)
#define DoPurgeProObjAtClass(class, this, mfail) \
        _DoPurgeProObjAtClass(class, FALSE, this, mfail)
#define DoPurgeProObjAtParent(class, this, mfail) \
        _DoPurgeProObjAtClass(class, TRUE, this, mfail)

#define DoRealPurgeProDir(className, dirContents, mfail) \
        _DoRealPurgeProDir(className, FALSE, className, dirContents, mfail)
#define DoRealPurgeProDirAtParent(_class, className, dirContents, mfail) \
        _DoRealPurgeProDir(_class, TRUE, className, dirContents, mfail)

#define DoRename(this, newName, mfail) \
        _DoRenameAtClass(NULL, FALSE, this, newName, mfail)
#define DoRenameAtClass(class, this, newName, mfail) \
        _DoRenameAtClass(class, FALSE, this, newName, mfail)
#define DoRenameAtParent(class, this, newName, mfail) \
        _DoRenameAtClass(class, TRUE, this, newName, mfail)

#define DoRgstUnknown(this, dialogObj, mfail) \
        _DoRgstUnknownAtClass(NULL, FALSE, this, dialogObj, mfail)
#define DoRgstUnknownAtClass(class, this, dialogObj, mfail) \
        _DoRgstUnknownAtClass(class, FALSE, this, dialogObj, mfail)
#define DoRgstUnknownAtParent(class, this, dialogObj, mfail) \
        _DoRgstUnknownAtClass(class, TRUE, this, dialogObj, mfail)

#define FindGenObject(this, genObj, mfail) \
        _FindGenObjectAtClass(NULL, FALSE, this, genObj, mfail)
#define FindGenObjectAtClass(class, this, genObj, mfail) \
        _FindGenObjectAtClass(class, FALSE, this, genObj, mfail)
#define FindGenObjectAtParent(class, this, genObj, mfail) \
        _FindGenObjectAtClass(class, TRUE, this, genObj, mfail)

#define FindGenObjects(this, genObjs, mfail) \
        _FindGenObjectsAtClass(NULL, FALSE, this, genObjs, mfail)
#define FindGenObjectsAtClass(class, this, genObjs, mfail) \
        _FindGenObjectsAtClass(class, FALSE, this, genObjs, mfail)
#define FindGenObjectsAtParent(class, this, genObjs, mfail) \
        _FindGenObjectsAtClass(class, TRUE, this, genObjs, mfail)

#define FindInstObjs(this, instObjs, mfail) \
        _FindInstObjsAtClass(NULL, FALSE, this, instObjs, mfail)
#define FindInstObjsAtClass(class, this, instObjs, mfail) \
        _FindInstObjsAtClass(class, FALSE, this, instObjs, mfail)
#define FindInstObjsAtParent(class, this, instObjs, mfail) \
        _FindInstObjsAtClass(class, TRUE, this, instObjs, mfail)

#define FindInstObjsSingle(this, instObjs, mfail) \
        _FindInstObjsSingleAtClass(NULL, FALSE, this, instObjs, mfail)
#define FindInstObjsSingleAtClass(class, this, instObjs, mfail) \
        _FindInstObjsSingleAtClass(class, FALSE, this, instObjs, mfail)
#define FindInstObjsSingleAtParent(class, this, instObjs, mfail) \
        _FindInstObjsSingleAtClass(class, TRUE, this, instObjs, mfail)

#define FindProDepObjects(this, dependObjSet, relObjSet, mfail) \
        _FindProDepObjectsAtClass(NULL, FALSE, this, dependObjSet, relObjSet, mfail)
#define FindProDepObjectsAtClass(class, this, dependObjSet, relObjSet, mfail) \
        _FindProDepObjectsAtClass(class, FALSE, this, dependObjSet, relObjSet, mfail)
#define FindProDepObjectsAtParent(class, this, dependObjSet, relObjSet, mfail) \
        _FindProDepObjectsAtClass(class, TRUE, this, dependObjSet, relObjSet, mfail)

#define GetCurObjectInAnyLoc(dependObj, latestObj, mfail) \
        _GetCurObjectInAnyLocAtClass(NULL, FALSE, dependObj, latestObj, mfail)
#define GetCurObjectInAnyLocAtClass(class, dependObj, latestObj, mfail) \
        _GetCurObjectInAnyLocAtClass(class, FALSE, dependObj, latestObj, mfail)
#define GetCurObjectInAnyLocAtParent(class, dependObj, latestObj, mfail) \
        _GetCurObjectInAnyLocAtClass(class, TRUE, dependObj, latestObj, mfail)

#define GetCurObjectInSameLoc(dependObj, latestObj, mfail) \
        _GetCurObjectInSameLocAtClass(NULL, FALSE, dependObj, latestObj, mfail)
#define GetCurObjectInSameLocAtClass(class, dependObj, latestObj, mfail) \
        _GetCurObjectInSameLocAtClass(class, FALSE, dependObj, latestObj, mfail)
#define GetCurObjectInSameLocAtParent(class, dependObj, latestObj, mfail) \
        _GetCurObjectInSameLocAtClass(class, TRUE, dependObj, latestObj, mfail)

#define GetInflatedHostPath(this, contextHost, host, path, mfail) \
        _GetInflatedHostPathAtClass(NULL, FALSE, this, contextHost, host, path, mfail)
#define GetInflatedHostPathAtClass(class, this, contextHost, host, path, mfail) \
        _GetInflatedHostPathAtClass(class, FALSE, this, contextHost, host, path, mfail)
#define GetInflatedHostPathAtParent(class, this, contextHost, host, path, mfail) \
        _GetInflatedHostPathAtClass(class, TRUE, this, contextHost, host, path, mfail)

#define GetObjProVersion(this, objVersion, mfail) \
        _GetObjProVersionAtClass(NULL, FALSE, this, objVersion, mfail)
#define GetObjProVersionAtClass(class, this, objVersion, mfail) \
        _GetObjProVersionAtClass(class, FALSE, this, objVersion, mfail)
#define GetObjProVersionAtParent(class, this, objVersion, mfail) \
        _GetObjProVersionAtClass(class, TRUE, this, objVersion, mfail)

#define GetProCondition(className, condName, condValue, condExists, mfail) \
        _GetProCondition(className, FALSE, className, condName, condValue, condExists, mfail)
#define GetProConditionAtParent(_class, className, condName, condValue, condExists, mfail) \
        _GetProCondition(_class, TRUE, className, condName, condValue, condExists, mfail)

#define GetProDependentObjs(this, depObjSet, mfail) \
        _GetProDependentObjsAtClass(NULL, FALSE, this, depObjSet, mfail)
#define GetProDependentObjsAtClass(class, this, depObjSet, mfail) \
        _GetProDependentObjsAtClass(class, FALSE, this, depObjSet, mfail)
#define GetProDependentObjsAtParent(class, this, depObjSet, mfail) \
        _GetProDependentObjsAtClass(class, TRUE, this, depObjSet, mfail)

#define GetProPrefs(className, prefObj, mfail) \
        _GetProPrefs(className, FALSE, className, prefObj, mfail)
#define GetProPrefsAtParent(_class, className, prefObj, mfail) \
        _GetProPrefs(_class, TRUE, className, prefObj, mfail)

#define GetProRelationObject(this, dependObj, relObj, mfail) \
        _GetProRelationObjectAtClass(NULL, FALSE, this, dependObj, relObj, mfail)
#define GetProRelationObjectAtClass(class, this, dependObj, relObj, mfail) \
        _GetProRelationObjectAtClass(class, FALSE, this, dependObj, relObj, mfail)
#define GetProRelationObjectAtParent(class, this, dependObj, relObj, mfail) \
        _GetProRelationObjectAtClass(class, TRUE, this, dependObj, relObj, mfail)

#define GetRelatedProObj(className, expand, scope, relationship, itemObj, queryDefinition, itemObjs, relObjs, mfail) \
        _GetRelatedProObj(className, FALSE, className, expand, scope, relationship, itemObj, queryDefinition, itemObjs, relObjs, mfail)
#define GetRelatedProObjAtParent(_class, className, expand, scope, relationship, itemObj, queryDefinition, itemObjs, relObjs, mfail) \
        _GetRelatedProObj(_class, TRUE, className, expand, scope, relationship, itemObj, queryDefinition, itemObjs, relObjs, mfail)

#define HandleInterrupts(className, mfail) \
        _HandleInterrupts(className, FALSE, className, mfail)
#define HandleInterruptsAtParent(_class, className, mfail) \
        _HandleInterrupts(_class, TRUE, className, mfail)

#define HideWorkbench(className, mfail) \
        _HideWorkbench(className, FALSE, className, mfail)
#define HideWorkbenchAtParent(_class, className, mfail) \
        _HideWorkbench(_class, TRUE, className, mfail)

#define IsInstanceCheckedOut(this, dependObjSet, checkout, mfail) \
        _IsInstanceCheckedOutAtClass(NULL, FALSE, this, dependObjSet, checkout, mfail)
#define IsInstanceCheckedOutAtClass(class, this, dependObjSet, checkout, mfail) \
        _IsInstanceCheckedOutAtClass(class, FALSE, this, dependObjSet, checkout, mfail)
#define IsInstanceCheckedOutAtParent(class, this, dependObjSet, checkout, mfail) \
        _IsInstanceCheckedOutAtClass(class, TRUE, this, dependObjSet, checkout, mfail)

#define IsObjExistInSet(this, dependObjSet, objExist, mfail) \
        _IsObjExistInSetAtClass(NULL, FALSE, this, dependObjSet, objExist, mfail)
#define IsObjExistInSetAtClass(class, this, dependObjSet, objExist, mfail) \
        _IsObjExistInSetAtClass(class, FALSE, this, dependObjSet, objExist, mfail)
#define IsObjExistInSetAtParent(class, this, dependObjSet, objExist, mfail) \
        _IsObjExistInSetAtClass(class, TRUE, this, dependObjSet, objExist, mfail)

#define IsProInstRegistered(obj, isReg, regObj, mfail) \
        _IsProInstRegisteredAtClass(NULL, FALSE, obj, isReg, regObj, mfail)
#define IsProInstRegisteredAtClass(class, obj, isReg, regObj, mfail) \
        _IsProInstRegisteredAtClass(class, FALSE, obj, isReg, regObj, mfail)
#define IsProInstRegisteredAtParent(class, obj, isReg, regObj, mfail) \
        _IsProInstRegisteredAtClass(class, TRUE, obj, isReg, regObj, mfail)

#define IsProRelatedTo(className, itemToCheck, itemObject, relationship, answer, mfail) \
        _IsProRelatedTo(className, FALSE, className, itemToCheck, itemObject, relationship, answer, mfail)
#define IsProRelatedToAtParent(_class, className, itemToCheck, itemObject, relationship, answer, mfail) \
        _IsProRelatedTo(_class, TRUE, className, itemToCheck, itemObject, relationship, answer, mfail)

#define IsProVersionSame(obj1, obj2, verSame, mfail) \
        _IsProVersionSameAtClass(NULL, FALSE, obj1, obj2, verSame, mfail)
#define IsProVersionSameAtClass(class, obj1, obj2, verSame, mfail) \
        _IsProVersionSameAtClass(class, FALSE, obj1, obj2, verSame, mfail)
#define IsProVersionSameAtParent(class, obj1, obj2, verSame, mfail) \
        _IsProVersionSameAtClass(class, TRUE, obj1, obj2, verSame, mfail)

#define MakeRelForProWorkB(className, leftObj, rightObj, mfail, this) \
        _MakeRelForProWorkB(className, FALSE, className, leftObj, rightObj, mfail, this)
#define MakeRelForProWorkBAtParent(_class, className, leftObj, rightObj, mfail, this) \
        _MakeRelForProWorkB(_class, TRUE, className, leftObj, rightObj, mfail, this)

#define PassMtiAttrsToPro(this, mfail) \
        _PassMtiAttrsToProAtClass(NULL, FALSE, this, mfail)
#define PassMtiAttrsToProAtClass(class, this, mfail) \
        _PassMtiAttrsToProAtClass(class, FALSE, this, mfail)
#define PassMtiAttrsToProAtParent(class, this, mfail) \
        _PassMtiAttrsToProAtClass(class, TRUE, this, mfail)

#define ProAMGetProEAttributes(this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _ProAMGetProEAttributesAtClass(NULL, FALSE, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define ProAMGetProEAttributesAtClass(class, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _ProAMGetProEAttributesAtClass(class, FALSE, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define ProAMGetProEAttributesAtParent(class, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _ProAMGetProEAttributesAtClass(class, TRUE, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define ProAMGetSubMTIAttrs(this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _ProAMGetSubMTIAttrsAtClass(NULL, FALSE, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define ProAMGetSubMTIAttrsAtClass(class, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _ProAMGetSubMTIAttrsAtClass(class, FALSE, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define ProAMGetSubMTIAttrsAtParent(class, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _ProAMGetSubMTIAttrsAtClass(class, TRUE, this, ValueSetName, LvAttribute, RealClass, RealObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define ProCheckEditQueryAcces(thisObj, editOrViewFlag, mfail) \
        _ProCheckEditQueryAccesAtClass(NULL, FALSE, thisObj, editOrViewFlag, mfail)
#define ProCheckEditQueryAccesAtClass(class, thisObj, editOrViewFlag, mfail) \
        _ProCheckEditQueryAccesAtClass(class, FALSE, thisObj, editOrViewFlag, mfail)
#define ProCheckEditQueryAccesAtParent(class, thisObj, editOrViewFlag, mfail) \
        _ProCheckEditQueryAccesAtClass(class, TRUE, thisObj, editOrViewFlag, mfail)

#define ProCheckIn(thisObj, mfail) \
        _ProCheckInAtClass(NULL, FALSE, thisObj, mfail)
#define ProCheckInAtClass(class, thisObj, mfail) \
        _ProCheckInAtClass(class, FALSE, thisObj, mfail)
#define ProCheckInAtParent(class, thisObj, mfail) \
        _ProCheckInAtClass(class, TRUE, thisObj, mfail)

#define ProCheckInInt(thisObj, mfail) \
        _ProCheckInIntAtClass(NULL, FALSE, thisObj, mfail)
#define ProCheckInIntAtClass(class, thisObj, mfail) \
        _ProCheckInIntAtClass(class, FALSE, thisObj, mfail)
#define ProCheckInIntAtParent(class, thisObj, mfail) \
        _ProCheckInIntAtClass(class, TRUE, thisObj, mfail)

#define ProCheckInItem(thisObj, destOwnerName, mfail) \
        _ProCheckInItemAtClass(NULL, FALSE, thisObj, destOwnerName, mfail)
#define ProCheckInItemAtClass(class, thisObj, destOwnerName, mfail) \
        _ProCheckInItemAtClass(class, FALSE, thisObj, destOwnerName, mfail)
#define ProCheckInItemAtParent(class, thisObj, destOwnerName, mfail) \
        _ProCheckInItemAtClass(class, TRUE, thisObj, destOwnerName, mfail)

#define ProCheckInNonInt(thisObj, mfail) \
        _ProCheckInNonIntAtClass(NULL, FALSE, thisObj, mfail)
#define ProCheckInNonIntAtClass(class, thisObj, mfail) \
        _ProCheckInNonIntAtClass(class, FALSE, thisObj, mfail)
#define ProCheckInNonIntAtParent(class, thisObj, mfail) \
        _ProCheckInNonIntAtClass(class, TRUE, thisObj, mfail)

#define ProCheckOut(workItem, newWorkItem, mfail) \
        _ProCheckOutAtClass(NULL, FALSE, workItem, newWorkItem, mfail)
#define ProCheckOutAtClass(class, workItem, newWorkItem, mfail) \
        _ProCheckOutAtClass(class, FALSE, workItem, newWorkItem, mfail)
#define ProCheckOutAtParent(class, workItem, newWorkItem, mfail) \
        _ProCheckOutAtClass(class, TRUE, workItem, newWorkItem, mfail)

#define ProCheckOutInt(workItem, newWorkItem, mfail) \
        _ProCheckOutIntAtClass(NULL, FALSE, workItem, newWorkItem, mfail)
#define ProCheckOutIntAtClass(class, workItem, newWorkItem, mfail) \
        _ProCheckOutIntAtClass(class, FALSE, workItem, newWorkItem, mfail)
#define ProCheckOutIntAtParent(class, workItem, newWorkItem, mfail) \
        _ProCheckOutIntAtClass(class, TRUE, workItem, newWorkItem, mfail)

#define ProCheckOutItem2(workItem, workLoc, newWorkItem, mfail) \
        _ProCheckOutItem2AtClass(NULL, FALSE, workItem, workLoc, newWorkItem, mfail)
#define ProCheckOutItem2AtClass(class, workItem, workLoc, newWorkItem, mfail) \
        _ProCheckOutItem2AtClass(class, FALSE, workItem, workLoc, newWorkItem, mfail)
#define ProCheckOutItem2AtParent(class, workItem, workLoc, newWorkItem, mfail) \
        _ProCheckOutItem2AtClass(class, TRUE, workItem, workLoc, newWorkItem, mfail)

#define ProCheckOutNonInt(workItem, newWorkItem, mfail) \
        _ProCheckOutNonIntAtClass(NULL, FALSE, workItem, newWorkItem, mfail)
#define ProCheckOutNonIntAtClass(class, workItem, newWorkItem, mfail) \
        _ProCheckOutNonIntAtClass(class, FALSE, workItem, newWorkItem, mfail)
#define ProCheckOutNonIntAtParent(class, workItem, newWorkItem, mfail) \
        _ProCheckOutNonIntAtClass(class, TRUE, workItem, newWorkItem, mfail)

#define ProCheckOutObject(thisObj, dialogObj, mfail) \
        _ProCheckOutObjectAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ProCheckOutObjectAtClass(class, thisObj, dialogObj, mfail) \
        _ProCheckOutObjectAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ProCheckOutObjectAtParent(class, thisObj, dialogObj, mfail) \
        _ProCheckOutObjectAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ProCirProInstObj(oldObj, dlgObj, mfail) \
        _ProCirProInstObjAtClass(NULL, FALSE, oldObj, dlgObj, mfail)
#define ProCirProInstObjAtClass(class, oldObj, dlgObj, mfail) \
        _ProCirProInstObjAtClass(class, FALSE, oldObj, dlgObj, mfail)
#define ProCirProInstObjAtParent(class, oldObj, dlgObj, mfail) \
        _ProCirProInstObjAtClass(class, TRUE, oldObj, dlgObj, mfail)

#define ProCkConditionExists(className, conditionName, answer, mfail) \
        _ProCkConditionExists(className, FALSE, className, conditionName, answer, mfail)
#define ProCkConditionExistsAtParent(_class, className, conditionName, answer, mfail) \
        _ProCkConditionExists(_class, TRUE, className, conditionName, answer, mfail)

#define ProClassify(className, unRegObj, startProb, bestProbability, bestClass, mfail) \
        _ProClassify(className, FALSE, className, unRegObj, startProb, bestProbability, bestClass, mfail)
#define ProClassifyAtParent(_class, className, unRegObj, startProb, bestProbability, bestClass, mfail) \
        _ProClassify(_class, TRUE, className, unRegObj, startProb, bestProbability, bestClass, mfail)

#define ProConnectHungProE(className, mfail) \
        _ProConnectHungProE(className, FALSE, className, mfail)
#define ProConnectHungProEAtParent(_class, className, mfail) \
        _ProConnectHungProE(_class, TRUE, className, mfail)

#define ProCreateHPGLPost(thisObj, proWorkingDir, mfail) \
        _ProCreateHPGLPostAtClass(NULL, FALSE, thisObj, proWorkingDir, mfail)
#define ProCreateHPGLPostAtClass(class, thisObj, proWorkingDir, mfail) \
        _ProCreateHPGLPostAtClass(class, FALSE, thisObj, proWorkingDir, mfail)
#define ProCreateHPGLPostAtParent(class, thisObj, proWorkingDir, mfail) \
        _ProCreateHPGLPostAtClass(class, TRUE, thisObj, proWorkingDir, mfail)

#define ProCreateHPGLPre(thisObj, proWorkingDir, mfail) \
        _ProCreateHPGLPreAtClass(NULL, FALSE, thisObj, proWorkingDir, mfail)
#define ProCreateHPGLPreAtClass(class, thisObj, proWorkingDir, mfail) \
        _ProCreateHPGLPreAtClass(class, FALSE, thisObj, proWorkingDir, mfail)
#define ProCreateHPGLPreAtParent(class, thisObj, proWorkingDir, mfail) \
        _ProCreateHPGLPreAtClass(class, TRUE, thisObj, proWorkingDir, mfail)

#define ProCreatePsmDocList(className, proparts, psmObjs, psmdoc_proparts, list_strings, mfail) \
        _ProCreatePsmDocList(className, FALSE, className, proparts, psmObjs, psmdoc_proparts, list_strings, mfail)
#define ProCreatePsmDocListAtParent(_class, className, proparts, psmObjs, psmdoc_proparts, list_strings, mfail) \
        _ProCreatePsmDocList(_class, TRUE, className, proparts, psmObjs, psmdoc_proparts, list_strings, mfail)

#define ProCreatePsmRelations(dataAssmObj, QSet, componentObjs, currentPartPaths, currentPartMstrs, psmAssmObj, mfail) \
        _ProCreatePsmRelationsAtClass(NULL, FALSE, dataAssmObj, QSet, componentObjs, currentPartPaths, currentPartMstrs, psmAssmObj, mfail)
#define ProCreatePsmRelationsAtClass(class, dataAssmObj, QSet, componentObjs, currentPartPaths, currentPartMstrs, psmAssmObj, mfail) \
        _ProCreatePsmRelationsAtClass(class, FALSE, dataAssmObj, QSet, componentObjs, currentPartPaths, currentPartMstrs, psmAssmObj, mfail)
#define ProCreatePsmRelationsAtParent(class, dataAssmObj, QSet, componentObjs, currentPartPaths, currentPartMstrs, psmAssmObj, mfail) \
        _ProCreatePsmRelationsAtClass(class, TRUE, dataAssmObj, QSet, componentObjs, currentPartPaths, currentPartMstrs, psmAssmObj, mfail)

#define ProCreateTecDocObj(className, docObjs, mfail) \
        _ProCreateTecDocObj(className, FALSE, className, docObjs, mfail)
#define ProCreateTecDocObjAtParent(_class, className, docObjs, mfail) \
        _ProCreateTecDocObj(_class, TRUE, className, docObjs, mfail)

#define ProCreateTransRel(className, origObj, newObj, mfail) \
        _ProCreateTransRel(className, FALSE, className, origObj, newObj, mfail)
#define ProCreateTransRelAtParent(_class, className, origObj, newObj, mfail) \
        _ProCreateTransRel(_class, TRUE, className, origObj, newObj, mfail)

#define ProCreateUpdPsmRels(thisObj, mfail) \
        _ProCreateUpdPsmRelsAtClass(NULL, FALSE, thisObj, mfail)
#define ProCreateUpdPsmRelsAtClass(class, thisObj, mfail) \
        _ProCreateUpdPsmRelsAtClass(class, FALSE, thisObj, mfail)
#define ProCreateUpdPsmRelsAtParent(class, thisObj, mfail) \
        _ProCreateUpdPsmRelsAtClass(class, TRUE, thisObj, mfail)

#define ProCreateUpdatePsmRels(thisObj, mfail) \
        _ProCreateUpdatePsmRelsAtClass(NULL, FALSE, thisObj, mfail)
#define ProCreateUpdatePsmRelsAtClass(class, thisObj, mfail) \
        _ProCreateUpdatePsmRelsAtClass(class, FALSE, thisObj, mfail)
#define ProCreateUpdatePsmRelsAtParent(class, thisObj, mfail) \
        _ProCreateUpdatePsmRelsAtClass(class, TRUE, thisObj, mfail)

#define ProCustomMessage1(thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage1AtClass(NULL, FALSE, thisObj, proWorkingDir, outObj, mfail)
#define ProCustomMessage1AtClass(class, thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage1AtClass(class, FALSE, thisObj, proWorkingDir, outObj, mfail)
#define ProCustomMessage1AtParent(class, thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage1AtClass(class, TRUE, thisObj, proWorkingDir, outObj, mfail)

#define ProCustomMessage2(thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage2AtClass(NULL, FALSE, thisObj, proWorkingDir, outObj, mfail)
#define ProCustomMessage2AtClass(class, thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage2AtClass(class, FALSE, thisObj, proWorkingDir, outObj, mfail)
#define ProCustomMessage2AtParent(class, thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage2AtClass(class, TRUE, thisObj, proWorkingDir, outObj, mfail)

#define ProCustomMessage3(thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage3AtClass(NULL, FALSE, thisObj, proWorkingDir, outObj, mfail)
#define ProCustomMessage3AtClass(class, thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage3AtClass(class, FALSE, thisObj, proWorkingDir, outObj, mfail)
#define ProCustomMessage3AtParent(class, thisObj, proWorkingDir, outObj, mfail) \
        _ProCustomMessage3AtClass(class, TRUE, thisObj, proWorkingDir, outObj, mfail)

#define ProDeleteUnregObj(this, updateBrowser, mfail) \
        _ProDeleteUnregObjAtClass(NULL, FALSE, this, updateBrowser, mfail)
#define ProDeleteUnregObjAtClass(class, this, updateBrowser, mfail) \
        _ProDeleteUnregObjAtClass(class, FALSE, this, updateBrowser, mfail)
#define ProDeleteUnregObjAtParent(class, this, updateBrowser, mfail) \
        _ProDeleteUnregObjAtClass(class, TRUE, this, updateBrowser, mfail)

#define ProDoCheckOut(thisObj, target, refresh, mfail) \
        _ProDoCheckOutAtClass(NULL, FALSE, thisObj, target, refresh, mfail)
#define ProDoCheckOutAtClass(class, thisObj, target, refresh, mfail) \
        _ProDoCheckOutAtClass(class, FALSE, thisObj, target, refresh, mfail)
#define ProDoCheckOutAtParent(class, thisObj, target, refresh, mfail) \
        _ProDoCheckOutAtClass(class, TRUE, thisObj, target, refresh, mfail)

#define ProDoTransfer(thisObj, destOwnerObj, destOwnerDirObj, rels, leftSide, rightSide, extraStr, extraObj, mfail) \
        _ProDoTransferAtClass(NULL, FALSE, thisObj, destOwnerObj, destOwnerDirObj, rels, leftSide, rightSide, extraStr, extraObj, mfail)
#define ProDoTransferAtClass(class, thisObj, destOwnerObj, destOwnerDirObj, rels, leftSide, rightSide, extraStr, extraObj, mfail) \
        _ProDoTransferAtClass(class, FALSE, thisObj, destOwnerObj, destOwnerDirObj, rels, leftSide, rightSide, extraStr, extraObj, mfail)
#define ProDoTransferAtParent(class, thisObj, destOwnerObj, destOwnerDirObj, rels, leftSide, rightSide, extraStr, extraObj, mfail) \
        _ProDoTransferAtClass(class, TRUE, thisObj, destOwnerObj, destOwnerDirObj, rels, leftSide, rightSide, extraStr, extraObj, mfail)

#define ProDocPrepInteractFlag(thisObj, docObj, uiFlag, mfail) \
        _ProDocPrepInteractFlagAtClass(NULL, FALSE, thisObj, docObj, uiFlag, mfail)
#define ProDocPrepInteractFlagAtClass(class, thisObj, docObj, uiFlag, mfail) \
        _ProDocPrepInteractFlagAtClass(class, FALSE, thisObj, docObj, uiFlag, mfail)
#define ProDocPrepInteractFlagAtParent(class, thisObj, docObj, uiFlag, mfail) \
        _ProDocPrepInteractFlagAtClass(class, TRUE, thisObj, docObj, uiFlag, mfail)

#define ProFndFitHostUsrPath(className, host, usr, path, fileObj, mfail) \
        _ProFndFitHostUsrPath(className, FALSE, className, host, usr, path, fileObj, mfail)
#define ProFndFitHostUsrPathAtParent(_class, className, host, usr, path, fileObj, mfail) \
        _ProFndFitHostUsrPath(_class, TRUE, className, host, usr, path, fileObj, mfail)

#define ProGetAttVal2CreBusItm(thisObj, regDialogObj, dialogObj, mfail) \
        _ProGetAttVal2CreBusItmAtClass(NULL, FALSE, thisObj, regDialogObj, dialogObj, mfail)
#define ProGetAttVal2CreBusItmAtClass(class, thisObj, regDialogObj, dialogObj, mfail) \
        _ProGetAttVal2CreBusItmAtClass(class, FALSE, thisObj, regDialogObj, dialogObj, mfail)
#define ProGetAttVal2CreBusItmAtParent(class, thisObj, regDialogObj, dialogObj, mfail) \
        _ProGetAttVal2CreBusItmAtClass(class, TRUE, thisObj, regDialogObj, dialogObj, mfail)

#define ProGetAttVal2CrePSMItm(thisObj, docObj, regDialogObj, dialogObj, mfail) \
        _ProGetAttVal2CrePSMItmAtClass(NULL, FALSE, thisObj, docObj, regDialogObj, dialogObj, mfail)
#define ProGetAttVal2CrePSMItmAtClass(class, thisObj, docObj, regDialogObj, dialogObj, mfail) \
        _ProGetAttVal2CrePSMItmAtClass(class, FALSE, thisObj, docObj, regDialogObj, dialogObj, mfail)
#define ProGetAttVal2CrePSMItmAtParent(class, thisObj, docObj, regDialogObj, dialogObj, mfail) \
        _ProGetAttVal2CrePSMItmAtClass(class, TRUE, thisObj, docObj, regDialogObj, dialogObj, mfail)

#define ProGetAttVal2QryBusObj(thisObj, docName, mfail) \
        _ProGetAttVal2QryBusObjAtClass(NULL, FALSE, thisObj, docName, mfail)
#define ProGetAttVal2QryBusObjAtClass(class, thisObj, docName, mfail) \
        _ProGetAttVal2QryBusObjAtClass(class, FALSE, thisObj, docName, mfail)
#define ProGetAttVal2QryBusObjAtParent(class, thisObj, docName, mfail) \
        _ProGetAttVal2QryBusObjAtClass(class, TRUE, thisObj, docName, mfail)

#define ProGetAttVal2QryPSMItm(thisObj, docObj, docName, mfail) \
        _ProGetAttVal2QryPSMItmAtClass(NULL, FALSE, thisObj, docObj, docName, mfail)
#define ProGetAttVal2QryPSMItmAtClass(class, thisObj, docObj, docName, mfail) \
        _ProGetAttVal2QryPSMItmAtClass(class, FALSE, thisObj, docObj, docName, mfail)
#define ProGetAttVal2QryPSMItmAtParent(class, thisObj, docObj, docName, mfail) \
        _ProGetAttVal2QryPSMItmAtClass(class, TRUE, thisObj, docObj, docName, mfail)

#define ProGetBusObjForProFile(thisObj, regDialogObj, docObj, mfail) \
        _ProGetBusObjForProFileAtClass(NULL, FALSE, thisObj, regDialogObj, docObj, mfail)
#define ProGetBusObjForProFileAtClass(class, thisObj, regDialogObj, docObj, mfail) \
        _ProGetBusObjForProFileAtClass(class, FALSE, thisObj, regDialogObj, docObj, mfail)
#define ProGetBusObjForProFileAtParent(class, thisObj, regDialogObj, docObj, mfail) \
        _ProGetBusObjForProFileAtClass(class, TRUE, thisObj, regDialogObj, docObj, mfail)

#define ProGetChekInRPredFrmSc(this, pred, mfail) \
        _ProGetChekInRPredFrmScAtClass(NULL, FALSE, this, pred, mfail)
#define ProGetChekInRPredFrmScAtClass(class, this, pred, mfail) \
        _ProGetChekInRPredFrmScAtClass(class, FALSE, this, pred, mfail)
#define ProGetChekInRPredFrmScAtParent(class, this, pred, mfail) \
        _ProGetChekInRPredFrmScAtClass(class, TRUE, this, pred, mfail)

#define ProGetChekInRScFrmPred(this, succ, mfail) \
        _ProGetChekInRScFrmPredAtClass(NULL, FALSE, this, succ, mfail)
#define ProGetChekInRScFrmPredAtClass(class, this, succ, mfail) \
        _ProGetChekInRScFrmPredAtClass(class, FALSE, this, succ, mfail)
#define ProGetChekInRScFrmPredAtParent(class, this, succ, mfail) \
        _ProGetChekInRScFrmPredAtClass(class, TRUE, this, succ, mfail)

#define ProGetChkOutRPrdFrmSc(this, pred, mfail) \
        _ProGetChkOutRPrdFrmScAtClass(NULL, FALSE, this, pred, mfail)
#define ProGetChkOutRPrdFrmScAtClass(class, this, pred, mfail) \
        _ProGetChkOutRPrdFrmScAtClass(class, FALSE, this, pred, mfail)
#define ProGetChkOutRPrdFrmScAtParent(class, this, pred, mfail) \
        _ProGetChkOutRPrdFrmScAtClass(class, TRUE, this, pred, mfail)

#define ProGetChkOutRScFrmPrd(this, succ, mfail) \
        _ProGetChkOutRScFrmPrdAtClass(NULL, FALSE, this, succ, mfail)
#define ProGetChkOutRScFrmPrdAtClass(class, this, succ, mfail) \
        _ProGetChkOutRScFrmPrdAtClass(class, FALSE, this, succ, mfail)
#define ProGetChkOutRScFrmPrdAtParent(class, this, succ, mfail) \
        _ProGetChkOutRScFrmPrdAtClass(class, TRUE, this, succ, mfail)

#define ProGetDataForQueryBI(thisObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail) \
        _ProGetDataForQueryBIAtClass(NULL, FALSE, thisObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail)
#define ProGetDataForQueryBIAtClass(class, thisObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail) \
        _ProGetDataForQueryBIAtClass(class, FALSE, thisObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail)
#define ProGetDataForQueryBIAtParent(class, thisObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail) \
        _ProGetDataForQueryBIAtClass(class, TRUE, thisObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail)

#define ProGetDataForQueryPSM(thisObj, docObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail) \
        _ProGetDataForQueryPSMAtClass(NULL, FALSE, thisObj, docObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail)
#define ProGetDataForQueryPSMAtClass(class, thisObj, docObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail) \
        _ProGetDataForQueryPSMAtClass(class, FALSE, thisObj, docObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail)
#define ProGetDataForQueryPSMAtParent(class, thisObj, docObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail) \
        _ProGetDataForQueryPSMAtClass(class, TRUE, thisObj, docObj, regDialogObj, qryClassName, qryAttrSet, qryAttrValSet, mfail)

#define ProGetFSItemPathTail(thisObj, pathTail, mfail) \
        _ProGetFSItemPathTailAtClass(NULL, FALSE, thisObj, pathTail, mfail)
#define ProGetFSItemPathTailAtClass(class, thisObj, pathTail, mfail) \
        _ProGetFSItemPathTailAtClass(class, FALSE, thisObj, pathTail, mfail)
#define ProGetFSItemPathTailAtParent(class, thisObj, pathTail, mfail) \
        _ProGetFSItemPathTailAtClass(class, TRUE, thisObj, pathTail, mfail)

#define ProGetMapObjTableData(className, mtiClasses, mtiAttrNames, proAttrNames, directions, mfail) \
        _ProGetMapObjTableData(className, FALSE, className, mtiClasses, mtiAttrNames, proAttrNames, directions, mfail)
#define ProGetMapObjTableDataAtParent(_class, className, mtiClasses, mtiAttrNames, proAttrNames, directions, mfail) \
        _ProGetMapObjTableData(_class, TRUE, className, mtiClasses, mtiAttrNames, proAttrNames, directions, mfail)

#define ProGetPathHost(thisObj, fileHost, filePath, mfail) \
        _ProGetPathHostAtClass(NULL, FALSE, thisObj, fileHost, filePath, mfail)
#define ProGetPathHostAtClass(class, thisObj, fileHost, filePath, mfail) \
        _ProGetPathHostAtClass(class, FALSE, thisObj, fileHost, filePath, mfail)
#define ProGetPathHostAtParent(class, thisObj, fileHost, filePath, mfail) \
        _ProGetPathHostAtClass(class, TRUE, thisObj, fileHost, filePath, mfail)

#define ProGetPrepClassForBI(ugPartObj, docObj, prepClassName, mfail) \
        _ProGetPrepClassForBIAtClass(NULL, FALSE, ugPartObj, docObj, prepClassName, mfail)
#define ProGetPrepClassForBIAtClass(class, ugPartObj, docObj, prepClassName, mfail) \
        _ProGetPrepClassForBIAtClass(class, FALSE, ugPartObj, docObj, prepClassName, mfail)
#define ProGetPrepClassForBIAtParent(class, ugPartObj, docObj, prepClassName, mfail) \
        _ProGetPrepClassForBIAtClass(class, TRUE, ugPartObj, docObj, prepClassName, mfail)

#define ProGetPrepClassForDI(ugPartObj, prepClassName, mfail) \
        _ProGetPrepClassForDIAtClass(NULL, FALSE, ugPartObj, prepClassName, mfail)
#define ProGetPrepClassForDIAtClass(class, ugPartObj, prepClassName, mfail) \
        _ProGetPrepClassForDIAtClass(class, FALSE, ugPartObj, prepClassName, mfail)
#define ProGetPrepClassForDIAtParent(class, ugPartObj, prepClassName, mfail) \
        _ProGetPrepClassForDIAtClass(class, TRUE, ugPartObj, prepClassName, mfail)

#define ProGetPsmObjToPrepare(thisObj, docObj, regDialogObj, psmObj, mfail) \
        _ProGetPsmObjToPrepareAtClass(NULL, FALSE, thisObj, docObj, regDialogObj, psmObj, mfail)
#define ProGetPsmObjToPrepareAtClass(class, thisObj, docObj, regDialogObj, psmObj, mfail) \
        _ProGetPsmObjToPrepareAtClass(class, FALSE, thisObj, docObj, regDialogObj, psmObj, mfail)
#define ProGetPsmObjToPrepareAtParent(class, thisObj, docObj, regDialogObj, psmObj, mfail) \
        _ProGetPsmObjToPrepareAtClass(class, TRUE, thisObj, docObj, regDialogObj, psmObj, mfail)

#define ProGetRelObjExtData(thisObj, depObjs, relObjs, mfail) \
        _ProGetRelObjExtDataAtClass(NULL, FALSE, thisObj, depObjs, relObjs, mfail)
#define ProGetRelObjExtDataAtClass(class, thisObj, depObjs, relObjs, mfail) \
        _ProGetRelObjExtDataAtClass(class, FALSE, thisObj, depObjs, relObjs, mfail)
#define ProGetRelObjExtDataAtParent(class, thisObj, depObjs, relObjs, mfail) \
        _ProGetRelObjExtDataAtClass(class, TRUE, thisObj, depObjs, relObjs, mfail)

#define ProGetRelObjExtInst(thisObj, depObjs, relObjs, mfail) \
        _ProGetRelObjExtInstAtClass(NULL, FALSE, thisObj, depObjs, relObjs, mfail)
#define ProGetRelObjExtInstAtClass(class, thisObj, depObjs, relObjs, mfail) \
        _ProGetRelObjExtInstAtClass(class, FALSE, thisObj, depObjs, relObjs, mfail)
#define ProGetRelObjExtInstAtParent(class, thisObj, depObjs, relObjs, mfail) \
        _ProGetRelObjExtInstAtClass(class, TRUE, thisObj, depObjs, relObjs, mfail)

#define ProGetRelatedPsmPart(thisObj, partObjSet, mfail) \
        _ProGetRelatedPsmPartAtClass(NULL, FALSE, thisObj, partObjSet, mfail)
#define ProGetRelatedPsmPartAtClass(class, thisObj, partObjSet, mfail) \
        _ProGetRelatedPsmPartAtClass(class, FALSE, thisObj, partObjSet, mfail)
#define ProGetRelatedPsmPartAtParent(class, thisObj, partObjSet, mfail) \
        _ProGetRelatedPsmPartAtClass(class, TRUE, thisObj, partObjSet, mfail)

#define ProGetSavedQueryObjs(thisObj, partObjs, mfail) \
        _ProGetSavedQueryObjsAtClass(NULL, FALSE, thisObj, partObjs, mfail)
#define ProGetSavedQueryObjsAtClass(class, thisObj, partObjs, mfail) \
        _ProGetSavedQueryObjsAtClass(class, FALSE, thisObj, partObjs, mfail)
#define ProGetSavedQueryObjsAtParent(class, thisObj, partObjs, mfail) \
        _ProGetSavedQueryObjsAtClass(class, TRUE, thisObj, partObjs, mfail)

#define ProGetTemplatePath(thisObj, dialogObj, proTemplate, mfail) \
        _ProGetTemplatePathAtClass(NULL, FALSE, thisObj, dialogObj, proTemplate, mfail)
#define ProGetTemplatePathAtClass(class, thisObj, dialogObj, proTemplate, mfail) \
        _ProGetTemplatePathAtClass(class, FALSE, thisObj, dialogObj, proTemplate, mfail)
#define ProGetTemplatePathAtParent(class, thisObj, dialogObj, proTemplate, mfail) \
        _ProGetTemplatePathAtClass(class, TRUE, thisObj, dialogObj, proTemplate, mfail)

#define ProInvokeLCMBrw(classname, tagname, mfail) \
        _ProInvokeLCMBrw(classname, FALSE, classname, tagname, mfail)
#define ProInvokeLCMBrwAtParent(_class, classname, tagname, mfail) \
        _ProInvokeLCMBrw(_class, TRUE, classname, tagname, mfail)

#define ProIsOwnedByVault(thisObj, vaultObj, answer, mfail) \
        _ProIsOwnedByVaultAtClass(NULL, FALSE, thisObj, vaultObj, answer, mfail)
#define ProIsOwnedByVaultAtClass(class, thisObj, vaultObj, answer, mfail) \
        _ProIsOwnedByVaultAtClass(class, FALSE, thisObj, vaultObj, answer, mfail)
#define ProIsOwnedByVaultAtParent(class, thisObj, vaultObj, answer, mfail) \
        _ProIsOwnedByVaultAtClass(class, TRUE, thisObj, vaultObj, answer, mfail)

#define ProIsRelHasCirDepObjs(thisObj, cirDeps, mfail) \
        _ProIsRelHasCirDepObjsAtClass(NULL, FALSE, thisObj, cirDeps, mfail)
#define ProIsRelHasCirDepObjsAtClass(class, thisObj, cirDeps, mfail) \
        _ProIsRelHasCirDepObjsAtClass(class, FALSE, thisObj, cirDeps, mfail)
#define ProIsRelHasCirDepObjsAtParent(class, thisObj, cirDeps, mfail) \
        _ProIsRelHasCirDepObjsAtClass(class, TRUE, thisObj, cirDeps, mfail)

#define ProMoveObject(thisObj, dialogObj, mfail) \
        _ProMoveObjectAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ProMoveObjectAtClass(class, thisObj, dialogObj, mfail) \
        _ProMoveObjectAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ProMoveObjectAtParent(class, thisObj, dialogObj, mfail) \
        _ProMoveObjectAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ProObjPrepInteractFlag(thisObj, uiFlag, mfail) \
        _ProObjPrepInteractFlagAtClass(NULL, FALSE, thisObj, uiFlag, mfail)
#define ProObjPrepInteractFlagAtClass(class, thisObj, uiFlag, mfail) \
        _ProObjPrepInteractFlagAtClass(class, FALSE, thisObj, uiFlag, mfail)
#define ProObjPrepInteractFlagAtParent(class, thisObj, uiFlag, mfail) \
        _ProObjPrepInteractFlagAtClass(class, TRUE, thisObj, uiFlag, mfail)

#define ProOpenPSMPart(thisObj, mfail) \
        _ProOpenPSMPartAtClass(NULL, FALSE, thisObj, mfail)
#define ProOpenPSMPartAtClass(class, thisObj, mfail) \
        _ProOpenPSMPartAtClass(class, FALSE, thisObj, mfail)
#define ProOpenPSMPartAtParent(class, thisObj, mfail) \
        _ProOpenPSMPartAtClass(class, TRUE, thisObj, mfail)

#define ProPSMListDlgAndGetObj(dialogClass, extraStr, extraObj, mfail) \
        _ProPSMListDlgAndGetObj(dialogClass, FALSE, dialogClass, extraStr, extraObj, mfail)
#define ProPSMListDlgAndGetObjAtParent(_class, dialogClass, extraStr, extraObj, mfail) \
        _ProPSMListDlgAndGetObj(_class, TRUE, dialogClass, extraStr, extraObj, mfail)

#define ProPrepDoCreateBIDlg(thisObj, docObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail) \
        _ProPrepDoCreateBIDlgAtClass(NULL, FALSE, thisObj, docObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail)
#define ProPrepDoCreateBIDlgAtClass(class, thisObj, docObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail) \
        _ProPrepDoCreateBIDlgAtClass(class, FALSE, thisObj, docObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail)
#define ProPrepDoCreateBIDlgAtParent(class, thisObj, docObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail) \
        _ProPrepDoCreateBIDlgAtClass(class, TRUE, thisObj, docObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail)

#define ProPrepDoCreateDIDlg(thisObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail) \
        _ProPrepDoCreateDIDlgAtClass(NULL, FALSE, thisObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail)
#define ProPrepDoCreateDIDlgAtClass(class, thisObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail) \
        _ProPrepDoCreateDIDlgAtClass(class, FALSE, thisObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail)
#define ProPrepDoCreateDIDlgAtParent(class, thisObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail) \
        _ProPrepDoCreateDIDlgAtClass(class, TRUE, thisObj, regDialogObj, defaultClass, dialogObj, intFlag, mfail)

#define ProPrepFileAndDocFunc(thisObj, dialogObj, docObj, psmObj, mfail) \
        _ProPrepFileAndDocFuncAtClass(NULL, FALSE, thisObj, dialogObj, docObj, psmObj, mfail)
#define ProPrepFileAndDocFuncAtClass(class, thisObj, dialogObj, docObj, psmObj, mfail) \
        _ProPrepFileAndDocFuncAtClass(class, FALSE, thisObj, dialogObj, docObj, psmObj, mfail)
#define ProPrepFileAndDocFuncAtParent(class, thisObj, dialogObj, docObj, psmObj, mfail) \
        _ProPrepFileAndDocFuncAtClass(class, TRUE, thisObj, dialogObj, docObj, psmObj, mfail)

#define ProPrepare(thisObj, mfail) \
        _ProPrepareAtClass(NULL, FALSE, thisObj, mfail)
#define ProPrepareAtClass(class, thisObj, mfail) \
        _ProPrepareAtClass(class, FALSE, thisObj, mfail)
#define ProPrepareAtParent(class, thisObj, mfail) \
        _ProPrepareAtClass(class, TRUE, thisObj, mfail)

#define ProPrepareCheckPSMObj(ugItmObj, docItmObj, psmItmObj, isMaster, mfail) \
        _ProPrepareCheckPSMObjAtClass(NULL, FALSE, ugItmObj, docItmObj, psmItmObj, isMaster, mfail)
#define ProPrepareCheckPSMObjAtClass(class, ugItmObj, docItmObj, psmItmObj, isMaster, mfail) \
        _ProPrepareCheckPSMObjAtClass(class, FALSE, ugItmObj, docItmObj, psmItmObj, isMaster, mfail)
#define ProPrepareCheckPSMObjAtParent(class, ugItmObj, docItmObj, psmItmObj, isMaster, mfail) \
        _ProPrepareCheckPSMObjAtClass(class, TRUE, ugItmObj, docItmObj, psmItmObj, isMaster, mfail)

#define ProPrepareDocFunc(thisObj, regDialogObj, docObj, psmObj, mfail) \
        _ProPrepareDocFuncAtClass(NULL, FALSE, thisObj, regDialogObj, docObj, psmObj, mfail)
#define ProPrepareDocFuncAtClass(class, thisObj, regDialogObj, docObj, psmObj, mfail) \
        _ProPrepareDocFuncAtClass(class, FALSE, thisObj, regDialogObj, docObj, psmObj, mfail)
#define ProPrepareDocFuncAtParent(class, thisObj, regDialogObj, docObj, psmObj, mfail) \
        _ProPrepareDocFuncAtClass(class, TRUE, thisObj, regDialogObj, docObj, psmObj, mfail)

#define ProPrepareFileFunc(thisObj, regDialogObj, docObj, mfail) \
        _ProPrepareFileFuncAtClass(NULL, FALSE, thisObj, regDialogObj, docObj, mfail)
#define ProPrepareFileFuncAtClass(class, thisObj, regDialogObj, docObj, mfail) \
        _ProPrepareFileFuncAtClass(class, FALSE, thisObj, regDialogObj, docObj, mfail)
#define ProPrepareFileFuncAtParent(class, thisObj, regDialogObj, docObj, mfail) \
        _ProPrepareFileFuncAtClass(class, TRUE, thisObj, regDialogObj, docObj, mfail)

#define ProProcessDepsForCki(oldObj, dlgObj, mfail) \
        _ProProcessDepsForCkiAtClass(NULL, FALSE, oldObj, dlgObj, mfail)
#define ProProcessDepsForCkiAtClass(class, oldObj, dlgObj, mfail) \
        _ProProcessDepsForCkiAtClass(class, FALSE, oldObj, dlgObj, mfail)
#define ProProcessDepsForCkiAtParent(class, oldObj, dlgObj, mfail) \
        _ProProcessDepsForCkiAtClass(class, TRUE, oldObj, dlgObj, mfail)

#define ProPsmSetViewNetwork(psmObj, curViewNetworkName, curViewName, mfail) \
        _ProPsmSetViewNetworkAtClass(NULL, FALSE, psmObj, curViewNetworkName, curViewName, mfail)
#define ProPsmSetViewNetworkAtClass(class, psmObj, curViewNetworkName, curViewName, mfail) \
        _ProPsmSetViewNetworkAtClass(class, FALSE, psmObj, curViewNetworkName, curViewName, mfail)
#define ProPsmSetViewNetworkAtParent(class, psmObj, curViewNetworkName, curViewName, mfail) \
        _ProPsmSetViewNetworkAtClass(class, TRUE, psmObj, curViewNetworkName, curViewName, mfail)

#define ProQueryPrtsFromName(dialogObj, proparts, setofpsmobjs, mfail) \
        _ProQueryPrtsFromNameAtClass(NULL, FALSE, dialogObj, proparts, setofpsmobjs, mfail)
#define ProQueryPrtsFromNameAtClass(class, dialogObj, proparts, setofpsmobjs, mfail) \
        _ProQueryPrtsFromNameAtClass(class, FALSE, dialogObj, proparts, setofpsmobjs, mfail)
#define ProQueryPrtsFromNameAtParent(class, dialogObj, proparts, setofpsmobjs, mfail) \
        _ProQueryPrtsFromNameAtClass(class, TRUE, dialogObj, proparts, setofpsmobjs, mfail)

#define ProRelateGetRelatedObj(classname, relateName, expand, scope, relationship, itemObj, itemObjs, relObjs, mfail) \
        _ProRelateGetRelatedObj(classname, FALSE, classname, relateName, expand, scope, relationship, itemObj, itemObjs, relObjs, mfail)
#define ProRelateGetRelatedObjAtParent(_class, classname, relateName, expand, scope, relationship, itemObj, itemObjs, relObjs, mfail) \
        _ProRelateGetRelatedObj(_class, TRUE, classname, relateName, expand, scope, relationship, itemObj, itemObjs, relObjs, mfail)

#define ProRetrieveIBISet(this, direction, IBISet, mfail) \
        _ProRetrieveIBISetAtClass(NULL, FALSE, this, direction, IBISet, mfail)
#define ProRetrieveIBISetAtClass(class, this, direction, IBISet, mfail) \
        _ProRetrieveIBISetAtClass(class, FALSE, this, direction, IBISet, mfail)
#define ProRetrieveIBISetAtParent(class, this, direction, IBISet, mfail) \
        _ProRetrieveIBISetAtClass(class, TRUE, this, direction, IBISet, mfail)

#define ProRetrievePSMCmpntSet(this, direction, PSMCompSet, mfail) \
        _ProRetrievePSMCmpntSetAtClass(NULL, FALSE, this, direction, PSMCompSet, mfail)
#define ProRetrievePSMCmpntSetAtClass(class, this, direction, PSMCompSet, mfail) \
        _ProRetrievePSMCmpntSetAtClass(class, FALSE, this, direction, PSMCompSet, mfail)
#define ProRetrievePSMCmpntSetAtParent(class, this, direction, PSMCompSet, mfail) \
        _ProRetrievePSMCmpntSetAtClass(class, TRUE, this, direction, PSMCompSet, mfail)

#define ProRevise(thisObj, mfail) \
        _ProReviseAtClass(NULL, FALSE, thisObj, mfail)
#define ProReviseAtClass(class, thisObj, mfail) \
        _ProReviseAtClass(class, FALSE, thisObj, mfail)
#define ProReviseAtParent(class, thisObj, mfail) \
        _ProReviseAtClass(class, TRUE, thisObj, mfail)

#define ProShowListDlgGetObj(dialogClass, extraObj, mfail) \
        _ProShowListDlgGetObj(dialogClass, FALSE, dialogClass, extraObj, mfail)
#define ProShowListDlgGetObjAtParent(_class, dialogClass, extraObj, mfail) \
        _ProShowListDlgGetObj(_class, TRUE, dialogClass, extraObj, mfail)

#define ProSubmitToLifeCycle(thisObj, mfail) \
        _ProSubmitToLifeCycleAtClass(NULL, FALSE, thisObj, mfail)
#define ProSubmitToLifeCycleAtClass(class, thisObj, mfail) \
        _ProSubmitToLifeCycleAtClass(class, FALSE, thisObj, mfail)
#define ProSubmitToLifeCycleAtParent(class, thisObj, mfail) \
        _ProSubmitToLifeCycleAtClass(class, TRUE, thisObj, mfail)

#define ProTransferObject(thisObj, dialogObj, mfail) \
        _ProTransferObjectAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ProTransferObjectAtClass(class, thisObj, dialogObj, mfail) \
        _ProTransferObjectAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ProTransferObjectAtParent(class, thisObj, dialogObj, mfail) \
        _ProTransferObjectAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ProUpdateBusItemsInDb(this, docItems, partItems, mfail) \
        _ProUpdateBusItemsInDbAtClass(NULL, FALSE, this, docItems, partItems, mfail)
#define ProUpdateBusItemsInDbAtClass(class, this, docItems, partItems, mfail) \
        _ProUpdateBusItemsInDbAtClass(class, FALSE, this, docItems, partItems, mfail)
#define ProUpdateBusItemsInDbAtParent(class, this, docItems, partItems, mfail) \
        _ProUpdateBusItemsInDbAtClass(class, TRUE, this, docItems, partItems, mfail)

#define ProUpdateDbObject(thisObj, mfail) \
        _ProUpdateDbObjectAtClass(NULL, FALSE, thisObj, mfail)
#define ProUpdateDbObjectAtClass(class, thisObj, mfail) \
        _ProUpdateDbObjectAtClass(class, FALSE, thisObj, mfail)
#define ProUpdateDbObjectAtParent(class, thisObj, mfail) \
        _ProUpdateDbObjectAtClass(class, TRUE, thisObj, mfail)

#define ProUpdateDbPref(className, mfail) \
        _ProUpdateDbPref(className, FALSE, className, mfail)
#define ProUpdateDbPrefAtParent(_class, className, mfail) \
        _ProUpdateDbPref(_class, TRUE, className, mfail)

#define ProValidateTemplate(thisObj, mfail) \
        _ProValidateTemplateAtClass(NULL, FALSE, thisObj, mfail)
#define ProValidateTemplateAtClass(class, thisObj, mfail) \
        _ProValidateTemplateAtClass(class, FALSE, thisObj, mfail)
#define ProValidateTemplateAtParent(class, thisObj, mfail) \
        _ProValidateTemplateAtClass(class, TRUE, thisObj, mfail)

#define ProcessReadOnlyObjSet(className, originSet, readOnlySaveDir, checkedOutSet, addToIntDirSet, mfail) \
        _ProcessReadOnlyObjSet(className, FALSE, className, originSet, readOnlySaveDir, checkedOutSet, addToIntDirSet, mfail)
#define ProcessReadOnlyObjSetAtParent(_class, className, originSet, readOnlySaveDir, checkedOutSet, addToIntDirSet, mfail) \
        _ProcessReadOnlyObjSet(_class, TRUE, className, originSet, readOnlySaveDir, checkedOutSet, addToIntDirSet, mfail)

#define ProsetupDlgAndQuery(dialogClass, originClass, dialogObj, inpExtraStrs, qryObjs, mfail) \
        _ProsetupDlgAndQuery(dialogClass, FALSE, dialogClass, originClass, dialogObj, inpExtraStrs, qryObjs, mfail)
#define ProsetupDlgAndQueryAtParent(_class, dialogClass, originClass, dialogObj, inpExtraStrs, qryObjs, mfail) \
        _ProsetupDlgAndQuery(_class, TRUE, dialogClass, originClass, dialogObj, inpExtraStrs, qryObjs, mfail)

#define ProsetupDlgforQrybyNm(dialogClass, originClass, dialogObj, mfail) \
        _ProsetupDlgforQrybyNm(dialogClass, FALSE, dialogClass, originClass, dialogObj, mfail)
#define ProsetupDlgforQrybyNmAtParent(_class, dialogClass, originClass, dialogObj, mfail) \
        _ProsetupDlgforQrybyNm(_class, TRUE, dialogClass, originClass, dialogObj, mfail)

#define PurgeProDir(thisObj, mfail) \
        _PurgeProDirAtClass(NULL, FALSE, thisObj, mfail)
#define PurgeProDirAtClass(class, thisObj, mfail) \
        _PurgeProDirAtClass(class, FALSE, thisObj, mfail)
#define PurgeProDirAtParent(class, thisObj, mfail) \
        _PurgeProDirAtClass(class, TRUE, thisObj, mfail)

#define PurgeProObj(thisObj, mfail) \
        _PurgeProObjAtClass(NULL, FALSE, thisObj, mfail)
#define PurgeProObjAtClass(class, thisObj, mfail) \
        _PurgeProObjAtClass(class, FALSE, thisObj, mfail)
#define PurgeProObjAtParent(class, thisObj, mfail) \
        _PurgeProObjAtClass(class, TRUE, thisObj, mfail)

#define PurgeUnregBkup(this, unRgstFiles, rgstFiles, masterFileVersion, mfail) \
        _PurgeUnregBkupAtClass(NULL, FALSE, this, unRgstFiles, rgstFiles, masterFileVersion, mfail)
#define PurgeUnregBkupAtClass(class, this, unRgstFiles, rgstFiles, masterFileVersion, mfail) \
        _PurgeUnregBkupAtClass(class, FALSE, this, unRgstFiles, rgstFiles, masterFileVersion, mfail)
#define PurgeUnregBkupAtParent(class, this, unRgstFiles, rgstFiles, masterFileVersion, mfail) \
        _PurgeUnregBkupAtClass(class, TRUE, this, unRgstFiles, rgstFiles, masterFileVersion, mfail)

#define PutDepObjsInWorkbench(this, viewOnly, workbenchDir, curWorkbenchObjSet, srepObjs, dependObjSet, relObjSet, mfail) \
        _PutDepObjsInWorkbenchAtClass(NULL, FALSE, this, viewOnly, workbenchDir, curWorkbenchObjSet, srepObjs, dependObjSet, relObjSet, mfail)
#define PutDepObjsInWorkbenchAtClass(class, this, viewOnly, workbenchDir, curWorkbenchObjSet, srepObjs, dependObjSet, relObjSet, mfail) \
        _PutDepObjsInWorkbenchAtClass(class, FALSE, this, viewOnly, workbenchDir, curWorkbenchObjSet, srepObjs, dependObjSet, relObjSet, mfail)
#define PutDepObjsInWorkbenchAtParent(class, this, viewOnly, workbenchDir, curWorkbenchObjSet, srepObjs, dependObjSet, relObjSet, mfail) \
        _PutDepObjsInWorkbenchAtClass(class, TRUE, this, viewOnly, workbenchDir, curWorkbenchObjSet, srepObjs, dependObjSet, relObjSet, mfail)

#define PutRootObjInWorkbench(this, procRel, mfail) \
        _PutRootObjInWorkbenchAtClass(NULL, FALSE, this, procRel, mfail)
#define PutRootObjInWorkbenchAtClass(class, this, procRel, mfail) \
        _PutRootObjInWorkbenchAtClass(class, FALSE, this, procRel, mfail)
#define PutRootObjInWorkbenchAtParent(class, this, procRel, mfail) \
        _PutRootObjInWorkbenchAtClass(class, TRUE, this, procRel, mfail)

#define QuitWorkbench(className, mfail) \
        _QuitWorkbench(className, FALSE, className, mfail)
#define QuitWorkbenchAtParent(_class, className, mfail) \
        _QuitWorkbench(_class, TRUE, className, mfail)

#define RefreshItObjPro(this, updateBrowser, displayError, found, inScopeObj, mfail) \
        _RefreshItObjProAtClass(NULL, FALSE, this, updateBrowser, displayError, found, inScopeObj, mfail)
#define RefreshItObjProAtClass(class, this, updateBrowser, displayError, found, inScopeObj, mfail) \
        _RefreshItObjProAtClass(class, FALSE, this, updateBrowser, displayError, found, inScopeObj, mfail)
#define RefreshItObjProAtParent(class, this, updateBrowser, displayError, found, inScopeObj, mfail) \
        _RefreshItObjProAtClass(class, TRUE, this, updateBrowser, displayError, found, inScopeObj, mfail)

#define RefreshWorkbench(className, mfail) \
        _RefreshWorkbench(className, FALSE, className, mfail)
#define RefreshWorkbenchAtParent(_class, className, mfail) \
        _RefreshWorkbench(_class, TRUE, className, mfail)

#define RemoveFromWorkbench(thisObj, mfail) \
        _RemoveFromWorkbenchAtClass(NULL, FALSE, thisObj, mfail)
#define RemoveFromWorkbenchAtClass(class, thisObj, mfail) \
        _RemoveFromWorkbenchAtClass(class, FALSE, thisObj, mfail)
#define RemoveFromWorkbenchAtParent(class, thisObj, mfail) \
        _RemoveFromWorkbenchAtClass(class, TRUE, thisObj, mfail)

#define RemoveFromWorkbenchSet(className, SelectedItems, mfail) \
        _RemoveFromWorkbenchSet(className, FALSE, className, SelectedItems, mfail)
#define RemoveFromWorkbenchSetAtParent(_class, className, SelectedItems, mfail) \
        _RemoveFromWorkbenchSet(_class, TRUE, className, SelectedItems, mfail)

#define RemoveProReprtFiles(className, dirContents, mfail) \
        _RemoveProReprtFiles(className, FALSE, className, dirContents, mfail)
#define RemoveProReprtFilesAtParent(_class, className, dirContents, mfail) \
        _RemoveProReprtFiles(_class, TRUE, className, dirContents, mfail)

#define RemoveProTrailFiles(className, dirContents, mfail) \
        _RemoveProTrailFiles(className, FALSE, className, dirContents, mfail)
#define RemoveProTrailFilesAtParent(_class, className, dirContents, mfail) \
        _RemoveProTrailFiles(_class, TRUE, className, dirContents, mfail)

#define Rename(thisObj, mfail) \
        _RenameAtClass(NULL, FALSE, thisObj, mfail)
#define RenameAtClass(class, thisObj, mfail) \
        _RenameAtClass(class, FALSE, thisObj, mfail)
#define RenameAtParent(class, thisObj, mfail) \
        _RenameAtClass(class, TRUE, thisObj, mfail)

#define RenameProObjsInDir(className, dirName, baseProName, curObjSet, targetSet, mfail) \
        _RenameProObjsInDir(className, FALSE, className, dirName, baseProName, curObjSet, targetSet, mfail)
#define RenameProObjsInDirAtParent(_class, className, dirName, baseProName, curObjSet, targetSet, mfail) \
        _RenameProObjsInDir(_class, TRUE, className, dirName, baseProName, curObjSet, targetSet, mfail)

#define RgstUnknown(thisObj, mfail) \
        _RgstUnknownAtClass(NULL, FALSE, thisObj, mfail)
#define RgstUnknownAtClass(class, thisObj, mfail) \
        _RgstUnknownAtClass(class, FALSE, thisObj, mfail)
#define RgstUnknownAtParent(class, thisObj, mfail) \
        _RgstUnknownAtClass(class, TRUE, thisObj, mfail)

#define SearchUnregFiles(this, unRgstFiles, rgstFiles, masterFileVersion, mfail) \
        _SearchUnregFilesAtClass(NULL, FALSE, this, unRgstFiles, rgstFiles, masterFileVersion, mfail)
#define SearchUnregFilesAtClass(class, this, unRgstFiles, rgstFiles, masterFileVersion, mfail) \
        _SearchUnregFilesAtClass(class, FALSE, this, unRgstFiles, rgstFiles, masterFileVersion, mfail)
#define SearchUnregFilesAtParent(class, this, unRgstFiles, rgstFiles, masterFileVersion, mfail) \
        _SearchUnregFilesAtClass(class, TRUE, this, unRgstFiles, rgstFiles, masterFileVersion, mfail)

#define ShowListInProWorkB(className, showType, showObjSet, showRelationSet, backgroundObj, backgroundRel, mfail) \
        _ShowListInProWorkB(className, FALSE, className, showType, showObjSet, showRelationSet, backgroundObj, backgroundRel, mfail)
#define ShowListInProWorkBAtParent(_class, className, showType, showObjSet, showRelationSet, backgroundObj, backgroundRel, mfail) \
        _ShowListInProWorkB(_class, TRUE, className, showType, showObjSet, showRelationSet, backgroundObj, backgroundRel, mfail)

#define ShowOneInProWorkB(className, showType, showObj, showRelationObj, backgroundObj, backgroundRel, mfail) \
        _ShowOneInProWorkB(className, FALSE, className, showType, showObj, showRelationObj, backgroundObj, backgroundRel, mfail)
#define ShowOneInProWorkBAtParent(_class, className, showType, showObj, showRelationObj, backgroundObj, backgroundRel, mfail) \
        _ShowOneInProWorkB(_class, TRUE, className, showType, showObj, showRelationObj, backgroundObj, backgroundRel, mfail)

#define UpdateFamilyTable(this, instanceObjSet, mfail) \
        _UpdateFamilyTableAtClass(NULL, FALSE, this, instanceObjSet, mfail)
#define UpdateFamilyTableAtClass(class, this, instanceObjSet, mfail) \
        _UpdateFamilyTableAtClass(class, FALSE, this, instanceObjSet, mfail)
#define UpdateFamilyTableAtParent(class, this, instanceObjSet, mfail) \
        _UpdateFamilyTableAtClass(class, TRUE, this, instanceObjSet, mfail)

#define UpdateParentsRefsInMti(oldObj, newName, mfail) \
        _UpdateParentsRefsInMtiAtClass(NULL, FALSE, oldObj, newName, mfail)
#define UpdateParentsRefsInMtiAtClass(class, oldObj, newName, mfail) \
        _UpdateParentsRefsInMtiAtClass(class, FALSE, oldObj, newName, mfail)
#define UpdateParentsRefsInMtiAtParent(class, oldObj, newName, mfail) \
        _UpdateParentsRefsInMtiAtClass(class, TRUE, oldObj, newName, mfail)

#define UpdateProDepObjects(this, dependObjSet, depObjsClassSet, WorkbenchDir, mfail) \
        _UpdateProDepObjectsAtClass(NULL, FALSE, this, dependObjSet, depObjsClassSet, WorkbenchDir, mfail)
#define UpdateProDepObjectsAtClass(class, this, dependObjSet, depObjsClassSet, WorkbenchDir, mfail) \
        _UpdateProDepObjectsAtClass(class, FALSE, this, dependObjSet, depObjsClassSet, WorkbenchDir, mfail)
#define UpdateProDepObjectsAtParent(class, this, dependObjSet, depObjsClassSet, WorkbenchDir, mfail) \
        _UpdateProDepObjectsAtClass(class, TRUE, this, dependObjSet, depObjsClassSet, WorkbenchDir, mfail)

#define UpdateProDeps(this, dependObjSet, externalRefs, mfail) \
        _UpdateProDepsAtClass(NULL, FALSE, this, dependObjSet, externalRefs, mfail)
#define UpdateProDepsAtClass(class, this, dependObjSet, externalRefs, mfail) \
        _UpdateProDepsAtClass(class, FALSE, this, dependObjSet, externalRefs, mfail)
#define UpdateProDepsAtParent(class, this, dependObjSet, externalRefs, mfail) \
        _UpdateProDepsAtClass(class, TRUE, this, dependObjSet, externalRefs, mfail)

#define UpdateProObj(this, objClass, WorkbenchDir, regObj, mfail) \
        _UpdateProObjAtClass(NULL, FALSE, this, objClass, WorkbenchDir, regObj, mfail)
#define UpdateProObjAtClass(class, this, objClass, WorkbenchDir, regObj, mfail) \
        _UpdateProObjAtClass(class, FALSE, this, objClass, WorkbenchDir, regObj, mfail)
#define UpdateProObjAtParent(class, this, objClass, WorkbenchDir, regObj, mfail) \
        _UpdateProObjAtClass(class, TRUE, this, objClass, WorkbenchDir, regObj, mfail)

#define UpdateWbDirectory(newObj, mfail) \
        _UpdateWbDirectoryAtClass(NULL, FALSE, newObj, mfail)
#define UpdateWbDirectoryAtClass(class, newObj, mfail) \
        _UpdateWbDirectoryAtClass(class, FALSE, newObj, mfail)
#define UpdateWbDirectoryAtParent(class, newObj, mfail) \
        _UpdateWbDirectoryAtClass(class, TRUE, newObj, mfail)

#define ValidateForProRename(this, mfail) \
        _ValidateForProRenameAtClass(NULL, FALSE, this, mfail)
#define ValidateForProRenameAtClass(class, this, mfail) \
        _ValidateForProRenameAtClass(class, FALSE, this, mfail)
#define ValidateForProRenameAtParent(class, this, mfail) \
        _ValidateForProRenameAtClass(class, TRUE, this, mfail)

#define ValidateOsNamForAction(className, mfail) \
        _ValidateOsNamForAction(className, FALSE, className, mfail)
#define ValidateOsNamForActionAtParent(_class, className, mfail) \
        _ValidateOsNamForAction(_class, TRUE, className, mfail)

#define ValidateProDepObjects(this, dependObjSet, mfail) \
        _ValidateProDepObjectsAtClass(NULL, FALSE, this, dependObjSet, mfail)
#define ValidateProDepObjectsAtClass(class, this, dependObjSet, mfail) \
        _ValidateProDepObjectsAtClass(class, FALSE, this, dependObjSet, mfail)
#define ValidateProDepObjectsAtParent(class, this, dependObjSet, mfail) \
        _ValidateProDepObjectsAtClass(class, TRUE, this, dependObjSet, mfail)

#define ValidateProInstObjects(this, instanceObjSet, mfail) \
        _ValidateProInstObjectsAtClass(NULL, FALSE, this, instanceObjSet, mfail)
#define ValidateProInstObjectsAtClass(class, this, instanceObjSet, mfail) \
        _ValidateProInstObjectsAtClass(class, FALSE, this, instanceObjSet, mfail)
#define ValidateProInstObjectsAtParent(class, this, instanceObjSet, mfail) \
        _ValidateProInstObjectsAtClass(class, TRUE, this, instanceObjSet, mfail)
#endif /* for msgpro_H */

