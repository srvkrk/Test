#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "saprfc.h"
#include "sapitab.h"



#define __min(a,b) (((a)<(b))?(a):(b))

//CLASS1
#ifndef SAP_ST_CAPIPARMS_CLASS
#define SAP_ST_CAPIPARMS_CLASS
typedef struct {
		RFC_CHAR aCLASS[18];	
}CAPIPARMS_CLASS;
#endif

#ifndef SAP_TH_CAPIPARMS_CLASS
#define SAP_TH_CAPIPARMS_CLASS
static const RFC_TYPEHANDLE handleOfCAPIPARMS_CLASS;
static const RFC_TYPE_ELEMENT typeOfCAPIPARMS_CLASS[] = {
		{"aCLASS",TYPC,18,0},	
};
#endif

//CLASS_TYPE
#ifndef SAP_ST_CAPIPARMS_CLASS_TYPE
#define SAP_ST_CAPIPARMS_CLASS_TYPE
typedef struct {
	
		RFC_CHAR CLASS_TYPE[3];
		
}CAPIPARMS_CLASS_TYPE;
#endif

#ifndef SAP_TH_CAPIPARMS_CLASS_TYPE
#define SAP_TH_CAPIPARMS_CLASS_TYPE
static const RFC_TYPEHANDLE handleOfCAPIPARMS_CLASS_TYPE;
static const RFC_TYPE_ELEMENT typeOfCAPIPARMS_CLASS_TYPE[] = {
		
		{"CLASS_TYPE",TYPC,3,0},

};
#endif


//CHARACT
#ifndef SAP_ST_CAPIPARMS_CHARACT
#define SAP_ST_CAPIPARMS_CHARACT
typedef struct {

		RFC_CHAR CHARACT[30];

}CAPIPARMS_CHARACT;
#endif

#ifndef SAP_TH_CAPIPARMS_CHARACT
#define SAP_TH_CAPIPARMS_CHARACT
static const RFC_TYPEHANDLE handleOfCAPIPARMS_CHARACT;

static const RFC_TYPE_ELEMENT typeOfCAPIPARMS_CHARACT[] = {
		{"CHARACT",TYPC,30,0},
};
#endif


//PROC_ORDER
#ifndef SAP_ST_CAPIPARMS_PROC_ORDER
#define SAP_ST_CAPIPARMS_PROC_ORDER
typedef struct {
		RFC_NUM PROC_ORDER[4];
		
}CAPIPARMS_PROC_ORDER;
#endif

#ifndef SAP_TH_CAPIPARMS_PROC_ORDER
#define SAP_TH_CAPIPARMS_PROC_ORDER
static const RFC_TYPEHANDLE handleOfCAPIPARMS_PROC_ORDER;

static const RFC_TYPE_ELEMENT typeOfCAPIPARMS_PROC_ORDER[] = {
		
		{"PROC_ORDER",TYPNUM,4,0},

};
#endif

//CHANGE_NO
#ifndef SAP_ST_CAPIPARMS_CHANGE_NO
#define SAP_ST_CAPIPARMS_CHANGE_NO
typedef struct {
		
		RFC_CHAR CHANGE_NO[12];
		
}CAPIPARMS_CHANGE_NO;
#endif

#ifndef SAP_TH_CAPIPARMS_CHANGE_NO
#define SAP_TH_CAPIPARMS_CHANGE_NO
static const RFC_TYPEHANDLE handleOfCAPIPARMS_CHANGE_NO;

static const RFC_TYPE_ELEMENT typeOfCAPIPARMS_CHANGE_NO[] = {
		
		{"CHANGE_NO",TYPC,12,0},
};
#endif


//VALUE

#ifndef SAP_ST_CAWN_ATWRT
#define SAP_ST_CAWN_ATWRT
typedef struct {
	
	RFC_CHAR ATWRT[30];
	
}CAWN_ATWRT;
#endif

#ifndef SAP_TH_CAWN_ATWRT
#define SAP_TH_CAWN_ATWRT
static const RFC_TYPEHANDLE handleOfCAWN_ATWRT;
static const RFC_TYPE_ELEMENT typeOfCAWN_ATWRT[] = {
	
	{"ATWRT",TYPC,30,0},
	
};
#endif




//DEPENDENCY_DATA

#ifndef SAP_ST_DEPDAT
#define SAP_ST_DEPDAT
typedef struct {
	RFC_CHAR DEP_TYPE[4];
	RFC_CHAR DEP_TYPE2[1];
	RFC_CHAR SCE_FLAG[1];
	RFC_CHAR STATUS[1];
	RFC_CHAR GROUP[10];
	RFC_CHAR WHR_TO_USE[3];

}DEPDAT;
#endif

#ifndef SAP_TH_DEPDAT
#define SAP_TH_DEPDAT
static const RFC_TYPEHANDLE handleOfDEPDAT;

static const RFC_TYPE_ELEMENT typeOfDEPDAT[] = {
	{"DEP_TYPE",TYPC,4,0},
	{"DEP_TYPE2",TYPC,1,0},
	{"SCE_FLAG",TYPC,1,0},
	{"STATUS",TYPC,1,0},
	{"GROUP",TYPC,10,0},
	{"WHR_TO_USE",TYPC,3,0},
};
#endif


//DELETE_FLAG

#ifndef SAP_ST_CAPIFLAG_FLLKENZ
#define SAP_ST_CAPIFLAG_FLLKENZ
typedef struct {

	RFC_CHAR FLLKENZ[1];
	

}CAPIFLAG_FLLKENZ;
#endif

#ifndef SAP_TH_CAPIFLAG_FLLKENZ
#define SAP_TH_CAPIFLAG_FLLKENZ
static const RFC_TYPEHANDLE handleOfCAPIFLAG_FLLKENZ;
static const RFC_TYPE_ELEMENT typeOfCAPIFLAG_FLLKENZ[] = {

	{"FLLKENZ",TYPC,1,0},
	
};
#endif



//KEY_DATE

#ifndef SAP_ST_SY_DATUM
#define SAP_ST_SY_DATUM
typedef struct {
	
	RFC_DATE DATUM;
	
}SY_DATUM;
#endif

#ifndef SAP_TH_SY_DATUM
#define SAP_TH_SY_DATUM
static const RFC_TYPEHANDLE handleOfSY_DATUM;
static const RFC_TYPE_ELEMENT typeOfSY_DATUM[] = {
	
	{"DATUM",TYPDATE,sizeof(RFC_DATE),0},
	
};
#endif


//DESCRIPTION
#ifndef SAP_ST_DEPDESCR
#define SAP_ST_DEPDESCR
typedef struct {
	RFC_CHAR LANGUAGE[1];
	RFC_CHAR DESCRIPT[30];
	RFC_CHAR FLDELETE[1];
	RFC_CHAR LANGUAGE_ISO[2];

}DEPDESCR;
#endif

#ifndef SAP_TH_DEPDESCR
#define SAP_TH_DEPDESCR
static const RFC_TYPEHANDLE handleOfDEPDESCR;

static const RFC_TYPE_ELEMENT typeOfDEPDESCR[] = {
	{"LANGUAGE",TYPC,1,0},
	{"DESCRIPT",TYPC,30,0},
	{"FLDELETE",TYPC,1,0},
	{"LANGUAGE_ISO",TYPC,2,0},
};
#endif


//SOURCE
#ifndef SAP_ST_DEPSOURCE
#define SAP_ST_DEPSOURCE
typedef struct {
	RFC_NUM LINE_NO[4];
	RFC_CHAR LINE[72];

}DEPSOURCE;
#endif

#ifndef SAP_TH_DEPSOURCE
#define SAP_TH_DEPSOURCE
static const RFC_TYPEHANDLE handleOfDEPSOURCE;

static const RFC_TYPE_ELEMENT typeOfDEPSOURCE[] = {
	{"LINE_NO",TYPNUM,4,0},
	{"LINE",TYPC,72,0},
};
#endif



//DOCUMENTATION
#ifndef SAP_ST_DOC_LANG
#define SAP_ST_DOC_LANG
typedef struct {
	RFC_CHAR LANGUAGE[1];
	RFC_NUM LINE_NO[4];
	RFC_CHAR TXT_FORM[2];
	RFC_CHAR TXT_LINE[132];
	RFC_CHAR LANGUAGE_ISO[2];

}DOC_LANG;
#endif

#ifndef SAP_TH_DOC_LANG
#define SAP_TH_DOC_LANG
static const RFC_TYPEHANDLE handleOfDOC_LANG;

static const RFC_TYPE_ELEMENT typeOfDOC_LANG[] = {
	{"LANGUAGE",TYPC,1,0},
	{"LINE_NO",TYPNUM,4,0},
	{"TXT_FORM",TYPC,2,0},
	{"TXT_LINE",TYPC,132,0},
	{"LANGUAGE_ISO",TYPC,2,0},
};
#endif

