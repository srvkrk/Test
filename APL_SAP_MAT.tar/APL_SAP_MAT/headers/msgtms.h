/*
 *  FILE: msgtms.h
 */

#ifndef msgtms_H
#define msgtms_H

#include <Mtimsgh.h>
#include <metadt.h>
/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _AddToAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects addedItemSet, boolean latest, integer * mfail);

MTIstatus _CancelReserveItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _CancelReserveItemPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _CancelReserveItemPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _CancelReserveSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, integer * mfail);

MTIstatus _CancelReserveSet2
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings workItemHandles, integer * mfail);

MTIstatus _CheckInToTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CheckInToTeamObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, integer * mfail);

MTIstatus _CheckInToTmOtherObjsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _CheckInToTmUnmgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects * TransferInfoObjects, integer * mfail);

MTIstatus _CheckInToTmUnmgAuxAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects transferInfoObjs, integer * mfail);

MTIstatus _CheckInToTmUnmgIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects * TransferInfoObjects, integer * mfail);

MTIstatus _CheckInToTmUnmgSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects inputObjects, ObjectPtr argumentsObj, SetOfObjects * TransferInfoObjects,
   integer * mfail);

MTIstatus _CheckInToTmUnmgSet2
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects inputObjects, SetOfObjects argumentsObjSet, SetOfObjects * TransferInfoObjects,
   integer * mfail);

MTIstatus _CheckOutFromTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CheckOutFromTeamObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, ObjectPtr * ckoObj, integer * mfail);

MTIstatus _CheckOutFromTmUnmgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr checkOutItem,
   ObjectPtr argumentsObj, integer pathFormat, SetOfObjects * transferObjects,
   integer * mfail);

MTIstatus _CheckOutFromTmUnmg2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr argumentsObj, integer pathFormat, SetOfObjects * transferObjects,
   ObjectPtr * newWorkItem, SetOfObjects * dataItems, integer * mfail);

MTIstatus _CheckOutObjFromTmIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr * ckoObj, integer * mfail);

MTIstatus _CheckOutToTeamDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CheckOutToTeamItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   MTIconstString teamName, MTIconstString teamLoc, boolean includeAtt,
   MTIconstString ckoType, ObjectPtr * newWorkItem, SetOfObjects * dataItems,
   integer * mfail);

MTIstatus _CheckOutToTeamItem2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr argumentsObj, ObjectPtr * newWorkItem, SetOfObjects * dataItems,
   integer * mfail);

MTIstatus _CheckOutToTmItmSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects workItems, MTIconstString teamName, MTIconstString teamLoc,
   boolean includeAtt, SetOfObjects * newWorkItems, SetOfStrings * trnObjIndex,
   SetOfObjects * transferObjects, integer * mfail);

MTIstatus _CreateMergeArgPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDailog,
   integer * mfail);

MTIstatus _CreateMergeArgs
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings mrgClassHndls, SetOfObjects * mrgDialogs, integer * mfail);

MTIstatus _CreateMergeArgsInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings mrgClassHndls, SetOfObjects * mrgDialogs, integer * mfail);

MTIstatus _CreateMergeArgsPost
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, integer * mfail);

MTIstatus _CreateReserveArgs
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings argsClassStrs, SetOfObjects * rsvArgObjects, integer * mfail);

MTIstatus _CreateReserveArgsPost
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings argsClassStrs, SetOfObjects * rsvArgObjects, integer * mfail);

MTIstatus _DeleteForSetAndFail
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects originObjects, SetOfObjects * failedObjects, integer * mfail);

MTIstatus _DeleteForSetAndFailPre
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects originObjects, integer * mfail);

MTIstatus _DoCheckInToTmUnmgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects TransferInfoObjects, integer * mfail);

MTIstatus _DoCheckInToTmUnmg2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects transferInfoObjs, ObjectPtr * newWorkItem,
   SetOfObjects * dataItems, SetOfObjects * transferInfo, integer * mfail);

MTIstatus _DoCheckInToTmUnmg3
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects selectedObjs, SetOfObjects argumentsObjs, SetOfObjects transferInfoObjs,
   SetOfObjects * ckoObjects, integer * mfail);

MTIstatus _DoCheckOutTPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _DoCheckOutTPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _DoCheckOutTeamPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _DoCheckOutTeamPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _DoCkiToTeamReplaceAuxAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr predecessorObj, ObjectPtr argsObj, integer * mfail);

MTIstatus _DoReleaseRplceAuxAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr predecessorObj, ObjectPtr argsObj, integer * mfail);

MTIstatus _DoReleaseTransferAuxAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj, ObjectPtr argsObj,
   integer * mfail);

MTIstatus _DoReleaseTransferPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoReleaseTransferPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoTransferTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoTransferTmFromUnmgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects transferInfoObjs, integer * mfail);

MTIstatus _DoTransferTmPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoTransferTmPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoesPredRPrcForCinToTm
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   boolean * answer, integer * mfail);

MTIstatus _DoesPredRValForCinToTm
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   boolean * answer, integer * mfail);

MTIstatus _DoesPredRelPrcForCirTm
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   MTIconstString action, integer actionCode, boolean * answer,
   integer * mfail);

MTIstatus _DoesPredRelValForCirTm
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   MTIconstString action, integer actionCode, boolean * answer,
   integer * mfail);

MTIstatus _DoesPredRelValForRel
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   boolean * answer, integer * mfail);

MTIstatus _DoesRelCValForCkoToTm
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassPrcForCkoT
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassPrcForMrg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesSuccRPrcForCinToTm
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   boolean * answer, integer * mfail);

MTIstatus _DoesSuccRValForCinToTm
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   boolean * answer, integer * mfail);

MTIstatus _DoesSuccRelPrcForCirTm
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   MTIconstString action, integer actionCode, boolean * answer,
   integer * mfail);

MTIstatus _DoesSuccRelValForCirTm
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   MTIconstString action, integer actionCode, boolean * answer,
   integer * mfail);

MTIstatus _DoesSuccRelValForRel
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   boolean * answer, integer * mfail);

MTIstatus _FindFldrByNameAndOwner
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString folderName, MTIconstString ownerName, ObjectPtr * folderObj,
   integer * mfail);

MTIstatus _FindLatestItemInFolderAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr relObj, SetOfObjects origFolderContents, ObjectPtr folder,
   boolean latest, boolean available, ObjectPtr currentObj,
   SetOfObjects * workingFolderContents, SetOfObjects * filteredFolderContents, integer * mfail);

MTIstatus _FindPredForMergeVers
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   ObjectPtr argObj, ObjectPtr extraObj, ObjectPtr * pred,
   integer * mfail);

MTIstatus _FindPredsForMergeVers
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, integer * mfail);

MTIstatus _FindTeamLocsByTeamName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, SetOfObjects * teamLocSet, integer * mfail);

MTIstatus _FindTmProjNameByTmName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, string * teamProjectName, integer * mfail);

MTIstatus _FinishMerge
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   integer * mfail);

MTIstatus _FinishMerge2
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects newItems, integer * mfail);

MTIstatus _FinishMergeVersions
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   integer * mfail);

MTIstatus _GetAllAccTmsForSesUser
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects * teamObjSet, integer * mfail);

MTIstatus _GetAllTeamsForSesUser
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects * teamObjSet, integer * mfail);

MTIstatus _GetFolderContentsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   boolean latest, boolean available, SetOfObjects * folderContents,
   integer * mfail);

MTIstatus _GetFolderContentsExclAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings excludeClasses, boolean latest, boolean available,
   SetOfObjects * folderContents, integer * mfail);

MTIstatus _GetFolderContentsInclAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings includeClasses, boolean latest, boolean available,
   SetOfObjects * folderContents, integer * mfail);

MTIstatus _GetFolderCtsFilterPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings includeClasses, SetOfStrings excludeClasses, boolean latest,
   boolean available, SetOfObjects * otherSideObjSet, SetOfObjects * relObjSet,
   integer * mfail);

MTIstatus _GetLatestAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfObjects origContentSet, boolean available, ObjectPtr * latestObj,
   integer * mfail);

MTIstatus _GetOwnerDatabase
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString ownerName, string * ownerDbName, integer * mfail);

MTIstatus _GetUserRolesAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr user,
   ObjectPtr team, SetOfObjects * setOfRoles, integer * mfail);

MTIstatus _GetUsrToTmCkiModeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * ckiMode, integer * mfail);

MTIstatus _InflateObtainedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _InflateQuestionableAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relObj, integer * mfail);

MTIstatus _InitCheckedOutMetaTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr target, integer * mfail);

MTIstatus _InitCheckedOutTMetaAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr target, integer * mfail);

MTIstatus _InitMergeDialogAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialog,
   integer * mfail);

MTIstatus _InitMrgDlgSetSeqVerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialog,
   integer * mfail);

MTIstatus _InitReserveDialogAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr rsvArgObject,
   ObjectPtr rsvItem, integer * mfail);

MTIstatus _IntAddToAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects addedItemSet, boolean latest, integer * mfail);

MTIstatus _IntAddTo2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects addedItemSet, boolean latest, integer * mfail);

MTIstatus _IntGetLatestAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr * latestObj, SetOfObjects * workingContentsSet, SetOfObjects origContentSet,
   boolean available, integer * mfail);

MTIstatus _IntRemoveFromAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   ObjectPtr removedItem, integer * mfail);

MTIstatus _IsTeamMember
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString userName, MTIconstString teamName, integer * answer,
   integer * mfail);

MTIstatus _ListAllTeamObjs
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects * teamObjSet, integer * mfail);

MTIstatus _ListTeams
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings * teamNames, integer * mfail);

MTIstatus _MakeShadowCopyFmTmTreeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * extraObj, SetOfObjects * processObjects, ObjectPtr workLocationObj,
   boolean doRoot, boolean updateWindow, SetOfObjects * shadowObjects,
   MTIconstString leafPref, integer * mfail);

MTIstatus _MakeShadowCopyTreeTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * extraObj, SetOfObjects * processObjects, ObjectPtr workLocationObj,
   boolean doRoot, boolean updateWindow, SetOfObjects * shadowObjects,
   MTIconstString leafPref, integer * mfail);

MTIstatus _MakeShwCopyFmTmRootObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr workLocationObj, boolean doRoot, boolean updateWindow,
   SetOfObjects * shadowObjects, SetOfObjects * extraObj, integer * mfail);

MTIstatus _MakeShwCopyRootObjectTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr workLocationObj, boolean doRoot, boolean updateWindow,
   SetOfObjects * shadowObjects, SetOfObjects * extraObj, integer * mfail);

MTIstatus _MarkQuestionableAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relationObj,
   integer * mfail);

MTIstatus _MergPrdSccItmsForCirTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, integer * mfail);

MTIstatus _MergPredSuccItmsForRlsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, integer * mfail);

MTIstatus _Merge
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects * uploadInfo, SetOfObjects * newItems,
   integer * mfail);

MTIstatus _Merge2
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _Merge3
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   MTIconstString infoDialogC, SetOfObjects mrgDialogs, SetOfObjects * uploadInfo,
   SetOfObjects * newItems, integer * mfail);

MTIstatus _MergeInsVerSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects newItems, integer * mfail);

MTIstatus _MergeInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects * uploadInfo, SetOfObjects * newItems,
   integer * mfail);

MTIstatus _MergePostItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialogs,
   ObjectPtr newItem, SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _MergePostSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects newItems, SetOfObjects * uploadInfo,
   integer * mfail);

MTIstatus _MergePostSet3
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   MTIconstString infoDialogC, SetOfObjects mrgDialogs, SetOfObjects newItems,
   SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _MergePreCreateItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDailog,
   integer * mfail);

MTIstatus _MergePreCreateSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, integer * mfail);

MTIstatus _MergePreItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialog,
   ObjectPtr newItem, integer * mfail);

MTIstatus _MergePreSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects newItems, integer * mfail);

MTIstatus _MergeVersionPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr newObj,
   ObjectPtr argObj, ObjectPtr pred, ObjectPtr team,
   SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _MergeVersionPostSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects newObjsList, SetOfObjects argObjsList, SetOfObjects * uploadInfo,
   integer * mfail);

MTIstatus _MergeVersionPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr newObj,
   ObjectPtr argObj, ObjectPtr pred, ObjectPtr team,
   integer * mfail);

MTIstatus _MergeVersions2
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argsList, SetOfObjects * uploadInfo, SetOfObjects * newItemList,
   SetOfObjects * failedItems, integer * mfail);

MTIstatus _MergeVersionsInt2
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argsList, SetOfObjects * uploadInfo, SetOfObjects * newItemList,
   SetOfObjects * failedObjects, integer * mfail);

MTIstatus _MergeVersionsPost
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, SetOfObjects workItems, SetOfObjects * uploadInfo,
   integer * mfail);

MTIstatus _MergeVersionsPre
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, SetOfObjects workItems, integer * mfail);

MTIstatus _MoveFldrToFldrDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _MoveFldrToFldrItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString teamName, MTIconstString fromTeamFldr, MTIconstString toTeamFldr,
   integer * mfail);

MTIstatus _MrgVerSpecifyCreArg
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   ObjectPtr argObj, string * altCreClass, ObjectPtr * altCreObj,
   integer * mfail);

MTIstatus _MrgVersAdjDlgPredInfoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr argObj,
   ObjectPtr pred, integer * mfail);

MTIstatus _ObtainCkoFmTmDstForDlgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * dest, integer * mfail);

MTIstatus _ObtainCkoTDestForDlgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * dest, integer * mfail);

MTIstatus _PrcFldrKyCtsForLatestAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfObjects * folderContents, integer * mfail);

MTIstatus _PrcFldrNKyCtsForLatestAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfObjects * folderContents, integer * mfail);

MTIstatus _PrcItmRelsForCancelRsvAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _PrcPrdSccItmForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredItemForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredItemForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredRForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, ObjectPtr succ, boolean isBaseObj,
   integer * mfail);

MTIstatus _PrcPredRelForCirToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr succ,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredSuccItemsForRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcSuccItemForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _PrcSuccItemForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _PrcSuccRForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, ObjectPtr pred, boolean isBaseObj,
   integer * mfail);

MTIstatus _PrcSuccRelForCirToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr succ,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _ProcCheckOutItemObjsTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, boolean refresh, boolean isBase,
   integer * mfail);

MTIstatus _ProcCheckOutTItemObjsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, boolean refresh, boolean isBase,
   integer * mfail);

MTIstatus _ProcERORelForCkoTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, ObjectPtr * newRelObj, integer * mfail);

MTIstatus _ProcERORelForMrgVerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, ObjectPtr * newRelObj, integer * mfail);

MTIstatus _ProcRelForCheckOutTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _ProcessObjsForRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relObject,
   ObjectPtr leftObject, ObjectPtr rightObject, integer * mfail);

MTIstatus _ProcessRelForMergeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _ProcessRelForMrgVerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _ProcessRelsForMrgPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mergeObj,
   ObjectPtr mergeDialog, SetOfObjects otherSideObjs, integer * mfail);

MTIstatus _ProcessRelsForMrgPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mergeObj,
   ObjectPtr mergeDialog, SetOfObjects otherSideObjs, integer * mfail);

MTIstatus _ProcessSetForPrg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProcessSetForPrgPost
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProcessSetForPrgPre
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _PropCreDateResMrgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * propagate, integer * mfail);

MTIstatus _PropCreDateTCOAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * propagate, integer * mfail);

MTIstatus _PurgePredecessorsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PurgePredecessorsDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _QueryUpToDateStatusAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * answer, integer * mfail);

MTIstatus _QueryUpToDateStatusIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * answer, integer * mfail);

MTIstatus _ReleaseDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ReleaseItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   MTIconstString destOwnerName, MTIconstString releaseType, boolean includeAtt,
   SetOfObjects * dataItems, integer * mfail);

MTIstatus _ReleaseItemForSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects dialogs, SetOfObjects * eplctSlctAndReleased, SetOfObjects * eplctSlctButFailed,
   SetOfObjects * implctSlctAndReleased, SetOfObjects * implctSlctButFailed, integer * mfail);

MTIstatus _ReleaseItemPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   MTIconstString destOwnerName, MTIconstString releaseType, boolean includeAtt,
   SetOfObjects * dataItems, integer * mfail);

MTIstatus _RemoveFromAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   ObjectPtr removedItem, integer * mfail);

MTIstatus _RenameFolderAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _RenameFolderDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _Reserve
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfObjects * downloadInfo,
   integer * mfail);

MTIstatus _Reserve1
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfObjects * failedItems,
   SetOfStrings * mfailCodes, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _Reserve2
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings workItemHandles, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _Reserve3
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings workItemHandles, SetOfObjects rsvArgObjects, SetOfObjects * downloadInfo,
   integer * mfail);

MTIstatus _Reserve4
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings workItemHandles, integer * mfail);

MTIstatus _Reserve5
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings workItemHandles, SetOfObjects rsvArgObjects, integer * mfail);

MTIstatus _ReserveInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfObjects * downloadInfo,
   integer * mfail);

MTIstatus _ReserveInt1
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfObjects failedItems,
   SetOfStrings mfailCodes, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr rsvArgObject, integer * mfail);

MTIstatus _ReserveItemPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr rsvArgObject, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveItemPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr rsvArgObject, integer * mfail);

MTIstatus _ReserveSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, integer * mfail);

MTIstatus _ReserveSet1
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfObjects failedItems,
   SetOfStrings mfailCodes, integer * mfail);

MTIstatus _ReserveSetPost
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfObjects * downloadInfo,
   integer * mfail);

MTIstatus _ReserveSetPost1
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfStrings failedItems,
   SetOfObjects mfailCodes, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveSetPre
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, integer * mfail);

MTIstatus _ReserveSetPre1
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfObjects failedItems,
   SetOfStrings mfailCodes, integer * mfail);

MTIstatus _ReserveVersionPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr argObj, ObjectPtr userFolder, boolean generateInfo,
   SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveVersionPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr argObj, ObjectPtr userFolder, integer * mfail);

MTIstatus _ReserveVersions2
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects argsList, ObjectPtr userFolder,
   boolean generateInfo, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveVersionsInt2
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects argsList, ObjectPtr userFolder,
   boolean generateInfo, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveVersionsPost
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects argsList, ObjectPtr userFolder,
   boolean generateInfo, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveVersionsPre
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects argsList, ObjectPtr userFolder,
   integer * mfail);

MTIstatus _SetCompCopyAttributesTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _SetCompCopyFromTmAttrsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _SetCopyAttributesTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr sourceObj, integer * mfail);

MTIstatus _SetCopyFromTmAttrsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr sourceObj, integer * mfail);

MTIstatus _SetSeqForCkoFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean isBase, ObjectPtr dest,
   integer * mfail);

MTIstatus _SetSeqForCkoToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean isBase, ObjectPtr dest,
   integer * mfail);

MTIstatus _SetVerForCkoFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean isBase, ObjectPtr dest,
   integer * mfail);

MTIstatus _SetVerForCkoToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean isBase, ObjectPtr dest,
   integer * mfail);

MTIstatus _TranTmFromUnmgPrepAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects * transferInfoObjs, integer * mfail);

MTIstatus _TranTmFromUnmgPrepAuxAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects * transferInfoObjs, integer * mfail);

MTIstatus _TranTmFromUnmgPrepIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, integer * mfail);

MTIstatus _TransferAuthorityAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, integer * mfail);

MTIstatus _TransferAuthorityDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _TransferReserveOwnerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   MTIconstString newOwner, integer * mfail);

MTIstatus _TransferTmObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _UpdateMergedItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr objToProc,
   ObjectPtr dialogObj, SetOfObjects newObjList, integer * mfail);

MTIstatus _UpdateMergedItemForSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects objsToProc, SetOfObjects dialogObjs, integer * mfail);

MTIstatus _UpdateTmDfltForTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValArgForMergePostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDailog,
   integer * mfail);

MTIstatus _ValArgsForMergeSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, integer * mfail);

MTIstatus _ValCancelReserveItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _ValCancelReserveSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, integer * mfail);

MTIstatus _ValCkoObjForCheckOutTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString ownerName, boolean interactive, integer * mfail);

MTIstatus _ValCkoObjForCkoFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString ownerName, boolean interactive, integer * mfail);

MTIstatus _ValCkoTestOwnForTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObject, integer * mfail);

MTIstatus _ValDlgForCkoFromTmCpyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, ObjectPtr originObject, SetOfStrings * extraStr,
   SetOfObjects * extraObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValDlgForCkoToTmCpyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, ObjectPtr originObject, SetOfStrings * extraStr,
   SetOfObjects * extraObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValDlgForPrgSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr originObj,
   MTIconstString originClassName, ObjectPtr dlgObject, SetOfStrings * extraStr,
   SetOfObjects * extraObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValForCkiNoRplToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValForMergeVersions
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects * failedItems, integer * mfail);

MTIstatus _ValForReleaseNoRplAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValForReserveVersions
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, integer * mfail);

MTIstatus _ValIfPurgeAllowedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relationObj, integer * mfail);

MTIstatus _ValIfPurgeAllowedWrpAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relationObj, integer * mfail);

MTIstatus _ValItemForMergeVersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr argObj,
   ObjectPtr pred, integer * mfail);

MTIstatus _ValPredForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _ValPredForCkiReplcToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, boolean isBaseObj,
   integer * mfail);

MTIstatus _ValPredForRelseReplcAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, boolean isBaseObj,
   integer * mfail);

MTIstatus _ValPredItemForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _ValPredRelForCirToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr succ,
   ObjectPtr pred, boolean isBaseObj, boolean * hasAttacher,
   integer * mfail);

MTIstatus _ValPredRelForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, ObjectPtr succ, boolean isBaseObj,
   integer * mfail);

MTIstatus _ValRelForMergePostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialogs,
   ObjectPtr newItems, SetOfObjects * otherSideItems, integer * mfail);

MTIstatus _ValRelForMergePreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialogs,
   ObjectPtr newItems, SetOfObjects * otherSideItems, integer * mfail);

MTIstatus _ValRelsForMergePost
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects newItems, SetOfObjects * otherSideItems,
   integer * mfail);

MTIstatus _ValRelsForMergePre
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects newItems, SetOfObjects * otherSideItems,
   integer * mfail);

MTIstatus _ValSccAndPrdForCirToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, boolean * hasAttacher, integer * mfail);

MTIstatus _ValSetForPurge
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects passedObjects, SetOfObjects failedObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValSetForPurgePost
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects passedObjects, SetOfObjects failedObjects, integer * mfail);

MTIstatus _ValSetForPurgePre
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects originObjects, integer * mfail);

MTIstatus _ValSuccAndPredForRlsRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, boolean * hasAttacher, integer * mfail);

MTIstatus _ValSuccItemForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _ValSuccItemForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _ValSuccRForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, ObjectPtr pred, boolean isBaseObj,
   integer * mfail);

MTIstatus _ValSuccRelForCirToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr succ,
   ObjectPtr pred, boolean isBaseObj, boolean * hasAttacher,
   integer * mfail);

MTIstatus _ValSuccRelForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, ObjectPtr pred, boolean isBaseObj,
   integer * mfail);

MTIstatus _ValidateForCheckOutTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForCkiToTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForCkoFromTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForCopyTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForMoveToFldrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForPurgeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relationObj, SetOfStrings * recurSetPtr, NVSET * classAnswersSetPtr,
   integer * mfail);

MTIstatus _ValidateForPurgeAuxAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects preds, integer * mfail);

MTIstatus _ValidateForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForReserveItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr rsvArgObject, integer * mfail);

MTIstatus _ValidateForReserveSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, integer * mfail);

MTIstatus _ValidateForReserveSet1
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects rsvArgObjects, SetOfObjects failedItems,
   SetOfStrings mfailCodes, integer * mfail);

MTIstatus _ValidatePredForMergeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _ValidateRelForCkoTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _ValidateRelsForMerge
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mrgDialogs, SetOfObjects newItems, SetOfObjects * otherSideItems,
   integer * mfail);

MTIstatus _ValidateTeamName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dialogObj, integer * mfail);

/*
 *  Unpublished Messages
 */

MTIstatus _AddToNestAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects addedItemSet, integer * mfail);

MTIstatus _AddToPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects addedItemSet, boolean latest, integer * mfail);

MTIstatus _AddToPreIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects addedItemSet, boolean latest, integer * mfail);

MTIstatus _AddUsrToTeamRoleUsrGrp
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamRole, ObjectPtr * usgObj,
   integer * mfail);

MTIstatus _AllowCkoFromTeam
   (MTIconstString _class, boolean getParent, MTIconstString className,
   boolean * answer, integer * mfail);

MTIstatus _AssignRoleToMbrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AssignRoleToMbrObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString teamName, MTIconstString teamRoleName, ObjectPtr * traObj,
   integer * mfail);

MTIstatus _AssignTeamRole
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, MTIconstString teamRoleName,
   ObjectPtr * traObj, integer * mfail);

MTIstatus _AssignTeamRoleForUst
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, MTIconstString teamRoleName,
   ObjectPtr * traObj, integer * mfail);

MTIstatus _CancelReserveSetInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, integer * mfail);

MTIstatus _CheckForCpyDuplicatesTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr newObj, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _CheckForCpyDupsFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr newObj, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _CheckInToTeamIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CheckInToTmUmgIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects * TransferInfoObjects, integer * mfail);

MTIstatus _CheckOutFromTeamIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CheckOutFromTmSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _CheckOutFromTmUnmgIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr checkOutItem,
   ObjectPtr argumentsObj, integer pathFormat, SetOfObjects * transferObjects,
   integer * mfail);

MTIstatus _CheckOutTAttmntsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _CheckOutTSubSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, MTIconstString workLoc, MTIconstString folder,
   integer * mfail);

MTIstatus _CheckOutToTeamIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CheckOutToTmObjectIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _CheckOutUAttmntsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _CheckOutUSubSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, MTIconstString workLoc, integer * mfail);

MTIstatus _CheckTmRlAssnObject
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString userName, MTIconstString teamProjName, MTIconstString teamRoleName,
   MTIconstString indirectTeam, boolean * exists, integer * mfail);

MTIstatus _CkiToTeamNoReplaceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * ckiDialog, integer * mfail);

MTIstatus _CkiToTeamReplaceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * ckiDialog, integer * mfail);

MTIstatus _CkiToTmNoReplaceObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, integer * mfail);

MTIstatus _CkiToTmReplaceObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, integer * mfail);

MTIstatus _CleanBrowsrItmCkoMkvTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ConvertTeamCkoToCpyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr ckoObj,
   ObjectPtr workItem, ObjectPtr * cpyObj, integer * mfail);

MTIstatus _CopyPpkCompTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * newObj, integer * mfail);

MTIstatus _CreDirSelRuForTeamLocAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CreateAndInsVer
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr creArg, MTIconstString teamfldr, MTIconstString owner,
   ObjectPtr predObj, ObjectPtr succObj, ObjectPtr * newObj,
   integer * mfail);

MTIstatus _CreateCopiedCompMetaTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * newObj, integer * mfail);

MTIstatus _CreateCopiedCompMetaTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * newObj, integer * mfail);

MTIstatus _CreateCopiedFromTmItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer updateWindow, SetOfObjects copiedObjs,
   ObjectPtr * newObj, ObjectPtr * copiedObj, integer * mfail);

MTIstatus _CreateCopiedFromTmMetaAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr * newObj, integer * mfail);

MTIstatus _CreateCopiedItemTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer updateWindow, SetOfObjects copiedObjs,
   ObjectPtr * newObj, ObjectPtr * copiedObj, integer * mfail);

MTIstatus _CreateCopiedMetaTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr * newObj, integer * mfail);

MTIstatus _CreateGnTmToTmRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr accTeamObj, ObjectPtr shrTeamObj, boolean useSameUsrRoleOpt,
   MTIconstString dfltTeamRole, ObjectPtr * gttObj, integer * mfail);

MTIstatus _CreateIndirectTraAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr gttObj,
   MTIconstString usrName, MTIconstString teamName, MTIconstString teamRoleName,
   integer * mfail);

MTIstatus _CreateMergeArgPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialog,
   integer * mfail);

MTIstatus _CreateReserveArgsInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings argsClassStrs, SetOfObjects * rsvArgObjects, integer * mfail);

MTIstatus _CreateReserveVersArgs
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfStrings argsClassStrs, SetOfObjects * argsObjects, integer * mfail);

MTIstatus _CreateTeamDefaults
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, MTIconstString teamRoleName, MTIconstString teamShrTmRoleName,
   ObjectPtr * teamDfltObj, integer * mfail);

MTIstatus _CreateTeamProject
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, MTIconstString teamProjectName, ObjectPtr * projObj,
   integer * mfail);

MTIstatus _CreateTeamRoleAssn
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, MTIconstString teamRoleName,
   MTIconstString indirectTeam, ObjectPtr * traObj, integer * mfail);

MTIstatus _CreateTeamRoleAssnInt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString roleName, MTIconstString teamName,
   MTIconstString shrTeamName, integer * mfail);

MTIstatus _CreateUsrToTmRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr teamObj, ObjectPtr userObj, MTIconstString teamRole,
   ObjectPtr * ustObj, integer * mfail);

MTIstatus _DGetLVSFolderAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSMergeToOwnerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSMergeToOwnerDirAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSTeamFldrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSTeamLocAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DelDirSelRuForTeamLocAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DelRolesForUsrInTm
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, MTIconstString indirectTeam,
   integer * mfail);

MTIstatus _DeleteForSetAndFailInt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects originObjects, SetOfObjects * failedObjects, integer * mfail);

MTIstatus _DeleteGnTmToTmRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString accTeamName, MTIconstString shrTeamName, integer * mfail);

MTIstatus _DeleteRoleOfMbrObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString teamName, MTIconstString teamRoleName, integer * mfail);

MTIstatus _DeleteTeamDefaults
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, integer * mfail);

MTIstatus _DeleteTeamRole
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, MTIconstString teamRoleName,
   MTIconstString indirectTeam, integer * mfail);

MTIstatus _DetermineVersionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, boolean updateCounter, integer * mfail);

MTIstatus _DoCheckInToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, ObjectPtr predecessor, ObjectPtr predecessorParent,
   ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoCheckInToTmOtherObjs
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects otherObjs, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoCheckOutFromTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, integer * mfail);

MTIstatus _DoCheckOutItemFromTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   SetOfObjects transferredObjs, ObjectPtr * dest, integer * mfail);

MTIstatus _DoCheckOutTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, MTIconstString oldName,
   integer * mfail);

MTIstatus _DoCheckOutTItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   MTIconstString oldName, SetOfObjects transferredObjs, ObjectPtr * dest,
   integer * mfail);

MTIstatus _DoCheckOutTPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _DoCheckOutTeamPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _DoCkiRplceToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, integer * mfail);

MTIstatus _DoCkiToTeamNoReplaceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, integer * mfail);

MTIstatus _DoCkoFromTmAttmnts
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects attachedObjs, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoCkoMkvCreDestObjTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   SetOfObjects transferredObjs, ObjectPtr * dest, ObjectPtr * relatedObj,
   integer * mfail);

MTIstatus _DoCkoMkvTeamPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _DoCkoTMkvCreDestObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   MTIconstString oldName, SetOfObjects transferredObjs, ObjectPtr * dest,
   ObjectPtr * relatedObj, integer * mfail);

MTIstatus _DoCkoTMkvPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _DoCopyFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer updateWindow, boolean createCopyRel, integer * mfail);

MTIstatus _DoCopyFromTmItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer updateWindow, boolean createCopyRel,
   SetOfObjects copiedObjs, ObjectPtr * newObj, ObjectPtr * nextTarget,
   integer * mfail);

MTIstatus _DoCopyItemTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer updateWindow, boolean createCopyRel,
   SetOfObjects copiedObjs, ObjectPtr * newObj, ObjectPtr * nextTarget,
   integer * mfail);

MTIstatus _DoCopyTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer updateWindow, boolean createCopyRel, integer * mfail);

MTIstatus _DoCorrectPurgeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relationObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoMoveFldrToFldrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoPurgeSequenceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DoReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr predecessor, ObjectPtr predecessorParent, ObjectPtr destOwnerObj,
   ObjectPtr dialogObj, ObjectPtr destOwnerDirObj, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoReleaseNoReplaceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoReleaseRplceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoReleaseTransferAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr destOwnerObj, ObjectPtr destOwnerDirObj, ObjectPtr dialogObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoReleaseTransferCopyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr destOwnerObj, ObjectPtr target, ObjectPtr dialogObj,
   boolean isBaseObj, SetOfObjects sourceObjSet, SetOfObjects destObjSet,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoShadowCopyFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer updateWindow, ObjectPtr * newObj, integer * mfail);

MTIstatus _DoShadowCopyTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer updateWindow, ObjectPtr * copiedObj, integer * mfail);

MTIstatus _DoTransferAuthorityAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoTransferGitItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr destOwnerObj, boolean isBaseObj, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoTransferTmCopyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr destOwnerObj, ObjectPtr target, boolean isBaseObj,
   SetOfObjects sourceObjSet, SetOfObjects destObjSet, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _DoTransferTmUnmgIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr argumentsObj, SetOfObjects transferInfoObjs, integer * mfail);

MTIstatus _DoesRelPrcForPostRlse
   (MTIconstString _class, boolean getParent, MTIconstString className,
   boolean * answer, integer * mfail);

MTIstatus _DoesRolePropagate
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamRole, integer * answer, integer * mfail);

MTIstatus _DoesTmRlAssnExist
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString userName, MTIconstString teamProjName, MTIconstString teamRoleName,
   MTIconstString indirectTeam, boolean * exists, integer * mfail);

MTIstatus _FailMerge
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   integer * mfail);

MTIstatus _FailMergeVersions
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   integer * mfail);

MTIstatus _FindAllFoldersByName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString folderName, SetOfObjects * folderObjSet, integer * mfail);

MTIstatus _FindBestTeamLocAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr team,
   ObjectPtr argObj, ObjectPtr * teamloc, integer * mfail);

MTIstatus _FindGnTmToTmRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString accTeamName, MTIconstString shrTeamName, ObjectPtr * gttObj,
   integer * mfail);

MTIstatus _FindTeamRoleObject
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer findType, MTIconstString teamRoleName, ObjectPtr * teamRoleObj,
   integer * validationStatus, integer * mfail);

MTIstatus _FindTmNameByTmProjName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamProjectName, string * teamName, integer * mfail);

MTIstatus _FindTmRlAssnObject
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer findType, MTIconstString userName, MTIconstString teamProjName,
   MTIconstString teamRoleName, MTIconstString indirectTeam, ObjectPtr * traObj,
   integer * validationStatus, integer * mfail);

MTIstatus _FindTmdByTeamName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer findType, MTIconstString teamName, ObjectPtr * tmDfltObj,
   integer * validationStatus, integer * mfail);

MTIstatus _FindTmdByTeamRole
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer findType, MTIconstString teamRoleName, boolean shrTeamRoleFlag,
   ObjectPtr * tmDfltObj, integer * validationStatus, integer * mfail);

MTIstatus _FindTraByRoleName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer findType, MTIconstString teamRoleName, ObjectPtr * traObj,
   integer * validationStatus, integer * mfail);

MTIstatus _FindTraForUsrWithRole
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString userName, MTIconstString teamRoleName, SetOfObjects * traObjSet,
   integer * mfail);

MTIstatus _FindUsrToGrpObject
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer findType, MTIconstString usrName, MTIconstString usrGrpName,
   ObjectPtr * usgObj, integer * validationStatus, integer * mfail);

MTIstatus _FindUsrToTmRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, ObjectPtr * ustObj,
   integer * mfail);

MTIstatus _GetAllAccGttByTmName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, SetOfObjects * gttObjSet, integer * mfail);

MTIstatus _GetAllAccessibleTeams
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, SetOfStrings * teamSet, integer * mfail);

MTIstatus _GetAllParentFolderIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects * parentFolders, integer * mfail);

MTIstatus _GetAllPreviousVersExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * preds, integer * mfail);

MTIstatus _GetAllPreviousVersionsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects preds, integer * mfail);

MTIstatus _GetAllShareTeams
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, SetOfStrings * teamSet, integer * mfail);

MTIstatus _GetAllShrGttByTmName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, SetOfObjects * gttObjSet, integer * mfail);

MTIstatus _GetAllTeamMembers
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, SetOfStrings * memberSet, integer * mfail);

MTIstatus _GetAllTeamsForUserName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString userName, SetOfStrings * teamSet, integer * mfail);

MTIstatus _GetAllTmRlsForUsrInTm
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, MTIconstString indirectTeam,
   SetOfStrings * tmRoleSet, integer * mfail);

MTIstatus _GetAllTraForUsrInTm
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, MTIconstString indirectTeam,
   SetOfObjects * traObj, integer * mfail);

MTIstatus _GetAllUstByTeamName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, SetOfObjects * ustObjSet, integer * mfail);

MTIstatus _GetAllUstByUserName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString userName, SetOfObjects * ustObjSet, integer * mfail);

MTIstatus _GetAnyCkoTeamRPredAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * pred, integer * mfail);

MTIstatus _GetCitPredFrmSuccAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * pred, integer * mfail);

MTIstatus _GetCkiTeamRPredFrmSuccAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * pred, integer * mfail);

MTIstatus _GetCkoRPredFrmSuccTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * pred, integer * mfail);

MTIstatus _GetCkoRSuccFrmPredTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * succ, integer * mfail);

MTIstatus _GetConditionState
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr objToProc, MTIconstString condName, boolean * state,
   integer * mfail);

MTIstatus _GetCtrlTeamFolderAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * folderObj, integer * mfail);

MTIstatus _GetCtrlTeamFolderInt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects objects, boolean forceRefresh, SetOfObjects * folders,
   integer * mfail);

MTIstatus _GetCtrlTeamFolderSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects objects, SetOfObjects * folders, integer * mfail);

MTIstatus _GetCurrentTeamFldrsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * folderObjSet, SetOfObjects * folderItemRelSet, integer * mfail);

MTIstatus _GetDfltRole
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, string * dfltRole, integer * mfail);

MTIstatus _GetDfltShrTmRole
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, string * dfltShrTmRole, integer * mfail);

MTIstatus _GetFolderAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr * folder, integer * mfail);

MTIstatus _GetFolderCanonicalPathAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects * path, integer * mfail);

MTIstatus _GetFolderContentsDAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   boolean latest, boolean available, SetOfObjects * folderContents,
   integer * mfail);

MTIstatus _GetFolderContentsExclDAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings excludeClasses, boolean latest, boolean available,
   SetOfObjects * folderContents, integer * mfail);

MTIstatus _GetFolderContentsInclDAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings includeClasses, boolean latest, boolean available,
   SetOfObjects * folderContents, integer * mfail);

MTIstatus _GetFolderContentsIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings includeClasses, SetOfStrings excludeClasses, boolean latest,
   boolean available, integer newWindow, SetOfObjects * folderContents,
   integer * mfail);

MTIstatus _GetFolderContentsInt3AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings includeClasses, SetOfStrings excludeClasses, boolean latest,
   boolean available, integer newWindow, SetOfObjects * folderContents,
   integer * mfail);

MTIstatus _GetFolderFilteredItemsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfObjects origFolderContents, boolean latest, ObjectPtr currentObj,
   SetOfObjects * workingFolderContents, SetOfObjects * filteredFolderContents, integer * mfail);

MTIstatus _GetParentFoldersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects * parentFolders, integer * mfail);

MTIstatus _GetParentFoldersIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfObjects * parentFolders, integer * mfail);

MTIstatus _GetRelatedForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workitemObj,
   ObjectPtr dialog, SetOfObjects * implctSlctAndReleased, SetOfObjects * implctSlctButFailed,
   integer * mfail);

MTIstatus _GetReleaseModeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * ckiMode, integer * mfail);

MTIstatus _GetSetFolderLatestItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr relObj, SetOfObjects origFolderContents, ObjectPtr folder,
   boolean latest, boolean available, ObjectPtr currentObj,
   SetOfObjects * workingFolderContents, SetOfObjects * filteredFolderContents, integer * mfail);

MTIstatus _GetSubFolders
   (MTIconstString _class, boolean getParent, MTIconstString tmFolderClass,
   MTIconstString tmFolderName, MTIconstString ownerNm, SetOfObjects * subFolders,
   integer * mfail);

MTIstatus _GetSuccForDoPrgSeqAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr tempObj, ObjectPtr * succ, integer * mfail);

MTIstatus _GetSuccForPrgSequenceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * succ, integer * mfail);

MTIstatus _GetTeamFoldersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * folderObjSet, boolean * isCtrlTmFldr, integer * mfail);

MTIstatus _GetTmCkiCkoSuccessorAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * successorObj, integer * mfail);

MTIstatus _GetTmCkiCkoSuccessorExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * successorObj, integer * mfail);

MTIstatus _GetTmRoleUsrGrp
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamRole, string * tmRoleUsrGrp, integer * mfail);

MTIstatus _GetTmdByTeamName
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, ObjectPtr * tmDfltObj, integer * mfail);

MTIstatus _GetTmrByTeamRole
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamRole, ObjectPtr * tmRoleObj, integer * mfail);

MTIstatus _GetTopLevelFoldersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr teamObj,
   SetOfObjects * folders, integer * mfail);

MTIstatus _InitCkoMkvMetaTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr target, integer * mfail);

MTIstatus _InitMetaForMergeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr newItem,
   ObjectPtr creDialog, integer * mfail);

MTIstatus _InsVersItemPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr insertObj,
   ObjectPtr predObj, ObjectPtr succObj, integer * mfail);

MTIstatus _InsVersItemSetPostInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects * insertObjs, SetOfObjects * predObjs, SetOfObjects * succObjs,
   integer * mfail);

MTIstatus _InsertVersionItemSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects * insertObjs, SetOfObjects * predObjs, SetOfObjects * succObjs,
   integer * mfail);

MTIstatus _InsertVersionTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr insertObj,
   ObjectPtr predObj, ObjectPtr succObj, integer * insFlags,
   integer * predFlags, integer * succFlags, integer * mfail);

MTIstatus _InsertVersionVaultAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr insertObj,
   ObjectPtr predObj, ObjectPtr succObj, integer * insFlags,
   integer * predFlags, integer * succFlags, integer * mfail);

MTIstatus _InsertVersnItemSetInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects * insertObjs, SetOfObjects * predObjs, SetOfObjects * succObjs,
   integer * mfail);

MTIstatus _InsertVersnItemSetPre
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects * insertObjs, SetOfObjects * predObjs, SetOfObjects * succObjs,
   integer * mfail);

MTIstatus _IntAddToNoValAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   SetOfObjects addedItemSet, boolean latest, integer * mfail);

MTIstatus _IntGetLatest2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr * latestObj, SetOfObjects * workingContentsSet, SetOfObjects origContentSet,
   boolean available, integer * mfail);

MTIstatus _IntGetLatest3AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr * latestObj, SetOfObjects * workingContentsSet, SetOfObjects origContentSet,
   boolean available, integer * mfail);

MTIstatus _IsAvailableAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr contentObj, boolean * available, integer * mfail);

MTIstatus _IsInSetOfClassesAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings setOfClasses, boolean * inClasses, integer * mfail);

MTIstatus _IsPromptSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, integer * answer, integer * mfail);

MTIstatus _IsReleasableAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workitemObj,
   ObjectPtr dialog, boolean * allowed, integer * mfail);

MTIstatus _IsTeamFldrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * answer, integer * mfail);

MTIstatus _ItemCopyInTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr objToCopy,
   ObjectPtr argumentsObj, ObjectPtr * newCopiedObj, integer * mfail);

MTIstatus _MakeAvailToNonSecureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _MakeAvailToSecureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _MakeShadowCopyObjectTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr workLocation, boolean updateWindow, SetOfObjects * shadowObjects,
   integer * mfail);

MTIstatus _MakeShadowCpyFromTmObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr workLocation, boolean updateWindow, SetOfObjects * shadowObjects,
   integer * mfail);

MTIstatus _MergPrdIntoSccForCirTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, integer * mfail);

MTIstatus _MergPrdSccRelsForCirTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, integer * mfail);

MTIstatus _MergPredIntoSuccForRlsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, integer * mfail);

MTIstatus _MergePostItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialogs,
   ObjectPtr newItem, SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _MergePreCreateItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialog,
   integer * mfail);

MTIstatus _MergePreItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialog,
   ObjectPtr newItem, integer * mfail);

MTIstatus _MergeVersExtractArgsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr argObj, ObjectPtr * pred, ObjectPtr * team,
   ObjectPtr * teamFldr, ObjectPtr * userFldr, integer * mfail);

MTIstatus _MergeVersSyncArgsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr pred, ObjectPtr team, ObjectPtr teamFldr,
   ObjectPtr userFldr, ObjectPtr argObj, integer * mfail);

MTIstatus _MergeVersionInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   ObjectPtr argObj, ObjectPtr team, ObjectPtr teamFldr,
   ObjectPtr userFldr, ObjectPtr extraObj, ObjectPtr * newItem,
   SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _MergeVersionPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr newObj,
   ObjectPtr argObj, ObjectPtr pred, ObjectPtr team,
   SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _MergeVersionPreIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr newObj,
   ObjectPtr argObj, ObjectPtr pred, ObjectPtr team,
   integer * mfail);

MTIstatus _MergeVersionsExpArgs
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, integer * mfail);

MTIstatus _MergeVersionsPostInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, SetOfObjects workItems, SetOfObjects * uploadInfo,
   integer * mfail);

MTIstatus _MergeVersionsPreInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, SetOfObjects workItems, integer * mfail);

MTIstatus _ModifyRoleOfMbrObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString teamName, MTIconstString oldTeamRoleName, MTIconstString newTeamRoleName,
   ObjectPtr * traObj, integer * mfail);

MTIstatus _ModifyTeamRole
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString usrName, MTIconstString teamName, MTIconstString oldTeamRoleName,
   MTIconstString newTeamRoleName, ObjectPtr * traObj, integer * mfail);

MTIstatus _MoveFldrToFldrIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _MoveFldrToNestedFldrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   ObjectPtr toFolder, ObjectPtr toFolderDialog, integer * mfail);

MTIstatus _MoveFldrToNestedFldrInAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   ObjectPtr toFolder, ObjectPtr toFolderDialog, integer * mfail);

MTIstatus _MrgIncrementSequenceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr predObj,
   ObjectPtr argObj, integer * mfail);

MTIstatus _MrgPostPrcForReplVaultAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialogs,
   ObjectPtr newItem, SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _MrgVerAdjMetaPostCreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr newObj,
   ObjectPtr argObj, ObjectPtr pred, ObjectPtr team,
   integer * mfail);

MTIstatus _MrgVerIncrementVersionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr predObj,
   ObjectPtr argObj, integer * mfail);

MTIstatus _MrgVerInsertVersionSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItemList, SetOfObjects argList, integer * mfail);

MTIstatus _MrgVersAdjDialogInfoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr argObj,
   ObjectPtr pred, integer * mfail);

MTIstatus _MrgVersAdjMetaPostCre
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, SetOfObjects workItems, integer * mfail);

MTIstatus _MrgVersAdjMetaPreCre
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, SetOfObjects * creArgs, SetOfStrings * creOwners,
   SetOfStrings * creClasses, integer * mfail);

MTIstatus _MrgVersPostInsert
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItemList, SetOfObjects argList, integer * mfail);

MTIstatus _NoReplaceSubSetRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects replaceObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _NoReplaceSubSetToTm
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects replaceObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   ObjectPtr * ckiDialog, integer * mfail);

MTIstatus _PostReleasePrcRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PrcCkoMkvItmAftInsrtTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   SetOfObjects transferredObjs, ObjectPtr destination, ObjectPtr relatedObj,
   integer * mfail);

MTIstatus _PrcERORelForCkoRevTIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, ObjectPtr * newRelObj, integer * mfail);

MTIstatus _PrcInsItemForInsVerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr insertObj,
   ObjectPtr predObj, ObjectPtr succObj, integer * mfail);

MTIstatus _PrcPrdItmRlsForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredAndSuccForRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredItemForInsVerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr predObj,
   ObjectPtr insertObj, ObjectPtr succObj, integer * mfail);

MTIstatus _PrcPredItemRelsForRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcPredSuccForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _PrcRelForPostRlseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr item, integer * mfail);

MTIstatus _PrcSccItmRlsForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _PrcSuccForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _PrcSuccForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _PrcSuccItemForInsVerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr succObj,
   ObjectPtr insertObj, ObjectPtr predObj, integer * mfail);

MTIstatus _PrcSuccItemRelsForRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _ProcCheckOutItemRelsTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, boolean refresh, boolean isBase,
   integer * mfail);

MTIstatus _ProcERORelForCkoMkvTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, ObjectPtr * newRelObj, integer * mfail);

MTIstatus _ProcForTranAuthorityAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects attachedObjs, ObjectPtr argumentsObj, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProcRelForMergePre
   (MTIconstString _class, boolean getParent, MTIconstString className,
   boolean * isPartDoc, integer * mfail);

MTIstatus _ProcRelForMrgVerPre
   (MTIconstString _class, boolean getParent, MTIconstString className,
   boolean * isPartDoc, integer * mfail);

MTIstatus _ProcessCheckOutTSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, MTIconstString workLoc, MTIconstString folder,
   integer * mfail);

MTIstatus _ProcessCheckOutUSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, MTIconstString workLoc, integer * mfail);

MTIstatus _ProcessCinToTmSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ProcessCirToTmSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ProcessRelNoReplaceSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ProcessRelReplaceSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ProcessRelsForMerge
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects newObjsList, SetOfObjects argObjsList, SetOfObjects otherSideObjs,
   integer * mfail);

MTIstatus _ProcessRelsForMrgVers
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects newObjsList, SetOfObjects argObjsList, SetOfObjects otherSideObjs,
   SetOfObjects * uploadInfo, integer * mfail);

MTIstatus _ProcessRlsTransferSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects transferObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ProcessTransferTmSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects transferObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ProjectExists
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString projectName, boolean * exists, integer * mfail);

MTIstatus _PropagateMrgItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, SetOfStrings relExclHandles, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _PurgePredecessorsIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   SetOfObjects * failedItems, integer * mfail);

MTIstatus _RecreateNestBeforeDelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects childFolders, integer * mfail);

MTIstatus _RelItemForSetIntPre
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects * dialogs, SetOfObjects * eplctSlctAndReleased, SetOfObjects * eplctSlctButFailed,
   SetOfObjects * implctSlctAndReleased, SetOfObjects * implctSlctButFailed, boolean * isTransactional,
   integer * mfail);

MTIstatus _ReleaseIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ReleaseItemForSetInt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects dialogs, SetOfObjects * eplctSlctAndReleased, SetOfObjects * eplctSlctButFailed,
   SetOfObjects * implctSlctAndReleased, SetOfObjects * implctSlctButFailed, integer * mfail);

MTIstatus _ReleaseItemForSetPre
   (MTIconstString _class, boolean getParent, MTIconstString classname,
   SetOfObjects orgDialogs, SetOfObjects * eplctSlctButFailed, SetOfObjects * dialogs,
   integer * mfail);

MTIstatus _ReleaseItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString destOwnerName, MTIconstString releaseType, boolean include,
   integer * mfail);

MTIstatus _ReleaseItemPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workitemObj,
   ObjectPtr dialog, SetOfObjects * implctSlctAndReleased, SetOfObjects * implctSlctButFailed,
   integer * mfail);

MTIstatus _ReleaseItemPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workitemObj,
   ObjectPtr dialog, SetOfObjects * implctSlctAndReleased, SetOfObjects * implctSlctButFailed,
   integer * mfail);

MTIstatus _ReleaseNoReplaceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ReleaseNoReplaceObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString releaseType, MTIconstString destOwnerName, boolean includeAtt,
   integer * mfail);

MTIstatus _ReleaseOtherObjectsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ReleaseReplaceAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ReleaseReplaceObjectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString releaseType, boolean includeAtt, integer * mfail);

MTIstatus _ReleaseTransferIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString userAction, integer * mfail);

MTIstatus _RelseTransferObjectIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _RelseTransferSubSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects transferObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _RemoveFromNestAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   ObjectPtr removedFolder, integer * mfail);

MTIstatus _RemoveFromPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   ObjectPtr removedItem, integer * mfail);

MTIstatus _RemoveFromPreIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr folder,
   ObjectPtr removedItem, integer * mfail);

MTIstatus _RemoveObjFromCurTmFdrsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ReplaceSubSetRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects replaceObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ReplaceSubSetToTm
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects replaceObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   ObjectPtr * ckiDialog, integer * mfail);

MTIstatus _ReserveItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr rsvArgObject, integer * mfail);

MTIstatus _ReserveItemPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr rsvArgObject, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveItemPreIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr rsvArgObject, integer * mfail);

MTIstatus _ReserveVersionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr ckoObj,
   ObjectPtr argObj, ObjectPtr userFldr, boolean generateInfo,
   SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveVersionIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr ckoObj,
   ObjectPtr argObj, ObjectPtr userFldr, boolean generateInfo,
   SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveVersionPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr argObj, ObjectPtr userFolder, boolean generateInfo,
   SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveVersionPreIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr argObj, ObjectPtr userFolder, integer * mfail);

MTIstatus _ReserveVersions3
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItemObjs, ObjectPtr userFolder, integer * mfail);

MTIstatus _ReserveVersionsPostInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects argsList, ObjectPtr userFolder,
   boolean generateInfo, SetOfObjects * downloadInfo, integer * mfail);

MTIstatus _ReserveVersionsPreInt
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects workItems, SetOfObjects argsList, ObjectPtr userFolder,
   integer * mfail);

MTIstatus _SetCreDAttrsForMrgVerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr createDialog,
   ObjectPtr argObj, ObjectPtr pred, integer * mfail);

MTIstatus _SetFlagsForInsVersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   integer context, integer * mfail);

MTIstatus _SetForNonIntTmCkoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr dialogObj,
   MTIconstString workLoc, MTIconstString folder, integer * mfail);

MTIstatus _SetMergeArgFromPredAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mergeDialogs,
   integer * mfail);

MTIstatus _SetMergeArgsFromPreds
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects mergeDialogs, integer * mfail);

MTIstatus _SetParentFolderAttrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr subFolder,
   ObjectPtr parentFolder, integer * mfail);

MTIstatus _SetRsvFldrOnRelatedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   MTIconstString relClass, MTIconstString relationship, ObjectPtr teamFolder,
   integer * mfail);

MTIstatus _TransferAuthorityIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _TransferTmIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString userAction, ObjectPtr * trnDialog, integer * mfail);

MTIstatus _TransferTmObjectIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _TransferTmSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _TransferTmSubSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects transferObjects, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _UnSetParentFolderAttrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr subFolder,
   ObjectPtr parentFolder, integer * mfail);

MTIstatus _UpdateChildFolderAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relationObj,
   integer * mfail);

MTIstatus _UpdateMetaForCkoFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   ObjectPtr dest, integer * mfail);

MTIstatus _UpdateMetaForCkoMkvTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   ObjectPtr dest, integer * mfail);

MTIstatus _UpdateMetaForTCkoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   ObjectPtr dest, integer * mfail);

MTIstatus _UpdateTeamDefaults
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamName, ObjectPtr * teamDfltObj, integer * mfail);

MTIstatus _ValArgForMergePostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mrgDialog,
   integer * mfail);

MTIstatus _ValCheckOutItemRelsTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, boolean refresh, boolean isBase,
   integer * mfail);

MTIstatus _ValCkiToTmNoRplObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValCkoItemRelsFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, boolean refresh, boolean isBase,
   integer * mfail);

MTIstatus _ValDoCheckOutFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, integer * mfail);

MTIstatus _ValDoCkoItemFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   ObjectPtr * dest, integer * mfail);

MTIstatus _ValDoCkoMkvCreDestObjTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   ObjectPtr * dest, ObjectPtr * relatedObj, integer * mfail);

MTIstatus _ValDoCkoTMkvCreDestObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   MTIconstString oldName, ObjectPtr * dest, ObjectPtr * relatedObj,
   integer * mfail);

MTIstatus _ValDomainForCheckOutTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForCkoFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForMoveToFldrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValERORelForMrgVerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, integer * answer,
   integer * mfail);

MTIstatus _ValFldrAndTeamNameAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString frmfldrName, MTIconstString frmteamName, integer * mfail);

MTIstatus _ValForCheckInToTmDestAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean isBaseObj, SetOfStrings * extraStr,
   SetOfObjects * extraObj, ObjectPtr * destObj, integer * mfail);

MTIstatus _ValForCiiAttmntToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForCinAttmntToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForCirAttmntToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForCkoFromTmSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects checkOutObjects, integer * mfail);

MTIstatus _ValForMakeAvailNSecureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForMakeAvailSecureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForRelToRepliOdrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForReleaseAttmntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForReleaseToDestAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean isBaseObj, SetOfStrings * extraStr,
   SetOfObjects * extraObj, ObjectPtr * destObj, integer * mfail);

MTIstatus _ValForReserveVersionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _ValForRlsRAttmntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValItemClassInSet
   (MTIconstString _class, boolean getParent, MTIconstString classToMatch,
   SetOfObjects setToVerify, integer * mfail);

MTIstatus _ValItemDestForCkoMkvTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _ValItemForMergeVersIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr argObj,
   ObjectPtr pred, integer * mfail);

MTIstatus _ValItemRelsForMergeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mergeObj,
   ObjectPtr mergeArg, SetOfObjects relCreateDialogs, SetOfStrings relClassNames,
   SetOfStrings mergeObjRoles, SetOfObjects otherSideObjs, integer * mfail);

MTIstatus _ValItemRelsForMrgVersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr mergeObj,
   ObjectPtr mergeArg, SetOfObjects relCreateDialogs, SetOfStrings relClassNames,
   SetOfStrings mergeObjRoles, SetOfObjects otherSideObjs, integer * mfail);

MTIstatus _ValItmDestForCkoFromTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dest, ObjectPtr target, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _ValOwnerForReserveAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr ownerObj,
   ObjectPtr workItem, ObjectPtr rsvArgObject, integer * mfail);

MTIstatus _ValPrdItmRlsForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _ValPredForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _ValPredItemForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _ValPredItemRelsForRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr succ, boolean isBaseObj, integer * mfail);

MTIstatus _ValPredRForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, ObjectPtr succ, boolean isBaseObj,
   integer * mfail);

MTIstatus _ValSccItmRlsForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _ValSccPrdRlsForCirToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, boolean * hasAttacher, integer * mfail);

MTIstatus _ValSuccForCinToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _ValSuccForReleaseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _ValSuccItemRelsForRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr pred, boolean isBaseObj, integer * mfail);

MTIstatus _ValSuccPredRelsForRlsRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString action, integer actionCode, ObjectPtr pred,
   boolean isBaseObj, boolean * hasAttacher, integer * mfail);

MTIstatus _ValidateArgForReserveAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr rsvArgObject,
   integer * mfail);

MTIstatus _ValidateArgsForReserve
   (MTIconstString _class, boolean getParent, MTIconstString rsvArgsClass,
   SetOfObjects rsvArgObjects, integer * mfail);

MTIstatus _ValidateCkiRplObjToTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValidateDoCheckOutTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, MTIconstString oldName,
   integer * mfail);

MTIstatus _ValidateDoCheckOutTItmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr target, boolean refresh, boolean isBase,
   MTIconstString oldName, ObjectPtr * dest, integer * mfail);

MTIstatus _ValidateForCirToTeamAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForInsVersnSet
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects * insertObjs, SetOfObjects * predObjs, SetOfObjects * succObjs,
   integer * mfail);

MTIstatus _ValidateForMergeRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr relCreDialog, ObjectPtr leftObj, ObjectPtr rightObj,
   integer * mfail);

MTIstatus _ValidateForPurgeExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForReleaseExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForRenameFldrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForRsvItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr rsvArgObject, integer * mfail);

MTIstatus _ValidateItemClassAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString classToMatch, integer * mfail);

MTIstatus _ValidateItemOwnersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr item1,
   ObjectPtr item2, integer * mfail);

MTIstatus _ValidateMoreDelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmitem,
   boolean * dodelete, integer * mfail);

MTIstatus _ValidatePredsForMerge
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects argObjs, SetOfObjects * failedObjects, integer * mfail);

MTIstatus _ValidateRelForCkoMkvTmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, ObjectPtr dest, boolean refresh,
   boolean isBase, integer * mfail);

MTIstatus _ValidateReleaseRplObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValidateRelsForMrgVers
   (MTIconstString _class, boolean getParent, MTIconstString workItemClass,
   SetOfObjects mergedObjs, SetOfObjects argObjsList, SetOfObjects * otherSideObjs,
   integer * mfail);

MTIstatus _ValidateRelseNoRplObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValidateTeamRoleDelete
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString teamRoleName, integer * mfail);

MTIstatus _ValidateToTeamFldrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString tofldrName, MTIconstString frmteamName, ObjectPtr * toteamFldr,
   boolean * inFldr, integer * mfail);

MTIstatus _ValidateTranAuthorityAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateTrnResvOwnerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   MTIconstString newOwner, integer * mfail);
/*
 *  Protected Messages
 */
/*
 *  Message Macro Definitions.
 */

#define AddTo(folder, addedItemSet, latest, mfail) \
        _AddToAtClass(NULL, FALSE, folder, addedItemSet, latest, mfail)
#define AddToAtClass(class, folder, addedItemSet, latest, mfail) \
        _AddToAtClass(class, FALSE, folder, addedItemSet, latest, mfail)
#define AddToAtParent(class, folder, addedItemSet, latest, mfail) \
        _AddToAtClass(class, TRUE, folder, addedItemSet, latest, mfail)

#define AddToNest(folder, addedItemSet, mfail) \
        _AddToNestAtClass(NULL, FALSE, folder, addedItemSet, mfail)
#define AddToNestAtClass(class, folder, addedItemSet, mfail) \
        _AddToNestAtClass(class, FALSE, folder, addedItemSet, mfail)
#define AddToNestAtParent(class, folder, addedItemSet, mfail) \
        _AddToNestAtClass(class, TRUE, folder, addedItemSet, mfail)

#define AddToPostInt(folder, addedItemSet, latest, mfail) \
        _AddToPostIntAtClass(NULL, FALSE, folder, addedItemSet, latest, mfail)
#define AddToPostIntAtClass(class, folder, addedItemSet, latest, mfail) \
        _AddToPostIntAtClass(class, FALSE, folder, addedItemSet, latest, mfail)
#define AddToPostIntAtParent(class, folder, addedItemSet, latest, mfail) \
        _AddToPostIntAtClass(class, TRUE, folder, addedItemSet, latest, mfail)

#define AddToPreInt(folder, addedItemSet, latest, mfail) \
        _AddToPreIntAtClass(NULL, FALSE, folder, addedItemSet, latest, mfail)
#define AddToPreIntAtClass(class, folder, addedItemSet, latest, mfail) \
        _AddToPreIntAtClass(class, FALSE, folder, addedItemSet, latest, mfail)
#define AddToPreIntAtParent(class, folder, addedItemSet, latest, mfail) \
        _AddToPreIntAtClass(class, TRUE, folder, addedItemSet, latest, mfail)

#define AddUsrToTeamRoleUsrGrp(className, usrName, teamRole, usgObj, mfail) \
        _AddUsrToTeamRoleUsrGrp(className, FALSE, className, usrName, teamRole, usgObj, mfail)
#define AddUsrToTeamRoleUsrGrpAtParent(_class, className, usrName, teamRole, usgObj, mfail) \
        _AddUsrToTeamRoleUsrGrp(_class, TRUE, className, usrName, teamRole, usgObj, mfail)

#define AllowCkoFromTeam(className, answer, mfail) \
        _AllowCkoFromTeam(className, FALSE, className, answer, mfail)
#define AllowCkoFromTeamAtParent(_class, className, answer, mfail) \
        _AllowCkoFromTeam(_class, TRUE, className, answer, mfail)

#define AssignRoleToMbr(thisObj, mfail) \
        _AssignRoleToMbrAtClass(NULL, FALSE, thisObj, mfail)
#define AssignRoleToMbrAtClass(class, thisObj, mfail) \
        _AssignRoleToMbrAtClass(class, FALSE, thisObj, mfail)
#define AssignRoleToMbrAtParent(class, thisObj, mfail) \
        _AssignRoleToMbrAtClass(class, TRUE, thisObj, mfail)

#define AssignRoleToMbrObject(thisObj, teamName, teamRoleName, traObj, mfail) \
        _AssignRoleToMbrObjectAtClass(NULL, FALSE, thisObj, teamName, teamRoleName, traObj, mfail)
#define AssignRoleToMbrObjectAtClass(class, thisObj, teamName, teamRoleName, traObj, mfail) \
        _AssignRoleToMbrObjectAtClass(class, FALSE, thisObj, teamName, teamRoleName, traObj, mfail)
#define AssignRoleToMbrObjectAtParent(class, thisObj, teamName, teamRoleName, traObj, mfail) \
        _AssignRoleToMbrObjectAtClass(class, TRUE, thisObj, teamName, teamRoleName, traObj, mfail)

#define AssignTeamRole(className, usrName, teamName, teamRoleName, traObj, mfail) \
        _AssignTeamRole(className, FALSE, className, usrName, teamName, teamRoleName, traObj, mfail)
#define AssignTeamRoleAtParent(_class, className, usrName, teamName, teamRoleName, traObj, mfail) \
        _AssignTeamRole(_class, TRUE, className, usrName, teamName, teamRoleName, traObj, mfail)

#define AssignTeamRoleForUst(className, usrName, teamName, teamRoleName, traObj, mfail) \
        _AssignTeamRoleForUst(className, FALSE, className, usrName, teamName, teamRoleName, traObj, mfail)
#define AssignTeamRoleForUstAtParent(_class, className, usrName, teamName, teamRoleName, traObj, mfail) \
        _AssignTeamRoleForUst(_class, TRUE, className, usrName, teamName, teamRoleName, traObj, mfail)

#define CancelReserveItem(workItem, mfail) \
        _CancelReserveItemAtClass(NULL, FALSE, workItem, mfail)
#define CancelReserveItemAtClass(class, workItem, mfail) \
        _CancelReserveItemAtClass(class, FALSE, workItem, mfail)
#define CancelReserveItemAtParent(class, workItem, mfail) \
        _CancelReserveItemAtClass(class, TRUE, workItem, mfail)

#define CancelReserveItemPost(workItem, mfail) \
        _CancelReserveItemPostAtClass(NULL, FALSE, workItem, mfail)
#define CancelReserveItemPostAtClass(class, workItem, mfail) \
        _CancelReserveItemPostAtClass(class, FALSE, workItem, mfail)
#define CancelReserveItemPostAtParent(class, workItem, mfail) \
        _CancelReserveItemPostAtClass(class, TRUE, workItem, mfail)

#define CancelReserveItemPre(workItem, mfail) \
        _CancelReserveItemPreAtClass(NULL, FALSE, workItem, mfail)
#define CancelReserveItemPreAtClass(class, workItem, mfail) \
        _CancelReserveItemPreAtClass(class, FALSE, workItem, mfail)
#define CancelReserveItemPreAtParent(class, workItem, mfail) \
        _CancelReserveItemPreAtClass(class, TRUE, workItem, mfail)

#define CancelReserveSet(workItemClass, workItems, mfail) \
        _CancelReserveSet(workItemClass, FALSE, workItemClass, workItems, mfail)
#define CancelReserveSetAtParent(_class, workItemClass, workItems, mfail) \
        _CancelReserveSet(_class, TRUE, workItemClass, workItems, mfail)

#define CancelReserveSet2(workItemClass, workItemHandles, mfail) \
        _CancelReserveSet2(workItemClass, FALSE, workItemClass, workItemHandles, mfail)
#define CancelReserveSet2AtParent(_class, workItemClass, workItemHandles, mfail) \
        _CancelReserveSet2(_class, TRUE, workItemClass, workItemHandles, mfail)

#define CancelReserveSetInt(workItemClass, workItems, mfail) \
        _CancelReserveSetInt(workItemClass, FALSE, workItemClass, workItems, mfail)
#define CancelReserveSetIntAtParent(_class, workItemClass, workItems, mfail) \
        _CancelReserveSetInt(_class, TRUE, workItemClass, workItems, mfail)

#define CheckForCpyDuplicatesT(thisObj, dialogObj, newObj, badArgs, mfail) \
        _CheckForCpyDuplicatesTAtClass(NULL, FALSE, thisObj, dialogObj, newObj, badArgs, mfail)
#define CheckForCpyDuplicatesTAtClass(class, thisObj, dialogObj, newObj, badArgs, mfail) \
        _CheckForCpyDuplicatesTAtClass(class, FALSE, thisObj, dialogObj, newObj, badArgs, mfail)
#define CheckForCpyDuplicatesTAtParent(class, thisObj, dialogObj, newObj, badArgs, mfail) \
        _CheckForCpyDuplicatesTAtClass(class, TRUE, thisObj, dialogObj, newObj, badArgs, mfail)

#define CheckForCpyDupsFromTm(thisObj, dialogObj, newObj, badArgs, mfail) \
        _CheckForCpyDupsFromTmAtClass(NULL, FALSE, thisObj, dialogObj, newObj, badArgs, mfail)
#define CheckForCpyDupsFromTmAtClass(class, thisObj, dialogObj, newObj, badArgs, mfail) \
        _CheckForCpyDupsFromTmAtClass(class, FALSE, thisObj, dialogObj, newObj, badArgs, mfail)
#define CheckForCpyDupsFromTmAtParent(class, thisObj, dialogObj, newObj, badArgs, mfail) \
        _CheckForCpyDupsFromTmAtClass(class, TRUE, thisObj, dialogObj, newObj, badArgs, mfail)

#define CheckInToTeam(thisObj, mfail) \
        _CheckInToTeamAtClass(NULL, FALSE, thisObj, mfail)
#define CheckInToTeamAtClass(class, thisObj, mfail) \
        _CheckInToTeamAtClass(class, FALSE, thisObj, mfail)
#define CheckInToTeamAtParent(class, thisObj, mfail) \
        _CheckInToTeamAtClass(class, TRUE, thisObj, mfail)

#define CheckInToTeamInt(thisObj, mfail) \
        _CheckInToTeamIntAtClass(NULL, FALSE, thisObj, mfail)
#define CheckInToTeamIntAtClass(class, thisObj, mfail) \
        _CheckInToTeamIntAtClass(class, FALSE, thisObj, mfail)
#define CheckInToTeamIntAtParent(class, thisObj, mfail) \
        _CheckInToTeamIntAtClass(class, TRUE, thisObj, mfail)

#define CheckInToTeamObject(thisObj, argumentsObj, mfail) \
        _CheckInToTeamObjectAtClass(NULL, FALSE, thisObj, argumentsObj, mfail)
#define CheckInToTeamObjectAtClass(class, thisObj, argumentsObj, mfail) \
        _CheckInToTeamObjectAtClass(class, FALSE, thisObj, argumentsObj, mfail)
#define CheckInToTeamObjectAtParent(class, thisObj, argumentsObj, mfail) \
        _CheckInToTeamObjectAtClass(class, TRUE, thisObj, argumentsObj, mfail)

#define CheckInToTmOtherObjs(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckInToTmOtherObjsAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define CheckInToTmOtherObjsAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckInToTmOtherObjsAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define CheckInToTmOtherObjsAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckInToTmOtherObjsAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define CheckInToTmUmgInt(thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUmgIntAtClass(NULL, FALSE, thisObj, argumentsObj, TransferInfoObjects, mfail)
#define CheckInToTmUmgIntAtClass(class, thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUmgIntAtClass(class, FALSE, thisObj, argumentsObj, TransferInfoObjects, mfail)
#define CheckInToTmUmgIntAtParent(class, thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUmgIntAtClass(class, TRUE, thisObj, argumentsObj, TransferInfoObjects, mfail)

#define CheckInToTmUnmg(thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgAtClass(NULL, FALSE, thisObj, argumentsObj, TransferInfoObjects, mfail)
#define CheckInToTmUnmgAtClass(class, thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgAtClass(class, FALSE, thisObj, argumentsObj, TransferInfoObjects, mfail)
#define CheckInToTmUnmgAtParent(class, thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgAtClass(class, TRUE, thisObj, argumentsObj, TransferInfoObjects, mfail)

#define CheckInToTmUnmgAux(thisObj, argumentsObj, transferInfoObjs, mfail) \
        _CheckInToTmUnmgAuxAtClass(NULL, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define CheckInToTmUnmgAuxAtClass(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _CheckInToTmUnmgAuxAtClass(class, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define CheckInToTmUnmgAuxAtParent(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _CheckInToTmUnmgAuxAtClass(class, TRUE, thisObj, argumentsObj, transferInfoObjs, mfail)

#define CheckInToTmUnmgInt(thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgIntAtClass(NULL, FALSE, thisObj, argumentsObj, TransferInfoObjects, mfail)
#define CheckInToTmUnmgIntAtClass(class, thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgIntAtClass(class, FALSE, thisObj, argumentsObj, TransferInfoObjects, mfail)
#define CheckInToTmUnmgIntAtParent(class, thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgIntAtClass(class, TRUE, thisObj, argumentsObj, TransferInfoObjects, mfail)

#define CheckInToTmUnmgSet(className, inputObjects, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgSet(className, FALSE, className, inputObjects, argumentsObj, TransferInfoObjects, mfail)
#define CheckInToTmUnmgSetAtParent(_class, className, inputObjects, argumentsObj, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgSet(_class, TRUE, className, inputObjects, argumentsObj, TransferInfoObjects, mfail)

#define CheckInToTmUnmgSet2(className, inputObjects, argumentsObjSet, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgSet2(className, FALSE, className, inputObjects, argumentsObjSet, TransferInfoObjects, mfail)
#define CheckInToTmUnmgSet2AtParent(_class, className, inputObjects, argumentsObjSet, TransferInfoObjects, mfail) \
        _CheckInToTmUnmgSet2(_class, TRUE, className, inputObjects, argumentsObjSet, TransferInfoObjects, mfail)

#define CheckOutFromTeam(thisObj, mfail) \
        _CheckOutFromTeamAtClass(NULL, FALSE, thisObj, mfail)
#define CheckOutFromTeamAtClass(class, thisObj, mfail) \
        _CheckOutFromTeamAtClass(class, FALSE, thisObj, mfail)
#define CheckOutFromTeamAtParent(class, thisObj, mfail) \
        _CheckOutFromTeamAtClass(class, TRUE, thisObj, mfail)

#define CheckOutFromTeamInt(thisObj, mfail) \
        _CheckOutFromTeamIntAtClass(NULL, FALSE, thisObj, mfail)
#define CheckOutFromTeamIntAtClass(class, thisObj, mfail) \
        _CheckOutFromTeamIntAtClass(class, FALSE, thisObj, mfail)
#define CheckOutFromTeamIntAtParent(class, thisObj, mfail) \
        _CheckOutFromTeamIntAtClass(class, TRUE, thisObj, mfail)

#define CheckOutFromTeamObject(thisObj, argumentsObj, ckoObj, mfail) \
        _CheckOutFromTeamObjectAtClass(NULL, FALSE, thisObj, argumentsObj, ckoObj, mfail)
#define CheckOutFromTeamObjectAtClass(class, thisObj, argumentsObj, ckoObj, mfail) \
        _CheckOutFromTeamObjectAtClass(class, FALSE, thisObj, argumentsObj, ckoObj, mfail)
#define CheckOutFromTeamObjectAtParent(class, thisObj, argumentsObj, ckoObj, mfail) \
        _CheckOutFromTeamObjectAtClass(class, TRUE, thisObj, argumentsObj, ckoObj, mfail)

#define CheckOutFromTmSet(className, SelectedItems, mfail) \
        _CheckOutFromTmSet(className, FALSE, className, SelectedItems, mfail)
#define CheckOutFromTmSetAtParent(_class, className, SelectedItems, mfail) \
        _CheckOutFromTmSet(_class, TRUE, className, SelectedItems, mfail)

#define CheckOutFromTmUnmg(checkOutItem, argumentsObj, pathFormat, transferObjects, mfail) \
        _CheckOutFromTmUnmgAtClass(NULL, FALSE, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail)
#define CheckOutFromTmUnmgAtClass(class, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail) \
        _CheckOutFromTmUnmgAtClass(class, FALSE, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail)
#define CheckOutFromTmUnmgAtParent(class, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail) \
        _CheckOutFromTmUnmgAtClass(class, TRUE, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail)

#define CheckOutFromTmUnmg2(workItem, argumentsObj, pathFormat, transferObjects, newWorkItem, dataItems, mfail) \
        _CheckOutFromTmUnmg2AtClass(NULL, FALSE, workItem, argumentsObj, pathFormat, transferObjects, newWorkItem, dataItems, mfail)
#define CheckOutFromTmUnmg2AtClass(class, workItem, argumentsObj, pathFormat, transferObjects, newWorkItem, dataItems, mfail) \
        _CheckOutFromTmUnmg2AtClass(class, FALSE, workItem, argumentsObj, pathFormat, transferObjects, newWorkItem, dataItems, mfail)
#define CheckOutFromTmUnmg2AtParent(class, workItem, argumentsObj, pathFormat, transferObjects, newWorkItem, dataItems, mfail) \
        _CheckOutFromTmUnmg2AtClass(class, TRUE, workItem, argumentsObj, pathFormat, transferObjects, newWorkItem, dataItems, mfail)

#define CheckOutFromTmUnmgInt(checkOutItem, argumentsObj, pathFormat, transferObjects, mfail) \
        _CheckOutFromTmUnmgIntAtClass(NULL, FALSE, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail)
#define CheckOutFromTmUnmgIntAtClass(class, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail) \
        _CheckOutFromTmUnmgIntAtClass(class, FALSE, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail)
#define CheckOutFromTmUnmgIntAtParent(class, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail) \
        _CheckOutFromTmUnmgIntAtClass(class, TRUE, checkOutItem, argumentsObj, pathFormat, transferObjects, mfail)

#define CheckOutObjFromTmInt(thisObj, dialogObj, ckoObj, mfail) \
        _CheckOutObjFromTmIntAtClass(NULL, FALSE, thisObj, dialogObj, ckoObj, mfail)
#define CheckOutObjFromTmIntAtClass(class, thisObj, dialogObj, ckoObj, mfail) \
        _CheckOutObjFromTmIntAtClass(class, FALSE, thisObj, dialogObj, ckoObj, mfail)
#define CheckOutObjFromTmIntAtParent(class, thisObj, dialogObj, ckoObj, mfail) \
        _CheckOutObjFromTmIntAtClass(class, TRUE, thisObj, dialogObj, ckoObj, mfail)

#define CheckOutTAttmnts(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckOutTAttmntsAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define CheckOutTAttmntsAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckOutTAttmntsAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define CheckOutTAttmntsAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckOutTAttmntsAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define CheckOutTSubSet(className, checkOutObjects, workLoc, folder, mfail) \
        _CheckOutTSubSet(className, FALSE, className, checkOutObjects, workLoc, folder, mfail)
#define CheckOutTSubSetAtParent(_class, className, checkOutObjects, workLoc, folder, mfail) \
        _CheckOutTSubSet(_class, TRUE, className, checkOutObjects, workLoc, folder, mfail)

#define CheckOutToTeamDP(thisObj, mfail) \
        _CheckOutToTeamDPAtClass(NULL, FALSE, thisObj, mfail)
#define CheckOutToTeamDPAtClass(class, thisObj, mfail) \
        _CheckOutToTeamDPAtClass(class, FALSE, thisObj, mfail)
#define CheckOutToTeamDPAtParent(class, thisObj, mfail) \
        _CheckOutToTeamDPAtClass(class, TRUE, thisObj, mfail)

#define CheckOutToTeamInt(thisObj, mfail) \
        _CheckOutToTeamIntAtClass(NULL, FALSE, thisObj, mfail)
#define CheckOutToTeamIntAtClass(class, thisObj, mfail) \
        _CheckOutToTeamIntAtClass(class, FALSE, thisObj, mfail)
#define CheckOutToTeamIntAtParent(class, thisObj, mfail) \
        _CheckOutToTeamIntAtClass(class, TRUE, thisObj, mfail)

#define CheckOutToTeamItem(workItem, teamName, teamLoc, includeAtt, ckoType, newWorkItem, dataItems, mfail) \
        _CheckOutToTeamItemAtClass(NULL, FALSE, workItem, teamName, teamLoc, includeAtt, ckoType, newWorkItem, dataItems, mfail)
#define CheckOutToTeamItemAtClass(class, workItem, teamName, teamLoc, includeAtt, ckoType, newWorkItem, dataItems, mfail) \
        _CheckOutToTeamItemAtClass(class, FALSE, workItem, teamName, teamLoc, includeAtt, ckoType, newWorkItem, dataItems, mfail)
#define CheckOutToTeamItemAtParent(class, workItem, teamName, teamLoc, includeAtt, ckoType, newWorkItem, dataItems, mfail) \
        _CheckOutToTeamItemAtClass(class, TRUE, workItem, teamName, teamLoc, includeAtt, ckoType, newWorkItem, dataItems, mfail)

#define CheckOutToTeamItem2(workItem, argumentsObj, newWorkItem, dataItems, mfail) \
        _CheckOutToTeamItem2AtClass(NULL, FALSE, workItem, argumentsObj, newWorkItem, dataItems, mfail)
#define CheckOutToTeamItem2AtClass(class, workItem, argumentsObj, newWorkItem, dataItems, mfail) \
        _CheckOutToTeamItem2AtClass(class, FALSE, workItem, argumentsObj, newWorkItem, dataItems, mfail)
#define CheckOutToTeamItem2AtParent(class, workItem, argumentsObj, newWorkItem, dataItems, mfail) \
        _CheckOutToTeamItem2AtClass(class, TRUE, workItem, argumentsObj, newWorkItem, dataItems, mfail)

#define CheckOutToTmItmSet(className, workItems, teamName, teamLoc, includeAtt, newWorkItems, trnObjIndex, transferObjects, mfail) \
        _CheckOutToTmItmSet(className, FALSE, className, workItems, teamName, teamLoc, includeAtt, newWorkItems, trnObjIndex, transferObjects, mfail)
#define CheckOutToTmItmSetAtParent(_class, className, workItems, teamName, teamLoc, includeAtt, newWorkItems, trnObjIndex, transferObjects, mfail) \
        _CheckOutToTmItmSet(_class, TRUE, className, workItems, teamName, teamLoc, includeAtt, newWorkItems, trnObjIndex, transferObjects, mfail)

#define CheckOutToTmObjectInt(thisObj, dialogObj, mfail) \
        _CheckOutToTmObjectIntAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define CheckOutToTmObjectIntAtClass(class, thisObj, dialogObj, mfail) \
        _CheckOutToTmObjectIntAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define CheckOutToTmObjectIntAtParent(class, thisObj, dialogObj, mfail) \
        _CheckOutToTmObjectIntAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define CheckOutUAttmnts(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckOutUAttmntsAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define CheckOutUAttmntsAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckOutUAttmntsAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define CheckOutUAttmntsAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _CheckOutUAttmntsAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define CheckOutUSubSet(className, checkOutObjects, workLoc, mfail) \
        _CheckOutUSubSet(className, FALSE, className, checkOutObjects, workLoc, mfail)
#define CheckOutUSubSetAtParent(_class, className, checkOutObjects, workLoc, mfail) \
        _CheckOutUSubSet(_class, TRUE, className, checkOutObjects, workLoc, mfail)

#define CheckTmRlAssnObject(className, userName, teamProjName, teamRoleName, indirectTeam, exists, mfail) \
        _CheckTmRlAssnObject(className, FALSE, className, userName, teamProjName, teamRoleName, indirectTeam, exists, mfail)
#define CheckTmRlAssnObjectAtParent(_class, className, userName, teamProjName, teamRoleName, indirectTeam, exists, mfail) \
        _CheckTmRlAssnObject(_class, TRUE, className, userName, teamProjName, teamRoleName, indirectTeam, exists, mfail)

#define CkiToTeamNoReplace(thisObj, ckiDialog, mfail) \
        _CkiToTeamNoReplaceAtClass(NULL, FALSE, thisObj, ckiDialog, mfail)
#define CkiToTeamNoReplaceAtClass(class, thisObj, ckiDialog, mfail) \
        _CkiToTeamNoReplaceAtClass(class, FALSE, thisObj, ckiDialog, mfail)
#define CkiToTeamNoReplaceAtParent(class, thisObj, ckiDialog, mfail) \
        _CkiToTeamNoReplaceAtClass(class, TRUE, thisObj, ckiDialog, mfail)

#define CkiToTeamReplace(thisObj, ckiDialog, mfail) \
        _CkiToTeamReplaceAtClass(NULL, FALSE, thisObj, ckiDialog, mfail)
#define CkiToTeamReplaceAtClass(class, thisObj, ckiDialog, mfail) \
        _CkiToTeamReplaceAtClass(class, FALSE, thisObj, ckiDialog, mfail)
#define CkiToTeamReplaceAtParent(class, thisObj, ckiDialog, mfail) \
        _CkiToTeamReplaceAtClass(class, TRUE, thisObj, ckiDialog, mfail)

#define CkiToTmNoReplaceObject(thisObj, argumentsObj, mfail) \
        _CkiToTmNoReplaceObjectAtClass(NULL, FALSE, thisObj, argumentsObj, mfail)
#define CkiToTmNoReplaceObjectAtClass(class, thisObj, argumentsObj, mfail) \
        _CkiToTmNoReplaceObjectAtClass(class, FALSE, thisObj, argumentsObj, mfail)
#define CkiToTmNoReplaceObjectAtParent(class, thisObj, argumentsObj, mfail) \
        _CkiToTmNoReplaceObjectAtClass(class, TRUE, thisObj, argumentsObj, mfail)

#define CkiToTmReplaceObject(thisObj, argumentsObj, mfail) \
        _CkiToTmReplaceObjectAtClass(NULL, FALSE, thisObj, argumentsObj, mfail)
#define CkiToTmReplaceObjectAtClass(class, thisObj, argumentsObj, mfail) \
        _CkiToTmReplaceObjectAtClass(class, FALSE, thisObj, argumentsObj, mfail)
#define CkiToTmReplaceObjectAtParent(class, thisObj, argumentsObj, mfail) \
        _CkiToTmReplaceObjectAtClass(class, TRUE, thisObj, argumentsObj, mfail)

#define CleanBrowsrItmCkoMkvTm(thisObj, mfail) \
        _CleanBrowsrItmCkoMkvTmAtClass(NULL, FALSE, thisObj, mfail)
#define CleanBrowsrItmCkoMkvTmAtClass(class, thisObj, mfail) \
        _CleanBrowsrItmCkoMkvTmAtClass(class, FALSE, thisObj, mfail)
#define CleanBrowsrItmCkoMkvTmAtParent(class, thisObj, mfail) \
        _CleanBrowsrItmCkoMkvTmAtClass(class, TRUE, thisObj, mfail)

#define ConvertTeamCkoToCpy(ckoObj, workItem, cpyObj, mfail) \
        _ConvertTeamCkoToCpyAtClass(NULL, FALSE, ckoObj, workItem, cpyObj, mfail)
#define ConvertTeamCkoToCpyAtClass(class, ckoObj, workItem, cpyObj, mfail) \
        _ConvertTeamCkoToCpyAtClass(class, FALSE, ckoObj, workItem, cpyObj, mfail)
#define ConvertTeamCkoToCpyAtParent(class, ckoObj, workItem, cpyObj, mfail) \
        _ConvertTeamCkoToCpyAtClass(class, TRUE, ckoObj, workItem, cpyObj, mfail)

#define CopyPpkCompT(thisObj, newObj, mfail) \
        _CopyPpkCompTAtClass(NULL, FALSE, thisObj, newObj, mfail)
#define CopyPpkCompTAtClass(class, thisObj, newObj, mfail) \
        _CopyPpkCompTAtClass(class, FALSE, thisObj, newObj, mfail)
#define CopyPpkCompTAtParent(class, thisObj, newObj, mfail) \
        _CopyPpkCompTAtClass(class, TRUE, thisObj, newObj, mfail)

#define CreDirSelRuForTeamLoc(thisObj, mfail) \
        _CreDirSelRuForTeamLocAtClass(NULL, FALSE, thisObj, mfail)
#define CreDirSelRuForTeamLocAtClass(class, thisObj, mfail) \
        _CreDirSelRuForTeamLocAtClass(class, FALSE, thisObj, mfail)
#define CreDirSelRuForTeamLocAtParent(class, thisObj, mfail) \
        _CreDirSelRuForTeamLocAtClass(class, TRUE, thisObj, mfail)

#define CreateAndInsVer(className, creArg, teamfldr, owner, predObj, succObj, newObj, mfail) \
        _CreateAndInsVer(className, FALSE, className, creArg, teamfldr, owner, predObj, succObj, newObj, mfail)
#define CreateAndInsVerAtParent(_class, className, creArg, teamfldr, owner, predObj, succObj, newObj, mfail) \
        _CreateAndInsVer(_class, TRUE, className, creArg, teamfldr, owner, predObj, succObj, newObj, mfail)

#define CreateCopiedCompMetaT(thisObj, newObj, mfail) \
        _CreateCopiedCompMetaTAtClass(NULL, FALSE, thisObj, newObj, mfail)
#define CreateCopiedCompMetaTAtClass(class, thisObj, newObj, mfail) \
        _CreateCopiedCompMetaTAtClass(class, FALSE, thisObj, newObj, mfail)
#define CreateCopiedCompMetaTAtParent(class, thisObj, newObj, mfail) \
        _CreateCopiedCompMetaTAtClass(class, TRUE, thisObj, newObj, mfail)

#define CreateCopiedCompMetaTm(thisObj, newObj, mfail) \
        _CreateCopiedCompMetaTmAtClass(NULL, FALSE, thisObj, newObj, mfail)
#define CreateCopiedCompMetaTmAtClass(class, thisObj, newObj, mfail) \
        _CreateCopiedCompMetaTmAtClass(class, FALSE, thisObj, newObj, mfail)
#define CreateCopiedCompMetaTmAtParent(class, thisObj, newObj, mfail) \
        _CreateCopiedCompMetaTmAtClass(class, TRUE, thisObj, newObj, mfail)

#define CreateCopiedFromTmItem(thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail) \
        _CreateCopiedFromTmItemAtClass(NULL, FALSE, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail)
#define CreateCopiedFromTmItemAtClass(class, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail) \
        _CreateCopiedFromTmItemAtClass(class, FALSE, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail)
#define CreateCopiedFromTmItemAtParent(class, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail) \
        _CreateCopiedFromTmItemAtClass(class, TRUE, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail)

#define CreateCopiedFromTmMeta(thisObj, dialogObj, newObj, mfail) \
        _CreateCopiedFromTmMetaAtClass(NULL, FALSE, thisObj, dialogObj, newObj, mfail)
#define CreateCopiedFromTmMetaAtClass(class, thisObj, dialogObj, newObj, mfail) \
        _CreateCopiedFromTmMetaAtClass(class, FALSE, thisObj, dialogObj, newObj, mfail)
#define CreateCopiedFromTmMetaAtParent(class, thisObj, dialogObj, newObj, mfail) \
        _CreateCopiedFromTmMetaAtClass(class, TRUE, thisObj, dialogObj, newObj, mfail)

#define CreateCopiedItemT(thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail) \
        _CreateCopiedItemTAtClass(NULL, FALSE, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail)
#define CreateCopiedItemTAtClass(class, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail) \
        _CreateCopiedItemTAtClass(class, FALSE, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail)
#define CreateCopiedItemTAtParent(class, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail) \
        _CreateCopiedItemTAtClass(class, TRUE, thisObj, dialogObj, updateWindow, copiedObjs, newObj, copiedObj, mfail)

#define CreateCopiedMetaT(thisObj, dialogObj, newObj, mfail) \
        _CreateCopiedMetaTAtClass(NULL, FALSE, thisObj, dialogObj, newObj, mfail)
#define CreateCopiedMetaTAtClass(class, thisObj, dialogObj, newObj, mfail) \
        _CreateCopiedMetaTAtClass(class, FALSE, thisObj, dialogObj, newObj, mfail)
#define CreateCopiedMetaTAtParent(class, thisObj, dialogObj, newObj, mfail) \
        _CreateCopiedMetaTAtClass(class, TRUE, thisObj, dialogObj, newObj, mfail)

#define CreateGnTmToTmRel(className, accTeamObj, shrTeamObj, useSameUsrRoleOpt, dfltTeamRole, gttObj, mfail) \
        _CreateGnTmToTmRel(className, FALSE, className, accTeamObj, shrTeamObj, useSameUsrRoleOpt, dfltTeamRole, gttObj, mfail)
#define CreateGnTmToTmRelAtParent(_class, className, accTeamObj, shrTeamObj, useSameUsrRoleOpt, dfltTeamRole, gttObj, mfail) \
        _CreateGnTmToTmRel(_class, TRUE, className, accTeamObj, shrTeamObj, useSameUsrRoleOpt, dfltTeamRole, gttObj, mfail)

#define CreateIndirectTra(gttObj, usrName, teamName, teamRoleName, mfail) \
        _CreateIndirectTraAtClass(NULL, FALSE, gttObj, usrName, teamName, teamRoleName, mfail)
#define CreateIndirectTraAtClass(class, gttObj, usrName, teamName, teamRoleName, mfail) \
        _CreateIndirectTraAtClass(class, FALSE, gttObj, usrName, teamName, teamRoleName, mfail)
#define CreateIndirectTraAtParent(class, gttObj, usrName, teamName, teamRoleName, mfail) \
        _CreateIndirectTraAtClass(class, TRUE, gttObj, usrName, teamName, teamRoleName, mfail)

#define CreateMergeArgPost(mrgDailog, mfail) \
        _CreateMergeArgPostAtClass(NULL, FALSE, mrgDailog, mfail)
#define CreateMergeArgPostAtClass(class, mrgDailog, mfail) \
        _CreateMergeArgPostAtClass(class, FALSE, mrgDailog, mfail)
#define CreateMergeArgPostAtParent(class, mrgDailog, mfail) \
        _CreateMergeArgPostAtClass(class, TRUE, mrgDailog, mfail)

#define CreateMergeArgPostInt(mrgDialog, mfail) \
        _CreateMergeArgPostIntAtClass(NULL, FALSE, mrgDialog, mfail)
#define CreateMergeArgPostIntAtClass(class, mrgDialog, mfail) \
        _CreateMergeArgPostIntAtClass(class, FALSE, mrgDialog, mfail)
#define CreateMergeArgPostIntAtParent(class, mrgDialog, mfail) \
        _CreateMergeArgPostIntAtClass(class, TRUE, mrgDialog, mfail)

#define CreateMergeArgs(workItemClass, mrgClassHndls, mrgDialogs, mfail) \
        _CreateMergeArgs(workItemClass, FALSE, workItemClass, mrgClassHndls, mrgDialogs, mfail)
#define CreateMergeArgsAtParent(_class, workItemClass, mrgClassHndls, mrgDialogs, mfail) \
        _CreateMergeArgs(_class, TRUE, workItemClass, mrgClassHndls, mrgDialogs, mfail)

#define CreateMergeArgsInt(workItemClass, mrgClassHndls, mrgDialogs, mfail) \
        _CreateMergeArgsInt(workItemClass, FALSE, workItemClass, mrgClassHndls, mrgDialogs, mfail)
#define CreateMergeArgsIntAtParent(_class, workItemClass, mrgClassHndls, mrgDialogs, mfail) \
        _CreateMergeArgsInt(_class, TRUE, workItemClass, mrgClassHndls, mrgDialogs, mfail)

#define CreateMergeArgsPost(workItemClass, mrgDialogs, mfail) \
        _CreateMergeArgsPost(workItemClass, FALSE, workItemClass, mrgDialogs, mfail)
#define CreateMergeArgsPostAtParent(_class, workItemClass, mrgDialogs, mfail) \
        _CreateMergeArgsPost(_class, TRUE, workItemClass, mrgDialogs, mfail)

#define CreateReserveArgs(workItemClass, argsClassStrs, rsvArgObjects, mfail) \
        _CreateReserveArgs(workItemClass, FALSE, workItemClass, argsClassStrs, rsvArgObjects, mfail)
#define CreateReserveArgsAtParent(_class, workItemClass, argsClassStrs, rsvArgObjects, mfail) \
        _CreateReserveArgs(_class, TRUE, workItemClass, argsClassStrs, rsvArgObjects, mfail)

#define CreateReserveArgsInt(workItemClass, argsClassStrs, rsvArgObjects, mfail) \
        _CreateReserveArgsInt(workItemClass, FALSE, workItemClass, argsClassStrs, rsvArgObjects, mfail)
#define CreateReserveArgsIntAtParent(_class, workItemClass, argsClassStrs, rsvArgObjects, mfail) \
        _CreateReserveArgsInt(_class, TRUE, workItemClass, argsClassStrs, rsvArgObjects, mfail)

#define CreateReserveArgsPost(workItemClass, argsClassStrs, rsvArgObjects, mfail) \
        _CreateReserveArgsPost(workItemClass, FALSE, workItemClass, argsClassStrs, rsvArgObjects, mfail)
#define CreateReserveArgsPostAtParent(_class, workItemClass, argsClassStrs, rsvArgObjects, mfail) \
        _CreateReserveArgsPost(_class, TRUE, workItemClass, argsClassStrs, rsvArgObjects, mfail)

#define CreateReserveVersArgs(workItemClass, argsClassStrs, argsObjects, mfail) \
        _CreateReserveVersArgs(workItemClass, FALSE, workItemClass, argsClassStrs, argsObjects, mfail)
#define CreateReserveVersArgsAtParent(_class, workItemClass, argsClassStrs, argsObjects, mfail) \
        _CreateReserveVersArgs(_class, TRUE, workItemClass, argsClassStrs, argsObjects, mfail)

#define CreateTeamDefaults(className, teamName, teamRoleName, teamShrTmRoleName, teamDfltObj, mfail) \
        _CreateTeamDefaults(className, FALSE, className, teamName, teamRoleName, teamShrTmRoleName, teamDfltObj, mfail)
#define CreateTeamDefaultsAtParent(_class, className, teamName, teamRoleName, teamShrTmRoleName, teamDfltObj, mfail) \
        _CreateTeamDefaults(_class, TRUE, className, teamName, teamRoleName, teamShrTmRoleName, teamDfltObj, mfail)

#define CreateTeamProject(className, teamName, teamProjectName, projObj, mfail) \
        _CreateTeamProject(className, FALSE, className, teamName, teamProjectName, projObj, mfail)
#define CreateTeamProjectAtParent(_class, className, teamName, teamProjectName, projObj, mfail) \
        _CreateTeamProject(_class, TRUE, className, teamName, teamProjectName, projObj, mfail)

#define CreateTeamRoleAssn(className, usrName, teamName, teamRoleName, indirectTeam, traObj, mfail) \
        _CreateTeamRoleAssn(className, FALSE, className, usrName, teamName, teamRoleName, indirectTeam, traObj, mfail)
#define CreateTeamRoleAssnAtParent(_class, className, usrName, teamName, teamRoleName, indirectTeam, traObj, mfail) \
        _CreateTeamRoleAssn(_class, TRUE, className, usrName, teamName, teamRoleName, indirectTeam, traObj, mfail)

#define CreateTeamRoleAssnInt(className, usrName, roleName, teamName, shrTeamName, mfail) \
        _CreateTeamRoleAssnInt(className, FALSE, className, usrName, roleName, teamName, shrTeamName, mfail)
#define CreateTeamRoleAssnIntAtParent(_class, className, usrName, roleName, teamName, shrTeamName, mfail) \
        _CreateTeamRoleAssnInt(_class, TRUE, className, usrName, roleName, teamName, shrTeamName, mfail)

#define CreateUsrToTmRel(className, teamObj, userObj, teamRole, ustObj, mfail) \
        _CreateUsrToTmRel(className, FALSE, className, teamObj, userObj, teamRole, ustObj, mfail)
#define CreateUsrToTmRelAtParent(_class, className, teamObj, userObj, teamRole, ustObj, mfail) \
        _CreateUsrToTmRel(_class, TRUE, className, teamObj, userObj, teamRole, ustObj, mfail)

#define DGetLVSFolder(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSFolderAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSFolderAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSFolderAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSFolderAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSFolderAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSMergeToOwner(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMergeToOwnerAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSMergeToOwnerAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMergeToOwnerAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSMergeToOwnerAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMergeToOwnerAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSMergeToOwnerDir(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMergeToOwnerDirAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSMergeToOwnerDirAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMergeToOwnerDirAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSMergeToOwnerDirAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMergeToOwnerDirAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSTeam(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTeamAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTeamAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSTeamFldr(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamFldrAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTeamFldrAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamFldrAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTeamFldrAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamFldrAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSTeamLoc(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamLocAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTeamLocAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamLocAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTeamLocAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTeamLocAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DelDirSelRuForTeamLoc(thisObj, mfail) \
        _DelDirSelRuForTeamLocAtClass(NULL, FALSE, thisObj, mfail)
#define DelDirSelRuForTeamLocAtClass(class, thisObj, mfail) \
        _DelDirSelRuForTeamLocAtClass(class, FALSE, thisObj, mfail)
#define DelDirSelRuForTeamLocAtParent(class, thisObj, mfail) \
        _DelDirSelRuForTeamLocAtClass(class, TRUE, thisObj, mfail)

#define DelRolesForUsrInTm(className, usrName, teamName, indirectTeam, mfail) \
        _DelRolesForUsrInTm(className, FALSE, className, usrName, teamName, indirectTeam, mfail)
#define DelRolesForUsrInTmAtParent(_class, className, usrName, teamName, indirectTeam, mfail) \
        _DelRolesForUsrInTm(_class, TRUE, className, usrName, teamName, indirectTeam, mfail)

#define DeleteForSetAndFail(className, originObjects, failedObjects, mfail) \
        _DeleteForSetAndFail(className, FALSE, className, originObjects, failedObjects, mfail)
#define DeleteForSetAndFailAtParent(_class, className, originObjects, failedObjects, mfail) \
        _DeleteForSetAndFail(_class, TRUE, className, originObjects, failedObjects, mfail)

#define DeleteForSetAndFailInt(className, originObjects, failedObjects, mfail) \
        _DeleteForSetAndFailInt(className, FALSE, className, originObjects, failedObjects, mfail)
#define DeleteForSetAndFailIntAtParent(_class, className, originObjects, failedObjects, mfail) \
        _DeleteForSetAndFailInt(_class, TRUE, className, originObjects, failedObjects, mfail)

#define DeleteForSetAndFailPre(className, originObjects, mfail) \
        _DeleteForSetAndFailPre(className, FALSE, className, originObjects, mfail)
#define DeleteForSetAndFailPreAtParent(_class, className, originObjects, mfail) \
        _DeleteForSetAndFailPre(_class, TRUE, className, originObjects, mfail)

#define DeleteGnTmToTmRel(className, accTeamName, shrTeamName, mfail) \
        _DeleteGnTmToTmRel(className, FALSE, className, accTeamName, shrTeamName, mfail)
#define DeleteGnTmToTmRelAtParent(_class, className, accTeamName, shrTeamName, mfail) \
        _DeleteGnTmToTmRel(_class, TRUE, className, accTeamName, shrTeamName, mfail)

#define DeleteRoleOfMbrObject(thisObj, teamName, teamRoleName, mfail) \
        _DeleteRoleOfMbrObjectAtClass(NULL, FALSE, thisObj, teamName, teamRoleName, mfail)
#define DeleteRoleOfMbrObjectAtClass(class, thisObj, teamName, teamRoleName, mfail) \
        _DeleteRoleOfMbrObjectAtClass(class, FALSE, thisObj, teamName, teamRoleName, mfail)
#define DeleteRoleOfMbrObjectAtParent(class, thisObj, teamName, teamRoleName, mfail) \
        _DeleteRoleOfMbrObjectAtClass(class, TRUE, thisObj, teamName, teamRoleName, mfail)

#define DeleteTeamDefaults(className, teamName, mfail) \
        _DeleteTeamDefaults(className, FALSE, className, teamName, mfail)
#define DeleteTeamDefaultsAtParent(_class, className, teamName, mfail) \
        _DeleteTeamDefaults(_class, TRUE, className, teamName, mfail)

#define DeleteTeamRole(className, usrName, teamName, teamRoleName, indirectTeam, mfail) \
        _DeleteTeamRole(className, FALSE, className, usrName, teamName, teamRoleName, indirectTeam, mfail)
#define DeleteTeamRoleAtParent(_class, className, usrName, teamName, teamRoleName, indirectTeam, mfail) \
        _DeleteTeamRole(_class, TRUE, className, usrName, teamName, teamRoleName, indirectTeam, mfail)

#define DetermineVersion(thisObj, source, updateCounter, mfail) \
        _DetermineVersionAtClass(NULL, FALSE, thisObj, source, updateCounter, mfail)
#define DetermineVersionAtClass(class, thisObj, source, updateCounter, mfail) \
        _DetermineVersionAtClass(class, FALSE, thisObj, source, updateCounter, mfail)
#define DetermineVersionAtParent(class, thisObj, source, updateCounter, mfail) \
        _DetermineVersionAtClass(class, TRUE, thisObj, source, updateCounter, mfail)

#define DoCheckInToTm(thisObj, argumentsObj, predecessor, predecessorParent, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoCheckInToTmAtClass(NULL, FALSE, thisObj, argumentsObj, predecessor, predecessorParent, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoCheckInToTmAtClass(class, thisObj, argumentsObj, predecessor, predecessorParent, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoCheckInToTmAtClass(class, FALSE, thisObj, argumentsObj, predecessor, predecessorParent, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoCheckInToTmAtParent(class, thisObj, argumentsObj, predecessor, predecessorParent, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoCheckInToTmAtClass(class, TRUE, thisObj, argumentsObj, predecessor, predecessorParent, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define DoCheckInToTmOtherObjs(className, otherObjs, dialogObj, mfail) \
        _DoCheckInToTmOtherObjs(className, FALSE, className, otherObjs, dialogObj, mfail)
#define DoCheckInToTmOtherObjsAtParent(_class, className, otherObjs, dialogObj, mfail) \
        _DoCheckInToTmOtherObjs(_class, TRUE, className, otherObjs, dialogObj, mfail)

#define DoCheckInToTmUnmg(thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _DoCheckInToTmUnmgAtClass(NULL, FALSE, thisObj, argumentsObj, TransferInfoObjects, mfail)
#define DoCheckInToTmUnmgAtClass(class, thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _DoCheckInToTmUnmgAtClass(class, FALSE, thisObj, argumentsObj, TransferInfoObjects, mfail)
#define DoCheckInToTmUnmgAtParent(class, thisObj, argumentsObj, TransferInfoObjects, mfail) \
        _DoCheckInToTmUnmgAtClass(class, TRUE, thisObj, argumentsObj, TransferInfoObjects, mfail)

#define DoCheckInToTmUnmg2(thisObj, argumentsObj, transferInfoObjs, newWorkItem, dataItems, transferInfo, mfail) \
        _DoCheckInToTmUnmg2AtClass(NULL, FALSE, thisObj, argumentsObj, transferInfoObjs, newWorkItem, dataItems, transferInfo, mfail)
#define DoCheckInToTmUnmg2AtClass(class, thisObj, argumentsObj, transferInfoObjs, newWorkItem, dataItems, transferInfo, mfail) \
        _DoCheckInToTmUnmg2AtClass(class, FALSE, thisObj, argumentsObj, transferInfoObjs, newWorkItem, dataItems, transferInfo, mfail)
#define DoCheckInToTmUnmg2AtParent(class, thisObj, argumentsObj, transferInfoObjs, newWorkItem, dataItems, transferInfo, mfail) \
        _DoCheckInToTmUnmg2AtClass(class, TRUE, thisObj, argumentsObj, transferInfoObjs, newWorkItem, dataItems, transferInfo, mfail)

#define DoCheckInToTmUnmg3(className, selectedObjs, argumentsObjs, transferInfoObjs, ckoObjects, mfail) \
        _DoCheckInToTmUnmg3(className, FALSE, className, selectedObjs, argumentsObjs, transferInfoObjs, ckoObjects, mfail)
#define DoCheckInToTmUnmg3AtParent(_class, className, selectedObjs, argumentsObjs, transferInfoObjs, ckoObjects, mfail) \
        _DoCheckInToTmUnmg3(_class, TRUE, className, selectedObjs, argumentsObjs, transferInfoObjs, ckoObjects, mfail)

#define DoCheckOutFromTeam(thisObj, target, refresh, mfail) \
        _DoCheckOutFromTeamAtClass(NULL, FALSE, thisObj, target, refresh, mfail)
#define DoCheckOutFromTeamAtClass(class, thisObj, target, refresh, mfail) \
        _DoCheckOutFromTeamAtClass(class, FALSE, thisObj, target, refresh, mfail)
#define DoCheckOutFromTeamAtParent(class, thisObj, target, refresh, mfail) \
        _DoCheckOutFromTeamAtClass(class, TRUE, thisObj, target, refresh, mfail)

#define DoCheckOutItemFromTeam(thisObj, target, refresh, isBase, transferredObjs, dest, mfail) \
        _DoCheckOutItemFromTeamAtClass(NULL, FALSE, thisObj, target, refresh, isBase, transferredObjs, dest, mfail)
#define DoCheckOutItemFromTeamAtClass(class, thisObj, target, refresh, isBase, transferredObjs, dest, mfail) \
        _DoCheckOutItemFromTeamAtClass(class, FALSE, thisObj, target, refresh, isBase, transferredObjs, dest, mfail)
#define DoCheckOutItemFromTeamAtParent(class, thisObj, target, refresh, isBase, transferredObjs, dest, mfail) \
        _DoCheckOutItemFromTeamAtClass(class, TRUE, thisObj, target, refresh, isBase, transferredObjs, dest, mfail)

#define DoCheckOutT(thisObj, target, refresh, oldName, mfail) \
        _DoCheckOutTAtClass(NULL, FALSE, thisObj, target, refresh, oldName, mfail)
#define DoCheckOutTAtClass(class, thisObj, target, refresh, oldName, mfail) \
        _DoCheckOutTAtClass(class, FALSE, thisObj, target, refresh, oldName, mfail)
#define DoCheckOutTAtParent(class, thisObj, target, refresh, oldName, mfail) \
        _DoCheckOutTAtClass(class, TRUE, thisObj, target, refresh, oldName, mfail)

#define DoCheckOutTItem(thisObj, target, refresh, isBase, oldName, transferredObjs, dest, mfail) \
        _DoCheckOutTItemAtClass(NULL, FALSE, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, mfail)
#define DoCheckOutTItemAtClass(class, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, mfail) \
        _DoCheckOutTItemAtClass(class, FALSE, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, mfail)
#define DoCheckOutTItemAtParent(class, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, mfail) \
        _DoCheckOutTItemAtClass(class, TRUE, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, mfail)

#define DoCheckOutTPost(thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPostAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTPostAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPostAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTPostAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPostAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define DoCheckOutTPostInt(thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPostIntAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTPostIntAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPostIntAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTPostIntAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPostIntAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define DoCheckOutTPre(thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPreAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTPreAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPreAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTPreAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTPreAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define DoCheckOutTeamPost(thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPostAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTeamPostAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPostAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTeamPostAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPostAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define DoCheckOutTeamPostInt(thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPostIntAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTeamPostIntAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPostIntAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTeamPostIntAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPostIntAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define DoCheckOutTeamPre(thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPreAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTeamPreAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPreAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCheckOutTeamPreAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCheckOutTeamPreAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define DoCkiRplceToTm(thisObj, argumentsObj, mfail) \
        _DoCkiRplceToTmAtClass(NULL, FALSE, thisObj, argumentsObj, mfail)
#define DoCkiRplceToTmAtClass(class, thisObj, argumentsObj, mfail) \
        _DoCkiRplceToTmAtClass(class, FALSE, thisObj, argumentsObj, mfail)
#define DoCkiRplceToTmAtParent(class, thisObj, argumentsObj, mfail) \
        _DoCkiRplceToTmAtClass(class, TRUE, thisObj, argumentsObj, mfail)

#define DoCkiToTeamNoReplace(thisObj, argumentsObj, mfail) \
        _DoCkiToTeamNoReplaceAtClass(NULL, FALSE, thisObj, argumentsObj, mfail)
#define DoCkiToTeamNoReplaceAtClass(class, thisObj, argumentsObj, mfail) \
        _DoCkiToTeamNoReplaceAtClass(class, FALSE, thisObj, argumentsObj, mfail)
#define DoCkiToTeamNoReplaceAtParent(class, thisObj, argumentsObj, mfail) \
        _DoCkiToTeamNoReplaceAtClass(class, TRUE, thisObj, argumentsObj, mfail)

#define DoCkiToTeamReplaceAux(thisObj, predecessorObj, argsObj, mfail) \
        _DoCkiToTeamReplaceAuxAtClass(NULL, FALSE, thisObj, predecessorObj, argsObj, mfail)
#define DoCkiToTeamReplaceAuxAtClass(class, thisObj, predecessorObj, argsObj, mfail) \
        _DoCkiToTeamReplaceAuxAtClass(class, FALSE, thisObj, predecessorObj, argsObj, mfail)
#define DoCkiToTeamReplaceAuxAtParent(class, thisObj, predecessorObj, argsObj, mfail) \
        _DoCkiToTeamReplaceAuxAtClass(class, TRUE, thisObj, predecessorObj, argsObj, mfail)

#define DoCkoFromTmAttmnts(className, attachedObjs, dialogObj, mfail) \
        _DoCkoFromTmAttmnts(className, FALSE, className, attachedObjs, dialogObj, mfail)
#define DoCkoFromTmAttmntsAtParent(_class, className, attachedObjs, dialogObj, mfail) \
        _DoCkoFromTmAttmnts(_class, TRUE, className, attachedObjs, dialogObj, mfail)

#define DoCkoMkvCreDestObjTm(thisObj, target, refresh, isBase, transferredObjs, dest, relatedObj, mfail) \
        _DoCkoMkvCreDestObjTmAtClass(NULL, FALSE, thisObj, target, refresh, isBase, transferredObjs, dest, relatedObj, mfail)
#define DoCkoMkvCreDestObjTmAtClass(class, thisObj, target, refresh, isBase, transferredObjs, dest, relatedObj, mfail) \
        _DoCkoMkvCreDestObjTmAtClass(class, FALSE, thisObj, target, refresh, isBase, transferredObjs, dest, relatedObj, mfail)
#define DoCkoMkvCreDestObjTmAtParent(class, thisObj, target, refresh, isBase, transferredObjs, dest, relatedObj, mfail) \
        _DoCkoMkvCreDestObjTmAtClass(class, TRUE, thisObj, target, refresh, isBase, transferredObjs, dest, relatedObj, mfail)

#define DoCkoMkvTeamPostInt(thisObj, dest, target, refresh, isBase, mfail) \
        _DoCkoMkvTeamPostIntAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCkoMkvTeamPostIntAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCkoMkvTeamPostIntAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCkoMkvTeamPostIntAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCkoMkvTeamPostIntAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define DoCkoTMkvCreDestObj(thisObj, target, refresh, isBase, oldName, transferredObjs, dest, relatedObj, mfail) \
        _DoCkoTMkvCreDestObjAtClass(NULL, FALSE, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, relatedObj, mfail)
#define DoCkoTMkvCreDestObjAtClass(class, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, relatedObj, mfail) \
        _DoCkoTMkvCreDestObjAtClass(class, FALSE, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, relatedObj, mfail)
#define DoCkoTMkvCreDestObjAtParent(class, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, relatedObj, mfail) \
        _DoCkoTMkvCreDestObjAtClass(class, TRUE, thisObj, target, refresh, isBase, oldName, transferredObjs, dest, relatedObj, mfail)

#define DoCkoTMkvPostInt(thisObj, dest, target, refresh, isBase, mfail) \
        _DoCkoTMkvPostIntAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCkoTMkvPostIntAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCkoTMkvPostIntAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define DoCkoTMkvPostIntAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _DoCkoTMkvPostIntAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define DoCopyFromTm(thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail) \
        _DoCopyFromTmAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail)
#define DoCopyFromTmAtClass(class, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail) \
        _DoCopyFromTmAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail)
#define DoCopyFromTmAtParent(class, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail) \
        _DoCopyFromTmAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail)

#define DoCopyFromTmItem(thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail) \
        _DoCopyFromTmItemAtClass(NULL, FALSE, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail)
#define DoCopyFromTmItemAtClass(class, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail) \
        _DoCopyFromTmItemAtClass(class, FALSE, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail)
#define DoCopyFromTmItemAtParent(class, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail) \
        _DoCopyFromTmItemAtClass(class, TRUE, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail)

#define DoCopyItemT(thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail) \
        _DoCopyItemTAtClass(NULL, FALSE, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail)
#define DoCopyItemTAtClass(class, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail) \
        _DoCopyItemTAtClass(class, FALSE, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail)
#define DoCopyItemTAtParent(class, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail) \
        _DoCopyItemTAtClass(class, TRUE, thisObj, dialogObj, updateWindow, createCopyRel, copiedObjs, newObj, nextTarget, mfail)

#define DoCopyT(thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail) \
        _DoCopyTAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail)
#define DoCopyTAtClass(class, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail) \
        _DoCopyTAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail)
#define DoCopyTAtParent(class, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail) \
        _DoCopyTAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, updateWindow, createCopyRel, mfail)

#define DoCorrectPurge(thisObj, relationObj, extraStr, extraObj, mfail) \
        _DoCorrectPurgeAtClass(NULL, FALSE, thisObj, relationObj, extraStr, extraObj, mfail)
#define DoCorrectPurgeAtClass(class, thisObj, relationObj, extraStr, extraObj, mfail) \
        _DoCorrectPurgeAtClass(class, FALSE, thisObj, relationObj, extraStr, extraObj, mfail)
#define DoCorrectPurgeAtParent(class, thisObj, relationObj, extraStr, extraObj, mfail) \
        _DoCorrectPurgeAtClass(class, TRUE, thisObj, relationObj, extraStr, extraObj, mfail)

#define DoMoveFldrToFldr(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoMoveFldrToFldrAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoMoveFldrToFldrAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoMoveFldrToFldrAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoMoveFldrToFldrAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoMoveFldrToFldrAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoPurgeSequence(thisObj, mfail) \
        _DoPurgeSequenceAtClass(NULL, FALSE, thisObj, mfail)
#define DoPurgeSequenceAtClass(class, thisObj, mfail) \
        _DoPurgeSequenceAtClass(class, FALSE, thisObj, mfail)
#define DoPurgeSequenceAtParent(class, thisObj, mfail) \
        _DoPurgeSequenceAtClass(class, TRUE, thisObj, mfail)

#define DoRelease(thisObj, predecessor, predecessorParent, destOwnerObj, dialogObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseAtClass(NULL, FALSE, thisObj, predecessor, predecessorParent, destOwnerObj, dialogObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoReleaseAtClass(class, thisObj, predecessor, predecessorParent, destOwnerObj, dialogObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseAtClass(class, FALSE, thisObj, predecessor, predecessorParent, destOwnerObj, dialogObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoReleaseAtParent(class, thisObj, predecessor, predecessorParent, destOwnerObj, dialogObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseAtClass(class, TRUE, thisObj, predecessor, predecessorParent, destOwnerObj, dialogObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define DoReleaseNoReplace(thisObj, dialogObj, mfail) \
        _DoReleaseNoReplaceAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoReleaseNoReplaceAtClass(class, thisObj, dialogObj, mfail) \
        _DoReleaseNoReplaceAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoReleaseNoReplaceAtParent(class, thisObj, dialogObj, mfail) \
        _DoReleaseNoReplaceAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoReleaseRplce(thisObj, dialogObj, mfail) \
        _DoReleaseRplceAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoReleaseRplceAtClass(class, thisObj, dialogObj, mfail) \
        _DoReleaseRplceAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoReleaseRplceAtParent(class, thisObj, dialogObj, mfail) \
        _DoReleaseRplceAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoReleaseRplceAux(thisObj, predecessorObj, argsObj, mfail) \
        _DoReleaseRplceAuxAtClass(NULL, FALSE, thisObj, predecessorObj, argsObj, mfail)
#define DoReleaseRplceAuxAtClass(class, thisObj, predecessorObj, argsObj, mfail) \
        _DoReleaseRplceAuxAtClass(class, FALSE, thisObj, predecessorObj, argsObj, mfail)
#define DoReleaseRplceAuxAtParent(class, thisObj, predecessorObj, argsObj, mfail) \
        _DoReleaseRplceAuxAtClass(class, TRUE, thisObj, predecessorObj, argsObj, mfail)

#define DoReleaseTransfer(thisObj, destOwnerObj, destOwnerDirObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferAtClass(NULL, FALSE, thisObj, destOwnerObj, destOwnerDirObj, dialogObj, extraStr, extraObj, mfail)
#define DoReleaseTransferAtClass(class, thisObj, destOwnerObj, destOwnerDirObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferAtClass(class, FALSE, thisObj, destOwnerObj, destOwnerDirObj, dialogObj, extraStr, extraObj, mfail)
#define DoReleaseTransferAtParent(class, thisObj, destOwnerObj, destOwnerDirObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferAtClass(class, TRUE, thisObj, destOwnerObj, destOwnerDirObj, dialogObj, extraStr, extraObj, mfail)

#define DoReleaseTransferAux(thisObj, destOwnerObj, destOwnerDirObj, argsObj, mfail) \
        _DoReleaseTransferAuxAtClass(NULL, FALSE, thisObj, destOwnerObj, destOwnerDirObj, argsObj, mfail)
#define DoReleaseTransferAuxAtClass(class, thisObj, destOwnerObj, destOwnerDirObj, argsObj, mfail) \
        _DoReleaseTransferAuxAtClass(class, FALSE, thisObj, destOwnerObj, destOwnerDirObj, argsObj, mfail)
#define DoReleaseTransferAuxAtParent(class, thisObj, destOwnerObj, destOwnerDirObj, argsObj, mfail) \
        _DoReleaseTransferAuxAtClass(class, TRUE, thisObj, destOwnerObj, destOwnerDirObj, argsObj, mfail)

#define DoReleaseTransferCopy(thisObj, destOwnerObj, target, dialogObj, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail) \
        _DoReleaseTransferCopyAtClass(NULL, FALSE, thisObj, destOwnerObj, target, dialogObj, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail)
#define DoReleaseTransferCopyAtClass(class, thisObj, destOwnerObj, target, dialogObj, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail) \
        _DoReleaseTransferCopyAtClass(class, FALSE, thisObj, destOwnerObj, target, dialogObj, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail)
#define DoReleaseTransferCopyAtParent(class, thisObj, destOwnerObj, target, dialogObj, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail) \
        _DoReleaseTransferCopyAtClass(class, TRUE, thisObj, destOwnerObj, target, dialogObj, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail)

#define DoReleaseTransferPost(thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferPostAtClass(NULL, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoReleaseTransferPostAtClass(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferPostAtClass(class, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoReleaseTransferPostAtParent(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferPostAtClass(class, TRUE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define DoReleaseTransferPre(thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferPreAtClass(NULL, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoReleaseTransferPreAtClass(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferPreAtClass(class, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoReleaseTransferPreAtParent(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoReleaseTransferPreAtClass(class, TRUE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define DoShadowCopyFromTm(thisObj, dialogObj, extraStr, extraObj, updateWindow, newObj, mfail) \
        _DoShadowCopyFromTmAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, updateWindow, newObj, mfail)
#define DoShadowCopyFromTmAtClass(class, thisObj, dialogObj, extraStr, extraObj, updateWindow, newObj, mfail) \
        _DoShadowCopyFromTmAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, updateWindow, newObj, mfail)
#define DoShadowCopyFromTmAtParent(class, thisObj, dialogObj, extraStr, extraObj, updateWindow, newObj, mfail) \
        _DoShadowCopyFromTmAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, updateWindow, newObj, mfail)

#define DoShadowCopyTm(thisObj, dialogObj, extraStr, extraObj, updateWindow, copiedObj, mfail) \
        _DoShadowCopyTmAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, updateWindow, copiedObj, mfail)
#define DoShadowCopyTmAtClass(class, thisObj, dialogObj, extraStr, extraObj, updateWindow, copiedObj, mfail) \
        _DoShadowCopyTmAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, updateWindow, copiedObj, mfail)
#define DoShadowCopyTmAtParent(class, thisObj, dialogObj, extraStr, extraObj, updateWindow, copiedObj, mfail) \
        _DoShadowCopyTmAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, updateWindow, copiedObj, mfail)

#define DoTransferAuthority(thisObj, argumentsObj, extraStr, extraObj, mfail) \
        _DoTransferAuthorityAtClass(NULL, FALSE, thisObj, argumentsObj, extraStr, extraObj, mfail)
#define DoTransferAuthorityAtClass(class, thisObj, argumentsObj, extraStr, extraObj, mfail) \
        _DoTransferAuthorityAtClass(class, FALSE, thisObj, argumentsObj, extraStr, extraObj, mfail)
#define DoTransferAuthorityAtParent(class, thisObj, argumentsObj, extraStr, extraObj, mfail) \
        _DoTransferAuthorityAtClass(class, TRUE, thisObj, argumentsObj, extraStr, extraObj, mfail)

#define DoTransferGitItem(thisObj, destOwnerObj, isBaseObj, extraStr, extraObj, mfail) \
        _DoTransferGitItemAtClass(NULL, FALSE, thisObj, destOwnerObj, isBaseObj, extraStr, extraObj, mfail)
#define DoTransferGitItemAtClass(class, thisObj, destOwnerObj, isBaseObj, extraStr, extraObj, mfail) \
        _DoTransferGitItemAtClass(class, FALSE, thisObj, destOwnerObj, isBaseObj, extraStr, extraObj, mfail)
#define DoTransferGitItemAtParent(class, thisObj, destOwnerObj, isBaseObj, extraStr, extraObj, mfail) \
        _DoTransferGitItemAtClass(class, TRUE, thisObj, destOwnerObj, isBaseObj, extraStr, extraObj, mfail)

#define DoTransferTm(thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmAtClass(NULL, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoTransferTmAtClass(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmAtClass(class, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoTransferTmAtParent(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmAtClass(class, TRUE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define DoTransferTmCopy(thisObj, destOwnerObj, target, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail) \
        _DoTransferTmCopyAtClass(NULL, FALSE, thisObj, destOwnerObj, target, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail)
#define DoTransferTmCopyAtClass(class, thisObj, destOwnerObj, target, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail) \
        _DoTransferTmCopyAtClass(class, FALSE, thisObj, destOwnerObj, target, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail)
#define DoTransferTmCopyAtParent(class, thisObj, destOwnerObj, target, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail) \
        _DoTransferTmCopyAtClass(class, TRUE, thisObj, destOwnerObj, target, isBaseObj, sourceObjSet, destObjSet, extraStr, extraObj, mfail)

#define DoTransferTmFromUnmg(thisObj, argumentsObj, transferInfoObjs, mfail) \
        _DoTransferTmFromUnmgAtClass(NULL, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define DoTransferTmFromUnmgAtClass(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _DoTransferTmFromUnmgAtClass(class, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define DoTransferTmFromUnmgAtParent(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _DoTransferTmFromUnmgAtClass(class, TRUE, thisObj, argumentsObj, transferInfoObjs, mfail)

#define DoTransferTmPost(thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmPostAtClass(NULL, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoTransferTmPostAtClass(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmPostAtClass(class, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoTransferTmPostAtParent(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmPostAtClass(class, TRUE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define DoTransferTmPre(thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmPreAtClass(NULL, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoTransferTmPreAtClass(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmPreAtClass(class, FALSE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define DoTransferTmPreAtParent(class, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _DoTransferTmPreAtClass(class, TRUE, thisObj, argumentsObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define DoTransferTmUnmgInt(thisObj, argumentsObj, transferInfoObjs, mfail) \
        _DoTransferTmUnmgIntAtClass(NULL, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define DoTransferTmUnmgIntAtClass(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _DoTransferTmUnmgIntAtClass(class, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define DoTransferTmUnmgIntAtParent(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _DoTransferTmUnmgIntAtClass(class, TRUE, thisObj, argumentsObj, transferInfoObjs, mfail)

#define DoesPredRPrcForCinToTm(classname, answer, mfail) \
        _DoesPredRPrcForCinToTm(classname, FALSE, classname, answer, mfail)
#define DoesPredRPrcForCinToTmAtParent(_class, classname, answer, mfail) \
        _DoesPredRPrcForCinToTm(_class, TRUE, classname, answer, mfail)

#define DoesPredRValForCinToTm(classname, answer, mfail) \
        _DoesPredRValForCinToTm(classname, FALSE, classname, answer, mfail)
#define DoesPredRValForCinToTmAtParent(_class, classname, answer, mfail) \
        _DoesPredRValForCinToTm(_class, TRUE, classname, answer, mfail)

#define DoesPredRelPrcForCirTm(classname, action, actionCode, answer, mfail) \
        _DoesPredRelPrcForCirTm(classname, FALSE, classname, action, actionCode, answer, mfail)
#define DoesPredRelPrcForCirTmAtParent(_class, classname, action, actionCode, answer, mfail) \
        _DoesPredRelPrcForCirTm(_class, TRUE, classname, action, actionCode, answer, mfail)

#define DoesPredRelValForCirTm(classname, action, actionCode, answer, mfail) \
        _DoesPredRelValForCirTm(classname, FALSE, classname, action, actionCode, answer, mfail)
#define DoesPredRelValForCirTmAtParent(_class, classname, action, actionCode, answer, mfail) \
        _DoesPredRelValForCirTm(_class, TRUE, classname, action, actionCode, answer, mfail)

#define DoesPredRelValForRel(classname, answer, mfail) \
        _DoesPredRelValForRel(classname, FALSE, classname, answer, mfail)
#define DoesPredRelValForRelAtParent(_class, classname, answer, mfail) \
        _DoesPredRelValForRel(_class, TRUE, classname, answer, mfail)

#define DoesRelCValForCkoToTm(className, answer, mfail) \
        _DoesRelCValForCkoToTm(className, FALSE, className, answer, mfail)
#define DoesRelCValForCkoToTmAtParent(_class, className, answer, mfail) \
        _DoesRelCValForCkoToTm(_class, TRUE, className, answer, mfail)

#define DoesRelClassPrcForCkoT(className, answer, mfail) \
        _DoesRelClassPrcForCkoT(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForCkoTAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForCkoT(_class, TRUE, className, answer, mfail)

#define DoesRelClassPrcForMrg(className, answer, mfail) \
        _DoesRelClassPrcForMrg(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForMrgAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForMrg(_class, TRUE, className, answer, mfail)

#define DoesRelPrcForPostRlse(className, answer, mfail) \
        _DoesRelPrcForPostRlse(className, FALSE, className, answer, mfail)
#define DoesRelPrcForPostRlseAtParent(_class, className, answer, mfail) \
        _DoesRelPrcForPostRlse(_class, TRUE, className, answer, mfail)

#define DoesRolePropagate(className, teamRole, answer, mfail) \
        _DoesRolePropagate(className, FALSE, className, teamRole, answer, mfail)
#define DoesRolePropagateAtParent(_class, className, teamRole, answer, mfail) \
        _DoesRolePropagate(_class, TRUE, className, teamRole, answer, mfail)

#define DoesSuccRPrcForCinToTm(classname, answer, mfail) \
        _DoesSuccRPrcForCinToTm(classname, FALSE, classname, answer, mfail)
#define DoesSuccRPrcForCinToTmAtParent(_class, classname, answer, mfail) \
        _DoesSuccRPrcForCinToTm(_class, TRUE, classname, answer, mfail)

#define DoesSuccRValForCinToTm(classname, answer, mfail) \
        _DoesSuccRValForCinToTm(classname, FALSE, classname, answer, mfail)
#define DoesSuccRValForCinToTmAtParent(_class, classname, answer, mfail) \
        _DoesSuccRValForCinToTm(_class, TRUE, classname, answer, mfail)

#define DoesSuccRelPrcForCirTm(classname, action, actionCode, answer, mfail) \
        _DoesSuccRelPrcForCirTm(classname, FALSE, classname, action, actionCode, answer, mfail)
#define DoesSuccRelPrcForCirTmAtParent(_class, classname, action, actionCode, answer, mfail) \
        _DoesSuccRelPrcForCirTm(_class, TRUE, classname, action, actionCode, answer, mfail)

#define DoesSuccRelValForCirTm(classname, action, actionCode, answer, mfail) \
        _DoesSuccRelValForCirTm(classname, FALSE, classname, action, actionCode, answer, mfail)
#define DoesSuccRelValForCirTmAtParent(_class, classname, action, actionCode, answer, mfail) \
        _DoesSuccRelValForCirTm(_class, TRUE, classname, action, actionCode, answer, mfail)

#define DoesSuccRelValForRel(classname, answer, mfail) \
        _DoesSuccRelValForRel(classname, FALSE, classname, answer, mfail)
#define DoesSuccRelValForRelAtParent(_class, classname, answer, mfail) \
        _DoesSuccRelValForRel(_class, TRUE, classname, answer, mfail)

#define DoesTmRlAssnExist(className, userName, teamProjName, teamRoleName, indirectTeam, exists, mfail) \
        _DoesTmRlAssnExist(className, FALSE, className, userName, teamProjName, teamRoleName, indirectTeam, exists, mfail)
#define DoesTmRlAssnExistAtParent(_class, className, userName, teamProjName, teamRoleName, indirectTeam, exists, mfail) \
        _DoesTmRlAssnExist(_class, TRUE, className, userName, teamProjName, teamRoleName, indirectTeam, exists, mfail)

#define FailMerge(workItemClass, mfail) \
        _FailMerge(workItemClass, FALSE, workItemClass, mfail)
#define FailMergeAtParent(_class, workItemClass, mfail) \
        _FailMerge(_class, TRUE, workItemClass, mfail)

#define FailMergeVersions(workItemClass, mfail) \
        _FailMergeVersions(workItemClass, FALSE, workItemClass, mfail)
#define FailMergeVersionsAtParent(_class, workItemClass, mfail) \
        _FailMergeVersions(_class, TRUE, workItemClass, mfail)

#define FindAllFoldersByName(className, folderName, folderObjSet, mfail) \
        _FindAllFoldersByName(className, FALSE, className, folderName, folderObjSet, mfail)
#define FindAllFoldersByNameAtParent(_class, className, folderName, folderObjSet, mfail) \
        _FindAllFoldersByName(_class, TRUE, className, folderName, folderObjSet, mfail)

#define FindBestTeamLoc(team, argObj, teamloc, mfail) \
        _FindBestTeamLocAtClass(NULL, FALSE, team, argObj, teamloc, mfail)
#define FindBestTeamLocAtClass(class, team, argObj, teamloc, mfail) \
        _FindBestTeamLocAtClass(class, FALSE, team, argObj, teamloc, mfail)
#define FindBestTeamLocAtParent(class, team, argObj, teamloc, mfail) \
        _FindBestTeamLocAtClass(class, TRUE, team, argObj, teamloc, mfail)

#define FindFldrByNameAndOwner(className, folderName, ownerName, folderObj, mfail) \
        _FindFldrByNameAndOwner(className, FALSE, className, folderName, ownerName, folderObj, mfail)
#define FindFldrByNameAndOwnerAtParent(_class, className, folderName, ownerName, folderObj, mfail) \
        _FindFldrByNameAndOwner(_class, TRUE, className, folderName, ownerName, folderObj, mfail)

#define FindGnTmToTmRel(className, accTeamName, shrTeamName, gttObj, mfail) \
        _FindGnTmToTmRel(className, FALSE, className, accTeamName, shrTeamName, gttObj, mfail)
#define FindGnTmToTmRelAtParent(_class, className, accTeamName, shrTeamName, gttObj, mfail) \
        _FindGnTmToTmRel(_class, TRUE, className, accTeamName, shrTeamName, gttObj, mfail)

#define FindLatestItemInFolder(itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _FindLatestItemInFolderAtClass(NULL, FALSE, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail)
#define FindLatestItemInFolderAtClass(class, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _FindLatestItemInFolderAtClass(class, FALSE, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail)
#define FindLatestItemInFolderAtParent(class, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _FindLatestItemInFolderAtClass(class, TRUE, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail)

#define FindPredForMergeVers(workItemClass, argObj, extraObj, pred, mfail) \
        _FindPredForMergeVers(workItemClass, FALSE, workItemClass, argObj, extraObj, pred, mfail)
#define FindPredForMergeVersAtParent(_class, workItemClass, argObj, extraObj, pred, mfail) \
        _FindPredForMergeVers(_class, TRUE, workItemClass, argObj, extraObj, pred, mfail)

#define FindPredsForMergeVers(workItemClass, argObjs, mfail) \
        _FindPredsForMergeVers(workItemClass, FALSE, workItemClass, argObjs, mfail)
#define FindPredsForMergeVersAtParent(_class, workItemClass, argObjs, mfail) \
        _FindPredsForMergeVers(_class, TRUE, workItemClass, argObjs, mfail)

#define FindTeamLocsByTeamName(className, teamName, teamLocSet, mfail) \
        _FindTeamLocsByTeamName(className, FALSE, className, teamName, teamLocSet, mfail)
#define FindTeamLocsByTeamNameAtParent(_class, className, teamName, teamLocSet, mfail) \
        _FindTeamLocsByTeamName(_class, TRUE, className, teamName, teamLocSet, mfail)

#define FindTeamRoleObject(className, findType, teamRoleName, teamRoleObj, validationStatus, mfail) \
        _FindTeamRoleObject(className, FALSE, className, findType, teamRoleName, teamRoleObj, validationStatus, mfail)
#define FindTeamRoleObjectAtParent(_class, className, findType, teamRoleName, teamRoleObj, validationStatus, mfail) \
        _FindTeamRoleObject(_class, TRUE, className, findType, teamRoleName, teamRoleObj, validationStatus, mfail)

#define FindTmNameByTmProjName(className, teamProjectName, teamName, mfail) \
        _FindTmNameByTmProjName(className, FALSE, className, teamProjectName, teamName, mfail)
#define FindTmNameByTmProjNameAtParent(_class, className, teamProjectName, teamName, mfail) \
        _FindTmNameByTmProjName(_class, TRUE, className, teamProjectName, teamName, mfail)

#define FindTmProjNameByTmName(className, teamName, teamProjectName, mfail) \
        _FindTmProjNameByTmName(className, FALSE, className, teamName, teamProjectName, mfail)
#define FindTmProjNameByTmNameAtParent(_class, className, teamName, teamProjectName, mfail) \
        _FindTmProjNameByTmName(_class, TRUE, className, teamName, teamProjectName, mfail)

#define FindTmRlAssnObject(className, findType, userName, teamProjName, teamRoleName, indirectTeam, traObj, validationStatus, mfail) \
        _FindTmRlAssnObject(className, FALSE, className, findType, userName, teamProjName, teamRoleName, indirectTeam, traObj, validationStatus, mfail)
#define FindTmRlAssnObjectAtParent(_class, className, findType, userName, teamProjName, teamRoleName, indirectTeam, traObj, validationStatus, mfail) \
        _FindTmRlAssnObject(_class, TRUE, className, findType, userName, teamProjName, teamRoleName, indirectTeam, traObj, validationStatus, mfail)

#define FindTmdByTeamName(className, findType, teamName, tmDfltObj, validationStatus, mfail) \
        _FindTmdByTeamName(className, FALSE, className, findType, teamName, tmDfltObj, validationStatus, mfail)
#define FindTmdByTeamNameAtParent(_class, className, findType, teamName, tmDfltObj, validationStatus, mfail) \
        _FindTmdByTeamName(_class, TRUE, className, findType, teamName, tmDfltObj, validationStatus, mfail)

#define FindTmdByTeamRole(className, findType, teamRoleName, shrTeamRoleFlag, tmDfltObj, validationStatus, mfail) \
        _FindTmdByTeamRole(className, FALSE, className, findType, teamRoleName, shrTeamRoleFlag, tmDfltObj, validationStatus, mfail)
#define FindTmdByTeamRoleAtParent(_class, className, findType, teamRoleName, shrTeamRoleFlag, tmDfltObj, validationStatus, mfail) \
        _FindTmdByTeamRole(_class, TRUE, className, findType, teamRoleName, shrTeamRoleFlag, tmDfltObj, validationStatus, mfail)

#define FindTraByRoleName(className, findType, teamRoleName, traObj, validationStatus, mfail) \
        _FindTraByRoleName(className, FALSE, className, findType, teamRoleName, traObj, validationStatus, mfail)
#define FindTraByRoleNameAtParent(_class, className, findType, teamRoleName, traObj, validationStatus, mfail) \
        _FindTraByRoleName(_class, TRUE, className, findType, teamRoleName, traObj, validationStatus, mfail)

#define FindTraForUsrWithRole(className, userName, teamRoleName, traObjSet, mfail) \
        _FindTraForUsrWithRole(className, FALSE, className, userName, teamRoleName, traObjSet, mfail)
#define FindTraForUsrWithRoleAtParent(_class, className, userName, teamRoleName, traObjSet, mfail) \
        _FindTraForUsrWithRole(_class, TRUE, className, userName, teamRoleName, traObjSet, mfail)

#define FindUsrToGrpObject(className, findType, usrName, usrGrpName, usgObj, validationStatus, mfail) \
        _FindUsrToGrpObject(className, FALSE, className, findType, usrName, usrGrpName, usgObj, validationStatus, mfail)
#define FindUsrToGrpObjectAtParent(_class, className, findType, usrName, usrGrpName, usgObj, validationStatus, mfail) \
        _FindUsrToGrpObject(_class, TRUE, className, findType, usrName, usrGrpName, usgObj, validationStatus, mfail)

#define FindUsrToTmRel(className, usrName, teamName, ustObj, mfail) \
        _FindUsrToTmRel(className, FALSE, className, usrName, teamName, ustObj, mfail)
#define FindUsrToTmRelAtParent(_class, className, usrName, teamName, ustObj, mfail) \
        _FindUsrToTmRel(_class, TRUE, className, usrName, teamName, ustObj, mfail)

#define FinishMerge(workItemClass, mfail) \
        _FinishMerge(workItemClass, FALSE, workItemClass, mfail)
#define FinishMergeAtParent(_class, workItemClass, mfail) \
        _FinishMerge(_class, TRUE, workItemClass, mfail)

#define FinishMerge2(workItemClass, mrgDialogs, newItems, mfail) \
        _FinishMerge2(workItemClass, FALSE, workItemClass, mrgDialogs, newItems, mfail)
#define FinishMerge2AtParent(_class, workItemClass, mrgDialogs, newItems, mfail) \
        _FinishMerge2(_class, TRUE, workItemClass, mrgDialogs, newItems, mfail)

#define FinishMergeVersions(workItemClass, mfail) \
        _FinishMergeVersions(workItemClass, FALSE, workItemClass, mfail)
#define FinishMergeVersionsAtParent(_class, workItemClass, mfail) \
        _FinishMergeVersions(_class, TRUE, workItemClass, mfail)

#define GetAllAccGttByTmName(className, teamName, gttObjSet, mfail) \
        _GetAllAccGttByTmName(className, FALSE, className, teamName, gttObjSet, mfail)
#define GetAllAccGttByTmNameAtParent(_class, className, teamName, gttObjSet, mfail) \
        _GetAllAccGttByTmName(_class, TRUE, className, teamName, gttObjSet, mfail)

#define GetAllAccTmsForSesUser(className, teamObjSet, mfail) \
        _GetAllAccTmsForSesUser(className, FALSE, className, teamObjSet, mfail)
#define GetAllAccTmsForSesUserAtParent(_class, className, teamObjSet, mfail) \
        _GetAllAccTmsForSesUser(_class, TRUE, className, teamObjSet, mfail)

#define GetAllAccessibleTeams(className, teamName, teamSet, mfail) \
        _GetAllAccessibleTeams(className, FALSE, className, teamName, teamSet, mfail)
#define GetAllAccessibleTeamsAtParent(_class, className, teamName, teamSet, mfail) \
        _GetAllAccessibleTeams(_class, TRUE, className, teamName, teamSet, mfail)

#define GetAllParentFolderInt(folder, parentFolders, mfail) \
        _GetAllParentFolderIntAtClass(NULL, FALSE, folder, parentFolders, mfail)
#define GetAllParentFolderIntAtClass(class, folder, parentFolders, mfail) \
        _GetAllParentFolderIntAtClass(class, FALSE, folder, parentFolders, mfail)
#define GetAllParentFolderIntAtParent(class, folder, parentFolders, mfail) \
        _GetAllParentFolderIntAtClass(class, TRUE, folder, parentFolders, mfail)

#define GetAllPreviousVersExt(thisObj, preds, mfail) \
        _GetAllPreviousVersExtAtClass(NULL, FALSE, thisObj, preds, mfail)
#define GetAllPreviousVersExtAtClass(class, thisObj, preds, mfail) \
        _GetAllPreviousVersExtAtClass(class, FALSE, thisObj, preds, mfail)
#define GetAllPreviousVersExtAtParent(class, thisObj, preds, mfail) \
        _GetAllPreviousVersExtAtClass(class, TRUE, thisObj, preds, mfail)

#define GetAllPreviousVersions(thisObj, preds, mfail) \
        _GetAllPreviousVersionsAtClass(NULL, FALSE, thisObj, preds, mfail)
#define GetAllPreviousVersionsAtClass(class, thisObj, preds, mfail) \
        _GetAllPreviousVersionsAtClass(class, FALSE, thisObj, preds, mfail)
#define GetAllPreviousVersionsAtParent(class, thisObj, preds, mfail) \
        _GetAllPreviousVersionsAtClass(class, TRUE, thisObj, preds, mfail)

#define GetAllShareTeams(className, teamName, teamSet, mfail) \
        _GetAllShareTeams(className, FALSE, className, teamName, teamSet, mfail)
#define GetAllShareTeamsAtParent(_class, className, teamName, teamSet, mfail) \
        _GetAllShareTeams(_class, TRUE, className, teamName, teamSet, mfail)

#define GetAllShrGttByTmName(className, teamName, gttObjSet, mfail) \
        _GetAllShrGttByTmName(className, FALSE, className, teamName, gttObjSet, mfail)
#define GetAllShrGttByTmNameAtParent(_class, className, teamName, gttObjSet, mfail) \
        _GetAllShrGttByTmName(_class, TRUE, className, teamName, gttObjSet, mfail)

#define GetAllTeamMembers(className, teamName, memberSet, mfail) \
        _GetAllTeamMembers(className, FALSE, className, teamName, memberSet, mfail)
#define GetAllTeamMembersAtParent(_class, className, teamName, memberSet, mfail) \
        _GetAllTeamMembers(_class, TRUE, className, teamName, memberSet, mfail)

#define GetAllTeamsForSesUser(className, teamObjSet, mfail) \
        _GetAllTeamsForSesUser(className, FALSE, className, teamObjSet, mfail)
#define GetAllTeamsForSesUserAtParent(_class, className, teamObjSet, mfail) \
        _GetAllTeamsForSesUser(_class, TRUE, className, teamObjSet, mfail)

#define GetAllTeamsForUserName(className, userName, teamSet, mfail) \
        _GetAllTeamsForUserName(className, FALSE, className, userName, teamSet, mfail)
#define GetAllTeamsForUserNameAtParent(_class, className, userName, teamSet, mfail) \
        _GetAllTeamsForUserName(_class, TRUE, className, userName, teamSet, mfail)

#define GetAllTmRlsForUsrInTm(className, usrName, teamName, indirectTeam, tmRoleSet, mfail) \
        _GetAllTmRlsForUsrInTm(className, FALSE, className, usrName, teamName, indirectTeam, tmRoleSet, mfail)
#define GetAllTmRlsForUsrInTmAtParent(_class, className, usrName, teamName, indirectTeam, tmRoleSet, mfail) \
        _GetAllTmRlsForUsrInTm(_class, TRUE, className, usrName, teamName, indirectTeam, tmRoleSet, mfail)

#define GetAllTraForUsrInTm(className, usrName, teamName, indirectTeam, traObj, mfail) \
        _GetAllTraForUsrInTm(className, FALSE, className, usrName, teamName, indirectTeam, traObj, mfail)
#define GetAllTraForUsrInTmAtParent(_class, className, usrName, teamName, indirectTeam, traObj, mfail) \
        _GetAllTraForUsrInTm(_class, TRUE, className, usrName, teamName, indirectTeam, traObj, mfail)

#define GetAllUstByTeamName(className, teamName, ustObjSet, mfail) \
        _GetAllUstByTeamName(className, FALSE, className, teamName, ustObjSet, mfail)
#define GetAllUstByTeamNameAtParent(_class, className, teamName, ustObjSet, mfail) \
        _GetAllUstByTeamName(_class, TRUE, className, teamName, ustObjSet, mfail)

#define GetAllUstByUserName(className, userName, ustObjSet, mfail) \
        _GetAllUstByUserName(className, FALSE, className, userName, ustObjSet, mfail)
#define GetAllUstByUserNameAtParent(_class, className, userName, ustObjSet, mfail) \
        _GetAllUstByUserName(_class, TRUE, className, userName, ustObjSet, mfail)

#define GetAnyCkoTeamRPred(thisObj, pred, mfail) \
        _GetAnyCkoTeamRPredAtClass(NULL, FALSE, thisObj, pred, mfail)
#define GetAnyCkoTeamRPredAtClass(class, thisObj, pred, mfail) \
        _GetAnyCkoTeamRPredAtClass(class, FALSE, thisObj, pred, mfail)
#define GetAnyCkoTeamRPredAtParent(class, thisObj, pred, mfail) \
        _GetAnyCkoTeamRPredAtClass(class, TRUE, thisObj, pred, mfail)

#define GetCitPredFrmSucc(thisObj, pred, mfail) \
        _GetCitPredFrmSuccAtClass(NULL, FALSE, thisObj, pred, mfail)
#define GetCitPredFrmSuccAtClass(class, thisObj, pred, mfail) \
        _GetCitPredFrmSuccAtClass(class, FALSE, thisObj, pred, mfail)
#define GetCitPredFrmSuccAtParent(class, thisObj, pred, mfail) \
        _GetCitPredFrmSuccAtClass(class, TRUE, thisObj, pred, mfail)

#define GetCkiTeamRPredFrmSucc(thisObj, pred, mfail) \
        _GetCkiTeamRPredFrmSuccAtClass(NULL, FALSE, thisObj, pred, mfail)
#define GetCkiTeamRPredFrmSuccAtClass(class, thisObj, pred, mfail) \
        _GetCkiTeamRPredFrmSuccAtClass(class, FALSE, thisObj, pred, mfail)
#define GetCkiTeamRPredFrmSuccAtParent(class, thisObj, pred, mfail) \
        _GetCkiTeamRPredFrmSuccAtClass(class, TRUE, thisObj, pred, mfail)

#define GetCkoRPredFrmSuccTeam(thisObj, pred, mfail) \
        _GetCkoRPredFrmSuccTeamAtClass(NULL, FALSE, thisObj, pred, mfail)
#define GetCkoRPredFrmSuccTeamAtClass(class, thisObj, pred, mfail) \
        _GetCkoRPredFrmSuccTeamAtClass(class, FALSE, thisObj, pred, mfail)
#define GetCkoRPredFrmSuccTeamAtParent(class, thisObj, pred, mfail) \
        _GetCkoRPredFrmSuccTeamAtClass(class, TRUE, thisObj, pred, mfail)

#define GetCkoRSuccFrmPredTeam(thisObj, succ, mfail) \
        _GetCkoRSuccFrmPredTeamAtClass(NULL, FALSE, thisObj, succ, mfail)
#define GetCkoRSuccFrmPredTeamAtClass(class, thisObj, succ, mfail) \
        _GetCkoRSuccFrmPredTeamAtClass(class, FALSE, thisObj, succ, mfail)
#define GetCkoRSuccFrmPredTeamAtParent(class, thisObj, succ, mfail) \
        _GetCkoRSuccFrmPredTeamAtClass(class, TRUE, thisObj, succ, mfail)

#define GetConditionState(className, objToProc, condName, state, mfail) \
        _GetConditionState(className, FALSE, className, objToProc, condName, state, mfail)
#define GetConditionStateAtParent(_class, className, objToProc, condName, state, mfail) \
        _GetConditionState(_class, TRUE, className, objToProc, condName, state, mfail)

#define GetCtrlTeamFolder(thisObj, folderObj, mfail) \
        _GetCtrlTeamFolderAtClass(NULL, FALSE, thisObj, folderObj, mfail)
#define GetCtrlTeamFolderAtClass(class, thisObj, folderObj, mfail) \
        _GetCtrlTeamFolderAtClass(class, FALSE, thisObj, folderObj, mfail)
#define GetCtrlTeamFolderAtParent(class, thisObj, folderObj, mfail) \
        _GetCtrlTeamFolderAtClass(class, TRUE, thisObj, folderObj, mfail)

#define GetCtrlTeamFolderInt(className, objects, forceRefresh, folders, mfail) \
        _GetCtrlTeamFolderInt(className, FALSE, className, objects, forceRefresh, folders, mfail)
#define GetCtrlTeamFolderIntAtParent(_class, className, objects, forceRefresh, folders, mfail) \
        _GetCtrlTeamFolderInt(_class, TRUE, className, objects, forceRefresh, folders, mfail)

#define GetCtrlTeamFolderSet(className, objects, folders, mfail) \
        _GetCtrlTeamFolderSet(className, FALSE, className, objects, folders, mfail)
#define GetCtrlTeamFolderSetAtParent(_class, className, objects, folders, mfail) \
        _GetCtrlTeamFolderSet(_class, TRUE, className, objects, folders, mfail)

#define GetCurrentTeamFldrs(thisObj, folderObjSet, folderItemRelSet, mfail) \
        _GetCurrentTeamFldrsAtClass(NULL, FALSE, thisObj, folderObjSet, folderItemRelSet, mfail)
#define GetCurrentTeamFldrsAtClass(class, thisObj, folderObjSet, folderItemRelSet, mfail) \
        _GetCurrentTeamFldrsAtClass(class, FALSE, thisObj, folderObjSet, folderItemRelSet, mfail)
#define GetCurrentTeamFldrsAtParent(class, thisObj, folderObjSet, folderItemRelSet, mfail) \
        _GetCurrentTeamFldrsAtClass(class, TRUE, thisObj, folderObjSet, folderItemRelSet, mfail)

#define GetDfltRole(className, teamName, dfltRole, mfail) \
        _GetDfltRole(className, FALSE, className, teamName, dfltRole, mfail)
#define GetDfltRoleAtParent(_class, className, teamName, dfltRole, mfail) \
        _GetDfltRole(_class, TRUE, className, teamName, dfltRole, mfail)

#define GetDfltShrTmRole(className, teamName, dfltShrTmRole, mfail) \
        _GetDfltShrTmRole(className, FALSE, className, teamName, dfltShrTmRole, mfail)
#define GetDfltShrTmRoleAtParent(_class, className, teamName, dfltShrTmRole, mfail) \
        _GetDfltShrTmRole(_class, TRUE, className, teamName, dfltShrTmRole, mfail)

#define GetFolder(workItem, folder, mfail) \
        _GetFolderAtClass(NULL, FALSE, workItem, folder, mfail)
#define GetFolderAtClass(class, workItem, folder, mfail) \
        _GetFolderAtClass(class, FALSE, workItem, folder, mfail)
#define GetFolderAtParent(class, workItem, folder, mfail) \
        _GetFolderAtClass(class, TRUE, workItem, folder, mfail)

#define GetFolderCanonicalPath(folder, path, mfail) \
        _GetFolderCanonicalPathAtClass(NULL, FALSE, folder, path, mfail)
#define GetFolderCanonicalPathAtClass(class, folder, path, mfail) \
        _GetFolderCanonicalPathAtClass(class, FALSE, folder, path, mfail)
#define GetFolderCanonicalPathAtParent(class, folder, path, mfail) \
        _GetFolderCanonicalPathAtClass(class, TRUE, folder, path, mfail)

#define GetFolderContents(itemObj, latest, available, folderContents, mfail) \
        _GetFolderContentsAtClass(NULL, FALSE, itemObj, latest, available, folderContents, mfail)
#define GetFolderContentsAtClass(class, itemObj, latest, available, folderContents, mfail) \
        _GetFolderContentsAtClass(class, FALSE, itemObj, latest, available, folderContents, mfail)
#define GetFolderContentsAtParent(class, itemObj, latest, available, folderContents, mfail) \
        _GetFolderContentsAtClass(class, TRUE, itemObj, latest, available, folderContents, mfail)

#define GetFolderContentsD(itemObj, latest, available, folderContents, mfail) \
        _GetFolderContentsDAtClass(NULL, FALSE, itemObj, latest, available, folderContents, mfail)
#define GetFolderContentsDAtClass(class, itemObj, latest, available, folderContents, mfail) \
        _GetFolderContentsDAtClass(class, FALSE, itemObj, latest, available, folderContents, mfail)
#define GetFolderContentsDAtParent(class, itemObj, latest, available, folderContents, mfail) \
        _GetFolderContentsDAtClass(class, TRUE, itemObj, latest, available, folderContents, mfail)

#define GetFolderContentsExcl(itemObj, excludeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsExclAtClass(NULL, FALSE, itemObj, excludeClasses, latest, available, folderContents, mfail)
#define GetFolderContentsExclAtClass(class, itemObj, excludeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsExclAtClass(class, FALSE, itemObj, excludeClasses, latest, available, folderContents, mfail)
#define GetFolderContentsExclAtParent(class, itemObj, excludeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsExclAtClass(class, TRUE, itemObj, excludeClasses, latest, available, folderContents, mfail)

#define GetFolderContentsExclD(itemObj, excludeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsExclDAtClass(NULL, FALSE, itemObj, excludeClasses, latest, available, folderContents, mfail)
#define GetFolderContentsExclDAtClass(class, itemObj, excludeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsExclDAtClass(class, FALSE, itemObj, excludeClasses, latest, available, folderContents, mfail)
#define GetFolderContentsExclDAtParent(class, itemObj, excludeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsExclDAtClass(class, TRUE, itemObj, excludeClasses, latest, available, folderContents, mfail)

#define GetFolderContentsIncl(itemObj, includeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsInclAtClass(NULL, FALSE, itemObj, includeClasses, latest, available, folderContents, mfail)
#define GetFolderContentsInclAtClass(class, itemObj, includeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsInclAtClass(class, FALSE, itemObj, includeClasses, latest, available, folderContents, mfail)
#define GetFolderContentsInclAtParent(class, itemObj, includeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsInclAtClass(class, TRUE, itemObj, includeClasses, latest, available, folderContents, mfail)

#define GetFolderContentsInclD(itemObj, includeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsInclDAtClass(NULL, FALSE, itemObj, includeClasses, latest, available, folderContents, mfail)
#define GetFolderContentsInclDAtClass(class, itemObj, includeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsInclDAtClass(class, FALSE, itemObj, includeClasses, latest, available, folderContents, mfail)
#define GetFolderContentsInclDAtParent(class, itemObj, includeClasses, latest, available, folderContents, mfail) \
        _GetFolderContentsInclDAtClass(class, TRUE, itemObj, includeClasses, latest, available, folderContents, mfail)

#define GetFolderContentsInt(itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail) \
        _GetFolderContentsIntAtClass(NULL, FALSE, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail)
#define GetFolderContentsIntAtClass(class, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail) \
        _GetFolderContentsIntAtClass(class, FALSE, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail)
#define GetFolderContentsIntAtParent(class, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail) \
        _GetFolderContentsIntAtClass(class, TRUE, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail)

#define GetFolderContentsInt3(itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail) \
        _GetFolderContentsInt3AtClass(NULL, FALSE, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail)
#define GetFolderContentsInt3AtClass(class, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail) \
        _GetFolderContentsInt3AtClass(class, FALSE, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail)
#define GetFolderContentsInt3AtParent(class, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail) \
        _GetFolderContentsInt3AtClass(class, TRUE, itemObj, includeClasses, excludeClasses, latest, available, newWindow, folderContents, mfail)

#define GetFolderCtsFilterPre(itemObj, includeClasses, excludeClasses, latest, available, otherSideObjSet, relObjSet, mfail) \
        _GetFolderCtsFilterPreAtClass(NULL, FALSE, itemObj, includeClasses, excludeClasses, latest, available, otherSideObjSet, relObjSet, mfail)
#define GetFolderCtsFilterPreAtClass(class, itemObj, includeClasses, excludeClasses, latest, available, otherSideObjSet, relObjSet, mfail) \
        _GetFolderCtsFilterPreAtClass(class, FALSE, itemObj, includeClasses, excludeClasses, latest, available, otherSideObjSet, relObjSet, mfail)
#define GetFolderCtsFilterPreAtParent(class, itemObj, includeClasses, excludeClasses, latest, available, otherSideObjSet, relObjSet, mfail) \
        _GetFolderCtsFilterPreAtClass(class, TRUE, itemObj, includeClasses, excludeClasses, latest, available, otherSideObjSet, relObjSet, mfail)

#define GetFolderFilteredItems(itemObj, origFolderContents, latest, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _GetFolderFilteredItemsAtClass(NULL, FALSE, itemObj, origFolderContents, latest, currentObj, workingFolderContents, filteredFolderContents, mfail)
#define GetFolderFilteredItemsAtClass(class, itemObj, origFolderContents, latest, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _GetFolderFilteredItemsAtClass(class, FALSE, itemObj, origFolderContents, latest, currentObj, workingFolderContents, filteredFolderContents, mfail)
#define GetFolderFilteredItemsAtParent(class, itemObj, origFolderContents, latest, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _GetFolderFilteredItemsAtClass(class, TRUE, itemObj, origFolderContents, latest, currentObj, workingFolderContents, filteredFolderContents, mfail)

#define GetLatest(itemObj, origContentSet, available, latestObj, mfail) \
        _GetLatestAtClass(NULL, FALSE, itemObj, origContentSet, available, latestObj, mfail)
#define GetLatestAtClass(class, itemObj, origContentSet, available, latestObj, mfail) \
        _GetLatestAtClass(class, FALSE, itemObj, origContentSet, available, latestObj, mfail)
#define GetLatestAtParent(class, itemObj, origContentSet, available, latestObj, mfail) \
        _GetLatestAtClass(class, TRUE, itemObj, origContentSet, available, latestObj, mfail)

#define GetOwnerDatabase(className, ownerName, ownerDbName, mfail) \
        _GetOwnerDatabase(className, FALSE, className, ownerName, ownerDbName, mfail)
#define GetOwnerDatabaseAtParent(_class, className, ownerName, ownerDbName, mfail) \
        _GetOwnerDatabase(_class, TRUE, className, ownerName, ownerDbName, mfail)

#define GetParentFolders(folder, parentFolders, mfail) \
        _GetParentFoldersAtClass(NULL, FALSE, folder, parentFolders, mfail)
#define GetParentFoldersAtClass(class, folder, parentFolders, mfail) \
        _GetParentFoldersAtClass(class, FALSE, folder, parentFolders, mfail)
#define GetParentFoldersAtParent(class, folder, parentFolders, mfail) \
        _GetParentFoldersAtClass(class, TRUE, folder, parentFolders, mfail)

#define GetParentFoldersInt(itemObj, parentFolders, mfail) \
        _GetParentFoldersIntAtClass(NULL, FALSE, itemObj, parentFolders, mfail)
#define GetParentFoldersIntAtClass(class, itemObj, parentFolders, mfail) \
        _GetParentFoldersIntAtClass(class, FALSE, itemObj, parentFolders, mfail)
#define GetParentFoldersIntAtParent(class, itemObj, parentFolders, mfail) \
        _GetParentFoldersIntAtClass(class, TRUE, itemObj, parentFolders, mfail)

#define GetRelatedForRelease(workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _GetRelatedForReleaseAtClass(NULL, FALSE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)
#define GetRelatedForReleaseAtClass(class, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _GetRelatedForReleaseAtClass(class, FALSE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)
#define GetRelatedForReleaseAtParent(class, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _GetRelatedForReleaseAtClass(class, TRUE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)

#define GetReleaseMode(thisObj, ckiMode, mfail) \
        _GetReleaseModeAtClass(NULL, FALSE, thisObj, ckiMode, mfail)
#define GetReleaseModeAtClass(class, thisObj, ckiMode, mfail) \
        _GetReleaseModeAtClass(class, FALSE, thisObj, ckiMode, mfail)
#define GetReleaseModeAtParent(class, thisObj, ckiMode, mfail) \
        _GetReleaseModeAtClass(class, TRUE, thisObj, ckiMode, mfail)

#define GetSetFolderLatestItem(itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _GetSetFolderLatestItemAtClass(NULL, FALSE, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail)
#define GetSetFolderLatestItemAtClass(class, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _GetSetFolderLatestItemAtClass(class, FALSE, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail)
#define GetSetFolderLatestItemAtParent(class, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail) \
        _GetSetFolderLatestItemAtClass(class, TRUE, itemObj, relObj, origFolderContents, folder, latest, available, currentObj, workingFolderContents, filteredFolderContents, mfail)

#define GetSubFolders(tmFolderClass, tmFolderName, ownerNm, subFolders, mfail) \
        _GetSubFolders(tmFolderClass, FALSE, tmFolderClass, tmFolderName, ownerNm, subFolders, mfail)
#define GetSubFoldersAtParent(_class, tmFolderClass, tmFolderName, ownerNm, subFolders, mfail) \
        _GetSubFolders(_class, TRUE, tmFolderClass, tmFolderName, ownerNm, subFolders, mfail)

#define GetSuccForDoPrgSeq(thisObj, tempObj, succ, mfail) \
        _GetSuccForDoPrgSeqAtClass(NULL, FALSE, thisObj, tempObj, succ, mfail)
#define GetSuccForDoPrgSeqAtClass(class, thisObj, tempObj, succ, mfail) \
        _GetSuccForDoPrgSeqAtClass(class, FALSE, thisObj, tempObj, succ, mfail)
#define GetSuccForDoPrgSeqAtParent(class, thisObj, tempObj, succ, mfail) \
        _GetSuccForDoPrgSeqAtClass(class, TRUE, thisObj, tempObj, succ, mfail)

#define GetSuccForPrgSequence(thisObj, succ, mfail) \
        _GetSuccForPrgSequenceAtClass(NULL, FALSE, thisObj, succ, mfail)
#define GetSuccForPrgSequenceAtClass(class, thisObj, succ, mfail) \
        _GetSuccForPrgSequenceAtClass(class, FALSE, thisObj, succ, mfail)
#define GetSuccForPrgSequenceAtParent(class, thisObj, succ, mfail) \
        _GetSuccForPrgSequenceAtClass(class, TRUE, thisObj, succ, mfail)

#define GetTeamFolders(thisObj, folderObjSet, isCtrlTmFldr, mfail) \
        _GetTeamFoldersAtClass(NULL, FALSE, thisObj, folderObjSet, isCtrlTmFldr, mfail)
#define GetTeamFoldersAtClass(class, thisObj, folderObjSet, isCtrlTmFldr, mfail) \
        _GetTeamFoldersAtClass(class, FALSE, thisObj, folderObjSet, isCtrlTmFldr, mfail)
#define GetTeamFoldersAtParent(class, thisObj, folderObjSet, isCtrlTmFldr, mfail) \
        _GetTeamFoldersAtClass(class, TRUE, thisObj, folderObjSet, isCtrlTmFldr, mfail)

#define GetTmCkiCkoSuccessor(thisObj, successorObj, mfail) \
        _GetTmCkiCkoSuccessorAtClass(NULL, FALSE, thisObj, successorObj, mfail)
#define GetTmCkiCkoSuccessorAtClass(class, thisObj, successorObj, mfail) \
        _GetTmCkiCkoSuccessorAtClass(class, FALSE, thisObj, successorObj, mfail)
#define GetTmCkiCkoSuccessorAtParent(class, thisObj, successorObj, mfail) \
        _GetTmCkiCkoSuccessorAtClass(class, TRUE, thisObj, successorObj, mfail)

#define GetTmCkiCkoSuccessorExt(thisObj, successorObj, mfail) \
        _GetTmCkiCkoSuccessorExtAtClass(NULL, FALSE, thisObj, successorObj, mfail)
#define GetTmCkiCkoSuccessorExtAtClass(class, thisObj, successorObj, mfail) \
        _GetTmCkiCkoSuccessorExtAtClass(class, FALSE, thisObj, successorObj, mfail)
#define GetTmCkiCkoSuccessorExtAtParent(class, thisObj, successorObj, mfail) \
        _GetTmCkiCkoSuccessorExtAtClass(class, TRUE, thisObj, successorObj, mfail)

#define GetTmRoleUsrGrp(className, teamRole, tmRoleUsrGrp, mfail) \
        _GetTmRoleUsrGrp(className, FALSE, className, teamRole, tmRoleUsrGrp, mfail)
#define GetTmRoleUsrGrpAtParent(_class, className, teamRole, tmRoleUsrGrp, mfail) \
        _GetTmRoleUsrGrp(_class, TRUE, className, teamRole, tmRoleUsrGrp, mfail)

#define GetTmdByTeamName(className, teamName, tmDfltObj, mfail) \
        _GetTmdByTeamName(className, FALSE, className, teamName, tmDfltObj, mfail)
#define GetTmdByTeamNameAtParent(_class, className, teamName, tmDfltObj, mfail) \
        _GetTmdByTeamName(_class, TRUE, className, teamName, tmDfltObj, mfail)

#define GetTmrByTeamRole(className, teamRole, tmRoleObj, mfail) \
        _GetTmrByTeamRole(className, FALSE, className, teamRole, tmRoleObj, mfail)
#define GetTmrByTeamRoleAtParent(_class, className, teamRole, tmRoleObj, mfail) \
        _GetTmrByTeamRole(_class, TRUE, className, teamRole, tmRoleObj, mfail)

#define GetTopLevelFolders(teamObj, folders, mfail) \
        _GetTopLevelFoldersAtClass(NULL, FALSE, teamObj, folders, mfail)
#define GetTopLevelFoldersAtClass(class, teamObj, folders, mfail) \
        _GetTopLevelFoldersAtClass(class, FALSE, teamObj, folders, mfail)
#define GetTopLevelFoldersAtParent(class, teamObj, folders, mfail) \
        _GetTopLevelFoldersAtClass(class, TRUE, teamObj, folders, mfail)

#define GetUserRoles(user, team, setOfRoles, mfail) \
        _GetUserRolesAtClass(NULL, FALSE, user, team, setOfRoles, mfail)
#define GetUserRolesAtClass(class, user, team, setOfRoles, mfail) \
        _GetUserRolesAtClass(class, FALSE, user, team, setOfRoles, mfail)
#define GetUserRolesAtParent(class, user, team, setOfRoles, mfail) \
        _GetUserRolesAtClass(class, TRUE, user, team, setOfRoles, mfail)

#define GetUsrToTmCkiMode(thisObj, ckiMode, mfail) \
        _GetUsrToTmCkiModeAtClass(NULL, FALSE, thisObj, ckiMode, mfail)
#define GetUsrToTmCkiModeAtClass(class, thisObj, ckiMode, mfail) \
        _GetUsrToTmCkiModeAtClass(class, FALSE, thisObj, ckiMode, mfail)
#define GetUsrToTmCkiModeAtParent(class, thisObj, ckiMode, mfail) \
        _GetUsrToTmCkiModeAtClass(class, TRUE, thisObj, ckiMode, mfail)

#define InflateObtained(thisObj, mfail) \
        _InflateObtainedAtClass(NULL, FALSE, thisObj, mfail)
#define InflateObtainedAtClass(class, thisObj, mfail) \
        _InflateObtainedAtClass(class, FALSE, thisObj, mfail)
#define InflateObtainedAtParent(class, thisObj, mfail) \
        _InflateObtainedAtClass(class, TRUE, thisObj, mfail)

#define InflateQuestionable(thisObj, relObj, mfail) \
        _InflateQuestionableAtClass(NULL, FALSE, thisObj, relObj, mfail)
#define InflateQuestionableAtClass(class, thisObj, relObj, mfail) \
        _InflateQuestionableAtClass(class, FALSE, thisObj, relObj, mfail)
#define InflateQuestionableAtParent(class, thisObj, relObj, mfail) \
        _InflateQuestionableAtClass(class, TRUE, thisObj, relObj, mfail)

#define InitCheckedOutMetaTeam(thisObj, source, target, mfail) \
        _InitCheckedOutMetaTeamAtClass(NULL, FALSE, thisObj, source, target, mfail)
#define InitCheckedOutMetaTeamAtClass(class, thisObj, source, target, mfail) \
        _InitCheckedOutMetaTeamAtClass(class, FALSE, thisObj, source, target, mfail)
#define InitCheckedOutMetaTeamAtParent(class, thisObj, source, target, mfail) \
        _InitCheckedOutMetaTeamAtClass(class, TRUE, thisObj, source, target, mfail)

#define InitCheckedOutTMeta(thisObj, source, target, mfail) \
        _InitCheckedOutTMetaAtClass(NULL, FALSE, thisObj, source, target, mfail)
#define InitCheckedOutTMetaAtClass(class, thisObj, source, target, mfail) \
        _InitCheckedOutTMetaAtClass(class, FALSE, thisObj, source, target, mfail)
#define InitCheckedOutTMetaAtParent(class, thisObj, source, target, mfail) \
        _InitCheckedOutTMetaAtClass(class, TRUE, thisObj, source, target, mfail)

#define InitCkoMkvMetaTeam(thisObj, source, target, mfail) \
        _InitCkoMkvMetaTeamAtClass(NULL, FALSE, thisObj, source, target, mfail)
#define InitCkoMkvMetaTeamAtClass(class, thisObj, source, target, mfail) \
        _InitCkoMkvMetaTeamAtClass(class, FALSE, thisObj, source, target, mfail)
#define InitCkoMkvMetaTeamAtParent(class, thisObj, source, target, mfail) \
        _InitCkoMkvMetaTeamAtClass(class, TRUE, thisObj, source, target, mfail)

#define InitMergeDialog(mrgDialog, mfail) \
        _InitMergeDialogAtClass(NULL, FALSE, mrgDialog, mfail)
#define InitMergeDialogAtClass(class, mrgDialog, mfail) \
        _InitMergeDialogAtClass(class, FALSE, mrgDialog, mfail)
#define InitMergeDialogAtParent(class, mrgDialog, mfail) \
        _InitMergeDialogAtClass(class, TRUE, mrgDialog, mfail)

#define InitMetaForMerge(newItem, creDialog, mfail) \
        _InitMetaForMergeAtClass(NULL, FALSE, newItem, creDialog, mfail)
#define InitMetaForMergeAtClass(class, newItem, creDialog, mfail) \
        _InitMetaForMergeAtClass(class, FALSE, newItem, creDialog, mfail)
#define InitMetaForMergeAtParent(class, newItem, creDialog, mfail) \
        _InitMetaForMergeAtClass(class, TRUE, newItem, creDialog, mfail)

#define InitMrgDlgSetSeqVer(mrgDialog, mfail) \
        _InitMrgDlgSetSeqVerAtClass(NULL, FALSE, mrgDialog, mfail)
#define InitMrgDlgSetSeqVerAtClass(class, mrgDialog, mfail) \
        _InitMrgDlgSetSeqVerAtClass(class, FALSE, mrgDialog, mfail)
#define InitMrgDlgSetSeqVerAtParent(class, mrgDialog, mfail) \
        _InitMrgDlgSetSeqVerAtClass(class, TRUE, mrgDialog, mfail)

#define InitReserveDialog(rsvArgObject, rsvItem, mfail) \
        _InitReserveDialogAtClass(NULL, FALSE, rsvArgObject, rsvItem, mfail)
#define InitReserveDialogAtClass(class, rsvArgObject, rsvItem, mfail) \
        _InitReserveDialogAtClass(class, FALSE, rsvArgObject, rsvItem, mfail)
#define InitReserveDialogAtParent(class, rsvArgObject, rsvItem, mfail) \
        _InitReserveDialogAtClass(class, TRUE, rsvArgObject, rsvItem, mfail)

#define InsVersItemPost(insertObj, predObj, succObj, mfail) \
        _InsVersItemPostAtClass(NULL, FALSE, insertObj, predObj, succObj, mfail)
#define InsVersItemPostAtClass(class, insertObj, predObj, succObj, mfail) \
        _InsVersItemPostAtClass(class, FALSE, insertObj, predObj, succObj, mfail)
#define InsVersItemPostAtParent(class, insertObj, predObj, succObj, mfail) \
        _InsVersItemPostAtClass(class, TRUE, insertObj, predObj, succObj, mfail)

#define InsVersItemSetPostInt(workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _InsVersItemSetPostInt(workItemClass, FALSE, workItemClass, insertObjs, predObjs, succObjs, mfail)
#define InsVersItemSetPostIntAtParent(_class, workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _InsVersItemSetPostInt(_class, TRUE, workItemClass, insertObjs, predObjs, succObjs, mfail)

#define InsertVersionItemSet(workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _InsertVersionItemSet(workItemClass, FALSE, workItemClass, insertObjs, predObjs, succObjs, mfail)
#define InsertVersionItemSetAtParent(_class, workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _InsertVersionItemSet(_class, TRUE, workItemClass, insertObjs, predObjs, succObjs, mfail)

#define InsertVersionTeam(insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail) \
        _InsertVersionTeamAtClass(NULL, FALSE, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail)
#define InsertVersionTeamAtClass(class, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail) \
        _InsertVersionTeamAtClass(class, FALSE, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail)
#define InsertVersionTeamAtParent(class, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail) \
        _InsertVersionTeamAtClass(class, TRUE, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail)

#define InsertVersionVault(insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail) \
        _InsertVersionVaultAtClass(NULL, FALSE, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail)
#define InsertVersionVaultAtClass(class, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail) \
        _InsertVersionVaultAtClass(class, FALSE, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail)
#define InsertVersionVaultAtParent(class, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail) \
        _InsertVersionVaultAtClass(class, TRUE, insertObj, predObj, succObj, insFlags, predFlags, succFlags, mfail)

#define InsertVersnItemSetInt(workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _InsertVersnItemSetInt(workItemClass, FALSE, workItemClass, insertObjs, predObjs, succObjs, mfail)
#define InsertVersnItemSetIntAtParent(_class, workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _InsertVersnItemSetInt(_class, TRUE, workItemClass, insertObjs, predObjs, succObjs, mfail)

#define InsertVersnItemSetPre(workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _InsertVersnItemSetPre(workItemClass, FALSE, workItemClass, insertObjs, predObjs, succObjs, mfail)
#define InsertVersnItemSetPreAtParent(_class, workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _InsertVersnItemSetPre(_class, TRUE, workItemClass, insertObjs, predObjs, succObjs, mfail)

#define IntAddTo(folder, addedItemSet, latest, mfail) \
        _IntAddToAtClass(NULL, FALSE, folder, addedItemSet, latest, mfail)
#define IntAddToAtClass(class, folder, addedItemSet, latest, mfail) \
        _IntAddToAtClass(class, FALSE, folder, addedItemSet, latest, mfail)
#define IntAddToAtParent(class, folder, addedItemSet, latest, mfail) \
        _IntAddToAtClass(class, TRUE, folder, addedItemSet, latest, mfail)

#define IntAddTo2(folder, addedItemSet, latest, mfail) \
        _IntAddTo2AtClass(NULL, FALSE, folder, addedItemSet, latest, mfail)
#define IntAddTo2AtClass(class, folder, addedItemSet, latest, mfail) \
        _IntAddTo2AtClass(class, FALSE, folder, addedItemSet, latest, mfail)
#define IntAddTo2AtParent(class, folder, addedItemSet, latest, mfail) \
        _IntAddTo2AtClass(class, TRUE, folder, addedItemSet, latest, mfail)

#define IntAddToNoVal(folder, addedItemSet, latest, mfail) \
        _IntAddToNoValAtClass(NULL, FALSE, folder, addedItemSet, latest, mfail)
#define IntAddToNoValAtClass(class, folder, addedItemSet, latest, mfail) \
        _IntAddToNoValAtClass(class, FALSE, folder, addedItemSet, latest, mfail)
#define IntAddToNoValAtParent(class, folder, addedItemSet, latest, mfail) \
        _IntAddToNoValAtClass(class, TRUE, folder, addedItemSet, latest, mfail)

#define IntGetLatest(itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatestAtClass(NULL, FALSE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)
#define IntGetLatestAtClass(class, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatestAtClass(class, FALSE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)
#define IntGetLatestAtParent(class, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatestAtClass(class, TRUE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)

#define IntGetLatest2(itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatest2AtClass(NULL, FALSE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)
#define IntGetLatest2AtClass(class, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatest2AtClass(class, FALSE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)
#define IntGetLatest2AtParent(class, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatest2AtClass(class, TRUE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)

#define IntGetLatest3(itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatest3AtClass(NULL, FALSE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)
#define IntGetLatest3AtClass(class, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatest3AtClass(class, FALSE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)
#define IntGetLatest3AtParent(class, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail) \
        _IntGetLatest3AtClass(class, TRUE, itemObj, latestObj, workingContentsSet, origContentSet, available, mfail)

#define IntRemoveFrom(folder, removedItem, mfail) \
        _IntRemoveFromAtClass(NULL, FALSE, folder, removedItem, mfail)
#define IntRemoveFromAtClass(class, folder, removedItem, mfail) \
        _IntRemoveFromAtClass(class, FALSE, folder, removedItem, mfail)
#define IntRemoveFromAtParent(class, folder, removedItem, mfail) \
        _IntRemoveFromAtClass(class, TRUE, folder, removedItem, mfail)

#define IsAvailable(itemObj, contentObj, available, mfail) \
        _IsAvailableAtClass(NULL, FALSE, itemObj, contentObj, available, mfail)
#define IsAvailableAtClass(class, itemObj, contentObj, available, mfail) \
        _IsAvailableAtClass(class, FALSE, itemObj, contentObj, available, mfail)
#define IsAvailableAtParent(class, itemObj, contentObj, available, mfail) \
        _IsAvailableAtClass(class, TRUE, itemObj, contentObj, available, mfail)

#define IsInSetOfClasses(itemObj, setOfClasses, inClasses, mfail) \
        _IsInSetOfClassesAtClass(NULL, FALSE, itemObj, setOfClasses, inClasses, mfail)
#define IsInSetOfClassesAtClass(class, itemObj, setOfClasses, inClasses, mfail) \
        _IsInSetOfClassesAtClass(class, FALSE, itemObj, setOfClasses, inClasses, mfail)
#define IsInSetOfClassesAtParent(class, itemObj, setOfClasses, inClasses, mfail) \
        _IsInSetOfClassesAtClass(class, TRUE, itemObj, setOfClasses, inClasses, mfail)

#define IsPromptSet(className, teamName, answer, mfail) \
        _IsPromptSet(className, FALSE, className, teamName, answer, mfail)
#define IsPromptSetAtParent(_class, className, teamName, answer, mfail) \
        _IsPromptSet(_class, TRUE, className, teamName, answer, mfail)

#define IsReleasable(workitemObj, dialog, allowed, mfail) \
        _IsReleasableAtClass(NULL, FALSE, workitemObj, dialog, allowed, mfail)
#define IsReleasableAtClass(class, workitemObj, dialog, allowed, mfail) \
        _IsReleasableAtClass(class, FALSE, workitemObj, dialog, allowed, mfail)
#define IsReleasableAtParent(class, workitemObj, dialog, allowed, mfail) \
        _IsReleasableAtClass(class, TRUE, workitemObj, dialog, allowed, mfail)

#define IsTeamFldr(thisObj, answer, mfail) \
        _IsTeamFldrAtClass(NULL, FALSE, thisObj, answer, mfail)
#define IsTeamFldrAtClass(class, thisObj, answer, mfail) \
        _IsTeamFldrAtClass(class, FALSE, thisObj, answer, mfail)
#define IsTeamFldrAtParent(class, thisObj, answer, mfail) \
        _IsTeamFldrAtClass(class, TRUE, thisObj, answer, mfail)

#define IsTeamMember(className, userName, teamName, answer, mfail) \
        _IsTeamMember(className, FALSE, className, userName, teamName, answer, mfail)
#define IsTeamMemberAtParent(_class, className, userName, teamName, answer, mfail) \
        _IsTeamMember(_class, TRUE, className, userName, teamName, answer, mfail)

#define ItemCopyInTeam(objToCopy, argumentsObj, newCopiedObj, mfail) \
        _ItemCopyInTeamAtClass(NULL, FALSE, objToCopy, argumentsObj, newCopiedObj, mfail)
#define ItemCopyInTeamAtClass(class, objToCopy, argumentsObj, newCopiedObj, mfail) \
        _ItemCopyInTeamAtClass(class, FALSE, objToCopy, argumentsObj, newCopiedObj, mfail)
#define ItemCopyInTeamAtParent(class, objToCopy, argumentsObj, newCopiedObj, mfail) \
        _ItemCopyInTeamAtClass(class, TRUE, objToCopy, argumentsObj, newCopiedObj, mfail)

#define ListAllTeamObjs(className, teamObjSet, mfail) \
        _ListAllTeamObjs(className, FALSE, className, teamObjSet, mfail)
#define ListAllTeamObjsAtParent(_class, className, teamObjSet, mfail) \
        _ListAllTeamObjs(_class, TRUE, className, teamObjSet, mfail)

#define ListTeams(className, teamNames, mfail) \
        _ListTeams(className, FALSE, className, teamNames, mfail)
#define ListTeamsAtParent(_class, className, teamNames, mfail) \
        _ListTeams(_class, TRUE, className, teamNames, mfail)

#define MakeAvailToNonSecure(thisObj, mfail) \
        _MakeAvailToNonSecureAtClass(NULL, FALSE, thisObj, mfail)
#define MakeAvailToNonSecureAtClass(class, thisObj, mfail) \
        _MakeAvailToNonSecureAtClass(class, FALSE, thisObj, mfail)
#define MakeAvailToNonSecureAtParent(class, thisObj, mfail) \
        _MakeAvailToNonSecureAtClass(class, TRUE, thisObj, mfail)

#define MakeAvailToSecure(thisObj, mfail) \
        _MakeAvailToSecureAtClass(NULL, FALSE, thisObj, mfail)
#define MakeAvailToSecureAtClass(class, thisObj, mfail) \
        _MakeAvailToSecureAtClass(class, FALSE, thisObj, mfail)
#define MakeAvailToSecureAtParent(class, thisObj, mfail) \
        _MakeAvailToSecureAtClass(class, TRUE, thisObj, mfail)

#define MakeShadowCopyFmTmTree(thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail) \
        _MakeShadowCopyFmTmTreeAtClass(NULL, FALSE, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail)
#define MakeShadowCopyFmTmTreeAtClass(class, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail) \
        _MakeShadowCopyFmTmTreeAtClass(class, FALSE, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail)
#define MakeShadowCopyFmTmTreeAtParent(class, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail) \
        _MakeShadowCopyFmTmTreeAtClass(class, TRUE, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail)

#define MakeShadowCopyObjectTm(thisObj, workLocation, updateWindow, shadowObjects, mfail) \
        _MakeShadowCopyObjectTmAtClass(NULL, FALSE, thisObj, workLocation, updateWindow, shadowObjects, mfail)
#define MakeShadowCopyObjectTmAtClass(class, thisObj, workLocation, updateWindow, shadowObjects, mfail) \
        _MakeShadowCopyObjectTmAtClass(class, FALSE, thisObj, workLocation, updateWindow, shadowObjects, mfail)
#define MakeShadowCopyObjectTmAtParent(class, thisObj, workLocation, updateWindow, shadowObjects, mfail) \
        _MakeShadowCopyObjectTmAtClass(class, TRUE, thisObj, workLocation, updateWindow, shadowObjects, mfail)

#define MakeShadowCopyTreeTm(thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail) \
        _MakeShadowCopyTreeTmAtClass(NULL, FALSE, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail)
#define MakeShadowCopyTreeTmAtClass(class, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail) \
        _MakeShadowCopyTreeTmAtClass(class, FALSE, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail)
#define MakeShadowCopyTreeTmAtParent(class, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail) \
        _MakeShadowCopyTreeTmAtClass(class, TRUE, thisObj, extraObj, processObjects, workLocationObj, doRoot, updateWindow, shadowObjects, leafPref, mfail)

#define MakeShadowCpyFromTmObj(thisObj, workLocation, updateWindow, shadowObjects, mfail) \
        _MakeShadowCpyFromTmObjAtClass(NULL, FALSE, thisObj, workLocation, updateWindow, shadowObjects, mfail)
#define MakeShadowCpyFromTmObjAtClass(class, thisObj, workLocation, updateWindow, shadowObjects, mfail) \
        _MakeShadowCpyFromTmObjAtClass(class, FALSE, thisObj, workLocation, updateWindow, shadowObjects, mfail)
#define MakeShadowCpyFromTmObjAtParent(class, thisObj, workLocation, updateWindow, shadowObjects, mfail) \
        _MakeShadowCpyFromTmObjAtClass(class, TRUE, thisObj, workLocation, updateWindow, shadowObjects, mfail)

#define MakeShwCopyFmTmRootObj(thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail) \
        _MakeShwCopyFmTmRootObjAtClass(NULL, FALSE, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail)
#define MakeShwCopyFmTmRootObjAtClass(class, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail) \
        _MakeShwCopyFmTmRootObjAtClass(class, FALSE, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail)
#define MakeShwCopyFmTmRootObjAtParent(class, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail) \
        _MakeShwCopyFmTmRootObjAtClass(class, TRUE, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail)

#define MakeShwCopyRootObjectT(thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail) \
        _MakeShwCopyRootObjectTAtClass(NULL, FALSE, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail)
#define MakeShwCopyRootObjectTAtClass(class, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail) \
        _MakeShwCopyRootObjectTAtClass(class, FALSE, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail)
#define MakeShwCopyRootObjectTAtParent(class, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail) \
        _MakeShwCopyRootObjectTAtClass(class, TRUE, thisObj, workLocationObj, doRoot, updateWindow, shadowObjects, extraObj, mfail)

#define MarkQuestionable(relationObj, mfail) \
        _MarkQuestionableAtClass(NULL, FALSE, relationObj, mfail)
#define MarkQuestionableAtClass(class, relationObj, mfail) \
        _MarkQuestionableAtClass(class, FALSE, relationObj, mfail)
#define MarkQuestionableAtParent(class, relationObj, mfail) \
        _MarkQuestionableAtClass(class, TRUE, relationObj, mfail)

#define MergPrdIntoSccForCirTm(thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdIntoSccForCirTmAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPrdIntoSccForCirTmAtClass(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdIntoSccForCirTmAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPrdIntoSccForCirTmAtParent(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdIntoSccForCirTmAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, mfail)

#define MergPrdSccItmsForCirTm(thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdSccItmsForCirTmAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPrdSccItmsForCirTmAtClass(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdSccItmsForCirTmAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPrdSccItmsForCirTmAtParent(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdSccItmsForCirTmAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, mfail)

#define MergPrdSccRelsForCirTm(thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdSccRelsForCirTmAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPrdSccRelsForCirTmAtClass(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdSccRelsForCirTmAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPrdSccRelsForCirTmAtParent(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPrdSccRelsForCirTmAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, mfail)

#define MergPredIntoSuccForRls(thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPredIntoSuccForRlsAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPredIntoSuccForRlsAtClass(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPredIntoSuccForRlsAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPredIntoSuccForRlsAtParent(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPredIntoSuccForRlsAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, mfail)

#define MergPredSuccItmsForRls(thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPredSuccItmsForRlsAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPredSuccItmsForRlsAtClass(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPredSuccItmsForRlsAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, mfail)
#define MergPredSuccItmsForRlsAtParent(class, thisObj, action, actionCode, pred, isBaseObj, mfail) \
        _MergPredSuccItmsForRlsAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, mfail)

#define Merge(workItemClass, mrgDialogs, uploadInfo, newItems, mfail) \
        _Merge(workItemClass, FALSE, workItemClass, mrgDialogs, uploadInfo, newItems, mfail)
#define MergeAtParent(_class, workItemClass, mrgDialogs, uploadInfo, newItems, mfail) \
        _Merge(_class, TRUE, workItemClass, mrgDialogs, uploadInfo, newItems, mfail)

#define Merge2(workItemClass, mrgDialogs, uploadInfo, mfail) \
        _Merge2(workItemClass, FALSE, workItemClass, mrgDialogs, uploadInfo, mfail)
#define Merge2AtParent(_class, workItemClass, mrgDialogs, uploadInfo, mfail) \
        _Merge2(_class, TRUE, workItemClass, mrgDialogs, uploadInfo, mfail)

#define Merge3(workItemClass, infoDialogC, mrgDialogs, uploadInfo, newItems, mfail) \
        _Merge3(workItemClass, FALSE, workItemClass, infoDialogC, mrgDialogs, uploadInfo, newItems, mfail)
#define Merge3AtParent(_class, workItemClass, infoDialogC, mrgDialogs, uploadInfo, newItems, mfail) \
        _Merge3(_class, TRUE, workItemClass, infoDialogC, mrgDialogs, uploadInfo, newItems, mfail)

#define MergeInsVerSet(workItemClass, mrgDialogs, newItems, mfail) \
        _MergeInsVerSet(workItemClass, FALSE, workItemClass, mrgDialogs, newItems, mfail)
#define MergeInsVerSetAtParent(_class, workItemClass, mrgDialogs, newItems, mfail) \
        _MergeInsVerSet(_class, TRUE, workItemClass, mrgDialogs, newItems, mfail)

#define MergeInt(workItemClass, mrgDialogs, uploadInfo, newItems, mfail) \
        _MergeInt(workItemClass, FALSE, workItemClass, mrgDialogs, uploadInfo, newItems, mfail)
#define MergeIntAtParent(_class, workItemClass, mrgDialogs, uploadInfo, newItems, mfail) \
        _MergeInt(_class, TRUE, workItemClass, mrgDialogs, uploadInfo, newItems, mfail)

#define MergePostItem(mrgDialogs, newItem, uploadInfo, mfail) \
        _MergePostItemAtClass(NULL, FALSE, mrgDialogs, newItem, uploadInfo, mfail)
#define MergePostItemAtClass(class, mrgDialogs, newItem, uploadInfo, mfail) \
        _MergePostItemAtClass(class, FALSE, mrgDialogs, newItem, uploadInfo, mfail)
#define MergePostItemAtParent(class, mrgDialogs, newItem, uploadInfo, mfail) \
        _MergePostItemAtClass(class, TRUE, mrgDialogs, newItem, uploadInfo, mfail)

#define MergePostItemInt(mrgDialogs, newItem, uploadInfo, mfail) \
        _MergePostItemIntAtClass(NULL, FALSE, mrgDialogs, newItem, uploadInfo, mfail)
#define MergePostItemIntAtClass(class, mrgDialogs, newItem, uploadInfo, mfail) \
        _MergePostItemIntAtClass(class, FALSE, mrgDialogs, newItem, uploadInfo, mfail)
#define MergePostItemIntAtParent(class, mrgDialogs, newItem, uploadInfo, mfail) \
        _MergePostItemIntAtClass(class, TRUE, mrgDialogs, newItem, uploadInfo, mfail)

#define MergePostSet(workItemClass, mrgDialogs, newItems, uploadInfo, mfail) \
        _MergePostSet(workItemClass, FALSE, workItemClass, mrgDialogs, newItems, uploadInfo, mfail)
#define MergePostSetAtParent(_class, workItemClass, mrgDialogs, newItems, uploadInfo, mfail) \
        _MergePostSet(_class, TRUE, workItemClass, mrgDialogs, newItems, uploadInfo, mfail)

#define MergePostSet3(workItemClass, infoDialogC, mrgDialogs, newItems, uploadInfo, mfail) \
        _MergePostSet3(workItemClass, FALSE, workItemClass, infoDialogC, mrgDialogs, newItems, uploadInfo, mfail)
#define MergePostSet3AtParent(_class, workItemClass, infoDialogC, mrgDialogs, newItems, uploadInfo, mfail) \
        _MergePostSet3(_class, TRUE, workItemClass, infoDialogC, mrgDialogs, newItems, uploadInfo, mfail)

#define MergePreCreateItem(mrgDialog, mfail) \
        _MergePreCreateItemAtClass(NULL, FALSE, mrgDialog, mfail)
#define MergePreCreateItemAtClass(class, mrgDialog, mfail) \
        _MergePreCreateItemAtClass(class, FALSE, mrgDialog, mfail)
#define MergePreCreateItemAtParent(class, mrgDialog, mfail) \
        _MergePreCreateItemAtClass(class, TRUE, mrgDialog, mfail)

#define MergePreCreateItemInt(mrgDailog, mfail) \
        _MergePreCreateItemIntAtClass(NULL, FALSE, mrgDailog, mfail)
#define MergePreCreateItemIntAtClass(class, mrgDailog, mfail) \
        _MergePreCreateItemIntAtClass(class, FALSE, mrgDailog, mfail)
#define MergePreCreateItemIntAtParent(class, mrgDailog, mfail) \
        _MergePreCreateItemIntAtClass(class, TRUE, mrgDailog, mfail)

#define MergePreCreateSet(workItemClass, mrgDialogs, mfail) \
        _MergePreCreateSet(workItemClass, FALSE, workItemClass, mrgDialogs, mfail)
#define MergePreCreateSetAtParent(_class, workItemClass, mrgDialogs, mfail) \
        _MergePreCreateSet(_class, TRUE, workItemClass, mrgDialogs, mfail)

#define MergePreItem(mrgDialog, newItem, mfail) \
        _MergePreItemAtClass(NULL, FALSE, mrgDialog, newItem, mfail)
#define MergePreItemAtClass(class, mrgDialog, newItem, mfail) \
        _MergePreItemAtClass(class, FALSE, mrgDialog, newItem, mfail)
#define MergePreItemAtParent(class, mrgDialog, newItem, mfail) \
        _MergePreItemAtClass(class, TRUE, mrgDialog, newItem, mfail)

#define MergePreItemInt(mrgDialog, newItem, mfail) \
        _MergePreItemIntAtClass(NULL, FALSE, mrgDialog, newItem, mfail)
#define MergePreItemIntAtClass(class, mrgDialog, newItem, mfail) \
        _MergePreItemIntAtClass(class, FALSE, mrgDialog, newItem, mfail)
#define MergePreItemIntAtParent(class, mrgDialog, newItem, mfail) \
        _MergePreItemIntAtClass(class, TRUE, mrgDialog, newItem, mfail)

#define MergePreSet(workItemClass, mrgDialogs, newItems, mfail) \
        _MergePreSet(workItemClass, FALSE, workItemClass, mrgDialogs, newItems, mfail)
#define MergePreSetAtParent(_class, workItemClass, mrgDialogs, newItems, mfail) \
        _MergePreSet(_class, TRUE, workItemClass, mrgDialogs, newItems, mfail)

#define MergeVersExtractArgs(workItem, argObj, pred, team, teamFldr, userFldr, mfail) \
        _MergeVersExtractArgsAtClass(NULL, FALSE, workItem, argObj, pred, team, teamFldr, userFldr, mfail)
#define MergeVersExtractArgsAtClass(class, workItem, argObj, pred, team, teamFldr, userFldr, mfail) \
        _MergeVersExtractArgsAtClass(class, FALSE, workItem, argObj, pred, team, teamFldr, userFldr, mfail)
#define MergeVersExtractArgsAtParent(class, workItem, argObj, pred, team, teamFldr, userFldr, mfail) \
        _MergeVersExtractArgsAtClass(class, TRUE, workItem, argObj, pred, team, teamFldr, userFldr, mfail)

#define MergeVersSyncArgs(workItem, pred, team, teamFldr, userFldr, argObj, mfail) \
        _MergeVersSyncArgsAtClass(NULL, FALSE, workItem, pred, team, teamFldr, userFldr, argObj, mfail)
#define MergeVersSyncArgsAtClass(class, workItem, pred, team, teamFldr, userFldr, argObj, mfail) \
        _MergeVersSyncArgsAtClass(class, FALSE, workItem, pred, team, teamFldr, userFldr, argObj, mfail)
#define MergeVersSyncArgsAtParent(class, workItem, pred, team, teamFldr, userFldr, argObj, mfail) \
        _MergeVersSyncArgsAtClass(class, TRUE, workItem, pred, team, teamFldr, userFldr, argObj, mfail)

#define MergeVersionInt(workItemClass, argObj, team, teamFldr, userFldr, extraObj, newItem, uploadInfo, mfail) \
        _MergeVersionInt(workItemClass, FALSE, workItemClass, argObj, team, teamFldr, userFldr, extraObj, newItem, uploadInfo, mfail)
#define MergeVersionIntAtParent(_class, workItemClass, argObj, team, teamFldr, userFldr, extraObj, newItem, uploadInfo, mfail) \
        _MergeVersionInt(_class, TRUE, workItemClass, argObj, team, teamFldr, userFldr, extraObj, newItem, uploadInfo, mfail)

#define MergeVersionPost(newObj, argObj, pred, team, uploadInfo, mfail) \
        _MergeVersionPostAtClass(NULL, FALSE, newObj, argObj, pred, team, uploadInfo, mfail)
#define MergeVersionPostAtClass(class, newObj, argObj, pred, team, uploadInfo, mfail) \
        _MergeVersionPostAtClass(class, FALSE, newObj, argObj, pred, team, uploadInfo, mfail)
#define MergeVersionPostAtParent(class, newObj, argObj, pred, team, uploadInfo, mfail) \
        _MergeVersionPostAtClass(class, TRUE, newObj, argObj, pred, team, uploadInfo, mfail)

#define MergeVersionPostInt(newObj, argObj, pred, team, uploadInfo, mfail) \
        _MergeVersionPostIntAtClass(NULL, FALSE, newObj, argObj, pred, team, uploadInfo, mfail)
#define MergeVersionPostIntAtClass(class, newObj, argObj, pred, team, uploadInfo, mfail) \
        _MergeVersionPostIntAtClass(class, FALSE, newObj, argObj, pred, team, uploadInfo, mfail)
#define MergeVersionPostIntAtParent(class, newObj, argObj, pred, team, uploadInfo, mfail) \
        _MergeVersionPostIntAtClass(class, TRUE, newObj, argObj, pred, team, uploadInfo, mfail)

#define MergeVersionPostSet(workItemClass, newObjsList, argObjsList, uploadInfo, mfail) \
        _MergeVersionPostSet(workItemClass, FALSE, workItemClass, newObjsList, argObjsList, uploadInfo, mfail)
#define MergeVersionPostSetAtParent(_class, workItemClass, newObjsList, argObjsList, uploadInfo, mfail) \
        _MergeVersionPostSet(_class, TRUE, workItemClass, newObjsList, argObjsList, uploadInfo, mfail)

#define MergeVersionPre(newObj, argObj, pred, team, mfail) \
        _MergeVersionPreAtClass(NULL, FALSE, newObj, argObj, pred, team, mfail)
#define MergeVersionPreAtClass(class, newObj, argObj, pred, team, mfail) \
        _MergeVersionPreAtClass(class, FALSE, newObj, argObj, pred, team, mfail)
#define MergeVersionPreAtParent(class, newObj, argObj, pred, team, mfail) \
        _MergeVersionPreAtClass(class, TRUE, newObj, argObj, pred, team, mfail)

#define MergeVersionPreInt(newObj, argObj, pred, team, mfail) \
        _MergeVersionPreIntAtClass(NULL, FALSE, newObj, argObj, pred, team, mfail)
#define MergeVersionPreIntAtClass(class, newObj, argObj, pred, team, mfail) \
        _MergeVersionPreIntAtClass(class, FALSE, newObj, argObj, pred, team, mfail)
#define MergeVersionPreIntAtParent(class, newObj, argObj, pred, team, mfail) \
        _MergeVersionPreIntAtClass(class, TRUE, newObj, argObj, pred, team, mfail)

#define MergeVersions2(workItemClass, argsList, uploadInfo, newItemList, failedItems, mfail) \
        _MergeVersions2(workItemClass, FALSE, workItemClass, argsList, uploadInfo, newItemList, failedItems, mfail)
#define MergeVersions2AtParent(_class, workItemClass, argsList, uploadInfo, newItemList, failedItems, mfail) \
        _MergeVersions2(_class, TRUE, workItemClass, argsList, uploadInfo, newItemList, failedItems, mfail)

#define MergeVersionsExpArgs(workItemClass, argObjs, mfail) \
        _MergeVersionsExpArgs(workItemClass, FALSE, workItemClass, argObjs, mfail)
#define MergeVersionsExpArgsAtParent(_class, workItemClass, argObjs, mfail) \
        _MergeVersionsExpArgs(_class, TRUE, workItemClass, argObjs, mfail)

#define MergeVersionsInt2(workItemClass, argsList, uploadInfo, newItemList, failedObjects, mfail) \
        _MergeVersionsInt2(workItemClass, FALSE, workItemClass, argsList, uploadInfo, newItemList, failedObjects, mfail)
#define MergeVersionsInt2AtParent(_class, workItemClass, argsList, uploadInfo, newItemList, failedObjects, mfail) \
        _MergeVersionsInt2(_class, TRUE, workItemClass, argsList, uploadInfo, newItemList, failedObjects, mfail)

#define MergeVersionsPost(workItemClass, argObjs, workItems, uploadInfo, mfail) \
        _MergeVersionsPost(workItemClass, FALSE, workItemClass, argObjs, workItems, uploadInfo, mfail)
#define MergeVersionsPostAtParent(_class, workItemClass, argObjs, workItems, uploadInfo, mfail) \
        _MergeVersionsPost(_class, TRUE, workItemClass, argObjs, workItems, uploadInfo, mfail)

#define MergeVersionsPostInt(workItemClass, argObjs, workItems, uploadInfo, mfail) \
        _MergeVersionsPostInt(workItemClass, FALSE, workItemClass, argObjs, workItems, uploadInfo, mfail)
#define MergeVersionsPostIntAtParent(_class, workItemClass, argObjs, workItems, uploadInfo, mfail) \
        _MergeVersionsPostInt(_class, TRUE, workItemClass, argObjs, workItems, uploadInfo, mfail)

#define MergeVersionsPre(workItemClass, argObjs, workItems, mfail) \
        _MergeVersionsPre(workItemClass, FALSE, workItemClass, argObjs, workItems, mfail)
#define MergeVersionsPreAtParent(_class, workItemClass, argObjs, workItems, mfail) \
        _MergeVersionsPre(_class, TRUE, workItemClass, argObjs, workItems, mfail)

#define MergeVersionsPreInt(workItemClass, argObjs, workItems, mfail) \
        _MergeVersionsPreInt(workItemClass, FALSE, workItemClass, argObjs, workItems, mfail)
#define MergeVersionsPreIntAtParent(_class, workItemClass, argObjs, workItems, mfail) \
        _MergeVersionsPreInt(_class, TRUE, workItemClass, argObjs, workItems, mfail)

#define ModifyRoleOfMbrObject(thisObj, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail) \
        _ModifyRoleOfMbrObjectAtClass(NULL, FALSE, thisObj, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail)
#define ModifyRoleOfMbrObjectAtClass(class, thisObj, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail) \
        _ModifyRoleOfMbrObjectAtClass(class, FALSE, thisObj, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail)
#define ModifyRoleOfMbrObjectAtParent(class, thisObj, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail) \
        _ModifyRoleOfMbrObjectAtClass(class, TRUE, thisObj, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail)

#define ModifyTeamRole(className, usrName, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail) \
        _ModifyTeamRole(className, FALSE, className, usrName, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail)
#define ModifyTeamRoleAtParent(_class, className, usrName, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail) \
        _ModifyTeamRole(_class, TRUE, className, usrName, teamName, oldTeamRoleName, newTeamRoleName, traObj, mfail)

#define MoveFldrToFldrDP(thisObj, mfail) \
        _MoveFldrToFldrDPAtClass(NULL, FALSE, thisObj, mfail)
#define MoveFldrToFldrDPAtClass(class, thisObj, mfail) \
        _MoveFldrToFldrDPAtClass(class, FALSE, thisObj, mfail)
#define MoveFldrToFldrDPAtParent(class, thisObj, mfail) \
        _MoveFldrToFldrDPAtClass(class, TRUE, thisObj, mfail)

#define MoveFldrToFldrInt(thisObj, mfail) \
        _MoveFldrToFldrIntAtClass(NULL, FALSE, thisObj, mfail)
#define MoveFldrToFldrIntAtClass(class, thisObj, mfail) \
        _MoveFldrToFldrIntAtClass(class, FALSE, thisObj, mfail)
#define MoveFldrToFldrIntAtParent(class, thisObj, mfail) \
        _MoveFldrToFldrIntAtClass(class, TRUE, thisObj, mfail)

#define MoveFldrToFldrItem(thisObj, teamName, fromTeamFldr, toTeamFldr, mfail) \
        _MoveFldrToFldrItemAtClass(NULL, FALSE, thisObj, teamName, fromTeamFldr, toTeamFldr, mfail)
#define MoveFldrToFldrItemAtClass(class, thisObj, teamName, fromTeamFldr, toTeamFldr, mfail) \
        _MoveFldrToFldrItemAtClass(class, FALSE, thisObj, teamName, fromTeamFldr, toTeamFldr, mfail)
#define MoveFldrToFldrItemAtParent(class, thisObj, teamName, fromTeamFldr, toTeamFldr, mfail) \
        _MoveFldrToFldrItemAtClass(class, TRUE, thisObj, teamName, fromTeamFldr, toTeamFldr, mfail)

#define MoveFldrToNestedFldr(folder, toFolder, toFolderDialog, mfail) \
        _MoveFldrToNestedFldrAtClass(NULL, FALSE, folder, toFolder, toFolderDialog, mfail)
#define MoveFldrToNestedFldrAtClass(class, folder, toFolder, toFolderDialog, mfail) \
        _MoveFldrToNestedFldrAtClass(class, FALSE, folder, toFolder, toFolderDialog, mfail)
#define MoveFldrToNestedFldrAtParent(class, folder, toFolder, toFolderDialog, mfail) \
        _MoveFldrToNestedFldrAtClass(class, TRUE, folder, toFolder, toFolderDialog, mfail)

#define MoveFldrToNestedFldrIn(folder, toFolder, toFolderDialog, mfail) \
        _MoveFldrToNestedFldrInAtClass(NULL, FALSE, folder, toFolder, toFolderDialog, mfail)
#define MoveFldrToNestedFldrInAtClass(class, folder, toFolder, toFolderDialog, mfail) \
        _MoveFldrToNestedFldrInAtClass(class, FALSE, folder, toFolder, toFolderDialog, mfail)
#define MoveFldrToNestedFldrInAtParent(class, folder, toFolder, toFolderDialog, mfail) \
        _MoveFldrToNestedFldrInAtClass(class, TRUE, folder, toFolder, toFolderDialog, mfail)

#define MrgIncrementSequence(predObj, argObj, mfail) \
        _MrgIncrementSequenceAtClass(NULL, FALSE, predObj, argObj, mfail)
#define MrgIncrementSequenceAtClass(class, predObj, argObj, mfail) \
        _MrgIncrementSequenceAtClass(class, FALSE, predObj, argObj, mfail)
#define MrgIncrementSequenceAtParent(class, predObj, argObj, mfail) \
        _MrgIncrementSequenceAtClass(class, TRUE, predObj, argObj, mfail)

#define MrgPostPrcForReplVault(mrgDialogs, newItem, uploadInfo, mfail) \
        _MrgPostPrcForReplVaultAtClass(NULL, FALSE, mrgDialogs, newItem, uploadInfo, mfail)
#define MrgPostPrcForReplVaultAtClass(class, mrgDialogs, newItem, uploadInfo, mfail) \
        _MrgPostPrcForReplVaultAtClass(class, FALSE, mrgDialogs, newItem, uploadInfo, mfail)
#define MrgPostPrcForReplVaultAtParent(class, mrgDialogs, newItem, uploadInfo, mfail) \
        _MrgPostPrcForReplVaultAtClass(class, TRUE, mrgDialogs, newItem, uploadInfo, mfail)

#define MrgVerAdjMetaPostCre(newObj, argObj, pred, team, mfail) \
        _MrgVerAdjMetaPostCreAtClass(NULL, FALSE, newObj, argObj, pred, team, mfail)
#define MrgVerAdjMetaPostCreAtClass(class, newObj, argObj, pred, team, mfail) \
        _MrgVerAdjMetaPostCreAtClass(class, FALSE, newObj, argObj, pred, team, mfail)
#define MrgVerAdjMetaPostCreAtParent(class, newObj, argObj, pred, team, mfail) \
        _MrgVerAdjMetaPostCreAtClass(class, TRUE, newObj, argObj, pred, team, mfail)

#define MrgVerIncrementVersion(predObj, argObj, mfail) \
        _MrgVerIncrementVersionAtClass(NULL, FALSE, predObj, argObj, mfail)
#define MrgVerIncrementVersionAtClass(class, predObj, argObj, mfail) \
        _MrgVerIncrementVersionAtClass(class, FALSE, predObj, argObj, mfail)
#define MrgVerIncrementVersionAtParent(class, predObj, argObj, mfail) \
        _MrgVerIncrementVersionAtClass(class, TRUE, predObj, argObj, mfail)

#define MrgVerInsertVersionSet(workItemClass, workItemList, argList, mfail) \
        _MrgVerInsertVersionSet(workItemClass, FALSE, workItemClass, workItemList, argList, mfail)
#define MrgVerInsertVersionSetAtParent(_class, workItemClass, workItemList, argList, mfail) \
        _MrgVerInsertVersionSet(_class, TRUE, workItemClass, workItemList, argList, mfail)

#define MrgVerSpecifyCreArg(workItemClass, argObj, altCreClass, altCreObj, mfail) \
        _MrgVerSpecifyCreArg(workItemClass, FALSE, workItemClass, argObj, altCreClass, altCreObj, mfail)
#define MrgVerSpecifyCreArgAtParent(_class, workItemClass, argObj, altCreClass, altCreObj, mfail) \
        _MrgVerSpecifyCreArg(_class, TRUE, workItemClass, argObj, altCreClass, altCreObj, mfail)

#define MrgVersAdjDialogInfo(argObj, pred, mfail) \
        _MrgVersAdjDialogInfoAtClass(NULL, FALSE, argObj, pred, mfail)
#define MrgVersAdjDialogInfoAtClass(class, argObj, pred, mfail) \
        _MrgVersAdjDialogInfoAtClass(class, FALSE, argObj, pred, mfail)
#define MrgVersAdjDialogInfoAtParent(class, argObj, pred, mfail) \
        _MrgVersAdjDialogInfoAtClass(class, TRUE, argObj, pred, mfail)

#define MrgVersAdjDlgPredInfo(argObj, pred, mfail) \
        _MrgVersAdjDlgPredInfoAtClass(NULL, FALSE, argObj, pred, mfail)
#define MrgVersAdjDlgPredInfoAtClass(class, argObj, pred, mfail) \
        _MrgVersAdjDlgPredInfoAtClass(class, FALSE, argObj, pred, mfail)
#define MrgVersAdjDlgPredInfoAtParent(class, argObj, pred, mfail) \
        _MrgVersAdjDlgPredInfoAtClass(class, TRUE, argObj, pred, mfail)

#define MrgVersAdjMetaPostCre(workItemClass, argObjs, workItems, mfail) \
        _MrgVersAdjMetaPostCre(workItemClass, FALSE, workItemClass, argObjs, workItems, mfail)
#define MrgVersAdjMetaPostCreAtParent(_class, workItemClass, argObjs, workItems, mfail) \
        _MrgVersAdjMetaPostCre(_class, TRUE, workItemClass, argObjs, workItems, mfail)

#define MrgVersAdjMetaPreCre(workItemClass, argObjs, creArgs, creOwners, creClasses, mfail) \
        _MrgVersAdjMetaPreCre(workItemClass, FALSE, workItemClass, argObjs, creArgs, creOwners, creClasses, mfail)
#define MrgVersAdjMetaPreCreAtParent(_class, workItemClass, argObjs, creArgs, creOwners, creClasses, mfail) \
        _MrgVersAdjMetaPreCre(_class, TRUE, workItemClass, argObjs, creArgs, creOwners, creClasses, mfail)

#define MrgVersPostInsert(workItemClass, workItemList, argList, mfail) \
        _MrgVersPostInsert(workItemClass, FALSE, workItemClass, workItemList, argList, mfail)
#define MrgVersPostInsertAtParent(_class, workItemClass, workItemList, argList, mfail) \
        _MrgVersPostInsert(_class, TRUE, workItemClass, workItemList, argList, mfail)

#define NoReplaceSubSetRel(className, replaceObjects, extraStr, extraObj, mfail) \
        _NoReplaceSubSetRel(className, FALSE, className, replaceObjects, extraStr, extraObj, mfail)
#define NoReplaceSubSetRelAtParent(_class, className, replaceObjects, extraStr, extraObj, mfail) \
        _NoReplaceSubSetRel(_class, TRUE, className, replaceObjects, extraStr, extraObj, mfail)

#define NoReplaceSubSetToTm(className, replaceObjects, extraStr, extraObj, ckiDialog, mfail) \
        _NoReplaceSubSetToTm(className, FALSE, className, replaceObjects, extraStr, extraObj, ckiDialog, mfail)
#define NoReplaceSubSetToTmAtParent(_class, className, replaceObjects, extraStr, extraObj, ckiDialog, mfail) \
        _NoReplaceSubSetToTm(_class, TRUE, className, replaceObjects, extraStr, extraObj, ckiDialog, mfail)

#define ObtainCkoFmTmDstForDlg(thisObj, dest, mfail) \
        _ObtainCkoFmTmDstForDlgAtClass(NULL, FALSE, thisObj, dest, mfail)
#define ObtainCkoFmTmDstForDlgAtClass(class, thisObj, dest, mfail) \
        _ObtainCkoFmTmDstForDlgAtClass(class, FALSE, thisObj, dest, mfail)
#define ObtainCkoFmTmDstForDlgAtParent(class, thisObj, dest, mfail) \
        _ObtainCkoFmTmDstForDlgAtClass(class, TRUE, thisObj, dest, mfail)

#define ObtainCkoTDestForDlg(thisObj, dest, mfail) \
        _ObtainCkoTDestForDlgAtClass(NULL, FALSE, thisObj, dest, mfail)
#define ObtainCkoTDestForDlgAtClass(class, thisObj, dest, mfail) \
        _ObtainCkoTDestForDlgAtClass(class, FALSE, thisObj, dest, mfail)
#define ObtainCkoTDestForDlgAtParent(class, thisObj, dest, mfail) \
        _ObtainCkoTDestForDlgAtClass(class, TRUE, thisObj, dest, mfail)

#define PostReleasePrcRels(thisObj, mfail) \
        _PostReleasePrcRelsAtClass(NULL, FALSE, thisObj, mfail)
#define PostReleasePrcRelsAtClass(class, thisObj, mfail) \
        _PostReleasePrcRelsAtClass(class, FALSE, thisObj, mfail)
#define PostReleasePrcRelsAtParent(class, thisObj, mfail) \
        _PostReleasePrcRelsAtClass(class, TRUE, thisObj, mfail)

#define PrcCkoMkvItmAftInsrtTm(thisObj, target, refresh, isBase, transferredObjs, destination, relatedObj, mfail) \
        _PrcCkoMkvItmAftInsrtTmAtClass(NULL, FALSE, thisObj, target, refresh, isBase, transferredObjs, destination, relatedObj, mfail)
#define PrcCkoMkvItmAftInsrtTmAtClass(class, thisObj, target, refresh, isBase, transferredObjs, destination, relatedObj, mfail) \
        _PrcCkoMkvItmAftInsrtTmAtClass(class, FALSE, thisObj, target, refresh, isBase, transferredObjs, destination, relatedObj, mfail)
#define PrcCkoMkvItmAftInsrtTmAtParent(class, thisObj, target, refresh, isBase, transferredObjs, destination, relatedObj, mfail) \
        _PrcCkoMkvItmAftInsrtTmAtClass(class, TRUE, thisObj, target, refresh, isBase, transferredObjs, destination, relatedObj, mfail)

#define PrcERORelForCkoRevTInt(thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _PrcERORelForCkoRevTIntAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)
#define PrcERORelForCkoRevTIntAtClass(class, thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _PrcERORelForCkoRevTIntAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)
#define PrcERORelForCkoRevTIntAtParent(class, thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _PrcERORelForCkoRevTIntAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)

#define PrcFldrKyCtsForLatest(itemObj, folderContents, mfail) \
        _PrcFldrKyCtsForLatestAtClass(NULL, FALSE, itemObj, folderContents, mfail)
#define PrcFldrKyCtsForLatestAtClass(class, itemObj, folderContents, mfail) \
        _PrcFldrKyCtsForLatestAtClass(class, FALSE, itemObj, folderContents, mfail)
#define PrcFldrKyCtsForLatestAtParent(class, itemObj, folderContents, mfail) \
        _PrcFldrKyCtsForLatestAtClass(class, TRUE, itemObj, folderContents, mfail)

#define PrcFldrNKyCtsForLatest(itemObj, folderContents, mfail) \
        _PrcFldrNKyCtsForLatestAtClass(NULL, FALSE, itemObj, folderContents, mfail)
#define PrcFldrNKyCtsForLatestAtClass(class, itemObj, folderContents, mfail) \
        _PrcFldrNKyCtsForLatestAtClass(class, FALSE, itemObj, folderContents, mfail)
#define PrcFldrNKyCtsForLatestAtParent(class, itemObj, folderContents, mfail) \
        _PrcFldrNKyCtsForLatestAtClass(class, TRUE, itemObj, folderContents, mfail)

#define PrcInsItemForInsVer(insertObj, predObj, succObj, mfail) \
        _PrcInsItemForInsVerAtClass(NULL, FALSE, insertObj, predObj, succObj, mfail)
#define PrcInsItemForInsVerAtClass(class, insertObj, predObj, succObj, mfail) \
        _PrcInsItemForInsVerAtClass(class, FALSE, insertObj, predObj, succObj, mfail)
#define PrcInsItemForInsVerAtParent(class, insertObj, predObj, succObj, mfail) \
        _PrcInsItemForInsVerAtClass(class, TRUE, insertObj, predObj, succObj, mfail)

#define PrcItmRelsForCancelRsv(workItem, mfail) \
        _PrcItmRelsForCancelRsvAtClass(NULL, FALSE, workItem, mfail)
#define PrcItmRelsForCancelRsvAtClass(class, workItem, mfail) \
        _PrcItmRelsForCancelRsvAtClass(class, FALSE, workItem, mfail)
#define PrcItmRelsForCancelRsvAtParent(class, workItem, mfail) \
        _PrcItmRelsForCancelRsvAtClass(class, TRUE, workItem, mfail)

#define PrcPrdItmRlsForCinToTm(thisObj, succ, isBaseObj, mfail) \
        _PrcPrdItmRlsForCinToTmAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPrdItmRlsForCinToTmAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPrdItmRlsForCinToTmAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPrdItmRlsForCinToTmAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPrdItmRlsForCinToTmAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPrdSccItmForCinToTm(thisObj, succ, isBaseObj, mfail) \
        _PrcPrdSccItmForCinToTmAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPrdSccItmForCinToTmAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPrdSccItmForCinToTmAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPrdSccItmForCinToTmAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPrdSccItmForCinToTmAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPredAndSuccForRel(thisObj, succ, isBaseObj, mfail) \
        _PrcPredAndSuccForRelAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredAndSuccForRelAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredAndSuccForRelAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredAndSuccForRelAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredAndSuccForRelAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPredForCinToTm(thisObj, succ, isBaseObj, mfail) \
        _PrcPredForCinToTmAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredForCinToTmAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredForCinToTmAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredForCinToTmAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredForCinToTmAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPredForRelease(thisObj, succ, isBaseObj, mfail) \
        _PrcPredForReleaseAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredForReleaseAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredForReleaseAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredForReleaseAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredForReleaseAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPredItemForCinToTm(thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemForCinToTmAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredItemForCinToTmAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemForCinToTmAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredItemForCinToTmAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemForCinToTmAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPredItemForInsVer(predObj, insertObj, succObj, mfail) \
        _PrcPredItemForInsVerAtClass(NULL, FALSE, predObj, insertObj, succObj, mfail)
#define PrcPredItemForInsVerAtClass(class, predObj, insertObj, succObj, mfail) \
        _PrcPredItemForInsVerAtClass(class, FALSE, predObj, insertObj, succObj, mfail)
#define PrcPredItemForInsVerAtParent(class, predObj, insertObj, succObj, mfail) \
        _PrcPredItemForInsVerAtClass(class, TRUE, predObj, insertObj, succObj, mfail)

#define PrcPredItemForRelease(thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemForReleaseAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredItemForReleaseAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemForReleaseAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredItemForReleaseAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemForReleaseAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPredItemRelsForRel(thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemRelsForRelAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredItemRelsForRelAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemRelsForRelAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredItemRelsForRelAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredItemRelsForRelAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPredRForCinToTm(thisObj, pred, succ, isBaseObj, mfail) \
        _PrcPredRForCinToTmAtClass(NULL, FALSE, thisObj, pred, succ, isBaseObj, mfail)
#define PrcPredRForCinToTmAtClass(class, thisObj, pred, succ, isBaseObj, mfail) \
        _PrcPredRForCinToTmAtClass(class, FALSE, thisObj, pred, succ, isBaseObj, mfail)
#define PrcPredRForCinToTmAtParent(class, thisObj, pred, succ, isBaseObj, mfail) \
        _PrcPredRForCinToTmAtClass(class, TRUE, thisObj, pred, succ, isBaseObj, mfail)

#define PrcPredRelForCirToTm(thisObj, action, actionCode, succ, pred, isBaseObj, mfail) \
        _PrcPredRelForCirToTmAtClass(NULL, FALSE, thisObj, action, actionCode, succ, pred, isBaseObj, mfail)
#define PrcPredRelForCirToTmAtClass(class, thisObj, action, actionCode, succ, pred, isBaseObj, mfail) \
        _PrcPredRelForCirToTmAtClass(class, FALSE, thisObj, action, actionCode, succ, pred, isBaseObj, mfail)
#define PrcPredRelForCirToTmAtParent(class, thisObj, action, actionCode, succ, pred, isBaseObj, mfail) \
        _PrcPredRelForCirToTmAtClass(class, TRUE, thisObj, action, actionCode, succ, pred, isBaseObj, mfail)

#define PrcPredSuccForCinToTm(thisObj, succ, isBaseObj, mfail) \
        _PrcPredSuccForCinToTmAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredSuccForCinToTmAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredSuccForCinToTmAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredSuccForCinToTmAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredSuccForCinToTmAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcPredSuccItemsForRel(thisObj, succ, isBaseObj, mfail) \
        _PrcPredSuccItemsForRelAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredSuccItemsForRelAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredSuccItemsForRelAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define PrcPredSuccItemsForRelAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _PrcPredSuccItemsForRelAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define PrcRelForPostRlse(relObj, item, mfail) \
        _PrcRelForPostRlseAtClass(NULL, FALSE, relObj, item, mfail)
#define PrcRelForPostRlseAtClass(class, relObj, item, mfail) \
        _PrcRelForPostRlseAtClass(class, FALSE, relObj, item, mfail)
#define PrcRelForPostRlseAtParent(class, relObj, item, mfail) \
        _PrcRelForPostRlseAtClass(class, TRUE, relObj, item, mfail)

#define PrcSccItmRlsForCinToTm(thisObj, pred, isBaseObj, mfail) \
        _PrcSccItmRlsForCinToTmAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSccItmRlsForCinToTmAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSccItmRlsForCinToTmAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSccItmRlsForCinToTmAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSccItmRlsForCinToTmAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define PrcSuccForCinToTm(thisObj, pred, isBaseObj, mfail) \
        _PrcSuccForCinToTmAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccForCinToTmAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccForCinToTmAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccForCinToTmAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccForCinToTmAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define PrcSuccForRelease(thisObj, pred, isBaseObj, mfail) \
        _PrcSuccForReleaseAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccForReleaseAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccForReleaseAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccForReleaseAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccForReleaseAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define PrcSuccItemForCinToTm(thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemForCinToTmAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccItemForCinToTmAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemForCinToTmAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccItemForCinToTmAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemForCinToTmAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define PrcSuccItemForInsVer(succObj, insertObj, predObj, mfail) \
        _PrcSuccItemForInsVerAtClass(NULL, FALSE, succObj, insertObj, predObj, mfail)
#define PrcSuccItemForInsVerAtClass(class, succObj, insertObj, predObj, mfail) \
        _PrcSuccItemForInsVerAtClass(class, FALSE, succObj, insertObj, predObj, mfail)
#define PrcSuccItemForInsVerAtParent(class, succObj, insertObj, predObj, mfail) \
        _PrcSuccItemForInsVerAtClass(class, TRUE, succObj, insertObj, predObj, mfail)

#define PrcSuccItemForRelease(thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemForReleaseAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccItemForReleaseAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemForReleaseAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccItemForReleaseAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemForReleaseAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define PrcSuccItemRelsForRel(thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemRelsForRelAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccItemRelsForRelAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemRelsForRelAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define PrcSuccItemRelsForRelAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _PrcSuccItemRelsForRelAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define PrcSuccRForCinToTm(thisObj, succ, pred, isBaseObj, mfail) \
        _PrcSuccRForCinToTmAtClass(NULL, FALSE, thisObj, succ, pred, isBaseObj, mfail)
#define PrcSuccRForCinToTmAtClass(class, thisObj, succ, pred, isBaseObj, mfail) \
        _PrcSuccRForCinToTmAtClass(class, FALSE, thisObj, succ, pred, isBaseObj, mfail)
#define PrcSuccRForCinToTmAtParent(class, thisObj, succ, pred, isBaseObj, mfail) \
        _PrcSuccRForCinToTmAtClass(class, TRUE, thisObj, succ, pred, isBaseObj, mfail)

#define PrcSuccRelForCirToTm(thisObj, action, actionCode, succ, pred, isBaseObj, mfail) \
        _PrcSuccRelForCirToTmAtClass(NULL, FALSE, thisObj, action, actionCode, succ, pred, isBaseObj, mfail)
#define PrcSuccRelForCirToTmAtClass(class, thisObj, action, actionCode, succ, pred, isBaseObj, mfail) \
        _PrcSuccRelForCirToTmAtClass(class, FALSE, thisObj, action, actionCode, succ, pred, isBaseObj, mfail)
#define PrcSuccRelForCirToTmAtParent(class, thisObj, action, actionCode, succ, pred, isBaseObj, mfail) \
        _PrcSuccRelForCirToTmAtClass(class, TRUE, thisObj, action, actionCode, succ, pred, isBaseObj, mfail)

#define ProcCheckOutItemObjsTm(thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutItemObjsTmAtClass(NULL, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ProcCheckOutItemObjsTmAtClass(class, thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutItemObjsTmAtClass(class, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ProcCheckOutItemObjsTmAtParent(class, thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutItemObjsTmAtClass(class, TRUE, thisObj, dest, refresh, isBase, mfail)

#define ProcCheckOutItemRelsTm(thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutItemRelsTmAtClass(NULL, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ProcCheckOutItemRelsTmAtClass(class, thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutItemRelsTmAtClass(class, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ProcCheckOutItemRelsTmAtParent(class, thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutItemRelsTmAtClass(class, TRUE, thisObj, dest, refresh, isBase, mfail)

#define ProcCheckOutTItemObjs(thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutTItemObjsAtClass(NULL, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ProcCheckOutTItemObjsAtClass(class, thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutTItemObjsAtClass(class, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ProcCheckOutTItemObjsAtParent(class, thisObj, dest, refresh, isBase, mfail) \
        _ProcCheckOutTItemObjsAtClass(class, TRUE, thisObj, dest, refresh, isBase, mfail)

#define ProcERORelForCkoMkvTm(thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForCkoMkvTmAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)
#define ProcERORelForCkoMkvTmAtClass(class, thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForCkoMkvTmAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)
#define ProcERORelForCkoMkvTmAtParent(class, thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForCkoMkvTmAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)

#define ProcERORelForCkoTm(thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForCkoTmAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)
#define ProcERORelForCkoTmAtClass(class, thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForCkoTmAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)
#define ProcERORelForCkoTmAtParent(class, thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForCkoTmAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)

#define ProcERORelForMrgVer(thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForMrgVerAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)
#define ProcERORelForMrgVerAtClass(class, thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForMrgVerAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)
#define ProcERORelForMrgVerAtParent(class, thisObj, source, dest, refresh, isBase, newRelObj, mfail) \
        _ProcERORelForMrgVerAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, newRelObj, mfail)

#define ProcForTranAuthority(thisObj, attachedObjs, argumentsObj, extraStr, extraObj, mfail) \
        _ProcForTranAuthorityAtClass(NULL, FALSE, thisObj, attachedObjs, argumentsObj, extraStr, extraObj, mfail)
#define ProcForTranAuthorityAtClass(class, thisObj, attachedObjs, argumentsObj, extraStr, extraObj, mfail) \
        _ProcForTranAuthorityAtClass(class, FALSE, thisObj, attachedObjs, argumentsObj, extraStr, extraObj, mfail)
#define ProcForTranAuthorityAtParent(class, thisObj, attachedObjs, argumentsObj, extraStr, extraObj, mfail) \
        _ProcForTranAuthorityAtClass(class, TRUE, thisObj, attachedObjs, argumentsObj, extraStr, extraObj, mfail)

#define ProcRelForCheckOutTm(thisObj, source, dest, refresh, isBase, mfail) \
        _ProcRelForCheckOutTmAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ProcRelForCheckOutTmAtClass(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ProcRelForCheckOutTmAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ProcRelForCheckOutTmAtParent(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ProcRelForCheckOutTmAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, mfail)

#define ProcRelForMergePre(className, isPartDoc, mfail) \
        _ProcRelForMergePre(className, FALSE, className, isPartDoc, mfail)
#define ProcRelForMergePreAtParent(_class, className, isPartDoc, mfail) \
        _ProcRelForMergePre(_class, TRUE, className, isPartDoc, mfail)

#define ProcRelForMrgVerPre(className, isPartDoc, mfail) \
        _ProcRelForMrgVerPre(className, FALSE, className, isPartDoc, mfail)
#define ProcRelForMrgVerPreAtParent(_class, className, isPartDoc, mfail) \
        _ProcRelForMrgVerPre(_class, TRUE, className, isPartDoc, mfail)

#define ProcessCheckOutTSet(className, checkOutObjects, workLoc, folder, mfail) \
        _ProcessCheckOutTSet(className, FALSE, className, checkOutObjects, workLoc, folder, mfail)
#define ProcessCheckOutTSetAtParent(_class, className, checkOutObjects, workLoc, folder, mfail) \
        _ProcessCheckOutTSet(_class, TRUE, className, checkOutObjects, workLoc, folder, mfail)

#define ProcessCheckOutUSet(className, checkOutObjects, workLoc, mfail) \
        _ProcessCheckOutUSet(className, FALSE, className, checkOutObjects, workLoc, mfail)
#define ProcessCheckOutUSetAtParent(_class, className, checkOutObjects, workLoc, mfail) \
        _ProcessCheckOutUSet(_class, TRUE, className, checkOutObjects, workLoc, mfail)

#define ProcessCinToTmSet(className, checkOutObjects, extraStr, extraObj, mfail) \
        _ProcessCinToTmSet(className, FALSE, className, checkOutObjects, extraStr, extraObj, mfail)
#define ProcessCinToTmSetAtParent(_class, className, checkOutObjects, extraStr, extraObj, mfail) \
        _ProcessCinToTmSet(_class, TRUE, className, checkOutObjects, extraStr, extraObj, mfail)

#define ProcessCirToTmSet(className, checkOutObjects, extraStr, extraObj, mfail) \
        _ProcessCirToTmSet(className, FALSE, className, checkOutObjects, extraStr, extraObj, mfail)
#define ProcessCirToTmSetAtParent(_class, className, checkOutObjects, extraStr, extraObj, mfail) \
        _ProcessCirToTmSet(_class, TRUE, className, checkOutObjects, extraStr, extraObj, mfail)

#define ProcessObjsForRel(relObject, leftObject, rightObject, mfail) \
        _ProcessObjsForRelAtClass(NULL, FALSE, relObject, leftObject, rightObject, mfail)
#define ProcessObjsForRelAtClass(class, relObject, leftObject, rightObject, mfail) \
        _ProcessObjsForRelAtClass(class, FALSE, relObject, leftObject, rightObject, mfail)
#define ProcessObjsForRelAtParent(class, relObject, leftObject, rightObject, mfail) \
        _ProcessObjsForRelAtClass(class, TRUE, relObject, leftObject, rightObject, mfail)

#define ProcessRelForMerge(thisObj, source, dest, refresh, isBase, mfail) \
        _ProcessRelForMergeAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ProcessRelForMergeAtClass(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ProcessRelForMergeAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ProcessRelForMergeAtParent(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ProcessRelForMergeAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, mfail)

#define ProcessRelForMrgVer(thisObj, source, dest, refresh, isBase, mfail) \
        _ProcessRelForMrgVerAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ProcessRelForMrgVerAtClass(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ProcessRelForMrgVerAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ProcessRelForMrgVerAtParent(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ProcessRelForMrgVerAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, mfail)

#define ProcessRelNoReplaceSet(className, checkOutObjects, extraStr, extraObj, mfail) \
        _ProcessRelNoReplaceSet(className, FALSE, className, checkOutObjects, extraStr, extraObj, mfail)
#define ProcessRelNoReplaceSetAtParent(_class, className, checkOutObjects, extraStr, extraObj, mfail) \
        _ProcessRelNoReplaceSet(_class, TRUE, className, checkOutObjects, extraStr, extraObj, mfail)

#define ProcessRelReplaceSet(className, checkOutObjects, extraStr, extraObj, mfail) \
        _ProcessRelReplaceSet(className, FALSE, className, checkOutObjects, extraStr, extraObj, mfail)
#define ProcessRelReplaceSetAtParent(_class, className, checkOutObjects, extraStr, extraObj, mfail) \
        _ProcessRelReplaceSet(_class, TRUE, className, checkOutObjects, extraStr, extraObj, mfail)

#define ProcessRelsForMerge(workItemClass, newObjsList, argObjsList, otherSideObjs, mfail) \
        _ProcessRelsForMerge(workItemClass, FALSE, workItemClass, newObjsList, argObjsList, otherSideObjs, mfail)
#define ProcessRelsForMergeAtParent(_class, workItemClass, newObjsList, argObjsList, otherSideObjs, mfail) \
        _ProcessRelsForMerge(_class, TRUE, workItemClass, newObjsList, argObjsList, otherSideObjs, mfail)

#define ProcessRelsForMrgPost(mergeObj, mergeDialog, otherSideObjs, mfail) \
        _ProcessRelsForMrgPostAtClass(NULL, FALSE, mergeObj, mergeDialog, otherSideObjs, mfail)
#define ProcessRelsForMrgPostAtClass(class, mergeObj, mergeDialog, otherSideObjs, mfail) \
        _ProcessRelsForMrgPostAtClass(class, FALSE, mergeObj, mergeDialog, otherSideObjs, mfail)
#define ProcessRelsForMrgPostAtParent(class, mergeObj, mergeDialog, otherSideObjs, mfail) \
        _ProcessRelsForMrgPostAtClass(class, TRUE, mergeObj, mergeDialog, otherSideObjs, mfail)

#define ProcessRelsForMrgPre(mergeObj, mergeDialog, otherSideObjs, mfail) \
        _ProcessRelsForMrgPreAtClass(NULL, FALSE, mergeObj, mergeDialog, otherSideObjs, mfail)
#define ProcessRelsForMrgPreAtClass(class, mergeObj, mergeDialog, otherSideObjs, mfail) \
        _ProcessRelsForMrgPreAtClass(class, FALSE, mergeObj, mergeDialog, otherSideObjs, mfail)
#define ProcessRelsForMrgPreAtParent(class, mergeObj, mergeDialog, otherSideObjs, mfail) \
        _ProcessRelsForMrgPreAtClass(class, TRUE, mergeObj, mergeDialog, otherSideObjs, mfail)

#define ProcessRelsForMrgVers(workItemClass, newObjsList, argObjsList, otherSideObjs, uploadInfo, mfail) \
        _ProcessRelsForMrgVers(workItemClass, FALSE, workItemClass, newObjsList, argObjsList, otherSideObjs, uploadInfo, mfail)
#define ProcessRelsForMrgVersAtParent(_class, workItemClass, newObjsList, argObjsList, otherSideObjs, uploadInfo, mfail) \
        _ProcessRelsForMrgVers(_class, TRUE, workItemClass, newObjsList, argObjsList, otherSideObjs, uploadInfo, mfail)

#define ProcessRlsTransferSet(className, transferObjects, extraStr, extraObj, mfail) \
        _ProcessRlsTransferSet(className, FALSE, className, transferObjects, extraStr, extraObj, mfail)
#define ProcessRlsTransferSetAtParent(_class, className, transferObjects, extraStr, extraObj, mfail) \
        _ProcessRlsTransferSet(_class, TRUE, className, transferObjects, extraStr, extraObj, mfail)

#define ProcessSetForPrg(className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForPrg(className, FALSE, className, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForPrgAtParent(_class, className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForPrg(_class, TRUE, className, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProcessSetForPrgPost(className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForPrgPost(className, FALSE, className, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForPrgPostAtParent(_class, className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForPrgPost(_class, TRUE, className, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProcessSetForPrgPre(originClassName, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForPrgPre(originClassName, FALSE, originClassName, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForPrgPreAtParent(_class, originClassName, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForPrgPre(_class, TRUE, originClassName, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProcessTransferTmSet(className, transferObjects, extraStr, extraObj, mfail) \
        _ProcessTransferTmSet(className, FALSE, className, transferObjects, extraStr, extraObj, mfail)
#define ProcessTransferTmSetAtParent(_class, className, transferObjects, extraStr, extraObj, mfail) \
        _ProcessTransferTmSet(_class, TRUE, className, transferObjects, extraStr, extraObj, mfail)

#define ProjectExists(className, projectName, exists, mfail) \
        _ProjectExists(className, FALSE, className, projectName, exists, mfail)
#define ProjectExistsAtParent(_class, className, projectName, exists, mfail) \
        _ProjectExists(_class, TRUE, className, projectName, exists, mfail)

#define PropCreDateResMrg(thisObj, propagate, mfail) \
        _PropCreDateResMrgAtClass(NULL, FALSE, thisObj, propagate, mfail)
#define PropCreDateResMrgAtClass(class, thisObj, propagate, mfail) \
        _PropCreDateResMrgAtClass(class, FALSE, thisObj, propagate, mfail)
#define PropCreDateResMrgAtParent(class, thisObj, propagate, mfail) \
        _PropCreDateResMrgAtClass(class, TRUE, thisObj, propagate, mfail)

#define PropCreDateTCO(thisObj, propagate, mfail) \
        _PropCreDateTCOAtClass(NULL, FALSE, thisObj, propagate, mfail)
#define PropCreDateTCOAtClass(class, thisObj, propagate, mfail) \
        _PropCreDateTCOAtClass(class, FALSE, thisObj, propagate, mfail)
#define PropCreDateTCOAtParent(class, thisObj, propagate, mfail) \
        _PropCreDateTCOAtClass(class, TRUE, thisObj, propagate, mfail)

#define PropagateMrgItemRels(thisObj, dest, relExclHandles, refresh, isBase, mfail) \
        _PropagateMrgItemRelsAtClass(NULL, FALSE, thisObj, dest, relExclHandles, refresh, isBase, mfail)
#define PropagateMrgItemRelsAtClass(class, thisObj, dest, relExclHandles, refresh, isBase, mfail) \
        _PropagateMrgItemRelsAtClass(class, FALSE, thisObj, dest, relExclHandles, refresh, isBase, mfail)
#define PropagateMrgItemRelsAtParent(class, thisObj, dest, relExclHandles, refresh, isBase, mfail) \
        _PropagateMrgItemRelsAtClass(class, TRUE, thisObj, dest, relExclHandles, refresh, isBase, mfail)

#define PurgePredecessors(thisObj, mfail) \
        _PurgePredecessorsAtClass(NULL, FALSE, thisObj, mfail)
#define PurgePredecessorsAtClass(class, thisObj, mfail) \
        _PurgePredecessorsAtClass(class, FALSE, thisObj, mfail)
#define PurgePredecessorsAtParent(class, thisObj, mfail) \
        _PurgePredecessorsAtClass(class, TRUE, thisObj, mfail)

#define PurgePredecessorsDP(thisObj, mfail) \
        _PurgePredecessorsDPAtClass(NULL, FALSE, thisObj, mfail)
#define PurgePredecessorsDPAtClass(class, thisObj, mfail) \
        _PurgePredecessorsDPAtClass(class, FALSE, thisObj, mfail)
#define PurgePredecessorsDPAtParent(class, thisObj, mfail) \
        _PurgePredecessorsDPAtClass(class, TRUE, thisObj, mfail)

#define PurgePredecessorsInt(workItem, failedItems, mfail) \
        _PurgePredecessorsIntAtClass(NULL, FALSE, workItem, failedItems, mfail)
#define PurgePredecessorsIntAtClass(class, workItem, failedItems, mfail) \
        _PurgePredecessorsIntAtClass(class, FALSE, workItem, failedItems, mfail)
#define PurgePredecessorsIntAtParent(class, workItem, failedItems, mfail) \
        _PurgePredecessorsIntAtClass(class, TRUE, workItem, failedItems, mfail)

#define QueryUpToDateStatus(thisObj, answer, mfail) \
        _QueryUpToDateStatusAtClass(NULL, FALSE, thisObj, answer, mfail)
#define QueryUpToDateStatusAtClass(class, thisObj, answer, mfail) \
        _QueryUpToDateStatusAtClass(class, FALSE, thisObj, answer, mfail)
#define QueryUpToDateStatusAtParent(class, thisObj, answer, mfail) \
        _QueryUpToDateStatusAtClass(class, TRUE, thisObj, answer, mfail)

#define QueryUpToDateStatusInt(thisObj, answer, mfail) \
        _QueryUpToDateStatusIntAtClass(NULL, FALSE, thisObj, answer, mfail)
#define QueryUpToDateStatusIntAtClass(class, thisObj, answer, mfail) \
        _QueryUpToDateStatusIntAtClass(class, FALSE, thisObj, answer, mfail)
#define QueryUpToDateStatusIntAtParent(class, thisObj, answer, mfail) \
        _QueryUpToDateStatusIntAtClass(class, TRUE, thisObj, answer, mfail)

#define RecreateNestBeforeDel(thisObj, childFolders, mfail) \
        _RecreateNestBeforeDelAtClass(NULL, FALSE, thisObj, childFolders, mfail)
#define RecreateNestBeforeDelAtClass(class, thisObj, childFolders, mfail) \
        _RecreateNestBeforeDelAtClass(class, FALSE, thisObj, childFolders, mfail)
#define RecreateNestBeforeDelAtParent(class, thisObj, childFolders, mfail) \
        _RecreateNestBeforeDelAtClass(class, TRUE, thisObj, childFolders, mfail)

#define RelItemForSetIntPre(className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, isTransactional, mfail) \
        _RelItemForSetIntPre(className, FALSE, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, isTransactional, mfail)
#define RelItemForSetIntPreAtParent(_class, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, isTransactional, mfail) \
        _RelItemForSetIntPre(_class, TRUE, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, isTransactional, mfail)

#define ReleaseDP(thisObj, mfail) \
        _ReleaseDPAtClass(NULL, FALSE, thisObj, mfail)
#define ReleaseDPAtClass(class, thisObj, mfail) \
        _ReleaseDPAtClass(class, FALSE, thisObj, mfail)
#define ReleaseDPAtParent(class, thisObj, mfail) \
        _ReleaseDPAtClass(class, TRUE, thisObj, mfail)

#define ReleaseInt(thisObj, mfail) \
        _ReleaseIntAtClass(NULL, FALSE, thisObj, mfail)
#define ReleaseIntAtClass(class, thisObj, mfail) \
        _ReleaseIntAtClass(class, FALSE, thisObj, mfail)
#define ReleaseIntAtParent(class, thisObj, mfail) \
        _ReleaseIntAtClass(class, TRUE, thisObj, mfail)

#define ReleaseItem(workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail) \
        _ReleaseItemAtClass(NULL, FALSE, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail)
#define ReleaseItemAtClass(class, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail) \
        _ReleaseItemAtClass(class, FALSE, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail)
#define ReleaseItemAtParent(class, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail) \
        _ReleaseItemAtClass(class, TRUE, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail)

#define ReleaseItemForSet(className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemForSet(className, FALSE, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, mfail)
#define ReleaseItemForSetAtParent(_class, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemForSet(_class, TRUE, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, mfail)

#define ReleaseItemForSetInt(className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemForSetInt(className, FALSE, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, mfail)
#define ReleaseItemForSetIntAtParent(_class, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemForSetInt(_class, TRUE, className, dialogs, eplctSlctAndReleased, eplctSlctButFailed, implctSlctAndReleased, implctSlctButFailed, mfail)

#define ReleaseItemForSetPre(classname, orgDialogs, eplctSlctButFailed, dialogs, mfail) \
        _ReleaseItemForSetPre(classname, FALSE, classname, orgDialogs, eplctSlctButFailed, dialogs, mfail)
#define ReleaseItemForSetPreAtParent(_class, classname, orgDialogs, eplctSlctButFailed, dialogs, mfail) \
        _ReleaseItemForSetPre(_class, TRUE, classname, orgDialogs, eplctSlctButFailed, dialogs, mfail)

#define ReleaseItemInt(thisObj, destOwnerName, releaseType, include, mfail) \
        _ReleaseItemIntAtClass(NULL, FALSE, thisObj, destOwnerName, releaseType, include, mfail)
#define ReleaseItemIntAtClass(class, thisObj, destOwnerName, releaseType, include, mfail) \
        _ReleaseItemIntAtClass(class, FALSE, thisObj, destOwnerName, releaseType, include, mfail)
#define ReleaseItemIntAtParent(class, thisObj, destOwnerName, releaseType, include, mfail) \
        _ReleaseItemIntAtClass(class, TRUE, thisObj, destOwnerName, releaseType, include, mfail)

#define ReleaseItemP(workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail) \
        _ReleaseItemPAtClass(NULL, FALSE, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail)
#define ReleaseItemPAtClass(class, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail) \
        _ReleaseItemPAtClass(class, FALSE, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail)
#define ReleaseItemPAtParent(class, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail) \
        _ReleaseItemPAtClass(class, TRUE, workItem, destOwnerName, releaseType, includeAtt, dataItems, mfail)

#define ReleaseItemPost(workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemPostAtClass(NULL, FALSE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)
#define ReleaseItemPostAtClass(class, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemPostAtClass(class, FALSE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)
#define ReleaseItemPostAtParent(class, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemPostAtClass(class, TRUE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)

#define ReleaseItemPre(workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemPreAtClass(NULL, FALSE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)
#define ReleaseItemPreAtClass(class, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemPreAtClass(class, FALSE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)
#define ReleaseItemPreAtParent(class, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail) \
        _ReleaseItemPreAtClass(class, TRUE, workitemObj, dialog, implctSlctAndReleased, implctSlctButFailed, mfail)

#define ReleaseNoReplace(thisObj, mfail) \
        _ReleaseNoReplaceAtClass(NULL, FALSE, thisObj, mfail)
#define ReleaseNoReplaceAtClass(class, thisObj, mfail) \
        _ReleaseNoReplaceAtClass(class, FALSE, thisObj, mfail)
#define ReleaseNoReplaceAtParent(class, thisObj, mfail) \
        _ReleaseNoReplaceAtClass(class, TRUE, thisObj, mfail)

#define ReleaseNoReplaceObject(thisObj, releaseType, destOwnerName, includeAtt, mfail) \
        _ReleaseNoReplaceObjectAtClass(NULL, FALSE, thisObj, releaseType, destOwnerName, includeAtt, mfail)
#define ReleaseNoReplaceObjectAtClass(class, thisObj, releaseType, destOwnerName, includeAtt, mfail) \
        _ReleaseNoReplaceObjectAtClass(class, FALSE, thisObj, releaseType, destOwnerName, includeAtt, mfail)
#define ReleaseNoReplaceObjectAtParent(class, thisObj, releaseType, destOwnerName, includeAtt, mfail) \
        _ReleaseNoReplaceObjectAtClass(class, TRUE, thisObj, releaseType, destOwnerName, includeAtt, mfail)

#define ReleaseOtherObjects(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _ReleaseOtherObjectsAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define ReleaseOtherObjectsAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _ReleaseOtherObjectsAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define ReleaseOtherObjectsAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _ReleaseOtherObjectsAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define ReleaseReplace(thisObj, mfail) \
        _ReleaseReplaceAtClass(NULL, FALSE, thisObj, mfail)
#define ReleaseReplaceAtClass(class, thisObj, mfail) \
        _ReleaseReplaceAtClass(class, FALSE, thisObj, mfail)
#define ReleaseReplaceAtParent(class, thisObj, mfail) \
        _ReleaseReplaceAtClass(class, TRUE, thisObj, mfail)

#define ReleaseReplaceObject(thisObj, releaseType, includeAtt, mfail) \
        _ReleaseReplaceObjectAtClass(NULL, FALSE, thisObj, releaseType, includeAtt, mfail)
#define ReleaseReplaceObjectAtClass(class, thisObj, releaseType, includeAtt, mfail) \
        _ReleaseReplaceObjectAtClass(class, FALSE, thisObj, releaseType, includeAtt, mfail)
#define ReleaseReplaceObjectAtParent(class, thisObj, releaseType, includeAtt, mfail) \
        _ReleaseReplaceObjectAtClass(class, TRUE, thisObj, releaseType, includeAtt, mfail)

#define ReleaseTransferInt(thisObj, userAction, mfail) \
        _ReleaseTransferIntAtClass(NULL, FALSE, thisObj, userAction, mfail)
#define ReleaseTransferIntAtClass(class, thisObj, userAction, mfail) \
        _ReleaseTransferIntAtClass(class, FALSE, thisObj, userAction, mfail)
#define ReleaseTransferIntAtParent(class, thisObj, userAction, mfail) \
        _ReleaseTransferIntAtClass(class, TRUE, thisObj, userAction, mfail)

#define RelseTransferObjectInt(thisObj, dialogObj, mfail) \
        _RelseTransferObjectIntAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define RelseTransferObjectIntAtClass(class, thisObj, dialogObj, mfail) \
        _RelseTransferObjectIntAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define RelseTransferObjectIntAtParent(class, thisObj, dialogObj, mfail) \
        _RelseTransferObjectIntAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define RelseTransferSubSet(className, transferObjects, extraStr, extraObj, mfail) \
        _RelseTransferSubSet(className, FALSE, className, transferObjects, extraStr, extraObj, mfail)
#define RelseTransferSubSetAtParent(_class, className, transferObjects, extraStr, extraObj, mfail) \
        _RelseTransferSubSet(_class, TRUE, className, transferObjects, extraStr, extraObj, mfail)

#define RemoveFrom(folder, removedItem, mfail) \
        _RemoveFromAtClass(NULL, FALSE, folder, removedItem, mfail)
#define RemoveFromAtClass(class, folder, removedItem, mfail) \
        _RemoveFromAtClass(class, FALSE, folder, removedItem, mfail)
#define RemoveFromAtParent(class, folder, removedItem, mfail) \
        _RemoveFromAtClass(class, TRUE, folder, removedItem, mfail)

#define RemoveFromNest(folder, removedFolder, mfail) \
        _RemoveFromNestAtClass(NULL, FALSE, folder, removedFolder, mfail)
#define RemoveFromNestAtClass(class, folder, removedFolder, mfail) \
        _RemoveFromNestAtClass(class, FALSE, folder, removedFolder, mfail)
#define RemoveFromNestAtParent(class, folder, removedFolder, mfail) \
        _RemoveFromNestAtClass(class, TRUE, folder, removedFolder, mfail)

#define RemoveFromPostInt(folder, removedItem, mfail) \
        _RemoveFromPostIntAtClass(NULL, FALSE, folder, removedItem, mfail)
#define RemoveFromPostIntAtClass(class, folder, removedItem, mfail) \
        _RemoveFromPostIntAtClass(class, FALSE, folder, removedItem, mfail)
#define RemoveFromPostIntAtParent(class, folder, removedItem, mfail) \
        _RemoveFromPostIntAtClass(class, TRUE, folder, removedItem, mfail)

#define RemoveFromPreInt(folder, removedItem, mfail) \
        _RemoveFromPreIntAtClass(NULL, FALSE, folder, removedItem, mfail)
#define RemoveFromPreIntAtClass(class, folder, removedItem, mfail) \
        _RemoveFromPreIntAtClass(class, FALSE, folder, removedItem, mfail)
#define RemoveFromPreIntAtParent(class, folder, removedItem, mfail) \
        _RemoveFromPreIntAtClass(class, TRUE, folder, removedItem, mfail)

#define RemoveObjFromCurTmFdrs(thisObj, mfail) \
        _RemoveObjFromCurTmFdrsAtClass(NULL, FALSE, thisObj, mfail)
#define RemoveObjFromCurTmFdrsAtClass(class, thisObj, mfail) \
        _RemoveObjFromCurTmFdrsAtClass(class, FALSE, thisObj, mfail)
#define RemoveObjFromCurTmFdrsAtParent(class, thisObj, mfail) \
        _RemoveObjFromCurTmFdrsAtClass(class, TRUE, thisObj, mfail)

#define RenameFolder(thisObj, dialogObj, mfail) \
        _RenameFolderAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define RenameFolderAtClass(class, thisObj, dialogObj, mfail) \
        _RenameFolderAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define RenameFolderAtParent(class, thisObj, dialogObj, mfail) \
        _RenameFolderAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define RenameFolderDP(thisObj, mfail) \
        _RenameFolderDPAtClass(NULL, FALSE, thisObj, mfail)
#define RenameFolderDPAtClass(class, thisObj, mfail) \
        _RenameFolderDPAtClass(class, FALSE, thisObj, mfail)
#define RenameFolderDPAtParent(class, thisObj, mfail) \
        _RenameFolderDPAtClass(class, TRUE, thisObj, mfail)

#define ReplaceSubSetRel(className, replaceObjects, extraStr, extraObj, mfail) \
        _ReplaceSubSetRel(className, FALSE, className, replaceObjects, extraStr, extraObj, mfail)
#define ReplaceSubSetRelAtParent(_class, className, replaceObjects, extraStr, extraObj, mfail) \
        _ReplaceSubSetRel(_class, TRUE, className, replaceObjects, extraStr, extraObj, mfail)

#define ReplaceSubSetToTm(className, replaceObjects, extraStr, extraObj, ckiDialog, mfail) \
        _ReplaceSubSetToTm(className, FALSE, className, replaceObjects, extraStr, extraObj, ckiDialog, mfail)
#define ReplaceSubSetToTmAtParent(_class, className, replaceObjects, extraStr, extraObj, ckiDialog, mfail) \
        _ReplaceSubSetToTm(_class, TRUE, className, replaceObjects, extraStr, extraObj, ckiDialog, mfail)

#define Reserve(workItemClass, workItems, rsvArgObjects, downloadInfo, mfail) \
        _Reserve(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail)
#define ReserveAtParent(_class, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail) \
        _Reserve(_class, TRUE, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail)

#define Reserve1(workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail) \
        _Reserve1(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail)
#define Reserve1AtParent(_class, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail) \
        _Reserve1(_class, TRUE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail)

#define Reserve2(workItemClass, workItemHandles, downloadInfo, mfail) \
        _Reserve2(workItemClass, FALSE, workItemClass, workItemHandles, downloadInfo, mfail)
#define Reserve2AtParent(_class, workItemClass, workItemHandles, downloadInfo, mfail) \
        _Reserve2(_class, TRUE, workItemClass, workItemHandles, downloadInfo, mfail)

#define Reserve3(workItemClass, workItemHandles, rsvArgObjects, downloadInfo, mfail) \
        _Reserve3(workItemClass, FALSE, workItemClass, workItemHandles, rsvArgObjects, downloadInfo, mfail)
#define Reserve3AtParent(_class, workItemClass, workItemHandles, rsvArgObjects, downloadInfo, mfail) \
        _Reserve3(_class, TRUE, workItemClass, workItemHandles, rsvArgObjects, downloadInfo, mfail)

#define Reserve4(workItemClass, workItemHandles, mfail) \
        _Reserve4(workItemClass, FALSE, workItemClass, workItemHandles, mfail)
#define Reserve4AtParent(_class, workItemClass, workItemHandles, mfail) \
        _Reserve4(_class, TRUE, workItemClass, workItemHandles, mfail)

#define Reserve5(workItemClass, workItemHandles, rsvArgObjects, mfail) \
        _Reserve5(workItemClass, FALSE, workItemClass, workItemHandles, rsvArgObjects, mfail)
#define Reserve5AtParent(_class, workItemClass, workItemHandles, rsvArgObjects, mfail) \
        _Reserve5(_class, TRUE, workItemClass, workItemHandles, rsvArgObjects, mfail)

#define ReserveInt(workItemClass, workItems, rsvArgObjects, downloadInfo, mfail) \
        _ReserveInt(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail)
#define ReserveIntAtParent(_class, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail) \
        _ReserveInt(_class, TRUE, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail)

#define ReserveInt1(workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail) \
        _ReserveInt1(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail)
#define ReserveInt1AtParent(_class, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail) \
        _ReserveInt1(_class, TRUE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail)

#define ReserveItem(workItem, rsvArgObject, mfail) \
        _ReserveItemAtClass(NULL, FALSE, workItem, rsvArgObject, mfail)
#define ReserveItemAtClass(class, workItem, rsvArgObject, mfail) \
        _ReserveItemAtClass(class, FALSE, workItem, rsvArgObject, mfail)
#define ReserveItemAtParent(class, workItem, rsvArgObject, mfail) \
        _ReserveItemAtClass(class, TRUE, workItem, rsvArgObject, mfail)

#define ReserveItemInt(workItem, rsvArgObject, mfail) \
        _ReserveItemIntAtClass(NULL, FALSE, workItem, rsvArgObject, mfail)
#define ReserveItemIntAtClass(class, workItem, rsvArgObject, mfail) \
        _ReserveItemIntAtClass(class, FALSE, workItem, rsvArgObject, mfail)
#define ReserveItemIntAtParent(class, workItem, rsvArgObject, mfail) \
        _ReserveItemIntAtClass(class, TRUE, workItem, rsvArgObject, mfail)

#define ReserveItemPost(workItem, rsvArgObject, downloadInfo, mfail) \
        _ReserveItemPostAtClass(NULL, FALSE, workItem, rsvArgObject, downloadInfo, mfail)
#define ReserveItemPostAtClass(class, workItem, rsvArgObject, downloadInfo, mfail) \
        _ReserveItemPostAtClass(class, FALSE, workItem, rsvArgObject, downloadInfo, mfail)
#define ReserveItemPostAtParent(class, workItem, rsvArgObject, downloadInfo, mfail) \
        _ReserveItemPostAtClass(class, TRUE, workItem, rsvArgObject, downloadInfo, mfail)

#define ReserveItemPostInt(workItem, rsvArgObject, downloadInfo, mfail) \
        _ReserveItemPostIntAtClass(NULL, FALSE, workItem, rsvArgObject, downloadInfo, mfail)
#define ReserveItemPostIntAtClass(class, workItem, rsvArgObject, downloadInfo, mfail) \
        _ReserveItemPostIntAtClass(class, FALSE, workItem, rsvArgObject, downloadInfo, mfail)
#define ReserveItemPostIntAtParent(class, workItem, rsvArgObject, downloadInfo, mfail) \
        _ReserveItemPostIntAtClass(class, TRUE, workItem, rsvArgObject, downloadInfo, mfail)

#define ReserveItemPre(workItem, rsvArgObject, mfail) \
        _ReserveItemPreAtClass(NULL, FALSE, workItem, rsvArgObject, mfail)
#define ReserveItemPreAtClass(class, workItem, rsvArgObject, mfail) \
        _ReserveItemPreAtClass(class, FALSE, workItem, rsvArgObject, mfail)
#define ReserveItemPreAtParent(class, workItem, rsvArgObject, mfail) \
        _ReserveItemPreAtClass(class, TRUE, workItem, rsvArgObject, mfail)

#define ReserveItemPreInt(workItem, rsvArgObject, mfail) \
        _ReserveItemPreIntAtClass(NULL, FALSE, workItem, rsvArgObject, mfail)
#define ReserveItemPreIntAtClass(class, workItem, rsvArgObject, mfail) \
        _ReserveItemPreIntAtClass(class, FALSE, workItem, rsvArgObject, mfail)
#define ReserveItemPreIntAtParent(class, workItem, rsvArgObject, mfail) \
        _ReserveItemPreIntAtClass(class, TRUE, workItem, rsvArgObject, mfail)

#define ReserveSet(workItemClass, workItems, rsvArgObjects, mfail) \
        _ReserveSet(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, mfail)
#define ReserveSetAtParent(_class, workItemClass, workItems, rsvArgObjects, mfail) \
        _ReserveSet(_class, TRUE, workItemClass, workItems, rsvArgObjects, mfail)

#define ReserveSet1(workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail) \
        _ReserveSet1(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail)
#define ReserveSet1AtParent(_class, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail) \
        _ReserveSet1(_class, TRUE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail)

#define ReserveSetPost(workItemClass, workItems, rsvArgObjects, downloadInfo, mfail) \
        _ReserveSetPost(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail)
#define ReserveSetPostAtParent(_class, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail) \
        _ReserveSetPost(_class, TRUE, workItemClass, workItems, rsvArgObjects, downloadInfo, mfail)

#define ReserveSetPost1(workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail) \
        _ReserveSetPost1(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail)
#define ReserveSetPost1AtParent(_class, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail) \
        _ReserveSetPost1(_class, TRUE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, downloadInfo, mfail)

#define ReserveSetPre(workItemClass, workItems, rsvArgObjects, mfail) \
        _ReserveSetPre(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, mfail)
#define ReserveSetPreAtParent(_class, workItemClass, workItems, rsvArgObjects, mfail) \
        _ReserveSetPre(_class, TRUE, workItemClass, workItems, rsvArgObjects, mfail)

#define ReserveSetPre1(workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail) \
        _ReserveSetPre1(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail)
#define ReserveSetPre1AtParent(_class, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail) \
        _ReserveSetPre1(_class, TRUE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail)

#define ReserveVersion(ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail) \
        _ReserveVersionAtClass(NULL, FALSE, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail)
#define ReserveVersionAtClass(class, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail) \
        _ReserveVersionAtClass(class, FALSE, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail)
#define ReserveVersionAtParent(class, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail) \
        _ReserveVersionAtClass(class, TRUE, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail)

#define ReserveVersionInt(ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail) \
        _ReserveVersionIntAtClass(NULL, FALSE, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail)
#define ReserveVersionIntAtClass(class, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail) \
        _ReserveVersionIntAtClass(class, FALSE, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail)
#define ReserveVersionIntAtParent(class, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail) \
        _ReserveVersionIntAtClass(class, TRUE, ckoObj, argObj, userFldr, generateInfo, downloadInfo, mfail)

#define ReserveVersionPost(workItem, argObj, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionPostAtClass(NULL, FALSE, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail)
#define ReserveVersionPostAtClass(class, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionPostAtClass(class, FALSE, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail)
#define ReserveVersionPostAtParent(class, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionPostAtClass(class, TRUE, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail)

#define ReserveVersionPostInt(workItem, argObj, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionPostIntAtClass(NULL, FALSE, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail)
#define ReserveVersionPostIntAtClass(class, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionPostIntAtClass(class, FALSE, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail)
#define ReserveVersionPostIntAtParent(class, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionPostIntAtClass(class, TRUE, workItem, argObj, userFolder, generateInfo, downloadInfo, mfail)

#define ReserveVersionPre(workItem, argObj, userFolder, mfail) \
        _ReserveVersionPreAtClass(NULL, FALSE, workItem, argObj, userFolder, mfail)
#define ReserveVersionPreAtClass(class, workItem, argObj, userFolder, mfail) \
        _ReserveVersionPreAtClass(class, FALSE, workItem, argObj, userFolder, mfail)
#define ReserveVersionPreAtParent(class, workItem, argObj, userFolder, mfail) \
        _ReserveVersionPreAtClass(class, TRUE, workItem, argObj, userFolder, mfail)

#define ReserveVersionPreInt(workItem, argObj, userFolder, mfail) \
        _ReserveVersionPreIntAtClass(NULL, FALSE, workItem, argObj, userFolder, mfail)
#define ReserveVersionPreIntAtClass(class, workItem, argObj, userFolder, mfail) \
        _ReserveVersionPreIntAtClass(class, FALSE, workItem, argObj, userFolder, mfail)
#define ReserveVersionPreIntAtParent(class, workItem, argObj, userFolder, mfail) \
        _ReserveVersionPreIntAtClass(class, TRUE, workItem, argObj, userFolder, mfail)

#define ReserveVersions2(workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersions2(workItemClass, FALSE, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail)
#define ReserveVersions2AtParent(_class, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersions2(_class, TRUE, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail)

#define ReserveVersions3(workItemClass, workItemObjs, userFolder, mfail) \
        _ReserveVersions3(workItemClass, FALSE, workItemClass, workItemObjs, userFolder, mfail)
#define ReserveVersions3AtParent(_class, workItemClass, workItemObjs, userFolder, mfail) \
        _ReserveVersions3(_class, TRUE, workItemClass, workItemObjs, userFolder, mfail)

#define ReserveVersionsInt2(workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionsInt2(workItemClass, FALSE, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail)
#define ReserveVersionsInt2AtParent(_class, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionsInt2(_class, TRUE, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail)

#define ReserveVersionsPost(workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionsPost(workItemClass, FALSE, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail)
#define ReserveVersionsPostAtParent(_class, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionsPost(_class, TRUE, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail)

#define ReserveVersionsPostInt(workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionsPostInt(workItemClass, FALSE, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail)
#define ReserveVersionsPostIntAtParent(_class, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail) \
        _ReserveVersionsPostInt(_class, TRUE, workItemClass, workItems, argsList, userFolder, generateInfo, downloadInfo, mfail)

#define ReserveVersionsPre(workItemClass, workItems, argsList, userFolder, mfail) \
        _ReserveVersionsPre(workItemClass, FALSE, workItemClass, workItems, argsList, userFolder, mfail)
#define ReserveVersionsPreAtParent(_class, workItemClass, workItems, argsList, userFolder, mfail) \
        _ReserveVersionsPre(_class, TRUE, workItemClass, workItems, argsList, userFolder, mfail)

#define ReserveVersionsPreInt(workItemClass, workItems, argsList, userFolder, mfail) \
        _ReserveVersionsPreInt(workItemClass, FALSE, workItemClass, workItems, argsList, userFolder, mfail)
#define ReserveVersionsPreIntAtParent(_class, workItemClass, workItems, argsList, userFolder, mfail) \
        _ReserveVersionsPreInt(_class, TRUE, workItemClass, workItems, argsList, userFolder, mfail)

#define SetCompCopyAttributesT(thisObj, sourceObj, mfail) \
        _SetCompCopyAttributesTAtClass(NULL, FALSE, thisObj, sourceObj, mfail)
#define SetCompCopyAttributesTAtClass(class, thisObj, sourceObj, mfail) \
        _SetCompCopyAttributesTAtClass(class, FALSE, thisObj, sourceObj, mfail)
#define SetCompCopyAttributesTAtParent(class, thisObj, sourceObj, mfail) \
        _SetCompCopyAttributesTAtClass(class, TRUE, thisObj, sourceObj, mfail)

#define SetCompCopyFromTmAttrs(thisObj, sourceObj, mfail) \
        _SetCompCopyFromTmAttrsAtClass(NULL, FALSE, thisObj, sourceObj, mfail)
#define SetCompCopyFromTmAttrsAtClass(class, thisObj, sourceObj, mfail) \
        _SetCompCopyFromTmAttrsAtClass(class, FALSE, thisObj, sourceObj, mfail)
#define SetCompCopyFromTmAttrsAtParent(class, thisObj, sourceObj, mfail) \
        _SetCompCopyFromTmAttrsAtClass(class, TRUE, thisObj, sourceObj, mfail)

#define SetCopyAttributesT(thisObj, dialogObj, sourceObj, mfail) \
        _SetCopyAttributesTAtClass(NULL, FALSE, thisObj, dialogObj, sourceObj, mfail)
#define SetCopyAttributesTAtClass(class, thisObj, dialogObj, sourceObj, mfail) \
        _SetCopyAttributesTAtClass(class, FALSE, thisObj, dialogObj, sourceObj, mfail)
#define SetCopyAttributesTAtParent(class, thisObj, dialogObj, sourceObj, mfail) \
        _SetCopyAttributesTAtClass(class, TRUE, thisObj, dialogObj, sourceObj, mfail)

#define SetCopyFromTmAttrs(thisObj, dialogObj, sourceObj, mfail) \
        _SetCopyFromTmAttrsAtClass(NULL, FALSE, thisObj, dialogObj, sourceObj, mfail)
#define SetCopyFromTmAttrsAtClass(class, thisObj, dialogObj, sourceObj, mfail) \
        _SetCopyFromTmAttrsAtClass(class, FALSE, thisObj, dialogObj, sourceObj, mfail)
#define SetCopyFromTmAttrsAtParent(class, thisObj, dialogObj, sourceObj, mfail) \
        _SetCopyFromTmAttrsAtClass(class, TRUE, thisObj, dialogObj, sourceObj, mfail)

#define SetCreDAttrsForMrgVer(createDialog, argObj, pred, mfail) \
        _SetCreDAttrsForMrgVerAtClass(NULL, FALSE, createDialog, argObj, pred, mfail)
#define SetCreDAttrsForMrgVerAtClass(class, createDialog, argObj, pred, mfail) \
        _SetCreDAttrsForMrgVerAtClass(class, FALSE, createDialog, argObj, pred, mfail)
#define SetCreDAttrsForMrgVerAtParent(class, createDialog, argObj, pred, mfail) \
        _SetCreDAttrsForMrgVerAtClass(class, TRUE, createDialog, argObj, pred, mfail)

#define SetFlagsForInsVers(workItem, context, mfail) \
        _SetFlagsForInsVersAtClass(NULL, FALSE, workItem, context, mfail)
#define SetFlagsForInsVersAtClass(class, workItem, context, mfail) \
        _SetFlagsForInsVersAtClass(class, FALSE, workItem, context, mfail)
#define SetFlagsForInsVersAtParent(class, workItem, context, mfail) \
        _SetFlagsForInsVersAtClass(class, TRUE, workItem, context, mfail)

#define SetForNonIntTmCko(dialogObj, workLoc, folder, mfail) \
        _SetForNonIntTmCkoAtClass(NULL, FALSE, dialogObj, workLoc, folder, mfail)
#define SetForNonIntTmCkoAtClass(class, dialogObj, workLoc, folder, mfail) \
        _SetForNonIntTmCkoAtClass(class, FALSE, dialogObj, workLoc, folder, mfail)
#define SetForNonIntTmCkoAtParent(class, dialogObj, workLoc, folder, mfail) \
        _SetForNonIntTmCkoAtClass(class, TRUE, dialogObj, workLoc, folder, mfail)

#define SetMergeArgFromPred(mergeDialogs, mfail) \
        _SetMergeArgFromPredAtClass(NULL, FALSE, mergeDialogs, mfail)
#define SetMergeArgFromPredAtClass(class, mergeDialogs, mfail) \
        _SetMergeArgFromPredAtClass(class, FALSE, mergeDialogs, mfail)
#define SetMergeArgFromPredAtParent(class, mergeDialogs, mfail) \
        _SetMergeArgFromPredAtClass(class, TRUE, mergeDialogs, mfail)

#define SetMergeArgsFromPreds(className, mergeDialogs, mfail) \
        _SetMergeArgsFromPreds(className, FALSE, className, mergeDialogs, mfail)
#define SetMergeArgsFromPredsAtParent(_class, className, mergeDialogs, mfail) \
        _SetMergeArgsFromPreds(_class, TRUE, className, mergeDialogs, mfail)

#define SetParentFolderAttr(subFolder, parentFolder, mfail) \
        _SetParentFolderAttrAtClass(NULL, FALSE, subFolder, parentFolder, mfail)
#define SetParentFolderAttrAtClass(class, subFolder, parentFolder, mfail) \
        _SetParentFolderAttrAtClass(class, FALSE, subFolder, parentFolder, mfail)
#define SetParentFolderAttrAtParent(class, subFolder, parentFolder, mfail) \
        _SetParentFolderAttrAtClass(class, TRUE, subFolder, parentFolder, mfail)

#define SetRsvFldrOnRelated(obj, relClass, relationship, teamFolder, mfail) \
        _SetRsvFldrOnRelatedAtClass(NULL, FALSE, obj, relClass, relationship, teamFolder, mfail)
#define SetRsvFldrOnRelatedAtClass(class, obj, relClass, relationship, teamFolder, mfail) \
        _SetRsvFldrOnRelatedAtClass(class, FALSE, obj, relClass, relationship, teamFolder, mfail)
#define SetRsvFldrOnRelatedAtParent(class, obj, relClass, relationship, teamFolder, mfail) \
        _SetRsvFldrOnRelatedAtClass(class, TRUE, obj, relClass, relationship, teamFolder, mfail)

#define SetSeqForCkoFromTm(thisObj, target, isBase, dest, mfail) \
        _SetSeqForCkoFromTmAtClass(NULL, FALSE, thisObj, target, isBase, dest, mfail)
#define SetSeqForCkoFromTmAtClass(class, thisObj, target, isBase, dest, mfail) \
        _SetSeqForCkoFromTmAtClass(class, FALSE, thisObj, target, isBase, dest, mfail)
#define SetSeqForCkoFromTmAtParent(class, thisObj, target, isBase, dest, mfail) \
        _SetSeqForCkoFromTmAtClass(class, TRUE, thisObj, target, isBase, dest, mfail)

#define SetSeqForCkoToTm(thisObj, target, isBase, dest, mfail) \
        _SetSeqForCkoToTmAtClass(NULL, FALSE, thisObj, target, isBase, dest, mfail)
#define SetSeqForCkoToTmAtClass(class, thisObj, target, isBase, dest, mfail) \
        _SetSeqForCkoToTmAtClass(class, FALSE, thisObj, target, isBase, dest, mfail)
#define SetSeqForCkoToTmAtParent(class, thisObj, target, isBase, dest, mfail) \
        _SetSeqForCkoToTmAtClass(class, TRUE, thisObj, target, isBase, dest, mfail)

#define SetVerForCkoFromTm(thisObj, target, isBase, dest, mfail) \
        _SetVerForCkoFromTmAtClass(NULL, FALSE, thisObj, target, isBase, dest, mfail)
#define SetVerForCkoFromTmAtClass(class, thisObj, target, isBase, dest, mfail) \
        _SetVerForCkoFromTmAtClass(class, FALSE, thisObj, target, isBase, dest, mfail)
#define SetVerForCkoFromTmAtParent(class, thisObj, target, isBase, dest, mfail) \
        _SetVerForCkoFromTmAtClass(class, TRUE, thisObj, target, isBase, dest, mfail)

#define SetVerForCkoToTm(thisObj, target, isBase, dest, mfail) \
        _SetVerForCkoToTmAtClass(NULL, FALSE, thisObj, target, isBase, dest, mfail)
#define SetVerForCkoToTmAtClass(class, thisObj, target, isBase, dest, mfail) \
        _SetVerForCkoToTmAtClass(class, FALSE, thisObj, target, isBase, dest, mfail)
#define SetVerForCkoToTmAtParent(class, thisObj, target, isBase, dest, mfail) \
        _SetVerForCkoToTmAtClass(class, TRUE, thisObj, target, isBase, dest, mfail)

#define TranTmFromUnmgPrep(thisObj, argumentsObj, transferInfoObjs, mfail) \
        _TranTmFromUnmgPrepAtClass(NULL, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define TranTmFromUnmgPrepAtClass(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _TranTmFromUnmgPrepAtClass(class, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define TranTmFromUnmgPrepAtParent(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _TranTmFromUnmgPrepAtClass(class, TRUE, thisObj, argumentsObj, transferInfoObjs, mfail)

#define TranTmFromUnmgPrepAux(thisObj, argumentsObj, transferInfoObjs, mfail) \
        _TranTmFromUnmgPrepAuxAtClass(NULL, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define TranTmFromUnmgPrepAuxAtClass(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _TranTmFromUnmgPrepAuxAtClass(class, FALSE, thisObj, argumentsObj, transferInfoObjs, mfail)
#define TranTmFromUnmgPrepAuxAtParent(class, thisObj, argumentsObj, transferInfoObjs, mfail) \
        _TranTmFromUnmgPrepAuxAtClass(class, TRUE, thisObj, argumentsObj, transferInfoObjs, mfail)

#define TranTmFromUnmgPrepInt(thisObj, argumentsObj, mfail) \
        _TranTmFromUnmgPrepIntAtClass(NULL, FALSE, thisObj, argumentsObj, mfail)
#define TranTmFromUnmgPrepIntAtClass(class, thisObj, argumentsObj, mfail) \
        _TranTmFromUnmgPrepIntAtClass(class, FALSE, thisObj, argumentsObj, mfail)
#define TranTmFromUnmgPrepIntAtParent(class, thisObj, argumentsObj, mfail) \
        _TranTmFromUnmgPrepIntAtClass(class, TRUE, thisObj, argumentsObj, mfail)

#define TransferAuthority(thisObj, argumentsObj, mfail) \
        _TransferAuthorityAtClass(NULL, FALSE, thisObj, argumentsObj, mfail)
#define TransferAuthorityAtClass(class, thisObj, argumentsObj, mfail) \
        _TransferAuthorityAtClass(class, FALSE, thisObj, argumentsObj, mfail)
#define TransferAuthorityAtParent(class, thisObj, argumentsObj, mfail) \
        _TransferAuthorityAtClass(class, TRUE, thisObj, argumentsObj, mfail)

#define TransferAuthorityDP(thisObj, mfail) \
        _TransferAuthorityDPAtClass(NULL, FALSE, thisObj, mfail)
#define TransferAuthorityDPAtClass(class, thisObj, mfail) \
        _TransferAuthorityDPAtClass(class, FALSE, thisObj, mfail)
#define TransferAuthorityDPAtParent(class, thisObj, mfail) \
        _TransferAuthorityDPAtClass(class, TRUE, thisObj, mfail)

#define TransferAuthorityInt(thisObj, mfail) \
        _TransferAuthorityIntAtClass(NULL, FALSE, thisObj, mfail)
#define TransferAuthorityIntAtClass(class, thisObj, mfail) \
        _TransferAuthorityIntAtClass(class, FALSE, thisObj, mfail)
#define TransferAuthorityIntAtParent(class, thisObj, mfail) \
        _TransferAuthorityIntAtClass(class, TRUE, thisObj, mfail)

#define TransferReserveOwner(workItem, newOwner, mfail) \
        _TransferReserveOwnerAtClass(NULL, FALSE, workItem, newOwner, mfail)
#define TransferReserveOwnerAtClass(class, workItem, newOwner, mfail) \
        _TransferReserveOwnerAtClass(class, FALSE, workItem, newOwner, mfail)
#define TransferReserveOwnerAtParent(class, workItem, newOwner, mfail) \
        _TransferReserveOwnerAtClass(class, TRUE, workItem, newOwner, mfail)

#define TransferTmInt(thisObj, userAction, trnDialog, mfail) \
        _TransferTmIntAtClass(NULL, FALSE, thisObj, userAction, trnDialog, mfail)
#define TransferTmIntAtClass(class, thisObj, userAction, trnDialog, mfail) \
        _TransferTmIntAtClass(class, FALSE, thisObj, userAction, trnDialog, mfail)
#define TransferTmIntAtParent(class, thisObj, userAction, trnDialog, mfail) \
        _TransferTmIntAtClass(class, TRUE, thisObj, userAction, trnDialog, mfail)

#define TransferTmObject(thisObj, dialogObj, mfail) \
        _TransferTmObjectAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define TransferTmObjectAtClass(class, thisObj, dialogObj, mfail) \
        _TransferTmObjectAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define TransferTmObjectAtParent(class, thisObj, dialogObj, mfail) \
        _TransferTmObjectAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define TransferTmObjectInt(thisObj, dialogObj, mfail) \
        _TransferTmObjectIntAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define TransferTmObjectIntAtClass(class, thisObj, dialogObj, mfail) \
        _TransferTmObjectIntAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define TransferTmObjectIntAtParent(class, thisObj, dialogObj, mfail) \
        _TransferTmObjectIntAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define TransferTmSet(className, SelectedItems, mfail) \
        _TransferTmSet(className, FALSE, className, SelectedItems, mfail)
#define TransferTmSetAtParent(_class, className, SelectedItems, mfail) \
        _TransferTmSet(_class, TRUE, className, SelectedItems, mfail)

#define TransferTmSubSet(className, transferObjects, extraStr, extraObj, mfail) \
        _TransferTmSubSet(className, FALSE, className, transferObjects, extraStr, extraObj, mfail)
#define TransferTmSubSetAtParent(_class, className, transferObjects, extraStr, extraObj, mfail) \
        _TransferTmSubSet(_class, TRUE, className, transferObjects, extraStr, extraObj, mfail)

#define UnSetParentFolderAttr(subFolder, parentFolder, mfail) \
        _UnSetParentFolderAttrAtClass(NULL, FALSE, subFolder, parentFolder, mfail)
#define UnSetParentFolderAttrAtClass(class, subFolder, parentFolder, mfail) \
        _UnSetParentFolderAttrAtClass(class, FALSE, subFolder, parentFolder, mfail)
#define UnSetParentFolderAttrAtParent(class, subFolder, parentFolder, mfail) \
        _UnSetParentFolderAttrAtClass(class, TRUE, subFolder, parentFolder, mfail)

#define UpdateChildFolder(relationObj, mfail) \
        _UpdateChildFolderAtClass(NULL, FALSE, relationObj, mfail)
#define UpdateChildFolderAtClass(class, relationObj, mfail) \
        _UpdateChildFolderAtClass(class, FALSE, relationObj, mfail)
#define UpdateChildFolderAtParent(class, relationObj, mfail) \
        _UpdateChildFolderAtClass(class, TRUE, relationObj, mfail)

#define UpdateMergedItem(objToProc, dialogObj, newObjList, mfail) \
        _UpdateMergedItemAtClass(NULL, FALSE, objToProc, dialogObj, newObjList, mfail)
#define UpdateMergedItemAtClass(class, objToProc, dialogObj, newObjList, mfail) \
        _UpdateMergedItemAtClass(class, FALSE, objToProc, dialogObj, newObjList, mfail)
#define UpdateMergedItemAtParent(class, objToProc, dialogObj, newObjList, mfail) \
        _UpdateMergedItemAtClass(class, TRUE, objToProc, dialogObj, newObjList, mfail)

#define UpdateMergedItemForSet(className, objsToProc, dialogObjs, mfail) \
        _UpdateMergedItemForSet(className, FALSE, className, objsToProc, dialogObjs, mfail)
#define UpdateMergedItemForSetAtParent(_class, className, objsToProc, dialogObjs, mfail) \
        _UpdateMergedItemForSet(_class, TRUE, className, objsToProc, dialogObjs, mfail)

#define UpdateMetaForCkoFromTm(thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForCkoFromTmAtClass(NULL, FALSE, thisObj, target, refresh, isBase, dest, mfail)
#define UpdateMetaForCkoFromTmAtClass(class, thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForCkoFromTmAtClass(class, FALSE, thisObj, target, refresh, isBase, dest, mfail)
#define UpdateMetaForCkoFromTmAtParent(class, thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForCkoFromTmAtClass(class, TRUE, thisObj, target, refresh, isBase, dest, mfail)

#define UpdateMetaForCkoMkvTm(thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForCkoMkvTmAtClass(NULL, FALSE, thisObj, target, refresh, isBase, dest, mfail)
#define UpdateMetaForCkoMkvTmAtClass(class, thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForCkoMkvTmAtClass(class, FALSE, thisObj, target, refresh, isBase, dest, mfail)
#define UpdateMetaForCkoMkvTmAtParent(class, thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForCkoMkvTmAtClass(class, TRUE, thisObj, target, refresh, isBase, dest, mfail)

#define UpdateMetaForTCko(thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForTCkoAtClass(NULL, FALSE, thisObj, target, refresh, isBase, dest, mfail)
#define UpdateMetaForTCkoAtClass(class, thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForTCkoAtClass(class, FALSE, thisObj, target, refresh, isBase, dest, mfail)
#define UpdateMetaForTCkoAtParent(class, thisObj, target, refresh, isBase, dest, mfail) \
        _UpdateMetaForTCkoAtClass(class, TRUE, thisObj, target, refresh, isBase, dest, mfail)

#define UpdateTeamDefaults(className, teamName, teamDfltObj, mfail) \
        _UpdateTeamDefaults(className, FALSE, className, teamName, teamDfltObj, mfail)
#define UpdateTeamDefaultsAtParent(_class, className, teamName, teamDfltObj, mfail) \
        _UpdateTeamDefaults(_class, TRUE, className, teamName, teamDfltObj, mfail)

#define UpdateTmDfltForTeam(thisObj, mfail) \
        _UpdateTmDfltForTeamAtClass(NULL, FALSE, thisObj, mfail)
#define UpdateTmDfltForTeamAtClass(class, thisObj, mfail) \
        _UpdateTmDfltForTeamAtClass(class, FALSE, thisObj, mfail)
#define UpdateTmDfltForTeamAtParent(class, thisObj, mfail) \
        _UpdateTmDfltForTeamAtClass(class, TRUE, thisObj, mfail)

#define ValArgForMergePost(mrgDailog, mfail) \
        _ValArgForMergePostAtClass(NULL, FALSE, mrgDailog, mfail)
#define ValArgForMergePostAtClass(class, mrgDailog, mfail) \
        _ValArgForMergePostAtClass(class, FALSE, mrgDailog, mfail)
#define ValArgForMergePostAtParent(class, mrgDailog, mfail) \
        _ValArgForMergePostAtClass(class, TRUE, mrgDailog, mfail)

#define ValArgForMergePostInt(mrgDialog, mfail) \
        _ValArgForMergePostIntAtClass(NULL, FALSE, mrgDialog, mfail)
#define ValArgForMergePostIntAtClass(class, mrgDialog, mfail) \
        _ValArgForMergePostIntAtClass(class, FALSE, mrgDialog, mfail)
#define ValArgForMergePostIntAtParent(class, mrgDialog, mfail) \
        _ValArgForMergePostIntAtClass(class, TRUE, mrgDialog, mfail)

#define ValArgsForMergeSet(workItemClass, mrgDialogs, mfail) \
        _ValArgsForMergeSet(workItemClass, FALSE, workItemClass, mrgDialogs, mfail)
#define ValArgsForMergeSetAtParent(_class, workItemClass, mrgDialogs, mfail) \
        _ValArgsForMergeSet(_class, TRUE, workItemClass, mrgDialogs, mfail)

#define ValCancelReserveItem(workItem, mfail) \
        _ValCancelReserveItemAtClass(NULL, FALSE, workItem, mfail)
#define ValCancelReserveItemAtClass(class, workItem, mfail) \
        _ValCancelReserveItemAtClass(class, FALSE, workItem, mfail)
#define ValCancelReserveItemAtParent(class, workItem, mfail) \
        _ValCancelReserveItemAtClass(class, TRUE, workItem, mfail)

#define ValCancelReserveSet(workItemClass, workItems, mfail) \
        _ValCancelReserveSet(workItemClass, FALSE, workItemClass, workItems, mfail)
#define ValCancelReserveSetAtParent(_class, workItemClass, workItems, mfail) \
        _ValCancelReserveSet(_class, TRUE, workItemClass, workItems, mfail)

#define ValCheckOutItemRelsTm(thisObj, dest, refresh, isBase, mfail) \
        _ValCheckOutItemRelsTmAtClass(NULL, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ValCheckOutItemRelsTmAtClass(class, thisObj, dest, refresh, isBase, mfail) \
        _ValCheckOutItemRelsTmAtClass(class, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ValCheckOutItemRelsTmAtParent(class, thisObj, dest, refresh, isBase, mfail) \
        _ValCheckOutItemRelsTmAtClass(class, TRUE, thisObj, dest, refresh, isBase, mfail)

#define ValCkiToTmNoRplObj(thisObj, extraStr, extraObj, mfail) \
        _ValCkiToTmNoRplObjAtClass(NULL, FALSE, thisObj, extraStr, extraObj, mfail)
#define ValCkiToTmNoRplObjAtClass(class, thisObj, extraStr, extraObj, mfail) \
        _ValCkiToTmNoRplObjAtClass(class, FALSE, thisObj, extraStr, extraObj, mfail)
#define ValCkiToTmNoRplObjAtParent(class, thisObj, extraStr, extraObj, mfail) \
        _ValCkiToTmNoRplObjAtClass(class, TRUE, thisObj, extraStr, extraObj, mfail)

#define ValCkoItemRelsFromTm(thisObj, dest, refresh, isBase, mfail) \
        _ValCkoItemRelsFromTmAtClass(NULL, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ValCkoItemRelsFromTmAtClass(class, thisObj, dest, refresh, isBase, mfail) \
        _ValCkoItemRelsFromTmAtClass(class, FALSE, thisObj, dest, refresh, isBase, mfail)
#define ValCkoItemRelsFromTmAtParent(class, thisObj, dest, refresh, isBase, mfail) \
        _ValCkoItemRelsFromTmAtClass(class, TRUE, thisObj, dest, refresh, isBase, mfail)

#define ValCkoObjForCheckOutT(thisObj, ownerName, interactive, mfail) \
        _ValCkoObjForCheckOutTAtClass(NULL, FALSE, thisObj, ownerName, interactive, mfail)
#define ValCkoObjForCheckOutTAtClass(class, thisObj, ownerName, interactive, mfail) \
        _ValCkoObjForCheckOutTAtClass(class, FALSE, thisObj, ownerName, interactive, mfail)
#define ValCkoObjForCheckOutTAtParent(class, thisObj, ownerName, interactive, mfail) \
        _ValCkoObjForCheckOutTAtClass(class, TRUE, thisObj, ownerName, interactive, mfail)

#define ValCkoObjForCkoFromTm(thisObj, ownerName, interactive, mfail) \
        _ValCkoObjForCkoFromTmAtClass(NULL, FALSE, thisObj, ownerName, interactive, mfail)
#define ValCkoObjForCkoFromTmAtClass(class, thisObj, ownerName, interactive, mfail) \
        _ValCkoObjForCkoFromTmAtClass(class, FALSE, thisObj, ownerName, interactive, mfail)
#define ValCkoObjForCkoFromTmAtParent(class, thisObj, ownerName, interactive, mfail) \
        _ValCkoObjForCkoFromTmAtClass(class, TRUE, thisObj, ownerName, interactive, mfail)

#define ValCkoTestOwnForTm(thisObj, dialogObject, mfail) \
        _ValCkoTestOwnForTmAtClass(NULL, FALSE, thisObj, dialogObject, mfail)
#define ValCkoTestOwnForTmAtClass(class, thisObj, dialogObject, mfail) \
        _ValCkoTestOwnForTmAtClass(class, FALSE, thisObj, dialogObject, mfail)
#define ValCkoTestOwnForTmAtParent(class, thisObj, dialogObject, mfail) \
        _ValCkoTestOwnForTmAtClass(class, TRUE, thisObj, dialogObject, mfail)

#define ValDlgForCkoFromTmCpy(thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCkoFromTmCpyAtClass(NULL, FALSE, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForCkoFromTmCpyAtClass(class, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCkoFromTmCpyAtClass(class, FALSE, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForCkoFromTmCpyAtParent(class, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCkoFromTmCpyAtClass(class, TRUE, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail)

#define ValDlgForCkoToTmCpy(thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCkoToTmCpyAtClass(NULL, FALSE, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForCkoToTmCpyAtClass(class, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCkoToTmCpyAtClass(class, FALSE, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForCkoToTmCpyAtParent(class, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCkoToTmCpyAtClass(class, TRUE, thisObj, originClassName, originObject, extraStr, extraObj, badArgs, mfail)

#define ValDlgForPrgSet(originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForPrgSetAtClass(NULL, FALSE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForPrgSetAtClass(class, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForPrgSetAtClass(class, FALSE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForPrgSetAtParent(class, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForPrgSetAtClass(class, TRUE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)

#define ValDoCheckOutFromTm(thisObj, target, refresh, mfail) \
        _ValDoCheckOutFromTmAtClass(NULL, FALSE, thisObj, target, refresh, mfail)
#define ValDoCheckOutFromTmAtClass(class, thisObj, target, refresh, mfail) \
        _ValDoCheckOutFromTmAtClass(class, FALSE, thisObj, target, refresh, mfail)
#define ValDoCheckOutFromTmAtParent(class, thisObj, target, refresh, mfail) \
        _ValDoCheckOutFromTmAtClass(class, TRUE, thisObj, target, refresh, mfail)

#define ValDoCkoItemFromTm(thisObj, target, refresh, isBase, dest, mfail) \
        _ValDoCkoItemFromTmAtClass(NULL, FALSE, thisObj, target, refresh, isBase, dest, mfail)
#define ValDoCkoItemFromTmAtClass(class, thisObj, target, refresh, isBase, dest, mfail) \
        _ValDoCkoItemFromTmAtClass(class, FALSE, thisObj, target, refresh, isBase, dest, mfail)
#define ValDoCkoItemFromTmAtParent(class, thisObj, target, refresh, isBase, dest, mfail) \
        _ValDoCkoItemFromTmAtClass(class, TRUE, thisObj, target, refresh, isBase, dest, mfail)

#define ValDoCkoMkvCreDestObjT(thisObj, target, refresh, isBase, dest, relatedObj, mfail) \
        _ValDoCkoMkvCreDestObjTAtClass(NULL, FALSE, thisObj, target, refresh, isBase, dest, relatedObj, mfail)
#define ValDoCkoMkvCreDestObjTAtClass(class, thisObj, target, refresh, isBase, dest, relatedObj, mfail) \
        _ValDoCkoMkvCreDestObjTAtClass(class, FALSE, thisObj, target, refresh, isBase, dest, relatedObj, mfail)
#define ValDoCkoMkvCreDestObjTAtParent(class, thisObj, target, refresh, isBase, dest, relatedObj, mfail) \
        _ValDoCkoMkvCreDestObjTAtClass(class, TRUE, thisObj, target, refresh, isBase, dest, relatedObj, mfail)

#define ValDoCkoTMkvCreDestObj(thisObj, target, refresh, isBase, oldName, dest, relatedObj, mfail) \
        _ValDoCkoTMkvCreDestObjAtClass(NULL, FALSE, thisObj, target, refresh, isBase, oldName, dest, relatedObj, mfail)
#define ValDoCkoTMkvCreDestObjAtClass(class, thisObj, target, refresh, isBase, oldName, dest, relatedObj, mfail) \
        _ValDoCkoTMkvCreDestObjAtClass(class, FALSE, thisObj, target, refresh, isBase, oldName, dest, relatedObj, mfail)
#define ValDoCkoTMkvCreDestObjAtParent(class, thisObj, target, refresh, isBase, oldName, dest, relatedObj, mfail) \
        _ValDoCkoTMkvCreDestObjAtClass(class, TRUE, thisObj, target, refresh, isBase, oldName, dest, relatedObj, mfail)

#define ValDomainForCheckOutT(thisObj, isLocal, mfail) \
        _ValDomainForCheckOutTAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCheckOutTAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForCheckOutTAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCheckOutTAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForCheckOutTAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForCkoFromTm(thisObj, isLocal, mfail) \
        _ValDomainForCkoFromTmAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCkoFromTmAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForCkoFromTmAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCkoFromTmAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForCkoFromTmAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForMoveToFldr(thisObj, isLocal, mfail) \
        _ValDomainForMoveToFldrAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForMoveToFldrAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForMoveToFldrAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForMoveToFldrAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForMoveToFldrAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForRelease(thisObj, isLocal, mfail) \
        _ValDomainForReleaseAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForReleaseAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForReleaseAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForReleaseAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForReleaseAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValERORelForMrgVer(thisObj, source, dest, answer, mfail) \
        _ValERORelForMrgVerAtClass(NULL, FALSE, thisObj, source, dest, answer, mfail)
#define ValERORelForMrgVerAtClass(class, thisObj, source, dest, answer, mfail) \
        _ValERORelForMrgVerAtClass(class, FALSE, thisObj, source, dest, answer, mfail)
#define ValERORelForMrgVerAtParent(class, thisObj, source, dest, answer, mfail) \
        _ValERORelForMrgVerAtClass(class, TRUE, thisObj, source, dest, answer, mfail)

#define ValFldrAndTeamName(thisObj, frmfldrName, frmteamName, mfail) \
        _ValFldrAndTeamNameAtClass(NULL, FALSE, thisObj, frmfldrName, frmteamName, mfail)
#define ValFldrAndTeamNameAtClass(class, thisObj, frmfldrName, frmteamName, mfail) \
        _ValFldrAndTeamNameAtClass(class, FALSE, thisObj, frmfldrName, frmteamName, mfail)
#define ValFldrAndTeamNameAtParent(class, thisObj, frmfldrName, frmteamName, mfail) \
        _ValFldrAndTeamNameAtClass(class, TRUE, thisObj, frmfldrName, frmteamName, mfail)

#define ValForCheckInToTmDest(thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail) \
        _ValForCheckInToTmDestAtClass(NULL, FALSE, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail)
#define ValForCheckInToTmDestAtClass(class, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail) \
        _ValForCheckInToTmDestAtClass(class, FALSE, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail)
#define ValForCheckInToTmDestAtParent(class, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail) \
        _ValForCheckInToTmDestAtClass(class, TRUE, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail)

#define ValForCiiAttmntToTm(thisObj, mfail) \
        _ValForCiiAttmntToTmAtClass(NULL, FALSE, thisObj, mfail)
#define ValForCiiAttmntToTmAtClass(class, thisObj, mfail) \
        _ValForCiiAttmntToTmAtClass(class, FALSE, thisObj, mfail)
#define ValForCiiAttmntToTmAtParent(class, thisObj, mfail) \
        _ValForCiiAttmntToTmAtClass(class, TRUE, thisObj, mfail)

#define ValForCinAttmntToTm(thisObj, mfail) \
        _ValForCinAttmntToTmAtClass(NULL, FALSE, thisObj, mfail)
#define ValForCinAttmntToTmAtClass(class, thisObj, mfail) \
        _ValForCinAttmntToTmAtClass(class, FALSE, thisObj, mfail)
#define ValForCinAttmntToTmAtParent(class, thisObj, mfail) \
        _ValForCinAttmntToTmAtClass(class, TRUE, thisObj, mfail)

#define ValForCirAttmntToTm(thisObj, mfail) \
        _ValForCirAttmntToTmAtClass(NULL, FALSE, thisObj, mfail)
#define ValForCirAttmntToTmAtClass(class, thisObj, mfail) \
        _ValForCirAttmntToTmAtClass(class, FALSE, thisObj, mfail)
#define ValForCirAttmntToTmAtParent(class, thisObj, mfail) \
        _ValForCirAttmntToTmAtClass(class, TRUE, thisObj, mfail)

#define ValForCkiNoRplToTm(thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _ValForCkiNoRplToTmAtClass(NULL, FALSE, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define ValForCkiNoRplToTmAtClass(class, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _ValForCkiNoRplToTmAtClass(class, FALSE, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define ValForCkiNoRplToTmAtParent(class, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _ValForCkiNoRplToTmAtClass(class, TRUE, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define ValForCkoFromTmSet(className, checkOutObjects, mfail) \
        _ValForCkoFromTmSet(className, FALSE, className, checkOutObjects, mfail)
#define ValForCkoFromTmSetAtParent(_class, className, checkOutObjects, mfail) \
        _ValForCkoFromTmSet(_class, TRUE, className, checkOutObjects, mfail)

#define ValForMakeAvailNSecure(thisObj, mfail) \
        _ValForMakeAvailNSecureAtClass(NULL, FALSE, thisObj, mfail)
#define ValForMakeAvailNSecureAtClass(class, thisObj, mfail) \
        _ValForMakeAvailNSecureAtClass(class, FALSE, thisObj, mfail)
#define ValForMakeAvailNSecureAtParent(class, thisObj, mfail) \
        _ValForMakeAvailNSecureAtClass(class, TRUE, thisObj, mfail)

#define ValForMakeAvailSecure(thisObj, mfail) \
        _ValForMakeAvailSecureAtClass(NULL, FALSE, thisObj, mfail)
#define ValForMakeAvailSecureAtClass(class, thisObj, mfail) \
        _ValForMakeAvailSecureAtClass(class, FALSE, thisObj, mfail)
#define ValForMakeAvailSecureAtParent(class, thisObj, mfail) \
        _ValForMakeAvailSecureAtClass(class, TRUE, thisObj, mfail)

#define ValForMergeVersions(workItemClass, workItems, failedItems, mfail) \
        _ValForMergeVersions(workItemClass, FALSE, workItemClass, workItems, failedItems, mfail)
#define ValForMergeVersionsAtParent(_class, workItemClass, workItems, failedItems, mfail) \
        _ValForMergeVersions(_class, TRUE, workItemClass, workItems, failedItems, mfail)

#define ValForRelToRepliOdr(thisObj, mfail) \
        _ValForRelToRepliOdrAtClass(NULL, FALSE, thisObj, mfail)
#define ValForRelToRepliOdrAtClass(class, thisObj, mfail) \
        _ValForRelToRepliOdrAtClass(class, FALSE, thisObj, mfail)
#define ValForRelToRepliOdrAtParent(class, thisObj, mfail) \
        _ValForRelToRepliOdrAtClass(class, TRUE, thisObj, mfail)

#define ValForReleaseAttmnt(thisObj, mfail) \
        _ValForReleaseAttmntAtClass(NULL, FALSE, thisObj, mfail)
#define ValForReleaseAttmntAtClass(class, thisObj, mfail) \
        _ValForReleaseAttmntAtClass(class, FALSE, thisObj, mfail)
#define ValForReleaseAttmntAtParent(class, thisObj, mfail) \
        _ValForReleaseAttmntAtClass(class, TRUE, thisObj, mfail)

#define ValForReleaseNoRpl(thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _ValForReleaseNoRplAtClass(NULL, FALSE, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define ValForReleaseNoRplAtClass(class, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _ValForReleaseNoRplAtClass(class, FALSE, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)
#define ValForReleaseNoRplAtParent(class, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail) \
        _ValForReleaseNoRplAtClass(class, TRUE, thisObj, destOwnerObj, destOwnerDirObj, extraStr, extraObj, mfail)

#define ValForReleaseToDest(thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail) \
        _ValForReleaseToDestAtClass(NULL, FALSE, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail)
#define ValForReleaseToDestAtClass(class, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail) \
        _ValForReleaseToDestAtClass(class, FALSE, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail)
#define ValForReleaseToDestAtParent(class, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail) \
        _ValForReleaseToDestAtClass(class, TRUE, thisObj, target, isBaseObj, extraStr, extraObj, destObj, mfail)

#define ValForReserveVersion(workItem, mfail) \
        _ValForReserveVersionAtClass(NULL, FALSE, workItem, mfail)
#define ValForReserveVersionAtClass(class, workItem, mfail) \
        _ValForReserveVersionAtClass(class, FALSE, workItem, mfail)
#define ValForReserveVersionAtParent(class, workItem, mfail) \
        _ValForReserveVersionAtClass(class, TRUE, workItem, mfail)

#define ValForReserveVersions(workItemClass, workItems, mfail) \
        _ValForReserveVersions(workItemClass, FALSE, workItemClass, workItems, mfail)
#define ValForReserveVersionsAtParent(_class, workItemClass, workItems, mfail) \
        _ValForReserveVersions(_class, TRUE, workItemClass, workItems, mfail)

#define ValForRlsRAttmnt(thisObj, mfail) \
        _ValForRlsRAttmntAtClass(NULL, FALSE, thisObj, mfail)
#define ValForRlsRAttmntAtClass(class, thisObj, mfail) \
        _ValForRlsRAttmntAtClass(class, FALSE, thisObj, mfail)
#define ValForRlsRAttmntAtParent(class, thisObj, mfail) \
        _ValForRlsRAttmntAtClass(class, TRUE, thisObj, mfail)

#define ValIfPurgeAllowed(thisObj, relationObj, mfail) \
        _ValIfPurgeAllowedAtClass(NULL, FALSE, thisObj, relationObj, mfail)
#define ValIfPurgeAllowedAtClass(class, thisObj, relationObj, mfail) \
        _ValIfPurgeAllowedAtClass(class, FALSE, thisObj, relationObj, mfail)
#define ValIfPurgeAllowedAtParent(class, thisObj, relationObj, mfail) \
        _ValIfPurgeAllowedAtClass(class, TRUE, thisObj, relationObj, mfail)

#define ValIfPurgeAllowedWrp(thisObj, relationObj, mfail) \
        _ValIfPurgeAllowedWrpAtClass(NULL, FALSE, thisObj, relationObj, mfail)
#define ValIfPurgeAllowedWrpAtClass(class, thisObj, relationObj, mfail) \
        _ValIfPurgeAllowedWrpAtClass(class, FALSE, thisObj, relationObj, mfail)
#define ValIfPurgeAllowedWrpAtParent(class, thisObj, relationObj, mfail) \
        _ValIfPurgeAllowedWrpAtClass(class, TRUE, thisObj, relationObj, mfail)

#define ValItemClassInSet(classToMatch, setToVerify, mfail) \
        _ValItemClassInSet(classToMatch, FALSE, classToMatch, setToVerify, mfail)
#define ValItemClassInSetAtParent(_class, classToMatch, setToVerify, mfail) \
        _ValItemClassInSet(_class, TRUE, classToMatch, setToVerify, mfail)

#define ValItemDestForCkoMkvTm(thisObj, dest, target, refresh, isBase, mfail) \
        _ValItemDestForCkoMkvTmAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define ValItemDestForCkoMkvTmAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _ValItemDestForCkoMkvTmAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define ValItemDestForCkoMkvTmAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _ValItemDestForCkoMkvTmAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define ValItemForMergeVers(argObj, pred, mfail) \
        _ValItemForMergeVersAtClass(NULL, FALSE, argObj, pred, mfail)
#define ValItemForMergeVersAtClass(class, argObj, pred, mfail) \
        _ValItemForMergeVersAtClass(class, FALSE, argObj, pred, mfail)
#define ValItemForMergeVersAtParent(class, argObj, pred, mfail) \
        _ValItemForMergeVersAtClass(class, TRUE, argObj, pred, mfail)

#define ValItemForMergeVersInt(argObj, pred, mfail) \
        _ValItemForMergeVersIntAtClass(NULL, FALSE, argObj, pred, mfail)
#define ValItemForMergeVersIntAtClass(class, argObj, pred, mfail) \
        _ValItemForMergeVersIntAtClass(class, FALSE, argObj, pred, mfail)
#define ValItemForMergeVersIntAtParent(class, argObj, pred, mfail) \
        _ValItemForMergeVersIntAtClass(class, TRUE, argObj, pred, mfail)

#define ValItemRelsForMerge(mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail) \
        _ValItemRelsForMergeAtClass(NULL, FALSE, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail)
#define ValItemRelsForMergeAtClass(class, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail) \
        _ValItemRelsForMergeAtClass(class, FALSE, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail)
#define ValItemRelsForMergeAtParent(class, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail) \
        _ValItemRelsForMergeAtClass(class, TRUE, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail)

#define ValItemRelsForMrgVers(mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail) \
        _ValItemRelsForMrgVersAtClass(NULL, FALSE, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail)
#define ValItemRelsForMrgVersAtClass(class, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail) \
        _ValItemRelsForMrgVersAtClass(class, FALSE, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail)
#define ValItemRelsForMrgVersAtParent(class, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail) \
        _ValItemRelsForMrgVersAtClass(class, TRUE, mergeObj, mergeArg, relCreateDialogs, relClassNames, mergeObjRoles, otherSideObjs, mfail)

#define ValItmDestForCkoFromTm(thisObj, dest, target, refresh, isBase, mfail) \
        _ValItmDestForCkoFromTmAtClass(NULL, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define ValItmDestForCkoFromTmAtClass(class, thisObj, dest, target, refresh, isBase, mfail) \
        _ValItmDestForCkoFromTmAtClass(class, FALSE, thisObj, dest, target, refresh, isBase, mfail)
#define ValItmDestForCkoFromTmAtParent(class, thisObj, dest, target, refresh, isBase, mfail) \
        _ValItmDestForCkoFromTmAtClass(class, TRUE, thisObj, dest, target, refresh, isBase, mfail)

#define ValOwnerForReserve(ownerObj, workItem, rsvArgObject, mfail) \
        _ValOwnerForReserveAtClass(NULL, FALSE, ownerObj, workItem, rsvArgObject, mfail)
#define ValOwnerForReserveAtClass(class, ownerObj, workItem, rsvArgObject, mfail) \
        _ValOwnerForReserveAtClass(class, FALSE, ownerObj, workItem, rsvArgObject, mfail)
#define ValOwnerForReserveAtParent(class, ownerObj, workItem, rsvArgObject, mfail) \
        _ValOwnerForReserveAtClass(class, TRUE, ownerObj, workItem, rsvArgObject, mfail)

#define ValPrdItmRlsForCinToTm(thisObj, succ, isBaseObj, mfail) \
        _ValPrdItmRlsForCinToTmAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPrdItmRlsForCinToTmAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _ValPrdItmRlsForCinToTmAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPrdItmRlsForCinToTmAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _ValPrdItmRlsForCinToTmAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define ValPredForCinToTm(thisObj, succ, isBaseObj, mfail) \
        _ValPredForCinToTmAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredForCinToTmAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredForCinToTmAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredForCinToTmAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredForCinToTmAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define ValPredForCkiReplcToTm(thisObj, action, actionCode, isBaseObj, mfail) \
        _ValPredForCkiReplcToTmAtClass(NULL, FALSE, thisObj, action, actionCode, isBaseObj, mfail)
#define ValPredForCkiReplcToTmAtClass(class, thisObj, action, actionCode, isBaseObj, mfail) \
        _ValPredForCkiReplcToTmAtClass(class, FALSE, thisObj, action, actionCode, isBaseObj, mfail)
#define ValPredForCkiReplcToTmAtParent(class, thisObj, action, actionCode, isBaseObj, mfail) \
        _ValPredForCkiReplcToTmAtClass(class, TRUE, thisObj, action, actionCode, isBaseObj, mfail)

#define ValPredForRelease(thisObj, succ, isBaseObj, mfail) \
        _ValPredForReleaseAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredForReleaseAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredForReleaseAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredForReleaseAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredForReleaseAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define ValPredForRelseReplc(thisObj, action, actionCode, isBaseObj, mfail) \
        _ValPredForRelseReplcAtClass(NULL, FALSE, thisObj, action, actionCode, isBaseObj, mfail)
#define ValPredForRelseReplcAtClass(class, thisObj, action, actionCode, isBaseObj, mfail) \
        _ValPredForRelseReplcAtClass(class, FALSE, thisObj, action, actionCode, isBaseObj, mfail)
#define ValPredForRelseReplcAtParent(class, thisObj, action, actionCode, isBaseObj, mfail) \
        _ValPredForRelseReplcAtClass(class, TRUE, thisObj, action, actionCode, isBaseObj, mfail)

#define ValPredItemForCinToTm(thisObj, succ, isBaseObj, mfail) \
        _ValPredItemForCinToTmAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredItemForCinToTmAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredItemForCinToTmAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredItemForCinToTmAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredItemForCinToTmAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define ValPredItemForRelease(thisObj, succ, isBaseObj, mfail) \
        _ValPredItemForReleaseAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredItemForReleaseAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredItemForReleaseAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredItemForReleaseAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredItemForReleaseAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define ValPredItemRelsForRel(thisObj, succ, isBaseObj, mfail) \
        _ValPredItemRelsForRelAtClass(NULL, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredItemRelsForRelAtClass(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredItemRelsForRelAtClass(class, FALSE, thisObj, succ, isBaseObj, mfail)
#define ValPredItemRelsForRelAtParent(class, thisObj, succ, isBaseObj, mfail) \
        _ValPredItemRelsForRelAtClass(class, TRUE, thisObj, succ, isBaseObj, mfail)

#define ValPredRForCinToTm(thisObj, pred, succ, isBaseObj, mfail) \
        _ValPredRForCinToTmAtClass(NULL, FALSE, thisObj, pred, succ, isBaseObj, mfail)
#define ValPredRForCinToTmAtClass(class, thisObj, pred, succ, isBaseObj, mfail) \
        _ValPredRForCinToTmAtClass(class, FALSE, thisObj, pred, succ, isBaseObj, mfail)
#define ValPredRForCinToTmAtParent(class, thisObj, pred, succ, isBaseObj, mfail) \
        _ValPredRForCinToTmAtClass(class, TRUE, thisObj, pred, succ, isBaseObj, mfail)

#define ValPredRelForCirToTm(thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail) \
        _ValPredRelForCirToTmAtClass(NULL, FALSE, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail)
#define ValPredRelForCirToTmAtClass(class, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail) \
        _ValPredRelForCirToTmAtClass(class, FALSE, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail)
#define ValPredRelForCirToTmAtParent(class, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail) \
        _ValPredRelForCirToTmAtClass(class, TRUE, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail)

#define ValPredRelForRelease(thisObj, pred, succ, isBaseObj, mfail) \
        _ValPredRelForReleaseAtClass(NULL, FALSE, thisObj, pred, succ, isBaseObj, mfail)
#define ValPredRelForReleaseAtClass(class, thisObj, pred, succ, isBaseObj, mfail) \
        _ValPredRelForReleaseAtClass(class, FALSE, thisObj, pred, succ, isBaseObj, mfail)
#define ValPredRelForReleaseAtParent(class, thisObj, pred, succ, isBaseObj, mfail) \
        _ValPredRelForReleaseAtClass(class, TRUE, thisObj, pred, succ, isBaseObj, mfail)

#define ValRelForMergePost(mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelForMergePostAtClass(NULL, FALSE, mrgDialogs, newItems, otherSideItems, mfail)
#define ValRelForMergePostAtClass(class, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelForMergePostAtClass(class, FALSE, mrgDialogs, newItems, otherSideItems, mfail)
#define ValRelForMergePostAtParent(class, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelForMergePostAtClass(class, TRUE, mrgDialogs, newItems, otherSideItems, mfail)

#define ValRelForMergePre(mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelForMergePreAtClass(NULL, FALSE, mrgDialogs, newItems, otherSideItems, mfail)
#define ValRelForMergePreAtClass(class, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelForMergePreAtClass(class, FALSE, mrgDialogs, newItems, otherSideItems, mfail)
#define ValRelForMergePreAtParent(class, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelForMergePreAtClass(class, TRUE, mrgDialogs, newItems, otherSideItems, mfail)

#define ValRelsForMergePost(workItemClass, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelsForMergePost(workItemClass, FALSE, workItemClass, mrgDialogs, newItems, otherSideItems, mfail)
#define ValRelsForMergePostAtParent(_class, workItemClass, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelsForMergePost(_class, TRUE, workItemClass, mrgDialogs, newItems, otherSideItems, mfail)

#define ValRelsForMergePre(workItemClass, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelsForMergePre(workItemClass, FALSE, workItemClass, mrgDialogs, newItems, otherSideItems, mfail)
#define ValRelsForMergePreAtParent(_class, workItemClass, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValRelsForMergePre(_class, TRUE, workItemClass, mrgDialogs, newItems, otherSideItems, mfail)

#define ValSccAndPrdForCirToTm(thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSccAndPrdForCirToTmAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)
#define ValSccAndPrdForCirToTmAtClass(class, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSccAndPrdForCirToTmAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)
#define ValSccAndPrdForCirToTmAtParent(class, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSccAndPrdForCirToTmAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)

#define ValSccItmRlsForCinToTm(thisObj, pred, isBaseObj, mfail) \
        _ValSccItmRlsForCinToTmAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSccItmRlsForCinToTmAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _ValSccItmRlsForCinToTmAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSccItmRlsForCinToTmAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _ValSccItmRlsForCinToTmAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define ValSccPrdRlsForCirToTm(thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSccPrdRlsForCirToTmAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)
#define ValSccPrdRlsForCirToTmAtClass(class, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSccPrdRlsForCirToTmAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)
#define ValSccPrdRlsForCirToTmAtParent(class, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSccPrdRlsForCirToTmAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)

#define ValSetForPurge(originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail) \
        _ValSetForPurge(originClassName, FALSE, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail)
#define ValSetForPurgeAtParent(_class, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail) \
        _ValSetForPurge(_class, TRUE, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail)

#define ValSetForPurgePost(originClassName, passedObjects, failedObjects, mfail) \
        _ValSetForPurgePost(originClassName, FALSE, originClassName, passedObjects, failedObjects, mfail)
#define ValSetForPurgePostAtParent(_class, originClassName, passedObjects, failedObjects, mfail) \
        _ValSetForPurgePost(_class, TRUE, originClassName, passedObjects, failedObjects, mfail)

#define ValSetForPurgePre(originClassName, originObjects, mfail) \
        _ValSetForPurgePre(originClassName, FALSE, originClassName, originObjects, mfail)
#define ValSetForPurgePreAtParent(_class, originClassName, originObjects, mfail) \
        _ValSetForPurgePre(_class, TRUE, originClassName, originObjects, mfail)

#define ValSuccAndPredForRlsR(thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccAndPredForRlsRAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)
#define ValSuccAndPredForRlsRAtClass(class, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccAndPredForRlsRAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)
#define ValSuccAndPredForRlsRAtParent(class, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccAndPredForRlsRAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)

#define ValSuccForCinToTm(thisObj, pred, isBaseObj, mfail) \
        _ValSuccForCinToTmAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccForCinToTmAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccForCinToTmAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccForCinToTmAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccForCinToTmAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define ValSuccForRelease(thisObj, pred, isBaseObj, mfail) \
        _ValSuccForReleaseAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccForReleaseAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccForReleaseAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccForReleaseAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccForReleaseAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define ValSuccItemForCinToTm(thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemForCinToTmAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccItemForCinToTmAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemForCinToTmAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccItemForCinToTmAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemForCinToTmAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define ValSuccItemForRelease(thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemForReleaseAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccItemForReleaseAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemForReleaseAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccItemForReleaseAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemForReleaseAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define ValSuccItemRelsForRel(thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemRelsForRelAtClass(NULL, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccItemRelsForRelAtClass(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemRelsForRelAtClass(class, FALSE, thisObj, pred, isBaseObj, mfail)
#define ValSuccItemRelsForRelAtParent(class, thisObj, pred, isBaseObj, mfail) \
        _ValSuccItemRelsForRelAtClass(class, TRUE, thisObj, pred, isBaseObj, mfail)

#define ValSuccPredRelsForRlsR(thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccPredRelsForRlsRAtClass(NULL, FALSE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)
#define ValSuccPredRelsForRlsRAtClass(class, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccPredRelsForRlsRAtClass(class, FALSE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)
#define ValSuccPredRelsForRlsRAtParent(class, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccPredRelsForRlsRAtClass(class, TRUE, thisObj, action, actionCode, pred, isBaseObj, hasAttacher, mfail)

#define ValSuccRForCinToTm(thisObj, succ, pred, isBaseObj, mfail) \
        _ValSuccRForCinToTmAtClass(NULL, FALSE, thisObj, succ, pred, isBaseObj, mfail)
#define ValSuccRForCinToTmAtClass(class, thisObj, succ, pred, isBaseObj, mfail) \
        _ValSuccRForCinToTmAtClass(class, FALSE, thisObj, succ, pred, isBaseObj, mfail)
#define ValSuccRForCinToTmAtParent(class, thisObj, succ, pred, isBaseObj, mfail) \
        _ValSuccRForCinToTmAtClass(class, TRUE, thisObj, succ, pred, isBaseObj, mfail)

#define ValSuccRelForCirToTm(thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccRelForCirToTmAtClass(NULL, FALSE, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail)
#define ValSuccRelForCirToTmAtClass(class, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccRelForCirToTmAtClass(class, FALSE, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail)
#define ValSuccRelForCirToTmAtParent(class, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail) \
        _ValSuccRelForCirToTmAtClass(class, TRUE, thisObj, action, actionCode, succ, pred, isBaseObj, hasAttacher, mfail)

#define ValSuccRelForRelease(thisObj, succ, pred, isBaseObj, mfail) \
        _ValSuccRelForReleaseAtClass(NULL, FALSE, thisObj, succ, pred, isBaseObj, mfail)
#define ValSuccRelForReleaseAtClass(class, thisObj, succ, pred, isBaseObj, mfail) \
        _ValSuccRelForReleaseAtClass(class, FALSE, thisObj, succ, pred, isBaseObj, mfail)
#define ValSuccRelForReleaseAtParent(class, thisObj, succ, pred, isBaseObj, mfail) \
        _ValSuccRelForReleaseAtClass(class, TRUE, thisObj, succ, pred, isBaseObj, mfail)

#define ValidateArgForReserve(rsvArgObject, mfail) \
        _ValidateArgForReserveAtClass(NULL, FALSE, rsvArgObject, mfail)
#define ValidateArgForReserveAtClass(class, rsvArgObject, mfail) \
        _ValidateArgForReserveAtClass(class, FALSE, rsvArgObject, mfail)
#define ValidateArgForReserveAtParent(class, rsvArgObject, mfail) \
        _ValidateArgForReserveAtClass(class, TRUE, rsvArgObject, mfail)

#define ValidateArgsForReserve(rsvArgsClass, rsvArgObjects, mfail) \
        _ValidateArgsForReserve(rsvArgsClass, FALSE, rsvArgsClass, rsvArgObjects, mfail)
#define ValidateArgsForReserveAtParent(_class, rsvArgsClass, rsvArgObjects, mfail) \
        _ValidateArgsForReserve(_class, TRUE, rsvArgsClass, rsvArgObjects, mfail)

#define ValidateCkiRplObjToTm(thisObj, extraStr, extraObj, mfail) \
        _ValidateCkiRplObjToTmAtClass(NULL, FALSE, thisObj, extraStr, extraObj, mfail)
#define ValidateCkiRplObjToTmAtClass(class, thisObj, extraStr, extraObj, mfail) \
        _ValidateCkiRplObjToTmAtClass(class, FALSE, thisObj, extraStr, extraObj, mfail)
#define ValidateCkiRplObjToTmAtParent(class, thisObj, extraStr, extraObj, mfail) \
        _ValidateCkiRplObjToTmAtClass(class, TRUE, thisObj, extraStr, extraObj, mfail)

#define ValidateDoCheckOutT(thisObj, target, refresh, oldName, mfail) \
        _ValidateDoCheckOutTAtClass(NULL, FALSE, thisObj, target, refresh, oldName, mfail)
#define ValidateDoCheckOutTAtClass(class, thisObj, target, refresh, oldName, mfail) \
        _ValidateDoCheckOutTAtClass(class, FALSE, thisObj, target, refresh, oldName, mfail)
#define ValidateDoCheckOutTAtParent(class, thisObj, target, refresh, oldName, mfail) \
        _ValidateDoCheckOutTAtClass(class, TRUE, thisObj, target, refresh, oldName, mfail)

#define ValidateDoCheckOutTItm(thisObj, target, refresh, isBase, oldName, dest, mfail) \
        _ValidateDoCheckOutTItmAtClass(NULL, FALSE, thisObj, target, refresh, isBase, oldName, dest, mfail)
#define ValidateDoCheckOutTItmAtClass(class, thisObj, target, refresh, isBase, oldName, dest, mfail) \
        _ValidateDoCheckOutTItmAtClass(class, FALSE, thisObj, target, refresh, isBase, oldName, dest, mfail)
#define ValidateDoCheckOutTItmAtParent(class, thisObj, target, refresh, isBase, oldName, dest, mfail) \
        _ValidateDoCheckOutTItmAtClass(class, TRUE, thisObj, target, refresh, isBase, oldName, dest, mfail)

#define ValidateForCheckOutT(thisObj, mfail) \
        _ValidateForCheckOutTAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForCheckOutTAtClass(class, thisObj, mfail) \
        _ValidateForCheckOutTAtClass(class, FALSE, thisObj, mfail)
#define ValidateForCheckOutTAtParent(class, thisObj, mfail) \
        _ValidateForCheckOutTAtClass(class, TRUE, thisObj, mfail)

#define ValidateForCirToTeam(thisObj, mfail) \
        _ValidateForCirToTeamAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForCirToTeamAtClass(class, thisObj, mfail) \
        _ValidateForCirToTeamAtClass(class, FALSE, thisObj, mfail)
#define ValidateForCirToTeamAtParent(class, thisObj, mfail) \
        _ValidateForCirToTeamAtClass(class, TRUE, thisObj, mfail)

#define ValidateForCkiToTeam(thisObj, mfail) \
        _ValidateForCkiToTeamAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForCkiToTeamAtClass(class, thisObj, mfail) \
        _ValidateForCkiToTeamAtClass(class, FALSE, thisObj, mfail)
#define ValidateForCkiToTeamAtParent(class, thisObj, mfail) \
        _ValidateForCkiToTeamAtClass(class, TRUE, thisObj, mfail)

#define ValidateForCkoFromTeam(thisObj, mfail) \
        _ValidateForCkoFromTeamAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForCkoFromTeamAtClass(class, thisObj, mfail) \
        _ValidateForCkoFromTeamAtClass(class, FALSE, thisObj, mfail)
#define ValidateForCkoFromTeamAtParent(class, thisObj, mfail) \
        _ValidateForCkoFromTeamAtClass(class, TRUE, thisObj, mfail)

#define ValidateForCopyT(thisObj, mfail) \
        _ValidateForCopyTAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForCopyTAtClass(class, thisObj, mfail) \
        _ValidateForCopyTAtClass(class, FALSE, thisObj, mfail)
#define ValidateForCopyTAtParent(class, thisObj, mfail) \
        _ValidateForCopyTAtClass(class, TRUE, thisObj, mfail)

#define ValidateForInsVersnSet(workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _ValidateForInsVersnSet(workItemClass, FALSE, workItemClass, insertObjs, predObjs, succObjs, mfail)
#define ValidateForInsVersnSetAtParent(_class, workItemClass, insertObjs, predObjs, succObjs, mfail) \
        _ValidateForInsVersnSet(_class, TRUE, workItemClass, insertObjs, predObjs, succObjs, mfail)

#define ValidateForMergeRel(className, relCreDialog, leftObj, rightObj, mfail) \
        _ValidateForMergeRel(className, FALSE, className, relCreDialog, leftObj, rightObj, mfail)
#define ValidateForMergeRelAtParent(_class, className, relCreDialog, leftObj, rightObj, mfail) \
        _ValidateForMergeRel(_class, TRUE, className, relCreDialog, leftObj, rightObj, mfail)

#define ValidateForMoveToFldr(thisObj, mfail) \
        _ValidateForMoveToFldrAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForMoveToFldrAtClass(class, thisObj, mfail) \
        _ValidateForMoveToFldrAtClass(class, FALSE, thisObj, mfail)
#define ValidateForMoveToFldrAtParent(class, thisObj, mfail) \
        _ValidateForMoveToFldrAtClass(class, TRUE, thisObj, mfail)

#define ValidateForPurge(thisObj, relationObj, recurSetPtr, classAnswersSetPtr, mfail) \
        _ValidateForPurgeAtClass(NULL, FALSE, thisObj, relationObj, recurSetPtr, classAnswersSetPtr, mfail)
#define ValidateForPurgeAtClass(class, thisObj, relationObj, recurSetPtr, classAnswersSetPtr, mfail) \
        _ValidateForPurgeAtClass(class, FALSE, thisObj, relationObj, recurSetPtr, classAnswersSetPtr, mfail)
#define ValidateForPurgeAtParent(class, thisObj, relationObj, recurSetPtr, classAnswersSetPtr, mfail) \
        _ValidateForPurgeAtClass(class, TRUE, thisObj, relationObj, recurSetPtr, classAnswersSetPtr, mfail)

#define ValidateForPurgeAux(thisObj, preds, mfail) \
        _ValidateForPurgeAuxAtClass(NULL, FALSE, thisObj, preds, mfail)
#define ValidateForPurgeAuxAtClass(class, thisObj, preds, mfail) \
        _ValidateForPurgeAuxAtClass(class, FALSE, thisObj, preds, mfail)
#define ValidateForPurgeAuxAtParent(class, thisObj, preds, mfail) \
        _ValidateForPurgeAuxAtClass(class, TRUE, thisObj, preds, mfail)

#define ValidateForPurgeExt(thisObj, mfail) \
        _ValidateForPurgeExtAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForPurgeExtAtClass(class, thisObj, mfail) \
        _ValidateForPurgeExtAtClass(class, FALSE, thisObj, mfail)
#define ValidateForPurgeExtAtParent(class, thisObj, mfail) \
        _ValidateForPurgeExtAtClass(class, TRUE, thisObj, mfail)

#define ValidateForRelease(thisObj, mfail) \
        _ValidateForReleaseAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForReleaseAtClass(class, thisObj, mfail) \
        _ValidateForReleaseAtClass(class, FALSE, thisObj, mfail)
#define ValidateForReleaseAtParent(class, thisObj, mfail) \
        _ValidateForReleaseAtClass(class, TRUE, thisObj, mfail)

#define ValidateForReleaseExt(thisObj, mfail) \
        _ValidateForReleaseExtAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForReleaseExtAtClass(class, thisObj, mfail) \
        _ValidateForReleaseExtAtClass(class, FALSE, thisObj, mfail)
#define ValidateForReleaseExtAtParent(class, thisObj, mfail) \
        _ValidateForReleaseExtAtClass(class, TRUE, thisObj, mfail)

#define ValidateForRenameFldr(thisObj, mfail) \
        _ValidateForRenameFldrAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForRenameFldrAtClass(class, thisObj, mfail) \
        _ValidateForRenameFldrAtClass(class, FALSE, thisObj, mfail)
#define ValidateForRenameFldrAtParent(class, thisObj, mfail) \
        _ValidateForRenameFldrAtClass(class, TRUE, thisObj, mfail)

#define ValidateForReserveItem(workItem, rsvArgObject, mfail) \
        _ValidateForReserveItemAtClass(NULL, FALSE, workItem, rsvArgObject, mfail)
#define ValidateForReserveItemAtClass(class, workItem, rsvArgObject, mfail) \
        _ValidateForReserveItemAtClass(class, FALSE, workItem, rsvArgObject, mfail)
#define ValidateForReserveItemAtParent(class, workItem, rsvArgObject, mfail) \
        _ValidateForReserveItemAtClass(class, TRUE, workItem, rsvArgObject, mfail)

#define ValidateForReserveSet(workItemClass, workItems, rsvArgObjects, mfail) \
        _ValidateForReserveSet(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, mfail)
#define ValidateForReserveSetAtParent(_class, workItemClass, workItems, rsvArgObjects, mfail) \
        _ValidateForReserveSet(_class, TRUE, workItemClass, workItems, rsvArgObjects, mfail)

#define ValidateForReserveSet1(workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail) \
        _ValidateForReserveSet1(workItemClass, FALSE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail)
#define ValidateForReserveSet1AtParent(_class, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail) \
        _ValidateForReserveSet1(_class, TRUE, workItemClass, workItems, rsvArgObjects, failedItems, mfailCodes, mfail)

#define ValidateForRsvItemInt(workItem, rsvArgObject, mfail) \
        _ValidateForRsvItemIntAtClass(NULL, FALSE, workItem, rsvArgObject, mfail)
#define ValidateForRsvItemIntAtClass(class, workItem, rsvArgObject, mfail) \
        _ValidateForRsvItemIntAtClass(class, FALSE, workItem, rsvArgObject, mfail)
#define ValidateForRsvItemIntAtParent(class, workItem, rsvArgObject, mfail) \
        _ValidateForRsvItemIntAtClass(class, TRUE, workItem, rsvArgObject, mfail)

#define ValidateItemClass(thisObj, classToMatch, mfail) \
        _ValidateItemClassAtClass(NULL, FALSE, thisObj, classToMatch, mfail)
#define ValidateItemClassAtClass(class, thisObj, classToMatch, mfail) \
        _ValidateItemClassAtClass(class, FALSE, thisObj, classToMatch, mfail)
#define ValidateItemClassAtParent(class, thisObj, classToMatch, mfail) \
        _ValidateItemClassAtClass(class, TRUE, thisObj, classToMatch, mfail)

#define ValidateItemOwners(item1, item2, mfail) \
        _ValidateItemOwnersAtClass(NULL, FALSE, item1, item2, mfail)
#define ValidateItemOwnersAtClass(class, item1, item2, mfail) \
        _ValidateItemOwnersAtClass(class, FALSE, item1, item2, mfail)
#define ValidateItemOwnersAtParent(class, item1, item2, mfail) \
        _ValidateItemOwnersAtClass(class, TRUE, item1, item2, mfail)

#define ValidateMoreDel(pdmitem, dodelete, mfail) \
        _ValidateMoreDelAtClass(NULL, FALSE, pdmitem, dodelete, mfail)
#define ValidateMoreDelAtClass(class, pdmitem, dodelete, mfail) \
        _ValidateMoreDelAtClass(class, FALSE, pdmitem, dodelete, mfail)
#define ValidateMoreDelAtParent(class, pdmitem, dodelete, mfail) \
        _ValidateMoreDelAtClass(class, TRUE, pdmitem, dodelete, mfail)

#define ValidatePredForMerge(workItem, mfail) \
        _ValidatePredForMergeAtClass(NULL, FALSE, workItem, mfail)
#define ValidatePredForMergeAtClass(class, workItem, mfail) \
        _ValidatePredForMergeAtClass(class, FALSE, workItem, mfail)
#define ValidatePredForMergeAtParent(class, workItem, mfail) \
        _ValidatePredForMergeAtClass(class, TRUE, workItem, mfail)

#define ValidatePredsForMerge(workItemClass, argObjs, failedObjects, mfail) \
        _ValidatePredsForMerge(workItemClass, FALSE, workItemClass, argObjs, failedObjects, mfail)
#define ValidatePredsForMergeAtParent(_class, workItemClass, argObjs, failedObjects, mfail) \
        _ValidatePredsForMerge(_class, TRUE, workItemClass, argObjs, failedObjects, mfail)

#define ValidateRelForCkoMkvTm(thisObj, source, dest, refresh, isBase, mfail) \
        _ValidateRelForCkoMkvTmAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ValidateRelForCkoMkvTmAtClass(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ValidateRelForCkoMkvTmAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ValidateRelForCkoMkvTmAtParent(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ValidateRelForCkoMkvTmAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, mfail)

#define ValidateRelForCkoTm(thisObj, source, dest, refresh, isBase, mfail) \
        _ValidateRelForCkoTmAtClass(NULL, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ValidateRelForCkoTmAtClass(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ValidateRelForCkoTmAtClass(class, FALSE, thisObj, source, dest, refresh, isBase, mfail)
#define ValidateRelForCkoTmAtParent(class, thisObj, source, dest, refresh, isBase, mfail) \
        _ValidateRelForCkoTmAtClass(class, TRUE, thisObj, source, dest, refresh, isBase, mfail)

#define ValidateReleaseRplObj(thisObj, extraStr, extraObj, mfail) \
        _ValidateReleaseRplObjAtClass(NULL, FALSE, thisObj, extraStr, extraObj, mfail)
#define ValidateReleaseRplObjAtClass(class, thisObj, extraStr, extraObj, mfail) \
        _ValidateReleaseRplObjAtClass(class, FALSE, thisObj, extraStr, extraObj, mfail)
#define ValidateReleaseRplObjAtParent(class, thisObj, extraStr, extraObj, mfail) \
        _ValidateReleaseRplObjAtClass(class, TRUE, thisObj, extraStr, extraObj, mfail)

#define ValidateRelsForMerge(workItemClass, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValidateRelsForMerge(workItemClass, FALSE, workItemClass, mrgDialogs, newItems, otherSideItems, mfail)
#define ValidateRelsForMergeAtParent(_class, workItemClass, mrgDialogs, newItems, otherSideItems, mfail) \
        _ValidateRelsForMerge(_class, TRUE, workItemClass, mrgDialogs, newItems, otherSideItems, mfail)

#define ValidateRelsForMrgVers(workItemClass, mergedObjs, argObjsList, otherSideObjs, mfail) \
        _ValidateRelsForMrgVers(workItemClass, FALSE, workItemClass, mergedObjs, argObjsList, otherSideObjs, mfail)
#define ValidateRelsForMrgVersAtParent(_class, workItemClass, mergedObjs, argObjsList, otherSideObjs, mfail) \
        _ValidateRelsForMrgVers(_class, TRUE, workItemClass, mergedObjs, argObjsList, otherSideObjs, mfail)

#define ValidateRelseNoRplObj(thisObj, extraStr, extraObj, mfail) \
        _ValidateRelseNoRplObjAtClass(NULL, FALSE, thisObj, extraStr, extraObj, mfail)
#define ValidateRelseNoRplObjAtClass(class, thisObj, extraStr, extraObj, mfail) \
        _ValidateRelseNoRplObjAtClass(class, FALSE, thisObj, extraStr, extraObj, mfail)
#define ValidateRelseNoRplObjAtParent(class, thisObj, extraStr, extraObj, mfail) \
        _ValidateRelseNoRplObjAtClass(class, TRUE, thisObj, extraStr, extraObj, mfail)

#define ValidateTeamName(className, dialogObj, mfail) \
        _ValidateTeamName(className, FALSE, className, dialogObj, mfail)
#define ValidateTeamNameAtParent(_class, className, dialogObj, mfail) \
        _ValidateTeamName(_class, TRUE, className, dialogObj, mfail)

#define ValidateTeamRoleDelete(className, teamRoleName, mfail) \
        _ValidateTeamRoleDelete(className, FALSE, className, teamRoleName, mfail)
#define ValidateTeamRoleDeleteAtParent(_class, className, teamRoleName, mfail) \
        _ValidateTeamRoleDelete(_class, TRUE, className, teamRoleName, mfail)

#define ValidateToTeamFldr(thisObj, tofldrName, frmteamName, toteamFldr, inFldr, mfail) \
        _ValidateToTeamFldrAtClass(NULL, FALSE, thisObj, tofldrName, frmteamName, toteamFldr, inFldr, mfail)
#define ValidateToTeamFldrAtClass(class, thisObj, tofldrName, frmteamName, toteamFldr, inFldr, mfail) \
        _ValidateToTeamFldrAtClass(class, FALSE, thisObj, tofldrName, frmteamName, toteamFldr, inFldr, mfail)
#define ValidateToTeamFldrAtParent(class, thisObj, tofldrName, frmteamName, toteamFldr, inFldr, mfail) \
        _ValidateToTeamFldrAtClass(class, TRUE, thisObj, tofldrName, frmteamName, toteamFldr, inFldr, mfail)

#define ValidateTranAuthority(thisObj, mfail) \
        _ValidateTranAuthorityAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateTranAuthorityAtClass(class, thisObj, mfail) \
        _ValidateTranAuthorityAtClass(class, FALSE, thisObj, mfail)
#define ValidateTranAuthorityAtParent(class, thisObj, mfail) \
        _ValidateTranAuthorityAtClass(class, TRUE, thisObj, mfail)

#define ValidateTrnResvOwner(workItem, newOwner, mfail) \
        _ValidateTrnResvOwnerAtClass(NULL, FALSE, workItem, newOwner, mfail)
#define ValidateTrnResvOwnerAtClass(class, workItem, newOwner, mfail) \
        _ValidateTrnResvOwnerAtClass(class, FALSE, workItem, newOwner, mfail)
#define ValidateTrnResvOwnerAtParent(class, workItem, newOwner, mfail) \
        _ValidateTrnResvOwnerAtClass(class, TRUE, workItem, newOwner, mfail)
#endif /* for msgtms_H */

