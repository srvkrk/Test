/**********************************************************************/
/*                                                                    */
/* (C) Copyright  SAP AG, Walldorf  1997                              */
/*                                                                    */
/* wmconsteh                                                          */
/*                                                                    */
/* SAP specific constants (for external use)				                  */
/* (WAPI interface 2, Version 1.1, March 1997).                       */
/*                                                                    */
/* Author:		Stefan Maier																					  */
/* Reviewer:	Rainer Weber																						*/
/*                                                                    */
/* Standard C code (fully portable)                                   */
/*                                                                    */
/**********************************************************************/


#ifndef WMCONSTE_H
#define WMCONSTE_H


/***************************************************/
/* Org object types (see ABAP/4 programm RSWUINCL) */
/***************************************************/
#define SAP_WAPI_USER                 						"US"
#define SAP_WAPI_TASK                 						"T "
#define SAP_WAPI_STANDARD_TASK        						"TS"
#define SAP_WAPI_WORKFLOW_TASK        						"WF"
#define SAP_WAPI_WORKFLOW_TEMPLATE    						"WS"


/*************************************************/
/* Workitem types (see ABAP/4 programm RSWUINCL) */
/*************************************************/
#define SAP_WAPI_WI_BATCH                         'B'
#define SAP_WAPI_WI_FLOW                          'F'
#define SAP_WAPI_WI_NORMAL                        'W'


/**************************************************/
/* Workitem status (see ABAP/4 programm RSWUINCL) */
/**************************************************/
#define SAP_WAPI_WI_STATE_CANCELLED               "CANCELLED"
#define SAP_WAPI_WI_STATE_COMMITTED               "COMMITTED"
#define SAP_WAPI_WI_STATE_COMPLETED               "COMPLETED"
#define SAP_WAPI_WI_STATE_ERROR                   "ERROR"
#define SAP_WAPI_WI_STATE_SELECTED                "SELECTED"
#define SAP_WAPI_WI_STATE_STARTED                 "STARTED"
#define SAP_WAPI_WI_STATE_READY                   "READY"
#define SAP_WAPI_WI_STATE_WAITING                 "WAITING"
#define SAP_WAPI_NUMBER_OF_INSTANCES_STATES       8


/*****************************/
/* Process definition states */
/*****************************/
#define SAP_WAPI_PROC_DEF_ACTIVE									"ACTIVE"
#define SAP_WAPI_PROC_DEF_INSTANTIATION_BLOCKED   "INSTANTIATION_BLOCKED"
#define SAP_WAPI_NUMBER_OF_PROC_DEF_STATES				2


/****************************************************************/
/* Additional datatypes to the TYP* types (defined in saprfc.h) */
/****************************************************************/
#define TYPOBJECT                                 14
#define TYPDDIC											              15
#define TYPUNKNOWN                                99


/**************************************************/
/* Additional error codes to the WM_* error codes */
/**************************************************/
#define SAP_WAPI_UNKNOWN_ERROR						        0x01100000
#define SAP_WAPI_NO_DATA                          0x01200000
#define SAP_WAPI_REASSIGNMENT_FAILED              0x01300000
#define SAP_WAPI_NO_PROCESS_INSTANCES             0x01400000
#define SAP_WAPI_INVALID_ITEM                     0x01500000
#define SAP_WAPI_COMPLETION_FAILED                0x01600000
#define SAP_WAPI_MEMORY_ALLOCATION_FAILED         0x01700000
#define SAP_WAPI_INVALID_DEFINITION								0x01800000
#define SAP_WAPI_TERMINATION_NOT_ALLOWED					0x01900000
#define SAP_WAPI_ABORTION_NOT_ALLOWED							0x01A00000
#define SAP_WAPI_NO_ACTIVITY_INSTANCES						0x01B00000
#define SAP_WAPI_INVALID_ATTRIBUTES_LIST          0x01C00000
#define SAP_WAPI_FAULTY_DEFINITION								0x01D00000
#define SAP_WAPI_START_FAILED											0x01E00000
#define SAP_WAPI_DATA_READING_FAILED							0x01F00000
#define SAP_WAPI_INVALID_OBJECT_TYPE_OR_EVENT			0x02000000
#define SAP_WAPI_EVENT_GENERATION_FAILED					0x02100000
#define SAP_WAPI_INVALID_OBJECT_KEY								0x02200000


/**************************/
/* For SAPWapiCreateEvent */
/**************************/
#define SAP_WAPI_SIZE_OBJECT_TYPE									10
#define SAP_WAPI_SIZE_OBJECT_KEY									70
#define SAP_WAPI_SIZE_EVENT												32
#define SAP_WAPI_SIZE_EVENT_ID										20


/***********************/
/* Diverse definitions */
/***********************/
#define NULL_BYTE									                '\0'
#define BLANK                                     ' '


/******************/
/* Reference type */
/******************/
#define SAP_WAPI_REFTYPE_DDIC                     'D'
#define SAP_WAPI_REFTYPE_OBJECT                   'O'


/*****************************************************/
/* Workitem has not been created by another workitem */
/*****************************************************/
#define SAP_WAPI_WI_DIRECT_CREATION               "000000000000"


/********************/
/* ABAP/4 datatypes */
/********************/
#define SAP_WAPI_CHAR_TYPC                        'C'  
#define SAP_WAPI_CHAR_TYPDATE                     'D'
#define SAP_WAPI_CHAR_TYPFLOAT                    'F'
#define SAP_WAPI_CHAR_TYPINT                      'I'
#define SAP_WAPI_CHAR_TYPNUM                      'N'
#define SAP_WAPI_CHAR_TYPP                        'P'
#define SAP_WAPI_CHAR_TYPTIME                     'T'
#define SAP_WAPI_CHAR_TYPX                        'X'
#define SAP_WAPI_CHAR_TYPOBJECT                   'o'


/*************/
/* Delimiter */
/*************/
#define SAP_WAPI_DELIMITER					              BLANK


/*********/
/* Trace */
/*********/
#define SAP_WAPI_TRACE							              0


/*****************/
/* System number */
/*****************/
#define SAP_WAPI_MIN_SYSNR                        0
#define SAP_WAPI_MAX_SYSNR                        99


/*******************/
/* Error sub codes */
/*******************/
#define SAP_WAPI_INVALID_LANGUAGE                 0x0001
#define SAP_WAPI_INVALID_SYSNR                    0x0002
#define SAP_WAPI_INVALID_CLIENT                   0x0003
#define SAP_WAPI_INVALID_ENGINE_NAME              0x0004
#define SAP_WAPI_READ_FAILED				              0x0005
#define SAP_WAPI_NO_ACTIVE_PLVAR			            0x0006
#define SAP_WAPI_NO_ORG_OBJECT				            0x0007
#define SAP_WAPI_ORG_OBJECT_NOT_FOUND			        0x0008
#define SAP_WAPI_INFEASIBLE_STATE_TRANSITION		  0x0009
#define SAP_WAPI_NOTIFICATION_FAILED			        0x000A
#define SAP_WAPI_STATUS_UNKNOWN				            0x000B
#define SAP_WAPI_UPDATE_FAILED				            0x000C
#define SAP_WAPI_NO_AUTHORIZATION			            0x000D
#define SAP_WAPI_ID_NOT_CREATED				            0x000E
#define SAP_WAPI_INVALID_TYPE				              0x000F
#define SAP_WAPI_CONTAINER_DOES_NOT_EXIST		      0x0010
#define SAP_WAPI_CONTAINER_EMPTY			            0x0011
#define SAP_WAPI_USER_NAME_NOT_FOUND              0x0012
#define SAP_WAPI_INVALID_STATUS                   0x0013
#define SAP_WAPI_PROCESS_TYPE_NOT_SUPPORTED       0x0014
#define SAP_WAPI_PARTIAL_SUCCESS                  0x0015
#define SAP_WAPI_SELECT_FAILED                    0x0016
#define SAP_WAPI_DELETE_FAILED                    0x0017
#define SAP_WAPI_APPEND_FAILED                    0x0018
#define SAP_WAPI_ACTIVITY_TYPE_NOT_SUPPORTED      0x0019
#define SAP_WAPI_WORKITEM_TYPE_NOT_SUPPORTED      0x001A
#define SAP_WAPI_ORGINFO_NOT_FOUND                0x001B
#define SAP_WAPI_NO_AGENT_FOUND										0x001C
#define SAP_WAPI_GENERAL_TASK											0x001D
#define SAP_WAPI_BACKGROUND_TASK									0x001E
#define SAP_WAPI_FAILED														0x001F
#define SAP_WAPI_OBJECT_DOES_NOT_EXIST						0x0020
#define SAP_WAPI_OTYPE_NOT_VALID									0x0021
#define SAP_WAPI_NO_AUTHORIZATION_FOR_UPDATE			0x0022
#define SAP_WAPI_ERROR_DURING_UPDATE							0x0023
#define SAP_WAPI_OBJECT_NOT_IN_ACT_DATE						0x0024
#define SAP_WAPI_NO_TASK_TYPE											0x0025
#define SAP_WAPI_NOTHING_FOUND                    0x0026
#define SAP_WAPI_INVALID_LOGON_INFO               0x0027


/***********/
/* Filters */
/***********/
#define SAP_WAPI_FILTER_ONLY_PROCESS_DEFINITION  	0x00000100
#define SAP_WAPI_FILTER_PROCESS_INSTANCE_STATE		0x00000101
#define SAP_WAPI_FILTER_DESTINATION_STATES        0x00000102
#define SAP_WAPI_FILTER_LOGIN_USER                0x00000103
#define SAP_WAPI_FILTER_SEARCH_EXPRESSION         0x00000104


/****************/
/* Participants */
/****************/
#define SAP_WAPI_PARTICIPANTS_ACTIVITY_INSTANCE		10


#endif
