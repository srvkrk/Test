int DZ_explnew2();
char*  DZ_date();
int DZ_dmlload();
int DZ_conn();
	struct get_data
	{
		char grp_ind[2];
		char part_no[14];
		char description[40];
		char colour_ind[2] ;
		char drg_std_ind[2] ;
		char spare_ind[2] ;
		char dismantelability[2];
		char cmvr_certification_reqd[2];
		char rational_ind[2] ;
		char spare_criteria[4] ;
		char list_rec_spares[2] ;
		char drg_std_no[14]; 
		char classification_hazardous[4];
		char design_group[3];
		char envelop_dimensions[18];
		char  hazardous_contents[2];
		char homologation_reqd[40];
		char  material_class[3];
		char   nc_partno[15];
		char part_code[2];
		char packing_std[13];
		char recoverable[2];
		char recyclability[2];
		char ref_part_no[15];
		char  surf_prot_std[13];
		char weight[20];
		char acr_ind[20];

		char category[5] ;
		char alt_group[5];
	};

struct get_drg_data
 {
	char drawing_no[15];
	char description[15];
	char drawing_type[7];
	char offer_drawing_no[81];
	char party_drawing_no[81] ;
	char sheet_size[6] ;
	char man_cad_ind[4] ;
	char design_group[6];
	char mod_desc[241] ;
	char project[6];
 };

struct get_drg_change
{
	int  count;
	char chgsheet_status[4];
	char chgsheet_size[3];
	char chgman_cad[4];
	char chgmod_desc[241];

};

