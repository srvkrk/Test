/*
 *  FILE: msgxml.h
 */

#ifndef msgxml_H
#define msgxml_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

#ifdef _LCINTERP_
}
#else

/*
 *  Unpublished Messages
 */

MTIstatus _AcceptXSLTDataAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring result, integer * mfail);

MTIstatus _CreateXMLFilesForLoad
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr argsObj, integer numberOfFiles, SetOfObjects * xmlFileObjs,
   SetOfObjects * xmlFileTransferObjs, integer * mfail);

MTIstatus _CustomizeXSLTProcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialog,
   ObjectPtr processor, integer * mfail);

MTIstatus _CvtDataExportAdd2
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr object, ObjectPtr dialog, ObjectPtr cnvseto,
   integer * mfail);

MTIstatus _CvtDataExportBegin2
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr dialog, ObjectPtr cnvseto, integer * mfail);

MTIstatus _CvtDataExportEnd2
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr dialog, ObjectPtr cnvseto, boolean * needToTransliterate,
   integer * mfail);

MTIstatus _ExtEmbObjectsWithPrsr
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr dialogObj, ObjectPtr inputObj, ObjectPtr outputObj,
   ObjectPtr parserObj, ObjectPtr contentHandler, integer * mfail);

MTIstatus _ExtractEmbeddedObjects
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr dialogObj, ObjectPtr inputObj, ObjectPtr outputObj,
   ObjectPtr contentHandler, integer * mfail);

MTIstatus _GetPLMBridgeObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * newObject, boolean * deleteMe, integer * mfail);

MTIstatus _GetXMLBufferAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring * data, integer * mfail);

MTIstatus _GetXMLFilePathAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring * fullpath, integer * mfail);

MTIstatus _GetXMLSourceAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring * result, integer * mfail);

MTIstatus _GetXSLTInputObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * xsltinp, integer * mfail);

MTIstatus _GetXSLTOutputObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * xsltout, integer * mfail);

MTIstatus _GetXSLTSourceAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring * data, integer * mfail);

MTIstatus _GetXSLTStringsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * strings, integer * mfail);

MTIstatus _HandleXMLExtractOutAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr embeddedObject, integer * mfail);

MTIstatus _InitPLMBSetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects objectSet, integer * mfail);

MTIstatus _MakeStyleSheetObj
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr srcObj, ObjectPtr * finalObj, integer * mfail);

MTIstatus _SAXExSetValuesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlsaxexobj,
   integer line, integer col, MTIstring publicId,
   MTIstring systemId, MTIstring msg, integer * mfail);

MTIstatus _SetStylShtTrnsfmParmsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xsltProcessor,
   ObjectPtr cnvrtrDialog, integer * mfail);

MTIstatus _TransformXMLUsingXslt
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr cnvrtrDialog, ObjectPtr xmlInputFile, ObjectPtr * outputXMLFile,
   integer * mfail);

MTIstatus _UpdateCnvOutObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr xsltout, integer * mfail);

MTIstatus _UseCnvOutObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr cnvoutObj, integer * mfail);

MTIstatus _UseXMLBufferAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring buffer, integer * mfail);

MTIstatus _UseXMLFileAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlfileiobj,
   ObjectPtr fileobj, integer * mfail);

MTIstatus _UseXMLObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr XMLobj, integer * mfail);

MTIstatus _UseXMLStringsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings strings, integer * mfail);

MTIstatus _XAttrGetIndexAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring name, integer * index, integer * mfail);

MTIstatus _XAttrGetLengthAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * length, integer * mfail);

MTIstatus _XAttrGetLocalNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer index, MTIstring * localname, integer * mfail);

MTIstatus _XAttrGetValueAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer index, MTIstring * value, integer * mfail);

MTIstatus _XAttrGetValueByNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring name, MTIstring * value, integer * mfail);

MTIstatus _XEOBlobHandlerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xeocthdlobj,
   MTIstring attrName, MTIstring content, ObjectPtr destObj,
   integer * mfail);

MTIstatus _XEOConsolidateObject
   (MTIstring _class, boolean getParent, MTIstring className,
   ObjectPtr consObj, ObjectPtr * finalObj, integer * mfail);

MTIstatus _XEOGetOutputHandlerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * outputHandler, integer * mfail);

MTIstatus _XEOSetOutputHandlerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr outputHandler, integer * mfail);

MTIstatus _XEOSpareAttrsHandlerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr contentHandler,
   ObjectPtr spareAttrsObj, ObjectPtr parentObj, integer * mfail);

MTIstatus _XMLCharactersAtClass
   (MTIstring _class, boolean getParent, ObjectPtr contentHandler,
   MTIstring data, integer * mfail);

MTIstatus _XMLClearTempDataAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _XMLEndDocumentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr contentHandler,
   integer * mfail);

MTIstatus _XMLEndElementAtClass
   (MTIstring _class, boolean getParent, ObjectPtr contentHandler,
   MTIstring uri, MTIstring localName, MTIstring qName,
   integer * mfail);

MTIstatus _XMLErrorAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlerrhlobj,
   ObjectPtr xmlsaxexobj, integer * status, integer * mfail);

MTIstatus _XMLFatalErrorAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlerrhlobj,
   ObjectPtr xmlsaxexobj, integer * status, integer * mfail);

MTIstatus _XMLGetColumnNumberAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlsaxexobj,
   integer * col, integer * mfail);

MTIstatus _XMLGetContentHandlerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr parser,
   ObjectPtr * contentHandler, integer * mfail);

MTIstatus _XMLGetEntityResolverAtClass
   (MTIstring _class, boolean getParent, ObjectPtr parser,
   ObjectPtr * xmlenresobj, integer * mfail);

MTIstatus _XMLGetErrorHandlerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlparsrobj,
   ObjectPtr * xmlerrhlobj, integer * mfail);

MTIstatus _XMLGetFeatureAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlparsrobj,
   MTIstring feature, boolean * value, integer * mfail);

MTIstatus _XMLGetLineNumberAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlsaxexobj,
   integer * line, integer * mfail);

MTIstatus _XMLGetMessageAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlsaxexobj,
   MTIstring * msg, integer * mfail);

MTIstatus _XMLGetProblemListenerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlparsrobj,
   ObjectPtr * xmlplobj, integer * mfail);

MTIstatus _XMLGetPropertyStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlparsrobj,
   MTIstring property, MTIstring * value, integer * mfail);

MTIstatus _XMLGetPublicIdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlsaxexobj,
   MTIstring * publicId, integer * mfail);

MTIstatus _XMLGetSystemIdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlsaxexobj,
   MTIstring * systemId, integer * mfail);

MTIstatus _XMLParseAtClass
   (MTIstring _class, boolean getParent, ObjectPtr parser,
   ObjectPtr source, integer * mfail);

MTIstatus _XMLResetErrorsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlerrhlobj,
   integer * status, integer * mfail);

MTIstatus _XMLResolveEntityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlenresobj,
   MTIstring publicId, MTIstring systemId, ObjectPtr * xmlinputobj,
   integer * mfail);

MTIstatus _XMLSetContentHandlerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr parser,
   ObjectPtr contentHandler, integer * mfail);

MTIstatus _XMLSetEntityResolverAtClass
   (MTIstring _class, boolean getParent, ObjectPtr parser,
   ObjectPtr xmlenresobj, integer * mfail);

MTIstatus _XMLSetErrorHandlerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlparsrobj,
   ObjectPtr xmlerrhlobj, integer * mfail);

MTIstatus _XMLSetFeatureAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlparsrobj,
   MTIstring feature, boolean value, integer * mfail);

MTIstatus _XMLSetProblemListenerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlparsrobj,
   ObjectPtr xmlplobj, integer * mfail);

MTIstatus _XMLSetPropertyStrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlparsrobj,
   MTIstring property, MTIstring value, integer * mfail);

MTIstatus _XMLStartDocumentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlcthdlobj,
   integer * mfail);

MTIstatus _XMLStartElementAtClass
   (MTIstring _class, boolean getParent, ObjectPtr contentHandler,
   MTIstring uri, MTIstring localName, MTIstring qName,
   ObjectPtr xmlattrsobj, integer * mfail);

MTIstatus _XMLUseXSLTObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr XSLTobj, integer * mfail);

MTIstatus _XMLWarningAtClass
   (MTIstring _class, boolean getParent, ObjectPtr xmlerrhlobj,
   ObjectPtr xmlsaxexobj, integer * status, integer * mfail);

MTIstatus _XSLTProblemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr probListener,
   integer mtiWhere, integer mtiClassif, MTIstring mtiMsg,
   MTIstring mtiUri, integer lineNo, integer charOffset,
   integer * mfail);

MTIstatus _XSLTProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr processor,
   ObjectPtr stylesheet, ObjectPtr inputSrc, ObjectPtr outputSink,
   integer * mfail);

MTIstatus _XSLTSetStyleSheetParamAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   MTIstring key, MTIstring value, integer * mfail);

MTIstatus _XmlDummyDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr pdmItem,
   integer * mfail);
/*
 *  Protected Messages
 */
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define AcceptXSLTData(thisObj, result, mfail) \
        _AcceptXSLTDataAtClass(NULL, FALSE, thisObj, result, mfail)
#define AcceptXSLTDataAtClass(class, thisObj, result, mfail) \
        _AcceptXSLTDataAtClass(class, FALSE, thisObj, result, mfail)
#define AcceptXSLTDataAtParent(class, thisObj, result, mfail) \
        _AcceptXSLTDataAtClass(class, TRUE, thisObj, result, mfail)

#define CreateXMLFilesForLoad(className, argsObj, numberOfFiles, xmlFileObjs, xmlFileTransferObjs, mfail) \
        _CreateXMLFilesForLoad(className, FALSE, className, argsObj, numberOfFiles, xmlFileObjs, xmlFileTransferObjs, mfail)
#define CreateXMLFilesForLoadAtParent(_class, className, argsObj, numberOfFiles, xmlFileObjs, xmlFileTransferObjs, mfail) \
        _CreateXMLFilesForLoad(_class, TRUE, className, argsObj, numberOfFiles, xmlFileObjs, xmlFileTransferObjs, mfail)

#define CustomizeXSLTProc(dialog, processor, mfail) \
        _CustomizeXSLTProcAtClass(NULL, FALSE, dialog, processor, mfail)
#define CustomizeXSLTProcAtClass(class, dialog, processor, mfail) \
        _CustomizeXSLTProcAtClass(class, FALSE, dialog, processor, mfail)
#define CustomizeXSLTProcAtParent(class, dialog, processor, mfail) \
        _CustomizeXSLTProcAtClass(class, TRUE, dialog, processor, mfail)

#define CvtDataExportAdd2(className, object, dialog, cnvseto, mfail) \
        _CvtDataExportAdd2(className, FALSE, className, object, dialog, cnvseto, mfail)
#define CvtDataExportAdd2AtParent(_class, className, object, dialog, cnvseto, mfail) \
        _CvtDataExportAdd2(_class, TRUE, className, object, dialog, cnvseto, mfail)

#define CvtDataExportBegin2(className, dialog, cnvseto, mfail) \
        _CvtDataExportBegin2(className, FALSE, className, dialog, cnvseto, mfail)
#define CvtDataExportBegin2AtParent(_class, className, dialog, cnvseto, mfail) \
        _CvtDataExportBegin2(_class, TRUE, className, dialog, cnvseto, mfail)

#define CvtDataExportEnd2(className, dialog, cnvseto, needToTransliterate, mfail) \
        _CvtDataExportEnd2(className, FALSE, className, dialog, cnvseto, needToTransliterate, mfail)
#define CvtDataExportEnd2AtParent(_class, className, dialog, cnvseto, needToTransliterate, mfail) \
        _CvtDataExportEnd2(_class, TRUE, className, dialog, cnvseto, needToTransliterate, mfail)

#define ExtEmbObjectsWithPrsr(className, dialogObj, inputObj, outputObj, parserObj, contentHandler, mfail) \
        _ExtEmbObjectsWithPrsr(className, FALSE, className, dialogObj, inputObj, outputObj, parserObj, contentHandler, mfail)
#define ExtEmbObjectsWithPrsrAtParent(_class, className, dialogObj, inputObj, outputObj, parserObj, contentHandler, mfail) \
        _ExtEmbObjectsWithPrsr(_class, TRUE, className, dialogObj, inputObj, outputObj, parserObj, contentHandler, mfail)

#define ExtractEmbeddedObjects(className, dialogObj, inputObj, outputObj, contentHandler, mfail) \
        _ExtractEmbeddedObjects(className, FALSE, className, dialogObj, inputObj, outputObj, contentHandler, mfail)
#define ExtractEmbeddedObjectsAtParent(_class, className, dialogObj, inputObj, outputObj, contentHandler, mfail) \
        _ExtractEmbeddedObjects(_class, TRUE, className, dialogObj, inputObj, outputObj, contentHandler, mfail)

#define GetPLMBridgeObject(thisObj, newObject, deleteMe, mfail) \
        _GetPLMBridgeObjectAtClass(NULL, FALSE, thisObj, newObject, deleteMe, mfail)
#define GetPLMBridgeObjectAtClass(class, thisObj, newObject, deleteMe, mfail) \
        _GetPLMBridgeObjectAtClass(class, FALSE, thisObj, newObject, deleteMe, mfail)
#define GetPLMBridgeObjectAtParent(class, thisObj, newObject, deleteMe, mfail) \
        _GetPLMBridgeObjectAtClass(class, TRUE, thisObj, newObject, deleteMe, mfail)

#define GetXMLBuffer(thisObj, data, mfail) \
        _GetXMLBufferAtClass(NULL, FALSE, thisObj, data, mfail)
#define GetXMLBufferAtClass(class, thisObj, data, mfail) \
        _GetXMLBufferAtClass(class, FALSE, thisObj, data, mfail)
#define GetXMLBufferAtParent(class, thisObj, data, mfail) \
        _GetXMLBufferAtClass(class, TRUE, thisObj, data, mfail)

#define GetXMLFilePath(thisObj, fullpath, mfail) \
        _GetXMLFilePathAtClass(NULL, FALSE, thisObj, fullpath, mfail)
#define GetXMLFilePathAtClass(class, thisObj, fullpath, mfail) \
        _GetXMLFilePathAtClass(class, FALSE, thisObj, fullpath, mfail)
#define GetXMLFilePathAtParent(class, thisObj, fullpath, mfail) \
        _GetXMLFilePathAtClass(class, TRUE, thisObj, fullpath, mfail)

#define GetXMLSource(thisObj, result, mfail) \
        _GetXMLSourceAtClass(NULL, FALSE, thisObj, result, mfail)
#define GetXMLSourceAtClass(class, thisObj, result, mfail) \
        _GetXMLSourceAtClass(class, FALSE, thisObj, result, mfail)
#define GetXMLSourceAtParent(class, thisObj, result, mfail) \
        _GetXMLSourceAtClass(class, TRUE, thisObj, result, mfail)

#define GetXSLTInputObject(thisObj, xsltinp, mfail) \
        _GetXSLTInputObjectAtClass(NULL, FALSE, thisObj, xsltinp, mfail)
#define GetXSLTInputObjectAtClass(class, thisObj, xsltinp, mfail) \
        _GetXSLTInputObjectAtClass(class, FALSE, thisObj, xsltinp, mfail)
#define GetXSLTInputObjectAtParent(class, thisObj, xsltinp, mfail) \
        _GetXSLTInputObjectAtClass(class, TRUE, thisObj, xsltinp, mfail)

#define GetXSLTOutputObject(thisObj, xsltout, mfail) \
        _GetXSLTOutputObjectAtClass(NULL, FALSE, thisObj, xsltout, mfail)
#define GetXSLTOutputObjectAtClass(class, thisObj, xsltout, mfail) \
        _GetXSLTOutputObjectAtClass(class, FALSE, thisObj, xsltout, mfail)
#define GetXSLTOutputObjectAtParent(class, thisObj, xsltout, mfail) \
        _GetXSLTOutputObjectAtClass(class, TRUE, thisObj, xsltout, mfail)

#define GetXSLTSource(thisObj, data, mfail) \
        _GetXSLTSourceAtClass(NULL, FALSE, thisObj, data, mfail)
#define GetXSLTSourceAtClass(class, thisObj, data, mfail) \
        _GetXSLTSourceAtClass(class, FALSE, thisObj, data, mfail)
#define GetXSLTSourceAtParent(class, thisObj, data, mfail) \
        _GetXSLTSourceAtClass(class, TRUE, thisObj, data, mfail)

#define GetXSLTStrings(thisObj, strings, mfail) \
        _GetXSLTStringsAtClass(NULL, FALSE, thisObj, strings, mfail)
#define GetXSLTStringsAtClass(class, thisObj, strings, mfail) \
        _GetXSLTStringsAtClass(class, FALSE, thisObj, strings, mfail)
#define GetXSLTStringsAtParent(class, thisObj, strings, mfail) \
        _GetXSLTStringsAtClass(class, TRUE, thisObj, strings, mfail)

#define HandleXMLExtractOut(thisObj, embeddedObject, mfail) \
        _HandleXMLExtractOutAtClass(NULL, FALSE, thisObj, embeddedObject, mfail)
#define HandleXMLExtractOutAtClass(class, thisObj, embeddedObject, mfail) \
        _HandleXMLExtractOutAtClass(class, FALSE, thisObj, embeddedObject, mfail)
#define HandleXMLExtractOutAtParent(class, thisObj, embeddedObject, mfail) \
        _HandleXMLExtractOutAtClass(class, TRUE, thisObj, embeddedObject, mfail)

#define InitPLMBSet(thisObj, objectSet, mfail) \
        _InitPLMBSetAtClass(NULL, FALSE, thisObj, objectSet, mfail)
#define InitPLMBSetAtClass(class, thisObj, objectSet, mfail) \
        _InitPLMBSetAtClass(class, FALSE, thisObj, objectSet, mfail)
#define InitPLMBSetAtParent(class, thisObj, objectSet, mfail) \
        _InitPLMBSetAtClass(class, TRUE, thisObj, objectSet, mfail)

#define MakeStyleSheetObj(className, srcObj, finalObj, mfail) \
        _MakeStyleSheetObj(className, FALSE, className, srcObj, finalObj, mfail)
#define MakeStyleSheetObjAtParent(_class, className, srcObj, finalObj, mfail) \
        _MakeStyleSheetObj(_class, TRUE, className, srcObj, finalObj, mfail)

#define SAXExSetValues(xmlsaxexobj, line, col, publicId, systemId, msg, mfail) \
        _SAXExSetValuesAtClass(NULL, FALSE, xmlsaxexobj, line, col, publicId, systemId, msg, mfail)
#define SAXExSetValuesAtClass(class, xmlsaxexobj, line, col, publicId, systemId, msg, mfail) \
        _SAXExSetValuesAtClass(class, FALSE, xmlsaxexobj, line, col, publicId, systemId, msg, mfail)
#define SAXExSetValuesAtParent(class, xmlsaxexobj, line, col, publicId, systemId, msg, mfail) \
        _SAXExSetValuesAtClass(class, TRUE, xmlsaxexobj, line, col, publicId, systemId, msg, mfail)

#define SetStylShtTrnsfmParms(xsltProcessor, cnvrtrDialog, mfail) \
        _SetStylShtTrnsfmParmsAtClass(NULL, FALSE, xsltProcessor, cnvrtrDialog, mfail)
#define SetStylShtTrnsfmParmsAtClass(class, xsltProcessor, cnvrtrDialog, mfail) \
        _SetStylShtTrnsfmParmsAtClass(class, FALSE, xsltProcessor, cnvrtrDialog, mfail)
#define SetStylShtTrnsfmParmsAtParent(class, xsltProcessor, cnvrtrDialog, mfail) \
        _SetStylShtTrnsfmParmsAtClass(class, TRUE, xsltProcessor, cnvrtrDialog, mfail)

#define TransformXMLUsingXslt(className, cnvrtrDialog, xmlInputFile, outputXMLFile, mfail) \
        _TransformXMLUsingXslt(className, FALSE, className, cnvrtrDialog, xmlInputFile, outputXMLFile, mfail)
#define TransformXMLUsingXsltAtParent(_class, className, cnvrtrDialog, xmlInputFile, outputXMLFile, mfail) \
        _TransformXMLUsingXslt(_class, TRUE, className, cnvrtrDialog, xmlInputFile, outputXMLFile, mfail)

#define UpdateCnvOutObj(thisObj, xsltout, mfail) \
        _UpdateCnvOutObjAtClass(NULL, FALSE, thisObj, xsltout, mfail)
#define UpdateCnvOutObjAtClass(class, thisObj, xsltout, mfail) \
        _UpdateCnvOutObjAtClass(class, FALSE, thisObj, xsltout, mfail)
#define UpdateCnvOutObjAtParent(class, thisObj, xsltout, mfail) \
        _UpdateCnvOutObjAtClass(class, TRUE, thisObj, xsltout, mfail)

#define UseCnvOutObject(thisObj, cnvoutObj, mfail) \
        _UseCnvOutObjectAtClass(NULL, FALSE, thisObj, cnvoutObj, mfail)
#define UseCnvOutObjectAtClass(class, thisObj, cnvoutObj, mfail) \
        _UseCnvOutObjectAtClass(class, FALSE, thisObj, cnvoutObj, mfail)
#define UseCnvOutObjectAtParent(class, thisObj, cnvoutObj, mfail) \
        _UseCnvOutObjectAtClass(class, TRUE, thisObj, cnvoutObj, mfail)

#define UseXMLBuffer(thisObj, buffer, mfail) \
        _UseXMLBufferAtClass(NULL, FALSE, thisObj, buffer, mfail)
#define UseXMLBufferAtClass(class, thisObj, buffer, mfail) \
        _UseXMLBufferAtClass(class, FALSE, thisObj, buffer, mfail)
#define UseXMLBufferAtParent(class, thisObj, buffer, mfail) \
        _UseXMLBufferAtClass(class, TRUE, thisObj, buffer, mfail)

#define UseXMLFile(xmlfileiobj, fileobj, mfail) \
        _UseXMLFileAtClass(NULL, FALSE, xmlfileiobj, fileobj, mfail)
#define UseXMLFileAtClass(class, xmlfileiobj, fileobj, mfail) \
        _UseXMLFileAtClass(class, FALSE, xmlfileiobj, fileobj, mfail)
#define UseXMLFileAtParent(class, xmlfileiobj, fileobj, mfail) \
        _UseXMLFileAtClass(class, TRUE, xmlfileiobj, fileobj, mfail)

#define UseXMLObject(thisObj, XMLobj, mfail) \
        _UseXMLObjectAtClass(NULL, FALSE, thisObj, XMLobj, mfail)
#define UseXMLObjectAtClass(class, thisObj, XMLobj, mfail) \
        _UseXMLObjectAtClass(class, FALSE, thisObj, XMLobj, mfail)
#define UseXMLObjectAtParent(class, thisObj, XMLobj, mfail) \
        _UseXMLObjectAtClass(class, TRUE, thisObj, XMLobj, mfail)

#define UseXMLStrings(thisObj, strings, mfail) \
        _UseXMLStringsAtClass(NULL, FALSE, thisObj, strings, mfail)
#define UseXMLStringsAtClass(class, thisObj, strings, mfail) \
        _UseXMLStringsAtClass(class, FALSE, thisObj, strings, mfail)
#define UseXMLStringsAtParent(class, thisObj, strings, mfail) \
        _UseXMLStringsAtClass(class, TRUE, thisObj, strings, mfail)

#define XAttrGetIndex(thisObj, name, index, mfail) \
        _XAttrGetIndexAtClass(NULL, FALSE, thisObj, name, index, mfail)
#define XAttrGetIndexAtClass(class, thisObj, name, index, mfail) \
        _XAttrGetIndexAtClass(class, FALSE, thisObj, name, index, mfail)
#define XAttrGetIndexAtParent(class, thisObj, name, index, mfail) \
        _XAttrGetIndexAtClass(class, TRUE, thisObj, name, index, mfail)

#define XAttrGetLength(thisObj, length, mfail) \
        _XAttrGetLengthAtClass(NULL, FALSE, thisObj, length, mfail)
#define XAttrGetLengthAtClass(class, thisObj, length, mfail) \
        _XAttrGetLengthAtClass(class, FALSE, thisObj, length, mfail)
#define XAttrGetLengthAtParent(class, thisObj, length, mfail) \
        _XAttrGetLengthAtClass(class, TRUE, thisObj, length, mfail)

#define XAttrGetLocalName(thisObj, index, localname, mfail) \
        _XAttrGetLocalNameAtClass(NULL, FALSE, thisObj, index, localname, mfail)
#define XAttrGetLocalNameAtClass(class, thisObj, index, localname, mfail) \
        _XAttrGetLocalNameAtClass(class, FALSE, thisObj, index, localname, mfail)
#define XAttrGetLocalNameAtParent(class, thisObj, index, localname, mfail) \
        _XAttrGetLocalNameAtClass(class, TRUE, thisObj, index, localname, mfail)

#define XAttrGetValue(thisObj, index, value, mfail) \
        _XAttrGetValueAtClass(NULL, FALSE, thisObj, index, value, mfail)
#define XAttrGetValueAtClass(class, thisObj, index, value, mfail) \
        _XAttrGetValueAtClass(class, FALSE, thisObj, index, value, mfail)
#define XAttrGetValueAtParent(class, thisObj, index, value, mfail) \
        _XAttrGetValueAtClass(class, TRUE, thisObj, index, value, mfail)

#define XAttrGetValueByName(thisObj, name, value, mfail) \
        _XAttrGetValueByNameAtClass(NULL, FALSE, thisObj, name, value, mfail)
#define XAttrGetValueByNameAtClass(class, thisObj, name, value, mfail) \
        _XAttrGetValueByNameAtClass(class, FALSE, thisObj, name, value, mfail)
#define XAttrGetValueByNameAtParent(class, thisObj, name, value, mfail) \
        _XAttrGetValueByNameAtClass(class, TRUE, thisObj, name, value, mfail)

#define XEOBlobHandler(xeocthdlobj, attrName, content, destObj, mfail) \
        _XEOBlobHandlerAtClass(NULL, FALSE, xeocthdlobj, attrName, content, destObj, mfail)
#define XEOBlobHandlerAtClass(class, xeocthdlobj, attrName, content, destObj, mfail) \
        _XEOBlobHandlerAtClass(class, FALSE, xeocthdlobj, attrName, content, destObj, mfail)
#define XEOBlobHandlerAtParent(class, xeocthdlobj, attrName, content, destObj, mfail) \
        _XEOBlobHandlerAtClass(class, TRUE, xeocthdlobj, attrName, content, destObj, mfail)

#define XEOConsolidateObject(className, consObj, finalObj, mfail) \
        _XEOConsolidateObject(className, FALSE, className, consObj, finalObj, mfail)
#define XEOConsolidateObjectAtParent(_class, className, consObj, finalObj, mfail) \
        _XEOConsolidateObject(_class, TRUE, className, consObj, finalObj, mfail)

#define XEOGetOutputHandler(thisObj, outputHandler, mfail) \
        _XEOGetOutputHandlerAtClass(NULL, FALSE, thisObj, outputHandler, mfail)
#define XEOGetOutputHandlerAtClass(class, thisObj, outputHandler, mfail) \
        _XEOGetOutputHandlerAtClass(class, FALSE, thisObj, outputHandler, mfail)
#define XEOGetOutputHandlerAtParent(class, thisObj, outputHandler, mfail) \
        _XEOGetOutputHandlerAtClass(class, TRUE, thisObj, outputHandler, mfail)

#define XEOSetOutputHandler(thisObj, outputHandler, mfail) \
        _XEOSetOutputHandlerAtClass(NULL, FALSE, thisObj, outputHandler, mfail)
#define XEOSetOutputHandlerAtClass(class, thisObj, outputHandler, mfail) \
        _XEOSetOutputHandlerAtClass(class, FALSE, thisObj, outputHandler, mfail)
#define XEOSetOutputHandlerAtParent(class, thisObj, outputHandler, mfail) \
        _XEOSetOutputHandlerAtClass(class, TRUE, thisObj, outputHandler, mfail)

#define XEOSpareAttrsHandler(contentHandler, spareAttrsObj, parentObj, mfail) \
        _XEOSpareAttrsHandlerAtClass(NULL, FALSE, contentHandler, spareAttrsObj, parentObj, mfail)
#define XEOSpareAttrsHandlerAtClass(class, contentHandler, spareAttrsObj, parentObj, mfail) \
        _XEOSpareAttrsHandlerAtClass(class, FALSE, contentHandler, spareAttrsObj, parentObj, mfail)
#define XEOSpareAttrsHandlerAtParent(class, contentHandler, spareAttrsObj, parentObj, mfail) \
        _XEOSpareAttrsHandlerAtClass(class, TRUE, contentHandler, spareAttrsObj, parentObj, mfail)

#define XMLCharacters(contentHandler, data, mfail) \
        _XMLCharactersAtClass(NULL, FALSE, contentHandler, data, mfail)
#define XMLCharactersAtClass(class, contentHandler, data, mfail) \
        _XMLCharactersAtClass(class, FALSE, contentHandler, data, mfail)
#define XMLCharactersAtParent(class, contentHandler, data, mfail) \
        _XMLCharactersAtClass(class, TRUE, contentHandler, data, mfail)

#define XMLClearTempData(thisObj, mfail) \
        _XMLClearTempDataAtClass(NULL, FALSE, thisObj, mfail)
#define XMLClearTempDataAtClass(class, thisObj, mfail) \
        _XMLClearTempDataAtClass(class, FALSE, thisObj, mfail)
#define XMLClearTempDataAtParent(class, thisObj, mfail) \
        _XMLClearTempDataAtClass(class, TRUE, thisObj, mfail)

#define XMLEndDocument(contentHandler, mfail) \
        _XMLEndDocumentAtClass(NULL, FALSE, contentHandler, mfail)
#define XMLEndDocumentAtClass(class, contentHandler, mfail) \
        _XMLEndDocumentAtClass(class, FALSE, contentHandler, mfail)
#define XMLEndDocumentAtParent(class, contentHandler, mfail) \
        _XMLEndDocumentAtClass(class, TRUE, contentHandler, mfail)

#define XMLEndElement(contentHandler, uri, localName, qName, mfail) \
        _XMLEndElementAtClass(NULL, FALSE, contentHandler, uri, localName, qName, mfail)
#define XMLEndElementAtClass(class, contentHandler, uri, localName, qName, mfail) \
        _XMLEndElementAtClass(class, FALSE, contentHandler, uri, localName, qName, mfail)
#define XMLEndElementAtParent(class, contentHandler, uri, localName, qName, mfail) \
        _XMLEndElementAtClass(class, TRUE, contentHandler, uri, localName, qName, mfail)

#define XMLError(xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLErrorAtClass(NULL, FALSE, xmlerrhlobj, xmlsaxexobj, status, mfail)
#define XMLErrorAtClass(class, xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLErrorAtClass(class, FALSE, xmlerrhlobj, xmlsaxexobj, status, mfail)
#define XMLErrorAtParent(class, xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLErrorAtClass(class, TRUE, xmlerrhlobj, xmlsaxexobj, status, mfail)

#define XMLFatalError(xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLFatalErrorAtClass(NULL, FALSE, xmlerrhlobj, xmlsaxexobj, status, mfail)
#define XMLFatalErrorAtClass(class, xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLFatalErrorAtClass(class, FALSE, xmlerrhlobj, xmlsaxexobj, status, mfail)
#define XMLFatalErrorAtParent(class, xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLFatalErrorAtClass(class, TRUE, xmlerrhlobj, xmlsaxexobj, status, mfail)

#define XMLGetColumnNumber(xmlsaxexobj, col, mfail) \
        _XMLGetColumnNumberAtClass(NULL, FALSE, xmlsaxexobj, col, mfail)
#define XMLGetColumnNumberAtClass(class, xmlsaxexobj, col, mfail) \
        _XMLGetColumnNumberAtClass(class, FALSE, xmlsaxexobj, col, mfail)
#define XMLGetColumnNumberAtParent(class, xmlsaxexobj, col, mfail) \
        _XMLGetColumnNumberAtClass(class, TRUE, xmlsaxexobj, col, mfail)

#define XMLGetContentHandler(parser, contentHandler, mfail) \
        _XMLGetContentHandlerAtClass(NULL, FALSE, parser, contentHandler, mfail)
#define XMLGetContentHandlerAtClass(class, parser, contentHandler, mfail) \
        _XMLGetContentHandlerAtClass(class, FALSE, parser, contentHandler, mfail)
#define XMLGetContentHandlerAtParent(class, parser, contentHandler, mfail) \
        _XMLGetContentHandlerAtClass(class, TRUE, parser, contentHandler, mfail)

#define XMLGetEntityResolver(parser, xmlenresobj, mfail) \
        _XMLGetEntityResolverAtClass(NULL, FALSE, parser, xmlenresobj, mfail)
#define XMLGetEntityResolverAtClass(class, parser, xmlenresobj, mfail) \
        _XMLGetEntityResolverAtClass(class, FALSE, parser, xmlenresobj, mfail)
#define XMLGetEntityResolverAtParent(class, parser, xmlenresobj, mfail) \
        _XMLGetEntityResolverAtClass(class, TRUE, parser, xmlenresobj, mfail)

#define XMLGetErrorHandler(xmlparsrobj, xmlerrhlobj, mfail) \
        _XMLGetErrorHandlerAtClass(NULL, FALSE, xmlparsrobj, xmlerrhlobj, mfail)
#define XMLGetErrorHandlerAtClass(class, xmlparsrobj, xmlerrhlobj, mfail) \
        _XMLGetErrorHandlerAtClass(class, FALSE, xmlparsrobj, xmlerrhlobj, mfail)
#define XMLGetErrorHandlerAtParent(class, xmlparsrobj, xmlerrhlobj, mfail) \
        _XMLGetErrorHandlerAtClass(class, TRUE, xmlparsrobj, xmlerrhlobj, mfail)

#define XMLGetFeature(xmlparsrobj, feature, value, mfail) \
        _XMLGetFeatureAtClass(NULL, FALSE, xmlparsrobj, feature, value, mfail)
#define XMLGetFeatureAtClass(class, xmlparsrobj, feature, value, mfail) \
        _XMLGetFeatureAtClass(class, FALSE, xmlparsrobj, feature, value, mfail)
#define XMLGetFeatureAtParent(class, xmlparsrobj, feature, value, mfail) \
        _XMLGetFeatureAtClass(class, TRUE, xmlparsrobj, feature, value, mfail)

#define XMLGetLineNumber(xmlsaxexobj, line, mfail) \
        _XMLGetLineNumberAtClass(NULL, FALSE, xmlsaxexobj, line, mfail)
#define XMLGetLineNumberAtClass(class, xmlsaxexobj, line, mfail) \
        _XMLGetLineNumberAtClass(class, FALSE, xmlsaxexobj, line, mfail)
#define XMLGetLineNumberAtParent(class, xmlsaxexobj, line, mfail) \
        _XMLGetLineNumberAtClass(class, TRUE, xmlsaxexobj, line, mfail)

#define XMLGetMessage(xmlsaxexobj, msg, mfail) \
        _XMLGetMessageAtClass(NULL, FALSE, xmlsaxexobj, msg, mfail)
#define XMLGetMessageAtClass(class, xmlsaxexobj, msg, mfail) \
        _XMLGetMessageAtClass(class, FALSE, xmlsaxexobj, msg, mfail)
#define XMLGetMessageAtParent(class, xmlsaxexobj, msg, mfail) \
        _XMLGetMessageAtClass(class, TRUE, xmlsaxexobj, msg, mfail)

#define XMLGetProblemListener(xmlparsrobj, xmlplobj, mfail) \
        _XMLGetProblemListenerAtClass(NULL, FALSE, xmlparsrobj, xmlplobj, mfail)
#define XMLGetProblemListenerAtClass(class, xmlparsrobj, xmlplobj, mfail) \
        _XMLGetProblemListenerAtClass(class, FALSE, xmlparsrobj, xmlplobj, mfail)
#define XMLGetProblemListenerAtParent(class, xmlparsrobj, xmlplobj, mfail) \
        _XMLGetProblemListenerAtClass(class, TRUE, xmlparsrobj, xmlplobj, mfail)

#define XMLGetPropertyStr(xmlparsrobj, property, value, mfail) \
        _XMLGetPropertyStrAtClass(NULL, FALSE, xmlparsrobj, property, value, mfail)
#define XMLGetPropertyStrAtClass(class, xmlparsrobj, property, value, mfail) \
        _XMLGetPropertyStrAtClass(class, FALSE, xmlparsrobj, property, value, mfail)
#define XMLGetPropertyStrAtParent(class, xmlparsrobj, property, value, mfail) \
        _XMLGetPropertyStrAtClass(class, TRUE, xmlparsrobj, property, value, mfail)

#define XMLGetPublicId(xmlsaxexobj, publicId, mfail) \
        _XMLGetPublicIdAtClass(NULL, FALSE, xmlsaxexobj, publicId, mfail)
#define XMLGetPublicIdAtClass(class, xmlsaxexobj, publicId, mfail) \
        _XMLGetPublicIdAtClass(class, FALSE, xmlsaxexobj, publicId, mfail)
#define XMLGetPublicIdAtParent(class, xmlsaxexobj, publicId, mfail) \
        _XMLGetPublicIdAtClass(class, TRUE, xmlsaxexobj, publicId, mfail)

#define XMLGetSystemId(xmlsaxexobj, systemId, mfail) \
        _XMLGetSystemIdAtClass(NULL, FALSE, xmlsaxexobj, systemId, mfail)
#define XMLGetSystemIdAtClass(class, xmlsaxexobj, systemId, mfail) \
        _XMLGetSystemIdAtClass(class, FALSE, xmlsaxexobj, systemId, mfail)
#define XMLGetSystemIdAtParent(class, xmlsaxexobj, systemId, mfail) \
        _XMLGetSystemIdAtClass(class, TRUE, xmlsaxexobj, systemId, mfail)

#define XMLParse(parser, source, mfail) \
        _XMLParseAtClass(NULL, FALSE, parser, source, mfail)
#define XMLParseAtClass(class, parser, source, mfail) \
        _XMLParseAtClass(class, FALSE, parser, source, mfail)
#define XMLParseAtParent(class, parser, source, mfail) \
        _XMLParseAtClass(class, TRUE, parser, source, mfail)

#define XMLResetErrors(xmlerrhlobj, status, mfail) \
        _XMLResetErrorsAtClass(NULL, FALSE, xmlerrhlobj, status, mfail)
#define XMLResetErrorsAtClass(class, xmlerrhlobj, status, mfail) \
        _XMLResetErrorsAtClass(class, FALSE, xmlerrhlobj, status, mfail)
#define XMLResetErrorsAtParent(class, xmlerrhlobj, status, mfail) \
        _XMLResetErrorsAtClass(class, TRUE, xmlerrhlobj, status, mfail)

#define XMLResolveEntity(xmlenresobj, publicId, systemId, xmlinputobj, mfail) \
        _XMLResolveEntityAtClass(NULL, FALSE, xmlenresobj, publicId, systemId, xmlinputobj, mfail)
#define XMLResolveEntityAtClass(class, xmlenresobj, publicId, systemId, xmlinputobj, mfail) \
        _XMLResolveEntityAtClass(class, FALSE, xmlenresobj, publicId, systemId, xmlinputobj, mfail)
#define XMLResolveEntityAtParent(class, xmlenresobj, publicId, systemId, xmlinputobj, mfail) \
        _XMLResolveEntityAtClass(class, TRUE, xmlenresobj, publicId, systemId, xmlinputobj, mfail)

#define XMLSetContentHandler(parser, contentHandler, mfail) \
        _XMLSetContentHandlerAtClass(NULL, FALSE, parser, contentHandler, mfail)
#define XMLSetContentHandlerAtClass(class, parser, contentHandler, mfail) \
        _XMLSetContentHandlerAtClass(class, FALSE, parser, contentHandler, mfail)
#define XMLSetContentHandlerAtParent(class, parser, contentHandler, mfail) \
        _XMLSetContentHandlerAtClass(class, TRUE, parser, contentHandler, mfail)

#define XMLSetEntityResolver(parser, xmlenresobj, mfail) \
        _XMLSetEntityResolverAtClass(NULL, FALSE, parser, xmlenresobj, mfail)
#define XMLSetEntityResolverAtClass(class, parser, xmlenresobj, mfail) \
        _XMLSetEntityResolverAtClass(class, FALSE, parser, xmlenresobj, mfail)
#define XMLSetEntityResolverAtParent(class, parser, xmlenresobj, mfail) \
        _XMLSetEntityResolverAtClass(class, TRUE, parser, xmlenresobj, mfail)

#define XMLSetErrorHandler(xmlparsrobj, xmlerrhlobj, mfail) \
        _XMLSetErrorHandlerAtClass(NULL, FALSE, xmlparsrobj, xmlerrhlobj, mfail)
#define XMLSetErrorHandlerAtClass(class, xmlparsrobj, xmlerrhlobj, mfail) \
        _XMLSetErrorHandlerAtClass(class, FALSE, xmlparsrobj, xmlerrhlobj, mfail)
#define XMLSetErrorHandlerAtParent(class, xmlparsrobj, xmlerrhlobj, mfail) \
        _XMLSetErrorHandlerAtClass(class, TRUE, xmlparsrobj, xmlerrhlobj, mfail)

#define XMLSetFeature(xmlparsrobj, feature, value, mfail) \
        _XMLSetFeatureAtClass(NULL, FALSE, xmlparsrobj, feature, value, mfail)
#define XMLSetFeatureAtClass(class, xmlparsrobj, feature, value, mfail) \
        _XMLSetFeatureAtClass(class, FALSE, xmlparsrobj, feature, value, mfail)
#define XMLSetFeatureAtParent(class, xmlparsrobj, feature, value, mfail) \
        _XMLSetFeatureAtClass(class, TRUE, xmlparsrobj, feature, value, mfail)

#define XMLSetProblemListener(xmlparsrobj, xmlplobj, mfail) \
        _XMLSetProblemListenerAtClass(NULL, FALSE, xmlparsrobj, xmlplobj, mfail)
#define XMLSetProblemListenerAtClass(class, xmlparsrobj, xmlplobj, mfail) \
        _XMLSetProblemListenerAtClass(class, FALSE, xmlparsrobj, xmlplobj, mfail)
#define XMLSetProblemListenerAtParent(class, xmlparsrobj, xmlplobj, mfail) \
        _XMLSetProblemListenerAtClass(class, TRUE, xmlparsrobj, xmlplobj, mfail)

#define XMLSetPropertyStr(xmlparsrobj, property, value, mfail) \
        _XMLSetPropertyStrAtClass(NULL, FALSE, xmlparsrobj, property, value, mfail)
#define XMLSetPropertyStrAtClass(class, xmlparsrobj, property, value, mfail) \
        _XMLSetPropertyStrAtClass(class, FALSE, xmlparsrobj, property, value, mfail)
#define XMLSetPropertyStrAtParent(class, xmlparsrobj, property, value, mfail) \
        _XMLSetPropertyStrAtClass(class, TRUE, xmlparsrobj, property, value, mfail)

#define XMLStartDocument(xmlcthdlobj, mfail) \
        _XMLStartDocumentAtClass(NULL, FALSE, xmlcthdlobj, mfail)
#define XMLStartDocumentAtClass(class, xmlcthdlobj, mfail) \
        _XMLStartDocumentAtClass(class, FALSE, xmlcthdlobj, mfail)
#define XMLStartDocumentAtParent(class, xmlcthdlobj, mfail) \
        _XMLStartDocumentAtClass(class, TRUE, xmlcthdlobj, mfail)

#define XMLStartElement(contentHandler, uri, localName, qName, xmlattrsobj, mfail) \
        _XMLStartElementAtClass(NULL, FALSE, contentHandler, uri, localName, qName, xmlattrsobj, mfail)
#define XMLStartElementAtClass(class, contentHandler, uri, localName, qName, xmlattrsobj, mfail) \
        _XMLStartElementAtClass(class, FALSE, contentHandler, uri, localName, qName, xmlattrsobj, mfail)
#define XMLStartElementAtParent(class, contentHandler, uri, localName, qName, xmlattrsobj, mfail) \
        _XMLStartElementAtClass(class, TRUE, contentHandler, uri, localName, qName, xmlattrsobj, mfail)

#define XMLUseXSLTObj(thisObj, XSLTobj, mfail) \
        _XMLUseXSLTObjAtClass(NULL, FALSE, thisObj, XSLTobj, mfail)
#define XMLUseXSLTObjAtClass(class, thisObj, XSLTobj, mfail) \
        _XMLUseXSLTObjAtClass(class, FALSE, thisObj, XSLTobj, mfail)
#define XMLUseXSLTObjAtParent(class, thisObj, XSLTobj, mfail) \
        _XMLUseXSLTObjAtClass(class, TRUE, thisObj, XSLTobj, mfail)

#define XMLWarning(xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLWarningAtClass(NULL, FALSE, xmlerrhlobj, xmlsaxexobj, status, mfail)
#define XMLWarningAtClass(class, xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLWarningAtClass(class, FALSE, xmlerrhlobj, xmlsaxexobj, status, mfail)
#define XMLWarningAtParent(class, xmlerrhlobj, xmlsaxexobj, status, mfail) \
        _XMLWarningAtClass(class, TRUE, xmlerrhlobj, xmlsaxexobj, status, mfail)

#define XSLTProblem(probListener, mtiWhere, mtiClassif, mtiMsg, mtiUri, lineNo, charOffset, mfail) \
        _XSLTProblemAtClass(NULL, FALSE, probListener, mtiWhere, mtiClassif, mtiMsg, mtiUri, lineNo, charOffset, mfail)
#define XSLTProblemAtClass(class, probListener, mtiWhere, mtiClassif, mtiMsg, mtiUri, lineNo, charOffset, mfail) \
        _XSLTProblemAtClass(class, FALSE, probListener, mtiWhere, mtiClassif, mtiMsg, mtiUri, lineNo, charOffset, mfail)
#define XSLTProblemAtParent(class, probListener, mtiWhere, mtiClassif, mtiMsg, mtiUri, lineNo, charOffset, mfail) \
        _XSLTProblemAtClass(class, TRUE, probListener, mtiWhere, mtiClassif, mtiMsg, mtiUri, lineNo, charOffset, mfail)

#define XSLTProcess(processor, stylesheet, inputSrc, outputSink, mfail) \
        _XSLTProcessAtClass(NULL, FALSE, processor, stylesheet, inputSrc, outputSink, mfail)
#define XSLTProcessAtClass(class, processor, stylesheet, inputSrc, outputSink, mfail) \
        _XSLTProcessAtClass(class, FALSE, processor, stylesheet, inputSrc, outputSink, mfail)
#define XSLTProcessAtParent(class, processor, stylesheet, inputSrc, outputSink, mfail) \
        _XSLTProcessAtClass(class, TRUE, processor, stylesheet, inputSrc, outputSink, mfail)

#define XSLTSetStyleSheetParam(thisObj, key, value, mfail) \
        _XSLTSetStyleSheetParamAtClass(NULL, FALSE, thisObj, key, value, mfail)
#define XSLTSetStyleSheetParamAtClass(class, thisObj, key, value, mfail) \
        _XSLTSetStyleSheetParamAtClass(class, FALSE, thisObj, key, value, mfail)
#define XSLTSetStyleSheetParamAtParent(class, thisObj, key, value, mfail) \
        _XSLTSetStyleSheetParamAtClass(class, TRUE, thisObj, key, value, mfail)

#define XmlDummyDP(pdmItem, mfail) \
        _XmlDummyDPAtClass(NULL, FALSE, pdmItem, mfail)
#define XmlDummyDPAtClass(class, pdmItem, mfail) \
        _XmlDummyDPAtClass(class, FALSE, pdmItem, mfail)
#define XmlDummyDPAtParent(class, pdmItem, mfail) \
        _XmlDummyDPAtClass(class, TRUE, pdmItem, mfail)
#endif /* for msgxml_H */

