struct get_SAP_Part_details
{
	char sStock[10];
	char sMRPCtrl[10];
	char sBulkMatInd[3];
	char sProcType[2];
	char sSpProcType[3];
	char sMovPR[15];
	char sStdPrice[17];
	char sPlndPrice[17];	
	char sPurGrp[3];
	char sPoUnit[3];
	char sPoUnitIso[3];
	char sStgeLoc[4];
	//char sIssStLoc[4];	
	//char sUsgProb[10];
};

struct get_UsagProb
{
	char sComp[20];
	char sUsgProb[10];
};

struct get_SOR_details
{
	char part_no[19];
	char description[41];
	char drawing_no[23];
	char drawing_date[11];
	char revision_level[3];
	char sequence_no[6];
	char sor_no[11];
	char sor_creation_date[11];
	char rfx_no[11];
	char rfx_creation_date[11];
	char trso_init_date[11];
	char manuf_loc[51];
} getSORDet[100] ;
