/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_Interface_Rule.c
**
**
**	Date				Author			Modification
**	03-06-2024			Akshay Toke	    Code creation
* 
* SrNo		Modified By		Date			Modification
*	1		Akshay Toke 	03 Jun 2024		set dynamic participant for Interface Rule task

***********************************************************************************************************************************************************/

#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <pom/pom/pom.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#define PS_where_used_all_levels   -1 
#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 701)
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
**
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

/****************************************************************************
*   Function name			: IRC_Data_Assign_participant_Func
*   Description				: To set dynamic participant for Interface Rule task in workflow.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		22/01/2018			Akshay Toke	 set dynamic participant for Interface Rule task
*
****************************************************************************/
int IRC_Assign_participant_Func(EPM_action_message_t msg)
{
	tag_t   *attachment     =  NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t	objTag			=  NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	tag_t	roottask        =  NULLTAG;
	tag_t partrevtag = NULLTAG;
	int      no_attach      =  0;
	int     n_entry    = 1; 
	int     rsltCount      =  0; 
	int error_code = ITK_ok;
    char	*chklistdataNo			=  NULL;
	char	*DMLType		=  NULL;	
	char	*chklistdatarev		=  NULL;	
	char    *qry_entry[1]  = {"SYSCD"};
	char 	*qry_values2[1]={"IRC"};
	char	*info1	= NULL;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char   *ObjTyp = NULL;
	char* user_id =NULL;
	char command[512];

    POM_get_user_id (&user_id);
	printf("\n IRC: Dynamic particiant assignment start.......");fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n IRC:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		partrevtag = attachment[0];
		if(AOM_ask_value_string(attachment[0],"item_id",&chklistdataNo)!=ITK_ok)PrintErrorStack();
		printf("\n chklistdata Number: [%s].", chklistdataNo);fflush(stdout);
		if(AOM_ask_value_string(attachment[0],"item_revision_id",&chklistdatarev)!=ITK_ok)PrintErrorStack();
		printf("\n chklistdata Rev: [%s].", chklistdatarev);fflush(stdout);
		if(TCTYPE_ask_object_type(partrevtag,&objTypTag));
		if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
		printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
			if(rsltCount > 0)
			{
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
				if (tc_strcmp(info2,"Shell")==0)
				{
					if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
					printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
					printf("\n %s:Exe logic to set reviewer start...\n",chklistdataNo);fflush(stdout);
		            char    *strg = NULL;
				    strg = malloc(1500);
					char *tempRevID = NULL;
					char *Shell_Path  = NULL;
					char command[1000];

					tc_strcpy(strg,"");				
					tc_strcat(strg,stripBlanks(chklistdataNo));
					tc_strcat(strg," ");	
					STRNG_replace_str(chklistdatarev,";","_",&tempRevID);
					printf("\n After STRNG_replace_str tempRev ID %s \n",tempRevID);
					tc_strcat(strg,stripBlanks(tempRevID));
					
					sprintf(command,"%s %s %s",info1,strg,user_id);
					TC_write_syslog("Command = %s\n",command);
					printf("\n command to Run %s \n",command);
					system(command);
				}
				else
				{
					int PrtCount = 0;
					int jk=0;
					int iii=0;
					tag_t ObjTypIR  = NULLTAG;
					tag_t *IR_Particpant = NULLTAG;
					tag_t IR_PartTag     = NULLTAG;
					tag_t IR_Particpant_rel_type = NULLTAG;
					char* IR_Reviewr =NULL;
					char* IRtype_name =NULL;
					if(GRM_find_relation_type("HasParticipant", &IR_Particpant_rel_type)!=ITK_ok)PrintErrorStack();
					if(tc_strcmp(ObjTyp,"T5_IR_CLIST_DATARevision")==0)
					{
						printf("\n TR:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
						if(GRM_list_secondary_objects_only(partrevtag,IR_Particpant_rel_type,&PrtCount,&IR_Particpant)!=ITK_ok)PrintErrorStack();
						printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);
						for (jk=0;jk<PrtCount ;jk++ )
						{
							IR_PartTag = IR_Particpant[jk];
							if(TCTYPE_ask_object_type(IR_PartTag,&ObjTypIR));
							if(TCTYPE_ask_name2(ObjTypIR,&IRtype_name));
							printf("\n IR: Participants Name: %s", IRtype_name);fflush(stdout);
							if (tc_strcmp(IRtype_name,"T5_COChead")==0)
							{
								if(AOM_UIF_ask_value(IR_PartTag,"fnd0AssigneeUser",&IR_Reviewr)!=ITK_ok)PrintErrorStack();
								printf("\n TR:Removing CCID Reviewer: [%s] ",IR_Reviewr);fflush(stdout);
								AOM_lock(partrevtag);
								PARTICIPANT_remove_participant((const tag_t)partrevtag,(const tag_t)IR_PartTag);
								printf("\n TR:REMOVE PARTICIPALNTS END. \n");fflush(stdout);
								AOM_save_without_extensions(partrevtag);
								printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
								AOM_unlock(partrevtag);
								printf("\n TR:REMOVE PARTICIPALNTS END... \n");fflush(stdout);
								AOM_refresh (partrevtag,TRUE);
								printf("\n TR:REMOVE PARTICIPALNTS END.... \n");fflush(stdout);
							}
						}

						/// Addition of COC Reviewer
						char	*groupName			=  NULL;
						char	*roleName			=  NULL;
						char	*aggregate			=  NULL;
						tag_t	group_tag		=  NULLTAG;
						tag_t	role_tag			=  NULLTAG;
						tag_t	CCID_Party			=  NULLTAG;
						tag_t	CCID_Patri_Type			=  NULLTAG;
						tag_t  *CCID_Tags			=  NULL;
						int    No_CCID=0;
						int IRcnt = 0;
						int DegnRevCnt = 0;
						tag_t IRchklstreltyp = NULLTAG;
						tag_t ImaRefTag = NULLTAG;
						tag_t DsgnRevTag = NULLTAG;
						tag_t* IRobjTags = NULLTAG;
						tag_t* DegnRevTags = NULLTAG;
						if(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&IRchklstreltyp)) PrintErrorStack();
						if(GRM_list_primary_objects_only(partrevtag,IRchklstreltyp,&IRcnt,&IRobjTags)) PrintErrorStack();
						if (IRcnt > 0)
						{
							if(GRM_find_relation_type("IMAN_reference",&ImaRefTag)) PrintErrorStack();
							if(GRM_list_primary_objects_only(IRobjTags[0],ImaRefTag,&DegnRevCnt,&DegnRevTags)) PrintErrorStack();
							if (DegnRevCnt > 0)
							{
								DsgnRevTag = DegnRevTags[0];

								if(AOM_ask_value_string(DsgnRevTag,"t5_Aggregate",&aggregate)!=ITK_ok)PrintErrorStack();
							
								printf("\n IR:aggregate: [%s] ", aggregate);fflush(stdout);

								groupName = (char*)MEM_alloc(100);
								roleName = (char*)MEM_alloc(100);

								if(tc_strstr(aggregate,"APPLICATIONS")!=NULL)
								{
								  tc_strcpy(groupName,"APPLICATIONS");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"EXTERIOR")!=NULL)
								{
								  tc_strcpy(groupName,"EXTERIOR");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"INTERIOR")!=NULL)
								{
								  tc_strcpy(groupName,"INTERIOR");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"CHASSIS INTEGRATION AGGREGATES")!=NULL)
								{
								  tc_strcpy(groupName,"CHASSIS_INTEGRATION_AGGREGATES");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"DRIVELINE INTEGRATION AGGREGATES")!=NULL)
								{
								  tc_strcpy(groupName,"DRIVELINE_INTEGRATION_AGGREGATES");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"ENGINE INTEGRATION AGGREGATES")!=NULL)
								{
								  tc_strcpy(groupName,"ENGINE_INTEGRATION_AGGREGATES");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"SUSPENSION")!=NULL)
								{
								  tc_strcpy(groupName,"SUSPENSION");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"BRAKES & WHEELS")!=NULL)
								{
								  tc_strcpy(groupName,"BRAKES_AND_WHEELS");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"POWER AND DISTRIBUTION")!=NULL)
								{
								  tc_strcpy(groupName,"POWER_AND_DISTRIBUTION");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"ENGINE BASE ENGINEERING")!=NULL)
								{
								  tc_strcpy(groupName,"ENGINE_BASE_ENGINEERING");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"TRANSMISSION")!=NULL)
								{
								  tc_strcpy(groupName,"TRANSMISSION");
								  tc_strcat(groupName,".InterfaceRule");
								}
								else if(tc_strstr(aggregate,"POWERTRAIN")!=NULL)
								{
								  tc_strcpy(groupName,"POWERTRAIN");
								  tc_strcat(groupName,".InterfaceRule");
								}
								tc_strcpy(roleName,"COC_Head");
								printf("\n IR:groupName: [%s]   roleName: [%s]", groupName,roleName);fflush(stdout);
								if(SA_find_group(groupName,&group_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_role2(roleName,&role_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(role_tag,group_tag,&No_CCID,&CCID_Tags)!=ITK_ok)PrintErrorStack();
								printf("\n IR: No_CCID :[%d]",No_CCID);fflush(stdout);

								if(No_CCID>0)
								{
									for(iii=0;iii<No_CCID;iii++)
									{	 
										printf("\n IR:CVBU: COCHead Reviewer no [%d]",iii);fflush(stdout);

										if(EPM_get_participanttype ("T5_COChead",&CCID_Patri_Type)!=ITK_ok)PrintErrorStack();
										if(EPM_create_participant(CCID_Tags[iii],CCID_Patri_Type,&CCID_Party)!=ITK_ok)PrintErrorStack();
										AOM_lock(partrevtag);			
										//if(ITEM_rev_add_participant(partrevtag,CCID_Party)!=ITK_ok)PrintErrorStack(); 
										if(PARTICIPANT_add_participant((const tag_t)partrevtag,TRUE,(const tag_t)CCID_Party)!=ITK_ok)PrintErrorStack();
										AOM_save_without_extensions(partrevtag);
										AOM_unlock(partrevtag);
									}
									AOM_refresh (partrevtag,TRUE);
									MEM_free(CCID_Tags);
								}
							}
						}
					}
				}
				printf("\n IRC:Reviewers set successfully.. \n");fflush(stdout);
			}
		}
		else
		{
			printf("\n IRC:Not Found Query ControlObjects \n");fflush(stdout);
		}
	}
	return error_code;
}


int IRC_DeviationPreapprovalmail(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	ChkLstobjTag			=  NULLTAG;
	int      no_attach      =  0;
    char	*chklistdataNo			=  NULL;
	char	*DMLType		=  NULL;	
	char	*chklistdatarev		=  NULL;	
	tag_t	objTypTag		= NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	char    *qry_entry[1]  = {"SYSCD"};
	int     n_entry    = 1; 
	int     rsltCount      =  0; 
	tag_t   *CntrlObjectTag      = NULLTAG;
	char	*info1	= NULL;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char   *ObjTyp = NULL;
	char command[512];
	int error_code = ITK_ok;
	char* user_id =NULL;
	char    *qry_values2[1] = {"IRCDeviationPreapprovalmail"};
    POM_get_user_id (&user_id);
	
	printf("\n IRC: IRCDeviationPreapprovalmail start.......");fflush(stdout);
	printf("\n current user is: [%s]", user_id);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n IRC:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		ChkLstobjTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&chklistdataNo)!=ITK_ok)PrintErrorStack();

	printf("\n chklistdata Number: [%s].", chklistdataNo);fflush(stdout);
	if(AOM_ask_value_string(attachment[0],"item_revision_id",&chklistdatarev)!=ITK_ok)PrintErrorStack();
	printf("\n chklistdata Rev: [%s].", chklistdatarev);fflush(stdout);

	if(TCTYPE_ask_object_type(attachment[0],&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

	if(QRY_find2("ControlObjects", &qryTag));
	if (qryTag)
	{
		printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
		if(rsltCount > 0)
		{
			if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n info2 is.:[%s]\n", info2);fflush(stdout);

			if (tc_strcmp(info2,"Mail")==0)
			{
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				char  *CocHeads	  = NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				CocHeads = (char *) MEM_alloc( 500 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				char* info9 = NULL;
				char* info10 = NULL;
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(CocHeads,"");
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info9);
				tc_strcpy(eMailCC,info10);

				tag_t IRchklstreltyp = NULLTAG;
				tag_t ImaRefTag = NULLTAG;
				int IRcnt = 0;
				int DegnRevCnt = 0;
				tag_t* IRobjTags = NULLTAG;
				tag_t* DegnRevTags = NULLTAG;
				tag_t DsgnRevTag = NULLTAG;
				char* item_id = NULL;
				char* item_revision_id = NULL;
				char* aggregate = NULL;
				char* owning_user = NULL;
				char* group_display_name = NULL;
				char* cocName = NULL;
				char* mailId = NULL;
				char* OwnerMailId = NULL;
				char* t5_Design_Rule_ID = NULL;
				char* t5_Remark = NULL;
				char* t5_Aggregate_Group = NULL;
				char* t5_Interface_Rule_Desc = NULL;
				char* t5_Checklist_Implemented = NULL;
				int chldGrpCnt = 0;
				int g = 0;
				tag_t* chldGrpTags = NULLTAG;
				int No_COC = 0;
				int coc = 0;
				tag_t* COC_Tags = NULLTAG;
				tag_t user_tag = NULLTAG;
				tag_t person_tag = NULLTAG;
				tag_t owning_user_tag = NULLTAG;
				tag_t owningPerson = NULLTAG;
				tag_t group_tag = NULLTAG;
				tag_t role_tag = NULLTAG;
				if(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&IRchklstreltyp)) PrintErrorStack();
				if(GRM_list_primary_objects_only(ChkLstobjTag,IRchklstreltyp,&IRcnt,&IRobjTags)) PrintErrorStack();
				if (IRcnt > 0)
				{
					if(GRM_find_relation_type("IMAN_reference",&ImaRefTag)) PrintErrorStack();
					if(GRM_list_primary_objects_only(IRobjTags[0],ImaRefTag,&DegnRevCnt,&DegnRevTags)) PrintErrorStack();
					if (DegnRevCnt > 0)
					{
						DsgnRevTag = DegnRevTags[0];
						if(AOM_ask_value_string(DsgnRevTag,"item_id",&item_id)!=ITK_ok)   PrintErrorStack();
						if(AOM_ask_value_string(DsgnRevTag,"item_revision_id",&item_revision_id)!=ITK_ok)   PrintErrorStack();
						if(AOM_ask_value_string(DsgnRevTag,"t5_Aggregate",&aggregate)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(ChkLstobjTag,"t5_Design_Rule_ID",&t5_Design_Rule_ID)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(ChkLstobjTag,"t5_Remark",&t5_Remark)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(ChkLstobjTag,"t5_Aggregate_Group",&t5_Aggregate_Group)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(ChkLstobjTag,"t5_Interface_Rule_Desc",&t5_Interface_Rule_Desc)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(ChkLstobjTag,"t5_Checklist_Implemented",&t5_Checklist_Implemented)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(DsgnRevTag,"owning_user",&owning_user)!=ITK_ok)PrintErrorStack();

						if( AOM_ask_owner(DsgnRevTag,&owning_user_tag)!=ITK_ok) PrintErrorStack();
						if(owning_user_tag!=NULLTAG){
							if( SA_ask_user_person(owning_user_tag,&owningPerson)!=ITK_ok) PrintErrorStack();
							if(SA_ask_person_email_address(owningPerson,&OwnerMailId)!=ITK_ok) PrintErrorStack();
							if(OwnerMailId != NULL)
							{
								if (tc_strcmp(OwnerMailId,"")!=0)
								{
									printf("\nCreator Mail: %s\n",OwnerMailId);
									tc_strcat(eMailTo,",");
									tc_strcat(eMailTo,OwnerMailId);
								}
							}
						}

						if(SA_find_group("InterfaceRule",&group_tag)!=ITK_ok)PrintErrorStack();
						if(SA_find_role2("COC_Head",&role_tag)!=ITK_ok)PrintErrorStack();
						if(SA_ask_group_child_groups(group_tag,TRUE,&chldGrpCnt,&chldGrpTags)!=ITK_ok)PrintErrorStack();
						printf("\nChild Groups: %d",chldGrpCnt);
						for (g = 0; g < chldGrpCnt; ++g)
						{
							No_COC = 0;
							if(SA_ask_group_display_name(chldGrpTags[g],&group_display_name)!=ITK_ok)PrintErrorStack();
							printf("\ngroup_display_name: %s || aggregate: %s ",group_display_name,aggregate); fflush(stdout);

							if(tc_strstr(aggregate,"APPLICATIONS")!=NULL && tc_strstr(group_display_name,"APPLICATIONS")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"EXTERIOR")!=NULL && tc_strstr(group_display_name,"EXTERIOR")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"INTERIOR")!=NULL && tc_strstr(group_display_name,"INTERIOR")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"CHASSIS INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"CHASSIS_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"DRIVELINE INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"DRIVELINE_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"ENGINE INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"ENGINE_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"SUSPENSION")!=NULL && tc_strstr(group_display_name,"SUSPENSION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"BRAKES & WHEELS")!=NULL && tc_strstr(group_display_name,"BRAKES_AND_WHEELS")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"POWER AND DISTRIBUTION")!=NULL && tc_strstr(group_display_name,"POWER_AND_DISTRIBUTION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"ENGINE BASE ENGINEERING")!=NULL && tc_strstr(group_display_name,"ENGINE_BASE_ENGINEERING")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"TRANSMISSION")!=NULL && tc_strstr(group_display_name,"TRANSMISSION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"POWERTRAIN")!=NULL && tc_strstr(group_display_name,"POWERTRAIN")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}

							printf("\nNo_COC: %d",No_COC);
							if (No_COC > 0)
							{
								for (coc = 0; coc < No_COC; ++coc)
								{
									if(AOM_UIF_ask_value(COC_Tags[coc],"object_string",&cocName)!=ITK_ok)PrintErrorStack();
									printf("\ncocName: %d",cocName);
									tc_strcat(CocHeads,cocName);
									tc_strcat(CocHeads,",");

									if(SA_ask_groupmember_user(COC_Tags[coc],&user_tag)!=ITK_ok)PrintErrorStack();
									if(SA_ask_user_person (user_tag,&person_tag)!=ITK_ok)PrintErrorStack();
									if(person_tag!=NULLTAG)
									{
										if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
										if(mailId != NULL)
										{
											if(tc_strcmp(mailId,"")!=0)
											{
												printf("\n%s mailId: %s",mailId);
												if(tc_strstr(eMailTo, mailId)==NULL){
													tc_strcat(eMailTo,",");
													tc_strcat(eMailTo,mailId);
												}
											}
										}
									}
								}
							}
						}



						tc_strcpy(envSub,"Deviated Interface rule: ");
						tc_strcat(envSub,t5_Design_Rule_ID);
						tc_strcat(envSub," - ");
						tc_strcat(envSub,item_id);
						tc_strcat(envSub,"/");
						tc_strcat(envSub,item_revision_id);

						tc_strcpy(envDesc,"Dear All, ");
						tc_strcat(envDesc,"\nDeviated Design Rule ID: ");
						tc_strcat(envDesc,t5_Design_Rule_ID);
						tc_strcat(envDesc,"\nInterface Rule Description: ");
						tc_strcat(envDesc,t5_Interface_Rule_Desc);
						tc_strcat(envDesc,"\nAggregate Group: ");
						tc_strcat(envDesc,t5_Aggregate_Group);
						tc_strcat(envDesc,"\nRemark: ");
						tc_strcat(envDesc,t5_Remark);
						tc_strcat(envDesc,"\nStatus: ");
						tc_strcat(envDesc,t5_Checklist_Implemented);
						tc_strcat(envDesc,"\n\nSubmodule Number: ");
						tc_strcat(envDesc,item_id);
						tc_strcat(envDesc,"\nSubmodule Revision: ");
						tc_strcat(envDesc,item_revision_id);
						tc_strcat(envDesc,"\nSubmodule Aggregate: ");
						tc_strcat(envDesc,aggregate);
						tc_strcat(envDesc,"\n\nDesign Engineer: ");
						tc_strcat(envDesc,owning_user);
						tc_strcat(envDesc,"\nAggregate COC: ");
						tc_strcat(envDesc,CocHeads);
						tc_strcat(envDesc,"\nCoC approval status: Pending\n\n");

						printf("\n\nMAIL_initialize\n\n");
						sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
						printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
						system(buff);
					}
				}
			}

			if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
			printf("\n info3 is.:[%s]\n", info3);fflush(stdout);
			if (tc_strcmp(info3,"Shell")==0)
			{
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
				printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
	            char    *strg = NULL;
			    strg = malloc(1500);
				char *tempRevID = NULL;
				char *Shell_Path  = NULL;
				char command[1000];
				if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&Shell_Path)!=ITK_ok)PrintErrorStack();
				printf("\n Information 1 Value == [%s]", Shell_Path);fflush(stdout);
				tc_strcpy(strg,"");				
				tc_strcat(strg,stripBlanks(chklistdataNo));
				tc_strcat(strg," ");	
				STRNG_replace_str(chklistdatarev,";","_",&tempRevID);
				printf("\n After STRNG_replace_str tempRev ID %s \n",tempRevID);
				tc_strcat(strg,stripBlanks(tempRevID));
				sprintf(command,"%s %s %s",Shell_Path,strg,user_id);
				printf("\n Command to be run  == <%s>", command);fflush(stdout);
				system(command);
			}
		}
	}
	else
	{
		printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
	}
	return error_code;
}

int IRC_DeviationPostapprovalmail(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	tag_t   *CntrlObjectTag      = NULLTAG;
	int      no_attach      =  0;
    char	*chklistdataNo			=  NULL;
	char	*DMLType		=  NULL;	
	char	*chklistdatarev		=  NULL;	
	char    *qry_entry[1]  = {"SYSCD"};
	char    *qry_values2[1]     =  {"IRCDeviationPostapprovalmail"};
	int     n_entry    = 1; 
	int     rsltCount      =  0; 
	char	*info1	= NULL;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char   *ObjTyp = NULL;
	char command[512];
	int error_code = ITK_ok;
	char* user_id =NULL;
	char* TaskResult = NULL;
	
    POM_get_user_id (&user_id);
	printf("\n IRC: IRC_DeviationPostapprovalmail start.......");fflush(stdout);
	printf("\n current user is: [%s]", user_id);fflush(stdout);
	
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n IRC:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&chklistdataNo)!=ITK_ok)PrintErrorStack();
	printf("\n chklistdata Number: [%s].", chklistdataNo);fflush(stdout);
	if(AOM_ask_value_string(attachment[0],"item_revision_id",&chklistdatarev)!=ITK_ok)PrintErrorStack();
	printf("\n chklistdata Rev: [%s].", chklistdatarev);fflush(stdout);

	if(TCTYPE_ask_object_type(attachment[0],&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag));
	if (qryTag)
	{
		printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
		if(rsltCount > 0)
		{
			if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n info2 is.:[%s]\n", info2);fflush(stdout);

			if (tc_strcmp(info2,"Mail")==0)
			{
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				char  *CocHeads	  = NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				CocHeads = (char *) MEM_alloc( 500 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				char* info9 = NULL;
				char* info10 = NULL;
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(CocHeads,"");
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info9);
				tc_strcpy(eMailCC,info10);

				tag_t IRchklstreltyp = NULLTAG;
				tag_t ImaRefTag = NULLTAG;
				int IRcnt = 0;
				int DegnRevCnt = 0;
				tag_t* IRobjTags = NULLTAG;
				tag_t* DegnRevTags = NULLTAG;
				tag_t DsgnRevTag = NULLTAG;
				char* item_id = NULL;
				char* item_revision_id = NULL;
				char* aggregate = NULL;
				char* owning_user = NULL;
				char* group_display_name = NULL;
				char* cocName = NULL;
				char* mailId = NULL;
				char* OwnerMailId = NULL;
				char* t5_Design_Rule_ID = NULL;
				char* t5_Remark = NULL;
				char* t5_Aggregate_Group = NULL;
				char* t5_Interface_Rule_Desc = NULL;
				char* t5_Checklist_Implemented = NULL;
				int chldGrpCnt = 0;
				int g = 0;
				tag_t* chldGrpTags = NULLTAG;
				int No_COC = 0;
				int coc = 0;
				tag_t* COC_Tags = NULLTAG;
				tag_t user_tag = NULLTAG;
				tag_t person_tag = NULLTAG;
				tag_t owning_user_tag = NULLTAG;
				tag_t owningPerson = NULLTAG;
				tag_t group_tag = NULLTAG;
				tag_t role_tag = NULLTAG;
				if(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&IRchklstreltyp)) PrintErrorStack();
				if(GRM_list_primary_objects_only(objTag,IRchklstreltyp,&IRcnt,&IRobjTags)) PrintErrorStack();
				if (IRcnt > 0)
				{
					if(GRM_find_relation_type("IMAN_reference",&ImaRefTag)) PrintErrorStack();
					if(GRM_list_primary_objects_only(IRobjTags[0],ImaRefTag,&DegnRevCnt,&DegnRevTags)) PrintErrorStack();
					if (DegnRevCnt > 0)
					{
						DsgnRevTag = DegnRevTags[0];
						if (AOM_ask_value_string(DsgnRevTag,"item_id",&item_id)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DsgnRevTag,"item_revision_id",&item_revision_id)!=ITK_ok)   PrintErrorStack();
						if(AOM_ask_value_string(DsgnRevTag,"t5_Aggregate",&aggregate)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Design_Rule_ID",&t5_Design_Rule_ID)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Remark",&t5_Remark)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Aggregate_Group",&t5_Aggregate_Group)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Interface_Rule_Desc",&t5_Interface_Rule_Desc)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Checklist_Implemented",&t5_Checklist_Implemented)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(DsgnRevTag,"owning_user",&owning_user)!=ITK_ok)PrintErrorStack();

						if( AOM_ask_owner(DsgnRevTag,&owning_user_tag)!=ITK_ok) PrintErrorStack();
						if(owning_user_tag!=NULLTAG){
							if( SA_ask_user_person(owning_user_tag,&owningPerson)!=ITK_ok) PrintErrorStack();
							if(SA_ask_person_email_address(owningPerson,&OwnerMailId)!=ITK_ok) PrintErrorStack();
							if(OwnerMailId != NULL)
							{
								if (tc_strcmp(OwnerMailId,"")!=0)
								{
									printf("\nCreator Mail: %s\n",OwnerMailId);
									tc_strcat(eMailTo,",");
									tc_strcat(eMailTo,OwnerMailId);
								}
							}
						}

						if(SA_find_group("InterfaceRule",&group_tag)!=ITK_ok)PrintErrorStack();
						if(SA_find_role2("COC_Head",&role_tag)!=ITK_ok)PrintErrorStack();
						if(SA_ask_group_child_groups(group_tag,TRUE,&chldGrpCnt,&chldGrpTags)!=ITK_ok)PrintErrorStack();
						printf("\nChild Groups: %d",chldGrpCnt);
						for (g = 0; g < chldGrpCnt; ++g)
						{
							No_COC = 0;
							if(SA_ask_group_display_name(chldGrpTags[g],&group_display_name)!=ITK_ok)PrintErrorStack();
							printf("\ngroup_display_name: %s || aggregate: %s ",group_display_name,aggregate); fflush(stdout);

							if(tc_strstr(aggregate,"APPLICATIONS")!=NULL && tc_strstr(group_display_name,"APPLICATIONS")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"EXTERIOR")!=NULL && tc_strstr(group_display_name,"EXTERIOR")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"INTERIOR")!=NULL && tc_strstr(group_display_name,"INTERIOR")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"CHASSIS INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"CHASSIS_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"DRIVELINE INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"DRIVELINE_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"ENGINE INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"ENGINE_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"SUSPENSION")!=NULL && tc_strstr(group_display_name,"SUSPENSION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"BRAKES & WHEELS")!=NULL && tc_strstr(group_display_name,"BRAKES_AND_WHEELS")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"POWER AND DISTRIBUTION")!=NULL && tc_strstr(group_display_name,"POWER_AND_DISTRIBUTION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"ENGINE BASE ENGINEERING")!=NULL && tc_strstr(group_display_name,"ENGINE_BASE_ENGINEERING")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"TRANSMISSION")!=NULL && tc_strstr(group_display_name,"TRANSMISSION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"POWERTRAIN")!=NULL && tc_strstr(group_display_name,"POWERTRAIN")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}

							printf("\nNo_COC: %d",No_COC);
							if (No_COC > 0)
							{
								for (coc = 0; coc < No_COC; ++coc)
								{
									if(AOM_UIF_ask_value(COC_Tags[coc],"object_string",&cocName)!=ITK_ok)PrintErrorStack();
									printf("\ncocName: %d",cocName);
									tc_strcat(CocHeads,cocName);
									tc_strcat(CocHeads,",");

									if(SA_ask_groupmember_user(COC_Tags[coc],&user_tag)!=ITK_ok)PrintErrorStack();
									if(SA_ask_user_person (user_tag,&person_tag)!=ITK_ok)PrintErrorStack();
									if(person_tag!=NULLTAG)
									{
										if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
										if(mailId != NULL)
										{
											if(tc_strcmp(mailId,"")!=0)
											{
												printf("\n%s mailId: %s",mailId);
												if(tc_strstr(eMailTo, mailId)==NULL){
													tc_strcat(eMailTo,",");
													tc_strcat(eMailTo,mailId);
												}
											}
										}
									}
								}
							}
						}

						tc_strcpy(envSub,"APPROVED:Deviated Interface rule: ");
						tc_strcat(envSub,t5_Design_Rule_ID);
						tc_strcat(envSub," - ");
						tc_strcat(envSub,item_id);
						tc_strcat(envSub,"/");
						tc_strcat(envSub,item_revision_id);

						tc_strcpy(envDesc,"Dear All, ");
						tc_strcat(envDesc,"\n\nDeviated Design Rule ID: ");
						tc_strcat(envDesc,t5_Design_Rule_ID);
						tc_strcat(envDesc,"\n\nInterface Rule Description: ");
						tc_strcat(envDesc,t5_Interface_Rule_Desc);
						tc_strcat(envDesc,"\n\nAggregate Group: ");
						tc_strcat(envDesc,t5_Aggregate_Group);
						tc_strcat(envDesc,"\n\nRemark: ");
						tc_strcat(envDesc,t5_Remark);
						tc_strcat(envDesc,"\n\nStatus: ");
						tc_strcat(envDesc,t5_Checklist_Implemented);
						tc_strcat(envDesc,"\n\n\n\nSubmodule Number: ");
						tc_strcat(envDesc,item_id);
						tc_strcat(envDesc,"\n\nSubmodule Revision: ");
						tc_strcat(envDesc,item_revision_id);
						tc_strcat(envDesc,"\n\nSubmodule Aggregate: ");
						tc_strcat(envDesc,aggregate);
						tc_strcat(envDesc,"\n\n\n\nDesign Engineer: ");
						tc_strcat(envDesc,owning_user);
						tc_strcat(envDesc,"\n\nAggregate COC: ");
						tc_strcat(envDesc,CocHeads);
						tc_strcat(envDesc,"\n\nCoC approval status: Approved\n\n");

						printf("\n\nMAIL_initialize\n\n");
						sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
						printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
						system(buff);
					}
				}
			}

			if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
			printf("\n info3 is.:[%s]\n", info3);fflush(stdout);
			if (tc_strcmp(info3,"Shell")==0)
			{
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
				printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
		        char    *strg = NULL;
			    strg = malloc(1500);
				char *tempRevID = NULL;
				char *Shell_Path  = NULL;
				char command[1000];
			  
				AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&Shell_Path);
				printf("\n Information 1 Value == [%s]", Shell_Path);fflush(stdout);
				tc_strcpy(strg,"");				
				tc_strcat(strg,stripBlanks(chklistdataNo));
				tc_strcat(strg," ");	
				STRNG_replace_str(chklistdatarev,";","_",&tempRevID);
				printf("\n After STRNG_replace_str tempRev ID %s \n",tempRevID);
				tc_strcat(strg,stripBlanks(tempRevID));
				sprintf(command,"%s %s %s",Shell_Path,strg,user_id);

				printf("\n Command to be run  == <%s>", command);fflush(stdout);
				
				system(command);
			}
		}
	}
	else
	{
		printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
	}
	return error_code;
}

int IRC_DeviationCOCRejectmail(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	tag_t   *CntrlObjectTag      = NULLTAG;
	int      no_attach      =  0;
    char	*chklistdataNo			=  NULL;
	char	*DMLType		=  NULL;	
	char	*chklistdatarev		=  NULL;	
	char    *qry_entry[1]  = {"SYSCD"};
	char    *qry_values2[1]     =  {"IRCDeviationPostapprovalmail"};
	int     n_entry    = 1; 
	int     rsltCount      =  0; 
	char	*info1	= NULL;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char   *ObjTyp = NULL;
	char command[512];
	int error_code = ITK_ok;
	char* user_id =NULL;
	char* TaskResult = NULL;
	
    POM_get_user_id (&user_id);
	printf("\n IRC: IRC_DeviationPostapprovalmail start.......");fflush(stdout);
	printf("\n current user is: [%s]", user_id);fflush(stdout);
	
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n IRC:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&chklistdataNo)!=ITK_ok)PrintErrorStack();
	printf("\n chklistdata Number: [%s].", chklistdataNo);fflush(stdout);
	if(AOM_ask_value_string(attachment[0],"item_revision_id",&chklistdatarev)!=ITK_ok)PrintErrorStack();
	printf("\n chklistdata Rev: [%s].", chklistdatarev);fflush(stdout);

	if(TCTYPE_ask_object_type(attachment[0],&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n IRReject: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag));
	if (qryTag)
	{
		printf("\n IRCDeviationPostapprovalmail:Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n IRCDeviationPostapprovalmail:rsltCount :%d:", rsltCount); fflush(stdout);
		if(rsltCount > 0)
		{
			if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n info2 is.:[%s]\n", info2);fflush(stdout);

			if (tc_strcmp(info2,"Mail")==0)
			{
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				char  *CocHeads	  = NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				CocHeads = (char *) MEM_alloc( 500 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				//tc_strcpy(eMailTo,"at924736.ttl@tatamotors.com,sagard1.ttl@tatamotors.com");
				//tc_strcpy(eMailCC,"alokeshg.ttl@tatamotors.com");
				char* info9 = NULL;
				char* info10 = NULL;
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(CocHeads,"");
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info9);
				tc_strcpy(eMailCC,info10);

				tag_t IRchklstreltyp = NULLTAG;
				tag_t ImaRefTag = NULLTAG;
				int IRcnt = 0;
				int DegnRevCnt = 0;
				tag_t* IRobjTags = NULLTAG;
				tag_t* DegnRevTags = NULLTAG;
				tag_t DsgnRevTag = NULLTAG;
				char* item_id = NULL;
				char* item_revision_id = NULL;
				char* aggregate = NULL;
				char* owning_user = NULL;
				char* group_display_name = NULL;
				char* cocName = NULL;
				char* mailId = NULL;
				char* OwnerMailId = NULL;
				char* t5_Design_Rule_ID = NULL;
				char* t5_Remark = NULL;
				char* t5_Aggregate_Group = NULL;
				char* t5_Interface_Rule_Desc = NULL;
				char* t5_Checklist_Implemented = NULL;
				int chldGrpCnt = 0;
				int g = 0;
				tag_t* chldGrpTags = NULLTAG;
				int No_COC = 0;
				int coc = 0;
				tag_t* COC_Tags = NULLTAG;
				tag_t user_tag = NULLTAG;
				tag_t person_tag = NULLTAG;
				tag_t owning_user_tag = NULLTAG;
				tag_t owningPerson = NULLTAG;
				tag_t group_tag = NULLTAG;
				tag_t role_tag = NULLTAG;
				if(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&IRchklstreltyp)) PrintErrorStack();
				if(GRM_list_primary_objects_only(objTag,IRchklstreltyp,&IRcnt,&IRobjTags)) PrintErrorStack();
				if (IRcnt > 0)
				{
					if(GRM_find_relation_type("IMAN_reference",&ImaRefTag)) PrintErrorStack();
					if(GRM_list_primary_objects_only(IRobjTags[0],ImaRefTag,&DegnRevCnt,&DegnRevTags)) PrintErrorStack();
					if (DegnRevCnt > 0)
					{
						DsgnRevTag = DegnRevTags[0];
						if (AOM_ask_value_string(DsgnRevTag,"item_id",&item_id)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DsgnRevTag,"item_revision_id",&item_revision_id)!=ITK_ok)   PrintErrorStack();
						if(AOM_ask_value_string(DsgnRevTag,"t5_Aggregate",&aggregate)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Design_Rule_ID",&t5_Design_Rule_ID)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Remark",&t5_Remark)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Aggregate_Group",&t5_Aggregate_Group)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Interface_Rule_Desc",&t5_Interface_Rule_Desc)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_Checklist_Implemented",&t5_Checklist_Implemented)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(DsgnRevTag,"owning_user",&owning_user)!=ITK_ok)PrintErrorStack();

						if( AOM_ask_owner(DsgnRevTag,&owning_user_tag)!=ITK_ok) PrintErrorStack();
						if(owning_user_tag!=NULLTAG){
							if( SA_ask_user_person(owning_user_tag,&owningPerson)!=ITK_ok) PrintErrorStack();
							if(SA_ask_person_email_address(owningPerson,&OwnerMailId)!=ITK_ok) PrintErrorStack();
							if(OwnerMailId != NULL)
							{
								if (tc_strcmp(OwnerMailId,"")!=0)
								{
									printf("\nCreator Mail: %s\n",OwnerMailId);
									tc_strcat(eMailTo,",");
									tc_strcat(eMailTo,OwnerMailId);
								}
							}
						}

						if(SA_find_group("InterfaceRule",&group_tag)!=ITK_ok)PrintErrorStack();
						if(SA_find_role2("COC_Head",&role_tag)!=ITK_ok)PrintErrorStack();
						if(SA_ask_group_child_groups(group_tag,TRUE,&chldGrpCnt,&chldGrpTags)!=ITK_ok)PrintErrorStack();
						printf("\nChild Groups: %d",chldGrpCnt);
						for (g = 0; g < chldGrpCnt; ++g)
						{
							No_COC = 0;
							if(SA_ask_group_display_name(chldGrpTags[g],&group_display_name)!=ITK_ok)PrintErrorStack();
							printf("\ngroup_display_name: %s || aggregate: %s ",group_display_name,aggregate); fflush(stdout);

							if(tc_strstr(aggregate,"APPLICATIONS")!=NULL && tc_strstr(group_display_name,"APPLICATIONS")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"EXTERIOR")!=NULL && tc_strstr(group_display_name,"EXTERIOR")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"INTERIOR")!=NULL && tc_strstr(group_display_name,"INTERIOR")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"CHASSIS INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"CHASSIS_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"DRIVELINE INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"DRIVELINE_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"ENGINE INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"ENGINE_INTEGRATION_AGGREGATES")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"SUSPENSION")!=NULL && tc_strstr(group_display_name,"SUSPENSION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"BRAKES & WHEELS")!=NULL && tc_strstr(group_display_name,"BRAKES_AND_WHEELS")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"POWER AND DISTRIBUTION")!=NULL && tc_strstr(group_display_name,"POWER_AND_DISTRIBUTION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"ENGINE BASE ENGINEERING")!=NULL && tc_strstr(group_display_name,"ENGINE_BASE_ENGINEERING")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"TRANSMISSION")!=NULL && tc_strstr(group_display_name,"TRANSMISSION")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strstr(aggregate,"POWERTRAIN")!=NULL && tc_strstr(group_display_name,"POWERTRAIN")!=NULL)
							{
								if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
							}

							printf("\nNo_COC: %d",No_COC);
							if (No_COC > 0)
							{
								for (coc = 0; coc < No_COC; ++coc)
								{
									if(AOM_UIF_ask_value(COC_Tags[coc],"object_string",&cocName)!=ITK_ok)PrintErrorStack();
									printf("\ncocName: %d",cocName);
									tc_strcat(CocHeads,cocName);
									tc_strcat(CocHeads,",");

									if(SA_ask_groupmember_user(COC_Tags[coc],&user_tag)!=ITK_ok)PrintErrorStack();
									if(SA_ask_user_person (user_tag,&person_tag)!=ITK_ok)PrintErrorStack();
									if(person_tag!=NULLTAG)
									{
										if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
										if(mailId != NULL)
										{
											if(tc_strcmp(mailId,"")!=0)
											{
												printf("\n%s mailId: %s",mailId);
												if(tc_strstr(eMailTo, mailId)==NULL){
													tc_strcat(eMailTo,",");
													tc_strcat(eMailTo,mailId);
												}
											}
										}
									}
								}
							}
						}

						tc_strcpy(envSub,"REJECTED:Deviated Interface rule: ");
						tc_strcat(envSub,t5_Design_Rule_ID);
						tc_strcat(envSub," - ");
						tc_strcat(envSub,item_id);
						tc_strcat(envSub,"/");
						tc_strcat(envSub,item_revision_id);

						tc_strcpy(envDesc,"Dear All, ");
						tc_strcat(envDesc,"\n\nDeviated Design Rule ID: ");
						tc_strcat(envDesc,t5_Design_Rule_ID);
						tc_strcat(envDesc,"\n\nInterface Rule Description: ");
						tc_strcat(envDesc,t5_Interface_Rule_Desc);
						tc_strcat(envDesc,"\n\nAggregate Group: ");
						tc_strcat(envDesc,t5_Aggregate_Group);
						tc_strcat(envDesc,"\n\nRemark: ");
						tc_strcat(envDesc,t5_Remark);
						tc_strcat(envDesc,"\n\nStatus: ");
						tc_strcat(envDesc,t5_Checklist_Implemented);
						tc_strcat(envDesc,"\n\n\n\nSubmodule Number: ");
						tc_strcat(envDesc,item_id);
						tc_strcat(envDesc,"\n\nSubmodule Revision: ");
						tc_strcat(envDesc,item_revision_id);
						tc_strcat(envDesc,"\n\nSubmodule Aggregate: ");
						tc_strcat(envDesc,aggregate);
						tc_strcat(envDesc,"\n\n\n\nDesign Engineer: ");
						tc_strcat(envDesc,owning_user);
						tc_strcat(envDesc,"\n\nAggregate COC: ");
						tc_strcat(envDesc,CocHeads);
						tc_strcat(envDesc,"\n\nCoC approval status: Rejected\n\n");

						printf("\n\nMAIL_initialize\n\n");
						sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
						printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
						system(buff);
					}
				}
			}

			if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo5",&info3)!=ITK_ok)   PrintErrorStack();
			printf("\n info3 is.:[%s]\n", info3);fflush(stdout);
			if (tc_strcmp(info3,"Shell")==0)
			{
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo6",&info1)!=ITK_ok)   PrintErrorStack();
				printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
	            char    *strg = NULL;
			    strg = malloc(1500);
				char *tempRevID = NULL;
				char *Shell_Path  = NULL;
				char command[1000];
				if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&Shell_Path)!=ITK_ok)PrintErrorStack();
				printf("\n Information 1 Value == [%s]", Shell_Path);fflush(stdout);
				tc_strcpy(strg,"");				
				tc_strcat(strg,stripBlanks(chklistdataNo));
				tc_strcat(strg," ");	
				STRNG_replace_str(chklistdatarev,";","_",&tempRevID);
				printf("\n After STRNG_replace_str tempRev ID %s \n",tempRevID);
				tc_strcat(strg,stripBlanks(tempRevID));
				sprintf(command,"%s %s %s",Shell_Path,strg,user_id);
				printf("\n Command to be run  == <%s>", command);fflush(stdout);
				system(command);
			}
		}
	}
	else
	{
		printf("\n IRCDeviationPostapprovalmail:Not Found Query ControlObjects \n");fflush(stdout);
	}
	return error_code;
}

EPM_decision_t IRCDeviationCOCDecisionCmnt( EPM_rule_message_t msg)
{
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	tag_t   *CntrlObjectTag      = NULLTAG;
	int      no_attach      =  0;
    char	*chklistdataNo			=  NULL;
	char	*DMLType		=  NULL;	
	char	*chklistdatarev		=  NULL;	
	char    *qry_entry[1]  = {"SYSCD"};
	char    *qry_values2[1]     =  {"IRCDeviationPostapprovalmail"};
	int     n_entry    = 1; 
	int     rsltCount      =  0; 
	char	*info1	= NULL;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char   *ObjTyp = NULL;
	char command[512];
	int error_code = ITK_ok;
	char* user_id =NULL;
	char* TaskResult = NULL;
	int cnt = 0;
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	tag_t	rootTask = NULLTAG;
	tag_t* signOffTags = NULLTAG;
	const char * prog_name ="IRCDeviationCOCDecisionCmnt";
	if(EPM_ask_root_task(msg.task,&rootTask)!=ITK_ok)PrintErrorStack();
	printf("\nRoot task found");fflush(stdout);	
	if(EPM_ask_attachments(msg.task, EPM_signoff_attachment,&cnt, &signOffTags)!=ITK_ok)PrintErrorStack();
	printf("\n No of Sign off Tags ===> %d\n",cnt);fflush(stdout);
	if(cnt>0)
	{
		tag_t signOffTag = NULLTAG;
		EPM_signoff_decision_t decsn = EPM_no_decision;
		char* comments = NULL;
		date_t decision_date = NULLDATE;
		signOffTag = signOffTags[0];
		if(EPM_ask_signoff_decision(signOffTag, &decsn, &comments, &decision_date)!=ITK_ok)PrintErrorStack();
		printf("\nAGG comments ==> %s\n",comments);fflush(stdout);
		if (decsn==EPM_approve_decision || decsn==EPM_reject_decision)
		{
			if(comments == NULL)
			{
				char* buff = NULL;
				ifail=T5_WorkFlowHandlerErr;
				buff = (char*)MEM_alloc(200*sizeof(char));
				sprintf(buff, "Sign off Comment is mandatory. Kindly enter comments before sign off");
				EMH_store_error_s1(EMH_severity_error,ifail,buff);
				decision = EPM_nogo;
				if(buff)MEM_free(buff);
				return decision; 						
			}
			else
			{
				if(tc_strcmp(comments,"")==0)
				{
					char* buff = NULL;
					ifail=T5_WorkFlowHandlerErr;
					buff = (char*)MEM_alloc(200*sizeof(char));
					sprintf(buff, "Sign off Comment is blank. Kindly enter comments before sign off");
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					decision = EPM_nogo;
					if(buff)MEM_free(buff);
					return decision; 						
				}
				else
				{
					if(EPM_ask_attachments(rootTask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
					printf("\n IRC:No of Attachements: [%d]", no_attach);fflush(stdout);

					if (no_attach > 0)
					{
						objTag = attachment[0];
						char* COCDecision = NULL;
						if (decsn==EPM_approve_decision)
						{
							tc_strdup("APPROVED",&COCDecision);
						}
						else
						{
							tc_strdup("REJECTED",&COCDecision);
						}

						if(AOM_ask_value_string(objTag,"item_id",&chklistdataNo)!=ITK_ok)PrintErrorStack();
						printf("\n chklistdata Number: [%s].", chklistdataNo);fflush(stdout);
						if(AOM_ask_value_string(objTag,"item_revision_id",&chklistdatarev)!=ITK_ok)PrintErrorStack();
						printf("\n chklistdata Rev: [%s].", chklistdatarev);fflush(stdout);

						if(TCTYPE_ask_object_type(objTag,&objTypTag));
						if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
						printf("\n IRReject: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
						if(QRY_find2("ControlObjects", &qryTag));
						if (qryTag)
						{
							printf("\n IRCDeviationPostapprovalmail:Found Query ControlObjects \n");fflush(stdout);
							if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
							printf(" \n IRCDeviationPostapprovalmail:rsltCount :%d:", rsltCount); fflush(stdout);
							if(rsltCount > 0)
							{
								if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo7",&info2)!=ITK_ok)   PrintErrorStack();
								printf("\n info2 is.:[%s]\n", info2);fflush(stdout);

								if (tc_strcmp(info2,"Handler")==0)
								{
									char  *envSub	  = NULL;
									char  *envDesc	  = NULL;
									char  *buff 	= NULL;
									char*	eMailCC			= NULL;
									char*	eMailTo			= NULL;
									char  *CocHeads	  = NULL;
									eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
									eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
									envSub = (char *) MEM_alloc( 250 * sizeof(char) );
									envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
									CocHeads = (char *) MEM_alloc( 500 * sizeof(char) );
									buff=(char *) MEM_alloc(2000 * sizeof(char *));
									//tc_strcpy(eMailTo,"at924736.ttl@tatamotors.com,sagard1.ttl@tatamotors.com");
									//tc_strcpy(eMailCC,"alokeshg.ttl@tatamotors.com");
									char* info9 = NULL;
									char* info10 = NULL;
									if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
									if (AOM_ask_value_string(CntrlObjectTag[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
									tc_strcpy(CocHeads,"");
									tc_strcpy(eMailCC,"");
									tc_strcpy(eMailTo,"");
									tc_strcpy(envSub,"");
									tc_strcpy(envDesc,"");
									tc_strcpy(buff,"");
									tc_strcpy(eMailTo,info9);
									tc_strcpy(eMailCC,info10);

									tag_t IRchklstreltyp = NULLTAG;
									tag_t ImaRefTag = NULLTAG;
									int IRcnt = 0;
									int DegnRevCnt = 0;
									tag_t* IRobjTags = NULLTAG;
									tag_t* DegnRevTags = NULLTAG;
									tag_t DsgnRevTag = NULLTAG;
									char* item_id = NULL;
									char* item_revision_id = NULL;
									char* aggregate = NULL;
									char* owning_user = NULL;
									char* group_display_name = NULL;
									char* cocName = NULL;
									char* mailId = NULL;
									char* OwnerMailId = NULL;
									char* t5_Design_Rule_ID = NULL;
									char* t5_Remark = NULL;
									char* t5_Aggregate_Group = NULL;
									char* t5_Interface_Rule_Desc = NULL;
									char* t5_Checklist_Implemented = NULL;
									int chldGrpCnt = 0;
									int g = 0;
									tag_t* chldGrpTags = NULLTAG;
									int No_COC = 0;
									int coc = 0;
									tag_t* COC_Tags = NULLTAG;
									tag_t user_tag = NULLTAG;
									tag_t person_tag = NULLTAG;
									tag_t owning_user_tag = NULLTAG;
									tag_t owningPerson = NULLTAG;
									tag_t group_tag = NULLTAG;
									tag_t role_tag = NULLTAG;
									if(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&IRchklstreltyp)) PrintErrorStack();
									if(GRM_list_primary_objects_only(objTag,IRchklstreltyp,&IRcnt,&IRobjTags)) PrintErrorStack();
									if (IRcnt > 0)
									{
										if(GRM_find_relation_type("IMAN_reference",&ImaRefTag)) PrintErrorStack();
										if(GRM_list_primary_objects_only(IRobjTags[0],ImaRefTag,&DegnRevCnt,&DegnRevTags)) PrintErrorStack();
										if (DegnRevCnt > 0)
										{
											DsgnRevTag = DegnRevTags[0];
											if (AOM_ask_value_string(DsgnRevTag,"item_id",&item_id)!=ITK_ok)   PrintErrorStack();
											if (AOM_ask_value_string(DsgnRevTag,"item_revision_id",&item_revision_id)!=ITK_ok)   PrintErrorStack();
											if(AOM_ask_value_string(DsgnRevTag,"t5_Aggregate",&aggregate)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(objTag,"t5_Design_Rule_ID",&t5_Design_Rule_ID)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(objTag,"t5_Remark",&t5_Remark)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(objTag,"t5_Aggregate_Group",&t5_Aggregate_Group)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(objTag,"t5_Interface_Rule_Desc",&t5_Interface_Rule_Desc)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(objTag,"t5_Checklist_Implemented",&t5_Checklist_Implemented)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(DsgnRevTag,"owning_user",&owning_user)!=ITK_ok)PrintErrorStack();

											if( AOM_ask_owner(DsgnRevTag,&owning_user_tag)!=ITK_ok) PrintErrorStack();
											if(owning_user_tag!=NULLTAG){
												if( SA_ask_user_person(owning_user_tag,&owningPerson)!=ITK_ok) PrintErrorStack();
												if(SA_ask_person_email_address(owningPerson,&OwnerMailId)!=ITK_ok) PrintErrorStack();
												if(OwnerMailId != NULL)
												{
													if (tc_strcmp(OwnerMailId,"")!=0)
													{
														printf("\nCreator Mail: %s\n",OwnerMailId);
														tc_strcat(eMailTo,",");
														tc_strcat(eMailTo,OwnerMailId);
													}
												}
											}

											if(SA_find_group("InterfaceRule",&group_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_role2("COC_Head",&role_tag)!=ITK_ok)PrintErrorStack();
											if(SA_ask_group_child_groups(group_tag,TRUE,&chldGrpCnt,&chldGrpTags)!=ITK_ok)PrintErrorStack();
											printf("\nChild Groups: %d",chldGrpCnt);
											for (g = 0; g < chldGrpCnt; ++g)
											{
												No_COC = 0;
												if(SA_ask_group_display_name(chldGrpTags[g],&group_display_name)!=ITK_ok)PrintErrorStack();
												printf("\ngroup_display_name: %s || aggregate: %s ",group_display_name,aggregate); fflush(stdout);

												if(tc_strstr(aggregate,"APPLICATIONS")!=NULL && tc_strstr(group_display_name,"APPLICATIONS")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"EXTERIOR")!=NULL && tc_strstr(group_display_name,"EXTERIOR")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"INTERIOR")!=NULL && tc_strstr(group_display_name,"INTERIOR")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"CHASSIS INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"CHASSIS_INTEGRATION_AGGREGATES")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"DRIVELINE INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"DRIVELINE_INTEGRATION_AGGREGATES")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"ENGINE INTEGRATION AGGREGATES")!=NULL && tc_strstr(group_display_name,"ENGINE_INTEGRATION_AGGREGATES")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"SUSPENSION")!=NULL && tc_strstr(group_display_name,"SUSPENSION")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"BRAKES & WHEELS")!=NULL && tc_strstr(group_display_name,"BRAKES_AND_WHEELS")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"POWER AND DISTRIBUTION")!=NULL && tc_strstr(group_display_name,"POWER_AND_DISTRIBUTION")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"ENGINE BASE ENGINEERING")!=NULL && tc_strstr(group_display_name,"ENGINE_BASE_ENGINEERING")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"TRANSMISSION")!=NULL && tc_strstr(group_display_name,"TRANSMISSION")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}
												else if(tc_strstr(aggregate,"POWERTRAIN")!=NULL && tc_strstr(group_display_name,"POWERTRAIN")!=NULL)
												{
													if(SA_find_groupmember_by_role(role_tag,chldGrpTags[g],&No_COC,&COC_Tags)!=ITK_ok)PrintErrorStack();
												}

												printf("\nNo_COC: %d",No_COC);
												if (No_COC > 0)
												{
													for (coc = 0; coc < No_COC; ++coc)
													{
														if(AOM_UIF_ask_value(COC_Tags[coc],"object_string",&cocName)!=ITK_ok)PrintErrorStack();
														printf("\ncocName: %d",cocName);
														tc_strcat(CocHeads,cocName);
														tc_strcat(CocHeads,",");

														if(SA_ask_groupmember_user(COC_Tags[coc],&user_tag)!=ITK_ok)PrintErrorStack();
														if(SA_ask_user_person (user_tag,&person_tag)!=ITK_ok)PrintErrorStack();
														if(person_tag!=NULLTAG)
														{
															if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
															if(mailId != NULL)
															{
																if(tc_strcmp(mailId,"")!=0)
																{
																	printf("\n%s mailId: %s",mailId);
																	if(tc_strstr(eMailTo, mailId)==NULL){
																		tc_strcat(eMailTo,",");
																		tc_strcat(eMailTo,mailId);
																	}
																}
															}
														}
													}
												}
											}

											tc_strcpy(envSub,COCDecision);
											tc_strcat(envSub,":Deviated Interface rule: ");
											tc_strcat(envSub,t5_Design_Rule_ID);
											tc_strcat(envSub," - ");
											tc_strcat(envSub,item_id);
											tc_strcat(envSub,"-");
											tc_strcat(envSub,item_revision_id);

											tc_strcpy(envDesc,"Dear All, ");
											tc_strcat(envDesc,"\nDeviated Design Rule ID: ");
											tc_strcat(envDesc,t5_Design_Rule_ID);
											tc_strcat(envDesc,"\nInterface Rule Description: ");
											tc_strcat(envDesc,t5_Interface_Rule_Desc);
											tc_strcat(envDesc,"\nAggregate Group: ");
											tc_strcat(envDesc,t5_Aggregate_Group);
											tc_strcat(envDesc,"\nRemark: ");
											tc_strcat(envDesc,t5_Remark);
											tc_strcat(envDesc,"\nStatus: ");
											tc_strcat(envDesc,t5_Checklist_Implemented);
											tc_strcat(envDesc,"\n\nSubmodule Number: ");
											tc_strcat(envDesc,item_id);
											tc_strcat(envDesc,"\nSubmodule Revision: ");
											tc_strcat(envDesc,item_revision_id);
											tc_strcat(envDesc,"\nSubmodule Aggregate: ");
											tc_strcat(envDesc,aggregate);
											tc_strcat(envDesc,"\n\nDesign Engineer: ");
											tc_strcat(envDesc,owning_user);
											tc_strcat(envDesc,"\nAggregate COC: ");
											tc_strcat(envDesc,CocHeads);
											tc_strcat(envDesc,"\nCoC approval status: ");
											tc_strcat(envDesc,COCDecision);
											tc_strcat(envDesc,"\nComments from CoC: ");
											tc_strcat(envDesc,comments);
											tc_strcat(envDesc,"\n\n");

											printf("\n\nMAIL_initialize\n\n");
											sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
											printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
											system(buff);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return decision;
}

extern int Interface_Rule_register_method(int *decision, va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;

	status = EPM_register_action_handler ("IRC_Assign_participant","IRC_Assign_participant",(EPM_action_handler_t)IRC_Assign_participant_Func);
	status = EPM_register_action_handler ("IRCDeviationPreapprovalmail","IRCDeviationPreapprovalmail",(EPM_action_handler_t)IRC_DeviationPreapprovalmail);
	status = EPM_register_action_handler ("IRCDeviationPostapprovalmail","IRCDeviationPostapprovalmail",(EPM_action_handler_t)IRC_DeviationPostapprovalmail);
	status = EPM_register_action_handler ("IRCDeviationCOCRejectmail","IRCDeviationCOCRejectmail",(EPM_action_handler_t)IRC_DeviationCOCRejectmail);

	status = EPM_register_rule_handler ("IRCDeviationCOCDecision","IRCDeviationCOCDecision",(EPM_rule_handler_t)IRCDeviationCOCDecisionCmnt);

	return status;
}

extern DLLAPI int tm_Interface_Rule_register_callbacks ()
{
	int ifail    = ITK_ok;
    ifail=CUSTOM_register_exit("tm_Interface_Rule","USER_init_module",(CUSTOM_EXIT_ftn_t)Interface_Rule_register_method);
    return ( ITK_ok );
}


