/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: IR_checklist.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** IR_checklist -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <sys/stat.h>

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
if(Debug)								\
{										\
	printf(#X);							\
}										\
fflush(NULL);							\
status=X; 								\
if (status != ITK_ok ) 					\
{										\
	int				index = 0;			\
	int				n_ifails = 0;		\
	const int*		severities = 0;		\
	const int*		ifails = 0;			\
	const char**	texts = NULL;		\
										\
	EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
	printf("\t%3d error(s)\n", n_ifails);							\
	for( index=0; index<n_ifails; index++)							\
	{																\
		printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
	}																\
	return status;													\
}																	\
else									\
{										\
	if(Debug)							\
	printf("\tSUCCESS\n");				\
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int IR(char*,char*,char*,char*,char*,char*,char*,char*,char*,char*);
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	char            *Folder_name                =NULL;
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	ifail = read_value_from_file(file);
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int		count	 				= 0;
	
	char	*item_id							= NULL;
	char	*IR_no					= NULL;
	char	*rev_id						= NULL;
	char	*Aggregates					= NULL;
	char	*agg_grp					= NULL;
	char	*module					= NULL;
	char	*submodule					= NULL;
	char	*applicable_modules					= NULL;
	char	*rule_desc					= NULL;
	char* irchecklist                           =NULL;
	char* irchecklistobj                        =NULL;
	char* File_path = NULL;
	char 	 temp[2000];
	char *ImanFile_Name=NULL;
	char *FullPath=NULL;
	IR_no=(char *) MEM_alloc(100);
	rev_id=(char *) MEM_alloc(100);
	rule_desc=(char *) MEM_alloc(100);
	applicable_modules	=(char *) MEM_alloc(100);
	agg_grp	=(char *) MEM_alloc(100);
	Aggregates	=(char *) MEM_alloc(100);
	module=(char *) MEM_alloc(1000);
	submodule=(char *) MEM_alloc(1000);
	ImanFile_Name=(char *) MEM_alloc(1000);
	FullPath=(char *) MEM_alloc(1000);
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 2000, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				IR_no = strtok(temp, "~");
				printf("\n IR_no:%s",IR_no);
				rev_id = strtok(NULL, "~");
				printf("\nrev_id:%s",rev_id);
				rule_desc = strtok(NULL, "~");
				printf("\nrule desc:%s",rule_desc);
				applicable_modules = strtok(NULL, "~");
				printf("\napplicable modules:%s",applicable_modules);
				agg_grp = strtok(NULL, "~");
				printf("\nagg grp:%s",agg_grp);
				Aggregates = strtok(NULL, "~");
				printf("\nAggregates:%s",Aggregates);
				module = strtok(NULL, "~");
				printf("\nmodule:%s",module);
				submodule = strtok(NULL, "~");
				printf("\nsubmodule:%s",submodule);
				ImanFile_Name = strtok(NULL,"~");
				printf("\nImanFile_Name:%s",ImanFile_Name);
				File_path = strtok(NULL,"~");
				printf("\nFile_path:%s",File_path);
		        //FullPath = strcpy(FullPath,"/user/cvprod/Akshay/IR/IR_Migration/");
		        FullPath = strcpy(FullPath,File_path);
				FullPath=strcat(FullPath,ImanFile_Name);
				printf("\nFull_Path:%s",FullPath);
				ifail = IR(IR_no,rev_id,rule_desc,applicable_modules,agg_grp,Aggregates,module,submodule,ImanFile_Name,FullPath);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}


/********************************************************************************************
    Function:       IR
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int IR(char* IR_no,char* rev_id,char* rule_desc,char* applicable_modules,char* agg_grp,char* Aggregates,char* module,char* submodule,char* ImanFile_Name,char* FullPath)
{
	int				i 							= 0;
	int				j 							= 0;
	int				count 						= 0;
	int				count_status				= 0;
	tag_t			module_tag			= NULLTAG;	
	tag_t			moduleRev_tag			= NULLTAG;
	tag_t           item_type_tag1           = NULLTAG;
	tag_t           item_create_input_tag1   = NULLTAG;
	tag_t            object1                = NULLTAG;
	tag_t            ChecklistRev            = NULLTAG;
    int                 n_items                = 0;
	int                n_items1                = 0;
	int                n_items2                = 0;
	tag_t               item_tag             = NULLTAG;
	tag_t                module_rev         = NULLTAG;
	char               *tempRev_ID	          =NULLTAG;
	tag_t                item_tag1           = NULLTAG;
	tag_t                IR_Rev         = NULLTAG;
    tag_t relation_type;
	tag_t relation = NULLTAG;
	char* irchecklist=	NULL;
	tag_t            tempChecklistRev            = NULLTAG;
    tag_t relation_type1;
	tag_t relation1 = NULLTAG;
	tag_t latest_rev_id         = NULLTAG;
	tag_t tool =NULLTAG;
	int nameRef_cnt =0;
	tag_t *namRefObject = NULL;
	int ref_count = 0;
	char **ref_list;
	tag_t filetag =  NULLTAG;
	IMF_file_t fileDescriptor;
	AE_reference_type_t tagRefType =  1;

	ITK_CALL(ITEM_find_item(IR_no,&item_tag1));
	printf("\niten find");
	if(item_tag1)
	{
		printf("\n IR Object is already Available.....updating\n"); fflush(stdout);
		ITK_CALL(ITEM_ask_latest_rev(item_tag1,&IR_Rev));
		ITK_CALL(AOM_refresh(IR_Rev,1));
		ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRAggregate",Aggregates));
		ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRAggrGrp",agg_grp));
		ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRModule",module));
		ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRSubModule",submodule));
		ITK_CALL(AOM_set_value_string(IR_Rev,"t5_ApplicableModules",applicable_modules));
		ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRRuleDesc",rule_desc));
		ITK_CALL(AOM_save_without_extensions(IR_Rev));
		ITK_CALL(AOM_refresh(IR_Rev,0));

		struct stat buffer;
		if (!stat(FullPath, &buffer))
		{
			int DsCnt=0;
			char* Dataset_name=NULL;
			tag_t datasettype=NULLTAG;
			tag_t Datasetobj4=NULLTAG;
			tag_t* datasetobj1=NULL;
			tag_t Datasetobj3=NULLTAG;
			tag_t dataset_rel_type2=NULLTAG;
			tag_t dataset_rel_type=NULLTAG;
			ifail = AE_find_datasettype2("PDF",&datasettype);
			ifail = AE_create_dataset_with_id(datasettype,IR_no,IR_no,IR_no,IR_no,&Datasetobj4);
			ifail = AE_set_dataset_format2(Datasetobj4, "BINARY_REF");
			ifail = AE_set_dataset_tool(Datasetobj4,tool);
			ifail = AE_ask_dataset_named_refs(Datasetobj4,&nameRef_cnt, &namRefObject);
			if (nameRef_cnt == 0)
			{
				printf("\nFullPath 2 : %s",FullPath);
				ifail = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
				ifail = IMF_import_file(FullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
				if (ifail == 41178)
				{
					ifail = IMF_import_file(FullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
				}
				if (ifail == ITK_ok)
				{
					printf("\n\t File Imported--->%d",ifail); fflush(stdout);
					ifail = AOM_save_with_extensions(filetag);
					printf("\n\t File saved--->%d",ifail); fflush(stdout);
					ifail = AE_add_dataset_named_ref2(Datasetobj4,ref_list[0],tagRefType,filetag);
					printf("\n\t AE_add_dataset_named_ref--->%d",ifail); fflush(stdout);
					AE_set_dataset_tool(Datasetobj4,tool);
					ifail = AOM_save_with_extensions(Datasetobj4);
					printf("\n\t AOM_save Dataset--->%d",ifail); fflush(stdout);

					ifail = GRM_find_relation_type("IMAN_reference", &dataset_rel_type);
			        ifail = GRM_list_secondary_objects_only(IR_Rev,dataset_rel_type,&DsCnt,&datasetobj1);
			        if (DsCnt > 0)
			        {
			        	Datasetobj3=datasetobj1[i];
						ifail = AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name);
				        if(tc_strcmp(Dataset_name,IR_no)==0)
				        {
				        	char *refname2 = NULL;
							tag_t *refobject2	= NULL;
							int result1 = 0;
							int z = 0;
							printf("\n\tNeed to delete");fflush(stdout);
							ITK_CALL(GRM_list_all_related_objects_only(Datasetobj3,&result1,&refobject2));
							printf("\nReleations Count : %d",result1); fflush(stdout);
							for (z = 0; z < result1; ++z)
							{
								ITK_CALL(AOM_ask_value_string(refobject2[z],"type_string",&refname2));
								printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
								ITK_CALL(GRM_delete_relation(refobject2[z]));
							}
							printf("\nAOM_delete Deleting Dataset"); fflush(stdout);
							ITK_CALL(AOM_refresh(Datasetobj3,0));
							ITK_CALL(AOM_delete(Datasetobj3));
				        }
			        }
			        ITK_CALL(AOM_refresh(IR_Rev,0));
			        ifail=GRM_create_relation(IR_Rev,Datasetobj4,dataset_rel_type,NULLTAG,&dataset_rel_type2);
                  	ifail=GRM_save_relation(dataset_rel_type2);
				}
			}
		}
		else
		{
			printf("\n\t File not exist for %s \n\n",FullPath);fflush(stdout);
		}
	}
	else
	{
		printf("\n IR object not found so creatiing check list object\n"); fflush(stdout);
		ITK_CALL(TCTYPE_find_type("T5_InterfaceRule","Seg0IntfSpec", &item_type_tag1));         
		ITK_CALL(TCTYPE_construct_create_input(item_type_tag1, &item_create_input_tag1));
		ITK_CALL(AOM_set_value_string(item_create_input_tag1,"item_id",IR_no));
		ITK_CALL(AOM_set_value_string(item_create_input_tag1,"object_name",IR_no));
		ITK_CALL(TCTYPE_create_object (item_create_input_tag1, &object1));
		if(object1)
		{
			ifail = AOM_save_with_extensions(object1);
			ifail = AOM_refresh(object1,0);
			ifail = AOM_unlock(object1);
			printf("\nadding properties.\n"); fflush(stdout);
			ITK_CALL(ITEM_ask_latest_rev(object1,&IR_Rev));
			ITK_CALL(AOM_refresh(IR_Rev,1));
			ITK_CALL(AOM_set_value_string(IR_Rev,"item_revision_id",rev_id));
			ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRAggregate",Aggregates));
			ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRAggrGrp",agg_grp));
			ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRModule",module));
			ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRSubModule",submodule));
			ITK_CALL(AOM_set_value_string(IR_Rev,"t5_ApplicableModules",applicable_modules));
			ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRRuleDesc",rule_desc));
			ITK_CALL(AOM_save_with_extensions(IR_Rev));
			ITK_CALL(AOM_refresh(IR_Rev,0));
		    printf("\n checklist is created\n"); fflush(stdout);
		}
		if(tc_strcmp("NA",ImanFile_Name)!=0)
		{
			printf("\nDataset available for this object...adding dataset");fflush(stdout);
			tag_t ItemQry     = NULLTAG;
			tag_t* ContainerTag   = NULL;
			tag_t dataset_rel_type=NULLTAG;
			tag_t dataset_rel_type2=NULLTAG;
			tag_t datasettype=NULLTAG;
			tag_t* datasetobj1=NULL;
			tag_t datasetobj2=NULLTAG;
			tag_t Datasetobj3=NULLTAG;
			tag_t Datasetobj4=NULLTAG;
			tag_t DVPrelation=NULLTAG;
			tag_t revtag=NULLTAG;
			tag_t* Named_ref=NULL;
			tag_t Named_ref_obj=NULLTAG;
			char* class =NULL;
			char* NR_Filename=NULL;
			char* Container_RevSeq=NULL;
			char* Dataset_name=NULL;
			char* Dataset_RevSeq=NULL;
			int ConCount=0;
			int Entry_count=2;
			int i=0;
			int NR_count=0;
			int NRflag=0;
			int DsCnt=0;
			class=(char *) MEM_alloc(100);
			ifail = AOM_ask_value_string(IR_Rev,"object_name",&class);
			ifail=GRM_find_relation_type("IMAN_reference", &dataset_rel_type);
	        ifail=GRM_list_secondary_objects_only(IR_Rev,dataset_rel_type,&DsCnt,&datasetobj1);
			if(DsCnt>0)
			{
			  	for( i=0; i<DsCnt; i++)
	            {
					Datasetobj3=datasetobj1[i];
					ifail = AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name);
			        if(tc_strcmp(Dataset_name,IR_no)==0)
			        {
			            printf("\nDataset found checking for Named ref file");fflush(stdout);
			            ifail=AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref);
			            if(NR_count>0)
			            {
			                for( i=0; i<NR_count; i++)
	                        {
			            	    Named_ref_obj=Named_ref[i];
			            	    ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
			            	    if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
			            	    { 
			            	    	printf("\nNamed refrenced file is alredy exists in dataset attached to container");fflush(stdout);
			            	    	NRflag=1;
			            	    }
			                }
			            }
			            if(NRflag==0||NR_count==0)
			           	{
		                    printf("\nAdding Named refrenced file in existing dataset attached to container");fflush(stdout);
		            		ifail=AOM_refresh(Datasetobj3,1);
		                    ifail=AE_import_named_ref(Datasetobj3,"PDF_Reference",FullPath,NULL,SS_BINARY);
		                    ifail=AOM_save_with_extensions(Datasetobj3);
		                    ifail=AOM_refresh(Datasetobj3,0);
			            		
			            }	
			        }
					else 
				    {
		               printf("\nDataset not matched with DVP creating both dataset and Named ref file");fflush(stdout);
			           ifail= AE_find_datasettype2("PDF",&datasettype);
			           ifail=AE_create_dataset_with_id(datasettype,IR_no,IR_no,IR_no,IR_no,&Datasetobj4);
			           ifail = AE_set_dataset_format2(Datasetobj4, "BINARY_REF");
					   ifail = AE_set_dataset_tool(Datasetobj4,tool);
					   ifail = AE_ask_dataset_named_refs(Datasetobj4,&nameRef_cnt, &namRefObject);
						if (nameRef_cnt == 0)
						{
							printf("\nFullPath 1 : %s",FullPath);
							ifail = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
							ifail = IMF_import_file(FullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
							if (ifail == 41178)
							{
								ifail = IMF_import_file(FullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
							}
							printf("\n\t File Imported--->%d",ifail); fflush(stdout);
							ifail = AOM_save_with_extensions(filetag);
							//if (IMF_set_original_file_name2(filetag,jtDataSetActNm)!=ITK_ok);
							//ifail = AOM_save_with_extensions(filetag);
							printf("\n\t File saved--->%d",ifail); fflush(stdout);
							ifail = AE_add_dataset_named_ref2(Datasetobj4,ref_list[0],tagRefType,filetag);
							printf("\n\t AE_add_dataset_named_ref--->%d",ifail); fflush(stdout);
							AE_set_dataset_tool(Datasetobj4,tool);
							ifail = AOM_save_with_extensions(Datasetobj4);
							printf("\n\t AOM_save Dataset--->%d",ifail); fflush(stdout);
						}


		               /*ifail=AOM_save_with_extensions(Datasetobj4);
			           ifail=AE_find_dataset2(IR_no,&datasetobj2);
		               ifail=AOM_refresh(datasetobj2,1);
		               ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		               ifail=AOM_save_with_extensions(datasetobj2);
		               ifail=AOM_refresh(datasetobj2,0);*/
			           ifail=GRM_create_relation(IR_Rev,Datasetobj4,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	                   ifail=GRM_save_relation(dataset_rel_type2);
				    }	
				}
	        }
			else
			{
				ifail=AE_find_dataset2(IR_no,&datasetobj2);
				if (datasetobj2)
				{
			        printf("\nDataset found. Creating relation with container");fflush(stdout);
			        ifail=GRM_create_relation(IR_Rev,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
			        ifail=GRM_save_relation(dataset_rel_type2);      
					ifail=AE_ask_dataset_named_refs(datasetobj2,&NR_count,&Named_ref);
					if(NR_count>0)
					{
						for( i=0; i<NR_count; i++)
			            {
							Named_ref_obj=Named_ref[i];
							ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
							if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
							{ 
								printf("\nNamed refrenced file is alredy exists in dataset");fflush(stdout);
								NRflag=1;
							}
					   	}
						
					}
			   		else if(NRflag==0||NR_count==0)
					{
				        printf("\nAdding Named refrenced file in existing dataset");fflush(stdout);
						ifail=AOM_refresh(datasetobj2,1);
				        ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
				        ifail=AOM_save_with_extensions(datasetobj2);
				        ifail=AOM_refresh(datasetobj2,0);
					}
			  	}
			  	else 
				{
			       printf("\nDataset not found creating both dataset and Named ref file");fflush(stdout);
				   /*ifail= AE_find_datasettype2("PDF",&datasettype);
				   ifail=AE_create_dataset_with_id(datasettype,IR_no,IR_no,IR_no,IR_no,&Datasetobj4);
			       ifail=AOM_save_with_extensions(Datasetobj4);
				   ifail=AE_find_dataset2(IR_no,&datasetobj2);
			       ifail=AOM_refresh(datasetobj2,1);
			       ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
			       ifail=AOM_save_with_extensions(datasetobj2);
			       ifail=AOM_refresh(datasetobj2,0);
				   ifail=GRM_create_relation(IR_Rev,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
		           ifail=GRM_save_relation(dataset_rel_type2);      
			       printf("\nDataset is attached to IR");fflush(stdout);*/

					ifail= AE_find_datasettype2("PDF",&datasettype);
					ifail=AE_create_dataset_with_id(datasettype,IR_no,IR_no,IR_no,IR_no,&Datasetobj4);
					ifail = AE_set_dataset_format2(Datasetobj4, "BINARY_REF");
					ifail = AE_set_dataset_tool(Datasetobj4,tool);
					ifail = AE_ask_dataset_named_refs(Datasetobj4,&nameRef_cnt, &namRefObject);
					if (nameRef_cnt == 0)
					{
						printf("\nFullPath 2 : %s",FullPath);
						ifail = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
						ifail = IMF_import_file(FullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
						if (ifail == 41178)
						{
							ifail = IMF_import_file(FullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
						}
						printf("\n\t File Imported--->%d",ifail); fflush(stdout);
						ifail = AOM_save_with_extensions(filetag);
						//if (IMF_set_original_file_name2(filetag,jtDataSetActNm)!=ITK_ok);
						//ifail = AOM_save_with_extensions(filetag);
						printf("\n\t File saved--->%d",ifail); fflush(stdout);
						ifail = AE_add_dataset_named_ref2(Datasetobj4,ref_list[0],tagRefType,filetag);
						printf("\n\t AE_add_dataset_named_ref--->%d",ifail); fflush(stdout);
						AE_set_dataset_tool(Datasetobj4,tool);
						ifail = AOM_save_with_extensions(Datasetobj4);
						printf("\n\t AOM_save Dataset--->%d",ifail); fflush(stdout);
					}


	               /*ifail=AOM_save_with_extensions(Datasetobj4);
		           ifail=AE_find_dataset2(IR_no,&datasetobj2);
	               ifail=AOM_refresh(datasetobj2,1);
	               ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
	               ifail=AOM_save_with_extensions(datasetobj2);
	               ifail=AOM_refresh(datasetobj2,0);*/
		           ifail=GRM_create_relation(IR_Rev,Datasetobj4,dataset_rel_type,NULLTAG,&dataset_rel_type2);
                   ifail=GRM_save_relation(dataset_rel_type2);
				}
			}
		}
		else
		{
			printf("\nDataset not available for this object");fflush(stdout);
		}
	}
	return 0;
}

