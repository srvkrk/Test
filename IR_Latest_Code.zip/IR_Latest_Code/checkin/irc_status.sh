
echo "${1}_IR_STS.txt"
cd /user/infodba/Alokesh/IR/checkin/
./IR_checklist -u=loader -pf=/user/infodba/Alokesh/pwfFile/loaderpasswdFile.pwf -g=dba -file="${1}_IR_STS.txt"

