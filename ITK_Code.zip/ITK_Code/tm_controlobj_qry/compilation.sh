./compile tm_controlobj_qry.c
./linkitk -o tm_controlobj_qry tm_controlobj_qry.o
chmod 777 tm_controlobj_qry*
