./compile tm_rel_correction.c
./linkitk -o tm_rel_correction tm_rel_correction.o
chmod 777 tm_rel_correction*
