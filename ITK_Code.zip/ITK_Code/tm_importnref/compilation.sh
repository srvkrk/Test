./compile tm_importnref.c
./linkitk -o tm_importnref tm_importnref.o
chmod 777 tm_importnref*
