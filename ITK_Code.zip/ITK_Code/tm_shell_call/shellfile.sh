echo "In Shell Argument Print Started...."

echo "User ID: "$1

echo "Password: "$2

echo "Group: "$3

echo "In Shell Argument Print Ended...."
