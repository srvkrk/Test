#define ITK_err 919002
#define TE_MAXLINELEN  128
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>

#define ITK_errStore (EMH_USER_error_base + 3)

//extern DLLAPI int checkin_register_method(int *decision, va_list args);
//extern DLLAPI int t5_LOV_register_method(int *decision);

int myAskModALOVValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVValuesMethodP( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVKeyWordValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVStartPartValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int  create_proto_method(METHOD_message_t *msg, va_list args);
//int  create_proto_method1(METHOD_message_t *msg, va_list args);

extern DLLAPI int checkin_method_1(METHOD_message_t *m, va_list args);

extern int checkin_register_method(int *decision, va_list args)
{
	METHOD_id_t  method;
	METHOD_id_t  methoddum1 ;
	METHOD_id_t  methoddum ;
	int	ifail = 0;
	*decision = ALL_CUSTOMIZATIONS;


	if ( METHOD_find_method(RES_Type, RES_checkin_msg, &method) !=ITK_ok);

	//  if ( METHOD_find_method("T5_DummyPartRevision", ITEM_create_msg, &methoddum) !=ITK_ok);
	// if ( METHOD_find_method("T5_DummyPartRevision", IMAN_save_msg, &methoddum1) !=ITK_ok);

	// if( METHOD_add_action(methoddum1, METHOD_pre_action_type, (METHOD_function_t) create_proto_method, NULL)!=ITK_ok);
	//if( METHOD_add_action(methoddum1, METHOD_pre_action_type, (METHOD_function_t) create_proto_method1, NULL)!=ITK_ok);


    if (method.id != NULLTAG)
    {
        if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) checkin_method_1, NULL)!=ITK_ok);

		printf("\nTCDCRegistered as Pre-Action for check-in - PRO-eee changes print \n");fflush(stdout);
    }
     else
        printf("TCDCMethod not found for checkin \n");fflush(stdout);


	if( ifail == ITK_ok )
    {
        printf("\nTCDCBefore Project Codecm \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_ProjCodeLOVType",
            LOV_ask_values_msg,
            &myAskLOVValuesMethodP,  0,
            &method);
    printf("\nTCDCAfter Project Codecm \n");fflush(stdout);
	}
    
	if( ifail == ITK_ok )
    {
        ifail = METHOD_register_method( "T5_KeyWordLOVType",
            LOV_ask_values_msg,
            &myAskLOVKeyWordValuesMethod,  0,
            &method);
    }

	if( ifail == ITK_ok )
    {
        printf("\nTCDCBefore Project Code \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_MatlClsLOVType",
            LOV_ask_values_msg,
            &myAskLOVValuesMethod,  0,
            &method);
			printf("\nTCDCAfter mat lov Code \n");fflush(stdout);
	}

	if( ifail == ITK_ok )
    {
		 printf("\ninside T5_StartPartLOVType \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_StartPartLOVType", LOV_ask_values_msg, &myAskLOVStartPartValuesMethod, 0, &method);
	}

    printf("\nTCDCProjectcode T5_StartPartLOVType \n");fflush(stdout);
	/*************************************************************************
      To fetch Keyword Description from classification in LOV
    *************************************************************************/
	
	if( ifail == ITK_ok )
    {
		printf("\ninside keyword lov testing \n");fflush(stdout);
        ifail = METHOD_register_method( "T5_KeyWordClassiLOVType",
            LOV_ask_values_msg,
            &t5_LOVKeyWordDescValuesMethod,  0,
            &method);
    }
	if( ifail == ITK_ok )
    {
        printf("\nSTART Module Address LOVType............................\n");fflush(stdout);		
		ifail = METHOD_register_method( "T5_CMModAddrLOVType", LOV_ask_values_msg, &myAskModALOVValuesMethod,  0, &method);
		printf("\nEND Module Address LOVType............................\n");fflush(stdout);
	}else
	{
		printf("\nModule Address T5_CMModAddrLOVType \n");fflush(stdout);
	}	
   
    return ifail;
}


DLLAPI int tel_user_init_register_callbacks ()
{
	int		       ifail=0;
	printf("\n\nTCDCcheckin_register_callback for PRO-eeee changed cmitest testing_04.june.2015\n\n");fflush(stdout);

	/*   exit(EXIT_SUCCESS);*/
	if(CUSTOM_register_exit ( "tel_user_init", "USER_init_module", (CUSTOM_EXIT_ftn_t)  checkin_register_method) !=ITK_ok);


	//    ifail=CUSTOM_register_exit ( "tel_user_init", "USER_init_module", (CUSTOM_EXIT_ftn_t)  t5_LOV_register_method);
	//    printf("\n - after calling t5_LOV_register_callbacks");

	return ( ITK_ok );


}

extern DLLAPI int  create_proto_method(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;

	tag_t objTag = va_arg(args, tag_t);
	tag_t  objTypeTagDi =NULLTAG;

	//tag_t*      new_item;
	//tag_t new_item = NULLTAG;
	char   *Item_id=NULL;
	char   *parttyp=NULL;
	char   *modtyp=NULL;
	char   *dumy_Item_ID_str=NULL;
	char   *Item_ID_str=NULL;
	char   *projectcode=NULL;
	char   *desgngrp=NULL;
	WSO_description_t        desc;
	tag_t  sequence_id_c;
	char   type_name2[TCTYPE_name_size_c+1];

	//new_item = va_arg(args, tag_t);


	//logical flag = va_arg(args, logical);


	//EPM_decision_t decision=EPM_go;

	printf("\nTCDCI am in create_proto_method function \n");fflush(stdout);

	if( AOM_ask_value_string(objTag,"item_id",&Item_id)!=ITK_ok);

	printf("\nTCDCI itemid %s\n",Item_id);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTagDi));
	if(TCTYPE_ask_name(objTypeTagDi,type_name2));
	printf("\nTCDCtype_name2:     %s\n", type_name2);

	if (WSOM_describe(objTag, &desc) !=ITK_ok)   ;
	//if (AOM_ask_value_int(object,"sequence_id",&sequence_id_c)!=ITK_ok)   PrintErrorStack();

	printf("TCDCObject Name:     %s\n", desc.object_name);
	printf("TCDCObject Type:     %s\n", desc.object_type);
	printf("TCDCRevision ID:     %s\n", desc.revision_id);

	//  if( AOM_ask_value_string(objTag,"t5_PartType",&parttyp)==ITK_ok);
	//  if( AOM_ask_value_string(objTag,"t5_Typofmod",&modtyp)==ITK_ok);

	printf("\nTCDCI am parttype %s \n",parttyp);fflush(stdout);

	// printf("\n I am in create_proto_method function \n");fflush(stdout);
//	    dumy_Item_ID_str=MEM_string_copy(Item_id) ;
//		projectcode=subString(dumy_Item_ID_str,0,4);
//		desgngrp=subString(dumy_Item_ID_str,4,2);
//
//		if(strcmp(desgngrp,"01")==0  && strcmp(modtyp,"01-Interior M0")==0 )
//					{
//					 EMH_store_error_s1(EMH_severity_error,ITK_errStore,"if sample error");
//					return ITK_errStore;
//					}



}


