#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <tccore/project.h>
#include <sa/groupmember.h>

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

/****************************************************************************
*   Function name			: Assign_Dynamic_party_Func
*   Description				: To set dynamic participant for dml and task in workflow.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		22/01/2018			Mohan Tayade	1.30: Set dynamic participants for dml and task
*
****************************************************************************/
int Assign_Dynamic_party_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	char	*groupName		= NULL;
	char	*DsgGrp			= NULL;
	char	*Task_name		= NULL;
	
	//BOM Analyst
	int     DsgGrup = 0;
	int     i = 0;
	int     No_BomAna = 0;
	tag_t   BomAna_Rev			= NULLTAG;
	tag_t   BAGrp_tag			= NULLTAG;
	tag_t   BomAnalyst_tag		= NULLTAG;
	tag_t	BomAna_Patri_Type	= NULLTAG;
	tag_t*  BomAna				= NULLTAG;
	tag_t	BomAna_Party		= NULLTAG;
	const char*   BomAnalyst_role = "BomAnalyst";
	/*//VI Reviewer
	int     iii = 0;
	int     No_VIAna = 0;
	tag_t   VIAna_Rev			= NULLTAG;
	tag_t   VIGrp_tag			= NULLTAG;
	tag_t   VIAnalyst_tag		= NULLTAG;
	tag_t	VIAna_Patri_Type	= NULLTAG;
	tag_t*  VIAna				= NULLTAG;
	tag_t	VIAna_Party		= NULLTAG;
	const char*   VIAnalyst_role = "VI_Reviewer";*/

	/*//CE Reviewer
	int     ik = 0;
	int     No_CEAna = 0;
	tag_t   CEAna_Rev			= NULLTAG;
	tag_t   CEGrp_tag			= NULLTAG;
	tag_t   CEAnalyst_tag		= NULLTAG;
	tag_t	CEAna_Patri_Type	= NULLTAG;
	tag_t*  CEAna				= NULLTAG;
	tag_t	CEAna_Party		= NULLTAG;
	const char*   CEAnalyst_role = "CE_Reviewer";*/

	//Peer_reviewer
	int     ii = 0;
	int     No_Peer = 0;
	tag_t   Peer_Rev			= NULLTAG;
	tag_t   PeerGrp_tag			= NULLTAG;
	tag_t   Peer_tag		= NULLTAG;
	tag_t	Peer_Patri_Type	= NULLTAG;
	tag_t*  Peer_t			= NULLTAG;
	tag_t	Peer_Party			= NULLTAG;
	const char*   Brake_Peer_role = "CoC_Brakes_Controls_Peer_PVBU";
	const char*   BIW_Peer_role = "CoC_CAB_BIW_Peer_PVBU";
	const char*   Door_Peer_role = "CoC_CAB_Door_Peer_PVBU";
	const char*   ExtTrims_Peer_role = "CoC_CAB_Ext_Trims_Peer_PVBU";
	const char*   Fit_Peer_role = "CoC_CAB_Int_Fittings_Peer_PVBU";
	const char*   IntTrims_Peer_role = "CoC_CAB_Int_Trims_Peer_PVBU";
	const char*   Mascots_Peer_role = "CoC_CAB_Mascots_Peer_PVBU";
	const char*   Seat_Peer_role = "CoC_CAB_Seats_Peer_PVBU";
	const char*   EE_Peer_role = "CoC_E&E_Peer_PVBU";
	const char*   Exhaust_Peer_role = "CoC_Exhaust_Peer_PVBU";
	const char*   Frame_Peer_role = "CoC_Frames_Peer_PVBU";
	const char*   Fuel_Peer_role = "CoC_Fuel_System_Peer_PVBU";
	const char*   HVAC_Peer_role = "CoC_HVAC_Peer_PVBU";
	const char*   Mounts_Peer_role = "CoC_Mounts_Peer_PVBU";
	const char*   Restrn_Peer_role = "CoC_Restraints_Peer_PVBU";
	const char*   Steering_Peer_role = "CoC_Steering_Peer_PVBU";
	const char*   Suspension_Peer_role = "CoC_Suspension_Peer_PVBU";
	const char*   Tools_Peer_role = "CoC_Tools_Acessories_Peer_PVBU";

	//DMU_reviewer
	int     im = 0;
	int     No_DMU = 0;
	tag_t   DMUGrp_tag			= NULLTAG;
	tag_t   DMU_Rev			= NULLTAG;
	tag_t   DMU_tag		= NULLTAG;
	tag_t	DMU_Patri_Type	= NULLTAG;
	tag_t*  DMU_t			= NULLTAG;
	tag_t	DMU_Party			= NULLTAG;
	const char*   Brake_DMU_role = "CoC_Brakes_Controls_DMU_PVBU";
	const char*   BIW_DMU_role = "CoC_CAB_BIW_DMU_PVBU";
	const char*   Door_DMU_role = "CoC_CAB_Door_DMU_PVBU";
	const char*   ExtTrims_DMU_role = "CoC_CAB_Ext_Trims_DMU_PVBU";
	const char*   Fit_DMU_role = "CoC_CAB_Int_Fittings_DMU_PVBU";
	const char*   IntTrims_DMU_role = "CoC_CAB_Int_Trims_DMU_PVBU";
	const char*   Mascots_DMU_role = "CoC_CAB_Mascots_DMU_PVBU";
	const char*   Seat_DMU_role = "CoC_CAB_Seats_DMU_PVBU";
	const char*   EE_DMU_role = "CoC_E&E_DMU_PVBU";
	const char*   Exhaust_DMU_role = "CoC_Exhaust_DMU_PVBU";
	const char*   Frame_DMU_role = "CoC_Frames_DMU_PVBU";
	const char*   Fuel_DMU_role = "CoC_Fuel_System_DMU_PVBU";
	const char*   HVAC_DMU_role = "CoC_HVAC_DMU_PVBU";
	const char*   Mounts_DMU_role = "CoC_Mounts_DMU_PVBU";
	const char*   Restrn_DMU_role = "CoC_Restraints_DMU_PVBU";
	const char*   Steering_DMU_role = "CoC_Steering_DMU_PVBU";
	const char*   Suspension_DMU_role = "CoC_Suspension_DMU_PVBU";
	const char*   Tools_DMU_role = "CoC_Tools_Acessories_DMU_PVBU";
	
	//Platform Reviewer (DML)
	int     pp = 0;
	int     No_PPAna = 0;
	tag_t   PPAna_Rev			= NULLTAG;
	tag_t   PPGrp_tag			= NULLTAG;
	tag_t   PPAnalyst_tag		= NULLTAG;
	tag_t	PPAna_Patri_Type	= NULLTAG;
	tag_t*  PPAna				= NULLTAG;
	tag_t	PPAna_Party		= NULLTAG;
	const char*   Def_PPAna_role = "Def_PPAnalyst";
	const char*   UV_PPAna_role = "UV_PPAnalyst";
	const char*   X0_PPAna_role = "X0_PPAnalyst";
	const char*   X1_PPAna_role = "X1_PPAnalyst";
	const char*   X2_PPAna_role = "X2_PPAnalyst";
	const char*   X3_PPAna_role = "X3_PPAnalyst";
	const char*   X4_PPAna_role = "X4_PPAnalyst";

	/*//SVR COC Reviewer (Task)
	//BIW_COC_Reviewer
	int     b = 0;
	int     No_SVRcoc = 0;
	tag_t   SVRcocGrp_tag	= NULLTAG;
	tag_t   SVRcoc_tag		= NULLTAG;
	tag_t	SVRcoc_Patri_Type	= NULLTAG;
	tag_t*  SVRcoc_t			= NULLTAG;
	tag_t	SVRcoc_Party		= NULLTAG;
	//Trim_SVRCoC_role
	int     tr = 0;
	int     No_SVRt = 0;
	tag_t   SVRtGrp_tag	= NULLTAG;
	tag_t   SVRt_tag		= NULLTAG;
	tag_t	SVRt_Patri_Type	= NULLTAG;
	tag_t*  SVRt_t			= NULLTAG;
	tag_t	SVRt_Party		= NULLTAG;
	//CH_SVRCoC_role
	int     c = 0;
	int     No_SVRc = 0;
	tag_t   SVRcGrp_tag	= NULLTAG;
	tag_t   SVRc_tag		= NULLTAG;
	tag_t	SVRc_Patri_Type	= NULLTAG;
	tag_t*  SVRc_t			= NULLTAG;
	tag_t	SVRc_Party		= NULLTAG;
	//EE_SVRCoC_role
	int     e = 0;
	int     No_SVRe = 0;
	tag_t   SVReGrp_tag	= NULLTAG;
	tag_t   SVRe_tag		= NULLTAG;
	tag_t	SVRe_Patri_Type	= NULLTAG;
	tag_t*  SVRe_t			= NULLTAG;
	tag_t	SVRe_Party		= NULLTAG;
	//PT_SVRCoC_role
	int     p = 0;
	int     No_SVRp = 0;
	tag_t   SVRpGrp_tag	= NULLTAG;
	tag_t   SVRp_tag		= NULLTAG;
	tag_t	SVRp_Patri_Type	= NULLTAG;
	tag_t*  SVRp_t			= NULLTAG;
	tag_t	SVRp_Party			= NULLTAG;
	const char*   BIW_SVRCoC_role = "BIW_COC_Reviewer";
	const char*   Trim_SVRCoC_role = "Trim_COC_Reviewer";
	const char*   CH_SVRCoC_role = "Chassis_COC_Reviewer";
	const char*   EE_SVRCoC_role = "EE_COC_Reviewer";
	const char*   PT_SVRCoC_role = "Powertrain_COC_Reviewer";*/

	// Participants remove.
	int jk = 0;
	int jkk = 0;
	int jtsk = 0;
	int CRBcount = 0;
	int CRBcunt = 0;
	char	*TskReviewr		= NULL;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm		= NULL;
	char 	*ProjectID		= NULL;
	char	*DMLReviewr		= NULL;
	tag_t Tsk_CRB_rel_type = NULLTAG;
	tag_t dml_CRB_rel_type = NULLTAG;
	tag_t* TskCRB = NULLTAG;
	tag_t* DmlCRB = NULLTAG;
	tag_t	TskCRBTag		= NULLTAG;
	tag_t	DmlCRBTag		= NULLTAG;
	tag_t	ObjTypDmlCRB	= NULLTAG;
	tag_t	ObjTypTskCRB	= NULLTAG;
	tag_t	TskRev_tg		= NULLTAG;
	char   type_name7[TCTYPE_name_size_c+1];
	char   type_name8[TCTYPE_name_size_c+1];
	logical is_Tskletst;

	//Task variables
	int     t		=  0;
	int     Tskcout		=  0;
	char	*Tsk_class		= NULL;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	DmlTask_tag		= NULLTAG;
	logical is_Tsklatst;
	int error_code = ITK_ok;

	printf("\n MT: Dynamic particiant assignment start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n MT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
	printf("\n MT:DML Number: [%s] DMLType: [%s]", DMLNo,DMLType);fflush(stdout);
	//t5_rlstype

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name(objTypTag,ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group");
	/*tc_strcat(groupName,".");
	tc_strcat(groupName,PrjName);
	tc_strcat(groupName,".");
	tc_strcat(groupName,"Assign_Dynamic_partyLKO");*/
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

	if(strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		if(AOM_ask_value_string(attachment[0],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
		printf("\n MT: ProjectID : %s\n",ProjectID);   fflush(stdout);
		if(PROJ_find(ProjectID,&Project_t)!=ITK_ok)PrintErrorStack();
		if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
		if(AOM_ask_value_string(Project_t,"object_desc",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
		//if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
		printf("\n MT: ProjDesc : %s Proj_PltFrm :[%s]\n",ProjDesc,Proj_PltFrm);   fflush(stdout);

		//Work for remove DML participants
		printf("\n MT: Work for remove DML participants \n"); fflush(stdout);
		//if(FUN!=ITK_ok)PrintErrorStack();
		if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
		if (dml_CRB_rel_type!=NULLTAG)
		{
			printf("\n MT:inside DML HasParticipant remove.. \n");fflush(stdout);
			if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
			printf("\n MT: DmlCRB count: %d",CRBcount);fflush(stdout);	
			for (jk=0;jk<CRBcount ;jk++ )
			{	
				printf("\n MT:jk: %d.\n",jk);fflush(stdout);
				DmlCRBTag = DmlCRB[jk];
				if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
				if(TCTYPE_ask_name(ObjTypDmlCRB,type_name7));
				printf("\n MT:DML: type_name7 :: %s\n", type_name7);fflush(stdout);
				if(strcmp(DMLType,"SVR")!=0)
				{
					if (strcmp(type_name7,"T5_BOMAnalyst")==0)
					{
						printf("\n MT: Removing BOM reviewer. \n"); fflush(stdout);
						if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
						printf("\n MT: DML Reviewer: [%s] ",DMLReviewr);fflush(stdout);
						AOM_lock(objTag);
						if(ITEM_rev_remove_participant (objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
						AOM_save(objTag);
						AOM_unlock(objTag);
					}
					if (strcmp(type_name7,"T5_PPReviewer")==0)
					{
						printf("\n MT: Removing PP reviewer. \n"); fflush(stdout);
						if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
						printf("\n MT: DML Reviewer: [%s] ",DMLReviewr);fflush(stdout);
						AOM_lock(objTag);
						if(ITEM_rev_remove_participant (objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
						AOM_save(objTag);
						AOM_unlock(objTag);
					}
				}
				else
				{
					/*if (strcmp(type_name7,"T5_VIReviewer")==0)
					{
						if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
						printf("\n MT: DML Reviewer: [%s] ",DMLReviewr);fflush(stdout);
						AOM_lock(objTag);
						if(ITEM_rev_remove_participant (objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
						AOM_save(objTag);
						AOM_unlock(objTag);
					}*/
				}
			}
		}
		//if(FUN!=ITK_ok)PrintErrorStack();
		printf("\n MT: Inside ChangeRequestRevision. \n"); fflush(stdout);
		if(strcmp(DMLType,"SVR")!=0)
		{
			//BOM Analyst
			printf("\n MT: Setting BOM Analyst...");fflush(stdout);
			if(SA_find_group(groupName, &BAGrp_tag)!=ITK_ok)PrintErrorStack();
			if(SA_find_role2(BomAnalyst_role,&BomAnalyst_tag)!=ITK_ok)PrintErrorStack();
			if(SA_find_groupmember_by_role(BomAnalyst_tag,BAGrp_tag,&No_BomAna,&BomAna)!=ITK_ok)PrintErrorStack();
			printf("\n MT:No_BomAna  ---> [%d]",No_BomAna);  fflush(stdout);
			if(No_BomAna>0)
			{
				for(i=0;i<No_BomAna;i++)
				{	
					printf("\n MT:BOM Analyst no: [%d]",i);fflush(stdout);
					if(EPM_get_participanttype ("T5_BOMAnalyst",&BomAna_Patri_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(BomAna[i],BomAna_Patri_Type,&BomAna_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(ITEM_rev_add_participant(objTag,BomAna_Party)!=ITK_ok)PrintErrorStack();	
					AOM_save(objTag);
					AOM_unlock(objTag);
				}
			}
			AOM_refresh ( objTag,TRUE);
			MEM_free(BomAna);

			//Platform Reviewer
			printf("\n MT: Setting BOM Analyst...");fflush(stdout);
			if(SA_find_group(groupName, &PPGrp_tag)!=ITK_ok)PrintErrorStack();
			if(tc_strcmp(Proj_PltFrm,"Def")==0)
			{
				printf("\n MT: Setting Def_PPAna_role.. \n"); fflush(stdout);
				if(SA_find_role2(Def_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
			}
			else if(tc_strcmp(Proj_PltFrm,"UV")==0)
			{
				printf("\n MT: Setting UV_PPAna_role.. \n"); fflush(stdout);
				if(SA_find_role2(UV_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
			}
			else if(tc_strcmp(Proj_PltFrm,"X0")==0)
			{
				printf("\n MT: Setting X0_PPAna_role.. \n"); fflush(stdout);
				if(SA_find_role2(X0_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
			}
			else if(tc_strcmp(Proj_PltFrm,"X1")==0)
			{
				printf("\n MT: Setting X1_PPAna_role.. \n"); fflush(stdout);
				if(SA_find_role2(X1_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
			}
			else if(tc_strcmp(Proj_PltFrm,"X2")==0)
			{
				printf("\n MT: Setting X2_PPAna_role.. \n"); fflush(stdout);
				if(SA_find_role2(X2_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
			}
			else if(tc_strcmp(Proj_PltFrm,"X3")==0)
			{
				printf("\n MT: Setting X3_PPAna_role.. \n"); fflush(stdout);
				if(SA_find_role2(X3_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
			}
			else if(tc_strcmp(Proj_PltFrm,"X4")==0)
			{
				printf("\n MT: Setting X4_PPAna_role.. \n"); fflush(stdout);
				if(SA_find_role2(X4_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
			}
			else
			{
				printf("\n MT: OTHER PLATFORM... \n"); fflush(stdout);
				//if(SA_find_role2(X4_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
				//if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
			}
			printf("\n MT:No_PPAna  ---> [%d]",No_PPAna);  fflush(stdout);
			if(No_PPAna>0)
			{
				for(pp=0;pp<No_PPAna;pp++)
				{	
					printf("\n MT:BOM Analyst no: [%d]",pp);fflush(stdout);
					if(EPM_get_participanttype ("T5_PPReviewer",&PPAna_Patri_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(PPAna[pp],PPAna_Patri_Type,&PPAna_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(ITEM_rev_add_participant(objTag,PPAna_Party)!=ITK_ok)PrintErrorStack();	
					AOM_save(objTag);
					AOM_unlock(objTag);
				}
			}
			AOM_refresh ( objTag,TRUE);
			MEM_free(PPAna);
			
			/*//CE Reviewer not for PVBU.
			printf("\n MT: Setting CE Reviewer...");fflush(stdout);
			if(SA_find_group(groupName, &CEGrp_tag);
			if(SA_find_role2(CEAnalyst_role,&CEAnalyst_tag)!=ITK_ok)PrintErrorStack();
			if(SA_find_groupmember_by_role(CEAnalyst_tag,CEGrp_tag,&No_CEAna,&CEAna)!=ITK_ok)PrintErrorStack();
			printf("\n MT:No_CEAna  :[%d]",No_CEAna);  fflush(stdout);

			if(No_CEAna>0)
			{
				for(ik=0;ik<No_CEAna;ik++)
				{	
					printf("\n MT:CE Reviewer no: %d",ik);fflush(stdout);
					if(EPM_get_participanttype ("T5_CEReviewer",&CEAna_Patri_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(CEAna[ik],CEAna_Patri_Type,&CEAna_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(ITEM_rev_add_participant(objTag,CEAna_Party)!=ITK_ok)PrintErrorStack();	
					AOM_save(objTag);
					AOM_unlock(objTag);
				}
			}
			AOM_refresh ( objTag,TRUE);
			MEM_free(CEAna);*/
		}
		else
		{
			/*//VI Reviewer for SVR only.
			printf("\n MT: Setting VI Analyst...");fflush(stdout);
			if(SA_find_group(groupName, &VIGrp_tag)!=ITK_ok)PrintErrorStack();
			if(SA_find_role2(VIAnalyst_role,&VIAnalyst_tag)!=ITK_ok)PrintErrorStack();
			if(SA_find_groupmember_by_role(VIAnalyst_tag,VIGrp_tag,&No_VIAna,&VIAna)!=ITK_ok)PrintErrorStack();
			printf("\n MT:No_VIAna :[%d]",No_VIAna);  fflush(stdout);
			if(No_VIAna>0)
			{
				for(iii=0;iii<No_VIAna;iii++)
				{	
					printf("\n MT: VI Reviewer no: [%d]",iii);fflush(stdout);
					if(EPM_get_participanttype ("T5_VIReviewer",&VIAna_Patri_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(VIAna[iii],VIAna_Patri_Type,&VIAna_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(ITEM_rev_add_participant(objTag,VIAna_Party)!=ITK_ok)PrintErrorStack();
					AOM_save(objTag);
					AOM_unlock(objTag);
				}
			}
			AOM_refresh ( objTag,TRUE);
			MEM_free(VIAna);*/
		}

		//Setting Reviewers for task.
		printf("\n MT:SETTING REVIEWERS FOR TASK START......\n");fflush(stdout);
		if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
		if (DmlTask_tag!=NULLTAG)
		{		
			if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
			printf("\n MT: TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
			printf("\n MT:Removing REVIEWERS FOR TASK START......\n");fflush(stdout);
			for (jkk=0;jkk<Tskcout ;jkk++ )
			{
				printf("\n MT: Party remove for Task no : %d.",jkk);fflush(stdout);
				if(ITEM_rev_sequence_is_latest(TskRev_tag[jkk],&is_Tskletst)!=ITK_ok)PrintErrorStack();
				printf("\n MT:.. %d\n",is_Tskletst);fflush(stdout);

				if(is_Tskletst != true)
				{
					printf("\n MT:is_Tskletst is not true .....\n");fflush(stdout);
				}
				else
				{	
					TskRev_tg = TskRev_tag[jkk];
					if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
					if (Tsk_CRB_rel_type!=NULLTAG)
					{
						printf("\n MT:inside DML HasParticipant remove.. \n");fflush(stdout);
						if(GRM_list_secondary_objects_only(TskRev_tg,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
						printf("\n MT: TskCRB count: %d",CRBcunt);fflush(stdout);	
						for (jtsk=0;jtsk<CRBcunt ;jtsk++ )
						{	
							printf("\n MT:jtsk: %d.\n",jtsk);fflush(stdout);
							TskCRBTag = TskCRB[jtsk];
							if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
							if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
							printf("\n MT:DML: type_name7 :: %s\n", type_name8);fflush(stdout);
							if(strcmp(DMLType,"SVR")!=0)
							{
								if (strcmp(type_name8,"T5_DMUReviewer")==0)
								{
									printf("\n MT: Removing DMU reviewer. \n"); fflush(stdout);
									if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
									printf("\n MT: DML Reviewer: [%s] ",TskReviewr);fflush(stdout);
									AOM_lock(TskRev_tg);
									if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
									AOM_save(TskRev_tg);
									AOM_unlock(TskRev_tg);
								}
								if (strcmp(type_name8,"T5_PeerReviewer")==0)
								{
									printf("\n MT: Removing PP reviewer. \n"); fflush(stdout);
									if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
									printf("\n MT: DML Reviewer: [%s] ",TskReviewr);fflush(stdout);
									AOM_lock(TskRev_tg);
									if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
									AOM_save(TskRev_tg);
									AOM_unlock(TskRev_tg);
								}
								
							}
							else
							{
								/*if (strcmp(type_name8,"T5_BIWReviewer")==0)
								{
									printf("\n MT: Removing BIW reviewer. \n"); fflush(stdout);
									if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
									printf("\n MT: DML Reviewer1: [%s] ",TskReviewr);fflush(stdout);
									AOM_lock(TskRev_tg);
									if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag) !=ITK_ok)PrintErrorStack();
									AOM_save(TskRev_tg);
									AOM_unlock(TskRev_tg);
								}
								if (strcmp(type_name8,"T5_TRIMReviewer")==0)
								{
									printf("\n MT: Removing Trim reviewer. \n"); fflush(stdout);
									if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
									printf("\n MT: DML Reviewer2: [%s] ",TskReviewr);fflush(stdout);
									AOM_lock(TskRev_tg);
									if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
									AOM_save(TskRev_tg);
									AOM_unlock(TskRev_tg);
								}
								if (strcmp(type_name8,"T5_CHReviewer")==0)
								{
									printf("\n MT: Removing CH reviewer. \n"); fflush(stdout);
									if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
									printf("\n MT: DML Reviewer3: [%s] ",TskReviewr);fflush(stdout);
									AOM_lock(TskRev_tg);
									if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
									AOM_save(TskRev_tg);
									AOM_unlock(TskRev_tg);
								}
								if (strcmp(type_name8,"T5_EEReviewer")==0)
								{
									printf("\n MT: Removing EE reviewer. \n"); fflush(stdout);
									if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr) !=ITK_ok)PrintErrorStack();
									printf("\n MT: DML Reviewer4: [%s] ",TskReviewr);fflush(stdout);
									AOM_lock(TskRev_tg);
									if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
									AOM_save(TskRev_tg);
									AOM_unlock(TskRev_tg);
								}
								if (strcmp(type_name8,"T5_PTReviewer")==0)
								{
									printf("\n MT: Removing PT reviewer. \n"); fflush(stdout);
									if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
									printf("\n MT: DML Reviewer5: [%s] ",TskReviewr);fflush(stdout);
									AOM_lock(TskRev_tg);
									if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
									AOM_save(TskRev_tg);
									AOM_unlock(TskRev_tg);
								}*/
							}
						}
					}
				}
			}
			printf("\n MT:Adding REVIEWERS FOR TASK START......\n");fflush(stdout);
			for (t=0;t<Tskcout ;t++ )
			{ 
				No_DMU=0;
				No_Peer=0;
				printf("\n MT: Task no : %d.",t);fflush(stdout);
				if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
				printf("\n MT: %d\n",is_Tsklatst);fflush(stdout);

				if(is_Tsklatst != true)
				{
					printf("\n MT:is_Tsklatst is not true .....\n");fflush(stdout);
				}
				else
				{	
					TskRev_t = TskRev_tag[t];
					if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
					if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
					printf("\n MT: Task class..:%s",Tsk_class);
					if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
					{
						printf("\n MT: Inside T5_ChangeTaskRevision. \n"); fflush(stdout);
						//Setting DMU Reviewers.
						if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
						printf("\n MT: Task_name:[%s]\n",Task_name);fflush(stdout);
						DsgGrp=subString(Task_name,11,2);
						DsgGrup=(int) atoi(DsgGrp);
						printf("\n MT: DsgGrp: %s",DsgGrp);fflush(stdout);
						if(strcmp(DMLType,"SVR")!=0)
						{
							//COC DMU Reviewer
							printf("\n MT:SETTING COC DMU Reviewer......\n");fflush(stdout);
							if(SA_find_group(groupName, &DMUGrp_tag)!=ITK_ok)PrintErrorStack();
							if((tc_strcmp(DsgGrp,"29")==0)||(tc_strcmp(DsgGrp,"30")==0)||(tc_strcmp(DsgGrp,"42")==0)||(tc_strcmp(DsgGrp,"43")==0))
							{
								printf("\n MT: Setting Brake_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Brake_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if ((DsgGrup >=60) && (DsgGrup <=66))
							{
								printf("\n MT: ELSE Setting BIW_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(BIW_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if ((DsgGrup >=70) && (DsgGrup <=80))
							{
								printf("\n MT: ELSE Setting  Door_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Door_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"88")==0)
							{
								printf("\n MT: ELSE Setting ExtTrims_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(ExtTrims_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"81")==0)
							{
								printf("\n MT: ELSE Setting Fit_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Fit_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if ((DsgGrup >=67) && (DsgGrup <=69))
							{
								printf("\n MT: ELSE Setting IntTrims_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(IntTrims_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"55")==0)
							{
								printf("\n MT: ELSE Setting Mascots_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Mascots_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if ((DsgGrup >=91) && (DsgGrup <=96))
							{
								printf("\n MT: ELSE Setting Seat_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Seat_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if((tc_strcmp(DsgGrp,"54")==0)||(tc_strcmp(DsgGrp,"15")==0)||(tc_strcmp(DsgGrp,"16")==0)||(tc_strcmp(DsgGrp,"04")==0)||(tc_strcmp(DsgGrp,"82")==0))
							{
								printf("\n MT: ELSE Setting EE_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(EE_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"49")==0)
							{
								printf("\n MT: ELSE Setting Exhaust_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Exhaust_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"31")==0)
							{
								printf("\n MT: ELSE Setting Frame_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Frame_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"47")==0)
							{
								printf("\n MT: ELSE Setting Fuel_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Fuel_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"83")==0)
							{
								printf("\n MT: ELSE Setting HVAC_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(HVAC_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"24")==0)
							{
								printf("\n MT: ELSE Setting Mounts_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Mounts_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"97")==0)
							{
								printf("\n MT: ELSE Setting Restrn_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Restrn_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"46")==0)
							{
								printf("\n MT: ELSE Setting Steering_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Steering_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if((tc_strcmp(DsgGrp,"32")==0)||(tc_strcmp(DsgGrp,"35")==0)||(tc_strcmp(DsgGrp,"33")==0)||(tc_strcmp(DsgGrp,"40")==0)||(tc_strcmp(DsgGrp,"41")==0))
							{
								printf("\n MT: ELSE Setting Suspension_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Suspension_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"58")==0)
							{
								printf("\n MT: ELSE Setting Tools_DMU_role.. \n"); fflush(stdout);
								if(SA_find_role2(Tools_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
							}
							else
							{
								printf("\n MT: ELSE Other design group.. \n"); fflush(stdout);
							}
							
							printf("\n MT: Find  grp member for DMU count..%d \n",No_DMU); fflush(stdout);
							if(No_DMU>0)
							{
								im=0;
								for(im=0;im<No_DMU;im++)
								{	
									printf("\n MT: DMU Reviewer no: %d",im);fflush(stdout);
									if(EPM_get_participanttype ("T5_DMUReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(DMU_t[im],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(TskRev_t);			
									if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save(TskRev_t);
									AOM_unlock(TskRev_t);
								}
								AOM_refresh ( TskRev_t,TRUE);
								MEM_free(DMU_t);
							}
							
							//COC PEER REVIEWER...
							printf("\n MT:SETTING COC Peer Reviewer......\n");fflush(stdout);
							if(SA_find_group(groupName, &PeerGrp_tag)!=ITK_ok)PrintErrorStack();
							if((tc_strcmp(DsgGrp,"29")==0)||(tc_strcmp(DsgGrp,"30")==0)||(tc_strcmp(DsgGrp,"42")==0)||(tc_strcmp(DsgGrp,"43")==0))
							{
								printf("\n MT: Setting Brake_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Brake_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if ((DsgGrup >=60) && (DsgGrup <=66))
							{
								printf("\n MT: ELSE Setting BIW_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(BIW_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if ((DsgGrup >=70) && (DsgGrup <=80))
							{
								printf("\n MT: ELSE Setting  Door_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Door_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"88")==0)
							{
								printf("\n MT: ELSE Setting ExtTrims_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(ExtTrims_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"81")==0)
							{
								printf("\n MT: ELSE Setting Fit_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Fit_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if ((DsgGrup >=67) && (DsgGrup <=69))
							{
								printf("\n MT: ELSE Setting IntTrims_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(IntTrims_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"55")==0)
							{
								printf("\n MT: ELSE Setting Mascots_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Mascots_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if ((DsgGrup >=91) && (DsgGrup <=96))
							{
								printf("\n MT: ELSE Setting Seat_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Seat_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if((tc_strcmp(DsgGrp,"54")==0)||(tc_strcmp(DsgGrp,"15")==0)||(tc_strcmp(DsgGrp,"16")==0)||(tc_strcmp(DsgGrp,"04")==0)||(tc_strcmp(DsgGrp,"82")==0))
							{
								printf("\n MT: ELSE Setting EE_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(EE_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"49")==0)
							{
								printf("\n MT: ELSE Setting Exhaust_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Exhaust_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"31")==0)
							{
								printf("\n MT: ELSE Setting Frame_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Frame_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"47")==0)
							{
								printf("\n MT: ELSE Setting Fuel_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Fuel_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"83")==0)
							{
								printf("\n MT: ELSE Setting HVAC_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(HVAC_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"24")==0)
							{
								printf("\n MT: ELSE Setting Mounts_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Mounts_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"97")==0)
							{
								printf("\n MT: ELSE Setting Restrn_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Restrn_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"46")==0)
							{
								printf("\n MT: ELSE Setting Steering_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Steering_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if((tc_strcmp(DsgGrp,"32")==0)||(tc_strcmp(DsgGrp,"35")==0)||(tc_strcmp(DsgGrp,"33")==0)||(tc_strcmp(DsgGrp,"40")==0)||(tc_strcmp(DsgGrp,"41")==0))
							{
								printf("\n MT: ELSE Setting Suspension_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Suspension_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else if(tc_strcmp(DsgGrp,"58")==0)
							{
								printf("\n MT: ELSE Setting Tools_Peer_role.. \n"); fflush(stdout);
								if(SA_find_role2(Tools_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
								if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
							}
							else
							{
								printf("\n MT: ELSE Other design group.. \n"); fflush(stdout);
							}
							printf("\n MT: Find  grp member for Peer count..%d \n",No_Peer); fflush(stdout);
							if(No_Peer>0)
							{
								ii=0;
								for(ii=0;ii<No_Peer;ii++)
								{	
									printf("\n MT: peer reviewer no: %d",ii);fflush(stdout);
									if(EPM_get_participanttype ("T5_PeerReviewer",&Peer_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(Peer_t[ii],Peer_Patri_Type,&Peer_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(TskRev_t);			
									if(ITEM_rev_add_participant(TskRev_t,Peer_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save(TskRev_t);
									AOM_unlock(TskRev_t);
								}
								AOM_refresh ( TskRev_t,TRUE);
								MEM_free(Peer_t);
							}
						}
						else
						{
							/*//SVR COC REVIEWER...
							No_SVRcoc=0;
							No_SVRc=0;
							No_SVRe=0;
							No_SVRp=0;
							No_SVRt=0;
							//BIW Reviewer.
							printf("\n MT: Setting BIW_SVRCoC_role SVR COC REVIEWER. \n"); fflush(stdout);
							if(SA_find_group(groupName, &SVRcocGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(BIW_SVRCoC_role,&SVRcoc_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_groupmember_by_role(SVRcoc_tag,SVRcocGrp_tag,&No_SVRcoc,&SVRcoc_t)!=ITK_ok)PrintErrorStack();
							if(No_SVRcoc>0)
							{
								for(b=0;b<No_SVRcoc;b++)
								{	
									printf("\n MT: peer reviewer no: %d",b);fflush(stdout);
									if(EPM_get_participanttype ("T5_BIWReviewer",&SVRcoc_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(SVRcoc_t[b],SVRcoc_Patri_Type,&SVRcoc_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(TskRev_t);			
									if(ITEM_rev_add_participant(TskRev_t,SVRcoc_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save(TskRev_t);
									AOM_unlock(TskRev_t);
								}
								AOM_refresh ( TskRev_t,TRUE);
								MEM_free(SVRcoc_t);
							}
							//TRIM Reviewer
							printf("\n MT: Setting Trim_SVRCoC_role SVR COC REVIEWER. \n"); fflush(stdout);
							if(SA_find_group(groupName, &SVRtGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(Trim_SVRCoC_role,&SVRt_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_groupmember_by_role(SVRt_tag,SVRtGrp_tag,&No_SVRt,&SVRt_t)!=ITK_ok)PrintErrorStack();
							if(No_SVRt>0)
							{
								for(tr=0;tr<No_SVRt;tr++)
								{	
									printf("\n MT: peer reviewer no: %d",tr);fflush(stdout);
									if(EPM_get_participanttype ("T5_TRIMReviewer",&SVRt_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(SVRt_t[tr],SVRt_Patri_Type,&SVRt_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(TskRev_t);			
									if(ITEM_rev_add_participant(TskRev_t,SVRt_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save(TskRev_t);
									AOM_unlock(TskRev_t);
								}
								AOM_refresh (TskRev_t,TRUE);
								MEM_free(SVRt_t);
							}
							//CHASSIS SVR ROLE
							printf("\n MT: Setting CH_SVRCoC_role SVR COC REVIEWER. \n"); fflush(stdout);
							if(SA_find_group(groupName, &SVRcGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(CH_SVRCoC_role,&SVRc_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_groupmember_by_role(SVRc_tag,SVRcGrp_tag,&No_SVRc,&SVRc_t)!=ITK_ok)PrintErrorStack();
							if(No_SVRc>0)
							{
								for(c=0;c<No_SVRc;c++)
								{	
									printf("\n MT: peer reviewer no: %d",c);fflush(stdout);
									if(EPM_get_participanttype ("T5_CHReviewer",&SVRc_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(SVRc_t[c],SVRc_Patri_Type,&SVRc_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(TskRev_t);			
									if(ITEM_rev_add_participant(TskRev_t,SVRc_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save(TskRev_t);
									AOM_unlock(TskRev_t);
								}
								AOM_refresh (TskRev_t,TRUE);
								MEM_free(SVRc_t);
							}
							//EE COC reviewer
							printf("\n MT: Setting EE_SVRCoC_role SVR COC REVIEWER. \n"); fflush(stdout);
							if(SA_find_group(groupName, &SVReGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(EE_SVRCoC_role,&SVRe_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_groupmember_by_role(SVRe_tag,SVReGrp_tag,&No_SVRe,&SVRe_t)!=ITK_ok)PrintErrorStack();
							if(No_SVRe>0)
							{
								for(e=0;e<No_SVRe;e++)
								{	
									printf("\n MT: peer reviewer no: %d",e);fflush(stdout);
									if(EPM_get_participanttype ("T5_EEReviewer",&SVRe_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(SVRe_t[e],SVRe_Patri_Type,&SVRe_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(TskRev_t);			
									if(ITEM_rev_add_participant(TskRev_t,SVRe_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save(TskRev_t);
									AOM_unlock(TskRev_t);
								}
								AOM_refresh (TskRev_t,TRUE);
								MEM_free(SVRe_t);
							}
							//Powertrain reviewer
							printf("\n MT: Setting PT_SVRCoC_role SVR COC REVIEWER. \n"); fflush(stdout);
							if(SA_find_group(groupName, &SVRpGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(PT_SVRCoC_role,&SVRp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_groupmember_by_role(SVRp_tag,SVRpGrp_tag,&No_SVRp,&SVRp_t)!=ITK_ok)PrintErrorStack();
							if(No_SVRp>0)
							{
								for(p=0;p<No_SVRp;p++)
								{	
									printf("\n MT: PT_SVRCoC reviewer no: %d",p);fflush(stdout);
									if(EPM_get_participanttype ("T5_PTReviewer",&SVRp_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(SVRp_t[p],SVRp_Patri_Type,&SVRp_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(TskRev_t);			
									if(ITEM_rev_add_participant(TskRev_t,SVRp_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save(TskRev_t);
									AOM_unlock(TskRev_t);
								}
								AOM_refresh (TskRev_t,TRUE);
								MEM_free(SVRp_t);
							}*/
						}
					}
				}
			}
		}
	}

	return error_code;
}


int Assign_Dynamic_party_register_action_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{
		retcode = EPM_register_action_handler (
								"Assign_Dynamic_party",
								"Assign_Dynamic_party",
								(EPM_action_handler_t)Assign_Dynamic_party_Func
								);

		printf("\n Assign_Dynamic_party_register_action_handlers\n");fflush(stdout);
	}
	return retcode;
}

extern int Assign_Dynamic_party_action(int *decision, va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;	

	printf("\n before Assign_Dynamic_party_register_action_handlers is added now. ");fflush(stdout);
	status = Assign_Dynamic_party_register_action_handlers();
	printf("\n after Assign_Dynamic_party_register_action_handlers is added now. ");fflush(stdout);
	return status;
}

extern DLLAPI int Assign_Dynamic_party_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n\n before calling Assign_Dynamic_party_register_callbacks\n");
    ifail=CUSTOM_register_exit("Assign_Dynamic_party","USER_init_module",(CUSTOM_EXIT_ftn_t)Assign_Dynamic_party_action);
	printf("\n\n after calling Assign_Dynamic_party_register_callbacks\n");
	
    return ( ITK_ok );
}
