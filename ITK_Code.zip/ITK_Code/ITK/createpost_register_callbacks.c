/****************************************************************************************************
*  File            :   createpost_register_callbacks.c
*  Created By      :   Muktesh Girdhani
*  Created On      :   30-july-2011
*  Purpose         :   Assign the created object to Project depending on t5_ProjectCode attribute value.			
*					   This is called at post action of creation.
******************************************************************************************************/
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <user_exits/user_exits.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <tccore/item_msg.h>
#include <sa/user.h>
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 4)


char* subString (char* mainStringf ,int fromCharf,int toCharf);
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
//    vsprintf(msg, format, args);
    printf(msg);
    va_end(args);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;   
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL; 
	                             
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
//Create Dataset and attach it to Design Revision
static int t5CreateDatasetOnDesignCre( tag_t DesignRevision, char* startPartName)
{	
	char *item_id;
	char *object_types;
	tag_t qryDatasetTag = NULLTAG;
	tag_t datasetTag = NULLTAG;
	tag_t relationTag = NULLTAG;
 	tag_t relation = NULLTAG;
	int   	count = 0, i =0 , flag = 0;
	tag_t *secondary_objects	 ;
	
	printf("\n Inside Function t5CreateDatasetOnDesignCre in file createpost_register_callbacks.c\n");fflush(stdout);

	//Query GRM Relation Type
	if (GRM_find_relation_type("IMAN_specification", &relationTag))   PrintErrorStack();

	if(GRM_list_secondary_objects_only(DesignRevision, relationTag, &count, &secondary_objects)) PrintErrorStack();

	if(count > 0)
	{
		for (i=0; i< count; i++)
		{
			if (AOM_ask_value_string(secondary_objects[i],"object_type",&object_types)!=ITK_ok)   PrintErrorStack();

			if(tc_strcmp(object_types,"Creo assembly") == 0 || tc_strcmp(object_types,"Creo part") == 0) 
			{
				flag = 1;
				break;
			}
		}
	}
	
	printf("\n Inside Function t5CreateDatasetOnDesignCre flag == %d \n", flag);fflush(stdout);
	if(flag == 0)
	{

		if (AOM_ask_value_string(DesignRevision,"item_id",&item_id)!=ITK_ok)   PrintErrorStack();
		printf("\n Design Revision ID  = [%s]\n", item_id);fflush(stdout);

		//Query Dataset With Start Part Name
		if (AE_find_dataset2(startPartName, &qryDatasetTag)!=ITK_ok)   PrintErrorStack(); 

		if(qryDatasetTag != NULLTAG)
		{
			//Copy the Dataset Tag with new name
			if (AE_copy_dataset_with_id(qryDatasetTag, item_id, NULL, NULL, &datasetTag))   PrintErrorStack();

			/*result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\n\t Got reference list--->%d",result); fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\n\t File Imported--->%d",result); fflush(stdout);

                                                                if (result == 41178)
                                                                {
                                                                        ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
                                                                }

                                                                result = AOM_save(filetag);
                                                                printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

                                                                ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
                                                                result = AOM_save(filetag);
                                                                printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\n\t Tool set--->%d",result); fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                printf("\n\t AOM_save--->%d",result); fflush(stdout);*/
			
			if(datasetTag != NULLTAG)
			{
				printf("\n Dataset with Name [%s], created successfully. \n", item_id);fflush(stdout);

				//Saving the newly copied dataset 
				if(AE_save_myself(datasetTag)) PrintErrorStack();			

				if(relationTag != NULLTAG)
				{
					//IMAN_SPECIFICATION relationship
					if (GRM_create_relation(DesignRevision, datasetTag, relationTag, NULLTAG, &relation))   PrintErrorStack();

					if(relation != NULLTAG)
					{
						//Saving the Relationship
						if (GRM_save_relation 	(relation)); 	
						printf("\n Relationship Create Between Design Revision and Dataset\n");fflush(stdout);
					}
					else
					{
						printf("\n *** Relationship creation failed between Design Reivion and Dataset" );fflush(stdout);
					}
				}
				else
				{
					printf("\n *** Relationship Tag for relation name IMAN_specification not found. ***\n", startPartName, item_id);fflush(stdout);
				}
			}
			else
			{
				printf("\n *** Copy Of Dataset [%s] with new name [%s] failed. ***\n", startPartName, item_id);fflush(stdout);
			}
		}
		else
		{
			printf("\n *** Dataset Not Found with name [%s] *** \n", startPartName);fflush(stdout);
		}
	}
	printf("\n Exiting Function t5CreateDatasetOnDesignCre in file createpost_register_callbacks.c\n");fflush(stdout);
    return ITK_ok;
}
extern DLLAPI int createpost_method_1(METHOD_message_t *m, va_list args)
{
	const char* item_id;
    const char* item_name;
    const char* type_name;
	char type_name2[TCTYPE_name_size_c+1];
    const char* rev_id;
    tag_t*      new_item_tag;
    tag_t*      new_rev_tag;
    tag_t*      secondary_objects=NULLTAG;
    tag_t       item_master_form_tag;
    tag_t       item_rev_master_form_tag;
    tag_t reln_type =NULLTAG;
	char* t5_StartPartProductS;
	char* t5_DrawingIndS;

	tag_t    tagItem=NULLTAG;
	tag_t    tagItemRev=NULLTAG;
	tag_t objTypeTag;
	tag_t objTag;
	 tag_t   projobj; 
	// tag_t projobj1;
	int i=0, notalpha =99,c_attchs=0,p=0;

	const char	   reason;
	const char	   reason1;
	const char     change_id;
	const char     change_id1;
	const char     dir_name;
	const char     dir_name1;

	char	*ObjProject= NULL;
	char	*ObjProject1	= NULL;
	char* ProSubStr = NULL;
	char	*ItemIdV	= NULL;
	char   *prid=NULL;
    char   *desid=NULL;
	char   *desrevid=NULL;
	int	 IDlen;
	char   *projectcode=NULL;
    char   *desgngrp=NULL;
	char* itemTagString=NULL;
	char* itemRevTagString=NULL;
	char   type_name1[TCTYPE_name_size_c+1];
	logical	checkout				= 0;
	logical	checkoutp				= 0;
//	char	Ptype_name1[TCTYPE_name_size_c+1];
	tag_t objTagMaster = va_arg(args, tag_t);
	tag_t			status_rel					= NULLTAG;
	tag_t			primary					= NULLTAG;
	tag_t			objTypeTagDi				= NULLTAG;
	tag_t attr_id ;
	logical			retain							= 0;
	char			*Desc_obj2	= NULL;
//	ITEM_find_revision(objTagMaster,"A",&objTag);
	int Procnt=0;
	int ProEfound=0;
	//ITEM_ask_latest_rev  (objTagMaster, &objTag)  ;
	tag_t			relation_type								= NULLTAG;
		int				cnt=0;
		int				j=0;
		tag_t			*attachments								= NULLTAG;

 char		   *ObjectClassType		= NULL;
	  char		   *ObjectName		= NULL;
	  char* oojname = NULL;
	  tag_t form_attr_id ;
tag_t			dataset		= NULLTAG;
	/*
	item_id = va_arg(args, const char*);
	item_name = va_arg(args, const char*);
	type_name = va_arg(args, const char*);
	rev_id = va_arg(args, const char*);
	new_item_tag = va_arg(args, tag_t *);
	new_rev_tag = va_arg(args, tag_t *);
	item_master_form_tag = va_arg(args, tag_t);
	item_rev_master_form_tag= va_arg(args, tag_t);
  
     
	 tagItem=*new_item_tag;
	 tagItemRev=*new_rev_tag;
*/
	 // tag_t objTagMaster = va_arg(args, tag_t);
	 ITEM_ask_latest_rev  (objTagMaster, &objTag)  ;
	 if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	 if (TCTYPE_ask_name(objTypeTag,type_name1)!=ITK_ok)PrintErrorStack();
	
	 printf("\n In Createpost \n");fflush(stdout);
	 if(strcmp(type_name1,"Design Revision")==0)
	 {
		if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
		printf("\n Desc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);

		 if (AOM_get_value_string(objTag,"t5_ProjectCode",&ObjProject1))PrintErrorStack();
			 printf("\nProject stamped is  : %s\n",ObjProject1);fflush(stdout);
  
    if( AOM_ask_value_string(objTag,"item_id",&ItemIdV)!=ITK_ok);PrintErrorStack();

         ProSubStr=subString(ItemIdV,0,4);

			if ((strcmp(ObjProject1,"9001")==0) || (strcmp(ProSubStr,"9001")==0))
			{

				EMH_store_error_s1(EMH_severity_error,ITK_err,"Project 9001 is no longer available. Please use 9002");	
				return ITK_err; 
			}
       

			else 
		 {

		if(strcmp(Desc_obj2,"NR;1")==0)
		{
			if(RES_is_checked_out(objTag,&checkout))PrintErrorStack();
			if (checkout==0)
			 {
				//Create Pro/E Datasets

				//Get Start Part/Product Value
				if (AOM_ask_value_string(objTag,"t5_StartPartProduct",&t5_StartPartProductS)!=ITK_ok)   PrintErrorStack();
				printf("\n t5_StartPartProduct  = [%s]\n", t5_StartPartProductS);fflush(stdout);
				
				if(tc_strcmp(t5_StartPartProductS,"START PART PRO-E COMPONENT") == 0 || tc_strcmp(t5_StartPartProductS,"START PART PRO-E ASSEMBLY") == 0 || tc_strcmp(t5_StartPartProductS,"START PART PRO-E DRAWING") == 0)
				{
					//Create Component / Assembly Dataset
					if (t5CreateDatasetOnDesignCre( objTag, t5_StartPartProductS))   PrintErrorStack();
								
					//Get Drawing Indicator 
					if (AOM_ask_value_string(objTag,"t5_DrawingInd",&t5_DrawingIndS)!=ITK_ok)   PrintErrorStack();
					printf("\n t5_DrawingInd  = [%s]\n", t5_DrawingIndS);fflush(stdout);

					if(tc_strcmp(t5_DrawingIndS,"D") == 0 && tc_strcmp(t5_StartPartProductS,"START PART PRO-E DRAWING") != 0)
					{
						//Create Drawing Dataset
						if (t5CreateDatasetOnDesignCre( objTag, "START PART PRO-E DRAWING"))   PrintErrorStack();
					}
				}
				//End of Create Pro/E Datasets

				if (RES_checkout(objTag,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
				
				printf("\n**********After Check Out DR in createpost***************\n");fflush(stdout);
				if(GRM_list_secondary_objects_only(objTag,reln_type,&c_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
				printf("\nc_attchs :%d\n",c_attchs);fflush(stdout);
				if(c_attchs>0)
				{
					for (p= 0; p < c_attchs; p++)
					{
						primary=secondary_objects[p];
						if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
						if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
						printf("\nValue of type_name2 : %s\n",type_name2);fflush(stdout);
						if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0|| strcmp(type_name2,"ProDrw")==0)
						{
							  if(RES_is_checked_out(primary,&checkoutp))PrintErrorStack();
							   if (checkoutp==0)
							 {
								printf("\n**********Before Check Out Dataset in createpost***************\n");fflush(stdout);
								if (RES_checkout(primary,&reason1,&change_id1,&dir_name1,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
								printf("\n**********After Check Out Dataset in createpost***************\n");fflush(stdout);
							 }
			
						}
					
				
					}
				}	
				//	if (AOM_lock(objTag))PrintErrorStack();
				
				printf("\n############After lock\n");fflush(stdout);
			}
		}
		else
		{
				printf("\nin Else , part is not NR;1\n");fflush(stdout);
				if(GRM_list_secondary_objects_only(objTag,reln_type,&c_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
				printf("\nc_attchs :%d\n",c_attchs);fflush(stdout);
				if(c_attchs>0)
				{
					for (p= 0; p < c_attchs; p++)
					{
						primary=secondary_objects[p];
						if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
						if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
						printf("\nType of Dataset: %s\n",type_name2);fflush(stdout);
						
					//	if(strcmp(type_name2,"CMI2Part")==0 || strcmp(type_name2,"CMI2Product")==0|| strcmp(type_name2,"CMI2Drawing")==0 )
					//	{
					//		printf("\ninside CMI will show error\n");fflush(stdout);
					//		EMH_store_error_s1(EMH_severity_error,ITK_err,"Initial revision for TC parts should be 'NR' only. Pls check revision..");
					//		return ITK_err;
					//		break;
					//	}
						
						if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0|| strcmp(type_name2,"ProDrw")==0 )
						{
							printf("\ninside ProPrt,ProAsm,ProDrw will break\n");fflush(stdout);
							ProEfound=1;
							break;
			
						}
						//else
					//	{
					//		printf("\ninside ELSE of ProPrt,ProAsm,ProDrw will show error\n");fflush(stdout);
					//		EMH_store_error_s1(EMH_severity_error,ITK_err,"Initial revision for TC parts should be 'NR' only. Pls check revision..");
					//		return ITK_err;
					//		break;
					//	}
					}
					
					/*
					if (ProEfound==0)
					{
						printf("\nnot PROE will show error\n");fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Initial revision for TC parts should be 'NR' only. Pls check revision..");
						return ITK_err;
					}*/
				}
				
				/*
				else
				{
					printf("\ninside Elese when attaches = 0 . will show error\n");fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Initial revision for TC parts should be 'NR' only. Pls check revision..");
					return ITK_err;		
				}
				*/
		}
		 }
	 }

	return ITK_ok;
}

extern int createpost_register_method(int *decision, va_list args)
{
    METHOD_id_t  method;
  
	  *decision = ALL_CUSTOMIZATIONS;

  
   if ( METHOD_find_method("Item", TC_save_msg, &method) !=ITK_ok)
   PrintErrorStack();

    if (method.id != NULLTAG)
    {
        if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) createpost_method_1, NULL)!=ITK_ok)
        PrintErrorStack();
		printf("Registered as Post-Action for Creation\n");fflush(stdout);
    }
    else
        printf("Method not found!\n");fflush(stdout);

    return ITK_ok;
}

extern DLLAPI int createpost_register_callbacks ()
{
    printf("\n\ncreatepost_register_callbacks changed -------------new printf addedff \n\n");fflush(stdout);
	
	
  //  if(CUSTOM_register_exit ( "createpost", "USER_init_module", (CUSTOM_EXIT_ftn_t)  createpost_register_method) !=ITK_ok)
    if(CUSTOM_register_exit ( "createpost", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t)  createpost_register_method) !=ITK_ok)
     PrintErrorStack();
  return ( ITK_ok );
}

