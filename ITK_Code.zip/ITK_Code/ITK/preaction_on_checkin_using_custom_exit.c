/* Program Name: preaction_on_checkin_using_custom_exits.c
/* Purpose : Call TCDC programs on checkin
/* Sharvari Karale
/* Devkant Kedar
*/
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE 1
#define _CRT_NONSTDC_NO_DEPRECATE 1


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>

#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <ps/ps.h>
#include <bom/bom.h>
#include <bom/bom_tokens.h>
#include <pom/pom/pom.h>
#include <tccore/aom.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <ps/ps_errors.h>
#include <ps/vrule.h>
#include <tccore/grm.h>
#include <tc/emh_errors.h>
#include <tc/tc_errors.h>
#include <ss/ss_errors.h>
#include <fclasses/tc_string.h>
#include <property/prop.h>
#include <error.h>

#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#define ITK_err (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errErr (EMH_USER_error_base + 99)

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

#define MAX_LINE_LEN 1024
static const int    ECR_VERBOSE   = 1;
static const int    ECR_DEBUG     = 4;
static       int    log_threshold = 0;

#define ECR_IS_VERBOSE   ( log_threshold >= ECR_VERBOSE )
#define ECR_IS_DEBUG     ( log_threshold >= ECR_DEBUG   )


//Flag for LH/RH CheckIN
//static int	 LHFlg		= -1;
static int	 LHRhFlag		= -1;


static void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
 const char * fileName               /* <I> Name of the File */
 );
#define Debug TRUE

static void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int line_number,                    /* <I> Line Number in which the error Occurred in the Program */
 const char * file_name              /* <I> Name of the File */
 )
{
  int          n_ifails=0;
  const int   *severities=NULL;
  const int   *ifails=NULL;
  const char **texts=NULL;
  char        *errstring=NULL;
  char *err= NULL;
  err = ( char * ) MEM_alloc ( sizeof ( char ) * MAX_LINE_LEN );

  EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
  if ( n_ifails && texts != NULL )
    {
      if ( ifails[n_ifails-1] == stat )
        {
          //sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, texts[n_ifails-1] );
	  //printf ( "%s ", err );
          printf("\n\n%s: Error %d: %s\n\n", prog_name, stat, texts[n_ifails-1] );fflush(stdout);

        }
      else
        {
          EMH_ask_error_text (stat, &errstring );
          //sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );
          //printf ( "%s", err );
	  printf("\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );fflush(stdout);

          if ( errstring != NULL )
            MEM_free( errstring );
        }
    }
  else
    {
      EMH_ask_error_text (stat, &errstring );
      //sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );
      //printf ( " %s", err );
      printf("\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );fflush(stdout);
      if ( errstring != NULL )
        MEM_free( errstring );
    }
  //sprintf ( err,"\n\n%s: Error: Line %d in %s\n\n", prog_name, line_number, file_name );
  //printf ( "%s ", err);
  printf("\n\n%s: Error: Line %d in %s\n\n", prog_name, line_number, file_name );fflush(stdout);
}

#define ITK_CALL(x)                                                             \
{                                                                          \
    if ( ifail == ITK_ok )                                                 \
    {                                                                      \
        if ( (ifail = (x)) != ITK_ok )                                     \
        {                                                                  \
            FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
        }                                                                  \
    }                                                                      \
}

static void print_bom (tag_t line,tag_t Parent, int depth,char *Item_idP,char *Item_idC,int qty,int TmpQty,FILE *fdf,FILE *fus);
static void get_bom (tag_t line,tag_t Parent, int depth,char *Item_idP,char *Env, char *EnvOrignal);
//int getTcPartDetails(tag_t* objTag,char* ptimestamp);
int getTcPartDetails(tag_t* objTag,char ptimestamp[20]);


char* subString (char* mainStringf ,int fromCharf,int toCharf);


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack):\n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

static void report_object_description(tag_t object)
{
	WSO_description_t        desc;
	tag_t  sequence_id_c;


	if (WSOM_describe(object, &desc) !=ITK_ok)   PrintErrorStack();
	//if (AOM_ask_value_int(object,"sequence_id",&sequence_id_c)!=ITK_ok)   PrintErrorStack();

	printf("TCDCObject Name:     %s\n", desc.object_name);
	printf("TCDCObject Type:     %s\n", desc.object_type);
	printf("TCDCRevision ID:     %s\n", desc.revision_id);
//	printf("Sequence ID:		%d\n", sequence_id_c);
//  printf("Owner's Name:    %s\n", desc.owners_name);
//  printf("Owning Group:    %s\n", desc.owning_group_name);
//  printf("Description:     %s\n", desc.description);
//	printf("Date Created:    %s\n", desc.date_created);
//  printf("Date Modified:   %s\n", desc.date_modified);
//  printf("Application:     %s\n", desc.application);
//  printf("Revision Limit:  %d\n", desc.revision_limit);
//  printf("Last Modifier    %s\n", desc.last_modifying_user_name);
//  printf("Is Frozen:       %d\n", desc.is_frozen);
//  printf("Is Reserved:     %d\n", desc.is_reserved);
//  printf("Owning Site:     %s\n", desc.owning_site_name);

}
//int getTcPartDetails(tag_t* objTag,char* ptimestamp)
int getTcPartDetails(tag_t* objTag,char ptimestamp[20])
{

	const char *prog_name="getTcPartDetails";
	char name[WSO_name_size_c +1];
	char description[WSO_desc_size_c +1];
	char* Item_id = NULL;
	char* sRevision = NULL;
	char* sSequence = NULL;
	char* sDescription = NULL;
	char* sPartType = NULL;
	char* sModelDescription = NULL;
	char* sKeywordDescription = NULL;
	char* sAddonDescription = NULL;
	char* sProjectCode = NULL;
	char* sDesignGroup = NULL;
	char* sMaterialInDrawing = NULL;
	char* sMaterialThickness = NULL;
	char* sMaterialClass = NULL;
	char* sYield = NULL;
	char* sEnteredWeight = NULL;
	char* sRollupWeight = NULL;
	char* sSurfaceArea = NULL;
	char* sVolume = NULL;
	char* sEnvelopeDimensions = NULL;
	char* sPartCategory = NULL;

	int iSequence = 0;
	double dEnteredWeight = 0.0;
	double dRollupWeight = 0.0;
	double dSurfaceArea = 0.0;
	double dVolume = 0.0;
	WSO_description_t desc;

	char *sStagingDir=NULL;
	char *TcDcEnvName=NULL;
	FILE* fpPLMProperties = NULL;
	char* sPLMProperties = NULL;
	int ifail = ITK_ok;
	struct stat info;
	char cDescRevision[WSO_name_size_c+1] = { "" };
	char *newPatRev = NULL;
	char *newPatSeq = NULL;
	char*  cRevSeq = NULL;

	Item_id = malloc (50 * sizeof (char *) );
	sRevision = malloc(4 * sizeof (char *) );
	sSequence = malloc(4 * sizeof (char *) );
	sDescription = malloc(400 * sizeof (char *) );
	sPartType = malloc(25 * sizeof (char *) );
	sModelDescription = malloc(400 * sizeof (char *) );
	sKeywordDescription = malloc(400 * sizeof (char *) );
	sAddonDescription = malloc(400 * sizeof (char *) );
	sProjectCode = malloc(10 * sizeof (char *) );
	sDesignGroup = malloc(10 * sizeof (char *) );
	sMaterialInDrawing = malloc(50 * sizeof (char *) );
	sMaterialThickness = malloc(50 * sizeof (char *) );
	sMaterialClass = malloc(50 * sizeof (char *) );
	sYield = malloc(50 * sizeof (char *) );
	sEnteredWeight = malloc(50 * sizeof (char *) );
	sRollupWeight = malloc(50 * sizeof (char *) );
	sSurfaceArea = malloc(50 * sizeof (char *) );
	sVolume = malloc(50 * sizeof (char *) );
	sEnvelopeDimensions = malloc(50 * sizeof (char *) );
	sPartCategory = malloc(50 * sizeof (char *) );

	sStagingDir = malloc(500* sizeof (char *) );
	//TcDcEnvName = malloc(250 * sizeof (char *) );
	sPLMProperties = malloc(750 * sizeof (char *) );

	ITK_CALL(AOM_ask_value_string(*objTag,"item_id",&Item_id));
	ITK_CALL(WSOM_describe(*objTag, &desc));
	ITK_CALL(AOM_ask_value_int(*objTag,"sequence_id",&iSequence));
	ITK_CALL(AOM_ask_value_string(*objTag,"object_desc",&sDescription));
	if(tc_strcmp(sDescription,"")==0)
	{
		tc_strcpy(sDescription,"NULL");
	}
	//ITK_CALL(AOM_ask_value_string(*objTag,"t5_PartType",&sPartType));
	ITK_CALL(AOM_UIF_ask_value(*objTag,"t5_PartType",&sPartType));
	if(tc_strcmp(sPartType,"")==0)
	{
		tc_strcpy(sPartType,"NULL");
	}
	
	//tc_strcpy ( cDescRevision, desc.revision_id );
	printf("sPartType=%s\n",sPartType);fflush(stdout);

	ITK_CALL(AOM_UIF_ask_value(*objTag,"item_revision_id",&cRevSeq));
	printf("TCDC in getTcPartDetails AOM_UIF_ask_value cRevSeq:     %s\n", cRevSeq);fflush(stdout);

	//tc_strcpy ( cDescRevision, desc.revision_id );
	//printf("\ncDescRevision:%s",cDescRevision);
	//newPatRev = strtok ( cDescRevision, ";" );
	newPatRev = strtok ( cRevSeq, ";" );
	//newPatRev = strtok ( cDescRevision, ";" );
	newPatSeq = strtok ( NULL, ";" );

	printf("TCDCRevision=%s\n",newPatRev);fflush(stdout);
	printf("TCDCSequence=%s\n",newPatSeq);fflush(stdout);
	


	//if( strcmp(desc.revision_id,"NR")!=0 )
	if( strcmp(newPatRev,"NR")!=0 )
	{
		ITK_CALL(AOM_ask_value_string(*objTag,"t5_DocRemarks",&sModelDescription));
		if(tc_strcmp(sModelDescription,"")==0)
		{
			tc_strcpy(sModelDescription,"NULL");
		}
	}
	else
	{
		tc_strcpy(sModelDescription,"NULL");
	}
	tc_strcpy(sKeywordDescription,"NULL");
	tc_strcpy(sAddonDescription,"NULL");
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_ProjectCode",&sProjectCode));
	if(tc_strcmp(sProjectCode,"")==0)
	{
		tc_strcpy(sProjectCode,"NULL");
	}
	//ITK_CALL(AOM_ask_value_string(*objTag,"t5_DesignGrp",&sDesignGroup));
	ITK_CALL(AOM_UIF_ask_value(*objTag,"t5_DesignGrp",&sDesignGroup));
	if(tc_strcmp(sDesignGroup,"")==0)
	{
		tc_strcpy(sDesignGroup,"NULL");
	}
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_Material",&sMaterialInDrawing));
	if(tc_strcmp(sMaterialInDrawing,"")==0)
	{
		tc_strcpy(sMaterialInDrawing,"NULL");
	}
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_MThickness",&sMaterialThickness));
	if(tc_strcmp(sMaterialThickness,"")==0)
	{
		tc_strcpy(sMaterialThickness,"NULL");
	}
	tc_strcpy(sMaterialClass,"NULL");
	tc_strcpy(sYield,"NULL");
	ITK_CALL(AOM_ask_value_double(*objTag,"t5_Weight",&dEnteredWeight));
	if(dEnteredWeight==0)
	{
		dEnteredWeight = 0;
	}
	ITK_CALL(AOM_ask_value_double(*objTag,"t5_SurfaceArea",&dSurfaceArea));
	if(dSurfaceArea==0)
	{
		dSurfaceArea = 0;
	}
	ITK_CALL(AOM_ask_value_double(*objTag,"t5_Volume",&dVolume));
	if(dVolume==0)
	{
		dVolume = 0;
	}
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_EnvelopeDimensions",&sEnvelopeDimensions));
	if(tc_strcmp(sEnvelopeDimensions,"")==0)
	{
		tc_strcpy(sEnvelopeDimensions,"NULL");
	}
	tc_strcpy(sPartCategory,"NULL");


	sprintf(sSequence,"%d",iSequence);

	printf("\nTCDCPartNumber=%s\n",Item_id);fflush(stdout);
	tc_strcpy(sRevision,desc.revision_id);fflush(stdout);
	//printf("TCDCRevision=%s\n",sRevision);fflush(stdout);
	printf("TCDCRevision=%s\n",newPatRev);fflush(stdout);
	//printf("TCDCSequence=%s\n",sSequence);fflush(stdout);
	printf("TCDCSequence=%s\n",newPatSeq);fflush(stdout);
	printf("TCDCDescription=%s\n",sDescription);fflush(stdout);
	printf("TCDCPart Type=%s\n",sPartType);fflush(stdout);
	printf("TCDCModel Description=%s\n",sModelDescription);fflush(stdout);
	printf("TCDCKeyword Description=%s\n",sKeywordDescription);fflush(stdout);	//?
	printf("TCDCAddon Description=%s\n",sAddonDescription);fflush(stdout);		//?
	printf("TCDCProject Code=%s\n",sProjectCode);fflush(stdout);
	printf("TCDCDesign Group=%s\n",sDesignGroup);fflush(stdout);
	printf("TCDCMaterial In Drawing=%s\n",sMaterialInDrawing);fflush(stdout);
	printf("TCDCMaterial Thickness=%s\n",sMaterialThickness);fflush(stdout);
	printf("TCDCMaterial Class=%s\n",sMaterialClass);fflush(stdout);			//?		t5_MatlClass
	printf("TCDCYield=%s\n",sYield);fflush(stdout);					//?
	printf("TCDCEntered Weight=%.3f\n",dEnteredWeight);fflush(stdout);
	printf("TCDCRollup Weight=%.3f\n",dRollupWeight);	fflush(stdout);		//?
	printf("TCDCSurface Area=%.3f\n",dSurfaceArea);fflush(stdout);
	printf("TCDCVolume=%.3f\n",dVolume);fflush(stdout);
	printf("TCDCEnvelope Dimensions=%s\n",sEnvelopeDimensions);fflush(stdout);
	printf("TCDCPart Category=%s\n",sPartCategory);fflush(stdout);			//?		t5_ItmCategory


	/*TcDcEnvName = getenv("TCDC_LOGPATH");
	printf("\nTCDCTcDcEnvName:%s in getTcPartDetails",TcDcEnvName);fflush(stdout);
	if( stat( TcDcEnvName, &info ) != 0 )
	{
		printf("\nTCDCcannot access %s\n", TcDcEnvName );fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH");
		return ITK_errStore;
	}
	else if( info.st_mode & S_IFDIR )
	{
		printf("\nTCDC%s is a directory\n", TcDcEnvName );fflush(stdout);
	}
	else
	{
		printf("\nTCDC%s is not a directory\n", TcDcEnvName );fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH");
		return ITK_errStore;
	}*/

	if(PREF_ask_char_value("TCDC_LOGPATH", 0 , &TcDcEnvName )!=ITK_ok)PrintErrorStack();
	printf ( "\nenvName%s", TcDcEnvName ) ;

	printf("\nTCDCPlease check TCDC_LOGPATH %s\n",TcDcEnvName);fflush(stdout);

	if(!TcDcEnvName)
	{
		printf("\nTCDCcannot access in getTcPartDetails envname:%s\n", TcDcEnvName );fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH!!!...");
		return ITK_errStore;
	}

	//sprintf(sStagingDir,"%s/%s_%s_%s_%s",TcDcEnvName,Item_id,sRevision,sSequence,ptimestamp);
	sprintf(sStagingDir,"%s/%s_%s_%s_%s",TcDcEnvName,Item_id,newPatRev,newPatSeq,ptimestamp);
	printf("\nTCDCsStagingDir:%s in getTcPartDetails",sStagingDir);fflush(stdout);
	if(mkdir(sStagingDir,00777)==-1)
	{
		printf("\nTCDCerror creating directory inside staging directory\n");fflush(stdout);

	}
	sprintf(sPLMProperties,"%s/PLMProperties.txt",sStagingDir);
	printf("\nTCDCsStagingDir:%s",sStagingDir);fflush(stdout);
	printf("\nTCDCtimestamp:%s",ptimestamp);fflush(stdout);
	printf("\nTCDCsPLMProperties:%s",sPLMProperties);fflush(stdout);

	fpPLMProperties = fopen(sPLMProperties,"w");
	if(fpPLMProperties == NULL)
	{
		printf("\nTCDCUnable to create PLMProperties.txt in staging directory");fflush(stdout);
		return ITK_err;
	}


	fprintf(fpPLMProperties,"PartNumber=%s\n",Item_id);fflush(stdout);
	//fprintf(fpPLMProperties,"Revision=%s\n",sRevision);fflush(stdout);
	fprintf(fpPLMProperties,"Revision=%s\n",newPatRev);fflush(stdout);
	//fprintf(fpPLMProperties,"Sequence=%s\n",sSequence);fflush(stdout);
	fprintf(fpPLMProperties,"Sequence=%s\n",newPatSeq);fflush(stdout);
	fprintf(fpPLMProperties,"Description=%s\n",sDescription);fflush(stdout);
	fprintf(fpPLMProperties,"Part Type=%s\n",sPartType);fflush(stdout);
	fprintf(fpPLMProperties,"Model Description=%s\n",sModelDescription);fflush(stdout);
	fprintf(fpPLMProperties,"Keyword Description=%s\n",sKeywordDescription);fflush(stdout);	//?
	fprintf(fpPLMProperties,"Addon Description=%s\n",sAddonDescription);fflush(stdout);		//?
	fprintf(fpPLMProperties,"Project Code=%s\n",sProjectCode);fflush(stdout);
	fprintf(fpPLMProperties,"Design Group=%s\n",sDesignGroup);fflush(stdout);
	fprintf(fpPLMProperties,"Material In Drawing=%s\n",sMaterialInDrawing);fflush(stdout);
	fprintf(fpPLMProperties,"Material Thickness=%s\n",sMaterialThickness);fflush(stdout);
	fprintf(fpPLMProperties,"Material Class=%s\n",sMaterialClass);fflush(stdout);			//?		t5_MatlClass
	fprintf(fpPLMProperties,"Yield=%s\n",sYield);fflush(stdout);					//?
	fprintf(fpPLMProperties,"Entered Weight=%.3f\n",dEnteredWeight);fflush(stdout);
	fprintf(fpPLMProperties,"Rollup Weight=%.3f\n",dRollupWeight);fflush(stdout);			//?
	fprintf(fpPLMProperties,"Surface Area=%.3f\n",dSurfaceArea);fflush(stdout);
	fprintf(fpPLMProperties,"Volume=%.3f\n",dVolume);fflush(stdout);
	fprintf(fpPLMProperties,"Envelope Dimensions=%s\n",sEnvelopeDimensions);fflush(stdout);
	fprintf(fpPLMProperties,"Part Category=%s\n",sPartCategory);fflush(stdout);			//?		t5_ItmCategory
	fclose(fpPLMProperties);
	return ITK_ok;

}
extern DLLAPI int checkin_method_1(METHOD_message_t *m, va_list args)
{
	const char *prog_name = "checkin_method_1";
    tag_t objTag = va_arg(args, tag_t);
	tag_t reln_type =NULLTAG;
	tag_t reln_type1 =NULLTAG;
	int n_attchs,nattchs,n_attchsd,n_attchs1,i=0,referencenumberfound=0, referencenumberfound1=0,j=0,TCDCControlFlag=0,errorflag=0;
	AE_reference_type_t reftype;
	AE_reference_type_t reftype1;
	char *ret_id,*ret_rev;
	tag_t *secondary_objects,*sec_objects,*secondary_objectsd,*secondary_objects1,primary,primaryd,primary1,Childobject,refobject,refobject1,objTypeTag,objTypeTagDi,objTypeTagDid,objTypeTag1,ChildobjTypeTag1,objTypeTagW,objTypeRefTag=NULLTAG;
	
	tag_t *children1=NULLTAG;
	tag_t *ChildRevobject=NULLTAG;
	char refname[AE_reference_size_c + 1];
	char refname1[AE_reference_size_c + 1];
	char orig_name[IMF_filename_size_c + 1];
	char orig_nameW[IMF_filename_size_c + 1];
	char path_name[SS_MAXPATHLEN];
	char ownFilenamePass[SS_MAXPATHLEN];
	//char ownFilenamePass[IMF_filename_size_c+1];
	char ownFilename[IMF_filename_size_c+1];
	char path_nameW[SS_MAXPATHLEN];
	char type_name[TCTYPE_name_size_c+1];
	char type_name2[TCTYPE_name_size_c+1];
	char type_name2d[TCTYPE_name_size_c+1];
	char type_name_ref[TCTYPE_name_size_c+1];
	char child_type_name[TCTYPE_name_size_c+1];
	char type_name1[TCTYPE_name_size_c+1];
	WSO_description_t desc;
	//tag_t  sequence_id_c;
//	char envName[500];
//	char TmpenvName[500];
	//char envName1[500];
	//int n = 0;
	int sequence_id_c=0,Item_Type=0,j1=0,Item_RevisionW=0,Item_IDW=0,counter=0,CatPrtCN=0,ProPrtCN=0,CatPrdt=0;
	int CmiDrwCnt = 0;
	char *objName=NULL,*Item_Revision_strW,*Item_Type_str,*Item_ID_strW=NULL;
	char *Item_id=NULL;
	char *Item_idOwn=NULL;
	char *ModDes=NULL;
	char *projcode=NULL;
	char *desgrp=NULL;
	char *parttyp=NULL;
	char *PartType123=NULL;
	char *PatSeq,*TempTcPrtFile= NULL;
//	FILE *fp = NULL;
	FILE *fp1 = NULL;
//	FILE *fp2 = NULL;
	FILE *fpSrc = NULL;
	FILE *fpDest = NULL;
	IMF_file_t ft;
	double tempd=0;
	char line1[20000];
	char *Finalline=NULL;
	char *Finalline1=NULL;
	char *tmp1=NULL;
	char *envName1=NULL;
	char *Name=NULL;
	char *TmpenvName = NULL;
	char *envName = NULL;
	char *envNameCpy = NULL;
	char *ShellInpFilePath = NULL;

	char *envOrignal=NULL;
	char *FileName=NULL;
	char *ShellFileName=NULL;
	char *TempFile=NULL;
	char *tempS=NULL;
	char *DrnInd=NULL;
	char *MdlInd=NULL;
	char buf[20000];
	char command[100];
	char *JTTransFileName=NULL;
	char *PDFTransFileName=NULL;
	tag_t window, window2, rule,rule1, item_tag = null_tag, top_line,top_line1;
	tag_t t_BomLineWindow, t_Rule, t_ItemTag = null_tag, t_TopLine,t_Childobject=NULLTAG,t_ChildObjType; //Abhishek
	tag_t t_Window, t_RRule, ItemTag = null_tag, t_TLine,t_ChldObj=NULLTAG,t_ChldObjType; //Abhishek

	tag_t *t_PartChildren;//Abhishek
	tag_t *t_PrtChldren;//Abhishek
	tag_t t_ChildItemRev,t_ChildRev,ItemMasterTag=NULLTAG;//Abhishek
	int i_ChildCount= 0,iChldPrts=0,iItemType=0,iItemRevId=0,iItemId=0,iChildItemTag=0,iChdItemTag=0;//Abhishek
	int ChildCount= 0;
	int ItemType=0;
	int kk=0;
	int i_ChildSeq= 0,ChldSeq= 0,iItemChkdOut=0;//Abhishek
	int iChildPartChkOutFlag=0;//Abhishek
	logical	b_ChildChkOutValue ;//Abhishek
	logical	is_final=0 ;//Abhishek
	char ca_ChildType_Name[TCTYPE_name_size_c+1];//Abhishek
	char ChildType_Name[TCTYPE_name_size_c+1];//Abhishek
	char *cp_ItemType_str=NULL;//Abhishek
	char *ItemType_str=NULL;//Abhishek
	char *cp_ItemID_str=NULL;//Abhishek
	char *cp_ItemRev_str=NULL;//Abhishek
	char *cp_ChildSeq,*cp_ChildChkOutValue,*Desc_obj=NULL;//Abhishek
	tag_t projobj;
	tag_t objMasterTag;
	tag_t *tags_found,*referencers,*Objects_Found = NULLTAG;
    int n_tags_found= 0,n_tags_found1=0,cnt,k=0,n_refs=0;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
    char **attrs1 = (char **) MEM_alloc(1 * sizeof(char *));
    char **values1 = (char **) MEM_alloc(1 * sizeof(char *));
//	char relative_path[IMF_relative_path_size_c+1];
	char task_name[WSO_name_size_c+1];
	time_t now;
	struct tm *timeinfo;
	char timestamp[20] = { 0 };
	char* ptimestamp = NULL;
	char* username;
	char **relations=NULL;
	tag_t user_tag=NULLTAG;
	//Assign to project
	char *ObjProject = NULL;
	int *levels,p=0;
	char* TcDcShellEnvName = NULL;
	struct stat info;

	char* sDesignGroup = NULL;
	char* sPartType = NULL;
	tag_t owning_user = NULLTAG;
	char userid[SA_user_size_c+1];
	int n;
	tag_t *children;
	char* sComponentType = NULL;
	char* sIsCatiaComp = NULL;
	int ifail = ITK_ok;
	char cDescRevision[WSO_name_size_c+1] = { "" };
	char *newPatRev = NULL;
	char *newPatSeq = NULL;
	char*  cRevSeq = NULL;
	char* AttributeNullList = NULL ;

//validation on check in
	char	*Desc_obj2	= NULL;
	char   *sObjTagMatDrw=NULL;
	char   *sObjTagDrwInd=NULL;
    char   *sPartStatus	 =NULL;
    char   *sPartType1	 =NULL;
    char   *sCatName	 =NULL;
    char   *sDesignGrp	 =NULL;
    char   *ItemDesc	 =NULL;
	logical	SpareInd1	= false;
	char   *SpareCriteria1	=NULL;
    char   *RefPartNumber1	=NULL;
    char   *MThickness		=NULL;
	char   *TempVal			=NULL;
	char   *EnvelopeDim		=NULL;
	int y		= 0;
	int counter1	= 0;
	int             ir,im =0;
	double objWeightVal ;
	char wgtstr[100];
	int left=0;
	int right=0;
	int             PrtNumTplobo;
	
	sDesignGrp = malloc(10 * sizeof (char *) );
	TempVal=(char *) MEM_alloc(1000);
//validation on check in end


	char * SpareCriteria = NULL;  //Adi - PPart
  //char * SpareInd	     = NULL;  //Adi - PPart
	char * RefPartNumber = NULL;  //Adi - PPart

	logical	SpareInd	 = false;

	/************** Adi CMI 1.26**************/

	char * catiasynch	 = NULL;     
	tag_t	queryTag	 = NULLTAG;  
	int		n_entries	 = 1;	     
	char *qry_entries[1] = {"SYSCD"};
	char **qry_values    = (char **) MEM_alloc(10 * sizeof(char *)); 
	int		resultCount	 = 0;	    
	tag_t	*rev		 = NULLTAG; 
	char	*itemId		 = NULL;	
	tag_t *CntrlObjectTag=NULLTAG;	
	char cmi_name[TCTYPE_name_size_c+1];  
	tag_t	cmiprimary	     = NULLTAG;   
	int		ij,jj,flag		 = 0;		  
	tag_t	cmiobjTypeTagDi	 = NULLTAG;   
	tag_t	*cmi_objects	 = NULLTAG;  

     /************* Adi CMI 1.26 *************/

	char *bl_objectString = NULL;
	int	BomViewCnt = 0;
	tag_t	*BomViewList = NULLTAG;
	int partlength	       = 0;
	int item_seq=0;

	tag_t  itemrev1;

	//LH/RH Attribute declare
	char * ItemLhRhInd;
	char * DatasetName =NULL;
	int HasSymPrt=0;
	//char last_mod_user[SA_user_size_c+1];
	//tag_t a_mod_user = NULLTAG;
	int filelinecount = 0;
	char* gov_classification = NULL;
	char *FirstEightDig=NULL;

	static int          trans_sched_priority        = 0;
	static char        *trans_provider_name         = NULL;
	static char        *trans_service_name          = NULL;
	static char        *trans_type                  = NULL;
	static int          num_dataset_type_names      = 0;
	static char       **dataset_type_names          = NULL;
	static int          num_trans_args              = 0;
	static char       **trans_args                  = ( char ** )0;
	
	tag_t                     trans_rqst        = NULLTAG;
	AttributeNullList = (char* ) malloc ( 500 * sizeof ( char ) ) ;

	tc_strcpy ( AttributeNullList, "Please find List of Mandatory Attributes :" );

	printf("\nTCDCcheckin_method_1 for PRO-e\n");fflush(stdout);

	if( AOM_ask_value_string(objTag,"gov_classification",&gov_classification)!=ITK_ok)PrintErrorStack();
	printf("\ngov_classification:%s",gov_classification);fflush(stdout);

	if ( tc_strcmp(gov_classification, "Cancel_CheckOut" ) == 0)	
	{
		return ITK_ok;
	}


	POM_get_user(&username,&user_tag);

	if(strcmp(username,"loader")==0)
	{
		printf("\nTCDCThis is loader login");fflush(stdout);
		goto BYPASSLOADER;
	}
	else
	{
		printf("\nTCDCnot a loader login");fflush(stdout);
	}

	printf("\nTCDCWelcome :[%s]",username);fflush(stdout);
	time(&now);
	timeinfo = localtime(&now);
	//strftime(timestamp, 20, "%d%m%Y_%H%M%S", d);
	strftime(timestamp, 20, "%Y-%m-%d-%H_%M_%S", timeinfo);
	//sprintf(timestamp,"2015-06-05-02_46_01");
	printf("\nTCDCIt's the time to stamp %s\n", timestamp);fflush(stdout);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok)PrintErrorStack();

	printf("\nTCDCStarted for type_name allow only for selected class for Pro:%s\n", type_name);fflush(stdout);
	
	//if(strcmp(type_name,"ProPrt")!=0)
	if ( strstr ( type_name, "Pro" ) == NULL )
	{
		sDesignGroup = malloc(10 * sizeof (char *) );
		sPartType = malloc(25 * sizeof (char *) );

		//ITK_CALL(AOM_ask_value_string(objTag,"t5_DesignGrp",&sDesignGroup));
		ITK_CALL(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&sDesignGroup));
		if(tc_strcmp(sDesignGroup,"")==0)
		{
			tc_strcpy(sDesignGroup,"NULL");
		}

		//ITK_CALL(AOM_ask_value_string(objTag,"t5_PartType",&sPartType));
		ITK_CALL(AOM_UIF_ask_value(objTag,"t5_PartType",&sPartType));
		if(tc_strcmp(sPartType,"")==0)
		{
			tc_strcpy(sPartType,"NULL");
		}

		//ITK_CALL( AOM_ask_owner( objTag, &owning_user ));
		//ITK_CALL( SA_ask_user_identifier(owning_user,userid) );

		if(AOM_ask_last_modifier(objTag,&owning_user)!=ITK_ok)PrintErrorStack();
		if(SA_ask_user_identifier(owning_user,userid)!=ITK_ok)PrintErrorStack();
		printf("\nlast_mod_user:%s",userid);fflush(stdout);
				

		printf("\nTCDCDesign Group not for PROE: %s Part Type: %s Owner:%s\t",sDesignGroup,sPartType,userid);fflush(stdout);

		if(strcmp(type_name,"T5_DummyPartRevision")==0)
		{
			if( AOM_ask_value_string(objTag,"item_id",&Item_id)!=ITK_ok)PrintErrorStack();

			PatSeq = malloc(3);
			sprintf(PatSeq,"%d",sequence_id_c);

			if (WSOM_describe(objTag, &desc) !=ITK_ok)   PrintErrorStack();
			printf("TCDCItem_id:              %s\n", Item_id);fflush(stdout);
			printf("TCDCObject Typee:     %s\n", desc.object_type);fflush(stdout);
			printf("TCDCRevision IDD:     %s\n", desc.revision_id);fflush(stdout);
			printf("TCDCSequence IDD(PatSeq):     %s\n", PatSeq);fflush(stdout);
		
			tc_strcat(AttributeNullList,Item_id);
			tc_strcat(AttributeNullList,"/");
			tc_strcat(AttributeNullList,desc.revision_id);
			printf("\n AttributeNullList : %s",AttributeNullList);

			ITK_CALL(AOM_UIF_ask_value(objTag,"item_revision_id",&cRevSeq));
			printf("TCDCAOM_UIF_ask_value cRevSeq:     %s\n", cRevSeq);fflush(stdout);

			//tc_strcpy ( cDescRevision, desc.revision_id );
			//printf("\ncDescRevision:%s",cDescRevision);
			//newPatRev = strtok ( cDescRevision, ";" );
			newPatRev = strtok ( cRevSeq, ";" );
			newPatSeq = strtok ( NULL, ";" );

			printf("\nnewPatRev1:%s",newPatRev);fflush(stdout);
			printf("\nnewPatSeq1:%s",newPatSeq);fflush(stdout);

			if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
			printf("\nTCDCNo of DI :%d\n",n_attchs);fflush(stdout);
			if(n_attchs>0)
			{
				for (i = 0; i < n_attchs; i++)
				{
					primary=secondary_objects[i];
					if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
					if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
					printf("\nTCDCtype_name2 for the input is new:%s\n",type_name2);fflush(stdout);
					if(strcmp(type_name2,"CMI2Drawing")==0 || strcmp(type_name2,"ProDrw")==0)
					{
					   counter++;
					}
					if(strcmp(type_name2,"CMI2Part")==0 )
					{
					   CatPrtCN++;
					}
					if(strcmp(type_name2,"CMI2Product")==0 && strcmp(sPartType,"Assembly")==0 )
					{
					   CatPrdt++;
					}
					if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0)
					{
					   ProPrtCN++;
					}
					if(strcmp(type_name2,"CMI2Drawing")==0)
					{
					   CmiDrwCnt++;
					}
				}
			}
			//CatPrtCN++;
			printf("\nTCDCcounter :%d\n",counter);fflush(stdout);
			printf("\nTCDCCatPrtCN :%d\n",CatPrtCN);fflush(stdout);
			printf("\nTCDCCatPrdt :%d\n",CatPrdt);fflush(stdout);
			printf("\nTCDCProPrtCN :%d\n",ProPrtCN);fflush(stdout);
			printf("\nTCDCCmiDrwCnt :%d\n",CmiDrwCnt);fflush(stdout);

		}


		if(strcmp(type_name,"Design Revision")==0 ||strcmp(type_name,"ItemRevision")==0 )
		{
			if( AOM_ask_value_int(objTag,"sequence_id",&sequence_id_c)!=ITK_ok)PrintErrorStack();
			if( AOM_ask_value_string(objTag,"item_id",&Item_id)!=ITK_ok)PrintErrorStack();

			PatSeq=malloc(3);
			sprintf(PatSeq,"%d",sequence_id_c);

			if (WSOM_describe(objTag, &desc) !=ITK_ok)   PrintErrorStack();
			printf("\nTCDCItem_id:              %s\n", Item_id);fflush(stdout);
			printf("TCDCObject Type:     %s\n", desc.object_type);fflush(stdout);
			printf("TCDCRevision ID:     %s\n", desc.revision_id);fflush(stdout);
			printf("TCDCSequence ID(PatSeq):     %s\n", PatSeq);fflush(stdout);
			
			tc_strcat(AttributeNullList,Item_id);
			tc_strcat(AttributeNullList,"/");
			tc_strcat(AttributeNullList,desc.revision_id);
			printf("\n AttributeNullList : %s",AttributeNullList);

			ITK_CALL(AOM_UIF_ask_value(objTag,"item_revision_id",&cRevSeq));
			printf("TCDCAOM_UIF_ask_value cRevSeq:     %s\n", cRevSeq);fflush(stdout);
		
			//tc_strcpy ( cDescRevision, desc.revision_id );
			//printf("\ncDescRevision:%s",cDescRevision);
			//newPatRev = strtok ( cDescRevision, ";" );
			newPatRev = strtok ( cRevSeq, ";" );
			newPatSeq = strtok ( NULL, ";" );

			printf("TCDCnewPatRev3:     %s\n", newPatRev);fflush(stdout);
			printf("TCDCnewPatSeq3:     %s\n", newPatSeq);fflush(stdout);

			//if( AOM_ask_value_string(objTag,"t5_PartType",&parttyp)==ITK_ok)PrintErrorStack();
			if( AOM_UIF_ask_value(objTag,"t5_PartType",&parttyp)==ITK_ok)PrintErrorStack();
			printf("TCDCt5_PartType :     %s\n", parttyp);fflush(stdout);

			/*********************************************************************************/
			//added by Hanuman
			
			if(AOM_ask_value_string(objTag,"object_string",&bl_objectString));
			printf("\n\t object_string => %s\n",bl_objectString);fflush(stdout);

			if(ITEM_rev_list_bom_view_revs(objTag,&BomViewCnt,&BomViewList)!=ITK_ok)PrintErrorStack();
			printf("\n\t Count of BomView [%d]\n",BomViewCnt);fflush(stdout);

			/*Getting ChildParts through BOM LINE*/
			if(BOM_create_window (&t_Window) !=ITK_ok) PrintErrorStack();
			if(CFM_find( "Latest Working", &t_RRule )!=ITK_ok) PrintErrorStack();
			if(BOM_set_window_config_rule( t_Window, t_RRule )!=ITK_ok) PrintErrorStack();
			if(BOM_set_window_pack_all (t_Window, true)!=ITK_ok) PrintErrorStack();
			if(BOM_set_window_top_line (t_Window, ItemTag, objTag, null_tag, &t_TLine)!=ITK_ok) PrintErrorStack();
			if(BOM_line_ask_child_lines (t_TLine, &ChildCount, &t_PrtChldren)!=ITK_ok) PrintErrorStack();
			printf("\n [Hanuman]=> Child Parts Found in BomLine are :: [%d]\n",ChildCount);fflush(stdout);
						
			if((ChildCount > 0) && (tc_strcmp(parttyp,"Component")==0)) 
			{
				printf("\n\t Select revision having BVR");fflush(stdout);
				
				if(EMH_store_error_s3(EMH_severity_error,ITK_errStore,"\n Cmponent can't have Structure","Please check parttype of",bl_objectString)!=ITK_ok)PrintErrorStack();
								
				return ITK_errStore;

			}else
			printf("\n\t Select revision is nither Cmponent nor having BVR");fflush(stdout);
			
			/*********************************************************************************/


			counter=0;
			CatPrtCN=0;
			ProPrtCN=0;
			if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
			printf("\nTCDCNo of DI :%d\n",n_attchs);fflush(stdout);
			if(n_attchs>0)
			{
				for (i= 0; i < n_attchs; i++)
				{
					primary=secondary_objects[i];
					if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
					if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
					printf("\nTCDCtype_name2 for the input is new:%s\n",type_name2);fflush(stdout);
					if((tc_strcmp(type_name2,"CMI2Drawing")==0) || (tc_strcmp(type_name2,"ProDrw")==0))
					{
					   counter++;
					}
					if(tc_strcmp(type_name2,"CMI2Part")==0 )
					{
					   CatPrtCN++;
					}
					if((tc_strcmp(type_name2,"CMI2Product")==0)  && (tc_strcmp(parttyp,"Assembly")==0) )//previously it was A
					{
					   CatPrdt++;
					}
					if((tc_strcmp(type_name2,"ProPrt")==0) || (tc_strcmp(type_name2,"ProAsm")==0))
					{
					   ProPrtCN++;
					}
				}
			}
			//CatPrtCN++;
			printf("\nTCDCcounter :%d\n",counter);fflush(stdout);
			printf("\nTCDCCatPrtCN :%d\n",CatPrtCN);fflush(stdout);
			printf("\nTCDCCatPrdt :%d\n",CatPrdt);fflush(stdout);
			printf("\nTCDCProPrtCN :%d\n",ProPrtCN);fflush(stdout);

			//Modification Description (t5_DocRemarks) cannot be null for revision other than "NR"
			//if( strcmp(desc.revision_id,"NR")!=0 )
			if((tc_strcmp(newPatRev,"NR")!=0) || ((tc_strcmp(newPatRev,"NR")==0) && (tc_strcmp(newPatSeq,"1")!=0)))
			{
				//printf("TCDCRevision ID for Mod Desc %s\n", desc.revision_id);fflush(stdout);
				printf("TCDCRevision ID for Mod Desc %s\n", newPatRev);fflush(stdout);
				if( AOM_ask_value_string(objTag,"t5_DocRemarks",&ModDes)!=ITK_ok)PrintErrorStack();
				printf("TCDCMod Desc %s\n", ModDes);fflush(stdout);
				if( strcmp(ModDes,"")==0 )
				{
					printf("TCDCMod Desc is null\n");fflush(stdout);
					///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Modification Description");
					///return ITK_errStore;
					tc_strcat ( AttributeNullList, "Modification Description" );
					errorflag=errorflag+1;
				}

			}

			if( AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)==ITK_ok)
			printf("\nTCDCProject from Object : %s\n",projcode);fflush(stdout);

			if(strcmp(projcode,"")==0)
			{
				printf("\nTCDCBefore Project null error\n");fflush(stdout);
				///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Project Code");
				///return ITK_errStore;
				tc_strcat ( AttributeNullList, ", Project Code" );
				errorflag=errorflag+1;
			}
			else
			{
				printf("\nTCDCProject from Object in else : %s\n",projcode);fflush(stdout);

				if (PROJ_find(projcode,&projobj) !=ITK_ok)PrintErrorStack();

				if(projobj != NULLTAG)
				{
					printf("\nTCDCGetting Master Object for Project\n");fflush(stdout);
					if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok)PrintErrorStack();
					printf("\nTCDCAfter Master Object for Project\n");fflush(stdout);
					if (PROJ_assign_objects(1 ,&projobj ,1 ,&objMasterTag )!=ITK_ok)PrintErrorStack();
					printf("\nTCDCAssigned to Project\n");fflush(stdout);
				}
				else
				{
					printf("\nTCDCProject not found\n");fflush(stdout);
				}
			}

			//if( AOM_ask_value_string(objTag,"t5_DesignGrp",&desgrp)==ITK_ok)
			if(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&desgrp)==ITK_ok)
			{
				printf("TCDCchecking t5_DesignGrp.........");fflush(stdout);
				if(strcmp(desgrp,"")==0)
				{
					///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Design Group");
					///return ITK_errStore;
					tc_strcat ( AttributeNullList, ", Design Group" );
					errorflag=errorflag+1;
				}
			}

			//if( AOM_ask_value_string(objTag,"t5_PartType",&parttyp)==ITK_ok)
			if( AOM_UIF_ask_value(objTag,"t5_PartType",&parttyp)==ITK_ok)
			{
				printf("\nTCDCchecking my attribute.........");fflush(stdout);
				if(strcmp(parttyp,"")==0)
				{
					///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Part Type");
					///return ITK_errStore;
					tc_strcat ( AttributeNullList, ", Part Type" );
					errorflag=errorflag+1;
				}
			}
			if(CatPrdt==0 && CatPrtCN!=0)
			{
				if( AOM_ask_value_string(objTag,"t5_EnvelopeDimensions",&tempS)==ITK_ok)
				{
					if(strcmp(tempS,"")==0)
					{
						///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Envelope Dimensions");
						///return ITK_errStore;
						tc_strcat ( AttributeNullList, ", Envelope Dimensions" );
						errorflag=errorflag+1;
					}
				}

				if( AOM_ask_value_double(objTag,"t5_Volume",&tempd)==ITK_ok)
				{
					if(strcmp(tempS,"")==0)
					{
						///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Volume in CuMtr");
						///return ITK_errStore;
						tc_strcat ( AttributeNullList, ", Volume in CuMtr" );
						errorflag=errorflag+1;
					}
				}

				if( AOM_ask_value_string(objTag,"t5_MThickness",&tempS)==ITK_ok)
				{
					if(tempS==0)
					{
						///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Thickness in mm");
						///return ITK_errStore;
						tc_strcat ( AttributeNullList, ", Material Thickness in mm" );
						errorflag=errorflag+1;
					}
				}

				if( AOM_ask_value_string(objTag,"t5_SurfPrtStd",&tempS)==ITK_ok)
				{
					if(strcmp(tempS,"")==0)
					{
						///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Surface Protection Std");
						///return ITK_errStore;
						tc_strcat ( AttributeNullList, ", Surface Protection Std" );
						errorflag=errorflag+1;
					}
				}

				if( AOM_ask_value_double(objTag,"t5_SurfaceArea",&tempd)==ITK_ok)
				{
					if(tempd==0)
					{
						///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Surface Area in SqMtr");
						///return ITK_errStore;
						tc_strcat ( AttributeNullList, ", Surface Area in SqMtr" );
						errorflag=errorflag+1;
					}
				}

				if( AOM_ask_value_string(objTag,"t5_Material",&tempS)==ITK_ok)
				{
					if(strcmp(tempS,"")==0)
					{
						///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Part Material");
						///return ITK_errStore;
						tc_strcat ( AttributeNullList, ", Part Material" );
						errorflag=errorflag+1;
					}
				}

				if( AOM_ask_value_double(objTag,"t5_Weight",&tempd)==ITK_ok)
				{
					if(tempd==0)
					{
						///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Weight KG");
						///return ITK_errStore;
						tc_strcat ( AttributeNullList, ", Weight KG" );
						errorflag=errorflag+1;
					}
				}
			}

			if( AOM_ask_value_string(objTag,"object_desc",&tempS)==ITK_ok)
			{
				if(strcmp(tempS,"")==0 )
				{
					///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Description");
					///return ITK_errStore;
					tc_strcat ( AttributeNullList, ", Description" );
					errorflag = errorflag + 1;
				}
			}

			if ( errorflag > 0 )
			{
				printf("\nTCDC.NULL attributes : %s",AttributeNullList);fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_errStore,AttributeNullList);

				return ITK_errStore;

			}

			//validations 
	if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok);PrintErrorStack();
		printf("\n Desc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);
		//Vitthal start
		if( AOM_ask_value_string(objTag,"t5_DrawingInd",&sObjTagDrwInd)!=ITK_ok);PrintErrorStack();
        if( AOM_ask_value_string(objTag,"t5_Material",&sObjTagMatDrw)!=ITK_ok);PrintErrorStack();
        if( AOM_ask_value_string(objTag,"t5_PartStatus",&sPartStatus)!=ITK_ok);PrintErrorStack();
        if( AOM_ask_value_string(objTag,"t5_PartType",&sPartType1)!=ITK_ok);PrintErrorStack();
        if( AOM_ask_value_string(objTag,"t5_CategoryName",&sCatName)!=ITK_ok);PrintErrorStack();
		if(	AOM_UIF_ask_value(objTag,"t5_DesignGrp",&sDesignGrp)!=ITK_ok);PrintErrorStack();
		if(	AOM_ask_value_string(objTag,"object_desc",&ItemDesc)!=ITK_ok);PrintErrorStack();		
		if(	AOM_ask_value_logical(objTag,"t5_SpareInd",&SpareInd1)!=ITK_ok);PrintErrorStack();
		if(	AOM_ask_value_string(objTag,"t5_SpareCriteria",&SpareCriteria1)!=ITK_ok);PrintErrorStack();
		if(	AOM_ask_value_string(objTag,"t5_RefPartNumber",&RefPartNumber1)!=ITK_ok);PrintErrorStack();
		if(	AOM_ask_value_string(objTag,"t5_MThickness",&MThickness)!=ITK_ok);PrintErrorStack();
		if(	AOM_ask_value_string(objTag,"t5_EnvelopeDimensions",&EnvelopeDim)!=ITK_ok);PrintErrorStack();

		printf("\n Drawing Indicator :%s \n Material In Drawing :%s \n Part Status :%s \n Part Type :%s  \n Design Group ",sObjTagDrwInd,sObjTagMatDrw,sPartStatus,sPartType1,sDesignGrp);fflush(stdout);

		if((strcmp(sObjTagDrwInd,"A")==0) || (strcmp(sObjTagDrwInd,"D")==0) )
		{
			if((tc_strcmp(sObjTagMatDrw,"")!=0))	
			{
				printf("\n	Material name is present----->> :%s",sObjTagMatDrw);fflush(stdout);						
			}
			else
			{	
				EMH_store_error_s1(EMH_severity_error,ITK_errStore,"If Drawing Indicator is D/A then Material is Mandatory");
				return ITK_errStore;						
			}
		}
		if(strstr(Desc_obj2,"NR") != NULL) 
		{
			if((strcmp(sPartStatus,"DR4")==0) || (strcmp(sPartStatus,"DR5")==0) ||(strcmp(sPartStatus,"AR4")==0) || (strcmp(sPartStatus,"AR5")==0) )
			{
				EMH_store_error_s1(EMH_severity_error,ITK_errStore,"NR revision part can not be created or updated with DR-status DR4/5 or AR4/5");
				return ITK_errStore;						
				
			}
		}
		if((strcmp(sPartType1,"C")==0))
		{
			if((tc_strcmp(sObjTagMatDrw,"")!=0))	
			{
				printf("\n	Material while Part type comp :%s",sObjTagMatDrw);fflush(stdout);						
			}
			else
			{	
				EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material in drawing can not be NULL for part type Component. Please fill material in drawing");
				return ITK_errStore;						
			}
		}
		
		/*** modification by Anand starts ***/

		//Material Thickness cannot be NULL for part type Component
		//Material thickness can be only Number or NA
		//DOT should not be more than one
		if((tc_strcmp(MThickness,"")==0))
		{
			printf("\n Material Thickness is NULL \n");fflush(stdout);

			if((strcmp(sPartType1,"C")==0))	
			{
				EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Thickness cannot be NULL for part type Component.");
				return ITK_errStore;						
			}

		}
		else
		{
			if(tc_strcmp(MThickness,"NA"))
			{			
				TempVal =strcpy(TempVal,MThickness);
				
				for(y=0;y<tc_strlen(MThickness);y++)
				{
					if (TempVal[y] < 48 || TempVal[y] > 57)
					{	if (TempVal[y] == 46)
						{
							counter1++;
						}else
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Thickness need to have only numbers or it can be NA.");
							return ITK_errStore;	
						}
					}
				}

				if (counter1>0 && counter1<2 && tc_strlen(MThickness)>0 && tc_strlen(MThickness)<2)
				{
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Thickness need to have only numbers or it can be NA.");
					return ITK_errStore;
				}

				if(counter1 >1)
				{
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"DOT should not be more than one for Material Thickness");
					return ITK_errStore;
				}
			
			}

		}

		
		//If Part Category is BTS and Spare Indicator is True, so Party Part number is mandatory
		//if((SpareInd1==1) && tc_strcmp(SpareCriteria1,"BTS")==0 )
		if( tc_strcmp(SpareCriteria1,"BTS")==0 )
		{
			printf("\n Spare Criteria is BTS\n");fflush(stdout);

			if(tc_strcmp(RefPartNumber1,"")==0)
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Part Category is: BTS-Built To Specification, so Party Part number is mandatory");
				return ITK_err; 
			}
		}
		//for spare indicator ='Y' envelope dimension should not be null
		if( SpareInd1==1 )
		{
			printf("\n Spare Indicator is True\n");fflush(stdout);

			if(tc_strcmp(EnvelopeDim,"")==0)
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Envelope Dimensions cannot be null if Spare Indicator is True");
				return ITK_err; 
			}
		}

		if(tc_strstr(ItemDesc,"\n"))
		{
			printf("\n	Description of Design %s \n",ItemDesc);fflush(stdout);	
			EMH_store_error_s1(EMH_severity_error,ITK_errStore,"New Line charecter is not allowed in Desc field.");
			return ITK_errStore;
		}
		//Ashish

		//Mohan start

		if((tc_strlen(ItemDesc)>40) )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Please Fill Only 40 Character In Description As Per SAP/Denis Standards.");
			return ITK_errStore;
			
		}
		//Mohan
		
		if( AOM_ask_value_double(objTag,"t5_Weight",&objWeightVal)==ITK_ok)
			{					
			   if (objWeightVal > 0.0)
				{
					sprintf(wgtstr,"%0.3f",objWeightVal);
					printf("\n wgtstr  = [%s]\n", wgtstr);fflush(stdout);
					sscanf(wgtstr, "%d.%d", &left, &right);
					printf("\n adk left = [%d] adk right = [%d]", left,right);fflush(stdout);
					if(right>0)
					{
						while (right%10==0)
						{
							right=right/10;
						}
					}
					printf("\n adk left = [%d] adk right = [%d]", left,right);fflush(stdout);
					if(left > 99999 || right > 999)					
					{
						printf("\nvalidation to weight\n");fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Weight Value should have a maximum of 5 Digits before the Decimal Point and maximum of 3 digits after the Decimal Point.");	
						printf("\n after validation to weight\n");fflush(stdout);
					   return ITK_errStore;			 
					  
					   
					}
				}	
							
			}

		 /****************************************Anand Kumar Validation*********************************/
	
		 printf("\n PartType-------------- :%s\n",parttyp);fflush(stdout);
		 printf("\n PartNumber-------------- :%s\n",Item_id);fflush(stdout);
		 partlength = tc_strlen(Item_id);
		 printf("\n  partlength--------> %d\n",partlength);fflush(stdout);
		
		 //start TPL validation for having only numbers in first 8 Digits
		 /*
		 if(tc_strcmp(parttyp,"T")==0 && partlength ==11)
		 {
			 FirstEightDig=malloc(15);
			 FirstEightDig=subString(Item_id,0,8);
			 printf("\n  Kumar Anand1--------> %s\n", FirstEightDig);fflush(stdout);
			
			 ir=tc_strlen(FirstEightDig);
			 printf("\n  Kumar Anand1--------> %d\n",ir);fflush(stdout);

			 for(im=0;im<ir;im++)
			 {
				PrtNumTplobo = FirstEightDig[im];
				printf("\n Ascii Values of this string is-->%d\n",PrtNumTplobo);fflush(stdout);

				if(PrtNumTplobo>=48 && PrtNumTplobo<=57)
				{

					printf("\n  inside if loop-------->\n");fflush(stdout);
				}else
				{
					printf("\n  inside else loop-------->\n");fflush(stdout);

					EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Creation of Assembly with Part Type 'TPL' should contain only Numbers in first 10 Digits.");
			
					return ITK_errStore; 

				}

			 }
		 }
		 */
		 /***************************************************************************************/


			//Amol Kale
			//validations 


		/*********************** Adi - Synch from Catia  *********************/
			/*
			qry_values[0]		= itemId ; 

		    if(QRY_find("ControlObjects", &queryTag));

			if (queryTag)
			{
				printf("\n Found Query CMI \n");fflush(stdout);
			}
			else
			{
				printf("\n Not Found Query CMI \n");fflush(stdout);
			}

			qry_values[0] = "IsCatSynch" ;
	
			ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &CntrlObjectTag));

			printf(" \n resultCount :%d:", resultCount); fflush(stdout);

			if(resultCount>0)
			{
				printf("\n Adi Synch from Catia Validation-------------- \n");fflush(stdout);

				if(GRM_list_secondary_objects_only(objTag,reln_type,&jj,&cmi_objects)!=ITK_ok)PrintErrorStack();
				printf("\n cmi_objects :%d\n",jj);fflush(stdout);
	
				if(jj>0)
				{
					for (ij= 0;ij< jj;ij++)
					{
						cmiprimary=cmi_objects[ij];

						if(TCTYPE_ask_object_type(cmiprimary,&cmiobjTypeTagDi))PrintErrorStack();

						if(TCTYPE_ask_name(cmiobjTypeTagDi,cmi_name))PrintErrorStack();

						printf("\n cmi_name for the input is new :%s\n",cmi_name);fflush(stdout);

						if((tc_strcmp(cmi_name,"CMI2Product")==0)||(tc_strcmp(cmi_name,"CMI2Part")==0))
						{
							flag=1;
						}
					}
				}

				if(flag==1)
				{
				   if( AOM_ask_value_string(objTag,"t5_IsCatSynch",&catiasynch)==ITK_ok) 

				   printf("\n catiasynch value is -------------- %s \n",catiasynch);fflush(stdout);

				   if(tc_strcmp(catiasynch ,"Y")==0)
					{
					   printf("\n part has been synched from catia--- so continue \n");fflush(stdout);
					}  
					else
					{
						printf("\n Part has not been synchronised from Catia \n");fflush(stdout);
						//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
						EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Synchronize the part from CATIA and then try to check in");

						return ITK_errStore;
					}			
				}
				else
				{
					 printf("\n NOT A CATIA PART HENCE SKIPPING VALIDATION \n");fflush(stdout);
				}
			}
			else
			{
				printf("\n NO COntrol obj \n");fflush(stdout);
			}

		 */


         /************************* Adi - Synch from Catia  **************************/

		 /****************************************Adi validation for party part*********************************/


           printf("\n Adii -------------- \n");fflush(stdout);

		   if( AOM_ask_value_logical(objTag,"t5_SpareInd",&SpareInd)==ITK_ok) 
				
		   printf("\n SpareInd d-------------- :%d\n",SpareInd);fflush(stdout);

           if( AOM_ask_value_string(objTag,"t5_SpareCriteria",&SpareCriteria)==ITK_ok)

		   printf("\n SpareCriteria -------------- :%s\n",SpareCriteria);fflush(stdout);	

		   if( AOM_ask_value_string(objTag,"t5_RefPartNumber",&RefPartNumber)==ITK_ok)

		   printf("\n RefPartNumber -------------- :%s\n",RefPartNumber);fflush(stdout);

		   if((SpareInd==1) && tc_strcmp(SpareCriteria,"BTS")==0 )
			{
			   printf("\n 222222222222222 \n");fflush(stdout);

                if(tc_strcmp(RefPartNumber,"")==0)
				{
					EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Please enter a valid Party Part Number or make Spare Indicator as False");

					return ITK_errStore; 
				}

			}

		/*****************************************Adi validation for party part ends*********************************/

			if( AOM_ask_value_string(objTag,"t5_DrawingInd",&DrnInd)==ITK_ok)

			//Yogendra
			//if drawing indicator is N and CATDrawing file is attached then it should not be allowd to check in.
			//If drawing indicator is D and CATDrawing file Is not attached then it should not allowd to check in.

			//if( strcmp(DrnInd,"")==0 )
			//{
				printf("\nTCDCTrying to set Drawing Ind since null\n");fflush(stdout);
				printf("\nTCDCcounter :%d\n",counter);fflush(stdout);
				printf("\nDrnInd:%s\n",DrnInd);fflush(stdout);
				if( counter > 0 )
				{
					if( strcmp(DrnInd,"")==0 || strcmp(DrnInd,"N")==0 )
					{
						printf("\nTCDCDrnInd :\n");fflush(stdout);
						if(AOM_lock(objTag))PrintErrorStack();
						if(AOM_set_value_string(objTag,"t5_DrawingInd","D"))PrintErrorStack();
						if(AOM_save(objTag))PrintErrorStack();
						if(AOM_unlock(objTag))PrintErrorStack();
					}
				}
				else
				{
	//				if( strcmp(DrnInd,"")==0 )
	//				{
		       
			       if(tc_strcmp(DrnInd,"A")==0 )// Added by Rajendra TZ 1.28
					{
						printf("\nTCDCElseDrnInd :\n");fflush(stdout);
						printf("\nDrnInd :%s\n",DrnInd);fflush(stdout);
						if(AOM_lock(objTag))PrintErrorStack();
						if(AOM_set_value_string(objTag,"t5_DrawingInd","A"))PrintErrorStack();
						if(AOM_save(objTag))PrintErrorStack();
						if(AOM_unlock(objTag))PrintErrorStack();
					}
					else
					{
						printf("\nTCDCElseDrnInd :\n");fflush(stdout);
						printf("\nDrnInd :%s\n",DrnInd);fflush(stdout);
						if(AOM_lock(objTag))PrintErrorStack();
						if(AOM_set_value_string(objTag,"t5_DrawingInd","N"))PrintErrorStack();
						if(AOM_save(objTag))PrintErrorStack();
						if(AOM_unlock(objTag))PrintErrorStack();
					}
	//
	//					printf("\nTCDCThere is No CATDrawing.\n");fflush(stdout);
	////					EMH_store_error_s1(EMH_severity_warning,ITK_err,"Drawing indicator updated to 'N' since no Drawing file attached.");
	////					errorflag=errorflag+1;
	//				}
	//
	//				if( strcmp(DrnInd,"D")==0 )
	//				{
	//					  printf("\nTCDCThere is No CATDrawing.\n");fflush(stdout);
	//					//  EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Drawing Indicator=D, You must attach drawing or update to 'N'");
	//					  //return ITK_errStore;
	//					  errorflag=errorflag+1;
	//				}
				}

			if( AOM_ask_value_string(objTag,"t5_ModelIndicator",&MdlInd)==ITK_ok)

			printf("\nTCDCTrying to set Model Ind since null\n");fflush(stdout);
			printf("\nTCDCProPrtCN :%d\n",ProPrtCN);fflush(stdout);
			printf("\nTCDCCatPrtCN :%d\n",CatPrtCN);fflush(stdout);
			printf("\nTCDCCatPrdt :%d\n",CatPrdt);fflush(stdout);
			printf("\nTCDCMdlInd :%s\n",MdlInd);fflush(stdout);

			if( ProPrtCN > 0 ) //previously only for proasm or proprt modelind was set 15.04.2016
			//if ( ( ProPrtCN > 0 ) || ( CatPrtCN > 0 ) || ( CatPrdt > 0 ) ) // Borkar is going to inform this discussed on 20.04.2016 in which condition he want to set model indicator
			{
				printf("\nTCDCProPrtCN :\n");fflush(stdout);
				if ( ( strcmp(MdlInd,"")==0 )|| (strcmp(MdlInd,"N")==0 ) )
				{
					if(AOM_lock(objTag))PrintErrorStack();
					if(AOM_set_value_string(objTag,"t5_ModelIndicator","Y"))PrintErrorStack();
					if(AOM_save(objTag))PrintErrorStack();
					if(AOM_unlock(objTag))PrintErrorStack();
				}
			}
			else
			{
				printf("\nTCDCelse of count of ProPrtCN :\n");fflush(stdout);
				if(AOM_lock(objTag))PrintErrorStack();
				if(AOM_set_value_string(objTag,"t5_ModelIndicator","N"))PrintErrorStack();
				if(AOM_save(objTag))PrintErrorStack();
				if(AOM_unlock(objTag))PrintErrorStack();
			}
			//}

			printf("\nTCDC.....errorflag :: %d",errorflag);fflush(stdout);
			if ( errorflag > 0 )
			{
				printf("\nTCDC.....show error....");fflush(stdout);
				//if(EMH_store_error_s3(EMH_severity_error,ITK_errErr,Item_id,desc.revision_id,PatSeq)!=ITK_ok)PrintErrorStack();
				if(EMH_store_error_s3(EMH_severity_error,ITK_errErr,Item_id,newPatRev,newPatSeq)!=ITK_ok)PrintErrorStack();
				
				return ITK_errErr;
			}
			printf("\nTCDC.....no error");fflush(stdout);
			/*************************************code to get PLMProperties.txt***********************************************/
			//ptimestamp = malloc(20);
			//ptimestamp = timestamp;
			//printf("\nTCDCtimestamp:%s",timestamp);
			//printf("\nTCDCptimestamp:%s",ptimestamp);
			printf("\nTCDC Test00:%s",Item_id);fflush(stdout);
			printf("\nTCDCItem_id:%s",Item_id);fflush(stdout);
			printf("\nTCDC Test01:[%s]",Item_id);fflush(stdout);
			if ( ( CatPrtCN > 0 ) || ( CatPrdt > 0 ) || ( CmiDrwCnt > 0) )
			{
				printf("\nTCDC started");
				if ( Item_id )
				{
						printf("\nTCDC Test1:%s",Item_id);fflush(stdout);

						printf("\nTCDCenvName allocate memory");fflush(stdout);
						//envName = (char *)malloc(250 * sizeof(char));
						envNameCpy = (char *)malloc(500 * sizeof(char));
						//envName = getenv("TCDC_LOGPATH");
						
						if(PREF_ask_char_value("TCDC_LOGPATH", 0 , &envName )!=ITK_ok)PrintErrorStack();
						printf ( "\nTCDCenvName:%s", envName ) ;fflush(stdout);

						printf("\nTCDCPlease check TCDC_LOGPATH %s\n",envName);fflush(stdout);

						if(!envName)
						{
							printf("\nTCDCcannot access in checkin_method_1 envname:%s\n", envName );fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH!!!");
							
							return ITK_errStore;
						}

						/*if( stat( envName, &info ) != 0 )
						{
							printf("\nTCDCcannot access in checkin_method_1 envname:%s\n", envName );fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH!!!");
							return ITK_errStore;
						}
						else if( info.st_mode & S_IFDIR )
						{
							printf("\nTCDC%s is a directory\n", envName );fflush(stdout);
						}
						else
						{
							printf("\nTCDC%s is no directory\n", envName );fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH!!!!");
							return ITK_errStore;
						}*/
						//newPatRev = strtok ( desc.revision_id, ";" );
						//newPatSeq = strtok ( NULL, "_" );

						printf("\nnewPatRev2:%s",newPatRev);
						printf("\nnewPatSeq2:%s",newPatSeq);
						
						strcpy(envNameCpy,envName);
						strcat(envNameCpy,"/");
						strcat(envNameCpy,Item_id);
						strcat(envNameCpy,"_");
						strcat(envNameCpy,newPatRev);
						strcat(envNameCpy,"_");
						strcat(envNameCpy, newPatSeq);
						strcat(envNameCpy,"_");
						strcat(envNameCpy,timestamp);
						printf("\nTCDCenvName before system is=>%s\n", envNameCpy);fflush(stdout);
						TmpenvName = malloc(1500);
						strcpy(TmpenvName,envNameCpy);
						printf("\nTCDCTmpenvName  is:%s\n",envNameCpy);fflush(stdout);

						if(mkdir(envNameCpy,00777)==-1)
						{
							printf("\nTCDCerror in creating dir\n");fflush(stdout);

						}
				}

				getTcPartDetails(&objTag,timestamp);
				/*************************************code to get PLMProperties.txt***********************************************/
				printf("\nTCDC FindMismatchInCATProduct.sh check file exist");fflush(stdout);
				//TcDcShellEnvName = malloc(250 * sizeof (char *) );
				//TcDcShellEnvName = getenv("TCDC_SHELL_PATH");
				//printf("\nTCDCTCDC_SHELL_PATH:%s",TcDcShellEnvName);fflush(stdout);

				
				if(PREF_ask_char_value("TCDC_SHELL_PATH", 0 , &TcDcShellEnvName )!=ITK_ok)PrintErrorStack();
			
				printf("\nTCDCPlease check TCDC_SHELL_PATH %s\n",TcDcShellEnvName);fflush(stdout);

				if(!TcDcShellEnvName)
				{
					printf("\nTCDC Shell path not found. Please check TCDC_SHELL_PATH preference!!! envname:%s\n", TcDcShellEnvName );fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"TCDC Shell path not found. Please check TCDC_SHELL_PATH preference!!!");
					
					return ITK_errStore;
				}


				ShellFileName = malloc(250 * sizeof (char *) );
				tc_strcpy(ShellFileName,TcDcShellEnvName);
				tc_strcat(ShellFileName,"/FindMismatchInCATProduct.sh");
				printf("\nTCDCShellFileNamePath:%s",ShellFileName);fflush(stdout);
				fpSrc = fopen(ShellFileName,"r");
				if(fpSrc)
				{
					TCDCControlFlag=1;
					printf("\nTCDCFindMismatchInCATProduct.sh exists\n");fflush(stdout);
					fclose(fpSrc);
				}
				else
				{
					TCDCControlFlag=0;
					printf("\nTCDCError in opening the file fpSrc FindMismatchInCATProduct.sh-- DON't call TCDC programs\n");fflush(stdout);
				}
				printf("\nTCDCTCDCControlFlagis :%d\n",TCDCControlFlag);fflush(stdout);

				if(TCDCControlFlag ==1)
				{
					if (GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)	PrintErrorStack();

					printf("\nTCDCIn method_1:  checking in n_attchs after GRM_list_secondary_objects_only = %d\n", n_attchs);fflush(stdout);
					if(n_attchs>0)
					{
						/*if (Item_id)
						{
								envName = malloc(1500);
								sprintf(envName,"%s",getenv("TCDC_LOGPATH"));///home/cmitest/plmdownload/CATProductMismatch


								printf("\nTCDCPlease check TCDC_LOGPATH %s\n",envName);fflush(stdout);

								if( stat( envName, &info ) != 0 )
								{
									printf("\nTCDCcannot access %s\n", envName );fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH");
									return ITK_errStore;
								}
								else if( info.st_mode & S_IFDIR )
								{
									printf("\nTCDC%s is a directory\n", envName );fflush(stdout);
								}
								else
								{
									printf("\nTCDC%s is no directory\n", envName );fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH");
									return ITK_errStore;
								}

								strcat(envName,"/");
								strcat(envName,Item_id);
								strcat(envName,"_");
								strcat(envName,desc.revision_id);
								strcat(envName,"_");
								strcat(envName, PatSeq);
								strcat(envName,"_");
								strcat(envName,timestamp);
								printf("\nTCDCenvName before system is=>%s\n", envName);fflush(stdout);
								TmpenvName=malloc(1500);
								strcpy(TmpenvName,envName);
								printf("\nTCDCTmpenvName  is:%s\n",TmpenvName);fflush(stdout);

								if(mkdir(envName,00777)==-1)
								{
									printf("\nTCDCerror in creating dir\n");fflush(stdout);

								}
						}*/
						if(Item_id)
						{
							tag_t *tags_found = NULL;
							int n_tags_found= 0;

							attrs[0] ="item_id";
							values[0] = (char *)Item_id;
							printf("\nTCDCvalues[0] for parent is  :%s\n",values[0]);fflush(stdout);
		//						if(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found) !=ITK_ok)PrintErrorStack();
		//						MEM_free(attrs);
		//						MEM_free(values);
		//						if (n_tags_found == 0)
		//						{
		//							printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", Item_id);
		//							exit (0);
		//						}
		//						else if (n_tags_found > 1)
		//						{
		//							MEM_free(tags_found);
		//							EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
		//							printf ( "More than one items matched with id %s\n", Item_id);
		//							exit (0);
		//						}
		//						item_tag = tags_found[0];
		//						MEM_free(tags_found);

							if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
							if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_top_line (window, null_tag,objTag , null_tag, &top_line)!=ITK_ok)PrintErrorStack();

							printf("\nTCDCbefore get_bom:%s and envName :%s and TmpenvName :%s\n",values[0],envName,TmpenvName);fflush(stdout);
							envOrignal=malloc(1500);
							strcpy(envOrignal,envNameCpy);
							printf("\nTCDCbefore get_bom:envOrignal:%s\n",envOrignal);fflush(stdout);
							get_bom (top_line,NULLTAG, 0,Item_id,envNameCpy,envOrignal);
							printf("\nTCDCafter get_bom :%s\n",values[0]);fflush(stdout);

		//						if(BOM_line_ask_child_lines (top_line, &k, &children1));
		//						printf("\nTCDCNo of child objects are k %d\n",k);
		//						for (cnt = 0; cnt < k; cnt++)
		//						{
		//							 if(Childobject) Childobject=NULLTAG;
		//							Childobject=children1[cnt];
		//
		//							if (TCTYPE_ask_object_type(Childobject,&ChildobjTypeTag1)!=ITK_ok)PrintErrorStack();
		//							if (TCTYPE_ask_name(ChildobjTypeTag1,child_type_name)!=ITK_ok)PrintErrorStack();
		//							 printf("\nTCDCchild_type_name %s\n",child_type_name);
		//
		//							if( BOM_line_look_up_attribute ("bl_item_object_type",&Item_Type));
		//							if(BOM_line_ask_attribute_string(Childobject, Item_Type, &Item_Type_str));
		//
		//
		//							printf("\nTCDCItem_Type_str %s\n",Item_Type_str);
		//
		//							if (strcmp(Item_Type_str,"Design")==0)
		//							{
		//									printf("\nTCDCinside weldspot %s\n",Item_Type_str);
		//
		//										if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_RevisionW));
		//									    if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_IDW));
		//										if(BOM_line_ask_attribute_string(Childobject, Item_IDW, &Item_ID_strW));
		//
		//
		//										if(BOM_line_ask_attribute_string(Childobject, Item_RevisionW, &Item_Revision_strW));
		//										printf("\nTCDCItem_Revision_strW %s and Item_ID_strW :%s\n",Item_Revision_strW,Item_ID_strW);
		//								//
		//
		//									if (GRM_list_secondary_objects_only(Childobject,reln_type1,&n_attchs1,&secondary_objects1)!=ITK_ok)
		//									PrintErrorStack();
		//									printf("\nTCDCn_attchs1 for T5_WeldSpot%d\n",n_attchs1);
		//									for (n=0;n< n_attchs1;n++ )
		//									{
		//											if(primary1) primary1=NULLTAG;
		//											primary1=secondary_objects1[n];
		//											if (AE_ask_dataset_ref_count(primary1,&referencenumberfound1)!=ITK_ok)PrintErrorStack();
		//										    printf("\nTCDCreferencenumberfound for T5_WeldSpot= %d\n", referencenumberfound1);
		//										   for(j1=0;j1<referencenumberfound1;j1++)
		//										   {
		//												if (AE_find_dataset_named_ref(primary1,j1,refname1,&reftype1,&refobject1)!=ITK_ok)PrintErrorStack();
		//												//if(orig_name) orig_name=NULL;
		//												if ( IMF_ask_original_file_name(refobject1,orig_nameW)!=ITK_ok)PrintErrorStack();
		//												printf("\nTCDCorig_name as per referencenumberfound for T5_WeldSpot is :%s for j :%d\n",orig_nameW,j1);
		//												//if(path_name) path_name=NULL;
		//												if(IMF_ask_file_pathname(refobject1,SS_UNIX_MACHINE,path_nameW)!=ITK_ok)PrintErrorStack();
		//												printf("\nTCDCpath_nameW T5_WeldSpot is :%s for j :%d\n",path_nameW);
		//										   }
		//
		//									}
		//
		//							}
		//						   //print_bom (children1[k],line,depth,Item_idP,fdf,fus);
		//						}
							//      print_bom (children[k],line,depth,Item_idP,fdf,fus);
							//print_bom (top_line,NULLTAG, 0,Item_id,fp2,fp);
						}
						printf("\nn_attchs:%d",n_attchs);
						for (i= 0; i < n_attchs; i++)
						{
							if(envNameCpy)
							{
								printf("\nTCDCTmpenvName in is:%s for\n",TmpenvName);fflush(stdout);
								envName=NULL;  envNameCpy=malloc(500);
								Name=NULL;  Name=malloc(1500);
								strcpy(envNameCpy,TmpenvName);
								printf("\nTCDCenvName got orignal in is:%s for i :%d\n",envNameCpy,i);fflush(stdout);
							}
							if(primary) primary=NULLTAG;
							primary=secondary_objects[i];
							if (TCTYPE_ask_object_type(primary,&objTypeTag1)!=ITK_ok)PrintErrorStack();
							if (TCTYPE_ask_name(objTypeTag1,type_name1)!=ITK_ok)PrintErrorStack();
							printf("\nTCDCtype_name before strcmp is :%s for i :%d\n",type_name1,i);fflush(stdout);
							//   if(strcmp(type_name,"CATProduct")==0 || strcmp(type_name,"t5Alias")==0 || strcmp(type_name,"CATPart")==0 || strcmp(type_name,"CATDrawing")==0 || strcmp(type_name,"Text")==0)
							// {
							  //if (AE_ask_dataset_id_rev(primary,&ret_id,&ret_rev)!=ITK_ok)PrintErrorStack();
							if (AE_ask_dataset_ref_count(primary,&referencenumberfound)!=ITK_ok)PrintErrorStack();
							printf("\nTCDCIn method_1: referencenumberfound=%d\n", referencenumberfound);fflush(stdout);
							for(j=0;j<referencenumberfound;j++)
							{
								if(envNameCpy)
								{
									printf("\nTCDCTmpenvName in is:%s for\n",TmpenvName);fflush(stdout);
									envNameCpy=NULL; envNameCpy = malloc(500);
									Name=NULL; Name = malloc(1500);
									strcpy(envNameCpy,TmpenvName);
									printf("\nTCDCenvName got orignal in is:%s for i :%d\n",envNameCpy,i);fflush(stdout);
								}
								if (AE_find_dataset_named_ref(primary,j,refname,&reftype,&refobject)!=ITK_ok)PrintErrorStack();
								if ( IMF_ask_original_file_name(refobject,orig_name)!=ITK_ok)PrintErrorStack();
								printf("\nTCDCorig_name as per referencenumberfound is :%s for j :%d\n",orig_name,j);fflush(stdout);
								if(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,path_name)!=ITK_ok)PrintErrorStack();
								printf("\nTCDCpath_name as per referencenumberfound is :%s for j :%d and strstr(path_name,catpart) :%d\n",path_name, j,strstr(path_name,"catpart"));fflush(stdout);
								//if(strlen(path_name) >0)
								if(strlen(orig_name) >0)
								{
									//if(( strstr(path_name,"catpart") != NULL ) || ( strstr(path_name,"CATDrawing")  != NULL ) ||  ( strstr(path_name,"catdrawing")  != NULL ) ||  ( strstr(path_name,"CATPart")  != NULL ) || ( strstr(path_name,"CATProduct") != NULL ) || ( strstr(path_name,"catproduct")  != NULL ) || ( strstr(path_name,"txt")  != NULL ) || ( strstr(path_name,"dat")  != NULL  ) )
									if(( strstr(orig_name,"catpart") != NULL ) || ( strstr(orig_name,"CATDrawing")  != NULL ) ||  ( strstr(orig_name,"catdrawing")  != NULL ) ||  ( strstr(orig_name,"CATPart")  != NULL ) || ( strstr(orig_name,"CATProduct") != NULL ) || ( strstr(orig_name,"catproduct")  != NULL ) || ( strstr(orig_name,"txt")  != NULL ) || ( strstr(orig_name,"dat")  != NULL  ) )
									{
										printf("\nownFilename:%s",Item_id);fflush(stdout);
										
										Item_idOwn = malloc (50);
										tc_strcpy(Item_idOwn,Item_id);
										tc_strcat(Item_idOwn,".");
										printf("\nItem_idOwn:%s",Item_idOwn);fflush(stdout);
										
										if(strstr(orig_name,Item_idOwn)!= NULL)
										{
											if(IMF_ask_original_file_name( refobject, ownFilenamePass )!=ITK_ok)PrintErrorStack();
											//if(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,ownFilenamePass)!=ITK_ok)PrintErrorStack();
											printf("\nownFilenamePass:%s",ownFilenamePass);fflush(stdout);
										}
								
										//if(strstr(path_name,"bmp")==0 && strstr(path_name,"BMP")==0)
										if( ( strstr(path_name,"bmp")==NULL) && ( strstr(path_name,"BMP")== NULL))
										{

											printf("\nTCDCpath_name inside if condition :%s\n",path_name);fflush(stdout);
											printf("\nTCDCenvName before cat is if condition :%s\n",envNameCpy);fflush(stdout);
		//									if(strstr(path_name,"CATProduct") || strstr(path_name,"catproduct"))
		//									{
		//										strcat(envName,"/");
		//										strcat(envName,Item_id);
		//										strcat(envName,".CATProduct");
		//									}
		//									if(strstr(path_name,"catpart") || strstr(path_name,"CATPart"))
		//									{
		//										strcat(envName,"/");
		//										strcat(envName,Item_id);
		//										strcat(envName,".CATPart");
		//									}
											/*TempFile=malloc(1500);
											strcpy(TempFile,envName);
											strcat(TempFile,"/");
											strcat(TempFile,Item_id);
											strcat(TempFile,"-TCPartListTST.txt");
											printf("\nTCDCTempFile TCPartList:%s\n",TempFile);

											fp=fopen(TempFile,"w");
											if(fp==NULL)
											{
												printf("\nTCDCError in opening the file fp TCPartList\n");
											}
											fp2=fopen("Skktest1.txt","w");
											if(fp2==NULL)
											{
												printf("\nTCDCError in opening the file fp2 Skktest1.txt\n");
											}*/


											Name=malloc(1500);
											strcpy(Name,envNameCpy);
											strcat(Name,"/");
											strcat(Name,orig_name);
											printf("\nTCDCName after all stract :%s\n",Name);fflush(stdout);

											printf("\nTCDCpath_name before copy i am checking bmp:%s\n",path_name);fflush(stdout);

											sprintf(command,"cp  %s %s",path_name,Name);
											system(command);
											printf("\nTCDCDONE :%s\n",Name);fflush(stdout);
											printf("\nTCDCName after  mkdir is=> %s\n", Name);fflush(stdout);
											
											//---------------------------------------------------------------------------------------					
											//previous code location
											//---------------------------------------------------------------------------------------					

										}
										printf("\nTCDC..1");fflush(stdout);
									}printf("\nTCDC..2");fflush(stdout);

								}printf("\nTCDC..3");fflush(stdout);
							}printf("\nTCDC..4");fflush(stdout);
						}printf("\nTCDC..5");fflush(stdout);
						//-------------------------------19.09.2016--------------------------------------------------------
						printf("\nTCDC Item_id:%s *****************************",Item_id);fflush(stdout);
						n = 0;
						if(Item_id)
						{
							attrs[0] ="item_id";
							values[0] = (char *)Item_id;
							printf("\nTCDCvalues[0] :%s\n",values[0]);fflush(stdout);

							if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
							if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_top_line (window, null_tag,objTag , null_tag, &top_line)!=ITK_ok)PrintErrorStack();;

							if( BOM_line_ask_child_lines ( top_line, &n, &children ) );

							//print_bom (top_line,NULLTAG, 0,Item_id,Item_id,1,1,fp2,fp);
							//fclose(fp);
							//fclose(fp2);
						}
						sComponentType = malloc(5 * sizeof (char *) );
						sIsCatiaComp = malloc(5 * sizeof (char *) );
						if( n > 0 )
						{
							tc_strcpy(sComponentType,"ASM");
							tc_strcpy(sIsCatiaComp,"-");
						}
						else if( n <= 0 )
						{
							tc_strcpy(sComponentType,"PRT");
							tc_strcpy(sIsCatiaComp,"+");
						}

						//call shell here
						FileName = malloc(2000);
						//printf("\nTCDCItem_id:%s  and desc.revision_id :%s and PatSeq :%s and path_name :%s\n",  Item_id ,desc.revision_id, PatSeq,path_name );fflush(stdout);
						printf("\nTCDCItem_id:%s  and newPatRev :%s and newPatSeq :%s and path_name :%s\n",  Item_id ,newPatRev, newPatSeq,path_name );fflush(stdout);
						//TcDcShellEnvName = malloc(250 * sizeof (char *) );
						//TcDcShellEnvName = getenv("TCDC_SHELL_PATH");

						if(PREF_ask_char_value("TCDC_SHELL_PATH", 0 , &TcDcShellEnvName )!=ITK_ok)PrintErrorStack();
						
						printf("\nTCDCTCDC_SHELL_PATH %s\n",TcDcShellEnvName);fflush(stdout);

						if(!TcDcShellEnvName)
						{
							printf("\nTCDC Shell path not found. Please check TCDC_SHELL_PATH preference!!! envname:%s\n", TcDcShellEnvName );fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,"TCDC Shell path not found. Please check TCDC_SHELL_PATH preference!!!...");
							
							return ITK_errStore;
						}

						if(envNameCpy)
						{
							printf("\nTCDCTmpenvName in is:%s for\n",TmpenvName);fflush(stdout);
							envName=NULL;  envNameCpy=malloc(500);
							Name=NULL;  Name=malloc(1500);
							strcpy(envNameCpy,TmpenvName);
							printf("\nTCDCenvName got orignal in is:%s for i :%d\n",envNameCpy,i);fflush(stdout);
						}

						printf("\nTCDC line 1557 path_name:%s",path_name);
						printf("\nTCDC line 1558 envNameCpy:%s",envNameCpy);
						ShellInpFilePath = malloc(600);
						tc_strcpy(ShellInpFilePath,"");
						sprintf(ShellInpFilePath,"%s/%s",envNameCpy,ownFilenamePass);
						printf("ShellInpFilePath:%s\n",ShellInpFilePath);

						if(ShellInpFilePath == NULL)
						{
							printf("ShellInpFilePath is null hence mismatch shell failed\n");fflush(stdout);
						}
						printf("\n%s",path_name);
						strcpy(FileName,TcDcShellEnvName);
						strcat(FileName,"/FindMismatchInCATProduct.sh");
						strcat(FileName," ");
						strcat(FileName,Item_id);
						strcat(FileName," ");
						//strcat(FileName,desc.revision_id);
						strcat(FileName,newPatRev);
						strcat(FileName," ");
						//strcat(FileName,PatSeq);
						strcat(FileName,newPatSeq);
						strcat(FileName," ");
						//strcat(FileName,path_name);
						//strcat(FileName,ownFilenamePass);
						strcat(FileName,ShellInpFilePath);
						strcat(FileName," ");
						strcat(FileName,envNameCpy);
						strcat(FileName," ");
						strcat(FileName,sComponentType);
						strcat(FileName," ");
						strcat(FileName,sDesignGroup);
						strcat(FileName," ");
						strcat(FileName,sIsCatiaComp);
						strcat(FileName," ");
						strcat(FileName,sPartType);
						strcat(FileName," ");
						strcat(FileName,userid);
						printf("\nTCDCFileName before system calling shell from custom exit: %s\n", FileName);fflush(stdout);
						system(FileName);
						printf("\nTCDCAfter excecuting shell from custom exit: %s\n", FileName);fflush(stdout);
						envName1=malloc(1000);
						strcpy(envName1,envNameCpy);
						strcat(envName1,"/");
						strcat(envName1,Item_id);
						strcat(envName1,"_mismatch.txt");
						printf("\nTCDCenvName1 is:%s\n",envName1);fflush(stdout);
						fp1 = fopen(envName1, "r");
						Finalline=malloc(2000);
						filelinecount = 0;
						if ( fp1 )
						{
							 tc_strcpy(Finalline,"Error  ");
							 printf("after Finalline copy : %s\n", Finalline);fflush(stdout);
							 while ( fgets (line1 , 200 , fp1) )
							 {
									printf("The data of the file is: %s\n", line1);fflush(stdout);
									tc_strcat(Finalline,line1);
									filelinecount = filelinecount + 1;
									if ( filelinecount == 8 )
									{
										break;
									}

							 }
							 printf("\nTCDCstrlen(line1) :%d\n",tc_strlen(line1));fflush(stdout);
							 printf("\nTCDCstrlen(Finalline) :%d\n",tc_strlen(Finalline));fflush(stdout);
							 printf("\nTCDCAt end all after strcat: %s\n", Finalline);fflush(stdout);
							if(tc_strlen(Finalline)>8)
							{
								if(tc_strlen(Finalline)>1650)
								{
									Finalline1=malloc(2050);
									Finalline1=subString(Finalline,0,2000);
									 printf("\nTCDCBefore print of the file is: %s\n", Finalline1);fflush(stdout);
									//  printf("	\n Before print StrCat(Finalline,line1): %s\n", Finalline);
									 EMH_store_error_s1(EMH_severity_error,ITK_err,Finalline1);
									 
									 return ITK_err;
								}
								else
								{
									 printf("\nTCDCless than 1650 no substring: %s\n", Finalline);fflush(stdout);
									 EMH_store_error_s1(EMH_severity_error,ITK_err,Finalline);
									 return ITK_err;
								}
							}
						}
						else
						{
							printf("\nTCDCError: Log file can not be created.Program Aborting\n");fflush(stdout);
						}
						//----------------------------------19.09.2016-----------------------------------------------------
					}
					else
					{
						printf("\nTCDCThere are no data items attached to part being checked in\n");fflush(stdout);
					}
				}
			}

			//Added by Sharvari for handling removing relation of folder and Design revision during checkin on 8-10-2013(Requirement from MSDCAD for PRO-E)
			printf("\nTCDCProPrtCN is before folder check:%d\n",ProPrtCN);fflush(stdout);

			if(ProPrtCN >0)
			{
				if (ITEM_ask_item_of_rev( objTag,&ItemMasterTag)!=ITK_ok)PrintErrorStack();
				if (ItemMasterTag)
				{
					if(WSOM_where_referenced(ItemMasterTag, WSO_where_ref_any_depth,&n_refs,&levels,&referencers,&relations)!=ITK_ok)PrintErrorStack();
					 printf("\nTCDCn_refs  to item are:%d\n",n_refs);fflush(stdout);
					 if (n_refs >0)
					 {
							for (cnt=0;cnt<n_refs ;cnt++ )
							{
								 if(TCTYPE_ask_object_type(referencers[cnt],&objTypeRefTag))PrintErrorStack();
								if(TCTYPE_ask_name(objTypeRefTag,type_name_ref))PrintErrorStack();
								printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);
								if (strcmp(type_name_ref,"Folder")==0)
								{
									 if (WSOM_describe(referencers[cnt], &desc) !=ITK_ok)   PrintErrorStack();

									   printf("Object Name:     %s\n", desc.object_name);fflush(stdout);
									   printf("Object Typeeee:     %s\n", desc.object_type);fflush(stdout);
										 if(strcmp(desc.object_name,"Home")!=0)
									  {
		//								int TotalSize=0;
		//						    if(FL_ask_references(referencers[cnt],FL_fsc_by_date_modified ,&TotalSize,&Objects_Found)!=ITK_ok)PrintErrorStack();
		//						    printf("\nTCDCTotalSize:%d\n",TotalSize); fflush(stdout);
		//						    for (p=0;p<TotalSize ;p++ )
		//							{
		//								if(WSOM_ask_name(Objects_Found[p],task_name)!=ITK_ok)PrintErrorStack();
		//								printf("\nTCDCtaskName isss :%s\n",task_name);fflush(stdout);
		//							}
									if(AOM_lock(referencers[cnt])!=ITK_ok)PrintErrorStack();
									  if(FL_remove(referencers[cnt],ItemMasterTag)!=ITK_ok)PrintErrorStack();
								 //       if(AOM_refresh(referencers[cnt],1)!=ITK_ok)PrintErrorStack();
									  if(AOM_save(referencers[cnt])!=ITK_ok)PrintErrorStack();
										  if(AOM_refresh(referencers[cnt],0)!=ITK_ok)PrintErrorStack();
										  printf("\nTCDCrefreshed after save ..\n"); fflush(stdout);
									  if(AOM_unlock(referencers[cnt])!=ITK_ok)PrintErrorStack();

									  printf("\nTCDCremoved..\n"); fflush(stdout);
									  break;
									  }

								}
							}
					 }
				}
			}
			
			printf("\nTCDCItemId for Checkin is \t[%s]\n",Item_id);fflush(stdout);
			printf("\nTCDCObjectType for Checkin is \t[%s]\n",desc.object_type);fflush(stdout);
			//printf("\nTCDCRevision of Part is \t[%s]\n",desc.revision_id);fflush(stdout);
			printf("\nTCDCRevision of Part is \t[%s]\n",newPatRev);fflush(stdout);
			printf("\nTCDCSequence of Part Is \t[%s]\n", PatSeq);fflush(stdout);

			if (GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)	PrintErrorStack();
			printf("\nTCDCTotal Secondary Objects Found for Part [%s] are [%d]\n",Item_id,n_attchs);fflush(stdout);

			if (n_attchs > 0)
			{
				printf("\nTCDCThere are some Secondary Objects ... so proceed with checks\n");fflush(stdout);
				/*Getting ChildParts through BOM LINE*/
				if(BOM_create_window (&t_BomLineWindow) !=ITK_ok) PrintErrorStack();
				printf("\nTCDCABHI 1111\n");fflush(stdout);
				if(CFM_find( "Latest Working", &t_Rule )!=ITK_ok) PrintErrorStack();
				if(BOM_set_window_config_rule( t_BomLineWindow, t_Rule )!=ITK_ok) PrintErrorStack();
				if(BOM_set_window_pack_all (t_BomLineWindow, true)!=ITK_ok) PrintErrorStack();
				if(BOM_set_window_top_line (t_BomLineWindow, t_ItemTag, objTag, null_tag, &t_TopLine)!=ITK_ok) PrintErrorStack();
				if(BOM_line_ask_child_lines (t_TopLine, &i_ChildCount, &t_PartChildren)!=ITK_ok) PrintErrorStack();
				printf("\nTCDCTotal Child Parts Found in BomLine are [%d]\n",i_ChildCount);fflush(stdout);

				iChildPartChkOutFlag=0;
				for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
				{
					if(t_Childobject) t_Childobject=NULLTAG;
					t_Childobject=t_PartChildren[iChldPrts];
					if (TCTYPE_ask_object_type(t_Childobject,&t_ChildObjType)!=ITK_ok)PrintErrorStack();
					if (TCTYPE_ask_name(t_ChildObjType,ca_ChildType_Name)!=ITK_ok)PrintErrorStack();
					printf("\nTCDC[%d] ChildType is [%s]\n",iChldPrts+1,ca_ChildType_Name);fflush(stdout);

					if( BOM_line_look_up_attribute ("bl_item_object_type",&iItemType));
					if(BOM_line_ask_attribute_string(t_Childobject, iItemType, &cp_ItemType_str));
					printf("\nTCDC[%d] Child ItemType is [%s]\n",iChldPrts+1,cp_ItemType_str);

					if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemRevId));
					if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
					if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str));
					if(BOM_line_ask_attribute_string(t_Childobject, iItemRevId, &cp_ItemRev_str));
					printf("\nTCDC[%d] ItemRevision is [%s] and ItemID is: [%s]\n",iChldPrts+1,cp_ItemRev_str,cp_ItemID_str);

					if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
					if(BOM_line_ask_attribute_tag(t_Childobject, iChildItemTag, &t_ChildItemRev));

					if(AOM_ask_value_int(t_ChildItemRev,"sequence_id",&i_ChildSeq));
					cp_ChildSeq = (char *) MEM_alloc( 5 * sizeof(char) );
					sprintf(cp_ChildSeq,"%d",i_ChildSeq);
					printf("\nTCDC[%d] ItemSequence is [%s]\n",iChldPrts+1,cp_ChildSeq);fflush(stdout);

					if(BOM_line_look_up_attribute ("bl_rev_checked_out",&iItemChkdOut));
					if(BOM_line_ask_attribute_string (t_Childobject, iItemChkdOut, &cp_ChildChkOutValue));
					printf("\nTCDC[%d] CheckedOut is [%s]\n",iChldPrts+1,cp_ChildChkOutValue);fflush(stdout);

					if (AOM_ask_value_string(t_ChildItemRev,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
					printf("\nTCDC[%d] Description is [%s]\n",iChldPrts+1,Desc_obj);fflush(stdout);

					if (strcmp(cp_ChildChkOutValue,"Y")==0 && strcmp(cp_ItemType_str,"WeldSpot")!=0)
					{
						printf("\nTCDCChild Part is checkedout..\n");fflush(stdout);
						iChildPartChkOutFlag=1;
					}
					else if (strcmp(cp_ChildChkOutValue,"Y")==0 && strcmp(cp_ItemType_str,"WeldSpot")==0)
					{
						printf("\nTCDCThis is WeldSpot and is checked out... so auto checkin it\n");fflush(stdout);
						if (RES_checkin(t_ChildItemRev)!=ITK_ok)   PrintErrorStack();
					}
				}
				if (iChildPartChkOutFlag == 0)
				{
					printf("\nTCDCAll Child Part are checkedin ...so proceed\n");fflush(stdout);
				}
				else
				{
					//if( strcmp(desc.revision_id,"NR")==0 )
					if( strcmp(newPatRev,"NR")==0 )
					{
						//printf("\nTCDCSome Child Parts are checkedout.... So Ask user to checkin child Parts first Parent rev:%s itemid:%s...\n",desc.revision_id,Item_id);fflush(stdout);
						printf("\nTCDCbefore checkin message for child and parent");fflush(stdout);
						printf("\nTCDCCatPrtCN:%d",CatPrtCN);fflush(stdout);
						printf("\nTCDCCatPrdt:%d",CatPrdt);fflush(stdout);
						printf("\nTCDCCmiDrwCnt:%d",CmiDrwCnt);fflush(stdout);
						if ( ( CatPrtCN > 0 ) || ( CatPrdt > 0 ) || ( CmiDrwCnt > 0) )
						{
							printf("\nTCDCSome Child Parts are checkedout.... So Ask user to checkin child Parts first Parent rev:%s itemid:%s...\n",newPatRev,Item_id);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Dependent Child Parts are not Checked-In.. Checkin all Child Part first");
							return ITK_err;
						}
					}
					else
					{
						//printf("\nTCDC non NR assembly checkin allowed even if childs are checkedout mail on 15.01.2016 Parent rev:%s itemid:%s",desc.revision_id,Item_id);fflush(stdout);
						printf("\nTCDC non NR assembly checkin allowed even if childs are checkedout mail on 15.01.2016 Parent rev:%s itemid:%s",newPatRev,Item_id);fflush(stdout);
					}
				}
			}
			printf("\nTCDC1..");fflush(stdout);

			
			/******************************************************************************************
											LH/RH Checked-in start by Hanuman
			******************************************************************************************/
			HasSymPrt=0;
			int result,n_attch = 0;
			int count,k;
			int found =0;
			tag_t relation_type;
			tag_t relation_type3;
			tag_t  	master =	NULLTAG;
			tag_t  *master2 = NULLTAG;
			tag_t	latestrev	=	NULLTAG;
			tag_t objTypeTag2 = NULLTAG;
			logical	checkout = 0;
			logical	checkout1 = 0;
		
			ITK_CALL(RES_is_checked_out(objTag,&checkout1));
			printf("\n Checkedout Status is : [%d]\n",checkout1);fflush(stdout);
			
			if (checkout1)
			{			
				ITK_CALL(AOM_ask_value_string(objTag,"t5_LeftRh_Comp",&ItemLhRhInd));
				printf("\n LH/RH Indicator of Left Part is :: %s",ItemLhRhInd);fflush(stdout);
					
				if(ItemLhRhInd==NULL || tc_strcmp(ItemLhRhInd,"NA")==0)
				{	
					printf("\n inside NULL/NA of LH/RH Indicator values");fflush(stdout);
					HasSymPrt=0;
				}else
				{
					if(tc_strcmp(ItemLhRhInd,"LH CATIA")==0 || tc_strcmp(ItemLhRhInd,"LH PROE")==0)
					{
						printf("\n inside LH CATIA OR PROE");fflush(stdout);
						HasSymPrt=1;
											
						ITK_CALL(ITEM_ask_item_of_rev(objTag, &master)); 
						printf("\n ITEM_Found......");fflush(stdout);

						result = GRM_find_relation_type("T5_LRReln", &relation_type);
						printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

						if (relation_type!=NULLTAG)
						{
							ITK_CALL(GRM_list_secondary_objects_only(master,relation_type,&n_attch,&master2));
							printf("\n master2 from Design master1 :: %d\n",n_attch);fflush(stdout);

							if(n_attch>0)
							{						  
								  ITK_CALL(ITEM_ask_latest_rev(master2[0],&latestrev));

								  if (latestrev!=NULLTAG)
								  {	  
									  printf("\n master2 latest revision found\n");fflush(stdout); 									  
									  if (TCTYPE_ask_object_type(latestrev,&objTypeTag2)!=ITK_ok)PrintErrorStack();
									  if (TCTYPE_ask_name(objTypeTag2,type_name)!=ITK_ok)PrintErrorStack();								 
									  printf("\n type_name ==> %s\n", type_name);fflush(stdout);

									  if(tc_strcmp(type_name,"Design Revision")==0 || tc_strcmp(type_name,"ItemRevision")==0 )
									  {
										printf("\n Rh Part Revision is also of type [Design Revision/ItemRevision]");fflush(stdout);
										ITK_CALL(RES_is_checked_out(latestrev,&checkout));
										printf("\n Value of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
										
										if (checkout==1)
										{
											LHRhFlag = 1;
											printf("\n After checked-out RH Part flag is : : %d",LHRhFlag);										
											
											ifail=RES_checkin(latestrev);
											if(ifail  != ITK_ok)
											{
												printf("\n Error in Check IN ");												
												PrintErrorStack(); 
												LHRhFlag= 1;
												return ifail;
											}

											ITK_CALL(AOM_refresh(latestrev, 0 ));										
											printf("\n RH Part is checked-in\n");
											
											LHRhFlag = -1;
										}
										
										/*
										if (checkout==1)
										{										
											ifail=RES_checkin(latestrev);
											if(ifail  != ITK_ok)
											{
												printf("\n Error in Check IN ");
												PrintErrorStack(); 
												return ifail;
											}

											ITK_CALL(AOM_refresh(latestrev, 0 ));										
											printf("\n RH Part is checked-in\n");
										}*/

									  }
								  }
							}
						}					
					}else if(tc_strcmp(ItemLhRhInd,"RH CATIA")==0 || tc_strcmp(ItemLhRhInd,"RH PROE")==0)
					{
						ITK_CALL(ITEM_ask_item_of_rev(objTag, &master)); 
						printf("\n ITEM_Found......");fflush(stdout);

						result = GRM_find_relation_type("T5_LRReln", &relation_type);
						printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

						if (relation_type!=NULLTAG)
						{
							ITK_CALL(GRM_list_secondary_objects_only(master,relation_type,&n_attch,&master2));
							printf("\n master2 from Design master1 :: %d\n",n_attch);fflush(stdout);

							if(n_attch>0)
							{
								found=0;
								for (k = 0; k < n_attchs; k++)
								{	
									primary=secondary_objects[k];
									if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
									if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
									printf("\n Dataset Class for the input DI is : %s\n",type_name2);fflush(stdout);
									printf("\n values of strstr : %d\n",strstr ( type_name2, "Pro" ));fflush(stdout);
									
									if ( strstr ( type_name2, "Pro" ) != NULL )
									{
										printf("\n inside RH CATIA OR PROE");fflush(stdout);
										found=1;
									}
								}							

								if(found==0)
								{
									printf("\n Else IF LHFlg : %d",LHRhFlag);
									if(LHRhFlag<1)
									{
										printf("\n inside RH CATIA OR PROE");fflush(stdout);
										EMH_store_error_s2(EMH_severity_error,ITK_errStore,"In-Valid to Check-in RH Part","Pls select LH Part and Check-in");
										return ITK_errStore;	
									}
								}

								//printf("\n inside RH CATIA OR PROE");fflush(stdout);
								//EMH_store_error_s2(EMH_severity_error,ITK_errStore,"In-Valid to Check-in RH Part","Pls select LH Part and Check-in");
								//return ITK_errStore;	
							}
						}
					}
				}
			}else
			{				
				printf("\n Selected Part is already checked-in..........\n");fflush(stdout);
			}


			/***********Starting Dispatcher request code for JT creation by Sharvari on 16-12-2016**************************/

			printf("\nTCDCFound CMI2Part call JT service for CATPART\n");fflush(stdout);


			if ( ( CatPrtCN > 0 ) || ( CatPrdt > 0 ) || ( CmiDrwCnt > 0) )
			{
				if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchsd,&secondary_objectsd)!=ITK_ok)PrintErrorStack();
						printf("\n Number of DId :%d\n",n_attchsd);fflush(stdout);

						if(n_attchsd>0)
						{	
						
							for (k = 0; k < n_attchsd; k++)
							{	
								primaryd=secondary_objectsd[k];
								if(TCTYPE_ask_object_type(primaryd,&objTypeTagDid))PrintErrorStack();
								if(TCTYPE_ask_name(objTypeTagDid,type_name2d))PrintErrorStack();
								printf("\n type_name2d  :%s\n",type_name2d);fflush(stdout);
								if (strcmp(type_name2d,"CMI2Product")==0)
								{
									
									ITK_CALL(AOM_ask_value_string(primaryd,"object_name",&DatasetName));
										JTTransFileName=malloc(2000);
										strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
										//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

										strcat(JTTransFileName,Item_id);
										strcat(JTTransFileName," ");
										strcat(JTTransFileName,"-r='");
										//strcat(JTTransFileName,desc.revision_id);
										strcat(JTTransFileName,desc.revision_id);
										strcat(JTTransFileName,"'");
										strcat(JTTransFileName," ");
										//strcat(JTTransFileName, "-dt=CMI2Part");
										strcat(JTTransFileName, "-dt=CMI2Product  -dn='");
										strcat(JTTransFileName,DatasetName);
										strcat(JTTransFileName,"'");
										strcat(JTTransFileName," ");
										strcat(JTTransFileName,"-pr=1 -pn=SIEMENS    -tn=catiav5prdtojt -ty=COMMAND_LINE");
										printf("\nTCDCJTTransFileName before system is CMI2Product =>%s\n", JTTransFileName);fflush(stdout);
										system(JTTransFileName);
										//printf("\nTCDCAfter excecuting shell=>%s\n", JTTransFileName);fflush(stdout);
										//printf("\nTCDCJTTransFileName dispatcher_create_rqst before system is=>%s\n", JTTransFileName);fflush(stdout);
										//system(JTTransFileName);
										printf("\nTCDCAfter dispatcher_create_rqst shell CMI2Product=>%s\n", JTTransFileName);fflush(stdout);
								}
								if (strcmp(type_name2d,"CMI2Part")==0)
								{
									ITK_CALL(AOM_ask_value_string(primaryd,"object_name",&DatasetName));
										JTTransFileName=malloc(2000);
										strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
										//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

										strcat(JTTransFileName,Item_id);
										strcat(JTTransFileName," ");
										strcat(JTTransFileName,"-r='");
										//strcat(JTTransFileName,desc.revision_id);
										strcat(JTTransFileName,desc.revision_id);
										strcat(JTTransFileName,"'");
										strcat(JTTransFileName," ");
										//strcat(JTTransFileName, "-dt=CMI2Part");
										strcat(JTTransFileName, "-dt=CMI2Part  -dn='");
										strcat(JTTransFileName,DatasetName);
										strcat(JTTransFileName,"'");
										strcat(JTTransFileName," ");
										strcat(JTTransFileName,"-pr=1 -pn=SIEMENS    -tn=catiav5tojt -ty=COMMAND_LINE");
										printf("\nTCDCJTTransFileName before system catpart is=>%s\n", JTTransFileName);fflush(stdout);
										system(JTTransFileName);
										//printf("\nTCDCAfter excecuting shell=>%s\n", JTTransFileName);fflush(stdout);
										//printf("\nTCDCJTTransFileName dispatcher_create_rqst before system is=>%s\n", JTTransFileName);fflush(stdout);
										//system(JTTransFileName);
										printf("\nTCDCAfter dispatcher_create_rqst shell catpartt=>%s\n", JTTransFileName);fflush(stdout);

								}
								if (strcmp(type_name2d,"CMI2Drawing")==0)
								{

									ITK_CALL(AOM_ask_value_string(primaryd,"object_name",&DatasetName));
										JTTransFileName=malloc(2000);
										strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
										//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

										strcat(JTTransFileName,Item_id);
										strcat(JTTransFileName," ");
										strcat(JTTransFileName,"-r='");
										//strcat(JTTransFileName,desc.revision_id);
										strcat(JTTransFileName,desc.revision_id);
										strcat(JTTransFileName,"'");
										strcat(JTTransFileName," ");
										//strcat(JTTransFileName, "-dt=CMI2Part");
										strcat(JTTransFileName, "-dt=CMI2Drawing  -dn='");
										strcat(JTTransFileName,DatasetName);
										strcat(JTTransFileName,"'");
										strcat(JTTransFileName," ");
										strcat(JTTransFileName,"-pr=1 -pn=SIEMENS    -tn=catiav5drwtopdf -ty=COMMAND_LINE");
										printf("\nTCDCJTTransFileName before system is CMI2Drawing =>%s\n", JTTransFileName);fflush(stdout);
										system(JTTransFileName);
										//printf("\nTCDCAfter excecuting shell=>%s\n", JTTransFileName);fflush(stdout);
										//printf("\nTCDCJTTransFileName dispatcher_create_rqst before system is=>%s\n", JTTransFileName);fflush(stdout);
										//system(JTTransFileName);
										printf("\nTCDCAfter dispatcher_create_rqst shell CMI2Drawing=>%s\n", JTTransFileName);fflush(stdout);

								}
							}
						}
				
			}
		}
	}
	printf("\nTCDC2..");fflush(stdout);
	//fclose(fpSrc);
	BYPASSLOADER:
	LHRhFlag= -1;
	//LHFlg=-1;
    return ITK_ok;
}

//int checkin_register_method(int *decision, va_list args)
//{
//    METHOD_id_t  method;
//
//	  *decision = ALL_CUSTOMIZATIONS;
//
//
//   if ( METHOD_find_method(RES_Type, RES_checkin_msg, &method) !=ITK_ok)
//   PrintErrorStack();
//
//    if (method.id != NULLTAG)
//    {
//        if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) checkin_method_1, NULL)!=ITK_ok)
//        PrintErrorStack();
//		printf("Registered as Pre-Action for check-in\n");
//    }
//    else
//        printf("Method not found!\n");
//
//    return ITK_ok;
//}

//DLLAPI int check_register_callbacks ()
//{
//    printf("\nTCDC\ncheckin_register_callbackssssssssss changed\n\n");
//
// /*   exit(EXIT_SUCCESS);*/
//    if(CUSTOM_register_exit ( "check", "USER_init_module", (CUSTOM_EXIT_ftn_t)  checkin_register_method) !=ITK_ok);
//     PrintErrorStack();
//
//  return ( ITK_ok );
//
//
//}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static void get_bom (tag_t line,tag_t Parent, int depth,char *Item_idP,char *Env, char *EnvOrg)
{
    int    status;
	int    k, n,int_ent_sequence;
	int    Item_ID,Item_Revision,Item_Description,xform_matrix,parent_item_seq=0,occ_xform_matrix=0,User=0;
	int    n_attchs,i,referencenumberfound,j;
	int    numBoundingBoxes,ctr;
	int    Parentsequence_id=0;
	int    dum=0;

	double *  boundingBoxes;

	char   *name, *Item_ID_str,*Item_Revision_str,*Item_Description_str,*xform_matrix_str,*occ_xform_matrix_str,*User_str=NULL;
	char   *dumy_Item_ID_str=NULL;
	char   *catiafileName=NULL;
	char   *projectcode=NULL;
	char   *desgngrp=NULL;
	char   *ret_id,*ret_rev;
	char   type_name[TCTYPE_name_size_c+1];
	char   refname[AE_reference_size_c + 1];
	char   orig_name[IMF_filename_size_c + 1];
	char   *enterprise_sequence;
	char   pathname[SS_MAXPATHLEN + 1];
	char   path_name1[SS_MAXPATHLEN];
	char   *ent_seq_str;
	char   *parentrev=NULL;
	char   *parent=NULL;
	char   *parentseq=NULL;
	char   *parentdesc=NULL;
	char   *PatSeq= NULL;
	char   *ITemRevSeq,*Desc_obj,*EnvTemp= NULL;
	char command[100];
	//char *6;char *7;char *8;char *9;char *10;

	tag_t  ParentItemRevTag =NULLTAG;
	tag_t  *secondary_objects,primary,objTypeTag,refobject=NULLTAG;
	tag_t  *children,itemrev,sequence_id_c;
	tag_t  reln_type =NULLTAG;
	AE_reference_type_t     reftype;


	printf("\nTCDCEnv is:%s and EnvOrg :%s\n",Env,EnvOrg);fflush(stdout);
	EnvTemp=malloc(1500);
	strcpy(EnvTemp,EnvOrg);
	printf("\nTCDCEnvTemp  is:%s\n",EnvTemp);fflush(stdout);

	depth ++;

	if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	Item_ID_str =malloc(100);

	if(BOM_line_ask_attribute_string(line, Item_ID, &Item_ID_str));

	if( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix));
	if(BOM_line_ask_attribute_string(line, xform_matrix, &xform_matrix_str));

	printf("\nTCDC1] Item_ID_str =%s\n",Item_ID_str);fflush(stdout);

	if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	if(BOM_line_ask_attribute_string(line, Item_Revision, &Item_Revision_str));

	//printf("\nTCDC2] Item_Revision_str =%s\n",Item_Revision_str);

	if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
	if(BOM_line_ask_attribute_tag(line, parent_item_seq, &itemrev));
	if(AOM_ask_value_int(itemrev,"sequence_id",&sequence_id_c));
//	printf("\nTCDC3] Sequence =%d\n",sequence_id_c);
	ITemRevSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	sprintf(ITemRevSeq,"%d",sequence_id_c);

	if( BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));
	if(BOM_line_ask_attribute_string(line, Item_Description, &Item_Description_str));
//	printf("\nTCDC4] Item_Description_str =%s\n",Item_Description_str);

	if( BOM_line_look_up_attribute ("bl_rev_owning_user",&User));
	if(BOM_line_ask_attribute_string(line, User, &User_str));
	//printf("\nTCDCUser_str =%s\n",User_str);

	occ_xform_matrix=0;
	if( BOM_line_look_up_attribute ("bl_plmxml_def_occ_xform",&occ_xform_matrix));
	if(occ_xform_matrix_str) occ_xform_matrix_str=NULL;occ_xform_matrix_str=malloc(500);
	if(BOM_line_ask_attribute_string(line, occ_xform_matrix, &occ_xform_matrix_str));
//	printf("\nTCDC5]  bl_plmxml_def_occ_xform =%s\n",occ_xform_matrix_str);

	if(AOM_ask_value_string(itemrev,"gov_classification",&enterprise_sequence));
    //printf("\nTCDC-----------------------enterprise_sequence -->%s\n",enterprise_sequence);

	if (AOM_ask_value_string(itemrev,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
  // printf("\nTCDCDesc_obj is :%s\n",Desc_obj);

	int_ent_sequence=atoi(enterprise_sequence);

	dumy_Item_ID_str=MEM_string_copy(Item_ID_str) ;
	projectcode=subString(dumy_Item_ID_str,0,4);
	desgngrp=subString(dumy_Item_ID_str,4,2);
//
//	printf("\nTCDCprojectcode------->%s\n",projectcode);
//	printf("\nTCDCdesgngrp------->%s\n",desgngrp);
//    if (Parent)
//	{
//			   printf("\nTCDCThis is first line\n");
//	}
//	else
//	{
	if(  BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	if(  BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	if(  BOM_line_ask_attribute_string(Parent, Item_Revision, &parentrev));
	if(  BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
	if(  BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));

	if(parent) parent=NULL;
	parent =malloc(100);
	if(BOM_line_ask_attribute_string(Parent, Item_ID, &parent));
	if(BOM_line_ask_attribute_tag(Parent, parent_item_seq, &ParentItemRevTag));
	if(AOM_ask_value_int(ParentItemRevTag,"sequence_id",&Parentsequence_id));
	PatSeq=malloc(3);
	sprintf(PatSeq,"%d",Parentsequence_id);
	if(BOM_line_ask_attribute_string(Parent, Item_Description, &parentdesc));
//	    printf("\nTCDCparent---->%s\n", parent);
//		printf("\nTCDCparentrev---->%s\n",parentrev );
//		printf("\nTCDCPatSeq---->%s\n",PatSeq );
//		printf("\nTCDCparentdesc---->%s\n",parentdesc );
//		printf("\nTCDCItem_Description_str---->%s\n",Item_Description_str );

				//if(strlen(parent)>0 )

	printf("\nTCDCItem_ID_str =%s and  parent :%s\n",Item_ID_str,parent);fflush(stdout);
	if(GRM_list_secondary_objects_only(itemrev,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
	printf("\nTCDCn_attchs:%d",n_attchs);fflush(stdout);
	if(n_attchs>0)
	{
		for (i= 0; i < n_attchs; i++)
		{
		 	 printf("\nTCDCItem_ID_str:%s",Item_ID_str);fflush(stdout);
			 printf("\nTCDCItem_idP:%s",Item_idP);fflush(stdout);
			 
			 if(strcmp(Item_ID_str,Item_idP)==0 || strstr(Item_ID_str,"Spec")!=NULL )
			 {
				printf("\nTCDCEnv:%s",Env);fflush(stdout);
				if(Env)
				{
					printf("\nTCDCAEnvTemp in getbom is:%s for\n",EnvTemp);fflush(stdout);
					Env = NULL;  
					Env = malloc(1500);
					tc_strcpy(Env,EnvTemp);
					printf("\nTCDCAEnv got orignal in getbom is:%s for i :%d\n",Env,i);fflush(stdout);
				}
				else
				{
					printf("\nTCDCBEnvTemp in getbom is:%s for\n",EnvTemp);fflush(stdout);
					Env = NULL;
					Env = malloc(1500);
					tc_strcpy(Env,EnvTemp);
					printf("\nTCDCBEnv got orignal in getbom is:%s for i :%d\n",Env,i);fflush(stdout);
				}
				primary=secondary_objects[i];
				if(TCTYPE_ask_object_type(primary,&objTypeTag));
				if(TCTYPE_ask_name(objTypeTag,type_name));
				//   if (AOM_ask_value_string(type_name,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
				printf("\nTCDCtype_name in getbom is :%s\n",type_name);fflush(stdout);
				printf("\nTCDCInside Spec :%s\n",Item_ID_str);fflush(stdout);
				//
				//  if(strcmp(type_name,"CATProduct")==0 || strcmp(type_name,"catproduct")==0 ||strcmp(type_name,"catpart")==0 ||strcmp(type_name,"t5Alias")==0 || strcmp(type_name,"CATPart")==0 ||strcmp(refname,"catdrawing")==0|| strcmp(type_name,"CATDrawing")==0 || strcmp(type_name,"DirectModel")==0)
				if(strcmp(type_name,"CMI2Product")==0 || strcmp(type_name,"CMI2Product")==0 ||strcmp(type_name,"CMI2Part")==0 || strcmp(type_name,"CMI2Part")==0 || strcmp(type_name,"CMI2Drawing")==0 || strcmp(type_name,"DirectModel")==0)
				{
				   if(AE_ask_dataset_id_rev(primary,&ret_id,&ret_rev));
				   if(AE_ask_dataset_ref_count(primary,&referencenumberfound));
				   for(j=0;j<referencenumberfound;j++)
				   {
						if(AE_find_dataset_named_ref(primary,j,refname,&reftype,&refobject));
						printf("\nTCDCrefname in getbom is:%s\n",refname);fflush(stdout);
						if(strcmp(refname,"CATProduct")==0 ||strcmp(refname,"catpart")==0 ||strcmp(refname,"CATDrawing")==0 || strcmp(refname,"catproduct")==0 ||strcmp(refname,"CATPart")==0||strcmp(refname,"catdrawing")==0 )
					    {
							if(strcmp(refname,"catpart")==0)
							{
								if( AE_get_bounding_boxes(primary, &numBoundingBoxes, &boundingBoxes));
							}
							if( IMF_ask_original_file_name(refobject,orig_name));
							if(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,path_name1)!=ITK_ok)PrintErrorStack();
							if(strlen(path_name1) >0)
							{
								if(strstr(path_name1,"bmp")==0&&strstr(path_name1,"BMP")==0)
								{
									printf("\nTCDCpath_name1 in getbom  is :%s\n",path_name1);fflush(stdout);
									printf("\nTCDCorig_namein getbom  is is :%s\n",orig_name);fflush(stdout);
									printf("\nTCDCItem_Description- beforegetbom :%s and Item_idP :%s Env before cp is :%s\n",Item_Description_str,Item_idP,Env );fflush(stdout);
//
//									if(strstr(path_name1,"CATProduct") || strstr(path_name1,"catproduct"))
//									{
//									strcat(Env,"/");
//									strcat(Env,Item_idP);
//									strcat(Env,".CATProduct");
//									}
//									if(strstr(path_name1,"catpart") || strstr(path_name1,"CATPart"))
//									{
//									strcat(Env,"/");
//									strcat(Env,Item_idP);
//									strcat(Env,".CATPart");
//									}
									tc_strcat(Env,"/");
									tc_strcat(Env,orig_name);
									printf("\nTCDCEnv after all stract in getbom :%s\n",Env);fflush(stdout);

									sprintf(command,"cp %s '%s'",path_name1,Env);
									system(command);
									printf("\nTCDCDONE :%s\n",Env);fflush(stdout);
									printf("\nTCDCEnv after  copy in getbom  is :%s\n", Env);fflush(stdout);
								}
							}
						}
					}
				}
			}
		   //}
		}
	}
	else printf("\nTCDCThere are no data item attached to it\n");fflush(stdout);
	if(BOM_line_ask_child_lines (line, &n, &children));
	 printf("\nTCDCtotal children are :%d\n",n);fflush(stdout);
    for (k = 0; k < n; k++)
     get_bom (children[k],line,depth,Item_idP,Env,EnvOrg);

}
static void print_bom (tag_t line,tag_t Parent, int depth,char *Item_idP,char *Item_idC,int qty,int TmpQty,FILE *fdf,FILE *fus)
  {
    int    status;
	int    k, n,int_ent_sequence,q=0;
	int    Item_ID,Item_Revision,Item_Description,xform_matrix,parent_item_seq=0,occ_xform_matrix=0,User=0,bl_Qty=0;
	int    n_attchs,i,referencenumberfound,j;
	int    numBoundingBoxes,ctr;
	int    Parentsequence_id=0,CatiaOccName=0;
	int    Item_Type1,Item_Type2=0;
	char *Item_ID_strW2,*Item_ID_strW3=NULL;
	int    dum=0;

	double *  boundingBoxes;

	char   *name, *Item_ID_str,*Item_Revision_str,*Item_Description_str,*xform_matrix_str,*occ_xform_matrix_str,*User_str=NULL,*bl_Qty_str=NULL;
	char   *dumy_Item_ID_str=NULL;
	char   *catiafileName=NULL;
	char *CatiaOccName_str=NULL;
	char   *projectcode=NULL;
	char   *desgngrp=NULL;
	char   *ret_id,*ret_rev;
	char   type_name[TCTYPE_name_size_c+1];
	char   refname[AE_reference_size_c + 1];
	char   orig_name[IMF_filename_size_c + 1];
	char   *enterprise_sequence;
	char   pathname[SS_MAXPATHLEN + 1];
	char   path_name1[SS_MAXPATHLEN];
	char   *ent_seq_str;
	char   *parentrev=NULL;
	char   *parent=NULL;
	char   *parentseq=NULL;
	char   *parentdesc=NULL;
	char   *PatSeq= NULL;
	char   *ITemRevSeq,*Desc_obj,*PartType,*PartType1= NULL;
	tag_t *occs;
        int n_occs,io=0,Flag=0,qtyCnt1,k1=0,mulQtyIndex,cLen=0,p=0;
	char tmpchar[10];
	char tmpchar1[10];
	//char *6;char *7;char *8;char *9;char *10;

	tag_t  ParentItemRevTag,Childobject1,Childobject2 =NULLTAG;
	tag_t  *secondary_objects,primary,objTypeTag,refobject=NULLTAG;
	tag_t  *children,itemrev,sequence_id_c;
	tag_t  reln_type =NULLTAG;
	AE_reference_type_t     reftype;

	depth ++;

        if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	if(BOM_line_ask_attribute_string(line, Item_ID, &Item_ID_str));

       if( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix));
	if(BOM_line_ask_attribute_string(line, xform_matrix, &xform_matrix_str));

	printf("\nTCDC1] Item_ID_str =%s and xform_matrix_str :%s and Item_idC(child taken for qty ) :%s\n",Item_ID_str,xform_matrix_str,Item_idC);fflush(stdout);

	if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	if(BOM_line_ask_attribute_string(line, Item_Revision, &Item_Revision_str));

	printf("\nTCDC2] Item_Revision_str =%s\n",Item_Revision_str);fflush(stdout);

	if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
	if(BOM_line_ask_attribute_tag(line, parent_item_seq, &itemrev));
    if(AOM_ask_value_int(itemrev,"sequence_id",&sequence_id_c));
	printf("\nTCDC3] Sequence =%d\n",sequence_id_c);fflush(stdout);
	ITemRevSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	sprintf(ITemRevSeq,"%d",sequence_id_c);

	if( BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));
	if(BOM_line_ask_attribute_string(line, Item_Description, &Item_Description_str));
	printf("\nTCDC4] Item_Description_str =%s\n",Item_Description_str);fflush(stdout);

	if( BOM_line_look_up_attribute ("bl_rev_owning_user",&User));
	if(BOM_line_ask_attribute_string(line, User, &User_str));
	printf("\nTCDCUser_str =%s\n",User_str);fflush(stdout);

	occ_xform_matrix=0;
	 if( BOM_line_look_up_attribute ("bl_plmxml_def_occ_xform",&occ_xform_matrix));
	if(occ_xform_matrix_str) occ_xform_matrix_str=NULL;occ_xform_matrix_str=malloc(500);
	if(BOM_line_ask_attribute_string(line, occ_xform_matrix, &occ_xform_matrix_str));
	printf("\nTCDC5]  bl_plmxml_def_occ_xform =%s\n",occ_xform_matrix_str);fflush(stdout);

	 CatiaOccName=0;
	//if( BOM_line_look_up_attribute ("catiaOccurrenceName",&CatiaOccName));
	if( BOM_line_look_up_attribute ("bl_occurrence_name",&CatiaOccName));
	if(CatiaOccName_str) CatiaOccName_str=NULL;CatiaOccName_str=malloc(200);
	if(BOM_line_ask_attribute_string(line, CatiaOccName, &CatiaOccName_str));
	printf("\nTCDC7]  catiaOccuranceName =%s\n",CatiaOccName_str);fflush(stdout);

	bl_Qty=0;
	 if( BOM_line_look_up_attribute ("bl_quantity",&bl_Qty));
	if(bl_Qty_str) bl_Qty_str=NULL;bl_Qty_str=malloc(20);
	if(BOM_line_ask_attribute_string(line, bl_Qty, &bl_Qty_str));
	printf("\nTCDC6]  bl_Qty =%s\n",bl_Qty_str);fflush(stdout);

	if(AOM_ask_value_string(itemrev,"gov_classification",&enterprise_sequence));
        printf("\nTCDC-----------------------enterprise_sequence -->%s\n",enterprise_sequence);fflush(stdout);

	if (AOM_ask_value_string(itemrev,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
	printf("\nTCDCDesc_obj is :%s\n",Desc_obj);fflush(stdout);

	 PartType=NULL;PartType=malloc(50);
	 PartType1=NULL;PartType1=malloc(50);
	//if (AOM_ask_value_string(itemrev,"t5_PartType",&PartType)!=ITK_ok)   PrintErrorStack();
	if (AOM_UIF_ask_value(itemrev,"t5_PartType",&PartType)!=ITK_ok)   PrintErrorStack();
	printf("\nTCDCPartType is :%s\n",PartType);fflush(stdout);
	if (strcmp(PartType,"C")==0)
	{
		strcpy(PartType1,"Cmponent");
	}
	if (strcmp(PartType,"A")==0)
	{
		strcpy(PartType1,"Assembly");
	}
	if (strcmp(PartType,"G")==0)
	{
		strcpy(PartType1,"Group Id");
	}
	if (strcmp(PartType,"T")==0)
	{
		strcpy(PartType1,"Technical Part List");
	}
	if (strcmp(PartType,"V")==0)
	{
		strcpy(PartType1,"Vehicle");
	}
	if (strcmp(PartType,"")==0)
	{
		strcpy(PartType1,"NULL");
	}


	printf("\nTCDCPartType after strcpy  is :%s\n",PartType1);fflush(stdout);

	int_ent_sequence=atoi(enterprise_sequence);

	dumy_Item_ID_str=MEM_string_copy(Item_ID_str) ;
	projectcode=subString(dumy_Item_ID_str,0,4);
	desgngrp=subString(dumy_Item_ID_str,4,2);
//
//	printf("\nTCDCprojectcode------->%s\n",projectcode);
//	printf("\nTCDCdesgngrp------->%s\n",desgngrp);
//    if (Parent)
//	{
//			   printf("\nTCDCThis is first line\n");
//	}
//	else
//	{
	    if(  BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	    if(  BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	    if(  BOM_line_ask_attribute_string(Parent, Item_Revision, &parentrev));
	    if(  BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
	    if(  BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));

	   if(parent) parent=NULL;
	    if(BOM_line_ask_attribute_string(Parent, Item_ID, &parent));
	    if(BOM_line_ask_attribute_tag(Parent, parent_item_seq, &ParentItemRevTag));
	    if(AOM_ask_value_int(ParentItemRevTag,"sequence_id",&Parentsequence_id));
	    PatSeq=malloc(3);
	    sprintf(PatSeq,"%d",Parentsequence_id);
	    if(BOM_line_ask_attribute_string(Parent, Item_Description, &parentdesc));
	    printf("\nTCDCparent---->%s\n", parent);fflush(stdout);
		printf("\nTCDCparentrev---->%s\n",parentrev );fflush(stdout);
		printf("\nTCDCPatSeq---->%s\n",PatSeq );fflush(stdout);
		printf("\nTCDCparentdesc---->%s\n",parentdesc );fflush(stdout);
		printf("\nTCDCItem_Description_str---->%s\n",Item_Description_str );fflush(stdout);

		  Flag=0;
		   if(parent)
	          {
				if(strcmp(parent,Item_idP)==0) // commented last by skk on 10/15/2011 && strcmp(CatiaOccName_str,"")!=0)
				{
				printf("\nTCDConly Single level str for  Item_idP-->%s and Item_idC :%s and qty :%d\n",Item_idP,Item_idC,qty);fflush(stdout);
					fprintf(fus,parent);
					fprintf(fus,",");
					fprintf(fus,parentrev);
					fprintf(fus,",");
					fprintf(fus,PatSeq);
					fprintf(fus,",");
					fprintf(fus,PatSeq);

					fprintf(fus,",");
					fprintf(fus,Item_ID_str);
					fprintf(fus,",");
					fprintf(fus,Item_Revision_str);
					fprintf(fus,",");
					fprintf(fus,ITemRevSeq);
					fprintf(fus,",");
					fprintf(fus,ITemRevSeq);
					fprintf(fus,",");
					fprintf(fus,Item_ID_str);
					fprintf(fus,",");
					fprintf(fus,CatiaOccName_str);
					fprintf(fus,",");
					fprintf(fus,occ_xform_matrix_str);
					fprintf(fus,",");
					if(qty==1 || qty ==0 )
					{
						fprintf(fus,"1");
						fprintf(fus,",");
					}
					if(qty >1)
					{
						sprintf(tmpchar,"%d",qty);
						printf("\nTCDCtmpchar is:%s and bl_Qty_str :%s and TmpQty:%d\n",tmpchar,bl_Qty_str,TmpQty);fflush(stdout);
						fprintf(fus,tmpchar);
						fprintf(fus,",");
					//	cLen=strlen(CatiaOccName_str);
					//	printf("\nTCDCcLen length of CatiaOccName_str :%d\n",cLen);
					//	tmpchar1=subString(CatiaOccName_str,(cLen-1),1);
						//printf("\nTCDCmulQtyIndex is:%d\n",mulQtyIndex);
						sprintf(tmpchar1,"%d",TmpQty);
						printf("\nTCDCtmpchar1 index  is:%s\n",tmpchar1);fflush(stdout);

						fprintf(fus,tmpchar1);
						fprintf(fus,",");

					}

					fprintf(fus,Item_ID_str);
					fprintf(fus,",");
					//fprintf(fus,User_str);
					//fprintf(fus,",");
					//fprintf(fus,"-");
					//fprintf(fus,",");
					//fprintf(fus,"reptest");
				}
				else
				{
					Flag=1;
					printf("\nTCDCdont expand for other parts Flag:%d\n",Flag);fflush(stdout);
				}
		}
		else
	        {
				printf("\nTCDCbl_Qty for chidren is:%d\n",bl_Qty);fflush(stdout);
				printf("\nTCDCbl_Qty for chidren is:%d\n",bl_Qty);fflush(stdout);
				fprintf(fus,Item_ID_str);
				fprintf(fus,",");
				fprintf(fus,Item_Revision_str);
				fprintf(fus,",");
				fprintf(fus,ITemRevSeq);
				fprintf(fus,",");
				fprintf(fus,ITemRevSeq);
				fprintf(fus,",");
				fprintf(fus,Item_ID_str);
				fprintf(fus,",");
				fprintf(fus,Item_Revision_str);
				fprintf(fus,",");
				fprintf(fus,ITemRevSeq);
				fprintf(fus,",");
				fprintf(fus,Item_ID_str);
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,"NULL");
				fprintf(fus,",");
				fprintf(fus,Item_ID_str);
				fprintf(fus,",");
				//fprintf(fus,"-");
				//fprintf(fus,",");
				//fprintf(fus,"reptest");
	}

	printf("\nTCDCcheck flag for single level exp:%d\n",Flag);fflush(stdout);
	if(Flag==0)
	{

	if(GRM_list_secondary_objects_only(itemrev,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
	if(n_attchs>0)
	{
		for (i= 0; i < n_attchs; i++)
		{
		   primary=secondary_objects[i];
		   if(TCTYPE_ask_object_type(primary,&objTypeTag));
		   if(TCTYPE_ask_name(objTypeTag,type_name));
		//   if (AOM_ask_value_string(type_name,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
//		   printf("\nTCDCDesc_obj is :%s\n",Desc_obj);
//
		   if(strcmp(type_name,"CMI2Product")==0 ||  strcmp(type_name,"CMI2Part")==0 || strcmp(type_name,"CMI2Drawing")==0 || strcmp(type_name,"DirectModel")==0)
		   {
			   if(AE_ask_dataset_id_rev(primary,&ret_id,&ret_rev));
			   if(AE_ask_dataset_ref_count(primary,&referencenumberfound));
			   for(j=0;j<referencenumberfound;j++)
			   {
				   if(AE_find_dataset_named_ref(primary,j,refname,&reftype,&refobject));
				   if(strcmp(refname,"catpart")==0 || strcmp(refname,"catproduct")==0 ||strcmp(refname,"catdrawing")==0 )
				   {
						   if(strcmp(refname,"catpart")==0)
						   {
									if( AE_get_bounding_boxes(primary, &numBoundingBoxes, &boundingBoxes));
						   }
						   if( IMF_ask_original_file_name(refobject,orig_name));
						  if(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,path_name1)!=ITK_ok)PrintErrorStack();

						  printf("\nTCDCpath_name1 in printbomis :%s\n",path_name1);fflush(stdout);
							 printf("\nTCDCorig_namein printbom is is :%s\n",orig_name);fflush(stdout);
							 printf("\nTCDCItem_Description- before printbom ->%s and Item_idP :%s\n",Item_Description_str,Item_idP );fflush(stdout);
							printf("\nTCDCPartType before Actualy printis :%s\n",PartType1);fflush(stdout);
							//  fprintf(fus,",");
							  fprintf(fus,orig_name);
							 fprintf(fus,",");
							 fprintf(fus,orig_name);
							 fprintf(fus,",");
							fprintf(fus,ITemRevSeq);
							fprintf(fus,",");
							fprintf(fus,User_str);
							fprintf(fus,",");
							fprintf(fus,"NULL");
							fprintf(fus,",");
							fprintf(fus,"NULL");
							fprintf(fus,",");
							fprintf(fus,PartType1);
							fprintf(fus,",");
							fprintf(fus,User_str);
							fprintf(fus,",");
							fprintf(fus,Desc_obj);
							 fprintf(fus,"\n");

				   }
			   }

		   }
		}
	}
	else printf("\nTCDCThere are no data item attached to it\n");fflush(stdout);
	if(BOM_line_ask_child_lines (line, &n, &children));

     TmpQty=0;
      p=0;

    for (k = 0; k < n; k++)
    {
      		qtyCnt1=0;
      	//	TmpQty=0;
      		if(Childobject1) Childobject1=NULLTAG;
      		Childobject1=children[k];

      		Item_Type1=0;
      		if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_Type1));
      		printf("\nTCDCItem_Type1 for k loop :%d\n",Item_Type1);fflush(stdout);
      		if(Item_ID_strW2) Item_ID_strW2=NULL; Item_ID_strW2=malloc(50);
      		if(BOM_line_ask_attribute_string(Childobject1, Item_Type1, &Item_ID_strW2));
      		printf("\nTCDCItem_ID_strW2 : %s for k :%d\n",Item_ID_strW2,k);fflush(stdout);


      		for (k1 = 0; k1 < n; k1++)
      		{
      				if(Childobject2) Childobject2=NULLTAG;
      					Childobject2=children[k1];

      					Item_Type1=0;
      					if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_Type2));
      					printf("\nTCDCItem_Type2 for k1 loop :%d\n",Item_Type2);fflush(stdout);
      					if(Item_ID_strW3) Item_ID_strW3=NULL; Item_ID_strW3=malloc(50);
      					if(BOM_line_ask_attribute_string(Childobject2, Item_Type2, &Item_ID_strW3));
      					printf("\nTCDCItem_ID_strW3 : %s for k1 :%d\n",Item_ID_strW3,k1);fflush(stdout);
      					if (strcmp(Item_ID_strW2,Item_ID_strW3)==0)
      					{
      								qtyCnt1++;
      								printf("\nTCDCfound more than once before print_bom Item_ID_strW2:%s and qtyCnt1:%d  and p:%d\n",Item_ID_strW2,qtyCnt1,p);fflush(stdout);

      					}
      		}


      		printf("\nTCDCBefore calling printbom Item_ID_strW2: %s and its qty in bom qtyCnt1:%d\n",Item_ID_strW2,qtyCnt1);fflush(stdout);

      		if (qtyCnt1 >1)
      		{

				printf("\nTCDCcalling  for print_bom qtyCnt1 >1 multiqty   for Item_ID_strW2 :%s for k:%d\n",Item_ID_strW2,k);fflush(stdout);
				print_bom (children[k],line,depth,Item_idP,Item_ID_strW2,qtyCnt1,p,fdf,fus);
				if(qtyCnt1 >1 && p < qtyCnt1) { p=p+1;}
				printf("\nTCDCcalling  print_bom recursively for k:%d\n",k);fflush(stdout);
      		}
      		if (qtyCnt1<=1)
      		{
				printf("\nTCDCcallingfor print_bom qtyCnt1 <1for Item_ID_strW2 :%s for k:%d\n",Item_ID_strW2,k);fflush(stdout);
				qtyCnt1=1;
				print_bom (children[k],line,depth,Item_idP,Item_ID_strW2,qtyCnt1,p,fdf,fus);
      		}
       }
 }
}
