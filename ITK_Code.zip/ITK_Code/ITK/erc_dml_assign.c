#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;


tag_t t5_UpdateRleaseStatus(tag_t object_tag)
{		
		tag_t		class_id				=     NULLTAG;
		char		*class_name				=    NULL;
		tag_t		tReleaseStatusList_checkin=NULLTAG; 
		logical		log1;
		int			n_values_checkin			=0;
		int			cunt1					=	0; 
		tag_t*		attr_tags_checkin		=	NULLTAG; 
		logical		*is_it_null_checkin		=   NULL; 
		logical		*is_it_empty_checkin	=   NULL;
		
		int status = ITK_ok;
		
		status = POM_class_of_instance(object_tag,&class_id);
		if(status==ITK_ok)
	    {
			printf("\n\n\t\t class_id found......\n");
		}		

		status = POM_name_of_class(class_id,&class_name);
		if(status==ITK_ok)
	    {
			printf("\n class_name is :%s\n",class_name);fflush(stdout);
		}		

		status = POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin);fflush(stdout);
		if(status==ITK_ok)
	    {
			printf("\n\n\t\t release_status_list found......\n");
		}

		status =POM_unload_instances (1,&object_tag);
		status =POM_load_instances(1,&object_tag,class_id,1);
		status =POM_is_loaded(object_tag,&log1);
		if(status==ITK_ok)
	    {
			printf("\n\n\t\t status Updated......\n");
		}

		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}else
		printf("Load Failure\n"  );

		status =POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin);
		if(status==ITK_ok)
	    {
			printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
		}
		
		if(n_values_checkin>0)
		{
			status = POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin);
			if(status==ITK_ok)
			{
				printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
			}

			for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);

				status =POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1);
				if(status==ITK_ok)
				{
					printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
				}			

				status =POM_save_instances(1,&object_tag,1);
				status =POM_refresh_instances(1,&object_tag,class_id,2);
				status =AOM_lock(object_tag);
				status =AOM_save(object_tag);
				status =AOM_refresh(object_tag,1);
			}

			 status =AOM_unlock(object_tag);
			 if(status==ITK_ok)
			 {
				printf("\n object_tag unlocked..........\n");fflush(stdout);
			 }
		  }
	return object_tag;
}
;

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp); 	
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);  
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  } 
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  } 
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  } 
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  } 
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  } 
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }   
}
void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp); 	
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	
	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);
	
	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");	
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

int setEffectivity(tag_t* itemRev,char* date)
{

	int status;
	logical   date_is_valid   = FALSE; 
	tag_t	  st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t	  st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;
	int   ifail				= 0;


	CALLAPI(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		CALLAPI(POM_class_of_instance(status_list[0],&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		CALLAPI(POM_unload_instances (st_count,status_list)); 
		CALLAPI(POM_load_instances(st_count,status_list,class_id,1));
		CALLAPI(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
			//CALLAPI(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
			//CALLAPI(WSOM_eff_set_date_range(status_list[0]));
			//WSOM_status_ask_effectivitie
			//CALLAPI(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
			CALLAPI(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"11-MAR-2014 00:00 to UP",&eff_t));
			CALLAPI(AOM_save(status_list[0]));
			CALLAPI(POM_save_instances(st_count,status_list,1));

		}else
		{
			printf("\n Cannot load this......");
		}
		//CALLAPI(AOM_save(*itemRev));
		//CALLAPI(AOM_unlock(*itemRev));
	}
	  return ITK_ok;
}

int erc_task_breakdown( EPM_action_message_t msg )
{	
		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l	,cnt	=0;
	
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
		tag_t			*objTypeTagTask			= NULLTAG;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
		tag_t DMLTag = NULLTAG;
		tag_t AssyTag = NULLTAG;
		tag_t PrtTag = NULLTAG;
		tag_t *Dml_tasks= NULLTAG;
		tag_t *PartsTag= NULLTAG;
		tag_t attach = NULLTAG;
		tag_t   release_status =NULLTAG;  
		tag_t    	    superuserTag				    =NULLTAG;
		tag_t    	    propEff_tag				    =NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;
		int  attype = 1,partcnt=0,k=0;
		
		char*			parent_name				=NULL; 
		char*			object_type				=NULL;	
		char*			Analyst_name			=NULL;	
		char*			DmlAnalyst_name			=NULL;	
		
		char*			task_no					=NULL;	
		char*			CurrentTask				=NULL;	
		char*			TaskName				=NULL;	
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;
		char*			Part_no					=NULL;
		char*			ReleaseStatus					=NULL;
		char*			value					=NULL;
		char			*eff_date         = NULL;
		char *FrmDate;
		char *ItemID;
		char cNextDate[20]={0};
		char cCurrentAccessDate[20]={0};
		date_t test_date_1;
		date_t cCurrent_date_1;
	    date_t DayTommorow ;
	    date_t test_date_2;
	    date_t *start_end_date = NULL;
	    //date_t *CLdate = NULL;
	    tag_t eff_d = NULLTAG;
		logical  retain_released_date =TRUE;
		logical stat  ;

		tag_t UpdateRlease_t1			= NULLTAG;
		tag_t UpdateRlease_t2			= NULLTAG;
		tag_t UpdateRlease_t3			= NULLTAG;

		POM_get_user(&username,&user_tag);
		printf("\nStarting for taskbreskdownnn :%s....\n",username);fflush(stdout);	
		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	    printf("\nCurrentTask:%s\n",CurrentTask);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);	
		
		getCurrentDateTime(cCurrentAccessDate);
		printf("\n added by :: skk - cCurrentAccessDate : %s\n",cCurrentAccessDate);
		
		if(strcmp(parent_name,"Change Request Life Cycle")==0 || strcmp(parent_name,"Module Release Workflow"))
		{
			//if(strstr(CurrentTask,"Add Solution item")!=NULL)
			CALLAPI(SA_find_user("infodba",&superuserTag));	
			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0)
			{
			    DMLTag = attachments[0];			    	
			}
			CALLAPI(AOM_lock(DMLTag));
			CALLAPI(AOM_set_value_string(DMLTag,"CMClosure","Closed"));
			CALLAPI(AOM_set_value_string(DMLTag,"CMMaturity","Complete"));
			CALLAPI(AOM_set_value_string(DMLTag,"CMDisposition","Approved"));	
			//CALLAPI(AOM_set_value_string(DMLTag,"CMClosureDate",cCurrentAccessDate));
			
			if(ITK_ok != (ifail = AOM_save(DMLTag)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
			{
				return ifail;
			}

			UpdateRlease_t1 = t5_UpdateRleaseStatus(DMLTag);
			if (UpdateRlease_t1)
			{
				printf("\n Status Updated NULL on DML Revision Object................\n");fflush(stdout);
			}else 
			printf("\n UpdateRlease_t1 not found! ! !");  fflush(stdout);
			
			CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
			CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

			if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
			{
				CALLAPI(EPM_add_release_status(release_status,1,&DMLTag,retain_released_date));
			}
			if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
			{
				return ifail;
			}

		    CALLAPI(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&cnt,&Dml_tasks));
			printf("\n Now cnt:%d\n",cnt);fflush(stdout);

			if (cnt>0)
			{
				for (i=0;i<cnt ;i++ )
				{
					   AOM_ask_value_string(Dml_tasks[i],"object_type",&object_type);
					   printf("\n object_type is :%s\n",object_type);fflush(stdout);

					   if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
					   {
							getCurrentDateTime(cCurrentAccessDate);
							printf("\n added by :: skk - cCurrentAccessDate : %s\n",cCurrentAccessDate);

							//AOM_set_value_date

							CALLAPI(AOM_lock(Dml_tasks[i]));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosure","Closed"));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMMaturity","Complete"));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMDisposition","Approved"));
							//CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosureDate",cCurrentAccessDate));
							
							if(ITK_ok != (ifail = AOM_save(Dml_tasks[i])))
							{
								return ifail;
							}

							if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
							{
								return ifail;
							}

							UpdateRlease_t2 = t5_UpdateRleaseStatus(Dml_tasks[i]);
							if (UpdateRlease_t2)
							{
								printf("\n Status Updated on DML Task................\n");fflush(stdout);
							}else 
							printf("\n UpdateRlease_t2 not found! ! !");  fflush(stdout);
							
							CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
							CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

							if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0  )
							{
								CALLAPI(EPM_add_release_status(release_status,1,&Dml_tasks[i],retain_released_date));
							}
							if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
							{
								return ifail;
							}

						    CALLAPI(AOM_UIF_ask_value(Dml_tasks[i],"Analyst",&DmlAnalyst_name));
						    printf("\nDml Task Analyst_name:%s\n",DmlAnalyst_name);fflush(stdout);

						    CALLAPI(AOM_ask_value_tags(Dml_tasks[i],"CMHasSolutionItem",&partcnt,&PartsTag));
						    printf("\n Now partcnt:%d\n",partcnt);fflush(stdout);

						   if (partcnt>0)
						   {
							 for (k=0;k<partcnt ;k++ )
							 {							
								printf("\n for k =:%d\n",k);fflush(stdout);
								AssyTag=PartsTag[k];

								CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));	
								printf("\n Part_no  is :%s\n",Part_no);	fflush(stdout);	

								UpdateRlease_t3 = t5_UpdateRleaseStatus(AssyTag);
								if (UpdateRlease_t3)
								{
									printf("\n Status Updated on TC Part Revision................\n");fflush(stdout);
								}else 
								printf("\n UpdateRlease_t2 not found! ! !");  fflush(stdout);
								
								CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
								CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

								if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
								{
									CALLAPI(EPM_add_release_status(release_status,1,&AssyTag,retain_released_date));
								}
								
		 						printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								if((strcmp(ReleaseStatus,"ERC Released")==0) ||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
								{
									if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat)))	 return ifail;  
									printf("\n stat:%d\n",stat);

									if(stat != true)
									{
										printf("\n stat is not true .....\n");
									}
									else
									{
										printf("\n stat is  true .....\n");
									}
									
									getCurrentDateTime(cCurrentAccessDate);
									if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
									if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail; 
									printf("\n effectivity_text is value : %s\n",value);
										
									getNextDate(cNextDate);
									printf("\n cNextDate:%s",cNextDate);
									//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;											
									
									if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))									
									{
										return ifail;
									}
									start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

									printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n"); 
																		
									start_end_date[0] = test_date_1;
									start_end_date[1] = test_date_2;
									
									if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( release_status)))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_save(eff_d)))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_save(release_status)))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = AOM_refresh( release_status, 0 )))
									{
										return ifail;
									}
										
									if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
									if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail; 
									printf("\n After setting effectivity_text value : %s\n",value);
									if(ITK_ok != (ifail = AOM_refresh( AssyTag, 0 )))
									{
										return ifail;
									}
										
								}
							  }
								
							}
						
						}
							
					 }

			 }
			   
	  }
	  else
	  {
		printf("\n inside this loop \n");fflush(stdout);
	  }
	
		return ITK_ok;
}

int createCR_Task( METHOD_message_t *msg, va_list  args ) 
{
    tag_t	TaskTag		= va_arg(args, const tag_t); 
    int*	n_values	= va_arg(args, int*); 
    char	***values	= va_arg(args, char***); 

	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;

	int max_char_size = 80;
	int n_tags_found = 0;

	int  
	error_code	= ITK_ok, 
	n_entries	= 2, 
	n_found		= 0,
	num=0,
	i=0,
	ii			= 0;

	tag_t 
	query			= NULLTAG, 
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	tag_t *tags_found = NULL;

	int number_found;
	tag_t *list_of_WSO_tags=NULLTAG;

	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DMLrlstype = NULL;
	char *DmlDR = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	WSO_search_criteria_t  	criteria;

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
    printf("\n **************inside createCR_Task***************\n ");fflush(stdout);
    
	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{		
		printf("\n inside class ChangeRequestRevision......\n");fflush(stdout);
		AOM_ask_value_string( TaskTag, "item_id", &item_id);
		AOM_ask_value_string( TaskTag, "current_id", &DML_no);
		AOM_ask_value_strings( TaskTag,"t5_crdesigngroup",&num,&DesignGroupList);
		AOM_ask_value_string( TaskTag, "t5_rlstype", &DMLrlstype);

		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n DML_no : %s\n",DML_no);fflush(stdout);
		printf("\n DMLrlstype : %s\n",DMLrlstype);fflush(stdout);
		printf("\n num is : %d\n",num);fflush(stdout);
		
		if(num > 0)
		{
			//DR Validations 1.30-Mohan
			printf("\n DRCHK:1.30:CRE: DR VALIDATION START...\n"); fflush(stdout);
			if((tc_strcmp(DMLrlstype,"TPL")==0) || (tc_strcmp(DMLrlstype,"MR")==0)|| (tc_strcmp(DMLrlstype,"Veh")==0)|| (tc_strcmp(DMLrlstype,"PR")==0)|| (tc_strcmp(DMLrlstype,"CQ")==0) ||
				(tc_strcmp(DMLrlstype,"ECU")==0)|| (tc_strcmp(DMLrlstype,"WTR")==0)|| (tc_strcmp(DMLrlstype,"PPR")==0)|| (tc_strcmp(DMLrlstype,"BEC")==0))
			{
				AOM_ask_value_string(TaskTag,"t5_cDRstatus",&DmlDR);
				printf("\n DRCHK: DmlDR..:[%s]",DmlDR);fflush(stdout);
				if(tc_strcmp(DmlDR,"")==0)
				{
					printf("\n DRCHK:ERROR:8.\n"); fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"DML DR-status should not be NULL.\n Please update valid DR/AR-status.");	
					return ITK_err;
				}
				if(tc_strcmp(DmlDR,"NA")==0)
				{
					printf("\n DRCHK:ERROR:9.\n"); fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"DML DR-status should not be NA.\n Please update valid DR/AR-status.");	
					return ITK_err;
				}
				
			}
			printf("\n MT:1.30:CRE: DR VALIDATION END...\n"); fflush(stdout);
			//DR Validations 1.30-Mohan

			if(tc_strcmp(DMLrlstype,"MR")==0)
			{
				for(i=0;i<num;i++)
				{
					strcpy(item_id_dup,item_id);
					strcat (item_id_dup,"_");
					strcat (item_id_dup,DesignGroupList[i]);
					printf("\n Task Name is :%s\n",item_id_dup);fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,item_id_dup);
					strcpy(criteria.class_name,"T5_ChangeTaskRevision");
					status	= WSOM_search(criteria, &number_found, &list_of_WSO_tags);
					printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

					if(number_found == 0)
					 {
						ITEM_create_item(item_id_dup,item_id_dup,"T5_ChangeTask",item_id_dup,&item,&rev);	
						printf("\n Item created first time only with item_id111111------ \n");fflush(stdout);
						AOM_save(item);
						AOM_save(rev);
						GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						GRM_create_relation(TaskTag, rev, relation_type,  NULLTAG, &relation);
						GRM_save_relation(relation);
					 }else { printf("\n item_id created twice......  \n");fflush(stdout); }
					 MEM_free(list_of_WSO_tags);
				 }
			}else
			{
				for(i=0;i<num;i++)
				{
					strcpy(item_id_dup,item_id);
					strcat (item_id_dup,"_");
					strcat (item_id_dup,DesignGroupList[i]);
					printf("\n Task count in DB :: %s\n",item_id_dup);fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,item_id_dup);
					strcpy(criteria.class_name,"T5_ChangeTaskRevision");
					status	= WSOM_search(criteria, &number_found, &list_of_WSO_tags);
					
					//ITEM_find_items_by_key_attributes(1, "item_id", item_id_dup, &n_tags_found, &tags_found);
					printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

					if(number_found == 0)
					{
						printf("\n item_id : %s and DML_no : %s\n ",item_id,DML_no);fflush(stdout);
						ITEM_create_item(item_id_dup,item_id_dup,"T5_ChangeTask",item_id_dup,&item,&rev);	
						printf("\n Item created first time only with item_id \n");fflush(stdout);

						AOM_save(item);
						AOM_save(rev);
						GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						GRM_create_relation(TaskTag, rev, relation_type,  NULLTAG, &relation);
						GRM_save_relation(relation);
					}else { printf("\n Required item_id already in DB....  \n");fflush(stdout); }
					MEM_free(list_of_WSO_tags);
				 }
			}
		}else
		{
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"for Release Type TPL/Module Release Design Group is mandatory. Pls select design group.");			
			return ITK_errStore1;
		}
	}

    return error_code; 
}

int T5TaskToPartCreateVal( METHOD_message_t *msg, va_list  args ) 
{ 
	va_list largs;
	va_copy( largs, args );

	tag_t  primary_object = va_arg(largs, tag_t);
	tag_t  secondary_object = va_arg(largs, tag_t);
	tag_t  relation_type = va_arg(largs, tag_t);
	tag_t  user_data = va_arg(largs, tag_t);	
	tag_t  *new_relation = va_arg(largs, tag_t *);

	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;
	int max_char_size = 80;

	int  
	error_code	= ITK_ok, 
	n_found		= 0,
	num=0,
	i=0,
	ii	,st_count1,cnt, tskcnt	,pcnt,j	= 0;
	int count,p1 = 0;

	tag_t 
	query			= NULLTAG, 
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	objTypeTag1=NULLTAG,
	objTypeTag2=NULLTAG,
	ObjTypDmlCRB=NULLTAG,
	ObjTypTskCRB=NULLTAG,
	item=NULLTAG,
	SpecTypeTag = NULLTAG,
	TaskTypeTag = NULLTAG,
	RefTypeTag = NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	tag_t*    status_list1=NULLTAG;
	//char *item_id_dup 	   = NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *DML_no = NULL;
	char *WSO_Name = NULL;
	char *projcode = NULL;
	char *projectname = NULL;
	char *item_id_secObj = NULL;
	char *item_id_priObj = NULL;
	char *tsk_object_type = NULL;
	char *t5fnd0Workflows = NULL;
	char **DesignGroupList;
	char *type_name1;
	int	   *instance_levels;
	int	   *instance_where_found;
	int    *class_levels;
	int    *class_where_found;
	int    n_instances		= 0;
	int    n_classes	,k	= 0;
	tag_t  *ref_classes		= NULLTAG;
	tag_t  *ref_instances	= NULLTAG;	
	tag_t  *Primary_objects	= NULLTAG;	
	tag_t  *PrimaryObjects	= NULLTAG;	
	tag_t  task_class		= NULLTAG;	
	tag_t  condition_class	= NULLTAG;	
	tag_t  classId			= NULLTAG;
	tag_t *DMLRevision = NULLTAG;
    tag_t DMLRevTag = NULLTAG;
    tag_t TskSOTag = NULLTAG;
	tag_t tsk_dml_rel_type;
	tag_t SpecRel_tag;
	tag_t RefRel_tag;
	tag_t class_id1=NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t *SpecDoc_tag=NULLTAG;
	tag_t *attacheTo_tag=NULLTAG;
	tag_t *RefDoc_tag=NULLTAG;
    //tag_t tsk_dml_rel_type;
	char*	 RevpartType		= NULL;	
	tag_t reln_type =NULLTAG;
  	char* DMLtype		= NULL;	
	char *sDrwInd;
	char *sRCurDes;
	char *sSpCurDes;
	char *sCurDes;
	char *username;
	char *username1;
	char *curentname;
	char *selectedname;
	char *selectedDMLname;
	tag_t   Childobject=NULLTAG;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t  	master =	NULLTAG;
	char*	 Arch_obj_str			= NULL;
	tag_t  relation_dep	= NULLTAG;
	int countConfigCtx = 0;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;
	 tag_t	queryTag	= NULLTAG;
	int n_entries = 1;
	char *qry_entries[1] = {"ID"};
	int resultCount=0;
	tag_t *rev=NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
	char*	 ContextobjName			= NULL;

	//MT start
	int jk, jkk, tsk = 0;
	int TskCRBcount = 0;
	int CRBcount = 0;
	int Tskcount = 0;
	int n_parents,n1_parents = 0;
	int *levels = 0;
	char* TskNm = NULL;
	char* projChar = NULL;
	char* DesgChar = NULL;
	char* AnaAssignee = NULL;
	char* Assignee = NULL;
	char* performer = NULL;
	char* AssigneeGrp = NULL;
	char* DsgGrp = NULL;
	char *DerRoleNme = NULL;
	char *PeerRevNm = NULL;
	char *ManAccesNm = NULL;
	char *DMUAccesNm = NULL;
	char* Part_no = NULL;
	char* LcStus = NULL;
	char* DMLReviewGrp = NULL;
	char* DMLReviewr = NULL;
	char* TskAnlyst = NULL;
	char* DMUReviewGrp = NULL;
	char* TskAnlystGrp = NULL;
	char* DMUReviewr = NULL;
	char *Task_class = NULL;
	char *TaskAnlyst = NULL;
	char *taskTempLT = NULL;
	tag_t *parents = NULLTAG;
	tag_t projTag = NULLTAG;
	tag_t Ana_tag = NULLTAG;
	tag_t dml_tsk_rel_type = NULLTAG;
	tag_t tsk_CRB_rel_type = NULLTAG;
	tag_t dml_CRB_rel_type = NULLTAG;
	tag_t *TskRevision = NULLTAG;
	tag_t *DmlCRB = NULLTAG;
	tag_t *TskCRB = NULLTAG;
	tag_t TskCRBTag = NULLTAG;
	tag_t DmlCRBTag = NULLTAG;
	tag_t TskRevTag = NULLTAG;
	tag_t Task_cls = NULLTAG;
	char   type_name8[TCTYPE_name_size_c+1];
	char   type_name7[TCTYPE_name_size_c+1];
	logical is_Tsklatest;
	//MT End
	char *class_name1;
	int	ifail = 0;
	int	Speccount = 0,Refcount=0,is=0,ik=0,jr=0,intDrgCnt=0,sflag=0,rflag=0, n=0, ToTaskCnt=0;
    tag_t   window,rule,item_tag = null_tag,top_line;
	tag_t  *children1=NULLTAG;

	logical is_latest;
	
	int jd = 0;
	tag_t ArchAssyTag = NULLTAG;
	char*	 Arch_obj			= NULL;
	tag_t ArchobjTypeTag=NULLTAG;
	char *child_item_id=NULL;
	char *child_bl_formula=NULL;

	char   Archtype_name[TCTYPE_name_size_c+1];

	//logical is_Design; 
	//DR-Validation
	int DMLSTVAL = 0;
	int PRTSTVAL = 0;
	char*	 DMLSubStr = NULL;
	char*	 PRTSubStr = NULL;
	char*	 DmlDR = NULL;
	char*	 PrtType = NULL;
	char*	 PrtClass = NULL;
	char*	 PrtColInd = NULL;
	char*	 PrtDR = NULL;
	tag_t  	PrtCls =	NULLTAG;
	//DR-Validation
	tag_t  	Itemtag =	NULLTAG;
	tag_t	latestrev	=	NULLTAG;

	char   type_name[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   object_name[TCTYPE_name_size_c+1];
	char   Spectype_name[TCTYPE_name_size_c+1];
	char   Tasktype_name[TCTYPE_name_size_c+1];
	char   Reftype_name[TCTYPE_name_size_c+1];
	tag_t	relation	,propTag	,task_tag,taskDMLobj		= NULLTAG;

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	printf("\n **************inside T5TaskToPartCreateVal for DML and Task***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	if(strcmp(type_name,"T5_ChangeTaskRevision")==0)
	{
	CALLAPI(POM_get_user_id (&username));
	printf("\n\n  Session login User1 for MR : %s\n",username); fflush(stdout);

	if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
    {	
	
	printf("\n T5TaskToPartCreateVal primary_object  type_name MR:: %s\n", type_name);fflush(stdout);
	
	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	if (tsk_dml_rel_type!=NULLTAG)
	{		
	  CALLAPI(GRM_list_primary_objects_only(primary_object,tsk_dml_rel_type,&count,&DMLRevision));
	  printf("\n\n\t\t DML Revision from Task for MR : %d",count);fflush(stdout);	
	  for (j=0;j<count ;j++ )
	  {	
		CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
		printf("\n\n\t\t is_latest MR is : %d\n",is_latest);fflush(stdout);

		if(is_latest != true)
		{
			printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
		}else
		{	
			DMLRevTag = DMLRevision[j];
			CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
			CALLAPI(POM_name_of_class(class_id1,&class_name1));
			printf("\n\n\t\t class_name found1 MR :%s",class_name1);
			
			CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
			printf("\n\n\t\t DMLtype changingg is :%s",DMLtype);fflush(stdout);

			//if(tc_strcmp(DMLtype,"MR")!=0)
			//{	
			   if(secondary_object!=NULLTAG)
			   {
				   if(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
				   if(TCTYPE_ask_name(objTypeTag2,type_name2));
				   printf("\n T5TaskToPartCreateVal secondary_object  type_name2 :: %s\n", type_name2);fflush(stdout);
			  
					printf("\n Inside T5_ChangeTaskRevision part to taskkk \n");fflush(stdout);
					if(relation_type != NULLTAG)
					{
						CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
					}
					printf("\n Neww relation_name  T5TaskToPartCreateVal CMHasSolutionItem:%s \n",relation_name);fflush(stdout);
						//MT: task start
					printf("\n TASK: Working for ChangeRequestRevision\n");fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(primary_object,"t5project",&projChar));
					CALLAPI(AOM_UIF_ask_value(primary_object,"item_id",&TskNm));
					CALLAPI(AOM_UIF_ask_value(primary_object,"t5designgroup",&DesgChar));
					printf("\n TASK: Task: [%s] Project:[%s] DesgChar:[%s]\n",TskNm,projChar,DesgChar);fflush(stdout);
					CALLAPI(PROJ_find(projChar,&projTag));
					if(strcmp(relation_name,"HasParticipant")==0)
					{
					
						printf("\n TASK:Checking for Analyst: Relation Name:[%s] pri_object:[%s] Sec_object:[%s].\n",relation_name,type_name,type_name2);fflush(stdout);
						CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeUser",&AnaAssignee));
						CALLAPI(AOM_UIF_ask_value(secondary_object,"assignee",&Assignee));
						printf("\n TASK: AnaAssignee: %s	Assignee: %s ", AnaAssignee,Assignee);fflush(stdout);
						CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeGroup",&AssigneeGrp));
						printf("\n TASK: AssigneeGrp: %s", AssigneeGrp);fflush(stdout);

						DsgGrp=subString(TskNm,11,2);
						printf("\n TASK: DsgGrp: %s",DsgGrp);fflush(stdout);
						
						//third logic
						if(strcmp(type_name2,"Analyst")==0)
						{
							CALLAPI(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type));
							if (dml_CRB_rel_type!=NULLTAG)
							{
								printf("\n TASK:inside HasParticipant.. \n");fflush(stdout);
								CALLAPI(GRM_list_secondary_objects_only(DMLRevTag,dml_CRB_rel_type,&CRBcount,&DmlCRB));
								printf("\n TASK: DmlCRB count: %d",CRBcount);fflush(stdout);	
								for (jk=0;jk<CRBcount ;jk++ )
								{	
									printf("\n TASK:jk: %d.\n",jk);fflush(stdout);
									DmlCRBTag = DmlCRB[jk];
									if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
									if(TCTYPE_ask_name(ObjTypDmlCRB,type_name7));
									printf("\n TASK:DML: type_name7 :: %s\n", type_name7);fflush(stdout);
									if (strcmp(type_name7,"ChangeReviewBoard")==0)
									{
										CALLAPI(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr));
										CALLAPI(AOM_UIF_ask_value(DmlCRBTag,"assignee",&DMLReviewGrp));
										printf("\n TASK: DML Reviewer: [%s] Group: [%s] ",DMLReviewr,DMLReviewGrp);fflush(stdout);
									}
									if (strcmp(type_name7,"T5_DMUReviewer")==0)
									{
										CALLAPI(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMUReviewr));
										CALLAPI(AOM_UIF_ask_value(DmlCRBTag,"assignee",&DMUReviewGrp));
										printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
									}
								}
							}
							printf("\n TASK: DMLReviewr: [%s]	DMUReviewr: [%s] and Assignee: [%s] \n", DMLReviewr,DMUReviewr,AnaAssignee);fflush(stdout);
							//if((strcmp(DMLReviewr,AnaAssignee)==0) && (DMLReviewr!=NULL))
							
							if(DMLReviewr!=NULL)
							{
								printf("\n DML Reviewer Check \n");fflush(stdout);
								if(strcmp(DMLReviewr,AnaAssignee)==0)
								{
									printf("\n TASK: ERROR:DML Reviewer and Task Analyst should not be same.!!!!!!!!!!!!! \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DML reviewer and task analyst should not be same.");	
									return ITK_err;
								}
							}
							if(DMUReviewr!=NULL)
							{
								printf("\n DMU Reviewer Check \n");fflush(stdout);
								if(strcmp(DMUReviewr,AnaAssignee)==0)
								{
									printf("\n TASK: ERROR:DMU Reviewer and Task Analyst should not be same.!!!!!!!!!!!!! \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Dml DMU reviewer and task analyst should not be same.");	
									return ITK_err;
								}
							}
							printf("\n TASK:DML Reviewer and Task Analyst are not same.!!!!!!!!!!!!! \n");fflush(stdout);
							DerRoleNme=NULL;DerRoleNme=malloc(50);
							if (strlen(DsgGrp) ==0)
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Design group is not available.");	
								return ITK_err;
							}
							strcpy(DerRoleNme,DsgGrp);
							strcat(DerRoleNme,"_Designers");
							printf("\n TASK:Role name required: [%s]",DerRoleNme);fflush(stdout);
							if(strstr(Assignee,DerRoleNme)!=NULL)
							{
								printf("\n TASK: User having access for TASK project!!!!!!!!!!!!! \n");fflush(stdout);
							}
							else
							{
								printf("\n TASK: User NOT having access for Analyst. \n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Analyst should have access for task design group. Kindly get access from TCUA Admin.");	
								return ITK_err;
							}
							
						}
						else if(strcmp(type_name2,"T5_PeerReviewer")==0)
						{
							printf("\n TASK: Peer reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_DMUReviewer")==0)
						{
							printf("\n TASK: DMU reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_BIWReviewer")==0)
						{
							printf("\n TASK: BIW Reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_TRIMReviewer")==0)
						{
							printf("\n TASK: TRIM Reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_CHReviewer")==0)
						{
							printf("\n TASK: Chassis reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_EEReviewer")==0)
						{
							printf("\n TASK: EE reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_PTReviewer")==0)
						{
							printf("\n TASK: Powertrain reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else
						{
							printf("\n TASK: User having access for TASK project !!!!!!!!!!!!! \n");fflush(stdout);
						}
					}
					//MT task End T5_DMUReviewer
										
					CALLAPI(GRM_list_secondary_objects_only(primary_object,reln_type,&ToTaskCnt,&attacheTo_tag));
					printf("\n ToTaskCnt Value :-------------------->>>> Hanuman  %d\n",ToTaskCnt);fflush(stdout);
					if(ToTaskCnt > 0)
				    {
						for (ik=0;ik<ToTaskCnt;ik++ )
						{	
							
							if(TCTYPE_ask_object_type(attacheTo_tag[ik],&TaskTypeTag));
							if(TCTYPE_ask_name(TaskTypeTag,Tasktype_name));
							printf("\n     T5TaskToPartCreateVal Having relation Name :: %s\n", Tasktype_name);fflush(stdout);
						}
				    }
	
					//TZ 1.28 Rajendra - Check DML owner and Session User
					if(tc_strcmp(relation_name,"CMHasSolutionItem")==0)
					{
					  printf("\n     Inside attaching part to taskkk \n");fflush(stdout);
					  if(tc_strcmp(type_name2,"Design Revision")==0 || tc_strcmp(type_name2,"ItemRevision")==0)
					  {	

						  CALLAPI(AOM_UIF_ask_value(primary_object,"fnd0ActuatedInteractiveTsks",&taskTempLT));
						  printf("\n primary taskTempLT is .. Add Part: %s\n",taskTempLT);fflush(stdout);
						  
						  if(tc_strcmp(taskTempLT,"Add solution items")==0)
						  {
							    CALLAPI(AOM_UIF_ask_value(primary_object,"analyst_user_id",&TaskAnlyst));
								//CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeUser",&AnaAssignee));
															
								printf("\n TaskAnlyst [%s] ",TaskAnlyst);fflush(stdout);
									
								if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
								{
									if(tc_strcmp(username,TaskAnlyst) !=0)
										{
											printf("\n Inside loop 'Add solution items'.....\n"); fflush(stdout);	

											EMH_store_error_s2(EMH_severity_warning,ITK_err,"Session User is Not Task Analyst..Only Analyst Can Add Part To DML Task.Task Analyst Is:",TaskAnlyst); 	
											
											return ITK_err;
										}				
									else
										{
											printf("\n Session user is Analyst   ...:%s\n",TaskAnlyst); fflush(stdout);
										}
								}
								else
								{

									printf("\n bypass for infodba & loader   ...\n"); fflush(stdout);

								}
						  }else
						  {
							EMH_store_error_s2(EMH_severity_warning,ITK_err,"The Task Is Not For Assignment Of Add Solution Items","You cannot add parts to SolutionItem of the task."); 	
							return ITK_err;
						  }

						//Added By Rajendra-End
                                 
						int TskCnt=0;
						tag_t *TskSO=NULLTAG;
						CALLAPI( GRM_list_primary_objects_only(secondary_object,relation_type,&TskCnt,&TskSO));
						printf("\n Task Count :-------------------->>>>  %d\n",TskCnt);fflush(stdout);

						if (TskCnt > 0)
						{		
								TskSOTag = TskSO[0];
								printf("\n TskSOTag---------------> \n"); fflush(stdout);

								if( AOM_ask_value_string(TskSOTag,"item_revision_id",&selectedDMLname)==ITK_ok)
								printf("\n selected Task name---------------> %s\n",selectedDMLname); fflush(stdout);
		

								EMH_store_error_s2(EMH_severity_error,ITK_errStore1,"Design Revison is already attached to other task :: ",selectedDMLname);	
								return ITK_errStore1;
						}		
						
						if( AOM_ask_value_string(secondary_object,"object_string",&selectedname)==ITK_ok)
						printf("\n selected revision---------------> %s\n",selectedname);fflush(stdout);

						
						//CALLAPI(ITEM_rev_sequence_is_latest(secondary_object,&is_Design));
						//printf("\n\t select Design revision status---------> : %d\n",is_Design);fflush(stdout);
						
						CALLAPI(ITEM_ask_item_of_rev(secondary_object, &Itemtag)); 
						printf("\n ITEM_Found......");fflush(stdout);
						
						CALLAPI(ITEM_ask_latest_rev(Itemtag,&latestrev));
						if (latestrev!=NULLTAG)
						{
							if( AOM_ask_value_string(latestrev,"object_string",&curentname)==ITK_ok)
							printf("\n latest revision---------------> %s\n",curentname);fflush(stdout);
						}
						
						if(tc_strcmp(curentname,selectedname)!=0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach Latest Modules/Parts to the task.");	
							return ITK_err;
						}

						CALLAPI(AOM_ask_value_string(latestrev,"t5_PartType",&RevpartType));
						printf("\n\n\t\t partType of droped object is :%s\n",RevpartType);fflush(stdout);   //M

						//DR Validations 1.30-Mohan
						printf("\n DRCHK:1.30: DR VALIDATION LIVE FOR PART TO TASK ATTACHMENT...\n"); fflush(stdout);
						if((tc_strcmp(DMLtype,"TPL")==0) || (tc_strcmp(DMLtype,"MR")==0)|| (tc_strcmp(DMLtype,"Veh")==0)|| (tc_strcmp(DMLtype,"PR")==0)|| (tc_strcmp(DMLtype,"CQ")==0) ||
							(tc_strcmp(DMLtype,"ECU")==0)|| (tc_strcmp(DMLtype,"WTR")==0)|| (tc_strcmp(DMLtype,"PPR")==0)|| (tc_strcmp(DMLtype,"BEC")==0))
						{
							CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DmlDR));
							CALLAPI(AOM_ask_value_string(latestrev,"t5_PartType",&PrtType));
							CALLAPI(AOM_ask_value_string(latestrev,"t5_PartStatus",&PrtDR));
							CALLAPI(AOM_ask_value_string(latestrev,"t5_ColourInd",&PrtColInd));
							printf("\n DRCHK: DmlDR:[%s] PrtDR:[%s] PrtType:[%s]",DmlDR,PrtDR,PrtType);fflush(stdout);
							CALLAPI(POM_class_of_instance(latestrev,&PrtCls));
							CALLAPI(POM_name_of_class(PrtCls,&PrtClass));
							printf("\n DRCHK:PrtClass :%s",class_name1); fflush(stdout);
							if(((tc_strcmp(PrtType,"V")==0) || (tc_strcmp(PrtType,"VCCR")==0)|| (tc_strcmp(PrtType,"A")==0) || (tc_strcmp(PrtType,"T")==0) || (tc_strcmp(PrtType,"C")==0) || 
								(tc_strcmp(PrtType,"M")==0)||(tc_strcmp(PrtType,"G")==0)) && ((tc_strcmp(PrtColInd,"Y")==0) || (tc_strcmp(PrtColInd,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0))
							{
								if(tc_strcmp(DmlDR,"")==0)
								{
									printf("\n DRCHK:ERROR:1.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DML DR-status should not be NULL. Please update valid DR/AR-status.");	
									return ITK_err;
								}
								if(tc_strcmp(PrtDR,"")==0)
								{
									printf("\n DRCHK:ERROR:2.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Part DR-status should not be NULL. Please update valid DR/AR-status.");	
									return ITK_err;
								}
								if(tc_strcmp(DmlDR,"NA")==0)
								{
									printf("\n DRCHK:ERROR:3.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DML DR-status should not be NA. Please update valid DR/AR-status.");	
									return ITK_err;
								}
								if(tc_strcmp(PrtDR,"NA")==0)
								{
									printf("\n DRCHK:ERROR:4.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Part DR-status should not be NA. Please update valid DR/AR-status.");	
									return ITK_err;
								}
								DMLSubStr=subString(DmlDR, 2, 1);
								PRTSubStr=subString(PrtDR, 2, 1);
								printf("\n DRCHK: DMLSubStr: %s, PRTSubStr: %s",DMLSubStr,PRTSubStr);fflush(stdout);
								DMLSTVAL=atoi(DMLSubStr);
								PRTSTVAL=atoi(PRTSubStr);
								printf("\n DRCHK: DMLDRi: %d, PRTDRi: %d",DMLSTVAL,PRTSTVAL);fflush(stdout);

								if (DMLSTVAL<=3 && PRTSTVAL>=4)
								{
									printf("\n DRCHK:ERROR:6.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Part with DR/AR-status AR4/AR5/DR4/DR5 can not be attached to Dml with AR3/DR3 status or less.");	
									return ITK_err;
								}
								if (DMLSTVAL>=4 && PRTSTVAL<=3)
								{
									printf("\n DRCHK:ERROR:7.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"If DML with DR/AR-status AR4/DR4, then Part status should be AR4/AR5/DR4/DR5.\n if DML having DR/AR-status AR5/DR5, then Part AR-status should be AR5/DR5.");	
									return ITK_err;
								}
								if (PRTSTVAL<DMLSTVAL)
								{
									printf("\n DRCHK:ERROR:5.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DR/AR-Status of the Part should not be less than DR/AR status of the DML.\n It should be equal or above than dml DR/AR-status.");	
									return ITK_err;
								}
							}
						}
						printf("\n MT:1.30: DR VALIDATION END...\n"); fflush(stdout);
						//DR Validations 1.30-Mohan
														
						printf("\n\t Going To Start Checl Structure........\n");fflush(stdout);
						if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
						if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();		
						if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();	
						if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_top_line (window, null_tag, latestrev, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
						
						if(BOM_line_ask_child_lines (top_line, &n, &children1));	
						printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

						if(tc_strcmp(RevpartType,"M")==0)
						{							
							if(n==0)
							{	
								EMH_store_error_s2(EMH_severity_error,ITK_err, curentname, "Module has no structure hence can not be attached to DML");
								return ITK_err;						
							}

							CALLAPI(AOM_ask_value_string(latestrev,"item_id",&Part_no));
							printf("\n\n\t CP Part_no  is :%s",Part_no);	fflush(stdout); //003906			

							CALLAPI(PS_where_used_all(latestrev,1,&n_parents,&levels,&parents));
							printf("\n\t CP where_used count of objects are Drag Drop : %d",n_parents); fflush(stdout); // 1

							if(n_parents>0)
							{
							  for (jd=0;jd<n_parents;jd++ )
							  {		
								ArchAssyTag=parents[jd];														
								CALLAPI(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj));    //003915
								printf("\n\t Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);														
									
								if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
								if(TCTYPE_ask_name(ArchobjTypeTag,Archtype_name));
								printf("\n\t Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

								if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
								{
									 printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);										
									 if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
									 if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();		
									 if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();	
									 if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
									 if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
									 if(top_line!=NULLTAG)
									 {
									    if(BOM_line_ask_child_lines(top_line, &n, &children1));	
									    printf("\n\t No of child objects are n : %d",n);fflush(stdout);
										if (n >0)
										{
										  for (p1=0;p1<n ;p1++ )
										  {
											if(Childobject) Childobject=NULLTAG;
											Childobject=children1[p1];
											CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
											printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

											if(tc_strcmp(Part_no,child_item_id)==0)
											{
											   CALLAPI(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ));
											   printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

											   CALLAPI(ITEM_ask_item_of_rev(ArchAssyTag, &master));
												CALLAPI(AOM_ask_value_string(master,"item_id",&Arch_obj_str));
												printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

												CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
												if(relation_dep != NULLTAG)
												{
													printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);	
												}																	
												 
												CALLAPI(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
												printf("\n\t Configuration Context count is : %d",countConfigCtx);

												if(countConfigCtx>0)
												{
													  ConfigCtx=ConfigCtxSecObject[0];
													  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
													  CALLAPI(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));	  
													  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
													  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);	 

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
													  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

													  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
													  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
													  if (queryTag)
													  {
														printf("\n\tFound Query");fflush(stdout);
													  }else
													  {
														printf("\n\tNot Found Query");fflush(stdout);
													  }									  	 

													  qry_values[0] = SmCrIDContext;

													  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
													  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);

												  
													if(tc_strcmp(child_bl_formula,"")==0 && resultCount >0)
													{
														printf("\n CC available Variant formula not available \n"); fflush(stdout);
														EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",child_item_id);
														return ITK_err;		
													}
													else
													{ 
													  int cnt=0;

													  for (j=0;j<resultCount;j++ )
													  {
														 Optfmly_tag = rev[j];
														 CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
														 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
																											 
														 if(ContextobjName)
														 {
															// printf("\n\t Variant formula is incompleteeeee :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
															  printf("\n\t child_bl_formula value:%s",child_bl_formula);
															 printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(child_bl_formula,ContextobjName)); fflush(stdout);

															
															if(tc_strstr(child_bl_formula,ContextobjName)==NULL)
															{
																printf("\n inside iff \n"); fflush(stdout);
																cnt++;
																
															}
															else
															 {
																printf("\n inside else \n"); fflush(stdout);
															
															 }
														 }
													  }

													  printf("\n cnt value is at end for loop :%d\n",cnt); fflush(stdout);
													  if (cnt>0)
													  {
																 printf("\n cnt greator than 1 :%d\n",cnt); fflush(stdout);
																//EMH_clear_errors();
																EMH_store_error_s2(EMH_severity_error,ITK_err, "Variant formula is not complete for Module",child_item_id);
																return ITK_err;	
													  }

													}
												}
											}
										  }
										}
									 }
								}
							  }
							}
							else //SKS Start
							{
									EMH_store_error_s2(EMH_severity_error,ITK_err, curentname, "Module not attached to any architecture node.");
									return ITK_err;	
							} //SKS END
					    }
						
						if( AOM_ask_value_string(secondary_object,"t5_DrawingInd",&sDrwInd)==ITK_ok)
						printf("\nsDrwInd Value :-------------------->>>> Rajendra   %s\n",sDrwInd);fflush(stdout);

						CALLAPI(GRM_find_relation_type("IMAN_specification", &SpecRel_tag));
						
						if(SpecRel_tag)
						{
							CALLAPI(GRM_list_secondary_objects_only(secondary_object,SpecRel_tag,&Speccount,&SpecDoc_tag));
							printf("\n Speccount Value :-------------------->>>> Rajendra   %d\n",Speccount);fflush(stdout);


								for (is=0;is<Speccount;is++ )
								{	
									
									if(TCTYPE_ask_object_type(SpecDoc_tag[is],&SpecTypeTag));
									if(TCTYPE_ask_name(SpecTypeTag,Spectype_name));
									printf("\n     T5TaskToPartCreateVal RefDoc_tag  Spectype_name :: %s\n", Spectype_name);fflush(stdout);
								
										if(!strcmp(Spectype_name,"ProDrw"))
										{
											if( AOM_ask_value_string(SpecDoc_tag[is],"current_desc",&sSpCurDes)==ITK_ok)
											printf("\nsCurDes Value :-------------------->>>> Rajendra   %s\n",sSpCurDes);fflush(stdout);
											printf("\n ProDrw \n");fflush(stdout);
											intDrgCnt++;
											sflag=1;
											break;
										}
										else if(!strcmp(Spectype_name,"CMI2Drawing"))
										{
											if( AOM_ask_value_string(SpecDoc_tag[is],"current_desc",&sSpCurDes)==ITK_ok)
											printf("\nsCurDes Value :-------------------->>>> Rajendra   %s\n",sSpCurDes);fflush(stdout);
											printf("\n CMI2Drawing \n");fflush(stdout);
											intDrgCnt++;
											sflag=1;
											break;
										}

								}
								
								if(sflag==1)
								{
									if(strcmp(sSpCurDes,"")==0)
									{
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Drwaing Desc is NULL");	
										return ITK_errStore1;
									}
								}
						}

						CALLAPI(GRM_find_relation_type("IMAN_reference", &RefRel_tag));

						if(RefRel_tag)
						{
							CALLAPI(GRM_list_secondary_objects_only(secondary_object,RefRel_tag,&Refcount,&RefDoc_tag));
							printf("\n Refcount Value :-------------------->>>> Rajendra   %d\n",Refcount);fflush(stdout);

								for (jr=0;jr<Refcount;jr++ )
								{	
									if(TCTYPE_ask_object_type(RefDoc_tag[jr],&RefTypeTag));
									if(TCTYPE_ask_name(RefTypeTag,Reftype_name));
									printf("\n     T5TaskToPartCreateVal RefDoc_tag  Reftype_name :: %s\n", Reftype_name);fflush(stdout);

										if(!strcmp(Reftype_name,"ProDrw"))
										{
											if( AOM_ask_value_string(RefDoc_tag[jr],"current_desc",&sRCurDes)==ITK_ok)
											printf("\nsRCurDes Value :-------------------->>>> Rajendra   %s\n",sRCurDes);fflush(stdout);
											printf("\n REefProDrw \n");fflush(stdout);
											intDrgCnt++;
											rflag=1;
											break;
										}
										else if(!strcmp(Reftype_name,"CMI2Drawing"))
										{
											if( AOM_ask_value_string(RefDoc_tag[jr],"current_desc",&sRCurDes)==ITK_ok)
											printf("\nsRCurDes Value :-------------------->>>> Rajendra   %s\n",sRCurDes);fflush(stdout);
											printf("\n RefCMI2Drawing \n");fflush(stdout);
											intDrgCnt++;
											rflag=1;
											break;
										}
								}

								if(rflag==1)
								{
									if(strcmp(sRCurDes,"")==0)
									{
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"RefDrwaing Desc is NULL");	
										return ITK_errStore1;
									}
								}

						}

						// check dataset having  current_desc is  null

                        if(((tc_strcmp(sDrwInd,"N")==0)||(tc_strcmp(sDrwInd,"A")==0))&&(intDrgCnt>0))
						{
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1," Part having drawing but DrwInd is not D/S");	
						return ITK_errStore1;
							
						}
						//if(!strcmp(sDrwInd,"D")&&(intDrgCnt==0))
                        if(((tc_strcmp(sDrwInd,"D")==0)||(tc_strcmp(sDrwInd,"S")==0))&&(intDrgCnt==0))
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"DrwInd is D/S but part do not have any drawing");	
							return ITK_errStore1;
						}

						//if(!strcmp(sDrwInd,"D")&&(intDrgCnt==2))
						if(((tc_strcmp(sDrwInd,"D")==0)||(tc_strcmp(sDrwInd,"S")==0))&&(intDrgCnt==2))
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"part having both drwdoc and refdoc attached. ");	
							return ITK_errStore1;
						}
						
						CALLAPI(WSOM_ask_release_status_list(secondary_object,&st_count1,&status_list1));
						printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

						if(st_count1>0)
						{
							for (cnt=0;cnt< st_count1;cnt++ )
							{
								CALLAPI(AOM_ask_name(status_list1[cnt],&WSO_Name));
								printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
								
								
								//if ((strcmp(WSO_Name,"ERC Review")!=0) || (strcmp(WSO_Name,"T5_LcsReview")!=0))
								if (strcmp(WSO_Name,"T5_LcsReview")!=0)
								{		
									printf("\n inside loop........\n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"You Can't attach Part with Life Cycle State other than ERC Review to the task.");	
									return ITK_err;
								}else
								{
									printf("\n inside else loop........\n");fflush(stdout);

								}
							}
						}

						if( AOM_ask_value_string(secondary_object,"item_id",&item_id_secObj)==ITK_ok)
						printf("\n item_id_secObj : %s\n",item_id_secObj);fflush(stdout);

						if( AOM_ask_value_string(secondary_object,"t5_ProjectCode",&projcode)==ITK_ok)
						printf("\n Projectcode from rightObject : %s\n",projcode);fflush(stdout);
										
						if( AOM_ask_value_string(primary_object,"item_id",&item_id_priObj)==ITK_ok)
						printf("\n item_id_priObj : %s\n",item_id_priObj);fflush(stdout);						
						
						CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
						if (tsk_dml_rel_type!=NULLTAG)
						{
							CALLAPI(GRM_list_primary_objects_only(primary_object,tsk_dml_rel_type,&count,&DMLRevision));
							printf("\n\t\t DML Revision from Task : %d",count);fflush(stdout);
							
							for (j=0;j<count ;j++ )
							{	
								CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
								printf("\n\t is_latest : %d\n",is_latest);fflush(stdout);
													
								if(is_latest != true)
								{
									printf("\n\t is_latest is not true .....\n");fflush(stdout);
								}else
								{	
									DMLRevTag = DMLRevision[j];

									CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
									CALLAPI(POM_name_of_class(class_id1,&class_name1));
									printf("\n\t class_name found1 :%s",class_name1);

									if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
									{
										CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
										printf("\n\t DMLtype is :%s",DMLtype);fflush(stdout);

										CALLAPI(AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname));
										printf("\n Projectname from leftObject : %s\n",projectname);fflush(stdout);
										
										//if(tc_strcmp(projcode,projectname)!=0 && !tc_strcmp(DMLtype,"TPL"))
										if(tc_strcmp(projcode,projectname)!=0)
										{
											printf("\n\t Inside if.....loop..........");fflush(stdout);
										//	EMH_store_error_s5(EMH_severity_warning,ITK_err,"The project code of part is ",projcode," and that of task is ",projectname, "To ensure smooth operation at APL it's preferred to attach a part with same project's task.");	
										//	return ITK_err;
										}								
									}

									CALLAPI(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&tskcnt,&Dml_tasks));
									printf("\n Now tskcnt : %d\n",tskcnt);fflush(stdout);
							
									if (tskcnt>0)
									{
										for (i=0;i<tskcnt ;i++ )
										{
											   AOM_ask_value_string(Dml_tasks[i],"object_type",&tsk_object_type);
											   printf("\n tsk_object_type is :%s\n",tsk_object_type);fflush(stdout);
										}
									}
								}					
							}
						}
					}else
						{
							if(strcmp(relation_name,"HasParticipant")!=0)
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"You Can not attach objects other than Design Revision to Tasks.. Pls check");	
								return ITK_err;
							}
						}
				}else
				{
					if(strcmp(relation_name,"HasParticipant")!=0)
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You have not attached the part to SolutionItems. This will not be considered for release");	
						return ITK_err;
					}
				}
			//}
		}
		else
			{
				printf("\n Secondary object not found \n");fflush(stdout);
			}
	}
	}
	}
	}
	}
	else if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		printf("\n DML:Inside ChangeRequestRevision..... \n");fflush(stdout);
		CALLAPI(POM_get_user_id (&username));
		printf("\n DML:Session login User2 for MR : %s\n",username); fflush(stdout);

		if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
		{
			if(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
			if(TCTYPE_ask_name(objTypeTag2,type_name2));
			printf("\n DML: secondary_object  type_name2 :: %s\n", type_name2);fflush(stdout);
			printf("\n DML: Working for ChangeRequestRevision\n");fflush(stdout);
			CALLAPI(AOM_UIF_ask_value(primary_object,"t5_cprojectcode",&projChar));
			CALLAPI(AOM_UIF_ask_value(primary_object,"t5_crdesigngroup",&DesgChar));
			CALLAPI(AOM_UIF_ask_value(primary_object,"release_status_list",&LcStus));
			printf("\n DML: Project:[%s] DesgChar:[%s] LcStus:[%s]\n",projChar,DesgChar,LcStus);fflush(stdout);
			CALLAPI(PROJ_find(projChar,&projTag));	
			if(relation_type != NULLTAG)
			{
				CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
			}
			printf("\n DML: New relation_name:%s \n",relation_name);fflush(stdout);
			if(strcmp(relation_name,"HasParticipant")==0)
			{
				if(strcmp(LcStus,"ERC Released")==0)
				{
					printf("\n DML: DML is released, not allowing to update participants! \n");fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"DML is ERC Released, not allowed to update participants.");	
					return ITK_err;
				}
				else
				{
					printf("\n DML:Checking for Analyst: Relation Name:[%s] pri_object:[%s].\n",relation_name,type_name);fflush(stdout);	
					CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeUser",&AnaAssignee));
					CALLAPI(AOM_UIF_ask_value(secondary_object,"assignee",&Assignee));
					printf("\n DML: AnaAssignee: %s	 \n", AnaAssignee);fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeGroup",&AssigneeGrp));
					printf("\n DML: AssigneeGrp:: %s \n", AssigneeGrp);fflush(stdout);	
					printf("\n DML: Assignee: %s \n",Assignee);fflush(stdout);
								
					//third logic
					if(strcmp(type_name2,"Analyst")==0)
					{
						printf("\n DML: No need to set Analyst!!!!!!!!!!!!! \n");fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select Analyst for task, not for DML.");	
						return ITK_err;
					}
					else if(strcmp(type_name2,"T5_BOMAnalyst")==0)
					{
						printf("\n DML: Check access for BOM Analyst \n");fflush(stdout);
					}
					else if(strcmp(type_name2,"T5_CEReviewer")==0)
					{
						printf("\n DML: Check access for CE Reviewer \n");fflush(stdout);
					}
					else if (strcmp(type_name2,"T5_VIReviewer")==0)
					{
						printf("\n DML: Check access for CE Reviewer \n");fflush(stdout);
					}
					else if (strcmp(type_name2,"T5_PPReviewer")==0)
					{
						printf("\n DML: Check access for PP Reviewer \n");fflush(stdout);
					}
					else if (strcmp(type_name2,"T5_DMUReviewer")==0)
					{
						printf("\n DML: Check access for DMU Reviewer \n");fflush(stdout);
						DMUAccesNm=NULL;DMUAccesNm=malloc(50);
						strcpy(DMUAccesNm,"00");
						strcat(DMUAccesNm,"_Managers");
						printf("\n Role name3 required   = [%s]\n", DMUAccesNm);fflush(stdout);
						if(strstr(Assignee,"DMU_Reviewer")!=NULL)
						{
							printf("\n DML: User having access for DMU!!!!!!!!!!!!! \n");fflush(stdout);
							//1.28
							CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &dml_tsk_rel_type));
							if (dml_tsk_rel_type!=NULLTAG)
							{		
								CALLAPI(GRM_list_secondary_objects_only(primary_object,dml_tsk_rel_type,&Tskcount,&TskRevision));
								printf("\n DML: TskRevision Tskcount : %d",Tskcount);fflush(stdout);	
								for (tsk=0;tsk<Tskcount ;tsk++ )
								{ 
									printf("\n DML: Task no : %d ......",tsk);fflush(stdout);
									CALLAPI(ITEM_rev_sequence_is_latest(TskRevision[tsk],&is_Tsklatest));
									printf("\n DML: %d\n",is_Tsklatest);fflush(stdout);

									if(is_Tsklatest != true)
									{
										printf("\n DML:is_Tsklatest is not true .....\n");fflush(stdout);
									}
									else
									{	
										TskRevTag = TskRevision[tsk];
										CALLAPI(POM_class_of_instance(TskRevTag,&Task_cls));
										CALLAPI(POM_name_of_class(Task_cls,&Task_class));
										printf("\n DML: Task class :%s",Task_class);

										CALLAPI(GRM_find_relation_type("HasParticipant", &tsk_CRB_rel_type));
										if (tsk_CRB_rel_type!=NULLTAG)
										{
											printf("\n DML:TASK:inside HasParticipant.. \n");fflush(stdout);
											CALLAPI(GRM_list_secondary_objects_only(TskRevTag,tsk_CRB_rel_type,&TskCRBcount,&TskCRB));
											printf("\n DML:TASK: TskCRB count: %d",TskCRBcount);fflush(stdout);	
											for (jkk=0;jkk<TskCRBcount ;jkk++ )
											{	
												printf("\n DML:TASK:jkk: %d.\n",jkk);fflush(stdout);
												TskCRBTag = TskCRB[jkk];
												if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
												if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
												printf("\n DML:TASK: type_name8 :: %s\n", type_name8);fflush(stdout);
												if (strcmp(type_name8,"Analyst")==0)
												{
													CALLAPI(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskAnlyst));
													CALLAPI(AOM_UIF_ask_value(TskCRBTag,"assignee",&TskAnlystGrp));
													printf("\n DML:TASK: TskAnlyst: [%s] TskAnlystGrp: [%s] ",TskAnlyst,TskAnlystGrp);fflush(stdout);
													if (TskAnlyst!=NULL)
													{
														if(strcmp(TskAnlyst,AnaAssignee)==0)
														{
															printf("\n TASK: ERROR:DMU Reviewer and Task Analyst should not be same.!!!!!!!!!!!!! \n");fflush(stdout);
															EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU reviewer and task analyst should not be same.");	
															return ITK_err;
														}
													}
													break;
												}
											}
										}
									}
								}
							}
							//1.28
						}
						else
						{
							printf("\n DML: User NOT having access for DMU!!!!!!!!!!!!! \n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU reviewer should have manager access for 00 group. Please select DMU reviewer from 'DMU_Reviewer' group only.");	
							return ITK_err;
						}
					}
					else if (strcmp(type_name2,"ChangeReviewBoard")==0)
					{
						printf("\n DML: Check access for Reviewer \n");fflush(stdout);
						ManAccesNm=NULL;ManAccesNm=malloc(50);
						//strcpy(ManAccesNm,DesgChar);
						//strcat(ManAccesNm,"_Managers");
						strcpy(ManAccesNm,"_Managers");
						printf("\n Role name2 required   = [%s]\n", ManAccesNm);fflush(stdout);
						//if(strstr(Assignee,"DML_Reviewer")!=NULL)
						if(strstr(Assignee,ManAccesNm)!=NULL)
						{
							printf("\n DML: User having access for ChangeReviewBoard. \n");fflush(stdout);
							//1.28
							CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &dml_tsk_rel_type));
							if (dml_tsk_rel_type!=NULLTAG)
							{		
								CALLAPI(GRM_list_secondary_objects_only(primary_object,dml_tsk_rel_type,&Tskcount,&TskRevision));
								printf("\n DML: TskRevision Tskcount : %d",Tskcount);fflush(stdout);	
								for (tsk=0;tsk<Tskcount ;tsk++ )
								{ 
									printf("\n DML:Task num : %d ...",tsk);fflush(stdout);
									CALLAPI(ITEM_rev_sequence_is_latest(TskRevision[tsk],&is_Tsklatest));
									printf("\n DML: %d\n",is_Tsklatest);fflush(stdout);

									if(is_Tsklatest != true)
									{
										printf("\n DML:is_Tsklatest is not true .....\n");fflush(stdout);
									}
									else
									{	
										TskRevTag = TskRevision[tsk];
										CALLAPI(POM_class_of_instance(TskRevTag,&Task_cls));
										CALLAPI(POM_name_of_class(Task_cls,&Task_class));
										printf("\n DML: Task class :%s",Task_class);

										CALLAPI(GRM_find_relation_type("HasParticipant", &tsk_CRB_rel_type));
										if (tsk_CRB_rel_type!=NULLTAG)
										{
											printf("\n DML:TASK:inside HasParticipant.. \n");fflush(stdout);
											CALLAPI(GRM_list_secondary_objects_only(TskRevTag,tsk_CRB_rel_type,&TskCRBcount,&TskCRB));
											printf("\n DML:TASK: TskCRB count: %d",TskCRBcount);fflush(stdout);	
											for (jkk=0;jkk<TskCRBcount ;jkk++ )
											{	
												printf("\n DML:TASK:jkk: %d.\n",jkk);fflush(stdout);
												TskCRBTag = TskCRB[jkk];
												if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
												if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
												printf("\n DML:TASK: type_name8 :: %s\n", type_name8);fflush(stdout);
												if (strcmp(type_name8,"Analyst")==0)
												{
													CALLAPI(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskAnlyst));
													CALLAPI(AOM_UIF_ask_value(TskCRBTag,"assignee",&TskAnlystGrp));
													printf("\n DML:TASK: TskAnlyst: [%s] TskAnlystGrp:.. [%s] ",TskAnlyst,TskAnlystGrp);fflush(stdout);
													if (TskAnlyst!=NULL)
													{
														if(strcmp(TskAnlyst,AnaAssignee)==0)
														{
															printf("\n TASK: ERROR:DML Reviewer and Task Analyst should not be same.!!!!!!!!!!!!! \n");fflush(stdout);
															EMH_store_error_s1(EMH_severity_error,ITK_err,"DML reviewer (Change Review Board)and task analyst should not be same.");	
															return ITK_err;
														}
													}
													break;
												}
											}
										}
									}
								}
							}
							//1.28
						}
						else
						{
							printf("\n DML: User NOT having access for Reviewer!!!!!!!!!!!!! \n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"DML reviewer (Change Review Board) should have manager group access.");	
							return ITK_err;
						}
					}
					else
					{
						printf("\n DML: User having access for DML project !!!!!!!!!!!!! \n");fflush(stdout);
					}
				}
			}
		}
	}
	if(DMLRevision)
			MEM_free(DMLRevision);	
	
    return error_code; 
}

int erc_dml_assign( EPM_action_message_t msg )
{	
	
		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l,cnt		=0;
		int  attype = 1;
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
		
		tag_t			*objTypeTagTask			= NULLTAG;
		
		//GRM_relation_t			*secondary_objects	;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;
		

		char*			parent_name				=NULL; 
		char*			object_type				=NULL;	
		char*			Analyst_name			=NULL;	
		char*			DmlAnalyst_name			=NULL;	
		
		char*			Dml_no					=NULL;	
		char*			CurrentTask				=NULL;	
		char*			TaskName				=NULL;	
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;

		POM_get_user(&username,&user_tag);
		printf("\nStarting for username :%s....\n",username);fflush(stdout);		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n erc_dml_assign \n"); fflush(stdout);
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\nCurrentTask:%s\n",CurrentTask);
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);

		if(strstr(parent_name,"Work Break Down - CN")!=NULL)
		{
		  if(strstr(CurrentTask,"Add Solution item")!=NULL)
		  {
			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			 if(noAttachment > 0)
			 {
			   for(t=0;t<noAttachment;t++)
			   {
				  AOM_ask_value_string(attachments[t],"object_type",&object_type);
				  printf("\n object_type is :%s\n",object_type);fflush(stdout);


				  if(strcmp(object_type,"ChangeNoticeRevision")==0)
				  {
					CALLAPI(AOM_ask_value_string(attachments[t],"current_id",&Dml_no));				
					printf("\n Dml_no is :%s\n",Dml_no);	fflush(stdout);	
				
					if(Dml_no)
					{
							printf("\n found part \n");fflush(stdout);
							CALLAPI(AOM_UIF_ask_value(attachments[t],"Analyst",&DmlAnalyst_name));
							printf("\n Analyst_name  of DML  is %s\n", DmlAnalyst_name);						
					}
				  }

		      }

			 }
			}
	  }	
		return ITK_ok;
}

extern EPM_decision_t DLLAPI SignOffCheck_Chk_Validation (EPM_rule_message_t msg) 
{
  int count,i,j,k,t,l,k1;
  int m,n = 0;
  int jd = 0;
  tag_t *attachments = NULLTAG;
  tag_t *DMLRevision = NULLTAG;
  tag_t  *secondary_objects = NULLTAG;
  char *user_name;
  char *class_name;
  char *class_name1;
  char *proj_value;
  tag_t relation_type;
  tag_t tsk_dml_rel_type;
  int   n_attchs,partcnt = 0;

  tag_t login_user_tag;
  tag_t owner_tag;
  tag_t class_id=NULLTAG;
  tag_t class_id1=NULLTAG;
  tag_t attchments1=NULLTAG;
  tag_t root_task=NULLTAG;
  tag_t *  	rev_tag	;
  int status = ITK_ok;
  char *s;
  
  tag_t   bom_window=NULLTAG;
	
  char*	 object_type		= NULL;	
  char*	 Object_PartType		= NULL;	
  
  char*	 t5current_name		= NULL;	
  char*	 t5current_name1		= NULL;	
  char*	 DMLtype		= NULL;	
  char*	 Part_no			= NULL;
  char*	 Arch_obj			= NULL;
  char*	 Arch_obj_str			= NULL;
  char*	 SmVCContext			= NULL;
  char*	 SmCrIDContext			= NULL;
  char*	 ContextobjName			= NULL;
  char*	 CtxtrimobjName			= NULL;

  char*	 TargetThread			= NULL;
  char*	 ReleaseStatus		= NULL;
  char*	 current_name		= NULL;
  char*	 projectname		= NULL;
  tag_t  	master =	NULLTAG;
  int 	 sequence_id;
  tag_t  *children1=NULLTAG;
  tag_t  *children=NULLTAG;
  logical is_latest;

  char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
  char **values = (char **) MEM_alloc(1 * sizeof(char *));

  tag_t *PartsTag= NULLTAG;
  tag_t AssyTag = NULLTAG;
  tag_t ArchAssyTag = NULLTAG;
  tag_t CtxAssyTag = NULLTAG;
  tag_t objTypeTag=NULLTAG;
  tag_t ArchobjTypeTag=NULLTAG;
  tag_t ctxobjTypeTag=NULLTAG;
  tag_t  relation_dep	= NULLTAG;
  tag_t  relation_Ctx	= NULLTAG;

	int p1,m1 = 0;
	tag_t   Childobject=NULLTAG;
	tag_t   Desobject=NULLTAG;
	char *child_item_id=NULL;
	char *child_bl_formula=NULL;
	char *Trim_bl_formula=NULL;

	tag_t ref_instancesTemp = NULLTAG;
    tag_t   window,rule,item_tag = null_tag,top_line;

    tag_t DMLLcmTag = NULLTAG;
    tag_t DMLRevTag = NULLTAG;

    char		   *revisionID	=NULL;
    char		   *t5Des_Rev	=NULL;
    char		   *t5rlz_list	=NULL;
    char		   *DMLNumber =NULL;
    char		   *taskGrp	  =NULL;
	char *curentname;

	char*	username				=NULL;
	tag_t  objTypeTagDi1=NULLTAG;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;

	int    n_instances	= 0;
	tag_t  *ref_instances	= NULLTAG;	
	int	   *instance_levels;
	int	   *instance_where_found;
	int    n_classes		= 0;
	tag_t  *ref_classes		= NULLTAG;
	int    *class_levels;
	int    *class_where_found;
	tag_t	queryTag	= NULLTAG;
	tag_t	queryChkTag	= NULLTAG;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesChk = (char **) MEM_alloc(10 * sizeof(char *));

	int n_entries = 1;
	int n_Chkentries = 1;
	int resultCount=0;
	int ChkCount=0;
	tag_t *rev=NULLTAG;
	tag_t *Chkrev=NULLTAG;
	char *qry_entries[1] = {"ID"};
	char *qry_entriesChk[1] = {"Name"};

  	char   type_name[TCTYPE_name_size_c+1];
	char   type_name4[TCTYPE_name_size_c+1];
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char   Archtype_name[TCTYPE_name_size_c+1];
	char   Ctxtype_name[TCTYPE_name_size_c+1];
	char   objecttype[WSO_name_size_c+1];
	int ifail=0;
	int n_parents,n1_parents = 0;
	int cnt = 0;
	int cntFlag = 0;
	int *levels = 0;
	tag_t *parents = NULL;
	tag_t *parents1 = NULL;
	int countDep,countDep1 = 0;
	int countConfigCtx = 0;
	int countCtx =0;
	tag_t  *secondary_objects1	= NULLTAG;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  *secondary_objects2	= NULLTAG;
	tag_t  *CtxSecObject	= NULLTAG;
	tag_t  primary=NULLTAG;
	tag_t  primary1=NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  objTypeTagDi=NULLTAG;
	char   type_name3[TCTYPE_name_size_c+1];
	char  *Context_Str=NULL;
	char *class_nameCtx=NULL;
	char*	 DMLNo		= NULL;
	tag_t Optfmly_tag = NULLTAG;
    char * ItemPType ;
    char * ItemName1 ;
	char *  HangingPrtErr = NULL;
	char *  SetHangingPrtErr = NULL;

	//sks start
	int PartNoStrucCnt =0;
	int PartStrNoParentCnt =0;
	char PartStrNoStruc[1500];
	char PartStrNoParent[1500];
	//sks end

    //ref_instancesTemp = malloc( sizeof(1) ); 
    EPM_decision_t decision = EPM_go;
    char obj_type[WSO_name_size_c+1];

    CALLAPI(POM_get_user_id (&username));
    printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);

    if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
    {
	  CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	  printf("\n\n\t\t Root task found");
	  
	  CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	  printf("\n\n\t\t EPM_ask_attachments of :: %d",count);	
	  
	  if(count > 0)
	  {
		DMLLcmTag = attachments[0];
	  }
		  
	  status = AOM_ask_value_string(DMLLcmTag,"current_name",&t5current_name);
	  printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);

	  if ( status != ITK_ok)
	  {
		 EMH_ask_error_text( status, &s);
		 printf("Error with AOM_ask_value_string : %s \n",s);
		 MEM_free(s);
		 return status;
	  }
	 
	  CALLAPI(POM_class_of_instance(DMLLcmTag,&class_id));
	  CALLAPI(POM_name_of_class(class_id,&class_name));
	  printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout); 
	  
	  CALLAPI(AOM_refresh( DMLLcmTag, 0 ));

	  if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
	  {
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		{
			tc_strcpy(PartStrNoStruc,""); //sks start end
			CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count,&DMLRevision));
			printf("\n\n\t\t DML Revision from Task : %d",count);fflush(stdout);			
				
			for (j=0;j<count ;j++ )
			{	
				CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{	
					DMLRevTag = DMLRevision[j];

					CALLAPI(AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname));
					printf("\n Projectname from leftObject : %s\n",projectname);fflush(stdout);
				
					printf("\n\n\t\t is_latest is  true .....\n");fflush(stdout);						
					CALLAPI(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
					printf("\n\n\t\t current_name is :%s\n",current_name);fflush(stdout);

					DMLNumber = strtok( current_name, "_" );
					taskGrp	  = strtok ( NULL, "_" );
					printf("\n\n\t\t taskGrp is :%s",taskGrp); fflush(stdout);

					CALLAPI(AOM_ask_value_int(DMLRevTag,"sequence_id",&sequence_id));
					printf("\n\n\t\t sequence_id is :%d\n",sequence_id);fflush(stdout);

					CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
					CALLAPI(POM_name_of_class(class_id1,&class_name1));
					printf("\n\n\t\t class_name found1 :%s",class_name1);
					
					CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
					printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);

					if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
					{
						if(strcmp(DMLtype,"")==0)
						{
							printf("\n\n\t\t t5_rlstype is NULL\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "ERC-DML Type IsNULL, plz update release type as required");
							decision = EPM_nogo;
							return decision;
						}
						
						if((strcmp(DMLtype,"TPL")==0)  || (strcmp(DMLtype,"MR")==0) || (strcmp(DMLtype,"Veh")==0))
						{								
							CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &relation_type));
							if (relation_type!=NULLTAG)
							{				
								CALLAPI(GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects));
								printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);

								if(n_attchs>0)
								{
									for (l=0;l<n_attchs ;l++ )
									{
									   status = AOM_ask_value_string(secondary_objects[l],"current_name",&t5current_name1);
									   printf("\n\n\t\t t5current_name1 is :%s",t5current_name1);fflush(stdout);
									   if ( status != ITK_ok)
									   {
										 EMH_ask_error_text( status, &s);
										 printf("Error with AOM_ask_value_string2 : %s \n",s);
										 MEM_free(s);
										 return status;
									   }
								 
									   if(strcmp(t5current_name,t5current_name1)==0)
									   {												 
										 //CALLAPI(AOM_refresh( secondary_objects[l], 0 ));												 
										 CALLAPI(AOM_ask_value_string(secondary_objects[l],"object_type",&object_type));
										 printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);

										   if (!SetHangingPrtErr) MEM_free(SetHangingPrtErr);
										   SetHangingPrtErr=(char *)MEM_alloc(10000);
										 
										   if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
										   {											  
											  DMLNo=subString(t5current_name1,0,10);
											  printf("\n\n\t\t DML Number:-------> %s\n", DMLNo); fflush(stdout);

											  if(QRY_find("GetChkLst", &queryChkTag));
											  printf("\n\n\t\tAfter GetChkLst QRY_find------------>");fflush(stdout);
											  if (queryChkTag)
											  {
												printf("\n\n\t\tFound Query-------->");fflush(stdout);
											  }else
											  {
												printf("\n\n\t\tNot Found Query---->");fflush(stdout);
											  }									  	 
											  
											  trimLeading(DMLNo);
											  qry_valuesChk[0] = DMLNo;
											  if(QRY_execute(queryChkTag, n_Chkentries, qry_entriesChk, qry_valuesChk, &ChkCount, &Chkrev));
											  printf("\n\n\t\tChkCount:-------> %d\n", ChkCount); fflush(stdout);

											  if(ChkCount==0)
											  {
												  EMH_clear_errors();
												  EMH_store_error_s3(EMH_severity_warning,ITK_err, "Please Create Checklist for DML=> ",current_name,"\nHelp: Select DML goto File->New->Change Classes->ERC DML CheckList");
												  decision = EPM_nogo;
												  return decision;
											  }

											  CALLAPI(AOM_ask_value_tags(secondary_objects[l],"CMHasSolutionItem",&partcnt,&PartsTag));
											  printf("\n\n\t\t Now partcnt:%d",partcnt);fflush(stdout);

											  if (partcnt>0)
											  {
												for (k=0;k<partcnt ;k++ )
												{	
													printf("\n\n\t\t for k =:%d",k);fflush(stdout);
													AssyTag=PartsTag[k];
													
													CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
													printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);										
													//WSOM_ask_object_type(primary_objects[i],object_type);	
													
													if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
													if(TCTYPE_ask_name(objTypeTag,type_name));
													printf("\n\n\t\t AssyTag type_name := %s", type_name);fflush(stdout);	
													
													////////////////////////////////Drawing Doc Validation start SKS///////////////////////////
													tag_t primary_DS=NULLTAG;
													tag_t DataSet_TypeTag=NULLTAG;
													tag_t reln_type=NULLTAG;
													GRM_relation_t *rellist;
													char* Object_DrwInd = NULL;
													char   DataSet_type_name[TCTYPE_name_size_c+1];
													int    n_attchs_DS =0,DrwCnt=0,AttchCnt=0;
													logical	checkout= 0;
																									
													CALLAPI(RES_is_checked_out(AssyTag,&checkout));
													printf("\nValue of checkout Attribute : [%d]\n",checkout);fflush(stdout);
													if (checkout==1)
													{
														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please Check-In all items (which are in  Solution Items) to vault before signoff");
														decision = EPM_nogo;
														return decision;
													}
													
													CALLAPI(AOM_ask_value_string(AssyTag,"t5_DrawingInd",&Object_DrwInd));
													printf("\n\n\t\t Object_DrwInd is :<%s>\n",Object_DrwInd);fflush(stdout);

													//CALLAPI(GRM_find_relation_type("IMAN_specification",&reln_type));
													printf("\n\n\t\t IMAN_specification.........\n");fflush(stdout);
													
													CALLAPI(GRM_list_secondary_objects(AssyTag,reln_type,&n_attchs_DS,&rellist));

													printf("\n\n\t\t After GRM_list_secondary_objects count : %d\n",n_attchs_DS);fflush(stdout);

													if(n_attchs_DS>0)
													{
														DrwCnt=0;
														for (AttchCnt= 0; AttchCnt < n_attchs_DS; AttchCnt++)
														{
															primary_DS=rellist[AttchCnt].secondary;

															printf("\n\n\t\t primary_DS........\n");fflush(stdout);

															CALLAPI(TCTYPE_ask_object_type(primary_DS,&DataSet_TypeTag));
															CALLAPI(TCTYPE_ask_name(DataSet_TypeTag,DataSet_type_name));
															printf("\n\n\t\t DataSet_type_name : %s\n",DataSet_type_name);fflush(stdout);

															if(strcmp(DataSet_type_name,"CATDrawing")==0 || strcmp(DataSet_type_name,"CMI2Drawing")==0 || strcmp(DataSet_type_name,"ProDrw")==0) 
															{
																DrwCnt++;
																printf("\n\n\t\t DrwCnt ++ : %d\n",DrwCnt);fflush(stdout);
															}
														}
													}

													if(tc_strcmp(Object_DrwInd,"D")==0)
													{
														if (DrwCnt==0)
														{
															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please attach drawing for the parts with Drawing Indicator as D.");
															decision = EPM_nogo;
															return decision;
														}
													}else if (tc_strcmp(Object_DrwInd,"N")==0)
													{   
														printf("\n\n\t\t DrwCnt : %d\n",DrwCnt);fflush(stdout);

														if (DrwCnt>0)
														{
															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_warning,ITK_err, "Drawing indicator 'N' but Drwing Dataset found attached to Design Revision");
															decision = EPM_nogo;
															return decision;
														}
													}
													

													////////////////////////////////Drawing Doc Validation END///////////////////////////
													
													CALLAPI(AOM_ask_value_string(AssyTag,"object_string",&curentname));
													printf("\n\n\t\t curentname is :%s\n",curentname);fflush(stdout);
													
													CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&Object_PartType));
													printf("\n\n\t\t Object_PartType is :%s\n",Object_PartType);fflush(stdout);
													
													if((tc_strcmp(type_name,"Design Revision")==0) )
													{
														printf("\n\t Inside BOM_create........\n");fflush(stdout);
														if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
														if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();		
														if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();	
														if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_top_line (window, null_tag,AssyTag , null_tag, &top_line)!=ITK_ok)PrintErrorStack();
														
														if(BOM_line_ask_child_lines (top_line, &n, &children1));	
														printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);
																												
														if((tc_strcmp(Object_PartType,"D")==0))
														{
															/*
															if(n > 0)
															{
																
																EMH_clear_errors();
																EMH_store_error_s1(EMH_severity_error,ITK_err, "DUMMY part in TPL should not have structure");
																decision = EPM_nogo;
																return decision;
															}
															*/
														}
														else
														{
														     if((tc_strcmp(Object_PartType,"M")==0) || (tc_strcmp(Object_PartType,"T")==0)||(tc_strcmp(Object_PartType,"V")==0))
															 {
																if (n==0)
																{
																	
																		printf("\n\n\t\t for other parttypes Part_no : %s\n",Part_no);fflush(stdout);													
																		EMH_clear_errors();
																		EMH_store_error_s2(EMH_severity_error,ITK_err, "Structure Not present for this part . Pls check .",Part_no);
																		decision = EPM_nogo;
																		return decision;
																		
																}
															}	
														}												

													}
													
													////////////////////////////////Hanging Parts Validation start hpp///////////////////////////
													ItemPType = NULL;
													ItemName1 = NULL;

													CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&ItemPType));
													printf("\n child ItemPType:%s ..............",ItemPType);fflush(stdout);

													if(tc_strcmp(ItemPType,"V" )==0 || tc_strcmp(ItemPType,"T" )==0 ||  tc_strcmp(ItemPType,"M" )==0 || tc_strcmp(ItemPType,"VC" )==0 || tc_strcmp(ItemPType,"D" )==0 ||  tc_strcmp(ItemPType,"G" )==0)
													{
														printf("\n Part Type is V/T/M/VC/D/G[%s]--->So continue No hanging part check..............",ItemPType);fflush(stdout);
													}else
													{
														printf("\n Part Type is Other than this V/T/M/VC/D/G[%s]--->So continue for hanging part check..............",ItemPType);fflush(stdout);

														printf("\n\t AssyTag exists........\n");fflush(stdout);
														CALLAPI(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
														printf("\n\t where_used count of objects are : %d\n",n_parents); fflush(stdout);
														
														CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&ItemName1));
														printf("\n child ItemName1:%s ..............",ItemName1);fflush(stdout);

														CALLAPI(AOM_ask_value_string(AssyTag,"item_revision_id",&t5Des_Rev));
														printf("\n\n\t\t t5Des_Rev is :%s",t5Des_Rev); fflush(stdout);
														
														revisionID = strtok( t5Des_Rev, ";" );
														printf("\n\n\t\t revisionID is :%s",revisionID); fflush(stdout);

														CALLAPI(AOM_UIF_ask_value(AssyTag,"release_status_list",&t5rlz_list));
														printf("\n\n\t\t t5rlz_list is :%s",t5rlz_list); fflush(stdout);
														printf("\n\n\t\t DMLtype is :%s",DMLtype); fflush(stdout);

														if (tc_strcmp(HangingPrtErr,"NULL") !=0) MEM_free(HangingPrtErr);
														HangingPrtErr=(char *)MEM_alloc(500);
														tc_strcpy(HangingPrtErr," ");
													
														if((n_parents==0) && (tc_strcmp(revisionID,"NR")==0) && (tc_strstr(t5rlz_list,"Release")==NULL) && (tc_strcmp(DMLtype,"D")!=0))
														{
															printf("\n\n\t\t Inside Where_used count...............\n"); fflush(stdout);		
															if((!tc_strcmp(DMLtype,"ECU") && !tc_strcmp(taskGrp,"16")) || (tc_strcmp(Object_PartType,"DTPL")==0))
															{
																printf("\n ## Hanging parts validation bypassed for LLP release and task 16 of ECU Parts Release.\n");fflush(stdout);
															}else
															{
																printf("\n\n\t\t Inside else loop Where_used.........\n"); fflush(stdout);
																if(cnt==0)
																{
																	cnt = 1;
																	tc_strcat(HangingPrtErr,"PartNumber[");
																	tc_strcat(HangingPrtErr,ItemName1);
																	tc_strcat(HangingPrtErr,",");
																	tc_strcat(HangingPrtErr,t5Des_Rev);
																	tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
																	printf("\n ChildRelErr10: %s\n",HangingPrtErr);fflush(stdout);
																}
																else
																{
																	tc_strcat(HangingPrtErr,"PartNumber[");
																	tc_strcat(HangingPrtErr,ItemName1);
																	tc_strcat(HangingPrtErr,",");
																	tc_strcat(HangingPrtErr,t5Des_Rev);
																	tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
																	printf("\n ChildRelErr11: %s\n",HangingPrtErr);fflush(stdout);
																	cnt = cnt+1;
																	printf("\n ChildRelEr22r: %s\n",HangingPrtErr);fflush(stdout);
																}

																if(cnt==1)
																{	
																	printf("\n\n\t\t cnt values is===> %d\n",cnt); fflush(stdout);
																	tc_strcpy(SetHangingPrtErr,HangingPrtErr);
																	cntFlag = 1;
																}else if(cnt>1)
																{	
																	printf("\n\n\t\t cnt values is===> %d\n",cnt); fflush(stdout);
																	tc_strcat(SetHangingPrtErr,HangingPrtErr);
																	cntFlag = 1;
																}

																if(cntFlag==1)
																{	
																	printf("\n\n\t\t cnt values is===> %d\n",cnt); fflush(stdout);

																	//EMH_clear_errors();
																	//EMH_store_error_s2(EMH_severity_error,ITK_Prjerr, "The Parts attached in the resultant are not attached to any assembly.(Hanging Parts) : ",SetHangingPrtErr);
																}
															}														
															printf("\n ## Hanging parts validation bypassed for LLP release and task 16 of ECU Parts Release.\n");fflush(stdout);
														}
												  }
												}
											}else
											{
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "There is no Part attached to the Task. Please attach parts to task which you want to release with this dml or remove empty task.");
												decision = EPM_nogo;
												return decision;
											}
										 }
								   }
						    }
					  }
			     } 
			  }
			
			  if(strcmp(DMLtype,"MR")==0) 	  
			  {
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &relation_type));
				if (relation_type!=NULLTAG)
				{				
				  CALLAPI(GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects));
				  printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);

				  if(n_attchs>0)
				  {
				  	for (l=0;l<n_attchs ;l++ )
					{
					   status = AOM_ask_value_string(secondary_objects[l],"current_name",&t5current_name1);
					   printf("\n\n\t\t t5current_name1 is :%s",t5current_name1);fflush(stdout);
					   if ( status != ITK_ok)
					   {
						 EMH_ask_error_text( status, &s);
						 printf("Error with AOM_ask_value_string2 : %s \n",s);
						 MEM_free(s);
						 return status;
				 	   }
			 
					   if(strcmp(t5current_name,t5current_name1)==0)
					   {												 
						 //CALLAPI(AOM_refresh( secondary_objects[l], 0 ));												 
						 CALLAPI(AOM_ask_value_string(secondary_objects[l],"object_type",&object_type));       //12PM000003 User:hpp05653
						 printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
						 
						 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
						 {
						  CALLAPI(AOM_ask_value_tags(secondary_objects[l],"CMHasSolutionItem",&partcnt,&PartsTag));
						  printf("\n\n\t\t Now partcnt:%d",partcnt);fflush(stdout);

						  if (partcnt>0)
						  {
							for (k=0;k<partcnt ;k++ )
							{
							    AssyTag=PartsTag[k];												
								CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
								printf("\n\n\t CP Part_no  is :%s",Part_no);	fflush(stdout);		     //003906								
								
								if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
								if(TCTYPE_ask_name(objTypeTag,type_name));
								printf("\n\t CP AssyTag type_name := %s", type_name);fflush(stdout); //ItemRevision	
																
								CALLAPI(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
								printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1

								if(n_parents>0)
								{
								  for (jd=0;jd<n_parents;jd++ )
								  {		
									ArchAssyTag=parents[jd];														
									CALLAPI(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj));    //003915
									printf("\n\t Architecture Object is :%s",Arch_obj);	fflush(stdout);														
										
									if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
									if(TCTYPE_ask_name(ArchobjTypeTag,Archtype_name));
									printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
											

									  printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);										
									  if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
									  if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();		
									  if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();	
									  if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
									  if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();

									  if(top_line!=NULLTAG)
									  {
									    if(BOM_line_ask_child_lines (top_line, &n, &children1));	
									    printf("\n\t No of child objects are n : %d",n);fflush(stdout);

										if (n >0)
										{
										  for (p1=0;p1<n ;p1++ )
										  {
											if(Childobject) Childobject=NULLTAG;
											Childobject=children1[p1];
											CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
											printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

											if(tc_strcmp(Part_no,child_item_id)==0)
											{
											   CALLAPI(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ));
											   printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

											  // if(tc_strcmp(child_bl_formula,"")==0)
											  // {
												// EMH_clear_errors();
												// EMH_store_error_s2(EMH_severity_error,ITK_Prjerr, "Module Release not allowed without variant formula for ",child_item_id);
												// decision = EPM_nogo;
											  // }else
											  // {
												CALLAPI(ITEM_ask_item_of_rev(ArchAssyTag, &master));
												CALLAPI(AOM_ask_value_string(master,"item_id",&Arch_obj_str));
												printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

												CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
												if(relation_dep != NULLTAG)
												{
													printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);	
												}																	
												 
												CALLAPI(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
												printf("\n\t Configuration Context count is : %d",countConfigCtx);

												if(countConfigCtx>0)
												{
													  ConfigCtx=ConfigCtxSecObject[0];
													  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
													  CALLAPI(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));	  
													  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
													  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);	 

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
													  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

													  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
													  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
													  if (queryTag)
													  {
														printf("\n\tFound Query");fflush(stdout);
													  }else
													  {
														printf("\n\tNot Found Query");fflush(stdout);
													  }									  	 

													  qry_values[0] = SmCrIDContext;

													  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
													  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);

												  
													if(tc_strcmp(child_bl_formula,"")==0 && resultCount >0)
													{
														printf("\n CC available Variant formula not available \n"); fflush(stdout);
														EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",child_item_id);
														decision = EPM_nogo;
														return decision;
													}
													else
													{
												  
													  /*
													  ConfigCtx=ConfigCtxSecObject[0];
													  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
													  CALLAPI(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));	  
													  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
													  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);	 

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
													  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

													  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
													  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
													  if (queryTag)
													  {
														printf("\n\tFound Query");fflush(stdout);
													  }else
													  {
														printf("\n\tNot Found Query");fflush(stdout);
													  }									  	 

													  qry_values[0] = SmCrIDContext;

													  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
													  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);
													  */
													  int cnt=0;

													  for (j=0;j<resultCount;j++ )
													  {
														 Optfmly_tag = rev[j];
														 CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
														 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
																											 
														 if(ContextobjName)
														 {
															// printf("\n\t Variant formula is incompleteeeee :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
															  printf("\n\t child_bl_formula value:%s",child_bl_formula);
															 printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(child_bl_formula,ContextobjName)); fflush(stdout);

															
															if(tc_strstr(child_bl_formula,ContextobjName)==NULL)
															{
																printf("\n inside iff \n"); fflush(stdout);
																cnt++;
																
															}
															else
															 {
																printf("\n inside else \n"); fflush(stdout);
															
															 }
														 }
													  }

													  printf("\n cnt value is at end for loop :%d\n",cnt); fflush(stdout);
													  if (cnt>0)
													  {
																 printf("\n cnt greator than 1 :%d\n",cnt); fflush(stdout);
																//EMH_clear_errors();
																EMH_store_error_s2(EMH_severity_error,ITK_err, "Variant formula is not complete for Module",child_item_id);
																//return ITK_err;
																decision = EPM_nogo;
																return decision;
													  }

													}
												}
												
											   //}
											}
										  }
										}
									}
								}											
							}
						}
						}
					  }else
					  {
						  EMH_clear_errors();
						  EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "There is no Part attached to the Module Release Task. \nPlease attach parts to Module Release task which you want to release with this dml or remove empty task.");
						  decision = EPM_nogo;
						  return decision;
					  }										  
					  }
					  }
					}
					}
				}					  
			  }
			  /*
			  else
			  {
				  EMH_clear_errors();
				  EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "ERC-DML Type is should be of type TPL/Module Release, Plz update release type as TPL/Module Release");
				  decision = EPM_nogo;
			  }
			  */
			//}
		  }else
		  {
			  EMH_clear_errors();
			  EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "Select valid ERC DML");
			  decision = EPM_nogo;
			  return decision;
		  }
	   }
	}
	//sks start
	if (PartNoStrucCnt >0)
	{
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err, "Structure is not present for the given list of parts. Please check.",PartStrNoStruc);
		decision = EPM_nogo;
		return decision;
	}
	if (PartStrNoParentCnt >0)
	{
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err, "Following module not attached to any architecture node.. Please check.",PartStrNoParent);
		decision = EPM_nogo;
		return decision;
	}
	//sks END
}
}
}
  decision = EPM_go;
  if(children1)
			MEM_free(children1);	

  if(DMLRevision)
			MEM_free(DMLRevision);		
  
  if(attachments)
			MEM_free(attachments);


  if(secondary_objects)
			MEM_free(secondary_objects);

  return decision;
  
 }

extern EPM_decision_t DLLAPI assign_anlst_reviwer(EPM_rule_message_t msg)
{
	int count,i = 0;
	tag_t root_task=NULLTAG;
	EPM_decision_t decision;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t    	    propEff_tag				    =NULLTAG;

	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	user_tag1				=NULLTAG;
	char*	CurrentTask				=NULL;	
	char*	parent_name				=NULL; 
	char  	type_name[TCTYPE_name_size_c+1];
	char*	 DmlRevName		= NULL;
	char*	 AnalystName		= NULL;
	char*	 RequestorName		= NULL;
	char*	 ChangSpName		= NULL;
	char*	 ChangReviewName		= NULL;
	int ifail=0;
	
	POM_get_user(&username,&user_tag);
	printf("\n\t Starting for username :%s....\n",username);fflush(stdout);		

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n\t Root task found");fflush(stdout);	

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);	

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

	if(strstr(CurrentTask,"Assign Analyst and Change Review Board(COC) and VI/DMU Reviewer")!=NULL)
	{
		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);	
		
		if(count>0)
		{
		  for(i=0;i<count;i++)
		  {			
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
			{				
				CALLAPI(AOM_UIF_ask_value(attachments[i],"Analyst",&AnalystName));
				printf("\n\n\t\t Analyst Name of task :: %s \n",AnalystName);fflush(stdout);

				CALLAPI(AOM_UIF_ask_value(attachments[i],"Requestor",&RequestorName));
				printf("\n\n\t\t RequestorName Name of task :: %s \n",RequestorName);fflush(stdout);

				if (tc_strcmp(AnalystName,"")==0)
				{
					EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Analyst to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Analyst option"); 	
					return ITK_err;
				}
			}

			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
					CALLAPI(AOM_UIF_ask_value(attachments[i],"ChangeSpecialist1",&ChangSpName));
				printf("\n\n\t\t ChangeSpecialist1 Name of task :: %s \n",ChangSpName);fflush(stdout);

				CALLAPI(AOM_UIF_ask_value(attachments[i],"ChangeReviewBoard",&ChangReviewName));
				printf("\n\n\t\t ChangeSpecialist1 Name of task :: %s \n",ChangSpName);fflush(stdout);

				if (tc_strcmp(ChangReviewName,"")==0)
				{
					EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls Assign Change Review Board/Manager to the DML, \nHelp: Go to target","\nUse: Select DML : Tools->Assign Participant->Select Change Review Board"); 	
					return ITK_err;
				}
			}
		  }
		}
	}

	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI ChkdmlActiveinLC(EPM_rule_message_t msg) 
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;	
	logical			t5InProcess;
	char*			procedure_name				=NULL;	

	tag_t *attachments = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t DMLRevTag = NULLTAG;

	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n\n\t\t Root task found for CheckDMLActiveinLCCheckDMLActiveinLC"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n\n\t\t EPM_ask_attachments of :: %d",count);	

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
	}
	  
	CALLAPI(AOM_ask_value_string(DMLLcmTag,"current_name",&t5current_name));
	printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);
	
	/*
	CALLAPI( AOM_ask_value_logical(DMLLcmTag,"fnd0InProcess",&t5InProcess));
	printf("\n\n\t\t t5InProcess : %d\n",t5InProcess);fflush(stdout);

	if(t5InProcess == true)
	{
		printf("\n\n\t\t t5InProcess is true .....\n");fflush(stdout);
	}else
	{
		printf("\n\n\t\t t5InProcess is not true .....\n");fflush(stdout);
	}*/

	CALLAPI(EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents));
	printf("\n EPM_ask_active_job_for_target------>%d\n",n_parents); fflush(stdout);

	CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
	printf("\n procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);
		
	if (n_parents>1)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "DML already submitted in Lifecycle ... You can not submit it again.. abort DML -check with PLM admin..");
		decision = EPM_nogo;		
	}else
	{
		decision = EPM_go;
	}	
		
	return decision;
}

int T5PartToTaskDeleteVal( METHOD_message_t *msg, va_list  args ) 
{
	va_list largs;
	va_copy( largs, args );

	int ifail=0;
	int n_attchs,partcnt,k,count,j = 0;
	char   *username  = NULL;
	char   *user_name = NULL;
	tag_t	tUser	  = NULLTAG;
	char ** 	name;
	char*	 object_type		= NULL;
	char*	 taskCreater		= NULL;
	char*	 lstmodUsrOfTask		= NULL;
	char*	 TaskAnlyst		= NULL;
	char*	 Task_owning_user		= NULL;
	char*	 objectString		= NULL;
	char*	 taskTempLT		= NULL;
	char*	 AliasTaskName		= NULL;
	char*	 taskAnalystId		= NULL;
	
	tag_t objTypeTag4 = NULLTAG;
	tag_t	priObjTag				=	NULLTAG;
	tag_t	secObjTag				=	NULLTAG;
	tag_t	priObjTypeTag				=	NULLTAG;
	tag_t	priObjTaskTag				=	NULLTAG;
	tag_t	secObjTypeTag				=	NULLTAG;
	tag_t  *secondary_objects = NULLTAG;
	tag_t  *PartsTag = NULLTAG;
    tag_t  AssyTag = NULLTAG;
	tag_t rel_type;
	tag_t *TaskDML = NULLTAG;
	tag_t TaskDML_tag = NULLTAG;

	tag_t relation_type = NULLTAG;
    tag_t tsk_dml_rel_type;
    tag_t *DMLRevision = NULLTAG;
	logical is_latest;
	  tag_t DMLRevTag = NULLTAG;
	  tag_t class_id1=NULLTAG;
	  char *class_name1;
	  char*	 DMLtype		= NULL;	
	
	char  type_name1[TCTYPE_name_size_c+1];
	char  type_name2[TCTYPE_name_size_c+1];
	char  type_name3[TCTYPE_name_size_c+1];
	char  type_name4[TCTYPE_name_size_c+1];

	tag_t object = va_arg(largs, tag_t);

	username = NULL;
	taskCreater = NULL;
	lstmodUsrOfTask = NULL;
	taskTempLT = NULL;
	AliasTaskName = NULL;

	CALLAPI(POM_get_user_id (&username));
	printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);

	if(TCTYPE_ask_object_type(object,&objTypeTag4));
	if(TCTYPE_ask_name(objTypeTag4,type_name4));
	printf("\n selected Object is :: %s\n", type_name4);fflush(stdout);
	if(tc_strcmp(type_name4,"HasParticipant")==0)
	{
		printf("\n HasParticipant allow to remove.....\n");fflush(stdout);
	}else
	{
		if (GRM_ask_primary (object,&priObjTag)!=ITK_ok);

		if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
		if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
		printf("\n T5PartToTaskDeleteVal::pri_type_name :%s\n", type_name1);fflush(stdout);

		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		{
		 CALLAPI(GRM_list_primary_objects_only(priObjTag,tsk_dml_rel_type,&count,&DMLRevision));
		 printf("\n\n\t\t DML Revision from Task : %d",count);fflush(stdout);	

		 for (j=0;j<count ;j++ )
		 {	
			CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
			printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

			if(is_latest != true)
			{
				printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
			}else
			{	
				DMLRevTag = DMLRevision[j];
				CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
				CALLAPI(POM_name_of_class(class_id1,&class_name1));
				printf("\n\n\t\t class_name found1 :%s",class_name1);
				
				CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
				printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);
				
				if((tc_strcmp(DMLtype,"CP") !=0) &&  (tc_strcmp(DMLtype,"MR") !=0))
				{
					if (GRM_ask_secondary (object,&secObjTag)!=ITK_ok);
					if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
					if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
					printf("\n T5PartToTaskDeleteVal::sec_type_name :%s\n", type_name2);fflush(stdout);	
					
					if(tc_strcmp(type_name1,"T5_ChangeTaskRevision")==0)
					{
						//primary object
						if(AOM_ask_value_string(priObjTag,"object_type",&object_type));
						printf("\n primary object_type is :%s\n",object_type);fflush(stdout);

						if(AOM_ask_value_string(priObjTag,"object_string",&Task_owning_user));
						printf("\n primary object_string is :%s\n",Task_owning_user);fflush(stdout);
						
						CALLAPI(AOM_UIF_ask_value(priObjTag,"owning_user",&taskCreater));
						printf("\n primary taskCreater is : %s\n",taskCreater);fflush(stdout);

						//CALLAPI(AOM_UIF_ask_value(priObjTag,"fnd0ActuatedInteractiveTsks",&taskTempLT));
						//printf("\n primary taskTempLT is : %s\n",taskTempLT);fflush(stdout);						
						
						
					}else
					printf("\n Class is other than TaskRevision...\n"); fflush(stdout);
			}


			CALLAPI(AOM_UIF_ask_value(priObjTag,"fnd0ActuatedInteractiveTsks",&taskTempLT));
			printf("\n primary taskTempLT is : %s\n",taskTempLT);fflush(stdout);


			  //Added By Rajendra

			  //if(tc_strcmp(type_name4,"CMHasSolutionItem")!=0)

			if(tc_strcmp(taskTempLT,"Add solution items") !=0)
			{
				CALLAPI(AOM_UIF_ask_value(priObjTag,"last_mod_user",&lstmodUsrOfTask));
				printf("\n primary lstmodUsrOfTask is : %s\n",lstmodUsrOfTask);fflush(stdout);			
				
				if(tc_strcmp(lstmodUsrOfTask,"infodba") !=0 && tc_strcmp(lstmodUsrOfTask,"loader") !=0)
				{
					printf("\n Inside loop Delete from 'Add solution items'.....\n"); fflush(stdout);	

					EMH_store_error_s2(EMH_severity_warning,ITK_err,"The Task Is Not For Assignment Of Add Solution Items","You cannot delete parts from SolutionItem of the task."); 	
					
					return ITK_err;
				}else
				{
					printf("\n Bypass for infodba/Loader User...\n"); fflush(stdout);
				}			
			}

			 //TZ 1.28 Rajendra - Check DML owner and Session User

			//if(tc_strcmp(type_name4,"CMHasSolutionItem")==0)

			if(tc_strcmp(taskTempLT,"Add solution items") ==0)
			{

				//CALLAPI(AOM_UIF_ask_value(secObjTag,"fnd0AssigneeUser",&TaskAnlyst));
				CALLAPI(AOM_UIF_ask_value(priObjTag,"analyst_user_id",&TaskAnlyst));
											
				printf("\n TaskAnlyst [%s] ",TaskAnlyst);fflush(stdout);
					
				if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
				{
					if(tc_strcmp(username,TaskAnlyst) !=0)
						{
							printf("\n Inside loop 'Add solution items'.....Delete Parts From DML Task\n"); fflush(stdout);	

							EMH_store_error_s2(EMH_severity_warning,ITK_err,"Session User is Not Task Analyst..Only Analyst Can Delete Part From DML Task.Task Analyst Is:",TaskAnlyst); 	
							
							return ITK_err;
						}				
					else
						{
							printf("\n Session user is Analyst   ...:%s\n",TaskAnlyst); fflush(stdout);
						}
				}
				else
				{

					printf("\n bypass for infodba & loader   ...\n"); fflush(stdout);

				}
			}

			//Added By Rajendra-End
		}
	}   
	}else
	{
		printf("\n Relation DMLRevision to TaskRevision not found...\n"); fflush(stdout);
	}
	}
	

if(DMLRevision)
			MEM_free(DMLRevision);		

 return ITK_ok; 
}

extern int erc_user_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    METHOD_id_t  method3;

    int ifail=0;
    *decision = ALL_CUSTOMIZATIONS;

    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];

    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;
  
   if( ITK_ok == EPM_register_action_handler("erc_dml_assign", "", erc_dml_assign))
   {
		printf("\t\n Registered Action Handler erc_user_assign_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler erc_user_assign_register_method\n");fflush(stdout);
   }
   
   if( ITK_ok == EPM_register_action_handler("erc_task_breakdown", "", erc_task_breakdown))
   {
		printf("\t\n Registered Action Handler erc_task_breakdown\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler erc_task_breakdown\n");fflush(stdout);
   }
   
   if( ITK_ok ==  EPM_register_rule_handler ("SignOffCheck","Check Validation with DesignRevision", (EPM_rule_handler_t) SignOffCheck_Chk_Validation))
   {
		printf("\t\n Registered rule  HandlerSignOffCheck\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler SignOffCheck\n");fflush(stdout);
   }

   if( ITK_ok ==  EPM_register_rule_handler ("assign-anlst-reviwer","Assign Analyst", (EPM_rule_handler_t) assign_anlst_reviwer))
   {
		printf("\t\n Registered rule  Handler assign-anlst-reviwer\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler assign-anlst-reviwer\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("activeInWorkflow","Check Validation with ActiveInWorkflow", (EPM_rule_handler_t) ChkdmlActiveinLC))
   {
		printf("\t\n Registered rule  ActiveInWorkflow.................\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler ActiveInWorkflow\n");fflush(stdout);
   }

   ifail = METHOD_find_method("ChangeRequestRevision", TC_save_msg, &method1);
   if (method1.id != NULLTAG)
   {
		ifail = METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) createCR_Task, NULL)!=ITK_ok;
		//PrintErrorStack();
		printf("\nrrrrrrrrRegistered as Post-Action for ChangeRequestRevision Creation\n");fflush(stdout);
   }else
   {
		printf("\nMethod not found!TC_save_msg\n");fflush(stdout);
   }

   ifail = METHOD_find_method("ImanRelation", GRM_create_msg, &method2);	
   if( ifail == ITK_ok )
   {
	    printf("\n Before register method for GRM_create_msg for T5TaskToPartCreateVall\n");fflush(stdout);
	    if (method2.id != NULLTAG)
	    {
			if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) T5TaskToPartCreateVal, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for T5TaskToPartCreateVall\n");fflush(stdout);
	    }else
		printf("Method not found!GRM_create_msg\n");fflush(stdout);
	}
	
   /***************************delete_msg*****************************************/
   
   ifail = METHOD_find_method("ImanRelation", TC_delete_msg, &method3);	
   if( ifail == ITK_ok )
   {
	    printf("\n method TC_delete_msg is called... \n");fflush(stdout);
		if (method3.id != NULLTAG)
	    {
			if( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) T5PartToTaskDeleteVal, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for T5TaskToPartCreateVal\n");fflush(stdout);
		}else
		printf("Method not found!TC_delete_msg...\n");fflush(stdout);
   }

   /***************************end*****************************************/
   
   return ITK_ok;
}

extern DLLAPI int erc_dml_assign_register_callbacks()
{     
	 CUSTOM_register_exit("erc_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t) erc_user_assign_register_method);

     printf("\n registered function erc_dml_assign for all DMLs\n");	fflush(stdout);

	 return ( ITK_ok );
}
