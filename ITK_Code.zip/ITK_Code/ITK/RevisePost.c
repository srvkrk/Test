/****************************************************************************************************
*  File            :   Revise_register_callbacks.c
*  Created By      :   Muktesh Girdhani
*  Created On      :   11-Jan-2014
*  Purpose         :   ERC Review to be Stamped on the Design Revision after Revise			
*	
Modified : 04-05-2016 : Modfied checkout functionality, Revise is called and Revision attribute is updated.
******************************************************************************************************/

#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#define CLI_OPTION_BYPASS                    "-bypass"

#define ERROR_CALL(x) {               \
  int stat;                     \
  char *err_string = NULL;             \
  if( (stat = (x)) != ITK_ok)   \
  {                             \
    EMH_ask_error_text (stat, &err_string);              \
    if(err_string != NULL) {\
	printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string);        \
    printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__);             \
	TC_write_syslog("FORM Property Migiration[%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
	MEM_free (err_string);\
	err_string=NULL;\
	}\
    return (stat);          \
  }                         \
 }

#define ITK_errStore 91900002
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}




static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}


extern  DLLAPI int Revise_properties_post(METHOD_message_t *m, va_list args)
{
	char   *ReleaseStatus=NULL;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t  source_rev_Type_Tag = NULLTAG;
	tag_t* status_list = NULLTAG;
	int	   ifail	=0;
	int	   ii=0;
	char   *text	=NULL;
	int	   status_count=0;
	char   *Item_string=NULL;
	logical			retain							= 0;
	int status;	
	int Desc_seq=0;
	int Desc_seq9=0;
	int Desc_seq1=0;
	int Desc_seq2=0;
	char			*Desc_obj	= NULL;
	char			*Desc_obj9	= NULL;
	char			*Desc_obj2	= NULL;
	//char			*Desc_seq3	= NULL;
	char   Desc_seq3[10];
	tag_t			objTypeTag									= NULLTAG;
	tag_t			status_rel					= NULLTAG;
	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t master=NULLTAG;
	  logical      bypass                  = FALSE;
	tag_t	source_rev				 =va_arg (args, tag_t);
	char*	rev_id					 = va_arg(args, char*);
	tag_t*	new_rev					 = va_arg(args, tag_t*);
	tag_t	item_rev_master_form	 = va_arg(args, tag_t);
	  char   *ReplacedRevision=NULL;
	  char		   *ObjectClassType		= NULL;
	  char		   *ObjectName		= NULL;
tag_t			dataset										= NULLTAG;
tag_t			*attachments								= NULLTAG;
int revlength= 0;
tag_t *revisions;
int revision_count=0;
tag_t attr_id ;
tag_t form_attr_id ;
	tag_t			relation_type								= NULLTAG;
	char			relation_name[TCTYPE_name_size_c+1];

	const char	   reason;
	const char     change_id;
	const char     dir_name;
	const char	   reason1;
	const char     change_id1;
	const char     dir_name1;
	char* revi=NULL;
	char* oojname=NULL;
	 char   revi1[20];
	int				cnt=0;
	int				i=0;
	logical			checkout									= 0;

	/******Deepti Start Variable initialisation***********/
	int			st_relList_count		= 0; 
	int			Rel_cnt					= 0; 
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ; 
	tag_t		tReleaseStatusList		= NULLTAG; 
	int			n_values				= 0; 
	int			cunt1					= 0; 
	tag_t*		attr_tags				= NULLTAG; 
	logical		*is_it_null				= NULL; 
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;

	/******Deepti End ariable initialisation***********/

	printf("\n Inside Revise_properties_post Function.... \n");fflush(stdout);
	
	if (TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	
	if(ITEM_ask_item_of_rev  ( source_rev,&master) );

	if(ITEM_ask_latest_rev(master,&rev));



if(ITEM_list_all_revs (master, &revision_count, &revisions));
//MEM_free (revisions);
printf("\nNumber of revision : %d\n",revision_count); fflush(stdout);


		if (WSOM_ask_release_status_list(revisions[revision_count-2],&status_count,&status_list)) PrintErrorStack();
	    	
			printf("\n number of statuses: %d \n",  status_count);fflush(stdout);
			for (ii = 0; ii < status_count; ii++)
			{
				AOM_ask_name(status_list[ii], &ReleaseStatus);
				printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
			}

	if (AOM_ask_value_string(revisions[revision_count-2],"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
	printf("\n Desc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);
	
	if (AOM_ask_value_int(revisions[revision_count-2],"sequence_id",&Desc_seq2)!=ITK_ok)   PrintErrorStack();
	printf("\n Desc_seq2  = [%d]\n", Desc_seq2);fflush(stdout);

	if((strcmp(ReleaseStatus,"ERC Review")==0)  || (strcmp(ReleaseStatus,"T5_LcsReview")==0) )
	{
	
	if (AOM_ask_value_string(rev,"item_revision_id",&Desc_obj)!=ITK_ok)   PrintErrorStack();
	printf("\n type_name  = [%s]\n", type_name);fflush(stdout);
	printf("\n revision  = [%s]\n", Desc_obj);fflush(stdout);
	
	if (AOM_ask_value_int(rev,"sequence_id",&Desc_seq)!=ITK_ok)   PrintErrorStack();
	printf("\n sequence  = [%d]\n", Desc_seq);fflush(stdout);

	Desc_seq1 = Desc_seq2 + 1;
	printf("\n sequence1  = [%d]\n", Desc_seq1);fflush(stdout);


	if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();

//	if(strcmp(Desc_obj2,"NR")==0)
//		{
//			if(POM_set_attr_string(1, &rev, attr_id, "NR;2")) PrintErrorStack();
//		}

//	else
//		{
			printf("\nValue of Desc_obj : %s\n",Desc_obj2);fflush(stdout);
			revi=strtok(Desc_obj2,";");
			printf("\nValue of revi : %s\n",revi);fflush(stdout);
			strcat(revi,";");
			printf("\nValue of revi : %s\n",revi);fflush(stdout);

			sprintf(revi1, "%d", Desc_seq1);
			printf("\nValue of revi : %s\n",revi);fflush(stdout);

			strcat(revi,revi1);
			printf("\nValue of revi : %s\n",revi);fflush(stdout);

			if(POM_set_attr_string(1, &rev, attr_id, revi)) PrintErrorStack();
//		}

//if(POM_save_instances(1, &rev, true)) PrintErrorStack();

//Desc_seq1 = Desc_seq2 + 1;
//printf("\n sequence1  = [%d]\n", Desc_seq1);fflush(stdout);

	printf("\nUpdating start2\n");fflush(stdout);
	if(AOM_lock(rev));
	if( AOM_set_value_int(rev,"sequence_id",Desc_seq1))PrintErrorStack();
	if(AOM_save(rev))PrintErrorStack();
	if(AOM_unlock(rev))PrintErrorStack();
	printf("\nUpdating end2\n");fflush(stdout);

			//if (RES_checkout(rev,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
		
			printf("\n**********After Check Out***************\n");fflush(stdout);
		//	if (AOM_lock(rev))PrintErrorStack();
		
			printf("\n############After lock muktesh\n");fflush(stdout);

				//if(GRM_find_relation_type("IMAN_master_form_rtype",&relation_type));

			//	if(TCTYPE_ask_name( relation_type, relation_name))PrintErrorStack();
			//	printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);
				
			//	if(relation_type = NULLTAG)
			//	{
					//if(TCTYPE_ask_name( relation_type, relation_name))PrintErrorStack();
					//printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);
					
//					if(ITEM_ask_latest_rev(master,&rev1))PrintErrorStack();
//					if (AOM_ask_value_string(rev1,"item_revision_id",&Desc_obj9)!=ITK_ok)   PrintErrorStack();
					
//					printf("\n revision  = [%s]\n", Desc_obj9);fflush(stdout);
//	
//					if (AOM_ask_value_int(rev1,"sequence_id",&Desc_seq9)!=ITK_ok)   PrintErrorStack();
//					printf("\n sequence  = [%d]\n", Desc_seq9);fflush(stdout);
//
//					if(GRM_list_secondary_objects_only(revisions[revision_count-2],relation_type,&cnt,&attachments))PrintErrorStack();
//					printf("\n Attached Datasets1:%d\n",cnt);fflush(stdout);
					
					if(GRM_list_secondary_objects_only(rev,relation_type,&cnt,&attachments))PrintErrorStack();
					printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
					
					
						
						if (RES_checkout(rev,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
					
					//if(GRM_list_secondary_objects_only(rev1,relation_type,&cnt,&attachments))PrintErrorStack();
					//printf("\n Attached Datasets3:%d\n",cnt);fflush(stdout);
					
					for(i=0;i<cnt;i++)
					{
						dataset = attachments[i];
						
						if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
						printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

						if (strcmp(ObjectClassType,"Design Revision Master")==0)
						{
							if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
							printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
							oojname=strtok(ObjectName,"/");
							strcat(oojname,"/");
							strcat(oojname,revi);
							printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);

							
							if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();
							
							if(AOM_lock(dataset));
							if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)) PrintErrorStack();
							if(AOM_save(dataset))PrintErrorStack();
							if(AOM_unlock(dataset))PrintErrorStack();

							//if(AOM_lock(dataset));
							//if( AOM_set_value_string(dataset,"sequence_id",Desc_seq1))PrintErrorStack();
							//if(AOM_save(dataset))PrintErrorStack();
							//if(AOM_unlock(dataset))PrintErrorStack();
						
						}
						
						if (strcmp(ObjectClassType,"Design Revision")!=0)
						{
							if (strcmp(ObjectClassType,"Design Revision Master")!=0)
							{
									printf("\n\n Dataset ObjectClassType1 :%s\n",ObjectClassType);fflush(stdout);
									if(RES_is_checked_out(dataset,&checkout))PrintErrorStack();
									printf("\nValue of checkout : %d\n",checkout);fflush(stdout);
						
									if (checkout==0)
									{
										tag_t* relation_list = NULLTAG;
										int relcount = 0;
										tag_t relation_type1 = NULLTAG;
										if(GRM_find_relation_type  ("IMAN_reference",&relation_type1))PrintErrorStack();
										if(GRM_list_relations(rev,dataset,relation_type1,NULLTAG,&relcount,&relation_list))PrintErrorStack();
										printf("\nIMAN_references count : %d",relcount);
										printf("\n\n going to checkout :%s\n",ObjectClassType);fflush(stdout);
										printf("\nCommented checkout of dataset by Devkant");fflush(stdout);
										if ( relcount <= 0 )
										{
											if(RES_checkout(dataset,&reason1,&change_id1,&dir_name1,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
											printf("\n %d DataSet Checked Out \n",dataset);
										}
										else
										{
											printf("\nSkipping IMAN_reference relation checkout");
										}
										
									}
							
							}
						}
					}
				//}
}

	//For Revising Part
		//	if((strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0) )
			if((strcmp(ReleaseStatus,"ERC Released")==0)  || (strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0) )
			{
				if(GRM_list_secondary_objects_only(rev,relation_type,&cnt,&attachments)) PrintErrorStack();
				printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
					for(i=0;i<cnt;i++)
					{
						dataset = attachments[i];
						
						if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
						printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

						if (strcmp(ObjectClassType,"Design Revision Master")==0)
						{
							if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
							printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
							oojname=strtok(ObjectName,"/");
							strcat(oojname,"/");
							printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);
						
						}
					}

				revi=strtok(Desc_obj2,";");
				printf("\nValue of revi in revision : %s\n",revi);fflush(stdout);
				if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();
				if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();
				
				
				if(AOM_lock(rev));
				
				if (strcmp(revi,"NR")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"A;1")) PrintErrorStack(); 
					strcat(oojname,"A;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"A")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"B;1")) PrintErrorStack(); 
					strcat(oojname,"B;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"B")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"C;1")) PrintErrorStack(); 
					strcat(oojname,"C;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"C")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"D;1")) PrintErrorStack(); 
					strcat(oojname,"D;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"D")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"E;1")) PrintErrorStack(); 
					strcat(oojname,"E;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"E")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"F;1")) PrintErrorStack(); 
					strcat(oojname,"F;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"F")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"G;1")) PrintErrorStack(); 
					strcat(oojname,"G;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"G")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"H;1")) PrintErrorStack(); 
					strcat(oojname,"H;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"H")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"I;1")) PrintErrorStack(); 
					strcat(oojname,"I;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"I")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"J;1")) PrintErrorStack(); 
					strcat(oojname,"J;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"J")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"K;1")) PrintErrorStack(); 
					strcat(oojname,"K;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"K")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"L;1")) PrintErrorStack(); 
					strcat(oojname,"L;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"L")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"M;1")) PrintErrorStack(); 
					strcat(oojname,"M;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"M")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"N;1")) PrintErrorStack(); 
					strcat(oojname,"N;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"N")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"O;1")) PrintErrorStack(); 
					strcat(oojname,"O;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"O")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"P;1")) PrintErrorStack(); 
					strcat(oojname,"P;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"P")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"Q;1")) PrintErrorStack(); 
					strcat(oojname,"Q;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"Q")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"R;1")) PrintErrorStack(); 
					strcat(oojname,"R;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"R")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"S;1")) PrintErrorStack(); 
					strcat(oojname,"S;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"S")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"T;1")) PrintErrorStack(); 
					strcat(oojname,"T;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"T")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"U;1")) PrintErrorStack(); 
					strcat(oojname,"U;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"U")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"V;1")) PrintErrorStack(); 
					strcat(oojname,"V;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"V")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"W;1")) PrintErrorStack(); 
					strcat(oojname,"W;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"W")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"X;1")) PrintErrorStack(); 
					strcat(oojname,"X;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"X")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"Y;1")) PrintErrorStack(); 
					strcat(oojname,"Y;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"Y")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"Z;1")) PrintErrorStack(); 
					strcat(oojname,"Z;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}
				if (strcmp(revi,"Z")==0) 
				{ 
					if(POM_set_attr_string(1, &rev, attr_id,"AA;1")) PrintErrorStack(); 
					strcat(oojname,"AA;1");
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
				}

/*
				if (strcmp(revi,"A")==0) if(POM_set_attr_string(1, &rev, attr_id, "B;1")) PrintErrorStack();
				if (strcmp(revi,"B")==0) if(POM_set_attr_string(1, &rev, attr_id, "C;1")) PrintErrorStack();
				if (strcmp(revi,"C")==0) if(POM_set_attr_string(1, &rev, attr_id, "D;1")) PrintErrorStack();
				if (strcmp(revi,"D")==0) if(POM_set_attr_string(1, &rev, attr_id, "E;1")) PrintErrorStack();
				if (strcmp(revi,"E")==0) if(POM_set_attr_string(1, &rev, attr_id, "F;1")) PrintErrorStack();
				if (strcmp(revi,"F")==0) if(POM_set_attr_string(1, &rev, attr_id, "G;1")) PrintErrorStack();
				if (strcmp(revi,"G")==0) if(POM_set_attr_string(1, &rev, attr_id, "H;1")) PrintErrorStack();
				if (strcmp(revi,"H")==0) if(POM_set_attr_string(1, &rev, attr_id, "I;1")) PrintErrorStack();
				if (strcmp(revi,"I")==0) if(POM_set_attr_string(1, &rev, attr_id, "J;1")) PrintErrorStack();
				if (strcmp(revi,"J")==0) if(POM_set_attr_string(1, &rev, attr_id, "K;1")) PrintErrorStack();
				if (strcmp(revi,"K")==0) if(POM_set_attr_string(1, &rev, attr_id, "L;1")) PrintErrorStack();
				if (strcmp(revi,"L")==0) if(POM_set_attr_string(1, &rev, attr_id, "M;1")) PrintErrorStack();
				if (strcmp(revi,"M")==0) if(POM_set_attr_string(1, &rev, attr_id, "N;1")) PrintErrorStack();
				if (strcmp(revi,"N")==0) if(POM_set_attr_string(1, &rev, attr_id, "O;1")) PrintErrorStack();
				if (strcmp(revi,"O")==0) if(POM_set_attr_string(1, &rev, attr_id, "P;1")) PrintErrorStack();
				if (strcmp(revi,"P")==0) if(POM_set_attr_string(1, &rev, attr_id, "Q;1")) PrintErrorStack();
				if (strcmp(revi,"Q")==0) if(POM_set_attr_string(1, &rev, attr_id, "R;1")) PrintErrorStack();
				if (strcmp(revi,"R")==0) if(POM_set_attr_string(1, &rev, attr_id, "S;1")) PrintErrorStack();
				if (strcmp(revi,"S")==0) if(POM_set_attr_string(1, &rev, attr_id, "T;1")) PrintErrorStack();
				if (strcmp(revi,"S")==0) if(POM_set_attr_string(1, &rev, attr_id, "U;1")) PrintErrorStack();
				if (strcmp(revi,"U")==0) if(POM_set_attr_string(1, &rev, attr_id, "V;1")) PrintErrorStack();
				if (strcmp(revi,"V")==0) if(POM_set_attr_string(1, &rev, attr_id, "W;1")) PrintErrorStack();
				if (strcmp(revi,"W")==0) if(POM_set_attr_string(1, &rev, attr_id, "X;1")) PrintErrorStack();
				if (strcmp(revi,"X")==0) if(POM_set_attr_string(1, &rev, attr_id, "Y;1")) PrintErrorStack();
				if (strcmp(revi,"Y")==0) if(POM_set_attr_string(1, &rev, attr_id, "Z;1")) PrintErrorStack();
				if (strcmp(revi,"Z")==0) if(POM_set_attr_string(1, &rev, attr_id, "AA;1")) PrintErrorStack();
*/			
				
				if(AOM_save(dataset))PrintErrorStack();
				if(AOM_unlock(dataset))PrintErrorStack();

				if(AOM_save(rev))PrintErrorStack();
				if(AOM_unlock(rev))PrintErrorStack();
			
				//Upendra 
				printf("\n Upendra \n");fflush(stdout);
				t5removeAllReleaseStatus(rev);
				ERROR_CALL (CR_create_release_status("T5_LcsReview",&status_rel));      
				ERROR_CALL(EPM_add_release_status(status_rel,1,&rev,retain));   				
				//ERROR_CALL(ITK_set_bypass(TRUE));                                     
																						
				ERROR_CALL(AOM_refresh(rev,1));                                         
				ERROR_CALL(AOM_save(rev));                                              			
																									
				ERROR_CALL(AOM_unlock(rev));    

				
				//Upendra
			}
	
	//revlength = strlen(Desc_seq);
	//printf("\n revlength  = [%d]\n", revlength);fflush(stdout);


//	ReplacedRevision = (char *)MEM_alloc (2 * sizeof(char));
//	strcpy(ReplacedRevision,Desc_obj);
/*
	printf("\n Desc_obj  = [%s]\n", Desc_obj);fflush(stdout);

	printf("\nUpdating start1\n");fflush(stdout);
	printf("\nUpdating start1 Z\n");fflush(stdout);
	if(AOM_lock(rev));
	if( AOM_set_value_string(rev,"item_revision_id",Desc_obj2))PrintErrorStack();
	if(AOM_save(rev))PrintErrorStack();
	if(AOM_unlock(rev))PrintErrorStack();
	printf("\nUpdating end1\n");fflush(stdout);



	//POM_refresh_instances_any_class(1, &instance, POM_no_lock);
	
	ERROR_CALL(AOM_lock(rev));
*/	
	//ITK_set_bypass
	// bypass = ITK_ask_cli_argument( CLI_OPTION_BYPASS ) != NULL;
	/* if ( bypass )
    {
        ITK ( ITK_set_bypass ( bypass ) );
        ITK ( POM_set_env_info ( POM_bypass_access_check, bypass, 0, 0.0, NULLTAG, "" ) );
    }*/
	//ERROR_CALL (CR_create_release_status("ERC Review",&status_rel));
	
	
	
	
	
/*	
	if (strcmp(type_name,"Design Revision") == 0)
	{
		CALLAPI(POM_class_of_instance(rev,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

		CALLAPI(POM_unload_instances (1,&rev));
		CALLAPI(POM_load_instances(1,&rev,class_id,1));
		CALLAPI(POM_is_loaded(rev,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		CALLAPI( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
		printf("\n n_values is :%d\n",n_values);fflush(stdout);
		if(n_values>0)
		{
			CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			printf("\n n_values11 is :%d\n",n_values);fflush(stdout);
				
			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
				
				
				CALLAPI(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
				
				
				CALLAPI(POM_save_instances(1,&rev,1));

				CALLAPI(POM_refresh_instances(1,&rev,class_id,2));

				CALLAPI(AOM_lock(rev));

				CALLAPI(AOM_save(rev));
				CALLAPI(AOM_refresh(rev,1));
				
			}

			 CALLAPI(AOM_unlock(rev));
		}
		
		ERROR_CALL (CR_create_release_status("T5_LcsReview",&status_rel));
		ERROR_CALL(EPM_add_release_status(status_rel,1,&rev,retain));
		//ERROR_CALL(ITK_set_bypass(TRUE)); 

		ERROR_CALL(AOM_refresh(rev,1));
		ERROR_CALL(AOM_save(rev));
		
		ERROR_CALL(AOM_unlock(rev));
	}
	
	*/
	
//	ERROR_CALL (CR_create_release_status("T5_LcsReview",&status_rel));
//	ERROR_CALL(EPM_add_release_status(status_rel,1,&rev,retain));
//	//ERROR_CALL(ITK_set_bypass(TRUE)); 
//
//	ERROR_CALL(AOM_refresh(rev,1));
//	ERROR_CALL(AOM_save(rev));
//	
//    ERROR_CALL(AOM_unlock(rev));
	printf("\n After ERC Review.... \n");fflush(stdout);

	return ITK_ok;
}



t5removeAllReleaseStatus (tag_t rev)
{

	int status_count;
	tag_t* status_list;
	int			st_relList_count		= 0; 
	int			Rel_cnt					= 0; 
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ; 
	tag_t		tReleaseStatusList		= NULLTAG; 
	int			n_values				= 0; 
	int			cunt1					= 0; 
	tag_t*		attr_tags				= NULLTAG; 
	logical		*is_it_null				= NULL; 
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;
	int	ifail = 0;

	ERROR_CALL (WSOM_ask_release_status_list(rev,&status_count,&status_list));

	printf("\n no of Status==%d\n",status_count);;fflush(stdout);
	if(status_count>0) 
	{
		//ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove...");fflush(stdout);
		
		CALLAPI(POM_class_of_instance(rev,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

		CALLAPI(POM_unload_instances (1,&rev));
		CALLAPI(POM_load_instances(1,&rev,class_id,1));
		CALLAPI(POM_is_loaded(rev,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		CALLAPI( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
		printf("\n n_values is :%d\n",n_values);fflush(stdout);
		if(n_values>0)
		{
			CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			printf("\n n_values11 is :%d\n",n_values);fflush(stdout);
				
			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
				
				
				CALLAPI(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
				
				
				CALLAPI(POM_save_instances(1,&rev,1));

				CALLAPI(POM_refresh_instances(1,&rev,class_id,2));

				CALLAPI(AOM_lock(rev));

				CALLAPI(AOM_save(rev));
				CALLAPI(AOM_refresh(rev,1));
				
			}

			 CALLAPI(AOM_unlock(rev));
		}
		printf("\n Status removed");;fflush(stdout);
	}
		/*ERROR_CALL (CR_create_release_status("T5_LcsReview",&status_rel));
		ERROR_CALL(EPM_add_release_status(status_rel,1,&rev,retain));
		//ERROR_CALL(ITK_set_bypass(TRUE)); 

		ERROR_CALL(AOM_refresh(rev,1));
		ERROR_CALL(AOM_save(rev));
	*/	
		ERROR_CALL(AOM_unlock(rev));
}





extern int libRevisepost_register_post_condition(int *decision, va_list args)
{
	METHOD_id_t  method;
	int	ifail = 0;
    *decision = ALL_CUSTOMIZATIONS;
	
	printf("\n Inside libRevisepost_register_post_condition  \n");;fflush(stdout);

    CALLAPI(METHOD_find_method("Design Revision", "ITEM_copy_rev", &method));
    if (method.id != NULLTAG)
    {
       // CALLAPI(METHOD_call_post_action(method, (METHOD_function_t)Revise_properties_post,NULL));
		 CALLAPI(METHOD_add_action(method, METHOD_post_action_type,(METHOD_function_t)Revise_properties_post,NULL));
		TC_write_syslog("\n\nAfter Register Revisepost\n");
		printf("\n Registered as libRevisepost_register_post_condition for Creation \n");fflush(stdout);
    }
	else
        printf("\n Method not found! \n");fflush(stdout);

    return ifail;	
}

extern DLLAPI int libRevisepost_register_callbacks()
{
	printf("\n Inside libRevisepost_register_callbacks  \n");;fflush(stdout);
	CUSTOM_register_exit("libRevisepost", "USER_init_module", (CUSTOM_EXIT_ftn_t)libRevisepost_register_post_condition);
    TC_write_syslog("\nRegister libRevisepost_register_callbacks \n");
	printf("\n libRevisepost_register_callbacks called.   \n");;fflush(stdout);
	return ITK_ok;
}

