/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : create_dynamic_lov.c
* Created By                   : Yogiraj
* Created On                   : 05/01/2007
* Project                      : Trillix
* Methods Defined              : CUSTOM_EXIT
* Description                  : Call Dynamic LOV for Project code and Material Class
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>

#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>

//#define ECHO(X)  printf X; IMAN_write_syslog X

#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

//static int myAskLOVLengthMethod( METHOD_message_t *msg, va_list  args ) ;
//static int myAskLOVValuesMethod( METHOD_message_t *msg, va_list  args ) ;
static int report_error(char *file, int line, char *call, int status,
    logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        int const    *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors( &n_errors, &severities, &statuses, &messages );
        if (n_errors > 0)
        {
            printf("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            printf("\n%s\n", error_message_string);
        }

        printf("error %d at line %d in %s\n", status, line, file);
        printf("%s\n", call);

        if (exit_on_error)
        {
            printf("\nExiting program!\n");
            exit (status);
        }
    }
    return status;
}

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

//int myAskLOVLengthMethod( METHOD_message_t *msg, va_list  args )
//{
//    /* va_list for LOV_ask_num_of_values_msg */
//    tag_t  lov_tag = va_arg(args, const tag_t);
//    int    *length = va_arg(args, int*);
//    char  ***values = va_arg(args, char***);
//	char *item_sequence_id;
//	int status;
//
//    int
//        error_code= ITK_ok,
//        n_entries = 2,
//        n_found = 0,
//		ii = 0;
//    tag_t
//        query = NULLTAG,
//        *cntr_objects = NULL,
//		user = NULLTAG;
//    char
//        *qry_entries[2] = {"t5_SubSyscd", "t5_Syscd"},
//        *qry_values[2] =  {"Project", "Code"};
//
//    printf(("\n\n myAskLOVLengthMethod\n\n"));
//
//    TAG_free(cntr_objects);
//
//
//	IFERR_REPORT(QRY_find("ControlObjQry", &query));
//	printf(("111111111111111111"));
//    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
//	printf(("wwwwwwwww"));
//
//    *length = n_found;
//
//	printf(("\t n_values = %d\n", *length));
//
//    *values = (char **)MEM_alloc (*length * sizeof(char*));
//    memset( *values, 0,  *length * sizeof(char*));
//
//    for (ii = 0; ii < n_found; ii++)
//    {
//		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo1",&item_sequence_id));
//
//		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
//        strcpy((*values)[ii], item_sequence_id);
//    }
//    TAG_free(cntr_objects);
//    TAG_free(item_sequence_id);
//
//    return error_code;
//}


int myAskLOVValuesMethodP( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t	lov_tag		= va_arg(args, const tag_t);
    int*	n_values	= va_arg(args, int*);
    char	***values	= va_arg(args, char***);
	char	*item_sequence_id;
	int		status;

    int
        error_code	= ITK_ok,
        n_entries	= 2,
        n_found		= 0,
        ii			= 0;
    tag_t
        query			= NULLTAG,
        *cntr_objects	= NULL,
        user			= NULLTAG;
    char
        *qry_entries[2] = {"Project ID","Active"},
        *qry_values[2]	= {"*","Y"};

    printf("\nTCDC************** cmcreate_dynamic_lov.c::myAskLOVValuesMethodP ");fflush(stdout);

    IFERR_REPORT(QRY_find("QueryProject", &query));
	printf("\nTCDCAfter IFERR_REPORT : QRY_find \n");fflush(stdout);
	if (query)
	{
		printf("\nTCDCFound Query");fflush(stdout);
	}
	else
	{
		printf("\nTCDCNot Found Query");fflush(stdout);
	}
	printf("\nTCDC :::::-::::: \n");
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC**** %d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC####### = %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"project_id",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}

int myAskLOVValuesMethod( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;

    int
        error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
    tag_t
        query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;
    char
         *qry_entries[2] = {"SUBSYSCD", "SYSCD"},
        *qry_values[2] =  {"*", "MATCLS"};

	printf("\nTCDCcreate_dynamic_lov.c::myAskLOVValuesMethod ");fflush(stdout);

    IFERR_REPORT(QRY_find("ControlObjQry", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo4",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}

int myAskLOVKeyWordValuesMethod( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;

    int
        error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
    tag_t
        query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;
    char
         //*qry_entries[2] = {"t5_SubSyscd", "t5_Syscd"},
         *qry_entries[2] = {"SUBSYSCD", "SYSCD"},
        *qry_values[2] =  {"*", "KwyWord"};

	printf("\nTCDCcreate_dynamic_lov.c::myAskLOVKeyWordValuesMethod ");fflush(stdout);

    IFERR_REPORT(QRY_find("KeyWordQry", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo1",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}
int myAskLOVStartPartValuesMethod( METHOD_message_t *msg, va_list  args )
{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id=NULL;
	char *userinfo_value=NULL;
	char *role_name=NULL;
	char *design_group_name=NULL;
	char *information1_value = NULL;
	char final_information1_value[20];
	
	int status;

    int
        error_code = ITK_ok,
        n_entries = 2,
        m_entries = 3,
        n_found = 0,
        ii = 0;
	
    tag_t
        query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG,
		role_tag  = NULLTAG;
    char
         *qry_entries[2] = {"SYSCD", "SUBSYSCD"},
        *qry_values[2] = {"TOOLTYPE", "DESIGNGROUP"},
         *qry_m_entries[3] = {"SYSCD","SUBSYSCD","Information-1"},
          *qry_m_values[3];
	
	printf("\nTCDCcreate_dynamic_lov.c::myAskLOVStartPartValuesMethod ");fflush(stdout);

	//Find Current User Role
	IFERR_REPORT(SA_ask_current_role(&role_tag));

	if(role_tag != NULLTAG)
	{
		printf("\nTCDCcreate_dynamic_lov.c::Role Tag Found");fflush(stdout);
		//Get Role Name
		IFERR_REPORT(SA_ask_role_name2(role_tag,&role_name));
	}
	else
	{
		role_name = "NA";
	}	
	printf("\n RoleName == %s\n", role_name);

	design_group_name = tc_strtok(role_name,"_");
	printf("\n design_group_name == %s\n", design_group_name);fflush(stdout);
	
//	design_group_name_int = atoi(design_group_name);
//	printf("\n design_group_name_int == %s\n", design_group_name_int);

//	if(design_group_name_int < 0 || design_group_name_int > 99)
//	{
//		*qry_entries[2] = {"SUBSYSCD", "SYSCD","Information-1"},
//        *qry_values[2] =  {"*", "STARTPART","NA"};
//	}
//	else if(design_group_name_int == 54 || design_group_name_int == 16 || design_group_name_int > 59)
//	{
//		*qry_entries[2] = {"SUBSYSCD", "SYSCD","Information-1"},
//        *qry_values[2] =  {"*", "STARTPART","CATIA"};
//	}
//	else if(design_group_name_int == 54 || design_group_name_int == 16 || design_group_name_int > 59)
//	{
//		*qry_entries[2] = {"SUBSYSCD", "SYSCD","Information-1"},
//        *qry_values[2] =  {"*", "STARTPART","CATIA"};
//	}
//	else
//	{
//		*qry_entries[2] = {"SUBSYSCD", "SYSCD","Information-1"},
//        *qry_values[2] =  {"*", "STARTPART","PROE"};
//	}

	 IFERR_REPORT(QRY_find("ControlObjFindCadToolBasedOnDesGrp", &query));
	 IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	 printf("\n Objects for Query ControlObjFindCadToolBasedOnDesGrp == %d", n_found);fflush(stdout);

	 if(n_found == 1)
	 {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&userinfo_value));
		if(tc_strstr(userinfo_value, design_group_name) != NULL)
		{
			information1_value = tc_strtok(userinfo_value,"_");
		}

		if(information1_value == NULL)
		{
			ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&userinfo_value));
			if(tc_strstr(userinfo_value, design_group_name) != NULL)
			{
				information1_value = tc_strtok(userinfo_value,"_");
			}
		}

		if(information1_value == NULL)
		{
			ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo3",&userinfo_value));
			if(tc_strstr(userinfo_value, design_group_name) != NULL)
			{
				information1_value = tc_strtok(userinfo_value,"_");
			}
		}		
	 }		

	 printf("\ninformation1_value == %s\n", information1_value);

	 qry_m_values[0] = "STARTPART";
	 qry_m_values[1] = "PRT";
	 if(information1_value == NULL)
	 {       
		qry_m_values[2] = "NA";
	 }
	 else
	 {
		tc_strcpy(final_information1_value,"*");		
		tc_strcat(final_information1_value,information1_value);
		tc_strcat(final_information1_value,"*");
		printf("\nfinal_information1_value -- %s", final_information1_value);fflush(stdout);
		qry_m_values[2] = final_information1_value;	
	 }

    IFERR_REPORT(QRY_find("ControlObjQryStartPrt", &query));
	printf("\nTCDCSTARTPART-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, m_entries, qry_m_entries, qry_m_values, &n_found, &cntr_objects));
    printf("\nTCDCSTARTPART%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC STARTPART== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));
    printf("\nTCDC STARTPART== %d\n", *n_values);fflush(stdout);


    for (ii = 0; ii < n_found; ii++)
    {
		 printf("After ii:%d\n",ii);fflush(stdout);

		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo4",&item_sequence_id));
		 printf("After Userinfo4:%s\n",item_sequence_id);fflush(stdout);
		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
	
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);
 

    return error_code;
}
//extern DLLAPI int t5_LOV_register_method(int *decision)
//{
//    int          ifail = ITK_ok;
//    METHOD_id_t  method;
//    METHOD_id_t  methodP;
//
//    *decision = ALL_CUSTOMIZATIONS;
//
//
//    //printf("\n Inside register message for dynamic value set \n");
//    printf("create_dynamic_lov.c:t5_LOV_register_method - ");
//
//    if( ifail == ITK_ok )
//    {
//        ifail = METHOD_register_method( "T5_MatlClsLOVType",
//            LOV_ask_values_msg,
//            &myAskLOVValuesMethod,  0,
//            &method);
//    }
//    //printf("\n  registered message for dynamic value set \n");
//
//	if( ifail == ITK_ok )
//    {
//        ifail = METHOD_register_method( "T5_ProjCodeLOVType",
//            LOV_ask_values_msg,
//            &myAskLOVValuesMethodP,  0,
//            &methodP);
//    }
//    printf(" registered message for dynamic value set \n");
//
////    if( ifail == ITK_ok )
////    {
////        ifail = METHOD_register_method( "T5_ProjCodeLOVType",
////            LOV_ask_num_of_values_msg,
////            &myAskLOVLengthMethod,  0,
////            &method);
////    }
////    printf("\n  register message for dynamic value set..... \n");
//
//    if( ifail != ITK_ok )
//    {
//        EMH_store_error( EMH_severity_error, ifail );
//    }
//
//    return ifail;
//}

//
//extern DLLAPI int t5_LOV_register_callbacks ()
//{
//    int ifail    = ITK_ok;
//    printf("\n create_dynamic_lov.c:before t5_LOV_register_callbacks");
//
//    ifail=CUSTOM_register_exit ( "t5_LOV", "USER_init_module", (CUSTOM_EXIT_ftn_t)  t5_LOV_register_method);
//    printf(" - after calling t5_LOV_register_callbacks");
//
//  return ( ITK_ok );
//}


int myAskModALOVValuesMethod( METHOD_message_t *msg, va_list  args )
{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;

    int
        error_code = ITK_ok,
        n_entries = 1,
        n_found = 0,
        ii = 0;
	tag_t
        query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;

	char
        *qry_entries[1] = {"Module Address"},
        *qry_values[1]	= {"*"};

	//char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	//char *qry_entries[1] = {"Module Address"};

	printf("\nTCDCcreate_dynamic_lov.c :: myAskModALOVValuesMethod.......................\n");fflush(stdout);

    IFERR_REPORT(QRY_find("ModuleArchRlz", &query));
	printf("\nTCDC--ModuleArchRlz....\n");fflush(stdout);

    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC --> ModuleArchRlz :: %d", n_found);fflush(stdout);
		
    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL(AOM_ask_value_string(cntr_objects[ii],"t5_ArchModuleAddress",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }

	TAG_free(cntr_objects);
    TAG_free(item_sequence_id);
	
    return error_code;
}
/*************************************************************************
To fetch Keyword Description from classification in LOV
*************************************************************************/
int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args )
{
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
                tag_t                       item_tag        = NULLTAG;
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	char *Classi_class;
	
	char *objTypeTagk;
	char *DesignGrp;
	char       roleName[SA_name_size_c+1]  ;
	char *userId;
	char *parent_name;				             
	tag_t relns,*relns1;
	int status;
	tag_t  master_reln_type;
	tag_t  primary;
	tag_t  CurrentRoleTag = NULLTAG;
	WSO_description_t        desc;

	int error_code = ITK_ok;
	int n_entries = 2,k=0,j=0;
	int n_entries1=2;
	int n_found = 0;
	int n_found1=0;
	int ii = 0,n_relns,n_relns1=0;
	tag_t query = NULLTAG, query1=NULLTAG, *cntr_objects = NULL, *cntr_objects1 = NULL, user = NULLTAG;
	char *class_name = NULL;
	tag_t type_tag = NULLTAG;
	tag_t * new_form = NULLTAG; 
	tag_t objTypeTag2 = NULLTAG;
	tag_t *relation ;
	tag_t item_tag1 ;
	tag_t person_tag=NULLTAG;
	tag_t user_tag=NULLTAG;
                   
    char *type_wso_name= NULL;
	int TotalLovCount = 0;
	int iMyLovCounter = 0;
	char *qry_entries[2] = {"Name","ext_1"};
	char *qry_entries1[2]={"role_name1","Name"};				
	char * user_name_string;


	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));


	METHOD_PROP_MESSAGE_OBJECT( msg, item_tag );

    printf("\nKeyword description Lov");
	printf("\nKeywordcreate_dynamic_lov.c::myAskLOVKeyWordValuesMethod class_namewwww : Calling3");fflush(stdout);
	ITK_CALL(POM_get_user_id(&userId));    
	printf("\n after POM_get_user_id:%s\n",userId);fflush(stdout);  
	ITK_CALL( POM_get_user(&user_name_string,&user_tag)); 
	printf("\n after POM_get_user:%s\n",user_name_string);fflush(stdout);  

	ITK_CALL(SA_ask_current_role(&CurrentRoleTag));

	ITK_CALL(SA_ask_role_name(CurrentRoleTag,roleName))

	printf("\n after SA_ask_role_name:%s \n",roleName);fflush(stdout);
                                

	qry_values1[0]="*";
	qry_values1[1]=user_name_string;
	
	IFERR_REPORT(QRY_find("QryKyWrd_iUnme_oRole", &query1));
	printf("\nKeyword12345-- ");fflush(stdout);

	IFERR_REPORT(QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
	printf("\nKeyword54321   %d", n_found1);fflush(stdout);
	TotalLovCount = 0;                
	if(n_found1>0)
	{
		printf("\nafter for loop n_found:%d",n_found);
		for (j=0;j<n_found1;j++ )
		{
			item_tag1 = cntr_objects1[j];
			ITK_CALL(AOM_ask_value_string(item_tag1,"object_name",&parent_name));
			printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
			if(tc_strstr(parent_name, "dba"))
			continue;
			
			
			if(tc_strstr(parent_name,"ERC_Designers_Group")==NULL)
				{
					continue;
				}
			printf("\nbefore1 allocate DesignGrp mem");fflush(stdout);			
			DesignGrp = (char *) MEM_alloc(3 * sizeof(char ));
			printf("\nafter1 allocate DesignGrp mem parent_name:%s",parent_name);fflush(stdout);			
			
			DesignGrp[0]=parent_name[20];
			DesignGrp[1]=parent_name[21];
			DesignGrp[2]='\0';
			printf("\n DesignGrp:%s ..............",DesignGrp);fflush(stdout);
			qry_values[0] = "*" ;
			qry_values[1] = DesignGrp;		
			
			IFERR_REPORT(QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &query));
			IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
			
			TotalLovCount = TotalLovCount + n_found;
		}
		printf("\nTotalLovCount:%d",TotalLovCount);fflush(stdout);
		
		iMyLovCounter = 0;
						
		if( TotalLovCount > 0 )
		{
			*n_values = TotalLovCount;

			*values = (char **)MEM_alloc (*n_values * sizeof(char*));
			memset( *values, 0,  *n_values * sizeof(char*)); 
			
			for (j=0;j<n_found1;j++ )
			{
				item_tag1 = cntr_objects1[j];
				ITK_CALL(AOM_ask_value_string(item_tag1,"object_name",&parent_name));
				printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
				if(tc_strstr(parent_name, "dba" ))
			continue;
				
				
				if(tc_strstr(parent_name,"ERC_Designers_Group")==NULL)
				{
					continue;
				}
			printf("\nbefore2 allocate DesignGrp mem");fflush(stdout);			
			DesignGrp = (char *) MEM_alloc(3 * sizeof(char ));
			printf("\nafter2 allocate DesignGrp mem");fflush(stdout);			
			DesignGrp[0]=parent_name[20];
			DesignGrp[1]=parent_name[21];
			DesignGrp[2]='\0';
			printf("\n DesignGrp:%s ..............",DesignGrp);fflush(stdout);

				
				printf("\n DesignGrp:%s ..............",DesignGrp);fflush(stdout);
				qry_values[0] = "*" ;
				qry_values[1] = DesignGrp;
				



				IFERR_REPORT(QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &query));
				IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
				printf("\nKeyword n_found:%d", n_found);fflush(stdout);


				if(n_found>0)
				{
					printf("\nKeyword *n_values: %d\n", *n_values);fflush(stdout);

					for (ii = 0; ii < n_found; ii++)
					{
						ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"name",&Classi_class));

						(*values)[iMyLovCounter] = (char *) MEM_alloc (strlen(Classi_class) + 1);
						strcpy((*values)[iMyLovCounter], Classi_class);
						printf("\nKeyword ii=%d (*values)[%d]:%s",ii,iMyLovCounter, (*values)[iMyLovCounter]);fflush(stdout);
						iMyLovCounter = iMyLovCounter + 1;		
						


					}
					TAG_free(cntr_objects); 
				}
										
			}
		}
			printf("\nTest1");	fflush(stdout);
		  
	}
	printf("\ntest2");fflush(stdout);
    return error_code;
}
