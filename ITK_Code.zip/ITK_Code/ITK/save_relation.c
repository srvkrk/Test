/****************************************************************************************************
*  File                 :		save_relation.c
*  Created By			:		Yogendra Kumar Mahikwar
*  Created On			:		23-July-2012
*  Purpose				:		 Model Indicator and drawing Indicator field should be read only for user. The indicators should be updated on attaching of model or drawing by the system..			
*								This is called at pre action of save.
*  Modification History :		Set the Value of Application OwnerD in DataSet based on ProPrt/ProAsm.
								Datatype Selection if ApplicationOwner value in DesignRevision is blank. 
*  Modification Date    :		22-Oct-2016
*  Modification  By	    :		Deepti Meshram
******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <user_exits/user_exits.h>
#include <ss/ss_const.h>
#include <ae/ae.h>
#include <tccore/aom_prop.h>
#include <epm/epm_errors.h>
#include <sys/stat.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <tccore/custom.h>
#include <ae/dataset.h>
#include <tccore/grm.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <tccore/method.h>
#include <ps/ps_errors.h>
#include <tccore/aom.h>
#include <res/reservation.h>
#include <sa/sa.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <fclasses/tc_time.h>
#include <unidefs.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <tccore/tc_msg.h>
#include <tccore/iman_msg.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/grmtype.h>
#include <pom/pom/pom.h>
#include <ai/sample_err.h>



#define ITK_err 919002
#define CONNECT_FAIL (EMH_USER_error_base + 2)

char	*t5ApplOwnerDValCheck		=	NULL; //Added by Deepti

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

extern DLLAPI int  save_method_17(METHOD_message_t *msg, va_list args)
{

		int		error_code				=	ITK_ok;
		int		desclength				=	0;
		int		revdesccnt				=	0;

		tag_t	objTag					=	va_arg(args, tag_t);
		tag_t	objTypeTag				=	NULLTAG;
		tag_t	priObjTag				=	NULLTAG;
		tag_t	priObjTypeTag			=	NULLTAG;
		tag_t	secObjTag				=	NULLTAG;
		tag_t	secObjTypeTag			=	NULLTAG;

		char   type_name[TCTYPE_name_size_c+1];
		char   type_name1[TCTYPE_name_size_c+1];
		char   type_name2[TCTYPE_name_size_c+1];

		char	*desid					=	NULL;   
		char	*DesRevDesc				=	NULL;
		char	*ReplacedDesRevDesc		=	NULL;
		char	*NewReplacedDescription	=	NULL;
		char	*ItemMaterial			=	NULL;
		char	*DrwName				=	NULL;
		char	*FileName				=	NULL;
   



      EPM_decision_t decision=EPM_go;

      printf("\n save_method_17::It's the time to save IMAN_specification relation \n");fflush(stdout);


	  if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
      if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	  printf("\n save_method_17::type_name :%s\n", type_name);fflush(stdout);


	  if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
	  if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
	  if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
	  printf("\n save_method_17::pri_type_name :%s\n", type_name1);fflush(stdout);

	  if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
	  if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
	  if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
	  printf("\n save_method_17::sec_type_name :%s\n", type_name2);fflush(stdout);

	  
	  if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheck)!=ITK_ok);
	  printf("\n Before saving re;ation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheck);fflush(stdout);



//		if(strcmp(type_name2,"ProDrw")==0)
//		{
//			printf("\n It is ProDrw Dataset\n");fflush(stdout);
//			if( AOM_ask_value_string(priObjTag,"object_name",&DrwName)!=ITK_ok);
//			  printf("\n save_method_17::object_name :%s\n", DrwName);fflush(stdout);
//
//			if(AOM_lock(priObjTag))PrintErrorStack();
//			  printf("\n lock:%s\n", DrwName);fflush(stdout);
//			if( AOM_set_value_string(priObjTag,"t5_DrawingInd","D")!=ITK_ok);
//			  printf("\n AOM_set_value_string:%s\n", DrwName);fflush(stdout);
//			if(AOM_save(priObjTag))PrintErrorStack();
//			  printf("\n save\n");fflush(stdout);
//			if(AOM_unlock(priObjTag))PrintErrorStack();
//			  printf("\n unlock\n");fflush(stdout);		
//		}
//
//		if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0 )
//		{
//			printf("\n It is ProPrt or ProAsm Dataset\n");fflush(stdout);
//			if( AOM_ask_value_string(priObjTag,"object_name",&FileName)!=ITK_ok);
//			  printf("\n save_method_17::object_name :%s\n", FileName);fflush(stdout);
//
//			if(AOM_lock(priObjTag))PrintErrorStack();
//			  printf("\n lock:%s\n", FileName);fflush(stdout);
//			if( AOM_set_value_string(priObjTag,"t5_ModelIndicator","Y")!=ITK_ok);
//			  printf("\n AOM_set_value_string:%s\n", FileName);fflush(stdout);
//			if(AOM_save(priObjTag))PrintErrorStack();
//			  printf("\n save\n");fflush(stdout);
//			if(AOM_unlock(priObjTag))PrintErrorStack();
//			  printf("\n unlock\n");fflush(stdout);		
//		}



		if(strcmp(type_name2,"ProPrt")==0 )
		{
			printf("\n ProPrt Dataset found ..\n");fflush(stdout);

			if ((tc_strcmp(t5ApplOwnerDValCheck,"NULL")==0) || (tc_strcmp(t5ApplOwnerDValCheck,"")==0))
			{
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","ProEPart")!=ITK_ok);
				printf("\n first AOM_set_value_string for app owner: ProEPart \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n first save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n first unlock..\n");fflush(stdout);	
			}
			else
			{
				
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD",t5ApplOwnerDValCheck)!=ITK_ok);
				printf("\n ssecond AOM_set_value_string for app owner: t5ApplOwnerDValCheck \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n ssecond save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n ssecond unlock..\n");fflush(stdout);	
			
			}
		}

		if(strcmp(type_name2,"ProAsm")==0 )
		{
			printf("\n ProAsm Dataset found ..\n");fflush(stdout);

			if ((tc_strcmp(t5ApplOwnerDValCheck,"NULL")==0) || (tc_strcmp(t5ApplOwnerDValCheck,"")==0))
			{
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","ProEPart")!=ITK_ok);
				printf("\n ProAsm first AOM_set_value_string for app owner: ProEPart \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n ProAsm first save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n ProAsm first unlock..\n");fflush(stdout);	
			}
			else
			{
				
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD",t5ApplOwnerDValCheck)!=ITK_ok);
				printf("\n ssecond ProAsm AOM_set_value_string for app owner: t5ApplOwnerDValCheck \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n ssecond ProAsm save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n ssecond ProAsm unlock..\n");fflush(stdout);	
			
			}
		}

		if(strcmp(type_name2,"CMI2Part")==0 )
		{
			printf("\n CMI2Part�Dataset found ..\n");fflush(stdout);

			if ((tc_strcmp(t5ApplOwnerDValCheck,"NULL")==0) || (tc_strcmp(t5ApplOwnerDValCheck,"")==0))
			{
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Cat-Part")!=ITK_ok);
				printf("\n in CMI2Part AOM_set_value_string for app owner: ProEAsm \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n in CMI2Part save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n in CMI2Part unlock..\n");fflush(stdout);	
			}
			else
			{
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD",t5ApplOwnerDValCheck)!=ITK_ok);
				printf("\n 1 in CMI2Part AOM_set_value_string for app owner: ProEAsm \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n 1 in CMI2Part save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n 1 in CMI2Part unlock..\n");fflush(stdout);	
			
			
			}
		}


		if(strcmp(type_name2,"CMI2Product")==0 )
		{
			printf("\n CMI2Product� Dataset found ..\n");fflush(stdout);

			if ((tc_strcmp(t5ApplOwnerDValCheck,"NULL")==0) || (tc_strcmp(t5ApplOwnerDValCheck,"")==0))
			{
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Cat-Product")!=ITK_ok);
				printf("\n in CMI2Product� AOM_set_value_string for app owner: ProEAsm \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n in CMI2Product� save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n in CMI2Product� unlock..\n");fflush(stdout);	
			}
			else
			{
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD",t5ApplOwnerDValCheck)!=ITK_ok);
				printf("\n 1 in CMI2Product� AOM_set_value_string for app owner: ProEAsm \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n 1 in CMI2Product� save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n 1 in CMI2Product� unlock..\n");fflush(stdout);	
			
			
			}
		}

		if( (strcmp(type_name2,"CMI2Part")!=0 ) && (strcmp(type_name2,"CMI2Product")!=0 ) && (strcmp(type_name2,"ProPrt")!=0 ) && (strcmp(type_name2,"ProAsm")!=0 ))
		{
			printf("\n No CMI2Part/CMI2Product/ProPrt/ProAsm� Dataset found ..\n");fflush(stdout);

			if ((tc_strcmp(t5ApplOwnerDValCheck,"NULL")==0) || (tc_strcmp(t5ApplOwnerDValCheck,"")==0))
			{
				printf("\n No t5ApplOwnerDValCheck is found.. \n");fflush(stdout);
				
			}
			else
			{
				if(AOM_lock(secObjTag))PrintErrorStack();
				if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD",t5ApplOwnerDValCheck)!=ITK_ok);
				printf("\n AOM_set_value_string for app owner: ProEAsm \n");fflush(stdout);
				if(AOM_save(secObjTag))PrintErrorStack();
				printf("\n save..\n");fflush(stdout);
				if(AOM_unlock(secObjTag))PrintErrorStack();
				printf("\n unlock..\n");fflush(stdout);	
			
			
			}
		}








      return error_code;
}

extern int save_relation_custom_exit(int *decision, va_list args)
{
    int ifail = ITK_ok;
    METHOD_id_t  method ;

    *decision = ALL_CUSTOMIZATIONS;  

    /* do something useful here, for now just return */
	printf("\n\n save_relation.c:it, via Custom Exits.\n");fflush(stdout);
    if ( METHOD_find_method("IMAN_specification", IMAN_save_msg, &method) !=ITK_ok);

 
    if (method.id != NULLTAG)
	{
		printf("\n !!!!!!!!!!!IMAN_specification ---Method is  found!!!!!!!!!!\n");fflush(stdout);
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) save_method_17, NULL)!=ITK_ok);
   
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}

	else
	{
		printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");fflush(stdout);
	}

    return ifail;
}


extern DLLAPI int save_relation_register_callbacks ()
{
     printf("\n \n save_relation.c:::Hello Teamcenter, via Custom Exit\n");fflush(stdout);

     CUSTOM_register_exit ( "save_relation", "USER_init_module", (CUSTOM_EXIT_ftn_t) save_relation_custom_exit);

     return ( ITK_ok );
}
