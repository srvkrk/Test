#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void  getPlantDetailsAttr( char * RoleName ,char  getPlantCS[40],char  getPlantOptCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40])
{
     char   *PlantName=NULL;
	  printf( "RoleName:%s\n", RoleName);
      PlantName=subString(RoleName,0,4);
      printf( "PlantName:%s\n", PlantName);
	  if(strcmp(RoleName,"APLD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_DwdOptionalCS");
		tc_strcpy(getPlantIA,"t5_DwdIntialAgency");
		tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
		tc_strcpy(getUserAgency,"DWD");
	  }else  if(strcmp(PlantName,"APLP")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }else  if(strcmp(PlantName,"APLC")==0)
	  {
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_CarOptionalCS");
		tc_strcpy(getPlantIA,"t5_CarIntialAgency");
		tc_strcpy(getPlantStore,"t5_CarStoreLocation");
		tc_strcpy(getUserAgency,"CAR");
	  }else  if(strcmp(PlantName,"APLJ")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_JsrOptionalCS");
		tc_strcpy(getPlantIA,"t5_JsrIntialAgency");
		tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
		tc_strcpy(getUserAgency,"JSR");
	  }else  if(strcmp(PlantName,"APLL")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_LkoOptionalCS");
		tc_strcpy(getPlantIA,"t5_LkoIntialAgency");
		tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
		tc_strcpy(getUserAgency,"LKO");
	  }else  if(strcmp(PlantName,"APLA")==0)
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_AhdOptionalCS");
		tc_strcpy(getPlantIA,"t5_AhdIntialAgency");
		tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
		tc_strcpy(getUserAgency,"AHD");
	  }else  if(strcmp(PlantName,"APLU")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_PnrOptionalCS");
		tc_strcpy(getPlantIA,"t5_PnrIntialAgency");
		tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
		tc_strcpy(getUserAgency,"PNR");
	  }else  if(strcmp(PlantName,"APLS")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_JdlOptionalCS");
		tc_strcpy(getPlantIA,"t5_JdlIntialAgency");
		tc_strcpy(getPlantStore,"t5_JdlStoreLocation");
		tc_strcpy(getUserAgency,"JDL");
	  }else
	 {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}




int setEffectivity(tag_t* itemRev,char* date)
{

	int status;
	logical   date_is_valid   = FALSE;
	tag_t	  st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t	  st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;
	int   ifail				= 0;


	CALLAPI(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		CALLAPI(POM_class_of_instance(status_list[0],&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		CALLAPI(POM_unload_instances (st_count,status_list));
		CALLAPI(POM_load_instances(st_count,status_list,class_id,1));
		CALLAPI(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
			//CALLAPI(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
			//CALLAPI(WSOM_eff_set_date_range(status_list[0]));
			//WSOM_status_ask_effectivitie
			//CALLAPI(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
			CALLAPI(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"11-MAR-2014 00:00 to UP",&eff_t));
			CALLAPI(AOM_save(status_list[0]));
			CALLAPI(POM_save_instances(st_count,status_list,1));

		}else
		{
			printf("\n Cannot load this......");
		}
		//CALLAPI(AOM_save(*itemRev));
		//CALLAPI(AOM_unlock(*itemRev));
	}
	  return ITK_ok;

}

int createAplCR_Task( METHOD_message_t *msg, va_list  args )
{

    tag_t	TaskTag		= va_arg(args, const tag_t);
    int*	n_values	= va_arg(args, int*);
    char	***values	= va_arg(args, char***);
	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;
	int max_char_size = 80;
	char*			DMLAPL					=NULL;
	char*			Suffix					=NULL;

	int n_tags_found = 0;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	tag_t *tags_found = NULL;

	//char *item_id_dup 	   = NULL;
	int  number_found;
	tag_t *list_of_WSO_tags=NULLTAG;

	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	WSO_search_criteria_t  	criteria;

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
    printf("\n **************inside createCR_Task***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	if(strcmp(type_name,"T5_APLDMLRevision")==0)
	{
		    printf("\n inside class T5_APLDMLRevision......\n");fflush(stdout);
			AOM_ask_value_string( TaskTag, "item_id", &item_id);
			AOM_ask_value_string( TaskTag, "current_id", &DML_no);
			AOM_ask_value_strings(TaskTag,"t5_crdesigngroup",&num,&DesignGroupList);

			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			for(i=0;i<num;i++)
			{
				 DMLAPL = strtok (DML_no,"_");
				 Suffix = strtok (NULL,"_");

				printf("\n DMLAPL is : %s\n",DMLAPL);fflush(stdout);
    			printf("\n Suffix is : %s\n",Suffix);fflush(stdout);

				strcpy(item_id_dup,DMLAPL);
				strcat (item_id_dup,"_");
				strcat (item_id_dup,DesignGroupList[i]);
				strcat (item_id_dup,"_");
				strcat(item_id_dup,Suffix);


    			printf("\n item_id_dup AFTER CAT is by hanuman :%s\n",item_id_dup);fflush(stdout);

				WSOM_clear_search_criteria(&criteria);
				strcpy(criteria.name,item_id_dup);
				strcpy(criteria.class_name,"T5_APLTaskRevision");
				status	= WSOM_search(criteria, &number_found, &list_of_WSO_tags);

				//ITEM_find_items_by_key_attributes(1, "item_id", item_id_dup, &n_tags_found, &tags_found);
				printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

				if(number_found == 0)
				 {
					printf("\n item_id :%s and DML_no :%s\n ",item_id,DML_no);fflush(stdout);
					ITEM_create_item(item_id_dup,item_id_dup,"T5_APLTask","A",&item,&rev);
					printf("\n Item created first time only with item_id \n");fflush(stdout);

					AOM_save(item);
					AOM_save(rev);
					GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
					GRM_create_relation(TaskTag, rev, relation_type,  NULLTAG, &relation);
					GRM_save_relation(relation);
					if(AssignAPLPlanner(rev));
					if(AssignAPLReviewer(rev));

				 }else
				 {
					printf("\n item_id created twice......  \n");fflush(stdout);
				 }

				 MEM_free(list_of_WSO_tags);
			 }
	}

    return error_code;

}

int apl_dml_assign( EPM_action_message_t msg )
{

		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l,cnt		=0;
		int  attype = 1;
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;

		tag_t			*objTypeTagTask			= NULLTAG;

		//GRM_relation_t			*secondary_objects	;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;


		char*			parent_name				=NULL;
		char*			object_type				=NULL;
		char*			Analyst_name			=NULL;
		char*			DmlAnalyst_name			=NULL;

		char*			Dml_no					=NULL;
		char*			CurrentTask				=NULL;
		char*			TaskName				=NULL;
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;



		POM_get_user(&username,&user_tag);
		printf("\nStarting for username :%s....\n",username);fflush(stdout);
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n apl_dml_assign \n"); fflush(stdout);
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	   printf("\nCurrentTask:%s\n",CurrentTask);
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);

		if(strstr(parent_name,"Work Break Down - CN")!=NULL)
		{
		  if(strstr(CurrentTask,"Add Solution item")!=NULL)
		  {
			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
			 if(noAttachment > 0)
			{
			   for(t=0;t<noAttachment;t++)
			   {
				  AOM_ask_value_string(attachments[t],"object_type",&object_type);
				  printf("\n object_type is :%s\n",object_type);fflush(stdout);


				  if(strcmp(object_type,"ChangeNoticeRevision")==0)
				  {
					CALLAPI(AOM_ask_value_string(attachments[t],"current_id",&Dml_no));
					printf("\n Dml_no is :%s\n",Dml_no);	fflush(stdout);


				//	CALLAPI(ITEM_find_rev(Dml_no,"A", &item ));


					if(Dml_no)
					{
							printf("\n found part \n");fflush(stdout);
							CALLAPI(AOM_UIF_ask_value(attachments[t],"Analyst",&DmlAnalyst_name));
							printf("\n Analyst_name  of DML  is %s\n", DmlAnalyst_name);

					}
				  }

		      }

			 }
			}
	  }
		return ITK_ok;
}


int apl_dml_release( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside apl_dml_release***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_LcsAplRlzd");

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_dml_release \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_APLDMLRevision")==0)
	{
		    printf("\n inside class T5_APLDMLRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_cprojectcode", &Proj_Code);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
        				printf("\n Item created first time only with item_id \n");fflush(stdout);
                        if (DMLTag != NULLTAG)
						 {
							GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							 /// Solution Item start

							CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
							printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
							for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
							{
							TaskRevTag = TaskRevision[TaskCnt];

							CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
							printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
							if(strcmp(object_type,"T5_APLTaskRevision")==0)
							{
								PartCnt=0;

								CALLAPI(CR_create_release_status(lcsToset,&status2));
      							CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&TaskRevTag,retain));


								CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
								printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
								if (PartCnt>0)
								{
									GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
									for (k=0;k<PartCnt ;k++ )
									{
										printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
										AssyTag=PartTags[k];

										CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
										printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

										if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
										if(TCTYPE_ask_name2(objTypeTag,&type_name1));
										printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

										CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
										printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

										if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )
										{
								           CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));
											if((strcmp(ReleaseStatus,"T5_LcsAplRlzd")==0) )
											{
												CALLAPI(WSOM_ask_effectivity_mode(&stat));

												getCurrentDateTime(cCurrentAccessDate);
												CALLAPI(PROP_ask_property_by_name(status2,"effectivity_text",&propEff_tag));
												CALLAPI(PROP_ask_value_string(propEff_tag,&value));

												getNextDate(cNextDate);
												printf("\n cNextDate:%s",cNextDate);

												CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
												CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

												start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

												printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

												start_end_date[0] = test_date_1;
												start_end_date[1] = test_date_2;

												CALLAPI(WSOM_status_clear_effectivities (status2));
												CALLAPI(WSOM_effectivity_create_with_dates(status2, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
												CALLAPI(AOM_save(eff_d));
												CALLAPI(AOM_save(status2));
												CALLAPI(AOM_refresh(status2,0));
											}
										}
									}
								}
							}
						  }  /// Solution Item end
					 }

	}else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }

	return error_code;
}

int apl_dml_claim( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char getPlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside apl_dml_claim***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_LcsAplRlzd");

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_dml_claim \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_APLTaskRevision")==0 || strcmp(CurrentTask,"Work On DML")==0)
	{
		    printf("\n inside class T5_APLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_crdesigngroup", &Proj_Code);

			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n Item created first time only with item_id \n");fflush(stdout);
			if (DMLTag != NULLTAG)
			 {
					PartCnt=0;
					getPlantDetailsAttr(roleName,PlantCS,getPlantOptCS,PlantIA,PlantStore,UserAgency);
					printf("\n PlantCS %s \n",PlantCS);
					printf("\n getPlantOptCS %s \n",getPlantOptCS);
					printf("\n PlantAgency %s \n",PlantIA);
					printf("\n PlantStore %s \n",PlantStore);
					printf("\n UserAgency %s \n",UserAgency);

					CALLAPI(AOM_ask_value_tags(DMLTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
							printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

							CALLAPI(AOM_ask_value_string(AssyTag,"t5_Coated",&Part_Coated));
							printf("\n\n\t\t APL DML Cre:Part_Coated  is :%s",Part_Coated);	fflush(stdout);
							CALLAPI(AOM_ask_value_string(AssyTag,"t5_ColourInd",&Part_ColourInd));
							printf("\n\n\t\t APL DML Cre:Part_ColourInd  is :%s",Part_ColourInd);	fflush(stdout);
							CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&Part_Type));
							printf("\n\n\t\t APL DML Cre:Part_Type  is :%s",Part_Type);	fflush(stdout);

							if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name1));
							printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

							CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
							printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

							if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )
							{
								if((strcmp(Part_ColourInd,"C") ==0) || (strcmp(Part_Coated,"C")==0))
								{
								 printf("\n \t\t Colour part co continue No Update of CS  ");fflush(stdout);
								 continue;
								}
								if((strcmp(Part_Type,"V")==0))
								{
								 printf("\n\n\t\t APL DML Cre:Part_Type  is :%s",Part_Type);	fflush(stdout);
								CALLAPI(AOM_lock(AssyTag));
								 CALLAPI(AOM_set_value_string(AssyTag,PlantCS,"E50 (In-house production-Phantom Assembly)"));
								CALLAPI( AOM_save(AssyTag) );
								CALLAPI( AOM_unlock(AssyTag) );
								}else if(strcmp(Part_Type,"T")==0)
								{
								 printf("\n\n\t\t APL DML Cre:Part_Type  is :%s",Part_Type);	fflush(stdout);
								CALLAPI(AOM_lock(AssyTag));
								 CALLAPI(AOM_set_value_string(AssyTag,PlantCS,"E50 (In-house production-Phantom Assembly)"));
								 CALLAPI(AOM_set_value_string(AssyTag,"t5_EstSheetReqd","NA"));
								 CALLAPI(AOM_set_value_string(AssyTag,"t5_ToolIndentReqd","NA"));
								 CALLAPI(AOM_set_value_string(AssyTag,"t5_PFDModReqd","NA"));
								CALLAPI( AOM_save(AssyTag) );
								CALLAPI( AOM_unlock(AssyTag) );
								}else if(strcmp(Part_Type,"G")==0)
								{
								 printf("\n\n\t\t APL DML Cre:Part_Type  is :%s",Part_Type);	fflush(stdout);
								CALLAPI(AOM_lock(AssyTag));
								 CALLAPI(AOM_set_value_string(AssyTag,"t5_EstSheetReqd","NA"));
								 CALLAPI(AOM_set_value_string(AssyTag,"t5_ToolIndentReqd","NA"));
								 CALLAPI(AOM_set_value_string(AssyTag,"t5_PFDModReqd","NA"));
								CALLAPI( AOM_save(AssyTag) );
								CALLAPI( AOM_unlock(AssyTag) );
								}
								else if((strcmp(Part_Type,"VC")==0))
								{
								 printf("\n\n\t\t APL DML Cre:Part_Type  is :%s",Part_Type);	fflush(stdout);
								 CALLAPI(AOM_lock(AssyTag));
								 CALLAPI(AOM_set_value_string(AssyTag,PlantCS,"E99 (In-house production-Back Flush Items)"));
								CALLAPI( AOM_save(AssyTag) );
								CALLAPI( AOM_unlock(AssyTag) );
								}
							}
						}
					}
				}

	}if(strcmp(type_name,"T5_APLTaskRevision")==0 || strcmp(CurrentTask,"Please Review The Changes Done By APL Planner")==0)
	{
   /********************** Gss 2.49 For Generating 35-36 Parts at reviewer Claim of APL Reviewer *****************/
   /********************** This need to  be implemented if required now it is moved to ERC *****************/
	}
	else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }

	return error_code;
}


int apl_dml_create( EPM_action_message_t msg )
{
	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;
	int max_char_size = 80;
	char*			DMLAPL					=NULL;
	char*			Suffix					=NULL;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;

	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
    printf("\n **************inside apl_dml_create***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_dml_create \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		    printf("\n inside class ChangeRequestRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_cprojectcode", &Proj_Code);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);

			WSOM_clear_search_criteria(&criteria_control);
			strcpy(criteria_control.name,"PlantDML");
			strcpy(criteria_control.class_name,"T5_ControlObject");
			status	= WSOM_search(criteria_control, &control_number_found, &list_of_WSO_cntrl_tags);

			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			for(j=0;j<control_number_found;j++)
			{

			printf("\n j++++++++++++++++++[%d]\n",j);fflush(stdout);

			item_erc_id_dup = NULL;
			item_erc_id_dup =	(char *)MEM_alloc(max_char_size * sizeof(char));

			strcpy(item_erc_id_dup,item_id);
			AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo1", &PlantName);
	        printf("\n PlantName11: %s\n",PlantName);fflush(stdout);
			strcat (item_erc_id_dup,"_");
			strcat (item_erc_id_dup,PlantName);

			printf("\n item_erc_id_dup: %s\n",item_erc_id_dup);fflush(stdout);
			WSOM_clear_search_criteria(&criteria_erc);
			strcpy(criteria_erc.name,item_erc_id_dup);
			strcpy(criteria_erc.class_name,"T5_APLDMLRevision");
			status	= WSOM_search(criteria_erc, &apl_number_found, &list_of_WSO_erc_tags);

			printf("\n apl_number_found is000 :[%d]\n",apl_number_found);fflush(stdout);
        	     if(apl_number_found == 0)
				{
	    			printf("\n apl_number_found is111 : %d\n",apl_number_found);fflush(stdout);

					CALLAPI( TCTYPE_find_type( "T5_APLDML", NULL, &APLDTypeTag) );
					CALLAPI( TCTYPE_construct_create_input( APLDTypeTag, &APLDCreInTag) );

					CALLAPI( TCTYPE_find_type( "T5_APLDMLRevision", NULL, &APLDRevTypeTag) );
					CALLAPI( TCTYPE_construct_create_input( APLDRevTypeTag, &APLDRevCreInTag) );

					//Build the APL DML Input Structure

					tc_strcpy( stringArrayAPLD[0], item_erc_id_dup);
					//strncpy( stringArrayAPLD[0], item_erc_id_dup, l_strings );
					CALLAPI( TCTYPE_set_create_display_value( APLDCreInTag, "item_id", 1, (const char**)stringArrayAPLD) );
					tc_strcpy( stringArrayAPLD[0], "TEST APL DML Creation");
					CALLAPI( TCTYPE_set_create_display_value( APLDCreInTag, "object_name", 1, (const char**)stringArrayAPLD) );
					tc_strcpy( stringArrayAPLD[0], "APL DML is for APL DML testing!");
					CALLAPI( TCTYPE_set_create_display_value( APLDCreInTag, "object_desc", 1, (const char**)stringArrayAPLD) );

					CALLAPI( AOM_tag_to_string(APLDRevCreInTag, &tempString) );
					tc_strcpy( stringArrayAPLD[0], tempString);
					printf("\nTest0.D1..[%s]\n",stringArrayAPLD[0]);
					CALLAPI( TCTYPE_set_create_display_value( APLDCreInTag, "revision", 1,(const char**)stringArrayAPLD) );

					tc_strcpy( stringArrayAPLD[0], "A");
					CALLAPI( TCTYPE_set_create_display_value( APLDRevCreInTag, "item_revision_id", 1, (const char**)stringArrayAPLD) );

					printf("\nTest1..\n");
					CALLAPI( TCTYPE_create_object(APLDCreInTag, &APLDMLTag) );
					printf("\nTest2..\n");

			     	AOM_save(APLDMLTag);

					//CALLAPI( FL_user_update_newstuff_folder(APLDMLTag) );

					CALLAPI(ITEM_ask_latest_rev(APLDMLTag,&APLDMLRevTag));

					if (DMLTag != NULLTAG && APLDMLRevTag != NULLTAG)
					{
					GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
					GRM_create_relation(DMLTag, APLDMLRevTag, relation_type,  NULLTAG, &aplrelation);
					GRM_save_relation(aplrelation);
					printf("\n APL DML Created for ERC DML  : %s\n",item_erc_id_dup);fflush(stdout);
					//Update Project code on APL DML
					CALLAPI(AOM_lock(APLDMLRevTag));
					CALLAPI(AOM_set_value_string(APLDMLRevTag,"t5_cprojectcode",Proj_Code));
					CALLAPI( AOM_save(APLDMLRevTag) );
					CALLAPI( AOM_unlock(APLDMLRevTag) );
				  }

				for(i=0;i<num;i++)
				{
    				printf("\n item_erc_id_dup is : %s\n",item_erc_id_dup);fflush(stdout);
					strcpy(item_erc_id_dup1,item_erc_id_dup);

					 DMLAPL = strtok (item_erc_id_dup,"_");
					 Suffix = strtok (NULL,"_");

					item_erc_id_dup = NULL;
					item_erc_id_dup =	(char *)MEM_alloc(max_char_size * sizeof(char));
					strcpy(item_erc_id_dup,item_erc_id_dup1);

					printf("\n DMLAPL is : %s\n",DMLAPL);fflush(stdout);
					printf("\n Suffix is : %s\n",Suffix);fflush(stdout);

					strcpy(item_id_dup,DMLAPL);
					strcat (item_id_dup,"_");
					strcat (item_id_dup,DesignGroupList[i]);
					strcat (item_id_dup,"_");
					strcat(item_id_dup,Suffix);

					printf("\n item_id_dup AFTER CAT is by hanuman :%s\n",item_id_dup);fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,item_id_dup);
					strcpy(criteria.class_name,"T5_APLTaskRevision");
					status	= WSOM_search(criteria, &apl_task_number_found, &list_of_WSO_tags);

					//ITEM_find_items_by_key_attributes(1, "item_id", item_id_dup, &n_tags_found, &tags_found);
					printf("\n\n\t\t apl_task_number_found count in DB is : %d\n",apl_task_number_found);fflush(stdout);

        	          if(apl_task_number_found == 0)
					  {
						printf("\n item_id_dup :%s and Design_group :%s and DML_no :%s \n ",item_id_dup,DesignGroupList[i],DML_no);fflush(stdout);

						CALLAPI( TCTYPE_find_type( "T5_APLTask", NULL, &APLTTypeTag) );
						CALLAPI( TCTYPE_construct_create_input( APLTTypeTag, &APLTCreInTag) );

						CALLAPI( TCTYPE_find_type( "T5_APLTaskRevision", NULL, &APLTRevTypeTag) );
						CALLAPI( TCTYPE_construct_create_input( APLTRevTypeTag, &APLTRevCreInTag) );


						tc_strcpy( stringArrayAPLT[0], item_id_dup);
						CALLAPI( TCTYPE_set_create_display_value( APLTCreInTag, "item_id", 1,(const char**)stringArrayAPLT) );
						tc_strcpy( stringArrayAPLT[0], "TEST APL Task Creation");
						CALLAPI( TCTYPE_set_create_display_value( APLTCreInTag, "object_name", 1,(const char**)stringArrayAPLT) );

						CALLAPI( AOM_tag_to_string(APLTRevCreInTag, &tempStringt) );
						tc_strcpy( stringArrayAPLT[0], tempStringt);
						printf("\nTest0.4..[%s]\n",stringArrayAPLT[0]);
						CALLAPI( TCTYPE_set_create_display_value( APLTCreInTag, "revision", 1,(const char**) stringArrayAPLT) );
						tc_strcpy( stringArrayAPLT[0], "A");
						CALLAPI( TCTYPE_set_create_display_value( APLTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayAPLT) );
						tc_strcpy( stringArrayAPLT[0], DesignGroupList[i]);
						CALLAPI( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayAPLT) );
						tc_strcpy( stringArrayAPLT[0], Proj_Code);
						CALLAPI( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayAPLT) );

						CALLAPI( TCTYPE_create_object( APLTCreInTag, &APLTaskTag) );
						CALLAPI( AOM_save(APLTaskTag) );
						CALLAPI( AOM_unlock(APLTaskTag) );

						CALLAPI(ITEM_ask_latest_rev(APLTaskTag,&APLTaskRevTag));

        				printf("\n Item created first time only with item_id \n");fflush(stdout);
                        if (APLDMLRevTag != NULLTAG && APLTaskRevTag != NULLTAG)
						 {
							GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							GRM_create_relation(APLDMLRevTag, APLTaskRevTag, relation_type,  NULLTAG, &apltaskrelation);
							GRM_save_relation(apltaskrelation);
							printf("\n APL DML Created for ERC DML  : %s\n",item_erc_id_dup);fflush(stdout);
							if(AssignAPLPlanner(APLTaskRevTag));
							if(AssignAPLReviewer(APLTaskRevTag));

							 /// Solution Item start

							CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
							printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
							for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
							{
							TaskRevTag = TaskRevision[TaskCnt];
							CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
							printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
							if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
							{
								PartCnt=0;
								CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
								printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
								if (PartCnt>0)
								{
									GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
									for (k=0;k<PartCnt ;k++ )
									{
										printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
										AssyTag=PartTags[k];

										CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
										printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

										if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
										if(TCTYPE_ask_name2(objTypeTag,&type_name1));
										printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

										CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
										printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

										if (tc_strcmp(type_name1,"Design Revision")==0 &&  (AssyTag != NULLTAG && APLTaskRevTag != NULLTAG && tsk_part_sol_rel_type != NULLTAG))
										{

										    CALLAPI(GRM_find_relation(APLTaskRevTag, AssyTag, tsk_part_sol_rel_type ,&Fndrelation));
											if(Fndrelation)
											{
												printf("\n\t Relation Already Exist.\n" );fflush(stdout);
											}
											else
											{
											GRM_create_relation(APLTaskRevTag, AssyTag, tsk_part_sol_rel_type,  NULLTAG, &tsk_part_APL_rel);
											GRM_save_relation(tsk_part_APL_rel);
											}
											printf("\n\n\t\t APL DML Cre:Object_PartType is :%s\n",PartTypeStr);fflush(stdout);

										}
									}
								}
							}
						  }  /// Solution Item end

					 }
					 }else
					 {
						printf("\n item_id created twice......  \n");fflush(stdout);
					 }

			   }
 	       }
		}
	}else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }

	return error_code;
}

int AssignAPLPlanner(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	logical			flgRoleFnd			= false;

	printf("\n Inside AssignAPLPlanner \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignAPLPlanner:Task_no  is :%s",Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignAPLPlanner:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignAPLPlanner:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);


	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,Dsgn_No);
	tc_strcat(APL_Plnr_Grp,"_");
	tc_strcat(APL_Plnr_Grp,PLT_Code);
	tc_strcat(APL_Plnr_Grp,"_Planner");
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);
	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				if(tc_strcmp(rolename,"APLP Planner")==0 || tc_strcmp(rolename,"APLD Planner")==0)
				{
					printf("\nMatch Found\n");
					flgRoleFnd=true;
					break;
				}
		}

		if (flgRoleFnd==true)
		{
			CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
			printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
			if(num_of_members>0)
			{
				for (j=0;j<num_of_members ;j++  )
				{
					CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
					CALLAPI(SA_ask_user_identifier(user_tag,userid));
					printf("\nUser ID Name :[%s]\n",userid);
					TCTYPE_find_type("Analyst", "Analyst", &participant_type);
					EPM_create_participant(member_tags[j], participant_type, &participant_tag);
					GRM_find_relation_type("HasParticipant", &relation_type);
					GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
					GRM_save_relation(relation);
					printf("\n TestParticipent Assigned..DoneXXXX\n");
				}
			}else  //default group
			{
			APL_Plnr_Grp = NULL;
			group_tag = NULLTAG;
			num_of_roles = 0;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"Default");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_Code);
			tc_strcat(APL_Plnr_Grp,"_Planner");
			printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

			CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

			 if (group_tag != NULLTAG)
			CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
			printf("\nNo of Role found in Group are :%d\n",num_of_roles);
			flgRoleFnd=false;
			if(num_of_roles>0)
			{
				for (i=0;i<num_of_roles ;i++ )
				{
						CALLAPI(SA_ask_role_name(role_tags[i],rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);
						if(tc_strcmp(rolename,"APLP Default Planner")==0)
						{
							printf("\nMatch Found\n");
							flgRoleFnd=true;
							break;
						}
				}

				if (flgRoleFnd==true)
				{
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n TestParticipent Assigned..DoneXXXX\n");
						}
					}
				}
	        }
		}
		}
	}else //default group
	{
			APL_Plnr_Grp = NULL;
			group_tag = NULLTAG;
			num_of_roles = 0;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"Default");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_Code);
			tc_strcat(APL_Plnr_Grp,"_Planner");
			printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

			CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

			 if (group_tag != NULLTAG)
			CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
			printf("\nNo of Role found in Group are :%d\n",num_of_roles);
			flgRoleFnd=false;
			if(num_of_roles>0)
			{
				for (i=0;i<num_of_roles ;i++ )
				{
						CALLAPI(SA_ask_role_name(role_tags[i],rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);
						if(tc_strcmp(rolename,"APLP Default Planner")==0)
						{
							printf("\nMatch Found\n");
							flgRoleFnd=true;
							break;
						}
				}

				if (flgRoleFnd==true)
				{
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n TestParticipent Assigned..DoneXXXX\n");
						}
					}
				}
	        }
	}
	return ITK_ok;
}

int AssignAPLReviewer(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	logical			flgRoleFnd			= false;

	printf("\n Inside AssignAPLReviewer  \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Task_no  is :%s",Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);


	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,Dsgn_No);
	tc_strcat(APL_Plnr_Grp,"_");
	tc_strcat(APL_Plnr_Grp,PLT_Code);
	tc_strcat(APL_Plnr_Grp,"_Reviewer");
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);
	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				if(tc_strcmp(rolename,"APLP Reviewer")==0 || tc_strcmp(rolename,"APLD Reviewer")==0)
				{
					printf("\nMatch Found\n");
					flgRoleFnd=true;
					break;
				}
		}

		if (flgRoleFnd==true)
		{
			CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
			printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
			if(num_of_members>0)
			{
				for (j=0;j<num_of_members ;j++  )
				{
					CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
					CALLAPI(SA_ask_user_identifier(user_tag,userid));
					printf("\nUser ID Name :[%s]\n",userid);
					TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
					EPM_create_participant(member_tags[j], participant_type, &participant_tag);
					GRM_find_relation_type("HasParticipant", &relation_type);
					GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
					GRM_save_relation(relation);
					printf("\n TestParticipent Assigned..DoneXXXX\n");
				}
			}else
			{
					APL_Plnr_Grp = NULL;
					group_tag = NULLTAG;
					num_of_roles = 0;
					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
					tc_strcpy(APL_Plnr_Grp,"Default");
					tc_strcat(APL_Plnr_Grp,"_");
					tc_strcat(APL_Plnr_Grp,PLT_Code);
					tc_strcat(APL_Plnr_Grp,"_Reviewer");
					printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

					CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

					 if (group_tag != NULLTAG)
					CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
					printf("\nNo of Role found in Group are :%d\n",num_of_roles);
					flgRoleFnd=false;
					if(num_of_roles>0)
					{
						for (i=0;i<num_of_roles ;i++ )
						{
								CALLAPI(SA_ask_role_name(role_tags[i],rolename));
								printf("\nRol Name :[%d][%s]\n",i,rolename);
								if(tc_strcmp(rolename,"APLP Default Reviewer")==0)
								{
									printf("\nMatch Found\n");
									flgRoleFnd=true;
									break;
								}
						}

						if (flgRoleFnd==true)
						{
							CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
							if(num_of_members>0)
							{
								for (j=0;j<num_of_members ;j++  )
								{
									CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
									CALLAPI(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);
									TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
									EPM_create_participant(member_tags[j], participant_type, &participant_tag);
									GRM_find_relation_type("HasParticipant", &relation_type);
									GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
									GRM_save_relation(relation);
									printf("\n TestParticipent Assigned..DoneXXXX\n");
								}
							}
					}
			  }
			}
		}
	}else
	{
			APL_Plnr_Grp = NULL;
			group_tag = NULLTAG;
			num_of_roles = 0;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"Default");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_Code);
			tc_strcat(APL_Plnr_Grp,"_Reviewer");
			printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

			CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

			 if (group_tag != NULLTAG)
			CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
			printf("\nNo of Role found in Group are :%d\n",num_of_roles);
			flgRoleFnd=false;
			if(num_of_roles>0)
			{
				for (i=0;i<num_of_roles ;i++ )
				{
						CALLAPI(SA_ask_role_name(role_tags[i],rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);
						if(tc_strcmp(rolename,"APLP Default Reviewer")==0)
						{
							printf("\nMatch Found\n");
							flgRoleFnd=true;
							break;
						}
				}

				if (flgRoleFnd==true)
				{
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n TestParticipent Assigned..DoneXXXX\n");
						}
					}
	        }
	  }
	}
	return ITK_ok;

	//printf("\n Inside AssignAPLReviewer \n");

	///return 0;
}


int apl_dml_map( EPM_action_message_t msg )
{
	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;
	int max_char_size = 80;
	char*			DMLAPL					=NULL;
	char*			Suffix					=NULL;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;

	int n_tags_found = 0;
	int cnt = 0;
	tag_t			*attachments			=NULLTAG;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;
	int	  noAttachment1 = 0;
	tag_t *attachments1		=NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	char *project_ids		=NULL;
	tag_t team_tag			=NULLTAG;
	tag_t project			= NULLTAG;
	tag_t *mem = NULLTAG;
	int  k =0,z=0,num1=0;
	tag_t group_tag			=NULLTAG;
	tag_t role_tag			=NULLTAG;
	tag_t usertag			=NULLTAG;
	char group_name[SA_name_size_c+1];
	char role_name[SA_name_size_c+1];
	char *user_name=NULL;
	int is_Tertiary = 0;
	tag_t *Dml_tasks= NULLTAG;
    char*			object_type				=NULL;
	tag_t		   Analystusertag			= NULLTAG;
	int					num_of_members			= 0;
	tag_t*				member_tags				= NULLTAG;
	char				userid[SA_user_size_c+1];
	logical  	  is_deactivated ;
	//char *item_id_dup 	   = NULL;
	int * number_found;
	int  apl_number_found;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t  	group_tag_def_pl =NULLTAG;
	tag_t  	role_tag_def_pl =NULLTAG;
	tag_t  	group_tag_def_re =NULLTAG;
	tag_t  	role_tag_def_re =NULLTAG;
	int			num_of_members_dba	=0;
	tag_t				user_tag				= NULLTAG;
	tag_t				participant_type		= NULLTAG;
	tag_t				participant_tag			= NULLTAG;

	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	char   Group_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;

	char * check_group =(char *) MEM_alloc (sizeof (char) * 128);
	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
    printf("\n **************inside apl_dml_map***************\n ");fflush(stdout);

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_dml_map \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
       printf("  type_name:%s\n",type_name);fflush(stdout);
   }

	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		    printf("\n inside class ChangeRequestRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);

			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);

			strcpy(item_erc_id_dup,item_id);
			strcat (item_erc_id_dup,"_APLP");

			printf("\n item_erc_id_dup: %s\n",item_erc_id_dup);fflush(stdout);
			WSOM_clear_search_criteria(&criteria_erc);
			strcpy(criteria_erc.name,item_erc_id_dup);
			strcpy(criteria_erc.class_name,"T5_APLDMLRevision");
			status	= WSOM_search(criteria_erc, &apl_number_found, &list_of_WSO_erc_tags);

			 printf("\n noAttachment1: %d\n",noAttachment1);fflush(stdout);

			if(apl_number_found > 0)
		     {
     				if(AOM_ask_value_string(DMLTag,"project_list",&project_ids));
					if(PROJ_find(project_ids,&project));
					printf("\n     project_ids changes done: for workspaceobject     %s\n", project_ids);fflush(stdout);
					if(AOM_ask_value_tag(project,"project_team",&team_tag));

					if(team_tag != NULLTAG)
					{
						if(AOM_ask_value_tags(team_tag,"project_members",&num1,&mem));
						printf("\n  num1--->[ %d]\n", num1);fflush(stdout);

						for(z=0;z<num1;z++)
						{
							 member_tags  =  NULLTAG;
							 user_tag  =  NULLTAG;
							 participant_tag  =  NULLTAG;
							 relation  =  NULLTAG;

							if(AOM_ask_value_tag(mem[z],"the_group",&group_tag));
							 if(SA_ask_group_name(group_tag,group_name));
							 if(AOM_ask_value_tag(mem[z],"the_role",&role_tag));
							 if(SA_ask_role_name(role_tag,role_name));
							 if(AOM_ask_value_tag(mem[z],"the_user",&usertag));
							 if(AOM_ask_value_string(usertag,"user_name",&user_name));
							printf("\n     group_name--->[ %s]\n", group_name);fflush(stdout);
     						printf("\n     role_name--->[ %s]\n", role_name);fflush(stdout);
     						printf("\n     user_name--->[ %s]\n", user_name);fflush(stdout);

							if(strstr(role_name,"Planner"))
							{
							if(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
							printf("\n num_of_members :%d\n",num_of_members);
							if(num_of_members == 0)
							{
								if(SA_find_group	("APL_Default_Planner",	&group_tag_def_pl));
								if(SA_find_role	("APL Default Planner",	&role_tag_def_pl));
								if(SA_find_groupmember_by_role(role_tag_def_pl,group_tag_def_pl,&num_of_members,&member_tags));
       							printf("\n num_of_members11 :%d\n",num_of_members);
								if(SA_ask_groupmember_user(member_tags[0],&user_tag));
								if(SA_ask_user_identifier(user_tag,userid));
								printf("\nUser ID Name :[%s]\n",userid);

     							if(TCTYPE_find_type("Analyst", "Analyst", &participant_type));
								if(EPM_create_participant(member_tags[0], participant_type, &participant_tag));
								if(GRM_find_relation_type("HasParticipant", &relation_type));
								if(GRM_create_relation(list_of_WSO_erc_tags[0], participant_tag, relation_type,  NULLTAG, &relation));
								if(GRM_save_relation(relation));
							}
							else if(num_of_members>0)
							{
								 if(SA_ask_groupmember_user(member_tags[0],&user_tag));
								if(SA_ask_user_identifier(user_tag,userid));
								printf("\nUser ID Name :[%s]\n",userid);
								if(SA_ask_groupmember_inactive(member_tags[0],&is_deactivated));
								if(is_deactivated == true)
								{
								if(SA_find_group	("APL_Default_Planner",	&group_tag_def_pl));
								if(SA_find_role	("APL Default Planner",	&role_tag_def_pl));
								if(SA_find_groupmember_by_role(role_tag_def_pl,group_tag_def_pl,&num_of_members,&member_tags));
       							printf("\n num_of_members11 :%d\n",num_of_members);
								if(SA_ask_groupmember_user(member_tags[0],&user_tag));
								if(SA_ask_user_identifier(user_tag,userid));
								printf("\nUser ID Name :[%s]\n",userid);

     							if(TCTYPE_find_type("Analyst", "Analyst", &participant_type));
								if(EPM_create_participant(member_tags[0], participant_type, &participant_tag));
								if(GRM_find_relation_type("HasParticipant", &relation_type));
								if(GRM_create_relation(list_of_WSO_erc_tags[0], participant_tag, relation_type,  NULLTAG, &relation));
								if(GRM_save_relation(relation));
								}else
								{
								if(TCTYPE_find_type("Analyst", "Analyst", &participant_type));
								if(EPM_create_participant(member_tags[0], participant_type, &participant_tag));
								if(GRM_find_relation_type("HasParticipant", &relation_type));
								if(GRM_create_relation(list_of_WSO_erc_tags[0], participant_tag, relation_type,  NULLTAG, &relation));
								if(GRM_save_relation(relation));
								}
								printf("\nTestParticipent Assigned..DoneXXXX\n");
							}
							}else if(strstr(role_name,"Reviewer"))
							{
								if(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
       							printf("\n num_of_members :%d\n",num_of_members);
								if(num_of_members == 0)
								{
									if(SA_find_group	("APL_Default_Reviewer",	&group_tag_def_re));
									if(SA_find_role	("APL Default Reviewer",	&role_tag_def_re));
									if(SA_find_groupmember_by_role(role_tag_def_re,group_tag_def_re,&num_of_members,&member_tags));
									printf("\n num_of_members11 :%d\n",num_of_members);
									if(SA_ask_groupmember_user(member_tags[0],&user_tag));
									if(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);
									if(TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type));
									if(EPM_create_participant(member_tags[0], participant_type, &participant_tag));
									if(GRM_find_relation_type("HasParticipant", &relation_type));
									if(GRM_create_relation(list_of_WSO_erc_tags[0], participant_tag, relation_type,  NULLTAG, &relation));
									if(GRM_save_relation(relation));
								}
								else if(num_of_members>0)
								{
								if(SA_ask_groupmember_user(member_tags[0],&user_tag));
								if(SA_ask_user_identifier(user_tag,userid));
								printf("\nUser ID Name :[%s]\n",userid);
								if(SA_ask_groupmember_inactive(member_tags[0],&is_deactivated));
									if(is_deactivated == true)
									{
									if(SA_find_group	("APL_Default_Reviewer",	&group_tag_def_re));
									if(SA_find_role	("APL Default Reviewer",	&role_tag_def_re));
									if(SA_find_groupmember_by_role(role_tag_def_re,group_tag_def_re,&num_of_members,&member_tags));
									printf("\n num_of_members11 :%d\n",num_of_members);
									if(SA_ask_groupmember_user(member_tags[0],&user_tag));
									if(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);

									if(TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type));
									if(EPM_create_participant(member_tags[0], participant_type, &participant_tag));
									if(GRM_find_relation_type("HasParticipant", &relation_type));
									if(GRM_create_relation(list_of_WSO_erc_tags[0], participant_tag, relation_type,  NULLTAG, &relation));
									if(GRM_save_relation(relation));
									}
									else
									{
									if(TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type));
									if(EPM_create_participant(member_tags[0], participant_type, &participant_tag));
									if(GRM_find_relation_type("HasParticipant", &relation_type));
									if(GRM_create_relation(list_of_WSO_erc_tags[0], participant_tag, relation_type,  NULLTAG, &relation));
									if(GRM_save_relation(relation));
									}
								}
								printf("\nTestParticipent Assigned..DoneXXXX\n");
							}
							else
							{
								printf("\n No Assignment \n");
							}
						}
					}
		       }
			  else
	        	{
	     	         printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
			     }
	}else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }
	return error_code;
}

extern EPM_decision_t DLLAPI apl_child_part_rlz_check_Func(EPM_rule_message_t msg)
{

	int status;
	EPM_decision_t decision;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int cnt = 0;
	int cntFlag = 0;
	char*	itemid;
	char *  ChildRelErr = NULL;
	char *  SetChildRelErr = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	itemclassp							= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;

   	printf("\n Calling apl_child_part_rlz_check_Func %d.....\n",iNumAttch);


	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_child_part_rlz_check_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );


     if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
 	ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;
		 tag_t	*itemclass							= NULLTAG;
		  tag_t item = NULLTAG;

		ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		printf("\n itemid %s \n",itemid);
		ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
		ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
		printf("\t  type_name ...%s\n", type_name);
		if( objTypeTag == ItemTypeTag )
		{
			printf("\t \n objTypeTag == ItemTypeTag \n");

			ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
			ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

			printf("\t  type_itemRev ...%s\n", type_itemRev);
			if (!SetChildRelErr) MEM_free(SetChildRelErr);
			SetChildRelErr=(char *)MEM_alloc(1000);

			if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
			{

    		ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
			printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
			if (PartCnt>0)
			{
				GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
				for (k=0;k<PartCnt ;k++ )
				{
				const char *qry_entries[1];
				const char *qry_values[1];

				int n_tags_found1=0;
				 tag_t	*itemclass1							= NULLTAG;

				printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
				AssyTag=PartTags[k];

				ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
				printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);
				qry_entries[0] ="item_id";
				qry_values[0] =  Part_no;

				ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found1, &itemclass1);
				 itemclassp = itemclass1[0];

				cnt = 0;
				BOM_create_window(&window);
				BOM_set_window_top_line(window,itemclassp,null_tag,null_tag,&top_line);
				BOM_line_ask_all_child_lines(top_line,&n,&children);
				printf("\n\n\t no:of action taken are -->%d",n);
				BOM_line_look_up_attribute 	("bl_revision",&attribute_act_tak);

				printf("\n\n\t Inside if of count_act_tak ");
				for ( j = 0; j < n; j++)
				{
					const char *qry_entries[1];
					const char *qry_values[1];
					int n_tags_found2=0;
					tag_t	*itemclass2							= NULLTAG;

					BOM_line_ask_attribute_tag 	(children[j],attribute_act_tak,&value_act_Tak);
					AOM_UIF_ask_value(value_act_Tak,"item_id",&Item_id);
					printf("\n\n\t Child Part String is Item_id-->%s",Item_id);
					qry_entries[0] ="item_id";
					qry_values[0] = Item_id;

					ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found2, &itemclass2);
					 itemcldclass = itemclass2[0];

					AOM_UIF_ask_value(value_act_Tak,"item_revision_id",&Item_rev);
					printf("\n\n\t Child Part String is Item_rev--->%s",Item_rev);

					ITKCALL(ITEM_ask_latest_rev(itemcldclass,&item_rev_cld_tag));
					//AOM_UIF_ask_value(value_act_Tak,"release_status_list",&Item_LCS);
					//printf("\n\n\t Action Taken String is Item_LCS--->%s",Item_LCS);
                 	ITKCALL(WSOM_ask_release_status_list(item_rev_cld_tag,&st_count,&status_list));
//					BOM_line_look_up_attribute ("bl_item_release_status_list",&Item_LCS);
//					BOM_line_ask_attribute_string(children[j], Item_LCS, &Item_Lcs_str);
					printf("\n st_count:%d \n",st_count);
					if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
					ChildRelErr=(char *)MEM_alloc(100);
                    tc_strcpy(ChildRelErr," ");
					if (st_count == 0)  /* No Status, so the Item is not yet Released */
					{
						printf("\n No Status, so the Item is not yet Released \n");

					}else
						{
								cntLcs	=	0;
								for (iLCS=0;iLCS<st_count ;iLCS++ )
								{
									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);
									if(tc_strcmp(class_name,"T5_LcsAplRlzd")==0)
									{
										cntLcs++;
										break;
									}
								}
								printf("\n cntLcs: %d\n",cntLcs);fflush(stdout);
								if (cntLcs<=0)
								{
									if(cnt==0)
									{
										cnt = 1;
										tc_strcat(ChildRelErr,"Child Part ");
										tc_strcat(ChildRelErr,Item_id);
										tc_strcat(ChildRelErr,",");
										tc_strcat(ChildRelErr,Item_rev);
										tc_strcat(ChildRelErr,"  Of Parent Part ");
										tc_strcat(ChildRelErr,Part_no);
										tc_strcat(ChildRelErr," is not APL Released.\n");
								         printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
									}
									else
									{
										tc_strcat(ChildRelErr,"Child Part ");
										tc_strcat(ChildRelErr,Item_id);
										tc_strcat(ChildRelErr,",");
										tc_strcat(ChildRelErr,Item_rev);
										tc_strcat(ChildRelErr,"  Of Parent Part ");
										tc_strcat(ChildRelErr,Part_no);
										tc_strcat(ChildRelErr," is not APL Released.\n");
										cnt = cnt+1;
    							         printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);

									}
								}
								if(cnt==1)
								{
									tc_strcpy(SetChildRelErr,ChildRelErr);
									cntFlag = 1;
								}
								else
								{
									tc_strcat(SetChildRelErr,ChildRelErr);
									cntFlag = 1;
								}
						 }
			    	}
				}
			}



		   printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
			//if (tc_strcmp(SetChildRelErr,"NULL")!=0)
			if(cntFlag==1)
			{
				printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetChildRelErr);
				//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
				//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
				decision = EPM_nogo;
				return ITK_errStore;
			}

	  }
    }
  }
 }
	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI apl_part_prev_rev_rlz_check_Func(EPM_rule_message_t msg)
{
	int status=0;
	EPM_decision_t decision;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int   attribute_act_tak;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	int				PartCnt				= 0;
	tag_t			AssyTag				= NULLTAG;
	tag_t			AssyPreTag				= NULLTAG;
	int       st_count=0;
	tag_t*    status_list;
	char *  ChildRelErr = NULL;
	char *  SetChildRelErr = NULL;
	char* class_name=NULL;

	int iItm = 0;
	int j = 0;
	int i = 0;
	int n = 0;
	int cnt = 0;
	int cntFlag = 0;
	char*	itemid;
	char*	itemidpre;
	char*	itemidprerev;
	char *  PrevRelErr;
	char *  SetPrevRelErr;
	char*	PrevPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	char  type_itemRev[TCTYPE_name_size_c+1];
	char  PrevRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Prevtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	itemclass							= NULLTAG;
	tag_t	value_prev_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *prevRev;
	tag_t  *totalPrev;
	tag_t  	value_act_Tak;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			PartPreTags			= NULLTAG;
	tag_t	relation_type = NULLTAG;

		printf("\n Calling apl_part_prev_rev_rlz_check_Func.....\n");

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_part_prev_rev_rlz_check_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );


     if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
		ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

		printf("\n iNumAttch %d.....\n",iNumAttch);
		for (i=0; i < iNumAttch; i++)
		{
			tag_t objTypeTag = NULLTAG;
			tag_t objChildRevTag = NULLTAG;
			const char *qry_entries[1];
			const char *qry_values[1];
			int n_tags_found=0;
	         tag_t	*itemclass							= NULLTAG;
	          tag_t item = NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n itemid %s.....\n",itemid);
            qry_entries[0] ="item_id";
            qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			 item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

			printf("\n itemid %s \n",itemid);
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
			printf("\t  type_name ...%s\n", type_name);
			if( objTypeTag == ItemTypeTag )
			{
				printf("\t \n objTypeTag == ItemTypeTag \n");

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
				ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

				printf("\t  type_itemRev ...%s\n", type_itemRev);
				if (!SetChildRelErr) MEM_free(SetChildRelErr);
				SetChildRelErr=(char *)MEM_alloc(1000);


				if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
				{

				ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
				if (PartCnt>0)
				{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];
							GRM_find_relation_type("IMAN_based_on",&relation_type);
							GRM_list_secondary_objects_only(AssyTag,relation_type,&count,&PartPreTags);
							printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
							if(count >0)
							{
							AssyPreTag=PartPreTags[0];
							ITKCALL(AOM_ask_value_string(AssyPreTag, "item_id",&itemidpre));
							printf("\n itemidpre %s.....\n",itemidpre);
							ITKCALL(AOM_ask_value_string(AssyPreTag, "item_revision_id",&itemidprerev));
    						printf("\n itemidprerev %s.....\n",itemidprerev);

							ITKCALL(WSOM_ask_release_status_list(AssyPreTag,&st_count,&status_list));
							if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
							ChildRelErr=(char *)MEM_alloc(100);
							tc_strcpy(ChildRelErr," ");
							if (st_count == 0)  /* No Status, so the Item is not yet Released */
							{
								printf("\n No Status, so the Item is not yet Released \n");

							}else
								{
										ITKCALL(AOM_ask_value_string(status_list[0],"object_name",&class_name));
										printf("\n class_name: %s\n",class_name);fflush(stdout);
										if(tc_strcmp(class_name,"T5_LcsAplRlzd")!=0)
										{
											if(cnt==0)
											{
												cnt = 1;
												tc_strcat(ChildRelErr,"Previous Revision Part ");
												tc_strcat(ChildRelErr,itemidpre);
												tc_strcat(ChildRelErr,",");
												tc_strcat(ChildRelErr,itemidprerev);
												tc_strcat(ChildRelErr," is not APL Released.\n");
												 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
											}
											else
											{
												tc_strcat(ChildRelErr,"Previous Revision Part ");
												tc_strcat(ChildRelErr,itemidpre);
												tc_strcat(ChildRelErr,",");
												tc_strcat(ChildRelErr,itemidprerev);
												tc_strcat(ChildRelErr," is not APL Released.\n");
												 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
												cnt = cnt+1;
												 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);
											}
										}
										if(cnt==1)
										{
											tc_strcpy(SetChildRelErr,ChildRelErr);
											cntFlag = 1;
										}
										else
										{
											tc_strcat(SetChildRelErr,ChildRelErr);
											cntFlag = 1;
										}
								 }
							}
						}

						   printf("\n SetPrevRelErr: %s\n",SetChildRelErr);fflush(stdout);
							//if (tc_strcmp(SetChildRelErr,"NULL")!=0)
							if(cntFlag==1)
							{
								printf("\n All Previous Part is not TCM Released  %s \n",SetChildRelErr);
								EMH_clear_errors();
			                	status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetChildRelErr);
								//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
								//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
								decision = EPM_nogo;
								return ITK_errStore;
						}
					}
				}
			}
	}
	}

	decision = EPM_go;
	return decision;
 }

extern EPM_decision_t DLLAPI apl_erc_dml_check_Func(EPM_rule_message_t msg)
{
	int status=0;
	EPM_decision_t decision;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int   attribute_act_tak;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	int				PartCnt				= 0;
	tag_t			AssyTag				= NULLTAG;
	tag_t			PartDmlTag				= NULLTAG;
	int       st_count=0;
	tag_t*    status_list;
	char *  ChildRelErr = NULL;
	char *  SetChildRelErr = NULL;
	char* class_name=NULL;

	int iItm = 0;
	int j = 0;
	int i = 0;
	int n = 0;
	int dml = 0;
	int cnt = 0;
	int cntFlag = 0;
	char*	itemid;
	char*	DmlId;
	char*	itemidpre;
	char*	itemidprerev;
	char *  PrevRelErr;
	char *  SetPrevRelErr;
	char*	PrevPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	char  type_itemRev[TCTYPE_name_size_c+1];
	char  type_class[TCTYPE_name_size_c+1];
	char  PrevRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Prevtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	itemTypeTag_class							= NULLTAG;
	tag_t	value_prev_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *prevRev;
	tag_t  *totalPrev;
	tag_t  	value_act_Tak;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			PartDmlTags			= NULLTAG;
	tag_t	relation_type = NULLTAG;

		printf("\n Calling apl_erc_dml_check_Func.....\n");

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_erc_dml_check_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );


     if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
		ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

		printf("\n iNumAttch %d.....\n",iNumAttch);
		for (i=0; i < iNumAttch; i++)
		{
			tag_t objTypeTag = NULLTAG;
			tag_t objChildRevTag = NULLTAG;
			const char *qry_entries[1];
			const char *qry_values[1];
			int n_tags_found=0;
	         tag_t	*itemclass							= NULLTAG;
	          tag_t item = NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n itemid %s.....\n",itemid);
            qry_entries[0] ="item_id";
            qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			 item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

			printf("\n itemid %s \n",itemid);
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
			printf("\t  type_name ...%s\n", type_name);
			if( objTypeTag == ItemTypeTag )
			{
				printf("\t \n objTypeTag == ItemTypeTag \n");

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
				ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

				printf("\t  type_itemRev ...%s\n", type_itemRev);
				if (!SetChildRelErr) MEM_free(SetChildRelErr);
				SetChildRelErr=(char *)MEM_alloc(1000);


				if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
				{

				ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
				if (PartCnt>0)
				{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];
							GRM_find_relation_type("CMHasSolutionItem",&relation_type);
							GRM_list_primary_objects_only(AssyTag,relation_type,&count,&PartDmlTags);
							//GRM_list_all_related_objects_only(AssyTag,&count,&PartDmlTags);
							printf("\n\n\t\t Part to ERC DML to Task : %d",count);fflush(stdout);
							if(count >0)
							{
						   for (dml=0;dml<count ;dml++ )
						   {
							PartDmlTag=PartDmlTags[dml];
							ITKCALL (TCTYPE_ask_object_type(PartDmlTag,&itemTypeTag_class));
							ITKCALL (TCTYPE_ask_name(itemTypeTag_class,type_class));

							printf("\t  type_itemRev ...%s\n", type_class);
							if(tc_strcmp(type_class,"T5_APLTaskRevision")!=0)
								continue;

						ITKCALL(AOM_ask_value_string(PartDmlTag, "item_id",&DmlId));
						printf("\n DmlId %s.....\n",DmlId);

							if(strstr(DmlId,"AM"))
								continue;

							ITKCALL(WSOM_ask_release_status_list(PartDmlTag,&st_count,&status_list));
							if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
							ChildRelErr=(char *)MEM_alloc(100);
							tc_strcpy(ChildRelErr," ");
							if (st_count == 0)  /* No Status, so the Item is not yet Released */
							{
								printf("\n No Status, so the Item is not yet Released \n");

							}else
								{
										ITKCALL(AOM_ask_value_string(status_list[0],"object_name",&class_name));
										printf("\n class_name: %s\n",class_name);fflush(stdout);
										if(tc_strcmp(class_name,"T5_LcsAplRlzd")!=0)
										{
											if(cnt==0)
											{
												cnt = 1;
												tc_strcat(ChildRelErr,"PP/PM Series DML  ");
												tc_strcat(ChildRelErr,DmlId);
												tc_strcat(ChildRelErr,",");
												tc_strcat(ChildRelErr,"A");
												tc_strcat(ChildRelErr," is not APL Released.");
												tc_strcat(ChildRelErr,"Please Release the PP/PM Series DML First and try respective DML \n");
												 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
											}
											else
											{
												tc_strcat(ChildRelErr,"PP/PM Series DML ");
												tc_strcat(ChildRelErr,DmlId);
												tc_strcat(ChildRelErr,",");
												tc_strcat(ChildRelErr,"A");
												tc_strcat(ChildRelErr," is not APL Released.");
												tc_strcat(ChildRelErr,"Please Release the PP/PM Series DML First and try respective DML \n");
												 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
												cnt = cnt+1;
												 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);
											}
										}
										if(cnt==1)
										{
											tc_strcpy(SetChildRelErr,ChildRelErr);
											cntFlag = 1;
										}
										else if(cnt>1)
										{
											tc_strcat(SetChildRelErr,ChildRelErr);
											cntFlag = 1;
										}
								 }
							}
						  }
						}

						   printf("\n SetDMLRelErr: %s\n",SetChildRelErr);fflush(stdout);
							//if (tc_strcmp(SetChildRelErr,"NULL")!=0)
							if(cntFlag==1)
							{
              					printf("\n PP DML is not TCM Released  %s \n",SetChildRelErr);
								EMH_clear_errors();
			                	status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetChildRelErr);
								//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
								//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
								decision = EPM_nogo;
								return ITK_errStore;
					    	}
					}
				}
			}
	}
	}

	decision = EPM_go;
	return decision;
 }

extern EPM_decision_t DLLAPI Hanging_Part_check_Func(EPM_rule_message_t msg)
{
	int status=0;
	EPM_decision_t decision;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int   attribute_act_tak;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	int				PartCnt				= 0;
	tag_t			AssyTag				= NULLTAG;
	tag_t			PartDmlTag				= NULLTAG;
	int       st_count=0;
	tag_t*    status_list;
	char *  HangingPrtErr = NULL;
	char *  SetHangingPrtErr = NULL;
	char* class_name=NULL;

	int iItm = 0;
	int j = 0;
	int i = 0;
	int n = 0;
	int dml = 0;
	int cnt = 0;
	int cntFlag = 0;
	int  	n_parents=0;
	int * 	levels;
	tag_t * 	parents	 =NULLTAG;
	char*	itemid;
	char*	DmlId;
	char*	itemidpre;
	char*	itemidprerev;
	char *  PrevRelErr;
	char *  SetPrevRelErr;
	char*	PrevPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	char  type_itemRev[TCTYPE_name_size_c+1];
	char  type_class[TCTYPE_name_size_c+1];
	char  PrevRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Prevtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	itemTypeTag_class							= NULLTAG;
	tag_t	value_prev_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *prevRev;
	tag_t  *totalPrev;
	tag_t  	value_act_Tak;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			PartDmlTags			= NULLTAG;
	tag_t	relation_type = NULLTAG;

		printf("\n Calling Hanging_Part_check_Func.....\n");

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n Hanging_Part_check_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );


     if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
		ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

		printf("\n iNumAttch %d.....\n",iNumAttch);
		for (i=0; i < iNumAttch; i++)
		{
			tag_t objTypeTag = NULLTAG;
			tag_t objChildRevTag = NULLTAG;
			const char *qry_entries[1];
			const char *qry_values[1];
			int n_tags_found=0;
	         tag_t	*itemclass							= NULLTAG;
	          tag_t item = NULLTAG;
			 char * ItemName1 ;
			 char * ItemRev ;
			 char * ItemPType ;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n itemid %s.....\n",itemid);
            qry_entries[0] ="item_id";
            qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			 item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

			printf("\n itemid %s \n",itemid);
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
			printf("\t  type_name ...%s\n", type_name);
			if( objTypeTag == ItemTypeTag )
			{
				printf("\t \n objTypeTag == ItemTypeTag \n");

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
				ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

				printf("\t  type_itemRev ...%s\n", type_itemRev);
				if (!SetHangingPrtErr) MEM_free(SetHangingPrtErr);
				SetHangingPrtErr=(char *)MEM_alloc(10000);


				if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
				{

				ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
				if (PartCnt>0)
				{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							ItemName1 = NULL;
							ItemRev = NULL;
							ItemPType = NULL;
							AssyTag=PartTags[k];

							// Other check related colour,std part,ECU part will be added as per colour module introduction at ERC
							ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&ItemPType));
     						printf("\n child ItemPType:%s ..............",ItemPType);fflush(stdout);
                            if(tc_strcmp(ItemPType,"V" )==0 || tc_strcmp(ItemPType,"VC" )==0 ||  tc_strcmp(ItemPType,"VCCR" )==0 ||tc_strcmp(ItemPType,"T" )==0 || tc_strcmp(ItemPType,"M" )==0  || tc_strcmp(ItemPType,"D" )==0|| tc_strcmp(ItemPType,"SA" )==0 ||  tc_strcmp(ItemPType,"SP" )==0 ||  tc_strcmp(ItemPType,"G" )==0)
							{
     						printf("\n Part Type is V/VC/VCCR/T/M/D/SP/SA/G[[%s]]--->So continue No hanging part check..............",ItemPType);fflush(stdout);
							continue;
							}
    						ITKCALL(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
							printf("\n\n\t\t No of Assy objects are n_parents : %d\n",n_parents);fflush(stdout);
							//GRM_list_all_related_objects_only(AssyTag,&count,&PartDmlTags);
							ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&ItemName1));
     						printf("\n child ItemName1:%s ..............",ItemName1);fflush(stdout);
							ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&ItemRev));
     						printf("\n child ItemRev:%s ..............",ItemRev);fflush(stdout);

							if (tc_strcmp(HangingPrtErr,"NULL") !=0) MEM_free(HangingPrtErr);
							HangingPrtErr=(char *)MEM_alloc(500);
							tc_strcpy(HangingPrtErr," ");


							printf("\n\n\t\t Part to ERC DML to Task : %d",n_parents);fflush(stdout);
							if(n_parents<=0)
							{
									if(cnt==0)
									{
										cnt = 1;
										tc_strcat(HangingPrtErr,"PartNumber[");
										tc_strcat(HangingPrtErr,ItemName1);
										tc_strcat(HangingPrtErr,",");
										tc_strcat(HangingPrtErr,ItemRev);
										tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
										 printf("\n ChildRelErr10: %s\n",HangingPrtErr);fflush(stdout);
									}
									else
									{
										tc_strcat(HangingPrtErr,"PartNumber[");
										tc_strcat(HangingPrtErr,ItemName1);
										tc_strcat(HangingPrtErr,",");
										tc_strcat(HangingPrtErr,ItemRev);
										tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
										 printf("\n ChildRelErr11: %s\n",HangingPrtErr);fflush(stdout);
										cnt = cnt+1;
										 printf("\n ChildRelEr22r: %s\n",HangingPrtErr);fflush(stdout);
									}
								if(cnt==1)
								{
									tc_strcpy(SetHangingPrtErr,HangingPrtErr);
									cntFlag = 1;
								}
								else if(cnt>1)
								{
									tc_strcat(SetHangingPrtErr,HangingPrtErr);
									cntFlag = 1;
								}
							}
						}

					   printf("\n SetHangingPrtErr: %s\n",SetHangingPrtErr);fflush(stdout);
					   printf("\n cntFlag: %d\n",cntFlag);fflush(stdout);
						//if (tc_strcmp(SetChildRelErr,"NULL")!=0)
						if(cntFlag==1)
						{
							printf("\n Haging parts so giving error  %s \n",SetHangingPrtErr);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetHangingPrtErr);
							//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
							//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
							decision = EPM_nogo;
							return ITK_errStore;
						}else
						{
						 decision = EPM_go;
						 printf("\n decision: %s\n",decision);fflush(stdout);
					   }
					}
				}
			}
	}
	}

	decision = EPM_go;
	return decision;
 }


extern EPM_decision_t DLLAPI CS_mismatch_check_Func(EPM_rule_message_t msg)
{
	int status=0;
	EPM_decision_t decision;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int   attribute_act_tak;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	int				PartCnt				= 0;
	tag_t			AssyTag				= NULLTAG;
	tag_t			PartDmlTag				= NULLTAG;
	int       st_count=0;
	tag_t*    status_list;
	char *  ChildRelErr = NULL;
	char *  SetChildRelErr = NULL;
	char* class_name=NULL;
    char   *PuneCS=NULL;
    char   *ParentPart=NULL;
	char * ItemName ;
	char * t_ChildIOptionalCS ;
	char * ItemRev ;
	char * ChildPuneCS ;

	int iItm = 0;
	int j = 0;
	int i = 0;
	int n = 0;
	int cl = 0;
	int cnt = 0;
	int cntFlag = 0;
	char*	itemid;
	char*	DmlId;
	char*	itemidpre;
	char*	itemidprerev;
	char *  PrevRelErr;
	char *  SetPrevRelErr;
	char*	PrevPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	char  type_itemRev[TCTYPE_name_size_c+1];
	char  type_class[TCTYPE_name_size_c+1];
	char  PrevRevtype_name[TCTYPE_name_size_c+1];
	char PlantCS[40];
	char getPlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char  DMLPlant[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Prevtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	itemTypeTag_class							= NULLTAG;
	tag_t	value_prev_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *prevRev;
	tag_t  *totalPrev;
	tag_t  	value_act_Tak;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			PartDmlTags			= NULLTAG;
	tag_t	relation_type = NULLTAG;
	tag_t  *children1=NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;

	char   *username  = NULL;

	int iChildItemTag;
	int n_tags_found =0;

		printf("\n Calling CS_mismatch_check_Func.....\n");

	username = NULL;
	ITKCALL(POM_get_user_id (&username));
	printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n CS_mismatch_check_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );


     if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
		ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

		printf("\n iNumAttch %d.....\n",iNumAttch);
		for (i=0; i < iNumAttch; i++)
		{
			tag_t objTypeTag = NULLTAG;
			tag_t objChildRevTag = NULLTAG;
			const char *qry_entries[1];
			const char *qry_values[1];
			int n_tags_found=0;
	         tag_t	*itemclass							= NULLTAG;
	          tag_t item = NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n itemid %s.....\n",itemid);
            qry_entries[0] ="item_id";
            qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			 item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

			getPlantDetailsAttr(roleName,PlantCS,getPlantOptCS,PlantIA,PlantStore,UserAgency);
			printf("\n PlantCS %s \n",PlantCS);
			printf("\n getPlantOptCS %s \n",getPlantOptCS);
			printf("\n PlantAgency %s \n",PlantIA);
			printf("\n PlantStore %s \n",PlantStore);
			printf("\n UserAgency %s \n",UserAgency);

			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
			printf("\t  type_name ...%s\n", type_name);
			if( objTypeTag == ItemTypeTag )
			{
				printf("\t \n objTypeTag == ItemTypeTag \n");

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
				ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

				printf("\t  type_itemRev ...%s\n", type_itemRev);
				if (!SetChildRelErr) MEM_free(SetChildRelErr);
				SetChildRelErr=(char *)MEM_alloc(1000);


				if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
				{

				ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
				if (PartCnt>0)
				{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							ITKCALL(AOM_ask_value_string(AssyTag,PlantCS,&PuneCS));
							printf("\n Parent PuneCS:%s ..............",PuneCS);fflush(stdout);

							ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&ParentPart));
							printf("\n child ParentPart:%s ..............",ParentPart);fflush(stdout);

							ITKCALL(BOM_create_window (&window));
							ITKCALL(CFM_find( "Latest Working", &rule));
							ITKCALL(BOM_set_window_config_rule( window, rule ));
							//ifail = BOM_set_window_pack_all( window, false );
							//CHECK_IFAIL;
							ITKCALL(BOM_set_window_top_line(window, null_tag,AssyTag , null_tag, &top_line));
							ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children1));
							printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);
							for (cl = 0; cl < n; cl++)
							{
										ITKCALL(BOM_line_unpack (children1[cl]));
										ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
										ITKCALL(BOM_line_ask_attribute_tag(children1[cl], iChildItemTag, &t_ChildItemRev));

//										ITKCALL(AOM_ask_value_string(t_ChildItemRev,getPlantOptCS,&t_ChildIOptionalCS));
//										printf("\n child t_ChildIOptionalCS:%s ..............",t_ChildIOptionalCS);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName));
										printf("\n child ItemName:%s ..............",ItemName);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&ItemRev));
										printf("\n child ItemRev:%s ..............",ItemRev);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,PlantCS,&ChildPuneCS));
										printf("\n child ChildPuneCS:%s ..............",ChildPuneCS);fflush(stdout);
										if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
										ChildRelErr=(char *)MEM_alloc(500);
										tc_strcpy(ChildRelErr," ");
                                         // Parent as F CS and child part CS checks
										 if((strcmp(PuneCS,"F (External procurement)")==0) && (strcmp(ChildPuneCS,"E99 (In-house production-Back Flush Items)")==0 || strcmp(ChildPuneCS,"E50 (In-house production-Phantom Assembly)")==0
											                                                                                                              || strcmp(ChildPuneCS,"E98 (In-house production-SPD items - Ph)")==0  || strcmp(ChildPuneCS,"F (External procurement)")==0
											                                                                                                              || strcmp(ChildPuneCS,"F30 (External procurement - Subcontracting)")==0  || strcmp(ChildPuneCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0  ))
										{
//										 if((strcmp(PuneCS,"F (External procurement)")==0) && (strcmp(t_ChildIOptionalCS,"E99 (In-house production-Back Flush Items)")==0 || strcmp(t_ChildIOptionalCS,"E50 (In-house production-Phantom Assembly)")==0
//																											  || strcmp(t_ChildIOptionalCS,"E98 (In-house production-SPD items - Ph)")==0  || strcmp(t_ChildIOptionalCS,"F (External procurement)")==0
//																											  || strcmp(t_ChildIOptionalCS,"F30 (External procurement - Subcontracting)")==0  || strcmp(t_ChildIOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0  ))
											{

											printf("\n F under F not allowd");fflush(stdout);
												if(cnt==0)
													{
														cnt = 1;
														tc_strcat(ChildRelErr,"Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													}
												else
												{
														tc_strcat(ChildRelErr,"\n Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													     cnt = cnt+1;
													 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);

												}
											if(cnt==1)
											{
												tc_strcpy(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											else
											{
												tc_strcat(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											}
								      }else   // Parent as E50 CS and child part CS checks
									  if((strcmp(PuneCS,"E50 (In-house production-Phantom Assembly)")==0) && (strcmp(ChildPuneCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0
											                                                                                                               || strcmp(ChildPuneCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0  ))
										{
//										  if((strcmp(PuneCS,"E50 (In-house production-Phantom Assembly)")==0) && (strcmp(t_ChildIOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0
//																													   || strcmp(t_ChildIOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0  ))
											{
											printf("\n F18/F19 under E50 not allowd");fflush(stdout);
												if(cnt==0)
													{
														cnt = 1;
														tc_strcat(ChildRelErr,"Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													}
												else
												{
														tc_strcat(ChildRelErr,"\n Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													     cnt = cnt+1;
													 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);

												}
											if(cnt==1)
											{
												tc_strcpy(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											else
											{
												tc_strcat(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											}
								      }else   // Parent as E99 CS and child part CS checks
									  if((strcmp(PuneCS,"E99 (In-house production-Back Flush Items)")==0) && (strcmp(ChildPuneCS,"F (External procurement)")==0 || strcmp(ChildPuneCS,"F30 (External procurement - Subcontracting)")==0
											                                                                                                               || strcmp(ChildPuneCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0  || strcmp(ChildPuneCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0))
										{
//										  if((strcmp(PuneCS,"E99 (In-house production-Back Flush Items)")==0) && (strcmp(t_ChildIOptionalCS,"F (External procurement)")==0 || strcmp(t_ChildIOptionalCS,"F30 (External procurement - Subcontracting)")==0
//																													   || strcmp(t_ChildIOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0  || strcmp(t_ChildIOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0))
											{
											printf("\n F18/F19 under E50 not allowd");fflush(stdout);
												if(cnt==0)
													{
														cnt = 1;
														tc_strcat(ChildRelErr,"Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													}
												else
												{
														tc_strcat(ChildRelErr,"\n Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													     cnt = cnt+1;
													 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);

												}
											if(cnt==1)
											{
												tc_strcpy(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											else
											{
												tc_strcat(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											}
								      }else   // Parent as E98 CS and child part CS checks
									  if((strcmp(PuneCS,"E98 (In-house production-SPD items - Ph)")==0) && (strcmp(ChildPuneCS,"F (External procurement)")==0 || strcmp(ChildPuneCS,"F30 (External procurement - Subcontracting)")==0
											                                                                                                               || strcmp(ChildPuneCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0  || strcmp(ChildPuneCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0))
										{
//									  if((strcmp(PuneCS,"E98 (In-house production-SPD items - Ph)")==0) && (strcmp(t_ChildIOptionalCS,"F (External procurement)")==0 || strcmp(t_ChildIOptionalCS,"F30 (External procurement - Subcontracting)")==0
//											                                                                                                               || strcmp(t_ChildIOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0  || strcmp(t_ChildIOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0))
											{
											printf("\n F18/F19 under E50 not allowd");fflush(stdout);
												if(cnt==0)
													{
														cnt = 1;
														tc_strcat(ChildRelErr,"Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													}
												else
												{
														tc_strcat(ChildRelErr,"\n Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													     cnt = cnt+1;
													 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);

												}
											if(cnt==1)
											{
												tc_strcpy(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											else
											{
												tc_strcat(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											}
								      }else   // Parent as F18 CS and child part CS checks
										 if((strcmp(PuneCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
											                                                                                                              && (strcmp(ChildPuneCS,"E99 (In-house production-Back Flush Items)")==0 || strcmp(ChildPuneCS,"E50 (In-house production-Phantom Assembly)")==0
											                                                                                                              || strcmp(ChildPuneCS,"E98 (In-house production-SPD items - Ph)")==0  || strcmp(ChildPuneCS,"F (External procurement)")==0
											                                                                                                              || strcmp(ChildPuneCS,"F30 (External procurement - Subcontracting)")==0  || strcmp(ChildPuneCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0  ))
										{
//										 if((strcmp(PuneCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
//																											  && (strcmp(t_ChildIOptionalCS,"E99 (In-house production-Back Flush Items)")==0 || strcmp(t_ChildIOptionalCS,"E50 (In-house production-Phantom Assembly)")==0
//																											  || strcmp(t_ChildIOptionalCS,"E98 (In-house production-SPD items - Ph)")==0  || strcmp(t_ChildIOptionalCS,"F (External procurement)")==0
//																											  || strcmp(t_ChildIOptionalCS,"F30 (External procurement - Subcontracting)")==0  || strcmp(t_ChildIOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0  ))
											{
											printf("\n F18/F19 under E50 not allowd");fflush(stdout);
												if(cnt==0)
													{
														cnt = 1;
														tc_strcat(ChildRelErr,"Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													}
												else
												{
														tc_strcat(ChildRelErr,"\n Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													     cnt = cnt+1;
													 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);

												}
											if(cnt==1)
											{
												tc_strcpy(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											else
											{
												tc_strcat(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											}
								      }else   // Parent as F18 CS and child part CS checks
										 if((strcmp(PuneCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
											                                                                                                              && (strcmp(ChildPuneCS,"F30 (External procurement - Subcontracting)")==0  || strcmp(ChildPuneCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0  ))
										{
//										 if((strcmp(PuneCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
//																												  && (strcmp(t_ChildIOptionalCS,"F30 (External procurement - Subcontracting)")==0  || strcmp(t_ChildIOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0  ))

											{
											printf("\n F18/F19 under E50 not allowd");fflush(stdout);
												if(cnt==0)
													{
														cnt = 1;
														tc_strcat(ChildRelErr,"Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													}
												else
												{
														tc_strcat(ChildRelErr,"\n Parent Part ");
														tc_strcat(ChildRelErr,ParentPart);
														tc_strcat(ChildRelErr," Having CS ");
														tc_strcat(ChildRelErr,PuneCS);
														tc_strcat(ChildRelErr," is not allowed as Child ");
														tc_strcat(ChildRelErr,ItemName);
														tc_strcat(ChildRelErr," With CS  ");
														tc_strcat(ChildRelErr,ChildPuneCS);
														 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
													     cnt = cnt+1;
													 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);

												}
											if(cnt==1)
											{
												tc_strcpy(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											else
											{
												tc_strcat(SetChildRelErr,ChildRelErr);
												cntFlag = 1;
											}
											}
								      }
								} // End of FOR loop
							}
						  }
						}

					   printf("\n SetDMLRelErr: %s\n",SetChildRelErr);fflush(stdout);
						//if (tc_strcmp(SetChildRelErr,"NULL")!=0)
						if(cntFlag==1)
						{
							printf("\n Parent Child Part CS Mismatch  %s \n",SetChildRelErr);
							status=EMH_store_error_s1(EMH_severity_error,ITK_errStore,SetChildRelErr);
							//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
							//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
							decision = EPM_nogo;
							return ITK_errStore;
						}
					}
				}
			}

	decision = EPM_go;
	return decision;
 }

extern int apl_user_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

   if( ITK_ok == EPM_register_action_handler("apl_dml_assign", "", apl_dml_assign))
   {
		printf("\t\n Registered Action Handler apl_user_assign_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler apl_user_assign_register_method\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("apl_dml_create", "", apl_dml_create))
   {
		printf("\t\n Registered Action Handler apl_dml_create_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler apl_dml_create_register_method\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_action_handler("apl_dml_release", "", apl_dml_release))
   {
		printf("\t\n Registered Action Handler apl_dml_release_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler apl_dml_release_register_method\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_action_handler("apl_dml_claim", "", apl_dml_claim))
   {
		printf("\t\n Registered Action Handler apl_dml_claim_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler apl_dml_claim_register_method\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_rule_handler ("apl_child_part_rlz_check","This Handler is used to display message",(EPM_rule_handler_t)apl_child_part_rlz_check_Func))
   {
		printf("\t\n Registered Rule Handler apl_child_part_rlz_check\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler apl_child_part_rlz_check\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_rule_handler ("apl_part_prev_rev_rlz_check","This Handler is used to display message",(EPM_rule_handler_t)apl_part_prev_rev_rlz_check_Func))
   {
		printf("\t\n Registered Rule Handler apl_part_prev_rev_rlz_check\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler apl_part_prev_rev_rlz_check\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_rule_handler ("apl_erc_dml_check_Func","This Handler is used to display message",(EPM_rule_handler_t)apl_erc_dml_check_Func))
   {
		printf("\t\n Registered Rule Handler apl_erc_dml_check_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler apl_erc_dml_check_Func\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_rule_handler ("CS_mismatch_check_Func","This Handler is used to display message",(EPM_rule_handler_t)CS_mismatch_check_Func))
   {
		printf("\t\n Registered Rule Handler CS_mismatch_check_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler CS_mismatch_check_Func\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_rule_handler ("Hanging_Part_check_Func","This Handler is used to display message",(EPM_rule_handler_t)Hanging_Part_check_Func))
   {
		printf("\t\n Registered Rule Handler Hanging_Part_check_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler Hanging_Part_check_Func\n");fflush(stdout);
   }
//      if( ITK_ok == EPM_register_action_handler("apl_dml_map", "", apl_dml_map))
//   {
//		printf("\t\n Registered Action Handler apl_dml_map_register_method\n");fflush(stdout);
//   }else
//   {
//		printf("\t FAILED to register Action Handler apl_dml_map_register_method\n");fflush(stdout);
//   }

   ifail = METHOD_find_method("T5_APLDMLRevision", TC_save_msg, &method1);
   if (method1.id != NULLTAG)
   {
			ifail = METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) createAplCR_Task, NULL)!=ITK_ok;
			//PrintErrorStack();
			printf("\nrrrrrrrrRegistered as Post-Action for ChangeRequestRevision Creation\n");fflush(stdout);
   }else
		{
			printf("\nMethod not found!TC_save_msg\n");fflush(stdout);
		}

    return ITK_ok;
}

extern DLLAPI int apl_dml_assign_register_callbacks()
{
	 CUSTOM_register_exit("apl_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)apl_user_assign_register_method);

     printf("\n registered function apl_dml_assign\n");	fflush(stdout);

	 return ( ITK_ok );
}
