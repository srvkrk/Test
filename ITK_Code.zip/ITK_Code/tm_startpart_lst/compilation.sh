./compile tm_startpart_lst.c
./linkitk -o tm_startpart_lst tm_startpart_lst.o
chmod 777 tm_startpart_lst*
