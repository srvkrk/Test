./compile tm_wrongds_lst.c
./linkitk -o tm_wrongds_lst tm_wrongds_lst.o
chmod 777 tm_wrongds_lst*
