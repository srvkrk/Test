./compile tm_removenref.c
./linkitk -o tm_removenref tm_removenref.o
chmod 777 tm_removenref*
