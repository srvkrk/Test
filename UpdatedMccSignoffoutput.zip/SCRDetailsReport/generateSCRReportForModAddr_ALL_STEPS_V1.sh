############################################################
## To generate SCR Report
##############################################################
#Get ModuleAddres Name

cd /user/cvprod/sourav/InputSubModSimilarityReport

ModAddrName=`grep $1 "/user/cvprod/sourav/InputSubModSimilarityReport/ModuleAddres_Name_Mapping.config"`

echo "ModAddrName : $ModAddrName"
echo "Started generation SCR Report for Input-ModAddres : $1 ModAddrName: $ModAddrName"

./STEP_1_getSubModulesDataForModAddr.sh $1

sleep 5

./STEP_2_executeForModArrAndGenerateCompReport_V1.sh $1

sleep 5

./STEP_3_prepareModuleMatrixCompReport_V1.sh $1

sleep 5

./STEP_4_exceptionSMCompBOMPrint.sh $1


echo "Completed.......!"
