./compile tm_scrdetailsrpt.c
./linkitk -o tm_scrdetailsrpt tm_scrdetailsrpt.o
chmod 777 tm_scrdetailsrpt*
