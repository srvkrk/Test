###################################
#To generate multi-SCR for Mud-Addres
#
##################################

StartTime=`date`

echo "==========================> Started copying SCR for ModAddr as per input file"

while read ROW_ModAddr_Line
do
	echo "==========================> Copying for Module Address : $ROW_ModAddr_Line"
	
	cd /user/cvprod/sourav/InputSubModSimilarityReport/DATA/MCC_DATA_$ROW_ModAddr_Line
	
	ls -lrt MCC_SUBMODULE_COMPLEXITY_REDUCTION_REPORT_$ROW_ModAddr_Line*.xlsx	
	if [ $? == 0 ]
	then
		echo "==========================> SCR Report copied for Module Address  : $ROW_ModAddr_Line"
		cp MCC_SUBMODULE_COMPLEXITY_REDUCTION_REPORT_$ROW_ModAddr_Line*.xlsx ../../GENERATED_SCR_REPORTS_VAULT_MODADDR_D
	else
		echo "==========================> SCR Report Not found for $ROW_ModAddr_Line"
		echo "$ROW_ModAddr_Line , $StartTime" >> ../../SCR_REPORT_NOT_FOUND.txt
	fi	
	
	#sleep 1
	
done < Input_ModAdr_For_Fetch_List.txt

echo "==========================> Finished copying generated SCR for ModAddr as per input file"
#cd ..
#ls -lrt GENERATED_SCR_REPORTS_VAULT

exit
