echo "Start time:";date
echo "Input Module Address: $1"
echo "Creating directory as MCC_DATA_$1"
#mkdir MCC_DATA_$1
cd /user/cvprod/sourav/InputSubModSimilarityReport/MCC_DATA_$1
echo "Started executing Program for Module Adress $1"
#sleep 2
#/user/cvprod/sourav/InputSubModSimilarityReport/tm_InpSubModSimilarityRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Add=$1
#sleep 5
#ls -lrt
StrForSubModCount=`wc -l "ALL_SUBMOUDLES_"$1".txt"`
echo $StrForSubModCount

TotalLineCountALLSubMod=`echo $StrForSubModCount |cut -d\  -f1`

echo "TotalLineCountALLSubMod -------------------------> :"$TotalLineCountALLSubMod

rm -rf MATRIX_REPORT_WITH_SCORE_$1.csv
rm -rf QTY_ANALYIS_SUBMODULES_LIST_$1.txt
#rm -rf $1"_MATRIX_MODULARITY_SCORE_FILE.txt"

#Get ModuleAddres Name
ModAddrName=`grep $1 "/user/cvprod/sourav/InputSubModSimilarityReport/ModuleAddres_Name_Mapping.config"`

echo "ModAddrName : $ModAddrName"
ModAddr=`echo  $ModAddrName|cut -d "^"  -f1`
ModName=`echo  $ModAddrName|cut -d "^"  -f2`

echo "ModAddr : $ModAddr"
echo "ModName : $ModName"

#echo "$ModAddrName" >> MATRIX_REPORT_WITH_SCORE_$1.csv

HeaderString="$ModAddr [$ModName]"
echo "$HeaderString"

while read COLUMNS_SubModLine
do
		#COLUMNS_SubModLineCount=$(( $COLUMNS_SubModLineCount + 1 ))
		COLUMNS_SubMod_PartNumber=`echo $COLUMNS_SubModLine |cut -d "^"  -f2`
		COLUMNS_SubMod_PartRev=`echo $COLUMNS_SubModLine |cut -d "^"  -f3`
		COLUMNS_SubMod_PartSeq=`echo $COLUMNS_SubModLine |cut -d "^"  -f4`	
		COLUMNS_FormatttedSubModNum=$COLUMNS_SubMod_PartNumber"_"$COLUMNS_SubMod_PartRev"_"$COLUMNS_SubMod_PartSeq
		COLUMNS_SubModLineCount=$(( $COLUMNS_SubModLineCount + 1 ))
		HeaderString=$HeaderString","$COLUMNS_FormatttedSubModNum

done < "COLUMNS_ALL_SUBMOUDLES_"$1".txt"

echo "$HeaderString"
echo "$HeaderString" >> MATRIX_REPORT_WITH_SCORE_$1.csv

ROWS_SubModLineCount=0
while read ROWS_SubModLine
do
	ROWS_SubModLineCount=$(( $ROWS_SubModLineCount + 1 ))
	ROWS_SubMod_PartNumber=`echo $ROWS_SubModLine |cut -d "^"  -f2`
	ROWS_SubMod_PartRev=`echo $ROWS_SubModLine |cut -d "^"  -f3`
	ROWS_SubMod_PartSeq=`echo $ROWS_SubModLine |cut -d "^"  -f4`	
	ROWS_FormatttedSubModNum=$ROWS_SubMod_PartNumber"_"$ROWS_SubMod_PartRev"_"$ROWS_SubMod_PartSeq	
	#ROWS_SubModLineCount=$(( $ROWS_SubModLineCount + 1 ))
	#ROWS_SubMod_PartNumber=`echo $ROWS_SubModLine |cut -d "^"  -f7`
	#ROWS_SubMod_PartRev=`echo $ROWS_SubModLine |cut -d "^"  -f2`
	#ROWS_SubMod_PartSeq=`echo $ROWS_SubModLine |cut -d "^"  -f3`	
	#ROWS_FormatttedSubModNum=$ROWS_SubMod_PartNumber"_"$ROWS_SubMod_PartRev"_"$ROWS_SubMod_PartSeq
	#$1"_MATRIX_MODULARITY_SCORE_FILE_REPORT.txt"
	
	RowString="ROW [$ROWS_SubModLineCount] --> $ROWS_FormatttedSubModNum"
	
	while read COLUMNS_SubModLine
	do
		#COLUMNS_SubModLineCount=$(( $COLUMNS_SubModLineCount + 1 ))
		COLUMNS_SubMod_PartNumber=`echo $COLUMNS_SubModLine |cut -d "^"  -f2`
		COLUMNS_SubMod_PartRev=`echo $COLUMNS_SubModLine |cut -d "^"  -f3`
		COLUMNS_SubMod_PartSeq=`echo $COLUMNS_SubModLine |cut -d "^"  -f4`	
		COLUMNS_FormatttedSubModNum=$COLUMNS_SubMod_PartNumber"_"$COLUMNS_SubMod_PartRev"_"$COLUMNS_SubMod_PartSeq
		#COLUMNS_SubModLineCount=$(( $COLUMNS_SubModLineCount + 1 ))
		GrepString=$ROWS_FormatttedSubModNum","$COLUMNS_FormatttedSubModNum
		
		MatchingRowNumStr=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f1`
		MatchingColNumStr=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f2`
		ColStr=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f4`
		MatchedPartsCount=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f5`
		TotalPartsCount=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f6`
		TotalColChildParts=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f7`
		ModScore=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f8`
		
		if [ "$MatchedPartsCount" == "$TotalPartsCount" ]; then #100% case. ROW-set matching partially with COL-set.  
		#echo "First Strings match"
			if [ "$MatchedPartsCount" == "$TotalColChildParts" ]; then #100% case. ROW-set matching completely with COL-set.
				#echo "Second Strings match"
				RowString=$RowString","$ModScore"% ["$MatchedPartsCount"/"$TotalPartsCount" ("$TotalColChildParts")]*"
				
				if [[ "$COLUMNS_FormatttedSubModNum" = "$ROWS_FormatttedSubModNum" ]]
				then
					echo "Its Diagonal cell $MatchingRowNumStr,$MatchingColNumStr,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum $ModScore% [$MatchedPartsCount/$TotalPartsCount($TotalColChildParts)]*"
				else
					if [ "$ModScore" = "100.0" ]; then
						echo "100% case..ROW-set matching completely with COL-set. $MatchingRowNumStr,$MatchingColNumStr,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum,ALL_MATCHING $ModScore% [$MatchedPartsCount/$TotalPartsCount($TotalColChildParts)]*"
						echo "$MatchingRowNumStr,$MatchingColNumStr,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum,ALL_MATCHING" >> "QTY_ANALYIS_SUBMODULES_LIST_"$1".txt"
					else
						echo "ALL matching, but ModScore not 100.. $MatchingRowNumStr,$MatchingColNumStr,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum,PARTIAL_MATCHING $ModScore% [$MatchedPartsCount/$TotalPartsCount($TotalColChildParts)]"
					fi
				fi
				
			else
				#echo "MatchedPartsCount and TotalColChildParts dont't match"
				RowString=$RowString","$ModScore"% ["$MatchedPartsCount"/"$TotalPartsCount" ("$TotalColChildParts")]"
				
				if [ "$ModScore" = "100.0" ]; then
					echo "100% case..ROW-set matching partially with COL-set. $MatchingRowNumStr,$MatchingColNumStr,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum,PARTIAL_MATCHING $ModScore% [$MatchedPartsCount/$TotalPartsCount($TotalColChildParts)]"
					echo "$MatchingRowNumStr,$MatchingColNumStr,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum,PARTIAL_MATCHING" >> "QTY_ANALYIS_SUBMODULES_LIST_"$1".txt"
				else
					echo "PARTIAL matching, but ModScore not 100.. $MatchingRowNumStr,$MatchingColNumStr,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum,PARTIAL_MATCHING $ModScore% [$MatchedPartsCount/$TotalPartsCount($TotalColChildParts)]"
				fi
					
			fi
		else
			#echo "MatchedPartsCount and TotalPartsCount don't match"
			RowString=$RowString","$ModScore"% ["$MatchedPartsCount"/"$TotalPartsCount" ("$TotalColChildParts")]"
		fi
		
		
		#RowString=$RowString","$ColStr" "$ModScore
		#RowString=$RowString","$ModScore"% ["$MatchedPartsCount"/"$TotalPartsCount" ("$TotalColChildParts")]"
				
	done < "COLUMNS_ALL_SUBMOUDLES_"$1".txt"
	
echo " "
echo "$RowString"
echo "$RowString" >> MATRIX_REPORT_WITH_SCORE_$1.csv

done < "ROWS_ALL_SUBMOUDLES_"$1".txt"	

echo "Completed....."
echo "End time:";date
