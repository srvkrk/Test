###################################
#To generate multi-SCR for Mud-Addres
#
##################################

echo "==========================> Started generating multi SCR for ModAddr as per input file"

while read ROW_ModAddr_Line
do
	echo "==========================> Processing for Module Address : $ROW_ModAddr_Line"
		
	./generateSCRReportForModAddr_ALL_STEPS_V1.sh $ROW_ModAddr_Line
	
	echo "==========================> Completed for Module Address  : $ROW_ModAddr_Line"
	
done < Input_Multi_ModAdr_1.txt

echo "==========================> Finished generating multi SCR for ModAddr as per input file"

exit
