#start=$(date +%s)
#echo "Start Time : $start"
#echo "sleeping..7..";sleep 7
#end=$(date +%s)
#echo "End time...: $end"
#echo "Elapsed Time: $(($end-$start)) seconds"

########################################################################################################
##
## Date : 14-May-2025
## Creators : Ujjawal Kumar and Sourav Karak
## Desc : This program generates a Report for given Submodule-Address (say A1A02).
## Submodules Comparison first-level and print Submodules-matrix with Modularity-Matching score.
########################################################################################################
TodayDate=`date --date="today" +%d_%m_%Y`

echo "Today Date is : " $TodayDate
echo "Start time:";date

echo "Input Module Address: $1"
echo "Creating directory as MCC_DATA_$1"

echo "Backing up existing directory.."
mv MCC_DATA_$1 "MCC_DATA_"$1"_"$TodayDate
mkdir MCC_DATA_$1

cd /user/cvprod/sourav/InputSubModSimilarityReport/MCC_DATA_$1
echo "Started executing Program for Module Adress $1"

/user/cvprod/sourav/InputSubModSimilarityReport/tm_InpSubModSimilarityRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Add=$1
sleep 2

cp ALL_SUBMOUDLES_$1.txt COLUMNS_ALL_SUBMOUDLES_$1.txt
cp ALL_SUBMOUDLES_$1.txt ROWS_ALL_SUBMOUDLES_$1.txt

#ls -lrt

#exit
echo "Query program completed...going for Report generation processing..."
#sleep 3

StrForSubModCount=`wc -l "ALL_SUBMOUDLES_"$1".txt"`
echo $StrForSubModCount

TotalLineCountALLSubMod=`echo $StrForSubModCount |cut -d\  -f1`

echo "TotalLineCountALLSubMod -------------------------> :"$TotalLineCountALLSubMod

echo "Splitting in lines of 100...";

rm -rf SPLIT_FILES*
rm -rf "LIST_SPLIT_FILES_"$1".txt"

split -l 200 ALL_SUBMOUDLES_$1.txt "SPLIT_FILES_"$1"_"

ls -lrt SPLIT_FILES_$1_*|awk -F' ' '{print $9}' > "LIST_SPLIT_FILES_"$1".txt"

echo "Split files created and Split list file created pls check....";
cat "LIST_SPLIT_FILES_"$1".txt"


echo "Completed.."
echo "End time:";date

