. /user/cvprod/.bash_profile

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"
echo "First Argument: -----> "$1
echo "Second Argument: -----> "$2
echo "Third Argument: -----> "$3
START="MCC_DATA_"
DIRECTORY="${START}${1}"
echo "Directory Name: " $DIRECTORY
FIRSTPATH="/user/cvprod/sourav/InputSubModSimilarityReport/"
SECONDPATH="/"
FINALPATH="${FIRSTPATH}${DIRECTORY}${SECONDPATH}"
echo "Final Path: " $FINALPATH
cd $FINALPATH
sort -u $2 -o $3
sleep 3
rm -rf *TEMP.txt
echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"
