echo "Input Module Address: $1"
echo "Input Login ID: $2"
echo "Input Email Address: $3"

echo "Creating directory as MCC_DATA_$1"

mkdir MCC_DATA_$1

cd MCC_DATA_$1

/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport/tm_scrdetailsrpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -ModAdd=$1 -LoginID=$2 -Email=$3

sleep 5

echo "Completed....."
