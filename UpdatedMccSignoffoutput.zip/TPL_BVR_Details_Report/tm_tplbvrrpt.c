/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query All Released TPL & Print its Properties on Reports as well as check BVR Present or not  
*  File Name    :   tm_tplbvrrpt.c
*  Created on   :   Apr 16th, 2025
*  Usage        :   tm_tplbvrrpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     16/04/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_revseq_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_projcode_str = NULL;
	char *item_ardr_str = NULL;
	char *item_desgrp_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *item_projcode_strDup = NULL;
	char *item_ardr_strDup = NULL;
	char *item_desgrp_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *Owner = NULL;
	char *OwnerDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	int i = 0;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t DesRev_tag = NULLTAG;
	int ChldCount = 0;
	tag_t *PartChildTags = NULLTAG;
	char *ChildStatusDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"TPL_BVR_Details_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	 
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"TPL_NO, REV, SEQ, DESCRIPTION, PROJECT_CODE, DESIGN_GROUP, DR/AR_STATUS, OWNING_USER, CHILD_STATUS\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
		
	ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query [MCC_ERC_Released_Latest_Revision] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Item ID","Part Type","Type"};
		char *cValues[3]  = {"*","T","Design Revision"};
		//char *cValues[3]  = {"*","T","Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n Query [MCC_ERC_Released_Latest_Revision] Found..!!\n");fflush(stdout);
			for (i = 0; i < n_itemobj_found; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
				if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
				}
				else
				{
					tc_strdup("--",&item_id_strDup);
					printf("\n Part_No Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
				if(tc_strlen(item_revseq_str)>0)
				{
					tc_strdup(item_revseq_str,&item_revseq_strDup);
					item_rev_strDup=tc_strtok(item_revseq_strDup,";");
					item_seq_strDup=tc_strtok(NULL,";");
				}
				else
				{
					tc_strdup("--",&item_revseq_strDup);
					tc_strdup("--",&item_rev_strDup);
					tc_strdup("--",&item_seq_strDup);
					printf("\n Part Rev_seq Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"object_desc",&cItem_Desc));
				printf("\n Item Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
				if(tc_strlen(cItem_Desc)>0)
				{
					tc_strdup(cItem_Desc,&cItem_DescDup);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\n Item Description Value is NULL..!!");fflush(stdout);
				}
				trimwhitespace(cItem_DescDup);
				printf("\n Item Description Value After Dup & Trim: --------> <%s>", cItem_DescDup);fflush(stdout);
				STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
				printf("\n Item Description Final Value: --------> [%s]\n", cItem_DescDup);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ProjectCode",&item_projcode_str));
				if(tc_strlen(item_projcode_str)>0)
				{
					tc_strdup(item_projcode_str,&item_projcode_strDup);
				}
				else
				{
					tc_strdup("--",&item_projcode_strDup);
					printf("\n Part Project Code Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_DesignGrp",&item_desgrp_str));
				if(tc_strlen(item_desgrp_str)>0)
				{
					tc_strdup(item_desgrp_str,&item_desgrp_strDup);
				}
				else
				{
					tc_strdup("--",&item_desgrp_strDup);
					printf("\n Part Design Group Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartStatus",&item_ardr_str));
				if(tc_strlen(item_ardr_str)>0)
				{
					tc_strdup(item_ardr_str,&item_ardr_strDup);
				}
				else
				{
					tc_strdup("--",&item_ardr_strDup);
					printf("\n Part AR/DR Status Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"owning_user",&Owner));
				if(tc_strlen(Owner)>0)
				{
					tc_strdup(Owner,&OwnerDup);
					trimwhitespace(OwnerDup);
					printf("\n Owning_User Value After Dup & Trim: --------> <%s>", OwnerDup);fflush(stdout);
					STRNG_replace_str(OwnerDup,","," ",&OwnerDup);
					STRNG_replace_str(OwnerDup,";"," ",&OwnerDup);
					STRNG_replace_str(OwnerDup,"\n"," ",&OwnerDup);
					STRNG_replace_str(OwnerDup,"'"," ",&OwnerDup);
					printf("\n Owning_User Final Value: --------> [%s]\n", OwnerDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&OwnerDup);
					printf("\n Owning_User Value is NULL..!!");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_tags(DesRev_tag,"ps_children",&ChldCount,&PartChildTags));
				if(ChldCount>0)
				{
					tc_strdup("Present",&ChildStatusDup);
				}
				else
				{
					tc_strdup("Not_Present",&ChildStatusDup);
				}
				
				printf("\n TPL Details Start...!!\n");fflush(stdout);
				printf("[1] Part_No: [%s]\n",item_id_strDup);fflush(stdout);
				printf("[2] Revision: [%s]\n",item_rev_strDup);fflush(stdout);
				printf("[3] Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
				printf("[4] Description: [%s]\n",cItem_DescDup);fflush(stdout); 
				printf("[5] Project_Code: [%s]\n",item_projcode_strDup);fflush(stdout);
				printf("[6] Design_Group: [%s]\n",item_desgrp_strDup);fflush(stdout); 
				printf("[7] DR/AR Status: [%s]\n",item_ardr_strDup);fflush(stdout);
				printf("[8] Owning_User: [%s]\n",OwnerDup);fflush(stdout);
				printf("[9] Child_Status: [%s]\n",ChildStatusDup);fflush(stdout);
				printf("\n TPL Details End...!!\n");fflush(stdout);
				
				fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,cItem_DescDup,item_projcode_strDup,item_desgrp_strDup,item_ardr_strDup,OwnerDup,ChildStatusDup);fflush(fpOutput_file);
			}
		}
		else
		{
			printf(" Query [MCC_ERC_Released_Latest_Revision] Not Found..!!\n");fflush(stdout);
		}
	}
	else
	{
		printf(" [MCC_ERC_Released_Latest_Revision] Query Tag Not Found..!!\n");fflush(stdout);
	}
	if(titemobj_results)
	{
		MEM_free(titemobj_results);
	}
		
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);	
	printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_tplbvrrpt.c
* // ./linkitk -o tm_tplbvrrpt tm_tplbvrrpt.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/TPL_BVR_Details_Report/tm_tplbvrrpt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/TPL_BVR_Details_Report/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/TPL_BVR_Details_Report/PartList.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/TPL_BVR_Details_Report/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/TPL_BVR_Details_Report/SendEmail.sh .
* // ./tm_tplbvrrpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_tplbvrrpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_tplbvrrpt -u=loader -p=loader123 -g=dba
*
***************************************************************************/