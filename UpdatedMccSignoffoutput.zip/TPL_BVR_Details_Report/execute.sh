/user/cvprod/sourav/TPL_BVR_Details_Report/tm_tplbvrrpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
