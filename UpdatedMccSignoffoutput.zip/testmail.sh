( echo "Dear All,

PC tag removed for below vc from SAP
VC Number: 55552735000R
Description: 407G GOLD SFC DCR35HSD 85B6M5
Product Line: ILMCV
Platform: LCV
Segment: 4T-6T
Profit Center: 102200
Plant Code: 1001
System Release Date: 18-09-2025
Object Created Date: 19-09-2025
PC Tag Remove Date: 10-Jan-2026 09:44

Regards,
PLM Team

"   )  | nail  -s "UPDATE:PC tag removed from SAP: 55552735000R_NR_1_1001 | 102200 | 1001" -c "souravk.ttl@tatamotors.com"  "souravk.ttl@tatamotors.com,rajans.ttl@tatamotors.com,ad928811.ttl@tatamotors.com"
