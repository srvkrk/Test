#!/bin/bash
. /user/cvprod/.bash_profile

FROM="$1"
SUBJECT="$2"
BODY="$3"

ITEM_ID=$(echo "$BODY" | grep "ItemID=" | cut -d'=' -f2)
ITEM_NAME=$(echo "$BODY" | grep "ItemName=" | cut -d'=' -f2)
ITEM_TYPE=$(echo "$BODY" | grep "ItemType=" | cut -d'=' -f2)
REVISION=$(echo "$BODY" | grep "Revision=" | cut -d'=' -f2)

echo "Sender: $FROM"
echo "Subject: $SUBJECT"
echo "ItemID: $ITEM_ID"
echo "ItemName: $ITEM_NAME"
echo "ItemType: $ITEM_TYPE"
echo "Revision: $REVISION"