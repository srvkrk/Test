######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : SEPTEMBER-2024
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'Data Conversion Program Started...'
echo  "-----------------------------------------------------------------------------------------"

echo "XML File Name[IN][Format-.xml]: -----> "$1

echo "XLS File Name[OUT][Format-.xls]: -----> "$2

echo "JAR Calling Start....."
java -classpath $TC_ROOT/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN $1 -OUT $2 -XSL /user/cvprod/sourav/XMLTOXLSWITHXALAN/mcc_vehicle_compliance_report_excel.xsl
echo "JAR Calling End......."

echo  "-----------------------------------------------------------------------------------------"
echo  'Data Conversion Program Finished...'
echo  "-----------------------------------------------------------------------------------------"
