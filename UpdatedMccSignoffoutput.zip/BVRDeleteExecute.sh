/user/cvprod/sourav/bvrdelete -i=Input.txt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
