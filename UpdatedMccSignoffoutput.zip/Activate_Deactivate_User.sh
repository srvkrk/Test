$TC_ROOT/bin/make_user -u=infodba -pf=/user/cvprod/shells/Admin/infodbapasswdfile.pwf -g=dba -file=user.lst
