rm -f *.wsdl ns.xsd *.nsmap *.res.xml *.req.xml soapServerLib.c soapClientLib.c soapStub.h soapServer.c soapH.h soapClient.c soapC.c *.o *.cgi

./soapcpp2 -1 -e -c GeneratePart.h

./compile GeneratePart.c

./linkitk -o GeneratePart.cgi GeneratePart.o soapC.c soapServer.c stdsoap2.c
chmod 777 *
cp GeneratePart.wsdl /user/cvprod/apache-tomcat-9.0.113/webapps/ROOT/
cp GeneratePart.cgi /user/cvprod/apache-tomcat-9.0.113/webapps/ROOT/WEB-INF/cgi/
cp *.xml /user/cvprod/apache-tomcat-9.0.113/webapps/ROOT/WEB-INF/cgi/
#cd /home/user/tcuaadev/apache-tomcat-8.5.29/bin
#./shutdown.sh
#./startup.sh
cd /user/cvprod/sourav/TC_14_WebService/GeneratePart/
