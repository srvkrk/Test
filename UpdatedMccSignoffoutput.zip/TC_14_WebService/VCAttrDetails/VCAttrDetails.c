/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   WebService For VC Attribute Details Fetch From PLM For ProNext
*  File Name    :   VCAttrDetails.c
*  Created on   :   April 28th, 2025
*  Usage        :   VCAttrDetails.c
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     28/04/2025                 Sourav Karak
***************************************************************************/

#include "soapH.h"
#include "VCAttrDetails.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc_startup.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <base_utils/Mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <tc/folder.h>
#include <string.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <cfm/cfm.h>
#include <fclasses/tc_date.h>
#define MAX_LINE_LENGTH 1000
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

int ICS_keylov_get_keylov (const char *key_lov_id, char **key_lov_name, int *options, int *n_lov_entries, char ***lov_keys, char ***lov_values, logical **deprecated_staus, char **owning_site, int *n_shared_sites, char ***shared_sites);
int ICS_describe_unct (int unctNo, char **unctName, char **shortName, char **unctUnit, int *unctFormat);
int DATE_date_to_string (date_t date_struct, const char *format_str, char **date_str);
int CFM_find (const char *name, tag_t *rule);

char *FRRRTYREMOD=NULL;
char *FLTANKMOD=NULL;;
char *GBMODTMOD=NULL;
char *RAXMODRATMOD=NULL;
char *ENGMODMOD=NULL;
		
int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -pno=<Part Number> (Required)\n"
        );	
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    //register int i = 0;
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   //ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
   //fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
-      //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
       //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
	   printf("Test");
    }
    return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

tag_t TC_ModuleTag_Details(char* MdNoSrc)
{
	trimwhitespace(MdNoSrc);
	tag_t tModItemobj = NULLTAG;
	int n_modentries = 4;
	int n_moditemobj_found = 0;
	tag_t* modtitemobj_results = NULLTAG;
	int c = 0;
	tag_t ModDesRev_tag = NULLTAG;
	
	
	printf("\n Finding Query[MCC_ERC_Released_Latest_Revision]..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tModItemobj));
	printf("\n Query[MCC_ERC_Released_Latest_Revision] Tag Found Successfully..!!\n");fflush(stdout);
	char *cModEntries[4]  = {"Item ID","Release Status","Part Type","Type"};
	char *cModValues[4]  = {MdNoSrc,"T5_LcsErcRlzd","M","Design Revision"};
	ITK_CALL(QRY_execute(tModItemobj, n_modentries, cModEntries, cModValues, &n_moditemobj_found, &modtitemobj_results));
	printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Latest ERC Released Total Vehicle Found: [%d]\n",n_moditemobj_found);fflush(stdout);
	printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
	if(n_moditemobj_found > 0)
	{
		ModDesRev_tag = modtitemobj_results[c];
	}
	
	return ModDesRev_tag;	
}

char* TC_PlantCS(char* PNum, char* PRev, char* PSeq, char* PlntCSName)
{
	tag_t tCSItemobj = NULLTAG;
	int n_csentries = 2;
	int n_csitemobj_found = 0;
	tag_t* tcsitemobj_results = NULLTAG;
	int t = 0;
	char *RlzStatusName = NULL;
	char *CSVal = NULL;
	char *CSValDup = NULL;
	tag_t CSRev_tag = NULLTAG;
	char *PRevSeq = (char *) malloc(10*sizeof(char));
	tc_strcpy(PRevSeq,PRev);
	tc_strcat(PRevSeq,"*");
	tc_strcat(PRevSeq,PSeq);
	printf("\n Part Rev&Seq(PRevSeq): [%s]\n",PRevSeq);
	
	ITK_CALL(QRY_find2("DesignRevision Sequence",&tCSItemobj));
	if(tCSItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
		char *cCSEntries[2]  = {"Revision","ID"};
		char *cCSValues[2]  = {PRevSeq,PNum};
		//char *cCSValues[2]  = {"A;2","5137D1D0270001_WE"};
		ITK_CALL(QRY_execute(tCSItemobj, n_csentries, cCSEntries, cCSValues, &n_csitemobj_found, &tcsitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_csitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_csitemobj_found > 0)
		{
			printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
			for (t = 0; t < n_csitemobj_found; t++)
			{
				CSRev_tag = tcsitemobj_results[t];
				ITK_CALL(AOM_ask_value_string(tcsitemobj_results[t],PlntCSName,&CSVal));
				if(tc_strlen(CSVal)>0)
				{
					tc_strdup(CSVal,&CSValDup);
				}
				else
				{
					tc_strdup("--",&CSValDup);
					printf("\n CS Value is NULL..!!");fflush(stdout);
				}
			}
		}
	}
	if(tc_strlen(CSVal)>0)
	{
	   tc_strdup(CSVal,&CSValDup);
	}
	else
	{
	   tc_strdup("-",&CSValDup);
	}
	return CSValDup;
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, char* VNo, char* VRev, char* VSeq)
{
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cModAddress = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* cItemLevel = NULL;
		char* cItemLevelDup = NULL;
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
	        ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_level_starting_0", &cItemLevel));
			if(tc_strlen(cItemLevel)>0)
			{
				tc_strdup(cItemLevel,&cItemLevelDup);
			}
			else
			{
				tc_strdup("--",&cItemLevelDup);
				printf("\n Part Level Value is NULL");fflush(stdout);
			}
			trimwhitespace(cItemLevelDup);
			printf("\n Part Level Value After Dup & Trim: [%s]\n", cItemLevelDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			cModAddress = subString(cItem_Id, 4, 5);
			trimwhitespace(cModAddress);
			printf("\n Part Module Address Value: [%s]", cModAddress);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("--",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nParent_Part_No: [%s]", VNo);
			printf("\nParent_Part_Rev: [%s]", VRev);
			printf("\nParent_Part_Seq: [%s]", VSeq);
			printf("\nChild_Level: [%s]", cItemLevelDup);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Part Revision: [%s]", cItem_Rev);
			printf("\nChild_Level Part Sequence: [%s]", cItem_Seq);
			printf("\nChild_Level Module Address String: [%s]", cModAddress);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\n-------------------------------------------------------------------------\n");
			if((tc_strcmp(cPartTypeDup,"Module")==0) && (tc_strcmp(cModAddress,"F5B01")==0))
			{
				if(tc_strlen(FRRRTYREMOD)>0)
				{
					printf("\n [VC]FR_TYRE_SIZE & [VC]RR_TYRE_SIZE Value Found & Already Copied");fflush(stdout);
				}
				else
				{
					tc_strcat(FRRRTYREMOD,cItem_Id);
				}
			}
			if((tc_strcmp(cPartTypeDup,"Module")==0) && (tc_strcmp(cModAddress,"F3A01")==0))
			{
				if(tc_strlen(FLTANKMOD)>0)
				{
					printf("\n [VC]FuelTank Capacity(FUELTANK) Value Found & Already Copied");fflush(stdout);
				}
				else
				{
					tc_strcat(FLTANKMOD,cItem_Id);
				}
			}
			if((tc_strcmp(cPartTypeDup,"Module")==0) && (tc_strcmp(cModAddress,"H2C01")==0))
			{
				if(tc_strlen(GBMODTMOD)>0)
				{
					printf("\n Specs-Gearbox Model(GB_MODEL) Value Found & Already Copied");fflush(stdout);
				}
				else
				{
					tc_strcat(GBMODTMOD,cItem_Id);
				}
			}
			if((tc_strcmp(cPartTypeDup,"Module")==0) && (tc_strcmp(cModAddress,"H2D01")==0))
			{
				if(tc_strlen(RAXMODRATMOD)>0)
				{
					printf("\n [VC]Specs-Rear Axle Model(REAR_AXLE_MODEL) & [VC]Specs-Rear Axle Ratio(REAR_AXLE_RATIO) Value Found & Already Copied");fflush(stdout);
				}
				else
				{
					tc_strcat(RAXMODRATMOD,cItem_Id);
				}
			}
			if((tc_strcmp(cPartTypeDup,"Module")==0) && (tc_strcmp(cModAddress,"H1A01")==0))
			{
				if(tc_strlen(ENGMODMOD)>0)
				{
					printf("\n [VC]Engine Model Value Found & Already Copied");fflush(stdout);
				}
				else
				{
					tc_strcat(ENGMODMOD,cItem_Id);
				}
			}
			
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				printf("\n!!!!!!!!!! I N N E R  C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(tSubChild,iNumber_SubChild,cItem_Id,cItem_Rev,cItem_Seq);
			} */
		}
		
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRev,char* VehicleSeq,char* VehicleRS)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubLevel = NULL;
	char* ctopSubLevelDup = NULL;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_level_starting_0", &ctopSubLevel));
			if(tc_strlen(ctopSubLevel)>0)
			{
				tc_strdup(ctopSubLevel,&ctopSubLevelDup);
			}
			else
			{
				tc_strdup("--",&ctopSubLevelDup);
				printf("\n Part Level Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubLevelDup);
			printf("\n Part Level Value After Dup & Trim: [%s]\n", ctopSubLevelDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Parent_Part: [%s]", Vehicle);
			printf("\nTop_Parent_Rev: [%s]", VehicleRev);
			printf("\nTop_Parent_Seq: [%s]", VehicleSeq);
			printf("\nTop_Level: [%s]", ctopSubLevelDup);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);		
			printf("\n-------------------------------------------------------------------------\n");
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, Vehicle, VehicleRev, VehicleSeq);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

char* getClsValueFrmICSTag_new(tag_t  DesignMasterTag, char *attrname)
{
	int	status;
	int ifail = ITK_ok;
	int ic = 0;
    int	xc = 0;
	tag_t Design_rev_cls_tag = NULLTAG;
	int theAttributeCount = 0;
	int *theAttributeIds ;
	char **theAttributeNames = NULL;
	int *theAttributeValCounts = 0;
	char*** theAttributeValues = NULL;
	char*** theAttributeOptimizedUnits = NULL;
	char* attrId = NULL;
	attrId = (char *) MEM_alloc(50 * sizeof(char));
	char *attributeNameDup = NULL;
	char *attributeValueDup = NULL;
	attributeNameDup = (char *) MEM_alloc(500 * sizeof(char));
	attributeValueDup = (char *) MEM_alloc(500 * sizeof(char));
	
	ITKCALL(ICS_ask_classification_object(DesignMasterTag,&Design_rev_cls_tag));
	if(Design_rev_cls_tag)
	{
		ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
		if(theAttributeCount>0)
		{
			for(ic=0;ic<theAttributeCount;ic++)
			{
				sprintf(attrId,"%d",theAttributeIds[ic]);

				tc_strcpy(attributeNameDup,"");
				tc_strcpy(attributeNameDup,theAttributeNames[ic]);

				printf("\n Attribute Name: [%s] For Value: [%d]",attributeNameDup,ic);fflush(stdout);

				if(tc_strcmp(attributeNameDup,attrname)==0)
				{
					tc_strcpy(attributeValueDup,"");
					for(xc=0;xc<theAttributeValCounts[ic];xc++)
					{
						//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[ic][x]);fflush(stdout);
						tc_strcat(attributeValueDup,theAttributeValues[ic][xc]);
						//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
					}

					printf("\n Attribute Name: [%s]",attributeNameDup);fflush(stdout);
					printf("\n attrId: [%s]",attrId);fflush(stdout);
					printf("\n Attribute Value: [%s] ",attributeValueDup);fflush(stdout);
		     	}
			}
		}
	}
	else
	{
		printf("\n Design_rev_cls_tag Not Found..!!"); fflush(stdout);
	}
    printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	printf("\n Attribute Value: [%s]",attributeValueDup);fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	
    return attributeValueDup;	
	//return ITK_ok;
}

int getClsValueFrmICSTag_pm( tag_t  IcsClsTag_pm , char *clsKeyAtrrId_pm,char **AttrVal)
{
	tag_t objTypeTag_pm=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name_pm[TCTYPE_name_size_c+1];
	char   *Ptype_name_pm	=	NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag_pm,&objTypeTag_pm));
	//if(TCTYPE_ask_name(objTypeTag_pm,Ptype_name_pm));
	if(TCTYPE_ask_name2(objTypeTag_pm,&Ptype_name_pm)); // TC 14.3 Upgrade

	
	if(IcsClsTag_pm!=NULLTAG)
	{
		    char * 	theClassId = NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId_pm); fflush(stdout);
			//char keyPrefix[10];
			//tc_strcpy(keyPrefix,"-");
			//tc_strcat(keyPrefix,clsKeyAtrrId);
			int intid2 = 0;
			char * 	unctName = NULL;
		    char *	shortName = NULL;
		    char * 	unctUnit = NULL;
		    int  unctFormat = 0;
			intid2=atoi(clsKeyAtrrId_pm);
			printf("\n  input intid2[%d]",intid2); fflush(stdout);
	 
			printf("\n  111"); fflush(stdout);
			ITKCALL(ICS_describe_unct(intid2,&unctName,&shortName,&unctUnit,&unctFormat));
			printf("\n  222 ifail[%d]",ifail); fflush(stdout);
			if(ifail != ITK_ok)
			{
				printf("\n FAIL:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);						
				return ifail;	
			}
			
			printf("\n SUCCESS:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);
			//printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			//const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char theKeyLOVId[10];
			const char * 	key_lov_id;
			if(unctFormat)
			{

				sprintf(theKeyLOVId, "%d", unctFormat);
				key_lov_id=theKeyLOVId;	
			}
			char * 	key_lov_name;
			int  	options;
			int t = 0;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites;
			theICOTag=IcsClsTag_pm;
			ITKCALL(ICS_ask_attribute_value(theICOTag,clsKeyAtrrId_pm,&AttrKeyValue));
			
			printf("\n AttrKeyValue: [%s]  key_lov_id: [%s]",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			    if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    //CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    printf("\n key_lov_name: [%s] n_lov_entries: [%d] options: [%d]",key_lov_name,n_lov_entries,options); fflush(stdout);
 				for(t=0;t<n_lov_entries;t++)								
				{
					//printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
					
					//if(tc_strcasecmp(AttrKeyValue,lov_keys[t])==0)
					if(tc_strstr(lov_keys[t],AttrKeyValue) != NULL)
					{
						printf("\n AttrKeyValue: [%s]",AttrKeyValue);fflush(stdout);
						printf("\n Mascot lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						
						if(lov_values[t])
						{
							tc_strdup(lov_values[t],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						printf("\n Before Break RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
						break;
					}	
				} 
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}
    printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	printf("\n RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
			
	return ITK_ok;
}

int getClsValueFrmICSTag( tag_t  IcsClsTag , char *clsKeyAtrrId,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name[TCTYPE_name_size_c+1];
	char	*Ptype_name		=	NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag,&objTypeTag));
	//if(TCTYPE_ask_name(objTypeTag,Ptype_name));
	if(TCTYPE_ask_name2(objTypeTag,&Ptype_name));  // TC 14.3 API Change
	//printf("\n getClsValueFrmICSTag IcsClsTag  Ptype_name :: %s\n", Ptype_name); fflush(stdout);

	
	//Create Relation between Intent and Vehicle.
	int partRevCnt=0;
    tag_t* partRevTagObjs = NULLTAG;
    tag_t partRevTag = NULLTAG;
	if(IcsClsTag!=NULLTAG)
	{
		    char * 	theClassId = NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
			char keyPrefix[10];
			tc_strcpy(keyPrefix,"-");
			tc_strcat(keyPrefix,clsKeyAtrrId);
			printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char * 	key_lov_name;
			int  	options;
			int q = 0;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites ;
			theICOTag=IcsClsTag;
			//CALLAPI(ICS_ask_attribute_value(theICOTag,"8066",&AttrKeyValue))
			if(ICS_ask_attribute_value(IcsClsTag,clsKeyAtrrId,&AttrKeyValue))
			
			printf("\n AttrKeyValue: [%s]  key_lov_id: [%s]",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			    if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    //CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    printf("\n key_lov_name: [%s] n_lov_entries: [%d] options: [%d]",key_lov_name,n_lov_entries,options); fflush(stdout);
 				for(q=0;q<n_lov_entries;q++)								
				{
					printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[q],lov_values[q]);fflush(stdout);
					
					if(tc_strcasecmp(AttrKeyValue,lov_keys[q])==0)
					{
						printf("\n Mascot lov_keys: [%s] lov_values: [%s]",lov_keys[q],lov_values[q]);fflush(stdout);
						
						if(lov_values[q])
						{
							tc_strdup(lov_values[q],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						break;
					}	
				} 
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}
    printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	printf("\n RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
			
	return ITK_ok;
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSeqSrch)
{
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision PartType",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision PartType Query Found Successfully..!!\n");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[n];
				if(LC_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpLCQryobj_results[n],"release_status_list",&sRelStatus);
					printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						tc_strdup("--",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL..!!\n");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
					printf("\n Item Release Status After Dup & Trim: [%s]\n", sRelStatusDup);fflush(stdout);
					STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
					printf("\n Item Release Status Final Value: [%s]\n", sRelStatusDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&sRelStatusDup);
					printf("\nSorry! Revision Tag Not Found...\n");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&sRelStatusDup);
			printf("\nSorry! Entered Revision Not Found...\n");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&sRelStatusDup);
		printf("\nSorry! DesignRevision PartType Query Tag Not Found...\n");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

extern int ITK_user_main(int argc, char *argv[])
{
    FRRRTYREMOD = (char *) malloc(20*sizeof(char));
	FLTANKMOD = (char *) malloc(20*sizeof(char));
	GBMODTMOD = (char *) malloc(20*sizeof(char));
	RAXMODRATMOD = (char *) malloc(20*sizeof(char));
	ENGMODMOD = (char *) malloc(20*sizeof(char));
	tc_strcpy(FRRRTYREMOD,"");
	tc_strcpy(FLTANKMOD,"");
	tc_strcpy(GBMODTMOD,"");
	tc_strcpy(RAXMODRATMOD,"");
	tc_strcpy(ENGMODMOD,"");
	
	return soap_serve(soap_new()); 

}
;


int ns__getItemData(struct soap* soap,char *PartNum,struct ns__CharArray1 *aString_test)
{
        int iFail =0;
		int ifail =0;
		int	tt1	= 0;
		//char* PartNum = NULL;
	    char* PartNumber = NULL;
	    char* PartNumberDup = NULL;
	    PartNumberDup=(char *)MEM_alloc(200);
		char* responseString1 = NULL;
		char* responseString2 = NULL;
		char* responseString3 = NULL;
		char* responseString4 = NULL;
		char* responseString5 = NULL;
		char* responseString6 = NULL;
		char* responseString7 = NULL;
		char* responseString8 = NULL;
		char* responseString9 = NULL;
		char* responseString10 = NULL;
		char* responseString11 = NULL;
		char* responseString12 = NULL;
		char* responseString13 = NULL;
		char* responseString14 = NULL;
		char* responseString15 = NULL;
		char* responseString16 = NULL;
		char* responseString17 = NULL;
		char* responseString18 = NULL;
		char* responseString19 = NULL;
		char* responseString20 = NULL;
		char* responseString21 = NULL;
		char* responseString22 = NULL;
		char* responseString23 = NULL;
		char* responseString24 = NULL;
		char* responseString25 = NULL;
		char* responseString26 = NULL;
		char* responseString27 = NULL;
		char* Print_Report = NULL;
		char**	ReportSetSTR = NULL;
		size_t len;
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/VCAttrDetailsRpt.txt", "w", stdout);
		tag_t tItemobj = NULLTAG;
		int n_entries = 4;
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULLTAG;
		int m = 0;
		tag_t DesRev_tag = NULLTAG;
		char *item_id_str = NULL;
		char *item_id_strDup = NULL;
		char *item_revseq_str = NULL;
		char *item_revseq_strDup = NULL;
		char *item_rev_strDup = NULL;
		char *item_seq_strDup = NULL;
		char *cItem_Desc = NULL;
		char *cItem_DescDup = NULL;
		char *DRStatus = NULL;
		char *DRStatusDup = NULL;
		char *Platform = NULL;
		char *PlatformDup = NULL;
		char *cItem_RevSeq = NULL;
		cItem_RevSeq = (char *) malloc(20*sizeof(char));
		char *cItem_LCDetails = NULL;
		char *owner = NULL;
		char *ownerDup = NULL;
		date_t Lastmoddate;
		char *LastmoddateDup = NULL;
		char *Newitem_revseq_str = NULL;
		char *Newitem_revseq_strDup = NULL;
		tag_t FRRRTYRE_DesRev = NULLTAG;
		tag_t FLTANK_DesRev = NULLTAG;
		tag_t GBMODT_DesRev = NULLTAG;
		tag_t RAXMODRAT_DesRev = NULLTAG;
		tag_t ENGMOD_DesRev = NULLTAG;
		char Buffer[MAX_LINE_LENGTH];
		char* username_str = NULL;
		char* password_str = NULL;
		char* group_str = NULL;
		char* username_strDup = NULL;
		char* password_strDup = NULL;
		char* group_strDup = NULL;
		FILE *fpPart_List = NULL;
		char *loggedInUser = NULL;

		//CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//CALLAPI(ITK_auto_login( ));
		//CALLAPI(ITK_set_journalling( TRUE ));
		printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
        //CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//CALLAPI(ITK_set_journalling( TRUE ));
		//CALLAPI(ITK_auto_login());
		//fpPart_List = fopen("/user/uaprodtrl/Sourav/WebServicePwfFile.txt","r");  //UAPRODTRL Login
		fpPart_List = fopen("/user/cvprod/sourav/WebServicePwfFile.txt","r");  //CVPRODTRL Login
		if(fpPart_List != NULL)
		{
			printf(" Input_File Not Null..!!\n");fflush(stdout);
			while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
			{
				username_str=strtok(Buffer,"^");
				password_str=strtok(NULL,"^");
				group_str=strtok(NULL,"^");
				
				if(username_str!=NULL)tc_strdup(username_str,&username_strDup);
				if(password_str!=NULL)tc_strdup(password_str,&password_strDup);
				if(group_str!=NULL)tc_strdup(group_str,&group_strDup);
				
				if(username_strDup!=NULL)trimwhitespace(username_strDup);
				if(password_strDup!=NULL)trimwhitespace(password_strDup);
				if(group_strDup!=NULL)trimwhitespace(group_strDup);
		    }
		}
		else 
		{
			printf("\n UserName & Password Input_File is NULL..!!\n");fflush(stdout);
		}
		fclose(fpPart_List);
		printf(" UserName & Password & Group Data read From File Done..!!\n");fflush(stdout);
	    CALLAPI(ITK_init_module(username_strDup, password_strDup, group_strDup));
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
		
		//PartNum=strtok(PartNumType,"^");
	    printf("\n Part Number String --------> %s", PartNum);fflush(stdout);
		trimwhitespace(PartNum);
		printf("\n Part Number After Trim --------> %s\n", PartNum);fflush(stdout);
		
		printf("\n [1]: Input Part Number ---> [%s]",PartNum);fflush(stdout);
		
		if(tc_strlen(PartNum)>0)
		{
			tc_strdup(PartNum,&PartNumber);
		}
		else
		{
			tc_strdup("NULL",&PartNumber);
			printf("\n Part No Value is NULL");fflush(stdout);
		}
		printf("\n Part Number Value After Dup --------> %s", PartNumber);fflush(stdout);
        trimwhitespace(PartNumber);
		printf("\n Part Number Value After Trim --------> %s", PartNumber);fflush(stdout);
		tc_strcpy(PartNumberDup,PartNumber);
		printf("\n Final Part Number After Trim & Dup --------> %s", PartNumberDup);fflush(stdout);
		
		printf("\n Finding Query[MCC_ERC_Released_Latest_Revision]..!!\n");fflush(stdout);
        ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
	    printf("\n Query[MCC_ERC_Released_Latest_Revision] Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[4]  = {"Item ID","Release Status","Part Type","Type"};
		char *cValues[4]  = {PartNumberDup,"T5_LcsErcRlzd","V","Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Latest ERC Released Total Vehicle Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			DesRev_tag = titemobj_results[m];
			ITK_CALL(AOM_ask_value_string(titemobj_results[m],"item_id",&item_id_str));
			if(tc_strlen(item_id_str)>0)
			{
				tc_strdup(item_id_str,&item_id_strDup);
				trimwhitespace(item_id_strDup);
			}
			else
			{
				tc_strdup("--",&item_id_strDup);
				printf("\n Vehicle Number Value is NULL..!!");fflush(stdout);
			}
			ITK_CALL(AOM_ask_value_string(titemobj_results[m],"item_revision_id",&item_revseq_str));
			if(tc_strlen(item_revseq_str)>0)
			{
				tc_strdup(item_revseq_str,&item_revseq_strDup);
				item_rev_strDup=strtok(item_revseq_strDup,";");
				item_seq_strDup=strtok(NULL,";");
				printf("\n Vehicle Rev Value After Token: [%s]\n", item_rev_strDup);fflush(stdout);
				printf("\n Vehicle Seq Value After Token: [%s]\n", item_seq_strDup);fflush(stdout);
			}
			else
			{
				tc_strdup("--",&item_revseq_strDup);
				tc_strdup("--",&item_rev_strDup);
				tc_strdup("--",&item_seq_strDup);
				printf("\n Vehicle Revision Sequence Value is NULL..!!");fflush(stdout);
			}
			
			ITK_CALL(AOM_ask_value_string(titemobj_results[m],"item_revision_id",&Newitem_revseq_str));
			if(tc_strlen(Newitem_revseq_str)>0)
			{
				tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
			}
			else
			{
				tc_strdup("--",&Newitem_revseq_strDup);
				printf("\n [New]Module Revision Sequence Value is NULL..!!");fflush(stdout);
			}
			
			ITK_CALL(AOM_ask_value_string(titemobj_results[m],"object_desc",&cItem_Desc));
			printf("\n Vehicle Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
			if(tc_strlen(cItem_Desc)>0)
			{
				tc_strdup(cItem_Desc,&cItem_DescDup);
			}
			else
			{
				tc_strdup("--",&cItem_DescDup);
				printf("\n Vehicle Description Value is NULL..!!");fflush(stdout);
			}
			trimwhitespace(cItem_DescDup);
			printf("\n Vehicle Description Value After Dup & Trim: --------> <%s>", cItem_DescDup);fflush(stdout);
			STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
			STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
			STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
			STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
			STRNG_replace_str(cItem_DescDup,""""," ",&cItem_DescDup);
			STRNG_replace_str(cItem_DescDup,"''"," ",&cItem_DescDup);
			printf("\n Vehicle Description Final Value: --------> [%s]\n", cItem_DescDup);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(titemobj_results[m],"t5_PartStatus",&DRStatus));
			if(tc_strlen(DRStatus)>0)
			{
				tc_strdup(DRStatus,&DRStatusDup);
			}
			else
			{
				tc_strdup("--",&DRStatusDup);
				printf("\n DR Status Value is NULL..!!");fflush(stdout);
			}
			
			ITK_CALL(AOM_ask_value_string(titemobj_results[m],"t5_Product",&Platform));
			if(tc_strlen(Platform)>0)
			{
				tc_strdup(Platform,&PlatformDup);
			}
			else
			{
				tc_strdup("--",&PlatformDup);
				printf("\n Platform Value is NULL..!!");fflush(stdout);
			}
			
			printf("\n Function1: Release Status List Find Start..!!\n");fflush(stdout);
			tc_strcpy(cItem_RevSeq,item_rev_strDup);
			tc_strcat(cItem_RevSeq,"*");
			tc_strcat(cItem_RevSeq,item_seq_strDup);
			printf("Item RevSeq: [%s] \n", cItem_RevSeq);fflush(stdout);
			cItem_LCDetails = TC_PartLCDetails(item_id_strDup,cItem_RevSeq);
			printf("\n Vehicle Release Status Value After Dup & Trim: [%s]", cItem_LCDetails);fflush(stdout);
			printf("\n Function1: Release Status List Find End..!!\n");fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(titemobj_results[m],"owning_user",&owner));
			if(tc_strlen(owner)>0)
			{
				tc_strdup(owner,&ownerDup);
			}
			else
			{
				tc_strdup("--",&ownerDup);
				printf("\n Owner Value is NULL..!!");fflush(stdout);
			}
			
			ITK_CALL(AOM_ask_value_date(titemobj_results[m],"last_mod_date",&Lastmoddate));
			ITK_CALL(DATE_date_to_string(Lastmoddate,"%d/%m/%Y",&LastmoddateDup));
				
			printf("\n Function2: Classification Attribute Find Start");fflush(stdout);
			tag_t Vc_spec_relation_type = NULLTAG;
			int vcspec_count_f = 0;
			tag_t* Vc_specObjects_f = NULLTAG;
			char *vcspec_item_id_f = NULL;
			char *vcclass_f = NULL;
			tag_t VehMstrTag = NULLTAG;
			int cnt	= 0;
			tag_t *ClsObjTag_results = NULLTAG;
			tag_t ClsObj_f = NULLTAG;
			
			tag_t FRRRTYREMstrTag = NULLTAG;
			tag_t FLTANKMstrTag = NULLTAG;
			tag_t GBMODTMstrTag = NULLTAG;
			tag_t RAXMODRATMstrTag = NULLTAG;
			tag_t ENGMODMstrTag = NULLTAG;
			int cnt1 = 0;
			int cnt2 = 0;
			int cnt3 = 0;
			int cnt4 = 0;
			int cnt5 = 0;
			tag_t *FRRRTYREClsObjTag_results = NULLTAG;
			tag_t *FLTANKClsObjTag_results = NULLTAG;
			tag_t *GBMODTClsObjTag_results = NULLTAG;
			tag_t *RAXMODRATClsObjTag_results = NULLTAG;
			tag_t *ENGMODClsObjTag_results = NULLTAG;
			tag_t FRRRTYREClsObj_f = NULLTAG;
			tag_t FLTANKClsObj_f = NULLTAG;
			tag_t GBMODTClsObj_f = NULLTAG;
			tag_t RAXMODRATClsObj_f = NULLTAG;
			tag_t ENGMODClsObj_f = NULLTAG;
			
			char *frtyreval = NULL;
			frtyreval = (char *) malloc(100*sizeof(char));
			char *wheelbaseval = NULL;
			wheelbaseval = (char *) malloc(100*sizeof(char));
			char *rrtyreval = NULL;
			rrtyreval = (char *) malloc(100*sizeof(char));
			char *cabbodyval = NULL;
			cabbodyval = (char *) malloc(100*sizeof(char));
			char *fueltankval = NULL;
			fueltankval = (char *) malloc(100*sizeof(char));
			char *suspensiontypeval = NULL;
			suspensiontypeval = (char *) malloc(100*sizeof(char));
			char *vehmakeval = NULL;
			vehmakeval = (char *) malloc(100*sizeof(char));
			char *vahanval = NULL;
			vahanval = (char *) malloc(100*sizeof(char));
			char *printonrcval = NULL;
			printonrcval = (char *) malloc(100*sizeof(char));
			char *acheatingval = NULL;
			acheatingval = (char *) malloc(100*sizeof(char));
			char *grossvehwtval = NULL;
			grossvehwtval = (char *) malloc(100*sizeof(char));
			char *loadbdytypeval = NULL;
			loadbdytypeval = (char *) malloc(100*sizeof(char));
			char *cmvrtypeval = NULL;
			cmvrtypeval = (char *) malloc(100*sizeof(char));
			char *gbmodeltypeval = NULL;
			gbmodeltypeval = (char *) malloc(100*sizeof(char));
			char *rearaxlemodtypeval = NULL;
			rearaxlemodtypeval = (char *) malloc(100*sizeof(char));
			char *rearaxleratiotypeval = NULL;
			rearaxleratiotypeval = (char *) malloc(100*sizeof(char));
			char *enginemodeltypeval = NULL;
			enginemodeltypeval = (char *) malloc(100*sizeof(char));
			char *variantval = NULL;
			variantval = (char *) malloc(100*sizeof(char));
			
			
			if(frtyreval!=NULL)trimwhitespace(frtyreval);
			if(wheelbaseval!=NULL)trimwhitespace(wheelbaseval);
			if(rrtyreval!=NULL)trimwhitespace(rrtyreval);
			if(cabbodyval!=NULL)trimwhitespace(cabbodyval);
			if(fueltankval!=NULL)trimwhitespace(fueltankval);
			if(suspensiontypeval!=NULL)trimwhitespace(suspensiontypeval);
			if(vehmakeval!=NULL)trimwhitespace(vehmakeval);
			if(vahanval!=NULL)trimwhitespace(vahanval);
			if(printonrcval!=NULL)trimwhitespace(printonrcval);
			if(acheatingval!=NULL)trimwhitespace(acheatingval);
			if(grossvehwtval!=NULL)trimwhitespace(grossvehwtval);
			if(loadbdytypeval!=NULL)trimwhitespace(loadbdytypeval);
			if(variantval!=NULL)trimwhitespace(variantval);
		
			ITK_CALL(GRM_find_relation_type("T5_VCSpec",&Vc_spec_relation_type));
			if(Vc_spec_relation_type != NULLTAG)
			{
				ITK_CALL(GRM_list_secondary_objects_only(DesRev_tag, Vc_spec_relation_type, &vcspec_count_f, &Vc_specObjects_f));
				printf("\n ----------------------------------------------");fflush(stdout);
				printf("\n Total Tech_Spech Attached with Vehicle: [%d]",vcspec_count_f);fflush(stdout);
				printf("\n ----------------------------------------------\n");fflush(stdout);
				if(vcspec_count_f > 0)
				{
					ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"item_id",&vcspec_item_id_f));
					printf("\n Tech_Spech No: [%s]\n",vcspec_item_id_f);fflush(stdout);
															
					ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"t5_VCClassName",&vcclass_f));
					printf("\n Vehicle Class: [%s]",vcclass_f);fflush(stdout);
					
					if(tc_strlen(vcclass_f) > 0)
					{
						char *getfrtyresizeval_id = NULL;
						getfrtyresizeval_id = (char *) malloc(100*sizeof(char));
						char *getwheelbaseval_id = NULL;
						getwheelbaseval_id = (char *) malloc(100*sizeof(char));
						char *getrrtyresizeval_id = NULL;
						getrrtyresizeval_id = (char *) malloc(100*sizeof(char));
						char *getcabbodyval_id = NULL;
						getcabbodyval_id = (char *) malloc(100*sizeof(char));
						char *getfueltankval_id = NULL;
						getfueltankval_id = (char *) malloc(100*sizeof(char));
						char *getsuspensiontypeval_id = NULL;
						getsuspensiontypeval_id = (char *) malloc(100*sizeof(char));
						char *getvehmakeval_id = NULL;
						getvehmakeval_id = (char *) malloc(100*sizeof(char));
						char *getvahanmodelval_id = NULL;
						getvahanmodelval_id = (char *) malloc(100*sizeof(char));
						char *getprintonrcval_id = NULL;
						getprintonrcval_id = (char *) malloc(100*sizeof(char));
						char *getacheatingval_id = NULL;
						getacheatingval_id = (char *) malloc(100*sizeof(char));
						char *getgrossvehwtval_id = NULL;
						getgrossvehwtval_id = (char *) malloc(100*sizeof(char));
						char *getloadbdytypeval_id = NULL;
						getloadbdytypeval_id = (char *) malloc(100*sizeof(char));
						char *getcmvrtypeval_id = NULL;
						getcmvrtypeval_id = (char *) malloc(100*sizeof(char));
						char *getgbmodeltypeval_id = NULL;
						getgbmodeltypeval_id = (char *) malloc(100*sizeof(char));
						char *getrearaxlemodtypeval_id = NULL;
						getrearaxlemodtypeval_id = (char *) malloc(100*sizeof(char));
						char *getrearaxleratiotypeval_id = NULL;
						getrearaxleratiotypeval_id = (char *) malloc(100*sizeof(char));
						char *getenginemodeltypeval_id = NULL;
						getenginemodeltypeval_id = (char *) malloc(100*sizeof(char));
						char *getvariantval_id = NULL;
						getvariantval_id = (char *) malloc(100*sizeof(char));
						
						if(tc_strcmp(vcclass_f,"MCV")==0)
						{
							printf("\n Attribute_ID Start: [MCV] \n");fflush(stdout);
							tc_strcpy(getfrtyresizeval_id,"5109");
							tc_strcpy(getwheelbaseval_id,"5068");
							tc_strcpy(getrrtyresizeval_id,"5105");
							tc_strcpy(getcabbodyval_id,"5008");
							tc_strcpy(getfueltankval_id,"5004");
							tc_strcpy(getsuspensiontypeval_id,"5090");
							tc_strcpy(getvehmakeval_id,"5205");
							tc_strcpy(getvahanmodelval_id,"5201");
							tc_strcpy(getprintonrcval_id,"5224");
							tc_strcpy(getacheatingval_id,"5156");
							tc_strcpy(getgrossvehwtval_id,"5165");
							tc_strcpy(getloadbdytypeval_id,"5177");
							tc_strcpy(getcmvrtypeval_id,"5171");
							tc_strcpy(getgbmodeltypeval_id,"5074");
							tc_strcpy(getrearaxlemodtypeval_id,"5011");
							tc_strcpy(getrearaxleratiotypeval_id,"5046");
							tc_strcpy(getenginemodeltypeval_id,"5015");
							tc_strcpy(getvariantval_id,"6243");
							
                            printf("\n getfrtyresizeval_id_MCV: [%s]",getfrtyresizeval_id);fflush(stdout);							
							printf("\n getwheelbaseval_id_MCV: [%s]",getwheelbaseval_id);fflush(stdout);
							printf("\n getrrtyresizeval_id_MCV: [%s]",getrrtyresizeval_id);fflush(stdout);
							printf("\n getcabbodyval_id_MCV: [%s]",getcabbodyval_id);fflush(stdout);
							printf("\n getfueltankval_id_MCV: [%s]",getfueltankval_id);fflush(stdout);
							printf("\n getsuspensiontypeval_id_MCV: [%s]",getsuspensiontypeval_id);fflush(stdout);
							printf("\n getvehmakeval_id_MCV: [%s]",getvehmakeval_id);fflush(stdout);
							printf("\n getvahanmodelval_id_MCV: [%s]",getvahanmodelval_id);fflush(stdout);
							printf("\n getprintonrcval_id_MCV: [%s]",getprintonrcval_id);fflush(stdout);
							printf("\n getacheatingval_id_MCV: [%s]",getacheatingval_id);fflush(stdout);
							printf("\n getgrossvehwtval_id_MCV: [%s]",getgrossvehwtval_id);fflush(stdout);
							printf("\n getloadbdytypeval_id_MCV: [%s]",getloadbdytypeval_id);fflush(stdout);
							printf("\n getcmvrtypeval_id_MCV: [%s]",getcmvrtypeval_id);fflush(stdout);
							printf("\n getgbmodeltypeval_id_MCV: [%s]",getgbmodeltypeval_id);fflush(stdout);
							printf("\n getrearaxlemodtypeval_id_MCV: [%s]",getrearaxlemodtypeval_id);fflush(stdout);
							printf("\n getrearaxleratiotypeval_id_MCV: [%s]",getrearaxleratiotypeval_id);fflush(stdout);
							printf("\n getenginemodeltypeval_id_MCV: [%s]",getenginemodeltypeval_id);fflush(stdout);
							printf("\n getvariantval_id_MCV: [%s]",getvariantval_id);fflush(stdout);
							printf("\n Attribute_ID End: [MCV] \n");fflush(stdout);
						}
						else if(tc_strcmp(vcclass_f,"HCV")==0)
						{
							printf("\n Attribute_ID Start: [HCV] \n");fflush(stdout);
							tc_strcpy(getfrtyresizeval_id,"6109");
							tc_strcpy(getwheelbaseval_id,"6068");
							tc_strcpy(getrrtyresizeval_id,"6105");
							tc_strcpy(getcabbodyval_id,"6008");
							tc_strcpy(getfueltankval_id,"6004");
							tc_strcpy(getsuspensiontypeval_id,"6090");
							tc_strcpy(getvehmakeval_id,"6205");
							tc_strcpy(getvahanmodelval_id,"6201");
							tc_strcpy(getprintonrcval_id,"6224");
							tc_strcpy(getacheatingval_id,"6156");
							tc_strcpy(getgrossvehwtval_id,"6165");
							tc_strcpy(getloadbdytypeval_id,"6177");
							tc_strcpy(getcmvrtypeval_id,"6171");
							tc_strcpy(getgbmodeltypeval_id,"6074");
							tc_strcpy(getrearaxlemodtypeval_id,"6011");
							tc_strcpy(getrearaxleratiotypeval_id,"6046");
							tc_strcpy(getenginemodeltypeval_id,"6015");
							tc_strcpy(getvariantval_id,"6243");
							
                            printf("\n getfrtyresizeval_id_HCV: [%s]",getfrtyresizeval_id);fflush(stdout);							
							printf("\n getwheelbaseval_id_HCV: [%s]",getwheelbaseval_id);fflush(stdout);
							printf("\n getrrtyresizeval_id_HCV: [%s]",getrrtyresizeval_id);fflush(stdout);
							printf("\n getcabbodyval_id_HCV: [%s]",getcabbodyval_id);fflush(stdout);
							printf("\n getfueltankval_id_HCV: [%s]",getfueltankval_id);fflush(stdout);
							printf("\n getsuspensiontypeval_id_HCV: [%s]",getsuspensiontypeval_id);fflush(stdout);
							printf("\n getvehmakeval_id_HCV: [%s]",getvehmakeval_id);fflush(stdout);
							printf("\n getvahanmodelval_id_HCV: [%s]",getvahanmodelval_id);fflush(stdout);
							printf("\n getprintonrcval_id_HCV: [%s]",getprintonrcval_id);fflush(stdout);
							printf("\n getacheatingval_id_HCV: [%s]",getacheatingval_id);fflush(stdout);
							printf("\n getgrossvehwtval_id_HCV: [%s]",getgrossvehwtval_id);fflush(stdout);
							printf("\n getloadbdytypeval_id_HCV: [%s]",getloadbdytypeval_id);fflush(stdout);
							printf("\n getcmvrtypeval_id_HCV: [%s]",getcmvrtypeval_id);fflush(stdout);
							printf("\n getgbmodeltypeval_id_HCV: [%s]",getgbmodeltypeval_id);fflush(stdout);
							printf("\n getrearaxlemodtypeval_id_HCV: [%s]",getrearaxlemodtypeval_id);fflush(stdout);
							printf("\n getrearaxleratiotypeval_id_HCV: [%s]",getrearaxleratiotypeval_id);fflush(stdout);
							printf("\n getenginemodeltypeval_id_HCV: [%s]",getenginemodeltypeval_id);fflush(stdout);
							printf("\n getvariantval_id_HCV: [%s]",getvariantval_id);fflush(stdout);
							printf("\n Attribute_ID End: [HCV] \n");fflush(stdout);
						}
						else if(tc_strcmp(vcclass_f,"LCV")==0)
						{
							printf("\n Attribute_ID Start: [LCV] \n");fflush(stdout);
							tc_strcpy(getfrtyresizeval_id,"4109");
							tc_strcpy(getwheelbaseval_id,"4068");
							tc_strcpy(getrrtyresizeval_id,"4105");
							tc_strcpy(getcabbodyval_id,"4008");
							tc_strcpy(getfueltankval_id,"4004");
							tc_strcpy(getsuspensiontypeval_id,"4090");
							tc_strcpy(getvehmakeval_id,"4205");
							tc_strcpy(getvahanmodelval_id,"4201");
							tc_strcpy(getprintonrcval_id,"4224");
							tc_strcpy(getacheatingval_id,"4156");
							tc_strcpy(getgrossvehwtval_id,"4165");
							tc_strcpy(getloadbdytypeval_id,"4177");
							tc_strcpy(getcmvrtypeval_id,"4171");
							tc_strcpy(getgbmodeltypeval_id,"4074");
							tc_strcpy(getrearaxlemodtypeval_id,"4011");
							tc_strcpy(getrearaxleratiotypeval_id,"4046");
							tc_strcpy(getenginemodeltypeval_id,"4015");
							tc_strcpy(getvariantval_id,"6243");
							
                            printf("\n getfrtyresizeval_id_LCV: [%s]",getfrtyresizeval_id);fflush(stdout);							
							printf("\n getwheelbaseval_id_LCV: [%s]",getwheelbaseval_id);fflush(stdout);
							printf("\n getrrtyresizeval_id_LCV: [%s]",getrrtyresizeval_id);fflush(stdout);
							printf("\n getcabbodyval_id_LCV: [%s]",getcabbodyval_id);fflush(stdout);
							printf("\n getfueltankval_id_LCV: [%s]",getfueltankval_id);fflush(stdout);
							printf("\n getsuspensiontypeval_id_LCV: [%s]",getsuspensiontypeval_id);fflush(stdout);
							printf("\n getvehmakeval_id_LCV: [%s]",getvehmakeval_id);fflush(stdout);
							printf("\n getvahanmodelval_id_LCV: [%s]",getvahanmodelval_id);fflush(stdout);
							printf("\n getprintonrcval_id_LCV: [%s]",getprintonrcval_id);fflush(stdout);
							printf("\n getacheatingval_id_LCV: [%s]",getacheatingval_id);fflush(stdout);
							printf("\n getgrossvehwtval_id_LCV: [%s]",getgrossvehwtval_id);fflush(stdout);
							printf("\n getloadbdytypeval_id_LCV: [%s]",getloadbdytypeval_id);fflush(stdout);
							printf("\n getcmvrtypeval_id_LCV: [%s]",getcmvrtypeval_id);fflush(stdout);
							printf("\n getgbmodeltypeval_id_LCV: [%s]",getgbmodeltypeval_id);fflush(stdout);
							printf("\n getrearaxlemodtypeval_id_LCV: [%s]",getrearaxlemodtypeval_id);fflush(stdout);
							printf("\n getrearaxleratiotypeval_id_LCV: [%s]",getrearaxleratiotypeval_id);fflush(stdout);
							printf("\n getenginemodeltypeval_id_LCV: [%s]",getenginemodeltypeval_id);fflush(stdout);
							printf("\n getvariantval_id_LCV: [%s]",getvariantval_id);fflush(stdout);
							printf("\n Attribute_ID End: [LCV] \n");fflush(stdout);
						}
						else if(tc_strcmp(vcclass_f,"LMV")==0)
						{
							printf("\n Attribute_ID Start: [LMV] \n");fflush(stdout);
							tc_strcpy(getfrtyresizeval_id,"2109");
							tc_strcpy(getwheelbaseval_id,"2068");
							tc_strcpy(getrrtyresizeval_id,"2105");
							tc_strcpy(getcabbodyval_id,"2008");
							tc_strcpy(getfueltankval_id,"2004");
							tc_strcpy(getsuspensiontypeval_id,"2090");
							tc_strcpy(getvehmakeval_id,"2205");
							tc_strcpy(getvahanmodelval_id,"2201");
							tc_strcpy(getprintonrcval_id,"2224");
							tc_strcpy(getacheatingval_id,"2156");
							tc_strcpy(getgrossvehwtval_id,"2165");
							tc_strcpy(getloadbdytypeval_id,"2177");
							tc_strcpy(getcmvrtypeval_id,"2171");
							tc_strcpy(getgbmodeltypeval_id,"2074");
							tc_strcpy(getrearaxlemodtypeval_id,"2011");
							tc_strcpy(getrearaxleratiotypeval_id,"2046");
							tc_strcpy(getenginemodeltypeval_id,"2015");
							tc_strcpy(getvariantval_id,"6243");
							
                            printf("\n getfrtyresizeval_id_LMV: [%s]",getfrtyresizeval_id);fflush(stdout);							
							printf("\n getwheelbaseval_id_LMV: [%s]",getwheelbaseval_id);fflush(stdout);
							printf("\n getrrtyresizeval_id_LMV: [%s]",getrrtyresizeval_id);fflush(stdout);
							printf("\n getcabbodyval_id_LMV: [%s]",getcabbodyval_id);fflush(stdout);
							printf("\n getfueltankval_id_LMV: [%s]",getfueltankval_id);fflush(stdout);
							printf("\n getsuspensiontypeval_id_LMV: [%s]",getsuspensiontypeval_id);fflush(stdout);
							printf("\n getvehmakeval_id_LMV: [%s]",getvehmakeval_id);fflush(stdout);
							printf("\n getvahanmodelval_id_LMV: [%s]",getvahanmodelval_id);fflush(stdout);
							printf("\n getprintonrcval_id_LMV: [%s]",getprintonrcval_id);fflush(stdout);
							printf("\n getacheatingval_id_LMV: [%s]",getacheatingval_id);fflush(stdout);
							printf("\n getgrossvehwtval_id_LMV: [%s]",getgrossvehwtval_id);fflush(stdout);
							printf("\n getloadbdytypeval_id_LMV: [%s]",getloadbdytypeval_id);fflush(stdout);
							printf("\n getcmvrtypeval_id_LMV: [%s]",getcmvrtypeval_id);fflush(stdout);
							printf("\n getgbmodeltypeval_id_LMV: [%s]",getgbmodeltypeval_id);fflush(stdout);
							printf("\n getrearaxlemodtypeval_id_LMV: [%s]",getrearaxlemodtypeval_id);fflush(stdout);
							printf("\n getrearaxleratiotypeval_id_LMV: [%s]",getrearaxleratiotypeval_id);fflush(stdout);
							printf("\n getenginemodeltypeval_id_LMV: [%s]",getenginemodeltypeval_id);fflush(stdout);
							printf("\n getvariantval_id_LMV: [%s]",getvariantval_id);fflush(stdout);
							printf("\n Attribute_ID End: [LMV] \n");fflush(stdout);
						}
						else if(tc_strcmp(vcclass_f,"BUS")==0)
						{
							printf("\n Attribute_ID Start: [BUS] \n");fflush(stdout);
							tc_strcpy(getfrtyresizeval_id,"7109");
							tc_strcpy(getwheelbaseval_id,"7068");
							tc_strcpy(getrrtyresizeval_id,"7105");
							tc_strcpy(getcabbodyval_id,"7008");
							tc_strcpy(getfueltankval_id,"7004");
							tc_strcpy(getsuspensiontypeval_id,"7090");
							tc_strcpy(getvehmakeval_id,"7205");
							tc_strcpy(getvahanmodelval_id,"7201");
							tc_strcpy(getprintonrcval_id,"7224");
							tc_strcpy(getacheatingval_id,"7156");
							tc_strcpy(getgrossvehwtval_id,"7165");
							tc_strcpy(getloadbdytypeval_id,"7177");
							tc_strcpy(getcmvrtypeval_id,"7171");
							tc_strcpy(getgbmodeltypeval_id,"7074");
							tc_strcpy(getrearaxlemodtypeval_id,"7011");
							tc_strcpy(getrearaxleratiotypeval_id,"7046");
							tc_strcpy(getenginemodeltypeval_id,"7015");
							tc_strcpy(getvariantval_id,"6243");
							
                            printf("\n getfrtyresizeval_id_BUS: [%s]",getfrtyresizeval_id);fflush(stdout);							
							printf("\n getwheelbaseval_id_BUS: [%s]",getwheelbaseval_id);fflush(stdout);
							printf("\n getrrtyresizeval_id_BUS: [%s]",getrrtyresizeval_id);fflush(stdout);
							printf("\n getcabbodyval_id_BUS: [%s]",getcabbodyval_id);fflush(stdout);
							printf("\n getfueltankval_id_BUS: [%s]",getfueltankval_id);fflush(stdout);
							printf("\n getsuspensiontypeval_id_BUS: [%s]",getsuspensiontypeval_id);fflush(stdout);
							printf("\n getvehmakeval_id_BUS: [%s]",getvehmakeval_id);fflush(stdout);
							printf("\n getvahanmodelval_id_BUS: [%s]",getvahanmodelval_id);fflush(stdout);
							printf("\n getprintonrcval_id_BUS: [%s]",getprintonrcval_id);fflush(stdout);
							printf("\n getacheatingval_id_BUS: [%s]",getacheatingval_id);fflush(stdout);
							printf("\n getgrossvehwtval_id_BUS: [%s]",getgrossvehwtval_id);fflush(stdout);
							printf("\n getloadbdytypeval_id_BUS: [%s]",getloadbdytypeval_id);fflush(stdout);
							printf("\n getcmvrtypeval_id_BUS: [%s]",getcmvrtypeval_id);fflush(stdout);
							printf("\n getgbmodeltypeval_id_BUS: [%s]",getgbmodeltypeval_id);fflush(stdout);
							printf("\n getrearaxlemodtypeval_id_BUS: [%s]",getrearaxlemodtypeval_id);fflush(stdout);
							printf("\n getrearaxleratiotypeval_id_BUS: [%s]",getrearaxleratiotypeval_id);fflush(stdout);
							printf("\n getenginemodeltypeval_id_BUS: [%s]",getenginemodeltypeval_id);fflush(stdout);
							printf("\n getvariantval_id_BUS: [%s]",getvariantval_id);fflush(stdout);
							printf("\n Attribute_ID End: [BUS] \n");fflush(stdout);
						}
						else if(tc_strcmp(vcclass_f,"UV_VAN")==0)
						{
							printf("\n Attribute_ID Start: [UV_VAN] \n");fflush(stdout);
							tc_strcpy(getfrtyresizeval_id,"10109");
							tc_strcpy(getwheelbaseval_id,"10068");
							tc_strcpy(getrrtyresizeval_id,"10105");
							tc_strcpy(getcabbodyval_id,"10008");
							tc_strcpy(getfueltankval_id,"10004");
							tc_strcpy(getsuspensiontypeval_id,"10090");
							tc_strcpy(getvehmakeval_id,"10205");
							tc_strcpy(getvahanmodelval_id,"10201");
							tc_strcpy(getprintonrcval_id,"10224");
							tc_strcpy(getacheatingval_id,"10156");
							tc_strcpy(getgrossvehwtval_id,"10165");
							tc_strcpy(getloadbdytypeval_id,"10177");
							tc_strcpy(getcmvrtypeval_id,"10171");
							tc_strcpy(getgbmodeltypeval_id,"10074");
							tc_strcpy(getrearaxlemodtypeval_id,"10011");
							tc_strcpy(getrearaxleratiotypeval_id,"10046");
							tc_strcpy(getenginemodeltypeval_id,"10015");
							tc_strcpy(getvariantval_id,"6243");
							
                            printf("\n getfrtyresizeval_id_UV_VAN: [%s]",getfrtyresizeval_id);fflush(stdout);							
							printf("\n getwheelbaseval_id_UV_VAN: [%s]",getwheelbaseval_id);fflush(stdout);
							printf("\n getrrtyresizeval_id_UV_VAN: [%s]",getrrtyresizeval_id);fflush(stdout);
							printf("\n getcabbodyval_id_UV_VAN: [%s]",getcabbodyval_id);fflush(stdout);
							printf("\n getfueltankval_id_UV_VAN: [%s]",getfueltankval_id);fflush(stdout);
							printf("\n getsuspensiontypeval_id_UV_VAN: [%s]",getsuspensiontypeval_id);fflush(stdout);
							printf("\n getvehmakeval_id_UV_VAN: [%s]",getvehmakeval_id);fflush(stdout);
							printf("\n getvahanmodelval_id_UV_VAN: [%s]",getvahanmodelval_id);fflush(stdout);
							printf("\n getprintonrcval_id_UV_VAN: [%s]",getprintonrcval_id);fflush(stdout);
							printf("\n getacheatingval_id_UV_VAN: [%s]",getacheatingval_id);fflush(stdout);
							printf("\n getgrossvehwtval_id_UV_VAN: [%s]",getgrossvehwtval_id);fflush(stdout);
							printf("\n getloadbdytypeval_id_UV_VAN: [%s]",getloadbdytypeval_id);fflush(stdout);
							printf("\n getcmvrtypeval_id_UV_VAN: [%s]",getcmvrtypeval_id);fflush(stdout);
							printf("\n getgbmodeltypeval_id_UV_VAN: [%s]",getgbmodeltypeval_id);fflush(stdout);
							printf("\n getrearaxlemodtypeval_id_UV_VAN: [%s]",getrearaxlemodtypeval_id);fflush(stdout);
							printf("\n getrearaxleratiotypeval_id_UV_VAN: [%s]",getrearaxleratiotypeval_id);fflush(stdout);
							printf("\n getenginemodeltypeval_id_UV_VAN: [%s]",getenginemodeltypeval_id);fflush(stdout);
							printf("\n getvariantval_id_UV_VAN: [%s]",getvariantval_id);fflush(stdout);
							printf("\n Attribute_ID End: [UV_VAN] \n");fflush(stdout);
						}
						else if(tc_strcmp(vcclass_f,"ICV")==0)
						{
							printf("\n Attribute_ID Start: [ICV] \n");fflush(stdout);
							tc_strcpy(getfrtyresizeval_id,"3109");
							tc_strcpy(getwheelbaseval_id,"3068");
							tc_strcpy(getrrtyresizeval_id,"3105");
							tc_strcpy(getcabbodyval_id,"3008");
							tc_strcpy(getfueltankval_id,"3004");
							tc_strcpy(getsuspensiontypeval_id,"3090");
							tc_strcpy(getvehmakeval_id,"3205");
							tc_strcpy(getvahanmodelval_id,"3201");
							tc_strcpy(getprintonrcval_id,"3224");
							tc_strcpy(getacheatingval_id,"3156");
							tc_strcpy(getgrossvehwtval_id,"3165");
							tc_strcpy(getloadbdytypeval_id,"3177");
							tc_strcpy(getcmvrtypeval_id,"3171");
							tc_strcpy(getgbmodeltypeval_id,"3074");
							tc_strcpy(getrearaxlemodtypeval_id,"3011");
							tc_strcpy(getrearaxleratiotypeval_id,"3046");
							tc_strcpy(getenginemodeltypeval_id,"3015");
							tc_strcpy(getvariantval_id,"6243");
							
                            printf("\n getfrtyresizeval_id_ICV: [%s]",getfrtyresizeval_id);fflush(stdout);							
							printf("\n getwheelbaseval_id_ICV: [%s]",getwheelbaseval_id);fflush(stdout);
							printf("\n getrrtyresizeval_id_ICV: [%s]",getrrtyresizeval_id);fflush(stdout);
							printf("\n getcabbodyval_id_ICV: [%s]",getcabbodyval_id);fflush(stdout);
							printf("\n getfueltankval_id_ICV: [%s]",getfueltankval_id);fflush(stdout);
							printf("\n getsuspensiontypeval_id_ICV: [%s]",getsuspensiontypeval_id);fflush(stdout);
							printf("\n getvehmakeval_id_ICV: [%s]",getvehmakeval_id);fflush(stdout);
							printf("\n getvahanmodelval_id_ICV: [%s]",getvahanmodelval_id);fflush(stdout);
							printf("\n getprintonrcval_id_ICV: [%s]",getprintonrcval_id);fflush(stdout);
							printf("\n getacheatingval_id_ICV: [%s]",getacheatingval_id);fflush(stdout);
							printf("\n getgrossvehwtval_id_ICV: [%s]",getgrossvehwtval_id);fflush(stdout);
							printf("\n getloadbdytypeval_id_ICV: [%s]",getloadbdytypeval_id);fflush(stdout);
							printf("\n getcmvrtypeval_id_ICV: [%s]",getcmvrtypeval_id);fflush(stdout);
							printf("\n getgbmodeltypeval_id_ICV: [%s]",getgbmodeltypeval_id);fflush(stdout);
							printf("\n getrearaxlemodtypeval_id_ICV: [%s]",getrearaxlemodtypeval_id);fflush(stdout);
							printf("\n getrearaxleratiotypeval_id_ICV: [%s]",getrearaxleratiotypeval_id);fflush(stdout);
							printf("\n getenginemodeltypeval_id_ICV [%s]",getenginemodeltypeval_id);fflush(stdout);
							printf("\n getvariantval_id_ICV: [%s]",getvariantval_id);fflush(stdout);
							printf("\n Attribute_ID End: [ICV] \n");fflush(stdout);
						}
						else
						{
							printf("\n VC Class Not Matched..!! \n");fflush(stdout);
						}
						
						printf("\n Function4: Vehicle Child Details Find Start\n");fflush(stdout);
						TC_VehChild_Details(item_id_strDup,item_rev_strDup,item_seq_strDup,Newitem_revseq_strDup);
						printf("\n Function4: Vehicle Child Details Find End\n");fflush(stdout);
						
						printf("\n Function5: SubModule Tag Details Find Start\n");fflush(stdout);
						printf("\n FRRRTYRE_DesRev: [%s]\n", FRRRTYREMOD); fflush(stdout);
						printf("\n FLTANK_DesRev: [%s]\n", FLTANKMOD); fflush(stdout);
						printf("\n GBMODT_DesRev: [%s]\n", GBMODTMOD); fflush(stdout);
						printf("\n RAXMODRAT_DesRev: [%s]\n", RAXMODRATMOD); fflush(stdout);
						printf("\n ENGMOD_DesRev: [%s]\n", ENGMODMOD); fflush(stdout);
						FRRRTYRE_DesRev = TC_ModuleTag_Details(FRRRTYREMOD);
						FLTANK_DesRev = TC_ModuleTag_Details(FLTANKMOD);
						GBMODT_DesRev = TC_ModuleTag_Details(GBMODTMOD);
						RAXMODRAT_DesRev = TC_ModuleTag_Details(RAXMODRATMOD);
						ENGMOD_DesRev = TC_ModuleTag_Details(ENGMODMOD);
						printf("\n Function5: SubModule Tag Details Find End\n");fflush(stdout);
						
						ITK_CALL(ITEM_ask_item_of_rev(FRRRTYRE_DesRev,&FRRRTYREMstrTag));
						ITK_CALL(AOM_ask_value_tags(FRRRTYREMstrTag,"IMAN_classification",&cnt1,&FRRRTYREClsObjTag_results));
						ITK_CALL(ITEM_ask_item_of_rev(FLTANK_DesRev,&FLTANKMstrTag));
						ITK_CALL(AOM_ask_value_tags(FLTANKMstrTag,"IMAN_classification",&cnt2,&FLTANKClsObjTag_results));
						ITK_CALL(ITEM_ask_item_of_rev(GBMODT_DesRev,&GBMODTMstrTag));
						ITK_CALL(AOM_ask_value_tags(GBMODTMstrTag,"IMAN_classification",&cnt3,&GBMODTClsObjTag_results));
						ITK_CALL(ITEM_ask_item_of_rev(RAXMODRAT_DesRev,&RAXMODRATMstrTag));
						ITK_CALL(AOM_ask_value_tags(RAXMODRATMstrTag,"IMAN_classification",&cnt4,&RAXMODRATClsObjTag_results));
						ITK_CALL(ITEM_ask_item_of_rev(ENGMOD_DesRev,&ENGMODMstrTag));
						ITK_CALL(AOM_ask_value_tags(ENGMODMstrTag,"IMAN_classification",&cnt5,&ENGMODClsObjTag_results));
						
						FRRRTYREClsObj_f=*FRRRTYREClsObjTag_results;
						FLTANKClsObj_f=*FLTANKClsObjTag_results;
						GBMODTClsObj_f=*GBMODTClsObjTag_results;
						RAXMODRATClsObj_f=*RAXMODRATClsObjTag_results;
						ENGMODClsObj_f=*ENGMODClsObjTag_results;
						
						ITK_CALL(ITEM_ask_item_of_rev(DesRev_tag,&VehMstrTag));
						ITK_CALL(AOM_ask_value_tags(VehMstrTag,"IMAN_classification",&cnt,&ClsObjTag_results));
						printf("\n Vehicle Master Object Count: [%d]\n", cnt); fflush(stdout);
						if(cnt > 0)
						{
							ClsObj_f=*ClsObjTag_results;	
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getwheelbaseval_id,&wheelbaseval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getcabbodyval_id,&cabbodyval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getsuspensiontypeval_id,&suspensiontypeval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getvehmakeval_id,&vehmakeval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getvahanmodelval_id,&vahanval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getprintonrcval_id,&printonrcval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getacheatingval_id,&acheatingval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getgrossvehwtval_id,&grossvehwtval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getloadbdytypeval_id,&loadbdytypeval));
							ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getcmvrtypeval_id,&cmvrtypeval));
							ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getvariantval_id,&variantval));
							
							frtyreval = getClsValueFrmICSTag_new(FRRRTYREMstrTag,"[VC]FR_TYRE_SIZE");
							rrtyreval = getClsValueFrmICSTag_new(FRRRTYREMstrTag,"[VC]RR_TYRE_SIZE");
							//ITK_CALL(getClsValueFrmICSTag(FRRRTYREClsObj_f,getfrtyresizeval_id,&frtyreval));
							//ITK_CALL(getClsValueFrmICSTag(FRRRTYREClsObj_f,getrrtyresizeval_id,&rrtyreval));
							ITK_CALL(getClsValueFrmICSTag(FLTANKClsObj_f,getfueltankval_id,&fueltankval));
							ITK_CALL(getClsValueFrmICSTag(GBMODTClsObj_f,getgbmodeltypeval_id,&gbmodeltypeval));
							ITK_CALL(getClsValueFrmICSTag(RAXMODRATClsObj_f,getrearaxlemodtypeval_id,&rearaxlemodtypeval));
							ITK_CALL(getClsValueFrmICSTag(RAXMODRATClsObj_f,getrearaxleratiotypeval_id,&rearaxleratiotypeval));
							//ITK_CALL(getClsValueFrmICSTag(ENGMODClsObj_f,getenginemodeltypeval_id,&enginemodeltypeval));
							enginemodeltypeval = getClsValueFrmICSTag_new(ENGMODMstrTag,"[VC]Engine Model");
							
							if(frtyreval!=NULL)trimwhitespace(frtyreval);
							if(wheelbaseval!=NULL)trimwhitespace(wheelbaseval);
							if(rrtyreval!=NULL)trimwhitespace(rrtyreval);
                            if(cabbodyval!=NULL)trimwhitespace(cabbodyval);
							if(fueltankval!=NULL)trimwhitespace(fueltankval);
                            if(suspensiontypeval!=NULL)trimwhitespace(suspensiontypeval);
                            if(vehmakeval!=NULL)trimwhitespace(vehmakeval);
                            if(vahanval!=NULL)trimwhitespace(vahanval);
                            if(printonrcval!=NULL)trimwhitespace(printonrcval);
                            if(acheatingval!=NULL)trimwhitespace(acheatingval);
                            if(grossvehwtval!=NULL)trimwhitespace(grossvehwtval);
                            if(loadbdytypeval!=NULL)trimwhitespace(loadbdytypeval);
							if(cmvrtypeval!=NULL)trimwhitespace(cmvrtypeval);
							if(gbmodeltypeval!=NULL)trimwhitespace(gbmodeltypeval);
							if(rearaxlemodtypeval!=NULL)trimwhitespace(rearaxlemodtypeval);
							if(rearaxleratiotypeval!=NULL)trimwhitespace(rearaxleratiotypeval);
							if(enginemodeltypeval!=NULL)trimwhitespace(enginemodeltypeval);
                            if(variantval!=NULL)trimwhitespace(variantval);	
							
							printf("\n [VC]FR_TYRE_SIZE: [%s]",frtyreval);fflush(stdout);
							printf("\n [VC]Wheel Base(WHEEL_BASE_IN_MM): [%s]",wheelbaseval);fflush(stdout);
							printf("\n [VC]RR_TYRE_SIZE: [%s]",rrtyreval); fflush(stdout);
							printf("\n [VC]CAB_BODY(CAB_BODY): [%s]",cabbodyval); fflush(stdout);
							printf("\n [VC]FuelTank Capacity(FUELTANK): [%s]",fueltankval);fflush(stdout);
							printf("\n [VC]Type(SUSPENSION_TYPE): [%s]",suspensiontypeval);fflush(stdout);
							printf("\n VEHICLE MAKE: [%s]",vehmakeval); fflush(stdout);
							printf("\n VAHAN MODEL NAME: [%s]",vahanval); fflush(stdout);
							printf("\n MODEL NAME TO BE PRINTED ON RC : [%s]",printonrcval); fflush(stdout);
							printf("\n [VC]AC HEATING/DEMIST : [%s]",acheatingval); fflush(stdout);
							printf("\n [VC]GROSS VEHICLE WEIGHT : [%s]",grossvehwtval); fflush(stdout);
							printf("\n LOAD_BODY_TYPE : [%s]",loadbdytypeval); fflush(stdout);
							printf("\n CMVR_TYP_APPRVL_NO : [%s]",cmvrtypeval); fflush(stdout);
							printf("\n Specs-Gearbox Model(GB_MODEL) : [%s]",gbmodeltypeval); fflush(stdout);
							printf("\n [VC]Specs-Rear Axle Model(REAR_AXLE_MODEL) : [%s]",rearaxlemodtypeval); fflush(stdout);
							printf("\n [VC]Specs-Rear Axle Ratio(REAR_AXLE_RATIO) : [%s]",rearaxleratiotypeval); fflush(stdout);
							printf("\n [VC]Engine Model : [%s]",enginemodeltypeval); fflush(stdout);
							printf("\n VARIANT : [%s]",variantval); fflush(stdout);
						}
						else
						{
							printf("\n VC Master Not Found..!! \n");fflush(stdout);
							tc_strcpy(frtyreval,"--");
							tc_strcpy(wheelbaseval,"--");
							tc_strcpy(rrtyreval,"--");
							tc_strcpy(cabbodyval,"--");
							tc_strcpy(fueltankval,"--");
							tc_strcpy(suspensiontypeval,"--");
							tc_strcpy(vehmakeval,"--");
							tc_strcpy(vahanval,"--");
							tc_strcpy(printonrcval,"--");
							tc_strcpy(acheatingval,"--");
							tc_strcpy(grossvehwtval,"--");
							tc_strcpy(loadbdytypeval,"--");
							tc_strcpy(cmvrtypeval,"--");
							tc_strcpy(gbmodeltypeval,"--");
							tc_strcpy(rearaxlemodtypeval,"--");
							tc_strcpy(rearaxleratiotypeval,"--");
							tc_strcpy(enginemodeltypeval,"--");
							tc_strcpy(variantval,"--");
						}				
					}
					else
					{
						printf("\n VC Class Not Found..!! \n");fflush(stdout);
						tc_strcpy(frtyreval,"--");
						tc_strcpy(wheelbaseval,"--");
						tc_strcpy(rrtyreval,"--");
						tc_strcpy(cabbodyval,"--");
						tc_strcpy(fueltankval,"--");
						tc_strcpy(suspensiontypeval,"--");
						tc_strcpy(vehmakeval,"--");
						tc_strcpy(vahanval,"--");
						tc_strcpy(printonrcval,"--");
						tc_strcpy(acheatingval,"--");
						tc_strcpy(grossvehwtval,"--");
						tc_strcpy(loadbdytypeval,"--");
						tc_strcpy(cmvrtypeval,"--");
						tc_strcpy(gbmodeltypeval,"--");
						tc_strcpy(rearaxlemodtypeval,"--");
						tc_strcpy(rearaxleratiotypeval,"--");
						tc_strcpy(enginemodeltypeval,"--");
						tc_strcpy(variantval,"--");
					}
				}
				else
				{
					printf("\n No Tech_Spech Attached with Vehicle..!! \n");fflush(stdout);
					tc_strcpy(frtyreval,"--");
					tc_strcpy(wheelbaseval,"--");
					tc_strcpy(rrtyreval,"--");
					tc_strcpy(cabbodyval,"--");
					tc_strcpy(fueltankval,"--");
					tc_strcpy(suspensiontypeval,"--");
					tc_strcpy(vehmakeval,"--");
					tc_strcpy(vahanval,"--");
					tc_strcpy(printonrcval,"--");
					tc_strcpy(acheatingval,"--");
					tc_strcpy(grossvehwtval,"--");
					tc_strcpy(loadbdytypeval,"--");
					tc_strcpy(cmvrtypeval,"--");
					tc_strcpy(gbmodeltypeval,"--");
					tc_strcpy(rearaxlemodtypeval,"--");
					tc_strcpy(rearaxleratiotypeval,"--");
					tc_strcpy(enginemodeltypeval,"--");
					tc_strcpy(variantval,"--");
				}
			}
			printf("\n Function3: Classification Attribute Find End");fflush(stdout);
				
				
			responseString1=(char *)MEM_alloc(200);
			responseString2=(char *)MEM_alloc(200);
			responseString3=(char *)MEM_alloc(200);
			responseString4=(char *)MEM_alloc(200);
			responseString5=(char *)MEM_alloc(200);
			responseString6=(char *)MEM_alloc(200);
			responseString7=(char *)MEM_alloc(200);
			responseString8=(char *)MEM_alloc(200);
			responseString9=(char *)MEM_alloc(200);
			responseString10=(char *)MEM_alloc(200);
			responseString11=(char *)MEM_alloc(200);
			responseString12=(char *)MEM_alloc(200);
			responseString13=(char *)MEM_alloc(200);
			responseString14=(char *)MEM_alloc(200);
			responseString15=(char *)MEM_alloc(200);
			responseString16=(char *)MEM_alloc(200);
			responseString17=(char *)MEM_alloc(200);
			responseString18=(char *)MEM_alloc(200);
			responseString19=(char *)MEM_alloc(200);
			responseString20=(char *)MEM_alloc(200);
			responseString21=(char *)MEM_alloc(200);
			responseString22=(char *)MEM_alloc(200);
			responseString23=(char *)MEM_alloc(200);
			responseString24=(char *)MEM_alloc(200);
			responseString25=(char *)MEM_alloc(200);
			responseString26=(char *)MEM_alloc(200);
			responseString27=(char *)MEM_alloc(200);
			
			printf("\n Again Printing: Input Part Number: -----> <%s> \n",PartNumberDup);fflush(stdout);
			tc_strcpy(responseString1,"PartNumber=");
			tc_strcat(responseString1,PartNumberDup);
			setAddStr(&tt1,&ReportSetSTR,responseString1);
			
			tc_strcpy(responseString2,"Revision=");
			tc_strcat(responseString2,item_rev_strDup);
			setAddStr(&tt1,&ReportSetSTR,responseString2);
			
			tc_strcpy(responseString3,"Sequence=");
			tc_strcat(responseString3,item_seq_strDup);
			setAddStr(&tt1,&ReportSetSTR,responseString3);
			
			tc_strcpy(responseString4,"Description=");
			tc_strcat(responseString4,cItem_DescDup);
			setAddStr(&tt1,&ReportSetSTR,responseString4);
			
			tc_strcpy(responseString5,"DR/AR Status=");
			tc_strcat(responseString5,DRStatusDup);
			setAddStr(&tt1,&ReportSetSTR,responseString5);
			
			tc_strcpy(responseString6,"BU=");
			tc_strcat(responseString6,PlatformDup);
			setAddStr(&tt1,&ReportSetSTR,responseString6);
			
			tc_strcpy(responseString7,"LifeCycleState=");
			tc_strcat(responseString7,cItem_LCDetails);
			setAddStr(&tt1,&ReportSetSTR,responseString7);
			
			tc_strcpy(responseString8,"Owner=");
			tc_strcat(responseString8,ownerDup);
			setAddStr(&tt1,&ReportSetSTR,responseString8);
			
			tc_strcpy(responseString9,"LastUpdate=");
			tc_strcat(responseString9,LastmoddateDup);
			setAddStr(&tt1,&ReportSetSTR,responseString9);
			
			tc_strcpy(responseString10,"FR_TYRE_SIZE=");
			tc_strcat(responseString10,frtyreval);
			setAddStr(&tt1,&ReportSetSTR,responseString10);
			
			tc_strcpy(responseString11,"Wheel Base(WHEEL_BASE_IN_MM)=");
			tc_strcat(responseString11,wheelbaseval);
			setAddStr(&tt1,&ReportSetSTR,responseString11);
			
			tc_strcpy(responseString12,"RR_TYRE_SIZE=");
			tc_strcat(responseString12,rrtyreval);
			setAddStr(&tt1,&ReportSetSTR,responseString12);
			
			tc_strcpy(responseString13,"CAB_BODY(CAB_BODY)=");
			tc_strcat(responseString13,cabbodyval);
			setAddStr(&tt1,&ReportSetSTR,responseString13);
			
			tc_strcpy(responseString14,"FuelTank Capacity(FUELTANK)=");
			tc_strcat(responseString14,fueltankval);
			setAddStr(&tt1,&ReportSetSTR,responseString14);
			
			tc_strcpy(responseString15,"Type(SUSPENSION_TYPE)=");
			tc_strcat(responseString15,suspensiontypeval);
			setAddStr(&tt1,&ReportSetSTR,responseString15);
			
			tc_strcpy(responseString16,"VEHICLE MAKE=");
			tc_strcat(responseString16,vehmakeval);
			setAddStr(&tt1,&ReportSetSTR,responseString16);
			
			tc_strcpy(responseString17,"VAHAN MODEL NAME=");
			tc_strcat(responseString17,vahanval);
			setAddStr(&tt1,&ReportSetSTR,responseString17);
			
			tc_strcpy(responseString18,"MODEL NAME TO BE PRINTED ON RC=");
			tc_strcat(responseString18,printonrcval);
			setAddStr(&tt1,&ReportSetSTR,responseString18);
			
			tc_strcpy(responseString19,"AC HEATING or DEMIST=");
			tc_strcat(responseString19,acheatingval);
			setAddStr(&tt1,&ReportSetSTR,responseString19);
			
			tc_strcpy(responseString20,"GROSS VEHICLE WEIGHT=");
			tc_strcat(responseString20,grossvehwtval);
			setAddStr(&tt1,&ReportSetSTR,responseString20);
			
			tc_strcpy(responseString21,"LOAD_BODY_TYPE=");
			tc_strcat(responseString21,loadbdytypeval);
			setAddStr(&tt1,&ReportSetSTR,responseString21);
			
			tc_strcpy(responseString22,"CMVR_TYP_APPRVL_NO=");
			tc_strcat(responseString22,cmvrtypeval);
			setAddStr(&tt1,&ReportSetSTR,responseString22);
			
			tc_strcpy(responseString23,"Specs-Gearbox Model(GB_MODEL)=");
			tc_strcat(responseString23,gbmodeltypeval);
			setAddStr(&tt1,&ReportSetSTR,responseString23);
			
			tc_strcpy(responseString24,"[VC]Specs-Rear Axle Model(REAR_AXLE_MODEL)=");
			tc_strcat(responseString24,rearaxlemodtypeval);
			setAddStr(&tt1,&ReportSetSTR,responseString24);
			
			tc_strcpy(responseString25,"[VC]Specs-Rear Axle Ratio(REAR_AXLE_RATIO)=");
			tc_strcat(responseString25,rearaxleratiotypeval);
			setAddStr(&tt1,&ReportSetSTR,responseString25);
			
			tc_strcpy(responseString26,"[VC]Engine Model=");
			tc_strcat(responseString26,enginemodeltypeval);
			setAddStr(&tt1,&ReportSetSTR,responseString26);
			
			tc_strcpy(responseString27,"VARIANT=");
			tc_strcat(responseString27,variantval);
			setAddStr(&tt1,&ReportSetSTR,responseString27);
			
		    aString_test-> __size =tt1;
			//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
			aString_test->__ptrDetails = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrDetails) );
			int i =0;
			for(i=0;i<tt1;i++)
			{
				/* aString_test->__ptrItem[i].PROJECT_ID = malloc(30 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].PROJECT_ID,responseString1); // PROJECT_ID

				aString_test->__ptrItem[i].ORGANIZATION_ID = malloc(30 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].ORGANIZATION_ID,responseString2); // ORGANIZATION_ID */
								
				Print_Report = ReportSetSTR[i];
				printf("\n Print_Report: -----> <%s> \n",Print_Report);fflush(stdout);

				aString_test->__ptrDetails[i].PartIDDetails = malloc(500 * sizeof(char *) );
				strcpy(aString_test->__ptrDetails[i].PartIDDetails,Print_Report);

			}
		}
		
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;
}