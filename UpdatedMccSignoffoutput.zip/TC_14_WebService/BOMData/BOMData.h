//gsoap ns service name:				 BOMData
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:BOMData
//gsoap ns service location:			 http://172.22.99.106:9080/cgi/BOMData.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:BOMData
//gsoap ns service method-documentation: Tests the Simple Web service

typedef char * xsd__string;

struct ns__CharArray
{
	xsd__string     *__ptr;         // pointer to array of string
	int             __size;         // array size
};

int ns__BOMDetailsAll(char *Item, struct ns__CharArray *aString);
