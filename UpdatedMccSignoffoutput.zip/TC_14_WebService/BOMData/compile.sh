rm -f *.wsdl ns.xsd *.nsmap *.res.xml *.req.xml soapServerLib.c soapClientLib.c soapStub.h soapServer.c soapH.h soapClient.c soapC.c *.o *.cgi

./soapcpp2 -1 -e -c BOMData.h

./compile BOMData.c

./linkitk -o BOMData.cgi BOMData.o soapC.c soapServer.c stdsoap2.c
chmod 777 *
cp BOMData.wsdl /user/cvprod/apache-tomcat-9.0.113/webapps/ROOT/
cp BOMData.cgi /user/cvprod/apache-tomcat-9.0.113/webapps/ROOT/WEB-INF/cgi/
cp *.xml /user/cvprod/apache-tomcat-9.0.113/webapps/ROOT/WEB-INF/cgi/
#cd /user/cvprod/apache-tomcat-9.0.100/bin
#./shutdown.sh
#./startup.sh
cd /user/cvprod/sourav/TC_14_WebService/BOMData/
