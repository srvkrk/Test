/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   BOM
*  Description  :   WebService For First Level Child Details of a TC Part From TCUA CV
*  File Name    :   BOMData.c
*  Created on   :   May 07th, 2025
*  Usage        :   BOMData.c
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     07/05/2025                 Sourav Karak
***************************************************************************/

#include "soapH.h"
#include "BOMData.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc_startup.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>
#include <cfm/cfm.h>
#include <string.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define MAX_LINE_LENGTH 1000
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128
#define atoa(x) #x

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

void tostring(char [], int);
int tccount = 0;
int CFM_find (const char *name, tag_t *rule);
void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}
char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -inp=<Creation Date From, Creation Date To & Request Domain > (Required)\n"
        );	
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    for ( i = 0; i < iNumErrs; i++ )
    {
	   printf("Test");
    }
    return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

char* TC_PartDesc(char* PSrch,char* PRevSrch,char* PSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSrch);
	trimwhitespace(PSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	char *PRevSeqSrch = (char *) malloc(10*sizeof(char));
	tc_strcpy(PRevSeqSrch,PRevSrch);
	tc_strcat(PRevSeqSrch,"*");
	tc_strcat(PRevSeqSrch,PSeqSrch);
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSrch,char* PNSeqSrch)
{
	
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSrch);
	trimwhitespace(PNSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char *Item_revseq = NULL;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	char *PNRevSeqSrch = (char *) malloc(10*sizeof(char));
	tc_strcpy(PNRevSeqSrch,PNRevSrch);
	tc_strcat(PNRevSeqSrch,"*");
	tc_strcat(PNRevSeqSrch,PNSeqSrch);
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[n];
				if(LC_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpLCQryobj_results[n],"release_status_list",&sRelStatus);
					printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						tc_strdup("--",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
					printf("\n Item Release Status After Dup & Trim: [%s]", sRelStatusDup);fflush(stdout);
					STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
					printf("\n Item Release Status Final Value: [%s]", sRelStatusDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&sRelStatusDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&sRelStatusDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&sRelStatusDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

char* TC_PartLastModDtDetails(char* PrtSrch,char* PrtRevSrch,char* PrtSeqSrch)
{
	
	trimwhitespace(PrtSrch);
	trimwhitespace(PrtRevSrch);
	trimwhitespace(PrtSeqSrch);
	tag_t tpmodQryobj = NULLTAG;
	int nmod_entries = 2;
	int nmod_Qryobj_found = 0;
	tag_t* tpmodQryobj_results = NULLTAG;
	int f = 0;
	date_t dlast_mod_date;
	char* clast_mod_date = NULL;
	char* clast_mod_dateDup = NULL;
	char *PrtRevSeqSrch = (char *) malloc(10*sizeof(char));
	tc_strcpy(PrtRevSeqSrch,PrtRevSrch);
	tc_strcat(PrtRevSeqSrch,"*");
	tc_strcat(PrtRevSeqSrch,PrtSeqSrch);
	
	printf("\n Searched Part Number Value: [%s]\n", PrtSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PrtRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpmodQryobj));
    if(tpmodQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *ModEntries[2]  = {"Revision","ID"};
		char *ModValues[2]  = {PrtRevSeqSrch,PrtSrch};
		ITK_CALL(QRY_execute(tpmodQryobj, nmod_entries, ModEntries, ModValues, &nmod_Qryobj_found, &tpmodQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nmod_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nmod_Qryobj_found > 0)
		{
			printf(" Queried Design Revision Found..!!\n");fflush(stdout);
			for (f = 0; f < nmod_Qryobj_found; f++)
			{
				tag_t mod_rev_tags_found = NULLTAG;
				mod_rev_tags_found = tpmodQryobj_results[f];
				if(mod_rev_tags_found != NULLTAG)
				{	
			        ITK_CALL(AOM_ask_value_date(tpmodQryobj_results[f],"last_mod_date",&dlast_mod_date));
					ITK_date_to_string(dlast_mod_date, &clast_mod_date);
					printf("\n Last Modified Date:  <%s> \n",clast_mod_date);fflush(stdout);
					if(tc_strlen(clast_mod_date)>0)
					{
						tc_strdup(clast_mod_date,&clast_mod_dateDup);
					}
					else
					{
						tc_strdup("--",&clast_mod_dateDup);
						printf("\n Last Modified Date Value is NULL");fflush(stdout);
					}
				}
				else
				{
					tc_strdup("--",&clast_mod_dateDup);
					printf("\n Sorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&clast_mod_dateDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&clast_mod_dateDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return clast_mod_dateDup;	
}

char* TC_PartOwnerDetails(char* PrSrch,char* PrRevSrch,char* PrSeqSrch)
{
	trimwhitespace(PrSrch);
	trimwhitespace(PrRevSrch);
	trimwhitespace(PrSeqSrch);
	tag_t tpOwnQryobj = NULLTAG;
	int nOwn_entries = 2;
	int nown_Qryobj_found = 0;
	tag_t* tpOwnQryobj_results = NULLTAG;
	int r = 0;
	char* sOwner = NULL;
	char* sOwnerDup = NULL;
	char *PrRevSeqSrch = (char *) malloc(10*sizeof(char));
	tc_strcpy(PrRevSeqSrch,PrRevSrch);
	tc_strcat(PrRevSeqSrch,"*");
	tc_strcat(PrRevSeqSrch,PrSeqSrch);
	
	printf("\n Searched Part Number Value: [%s]\n", PrSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PrRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpOwnQryobj));
    if(tpOwnQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *OwnEntries[2]  = {"Revision","ID"};
		char *OwnValues[2]  = {PrRevSeqSrch,PrSrch};
		ITK_CALL(QRY_execute(tpOwnQryobj, nOwn_entries, OwnEntries, OwnValues, &nown_Qryobj_found, &tpOwnQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nown_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nown_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (r = 0; r < nown_Qryobj_found; r++)
			{
				tag_t Own_rev_tags_found = NULLTAG;
				Own_rev_tags_found = tpOwnQryobj_results[r];
				if(Own_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpOwnQryobj_results[r],"owning_user",&sOwner);
					printf("\n Item Owner Before Dup & Trim:  <%s> \n",sOwner);fflush(stdout);
					if(tc_strlen(sOwner)>0)
					{
						tc_strdup(sOwner,&sOwnerDup);
					}
					else
					{
						tc_strdup("--",&sOwnerDup);
						printf("\n Item Owner Value is NULL");fflush(stdout);
					}
					trimwhitespace(sOwnerDup);
					printf("\n Item Owner After Dup & Trim: [%s]", sOwnerDup);fflush(stdout);
					STRNG_replace_str(sOwnerDup,","," ",&sOwnerDup);
					STRNG_replace_str(sOwnerDup,";"," ",&sOwnerDup);
					STRNG_replace_str(sOwnerDup,"\n"," ",&sOwnerDup);
					STRNG_replace_str(sOwnerDup,"'"," ",&sOwnerDup);
					printf("\n Item Owner Final Value: [%s]", sOwnerDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&sOwnerDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&sOwnerDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&sOwnerDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return sOwnerDup;	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport, char* VNo, char* VRev, char* VSeq)
{
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cItem_Desc = NULL;
		char* cItemSubardr = NULL;
		char* cItemSubardrDup = NULL;
		char* cItem_LcStat = NULL;
		char* cItem_owner = NULL;
		char* cItem_lastmoddt = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartStatus", &cItemSubardr));
			if(tc_strlen(cItemSubardr)>0)
			{
				tc_strdup(cItemSubardr,&cItemSubardrDup);
			}
			else
			{
				tc_strdup("--",&cItemSubardrDup);
				printf("\n AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(cItemSubardrDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", cItemSubardrDup);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			cItem_Desc = TC_PartDesc(cItem_Id,cItem_Rev,cItem_Seq);
			printf("\n Part Description Value: [%s]", cItem_Desc);fflush(stdout);
			
			cItem_LcStat = TC_PartLCDetails(cItem_Id,cItem_Rev,cItem_Seq);
			printf("\n Part Release Status Value: [%s]", cItem_LcStat);fflush(stdout);
			
			cItem_owner = TC_PartOwnerDetails(cItem_Id,cItem_Rev,cItem_Seq);
			printf("\n Part Owner Value: [%s]", cItem_owner);fflush(stdout);
			
			cItem_lastmoddt = TC_PartLastModDtDetails(cItem_Id,cItem_Rev,cItem_Seq);
			printf("\n Part Last Modified Date Value: [%s]", cItem_lastmoddt);fflush(stdout);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Part Revision: [%s]", cItem_Rev);
			printf("\nChild_Level Part Sequence: [%s]", cItem_Seq);
			printf("\nChild_Level Part Description: [%s]", cItem_Desc);
			printf("\nChild_Level Part AR/DR Status: [%s]", cItemSubardrDup);
			printf("\nChild_Level Part LC_State: [%s]", cItem_LcStat);
			printf("\nChild_Level Part Owner: [%s]", cItem_owner);
			printf("\nChild_Level Part Last_Mod_Date: [%s]", cItem_lastmoddt);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cItem_Id)>0)
		    {
				fprintf(FP_OutputReport,"%s^%s^%s^%s^%s^%s^%s^%s^\n",cItem_Id,cItem_Rev,cItem_Seq,cItem_Desc,cItemSubardrDup,cItem_LcStat,cItem_owner,cItem_lastmoddt);fflush(FP_OutputReport);
				tccount = tccount + 1;
			}
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
			   printf("\n!!!!!!!!!! I N N E R  C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
			   bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport,cItem_Id,cItem_Rev,cItem_Seq);
			} */
		}
		
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRev,char* VehicleSeq,char* VehicleRS,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Desc = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubardr = NULL;
	char* ctopSubardrDup = NULL;
	char* ctopSubItem_LcStat = NULL;
	char* ctopSubItem_owner = NULL;
	char* ctopSubItem_lastmoddt = NULL;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartStatus", &ctopSubardr));
			if(tc_strlen(ctopSubardr)>0)
			{
				tc_strdup(ctopSubardr,&ctopSubardrDup);
			}
			else
			{
				tc_strdup("--",&ctopSubardrDup);
				printf("\n AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubardrDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", ctopSubardrDup);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ctopSubItem_Desc = TC_PartDesc(ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq);
			printf("\n Part Description Value: [%s]", ctopSubItem_Desc);fflush(stdout);
			
			ctopSubItem_LcStat = TC_PartLCDetails(ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq);
			printf("\n Part Release Status Value: [%s]", ctopSubItem_LcStat);fflush(stdout);
			
			ctopSubItem_owner = TC_PartOwnerDetails(ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq);
			printf("\n Part Owner Value: [%s]", ctopSubItem_owner);fflush(stdout);
			
			ctopSubItem_lastmoddt = TC_PartLastModDtDetails(ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq);
			printf("\n Part Last Modified Date Value: [%s]", ctopSubItem_lastmoddt);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Description: [%s]", ctopSubItem_Desc);
			printf("\nTop_Level AR/DR Status: [%s]", ctopSubardrDup);
			printf("\nTop_Level LC_State: [%s]", ctopSubItem_LcStat);
			printf("\nTop_Level Owner: [%s]", ctopSubItem_owner);
			printf("\nTop_Level Last_Mod_Date: [%s]", ctopSubItem_lastmoddt);		
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubItem_Id)>0)
		    {
				fprintf(VehRpt,"%s^%s^%s^%s^%s^%s^%s^%s^\n",ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubItem_Desc,ctopSubardrDup,ctopSubItem_LcStat,ctopSubItem_owner,ctopSubItem_lastmoddt);fflush(VehRpt);
				tccount = tccount + 1;
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt, Vehicle, VehicleRev, VehicleSeq);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); 

}
;

int ns__BOMDetailsAll(struct soap* soap,char *Input_line_str,struct ns__CharArray *aString)
{
        int iFail =0;
		int ifail =0;
		//int	tt1	= 0;
		char* Print_Report = NULL;
		//char**	ReportSetSTR = NULL;
		char *loggedInUser = NULL;
		size_t len;
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/BOMDetailsData.txt", "w", stdout);
		char *Input_line_strDup = NULL;
		tag_t tItemobj = NULLTAG;
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULLTAG;
		int i, k = 0;
		int d = 0;
		char* responseString = NULL;
		responseString=(char *)MEM_alloc(10000);
		char *RptFile = (char *) malloc(100*sizeof(char));
		char *inp_item_id_str = NULL;
		char *inp_item_id_strDup = NULL;
		char *inp_item_ptype_str = NULL;
		char *inp_item_ptype_strDup = NULL;
		int n_entries = 4;
		tag_t DesRev_tag = NULLTAG;
		char *Newitem_revseq_str = NULL;
		char *Newitem_revseq_strDup = NULL;
		char *item_rev_str = NULL;
		char *item_rev_strDup = NULL;
		char *item_seq_str = NULL;
		char *item_seq_strDup = NULL;
		char *inp_id_str = NULL;
		char *inp_rev_str = NULL;
		char *inp_seq_str = NULL;
		char *item_id_str = NULL;
		char *item_id_strDup = NULL;
		char *item_revseq_str = NULL;
		char *item_revseq_strDup = NULL;
		char *SubMod_Desc = NULL;
		char *SubMod_DescDup = NULL;
		char *SubModProd_str = NULL;
		char *SubModProd_strDup = NULL;
		char *SubMod_RelStatus = NULL;
		char *SubMod_RelStatusDup = NULL;
		char Buffer[MAX_LINE_LENGTH];
		char* username_str = NULL;
		char* password_str = NULL;
		char* group_str = NULL;
		char* username_strDup = NULL;
		char* password_strDup = NULL;
		char* group_strDup = NULL;
		FILE *fpPart_List = NULL;

		//CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//CALLAPI(ITK_auto_login( ));
		//CALLAPI(ITK_set_journalling( TRUE ));
		//printf(" Auto Login Successfull..!!\n");fflush(stdout);
		//POM_get_user_id(&loggedInUser);
		//printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
		
		printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
        //CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//CALLAPI(ITK_set_journalling( TRUE ));
		//CALLAPI(ITK_auto_login());
		//fpPart_List = fopen("/user/uaprodtrl/Sourav/WebServicePwfFile.txt","r");  //UAPRODTRL Login
		fpPart_List = fopen("/user/cvprod/sourav/WebServicePwfFile.txt","r");  //CVPRODTRL Login
		if(fpPart_List != NULL)
		{
			printf(" Input_File Not Null..!!\n");fflush(stdout);
			while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
			{
				username_str=strtok(Buffer,"^");
				password_str=strtok(NULL,"^");
				group_str=strtok(NULL,"^");
				
				if(username_str!=NULL)tc_strdup(username_str,&username_strDup);
				if(password_str!=NULL)tc_strdup(password_str,&password_strDup);
				if(group_str!=NULL)tc_strdup(group_str,&group_strDup);
				
				if(username_strDup!=NULL)trimwhitespace(username_strDup);
				if(password_strDup!=NULL)trimwhitespace(password_strDup);
				if(group_strDup!=NULL)trimwhitespace(group_strDup);
		    }
		}
		else 
		{
			printf("\n UserName & Password Input_File is NULL..!!\n");fflush(stdout);
		}
		fclose(fpPart_List);
		printf(" UserName & Password & Group Data read From File Done..!!\n");fflush(stdout);
	    CALLAPI(ITK_init_module(username_strDup, password_strDup, group_strDup));
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
		
		trimwhitespace(Input_line_str);
	    if(Input_line_str!=NULL)tc_strdup(Input_line_str,&Input_line_strDup);
	    printf(" [1]: Input Line(Input_line_str): [%s]\n",Input_line_strDup);
	    inp_item_id_str=strtok(Input_line_strDup,"^");
	    inp_item_ptype_str=strtok(NULL,"^");

		trimwhitespace(inp_item_id_str);
		trimwhitespace(inp_item_ptype_str);
	    if(inp_item_id_str!=NULL)tc_strdup(inp_item_id_str,&inp_item_id_strDup);
	    if(inp_item_ptype_str!=NULL)tc_strdup(inp_item_ptype_str,&inp_item_ptype_strDup);
	    printf(" [1]: Input Part_No(inp_item_id_strDup): [%s]\n",inp_item_id_strDup);
		printf(" [2]: Input Part_Type(inp_item_ptype_strDup): [%s]\n",inp_item_ptype_strDup);
		
		char GenDate[100] = "";
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
		printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

		printf("\n Generating First Level Child Details Report File Name..!!");fflush(stdout);
		tc_strcpy(RptFile,"/tmp/");
		tc_strcat(RptFile,inp_item_id_strDup);
		tc_strcat(RptFile,"_");
		tc_strcat(RptFile,GenDate);
		tc_strcat(RptFile,".txt");
		printf("\n First Level Child Details Report File Name: [%s]", RptFile);fflush(stdout);
		printf("\n First Level Child Details Report File Name Generated..!!");fflush(stdout);
		FILE* fpallsubmod_file = fopen(RptFile, "w");
		if(fpallsubmod_file == NULL)
		{
			printf("\n Unable to Create First Level Child Details Report File: --------> [%s]",fpallsubmod_file);fflush(stdout);
			return 0;
		}
		printf("\n Finding Query[MCC_ERC_Released_Latest_Revision]..!!\n");fflush(stdout);
		ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
		if(tItemobj != NULLTAG)
		{
			printf("\n [MCC_ERC_Released_Latest_Revision] Query Found Successfully..!!\n");fflush(stdout);
			char *cEntries[4]  = {"Item ID","Release Status","Part Type","Type"};
			char *cValues[4]  = {inp_item_id_strDup,"T5_LcsErcRlzd",inp_item_ptype_strDup,"Design Revision"};
			//char *cValues[4]  = {"50842168R","T5_LcsErcRlzd","V","Design Revision"};
			ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n  No of Part Found: [%d]\n",n_itemobj_found);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_itemobj_found > 0)
			{
				printf(" Queried Part Found For Input Part_No & Part_Type..!!\n");fflush(stdout);
				for(k = 0; k < n_itemobj_found; k++)
				{
					DesRev_tag = titemobj_results[k];
					ITK_CALL(AOM_ask_value_string(titemobj_results[k],"item_id",&item_id_str));
					if(tc_strlen(item_id_str)>0)
					{
						tc_strdup(item_id_str,&item_id_strDup);
						trimwhitespace(item_id_strDup);
					}
					else
					{
						tc_strdup("--",&item_id_strDup);
						printf("\n Part Number Value is NULL..!!");fflush(stdout);
					}
					ITK_CALL(AOM_ask_value_string(titemobj_results[k],"item_revision_id",&item_revseq_str));
					if(tc_strlen(item_revseq_str)>0)
					{
						tc_strdup(item_revseq_str,&item_revseq_strDup);
						trimwhitespace(item_revseq_strDup);
					}
					else
					{
						tc_strdup("--",&item_revseq_strDup);
						printf("\n Part Revision Sequence Value is NULL..!!");fflush(stdout);
					}
					
					ITK_CALL(AOM_ask_value_string(titemobj_results[k],"item_revision_id",&Newitem_revseq_str));
					if(tc_strlen(Newitem_revseq_str)>0)
					{
						tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
						trimwhitespace(Newitem_revseq_strDup);
						item_rev_str=strtok(Newitem_revseq_strDup,";");
						item_seq_str=strtok(NULL,";");
						if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
						if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
						trimwhitespace(item_rev_strDup);
						trimwhitespace(item_seq_strDup);
					}
					else
					{
						tc_strdup("--",&Newitem_revseq_strDup);
						printf("\n [New]Part Revision Sequence Value is NULL..!!");fflush(stdout);
					}
					
					printf("\n Function1: First Level Child Details Find Start\n");fflush(stdout);
					TC_VehChild_Details(item_id_strDup,item_rev_strDup,item_seq_strDup,item_revseq_strDup,fpallsubmod_file);
					printf("\n Function1: First Level Details Find End\n");fflush(stdout);		
				}
			}
			else
			{
				printf(" Part Found Zero[0] After MCC_ERC_Released_Latest_Revision Query..!!\n");fflush(stdout);
			}
		}
		else
		{
			printf(" Query[MCC_ERC_Released_Latest_Revision] Tag Not Found..!!\n");fflush(stdout);
		}
		fclose(fpallsubmod_file);
		
		char* Part_no_Str = NULL;
		char* Part_rev_Str = NULL;
		char* Part_seq_Str = NULL;
		char* Part_desc_Str = NULL;
		char* Part_ardr_Str = NULL;
		char* Part_lcstate_Str = NULL;
		char* Part_owner_Str = NULL;
		char* Part_lstmod_Str = NULL;
		
		FILE *fpchilddetails_List = fopen(RptFile, "r");
		if(fpchilddetails_List != NULL)
		{
			printf("\n Child Details List File Not Null..!!\n");fflush(stdout);
			d = tccount;	aString->__size = d;
		    aString->__ptr = malloc( (aString->__size + 1) * sizeof(*aString->__ptr) );
			int i = 0;
			while(fgets(Buffer,MAX_LINE_LENGTH,fpchilddetails_List)!=NULL)
			{
				Part_no_Str=strtok(Buffer,"^");
				Part_rev_Str=strtok(NULL,"^");
				Part_seq_Str=strtok(NULL,"^");
				Part_desc_Str=strtok(NULL,"^");
				Part_ardr_Str=strtok(NULL,"^");
				Part_lcstate_Str=strtok(NULL,"^");
				Part_owner_Str=strtok(NULL,"^");
			    Part_lstmod_Str=strtok(NULL,"^");
				if(Part_no_Str!=NULL)trimwhitespace(Part_no_Str);
				if(Part_rev_Str!=NULL)trimwhitespace(Part_rev_Str);
				if(Part_seq_Str!=NULL)trimwhitespace(Part_seq_Str);
				if(Part_desc_Str!=NULL)trimwhitespace(Part_desc_Str);
				if(Part_ardr_Str!=NULL)trimwhitespace(Part_ardr_Str);
				if(Part_lcstate_Str!=NULL)trimwhitespace(Part_lcstate_Str);
				if(Part_owner_Str!=NULL)trimwhitespace(Part_owner_Str);
				if(Part_lstmod_Str!=NULL)trimwhitespace(Part_lstmod_Str);
				
				tc_strcpy(responseString," ");
				tc_strcpy(responseString,"Part_No: ");
				tc_strcat(responseString,Part_no_Str);
				tc_strcat(responseString," ~Rev: ");
				tc_strcat(responseString,Part_rev_Str);
				tc_strcat(responseString," ~Seq: ");
				tc_strcat(responseString,Part_seq_Str);
				tc_strcat(responseString," ~Desc: ");
				tc_strcat(responseString,Part_desc_Str);
				tc_strcat(responseString," ~ArDr: ");
				tc_strcat(responseString,Part_ardr_Str);
				tc_strcat(responseString," ~LC_State: ");
				tc_strcat(responseString,Part_lcstate_Str);
				tc_strcat(responseString," ~Owner: ");
				tc_strcat(responseString,Part_owner_Str);
				tc_strcat(responseString," ~Last_Mod_Date: ");
				tc_strcat(responseString,Part_lstmod_Str);
					
                aString->__ptr[i] = (char *) malloc( (10000) * sizeof(char));
                tc_strcpy(aString->__ptr[i], responseString);
				i++;
			}
		}
		else
		{
			printf("\n No Child Found For Given Input Data..!!");fflush(stdout);
			d = 1;	aString->__size = d;
			aString->__ptr = malloc( (aString->__size + 1) * sizeof(*aString->__ptr) );

			tc_strcpy(responseString,"No Child Found For Given Input Data");
			aString->__ptr[0] = (char *) malloc( (20) * sizeof(char));
			tc_strcpy(aString->__ptr[0], responseString);
		}
        fclose(fpchilddetails_List);
		printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
		
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

	return SOAP_OK;
}