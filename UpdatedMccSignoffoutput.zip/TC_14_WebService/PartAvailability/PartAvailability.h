//gsoap ns service name:				 PartAvailability
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:PartAvailability
//gsoap ns service location:			 http://172.22.99.106:9990/cgi/PartAvailability.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:PartAvailability
//gsoap ns service method-documentation: Tests the Simple Web service


struct ns__ItemDet
{
   char *PartIDDetails;
}
;
struct ns__CharArray1
{
   struct ns__ItemDet *__ptrDetails;
   int __size;
}
;

int ns__getItemData(char *Item,struct ns__CharArray1 *aString_test);
