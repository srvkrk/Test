/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   WebService For Part Availability Status Check (Assembly,Component,Module,CAD Module)
*  File Name    :   PartAvailability.c
*  Created on   :   September 13th, 2023
*  Usage        :   PartAvailability.c
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     28/07/2023                 Sourav Karak
***************************************************************************/

#include "soapH.h"
#include "PartAvailability.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc_startup.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <base_utils/Mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>
#include <string.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -pno=<Part Number> (Required)\n"
        );	
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    //register int i = 0;
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   //ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
   //fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
-      //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
       //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
	   printf("Test");
    }
    return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); 

}
;


int ns__getItemData(struct soap* soap,char *PartNum,struct ns__CharArray1 *aString_test)
{
        int iFail =0;
		int ifail =0;
		int	tt1	= 0;
		//char* PartNum = NULL;
	    char* PartNumber = NULL;
	    char* PartNumberDup = NULL;
	    PartNumberDup=(char *)MEM_alloc(200);
		char* responseString1 = NULL;
		char* responseString2 = NULL;
		char* Print_Report = NULL;
		char**	ReportSetSTR = NULL;
		size_t len;
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/PartAvailabilityRpt.txt", "w", stdout);

		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		
		//PartNum=strtok(PartNumType,"^");
	    printf("\n Part Number String --------> %s", PartNum);fflush(stdout);
		trimwhitespace(PartNum);
		printf("\n Part Number After Trim --------> %s\n", PartNum);fflush(stdout);
		
		printf("\n [1]: Input Part Number ---> [%s]",PartNum);fflush(stdout);
		
		if(tc_strlen(PartNum)>0)
		{
			tc_strdup(PartNum,&PartNumber);
		}
		else
		{
			tc_strdup("NULL",&PartNumber);
			printf("\n Part No Value is NULL");fflush(stdout);
		}
		printf("\n Part Number Value After Dup --------> %s", PartNumber);fflush(stdout);
        trimwhitespace(PartNumber);
		printf("\n Part Number Value After Trim --------> %s", PartNumber);fflush(stdout);
		tc_strcpy(PartNumberDup,PartNumber);
		printf("\n Final Part Number After Trim & Dup --------> %s", PartNumberDup);fflush(stdout);
		
		tag_t* tItem_results = NULLTAG;
	    printf("\n Searched Part Number Value Trim & Dup --------> %s\n", PartNumberDup);fflush(stdout);
	    tag_t tPartobj = NULLTAG;
	    ITK_CALL(QRY_find2("Item ID",&tPartobj));
	    printf("\n Return Value From Item ID Query API is --------> %d", iFail);fflush(stdout);
		if(tPartobj != NULLTAG)
		{
			printf("\n Item ID Query Found Successfully...");fflush(stdout);
			int n_entrie = 1;
			char *cQry_entry[1] = {"Item ID"};
			char *cQry_values[1] = {PartNumberDup};
			//char *cQry_values[1] = {"5137D1D0270001_WE"};
			int nItem_found = 0;
			ITK_CALL(QRY_execute(tPartobj, n_entrie, cQry_entry, cQry_values, &nItem_found, &tItem_results));
			printf("\n Return Value From Item ID Query Execute API is --------> %d", iFail);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Part Found --------> %d\n",nItem_found);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			responseString1=(char *)MEM_alloc(200);
			responseString2=(char *)MEM_alloc(200);
			
			printf("\n Again Printing: Input Part Number: -----> <%s> \n",PartNumberDup);fflush(stdout);
			tc_strcpy(responseString1,"PART_NUMBER=");
			tc_strcat(responseString1,PartNumberDup);
			setAddStr(&tt1,&ReportSetSTR,responseString1);
			
			tc_strcpy(responseString2,"PART_STATUS=");
			if(nItem_found > 0)
			{
				tc_strcat(responseString2,"TRUE");
			}
			else
			{
				tc_strcat(responseString2,"FALSE");
			}
			setAddStr(&tt1,&ReportSetSTR,responseString2);
		    aString_test-> __size =tt1;
			//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
			aString_test->__ptrDetails = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrDetails) );
			int i =0;
			for(i=0;i<tt1;i++)
			{
				/* aString_test->__ptrItem[i].PROJECT_ID = malloc(30 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].PROJECT_ID,responseString1); // PROJECT_ID

				aString_test->__ptrItem[i].ORGANIZATION_ID = malloc(30 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].ORGANIZATION_ID,responseString2); // ORGANIZATION_ID */
								
				Print_Report = ReportSetSTR[i];
				printf("\n Print_Report: -----> <%s> \n",Print_Report);fflush(stdout);

				aString_test->__ptrDetails[i].PartIDDetails = malloc(500 * sizeof(char *) );
				strcpy(aString_test->__ptrDetails[i].PartIDDetails,Print_Report);

			}
		}
		
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;
}