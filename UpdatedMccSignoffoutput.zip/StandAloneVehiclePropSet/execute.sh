/user/cvprod/sourav/StandAloneVehiclePropSet/tm_StandAloneVehiclePropSet -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
