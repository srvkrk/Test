/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Vehicle Link Module Report (VehicleNo, Revision, Sequence)
*  File Name    :   tm_VehLinkModReport.c
*  Created on   :   Sept 08th, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     08/09/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_EEVehLinkStatus(char* ModAdd,char* PNSrch,char* PNRevSeqSrch,char* PNRlDate,FILE* ResRpt)
{
	
	trimwhitespace(ModAdd);
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char* ResponseVehlinkStat = NULL;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	tag_t rev_tags_found = NULLTAG;
	tag_t tParentDesRev = NULLTAG;
	char *VCList = (char *) malloc(60000*sizeof(char));
	int linkcount = 0;
	int statuscount = 0;
	char* PNProj = NULL;
	char* MainStatus = NULL;
	
	printf("\n Searched Module Address Value: [%s]\n", ModAdd);fflush(stdout);
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
            int	status_count = 0;
	        tag_t* relStatus_list = NULLTAG;
            char* latest_rev_Rel_Status = NULL;
	        char* latest_rev_Rel_StatusDup = NULL;			
	        rev_tags_found = tpLCQryobj_results[0];
			ITK_CALL(AOM_ask_value_string(rev_tags_found,"t5_ProjectCode",&PNProj));
			
			tag_t	tPNSrch	= NULLTAG;
			ITK_CALL(ITEM_find_item(PNSrch,&tPNSrch));
			char  **relations=NULL;
			ITK_CALL(WSOM_where_referenced2(tPNSrch, 1 ,&n_parents,&levels,&parents,&relations));
			//ITK_CALL(PS_where_used_all(rev_tags_found, 1, &n_parents, &levels, &parents));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Attachment Found: [%d]\n",n_parents);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_parents > 0)
			{
				int z = 0;
				printf(" Parent Attachment Found..!!\n");fflush(stdout);
				tc_strcpy(VCList,"@");
				for(z = 0; z < n_parents; z++)
				{ 
				   tParentDesRev = parents[z];
				   char *Parent_ID = NULL;
				   char *Parent_IDDup = NULL;
				   char *Parent_RevSeq = NULL;
				   char *Parent_RevSeqDup = NULL;
				   char *Parent_PartType = NULL;
				   char *Parent_PartTypeDup = NULL;
				   char *Parent_ProjCode = NULL;
				   char *Parent_ProjCodeDup = NULL;
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_id",&Parent_ID));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_revision_id",&Parent_RevSeq));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_PartType",&Parent_PartType));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_ProjectCode",&Parent_ProjCode));
				   
				   printf("\n Parent Part_No: [%s]",Parent_ID);fflush(stdout);
				   printf("\n Parent Rev&Seq No: [%s]",Parent_RevSeq);fflush(stdout);
				   printf("\n Parent Part Type: [%s]",Parent_PartType);fflush(stdout);
				   printf("\n Parent Project Code: [%s]",Parent_ProjCode);fflush(stdout);
				   
				   if(Parent_ID!=NULL)tc_strdup(Parent_ID,&Parent_IDDup);
				   if(Parent_RevSeq!=NULL)tc_strdup(Parent_RevSeq,&Parent_RevSeqDup);
				   if(Parent_PartType!=NULL)tc_strdup(Parent_PartType,&Parent_PartTypeDup);
				   if(Parent_ProjCode!=NULL)tc_strdup(Parent_ProjCode,&Parent_ProjCodeDup);
				    if(tc_strlen(Parent_PartTypeDup)>0)
				    {
					    if((tc_strcmp(Parent_PartTypeDup,"V") == 0) || (tc_strcmp(Parent_PartTypeDup,"VC") == 0) || (tc_strcmp(Parent_PartTypeDup,"CRVC") == 0))
					    {
						    WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list);
							printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
							if(status_count>0)
							{
								int g = 0;
								for(g = 0; g<status_count; g++)
								{			  
									AOM_ask_value_string(relStatus_list[g],"object_name",&latest_rev_Rel_StatusDup);
									printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
									if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"ERC Released") == 0))
									{
									    tc_strdup("Yes",&ResponseVehlinkStat);
									   	linkcount = linkcount + 1;
                                        tc_strcat(VCList,Parent_ProjCodeDup);
									    tc_strcat(VCList,"/@");
                                        if(tc_strcmp(PNProj,Parent_ProjCodeDup) == 0)
                                        {
										   statuscount = statuscount + 1;
										}										
									}
									else
									{
									   continue;
									}			  
								}
							}
					    }
				    }   
				}
			}
			else
			{
				tc_strdup("No",&ResponseVehlinkStat);
				printf("Parent Count Zero[0] Continue..!!\n");fflush(stdout);
			}	
		}
		else
		{
			tc_strdup("No",&ResponseVehlinkStat);
			printf("\nEntered Revision Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\nDesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	if(tc_strlen(ResponseVehlinkStat)>0)
	{
		printf("\n Vehicle Link Status Already Received..!!\n");fflush(stdout);
    }
    else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\n As ResponseVehlinkStat value was empty so status[No] added..!!\n");fflush(stdout);
	}
	printf("\n VC_List Before STRING_REPLACE: [%s]",VCList);fflush(stdout);
	STRNG_replace_str(VCList,"@","",&VCList);
	printf("\n VC_List After STRING_REPLACE: [%s]",VCList);fflush(stdout);
	if (linkcount == statuscount)
	{
		tc_strdup("Same",&MainStatus);
	}
	else
	{
		tc_strdup("Different",&MainStatus);
	}
	char str[10];
	tostring(str, linkcount);
    printf("\nLink Count in String: [%s]\n", str);fflush(stdout);
	char str1[10];
	tostring(str1, statuscount);
    printf("\nStatus Count in String: [%s]\n", str1);fflush(stdout);
	char* PNRevision = NULL;
	char* PNSequence = NULL;
	PNRevision=strtok(PNRevSeqSrch,";");
	PNSequence=strtok(NULL,";");
	printf("\n Part Rev Value After Token: [%s]\n", PNRevision);fflush(stdout);
	printf("\n Part Seq Value After Token: [%s]\n", PNSequence);fflush(stdout);
	
	write2xml(Report,"<LinkDetails>\n");
	write2xml(Report,"<Add>"); if(tc_strlen(ModAdd)>0) write2xml(Report,ModAdd); else write2xml(Report,"NA"); write2xml(Report,"</Add>\n");
	write2xml(Report,"<Mod>"); if(tc_strlen(PNSrch)>0) write2xml(Report,PNSrch); else write2xml(Report,"NA"); write2xml(Report,"</Mod>\n");
	write2xml(Report,"<ModR>"); if(tc_strlen(PNRevision)>0) write2xml(Report,PNRevision); else write2xml(Report,"NA"); write2xml(Report,"</ModR>\n");
	write2xml(Report,"<ModS>"); if(tc_strlen(PNSequence)>0) write2xml(Report,PNSequence); else write2xml(Report,"NA"); write2xml(Report,"</ModS>\n");
	write2xml(Report,"<ModRD>"); if(tc_strlen(PNRlDate)>0) write2xml(Report,PNRlDate); else write2xml(Report,"NA"); write2xml(Report,"</ModRD>\n");
	write2xml(Report,"<TCount>"); if(tc_strlen(str)>0) write2xml(Report,str); else write2xml(Report,"NA"); write2xml(Report,"</TCount>\n");
	write2xml(Report,"<LCount>"); if(tc_strlen(str1)>0) write2xml(Report,str1); else write2xml(Report,"NA"); write2xml(Report,"</LCount>\n");
	write2xml(Report,"<LProjCode>"); if(tc_strlen(VCList)>0) write2xml(Report,VCList); else write2xml(Report,"NA"); write2xml(Report,"</LProjCode>\n");
	write2xml(Report,"<LStatus>"); if(tc_strlen(MainStatus)>0) write2xml(Report,MainStatus); else write2xml(Report,"NA"); write2xml(Report,"</LStatus>\n");
	write2xml(Report,"</LinkDetails>\n");
	
}

void TC_VehLinkStatus(char* ModAdd,char* PNSrch,char* PNRevSeqSrch,char* PNRlDate,FILE* ResRpt)
{
	//trimwhitespace(ModAdd);
	//trimwhitespace(PNSrch);
	//trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char* ResponseVehlinkStat = NULL;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	tag_t rev_tags_found = NULLTAG;
	tag_t tParentDesRev = NULLTAG;
	char *VCList = (char *) malloc(60000*sizeof(char));
	int linkcount = 0;
	int statuscount = 0;
	char* PNProj = NULL;
	char* MainStatus = NULL;
	
	printf("\n Searched Module Address Value: [%s]\n", ModAdd);fflush(stdout);
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
            int	status_count = 0;
	        tag_t* relStatus_list = NULLTAG;
            char* latest_rev_Rel_Status = NULL;
	        char* latest_rev_Rel_StatusDup = NULL;			
	        rev_tags_found = tpLCQryobj_results[0];
			tag_t RevRuleObjTag = NULLTAG;
			ITK_CALL(AOM_ask_value_string(rev_tags_found,"t5_ProjectCode",&PNProj));
			
			ITK_CALL(CFM_find("ERC release and above", &RevRuleObjTag));
			//ITK_CALL(PS_where_used_all(rev_tags_found, 1, &n_parents, &levels, &parents));
			ITK_CALL(PS_where_used_configured(rev_tags_found,RevRuleObjTag,1,&n_parents,&levels,&parents));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Attachment Found: [%d]\n",n_parents);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_parents > 0)
			{
				int z = 0;
				printf(" Parent Attachment Found..!!\n");fflush(stdout);
				tc_strcpy(VCList,"@");
				for(z = 0; z < n_parents; z++)
				{ 
				   tParentDesRev = parents[z];
				   char *Parent_ID = NULL;
				   char *Parent_IDDup = NULL;
				   char *Parent_RevSeq = NULL;
				   char *Parent_RevSeqDup = NULL;
				   char *Parent_PartType = NULL;
				   char *Parent_PartTypeDup = NULL;
				   char *Parent_ProjCode = NULL;
				   char *Parent_ProjCodeDup = NULL;
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_id",&Parent_ID));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_revision_id",&Parent_RevSeq));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_PartType",&Parent_PartType));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_ProjectCode",&Parent_ProjCode));
				   
				   printf("\n Parent Part_No: [%s]",Parent_ID);fflush(stdout);
				   printf("\n Parent Rev&Seq No: [%s]",Parent_RevSeq);fflush(stdout);
				   printf("\n Parent Part Type: [%s]",Parent_PartType);fflush(stdout);
				   printf("\n Parent Project Code: [%s]",Parent_ProjCode);fflush(stdout);
				   
				   if(Parent_ID!=NULL)tc_strdup(Parent_ID,&Parent_IDDup);
				   if(Parent_RevSeq!=NULL)tc_strdup(Parent_RevSeq,&Parent_RevSeqDup);
				   if(Parent_PartType!=NULL)tc_strdup(Parent_PartType,&Parent_PartTypeDup);
				   if(Parent_ProjCode!=NULL)tc_strdup(Parent_ProjCode,&Parent_ProjCodeDup);
				    if(tc_strlen(Parent_PartTypeDup)>0)
				    {
					    if((tc_strcmp(Parent_PartTypeDup,"V") == 0) || (tc_strcmp(Parent_PartTypeDup,"VC") == 0) || (tc_strcmp(Parent_PartTypeDup,"CRVC") == 0))
					    {
						    WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list);
							printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
							if(status_count>0)
							{
								int g = 0;
								for(g = 0; g<status_count; g++)
								{			  
									AOM_ask_value_string(relStatus_list[g],"object_name",&latest_rev_Rel_StatusDup);
									printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
									if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"ERC Released") == 0))
									{
									    tc_strdup("Yes",&ResponseVehlinkStat);
									   	linkcount = linkcount + 1;
                                        tc_strcat(VCList,Parent_ProjCodeDup);
									    tc_strcat(VCList,"/@");
                                        if(tc_strcmp(PNProj,Parent_ProjCodeDup) == 0)
                                        {
										   statuscount = statuscount + 1;
										}											
									}
									else
									{
									   continue;
									}			  
								}
							}
					    }
				    }   
				}
			}
			else
			{
				tc_strdup("No",&ResponseVehlinkStat);
				printf("Parent Count Zero[0] Continue..!!\n");fflush(stdout);
			}	
		}
		else
		{
			tc_strdup("No",&ResponseVehlinkStat);
			printf("\nEntered Revision Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\nDesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	if(tc_strlen(ResponseVehlinkStat)>0)
	{
		printf("\n Vehicle Link Status Already Received..!!\n");fflush(stdout);
    }
    else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\n As ResponseVehlinkStat value was empty so status[No] added..!!\n");fflush(stdout);
	}
	printf("\n VC_List Before STRING_REPLACE: [%s]",VCList);fflush(stdout);
	STRNG_replace_str(VCList,"@","",&VCList);
	printf("\n VC_List After STRING_REPLACE: [%s]",VCList);fflush(stdout);
	if (linkcount == statuscount)
	{
		tc_strdup("Same",&MainStatus);
	}
	else
	{
		tc_strdup("Different",&MainStatus);
	}
	char str[10];
	tostring(str, linkcount);
    printf("\nLink Count in String: [%s]\n", str);fflush(stdout);
	char str1[10];
	tostring(str1, statuscount);
    printf("\nStatus Count in String: [%s]\n", str1);fflush(stdout);
	char* PNRevision = NULL;
	char* PNSequence = NULL;
	PNRevision=strtok(PNRevSeqSrch,";");
	PNSequence=strtok(NULL,";");
	printf("\n Part Rev Value After Token: [%s]\n", PNRevision);fflush(stdout);
	printf("\n Part Seq Value After Token: [%s]\n", PNSequence);fflush(stdout);
	
	write2xml(Report,"<LinkDetails>\n");
	write2xml(Report,"<Add>"); if(tc_strlen(ModAdd)>0) write2xml(Report,ModAdd); else write2xml(Report,"NA"); write2xml(Report,"</Add>\n");
	write2xml(Report,"<Mod>"); if(tc_strlen(PNSrch)>0) write2xml(Report,PNSrch); else write2xml(Report,"NA"); write2xml(Report,"</Mod>\n");
	write2xml(Report,"<ModR>"); if(tc_strlen(PNRevision)>0) write2xml(Report,PNRevision); else write2xml(Report,"NA"); write2xml(Report,"</ModR>\n");
	write2xml(Report,"<ModS>"); if(tc_strlen(PNSequence)>0) write2xml(Report,PNSequence); else write2xml(Report,"NA"); write2xml(Report,"</ModS>\n");
	write2xml(Report,"<ModRD>"); if(tc_strlen(PNRlDate)>0) write2xml(Report,PNRlDate); else write2xml(Report,"NA"); write2xml(Report,"</ModRD>\n");
	write2xml(Report,"<TCount>"); if(tc_strlen(str)>0) write2xml(Report,str); else write2xml(Report,"NA"); write2xml(Report,"</TCount>\n");
	write2xml(Report,"<LCount>"); if(tc_strlen(str1)>0) write2xml(Report,str1); else write2xml(Report,"NA"); write2xml(Report,"</LCount>\n");
	write2xml(Report,"<LProjCode>"); if(tc_strlen(VCList)>0) write2xml(Report,VCList); else write2xml(Report,"NA"); write2xml(Report,"</LProjCode>\n");
	write2xml(Report,"<LStatus>"); if(tc_strlen(MainStatus)>0) write2xml(Report,MainStatus); else write2xml(Report,"NA"); write2xml(Report,"</LStatus>\n");
	write2xml(Report,"</LinkDetails>\n");
}

char* TC_ERC_DTReleased(tag_t PartRev_tag)
{
	int	status = 0;
	tag_t *Stat_list = NULLTAG;
	tag_t Stat_tag = NULLTAG;
	int Stat_Cnt = 0;
	char *RlzStatusName = NULL;
	char *Dt_Rlzd = NULL;
	char *Dt_RlzdDup = NULL;
	int j = 0;
	
    ITK_CALL(WSOM_ask_release_status_list(PartRev_tag,&Stat_Cnt,&Stat_list));
    for(j=0;j<Stat_Cnt;j++)
	{
		Stat_tag = Stat_list[j];
		ITK_CALL(AOM_ask_name(Stat_tag, &RlzStatusName));
		printf("\n Part`s Release Status Name: [%s]\n",RlzStatusName);fflush(stdout);
        if ((tc_strcmp(RlzStatusName,"T5_LcsRlzd")==0) || (tc_strcmp(RlzStatusName,"T5_LcsErcRlzd")==0) || (tc_strcmp(RlzStatusName,"ERC Released") == 0))
		{
			ITK_CALL(AOM_UIF_ask_value(Stat_tag,"date_released",&Dt_Rlzd));
			printf(" \n ERC-Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
             
		}
	}
	if(tc_strlen(Dt_Rlzd)>0)
	{
	   tc_strdup(Dt_Rlzd,&Dt_RlzdDup);
	}
	else
	{
	   tc_strdup("Not_ERC_Released",&Dt_RlzdDup);
	}
	return Dt_RlzdDup;
}

char* TC_LibraryStatus(char* SAddr, char* SNo, char* SRev, char* SSeq)
{
	//trimwhitespace(SAddr);
	//trimwhitespace(SNo);
	//trimwhitespace(SRev);
	//trimwhitespace(SSeq);
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	char* SubModStatus = NULL;
	
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {SAddr};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n SubModule Address Revision Exist So Continue To Check Submodule Present or Not..!!\n");fflush(stdout);
			tsubmodlib_rev = titemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
					printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(Tbl_SubModRev!=NULL)trimwhitespace(Tbl_SubModRev);
					if(Tbl_SubModSeq!=NULL)trimwhitespace(Tbl_SubModSeq);
					//if((tc_strcmp(SNo,Tbl_SubModNo)==0) && (tc_strcmp(SRev,Tbl_SubModRev)==0) && (tc_strcmp(SSeq,Tbl_SubModSeq)==0))
					if(tc_strcmp(SNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched So Exit..!!\n");fflush(stdout);
						tc_strdup("Yes",&SubModStatus);
                        goto jump;						
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SAddr\n");fflush(stdout);
				tc_strdup("No",&SubModStatus);
			}    
		}
		else
		{
		   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
		   tc_strdup("No",&SubModStatus);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
		tc_strdup("No",&SubModStatus);
	}
	
	jump:
	   printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
	   
	return SubModStatus;
}

char* TC_LibraryVehLinkFreq(char* SAddr, char* SNo, char* SRev, char* SSeq)
{
	//trimwhitespace(SAddr);
	//trimwhitespace(SNo);
	//trimwhitespace(SRev);
	//trimwhitespace(SSeq);
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	char* Tbl_SubModDrAr = NULL;
	char* Tbl_SubModVehLink = NULL;
	char* SubModVehLinkFreqStatus = NULL;
	
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {SAddr};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n SubModule Address Revision Exist So Continue To Check Submodule Present or Not..!!\n");fflush(stdout);
			tsubmodlib_rev = titemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_drarstatus", &Tbl_SubModDrAr));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_info1", &Tbl_SubModVehLink));
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
					printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
					printf("\n Table SubModule AR/DR: [%s]",Tbl_SubModDrAr);fflush(stdout);
					printf("\n Table SubModule Vehicle Link Frequency: [%s]",Tbl_SubModVehLink);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(Tbl_SubModRev!=NULL)trimwhitespace(Tbl_SubModRev);
					if(Tbl_SubModSeq!=NULL)trimwhitespace(Tbl_SubModSeq);
					if(Tbl_SubModDrAr!=NULL)trimwhitespace(Tbl_SubModDrAr);
					if(Tbl_SubModVehLink!=NULL)trimwhitespace(Tbl_SubModVehLink);
					//if((tc_strcmp(SNo,Tbl_SubModNo)==0) && (tc_strcmp(SRev,Tbl_SubModRev)==0) && (tc_strcmp(SSeq,Tbl_SubModSeq)==0))
					if(tc_strcmp(SNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched So Exit..!!\n");fflush(stdout);
						tc_strdup(Tbl_SubModVehLink,&SubModVehLinkFreqStatus);
                        goto jump;						
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SAddr\n");fflush(stdout);
				tc_strdup("NA",&SubModVehLinkFreqStatus);
			}    
		}
		else
		{
		   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
		   tc_strdup("NA",&SubModVehLinkFreqStatus);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
		tc_strdup("NA",&SubModVehLinkFreqStatus);
	}
	
	jump:
	   printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
	   
	return SubModVehLinkFreqStatus;
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	//trimwhitespace(PSrch);
	//trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport)
{
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cModAddress = NULL;
		char* cProjCode = NULL;
	    char* cProjCodeDup = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* LibStatus = NULL;
		char* LibVehLinkFreqStatus = NULL;
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
	
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			cModAddress = subString(cItem_Id, 4, 5);
			trimwhitespace(cModAddress);
			printf("\n Part Module Address Value: [%s]", cModAddress);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_ProjectCode", &cProjCode));
			if(tc_strlen(cProjCode)>0)
			{
				tc_strdup(cProjCode,&cProjCodeDup);
			}
			else
			{
				tc_strdup("--",&cProjCodeDup);
				printf("\n Project Code Value is NULL");fflush(stdout);
			}
			trimwhitespace(cProjCodeDup);
			printf("\n Project Code Value After Dup & Trim: [%s]\n", cProjCodeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartStatus", &cArDrStatus));
			if(tc_strlen(cArDrStatus)>0)
			{
				tc_strdup(cArDrStatus,&cArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&cArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(cArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", cArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("--",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Part Revision: [%s]", cItem_Rev);
			printf("\nChild_Level Part Sequence: [%s]", cItem_Seq);
			printf("\nChild_Level Project Code: [%s]", cProjCodeDup);
			printf("\nChild_Level Part AR/DR Status: [%s]", cArDrStatusDup);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if(tc_strcmp(cPartTypeDup,"Module")==0)
				{
					printf("\n Function2: SubModule Library Status Find Start\n");fflush(stdout);
                    LibStatus = TC_LibraryStatus(cModAddress,cItem_Id,cItem_Rev,cItem_Seq);
					printf("\n Function2: SubModule Library Status Find End\n");fflush(stdout);
					printf("\n Function3: SubModule Library Vehicle Linkage Frequency Find Start\n");fflush(stdout);
                    LibVehLinkFreqStatus = TC_LibraryVehLinkFreq(cModAddress,cItem_Id,cItem_Rev,cItem_Seq);
					printf("\n Function3: SubModule Library Vehicle Linkage Frequency Find End\n");fflush(stdout);
					if((tc_strcmp(LibStatus,"Yes")==0) && (tc_strlen(LibVehLinkFreqStatus)>1))
					{
						if((tc_strcmp(cArDrStatusDup,"DR4")!=0) || (tc_strcmp(cArDrStatusDup,"AR4")!=0) || (tc_strcmp(cArDrStatusDup,"DR5")!=0) || (tc_strcmp(cArDrStatusDup,"AR5")!=0))
						{
							fprintf(FP_OutputReport,"%s^%s^%s^%s^%s^%s^%s^\n",cItem_Id,cItem_Rev,cItem_Seq,cProjCodeDup,cArDrStatusDup,cPartTypeDup,cModAddress);fflush(FP_OutputReport);
						}
						else
						{
							printf("\n !!!!!!!! Part DR/AR Status: DR4 or AR4 or DR5 or AR5 !!!!!!!!");fflush(stdout);
						}
					}
					else
					{
						printf("\n !!!!!!!! Either Part Not Present in MCC Library or Vehicle Link Frequency Status Less Than Two(2) !!!!!!!!");fflush(stdout);
					}
				}
			}
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				printf("\n!!!!!!!!!! I N N E R  C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			} */
		}
		
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRev,char* VehicleSeq,char* VDrAr,char* VehicleRS,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Desc = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubProjCode = NULL;
	char* ctopSubProjCodeDup = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_ProjectCode", &ctopSubProjCode));
			if(tc_strlen(ctopSubProjCode)>0)
			{
				tc_strdup(ctopSubProjCode,&ctopSubProjCodeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubProjCodeDup);
				printf("\n Project Code Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubProjCodeDup);
			printf("\n Project Code Value After Dup & Trim: [%s]\n", ctopSubProjCodeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartStatus", &ctopSubArDrStatus));
			if(tc_strlen(ctopSubArDrStatus)>0)
			{
				tc_strdup(ctopSubArDrStatus,&ctopSubArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&ctopSubArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", ctopSubArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Project Code: [%s]", ctopSubProjCodeDup);
			printf("\nTop_Level AR/DR: [%s]", ctopSubArDrStatusDup);
			printf("\nTop_Level Part Type: [%s]", ctopSubPartTypeDup);		
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if(tc_strcmp(ctopSubPartTypeDup,"Module")==0)
				{
				   fprintf(VehRpt,"%s^%s^%s^%s^%s^%s^%s^\n",ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubProjCodeDup,ctopSubArDrStatusDup,ctopSubPartTypeDup,"--");fflush(VehRpt);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	//char *RptFile = (char *) malloc(100*sizeof(char));
	//char *VCompFile = (char *) malloc(100*sizeof(char));
	//char *VFData = (char *) malloc(500*sizeof(char));
	char *RptFile = (char *) MEM_alloc(500 * sizeof(char *));
	char *VCompFile = (char *) MEM_alloc(500 * sizeof(char *));
	//char *VFData =(char *) MEM_alloc(500 * sizeof(char *));
	tag_t DesRev_tag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str = NULL;
	char *item_drar_strDup = NULL;
	char *Veh_Desc = NULL;
	char *Veh_DescDup = NULL;
	char *inp_id_str = NULL;
	char *inp_rev_str = NULL;
	char *inp_seq_str = NULL;
	char *inp_email_str = NULL;
	char *inp_id_strDup = NULL;
	char *inp_rev_strDup = NULL;
	char *inp_seq_strDup = NULL;
	char *inp_email_strDup = NULL;
	//char *inp_revseq_strdup = (char *) malloc(20*sizeof(char));
	char *inp_revseq_strdup =(char *) MEM_alloc(20 * sizeof(char *));
	
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inp_id_str = ITK_ask_cli_argument("-Veh=");
	inp_rev_str = ITK_ask_cli_argument("-Rev=");
	inp_seq_str = ITK_ask_cli_argument("-Seq=");
	//inp_email_str = ITK_ask_cli_argument("-Email=");
	
	trimwhitespace(inp_id_str);
	trimwhitespace(inp_rev_str);
	trimwhitespace(inp_seq_str);
	//trimwhitespace(inp_email_str);
	if(inp_id_str!=NULL)tc_strdup(inp_id_str,&inp_id_strDup);
	if(inp_rev_str!=NULL)tc_strdup(inp_rev_str,&inp_rev_strDup);
	if(inp_seq_str!=NULL)tc_strdup(inp_seq_str,&inp_seq_strDup);
	//if(inp_email_str!=NULL)tc_strdup(inp_email_str,&inp_email_strDup);
	
	printf(" [1]: Input Part No(inp_id_strDup): [%s]\n",inp_id_strDup);
	printf(" [2]: Input Part Rev(inp_rev_strDup): [%s]\n",inp_rev_strDup);
	printf(" [3]: Input Part Seq(inp_seq_strDup): [%s]\n",inp_seq_strDup);
	//printf(" [4]: Input User Email(inp_email_strDup): [%s]\n",inp_email_strDup);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	tc_strcpy(inp_revseq_strdup,inp_rev_strDup);
	tc_strcat(inp_revseq_strdup,"*");
	tc_strcat(inp_revseq_strdup,inp_seq_strDup);
	printf(" Final: Part_Rev_Seq Value(inp_revseq_strdup): [%s]\n",inp_revseq_strdup);
	
	printf("\n Finding Query[DesignRevision Sequence]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","ID"};
		char *cValues[2]  = {inp_revseq_strdup,inp_id_strDup};
		//char *cValues[2]  = {"A*2","51780353R"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
			    if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
					trimwhitespace(item_id_strDup);
				}
				else
			    {
					tc_strdup("--",&item_id_strDup);
					printf("\n Vehicle Number Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
			    if(tc_strlen(item_revseq_str)>0)
				{
					tc_strdup(item_revseq_str,&item_revseq_strDup);
					trimwhitespace(item_revseq_strDup);
				}
				else
			    {
					tc_strdup("--",&item_revseq_strDup);
					printf("\n Vehicle Revision Sequence Value is NULL..!!");fflush(stdout);
				}
				Veh_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
				if(tc_strlen(Veh_Desc)>0)
				{
					tc_strdup(Veh_Desc,&Veh_DescDup);
					trimwhitespace(Veh_DescDup);
				}
				else
			    {
					tc_strdup("--",&Veh_DescDup);
					printf("\n Vehicle Description Value is NULL..!!");fflush(stdout);
				}
				printf("\n Vehicle Description Value: [%s]", Veh_DescDup);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&Newitem_revseq_str));
			    if(tc_strlen(Newitem_revseq_str)>0)
				{
					tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
					trimwhitespace(Newitem_revseq_strDup);
					item_rev_str=strtok(Newitem_revseq_strDup,";");
			        item_seq_str=strtok(NULL,";");
					if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			        if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
					trimwhitespace(item_rev_strDup);
					trimwhitespace(item_seq_strDup);
				}
				else
			    {
					tc_strdup("--",&Newitem_revseq_strDup);
					printf("\n [New]Vehicle Revision Sequence Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartStatus",&item_drar_str));
			    if(tc_strlen(item_drar_str)>0)
				{
					tc_strdup(item_drar_str,&item_drar_strDup);
					trimwhitespace(item_drar_strDup);
				}
				else
			    {
					tc_strdup("--",&item_drar_strDup);
					printf("\n Vehicle DR/AR Status Value is NULL..!!");fflush(stdout);
				}
				
				printf("\n Generating Vehicle Link Module Input File Name..!!");fflush(stdout);
				tc_strcpy(VCompFile,"/tmp/");
				tc_strcat(VCompFile,"VLINKMOD");
				tc_strcat(VCompFile,"_");
				tc_strcat(VCompFile,item_id_strDup);
				tc_strcat(VCompFile,"_");
				tc_strcat(VCompFile,item_rev_strDup);
				tc_strcat(VCompFile,"_");
				tc_strcat(VCompFile,item_seq_strDup);
				tc_strcat(VCompFile,"_");
				tc_strcat(VCompFile,item_drar_strDup);
				tc_strcat(VCompFile,"_");
				tc_strcat(VCompFile,GenDate);
				tc_strcat(VCompFile,".txt");
				printf("\n Vehicle Link Module Input File Name: [%s]", VCompFile);fflush(stdout);
				printf("\n Vehicle Link Module Input File Name Generated..!!");fflush(stdout);
				
				FILE* fpvcomp_file = fopen(VCompFile, "w");
				if(fpvcomp_file == NULL)
				{
					printf("\n Unable to Open Vehicle Link Module Input File: --------> [%s]",VCompFile);fflush(stdout);
					return 0;
				}
				printf("\n Function1: Vehicle Child Details Find Start\n");fflush(stdout);
				TC_VehChild_Details(item_id_strDup,item_rev_strDup,item_seq_strDup,item_drar_strDup,item_revseq_strDup,fpvcomp_file);
			    printf("\n Function1: Vehicle Child Details Find End\n");fflush(stdout);
				fclose(fpvcomp_file);			
			}
		}
		else
        {
			printf(" Revision Found Zero[0] After DesRev_ERC_Rlzd Query..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" DesRev_ERC_Rlzd Tag Not Found..!!\n");fflush(stdout);
    }
	
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *SrcPart_No = NULL;
	char *SrcRevSeq = NULL;
	char *SrcDesGrp = NULL;
	FILE *fpOutput_file = NULL;
	char *fitem_id_str = NULL;
	char *fitem_rev_str = NULL;
	char *fitem_seq_str = NULL;
	char *item_proj_str = NULL;
	char *item_ardr_str = NULL;
	char *item_ptype_str = NULL;
	char *fitem_id_strDup = NULL;
	char *fitem_rev_strDup = NULL;
	char *fitem_seq_strDup = NULL;
	//char *item_revseq_strDup = (char *) malloc(20*sizeof(char));
	char *item_rs_strdup =(char *) MEM_alloc(20 * sizeof(char *));
	tag_t vltItemobj = NULLTAG;
	int nvl_entries = 2;
	int nvl_itemobj_found = 0;
	tag_t* tvlitemobj_results = NULLTAG;
	tag_t tvlQryDesRev = NULLTAG;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	int p = 0;
	char *Parent_ID = NULL;
	char *Parent_RevSeq = NULL;
	char *Parent_IDDup = NULL;
	char *Parent_RevSeqDup = NULL;
	char *Parent_PartType = NULL;
	char *Parent_PartTypeDup = NULL;
	tag_t tParentDesRev = NULLTAG;
	char *item_add_str = NULL;
	char *item_add_strDup = NULL;
	char *PreVCompFile = (char *) MEM_alloc(500 * sizeof(char *));
	char *ERCRlzdDt = NULL;
	
	char DTStamp[100] = "";
	time_t 	dtnow;
	struct 	tm dtwhen;
	time(&dtnow);
	dtwhen = *localtime(&dtnow);
	strftime(DTStamp,100,"%d_%b_%Y_%H_%M_%S",&dtwhen);
	printf(" Current TimeStamp: [%s]\n", DTStamp);fflush(stdout);
	
	printf("\n Generating XML Report File Name..!!");fflush(stdout);
	tc_strcpy(PreVCompFile,"/tmp/");
	tc_strcat(PreVCompFile,"VehLink_Mod_Report");
	tc_strcat(PreVCompFile,"_");
	tc_strcat(PreVCompFile,DTStamp);
	tc_strcat(PreVCompFile,".xml");
	//Report = fopen("/tmp/VehLink_Mod_Report.xml","w");
	printf("\n Vehicle Link Module Report File Name: [%s]", PreVCompFile);fflush(stdout);
	
	Report = fopen(PreVCompFile,"w");
	if(Report == NULL)
	{
		printf("ERROR: Unable To Open XML File..!!\n");
		return 0;
	}
	else
	{
		printf("\n XML File Opened Successfully..!!\n");
	}
	write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	write2xml(Report,"<VehLinkStatRpt>\n");
	write2xml(Report,"<PartDetails>\n");
	write2xml(Report,"<Veh>"); if(tc_strlen(item_id_strDup)>0) write2xml(Report,item_id_strDup); else write2xml(Report,"NA"); write2xml(Report,"</Veh>\n");
	write2xml(Report,"<Rev>"); if(tc_strlen(item_rev_strDup)>0) write2xml(Report,item_rev_strDup); else write2xml(Report,"NA"); write2xml(Report,"</Rev>\n");
	write2xml(Report,"<Seq>"); if(tc_strlen(item_seq_strDup)>0) write2xml(Report,item_seq_strDup); else write2xml(Report,"NA"); write2xml(Report,"</Seq>\n");
	write2xml(Report,"<Desc>"); if(tc_strlen(Veh_DescDup)>0) write2xml(Report,Veh_DescDup); else write2xml(Report,"NA"); write2xml(Report,"</Desc>\n");
	write2xml(Report,"<DRAR>"); if(tc_strlen(item_drar_strDup)>0) write2xml(Report,item_drar_strDup); else write2xml(Report,"NA"); write2xml(Report,"</DRAR>\n");
	write2xml(Report,"<DT>"); if(tc_strlen(DTStamp)>0) write2xml(Report,DTStamp); else write2xml(Report,"NA"); write2xml(Report,"</DT>\n");
	write2xml(Report,"</PartDetails>\n");
	fpPart_List = fopen(VCompFile,"r");
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			
			fitem_id_str=strtok(Buffer,"^");
			fitem_rev_str=strtok(NULL,"^");
			fitem_seq_str=strtok(NULL,"^");
			item_proj_str=strtok(NULL,"^");
			item_ardr_str=strtok(NULL,"^");
			item_ptype_str=strtok(NULL,"^");
			item_add_str=strtok(NULL,"^");
			
			if(fitem_id_str!=NULL)tc_strdup(fitem_id_str,&fitem_id_strDup);
			if(fitem_rev_str!=NULL)tc_strdup(fitem_rev_str,&fitem_rev_strDup);
			if(fitem_seq_str!=NULL)tc_strdup(fitem_seq_str,&fitem_seq_strDup);
			if(item_add_str!=NULL)tc_strdup(item_add_str,&item_add_strDup);
			
			if(fitem_id_strDup!=NULL)trimwhitespace(fitem_id_strDup);
			if(fitem_rev_strDup!=NULL)trimwhitespace(fitem_rev_strDup);
			if(fitem_seq_strDup!=NULL)trimwhitespace(fitem_seq_strDup);
			if(item_add_strDup!=NULL)trimwhitespace(item_add_strDup);
			
			tc_strcpy(item_rs_strdup,fitem_rev_strDup);
			tc_strcat(item_rs_strdup,"*");
			tc_strcat(item_rs_strdup,fitem_seq_strDup);
			
			printf("\n Part No(fitem_id_strDup): [%s]\n",fitem_id_strDup);
			printf("\n Part Rev(fitem_rev_strDup): [%s]\n",fitem_rev_strDup);
			printf("\n Part Seq(fitem_seq_strDup): [%s]\n",fitem_seq_strDup);
			printf("\n Mod Address(item_add_strDup): [%s]\n",item_add_strDup);
			printf("\n Part Rev&Seq(item_rs_strdup): [%s]\n",item_rs_strdup);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&vltItemobj));
            if(vltItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cvlEntries[2]  = {"Revision","ID"};
				char *cvlValues[2]  = {item_rs_strdup,fitem_id_strDup};
				//char *cValues[2]  = {"A*2","5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(vltItemobj, nvl_entries, cvlEntries, cvlValues, &nvl_itemobj_found, &tvlitemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",nvl_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(nvl_itemobj_found > 0)
				{
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (p = 0; p < nvl_itemobj_found; p++)
					{
						tvlQryDesRev = tvlitemobj_results[p];
						ITK_CALL(AOM_ask_value_string(tvlQryDesRev,"item_id",&SrcPart_No));
						ITK_CALL(AOM_ask_value_string(tvlQryDesRev,"item_revision_id",&SrcRevSeq));
						ITK_CALL(AOM_ask_value_string(tvlQryDesRev,"t5_DesignGrp",&SrcDesGrp));
						printf("\n Function3: ERC-Release Date Find Start");fflush(stdout);
						ERCRlzdDt = TC_ERC_DTReleased(tvlQryDesRev);
			            printf("\n Function3: ERC-Release Date Find End\n");fflush(stdout);
						printf("Child Part Details: ----> Child_Part_No: [%s], Child_Part_RevSeq: [%s], Child_Part_Design_Group: [%s], Child_ERC_Released_Date: [%s]\n",SrcPart_No,SrcRevSeq,SrcDesGrp,ERCRlzdDt);fflush(stdout);
						
						if(tc_strcmp(SrcDesGrp,"16")==0)
						{
							printf("\n Function2: [EE_Part] Vehicle Link And Platform Status Find Start..!!\n");fflush(stdout);
						    TC_EEVehLinkStatus(item_add_strDup,SrcPart_No,SrcRevSeq,ERCRlzdDt,Report);
						    printf("\n Function2: [EE_Part] Vehicle Link And Platform Status Find End..!!\n");fflush(stdout);
						}
						else
						{
							printf("\n Function1: [Normal_Part] Vehicle Link And Platform Status Find Start..!!\n");fflush(stdout);
						    TC_VehLinkStatus(item_add_strDup,SrcPart_No,SrcRevSeq,ERCRlzdDt,Report);
						    printf("\n Function1: [Normal_Part] Vehicle Link And Platform Status Find End..!!\n");fflush(stdout);
						}
					}
				}
				else
				{
					printf("\n Design Revision Not Found Continue..!!\n");fflush(stdout);
				}
			}
		}
        printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 		
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	write2xml(Report,"</VehLinkStatRpt>\n");
    fclose(Report);
	
	printf("Current File To Original File Move Start..!!\n");fflush(stdout);
	char* ShellCommandLine = NULL;
	ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	tc_strcpy(ShellCommandLine,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_VehModLinkReport/RemoveProcessFiles.sh");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,PreVCompFile);
	system(ShellCommandLine);
	printf("Current File To Original File Move End..!!\n");fflush(stdout);
	
	printf(" Vehicle Link Module Report Generation End..!!\n");fflush(stdout);	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_exit_module(TRUE);	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_VehLinkModReport.c
* // ./linkitk -o tm_VehLinkModReport tm_VehLinkModReport.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/VehicleLinkedModuleReport/tm_VehLinkModReport .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/VehicleLinkedModuleReport/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/VehicleLinkedModuleReport/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/VehicleLinkedModuleReport/SendEmail.sh .
* // ./tm_VehLinkModReport -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Veh="51374980R" -Rev="NR" -Seq="1"
* // ./tm_VehLinkModReport -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Veh="51374980R" -Rev="NR" -Seq="1"
*
***************************************************************************/