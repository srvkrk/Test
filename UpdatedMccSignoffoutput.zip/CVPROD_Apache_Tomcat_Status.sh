TOMCAT_PID=$(ps -ef | awk '/[t]omcat/{print $2}')
echo TOMCAT PROCESSID $TOMCAT_PID

if [ -z "$TOMCAT_PID" ]
then
    echo "Apache Tomcat-9.0.100 Stopped in CVPROD[172.22.99.106]"
    echo -e "Hi, \n\n                Apache Tomcat-9.0.100 Stopped in CVPROD[172.22.99.106].\n                Please Check Services & Restart.\n                 \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM Admin Category" |Mail -s "STOPPED : Apache Tomcat-9.0.100 in CVPROD[172.22.99.106]" souravk.ttl@tatamotors.com ujjawalk.ttl@tatamotors.com
else
   echo "Apache Tomcat-9.0.100 Running in CVPROD[172.22.99.106]"
   echo -e "Hi, \n\n                Apache Tomcat-9.0.100 Running in CVPROD[172.22.99.106].\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM Admin Category" |Mail -s "RUNNING : Apache Tomcat-9.0.100 in CVPROD[172.22.99.106]" souravk.ttl@tatamotors.com ujjawalk.ttl@tatamotors.com
fi
