#!/bin/bash
. /user/cvprod/.bash_profile

MAILDIR="/var/mail/cvprod@sles15sp4/Maildir/new"
SCRIPT="/user/cvprod/sourav/create_item.sh"

for MAIL in "$MAILDIR"/*; do
  [ -f "$MAIL" ] || continue

  echo "Processing mail: $MAIL"

  # ---- Parse sender ----
  FROM=$(grep -m1 "^From:" "$MAIL" | sed 's/^From: //')

  # ---- Parse subject ----
  SUBJECT=$(grep -m1 "^Subject:" "$MAIL" | sed 's/^Subject: //')

  # ---- Parse body (after blank line) ----
  BODY=$(sed -n '/^$/,$p' "$MAIL" | sed '1d')

  echo "FROM=$FROM"
  echo "SUBJECT=$SUBJECT"
  echo "BODY:"
  echo "$BODY"

  # ---- Call downstream script ----
  "$SCRIPT" "$FROM" "$SUBJECT" "$BODY"

done