./compile CATIAV5UsesPartListWTMSelf.c
./linkitk -o CATIAV5UsesPartListWTMSelf CATIAV5UsesPartListWTMSelf.o
chmod 777 CATIAV5UsesPartListWTMSelf*
