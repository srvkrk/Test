$TC_ROOT/*Patch*/tcPatchExecutable CATIAV5UsesPartListWTMSelf
