datetime=$1
# Extract first 11 characters (the date part)
date_part="${datetime:0:11}"
CSV_FILE="$3"
TO="sanjoym.ttl@tatamotors.com"
SUBJECT="Generic/Instance creo data set checkin report for the date $date_part"
FROM="TCUACVProd@tatamotors.com"
CC="sanjoym.ttl@tatamotors.com"

if [[ -z "$CSV_FILE" ]]; then
  echo "Usage: $0 yourfile.csv"
  exit 1
fi

if [[ ! -f "$CSV_FILE" ]]; then
  echo "CSV file '$CSV_FILE' not found!"
  exit 2
fi

# --- Convert CSV to HTML table ---
html_table=$(awk -v ORS= '
BEGIN {
  print "<table border=\"1\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse: collapse;\">"
}
NR==1 {
  print "<thead><tr>"
  for(i=1; i<=NF; i++) {
    print "<th>" $i "</th>"
  }
  print "</tr></thead><tbody>"
  next
}
{
  print "<tr>"
  for(i=1; i<=NF; i++) {
    print "<td>" $i "</td>"
  }
  print "</tr>"
}
END {
  print "</tbody></table>"
}
' FS=, "$CSV_FILE")

#html_body="<html><body><h2>CSV Data Report</h2>${html_table}</body></html>"

html_body="<html><body><p>Dear All,</p><p>Please find the attached report for the date <strong>$date_part</strong></p><h2>Creo Generic/Instance Dataset Checkin Report</h2>${html_table}<p>Regards<br>PLM Team</p></body></html>"

# --- Prepare MIME boundaries ---
BOUNDARY="=====BOUNDARY_$(date +%s)_$$====="

# --- Encode CSV file as base64 ---
ATTACH_B64=$(base64 < "$CSV_FILE")

# --- Compose MIME email and send ---
{
  echo "From: $FROM"
  echo "To: $TO"
  [[ -n "$CC" ]] && echo "Cc: $CC"
  echo "Subject: $SUBJECT"
  echo "MIME-Version: 1.0"
  echo "Content-Type: multipart/mixed; boundary=\"$BOUNDARY\""
  echo
  echo "This is a multi-part message in MIME format."
  echo
  echo "--$BOUNDARY"
  echo "Content-Type: text/html; charset=UTF-8"
  echo "Content-Transfer-Encoding: 7bit"
  echo
  echo "$html_body"
  echo
  echo "--$BOUNDARY"
  echo "Content-Type: text/csv; name=\"$(basename "$CSV_FILE")\""
  echo "Content-Transfer-Encoding: base64"
  echo "Content-Disposition: attachment; filename=\"$(basename "$CSV_FILE")\""
  echo
  echo "$ATTACH_B64"
  echo
  echo "--$BOUNDARY--"
} | /usr/sbin/sendmail -t

echo "Email with HTML body and CSV attachment sent!"