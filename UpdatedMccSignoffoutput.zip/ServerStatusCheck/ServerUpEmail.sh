######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it.
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : NOV-2024
#
#######################################################################################

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"
echo -e "\nServer-Up Email Send Started...."
echo -e "Hi, \n\n                EXE Running Successfully on CVPROD Utility Server[172.22.99.106].\n                 \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS : CVPROD Server Status" souravk.ttl@tatamotors.com
echo -e "\nServer-Up Email Send Ended...."
echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"