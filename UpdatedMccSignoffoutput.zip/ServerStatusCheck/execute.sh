/user/cvprod/sourav/ServerStatusCheck/tm_serverstatuscheck -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
