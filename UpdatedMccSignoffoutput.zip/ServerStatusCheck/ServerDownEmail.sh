######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it.
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : SEPT-2023
#
#######################################################################################

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"
echo "Server-Down Email Send Started...."
echo -e "Hi, \n\n                There is Some Issue in EXE Running on CVPROD Utility Server[172.22.99.106].\n                Please Check Log & Inform To Admin Team.\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED : CVPROD Server Status" souravk.ttl@tatamotors.com
echo "Server-Down Email Send Ended...."
echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"