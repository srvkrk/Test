mail -s "CREATE_ITEM" -r souravk.ttl@tatamotors.com cvprod@sles15sp4  <<EOF

ItemID=EML_2001
ItemName=Gear Box
ItemType=Item
Revision=A
EOF
