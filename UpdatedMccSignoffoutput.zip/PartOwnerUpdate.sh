. /user/cvprod/.bash_profile
cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD/PartOwnerUpdate
#echo "I am in Updation">>/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD/PartPropertyUpdate/PartPropertyUpdate_1.txt
#echo $1>>/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD/PartPropertyUpdate/PartPropertyUpdate_1.txt
#echo $2>>/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD/PartPropertyUpdate/PartPropertyUpdate_1.txt
#echo $3>>/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD/PartPropertyUpdate/PartPropertyUpdate_1.txt
#echo $4>>/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD/PartPropertyUpdate/PartPropertyUpdate_1.txt
./PartOwnerUpdate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=$1 -r=$2 -s=$3
