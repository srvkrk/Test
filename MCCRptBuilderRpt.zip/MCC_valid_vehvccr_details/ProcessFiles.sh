cd /user/cvprod/sourav/MCC_valid_vehvccr_details
rm -rf $1
rm -rf $2
rm -rf $3
rm -rf $4

echo -e "\nFile Copy Started...."
cp /user/cvprod/sourav/MCC_valid_vehvccr_details/$5 /user/cvprod/sourav/MCCMAINDASHBOARD/PartList.txt
cp /user/cvprod/sourav/MCC_valid_vehvccr_details/$6 /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_VehicleDetails/PartList.txt
echo -e "\nFile Copy Ended...."
