/user/cvprod/sourav/MCC_valid_vehvccr_details/tm_mcc_valid_vehvccr -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
