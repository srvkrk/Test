./compile tm_mcc_generate_maxardr_status.c
./linkitk -o tm_mcc_generate_maxardr_status tm_mcc_generate_maxardr_status.o
chmod 777 tm_mcc_generate_maxardr_status*
