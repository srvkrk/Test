/user/cvprod/sourav/MCC_NewPartReqReport/NewPartReqMCCSignOff -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -F=07-Apr-2024 -T=31-Jul-2025&
