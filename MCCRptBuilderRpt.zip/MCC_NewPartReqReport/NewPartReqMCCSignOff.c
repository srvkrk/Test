/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: NewPartRequest.c
**
** Functions: This utility takes from date and to date and then generate report of NPR's MCC node signed off history
**
** command to run:
** ./NewPartReqMCCSignOff -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -F=07-Apr-2024 -T=31-Jul-2025
***********************************************************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <epm/signoff.h>
#include <ce/ce.h>
#include <tc/folder.h>
#include <tccore/project.h>
#include <tc/tc_startup.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <ug_va_copy.h>
#include <base_utils/Mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/item_msg.h>
#include <constants/constants.h>
#include <common/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>

#include <stdio.h>
#include <time.h>
#include <stdbool.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


int			ifail 				= ITK_ok;
FILE *Report = NULL;
int ctr=0;


int read_value_from_file(char*);
//int get_object(char* item_id);
int get_object();
int get_owning_user_and_group(tag_t);
void setAddTAG(int *count,tag_t **objlist,tag_t obj );


void print_requirement()
{
	printf(
	"\nHELP:\n"
	"NewPartReqMCCSignOff -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -F=07-Apr-2024 -T=31-Jul-2025\n"
	"--------------------------------------------------------------------\n\n"
	);fflush(stdout);
}

char* MonthAbbreviation (char* MonthName)
{
	//char *ResponseMonth = (char *) malloc(400*sizeof(char));
	char *ResponseMonth = NULL;
	ResponseMonth = (char *) MEM_alloc( 400 * sizeof(char) );
	printf("\n Input Month Name in String: --------> [%s]\n", MonthName);fflush(stdout);
	if(tc_strcmp(MonthName,"Jan")==0)
	{
		tc_strcpy(ResponseMonth,"01");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Feb")==0)
	{
		tc_strcpy(ResponseMonth,"02");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Mar")==0)
	{
		tc_strcpy(ResponseMonth,"03");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Apr")==0)
	{
		tc_strcpy(ResponseMonth,"04");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"May")==0)
	{
		tc_strcpy(ResponseMonth,"05");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Jun")==0)
	{
		tc_strcpy(ResponseMonth,"06");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Jul")==0)
	{
		tc_strcpy(ResponseMonth,"07");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Aug")==0)
	{
		tc_strcpy(ResponseMonth,"08");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Sep")==0)
	{
		tc_strcpy(ResponseMonth,"09");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Oct")==0)
	{
		tc_strcpy(ResponseMonth,"10");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Nov")==0)
	{
		tc_strcpy(ResponseMonth,"11");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Dec")==0)
	{
		tc_strcpy(ResponseMonth,"12");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else
	{
		printf("Invalid Number");
	}
	  
	return ResponseMonth;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

// Function to check if a date is a weekday (Monday-Friday)
bool isWeekday(struct tm *date) 
{
    int dayOfWeek = date->tm_wday;
    return (dayOfWeek != 0 && dayOfWeek != 6);
}

// Function to calculate the number of weekdays between two dates
int weekdaysBetween(time_t start, time_t end) 
{
    int weekdays = 0;
    struct tm startDate, endDate;
    localtime_r(&start, &startDate);
    localtime_r(&end, &endDate);

    while (difftime(mktime(&endDate), mktime(&startDate)) > 0) 
    {
        if (isWeekday(&startDate)) 
        {
            weekdays++;
        }
        startDate.tm_mday++;
        mktime(&startDate);
    }

    return weekdays;
}

void replaceSpacesWithSlash(char *str) {
    int i;
    // Iterate through the string until the null terminator is reached
    for (i = 0; str[i] != '\0'; i++) {
        // If the current character is a space, replace it with a forward slash
        if (str[i] == ' ') {
            str[i] = '/';
        }
    }
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
					It checks for the proper Usr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int 			a;
	const char* u = NULL;
	const char* p = NULL;
	const char* g = NULL;
	char			* itemId						= NULL;
	char			* rev						= NULL;
	char			* propName					= NULL;
	char			* propValue					= NULL;



	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-pf=");
	g = ITK_ask_cli_argument( "-g=");

	char*  F_date = ITK_ask_cli_argument("-F=");
	char*  T_date = ITK_ask_cli_argument("-T=");
	
	char*   From_date = NULL;
	char*   To_date = NULL;
	
	From_date = (char *) MEM_alloc(100);
	To_date = (char *) MEM_alloc(100);
		
	tc_strcpy(From_date,"");
	tc_strcpy(From_date,F_date);
	tc_strcat(From_date," 00:00");
		
	tc_strcpy(To_date,"");
	tc_strcpy(To_date,T_date);
	tc_strcat(To_date," 23:59");
	printf("\n\n\n\n\nFrom date [%s] \n To Date [%s]",From_date,To_date);fflush(stdout);
	
	
	//itemId = ITK_ask_cli_argument("-i=");

//	if(tc_strlen(stripBlanks(itemId)) == 0)
//	{
//		print_requirement();
//		return -1;
//	}

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");fflush(stdout);
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}

	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		ifail = ITK_set_bypass(true);
		//output = fopen("output.csv", "w");
		//ifail = get_object();
		ifail = get_object(From_date,To_date);		
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}

	printf("\nEnd of program.....!!\n");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
/*
int read_value_from_file(char* Filename)
{
	char 		*itemid					= NULL;
	char 		temp[200];

	FILE		* fp 					= NULL;

	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "~");
				printf("\nInput Item_id:%s\n",itemid);fflush(stdout);

				ifail = get_object(itemid);
			}
			printf("***************************************\n");fflush(stdout);
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");fflush(stdout);
	}
	fclose(fp);
	return ifail;
}
*/


/********************************************************************************************
    Function:       get_object
    Description:    This function takes the item_id as input and queries into TC and gets
					item, BV, item_rev, it's BVR, and secondary object.
********************************************************************************************/

char* NewPartsubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf = NULL;
	//retStringf = (char*) malloc(30);
	retStringf = (char *) MEM_alloc( 300 * sizeof(char) );
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;

}

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

/* Function to add Tag into a set of Tag */	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTAG1");fflush(stdout);
		//(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
		(*objlist) = (tag_t *)MEM_alloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTAG2");fflush(stdout);
		//(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
		(*objlist) = (tag_t *)MEM_realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

void replace_multiple_newlines(char *str, char replacement) {
    int read = 0, write = 0;
    int in_newline_sequence = 0;

    while (str[read] != '\0') {
        if (str[read] == '\n' || str[read] == ',') {
            if (!in_newline_sequence) {
                str[write++] = replacement;  // Replace first '\n' in sequence
                in_newline_sequence = 1;
            }
            // else skip additional '\n's
        } else {
            str[write++] = str[read];
            in_newline_sequence = 0;
        }
        read++;
    }
    str[write] = '\0';  // Null-terminate the modified string
}
void replace_newline(char *str, char replacement)
{
	printf("\n Before str========>:[%s]\n",str);fflush(stdout);
	int lenth= 0;
	lenth = tc_strlen(str);
	printf("\n Before str lenth========>:[%d]\n",lenth);fflush(stdout);
    for (int i = 0; str[i] != '\0'; i++)
	//for (int i = 0; i<lenth; i++)
	{
		if (str[i] == '\n')
		{
            str[i] = replacement;
        }
		else if (str[i] == ',')
		{
            str[i] = replacement;
        }
		else if (str[i] == '\\')
		{
            str[i] = replacement;
        }
		
		else if (str[i] == ';')
		{
            str[i] = replacement;
        }
		else if (str[i] == '=')
		{
            str[i] = replacement;
        }
		else if (str[i] == '\"')
		{
            str[i] = replacement;
        }
		else if (str[i] == '@')
		{
            str[i] = replacement;
        }
		else if (str[i] == '$')
		{
            str[i] = replacement;
        }
		else if (str[i] == '%')
		{
            str[i] = replacement;
        }
		else if (str[i] == '(')
		{
            str[i] = replacement;
        }
		else if (str[i] == ')')
		{
            str[i] = replacement;
        }
    }
	printf("\n After str========>:[%s]\n",str);fflush(stdout);
}

void remove_chars(char *str, const char *chars_to_remove) {
    int i, j;
	printf("\n 1remove_chars::str========>:[%s]\n",str);fflush(stdout);
    int str_len = strlen(str);
    int chars_len = strlen(chars_to_remove);

    for (i = 0, j = 0; i < str_len; i++) {
        int remove = 0;
        for (int k = 0; k < chars_len; k++) {
            if (str[i] == chars_to_remove[k]) {
                remove = 1;
                break;
            }
        }
        if (!remove) {
            str[j++] = str[i];
        }
    }
    str[j] = '\0';
	printf("\n 2remove_chars::str========>:[%s]\n",str);fflush(stdout);
}

void trim_newline(char *str) {
    size_t len = strlen(str);
    if (len > 0 && (str[len - 1] == '\n' || str[len - 1] == '\r' || str[len - 1] == ',')) {
        str[len - 1] = '\0';
    }
}


void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y_%H_%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%m_%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int get_object(char* s_date, char* e_date)
//int get_object(char* item_id)
{

	int				n_tags_found				= 0;
	int				count						= 0;
	int				totalprocess				= 0;
	int				processcounter				= 0;
	int				ModuleRevsignOfCount		= 0;
	int				COCsignOfCount				= 0;
	int				COCHsignOfCount				= 0;
	int				MCCsignOfCount				= 0;
	int				AssignsignOfCount			= 0;
	int				reviewcounter				= 0;
	int				process_counter				= 0;
	int				ModuleTL					= 0;
	int				COCP						= 0;
	int				COCH						= 0;
	int				MCC							= 0;
	int				ASSIGN						= 0;
	int				q						= 0;
	int				s						= 0;

	tag_t			itemRev_t				= NULLTAG;
	tag_t			latest_rev_tag			= NULLTAG;
	tag_t			*ProcessStageList		= NULLTAG;
	tag_t			query					= NULLTAG;
	tag_t			ProcessStage			= NULLTAG;

	tag_t			*tags_found				= NULLTAG;
	tag_t			*ModuleRevSignOffTeam	= NULLTAG;
	tag_t			*COCSignOffTeam			= NULLTAG;
	tag_t			*COCHSignOffTeam		= NULLTAG;
	tag_t			*MCCSignOffTeam			= NULLTAG;
	tag_t			*AssignSignOffTeam		= NULLTAG;
	tag_t			Process_Stage			= NULLTAG;
	tag_t			ReviewProcessStage		= NULLTAG;


	FILE		*output1 			= NULL;
	FILE		*output 			= NULL;


	char 			*AssignedTCUATmlPartNumber	= NULL;
	char 			*NewPartReqNumber			= NULL;
	char 			*LatRev_ObjectType			= NULL;
	char 			*NPRCreator					= NULL;
	char 			*processName				= NULL;
	char 			*processResult				= NULL;
	char 			*processState				= NULL;
	char 			*processtype				= NULL;

	char 			*ModuleRevprocessResult		= NULL;
	char 			*ModuleRevprocessState		= NULL;
	char 			*ModuleRevprocessStDate		= NULL;
	char 			*ModuleRevprocessEndDate	= NULL;
	char 			*ModuleRevprocessPerformer	= NULL;

	char 			*COCPprocessResult			= NULL;
	char 			*COCPprocessState			= NULL;
	char 			*COCPprocessStDate			= NULL;
	char 			*COCPprocessEndDate			= NULL;
	char 			*COCPprocessPerformer		= NULL;

	char 			*COCHprocessResult			= NULL;
	char 			*COCHprocessState			= NULL;
	char 			*COCHprocessStDate			= NULL;
	char 			*COCHprocessEndDate			= NULL;
	char 			*COCHprocessPerformer		= NULL;

	char 			*MCCprocessResult			= NULL;
	char 			*MCCprocessState			= NULL;
	char 			*MCCprocessStDate			= NULL;
	char 			*MCCprocessEndDate			= NULL;
	char 			*MCCprocessPerformer		= NULL;

	char 			*ModuleRevSignOffTeamMember		= NULL;
	char 			*COCPSignOffTeamMember			= NULL;
	char 			*COCHSignOffTeamMember			= NULL;
	char 			*MCCSignOffTeamMember			= NULL;
	char 			*AssignSignOffTeamMember		= NULL;

	char 			*AssignprocessResult			= NULL;
	char 			*AssignprocessState				= NULL;
	char 			*AssignprocessStDate			= NULL;
	char 			*AssignprocessEndDate			= NULL;
	char 			*AssignprocessPerformer			= NULL;

	char 			*process_Name					= NULL;
	char 			*process_type					= NULL;
	
	char 			*Aggregate_value					= NULL;
	char 			*MCCStatus_value					= NULL;
	int 			D_cab_approved					= 0;
	int 			D_cab_dropped					= 0;
	int 			D_cab_total						= 0;
	int 			F_chasis_approved				= 0;
	int 			F_chasis_dropped				= 0;
	int 			F_chasis_total					= 0;
	int 			G_Electrical_approved			= 0;
	int 			G_Electrical_dropped			= 0;
	int 			G_Electrical_total				= 0;
	int 			K_Vehicle_approved				= 0;
	int 			K_Vehicle_dropped				= 0;
	int 			K_Vehicle_total					= 0;
	int 			A_Application_approved			= 0;
	int 			A_Application_dropped			= 0;
	int 			A_Application_total				= 0;
	int 			H_POWERTRAIN_approved			= 0;
	int 			H_POWERTRAIN_dropped			= 0;
	int 			H_POWERTRAIN_total				= 0;
	int 			TOTAL_AGGRE_ALL_AGGREATE		= 0;
	int 			TOTAL_DROP_ALL_AGGREATE			= 0;
	int 			TOTAL_Grand_ALL_AGGREATE		= 0;

	
	char 			*D_cab_approvedStr					= NULL;
	char 			*D_cab_droppedStr					= NULL;
	char 			*D_cab_totalStr						= NULL;
	char 			*F_chasis_approvedStr				= NULL;
	char 			*F_chasis_droppedStr				= NULL;
	char 			*F_chasis_totalStr					= NULL;
	char 			*G_Electrical_approvedStr			= NULL;
	char 			*G_Electrical_droppedStr			= NULL;
	char 			*G_Electrical_totalStr				= NULL;
	char 			*H_POWERTRAIN_approvedStr			= NULL;
	char 			*H_POWERTRAIN_droppedStr			= NULL;
	char 			*H_POWERTRAIN_totalStr				= NULL;
	char 			*K_Vehicle_approvedStr				= NULL;
	char 			*K_Vehicle_droppedStr				= NULL;
	char 			*K_Vehicle_totalStr					= NULL;
	char 			*A_Application_approvedStr			= NULL;
	char 			*A_Application_droppedStr			= NULL;
	char 			*A_Application_totalStr				= NULL;
	char 			*TOTAL_AGGRE_ALL_AGGREATEdStr		= NULL;
	char 			*TOTAL_DROP_ALL_AGGREATEStr			= NULL;
	char 			*TOTAL_Grand_ALL_AGGREATEStr		= NULL;

	char 			*temp_D_cab_approvedStr					= NULL;
	char 			*temp_D_cab_droppedStr					= NULL;
	char 			*temp_D_cab_totalStr						= NULL;
	char 			*temp_F_chasis_approvedStr				= NULL;
	char 			*temp_F_chasis_droppedStr				= NULL;
	char 			*temp_F_chasis_totalStr					= NULL;
	char 			*temp_G_Electrical_approvedStr			= NULL;
	char 			*temp_G_Electrical_droppedStr			= NULL;
	char 			*temp_G_Electrical_totalStr				= NULL;
	char 			*temp_H_POWERTRAIN_approvedStr			= NULL;
	char 			*temp_H_POWERTRAIN_droppedStr			= NULL;
	char 			*temp_H_POWERTRAIN_totalStr				= NULL;
	char 			*temp_K_Vehicle_approvedStr				= NULL;
	char 			*temp_K_Vehicle_droppedStr				= NULL;
	char 			*temp_K_Vehicle_totalStr					= NULL;
	char 			*temp_A_Application_approvedStr			= NULL;
	char 			*temp_A_Application_droppedStr			= NULL;
	char 			*temp_A_Application_totalStr				= NULL;
	char 			*tmlpart_value						= NULL;
	char 			*PartType							= NULL;
	char 			*ApproveComment							= NULL;
	char 			*RejectComment							= NULL;

	tag_t			*soResultApproved				= NULLTAG;
	int				TotalApprovedTask				= 0;

	tag_t			*soResultReject				= NULLTAG;
	int				TotalRejectTask				= 0;
	int				nprapprove				= 0;
	int				nprreject				= 0;
	int				ApproveComment_1				= 0;
	int				ApproveComment_2				= 0;
	int				ApproveComment_3				= 0;
	int				ApproveComment_4				= 0;
	int				ApproveComment_5				= 0;
	int				ApproveComment_6				= 0;
	int				ApproveComment_7				= 0;
	int				ApproveComment_8				= 0;
	int				ApproveComment_9				= 0;
	int				ApproveComment_10				= 0;
	int				ApproveComment_11				= 0;
	int				ApproveComment_12				= 0;
	int				ApproveComment_13				= 0;
	int				ApproveComment_14				= 0;

	int				RejectComment_1				= 0;
	int				RejectComment_2				= 0;
	int				RejectComment_3				= 0;
	int				RejectComment_4				= 0;
	int				RejectComment_5				= 0;
	int				RejectComment_6				= 0;
	int				RejectComment_7				= 0;
	int				RejectComment_8				= 0;
	int				RejectComment_9				= 0;
	int				RejectComment_10				= 0;
	int				RejectComment_11				= 0;
	
	int				bus_aggreed_1			= 0;
	int				hcv_aggreed_1			= 0;
	int				ilmcv_aggreed_1				= 0;
	int				scv_aggreed_1			= 0;
	int				aggrbusiness_aggreed_1				= 0;
	int				Defence_aggreed_1				= 0;
	
	int				bus_aggreed_2			= 0;
	int				hcv_aggreed_2			= 0;
	int				ilmcv_aggreed_2				= 0;
	int				scv_aggreed_2			= 0;
	int				aggrbusiness_aggreed_2				= 0;
	int				Defence_aggreed_2				= 0;
	
	int				bus_aggreed_3			= 0;
	int				hcv_aggreed_3			= 0;
	int				ilmcv_aggreed_3				= 0;
	int				scv_aggreed_3			= 0;
	int				aggrbusiness_aggreed_3				= 0;
	int				Defence_aggreed_3				= 0;
	
	int				bus_aggreed_4			= 0;
	int				hcv_aggreed_4			= 0;
	int				ilmcv_aggreed_4				= 0;
	int				scv_aggreed_4			= 0;
	int				aggrbusiness_aggreed_4				= 0;
	int				Defence_aggreed_4				= 0;
	
	int				bus_aggreed_5			= 0;
	int				hcv_aggreed_5			= 0;
	int				ilmcv_aggreed_5			= 0;
	int				scv_aggreed_5			= 0;
	int				aggrbusiness_aggreed_5				= 0;
	int				Defence_aggreed_5				= 0;
	
	int				bus_aggreed_6			= 0;
	int				hcv_aggreed_6			= 0;
	int				ilmcv_aggreed_6				= 0;
	int				scv_aggreed_6			= 0;
	int				aggrbusiness_aggreed_6				= 0;
	int				Defence_aggreed_6				= 0;
	
	int				bus_aggreed_7			= 0;
	int				hcv_aggreed_7			= 0;
	int				ilmcv_aggreed_7				= 0;
	int				scv_aggreed_7			= 0;
	int				aggrbusiness_aggreed_7				= 0;
	int				Defence_aggreed_7				= 0;
	
	int				bus_aggreed_8			= 0;
	int				hcv_aggreed_8			= 0;
	int				ilmcv_aggreed_8				= 0;
	int				scv_aggreed_8			= 0;
	int				aggrbusiness_aggreed_8				= 0;
	int				Defence_aggreed_8				= 0;
	
	int				bus_aggreed_9			= 0;
	int				hcv_aggreed_9			= 0;
	int				ilmcv_aggreed_9			= 0;
	int				scv_aggreed_9			= 0;
	int				aggrbusiness_aggreed_9				= 0;
	int				Defence_aggreed_9				= 0;
	
	int				bus_aggreed_10			= 0;
	int				hcv_aggreed_10			= 0;
	int				ilmcv_aggreed_10				= 0;
	int				scv_aggreed_10			= 0;
	int				aggrbusiness_aggreed_10				= 0;
	int				Defence_aggreed_10				= 0;
	
	int				bus_aggreed_11			= 0;
	int				hcv_aggreed_11			= 0;
	int				ilmcv_aggreed_11			= 0;
	int				scv_aggreed_11			= 0;
	int				aggrbusiness_aggreed_11				= 0;
	int				Defence_aggreed_11				= 0;

	int				bus_aggreed_12			= 0;
	int				hcv_aggreed_12			= 0;
	int				ilmcv_aggreed_12			= 0;
	int				scv_aggreed_12			= 0;
	int				aggrbusiness_aggreed_12				= 0;
	int				Defence_aggreed_12				= 0;

	int				bus_aggreed_13			= 0;
	int				hcv_aggreed_13			= 0;
	int				ilmcv_aggreed_13			= 0;
	int				scv_aggreed_13			= 0;
	int				aggrbusiness_aggreed_13				= 0;
	int				Defence_aggreed_13				= 0;

	int				bus_aggreed_14			= 0;
	int				hcv_aggreed_14			= 0;
	int				ilmcv_aggreed_14			= 0;
	int				scv_aggreed_14			= 0;
	int				aggrbusiness_aggreed_14				= 0;
	int				Defence_aggreed_14				= 0;
	
	int				bus_reject_1			= 0;
	int				hcv_reject_1			= 0;
	int				ilmcv_reject_1				= 0;
	int				scv_reject_1			= 0;
	int				aggrbusiness_reject_1				= 0;
	int				Defence_reject_1				= 0;
	
	int				bus_reject_2			= 0;
	int				hcv_reject_2			= 0;
	int				ilmcv_reject_2				= 0;
	int				scv_reject_2			= 0;
	int				aggrbusiness_reject_2				= 0;
	int				Defence_reject_2				= 0;
	
	int				bus_reject_3			= 0;
	int				hcv_reject_3			= 0;
	int				ilmcv_reject_3				= 0;
	int				scv_reject_3			= 0;
	int				aggrbusiness_reject_3				= 0;
	int				Defence_reject_3				= 0;
	
	int				bus_reject_4			= 0;
	int				hcv_reject_4			= 0;
	int				ilmcv_reject_4				= 0;
	int				scv_reject_4			= 0;
	int				aggrbusiness_reject_4				= 0;
	int				Defence_reject_4				= 0;
	
	int				bus_reject_5			= 0;
	int				hcv_reject_5			= 0;
	int				ilmcv_reject_5			= 0;
	int				scv_reject_5			= 0;
	int				aggrbusiness_reject_5				= 0;
	int				Defence_reject_5				= 0;
	
	
	int				bus_reject_6			= 0;
	int				hcv_reject_6			= 0;
	int				ilmcv_reject_6				= 0;
	int				scv_reject_6			= 0;
	int				aggrbusiness_reject_6				= 0;
	int				Defence_reject_6				= 0;
	
	int				bus_reject_7			= 0;
	int				hcv_reject_7			= 0;
	int				ilmcv_reject_7				= 0;
	int				scv_reject_7			= 0;
	int				aggrbusiness_reject_7				= 0;
	int				Defence_reject_7				= 0;
	
	int				bus_reject_8			= 0;
	int				hcv_reject_8			= 0;
	int				ilmcv_reject_8				= 0;
	int				scv_reject_8			= 0;
	int				aggrbusiness_reject_8				= 0;
	int				Defence_reject_8				= 0;
	
	int				bus_reject_9			= 0;
	int				hcv_reject_9			= 0;
	int				ilmcv_reject_9			= 0;
	int				scv_reject_9			= 0;
	int				aggrbusiness_reject_9				= 0;
	int				Defence_reject_9				= 0;
	
	int				bus_reject_10			= 0;
	int				hcv_reject_10			= 0;
	int				ilmcv_reject_10				= 0;
	int				scv_reject_10			= 0;
	int				aggrbusiness_reject_10				= 0;
	int				Defence_reject_10				= 0;
	
	int				bus_reject_11			= 0;
	int				hcv_reject_11			= 0;
	int				ilmcv_reject_11			= 0;
	int				scv_reject_11			= 0;
	int				aggrbusiness_reject_11				= 0;
	int				Defence_reject_11				= 0;
	
	
	
	int 			platform_total_1		=0;
	int 			platform_total_2		=0;
	int 			platform_total_3		=0;
	int 			platform_total_4		=0;
	int 			platform_total_5		=0;
	int 			platform_total_6		=0;
	int 			platform_total_7		=0;
	int 			platform_total_8		=0;
	int 			platform_total_9		=0;
	int 			platform_total_10		=0;
	int 			platform_total_11		=0;
	int 			platform_total_12		=0;
	int 			platform_total_13		=0;
	int 			platform_total_14		=0;
	
	
	int 			platform_total_1_rej		=0;
	int 			platform_total_2_rej	=0;
	int 			platform_total_3_rej	=0;
	int 			platform_total_4_rej	=0;
	int 			platform_total_5_rej		=0;
	int 			platform_total_6_rej		=0;
	int 			platform_total_7_rej		=0;
	int 			platform_total_8_rej		=0;
	int 			platform_total_9_rej		=0;
	int 			platform_total_10_rej		=0;
	int 			platform_total_11_rej		=0;
	
	/*int 			bus_aggreed_1		=0;
	int 			bus_aggreed_2		=0;
	int 			bus_aggreed_3		=0;
	int 			bus_aggreed_4		=0;
	int 			bus_aggreed_5		=0;
	int 			bus_aggreed_6		=0;
	int 			bus_aggreed_7		=0;
	int 			bus_aggreed_8		=0;
	int 			bus_aggreed_9		=0;
	int 			bus_aggreed_10		=0;
	int 			bus_aggreed_11		=0;*/
	
	
	char	*ApproveComment_1Str	=NULL;
	char	*ApproveComment_2Str	=NULL;
	char	*ApproveComment_3Str	=NULL;
	char	*ApproveComment_4Str	=NULL;
	char	*ApproveComment_5Str	=NULL;
	char	*ApproveComment_6Str	=NULL;
	char	*ApproveComment_7Str	=NULL;
	char	*ApproveComment_8Str	=NULL;
	char	*ApproveComment_9Str	=NULL;
	char	*ApproveComment_10Str	=NULL;
	char	*ApproveComment_11Str	=NULL;
	char	*ApproveComment_12Str	=NULL;
	char	*ApproveComment_13Str	=NULL;
	char	*ApproveComment_14Str	=NULL;
	char	*ApproveComment_totalStr	=NULL;
	
	char	*RejectComment_1Str	=NULL;
	char	*RejectComment_2Str	=NULL;
	char	*RejectComment_3Str	=NULL;
	char	*RejectComment_4Str	=NULL;
	char	*RejectComment_5Str	=NULL;
	char	*RejectComment_6Str	=NULL;
	char	*RejectComment_7Str	=NULL;
	char	*RejectComment_8Str	=NULL;
	char	*RejectComment_9Str	=NULL;
	char	*RejectComment_10Str	=NULL;
	char	*RejectComment_11Str	=NULL;
	
	char	*bus_aggreedStr	=NULL;
	char	*hcv_aggreedStr	=NULL;
	char	*ilmcv_aggreedStr	=NULL;
	char	*scv_aggreedStr	=NULL;
	char	*aggrbusiness_aggreedStr	=NULL;
	char	*Defence_aggreedStr	=NULL;
	char	*platform_totalStr	=NULL;
	
	
	char	*MCCproduct_line	=NULL;
	char	*MCCproduct_line_rej	=NULL;
	char	*MCCAprrej_comment	=NULL;

	char	*bus_aggreedStr_14	=NULL;
	char	*hcv_aggreedStr_14	=NULL;
	char	*scv_aggreedStr_14	=NULL;
	char	*ilmcv_aggreedStr_14	=NULL;
	char	*aggrbusiness_aggreedStr_14	=NULL;
	char	*Defence_aggreedStr_14	=NULL;
	char	*platform_totalStr_14	=NULL;

	char	*bus_aggreedStr_13	=NULL;
	char	*hcv_aggreedStr_13	=NULL;
	char	*scv_aggreedStr_13	=NULL;
	char	*ilmcv_aggreedStr_13	=NULL;
	char	*aggrbusiness_aggreedStr_13	=NULL;
	char	*Defence_aggreedStr_13	=NULL;
	char	*platform_totalStr_13	=NULL;

	char	*bus_aggreedStr_12	=NULL;
	char	*hcv_aggreedStr_12	=NULL;
	char	*scv_aggreedStr_12	=NULL;
	char	*ilmcv_aggreedStr_12	=NULL;
	char	*aggrbusiness_aggreedStr_12	=NULL;
	char	*Defence_aggreedStr_12	=NULL;
	char	*platform_totalStr_12	=NULL;
	
	char	*bus_aggreedStr_11	=NULL;
	char	*hcv_aggreedStr_11	=NULL;
	char	*scv_aggreedStr_11	=NULL;
	char	*ilmcv_aggreedStr_11	=NULL;
	char	*aggrbusiness_aggreedStr_11	=NULL;
	char	*Defence_aggreedStr_11	=NULL;
	char	*platform_totalStr_11	=NULL;
	
	char	*bus_aggreedStr_10	=NULL;
	char	*hcv_aggreedStr_10	=NULL;
	char	*scv_aggreedStr_10	=NULL;
	char	*ilmcv_aggreedStr_10	=NULL;
	char	*aggrbusiness_aggreedStr_10	=NULL;
	char	*Defence_aggreedStr_10	=NULL;
	char	*platform_totalStr_10	=NULL;
	
	char	*bus_aggreedStr_9	=NULL;
	char	*hcv_aggreedStr_9	=NULL;
	char	*scv_aggreedStr_9	=NULL;
	char	*ilmcv_aggreedStr_9	=NULL;
	char	*aggrbusiness_aggreedStr_9	=NULL;
	char	*Defence_aggreedStr_9	=NULL;
	char	*platform_totalStr_9	=NULL;
	
	char	*bus_aggreedStr_8	=NULL;
	char	*hcv_aggreedStr_8	=NULL;
	char	*scv_aggreedStr_8	=NULL;
	char	*ilmcv_aggreedStr_8	=NULL;
	char	*aggrbusiness_aggreedStr_8	=NULL;
	char	*Defence_aggreedStr_8	=NULL;
	char	*platform_totalStr_8	=NULL;
	
	char	*bus_aggreedStr_7	=NULL;
	char	*hcv_aggreedStr_7	=NULL;
	char	*scv_aggreedStr_7	=NULL;
	char	*ilmcv_aggreedStr_7	=NULL;
	char	*aggrbusiness_aggreedStr_7	=NULL;
	char	*Defence_aggreedStr_7	=NULL;
	char	*platform_totalStr_7	=NULL;
	
	char	*bus_aggreedStr_6	=NULL;
	char	*hcv_aggreedStr_6	=NULL;
	char	*scv_aggreedStr_6	=NULL;
	char	*ilmcv_aggreedStr_6	=NULL;
	char	*aggrbusiness_aggreedStr_6	=NULL;
	char	*Defence_aggreedStr_6	=NULL;
	char	*platform_totalStr_6	=NULL;
	
	char	*bus_aggreedStr_5	=NULL;
	char	*hcv_aggreedStr_5	=NULL;
	char	*scv_aggreedStr_5	=NULL;
	char	*ilmcv_aggreedStr_5	=NULL;
	char	*aggrbusiness_aggreedStr_5	=NULL;
	char	*Defence_aggreedStr_5	=NULL;
	char	*platform_totalStr_5	=NULL;
	
	char	*bus_aggreedStr_4	=NULL;
	char	*hcv_aggreedStr_4	=NULL;
	char	*scv_aggreedStr_4	=NULL;
	char	*ilmcv_aggreedStr_4	=NULL;
	char	*aggrbusiness_aggreedStr_4	=NULL;
	char	*Defence_aggreedStr_4	=NULL;
	char	*platform_totalStr_4	=NULL;
	
	char	*bus_aggreedStr_3	=NULL;
	char	*hcv_aggreedStr_3	=NULL;
	char	*scv_aggreedStr_3	=NULL;
	char	*ilmcv_aggreedStr_3	=NULL;
	char	*aggrbusiness_aggreedStr_3	=NULL;
	char	*Defence_aggreedStr_3	=NULL;
	char	*platform_totalStr_3	=NULL;
	
	char	*bus_aggreedStr_2	=NULL;
	char	*hcv_aggreedStr_2	=NULL;
	char	*scv_aggreedStr_2	=NULL;
	char	*ilmcv_aggreedStr_2	=NULL;
	char	*aggrbusiness_aggreedStr_2	=NULL;
	char	*Defence_aggreedStr_2	=NULL;
	char	*platform_totalStr_2	=NULL;
	
	char	*bus_aggreedStr_1	=NULL;
	char	*hcv_aggreedStr_1	=NULL;
	char	*scv_aggreedStr_1	=NULL;
	char	*ilmcv_aggreedStr_1	=NULL;
	char	*aggrbusiness_aggreedStr_1	=NULL;
	char	*Defence_aggreedStr_1	=NULL;
	char	*platform_totalStr_1	=NULL;
	
	char	*bus_rejectStr_11	=NULL;
	char	*hcv_rejectStr_11	=NULL;
	char	*scv_rejectStr_11	=NULL;
	char	*ilmcv_rejectStr_11	=NULL;
	char	*aggrbusiness_rejectStr_11	=NULL;
	char	*Defence_rejectStr_11	=NULL;
	char	*platform_totalStr_11_rej	=NULL;
	
	char	*bus_rejectStr_10	=NULL;
	char	*hcv_rejectStr_10	=NULL;
	char	*scv_rejectStr_10	=NULL;
	char	*ilmcv_rejectStr_10	=NULL;
	char	*aggrbusiness_rejectStr_10	=NULL;
	char	*Defence_rejectStr_10	=NULL;
	char	*platform_totalStr_10_rej	=NULL;
	
	char	*bus_rejectStr_9	=NULL;
	char	*hcv_rejectStr_9	=NULL;
	char	*scv_rejectStr_9	=NULL;
	char	*ilmcv_rejectStr_9	=NULL;
	char	*aggrbusiness_rejectStr_9	=NULL;
	char	*Defence_rejectStr_9	=NULL;
	char	*platform_totalStr_9_rej	=NULL;
	
	char	*bus_rejectStr_8	=NULL;
	char	*hcv_rejectStr_8	=NULL;
	char	*scv_rejectStr_8	=NULL;
	char	*ilmcv_rejectStr_8	=NULL;
	char	*aggrbusiness_rejectStr_8	=NULL;
	char	*Defence_rejectStr_8	=NULL;
	char	*platform_totalStr_8_rej	=NULL;
	
	char	*bus_rejectStr_7	=NULL;
	char	*hcv_rejectStr_7	=NULL;
	char	*scv_rejectStr_7	=NULL;
	char	*ilmcv_rejectStr_7	=NULL;
	char	*aggrbusiness_rejectStr_7	=NULL;
	char	*Defence_rejectStr_7	=NULL;
	char	*platform_totalStr_7_rej	=NULL;
	
	char	*bus_rejectStr_6	=NULL;
	char	*hcv_rejectStr_6	=NULL;
	char	*scv_rejectStr_6	=NULL;
	char	*ilmcv_rejectStr_6	=NULL;
	char	*aggrbusiness_rejectStr_6	=NULL;
	char	*Defence_rejectStr_6	=NULL;
	char	*platform_totalStr_6_rej	=NULL;
	
	char	*bus_rejectStr_5	=NULL;
	char	*hcv_rejectStr_5	=NULL;
	char	*scv_rejectStr_5	=NULL;
	char	*ilmcv_rejectStr_5	=NULL;
	char	*aggrbusiness_rejectStr_5	=NULL;
	char	*Defence_rejectStr_5	=NULL;
	char	*platform_totalStr_5_rej	=NULL;
	
	char	*bus_rejectStr_4	=NULL;
	char	*hcv_rejectStr_4	=NULL;
	char	*scv_rejectStr_4	=NULL;
	char	*ilmcv_rejectStr_4	=NULL;
	char	*aggrbusiness_rejectStr_4	=NULL;
	char	*Defence_rejectStr_4	=NULL;
	char	*platform_totalStr_4_rej	=NULL;
	
	char	*bus_rejectStr_3	=NULL;
	char	*hcv_rejectStr_3	=NULL;
	char	*scv_rejectStr_3	=NULL;
	char	*ilmcv_rejectStr_3	=NULL;
	char	*aggrbusiness_rejectStr_3	=NULL;
	char	*Defence_rejectStr_3	=NULL;
	char	*platform_totalStr_3_rej	=NULL;
	
	char	*bus_rejectStr_2	=NULL;
	char	*hcv_rejectStr_2	=NULL;
	char	*scv_rejectStr_2	=NULL;
	char	*ilmcv_rejectStr_2	=NULL;
	char	*aggrbusiness_rejectStr_2	=NULL;
	char	*Defence_rejectStr_2	=NULL;
	char	*platform_totalStr_2_rej	=NULL;
	
	char	*bus_rejectStr_1	=NULL;
	char	*hcv_rejectStr_1	=NULL;
	char	*scv_rejectStr_1	=NULL;
	char	*ilmcv_rejectStr_1	=NULL;
	char	*aggrbusiness_rejectStr_1	=NULL;
	char	*Defence_rejectStr_1	=NULL;
	char	*platform_totalStr_1_rej	=NULL;
	char	*Part_Type	=NULL;
	char	*ModAddress	=NULL;
	char	*modinfo01Str	=NULL;
	char	*modinfo02Str	=NULL;
	char	*modinfo03Str	=NULL;
	char	*modinfo04Str	=NULL;
	char	*MODULE_OTHER_ADDRESS	=NULL;
	
	float 	percent_agree;
	float 	percent_dropped;
	float 	percent_bus_1;
	float 	percent_hcv_1;
    float	percent_ilmcv_1;
	float	percent_scv_1;
	float	percent_aggr_1;
	float	percent_Defence_1;
	
	float 	percent_bus_2;
	float 	percent_hcv_2;
    float	percent_ilmcv_2;
	float	percent_scv_2;
	float	percent_aggr_2;
	float	percent_Defence_2;
	
	float 	percent_bus_3;
	float 	percent_hcv_3;
    float	percent_ilmcv_3;
	float	percent_scv_3;
	float	percent_aggr_3;
	float	percent_Defence_3;
	
	float 	percent_bus_4;
	float 	percent_hcv_4;
    float	percent_ilmcv_4;
	float	percent_scv_4;
	float	percent_aggr_4;
	float	percent_Defence_4;
	
	
	float 	percent_bus_5;
	float 	percent_hcv_5;
    float	percent_ilmcv_5;
	float	percent_scv_5;
	float	percent_aggr_5;
	float	percent_Defence_5;
	
	float 	percent_bus_6;
	float 	percent_hcv_6;
    float	percent_ilmcv_6;
	float	percent_scv_6;
	float	percent_aggr_6;
	float	percent_Defence_6;
	
	float 	percent_bus_7;
	float 	percent_hcv_7;
    float	percent_ilmcv_7;
	float	percent_scv_7;
	float	percent_aggr_7;
	float	percent_Defence_7;
	
	float 	percent_bus_8;
	float 	percent_hcv_8;
    float	percent_ilmcv_8;
	float	percent_scv_8;
	float	percent_aggr_8;
	float	percent_Defence_8;
	
	float 	percent_bus_9;
	float 	percent_hcv_9;
    float	percent_ilmcv_9;
	float	percent_scv_9;
	float	percent_aggr_9;
	float	percent_Defence_9;
	
	float 	percent_bus_10;
	float 	percent_hcv_10;
    float	percent_ilmcv_10;
	float	percent_scv_10;
	float	percent_aggr_10;
	float	percent_Defence_10;
	
	float 	percent_bus_11;
	float 	percent_hcv_11;
    float	percent_ilmcv_11;
	float	percent_scv_11;
	float	percent_aggr_11;
	float	percent_Defence_11;

	float 	percent_bus_12;
	float 	percent_hcv_12;
    float	percent_ilmcv_12;
	float	percent_scv_12;
	float	percent_aggr_12;
	float	percent_Defence_12;
	
	float 	percent_bus_13;
	float 	percent_hcv_13;
    float	percent_ilmcv_13;
	float	percent_scv_13;
	float	percent_aggr_13;
	float	percent_Defence_13;

	float 	percent_bus_14;
	float 	percent_hcv_14;
    float	percent_ilmcv_14;
	float	percent_scv_14;
	float	percent_aggr_14;
	float	percent_Defence_14;

	float 	percent_bus_1_rej;
	float 	percent_hcv_1_rej;
    float	percent_ilmcv_1_rej;
	float	percent_scv_1_rej;
	float	percent_aggr_1_rej;
	float	percent_Defence_1_rej;
	
	float 	percent_bus_2_rej;
	float 	percent_hcv_2_rej;
    float	percent_ilmcv_2_rej;
	float	percent_scv_2_rej;
	float	percent_aggr_2_rej;
	float	percent_Defence_2_rej;
	
	float 	percent_bus_3_rej;
	float 	percent_hcv_3_rej;
    float	percent_ilmcv_3_rej;
	float	percent_scv_3_rej;
	float	percent_aggr_3_rej;
	float	percent_Defence_3_rej;
	
	float 	percent_bus_4_rej;
	float 	percent_hcv_4_rej;
    float	percent_ilmcv_4_rej;
	float	percent_scv_4_rej;
	float	percent_aggr_4_rej;
	float	percent_Defence_4_rej;
	
	float 	percent_bus_5_rej;
	float 	percent_hcv_5_rej;
    float	percent_ilmcv_5_rej;
	float	percent_scv_5_rej;
	float	percent_aggr_5_rej;
	float	percent_Defence_5_rej;
	
	float 	percent_bus_6_rej;
	float 	percent_hcv_6_rej;
    float	percent_ilmcv_6_rej;
	float	percent_scv_6_rej;
	float	percent_aggr_6_rej;
	float	percent_Defence_6_rej;
	
	float 	percent_bus_7_rej;
	float 	percent_hcv_7_rej;
    float	percent_ilmcv_7_rej;
	float	percent_scv_7_rej;
	float	percent_aggr_7_rej;
	float	percent_Defence_7_rej;
	
	float 	percent_bus_8_rej;
	float 	percent_hcv_8_rej;
    float	percent_ilmcv_8_rej;
	float	percent_scv_8_rej;
	float	percent_aggr_8_rej;
	float	percent_Defence_8_rej;
	
	float 	percent_bus_9_rej;
	float 	percent_hcv_9_rej;
    float	percent_ilmcv_9_rej;
	float	percent_scv_9_rej;
	float	percent_aggr_9_rej;
	float	percent_Defence_9_rej;
	
	float 	percent_bus_10_rej;
	float 	percent_hcv_10_rej;
    float	percent_ilmcv_10_rej;
	float	percent_scv_10_rej;
	float	percent_aggr_10_rej;
	float	percent_Defence_10_rej;
	
	float 	percent_bus_11_rej;
	float 	percent_hcv_11_rej;
    float	percent_ilmcv_11_rej;
	float	percent_scv_11_rej;
	float	percent_aggr_11_rej;
	float	percent_Defence_11_rej;
	
	int Bus_Col_Total_reject =0;
	int Hcv_Col_Total_reject =0;
	int Scv_Col_Total_reject =0;
	int Ilmcv_Col_Total_reject =0;
	int Aggr_Business_Col_Total_reject=0;
	int Defence_Col_Total_reject=0;
	
	int Bus_Col_Total_aggreed =0;
	int Hcv_Col_Total_aggreed =0;
	int Scv_Col_Total_aggreed =0;
	int Ilmcv_Col_Total_aggreed =0;
	int Aggr_Business_Col_Total_aggreed=0;
	int Defence_Col_Total_aggreed=0;
	int ModAddctrl_n_found=0;
	int ProductLinectrl_n_found=0;
	int ApproveSignOff_n_found=0;
	int RejectSignOff_n_found=0;

	char
        *ModAddctrl_qry_entries[1] = {"SYSCD"},
        *ModAddctrl_qry_values[1]	= {"*"};

	char
        *ProductLineqry_entries[3] = {"SYSCD","Information-1","Information-2"},
        *ProductLineqry_values[3]	= {"*","*","*"};

	char
        *ApproveSignOff_entries[3] = {"Job Name","Name","Event Type Name"},
        *ApproveSignOff_values[3]	= {"*","*","*"};

	char
        *RejectSignOff_entries[3] = {"Job Name","Name","Event Type Name"},
        *RejectSignOff_values[3]	= {"*","*","*"};

	tag_t	ModAddctrlquery	= NULLTAG;
	tag_t	*ModAddCntrlObjs	= NULLTAG;

	tag_t	ProductLineCntrlquery	= NULLTAG;
	tag_t	ProductLinequery	= NULLTAG;
	tag_t	*ProductLineCntrlObjs	= NULLTAG;
	tag_t	*ProductLineCntrlObjs1	= NULLTAG;

	tag_t	ApproveSignOffObj	= NULLTAG;
	tag_t	SignOffquery	= NULLTAG;
	tag_t	*ApproveSignOffObjs	= NULLTAG;

	tag_t	RejectSignOffObj	= NULLTAG;
	tag_t	*RejectSignOffObjs	= NULLTAG;
	tag_t	RejectSignOffquery	= NULLTAG;
	tag_t	RejectProductLinequery	= NULLTAG;
	tag_t	ControlObjQuery	= NULLTAG;

	
	printf("\n value of from_date and to_date -> getting from main function %s,%s",s_date,e_date);fflush(stdout);
	
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	char Data[100] = "";
	
	char
        *qry_entries[3] = {"Type","Created After","Created Before"},
        *qry_values[3]	= {"*","*","*"};

	char
		*Cntrlqry_entries[3] = {"SYSCD","SUBSYSCD","Information-1"},
		*Cntrlqry_values[3]	= {"ModuleAdd","DesignGrp","*"};

	const char *attrs[1];
	const char *values[1];
	attrs[0] ="item_id";
	//values[0] = (char *)item_id;
	//printf("\n item_id[%s]\n",item_id);fflush(stdout);

	output1 = fopen("output.csv", "w");
	output=fopen("/tmp/UpdatedMccSignoffoutput.xml","w");
	//fprintf(output,"New Part Request WorkFlow Details\n");fflush(output);
	//fprintf(output1,"ID,Module Address,Part Type,Aggregate Group,Product Line,MCC Status,Comment,MCC Approve Date,MCC Approved By,MCC Reject Date,MCC Reject By,TML PartNumber,\n");fflush(stdout);
	fprintf(output1,"NPR_Number, Product_Line, MCC_Reviewer_Name, Start, End, Ageing, Status, TML_Part_Number,\n");fflush(stdout);
	//fprintf(output,"New Part Request Number,MCCReviewer,,,,COC Head Plantform Engineer Review,,,,COC Principal Engineer Review,,,,Module TeamLeader Review,,,,Assign Reviewer Assignemnt,\n");fflush(output);
	//fprintf(output,",MCCReviewerName,Start Date,End Date,Status,COC HeadReviewerName,Start Date,End Date,Status,COCPrincipalReviewerName,Start Date,End Date,Status,Module ReviewerName,Start Date,End Date,Status,SignOffUserName,Start Date,End Date,Status,Assigned TML Part Number\n");fflush(output);


	if (output == NULL)
	{
		printf("\n ERROR: XML Cannot open File\n");
		return -1;
	}
	else
	{
		printf("\n XML File opened successfully.\n");
	}
	ctr = 0;

	strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
	write2xml(output,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	//write2xml(output,"\n<PLMXML date=\"");
	//write2xml(output,Data);
	//write2xml(output,"\" >\n");


	//ifail = ITEM_find_item_revs_by_key_attributes(1,attrs, values,item_revid,&n_tags_found, &tags_found);
	//ifail = ITEM_find_items_by_key_attributes(1, attrs, values, &n_tags_found, &tags_found);
	QRY_find2("Item...", &query);
	QRY_find2("Control Objects...", &ProductLinequery);
	QRY_find2("Control Objects...", &RejectProductLinequery);
	QRY_find2("Audit - Workflow MonthlyCv_EPA", &SignOffquery);
	QRY_find2("Audit - Workflow MonthlyCv_EPA", &RejectSignOffquery);
	QRY_find2("Control Objects...", &ControlObjQuery);

	qry_values[0] = "New Part Request";
	qry_values[1] = s_date;
	qry_values[2] = e_date;
	QRY_execute(query, 3, qry_entries, qry_values, &n_tags_found, &tags_found);
	printf("\n n_tags_found[%d]\n",n_tags_found);fflush(stdout);

	ModAddctrl_qry_values[0]	= "NewPartReqPartTypeCheckForIFD";
	QRY_find2("ControlObjQry", &ModAddctrlquery);
	QRY_execute(ModAddctrlquery,1, ModAddctrl_qry_entries, ModAddctrl_qry_values, &ModAddctrl_n_found, &ModAddCntrlObjs);
	printf("\n TML_New_MCC_NODE_Function::ModAddctrl_n_found =[%d]",ModAddctrl_n_found);fflush(stdout);
	if(ModAddctrl_n_found>0)
	{
		AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo1",&modinfo01Str);
		AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo2",&modinfo02Str);
		AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo3",&modinfo03Str);
		AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo4",&modinfo04Str);
		printf("\nmodinfo01Str is:%s",modinfo01Str);fflush(stdout);
		printf("\nmodinfo02Str is:%s",modinfo02Str);fflush(stdout);
		printf("\nmodinfo03Str is:%s",modinfo03Str);fflush(stdout);
		printf("\nmodinfo04Str is:%s",modinfo04Str);fflush(stdout);
		 MODULE_OTHER_ADDRESS = (char *) MEM_alloc(2000);
		 tc_strcpy(MODULE_OTHER_ADDRESS,modinfo01Str);
		 tc_strcat(MODULE_OTHER_ADDRESS,modinfo02Str);
		 tc_strcat(MODULE_OTHER_ADDRESS,modinfo03Str);
		 tc_strcat(MODULE_OTHER_ADDRESS,modinfo04Str);
	}
	printf("\nMODULE_OTHER_ADDRESS is:%s",MODULE_OTHER_ADDRESS);fflush(stdout);

	if(n_tags_found>0)
	{
		
		for(count=0;count<n_tags_found;count++)
		{
			itemRev_t = tags_found[count];
			AOM_UIF_ask_value(itemRev_t,"object_type",&LatRev_ObjectType);
			if(tc_strcasecmp(LatRev_ObjectType,"New Part Request")==0)
			{
				AOM_UIF_ask_value(itemRev_t,"item_id",&NewPartReqNumber);
				AOM_ask_value_string(itemRev_t,"t5_PartType",&Part_Type);
				AOM_ask_value_string(itemRev_t,"t5_ModuleAddress",&ModAddress);
			    //AOM_UIF_ask_value(itemRev_t,"item_id",&NewPartReqNumber);
				//if(tc_strlen(NewPartReqNumber)==25)
				if(tc_strlen(NewPartReqNumber)==25 && (tc_strcmp(Part_Type,"Module")==0 || tc_strcmp(Part_Type,"M")==0 ) && tc_strstr(MODULE_OTHER_ADDRESS,ModAddress)==NULL)
				{
					//MCC = 0;
					AOM_UIF_ask_value(itemRev_t,"t5_AggregateGrp",&Aggregate_value);
					AOM_ask_value_string(itemRev_t,"t5_MCCStatus",&MCCStatus_value);
					AOM_UIF_ask_value(itemRev_t,"t5_NwTmlPtNo",&tmlpart_value);
					AOM_ask_value_string(itemRev_t,"t5_PartType",&PartType);
					//AOM_ask_value_string(itemRev_t,"t5_PartType",&PartType);
					
					
					printf("\n Aggregate_value is %s",Aggregate_value);fflush(stdout);
					printf("\n MCCStatus_value is %s",MCCStatus_value);fflush(stdout);
					printf("\n tmlpart_value is %s",tmlpart_value);fflush(stdout);
					printf("\n PartType is %s",PartType);fflush(stdout);
					
					/*
					ITEM_ask_latest_rev(itemRev_t, &latest_rev_tag);
					AOM_ask_value_tags(latest_rev_tag,"fnd0ActuatedInteractiveTsks",&totalprocess,&ProcessStageList);
					
						if(totalprocess>0)
						{
							for(process_counter=0;process_counter<totalprocess;process_counter++)
							{
								Process_Stage = ProcessStageList[process_counter];
								AOM_ask_value_string(Process_Stage,"object_name",&process_Name);
								AOM_UIF_ask_value(Process_Stage,"object_type",&process_type);
								printf("\n process_Name is %s",process_Name);fflush(stdout);
								printf("\n process_type is %s",process_type);fflush(stdout);
								if((tc_strstr(process_Name,"MCC")!=NULL) && tc_strcmp(process_type,"Review Task")==0)
								{
									MCC++;
									break;
								}
							}
						}
						printf("\n MCC is %d",MCC);fflush(stdout);
					*/
						
					//if(MCC>0)
					//{

				    //if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
					if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0)
					{
						
						if(tc_strstr(Aggregate_value,"D-CAB")!=NULL)
						{
							if(tc_strcmp(MCCStatus_value,"Aggreed") == 0)
							{
								D_cab_approved++;
								setAddTAG(&TotalApprovedTask,&soResultApproved,itemRev_t);
								
							}
							if(tc_strcmp(MCCStatus_value,"Dropped") == 0)
							{
								D_cab_dropped++;
								setAddTAG(&TotalRejectTask,&soResultReject,itemRev_t);
							}
						}
						if(tc_strstr(Aggregate_value,"F-CHASSIS")!=NULL)
						{
							if(tc_strcmp(MCCStatus_value,"Aggreed") == 0)
							{
								F_chasis_approved++;
								setAddTAG(&TotalApprovedTask,&soResultApproved,itemRev_t);
							}
							if(tc_strcmp(MCCStatus_value,"Dropped") == 0)
							{
								F_chasis_dropped++;
								setAddTAG(&TotalRejectTask,&soResultReject,itemRev_t);
							}
						}
						if(tc_strstr(Aggregate_value,"G-E&E")!=NULL)
						{
							if(tc_strcmp(MCCStatus_value,"Aggreed") == 0)
							{
								G_Electrical_approved++;
								setAddTAG(&TotalApprovedTask,&soResultApproved,itemRev_t);
							}
							if(tc_strcmp(MCCStatus_value,"Dropped") == 0)
							{
								G_Electrical_dropped++;
								setAddTAG(&TotalRejectTask,&soResultReject,itemRev_t);
							}
						}
						if(tc_strstr(Aggregate_value,"H-POWERTRAIN")!=NULL)
						{							
							if(tc_strcmp(MCCStatus_value,"Aggreed") == 0)
							{								
								H_POWERTRAIN_approved++;
								printf("\n 11111111");fflush(stdout);
								setAddTAG(&TotalApprovedTask,&soResultApproved,itemRev_t);
								
							}
							if(tc_strcmp(MCCStatus_value,"Dropped") == 0)
							{
								H_POWERTRAIN_dropped++;
								printf("\n 222222222");fflush(stdout);
								setAddTAG(&TotalRejectTask,&soResultReject,itemRev_t);
							}	 
						}
						if(tc_strstr(Aggregate_value,"K-VEHICLE")!=NULL)
						{
							if(tc_strcmp(MCCStatus_value,"Aggreed") == 0)
							{								
								K_Vehicle_approved++;
								setAddTAG(&TotalApprovedTask,&soResultApproved,itemRev_t);
							}
							if(tc_strcmp(MCCStatus_value,"Dropped") == 0)
							{
								K_Vehicle_dropped++;
								setAddTAG(&TotalRejectTask,&soResultReject,itemRev_t);
							}
						}
						if(tc_strstr(Aggregate_value,"A-APPLICATION ENGINEERING")!=NULL)
						{
							if(tc_strcmp(MCCStatus_value,"Aggreed") == 0)
							{								
								A_Application_approved++;
								setAddTAG(&TotalApprovedTask,&soResultApproved,itemRev_t);
							}
							if(tc_strcmp(MCCStatus_value,"Dropped") == 0)
							{
								A_Application_dropped++;
								setAddTAG(&TotalRejectTask,&soResultReject,itemRev_t);
							}
						}
					}
					
					//}// MCC>0
					
				}
			}
		}

		D_cab_approvedStr = (char *) MEM_alloc(1000);
		D_cab_droppedStr = (char *) MEM_alloc(1000);
		D_cab_totalStr = (char *) MEM_alloc(1000);

		F_chasis_approvedStr = (char *) MEM_alloc(1000);
		F_chasis_droppedStr = (char *) MEM_alloc(1000);
		F_chasis_totalStr = (char *) MEM_alloc(1000);

		G_Electrical_approvedStr = (char *) MEM_alloc(1000);
		G_Electrical_droppedStr = (char *) MEM_alloc(1000);
		G_Electrical_totalStr = (char *) MEM_alloc(1000);
		
		H_POWERTRAIN_approvedStr = (char *) MEM_alloc(1000);
		H_POWERTRAIN_droppedStr = (char *) MEM_alloc(1000);
		H_POWERTRAIN_totalStr = (char *) MEM_alloc(1000);

		K_Vehicle_approvedStr = (char *) MEM_alloc(1000);
		K_Vehicle_droppedStr = (char *) MEM_alloc(1000);
		K_Vehicle_totalStr = (char *) MEM_alloc(1000);

		A_Application_approvedStr = (char *) MEM_alloc(1000);
		A_Application_droppedStr = (char *) MEM_alloc(1000);
		A_Application_totalStr = (char *) MEM_alloc(1000);

		temp_D_cab_approvedStr = (char *) MEM_alloc(1000);
		temp_D_cab_droppedStr = (char *) MEM_alloc(1000);
		temp_D_cab_totalStr = (char *) MEM_alloc(1000);

		temp_F_chasis_approvedStr = (char *) MEM_alloc(1000);
		temp_F_chasis_droppedStr = (char *) MEM_alloc(1000);
		temp_F_chasis_totalStr = (char *) MEM_alloc(1000);

		temp_G_Electrical_approvedStr = (char *) MEM_alloc(1000);
		temp_G_Electrical_droppedStr = (char *) MEM_alloc(1000);
		temp_G_Electrical_totalStr = (char *) MEM_alloc(1000);
		
		temp_H_POWERTRAIN_approvedStr = (char *) MEM_alloc(1000);
		temp_H_POWERTRAIN_droppedStr = (char *) MEM_alloc(1000);
		temp_H_POWERTRAIN_totalStr = (char *) MEM_alloc(1000);

		temp_K_Vehicle_approvedStr = (char *) MEM_alloc(1000);
		temp_K_Vehicle_droppedStr = (char *) MEM_alloc(1000);
		temp_K_Vehicle_totalStr = (char *) MEM_alloc(1000);

		temp_A_Application_approvedStr = (char *) MEM_alloc(1000);
		temp_A_Application_droppedStr = (char *) MEM_alloc(1000);
		temp_A_Application_totalStr = (char *) MEM_alloc(1000);

		TOTAL_AGGRE_ALL_AGGREATEdStr = (char *) MEM_alloc(1000);
		TOTAL_DROP_ALL_AGGREATEStr = (char *) MEM_alloc(1000);
		TOTAL_Grand_ALL_AGGREATEStr = (char *) MEM_alloc(1000);
		
		

		sprintf(D_cab_approvedStr,"%d",D_cab_approved);
		sprintf(D_cab_droppedStr,"%d",D_cab_dropped);
		D_cab_total =D_cab_approved + D_cab_dropped;
		printf("\n the value of D_cab_total is %d",D_cab_total);
		sprintf(D_cab_totalStr,"%d",D_cab_total);

		sprintf(F_chasis_approvedStr,"%d",F_chasis_approved);
		sprintf(F_chasis_droppedStr,"%d",F_chasis_dropped);
		F_chasis_total =F_chasis_approved + F_chasis_dropped;
		printf("\n the value of F_chasis is %d",F_chasis_total);
		sprintf(F_chasis_totalStr,"%d",F_chasis_total);

		sprintf(G_Electrical_approvedStr,"%d",G_Electrical_approved);
		sprintf(G_Electrical_droppedStr,"%d",G_Electrical_dropped);
		G_Electrical_total =G_Electrical_approved + G_Electrical_dropped;
		printf("\n the value of G_Electrical is %d",G_Electrical_total);
		sprintf(G_Electrical_totalStr,"%d",G_Electrical_total);
		
		sprintf(H_POWERTRAIN_approvedStr,"%d",H_POWERTRAIN_approved);
		sprintf(H_POWERTRAIN_droppedStr,"%d",H_POWERTRAIN_dropped);
		H_POWERTRAIN_total =H_POWERTRAIN_approved + H_POWERTRAIN_dropped;
		printf("\n the value of H_POWERTRAIN_total is %d",H_POWERTRAIN_total);
		sprintf(H_POWERTRAIN_totalStr,"%d",H_POWERTRAIN_total);

		sprintf(K_Vehicle_approvedStr,"%d",K_Vehicle_approved);
		sprintf(K_Vehicle_droppedStr,"%d",K_Vehicle_dropped);
		K_Vehicle_total =K_Vehicle_approved + K_Vehicle_dropped;
		printf("\n the value of K_Vehicle is %d",K_Vehicle_total);
		sprintf(K_Vehicle_totalStr,"%d",K_Vehicle_total);

		sprintf(A_Application_approvedStr,"%d",A_Application_approved);
		sprintf(A_Application_droppedStr,"%d",A_Application_dropped);
		A_Application_total =A_Application_approved + A_Application_dropped;
		printf("\n the value of A_Application is %d",A_Application_total);
		sprintf(A_Application_totalStr,"%d",A_Application_total);

		TOTAL_AGGRE_ALL_AGGREATE = D_cab_approved+F_chasis_approved+G_Electrical_approved+H_POWERTRAIN_approved+K_Vehicle_approved+A_Application_approved;
		TOTAL_DROP_ALL_AGGREATE = D_cab_dropped+F_chasis_dropped+G_Electrical_dropped+H_POWERTRAIN_dropped+K_Vehicle_dropped+A_Application_dropped;
		TOTAL_Grand_ALL_AGGREATE = D_cab_total+F_chasis_total+G_Electrical_total+H_POWERTRAIN_total+K_Vehicle_total+A_Application_total;


		sprintf(TOTAL_AGGRE_ALL_AGGREATEdStr,"%d",TOTAL_AGGRE_ALL_AGGREATE);
		sprintf(TOTAL_DROP_ALL_AGGREATEStr,"%d",TOTAL_DROP_ALL_AGGREATE);
		sprintf(TOTAL_Grand_ALL_AGGREATEStr,"%d",TOTAL_Grand_ALL_AGGREATE);

		tc_strcpy(temp_D_cab_approvedStr,D_cab_approvedStr);
		tc_strcpy(temp_D_cab_droppedStr,D_cab_droppedStr);
		tc_strcpy(temp_D_cab_totalStr,D_cab_totalStr);

		tc_strcpy(temp_F_chasis_approvedStr,F_chasis_approvedStr);
		tc_strcpy(temp_F_chasis_droppedStr,F_chasis_droppedStr);
		tc_strcpy(temp_F_chasis_totalStr,F_chasis_totalStr);

		tc_strcpy(temp_G_Electrical_approvedStr,G_Electrical_approvedStr);
		tc_strcpy(temp_G_Electrical_droppedStr,G_Electrical_droppedStr);
		tc_strcpy(temp_G_Electrical_totalStr,G_Electrical_totalStr);

		tc_strcpy(temp_H_POWERTRAIN_approvedStr,H_POWERTRAIN_approvedStr);
		tc_strcpy(temp_H_POWERTRAIN_droppedStr,H_POWERTRAIN_droppedStr);
		tc_strcpy(temp_H_POWERTRAIN_totalStr,H_POWERTRAIN_totalStr);

		tc_strcpy(temp_K_Vehicle_approvedStr,K_Vehicle_approvedStr);
		tc_strcpy(temp_K_Vehicle_droppedStr,K_Vehicle_droppedStr);
		tc_strcpy(temp_K_Vehicle_totalStr,K_Vehicle_totalStr);

		tc_strcpy(temp_A_Application_approvedStr,A_Application_approvedStr);
		tc_strcpy(temp_A_Application_droppedStr,A_Application_droppedStr);
		tc_strcpy(temp_A_Application_totalStr,A_Application_totalStr);

		printf("\n the value TotalApprovedTask is %d",TotalApprovedTask);
		printf("\n the value of TotalRejectTask is %d",TotalRejectTask);
		
		percent_agree = ((float)TOTAL_AGGRE_ALL_AGGREATE / (float)TOTAL_Grand_ALL_AGGREATE)*100;
		percent_dropped = ((float)TOTAL_DROP_ALL_AGGREATE / (float)TOTAL_Grand_ALL_AGGREATE)*100;
		
		write2xml(output,"<DataSheet6>\n");
		write2xml(output,"<Section_NPRVarietyCount>\n");
		
		write2xml(output,"<Row name=\"Agreed\">\n");
		
		write2xml(output,"<D_Cab_column1>");
		write2xml(output,D_cab_approvedStr);
		write2xml(output,"</D_Cab_column1>\n");
		
		write2xml(output,"<F_Chassis_column2>");
		write2xml(output,temp_F_chasis_approvedStr);
		write2xml(output,"</F_Chassis_column2>\n");
		
		write2xml(output,"<G_Electrical_column3>");
		write2xml(output,temp_G_Electrical_approvedStr);
		write2xml(output,"</G_Electrical_column3>\n");
		
		write2xml(output,"<H_Powertrain_column4>");
		write2xml(output,temp_H_POWERTRAIN_approvedStr);
		write2xml(output,"</H_Powertrain_column4>\n");
		
		write2xml(output,"<K_Vehicle_column5>");
		write2xml(output,temp_K_Vehicle_approvedStr);
		write2xml(output,"</K_Vehicle_column5>\n");
		
		write2xml(output,"<A_Application_column6>");
		write2xml(output,temp_A_Application_approvedStr);
		write2xml(output,"</A_Application_column6>\n");

		write2xml(output,"<Grand_Total_column7>");
		write2xml(output,TOTAL_AGGRE_ALL_AGGREATEdStr);
		write2xml(output,"</Grand_Total_column7>\n");
		fprintf(output, "<Agree_Percentage>%.2f</Agree_Percentage>\n", percent_agree);
		write2xml(output,"</Row>\n");
	
	
	//	write2xml(output,"<Row>\n");
		write2xml(output,"<Row name=\"Dropped\">\n");
		
		write2xml(output,"<D_Cab_column1>");
		write2xml(output,temp_D_cab_droppedStr);
		write2xml(output,"</D_Cab_column1>\n");

		write2xml(output,"<F_Chassis_column2>");
		write2xml(output,temp_F_chasis_droppedStr);
		write2xml(output,"</F_Chassis_column2>\n");

		write2xml(output,"<G_Electrical_column3>");
		write2xml(output,temp_G_Electrical_droppedStr);
		write2xml(output,"</G_Electrical_column3>\n");

		write2xml(output,"<H_Powertrain_column4>");
		write2xml(output,temp_H_POWERTRAIN_droppedStr);
		write2xml(output,"</H_Powertrain_column4>\n");

		write2xml(output,"<K_Vehicle_column5>");
		write2xml(output,temp_K_Vehicle_droppedStr);
		write2xml(output,"</K_Vehicle_column5>\n");

		write2xml(output,"<A_Application_column6>");
		write2xml(output,temp_A_Application_droppedStr);
		write2xml(output,"</A_Application_column6>\n");

		write2xml(output,"<Grand_Total_column7>");
		write2xml(output,TOTAL_DROP_ALL_AGGREATEStr);
		write2xml(output,"</Grand_Total_column7>\n");
		fprintf(output, "<Dropped_Percentage>%.2f</Dropped_Percentage>\n", percent_dropped);
		write2xml(output,"</Row>\n");
		
	//	write2xml(output,"<Row>\n");
		write2xml(output,"<Row name=\"Total\">\n");
		
		write2xml(output,"<D_Cab_column1>");
		write2xml(output,temp_D_cab_totalStr);
		write2xml(output,"</D_Cab_column1>\n");

		write2xml(output,"<F_Chassis_column2>");
		write2xml(output,temp_F_chasis_totalStr);
		write2xml(output,"</F_Chassis_column2>\n");

		write2xml(output,"<G_Electrical_column3>");
		write2xml(output,temp_G_Electrical_totalStr);
		write2xml(output,"</G_Electrical_column3>\n");

		write2xml(output,"<H_Powertrain_column4>");
		write2xml(output,temp_H_POWERTRAIN_totalStr);
		write2xml(output,"</H_Powertrain_column4>\n");

		write2xml(output,"<K_Vehicle_column5>");
		write2xml(output,temp_K_Vehicle_totalStr);
		write2xml(output,"</K_Vehicle_column5>\n");

		write2xml(output,"<A_Application_column6>");
		write2xml(output,temp_A_Application_totalStr);
		write2xml(output,"</A_Application_column6>\n");

		write2xml(output,"<Grand_Total_column7>");
		write2xml(output,TOTAL_Grand_ALL_AGGREATEStr);
		write2xml(output,"</Grand_Total_column7>\n");
		
		write2xml(output,"</Row>\n");
		write2xml(output,"</Section_NPRVarietyCount>\n");
		
	
	/*
		write2xml(output,"<rows>\n");
		write2xml(output,"<test1>\n");
		write2xml(output,"<row>\n");
		write2xml(output,"<fixedColumn>Agreed</fixedColumn>\n");

		write2xml(output,"<column1>");
		write2xml(output,D_cab_approvedStr);
		write2xml(output,"</column1>\n");

		write2xml(output,"<column2>");
		write2xml(output,temp_F_chasis_approvedStr);
		write2xml(output,"</column2>\n");

		write2xml(output,"<column3>");
		write2xml(output,temp_G_Electrical_approvedStr);
		write2xml(output,"</column3>\n");

		write2xml(output,"<column4>");
		write2xml(output,temp_H_POWERTRAIN_approvedStr);
		write2xml(output,"</column4>\n");

		write2xml(output,"<column5>");
		write2xml(output,temp_K_Vehicle_approvedStr);
		write2xml(output,"</column5>\n");

		write2xml(output,"<column6>");
		write2xml(output,temp_A_Application_approvedStr);
		write2xml(output,"</column6>\n");

		write2xml(output,"<column7>");
		write2xml(output,TOTAL_AGGRE_ALL_AGGREATEdStr);
		write2xml(output,"</column7>\n");

		write2xml(output,"</row>\n");

		write2xml(output,"<row>\n");
		write2xml(output,"<fixedColumn>Dropped</fixedColumn>\n");

		write2xml(output,"<column1>");
		write2xml(output,temp_D_cab_droppedStr);
		write2xml(output,"</column1>\n");

		write2xml(output,"<column2>");
		write2xml(output,temp_F_chasis_droppedStr);
		write2xml(output,"</column2>\n");

		write2xml(output,"<column3>");
		write2xml(output,temp_G_Electrical_droppedStr);
		write2xml(output,"</column3>\n");

		write2xml(output,"<column4>");
		write2xml(output,temp_H_POWERTRAIN_droppedStr);
		write2xml(output,"</column4>\n");

		write2xml(output,"<column5>");
		write2xml(output,temp_K_Vehicle_droppedStr);
		write2xml(output,"</column5>\n");

		write2xml(output,"<column6>");
		write2xml(output,temp_A_Application_droppedStr);
		write2xml(output,"</column6>\n");

		write2xml(output,"<column7>");
		write2xml(output,TOTAL_DROP_ALL_AGGREATEStr);
		write2xml(output,"</column7>\n");

		write2xml(output,"</row>\n");

		write2xml(output,"<row>\n");
		write2xml(output,"<fixedColumn>Total</fixedColumn>\n");

		write2xml(output,"<column1>");
		write2xml(output,temp_D_cab_totalStr);
		write2xml(output,"</column1>\n");

		write2xml(output,"<column2>");
		write2xml(output,temp_F_chasis_totalStr);
		write2xml(output,"</column2>\n");

		write2xml(output,"<column3>");
		write2xml(output,temp_G_Electrical_totalStr);
		write2xml(output,"</column3>\n");

		write2xml(output,"<column4>");
		write2xml(output,temp_H_POWERTRAIN_totalStr);
		write2xml(output,"</column4>\n");

		write2xml(output,"<column5>");
		write2xml(output,temp_K_Vehicle_totalStr);
		write2xml(output,"</column5>\n");

		write2xml(output,"<column6>");
		write2xml(output,temp_A_Application_totalStr);
		write2xml(output,"</column6>\n");

		write2xml(output,"<column7>");
		write2xml(output,TOTAL_Grand_ALL_AGGREATEStr);
		write2xml(output,"</column7>\n");

		write2xml(output,"</row>\n");
		write2xml(output,"</test1>\n");
	
		*/
	//	write2xml(output,"</rows>\n");
	
	
		if(TotalApprovedTask>0)
		{
			char chars_to_remove[] = "\n\r*,#";
				
			for(nprapprove=0;nprapprove<TotalApprovedTask;nprapprove++)
			{
				tag_t Approve_NPR = NULLTAG;
				tag_t refrelation_type = NULLTAG;
				tag_t *refnprchklist = NULLTAG;

				char *Temp_MCCproduct_line	= NULL;
				char *MCCproduct_line	= NULL;
				char *tempMCCproduct_line	= NULL;
				char *NewPart_ReqNumber	= NULL;
				char *Part_Type	= NULL;
				char *Mod_Address	= NULL;
				char *Aggregatevalue	= NULL;
				char *MCCStatusvalue	= NULL;
				char *tmlpartvalue	= NULL;
				char *NPRPlatform	= NULL;
				char *NPRPrjCode	= NULL;
				char *TempNPRPrjCode	= NULL;
				char *MappedProductLine	= NULL;
				char *TempNewPart_ReqNumber	= NULL;
				char *TempApproveComment	= NULL;
				char *NPRMCCApproveDate	= NULL;
				char *NPRMCCApprovedBy	= NULL;
				char *TempNPRMCCApproveDate	= NULL;
				char *TempNPRMCCApprovedBy	= NULL;

				char *TargetDate	= NULL;
				char *ObsoluteNumber	= NULL;
				char *MCCFinalComment	= NULL;
				char *NwRaisedBy	= NULL;
				char *IBDomestic	= NULL;
				char *SubModule	= NULL;
				char *NewVCNumber	= NULL;
				char *BaseVCNumber	= NULL;
				char *BaseSubModuleNumber	= NULL;
				char *PartDescription	= NULL;
				char *PartDescriptionTemp	= NULL;
				char *MCCFinalCommentTemp	= NULL;
				char *MccStartDate	= NULL;
				char *NewVcDesc	= NULL;
				char *BaseVcDesc	= NULL;

				int	refcnt	= 0;

				Approve_NPR = soResultApproved[nprapprove];
				AOM_UIF_ask_value(Approve_NPR,"t5_MCCapproveRejectComment",&TempApproveComment);
				AOM_UIF_ask_value(Approve_NPR,"t5_ProductLine",&Temp_MCCproduct_line);
				AOM_UIF_ask_value(Approve_NPR,"item_id",&NewPart_ReqNumber);
				AOM_UIF_ask_value(Approve_NPR,"t5_PartType",&Part_Type);
				AOM_UIF_ask_value(Approve_NPR,"t5_ModuleAddress",&Mod_Address);
				AOM_UIF_ask_value(Approve_NPR,"t5_AggregateGrp",&Aggregatevalue);
				AOM_UIF_ask_value(Approve_NPR,"t5_MCCStatus",&MCCStatusvalue);
				AOM_UIF_ask_value(Approve_NPR,"t5_NwTmlPtNo",&tmlpartvalue);
				AOM_UIF_ask_value(Approve_NPR,"t5_Plateform",&NPRPlatform);
				AOM_UIF_ask_value(Approve_NPR,"t5_ProjectCode",&NPRPrjCode);
				AOM_UIF_ask_value(Approve_NPR,"t5_MCCApproveDate",&NPRMCCApproveDate);
				AOM_UIF_ask_value(Approve_NPR,"t5_MCCApprovedBy",&NPRMCCApprovedBy);

				AOM_UIF_ask_value(Approve_NPR,"t5_MCCApproveDate",&TempNPRMCCApproveDate);
				AOM_UIF_ask_value(Approve_NPR,"t5_MCCApprovedBy",&TempNPRMCCApprovedBy);

				AOM_UIF_ask_value(Approve_NPR,"t5_TargetDate",&TargetDate);
				AOM_UIF_ask_value(Approve_NPR,"t5_ObsoluteNumber",&ObsoluteNumber);
				AOM_UIF_ask_value(Approve_NPR,"t5_MCCFinalComment",&MCCFinalComment);
				AOM_UIF_ask_value(Approve_NPR,"t5_NwRaisedBy",&NwRaisedBy);
				AOM_UIF_ask_value(Approve_NPR,"t5_IBDomestic",&IBDomestic);
				AOM_UIF_ask_value(Approve_NPR,"t5_SubModule",&SubModule);
				AOM_UIF_ask_value(Approve_NPR,"t5_MCCStartDate",&MccStartDate);

				int lenght = 0;
				lenght = tc_strlen(SubModule);
				PartDescription=(char *)MEM_alloc(200);

				
				if(tc_strlen(Mod_Address)>0)
				{
					int n_Cntrltags_found = 0;
					tag_t	*Cntrltags_found	= NULLTAG;
					char *TempPartDescription = NULL;
					char *NewSubModAdd = NULL;
					NewSubModAdd = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(NewSubModAdd,"M");
					tc_strcat(NewSubModAdd,Mod_Address);
					Cntrlqry_values[2] = NewSubModAdd;
					QRY_execute(ControlObjQuery, 3, Cntrlqry_entries, Cntrlqry_values, &n_Cntrltags_found, &Cntrltags_found);
					printf("\n n_Cntrltags_found[%d]\n",n_Cntrltags_found);fflush(stdout);
					if(n_Cntrltags_found>0)
					{
						AOM_UIF_ask_value(Cntrltags_found[0],"t5_Userinfo3",&TempPartDescription);
						tc_strcpy(PartDescription,TempPartDescription);
					}
					else
					{
						tc_strcpy(PartDescription,"NA");
					}
					
				}
				//PartDescription= NewPartsubString(SubModule,3,lenght-3);
				
				else
				{
					tc_strcpy(PartDescription,"NA");
				}
				remove_chars(PartDescription, chars_to_remove);
				remove_chars(tmlpartvalue, chars_to_remove);
				remove_chars(ObsoluteNumber, chars_to_remove);
				remove_chars(TargetDate, chars_to_remove);
				remove_chars(MCCFinalComment, chars_to_remove);

				//replace_multiple_newlines(PartDescription, '-');
				//replace_multiple_newlines(tmlpartvalue, '-');
				//replace_multiple_newlines(ObsoluteNumber, '-');
				//replace_multiple_newlines(TargetDate, '-');
				printf("\n PartDescription[%s]\n",PartDescription);fflush(stdout);
				printf("\n tmlpartvalue[%s]\n",tmlpartvalue);fflush(stdout);
				printf("\n ObsoluteNumber[%s]\n",ObsoluteNumber);fflush(stdout);
				printf("\n TargetDate[%s]\n",TargetDate);fflush(stdout);
				printf("\n MCCFinalComment[%s]\n",MCCFinalComment);fflush(stdout);

				
				//replace_multiple_newlines(MCCFinalComment, '-');
				//printf("\n MCCFinalComment[%s]\n",MCCFinalComment);fflush(stdout);

				GRM_find_relation_type("IMAN_reference", &refrelation_type);
				GRM_list_secondary_objects_only(Approve_NPR,refrelation_type,&refcnt,&refnprchklist);
				if(refcnt>0)
				{
					int checklistcnt = 0;
					tag_t	checkListObj = NULLTAG;
					char * CheckListType = NULL;
					for(checklistcnt=0;checklistcnt<refcnt;checklistcnt++)
					{
						checkListObj = refnprchklist[checklistcnt];
						AOM_UIF_ask_value(checkListObj,"object_type",&CheckListType);
						if(tc_strcmp(CheckListType,"New Part Request CheckList")==0)
						{
							break;
						}
					}
					if(checkListObj!=NULLTAG)
					{
						AOM_UIF_ask_value(checkListObj,"t5_VCNumber",&NewVCNumber);
						AOM_UIF_ask_value(checkListObj,"t5_BaseVCNum",&BaseVCNumber);
						AOM_UIF_ask_value(checkListObj,"t5_BaseSubModule",&BaseSubModuleNumber);
						AOM_UIF_ask_value(checkListObj,"t5_VCDesc",&NewVcDesc);
						AOM_UIF_ask_value(checkListObj,"t5_BaseVCDesc",&BaseVcDesc);

						remove_chars(NewVCNumber, chars_to_remove);
						remove_chars(BaseVCNumber, chars_to_remove);
						remove_chars(BaseSubModuleNumber, chars_to_remove);
						remove_chars(NewVcDesc, chars_to_remove);
						remove_chars(BaseVcDesc, chars_to_remove);
					}
					else
					{
						NewVCNumber = (char *) MEM_alloc(10);
						BaseVCNumber = (char *) MEM_alloc(10);
						BaseSubModuleNumber = (char *) MEM_alloc(10);
						NewVcDesc = (char *) MEM_alloc(10);
						BaseVcDesc = (char *) MEM_alloc(10);

						tc_strcpy(NewVCNumber,"NA");
						tc_strcpy(BaseVCNumber,"NA");
						tc_strcpy(BaseSubModuleNumber,"NA");
						tc_strcpy(NewVcDesc,"NA");
						tc_strcpy(BaseVcDesc,"NA");
					}

					//replace_multiple_newlines(NewVCNumber, '-');
					//replace_multiple_newlines(BaseVCNumber, '-');
					//replace_multiple_newlines(BaseSubModuleNumber, '-');

					

					printf("\n Approve:NewPart_ReqNumber[%s]\n",NewPart_ReqNumber);fflush(stdout);
					printf("\n Approve:NewVCNumber[%s]\n",NewVCNumber);fflush(stdout);
				}
				else
				{
					NewVCNumber = (char *) MEM_alloc(10);
					BaseVCNumber = (char *) MEM_alloc(10);
					BaseSubModuleNumber = (char *) MEM_alloc(10);
					NewVcDesc = (char *) MEM_alloc(10);
					BaseVcDesc = (char *) MEM_alloc(10);

					tc_strcpy(NewVCNumber,"NA");
					tc_strcpy(BaseVCNumber,"NA");
					tc_strcpy(BaseSubModuleNumber,"NA");
					tc_strcpy(NewVcDesc,"NA");
					tc_strcpy(BaseVcDesc,"NA");
				}

				if(tc_strcmp(Temp_MCCproduct_line,"Other")==0 || tc_strlen(Temp_MCCproduct_line)==0)
				{
					// SYSCD PartPlatform
					// Info01 -->NPRPlatform
					// Info02 --> NPRPrjCode
					// Info03 --> Product Line

					TempNPRPrjCode = NULL;
					TempNPRPrjCode = (char *) MEM_alloc(50);
					tc_strcpy(TempNPRPrjCode,"*");
					tc_strcat(TempNPRPrjCode,NPRPrjCode);
					tc_strcat(TempNPRPrjCode,"*");
					ProductLineqry_values[0]	= "PartPlatform";
					ProductLineqry_values[1]	= NPRPlatform;
					ProductLineqry_values[2]	= TempNPRPrjCode;
					QRY_execute(ProductLinequery, 3, ProductLineqry_entries, ProductLineqry_values, &ProductLinectrl_n_found, &ProductLineCntrlObjs);
					printf("\n ProductLinectrl_n_found[%d]\n",ProductLinectrl_n_found);fflush(stdout);
					if(ProductLinectrl_n_found>0)
					{
						ProductLineCntrlquery = ProductLineCntrlObjs[0];
						AOM_UIF_ask_value(ProductLineCntrlquery,"t5_Userinfo3",&MappedProductLine);
					}
					else
					{
						int ProductLinectrl_n_found1 = 0;
						tag_t	ProductLineCntrlquery	= NULLTAG;
						ProductLineqry_values[0]	= "PartPlatform";
						ProductLineqry_values[1]	= NPRPlatform;
						ProductLineqry_values[2]	= "*";
						QRY_execute(ProductLinequery, 3, ProductLineqry_entries, ProductLineqry_values, &ProductLinectrl_n_found1, &ProductLineCntrlObjs1);
						if(ProductLinectrl_n_found1>0)
						{
							ProductLineCntrlquery = ProductLineCntrlObjs1[0];
							AOM_UIF_ask_value(ProductLineCntrlquery,"t5_Userinfo3",&MappedProductLine);
						}
					}
					printf("\n MappedProductLine[%s]\n",MappedProductLine);fflush(stdout);
					if(tc_strlen(MappedProductLine)>0)
					{
						tag_t		 updateinfo1			=  NULLTAG;
						AOM_refresh( Approve_NPR, POM_modify_lock);
						POM_attr_id_of_attr("t5_ProductLine", "T5_NwPCre", &updateinfo1);
						POM_set_attr_string(1, &Approve_NPR, updateinfo1, MappedProductLine);
						POM_save_instances(1, &Approve_NPR, false);
						AOM_refresh(Approve_NPR, POM_no_lock);
					}
					else
					{
						tag_t		 updateinfo1			=  NULLTAG;
						AOM_refresh( Approve_NPR, POM_modify_lock);
						POM_attr_id_of_attr("t5_ProductLine", "T5_NwPCre", &updateinfo1);
						POM_set_attr_string(1, &Approve_NPR, updateinfo1, "Other");
						POM_save_instances(1, &Approve_NPR, false);
						AOM_refresh(Approve_NPR, POM_no_lock);
					}					
				}
				if(tc_strlen(TempApproveComment)==0)
				{
					char *EpmSignOffComment	= NULL;
					TempNewPart_ReqNumber = (char *) MEM_alloc(100);
					tc_strcpy(TempNewPart_ReqNumber,"*");
					tc_strcat(TempNewPart_ReqNumber,NewPart_ReqNumber);
					tc_strcat(TempNewPart_ReqNumber,"*");
					ApproveSignOff_values[0]	= TempNewPart_ReqNumber;
					ApproveSignOff_values[1]	= "*MCC*";
					ApproveSignOff_values[2]	= "Approve";
					QRY_execute(SignOffquery, 3, ApproveSignOff_entries, ApproveSignOff_values, &ApproveSignOff_n_found, &ApproveSignOffObjs);
					printf("\n ApproveSignOff_n_found[%d]\n",ApproveSignOff_n_found);fflush(stdout);
					if(ApproveSignOff_n_found>0)
					{
						int count = 0;
						ApproveSignOffObj = NULLTAG;
						char *EpmSignOffType	= NULL;
						
						char *EpmSignOffDecision	= NULL;
						for(count=0;count<ApproveSignOff_n_found;count++)
						{
							EpmSignOffComment	= NULL;
							ApproveSignOffObj = ApproveSignOffObjs[count];
							AOM_UIF_ask_value(ApproveSignOffObj,"object_type",&EpmSignOffType);
							AOM_UIF_ask_value(ApproveSignOffObj,"fnd0SignoffDecision",&EpmSignOffDecision);
							if(tc_strcmp(EpmSignOffType,"EPMPerformSignoffTask")==0 && tc_strcmp(EpmSignOffDecision,"Approved")==0)
							{
								AOM_UIF_ask_value(ApproveSignOffObj,"fnd0SignoffComments",&EpmSignOffComment);
								break;
							}
						}						
					}
					printf("\n Approved EpmSignOffComment[%d]\n",EpmSignOffComment);fflush(stdout);
					if(tc_strlen(EpmSignOffComment)>0)
					{
						tag_t		 updateinfo1			=  NULLTAG;
						AOM_refresh( Approve_NPR, POM_modify_lock);
						POM_attr_id_of_attr("t5_MCCapproveRejectComment", "T5_NwPCre", &updateinfo1);
						POM_set_attr_string(1, &Approve_NPR, updateinfo1, EpmSignOffComment);
						POM_save_instances(1, &Approve_NPR, false);
						AOM_refresh(Approve_NPR, POM_no_lock);
					}
					else
					{
						tag_t		 updateinfo1			=  NULLTAG;
						AOM_refresh( Approve_NPR, POM_modify_lock);
						POM_attr_id_of_attr("t5_MCCapproveRejectComment", "T5_NwPCre", &updateinfo1);
						POM_set_attr_string(1, &Approve_NPR, updateinfo1, "NA");
						POM_save_instances(1, &Approve_NPR, false);
						AOM_refresh(Approve_NPR, POM_no_lock);
					}
				}

				AOM_UIF_ask_value(Approve_NPR,"t5_ProductLine",&MCCproduct_line);
				AOM_UIF_ask_value(Approve_NPR,"t5_MCCapproveRejectComment",&ApproveComment);
				
				/* @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@*/
				    int weekdayCount;
					if((tc_strstr(MccStartDate,"Jan")!=NULL) || (tc_strstr(MccStartDate,"Feb")!=NULL) || (tc_strstr(MccStartDate,"Mar")!=NULL) || (tc_strstr(MccStartDate,"Apr")!=NULL) || (tc_strstr(MccStartDate,"May")!=NULL) || (tc_strstr(MccStartDate,"Jun")!=NULL) || (tc_strstr(MccStartDate,"Jul")!=NULL) || (tc_strstr(MccStartDate,"Aug")!=NULL) || (tc_strstr(MccStartDate,"Sep")!=NULL) || (tc_strstr(MccStartDate,"Oct")!=NULL) || (tc_strstr(MccStartDate,"Nov")!=NULL) || (tc_strstr(MccStartDate,"Dec")!=NULL))
					{
						if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA") !=0))
						{
							char* ReNwMccStartDate = NULL;
							ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
							tc_strcpy(ReNwMccStartDate,MccStartDate);
							printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
							replaceSpacesWithSlash(ReNwMccStartDate);
							if(ReNwMccStartDate != NULL)
							{
								STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
							}
							 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
							char* Freceived = NULL;
							char* Sreceived = NULL;
							Freceived = tc_strtok(ReNwMccStartDate,"/");
							Sreceived = tc_strtok(NULL,"/");
							printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
							printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
							char* ReInpDay = NULL;
							char* ReInpMon = NULL;
							char* ReInpYear = NULL;
							char* ReInpYearChar = NULL;
							ReInpDay=tc_strtok(Freceived,"-");
							ReInpMon=tc_strtok(NULL,"-");
							ReInpYear=tc_strtok(NULL,"-");
							printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
							printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
							char* RespMonth = NULL;
							RespMonth = MonthAbbreviation(ReInpMon);
							printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
							printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
							ReInpYearChar=subString(ReInpYear,2,2);
							printf("\n ReInpYearChar: [%s]",ReInpYearChar);fflush(stdout);
							char* ReInpYearCharFinal = NULL;
							ReInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(ReInpYearCharFinal,"1");
							tc_strcat(ReInpYearCharFinal,ReInpYearChar);
							printf("\n ReInpYearCharFinal: [%s] \n", ReInpYearCharFinal);fflush(stdout);
							char* ReInpHr = NULL;
							char* ReInpMnt = NULL;
							//char* ReInpSec = NULL;
							char ReInpSec[] = "00";
							ReInpHr=tc_strtok(Sreceived,":");
							ReInpMnt=tc_strtok(NULL,":");
							//ReInpSec=tc_strtok(NULL,":");
							printf("\n ReInpHr: [%s]\n", ReInpHr);fflush(stdout);
							printf("\n ReInpMnt: [%s]\n", ReInpMnt);fflush(stdout);
							printf("\n ReInpSec: [%s]\n", ReInpSec);fflush(stdout);
							
							
							char* ReNwNPRMCCApproveDate = NULL;
							ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
							tc_strcpy(ReNwNPRMCCApproveDate,NPRMCCApproveDate);
							printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
							replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
							if(ReNwNPRMCCApproveDate != NULL)
							{
								STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
							}
							printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
							char* Fcompleted = NULL;
							char* Scompleted = NULL;
							Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
							Scompleted = tc_strtok(NULL,"/");
							printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
							printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
							char* ComInpDay = NULL;
							char* ComInpMon = NULL;
							char* ComInpYear = NULL;
							char* ComInpYearChar = NULL;
							ComInpDay=tc_strtok(Fcompleted,"-");
							ComInpMon=tc_strtok(NULL,"-");
							ComInpYear=tc_strtok(NULL,"-");
							printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
							printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
							char* ComRespMonth = NULL;
							ComRespMonth = MonthAbbreviation(ComInpMon);
							printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
							printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
							ComInpYearChar=subString(ComInpYear,2,2);
							printf("\n ComInpYearChar: [%s]",ComInpYearChar);fflush(stdout);
							char* ComInpYearCharFinal = NULL;
							ComInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(ComInpYearCharFinal,"1");
							tc_strcat(ComInpYearCharFinal,ComInpYearChar);
							printf("\n ComInpYearCharFinal: [%s] \n", ComInpYearCharFinal);fflush(stdout);
							char* ComInpHr = NULL;
							char* ComInpMnt = NULL;
							//char* ComInpSec = NULL;
							char ComInpSec[] = "00";
							ComInpHr=tc_strtok(Scompleted,":");
							ComInpMnt=tc_strtok(NULL,":");
							//ComInpSec=tc_strtok(NULL,":");
							printf("\n ComInpHr: [%s]\n", ComInpHr);fflush(stdout);
							printf("\n ComInpMnt: [%s]\n", ComInpMnt);fflush(stdout);
							printf("\n ComInpSec: [%s]\n", ComInpSec);fflush(stdout);
							
							int ReInpdayFinal = atoi(ReInpDay);
							int ReInpMonFinal = atoi(RespMonth);
							int ReInpYearFinal = atoi(ReInpYearCharFinal);
							int ReInpHrFinal = atoi(ReInpHr);
							int ReInpMntFinal = atoi(ReInpMnt);
							int ReInpSecFinal = atoi(ReInpSec);
							
							int ComInpDayFinal = atoi(ComInpDay);
							int ComInpMonFinal = atoi(ComRespMonth);
							int ComInpYearFinal = atoi(ComInpYearCharFinal);
							int ComInpHrFinal = atoi(ComInpHr);
							int ComInpMntFinal = atoi(ComInpMnt);
							int ComInpSecFinal = atoi(ComInpSec);
							
							struct tm tm_start = {ReInpSecFinal, ReInpMntFinal, ReInpHrFinal, ReInpdayFinal, ReInpMonFinal, ReInpYearFinal}; // Sec, Min, Hour, Month_Day, Month_No, Year
							struct tm tm_end = {ComInpSecFinal, ComInpMntFinal, ComInpHrFinal, ComInpDayFinal, ComInpMonFinal, ComInpYearFinal};  // Sec, Min, Hour, Month_Day, Month_No, Year
							
							time_t start = mktime(&tm_start);
							time_t end = mktime(&tm_end);
							
							printf("Current start: %s", ctime(&start));
							printf("Current end: %s", ctime(&end));

							weekdayCount = weekdaysBetween(start, end);
							printf("Number of weekdays between the dates: [%d]\n", weekdayCount);
						}
						else
						{
							weekdayCount = 0;
						}
					}
                    else
                    {
						if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA") !=0))
						{
							char* ReNwMccStartDate = NULL;
							ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
							tc_strcpy(ReNwMccStartDate,MccStartDate);
							printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
							replaceSpacesWithSlash(ReNwMccStartDate);
							if(ReNwMccStartDate != NULL)
							{
								STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
							}
							 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
							char* Freceived = NULL;
							char* Sreceived = NULL;
							Freceived = tc_strtok(ReNwMccStartDate,"/");
							Sreceived = tc_strtok(NULL,"/");
							printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
							printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
							char* ReInpDay = NULL;
							char* ReInpMon = NULL;
							char* ReInpYear = NULL;
							char* ReInpYearChar = NULL;
							ReInpDay=tc_strtok(Freceived,"-");
							ReInpMon=tc_strtok(NULL,"-");
							ReInpYear=tc_strtok(NULL,"-");
							printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
							printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
							printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
							ReInpYearChar=subString(ReInpYear,2,2);
							printf("\n ReInpYearChar: [%s]",ReInpYearChar);fflush(stdout);
							char* ReInpYearCharFinal = NULL;
							ReInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(ReInpYearCharFinal,"1");
							tc_strcat(ReInpYearCharFinal,ReInpYearChar);
							printf("\n ReInpYearCharFinal: [%s] \n", ReInpYearCharFinal);fflush(stdout);
							char* ReInpHr = NULL;
							char* ReInpMnt = NULL;
							//char* ReInpSec = NULL;
							char ReInpSec[] = "00";
							ReInpHr=tc_strtok(Sreceived,":");
							ReInpMnt=tc_strtok(NULL,":");
							//ReInpSec=tc_strtok(NULL,":");
							printf("\n ReInpHr: [%s]\n", ReInpHr);fflush(stdout);
							printf("\n ReInpMnt: [%s]\n", ReInpMnt);fflush(stdout);
							printf("\n ReInpSec: [%s]\n", ReInpSec);fflush(stdout);
							
							
							char* ReNwNPRMCCApproveDate = NULL;
							ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
							tc_strcpy(ReNwNPRMCCApproveDate,NPRMCCApproveDate);
							printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
							replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
							if(ReNwNPRMCCApproveDate != NULL)
							{
								STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
							}
							printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
							char* Fcompleted = NULL;
							char* Scompleted = NULL;
							Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
							Scompleted = tc_strtok(NULL,"/");
							printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
							printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
							char* ComInpDay = NULL;
							char* ComInpMon = NULL;
							char* ComInpYear = NULL;
							char* ComInpYearChar = NULL;
							ComInpDay=tc_strtok(Fcompleted,"-");
							ComInpMon=tc_strtok(NULL,"-");
							ComInpYear=tc_strtok(NULL,"-");
							printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
							printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
							printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
							ComInpYearChar=subString(ComInpYear,2,2);
							printf("\n ComInpYearChar: [%s]",ComInpYearChar);fflush(stdout);
							char* ComInpYearCharFinal = NULL;
							ComInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(ComInpYearCharFinal,"1");
							tc_strcat(ComInpYearCharFinal,ComInpYearChar);
							printf("\n ComInpYearCharFinal: [%s] \n", ComInpYearCharFinal);fflush(stdout);
							char* ComInpHr = NULL;
							char* ComInpMnt = NULL;
							//char* ComInpSec = NULL;
							char ComInpSec[] = "00";
							ComInpHr=tc_strtok(Scompleted,":");
							ComInpMnt=tc_strtok(NULL,":");
							//ComInpSec=tc_strtok(NULL,":");
							printf("\n ComInpHr: [%s]\n", ComInpHr);fflush(stdout);
							printf("\n ComInpMnt: [%s]\n", ComInpMnt);fflush(stdout);
							printf("\n ComInpSec: [%s]\n", ComInpSec);fflush(stdout);
							
							int ReInpdayFinal = atoi(ReInpDay);
							int ReInpMonFinal = atoi(ReInpMon);
							int ReInpYearFinal = atoi(ReInpYearCharFinal);
							int ReInpHrFinal = atoi(ReInpHr);
							int ReInpMntFinal = atoi(ReInpMnt);
							int ReInpSecFinal = atoi(ReInpSec);
							
							int ComInpDayFinal = atoi(ComInpDay);
							int ComInpMonFinal = atoi(ComInpMon);
							int ComInpYearFinal = atoi(ComInpYearCharFinal);
							int ComInpHrFinal = atoi(ComInpHr);
							int ComInpMntFinal = atoi(ComInpMnt);
							int ComInpSecFinal = atoi(ComInpSec);
							
							struct tm tm_start = {ReInpSecFinal, ReInpMntFinal, ReInpHrFinal, ReInpdayFinal, ReInpMonFinal, ReInpYearFinal}; // Sec, Min, Hour, Month_Day, Month_No, Year
							struct tm tm_end = {ComInpSecFinal, ComInpMntFinal, ComInpHrFinal, ComInpDayFinal, ComInpMonFinal, ComInpYearFinal};  // Sec, Min, Hour, Month_Day, Month_No, Year
							
							time_t start = mktime(&tm_start);
							time_t end = mktime(&tm_end);
							
							printf("Current start: %s", ctime(&start));
							printf("Current end: %s", ctime(&end));

							weekdayCount = weekdaysBetween(start, end);
							printf("Number of weekdays between the dates: [%d]\n", weekdayCount);
						}
						else
						{
							weekdayCount = 0;
						}
					}						
				/* @@@@@@@@@@@@@@@  Weekdays calculation logic end @@@@@@@@@@@@@@@@ */

				printf("\n MCCproduct_line is %s",MCCproduct_line);fflush(stdout);
				if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
				{
					tempMCCproduct_line = (char *) MEM_alloc(50);
					tc_strcpy(tempMCCproduct_line,"AGGREGATE");
				}
				if(tc_strstr(MCCproduct_line,"AGGREGATE")==NULL)
				{
					//////fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,MCCproduct_line,"Agreed",ApproveComment,MccStartDate,NPRMCCApproveDate,weekdayCount,NPRMCCApprovedBy,tmlpartvalue,NewVCNumber,NewVcDesc,BaseVCNumber,BaseVcDesc,PartDescription,IBDomestic,BaseSubModuleNumber,NwRaisedBy,ObsoluteNumber,TargetDate,MCCFinalComment);fflush(output);
					 fprintf(output1,"%s,%s,%s,%s,%s,%d,%s,%s,\n",NewPart_ReqNumber,MCCproduct_line,NPRMCCApprovedBy,MccStartDate,NPRMCCApproveDate,weekdayCount,"Approve",tmlpartvalue);fflush(output);
					//fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,MCCproduct_line,MCCStatusvalue,ApproveComment,MccStartDate,NPRMCCApproveDate,weekdayCount,NPRMCCApprovedBy,tmlpartvalue,NewVCNumber,NewVcDesc,BaseVCNumber,BaseVcDesc,PartDescription,IBDomestic,BaseSubModuleNumber,NwRaisedBy,ObsoluteNumber,TargetDate,MCCFinalComment);fflush(output);
					//fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,,,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,MCCproduct_line,MCCStatusvalue,ApproveComment,NPRMCCApproveDate,NPRMCCApprovedBy,tmlpartvalue,NewVCNumber,BaseVCNumber,PartDescriptionTemp,IBDomestic,BaseSubModuleNumber,NwRaisedBy,ObsoluteNumber,TargetDate);fflush(output);
				}
				if(tc_strcmp(tempMCCproduct_line,"AGGREGATE")==0)
				{
					//fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,tempMCCproduct_line,MCCStatusvalue,ApproveComment,MccStartDate,NPRMCCApproveDate,weekdayCount,NPRMCCApprovedBy,tmlpartvalue,NewVCNumber,NewVcDesc,BaseVCNumber,BaseVcDesc,PartDescription,IBDomestic,BaseSubModuleNumber,NwRaisedBy,ObsoluteNumber,TargetDate,MCCFinalComment);fflush(output);
					///////fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,tempMCCproduct_line,"Agreed",ApproveComment,MccStartDate,NPRMCCApproveDate,weekdayCount,NPRMCCApprovedBy,tmlpartvalue,NewVCNumber,NewVcDesc,BaseVCNumber,BaseVcDesc,PartDescription,IBDomestic,BaseSubModuleNumber,NwRaisedBy,ObsoluteNumber,TargetDate,MCCFinalComment);fflush(output);
					fprintf(output1,"%s,%s,%s,%s,%s,%d,%s,%s,\n",NewPart_ReqNumber,tempMCCproduct_line,NPRMCCApprovedBy,MccStartDate,NPRMCCApproveDate,weekdayCount,"Approve",tmlpartvalue);fflush(output);
				}
				if(tc_strlen(ApproveComment)>0)
				{
					if(tc_strcmp(ApproveComment,"New parts - new project")==0)
					{
						ApproveComment_1++;
		
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_1++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_1++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_1++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_1++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_1++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_1++;
						}
					}
					if(tc_strcmp(ApproveComment,"TPL to submodule conversion - EV modularity")==0)
					{
						ApproveComment_2++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_2++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_2++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_2++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_2++;
						}
					//	if(tc_strcmp(MCCproduct_line,"AGGR_BUSINESS")==0)
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_2++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_2++;
						}
					}
					if(tc_strcmp(ApproveComment,"TPL to submodule conversion - IB modularity")==0)
					{
						ApproveComment_3++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_3++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_3++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_3++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_3++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_3++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_3++;
						}
					}
					if(tc_strcmp(ApproveComment,"Packaging constraint")==0)
					{
						ApproveComment_4++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_4++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_4++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_4++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_4++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_4++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_4++;
						}
					}
					if(tc_strcmp(ApproveComment,"Cost Reduction")==0)
					{
						ApproveComment_5++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_5++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_5++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_5++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_5++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_5++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_5++;
						}
					}
					if(tc_strcmp(ApproveComment,"New technology introduction")==0)
					{
						ApproveComment_6++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_6++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_6++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_6++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_6++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_6++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_6++;
						}
					}
					if(tc_strcmp(ApproveComment,"New submodule number from existing parts")==0)
					{
						ApproveComment_7++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_7++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_7++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_7++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_7++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_7++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_7++;
						}
					}
					if(tc_strcmp(ApproveComment,"Quality Improvement")==0)
					{
						ApproveComment_8++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_8++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_8++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_8++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_8++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_8++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_8++;
						}
					}
					if(tc_strcmp(ApproveComment,"Drawing parameter correction")==0)
					{
						ApproveComment_9++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_9++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_9++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_9++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_9++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_9++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_9++;
						}
					}					
					if(tc_strcmp(ApproveComment,"Other")==0)
					{
						ApproveComment_10++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_10++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_10++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_10++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_10++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_10++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_10++;
						}
					}
					if(tc_strcmp(ApproveComment,"NA")==0)
					{
						ApproveComment_11++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_11++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_11++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_11++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_11++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_11++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_11++;
						}
					}
					if(tc_strcmp(ApproveComment,"Regulatory Requirement")==0)
					{
						ApproveComment_12++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_12++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_12++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_12++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_12++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_12++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_12++;
						}
					}
					if(tc_strcmp(ApproveComment,"VLO requirement")==0)
					{
						ApproveComment_13++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_13++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_13++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_13++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_13++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_13++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_13++;
						}
					}
					if(tc_strcmp(ApproveComment,"submodule conversionDefence modularity")==0)
					{
						ApproveComment_14++;
						
						if(tc_strcmp(MCCproduct_line,"BUS")==0)
						{
							bus_aggreed_14++;
						}
						if(tc_strcmp(MCCproduct_line,"HCV")==0)
						{
							hcv_aggreed_14++;
						}
						if(tc_strcmp(MCCproduct_line,"ILMCV")==0)
						{
							ilmcv_aggreed_14++;
						}
						if(tc_strcmp(MCCproduct_line,"SCV")==0)
						{
							scv_aggreed_14++;
						}
						if(tc_strstr(MCCproduct_line,"AGGREGATE")!=NULL)
						{
							aggrbusiness_aggreed_14++;
						}
						if(tc_strcmp(MCCproduct_line,"Defence")==0 || tc_strcmp(MCCproduct_line,"DEFENCE")==0)
						{
							Defence_aggreed_14++;
						}
					}
				}
			}
			
			
		bus_aggreedStr_1 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_1 = (char *) MEM_alloc(1000);
		scv_aggreedStr_1 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_1 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_1 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_1 = (char *) MEM_alloc(1000);
		platform_totalStr_1 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_1,"%d",bus_aggreed_1);
		sprintf(hcv_aggreedStr_1,"%d",hcv_aggreed_1);
		sprintf(scv_aggreedStr_1,"%d",scv_aggreed_1);
		sprintf(ilmcv_aggreedStr_1,"%d",ilmcv_aggreed_1);
		sprintf(aggrbusiness_aggreedStr_1,"%d",aggrbusiness_aggreed_1);
		sprintf(Defence_aggreedStr_1,"%d",Defence_aggreed_1);
		
		printf("\n bus_aggreed_1 is %d",bus_aggreed_1);fflush(stdout);
		printf("\n hcv_aggreed_1 is %d",hcv_aggreed_1);fflush(stdout);
		printf("\n scv_aggreed_1 is %d",scv_aggreed_1);fflush(stdout);
		printf("\n ilmcv_aggreed_1 is %d",ilmcv_aggreed_1);fflush(stdout);
		printf("\n aggrbusiness_aggreed_1 is %d",aggrbusiness_aggreed_1);fflush(stdout);
		printf("\n Defence_aggreed_1 is %d",Defence_aggreed_1);fflush(stdout);
		platform_total_1 = (bus_aggreed_1 + hcv_aggreed_1 + scv_aggreed_1 + ilmcv_aggreed_1 + aggrbusiness_aggreed_1 + Defence_aggreed_1);
		printf("\n platform_total_1 is %d",platform_total_1);fflush(stdout);
		
		if (platform_total_1 >0)
		{
		percent_bus_1 = ((float)bus_aggreed_1 / (float)platform_total_1)*100;
		percent_hcv_1 = ((float)hcv_aggreed_1 / (float)platform_total_1)*100;
		percent_ilmcv_1 = ((float)ilmcv_aggreed_1 / (float)platform_total_1)*100;
		percent_scv_1 = ((float)scv_aggreed_1 / (float)platform_total_1)*100;
		percent_aggr_1 = ((float)aggrbusiness_aggreed_1 / (float)platform_total_1)*100;
		percent_Defence_1 = ((float)Defence_aggreed_1 / (float)platform_total_1)*100;
		}
		if(platform_total_1 == 0)
		{
			percent_bus_1 = 0.00;
			percent_hcv_1 = 0.00;
			percent_ilmcv_1 = 0.00;
			percent_scv_1 = 0.00;
			percent_aggr_1 = 0.00;
			percent_Defence_1 = 0.00;
		}
		
		
		bus_aggreedStr_2 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_2 = (char *) MEM_alloc(1000);
		scv_aggreedStr_2 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_2 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_2 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_2 = (char *) MEM_alloc(1000);
		platform_totalStr_2 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_2,"%d",bus_aggreed_2);
		sprintf(hcv_aggreedStr_2,"%d",hcv_aggreed_2);
		sprintf(scv_aggreedStr_2,"%d",scv_aggreed_2);
		sprintf(ilmcv_aggreedStr_2,"%d",ilmcv_aggreed_2);
		sprintf(aggrbusiness_aggreedStr_2,"%d",aggrbusiness_aggreed_2);
		sprintf(Defence_aggreedStr_2,"%d",Defence_aggreed_2);
		
		platform_total_2 = (bus_aggreed_2 + hcv_aggreed_2 + scv_aggreed_2 + ilmcv_aggreed_2 + aggrbusiness_aggreed_2 + Defence_aggreed_2);
		printf("\n platform_total_2 is %d",platform_total_2);fflush(stdout);
		
		if (platform_total_2 >0)
		{
		percent_bus_2 = ((float)bus_aggreed_2 / (float)platform_total_2)*100;
		percent_hcv_2 = ((float)hcv_aggreed_2 / (float)platform_total_2)*100;
		percent_ilmcv_2 = ((float)ilmcv_aggreed_2 / (float)platform_total_2)*100;
		percent_scv_2 = ((float)scv_aggreed_2 / (float)platform_total_2)*100;
		percent_aggr_2 = ((float)aggrbusiness_aggreed_2 / (float)platform_total_2)*100;
		percent_Defence_2 = ((float)Defence_aggreed_2 / (float)platform_total_2)*100;
		}
		
		if(platform_total_2 == 0)
		{
			percent_bus_2 = 0.00;
			percent_hcv_2 = 0.00;
			percent_ilmcv_2 = 0.00;
			percent_scv_2 = 0.00;
			percent_aggr_2 = 0.00;
			percent_Defence_2 = 0.00;
		}
		
		bus_aggreedStr_3 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_3 = (char *) MEM_alloc(1000);
		scv_aggreedStr_3 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_3 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_3 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_3 = (char *) MEM_alloc(1000);
		platform_totalStr_3 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_3,"%d",bus_aggreed_3);
		sprintf(hcv_aggreedStr_3,"%d",hcv_aggreed_3);
		sprintf(scv_aggreedStr_3,"%d",scv_aggreed_3);
		sprintf(ilmcv_aggreedStr_3,"%d",ilmcv_aggreed_3);
		sprintf(aggrbusiness_aggreedStr_3,"%d",aggrbusiness_aggreed_3);
		sprintf(Defence_aggreedStr_3,"%d",Defence_aggreed_3);
		
		platform_total_3 = (bus_aggreed_3 + hcv_aggreed_3 + scv_aggreed_3 + ilmcv_aggreed_3 + aggrbusiness_aggreed_3 + Defence_aggreed_3);
		printf("\n platform_total_3 is %d",platform_total_3);fflush(stdout);
		
		if (platform_total_3 >0)
		{
		percent_bus_3 = ((float)bus_aggreed_3 / (float)platform_total_3)*100;
		percent_hcv_3 = ((float)hcv_aggreed_3 / (float)platform_total_3)*100;
		percent_ilmcv_3 = ((float)ilmcv_aggreed_3 / (float)platform_total_3)*100;
		percent_scv_3 = ((float)scv_aggreed_3 / (float)platform_total_3)*100;
		percent_aggr_3 = ((float)aggrbusiness_aggreed_3 / (float)platform_total_3)*100;
		percent_Defence_3 = ((float)Defence_aggreed_3 / (float)platform_total_3)*100;
		}
		
		if(platform_total_3 == 0)
		{
			percent_bus_3 = 0.00;
			percent_hcv_3 = 0.00;
			percent_ilmcv_3 = 0.00;
			percent_scv_3 = 0.00;
			percent_aggr_3 = 0.00;
			percent_Defence_3 = 0.00;
		}
		
		bus_aggreedStr_4 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_4 = (char *) MEM_alloc(1000);
		scv_aggreedStr_4 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_4 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_4 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_4 = (char *) MEM_alloc(1000);
		platform_totalStr_4 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_4,"%d",bus_aggreed_4);
		sprintf(hcv_aggreedStr_4,"%d",hcv_aggreed_4);
		sprintf(scv_aggreedStr_4,"%d",scv_aggreed_4);
		sprintf(ilmcv_aggreedStr_4,"%d",ilmcv_aggreed_4);
		sprintf(aggrbusiness_aggreedStr_4,"%d",aggrbusiness_aggreed_4);
		sprintf(Defence_aggreedStr_4,"%d",Defence_aggreed_4);
		
		platform_total_4 = (bus_aggreed_4 + hcv_aggreed_4 + scv_aggreed_4 + ilmcv_aggreed_4 + aggrbusiness_aggreed_4 + Defence_aggreed_4);
		printf("\n platform_total_4 is %d",platform_total_4);fflush(stdout);
		
		if (platform_total_4 >0)
		{
		percent_bus_4 = ((float)bus_aggreed_4 / (float)platform_total_4)*100;
		percent_hcv_4 = ((float)hcv_aggreed_4 / (float)platform_total_4)*100;
		percent_ilmcv_4 = ((float)ilmcv_aggreed_4 / (float)platform_total_4)*100;
		percent_scv_4 = ((float)scv_aggreed_4 / (float)platform_total_4)*100;
		percent_aggr_4 = ((float)aggrbusiness_aggreed_4 / (float)platform_total_4)*100;
		percent_Defence_4 = ((float)Defence_aggreed_4 / (float)platform_total_4)*100;
		}
		
		if(platform_total_4 == 0)
		{
			percent_bus_4 = 0.00;
			percent_hcv_4 = 0.00;
			percent_ilmcv_4 = 0.00;
			percent_scv_4 = 0.00;
			percent_aggr_4 = 0.00;
			percent_Defence_4 = 0.00;
		}
		
		bus_aggreedStr_5 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_5 = (char *) MEM_alloc(1000);
		scv_aggreedStr_5 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_5 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_5 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_5 = (char *) MEM_alloc(1000);
		platform_totalStr_5 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_5,"%d",bus_aggreed_5);
		sprintf(hcv_aggreedStr_5,"%d",hcv_aggreed_5);
		sprintf(scv_aggreedStr_5,"%d",scv_aggreed_5);
		sprintf(ilmcv_aggreedStr_5,"%d",ilmcv_aggreed_5);
		sprintf(aggrbusiness_aggreedStr_5,"%d",aggrbusiness_aggreed_5);
		sprintf(Defence_aggreedStr_5,"%d",Defence_aggreed_5);
		
		platform_total_5 = (bus_aggreed_5 + hcv_aggreed_5 + scv_aggreed_5 + ilmcv_aggreed_5 + aggrbusiness_aggreed_5 + Defence_aggreed_5);
		printf("\n platform_total_5 is %d",platform_total_5);fflush(stdout);
		
		if (platform_total_5 >0)
		{
		percent_bus_5 = ((float)bus_aggreed_5 / (float)platform_total_5)*100;
		percent_hcv_5 = ((float)hcv_aggreed_5 / (float)platform_total_5)*100;
		percent_ilmcv_5 = ((float)ilmcv_aggreed_5 / (float)platform_total_5)*100;
		percent_scv_5 = ((float)scv_aggreed_5 / (float)platform_total_5)*100;
		percent_aggr_5 = ((float)aggrbusiness_aggreed_5 / (float)platform_total_5)*100;
		percent_Defence_5 = ((float)Defence_aggreed_5 / (float)platform_total_5)*100;
		}
		if(platform_total_5 == 0)
		{
			percent_bus_5 = 0.00;
			percent_hcv_5 = 0.00;
			percent_ilmcv_5 = 0.00;
			percent_scv_5 = 0.00;
			percent_aggr_5 = 0.00;
			percent_Defence_5 = 0.00;
		}
		
		bus_aggreedStr_6 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_6 = (char *) MEM_alloc(1000);
		scv_aggreedStr_6 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_6 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_6 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_6 = (char *) MEM_alloc(1000);
		platform_totalStr_6 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_6,"%d",bus_aggreed_6);
		sprintf(hcv_aggreedStr_6,"%d",hcv_aggreed_6);
		sprintf(scv_aggreedStr_6,"%d",scv_aggreed_6);
		sprintf(ilmcv_aggreedStr_6,"%d",ilmcv_aggreed_6);
		sprintf(aggrbusiness_aggreedStr_6,"%d",aggrbusiness_aggreed_6);
		sprintf(Defence_aggreedStr_6,"%d",Defence_aggreed_6);
		
		platform_total_6 = (bus_aggreed_6 + hcv_aggreed_6 + scv_aggreed_6 + ilmcv_aggreed_6 + aggrbusiness_aggreed_6 + Defence_aggreed_6);
		printf("\n platform_total_6 is %d",platform_total_6);fflush(stdout);
		
		if (platform_total_6 >0)
		{
		percent_bus_6 = ((float)bus_aggreed_6 / (float)platform_total_6)*100;
		percent_hcv_6 = ((float)hcv_aggreed_6 / (float)platform_total_6)*100;
		percent_ilmcv_6 = ((float)ilmcv_aggreed_6 / (float)platform_total_6)*100;
		percent_scv_6 = ((float)scv_aggreed_6 / (float)platform_total_6)*100;
		percent_aggr_6 = ((float)aggrbusiness_aggreed_6 / (float)platform_total_6)*100;
		percent_Defence_6 = ((float)Defence_aggreed_6 / (float)platform_total_6)*100;
		}
		
		if(platform_total_6 == 0)
		{
			percent_bus_6 = 0.00;
			percent_hcv_6 = 0.00;
			percent_ilmcv_6 = 0.00;
			percent_scv_6 = 0.00;
			percent_aggr_6 = 0.00;
			percent_Defence_6 = 0.00;
		}
		
		bus_aggreedStr_7 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_7 = (char *) MEM_alloc(1000);
		scv_aggreedStr_7 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_7 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_7 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_7 = (char *) MEM_alloc(1000);
		platform_totalStr_7 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_7,"%d",bus_aggreed_7);
		sprintf(hcv_aggreedStr_7,"%d",hcv_aggreed_7);
		sprintf(scv_aggreedStr_7,"%d",scv_aggreed_7);
		sprintf(ilmcv_aggreedStr_7,"%d",ilmcv_aggreed_7);
		sprintf(aggrbusiness_aggreedStr_7,"%d",aggrbusiness_aggreed_7);
		sprintf(Defence_aggreedStr_7,"%d",Defence_aggreed_7);
		
		
		platform_total_7 = (bus_aggreed_7 + hcv_aggreed_7 + scv_aggreed_7 + ilmcv_aggreed_7 + aggrbusiness_aggreed_7 + Defence_aggreed_7);
		printf("\n platform_total_7 is %d",platform_total_7);fflush(stdout);
		
		if (platform_total_7 >0)
		{
		percent_bus_7 = ((float)bus_aggreed_7 / (float)platform_total_7)*100;
		percent_hcv_7 = ((float)hcv_aggreed_7 / (float)platform_total_7)*100;
		percent_ilmcv_7 = ((float)ilmcv_aggreed_7 / (float)platform_total_7)*100;
		percent_scv_7 = ((float)scv_aggreed_7 / (float)platform_total_7)*100;
		percent_aggr_7 = ((float)aggrbusiness_aggreed_7 / (float)platform_total_7)*100;
		percent_Defence_7 = ((float)Defence_aggreed_7 / (float)platform_total_7)*100;
		}
		
		if(platform_total_7 == 0)
		{
			percent_bus_7 = 0.00;
			percent_hcv_7 = 0.00;
			percent_ilmcv_7 = 0.00;
			percent_scv_7 = 0.00;
			percent_aggr_7 = 0.00;
			percent_Defence_7 = 0.00;
		}
		
		bus_aggreedStr_8 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_8 = (char *) MEM_alloc(1000);
		scv_aggreedStr_8 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_8 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_8 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_8 = (char *) MEM_alloc(1000);
		platform_totalStr_8 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_8,"%d",bus_aggreed_8);
		sprintf(hcv_aggreedStr_8,"%d",hcv_aggreed_8);
		sprintf(scv_aggreedStr_8,"%d",scv_aggreed_8);
		sprintf(ilmcv_aggreedStr_8,"%d",ilmcv_aggreed_8);
		sprintf(aggrbusiness_aggreedStr_8,"%d",aggrbusiness_aggreed_8);
		sprintf(Defence_aggreedStr_8,"%d",Defence_aggreed_8);
		
		platform_total_8 = (bus_aggreed_8 + hcv_aggreed_8 + scv_aggreed_8 + ilmcv_aggreed_8 + aggrbusiness_aggreed_8 + Defence_aggreed_8);
		printf("\n platform_total_8 is %d",platform_total_8);fflush(stdout);
		
		if (platform_total_8 >0)
		{
		percent_bus_8 = ((float)bus_aggreed_8 / (float)platform_total_8)*100;
		percent_hcv_8 = ((float)hcv_aggreed_8 / (float)platform_total_8)*100;
		percent_ilmcv_8 = ((float)ilmcv_aggreed_8 / (float)platform_total_8)*100;
		percent_scv_8 = ((float)scv_aggreed_8 / (float)platform_total_8)*100;
		percent_aggr_8 = ((float)aggrbusiness_aggreed_8 / (float)platform_total_8)*100;
		percent_Defence_8 = ((float)Defence_aggreed_8 / (float)platform_total_8)*100;
		}
		
		if(platform_total_8 == 0)
		{
			percent_bus_8 = 0.00;
			percent_hcv_8 = 0.00;
			percent_ilmcv_8 = 0.00;
			percent_scv_8 = 0.00;
			percent_aggr_8 = 0.00;
			percent_Defence_8 = 0.00;
		}
		
		bus_aggreedStr_9 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_9 = (char *) MEM_alloc(1000);
		scv_aggreedStr_9 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_9 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_9 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_9 = (char *) MEM_alloc(1000);
		platform_totalStr_9 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_9,"%d",bus_aggreed_9);
		sprintf(hcv_aggreedStr_9,"%d",hcv_aggreed_9);
		sprintf(scv_aggreedStr_9,"%d",scv_aggreed_9);
		sprintf(ilmcv_aggreedStr_9,"%d",ilmcv_aggreed_9);
		sprintf(aggrbusiness_aggreedStr_9,"%d",aggrbusiness_aggreed_9);
		sprintf(Defence_aggreedStr_9,"%d",Defence_aggreed_9);
		
		platform_total_9 = (bus_aggreed_9 + hcv_aggreed_9 + scv_aggreed_9 + ilmcv_aggreed_9 + aggrbusiness_aggreed_9 + Defence_aggreed_9);
		printf("\n platform_total_9 is %d",platform_total_9);fflush(stdout);
		
		if (platform_total_9 >0)
		{
		percent_bus_9 = ((float)bus_aggreed_9 / (float)platform_total_9)*100;
		percent_hcv_9 = ((float)hcv_aggreed_9 / (float)platform_total_9)*100;
		percent_ilmcv_9 = ((float)ilmcv_aggreed_9 / (float)platform_total_9)*100;
		percent_scv_9 = ((float)scv_aggreed_9 / (float)platform_total_9)*100;
		percent_aggr_9 = ((float)aggrbusiness_aggreed_9 / (float)platform_total_9)*100;
		percent_Defence_9 = ((float)Defence_aggreed_9 / (float)platform_total_9)*100;
		}
		
		if(platform_total_9 == 0)
		{
			percent_bus_9 = 0.00;
			percent_hcv_9 = 0.00;
			percent_ilmcv_9 = 0.00;
			percent_scv_9 = 0.00;
			percent_aggr_9 = 0.00;
			percent_Defence_9 = 0.00;
		}
		
		bus_aggreedStr_10 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_10 = (char *) MEM_alloc(1000);
		scv_aggreedStr_10 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_10 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_10 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_10 = (char *) MEM_alloc(1000);
		platform_totalStr_10 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_10,"%d",bus_aggreed_10);
		sprintf(hcv_aggreedStr_10,"%d",hcv_aggreed_10);
		sprintf(scv_aggreedStr_10,"%d",scv_aggreed_10);
		sprintf(ilmcv_aggreedStr_10,"%d",ilmcv_aggreed_10);
		sprintf(aggrbusiness_aggreedStr_10,"%d",aggrbusiness_aggreed_10);
		sprintf(Defence_aggreedStr_10,"%d",Defence_aggreed_10);
		
		platform_total_10 = (bus_aggreed_10 + hcv_aggreed_10 + scv_aggreed_10 + ilmcv_aggreed_10 + aggrbusiness_aggreed_10 + Defence_aggreed_10);
		printf("\n platform_total_10 is %d",platform_total_10);fflush(stdout);
		
		if (platform_total_10 >0)
		{
		percent_bus_10 = ((float)bus_aggreed_10 / (float)platform_total_10)*100;
		percent_hcv_10 = ((float)hcv_aggreed_10 / (float)platform_total_10)*100;
		percent_ilmcv_10 = ((float)ilmcv_aggreed_10 / (float)platform_total_10)*100;
		percent_scv_10 = ((float)scv_aggreed_10 / (float)platform_total_10)*100;
		percent_aggr_10 = ((float)aggrbusiness_aggreed_10 / (float)platform_total_10)*100;
		percent_Defence_10 = ((float)Defence_aggreed_10 / (float)platform_total_10)*100;
		}
		if(platform_total_10 == 0)
		{
			percent_bus_10 = 0.00;
			percent_hcv_10 = 0.00;
			percent_ilmcv_10 = 0.00;
			percent_scv_10 = 0.00;
			percent_aggr_10 = 0.00;
			percent_Defence_10 = 0.00;
		}
		
		bus_aggreedStr_11 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_11 = (char *) MEM_alloc(1000);
		scv_aggreedStr_11 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_11 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_11 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_11 = (char *) MEM_alloc(1000);
		platform_totalStr_11 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_11,"%d",bus_aggreed_11);
		sprintf(hcv_aggreedStr_11,"%d",hcv_aggreed_11);
		sprintf(scv_aggreedStr_11,"%d",scv_aggreed_11);
		sprintf(ilmcv_aggreedStr_11,"%d",ilmcv_aggreed_11);
		sprintf(aggrbusiness_aggreedStr_11,"%d",aggrbusiness_aggreed_11);
		sprintf(Defence_aggreedStr_11,"%d",Defence_aggreed_11);
		
		platform_total_11 = (bus_aggreed_11 + hcv_aggreed_11 + scv_aggreed_11 + ilmcv_aggreed_11 + aggrbusiness_aggreed_11 + Defence_aggreed_11);
		printf("\n platform_total_11 is %d",platform_total_11);fflush(stdout);
		
		if (platform_total_11 >0)
		{
		percent_bus_11 = ((float)bus_aggreed_11 / (float)platform_total_11)*100;
		percent_hcv_11 = ((float)hcv_aggreed_11 / (float)platform_total_11)*100;
		percent_ilmcv_11 = ((float)ilmcv_aggreed_11 / (float)platform_total_11)*100;
		percent_scv_11 = ((float)scv_aggreed_11 / (float)platform_total_11)*100;
		percent_aggr_11 = ((float)aggrbusiness_aggreed_11 / (float)platform_total_11)*100;
		percent_Defence_11 = ((float)Defence_aggreed_11 / (float)platform_total_11)*100;
		}
		if(platform_total_11 == 0)
		{
			percent_bus_11 = 0.00;
			percent_hcv_11 = 0.00;
			percent_ilmcv_11 = 0.00;
			percent_scv_11 = 0.00;
			percent_aggr_11 = 0.00;
			percent_Defence_11 = 0.00;
		}

		bus_aggreedStr_12 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_12 = (char *) MEM_alloc(1000);
		scv_aggreedStr_12 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_12 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_12 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_12 = (char *) MEM_alloc(1000);
		platform_totalStr_12 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_12,"%d",bus_aggreed_12);
		sprintf(hcv_aggreedStr_12,"%d",hcv_aggreed_12);
		sprintf(scv_aggreedStr_12,"%d",scv_aggreed_12);
		sprintf(ilmcv_aggreedStr_12,"%d",ilmcv_aggreed_12);
		sprintf(aggrbusiness_aggreedStr_12,"%d",aggrbusiness_aggreed_12);
		sprintf(Defence_aggreedStr_12,"%d",Defence_aggreed_12);
		
		platform_total_12 = (bus_aggreed_12 + hcv_aggreed_12 + scv_aggreed_12 + ilmcv_aggreed_12 + aggrbusiness_aggreed_12 + Defence_aggreed_12);
		printf("\n platform_total_12 is %d",platform_total_12);fflush(stdout);
		
		if (platform_total_12 >0)
		{
		percent_bus_12 = ((float)bus_aggreed_12 / (float)platform_total_12)*100;
		percent_hcv_12 = ((float)hcv_aggreed_12 / (float)platform_total_12)*100;
		percent_ilmcv_12 = ((float)ilmcv_aggreed_12 / (float)platform_total_12)*100;
		percent_scv_12 = ((float)scv_aggreed_12 / (float)platform_total_12)*100;
		percent_aggr_12 = ((float)aggrbusiness_aggreed_12 / (float)platform_total_12)*100;
		percent_Defence_12 = ((float)Defence_aggreed_12 / (float)platform_total_12)*100;
		}
		if(platform_total_12 == 0)
		{
			percent_bus_12 = 0.00;
			percent_hcv_12 = 0.00;
			percent_ilmcv_12 = 0.00;
			percent_scv_12 = 0.00;
			percent_aggr_12 = 0.00;
			percent_Defence_12 = 0.00;
		}

		bus_aggreedStr_13 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_13 = (char *) MEM_alloc(1000);
		scv_aggreedStr_13 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_13 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_13 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_13 = (char *) MEM_alloc(1000);
		platform_totalStr_13 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_13,"%d",bus_aggreed_13);
		sprintf(hcv_aggreedStr_13,"%d",hcv_aggreed_13);
		sprintf(scv_aggreedStr_13,"%d",scv_aggreed_13);
		sprintf(ilmcv_aggreedStr_13,"%d",ilmcv_aggreed_13);
		sprintf(aggrbusiness_aggreedStr_13,"%d",aggrbusiness_aggreed_13);
		sprintf(Defence_aggreedStr_13,"%d",Defence_aggreed_13);
		
		platform_total_13 = (bus_aggreed_13 + hcv_aggreed_13 + scv_aggreed_13 + ilmcv_aggreed_13 + aggrbusiness_aggreed_13 + Defence_aggreed_13);
		printf("\n platform_total_13 is %d",platform_total_13);fflush(stdout);
		
		if (platform_total_13 >0)
		{
		percent_bus_13 = ((float)bus_aggreed_13 / (float)platform_total_13)*100;
		percent_hcv_13 = ((float)hcv_aggreed_13 / (float)platform_total_13)*100;
		percent_ilmcv_13 = ((float)ilmcv_aggreed_13 / (float)platform_total_13)*100;
		percent_scv_13 = ((float)scv_aggreed_13 / (float)platform_total_13)*100;
		percent_aggr_13 = ((float)aggrbusiness_aggreed_13 / (float)platform_total_13)*100;
		percent_Defence_13 = ((float)Defence_aggreed_13 / (float)platform_total_13)*100;
		}
		if(platform_total_13 == 0)
		{
			percent_bus_13 = 0.00;
			percent_hcv_13 = 0.00;
			percent_ilmcv_13 = 0.00;
			percent_scv_13 = 0.00;
			percent_aggr_13 = 0.00;
			percent_Defence_13 = 0.00;
		}

		bus_aggreedStr_14 = (char *) MEM_alloc(1000);
		hcv_aggreedStr_14 = (char *) MEM_alloc(1000);
		scv_aggreedStr_14 = (char *) MEM_alloc(1000);
		ilmcv_aggreedStr_14 = (char *) MEM_alloc(1000);
		aggrbusiness_aggreedStr_14 = (char *) MEM_alloc(1000);
		Defence_aggreedStr_14 = (char *) MEM_alloc(1000);
		platform_totalStr_14 = (char *) MEM_alloc(1000);
		
		sprintf(bus_aggreedStr_14,"%d",bus_aggreed_14);
		sprintf(hcv_aggreedStr_14,"%d",hcv_aggreed_14);
		sprintf(scv_aggreedStr_14,"%d",scv_aggreed_14);
		sprintf(ilmcv_aggreedStr_14,"%d",ilmcv_aggreed_14);
		sprintf(aggrbusiness_aggreedStr_14,"%d",aggrbusiness_aggreed_14);
		sprintf(Defence_aggreedStr_14,"%d",Defence_aggreed_14);
		

		platform_total_14 = (bus_aggreed_14 + hcv_aggreed_14 + scv_aggreed_14 + ilmcv_aggreed_14 + aggrbusiness_aggreed_14 + Defence_aggreed_14);
		printf("\n platform_total_14 is %d",platform_total_14);fflush(stdout);
		
		if (platform_total_14 >0)
		{
		percent_bus_14 = ((float)bus_aggreed_14 / (float)platform_total_14)*100;
		percent_hcv_14 = ((float)hcv_aggreed_14 / (float)platform_total_14)*100;
		percent_ilmcv_14 = ((float)ilmcv_aggreed_14 / (float)platform_total_14)*100;
		percent_scv_14 = ((float)scv_aggreed_14 / (float)platform_total_14)*100;
		percent_aggr_14 = ((float)aggrbusiness_aggreed_14 / (float)platform_total_14)*100;
		percent_Defence_14 = ((float)Defence_aggreed_14 / (float)platform_total_14)*100;
		}
		if(platform_total_14 == 0)
		{
			percent_bus_14 = 0.00;
			percent_hcv_14 = 0.00;
			percent_ilmcv_14 = 0.00;
			percent_scv_14 = 0.00;
			percent_aggr_14 = 0.00;
			percent_Defence_14 = 0.00;
		}
		
		Bus_Col_Total_aggreed = (bus_aggreed_1 + bus_aggreed_2 + bus_aggreed_3 +bus_aggreed_4 + bus_aggreed_5 + bus_aggreed_6 + bus_aggreed_7 + bus_aggreed_8 + bus_aggreed_9 + bus_aggreed_10 + bus_aggreed_11 + bus_aggreed_12 + bus_aggreed_13 + bus_aggreed_14);
		Hcv_Col_Total_aggreed = (hcv_aggreed_1 + hcv_aggreed_2 + hcv_aggreed_3 +hcv_aggreed_4 + hcv_aggreed_5 + hcv_aggreed_6 + hcv_aggreed_7 + hcv_aggreed_8 + hcv_aggreed_9 + hcv_aggreed_10 + hcv_aggreed_11 + hcv_aggreed_12 + hcv_aggreed_13 + hcv_aggreed_14);
		Scv_Col_Total_aggreed = (scv_aggreed_1 + scv_aggreed_2 + scv_aggreed_3 +scv_aggreed_4 + scv_aggreed_5 + scv_aggreed_6 + scv_aggreed_7 + scv_aggreed_8 + scv_aggreed_9 + scv_aggreed_10 + scv_aggreed_11 + scv_aggreed_12 + scv_aggreed_13 + scv_aggreed_14);
		Ilmcv_Col_Total_aggreed = (ilmcv_aggreed_1 + ilmcv_aggreed_2 + ilmcv_aggreed_3 +ilmcv_aggreed_4 + ilmcv_aggreed_5 + ilmcv_aggreed_6 + ilmcv_aggreed_7 + ilmcv_aggreed_8 + ilmcv_aggreed_9 + ilmcv_aggreed_10 + ilmcv_aggreed_11 + ilmcv_aggreed_12 + ilmcv_aggreed_13 + ilmcv_aggreed_14);
		Aggr_Business_Col_Total_aggreed = (aggrbusiness_aggreed_1 + aggrbusiness_aggreed_2 + aggrbusiness_aggreed_3 +aggrbusiness_aggreed_4 + aggrbusiness_aggreed_5 + aggrbusiness_aggreed_6 + aggrbusiness_aggreed_7 + aggrbusiness_aggreed_8 + aggrbusiness_aggreed_9 + aggrbusiness_aggreed_10 + aggrbusiness_aggreed_11 + aggrbusiness_aggreed_12 + aggrbusiness_aggreed_13 + aggrbusiness_aggreed_14);
		Defence_Col_Total_aggreed = (Defence_aggreed_1 + Defence_aggreed_2 + Defence_aggreed_3 +Defence_aggreed_4 + Defence_aggreed_5 + Defence_aggreed_6 + Defence_aggreed_7 + Defence_aggreed_8 + Defence_aggreed_9 + Defence_aggreed_10 + Defence_aggreed_11 + Defence_aggreed_12 + Defence_aggreed_13 + Defence_aggreed_14);
			
			
			ApproveComment_1Str = (char *) MEM_alloc(1000);
			ApproveComment_2Str = (char *) MEM_alloc(1000);
			ApproveComment_3Str = (char *) MEM_alloc(1000);
			ApproveComment_4Str = (char *) MEM_alloc(1000);
			ApproveComment_5Str = (char *) MEM_alloc(1000);
			ApproveComment_6Str = (char *) MEM_alloc(1000);
			ApproveComment_7Str = (char *) MEM_alloc(1000);
			ApproveComment_8Str = (char *) MEM_alloc(1000);
			ApproveComment_9Str = (char *) MEM_alloc(1000);
			ApproveComment_10Str = (char *) MEM_alloc(1000);
			ApproveComment_11Str = (char *) MEM_alloc(1000);
			ApproveComment_12Str = (char *) MEM_alloc(1000);
			ApproveComment_13Str = (char *) MEM_alloc(1000);
			ApproveComment_14Str = (char *) MEM_alloc(1000);
			ApproveComment_totalStr = (char *) MEM_alloc(1000);
			
			sprintf(ApproveComment_1Str,"%d",ApproveComment_1);
			sprintf(ApproveComment_2Str,"%d",ApproveComment_2);
			sprintf(ApproveComment_3Str,"%d",ApproveComment_3);
			sprintf(ApproveComment_4Str,"%d",ApproveComment_4);
			sprintf(ApproveComment_5Str,"%d",ApproveComment_5);
			sprintf(ApproveComment_6Str,"%d",ApproveComment_6);
			sprintf(ApproveComment_7Str,"%d",ApproveComment_7);
			sprintf(ApproveComment_8Str,"%d",ApproveComment_8);
			sprintf(ApproveComment_9Str,"%d",ApproveComment_9);
			sprintf(ApproveComment_10Str,"%d",ApproveComment_10);
			sprintf(ApproveComment_11Str,"%d",ApproveComment_11);
			sprintf(ApproveComment_12Str,"%d",ApproveComment_12);
			sprintf(ApproveComment_13Str,"%d",ApproveComment_13);
			sprintf(ApproveComment_14Str,"%d",ApproveComment_14);
			
			
			
			
			int ApproveComment_total  = (ApproveComment_1 + ApproveComment_2 + ApproveComment_3 + ApproveComment_4 + ApproveComment_5 + ApproveComment_6 + ApproveComment_7 + ApproveComment_8 + ApproveComment_9 + ApproveComment_10 + ApproveComment_11 + ApproveComment_12 + ApproveComment_13 + ApproveComment_14) ;
			
			sprintf(ApproveComment_totalStr,"%d",ApproveComment_total);
			
			int counts[] = {ApproveComment_1, ApproveComment_2, ApproveComment_3,ApproveComment_4, ApproveComment_5, ApproveComment_6,ApproveComment_7, ApproveComment_8, ApproveComment_9, ApproveComment_10, ApproveComment_11, ApproveComment_12, ApproveComment_13, ApproveComment_14};
			
			write2xml(output,"<Section_NPRAggreedReasonCount>\n");
			
			// code to each Row element with dynamic count value
		for (q = 0; q < 14; q++)
		{
			
			// Calculate percentage for the current count
			float agrred_percentage = 0;
			if (ApproveComment_total > 0) 
			{
			agrred_percentage = ((float)counts[q] / (float)ApproveComment_total) * 100;
			}
			
			fprintf(output, "<Row Srl=\"%d\" ReasonName=\"", q + 1);
			
			
			 // Set the ReasonName for each Row
        switch (q) {
            case 0: fprintf(output, "New parts - new project\""); break;
            case 1: fprintf(output, "TPL to submodule conversion - EV modularity\""); break;
            case 2: fprintf(output, "TPL to submodule conversion - IB modularity\""); break;
            case 3: fprintf(output, "Packaging constraint\""); break;
            case 4: fprintf(output, "Cost Reduction\""); break;
			case 5: fprintf(output, "New technology introduction\""); break;
            case 6: fprintf(output, "New submodule number from existing parts\""); break;
            case 7: fprintf(output, "Quality Improvement\""); break;
            case 8: fprintf(output, "Drawing parameter correction\""); break;
            case 9: fprintf(output, "Other\""); break;
            case 10: fprintf(output, "NA\""); break;
			case 11: fprintf(output, "Regulatory Requirement\""); break;
			case 12: fprintf(output, "VLO requirement\""); break;
			case 13: fprintf(output, "submodule conversionDefence modularity\""); break;
        }
		
		    // Count value for each Row
		//	fprintf(output, " Count=\"%d\"/>\n", counts[q]);
			fprintf(output, " Count=\"%d\" Percentage=\"%.2f\"/>\n", counts[q], agrred_percentage);
		}
		fprintf(output, "<Row ColName=\"ALL_TOTAL\" ReasonName=\"Total\" Count=\"%d\"/>\n", ApproveComment_total);
		//	fprintf(output, "<Row ColName=\"ALL_TOTAL\" ReasonName=\"Total\" Count=\"ApproveComment_totalStr\"/>\n");
			write2xml(output,"</Section_NPRAggreedReasonCount>\n");
			
		/*	
			write2xml(output,"<test2>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>New parts - new project</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_1Str);
			write2xml(output,"</nwcolumn1>\n");
			
			write2xml(output,"<nwcolumn2>");
			write2xml(output,ApproveComment_2Str);
			write2xml(output,"</nwcolumn2>\n");
			
			write2xml(output,"<nwcolumn3>");
			write2xml(output,ApproveComment_3Str);
			write2xml(output,"</nwcolumn3>\n");
			
			write2xml(output,"<nwcolumn4>");
			write2xml(output,ApproveComment_4Str);
			write2xml(output,"</nwcolumn4>\n");
			
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_1Str);
			write2xml(output,"</nwcolumn1>\n");
			
			write2xml(output,"<nwcolumn5>");
			write2xml(output,ApproveComment_5Str);
			write2xml(output,"</nwcolumn5>\n");
			
			write2xml(output,"<nwcolumn6>");
			write2xml(output,ApproveComment_6Str);
			write2xml(output,"</nwcolumn6>\n");
			
			write2xml(output,"<nwcolumn7>");
			write2xml(output,ApproveComment_7Str);
			write2xml(output,"</nwcolumn7>\n");
			
			write2xml(output,"<nwcolumn8>");
			write2xml(output,ApproveComment_8Str);
			write2xml(output,"</nwcolumn8>\n");
			
			write2xml(output,"<nwcolumn9>");
			write2xml(output,ApproveComment_9Str);
			write2xml(output,"</nwcolumn9>\n");
			
			write2xml(output,"<nwcolumn10>");
			write2xml(output,ApproveComment_10Str);
			write2xml(output,"</nwcolumn10>\n");
			
			write2xml(output,"<nwcolumn11>");
			write2xml(output,ApproveComment_11Str);
			write2xml(output,"</nwcolumn11>\n");
			
			write2xml(output,"</rownew>\n");
			*/
			
		
		/*
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>TPL to submodule conversion - EV modularity</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_2Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>TPL to submodule conversion - IB modularity</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_3Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>Packaging constraint</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_4Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>Cost Reduction</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_5Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>New technology introduction</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_6Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>New submodule number from existing parts</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_7Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>Quality Improvement</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_8Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>Drawing parameter correction</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_9Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>Other</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_10Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");
			
			write2xml(output,"<rownew>\n");
		//	write2xml(output,"<fixedColumn>NA</fixedColumn>\n");
			write2xml(output,"<nwcolumn1>");
			write2xml(output,ApproveComment_11Str);
			write2xml(output,"</nwcolumn1>\n");
			write2xml(output,"</rownew>\n");*/
			
			
		//	write2xml(output,"</test2>\n");
			
			
			
		}

		if(TotalRejectTask>0)
		{
			char chars_to_remove[] = "\n\r*,#";
			for(nprreject=0;nprreject<TotalRejectTask;nprreject++)
			{
				tag_t Reject_NPR = NULLTAG;
				tag_t refrelation_type = NULLTAG;
				tag_t *refnprchklist = NULLTAG;
				char *MCCproduct_line_rej	= NULL;
				char *Temp_MCCproduct_line_rej	= NULL;
				char *NewPart_ReqNumber	= NULL;
				char *Part_Type	= NULL;
				char *Mod_Address	= NULL;
				char *Aggregatevalue	= NULL;
				char *MCCStatusvalue	= NULL;
				char *tmlpartvalue	= NULL;
				char *tempMCCproduct_line	= NULL;
				char *NPRPlatform	= NULL;
				char *NPRPrjCode	= NULL;
				char *TempNPRPrjCode	= NULL;
				char *MappedProductLine	= NULL;
				char *TempNewPart_ReqNumber	= NULL;
				char *TempRejectComment	= NULL;
				char *NPRMCCRejectDate	= NULL;
				char *NPRMCCRejectBy	= NULL;


				char *TargetDate	= NULL;
				char *ObsoluteNumber	= NULL;
				char *MCCFinalComment	= NULL;
				char *NwRaisedBy	= NULL;
				char *IBDomestic	= NULL;
				char *SubModule	= NULL;
				char *NewVCNumber	= NULL;
				char *BaseVCNumber	= NULL;
				char *BaseSubModuleNumber	= NULL;
				char *PartDescription	= NULL;
				char *PartDescriptionTemp	= NULL;
				char *MCCFinalCommentTemp	= NULL;
				char *MccStartDate	= NULL;
				char *NewVcDesc	= NULL;
				char *BaseVcDesc	= NULL;

				int	refcnt	= 0;

				Reject_NPR = soResultReject[nprreject];
				AOM_UIF_ask_value(Reject_NPR,"t5_MCCapproveRejectComment",&TempRejectComment);
				AOM_UIF_ask_value(Reject_NPR,"t5_ProductLine",&Temp_MCCproduct_line_rej);
				

				AOM_UIF_ask_value(Reject_NPR,"item_id",&NewPart_ReqNumber);
				AOM_UIF_ask_value(Reject_NPR,"t5_PartType",&Part_Type);
				AOM_UIF_ask_value(Reject_NPR,"t5_ModuleAddress",&Mod_Address);
				AOM_UIF_ask_value(Reject_NPR,"t5_AggregateGrp",&Aggregatevalue);
				AOM_UIF_ask_value(Reject_NPR,"t5_MCCStatus",&MCCStatusvalue);
				AOM_UIF_ask_value(Reject_NPR,"t5_NwTmlPtNo",&tmlpartvalue);
				AOM_UIF_ask_value(Reject_NPR,"t5_Plateform",&NPRPlatform);
				AOM_UIF_ask_value(Reject_NPR,"t5_ProjectCode",&NPRPrjCode);
				AOM_UIF_ask_value(Reject_NPR,"t5_MCCRejectDate",&NPRMCCRejectDate);
				AOM_UIF_ask_value(Reject_NPR,"t5_MCCRejectBy",&NPRMCCRejectBy);

				AOM_UIF_ask_value(Reject_NPR,"t5_TargetDate",&TargetDate);
				AOM_UIF_ask_value(Reject_NPR,"t5_ObsoluteNumber",&ObsoluteNumber);
				AOM_UIF_ask_value(Reject_NPR,"t5_MCCFinalComment",&MCCFinalComment);
				AOM_UIF_ask_value(Reject_NPR,"t5_NwRaisedBy",&NwRaisedBy);
				AOM_UIF_ask_value(Reject_NPR,"t5_IBDomestic",&IBDomestic);
				AOM_UIF_ask_value(Reject_NPR,"t5_SubModule",&SubModule);
				AOM_UIF_ask_value(Reject_NPR,"t5_MCCStartDate",&MccStartDate);

				int lenght = 0;
				lenght = tc_strlen(SubModule);
				PartDescription=(char *)MEM_alloc(200);
				if(tc_strlen(Mod_Address)>0)
				{
					int n_Cntrltags_found = 0;
					tag_t	*Cntrltags_found	= NULLTAG;
					char *TempPartDescription = NULL;
					char *NewSubModAdd = NULL;
					NewSubModAdd = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(NewSubModAdd,"M");
					tc_strcat(NewSubModAdd,Mod_Address);
					Cntrlqry_values[2] = NewSubModAdd;
					QRY_execute(ControlObjQuery, 3, Cntrlqry_entries, Cntrlqry_values, &n_Cntrltags_found, &Cntrltags_found);
					printf("\n n_Cntrltags_found[%d]\n",n_Cntrltags_found);fflush(stdout);
					if(n_Cntrltags_found>0)
					{
						AOM_UIF_ask_value(Cntrltags_found[0],"t5_Userinfo3",&TempPartDescription);
						tc_strcpy(PartDescription,TempPartDescription);
					}
					else
					{
						tc_strcpy(PartDescription,"NA");
					}
					
				}
				//PartDescription= NewPartsubString(SubModule,3,lenght-3);
				
				else
				{
					tc_strcpy(PartDescription,"NA");
				}
				//replace_multiple_newlines(PartDescription, '-');
				//replace_multiple_newlines(tmlpartvalue, '-');
				//replace_multiple_newlines(ObsoluteNumber, '-');
				//replace_multiple_newlines(TargetDate, '-');

				remove_chars(PartDescription, chars_to_remove);
				remove_chars(tmlpartvalue, chars_to_remove);
				remove_chars(ObsoluteNumber, chars_to_remove);
				remove_chars(TargetDate, chars_to_remove);
				remove_chars(MCCFinalComment, chars_to_remove);
				printf("\n PartDescription[%s]\n",PartDescription);fflush(stdout);

				
				//replace_multiple_newlines(MCCFinalComment, '-');
				//printf("\n MCCFinalComment[%s]\n",MCCFinalComment);fflush(stdout);

				GRM_find_relation_type("IMAN_Reference", &refrelation_type);
				GRM_list_secondary_objects_only(Reject_NPR,refrelation_type,&refcnt,&refnprchklist);
				if(refcnt>0)
				{
					int checklistcnt = 0;
					tag_t	checkListObj = NULLTAG;
					char * CheckListType = NULL;
					for(checklistcnt=0;checklistcnt<refcnt;checklistcnt++)
					{
						checkListObj = refnprchklist[checklistcnt];
						AOM_UIF_ask_value(checkListObj,"object_type",&CheckListType);
						if(tc_strcmp(CheckListType,"New Part Request CheckList")==0)
						{
							break;
						}
					}
					if(checkListObj!=NULLTAG)
					{
						AOM_UIF_ask_value(checkListObj,"t5_VCNumber",&NewVCNumber);
						AOM_UIF_ask_value(checkListObj,"t5_BaseVCNum",&BaseVCNumber);
						AOM_UIF_ask_value(checkListObj,"t5_BaseSubModule",&BaseSubModuleNumber);
						AOM_UIF_ask_value(checkListObj,"t5_VCDesc",&NewVcDesc);
						AOM_UIF_ask_value(checkListObj,"t5_BaseVCDesc",&BaseVcDesc);

						remove_chars(NewVCNumber, chars_to_remove);
						remove_chars(BaseVCNumber, chars_to_remove);
						remove_chars(BaseSubModuleNumber, chars_to_remove);
						remove_chars(NewVcDesc, chars_to_remove);
						remove_chars(BaseVcDesc, chars_to_remove);
					}
					else
					{
						NewVCNumber = (char *) MEM_alloc(10);
						BaseVCNumber = (char *) MEM_alloc(10);
						BaseSubModuleNumber = (char *) MEM_alloc(10);
						NewVcDesc = (char *) MEM_alloc(10);
						BaseVcDesc = (char *) MEM_alloc(10);

						tc_strcpy(NewVCNumber,"NA");
						tc_strcpy(BaseVCNumber,"NA");
						tc_strcpy(BaseSubModuleNumber,"NA");
						tc_strcpy(NewVcDesc,"NA");
						tc_strcpy(BaseVcDesc,"NA");
					}

					//replace_multiple_newlines(NewVCNumber, '-');
					//replace_multiple_newlines(BaseVCNumber, '-');
					//replace_multiple_newlines(BaseSubModuleNumber, '-');

					

					printf("\n Reject:NewPart_ReqNumber[%s]\n",NewPart_ReqNumber);fflush(stdout);
					printf("\n Reject:NewVCNumber[%s]\n",NewVCNumber);fflush(stdout);
				}
				else
				{
					NewVCNumber = (char *) MEM_alloc(10);
					BaseVCNumber = (char *) MEM_alloc(10);
					BaseSubModuleNumber = (char *) MEM_alloc(10);

					tc_strcpy(NewVCNumber,"NA");
					tc_strcpy(BaseVCNumber,"NA");
					tc_strcpy(BaseSubModuleNumber,"NA");
				}

				if(tc_strcmp(Temp_MCCproduct_line_rej,"Other")==0 || tc_strlen(Temp_MCCproduct_line_rej)==0)
				{
					// SYSCD PartPlatform
					// Info01 -->NPRPlatform
					// Info02 --> NPRPrjCode
					// Info03 --> Product Line

					TempNPRPrjCode = NULL;
					TempNPRPrjCode = (char *) MEM_alloc(50);
					tc_strcpy(TempNPRPrjCode,"*");
					tc_strcat(TempNPRPrjCode,NPRPrjCode);
					tc_strcat(TempNPRPrjCode,"*");
					ProductLineqry_values[0]	= "PartPlatform";
					ProductLineqry_values[1]	= NPRPlatform;
					ProductLineqry_values[2]	= TempNPRPrjCode;
					QRY_execute(RejectProductLinequery, 3, ProductLineqry_entries, ProductLineqry_values, &ProductLinectrl_n_found, &ProductLineCntrlObjs);
					printf("\n ProductLinectrl_n_found[%d]\n",ProductLinectrl_n_found);fflush(stdout);
					if(ProductLinectrl_n_found>0)
					{
						ProductLineCntrlquery = ProductLineCntrlObjs[0];
						AOM_UIF_ask_value(ProductLineCntrlquery,"t5_Userinfo3",&MappedProductLine);
					}
					printf("\n Reject MappedProductLine[%s]\n",MappedProductLine);fflush(stdout);
					if(tc_strlen(MappedProductLine)>0)
					{
						tag_t		 updateinfo1			=  NULLTAG;
						AOM_refresh( Reject_NPR, POM_modify_lock);
						POM_attr_id_of_attr("t5_ProductLine", "T5_NwPCre", &updateinfo1);
						POM_set_attr_string(1, &Reject_NPR, updateinfo1, MappedProductLine);
						POM_save_instances(1, &Reject_NPR, false);
						AOM_refresh(Reject_NPR, POM_no_lock);
					}
					else
					{
						tag_t		 updateinfo1			=  NULLTAG;
						AOM_refresh( Reject_NPR, POM_modify_lock);
						POM_attr_id_of_attr("t5_ProductLine", "T5_NwPCre", &updateinfo1);
						POM_set_attr_string(1, &Reject_NPR, updateinfo1, "Other");
						POM_save_instances(1, &Reject_NPR, false);
						AOM_refresh(Reject_NPR, POM_no_lock);
					}					
				}
				
				if(tc_strlen(TempRejectComment)==0)
				{
					printf("\n TempRejectComment[%s]\n",TempRejectComment);fflush(stdout);
					char *EpmSignOffComment	= NULL;
					TempNewPart_ReqNumber = (char *) MEM_alloc(100);
					tc_strcpy(TempNewPart_ReqNumber,"*");
					tc_strcat(TempNewPart_ReqNumber,NewPart_ReqNumber);
					tc_strcat(TempNewPart_ReqNumber,"*");
					printf("\n TempNewPart_ReqNumber[%s]\n",TempNewPart_ReqNumber);fflush(stdout);
					RejectSignOff_values[0]	= TempNewPart_ReqNumber;
					RejectSignOff_values[1]	= "*MCC*";
					RejectSignOff_values[2]	= "Reject";
					QRY_execute(RejectSignOffquery, 3, RejectSignOff_entries, RejectSignOff_values, &RejectSignOff_n_found, &RejectSignOffObjs);
					printf("\n RejectSignOff_n_found[%d]\n",RejectSignOff_n_found);fflush(stdout);
					if(RejectSignOff_n_found>0)
					{
						int count = 0;
						//RejectSignOffObj = NULLTAG;
						char *EpmSignOffType	= NULL;
						
						char *EpmSignOffDecision	= NULL;
						for(count=0;count<RejectSignOff_n_found;count++)
						{
							EpmSignOffComment	= NULL;
							RejectSignOffObj = RejectSignOffObjs[count];
							AOM_UIF_ask_value(RejectSignOffObj,"object_type",&EpmSignOffType);
							AOM_UIF_ask_value(RejectSignOffObj,"fnd0SignoffDecision",&EpmSignOffDecision);
							if(tc_strcmp(EpmSignOffType,"EPMPerformSignoffTask")==0 && tc_strcmp(EpmSignOffDecision,"Rejected")==0)
							{
								AOM_UIF_ask_value(RejectSignOffObj,"fnd0SignoffComments",&EpmSignOffComment);
								break;
							}
						}						
					}
					printf("\n EpmSignOffComment[%s]\n",EpmSignOffComment);fflush(stdout);
					if(tc_strlen(EpmSignOffComment)>0)
					{
						printf("\n 1 EpmSignOffComment[%s]\n",EpmSignOffComment);fflush(stdout);
						tag_t		 updateinfo1			=  NULLTAG;
						AOM_refresh( Reject_NPR, POM_modify_lock);
						POM_attr_id_of_attr("t5_MCCapproveRejectComment", "T5_NwPCre", &updateinfo1);
						POM_set_attr_string(1, &Reject_NPR, updateinfo1, EpmSignOffComment);
						POM_save_instances(1, &Reject_NPR, false);
						AOM_refresh(Reject_NPR, POM_no_lock);
					}
					else
					{
						printf("\n 2EpmSignOffComment[%s]\n",EpmSignOffComment);fflush(stdout);
						tag_t		 updateinfo1			=  NULLTAG;
						AOM_refresh( Reject_NPR, POM_modify_lock);
						POM_attr_id_of_attr("t5_MCCapproveRejectComment", "T5_NwPCre", &updateinfo1);
						POM_set_attr_string(1, &Reject_NPR, updateinfo1, "NA");
						POM_save_instances(1, &Reject_NPR, false);
						AOM_refresh(Reject_NPR, POM_no_lock);
					}
				}

				AOM_UIF_ask_value(Reject_NPR,"t5_ProductLine",&MCCproduct_line_rej);
				AOM_UIF_ask_value(Reject_NPR,"t5_MCCapproveRejectComment",&RejectComment);
				
				/* @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@*/
				    int weekdayCount;
					if((tc_strstr(MccStartDate,"Jan")!=NULL) || (tc_strstr(MccStartDate,"Feb")!=NULL) || (tc_strstr(MccStartDate,"Mar")!=NULL) || (tc_strstr(MccStartDate,"Apr")!=NULL) || (tc_strstr(MccStartDate,"May")!=NULL) || (tc_strstr(MccStartDate,"Jun")!=NULL) || (tc_strstr(MccStartDate,"Jul")!=NULL) || (tc_strstr(MccStartDate,"Aug")!=NULL) || (tc_strstr(MccStartDate,"Sep")!=NULL) || (tc_strstr(MccStartDate,"Oct")!=NULL) || (tc_strstr(MccStartDate,"Nov")!=NULL) || (tc_strstr(MccStartDate,"Dec")!=NULL))
					{
						if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCRejectDate) > 0) && (tc_strcmp(NPRMCCRejectDate,"NA") !=0))
						{
							char* ReNewMccStartDate = NULL;
							ReNewMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
							tc_strcpy(ReNewMccStartDate,MccStartDate);
							printf("\n ReNewMccStartDate Before: [%s]\n", ReNewMccStartDate);fflush(stdout);
							replaceSpacesWithSlash(ReNewMccStartDate);
							if(ReNewMccStartDate != NULL)
							{
								STRNG_replace_str(ReNewMccStartDate,"//","/",&ReNewMccStartDate);
							}
							printf("\n ReNewMccStartDate After: [%s]\n", ReNewMccStartDate);fflush(stdout);
							char* Freceived = NULL;
							char* Sreceived = NULL;
							Freceived = tc_strtok(ReNewMccStartDate,"/");
							Sreceived = tc_strtok(NULL,"/");
							printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
							printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
							char* ReInpDay = NULL;
							char* ReInpMon = NULL;
							char* ReInpYear = NULL;
							char* ReInpYearChar = NULL;
							ReInpDay=tc_strtok(Freceived,"-");
							ReInpMon=tc_strtok(NULL,"-");
							ReInpYear=tc_strtok(NULL,"-");
							printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
							printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
							char* RespMonth = NULL;
							RespMonth = MonthAbbreviation(ReInpMon);
							printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
							printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
							ReInpYearChar=subString(ReInpYear,2,2);
							printf("\n ReInpYearChar: [%s]",ReInpYearChar);fflush(stdout);
							char* ReInpYearCharFinal = NULL;
							ReInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(ReInpYearCharFinal,"1");
							tc_strcat(ReInpYearCharFinal,ReInpYearChar);
							printf("\n ReInpYearCharFinal: [%s] \n", ReInpYearCharFinal);fflush(stdout);
							char* ReInpHr = NULL;
							char* ReInpMnt = NULL;
							//char* ReInpSec = NULL;
							char ReInpSec[] = "00";
							ReInpHr=tc_strtok(Sreceived,":");
							ReInpMnt=tc_strtok(NULL,":");
							//ReInpSec=tc_strtok(NULL,":");
							printf("\n ReInpHr: [%s]\n", ReInpHr);fflush(stdout);
							printf("\n ReInpMnt: [%s]\n", ReInpMnt);fflush(stdout);
							printf("\n ReInpSec: [%s]\n", ReInpSec);fflush(stdout);
							
							
							char* ReNewNPRMCCRejectDate = NULL;
							ReNewNPRMCCRejectDate = (char *) MEM_alloc( 50 * sizeof(char) );
							tc_strcpy(ReNewNPRMCCRejectDate,NPRMCCRejectDate);
							printf("\n NPRMCCRejectDate Before: [%s]\n", ReNewNPRMCCRejectDate);fflush(stdout);
							replaceSpacesWithSlash(ReNewNPRMCCRejectDate);
							if(ReNewNPRMCCRejectDate != NULL)
							{
								STRNG_replace_str(ReNewNPRMCCRejectDate,"//","/",&ReNewNPRMCCRejectDate);
							}
							printf("\n ReNewNPRMCCRejectDate After: [%s]\n", ReNewNPRMCCRejectDate);fflush(stdout);
							char* Fcompleted = NULL;
							char* Scompleted = NULL;
							Fcompleted = tc_strtok(ReNewNPRMCCRejectDate,"/");
							Scompleted = tc_strtok(NULL,"/");
							printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
							printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
							char* ComInpDay = NULL;
							char* ComInpMon = NULL;
							char* ComInpYear = NULL;
							char* ComInpYearChar = NULL;
							ComInpDay=tc_strtok(Fcompleted,"-");
							ComInpMon=tc_strtok(NULL,"-");
							ComInpYear=tc_strtok(NULL,"-");
							printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
							printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
							char* ComRespMonth = NULL;
							ComRespMonth = MonthAbbreviation(ComInpMon);
							printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
							printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
							ComInpYearChar=subString(ComInpYear,2,2);
							printf("\n ComInpYearChar: [%s]",ComInpYearChar);fflush(stdout);
							char* ComInpYearCharFinal = NULL;
							ComInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(ComInpYearCharFinal,"1");
							tc_strcat(ComInpYearCharFinal,ComInpYearChar);
							printf("\n ComInpYearCharFinal: [%s] \n", ComInpYearCharFinal);fflush(stdout);
							char* ComInpHr = NULL;
							char* ComInpMnt = NULL;
							//char* ComInpSec = NULL;
							char ComInpSec[] = "00";
							ComInpHr=tc_strtok(Scompleted,":");
							ComInpMnt=tc_strtok(NULL,":");
							//ComInpSec=tc_strtok(NULL,":");
							printf("\n ComInpHr: [%s]\n", ComInpHr);fflush(stdout);
							printf("\n ComInpMnt: [%s]\n", ComInpMnt);fflush(stdout);
							printf("\n ComInpSec: [%s]\n", ComInpSec);fflush(stdout);
							
							int ReInpdayFinal = atoi(ReInpDay);
							int ReInpMonFinal = atoi(RespMonth);
							int ReInpYearFinal = atoi(ReInpYearCharFinal);
							int ReInpHrFinal = atoi(ReInpHr);
							int ReInpMntFinal = atoi(ReInpMnt);
							int ReInpSecFinal = atoi(ReInpSec);
							
							int ComInpDayFinal = atoi(ComInpDay);
							int ComInpMonFinal = atoi(ComRespMonth);
							int ComInpYearFinal = atoi(ComInpYearCharFinal);
							int ComInpHrFinal = atoi(ComInpHr);
							int ComInpMntFinal = atoi(ComInpMnt);
							int ComInpSecFinal = atoi(ComInpSec);
							
							struct tm tm_start = {ReInpSecFinal, ReInpMntFinal, ReInpHrFinal, ReInpdayFinal, ReInpMonFinal, ReInpYearFinal}; // Sec, Min, Hour, Month_Day, Month_No, Year
							struct tm tm_end = {ComInpSecFinal, ComInpMntFinal, ComInpHrFinal, ComInpDayFinal, ComInpMonFinal, ComInpYearFinal};  // Sec, Min, Hour, Month_Day, Month_No, Year
							
							time_t start = mktime(&tm_start);
							time_t end = mktime(&tm_end);
							
							printf("Current start: %s", ctime(&start));
							printf("Current end: %s", ctime(&end));

							weekdayCount = weekdaysBetween(start, end);
							printf("Number of weekdays between the dates: [%d]\n", weekdayCount);
						}
						else
						{
							weekdayCount = 0;
						}						
					}
					else
					{
						if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCRejectDate) > 0) && (tc_strcmp(NPRMCCRejectDate,"NA") !=0))
						{
							char* ReNewMccStartDate = NULL;
							ReNewMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
							tc_strcpy(ReNewMccStartDate,MccStartDate);
							printf("\n ReNewMccStartDate Before: [%s]\n", ReNewMccStartDate);fflush(stdout);
							replaceSpacesWithSlash(ReNewMccStartDate);
							if(ReNewMccStartDate != NULL)
							{
								STRNG_replace_str(ReNewMccStartDate,"//","/",&ReNewMccStartDate);
							}
							printf("\n ReNewMccStartDate After: [%s]\n", ReNewMccStartDate);fflush(stdout);
							char* Freceived = NULL;
							char* Sreceived = NULL;
							Freceived = tc_strtok(ReNewMccStartDate,"/");
							Sreceived = tc_strtok(NULL,"/");
							printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
							printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
							char* ReInpDay = NULL;
							char* ReInpMon = NULL;
							char* ReInpYear = NULL;
							char* ReInpYearChar = NULL;
							ReInpDay=tc_strtok(Freceived,"-");
							ReInpMon=tc_strtok(NULL,"-");
							ReInpYear=tc_strtok(NULL,"-");
							printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
							printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
							printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
							ReInpYearChar=subString(ReInpYear,2,2);
							printf("\n ReInpYearChar: [%s]",ReInpYearChar);fflush(stdout);
							char* ReInpYearCharFinal = NULL;
							ReInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(ReInpYearCharFinal,"1");
							tc_strcat(ReInpYearCharFinal,ReInpYearChar);
							printf("\n ReInpYearCharFinal: [%s] \n", ReInpYearCharFinal);fflush(stdout);
							char* ReInpHr = NULL;
							char* ReInpMnt = NULL;
							//char* ReInpSec = NULL;
							char ReInpSec[] = "00";
							ReInpHr=tc_strtok(Sreceived,":");
							ReInpMnt=tc_strtok(NULL,":");
							//ReInpSec=tc_strtok(NULL,":");
							printf("\n ReInpHr: [%s]\n", ReInpHr);fflush(stdout);
							printf("\n ReInpMnt: [%s]\n", ReInpMnt);fflush(stdout);
							printf("\n ReInpSec: [%s]\n", ReInpSec);fflush(stdout);
							
							
							char* ReNewNPRMCCRejectDate = NULL;
							ReNewNPRMCCRejectDate = (char *) MEM_alloc( 50 * sizeof(char) );
							tc_strcpy(ReNewNPRMCCRejectDate,NPRMCCRejectDate);
							printf("\n NPRMCCRejectDate Before: [%s]\n", ReNewNPRMCCRejectDate);fflush(stdout);
							replaceSpacesWithSlash(ReNewNPRMCCRejectDate);
							if(ReNewNPRMCCRejectDate != NULL)
							{
								STRNG_replace_str(ReNewNPRMCCRejectDate,"//","/",&ReNewNPRMCCRejectDate);
							}
							printf("\n ReNewNPRMCCRejectDate After: [%s]\n", ReNewNPRMCCRejectDate);fflush(stdout);
							char* Fcompleted = NULL;
							char* Scompleted = NULL;
							Fcompleted = tc_strtok(ReNewNPRMCCRejectDate,"/");
							Scompleted = tc_strtok(NULL,"/");
							printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
							printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
							char* ComInpDay = NULL;
							char* ComInpMon = NULL;
							char* ComInpYear = NULL;
							char* ComInpYearChar = NULL;
							ComInpDay=tc_strtok(Fcompleted,"-");
							ComInpMon=tc_strtok(NULL,"-");
							ComInpYear=tc_strtok(NULL,"-");
							printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
							printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
							printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
							ComInpYearChar=subString(ComInpYear,2,2);
							printf("\n ComInpYearChar: [%s]",ComInpYearChar);fflush(stdout);
							char* ComInpYearCharFinal = NULL;
							ComInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(ComInpYearCharFinal,"1");
							tc_strcat(ComInpYearCharFinal,ComInpYearChar);
							printf("\n ComInpYearCharFinal: [%s] \n", ComInpYearCharFinal);fflush(stdout);
							char* ComInpHr = NULL;
							char* ComInpMnt = NULL;
							//char* ComInpSec = NULL;
							char ComInpSec[] = "00";
							ComInpHr=tc_strtok(Scompleted,":");
							ComInpMnt=tc_strtok(NULL,":");
							//ComInpSec=tc_strtok(NULL,":");
							printf("\n ComInpHr: [%s]\n", ComInpHr);fflush(stdout);
							printf("\n ComInpMnt: [%s]\n", ComInpMnt);fflush(stdout);
							printf("\n ComInpSec: [%s]\n", ComInpSec);fflush(stdout);
							
							int ReInpdayFinal = atoi(ReInpDay);
							int ReInpMonFinal = atoi(ReInpMon);
							int ReInpYearFinal = atoi(ReInpYearCharFinal);
							int ReInpHrFinal = atoi(ReInpHr);
							int ReInpMntFinal = atoi(ReInpMnt);
							int ReInpSecFinal = atoi(ReInpSec);
							
							int ComInpDayFinal = atoi(ComInpDay);
							int ComInpMonFinal = atoi(ComInpMon);
							int ComInpYearFinal = atoi(ComInpYearCharFinal);
							int ComInpHrFinal = atoi(ComInpHr);
							int ComInpMntFinal = atoi(ComInpMnt);
							int ComInpSecFinal = atoi(ComInpSec);
							
							struct tm tm_start = {ReInpSecFinal, ReInpMntFinal, ReInpHrFinal, ReInpdayFinal, ReInpMonFinal, ReInpYearFinal}; // Sec, Min, Hour, Month_Day, Month_No, Year
							struct tm tm_end = {ComInpSecFinal, ComInpMntFinal, ComInpHrFinal, ComInpDayFinal, ComInpMonFinal, ComInpYearFinal};  // Sec, Min, Hour, Month_Day, Month_No, Year
							
							time_t start = mktime(&tm_start);
							time_t end = mktime(&tm_end);
							
							printf("Current start: %s", ctime(&start));
							printf("Current end: %s", ctime(&end));

							weekdayCount = weekdaysBetween(start, end);
							printf("Number of weekdays between the dates: [%d]\n", weekdayCount);
						}
						else
						{
							weekdayCount = 0;
						}				
					}
				/* @@@@@@@@@@@@@@@  Weekdays calculation logic end @@@@@@@@@@@@@@@@ */

				if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
				{
					tempMCCproduct_line = (char *) MEM_alloc(50);
					tc_strcpy(tempMCCproduct_line,"AGGREGATE");
				}

				if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")==NULL)
				{
					//////fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,MCCproduct_line_rej,MCCStatusvalue,RejectComment,MccStartDate,NPRMCCRejectDate,weekdayCount,NPRMCCRejectBy,tmlpartvalue,NewVCNumber,NewVcDesc,BaseVCNumber,BaseVcDesc,PartDescription,IBDomestic,BaseSubModuleNumber,NwRaisedBy,ObsoluteNumber,TargetDate,MCCFinalComment);fflush(output);
					//fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,,,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,MCCproduct_line_rej,MCCStatusvalue,RejectComment,NPRMCCRejectDate,NPRMCCRejectBy,tmlpartvalue,NewVCNumber,BaseVCNumber,PartDescriptionTemp,IBDomestic,BaseSubModuleNumber,NwRaisedBy,MCCFinalCommentTemp,ObsoluteNumber,TargetDate);fflush(output);
					fprintf(output1,"%s,%s,%s,%s,%s,%d,%s,%s,\n",NewPart_ReqNumber,MCCproduct_line_rej,NPRMCCRejectBy,MccStartDate,NPRMCCRejectDate,weekdayCount,"Reject",tmlpartvalue);fflush(output1);
				}
				if(tc_strcmp(tempMCCproduct_line,"AGGREGATE")==0)
				{
					//////fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,tempMCCproduct_line,MCCStatusvalue,RejectComment,MccStartDate,NPRMCCRejectDate,weekdayCount,NPRMCCRejectBy,tmlpartvalue,NewVCNumber,NewVcDesc,BaseVCNumber,BaseVcDesc,PartDescription,IBDomestic,BaseSubModuleNumber,NwRaisedBy,ObsoluteNumber,TargetDate,MCCFinalComment);fflush(output);
					fprintf(output1,"%s,%s,%s,%s,%s,%d,%s,%s,\n",NewPart_ReqNumber,MCCproduct_line_rej,NPRMCCRejectBy,MccStartDate,NPRMCCRejectDate,weekdayCount,"Reject",tmlpartvalue);fflush(output1);
				}

				//fprintf(output1,"%s,%s,%s,%s,%s,%s,%s,%s,\n",NewPart_ReqNumber,Mod_Address,Part_Type,Aggregatevalue,MCCproduct_line_rej,MCCStatusvalue,RejectComment,tmlpartvalue);fflush(output);

				
				printf("\n under reject NPR MCCproduct_line_rej is %s",MCCproduct_line_rej);
				
				if(tc_strlen(RejectComment)>0)
				{
					if(tc_strcmp(RejectComment,"Alternate suggested from library/Modified Existing Submodule")==0)
					{
						RejectComment_1++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_1++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_1++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_1++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_1++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_1++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_1++;
						}
					}
					if(tc_strcmp(RejectComment,"Not as per project scope")==0)
					{
						RejectComment_2++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_2++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_2++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_2++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_2++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_2++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_2++;
						}
					}
					if(tc_strcmp(RejectComment,"Duplicate submodule")==0)
					{
						RejectComment_3++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_3++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_3++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_3++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_3++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_3++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_3++;
						}
					}
					if(tc_strcmp(RejectComment,"Prototype development")==0)
					{
						RejectComment_4++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_4++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_4++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_4++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_4++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_4++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_4++;
						}
					}
					if(tc_strcmp(RejectComment,"Wrong submodule address")==0)
					{
						RejectComment_5++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_5++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_5++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_5++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_5++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_5++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_5++;
						}
					}
					if(tc_strcmp(RejectComment,"No inputs from COC")==0)
					{
						RejectComment_6++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_6++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_6++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_6++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_6++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_6++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_6++;
						}
					}
					if(tc_strcmp(RejectComment,"VC not in PPG Migration Plan")==0)
					{
						RejectComment_7++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_7++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_7++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_7++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_7++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_7++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_7++;
						}
					}
					if(tc_strcmp(RejectComment,"Project on hold")==0)
					{
						RejectComment_8++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_8++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_8++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_8++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_8++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_8++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_8++;
						}
					}
					if(tc_strcmp(RejectComment,"Common part with different software")==0)
					{
						RejectComment_9++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_9++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_9++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_9++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_9++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_9++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_9++;
						}
					}
					if(tc_strcmp(RejectComment,"Other")==0)
					{
						RejectComment_10++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_10++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_10++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_10++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_10++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_10++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_10++;
						}
					}
					if(tc_strcmp(RejectComment,"NA")==0)
					{
						RejectComment_11++;
						
						if(tc_strcmp(MCCproduct_line_rej,"BUS")==0)
						{
							bus_reject_11++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"HCV")==0)
						{
							hcv_reject_11++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"ILMCV")==0)
						{
							ilmcv_reject_11++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"SCV")==0)
						{
							scv_reject_11++;
						}
						if(tc_strstr(MCCproduct_line_rej,"AGGREGATE")!=NULL)
						{
							aggrbusiness_reject_11++;
						}
						if(tc_strcmp(MCCproduct_line_rej,"Defence")==0 || tc_strcmp(MCCproduct_line_rej,"DEFENCE")==0)
						{
							Defence_reject_11++;
						}
					}
					
				}
			}
			
			
			bus_rejectStr_1 = (char *) MEM_alloc(1000);
			hcv_rejectStr_1 = (char *) MEM_alloc(1000);
			scv_rejectStr_1 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_1 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_1 = (char *) MEM_alloc(1000);
			Defence_rejectStr_1 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_1,"%d",bus_reject_1);
			sprintf(hcv_rejectStr_1,"%d",hcv_reject_1);
			sprintf(scv_rejectStr_1,"%d",scv_reject_1);
			sprintf(ilmcv_rejectStr_1,"%d",ilmcv_reject_1);
			sprintf(aggrbusiness_rejectStr_1,"%d",aggrbusiness_reject_1);
			sprintf(Defence_rejectStr_1,"%d",Defence_reject_1);
			
			platform_total_1_rej = (bus_reject_1 + hcv_reject_1 + scv_reject_1 + ilmcv_reject_1 + aggrbusiness_reject_1 + Defence_reject_1);
			printf("\n platform_total_1_rej is %d",platform_total_1_rej);
			
			if (platform_total_1_rej >0)
			{
			percent_bus_1_rej = ((float)bus_reject_1 / (float)platform_total_1_rej)*100;
			percent_hcv_1_rej = ((float)hcv_reject_1 / (float)platform_total_1_rej)*100;
			percent_ilmcv_1_rej = ((float)ilmcv_reject_1 / (float)platform_total_1_rej)*100;
			percent_scv_1_rej = ((float)scv_reject_1 / (float)platform_total_1_rej)*100;
			percent_aggr_1_rej = ((float)aggrbusiness_reject_1 / (float)platform_total_1_rej)*100;
			percent_Defence_1_rej = ((float)Defence_reject_1 / (float)platform_total_1_rej)*100;
			}
			
			if(platform_total_1_rej == 0)
			{
			percent_bus_1_rej = 0.00;
			percent_hcv_1_rej = 0.00;
			percent_ilmcv_1_rej = 0.00;
			percent_scv_1_rej = 0.00;
			percent_aggr_1_rej = 0.00;
			percent_Defence_1_rej = 0.00;
			}
			
			bus_rejectStr_2 = (char *) MEM_alloc(1000);
			hcv_rejectStr_2 = (char *) MEM_alloc(1000);
			scv_rejectStr_2 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_2 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_2 = (char *) MEM_alloc(1000);
			Defence_rejectStr_2 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_2,"%d",bus_reject_2);
			sprintf(hcv_rejectStr_2,"%d",hcv_reject_2);
			sprintf(scv_rejectStr_2,"%d",scv_reject_2);
			sprintf(ilmcv_rejectStr_2,"%d",ilmcv_reject_2);
			sprintf(aggrbusiness_rejectStr_2,"%d",aggrbusiness_reject_2);
			sprintf(Defence_rejectStr_2,"%d",Defence_reject_2);
			
			platform_total_2_rej = (bus_reject_2 + hcv_reject_2 + scv_reject_2 + ilmcv_reject_2 + aggrbusiness_reject_2 + Defence_reject_2);
			printf("\n platform_total_2_rej is %d",platform_total_2_rej);
			
			if (platform_total_2_rej >0)
			{
			percent_bus_2_rej = ((float)bus_reject_2 / (float)platform_total_2_rej)*100;
			percent_hcv_2_rej = ((float)hcv_reject_2 / (float)platform_total_2_rej)*100;
			percent_ilmcv_2_rej = ((float)ilmcv_reject_2 / (float)platform_total_2_rej)*100;
			percent_scv_2_rej = ((float)scv_reject_2 / (float)platform_total_2_rej)*100;
			percent_aggr_2_rej = ((float)aggrbusiness_reject_2 / (float)platform_total_2_rej)*100;
			percent_Defence_2_rej = ((float)Defence_reject_2 / (float)platform_total_2_rej)*100;
			}
			
			if(platform_total_2_rej == 0)
			{
			percent_bus_2_rej = 0.00;
			percent_hcv_2_rej = 0.00;
			percent_ilmcv_2_rej = 0.00;
			percent_scv_2_rej = 0.00;
			percent_aggr_2_rej = 0.00;
			percent_Defence_2_rej = 0.00;
			}
			
			bus_rejectStr_3 = (char *) MEM_alloc(1000);
			hcv_rejectStr_3 = (char *) MEM_alloc(1000);
			scv_rejectStr_3 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_3 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_3 = (char *) MEM_alloc(1000);
			Defence_rejectStr_3 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_3,"%d",bus_reject_3);
			sprintf(hcv_rejectStr_3,"%d",hcv_reject_3);
			sprintf(scv_rejectStr_3,"%d",scv_reject_3);
			sprintf(ilmcv_rejectStr_3,"%d",ilmcv_reject_3);
			sprintf(aggrbusiness_rejectStr_3,"%d",aggrbusiness_reject_3);
			sprintf(Defence_rejectStr_3,"%d",Defence_reject_3);
			
			platform_total_3_rej = (bus_reject_3 + hcv_reject_3 + scv_reject_3 + ilmcv_reject_3 + aggrbusiness_reject_3 + Defence_reject_3);
			printf("\n platform_total_3_rej is %d",platform_total_3_rej);
			
			if (platform_total_3_rej >0)
			{
			percent_bus_3_rej = ((float)bus_reject_3 / (float)platform_total_3_rej)*100;
			percent_hcv_3_rej = ((float)hcv_reject_3 / (float)platform_total_3_rej)*100;
			percent_ilmcv_3_rej = ((float)ilmcv_reject_3 / (float)platform_total_3_rej)*100;
			percent_scv_3_rej = ((float)scv_reject_3 / (float)platform_total_3_rej)*100;
			percent_aggr_3_rej = ((float)aggrbusiness_reject_3 / (float)platform_total_3_rej)*100;
			percent_Defence_3_rej = ((float)Defence_reject_3 / (float)platform_total_3_rej)*100;
			}
			
			if(platform_total_3_rej == 0)
			{
			percent_bus_3_rej = 0.00;
			percent_hcv_3_rej = 0.00;
			percent_ilmcv_3_rej = 0.00;
			percent_scv_3_rej = 0.00;
			percent_aggr_3_rej = 0.00;
			percent_Defence_3_rej = 0.00;
			}
			
			bus_rejectStr_4 = (char *) MEM_alloc(1000);
			hcv_rejectStr_4 = (char *) MEM_alloc(1000);
			scv_rejectStr_4 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_4 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_4 = (char *) MEM_alloc(1000);
			Defence_rejectStr_4 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_4,"%d",bus_reject_4);
			sprintf(hcv_rejectStr_4,"%d",hcv_reject_4);
			sprintf(scv_rejectStr_4,"%d",scv_reject_4);
			sprintf(ilmcv_rejectStr_4,"%d",ilmcv_reject_4);
			sprintf(aggrbusiness_rejectStr_4,"%d",aggrbusiness_reject_4);
			sprintf(Defence_rejectStr_4,"%d",Defence_reject_4);
			
			platform_total_4_rej = (bus_reject_4 + hcv_reject_4 + scv_reject_4 + ilmcv_reject_4 + aggrbusiness_reject_4 + Defence_reject_4);
			printf("\n platform_total_4_rej is %d",platform_total_4_rej);
			
			if (platform_total_4_rej >0)
			{
			percent_bus_4_rej = ((float)bus_reject_4 / (float)platform_total_4_rej)*100;
			percent_hcv_4_rej = ((float)hcv_reject_4 / (float)platform_total_4_rej)*100;
			percent_ilmcv_4_rej = ((float)ilmcv_reject_4 / (float)platform_total_4_rej)*100;
			percent_scv_4_rej = ((float)scv_reject_4 / (float)platform_total_4_rej)*100;
			percent_aggr_4_rej = ((float)aggrbusiness_reject_4 / (float)platform_total_4_rej)*100;
			percent_Defence_4_rej = ((float)Defence_reject_4 / (float)platform_total_4_rej)*100;
			}
			
			if(platform_total_4_rej == 0)
			{
			percent_bus_4_rej = 0.00;
			percent_hcv_4_rej = 0.00;
			percent_ilmcv_4_rej = 0.00;
			percent_scv_4_rej = 0.00;
			percent_aggr_4_rej = 0.00;
			percent_Defence_4_rej = 0.00;
			}
			
			bus_rejectStr_5 = (char *) MEM_alloc(1000);
			hcv_rejectStr_5 = (char *) MEM_alloc(1000);
			scv_rejectStr_5 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_5 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_5 = (char *) MEM_alloc(1000);
			Defence_rejectStr_5 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_5,"%d",bus_reject_5);
			sprintf(hcv_rejectStr_5,"%d",hcv_reject_5);
			sprintf(scv_rejectStr_5,"%d",scv_reject_5);
			sprintf(ilmcv_rejectStr_5,"%d",ilmcv_reject_5);
			sprintf(aggrbusiness_rejectStr_5,"%d",aggrbusiness_reject_5);
			sprintf(Defence_rejectStr_5,"%d",Defence_reject_5);
			
			platform_total_5_rej = (bus_reject_5 + hcv_reject_5 + scv_reject_5 + ilmcv_reject_5 + aggrbusiness_reject_5 + Defence_reject_5);
			printf("\n platform_total_5_rej is %d",platform_total_5_rej);
			
			if (platform_total_5_rej >0)
			{
			percent_bus_5_rej = ((float)bus_reject_5 / (float)platform_total_5_rej)*100;
			percent_hcv_5_rej = ((float)hcv_reject_5 / (float)platform_total_5_rej)*100;
			percent_ilmcv_5_rej = ((float)ilmcv_reject_5 / (float)platform_total_5_rej)*100;
			percent_scv_5_rej = ((float)scv_reject_5 / (float)platform_total_5_rej)*100;
			percent_aggr_5_rej = ((float)aggrbusiness_reject_5 / (float)platform_total_5_rej)*100;
			percent_Defence_5_rej = ((float)Defence_reject_5 / (float)platform_total_5_rej)*100;
			}
			
			if(platform_total_5_rej == 0)
			{
			percent_bus_5_rej = 0.00;
			percent_hcv_5_rej = 0.00;
			percent_ilmcv_5_rej = 0.00;
			percent_scv_5_rej = 0.00;
			percent_aggr_5_rej = 0.00;
			percent_Defence_5_rej = 0.00;
			}
			
			bus_rejectStr_6 = (char *) MEM_alloc(1000);
			hcv_rejectStr_6 = (char *) MEM_alloc(1000);
			scv_rejectStr_6 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_6 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_6 = (char *) MEM_alloc(1000);
			Defence_rejectStr_6 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_6,"%d",bus_reject_6);
			sprintf(hcv_rejectStr_6,"%d",hcv_reject_6);
			sprintf(scv_rejectStr_6,"%d",scv_reject_6);
			sprintf(ilmcv_rejectStr_6,"%d",ilmcv_reject_6);
			sprintf(aggrbusiness_rejectStr_6,"%d",aggrbusiness_reject_6);
			sprintf(Defence_rejectStr_6,"%d",Defence_reject_6);
			
			platform_total_6_rej = (bus_reject_6 + hcv_reject_6 + scv_reject_6 + ilmcv_reject_6 + aggrbusiness_reject_6 + Defence_reject_6);
			printf("\n platform_total_6_rej is %d",platform_total_6_rej);
			
			if (platform_total_6_rej >0)
			{
			percent_bus_6_rej = ((float)bus_reject_6 / (float)platform_total_6_rej)*100;
			percent_hcv_6_rej = ((float)hcv_reject_6 / (float)platform_total_6_rej)*100;
			percent_ilmcv_6_rej = ((float)ilmcv_reject_6 / (float)platform_total_6_rej)*100;
			percent_scv_6_rej = ((float)scv_reject_6 / (float)platform_total_6_rej)*100;
			percent_aggr_6_rej = ((float)aggrbusiness_reject_6 / (float)platform_total_6_rej)*100;
			percent_Defence_6_rej = ((float)Defence_reject_6 / (float)platform_total_6_rej)*100;
			}
			
			if(platform_total_6_rej == 0)
			{
			percent_bus_6_rej = 0.00;
			percent_hcv_6_rej = 0.00;
			percent_ilmcv_6_rej = 0.00;
			percent_scv_6_rej = 0.00;
			percent_aggr_6_rej = 0.00;
			percent_Defence_6_rej = 0.00;
			}
			
			bus_rejectStr_7 = (char *) MEM_alloc(1000);
			hcv_rejectStr_7 = (char *) MEM_alloc(1000);
			scv_rejectStr_7 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_7 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_7 = (char *) MEM_alloc(1000);
			Defence_rejectStr_7 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_7,"%d",bus_reject_7);
			sprintf(hcv_rejectStr_7,"%d",hcv_reject_7);
			sprintf(scv_rejectStr_7,"%d",scv_reject_7);
			sprintf(ilmcv_rejectStr_7,"%d",ilmcv_reject_7);
			sprintf(aggrbusiness_rejectStr_7,"%d",aggrbusiness_reject_7);
			sprintf(Defence_rejectStr_7,"%d",Defence_reject_7);
			
			platform_total_7_rej = (bus_reject_7 + hcv_reject_7 + scv_reject_7 + ilmcv_reject_7 + aggrbusiness_reject_7 + Defence_reject_7);
			printf("\n platform_total_7_rej is %d",platform_total_7_rej);
			
			if (platform_total_7_rej >0)
			{
			percent_bus_7_rej = ((float)bus_reject_7 / (float)platform_total_7_rej)*100;
			percent_hcv_7_rej = ((float)hcv_reject_7 / (float)platform_total_7_rej)*100;
			percent_ilmcv_7_rej = ((float)ilmcv_reject_7 / (float)platform_total_7_rej)*100;
			percent_scv_7_rej = ((float)scv_reject_7 / (float)platform_total_7_rej)*100;
			percent_aggr_7_rej = ((float)aggrbusiness_reject_7 / (float)platform_total_7_rej)*100;
			percent_Defence_7_rej = ((float)Defence_reject_7 / (float)platform_total_7_rej)*100;
			}
			
			if(platform_total_7_rej == 0)
			{
			percent_bus_7_rej = 0.00;
			percent_hcv_7_rej = 0.00;
			percent_ilmcv_7_rej = 0.00;
			percent_scv_7_rej = 0.00;
			percent_aggr_7_rej = 0.00;
			percent_Defence_7_rej = 0.00;
			}
			
			bus_rejectStr_8 = (char *) MEM_alloc(1000);
			hcv_rejectStr_8 = (char *) MEM_alloc(1000);
			scv_rejectStr_8 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_8 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_8 = (char *) MEM_alloc(1000);
			Defence_rejectStr_8 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_8,"%d",bus_reject_8);
			sprintf(hcv_rejectStr_8,"%d",hcv_reject_8);
			sprintf(scv_rejectStr_8,"%d",scv_reject_8);
			sprintf(ilmcv_rejectStr_8,"%d",ilmcv_reject_8);
			sprintf(aggrbusiness_rejectStr_8,"%d",aggrbusiness_reject_8);
			sprintf(Defence_rejectStr_8,"%d",Defence_reject_8);
			
			platform_total_8_rej = (bus_reject_8 + hcv_reject_8 + scv_reject_8 + ilmcv_reject_8 + aggrbusiness_reject_8 + Defence_reject_8);
			printf("\n platform_total_8_rej is %d",platform_total_8_rej);
			
			if (platform_total_8_rej >0)
			{
			percent_bus_8_rej = ((float)bus_reject_8 / (float)platform_total_8_rej)*100;
			percent_hcv_8_rej = ((float)hcv_reject_8 / (float)platform_total_8_rej)*100;
			percent_ilmcv_8_rej = ((float)ilmcv_reject_8 / (float)platform_total_8_rej)*100;
			percent_scv_8_rej = ((float)scv_reject_8 / (float)platform_total_8_rej)*100;
			percent_aggr_8_rej = ((float)aggrbusiness_reject_8 / (float)platform_total_8_rej)*100;
			percent_Defence_8_rej = ((float)Defence_reject_8 / (float)platform_total_8_rej)*100;
			}
			
			if(platform_total_8_rej == 0)
			{
			percent_bus_8_rej = 0.00;
			percent_hcv_8_rej = 0.00;
			percent_ilmcv_8_rej = 0.00;
			percent_scv_8_rej = 0.00;
			percent_aggr_8_rej = 0.00;
			percent_Defence_8_rej = 0.00;
			}
			
			bus_rejectStr_9 = (char *) MEM_alloc(1000);
			hcv_rejectStr_9 = (char *) MEM_alloc(1000);
			scv_rejectStr_9 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_9 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_9 = (char *) MEM_alloc(1000);
			Defence_rejectStr_9 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_9,"%d",bus_reject_9);
			sprintf(hcv_rejectStr_9,"%d",hcv_reject_9);
			sprintf(scv_rejectStr_9,"%d",scv_reject_9);
			sprintf(ilmcv_rejectStr_9,"%d",ilmcv_reject_9);
			sprintf(aggrbusiness_rejectStr_9,"%d",aggrbusiness_reject_9);
			sprintf(Defence_rejectStr_9,"%d",Defence_reject_9);
			
			platform_total_9_rej = (bus_reject_9 + hcv_reject_9 + scv_reject_9 + ilmcv_reject_9 + aggrbusiness_reject_9 + Defence_reject_9);
			printf("\n platform_total_9_rej is %d",platform_total_9_rej);
			
			if (platform_total_9_rej >0)
			{
			percent_bus_9_rej = ((float)bus_reject_9 / (float)platform_total_9_rej)*100;
			percent_hcv_9_rej = ((float)hcv_reject_9 / (float)platform_total_9_rej)*100;
			percent_ilmcv_9_rej = ((float)ilmcv_reject_9 / (float)platform_total_9_rej)*100;
			percent_scv_9_rej = ((float)scv_reject_9 / (float)platform_total_9_rej)*100;
			percent_aggr_9_rej = ((float)aggrbusiness_reject_9 / (float)platform_total_9_rej)*100;
			percent_Defence_9_rej = ((float)Defence_reject_9 / (float)platform_total_9_rej)*100;
			}
			
			if(platform_total_9_rej == 0)
			{
			percent_bus_9_rej = 0.00;
			percent_hcv_9_rej = 0.00;
			percent_ilmcv_9_rej = 0.00;
			percent_scv_9_rej = 0.00;
			percent_aggr_9_rej = 0.00;
			percent_Defence_9_rej = 0.00;
			}
			
			bus_rejectStr_10 = (char *) MEM_alloc(1000);
			hcv_rejectStr_10 = (char *) MEM_alloc(1000);
			scv_rejectStr_10 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_10 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_10 = (char *) MEM_alloc(1000);
			Defence_rejectStr_10 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_10,"%d",bus_reject_10);
			sprintf(hcv_rejectStr_10,"%d",hcv_reject_10);
			sprintf(scv_rejectStr_10,"%d",scv_reject_10);
			sprintf(ilmcv_rejectStr_10,"%d",ilmcv_reject_10);
			sprintf(aggrbusiness_rejectStr_10,"%d",aggrbusiness_reject_10);
			sprintf(Defence_rejectStr_10,"%d",Defence_reject_10);
			
			platform_total_10_rej = (bus_reject_10 + hcv_reject_10 + scv_reject_10 + ilmcv_reject_10 + aggrbusiness_reject_10 + Defence_reject_10);
			printf("\n platform_total_10_rej is %d",platform_total_10_rej);
			
			if(platform_total_10_rej >0)
			{
			percent_bus_10_rej = ((float)bus_reject_10 / (float)platform_total_10_rej)*100;
			percent_hcv_10_rej = ((float)hcv_reject_10 / (float)platform_total_10_rej)*100;
			percent_ilmcv_10_rej = ((float)ilmcv_reject_10 / (float)platform_total_10_rej)*100;
			percent_scv_10_rej = ((float)scv_reject_10 / (float)platform_total_10_rej)*100;
			percent_aggr_10_rej = ((float)aggrbusiness_reject_10 / (float)platform_total_10_rej)*100;
			percent_Defence_10_rej = ((float)Defence_reject_10 / (float)platform_total_10_rej)*100;
			}
			
			if(platform_total_10_rej == 0)
			{
			percent_bus_10_rej = 0.00;
			percent_hcv_10_rej = 0.00;
			percent_ilmcv_10_rej = 0.00;
			percent_scv_10_rej = 0.00;
			percent_aggr_10_rej = 0.00;
			percent_Defence_10_rej = 0.00;
			}
			
			bus_rejectStr_11 = (char *) MEM_alloc(1000);
			hcv_rejectStr_11 = (char *) MEM_alloc(1000);
			scv_rejectStr_11 = (char *) MEM_alloc(1000);
			ilmcv_rejectStr_11 = (char *) MEM_alloc(1000);
			aggrbusiness_rejectStr_11 = (char *) MEM_alloc(1000);
			Defence_rejectStr_11 = (char *) MEM_alloc(1000);
			
			
			sprintf(bus_rejectStr_11,"%d",bus_reject_11);
			sprintf(hcv_rejectStr_11,"%d",hcv_reject_11);
			sprintf(scv_rejectStr_11,"%d",scv_reject_11);
			sprintf(ilmcv_rejectStr_11,"%d",ilmcv_reject_11);
			sprintf(aggrbusiness_rejectStr_11,"%d",aggrbusiness_reject_11);
			sprintf(Defence_rejectStr_11,"%d",Defence_reject_11);
			
			platform_total_11_rej = (bus_reject_11 + hcv_reject_11 + scv_reject_11 + ilmcv_reject_11 + aggrbusiness_reject_11 + Defence_reject_11);
			printf("\n platform_total_11_rej is %d",platform_total_11_rej);
			
			if(platform_total_11_rej >0)
			{
			percent_bus_11_rej = ((float)bus_reject_11 / (float)platform_total_11_rej)*100;
			percent_hcv_11_rej = ((float)hcv_reject_11 / (float)platform_total_11_rej)*100;
			percent_ilmcv_11_rej = ((float)ilmcv_reject_11 / (float)platform_total_11_rej)*100;
			percent_scv_11_rej = ((float)scv_reject_11 / (float)platform_total_11_rej)*100;
			percent_aggr_11_rej = ((float)aggrbusiness_reject_11 / (float)platform_total_11_rej)*100;
			percent_Defence_11_rej = ((float)Defence_reject_11 / (float)platform_total_11_rej)*100;
			}
			
			if(platform_total_11_rej == 0)
			{
			percent_bus_11_rej = 0.00;
			percent_hcv_11_rej = 0.00;
			percent_ilmcv_11_rej = 0.00;
			percent_scv_11_rej = 0.00;
			percent_aggr_11_rej = 0.00;
			percent_Defence_11_rej = 0.00;
			}
			
			Bus_Col_Total_reject = (bus_reject_1 + bus_reject_2 + bus_reject_3 +bus_reject_4 + bus_reject_5 + bus_reject_6 + bus_reject_7 + bus_reject_8 + bus_reject_9 + bus_reject_10 +bus_reject_11);
			Hcv_Col_Total_reject = (hcv_reject_1 + hcv_reject_2 + hcv_reject_3 +hcv_reject_4 + hcv_reject_5 + hcv_reject_6 + hcv_reject_7 + hcv_reject_8 + hcv_reject_9 + hcv_reject_10 +hcv_reject_11);
			Scv_Col_Total_reject = (scv_reject_1 + scv_reject_2 + scv_reject_3 +scv_reject_4 + scv_reject_5 + scv_reject_6 + scv_reject_7 + scv_reject_8 + scv_reject_9 + scv_reject_10 +scv_reject_11);
			Ilmcv_Col_Total_reject = (ilmcv_reject_1 + ilmcv_reject_2 + ilmcv_reject_3 +ilmcv_reject_4 + ilmcv_reject_5 + ilmcv_reject_6 + ilmcv_reject_7 + ilmcv_reject_8 + ilmcv_reject_9 + ilmcv_reject_10 +ilmcv_reject_11);
			Aggr_Business_Col_Total_reject = (aggrbusiness_reject_1 + aggrbusiness_reject_2 + aggrbusiness_reject_3 + aggrbusiness_reject_4 + aggrbusiness_reject_5 + aggrbusiness_reject_6 + aggrbusiness_reject_7 + aggrbusiness_reject_8 + aggrbusiness_reject_9 + aggrbusiness_reject_10 +aggrbusiness_reject_11);
			Defence_Col_Total_reject = (Defence_reject_1 + Defence_reject_2 + Defence_reject_3 + Defence_reject_4 + Defence_reject_5 + Defence_reject_6 + Defence_reject_7 + Defence_reject_8 + Defence_reject_9 + Defence_reject_10 +Defence_reject_11);
			
			RejectComment_1Str = (char *) MEM_alloc(1000);
			RejectComment_2Str = (char *) MEM_alloc(1000);
			RejectComment_3Str = (char *) MEM_alloc(1000);
			RejectComment_4Str = (char *) MEM_alloc(1000);
			RejectComment_5Str = (char *) MEM_alloc(1000);
			RejectComment_6Str = (char *) MEM_alloc(1000);
			RejectComment_7Str = (char *) MEM_alloc(1000);
			RejectComment_8Str = (char *) MEM_alloc(1000);
			RejectComment_9Str = (char *) MEM_alloc(1000);
			RejectComment_10Str = (char *) MEM_alloc(1000);
			RejectComment_11Str = (char *) MEM_alloc(1000);
			
			sprintf(RejectComment_1Str,"%d",RejectComment_1);
			sprintf(RejectComment_2Str,"%d",RejectComment_2);
			sprintf(RejectComment_3Str,"%d",RejectComment_3);
			sprintf(RejectComment_4Str,"%d",RejectComment_4);
			sprintf(RejectComment_5Str,"%d",RejectComment_5);
			sprintf(RejectComment_6Str,"%d",RejectComment_6);
			sprintf(RejectComment_7Str,"%d",RejectComment_7);
			sprintf(RejectComment_8Str,"%d",RejectComment_8);
			sprintf(RejectComment_9Str,"%d",RejectComment_9);
			sprintf(RejectComment_10Str,"%d",RejectComment_10);
			sprintf(RejectComment_11Str,"%d",RejectComment_11);
			
			int RejectComment_total  = (RejectComment_1 + RejectComment_2 + RejectComment_3 + RejectComment_4 + RejectComment_5 + RejectComment_6 + RejectComment_7 + RejectComment_8 + RejectComment_9 + RejectComment_10 + RejectComment_11) ;
			
			int countt[] = {RejectComment_1, RejectComment_2, RejectComment_3,RejectComment_4, RejectComment_5, RejectComment_6,RejectComment_7, RejectComment_8, RejectComment_9,RejectComment_10, RejectComment_11};
			
			write2xml(output,"<Section_NPRDroppedReasonCount>\n");
			
		for (s = 0; s < 11; s++)
		{
			// Calculate percentage for the current count
			float reject_percentage = 0;
			if (RejectComment_total > 0) 
			{
			reject_percentage = ((float)countt[s] / (float)RejectComment_total) * 100;
			}
			
			fprintf(output, "<Row Srl=\"%d\" ReasonName=\"", s + 1);
			
			 // Set the ReasonName for each Row
        switch (s) {
            case 0: fprintf(output, "Alternate suggested from library/Modified Existing Submodule\""); break;
            case 1: fprintf(output, "Not as per project scope\""); break;
            case 2: fprintf(output, "Duplicate submodule\""); break;
            case 3: fprintf(output, "Prototype development\""); break;
            case 4: fprintf(output, "Wrong submodule address\""); break;
            case 5: fprintf(output, "No inputs from COC\""); break;
            case 6: fprintf(output, "VC not in PPG Migration Plan\""); break;
            case 7: fprintf(output, "Project on hold\""); break;
            case 8: fprintf(output, "Common part with different software\""); break;
            case 9: fprintf(output, "Other\""); break;
            case 10: fprintf(output, "NA\""); break;
        }
		
		    // Count value for each Row
		//	fprintf(output, " Count=\"%d\"/>\n", countt[s]);
			fprintf(output, " Count=\"%d\" Percentage=\"%.2f\"/>\n", countt[s], reject_percentage);
		}
			
			fprintf(output, "<Row ColName=\"ALL_TOTAL\" ReasonName=\"Total\" Count=\"%d\"/>\n", RejectComment_total);
			write2xml(output,"</Section_NPRDroppedReasonCount>\n");
			
			/*
			write2xml(output,"<test3>\n");
			
			write2xml(output,"<rownewr>\n");
			write2xml(output,"<nwrcolumn1>");
			write2xml(output,RejectComment_1Str);
			write2xml(output,"</nwrcolumn1>\n");
			
			write2xml(output,"<nwrcolumn2>");
			write2xml(output,RejectComment_2Str);
			write2xml(output,"</nwrcolumn2>\n");
			
			write2xml(output,"<nwrcolumn3>");
			write2xml(output,RejectComment_3Str);
			write2xml(output,"</nwrcolumn3>\n");
			
			write2xml(output,"<nwrcolumn4>");
			write2xml(output,RejectComment_4Str);
			write2xml(output,"</nwrcolumn4>\n");
			
			write2xml(output,"<nwrcolumn5>");
			write2xml(output,RejectComment_5Str);
			write2xml(output,"</nwrcolumn5>\n");
			
			write2xml(output,"<nwrcolumn6>");
			write2xml(output,RejectComment_6Str);
			write2xml(output,"</nwrcolumn6>\n");
			
			write2xml(output,"<nwrcolumn7>");
			write2xml(output,RejectComment_7Str);
			write2xml(output,"</nwrcolumn7>\n");
			
			write2xml(output,"<nwrcolumn8>");
			write2xml(output,RejectComment_8Str);
			write2xml(output,"</nwrcolumn8>\n");
			
			write2xml(output,"<nwrcolumn9>");
			write2xml(output,RejectComment_9Str);
			write2xml(output,"</nwrcolumn9>\n");
			
			write2xml(output,"<nwrcolumn10>");
			write2xml(output,RejectComment_10Str);
			write2xml(output,"</nwrcolumn10>\n");
			
			write2xml(output,"<nwrcolumn11>");
			write2xml(output,RejectComment_11Str);
			write2xml(output,"</nwrcolumn11>\n");
			
			write2xml(output,"</rownewr>\n");
			write2xml(output,"</test3>\n");
			*/
		
		
			
		}
		write2xml(output,"<Section_NPRAggreedReasonCountProductLineWise>\n");
		
		fprintf(output, "<Row Srl=\"1\" ReasonName=\"New parts - new project\" RowTotal=\"%d\">\n", platform_total_1);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_1);
		write2xml(output,"</BUS>\n");
		
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_1);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_1);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_1);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_1);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_1);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_1);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_1);
		
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_1);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_1);

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_1);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_1);
		
	/*	write2xml(output,"<TOTAL>");
		write2xml(output,platform_totalStr);
		write2xml(output,"</TOTAL>\n");*/
		
		write2xml(output,"</Row>\n");
		
		fprintf(output, "<Row Srl=\"2\" ReasonName=\"TPL to submodule conversion - EV modularity\" RowTotal=\"%d\">\n", platform_total_2);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_2);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_2);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_2);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_2);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_2);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_2);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_2);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_2);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_2);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_2);

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_2);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_2);
		
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");
		
		write2xml(output,"</Row>\n");
		
		fprintf(output, "<Row Srl=\"3\" ReasonName=\"TPL to submodule conversion - IB modularity\" RowTotal=\"%d\">\n", platform_total_3);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_3);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_3);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_3);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_3);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_3);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_3);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_3);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_3);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_3);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_3);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_3);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_3);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"4\" ReasonName=\"Packaging constraint\" RowTotal=\"%d\">\n", platform_total_4);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_4);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_4);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_4);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_4);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_4);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_4);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_4);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_4);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_4);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_4);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_4);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_4);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"5\" ReasonName=\"Cost Reduction\" RowTotal=\"%d\">\n", platform_total_5);
		
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_5);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_5);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_5);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_5);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_5);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_5);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_5);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_5);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_5);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_5);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_5);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_5);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"6\" ReasonName=\"New technology introduction\" RowTotal=\"%d\">\n", platform_total_6);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_6);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_6);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_6);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_6);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_6);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_6);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_6);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_6);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_6);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_6);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_6);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_6);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"7\" ReasonName=\"New submodule number from existing parts\" RowTotal=\"%d\">\n", platform_total_7);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_7);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_7);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_7);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_7);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_7);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_7);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_7);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_7);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_7);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_7);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_7);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_7);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"8\" ReasonName=\"Quality Improvement\" RowTotal=\"%d\">\n", platform_total_8);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_8);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_8);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_8);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_8);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_8);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_8);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_8);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_8);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_8);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_8);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_8);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_8);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"9\" ReasonName=\"Drawing parameter correction\" RowTotal=\"%d\">\n", platform_total_9);

		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_9);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_9);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_9);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_9);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_9);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_9);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_9);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_9);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_9);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_9);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_9);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_9);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"10\" ReasonName=\"Other\" RowTotal=\"%d\">\n", platform_total_10);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_10);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_10);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_10);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_10);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_10);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_10);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_10);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_10);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_10);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_10);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_10);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_10);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"11\" ReasonName=\"NA\" RowTotal=\"%d\">\n", platform_total_11);
	//	write2xml(output,"<Row Srl=\"11\" ReasonName=\"NA\">\n");
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_11);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_11);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_11);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_11);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_11);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_11);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_11);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_11);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_11);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_11);
		// write2xml(output,"<TOTAL>\n");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_11);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_11);

		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"11\" ReasonName=\"Regulatory Requirement\" RowTotal=\"%d\">\n", platform_total_12);
	//	write2xml(output,"<Row Srl=\"11\" ReasonName=\"NA\">\n");
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_12);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_12);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_12);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_12);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_12);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_12);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_12);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_12);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_12);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_12);
		// write2xml(output,"<TOTAL>\n");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_12);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_12);

		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"11\" ReasonName=\"VLO requirement\" RowTotal=\"%d\">\n", platform_total_13);
	//	write2xml(output,"<Row Srl=\"11\" ReasonName=\"NA\">\n");
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_13);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_13);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_13);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_13);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_13);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_13);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_13);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_13);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_13);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_13);
		// write2xml(output,"<TOTAL>\n");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_13);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_13);

		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"11\" ReasonName=\"submodule conversionDefence modularity\" RowTotal=\"%d\">\n", platform_total_14);
	//	write2xml(output,"<Row Srl=\"11\" ReasonName=\"NA\">\n");
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_aggreedStr_14);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_14);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_aggreedStr_14);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_14);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_aggreedStr_14);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_14);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_aggreedStr_14);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_14);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_aggreedStr_14);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_14);
		// write2xml(output,"<TOTAL>\n");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_aggreedStr_14);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_14);
		
		write2xml(output,"</Row>\n");
		
		fprintf(output, "<Row_Total ColName=\"BUS_TOTAL\" ColTotal=\"%d\"/>\n", Bus_Col_Total_aggreed);
		fprintf(output, "<Row_Total ColName=\"HCV_TOTAL\" ColTotal=\"%d\"/>\n", Hcv_Col_Total_aggreed);
		fprintf(output, "<Row_Total ColName=\"ILMCV_TOTAL\" ColTotal=\"%d\"/>\n", Ilmcv_Col_Total_aggreed);
		fprintf(output, "<Row_Total ColName=\"SCV_TOTAL\" ColTotal=\"%d\"/>\n", Scv_Col_Total_aggreed);
		fprintf(output, "<Row_Total ColName=\"AGGR_BUSINESS_TOTAL\" ColTotal=\"%d\"/>\n", Aggr_Business_Col_Total_aggreed);
		fprintf(output, "<Row_Total ColName=\"DEFENCE_TOTAL\" ColTotal=\"%d\"/>\n", Defence_Col_Total_aggreed);
		
		write2xml(output,"</Section_NPRAggreedReasonCountProductLineWise>\n");
		
		// for dropped productline-------------------
		
		write2xml(output,"<Section_NPRDroppedReasonCountProductLineWise>\n");
		
		fprintf(output, "<Row Srl=\"1\" ReasonName=\"Alternate suggested from library/Modified Existing Submodule\" RowTotal=\"%d\">\n", platform_total_1_rej);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_1);
		write2xml(output,"</BUS>\n");
		
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_1_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_1);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_1_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_1);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_1_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_1);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_1_rej);
		
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_1);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_1_rej);

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_1);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_1_rej);
		
	/*	write2xml(output,"<TOTAL>");
		write2xml(output,platform_totalStr);
		write2xml(output,"</TOTAL>\n");*/
		
		write2xml(output,"</Row>\n");
		
		fprintf(output, "<Row Srl=\"2\" ReasonName=\"Not as per project scope\" RowTotal=\"%d\">\n", platform_total_2_rej);

		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_2);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_2_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_2);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_2_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_2);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_2_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_2);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_2_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_2);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_2_rej);

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_2);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_2_rej);
		
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");
		
		write2xml(output,"</Row>\n");
		
		fprintf(output, "<Row Srl=\"3\" ReasonName=\"Duplicate submodule\" RowTotal=\"%d\">\n", platform_total_3_rej);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_3);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_3_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_3);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_3_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_3);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_3_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_3);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_3_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_3);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_3_rej);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_3);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_3_rej);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"4\" ReasonName=\"Prototype development\" RowTotal=\"%d\">\n", platform_total_4_rej);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_4);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_4_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_4);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_4_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_4);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_4_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_4);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_4_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_4);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_4_rej);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_4);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_4_rej);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"5\" ReasonName=\"Wrong submodule address\" RowTotal=\"%d\">\n", platform_total_5_rej);
		
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_5);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_5_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_5);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_5_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_5);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_5_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_5);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_5_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_5);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_5_rej);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_5);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_5_rej);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"6\" ReasonName=\"No inputs from COC\" RowTotal=\"%d\">\n", platform_total_6_rej);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_6);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_6_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_6);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_6_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_6);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_6_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_6);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_6_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_6);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_6_rej);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_6);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_6_rej);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"7\" ReasonName=\"VC not in PPG Migration Plan\" RowTotal=\"%d\">\n", platform_total_7_rej);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_7);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_7_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_7);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_7_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_7);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_7_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_7);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_7_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_7);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_7_rej);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_7);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_7_rej);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"8\" ReasonName=\"Project on hold\" RowTotal=\"%d\">\n", platform_total_8_rej);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_8);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_8_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_8);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_8_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_8);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_8_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_8);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_8_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_8);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_8_rej);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_8);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_8_rej);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"9\" ReasonName=\"Common part with different software\" RowTotal=\"%d\">\n", platform_total_9_rej);
	
		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_9);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_9_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_9);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_9_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_9);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_9_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_9);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_9_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_9);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_9_rej);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_9);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_9_rej);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"10\" ReasonName=\"Other\" RowTotal=\"%d\">\n", platform_total_10_rej);

		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_10);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_10_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_10);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_10_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_10);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_10_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_10);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_10_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_10);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_10_rej);
		// write2xml(output,"<TOTAL>");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>\n");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_10);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_10_rej);
		
		write2xml(output,"</Row>\n");
		fprintf(output, "<Row Srl=\"11\" ReasonName=\"NA\" RowTotal=\"%d\">\n", platform_total_11_rej);

		
		write2xml(output,"<BUS>");
		write2xml(output,bus_rejectStr_11);
		write2xml(output,"</BUS>\n");
		fprintf(output, "<BUS_Percent>%.2f</BUS_Percent>\n", percent_bus_11_rej);
		
		write2xml(output,"<HCV>");
		write2xml(output,hcv_rejectStr_11);
		write2xml(output,"</HCV>\n");
		fprintf(output, "<HCV_Percent>%.2f</HCV_Percent>\n", percent_hcv_11_rej);
		
		write2xml(output,"<ILMCV>");
		write2xml(output,ilmcv_rejectStr_11);
		write2xml(output,"</ILMCV>\n");
		fprintf(output, "<ILMCV_Percent>%.2f</ILMCV_Percent>\n", percent_ilmcv_11_rej);
		
		write2xml(output,"<SCV>");
		write2xml(output,scv_rejectStr_11);
		write2xml(output,"</SCV>\n");
		fprintf(output, "<SCV_Percent>%.2f</SCV_Percent>\n", percent_scv_11_rej);
		
		write2xml(output,"<AGGR_BUSINESS>");
		write2xml(output,aggrbusiness_rejectStr_11);
		write2xml(output,"</AGGR_BUSINESS>\n");
		fprintf(output, "<AGGR_BUSINESS_Percent>%.2f</AGGR_BUSINESS_Percent>\n", percent_aggr_11_rej);
		// write2xml(output,"<TOTAL>\n");
		// write2xml(output,platform_totalStr);
		// write2xml(output,"</TOTAL>");

		write2xml(output,"<DEFENCE>");
		write2xml(output,Defence_rejectStr_11);
		write2xml(output,"</DEFENCE>\n");
		fprintf(output, "<DEFENCE_Percent>%.2f</DEFENCE_Percent>\n", percent_Defence_11_rej);
		
		write2xml(output,"</Row>\n");
		
		fprintf(output, "<Row_Total ColName=\"BUS_TOTAL\" ColTotal=\"%d\"/>\n", Bus_Col_Total_reject);
		fprintf(output, "<Row_Total ColName=\"HCV_TOTAL\" ColTotal=\"%d\"/>\n", Hcv_Col_Total_reject);
		fprintf(output, "<Row_Total ColName=\"ILMCV_TOTAL\" ColTotal=\"%d\"/>\n", Ilmcv_Col_Total_reject);
		fprintf(output, "<Row_Total ColName=\"SCV_TOTAL\" ColTotal=\"%d\"/>\n", Scv_Col_Total_reject);
		fprintf(output, "<Row_Total ColName=\"AGGR_BUSINESS_TOTAL\" ColTotal=\"%d\"/>\n", Aggr_Business_Col_Total_reject);
		fprintf(output, "<Row_Total ColName=\"DEFENCE_TOTAL\" ColTotal=\"%d\"/>\n", Defence_Col_Total_reject);
		
		write2xml(output,"</Section_NPRDroppedReasonCountProductLineWise>\n");
		
		
		
	//	write2xml(output,"</rows>\n");
		write2xml(output,"</DataSheet6>\n");
	}
	//write2xml(output,"</PLMXML>\n");
	MEM_free(tags_found);
	if(output!=NULL)fclose(output);output = NULL;

	return ifail;
}