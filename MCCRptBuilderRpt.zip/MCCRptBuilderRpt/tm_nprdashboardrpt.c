/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   NPR Status Dashboard Report Calling Exe  
*  File Name    :   tm_nprdashboardrpt.c
*  Created on   :   Jun 26th, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     26/06/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_string.h>


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of NPR Status Dashboard Main Function ************* \n");fflush(stdout);
	
	char* sysCmnd = NULL;
	//char* PrtStr = ITK_ask_cli_argument( "-PartList=");
	//char* UsrStr = ITK_ask_cli_argument( "-User=");
	//char* EmlStr = ITK_ask_cli_argument( "-Email=");
	sysCmnd=(char *) MEM_alloc(400);
	tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/NPRStatusDashboard/CallingShell.sh");
	//tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/NPRStatusDashboard/CallingShell.sh");
	//tc_strcat(sysCmnd,PrtStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,UsrStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,EmlStr);
	
	printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
	system(sysCmnd);
	//MEM_free(sysCmnd);
						

	printf("\n*********** End Of NPR Status Dashboard Main Function ************* \n");fflush(stdout);	
	return ifail;
}

/***************************************************************************
*
* // ./compile tm_nprdashboardrpt.c
* // ./linkitk -o tm_nprdashboardrpt tm_nprdashboardrpt.o
*
***************************************************************************/