./compile tm_DailyLibraryCreationCronJob.c
./linkitk -o tm_DailyLibraryCreationCronJob tm_DailyLibraryCreationCronJob.o
chmod 777 tm_DailyLibraryCreationCronJob*
