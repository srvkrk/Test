@echo off

set JAVA_HOME=C:\Siemens\Zulu_Java
set JRE_HOME=C:\Siemens\Zulu_Java

set XSL_FILE=print.xsl
set XML_FILE=%1%
set PDF_FILE=%2%
call java -jar generatesco.jar %XSL_FILE% %XML_FILE% %PDF_FILE%