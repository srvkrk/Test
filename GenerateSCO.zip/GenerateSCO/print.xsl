<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet version="2.0"
 xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:fo="http://www.w3.org/1999/XSL/Format"
  xmlns:DBE="http://www.sdrc.com/metaphase/cf11bd"
  xmlns:xs="http://www.w3.org/2001/XMLSchema"
  xmlns:str="http://exslt.org/strings"
  xmlns:java="http://xml.apache.org/xslt/java" exclude-result-prefixes="java str xs">

<!--  <xsl:import href="/home/people/dvault/srr07410/functx-1.0/functx/functx.xsl"/>  xmlns:functx="http://www.functx.com"
-->
  <xsl:output method="xml" indent="yes"/>
  <xsl:template match="/">
  <fo:root>
	<fo:layout-master-set>
        <fo:simple-page-master master-name="simple" page-height="11in" page-width="8.5in" margin-top=".5in" margin-bottom=".5in" margin-left=".5in" margin-right=".5in">
            <fo:region-body region-name="xsl-region-body" margin-bottom=".5in" margin-top="2mm"/>
            <!--<fo:region-before region-name="xsl-region-before" extent="5in"/>-->
            <fo:region-after region-name="xsl-region-after" extent=".5in"/>
        </fo:simple-page-master>
    </fo:layout-master-set>

     <fo:page-sequence master-reference="simple">
<!--        <fo:static-content flow-name="xsl-region-before">

        </fo:static-content>
-->
        <fo:static-content flow-name="xsl-region-after">
            <fo:block text-align="right" font-size="10" font-weight="bold">&#169; copyright TATA MOTORS Ltd., all rights reserved</fo:block>			
			<fo:block text-align="right" font-size="10">Page <fo:page-number/> of <fo:page-number-citation ref-id="end"/> </fo:block>
        </fo:static-content>
        <fo:flow flow-name="xsl-region-body">

		<xsl:variable name="datet" >
						<xsl:value-of select="java:format(java:java.text.SimpleDateFormat.new('dd-MMM-yyyy'), java:java.util.Date.new())"/>
		</xsl:variable>

		<xsl:variable name="developer" >
						<xsl:value-of select="CR/DATA/value[@name='developerName']"/>
		</xsl:variable>			

		<fo:block>			
		<fo:table table-layout="fixed" width="100%" border-width="0.2mm" border-style="solid"  >
			<fo:table-column column-width="55mm"/>
			<fo:table-column column-width="80mm"/>
			<fo:table-column column-width="17.5mm"/>
			<fo:table-column column-width="10mm"/>
			<fo:table-column column-width="17.5mm"/>
			<fo:table-column column-width="10mm"/>
			<fo:table-body>
				    
				
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>CUSTOMER NAME</fo:block>						
					</fo:table-cell>
			
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold">
						<fo:block>TATA MOTORS LIMITED</fo:block>
					</fo:table-cell>

					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" display-align="center" padding-right="7pt" font-size="10" number-columns-spanned="2">					
						<fo:block><fo:inline  font-weight="bold">DATE: </fo:inline></fo:block>
					</fo:table-cell>
					
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2">
						<fo:block>
							<fo:inline  font-size="10">													
									<xsl:value-of select="$datet"/>							
							</fo:inline>
						</fo:block>
					</fo:table-cell>
				</fo:table-row>

				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold">
						<fo:block>TATA MOTORS LIMITED</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold">
						<fo:block>SOFTWARE CHANGE ORDER</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="4">
						<fo:block text-align="center" font-size="10">Page <fo:page-number/> of <fo:page-number-citation ref-id="end"/> </fo:block>
					</fo:table-cell>					
				</fo:table-row>						
				
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold">
						<fo:block>Change Request:</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold">
						<fo:block><xsl:value-of select="CR/DATA/value[@name='wbsid']"/></fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2">
						<fo:block>SCO No</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2" >
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5ScoNumber']"/></fo:block>
					</fo:table-cell>
				</fo:table-row>
				
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold"> 
						<fo:block>REFERENCE NO:</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold"> 
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5RefCRNum']"/></fo:block>
					</fo:table-cell>						
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2" >
						<fo:block>VERSION NO:</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="center" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2" >
						<fo:block><xsl:value-of select="CR/DATA/value[@name='tzname']"/></fo:block>
					</fo:table-cell>					
				</fo:table-row>				
				
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold"> 
						<fo:block text-align="left" >MODULE/SYSTEM NAME:</fo:block >
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="5"> 
						<fo:block text-align="left" >TATA MOTORS IMPLEMENTATION</fo:block >
					</fo:table-cell>						
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold"> 
						<fo:block text-align="left" >PROGRAMMER:</fo:block >
					</fo:table-cell>					
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="5"> 
						<fo:block text-align="left" ><xsl:value-of select="substring-before($developer,',')"/></fo:block >
					</fo:table-cell>						
				</fo:table-row>					
				
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold"> 
						<fo:block text-align="left" >QA/REVIEW:</fo:block >
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold"> 
					<fo:block text-align="left" ><xsl:value-of select="CR/DATA/value[@name='t5UACRCodeRevwrDup']"/></fo:block >
					</fo:table-cell>	
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2"> 
						<fo:block text-align="left" >REVIEWED ON:</fo:block >
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2"> 
						<fo:block text-align="left" ><xsl:value-of select="$datet"/></fo:block >
					</fo:table-cell>					
				</fo:table-row>		
				
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold"> 
						<fo:block text-align="left" >INTEGRATOR:</fo:block >
					</fo:table-cell>	
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="5"> 
						<fo:block text-align="left" >INTEGRATION TEAM</fo:block >
					</fo:table-cell>					
				</fo:table-row>		
				
			</fo:table-body>
		</fo:table>		
	</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>

<!--Table 2 : Start -->	
	<fo:block>

		<fo:table table-layout="fixed" width="100%" border-width="0.2mm" border-style="solid"  >
			<fo:table-column column-width="10mm"/>
			<fo:table-column column-width="70mm"/>
			<fo:table-column column-width="15mm"/>
			<fo:table-column column-width="25mm"/>
			<fo:table-column column-width="45mm"/>			
			<fo:table-column column-width="30mm"/>			

			<fo:table-body>	
			
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="center" >LIST OF SOURCES CONSIDERED FOR INTEGRATION TESTING (WITH VERSIONS)</fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="8"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>Sr. No.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>FILE NAME</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="8"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>VERSION</fo:block>
					</fo:table-cell>

					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>Directory</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>Name of .so file</fo:block>
					</fo:table-cell>		

					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>Preference Name and Value </fo:block>
					</fo:table-cell>	
					
				</fo:table-row>
				
								
				<!-- <xsl:variable name="ColSize" >6</xsl:variable> -->
				
				

				<!-- 
					<xsl:variable name="attri" >
							<xsl:value-of select="DBE:String"/>
					</xsl:variable>-->
					<xsl:for-each select="CR/DATA/value[@name='t5UpdFileDetails']">
					<xsl:variable name="attriFile">
					             <xsl:value-of select="." />
				     </xsl:variable>
					
						<xsl:for-each select="str:tokenize($attriFile,';')">
						<xsl:variable name="attri">
									 <xsl:value-of select="."/>
							</xsl:variable>
						 
							<fo:table-row>
									<fo:table-cell border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold" > 
										<fo:block><xsl:value-of select="position()"/></fo:block>
									</fo:table-cell>
												<!-- filename first.mth@1.09@bom@so file name@preference name-->
										<fo:table-cell  border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold" > 
											<fo:block><xsl:value-of select="substring-before($attri,'@')"/></fo:block>
										</fo:table-cell>									
										<xsl:variable name="attri1" >
												<xsl:value-of select="substring-after($attri,'@')"/>
										</xsl:variable>
										<!-- version-->
										<fo:table-cell  border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold" > 
											<fo:block><xsl:value-of select="substring-before($attri1,'@')"/></fo:block>
										</fo:table-cell>

										<xsl:variable name="attri2" >
												<xsl:value-of select="substring-after($attri1,'@')"/>
										</xsl:variable>
										<!-- directory-->
										<fo:table-cell  border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold" > 
											<fo:block><xsl:value-of select="substring-before($attri2,'@')"/></fo:block>
										</fo:table-cell>
										
										<xsl:variable name="attri3" >
												<xsl:value-of select="substring-after($attri2,'@')"/>
										</xsl:variable>
										<!-- sofilename-->
										<fo:table-cell  border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold" > 
											<fo:block><xsl:value-of select="substring-before($attri3,'@')"/></fo:block>
										</fo:table-cell> 
										<xsl:variable name="attri4" >
												<xsl:value-of select="substring-after($attri3,'@')"/>
										</xsl:variable>
										<!-- prefname-->
										<fo:table-cell  border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold" > 
											<fo:block><xsl:value-of select="$attri4"/></fo:block>
										</fo:table-cell> 
									
								</fo:table-row>
						</xsl:for-each>
					
					</xsl:for-each>
				
					
				<fo:table-row>
							<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
									<fo:block text-align="center" >Mention names of new Stylesheet, Query, Transfer Mode,Workflow, Control Object:</fo:block >									
									<fo:block text-align="center" ><xsl:value-of select="CR/DATA/value[@name='t5UAOtherDetails']"/></fo:block >
							</fo:table-cell>
							
							
									
						
				</fo:table-row>


				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="center" >NEW SOURCES/ NEXT VERSIONS CHECKED INTO DIGITAL VAULT </fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2"> 
						<fo:block text-align="left" >DATE OF CHECKIN:</fo:block >
					</fo:table-cell>	
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="4"> 
						<fo:block text-align="left" ><xsl:value-of select="$datet"/></fo:block >
					</fo:table-cell>	
				</fo:table-row>				
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="left" >EXECUTABLES (PRD, EXE, ETC.) ON INTEGRATION SERVER.</fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="left" >DATE OF INTEGRATION TEST:</fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="left" >1.TEL MODULE</fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="left" >PACKAGING FILES</fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="left" >DATE OF PACKAGING FILES</fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="left" >1.TEL MODULE</fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell width="20px" padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold"> 
						<fo:block text-align="left" >CREATED BY:</fo:block >
					</fo:table-cell>		
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-left="40pt" font-size="10" font-weight="bold"> 
						<fo:block text-align="left" ><xsl:value-of select="substring-before($developer,',')"/></fo:block >
					</fo:table-cell>
					<fo:table-cell width="20px" padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="2" > 
						<fo:block text-align="left" >CREATED ON:</fo:block >
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-left="7pt" font-size="10" font-weight="bold" number-columns-spanned="2"> 
						<fo:block text-align="left" ><xsl:value-of select="$datet"/></fo:block >
					</fo:table-cell>						
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="6"> 
						<fo:block text-align="left" >TTL AUTHORIZATION:AVINASH DESHPANDE</fo:block >
					</fo:table-cell>									
				</fo:table-row>
			</fo:table-body>
		</fo:table>
	</fo:block>
	
<!--Table 2 : End -->

<!--Table 3 : Start -->
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>




		<fo:block>
		<fo:table table-layout="fixed" width="100%" border-width="0.2mm" border-style="solid"  >
			<fo:table-column column-width="20mm"/>
			<fo:table-column column-width="150mm"/>
			<fo:table-column column-width="29mm"/>
			<fo:table-body>
			<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="3"> 
						<fo:block text-align="center" >Generic Development Check List</fo:block >
					</fo:table-cell>									
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>Sr. No.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>QUERY</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>RESPONSE</fo:block>
					</fo:table-cell>	
				</fo:table-row>	

				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>1.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Have you used macros?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO3']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO1']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>	
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>2.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Have you carried memory cleanup?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO15']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO2']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>3.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Number of warnings in the code?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO16']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO3']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>4.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>If you have added an Attribute, have you provided the attribute in Create/Update/Query/View properties and relevant reports?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO17']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO4']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>5.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Have you checked out from Digital vault and worked on the same?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO18']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO5']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>
				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>6.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Have you compiled on your development environment check-in version?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO19']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO6']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>	

				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>7.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Have you tested with Designer/Manager login?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO19']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO7']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>	

				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>8.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>If LC is involved, have you tested the complete work-flow?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO19']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO8']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>	

				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>9.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>If functionality is affecting Design, Drawing, have you checked whether the Dataset opens in CAD?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO19']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO9']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>		

				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>10.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Have you updated the Training manual for this functionality?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO19']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO10']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>		

				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>11.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Do you need a small PPT for demo the same to Users?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO19']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO11']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>	

				<fo:table-row>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold">
						<fo:block>12.</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<fo:block>Are there any changes required in Admin Schema like ACLs?</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold">
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO19']/DBE:String"/></fo:block> -->
						<fo:block><xsl:value-of select="CR/DATA/value[@name='t5UaChkLstSCO12']"/></fo:block>
					</fo:table-cell>	
				</fo:table-row>					
				
			</fo:table-body>
		</fo:table>
</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>
<fo:block>&#xA0;</fo:block>

<!--Second list-->
<!-- <fo:block> -->
		<!-- <fo:table table-layout="fixed" width="100%" border-width="0.2mm" border-style="solid"  > -->
			<!-- <fo:table-column column-width="20mm"/> -->
			<!-- <fo:table-column column-width="150mm"/> -->
			<!-- <fo:table-column column-width="29mm"/> -->
			<!-- <fo:table-body> -->

				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid"  text-align="left" padding-right="7pt" font-size="10" font-weight="bold" number-columns-spanned="3">  -->
						<!-- <fo:block text-align="center" >Awareness Check List</fo:block > -->
					<!-- </fo:table-cell>									 -->
				<!-- </fo:table-row> -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Sr. No.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>QUERY</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>RESPONSE</fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row>	 -->

				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>1.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Have you used macros?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO1']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row>	 -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>2.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Have you used SC_SCOPE_WHERE_NECESSARY?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO2']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row>					 -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>3.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Number of warnings in the code?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO4']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row>	 -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>4.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Have you copy/duplicate of attribute after call to objGetAttribute in the code?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO5']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row>	 -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>5.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>If you have added an Attribute, have you provided the attribute in Create/Update/Query/Getinfo and relevant reports?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO6']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row>	 -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>6.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Have you checked out from Digital vault and worked on the same?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO7']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row> -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>7.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Have you compiled on your development environment check-in version?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO8']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row> -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>8.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Have you tested with Designer/Manager login?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO9']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row> -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>9.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>If LC is involved, have you tested the complete work-flow?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO10']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row> -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>10.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Have you fired GENTPL report from Web client?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO11']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row> -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>11.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>If functionality is affecting Part, DesDoc and Drawing, have you checked whether the DI opens in CAD?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO12']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row> -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>12.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Have you updated the Training manual for this functionality?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO13']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row> -->
				<!-- <fo:table-row> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="center" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>13.</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block>Do you need a small PPT for demo the same to Users?</fo:block> -->
					<!-- </fo:table-cell> -->
					<!-- <fo:table-cell padding="2pt" border-width="0.2mm" border-style="solid" font-size="10"  text-align="left" display-align="center" font-weight="bold"> -->
						<!-- <fo:block><xsl:value-of select="DBE:ObjectSetRoot/DBE:Object[@Class='t5PrRpIt']/DBE:Attribute[@name='t5ChkLstSCO14']/DBE:String"/></fo:block> -->
					<!-- </fo:table-cell>	 -->
				<!-- </fo:table-row> -->
				
				
			<!-- </fo:table-body> -->
		<!-- </fo:table> -->
<!-- </fo:block> -->

<!--Table 2 : End -->
<fo:block id="end"/>
<fo:block>&#xA0;</fo:block>

	 </fo:flow>
	</fo:page-sequence>
   </fo:root>
  </xsl:template>
</xsl:stylesheet>
