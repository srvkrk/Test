#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"
#include "ZMATERIAL_SAVE_CONFIGURATION_2.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//#include <cl.h>
//#include <msgomf.h>
//#include <msgapc.h>
#include <ZZ_sqlerr.h>
#include <AZ_ato.h>
#include <stdio.h>
#include <stdlib.h>
//#include <string.h>
//#include <Mtimsgh.h>
//#include <usc.h>
//#include <sc.h>
//#include <pdmsessn.h>
//#include <tel.h>
FILE *fsuccess = NULL;
void getTodayDate(char StdDate[11]);
RFC_HANDLE BapiLogon(void);

RFC_RC ZMATERIAL_SAVE_CONFIGURATION(RFC_HANDLE hRfc
		,MARA_MATNR*eMATNR1
		,SATNR *eSATNR
		,MARC_WERKS *eWerks
		,STDPD *eSTDPD
		,REVLV *eREVLV
		,DATUV *eDATUV
		,BAPIRET2 *iRETURN
		,ITAB_H thE1CUCFG
		,ITAB_H thE1CUINS
		,ITAB_H thE1CUVAL
		,ITAB_H thE1CUCOM
		,ITAB_H thE1CUCFG_W
		,ITAB_H thE1CUINS_W
		,ITAB_H thE1CUVAL_W
		,ITAB_H thE1CUCOM_W
		,ITAB_H thE1CUCFG_V
		,ITAB_H thE1CUINS_V
		,ITAB_H thE1CUVAL_V
		,ITAB_H thE1CUCOM_V
		,ITAB_H thRETURNMESSAGES
		,char *xException);

RFC_HANDLE BapiLogon(void)
{
	static RFC_OPTIONS RfcOptions;
	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;



	/*RfcOptions.destination ="PP8";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1;
	RfcConnoptR3only.hostname="172.31.14.89";
	RfcConnoptR3only.gateway_host="172.31.14.89";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

	/*RfcOptions.destination ="PP8";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1;
	RfcConnoptR3only.hostname="p690";
	RfcConnoptR3only.gateway_host="p690";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

	RfcOptions.destination ="PD8";
	RfcOptions.client = "250";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1;
	RfcConnoptR3only.hostname="6m252";
	RfcConnoptR3only.gateway_host="6m252";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;

	/*RfcOptions.destination ="PQ8";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1;
	RfcConnoptR3only.hostname="tdmsdest";
	RfcConnoptR3only.gateway_host="tdmsdest";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

	/*RfcOptions.destination ="PQ8";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1;
	RfcConnoptR3only.hostname="172.24.29.12";
	RfcConnoptR3only.gateway_host="172.24.29.12";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/


	printf("\nConnecting to...:%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
	hRfc = RfcOpen(&RfcOptions);
	if (hRfc == RFC_HANDLE_NULL)
	{
		printf("\n\nERROR RECEIVED CPIC-ERROR");
		exit(0);
	}
	else
	{

		RfcEnvironment(&RfcEnv);
	}
	return hRfc;
}


RFC_RC ZMATERIAL_SAVE_CONFIGURATION(RFC_HANDLE hRfc
		,MARA_MATNR*eMATNR1
		,SATNR *eSATNR
		,MARC_WERKS *eWerks
		,STDPD *eSTDPD
		,REVLV *eREVLV
		,DATUV *eDATUV
		,BAPIRET2 *iRETURN
		,ITAB_H thE1CUCFG
		,ITAB_H thE1CUINS
		,ITAB_H thE1CUVAL
		,ITAB_H thE1CUCOM
		,ITAB_H thE1CUCFG_W
		,ITAB_H thE1CUINS_W
		,ITAB_H thE1CUVAL_W
		,ITAB_H thE1CUCOM_W
		,ITAB_H thE1CUCFG_V
		,ITAB_H thE1CUINS_V
		,ITAB_H thE1CUVAL_V
		,ITAB_H thE1CUCOM_V
		,ITAB_H thRETURNMESSAGES
		,char *xException)
{
	RFC_RC RfcRc;
	RFC_PARAMETER Exporting[7];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[10];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(MARA_MATNR);
	Exporting[0].addr = eMATNR1;

	Exporting[1].name = "CONF_MATL";
	Exporting[1].nlen = 9;
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(SATNR);
	Exporting[1].addr = eSATNR;

	Exporting[2].name = "PLANT";
	Exporting[2].nlen = 5;
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(MARC_WERKS);
	Exporting[2].addr = eWerks;

	Exporting[3].name = "CONF_MATL_PLANT";
	Exporting[3].nlen = 15;
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(STDPD);
	Exporting[3].addr = eSTDPD;


	Exporting[4].name = "REV_LEVEL";
	Exporting[4].nlen = 9;
	Exporting[4].type = TYPC;
	Exporting[4].leng = sizeof(REVLV);
	Exporting[4].addr = eREVLV;

	Exporting[5].name = "DATE";
	Exporting[5].nlen = 4;
	Exporting[5].type = TYPC;
	Exporting[5].leng = sizeof(DATUV);
	Exporting[5].addr = eDATUV;



	Exporting[6].name = NULL;

	Tables[0].name     = "E1CUCFG";
	Tables[0].nlen     = 7;
	Tables[0].type     = handleOfE1CUCFG;
	Tables[0].ithandle = thE1CUCFG;

	Tables[1].name     = "E1CUINS";
	Tables[1].nlen     = 7;
	Tables[1].type     = handleOfE1CUINS;
	Tables[1].ithandle = thE1CUINS;

	Tables[2].name     = "E1CUVAL";
	Tables[2].nlen     = 7;
	Tables[2].type     = handleOfE1CUVAL;
	Tables[2].ithandle = thE1CUVAL;

	Tables[3].name     = "E1CUCOM";
	Tables[3].nlen     = 7;
	Tables[3].type     = handleOfE1CUCOM;
	Tables[3].ithandle = thE1CUCOM;

	Tables[4].name     = "E1CUCFG_W";
	Tables[4].nlen     = 9;
	Tables[4].type     = handleOfE1CUCFG_W;
	Tables[4].ithandle = thE1CUCFG_W;

	Tables[5].name     = "E1CUINS_W";
	Tables[5].nlen     = 9;
	Tables[5].type     = handleOfE1CUINS_W;
	Tables[5].ithandle = thE1CUINS_W;

	Tables[6].name     = "E1CUVAL_W";
	Tables[6].nlen     = 9;
	Tables[6].type     = handleOfE1CUVAL_W;
	Tables[6].ithandle = thE1CUVAL_W;

	Tables[7].name     = "E1CUCOM_W";
	Tables[7].nlen     = 9;
	Tables[7].type     = handleOfE1CUCOM_W;
	Tables[7].ithandle = thE1CUCOM_W;

	Tables[8].name     = "RETURNMESSAGES";
	Tables[8].nlen     = 14;
	Tables[8].type     = handleOfRETURNMESSAGES;
	Tables[8].ithandle = thRETURNMESSAGES;

	Tables[9].name = NULL;

	/*Tables[8].name     = "E1CUCFG_V";
	Tables[8].nlen     = 9;
	Tables[8].type     = handleOfE1CUCFG_V;
	Tables[8].ithandle = thE1CUCFG_V;

	Tables[9].name     = "E1CUINS_V";
	Tables[9].nlen     = 9;
	Tables[9].type     = handleOfE1CUINS_V;
	Tables[9].ithandle = thE1CUINS_V;

	Tables[10].name     = "E1CUVAL_V";
	Tables[10].nlen     = 9;
	Tables[10].type     = handleOfE1CUVAL_V;
	Tables[10].ithandle = thE1CUVAL_V;

	Tables[11].name     = "E1CUCOM_V";
	Tables[11].nlen     = 9;
	Tables[11].type     = handleOfE1CUCOM_V;
	Tables[11].ithandle = thE1CUCOM_V;

	Tables[12].name     = "RETURNMESSAGES";
	Tables[12].nlen     = 14;
	Tables[12].type     = handleOfRETURNMESSAGES;
	Tables[12].ithandle = thRETURNMESSAGES;

	Tables[13].name = NULL;
	*/

	RfcRc = RfcCall(hRfc,"ZMATERIAL_SAVE_CONFIGURATION_2",Exporting,Tables);
	switch (RfcRc)
{
	case RFC_OK :

		Importing[0].name = "RETURN";
		Importing[0].nlen = 6;
		Importing[0].type = handleOfBAPIRET2;
		Importing[0].leng = sizeof(BAPIRET2);
		Importing[0].addr = iRETURN;

		Importing[1].name = NULL;


		RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
		//printf("\n%s",RfcException);

		switch (RfcRc)
		{
			case RFC_SYS_EXCEPTION:
				strcpy(xException,RfcException);
			break;
			case RFC_EXCEPTION:
				strcpy(xException,RfcException);
			break;
			default:;
		}
	break;
	default :
		printf("\nin default");
}
return RfcRc;
}
/*
void getTodayDate(char StdDate[11])
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day= Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;
	sprintf(StdDate,"%02d.%02d.%04d",Day,Month,Year);
	printf("Date:[%s]",StdDate);
}
*/
void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("%*.0s",pos,text); printf("%-*s : %s\n",len,text,str);fflush(stdout);
  //if (stdout!=NULL) fprintf(stdout,"=%s\n>%s\n",text,str);
  return;
}

void getMonthYear(char MonYear[7])
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;

	sprintf(MonYear,"%02d.%04d",Month,Year);
	printf("Date:[%s]",MonYear);
}
int main(int argc,char* argv[])
{
/*status dstat = OKAY;
int stat = 0;
int mfail = OKAY;*/
char xException[256];
char cMaterial[100]={0};
char cPlant[5]={0};
/*char cBomUsage[2]={0};*/
char StdDate[11]={0};
char cChangeno[12]={0};
RFC_HANDLE hRfc;
RFC_RC RfcRc;
MARA_MATNR eMATNR1;
SATNR eSATNR;
MARC_WERKS eWerks;
STDPD eSTDPD;
REVLV eREVLV;
DATUV eDATUV;
BAPIRET2 iRETURN;

ITAB_H thE1CUCFG = ITAB_NULL;
E1CUCFG *tE1CUCFG;

ITAB_H thE1CUINS = ITAB_NULL;
E1CUINS *tE1CUINS;

ITAB_H thE1CUVAL = ITAB_NULL;
E1CUVAL *tE1CUVAL;

ITAB_H thE1CUCOM = ITAB_NULL;
E1CUCOM *tE1CUCOM;

ITAB_H thE1CUCFG_W = ITAB_NULL;
E1CUCFG_W *tE1CUCFG_W;

ITAB_H thE1CUINS_W = ITAB_NULL;
E1CUINS_W *tE1CUINS_W;

ITAB_H thE1CUVAL_W = ITAB_NULL;
E1CUVAL_W *tE1CUVAL_W;

ITAB_H thE1CUCOM_W = ITAB_NULL;
E1CUCOM_W *tE1CUCOM_W;

ITAB_H thE1CUCFG_V = ITAB_NULL;
E1CUCFG_V *tE1CUCFG_V;

ITAB_H thE1CUINS_V = ITAB_NULL;
E1CUINS_V *tE1CUINS_V;

ITAB_H thE1CUVAL_V = ITAB_NULL;
E1CUVAL_V *tE1CUVAL_V;

ITAB_H thE1CUCOM_V = ITAB_NULL;
E1CUCOM_V *tE1CUCOM_V;

ITAB_H thRETURNMESSAGES = ITAB_NULL;
RETURNMESSAGES *tRETURNMESSAGES;

char* jtmemFile = NULL;
char* DMLClsurS = NULL;
char DelindFileName[200]={0};
char fsuccess_name[200]={0};

FILE* fr = NULL;
char cPartNumber[15]={0};
int crow = 0;
char s[1024] = {0};
//SetOfStrings partSet = NULL;
int cnt = 0;

char Logfname[200]={0};
char MonYear[7] = {0};
char trDmlno[13]={0};

/*if (dstat = clInitMB2 (argc, &argv, NULL)) goto CLEANUP;
if (dstat = clTestNetwork ()) goto CLEANUP;
if (dstat = clInitialize2 (FALSE)) goto CLEANUP;

if (dstat = clLogin2 ("Loader", "123loader", &stat)) goto CLEANUP;
if (stat != OKAY)
{
	goto CLEANUP;
}
if (dstat = OpenStartupPrefs("StuPref",&mfail));
if (mfail) goto CLEANUP;*/

//hRfc = BapiLogon();
jtmemFile = (char*) malloc(100 * sizeof(char));
DMLClsurS = (char*) malloc(100 * sizeof(char));

strcpy(cPartNumber,argv[1]);
strcpy(cPlant,argv[2]);
//strcpy(cChangeno,argv[3]);


	//sprintf(ckdfilename,"%s/PLMSAP/CKDDMLLOGDIR/CkdDmlTransfer_%s.log",getenv("ONLREP"),CkdDml);
	//sprintf(ckdfilename,"/data/omfprod/PLMSAP/CKDDMLLOGDIR/CkdDmlTransfer_%s.log",CkdDml);
	//sprintf(ckdfilename,"CkdDmlTransfer_%s.log",CkdDml);

sprintf(fsuccess_name,"Modular_bom_%s_%s.log",argv[1],argv[2]);



	fsuccess = fopen(fsuccess_name,"a");
	//if(fsuccess == NULL)
		//printf("\nUnable To open Or Create Log  file");


if(fsuccess==NULL)
{
   printf("\nFile Does not exists....");
   fflush(stdout);
   fflush(stdout);
}
else
{
	//while(1)
//	partSet = low_set_read_file(DelindFileName);
//	for (cnt = 0; cnt < setSize(partSet); cnt++)
	{

//		DMLClsurS = nlsStrAlloc(100);
//		jtmemFile = nlsStrAlloc(100);
//		jtmemFile = setGetStr(partSet, cnt);
//		fgets(jtmemFile,100,fsuccess);
//		if(feof(fsuccess)!=0)
//		{
//		   printf("\nIn feofIF");fflush(stdout);
//		   break;
//		}
//		else
//		{
//			nlsStrCpy(DMLClsurS,jtmemFile);
//			nlsStrTrimTrailWhiteSpace(DMLClsurS);
//			nlsStrTrimLeadWhiteSpace(DMLClsurS);
//			nlsStrCpy(cMaterial,DMLClsurS);
//			cMaterial[nlsStrLen(cMaterial)] = '\0';
//			if(nlsStrLen(DMLClsurS)==0)
//			{
//				printf("\nBlankLineSkipping");fflush(stdout);
//				continue;
//			}


			printf("\n............aaaaaaaaaaaaaaaaaaaaaaa");


			printf("\n....abc............%s, %s,............................", cPartNumber,cPlant);

			hRfc = BapiLogon();

			SETCHAR(eMATNR1,cPartNumber);
			SETCHAR(eWerks,cPlant);
			SETCHAR(eSATNR,"X4MC4A06");
			SETCHAR(eSTDPD,"X4MC4A06");

			printf("\n......xyz..........%s, %s,............................", cPartNumber,cPlant);


			printf("\n............bbbbbbbbbbbbbbbbbbbbbbb");


		/*	tBomItem = ItAppLine(thBomItem);
		if (tBomItem == NULL)
		printf("ItAppLineBOM_ITEM");*/
			if(thE1CUCFG==ITAB_NULL)
			{
				thE1CUCFG = ItCreate("E1CUCFG",sizeof(E1CUCFG), 0, 0);
				if(thE1CUCFG == ITAB_NULL)
					printf("\nItCreate E1CUCFG");
			}
			else if(ItFree(thE1CUCFG) != 0)
				printf("\nItFree E1CUCFG");

			tE1CUCFG = ItAppLine(thE1CUCFG);
			if (tE1CUCFG == NULL)
			printf("ItAppLine tE1CUCFG");
//			SETCHAR(tE1CUCFG->POSEX,cPlant);
//			SETCHAR(tE1CUCFG->CONFIG_ID,"000001");
//			SETCHAR(tE1CUCFG->ROOT_ID,"00000001");
//			SETCHAR(tE1CUCFG->COMPLETE,"T");
//			SETCHAR(tE1CUCFG->CONSISTENT,"T");

/* Added by Govind*/

			SETCHAR(tE1CUCFG->POSEX,cPlant);
			SETCHAR(tE1CUCFG->CONFIG_ID,"000001");
			SETCHAR(tE1CUCFG->ROOT_ID,"00000001");
			SETCHAR(tE1CUCFG->SCE,"");
			SETCHAR(tE1CUCFG->KBNAME,"");
			SETCHAR(tE1CUCFG->KBVERSION,"");
			SETCHAR(tE1CUCFG->COMPLETE,"T");
			SETCHAR(tE1CUCFG->CONSISTENT,"T");
			SETCHAR(tE1CUCFG->CFGINFO,"");
			SETCHAR(tE1CUCFG->KBPROFILE,"");
			SETCHAR(tE1CUCFG->KBLANGUAGE,"");
			SETCHAR(tE1CUCFG->CBASE_ID,"");
			SETCHAR(tE1CUCFG->CBASE_ID_TYPE,"");


			//-----------------------------------
			if(thE1CUINS==ITAB_NULL)
			{
				thE1CUINS = ItCreate("E1CUINS",sizeof(E1CUINS), 0, 0);
				if(thE1CUINS == ITAB_NULL)
					printf("\nItCreate E1CUINS");
			}
			else if(ItFree(thE1CUINS) != 0)
				printf("\nItFree E1CUINS");

			tE1CUINS = ItAppLine(thE1CUINS);
			if (tE1CUINS == NULL)
			printf("ItAppLine tE1CUINS");
			/*SETCHAR(tE1CUINS->INST_ID,"00000001");
			SETCHAR(tE1CUINS->OBJ_TYPE,"MARA");
			SETCHAR(tE1CUINS->CLASS_TYPE,"300");
			SETCHAR(tE1CUINS->OBJ_KEY,"1100_KMAT_01");
			SETCHAR(tE1CUINS->QUANTITY,"1");
			SETCHAR(tE1CUINS->COMPLETE,"T");
			SETCHAR(tE1CUINS->CONSISTENT,"T");
			SETCHAR(tE1CUINS->QUANTITY_UNIT,"EA");
			SETCHAR(tE1CUINS->OBJECT_GUID,"1100_KMAT_01");*/

			SETCHAR(tE1CUINS->INST_ID,"00000001");
			SETCHAR(tE1CUINS->OBJ_TYPE,"MARA");
			SETCHAR(tE1CUINS->CLASS_TYPE,"300");
			SETCHAR(tE1CUINS->OBJ_KEY,"X4MC4A06");
			SETCHAR(tE1CUINS->OBJ_TXT,"");
			SETCHAR(tE1CUINS->QUANTITY,"1");
			SETCHAR(tE1CUINS->AUTHOR,"");
			SETCHAR(tE1CUINS->QUANTITY_UNIT,"EA");
			SETCHAR(tE1CUINS->COMPLETE,"T");
			SETCHAR(tE1CUINS->CONSISTENT,"T");
			SETCHAR(tE1CUINS->OBJECT_GUID,"X4MC4A06");
			SETCHAR(tE1CUINS->PERSIST_ID,"");
			SETCHAR(tE1CUINS->PERSIST_ID_TYPE,"");

			//-----------------------------------

			if(thE1CUVAL==ITAB_NULL)
			{
				thE1CUVAL = ItCreate("E1CUVAL",sizeof(E1CUVAL), 0, 0);
				if(thE1CUVAL == ITAB_NULL)
					printf("\nItCreate E1CUVAL");
			}
			else if(ItFree(thE1CUVAL) != 0)
				printf("\nItFree E1CUVAL");

			tE1CUVAL = ItAppLine(thE1CUVAL);
			if (tE1CUVAL == NULL)
			printf("ItAppLine tE1CUVAL");
			/*SETCHAR(tE1CUVAL->VALUE,cPartNumber);
			SETCHAR(tE1CUVAL->CHARC,"P_VC");
			SETCHAR(tE1CUVAL->INST_ID,"00000001");
			SETCHAR(tE1CUVAL->VALCODE,"1");*/

			/*SETCHAR(tE1CUVAL->INST_ID,"00000001");
			SETCHAR(tE1CUVAL->CHARC,"P_VC");
			SETCHAR(tE1CUVAL->CHARC_TXT,"");
			SETCHAR(tE1CUVAL->VALUE,"282010240B4R_1");//282010240B4R_1//cPartNumber
			SETCHAR(tE1CUVAL->VALUE_TXT,"");
			SETCHAR(tE1CUVAL->AUTHOR,"");
			SETCHAR(tE1CUVAL->VALUE_TO,"");
			SETCHAR(tE1CUVAL->VALCODE,"1");*/


			///////////////////-----------------2
			tE1CUVAL = ItAppLine(thE1CUVAL);
			if (tE1CUVAL == NULL)
			printf("ItAppLine tE1CUVAL");
			/*SETCHAR(tE1CUVAL->VALUE,cPartNumber);
			SETCHAR(tE1CUVAL->CHARC,"P_VC");
			SETCHAR(tE1CUVAL->INST_ID,"00000001");
			SETCHAR(tE1CUVAL->VALCODE,"1");*/

			SETCHAR(tE1CUVAL->INST_ID,"00000001");
			SETCHAR(tE1CUVAL->CHARC,"SURROUND_VIEW_360_DEG");
			SETCHAR(tE1CUVAL->CHARC_TXT,"");
			SETCHAR(tE1CUVAL->VALUE,"NO");
			SETCHAR(tE1CUVAL->VALUE_TXT,"");
			SETCHAR(tE1CUVAL->AUTHOR,"");
			SETCHAR(tE1CUVAL->VALUE_TO,"");
			SETCHAR(tE1CUVAL->VALCODE,"");


			//-----------------------------------
			if(thE1CUCOM==ITAB_NULL)
			{
				thE1CUCOM = ItCreate("E1CUCOM",sizeof(E1CUCOM), 0, 0);
				if(thE1CUCOM == ITAB_NULL)
					printf("\nItCreate E1CUCOM");
			}
			else if(ItFree(thE1CUCOM) != 0)
				printf("\nItFree E1CUCOM");

			tE1CUCOM = ItAppLine(thE1CUCOM);
			if (tE1CUCOM == NULL)
			printf("ItAppLine tE1CUCOM");
			/*SETCHAR(tE1CUCOM->MSGFN,"023");
			SETCHAR(tE1CUCOM->C_PROFILE,"PROFILE FOR 1100_KMAT_01");
			SETCHAR(tE1CUCOM->CLASSTYPE,"300");
			SETCHAR(tE1CUCOM->STATUS,"1");
			SETCHAR(tE1CUCOM->BOMEXPL,"1");
			SETCHAR(tE1CUCOM->CHAR_VALU,"2");*/

			SETCHAR(tE1CUCOM->MSGFN,"023");
			SETCHAR(tE1CUCOM->C_PROFILE,"PROFILE1");
			SETCHAR(tE1CUCOM->CLASSTYPE ,"300");
			SETCHAR(tE1CUCOM->ORGAREAS,"");
			SETCHAR(tE1CUCOM->STATUS,"1");
			SETCHAR(tE1CUCOM->BOMAPPL,"");
			SETCHAR(tE1CUCOM->FLAVAILCH,"");
			SETCHAR(tE1CUCOM->BOMEXPL ,"1");
			SETCHAR(tE1CUCOM->TASKLEXPL,"");
			SETCHAR(tE1CUCOM->INITSCREEN,"");
			SETCHAR(tE1CUCOM->FLASSEMBLY,"");
			SETCHAR(tE1CUCOM->FLRESULT,"");
			SETCHAR(tE1CUCOM->FLMDATA,"");
			SETCHAR(tE1CUCOM->FLCASONLY,"");
			SETCHAR(tE1CUCOM->FLMANCHANG,"");
			SETCHAR(tE1CUCOM->FLHOLDBOM,"");
			SETCHAR(tE1CUCOM->FLDELETE,"");
			SETCHAR(tE1CUCOM->DESIGN,"");
			SETCHAR(tE1CUCOM->NEUTR,"");
			SETCHAR(tE1CUCOM->CHAR_VALU,"2");
			SETCHAR(tE1CUCOM->A_LAISO,"");
			SETCHAR(tE1CUCOM->SCOPE_CHAR,"");
			SETCHAR(tE1CUCOM->SCOPE_VALU,"");
			SETCHAR(tE1CUCOM->FL_EXCLUDE,"");
			SETCHAR(tE1CUCOM->DISPLAY,"");
			SETCHAR(tE1CUCOM->PRICING,"");
			SETCHAR(tE1CUCOM->CONFIGUR,"");
			SETCHAR(tE1CUCOM->DEFVALU_DE,"");
			SETCHAR(tE1CUCOM->FL_MARK,"");
			SETCHAR(tE1CUCOM->DEFVALU_CC,"");
			SETCHAR(tE1CUCOM->TYPM_SEL,"");
			SETCHAR(tE1CUCOM->TYPM_STRA,"");
			SETCHAR(tE1CUCOM->FL_SC_CHAR,"");
			SETCHAR(tE1CUCOM->FL_SC_DEP,"");
			SETCHAR(tE1CUCOM->FL_SC_KN,"");
			SETCHAR(tE1CUCOM->FL_SC_CMPF,"");
			SETCHAR(tE1CUCOM->MULTIL_STRU,"");
			SETCHAR(tE1CUCOM->FL_DPSEU,"");
			SETCHAR(tE1CUCOM->OB_FIX,"");
			SETCHAR(tE1CUCOM->OB_INST,"");
			SETCHAR(tE1CUCOM->FL_EOASL,"");
			SETCHAR(tE1CUCOM->FL_SAASL,"");
			SETCHAR(tE1CUCOM->FL_OBJ_MAT,"");
			SETCHAR(tE1CUCOM->FL_OBJ_DOC,"");
			SETCHAR(tE1CUCOM->FL_OBJ_CLS ,"");
			SETCHAR(tE1CUCOM->FL_OBJ_TXT,"");
			SETCHAR(tE1CUCOM->FL_SDREL,"");
			SETCHAR(tE1CUCOM->FL_KOREL,"");
			SETCHAR(tE1CUCOM->FL_FEREL,"");
			SETCHAR(tE1CUCOM->FL_INREL,"");
			SETCHAR(tE1CUCOM->FL_KAREL,"");
			SETCHAR(tE1CUCOM->POSTYPEN,"");
			SETCHAR(tE1CUCOM->SORTF1,"");
			SETCHAR(tE1CUCOM->SORTF2,"");
			SETCHAR(tE1CUCOM->SORTF3,"");
			SETCHAR(tE1CUCOM->SORTF4,"");
			SETCHAR(tE1CUCOM->SORTF5,"");
			SETCHAR(tE1CUCOM->CLASSF1,"");
			SETCHAR(tE1CUCOM->CLASSF2,"");
			SETCHAR(tE1CUCOM->CLASSF3,"");
			SETCHAR(tE1CUCOM->CLASSF4,"");
			SETCHAR(tE1CUCOM->CLASSF5,"");
			SETCHAR(tE1CUCOM->PRIO,"");
			SETCHAR(tE1CUCOM->PRSTL,"");
			SETCHAR(tE1CUCOM->UMBEW,"");
			SETCHAR(tE1CUCOM->FLBROWSER,"");
			SETCHAR(tE1CUCOM->FL_PROF_OBOM,"");

			//-----------------------------------


			if(thE1CUCFG_W==ITAB_NULL)
			{
				thE1CUCFG_W = ItCreate("E1CUCFG_W",sizeof(E1CUCFG_W), 0, 0);
				if(thE1CUCFG_W == ITAB_NULL)
					printf("\nItCreate E1CUCFG_W");
			}
			else if(ItFree(thE1CUCFG_W) != 0)
				printf("\nItFree E1CUCFG_W");

			tE1CUCFG_W = ItAppLine(thE1CUCFG_W);
			if (tE1CUCFG_W == NULL)
			printf("ItAppLine tE1CUCFG_W");
//			SETCHAR(tE1CUCFG_W->POSEX,cPlant);
//			SETCHAR(tE1CUCFG_W->CONFIG_ID,"000001");
//			SETCHAR(tE1CUCFG_W->ROOT_ID,"00000001");
//			SETCHAR(tE1CUCFG_W->COMPLETE,"T");
//			SETCHAR(tE1CUCFG_W->CONSISTENT,"T");

			SETCHAR(tE1CUCFG_W->POSEX,cPlant);
			SETCHAR(tE1CUCFG_W->CONFIG_ID,"000001");
			SETCHAR(tE1CUCFG_W->ROOT_ID,"00000001");
			SETCHAR(tE1CUCFG_W->SCE,"");
			SETCHAR(tE1CUCFG_W->KBNAME,"");
			SETCHAR(tE1CUCFG_W->KBVERSION,"");
			SETCHAR(tE1CUCFG_W->COMPLETE,"T");
			SETCHAR(tE1CUCFG_W->CONSISTENT,"T");
			SETCHAR(tE1CUCFG_W->CFGINFO,"");
			SETCHAR(tE1CUCFG_W->KBPROFILE,"");
			SETCHAR(tE1CUCFG_W->KBLANGUAGE,"");
			SETCHAR(tE1CUCFG_W->CBASE_ID,"");
			SETCHAR(tE1CUCFG_W->CBASE_ID_TYPE,"");

			//-----------------------------------




			printf("\n............eeeeeeeeeeeeeeeeeeeeeeeeeeeeee");

			if(thE1CUINS_W==ITAB_NULL)
			{
				thE1CUINS_W = ItCreate("E1CUINS_W",sizeof(E1CUINS_W), 0, 0);
				if(thE1CUINS_W == ITAB_NULL)
					printf("\nItCreate E1CUINS_W");
			}
			else if(ItFree(thE1CUINS_W) != 0)
				printf("\nItFree E1CUINS_W");


			tE1CUINS_W = ItAppLine(thE1CUINS_W);
			if (tE1CUINS_W == NULL)
			printf("ItAppLine tE1CUINS_W");
			/*SETCHAR(tE1CUINS_W->INST_ID,"00000001");
			SETCHAR(tE1CUINS_W->OBJ_TYPE,"MARA");
			SETCHAR(tE1CUINS_W->CLASS_TYPE,"300");
			SETCHAR(tE1CUINS_W->OBJ_KEY,"1100_KMAT_01");
			SETCHAR(tE1CUINS_W->QUANTITY,"1");
			SETCHAR(tE1CUINS_W->COMPLETE,"T");
			SETCHAR(tE1CUINS_W->CONSISTENT,"T");
			SETCHAR(tE1CUINS_W->QUANTITY_UNIT,"EA");
			SETCHAR(tE1CUINS_W->OBJECT_GUID,"1100_KMAT_01");*/

			SETCHAR(tE1CUINS_W->INST_ID,"00000001");
			SETCHAR(tE1CUINS_W->OBJ_TYPE,"MARA");
			SETCHAR(tE1CUINS_W->CLASS_TYPE,"300");
			SETCHAR(tE1CUINS_W->OBJ_KEY,"X4MC4A06");
			SETCHAR(tE1CUINS_W->OBJ_TXT,"");
			SETCHAR(tE1CUINS_W->QUANTITY,"1");
			SETCHAR(tE1CUINS_W->AUTHOR,"");
			SETCHAR(tE1CUINS_W->QUANTITY_UNIT,"EA");
			SETCHAR(tE1CUINS_W->COMPLETE,"T");
			SETCHAR(tE1CUINS_W->CONSISTENT,"T");
			SETCHAR(tE1CUINS_W->OBJECT_GUID,"X4MC4A06");
			SETCHAR(tE1CUINS_W->PERSIST_ID,"");
			SETCHAR(tE1CUINS_W->PERSIST_ID_TYPE,"");

			printf("\n............fffffffffffffffffffffffffffffffffff");




			printf("\n............gggggggggggggggggggggggggggggggggggg");

			if(thE1CUVAL_W==ITAB_NULL)
			{
				thE1CUVAL_W = ItCreate("E1CUVAL_W",sizeof(E1CUVAL_W), 0, 0);
				if(thE1CUVAL_W == ITAB_NULL)
					printf("\nItCreate E1CUVAL_W");
			}
			else if(ItFree(thE1CUVAL_W) != 0)
				printf("\nItFree E1CUVAL_W");

			tE1CUVAL_W = ItAppLine(thE1CUVAL_W);
			if (tE1CUVAL_W == NULL)
			printf("ItAppLine tE1CUVAL_W");
			/*SETCHAR(tE1CUVAL_W->VALUE,cPartNumber);
			SETCHAR(tE1CUVAL_W->CHARC,"P_VC");
			SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
			SETCHAR(tE1CUVAL_W->VALCODE,"1");*/

			/*SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
			SETCHAR(tE1CUVAL_W->CHARC,"P_VC");
			SETCHAR(tE1CUVAL_W->CHARC_TXT,"");
			SETCHAR(tE1CUVAL_W->VALUE,"282010240B4R_1");//282010240B4R_1//cPartNumber
			SETCHAR(tE1CUVAL_W->VALUE_TXT,"");
			SETCHAR(tE1CUVAL_W->AUTHOR,"");
			SETCHAR(tE1CUVAL_W->VALUE_TO,"");
			SETCHAR(tE1CUVAL_W->VALCODE,"1");*/

			///////////////////-----------------2
			//P_MARKET	//DOMESTIC

			tE1CUVAL_W = ItAppLine(thE1CUVAL_W);
			if (tE1CUVAL_W == NULL)
			printf("ItAppLine tE1CUVAL_W");
			/*SETCHAR(tE1CUVAL_W->VALUE,cPartNumber);
			SETCHAR(tE1CUVAL_W->CHARC,"P_VC");
			SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
			SETCHAR(tE1CUVAL_W->VALCODE,"1");*/

			SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
			SETCHAR(tE1CUVAL_W->CHARC,"P_MARKET");
			SETCHAR(tE1CUVAL_W->CHARC_TXT,"");
			SETCHAR(tE1CUVAL_W->VALUE,"EXPORT");
			SETCHAR(tE1CUVAL_W->VALUE_TXT,"");
			SETCHAR(tE1CUVAL_W->AUTHOR,"");
			SETCHAR(tE1CUVAL_W->VALUE_TO,"");
			SETCHAR(tE1CUVAL_W->VALCODE,"1");
			printf("\n............hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");



			printf("\n...........iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");

			if(thE1CUCOM_W==ITAB_NULL)
			{
				thE1CUCOM_W = ItCreate("E1CUCOM_W",sizeof(E1CUCOM_W), 0, 0);
				if(thE1CUCOM_W == ITAB_NULL)
					printf("\nItCreate E1CUCOM_W");
			}
			else if(ItFree(thE1CUCOM_W) != 0)
				printf("\nItFree E1CUCOM_W");

			tE1CUCOM_W = ItAppLine(thE1CUCOM_W);
			if (tE1CUCOM_W == NULL)
			printf("ItAppLine tE1CUCOM_W");
			/*SETCHAR(tE1CUCOM_W->MSGFN,"023");
			SETCHAR(tE1CUCOM_W->C_PROFILE,"PROFILE FOR 1100_KMAT_01");
			SETCHAR(tE1CUCOM_W->CLASSTYPE,"300");
			SETCHAR(tE1CUCOM_W->STATUS,"1");
			SETCHAR(tE1CUCOM_W->BOMEXPL,"1");
			SETCHAR(tE1CUCOM_W->CHAR_VALU,"2");*/

			SETCHAR(tE1CUCOM_W->MSGFN,"023");
			SETCHAR(tE1CUCOM_W->C_PROFILE,"PROFILE1");
			SETCHAR(tE1CUCOM_W->CLASSTYPE,"300");
			SETCHAR(tE1CUCOM_W->ORGAREAS,"");
			SETCHAR(tE1CUCOM_W->STATUS,"1");
			SETCHAR(tE1CUCOM_W->BOMAPPL,"");
			SETCHAR(tE1CUCOM_W->FLAVAILCH,"");
			SETCHAR(tE1CUCOM_W->BOMEXPL ,"1");
			SETCHAR(tE1CUCOM_W->TASKLEXPL,"");
			SETCHAR(tE1CUCOM_W->INITSCREEN,"");
			SETCHAR(tE1CUCOM_W->FLASSEMBLY,"");
			SETCHAR(tE1CUCOM_W->FLRESULT,"");
			SETCHAR(tE1CUCOM_W->FLMDATA,"");
			SETCHAR(tE1CUCOM_W->FLCASONLY,"");
			SETCHAR(tE1CUCOM_W->FLMANCHANG,"");
			SETCHAR(tE1CUCOM_W->FLHOLDBOM,"");
			SETCHAR(tE1CUCOM_W->FLDELETE,"");
			SETCHAR(tE1CUCOM_W->DESIGN,"");
			SETCHAR(tE1CUCOM_W->NEUTR,"");
			SETCHAR(tE1CUCOM_W->CHAR_VALU,"2");
			SETCHAR(tE1CUCOM_W->A_LAISO,"");
			SETCHAR(tE1CUCOM_W->SCOPE_CHAR,"");
			SETCHAR(tE1CUCOM_W->SCOPE_VALU,"");
			SETCHAR(tE1CUCOM_W->FL_EXCLUDE,"");
			SETCHAR(tE1CUCOM_W->DISPLAY,"");
			SETCHAR(tE1CUCOM_W->PRICING,"");
			SETCHAR(tE1CUCOM_W->CONFIGUR,"");
			SETCHAR(tE1CUCOM_W->DEFVALU_DE,"");
			SETCHAR(tE1CUCOM_W->FL_MARK,"");
			SETCHAR(tE1CUCOM_W->DEFVALU_CC,"");
			SETCHAR(tE1CUCOM_W->TYPM_SEL,"");
			SETCHAR(tE1CUCOM_W->TYPM_STRA,"");
			SETCHAR(tE1CUCOM_W->FL_SC_CHAR,"");
			SETCHAR(tE1CUCOM_W->FL_SC_DEP,"");
			SETCHAR(tE1CUCOM_W->FL_SC_KN,"");
			SETCHAR(tE1CUCOM_W->FL_SC_CMPF,"");
			SETCHAR(tE1CUCOM_W->MULTIL_STRU,"");
			SETCHAR(tE1CUCOM_W->FL_DPSEU,"");
			SETCHAR(tE1CUCOM_W->OB_FIX,"");
			SETCHAR(tE1CUCOM_W->OB_INST,"");
			SETCHAR(tE1CUCOM_W->FL_EOASL,"");
			SETCHAR(tE1CUCOM_W->FL_SAASL,"");
			SETCHAR(tE1CUCOM_W->FL_OBJ_MAT,"");
			SETCHAR(tE1CUCOM_W->FL_OBJ_DOC,"");
			SETCHAR(tE1CUCOM_W->FL_OBJ_CLS,"");
			SETCHAR(tE1CUCOM_W->FL_OBJ_TXT,"");
			SETCHAR(tE1CUCOM_W->FL_SDREL,"");
			SETCHAR(tE1CUCOM_W->FL_KOREL ,"");
			SETCHAR(tE1CUCOM_W->FL_FEREL,"");
			SETCHAR(tE1CUCOM_W->FL_INREL,"");
			SETCHAR(tE1CUCOM_W->FL_KAREL,"");
			SETCHAR(tE1CUCOM_W->POSTYPEN ,"");
			SETCHAR(tE1CUCOM_W->SORTF1,"");
			SETCHAR(tE1CUCOM_W->SORTF2,"");
			SETCHAR(tE1CUCOM_W->SORTF3,"");
			SETCHAR(tE1CUCOM_W->SORTF4,"");
			SETCHAR(tE1CUCOM_W->SORTF5,"");
			SETCHAR(tE1CUCOM_W->CLASSF1,"");
			SETCHAR(tE1CUCOM_W->CLASSF2,"");
			SETCHAR(tE1CUCOM_W->CLASSF3,"");
			SETCHAR(tE1CUCOM_W->CLASSF4,"");
			SETCHAR(tE1CUCOM_W->CLASSF5,"");
			SETCHAR(tE1CUCOM_W->PRIO,"");
			SETCHAR(tE1CUCOM_W->PRSTL,"");
			SETCHAR(tE1CUCOM_W->UMBEW,"");
			SETCHAR(tE1CUCOM_W->FLBROWSER,"");
			SETCHAR(tE1CUCOM_W->FL_PROF_OBOM,"");

			printf("\n...........jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj");

			/*
			SETCHAR(eStlan.Stlan,"2");
			SETCHAR(eStnum.Stnum,"");
			SETCHAR(eStlal.Stlal,"");
			SETCHAR(eChar1.Char1,"");

			printf("\nProcessing [%s;%s;%s]",cMaterial,cPlant,cChangeno);fflush(stdout);
			fprintf(fsuccess,"\nProcessing [%s;%s;%s]",cMaterial,cPlant,cChangeno);*/
			/*thMESSTAB2 = ITAB_NULL;
			if (thMESSTAB2==ITAB_NULL)
			{
				thMESSTAB2 = ItCreate("MESSTAB2",sizeof(MESSTAB2),0,0);
				if (thMESSTAB2==ITAB_NULL)
					rfc_error("ItCreate MESSTAB2");
			}
			else if (ItFree(thMESSTAB2) != 0)
					rfc_error("ItFree MESSTAB2");*/

			if(thRETURNMESSAGES==ITAB_NULL)
			{
				thRETURNMESSAGES = ItCreate("RETURNMESSAGES",sizeof(RETURNMESSAGES), 0, 0);
				if(thRETURNMESSAGES == ITAB_NULL)
					printf("\nItCreate RETURNMESSAGES");
			}
			else if(ItFree(thRETURNMESSAGES) != 0)
				printf("\nItFree RETURNMESSAGES");


			RfcRc = ZMATERIAL_SAVE_CONFIGURATION(hRfc
		,&eMATNR1
		,&eSATNR  
		,&eWerks
		,&eSTDPD
		,&eREVLV
		,&eDATUV
		,&iRETURN
		,thE1CUCFG
		,thE1CUINS
		,thE1CUVAL
		,thE1CUCOM
		,thE1CUCFG_W
		,thE1CUINS_W
		,thE1CUVAL_W
		,thE1CUCOM_W
		,thE1CUCFG_V
		,thE1CUINS_V
		,thE1CUVAL_V
		,thE1CUCOM_V
		,thRETURNMESSAGES
		,xException);

			switch (RfcRc)
			{
				case RFC_OK:


				//for (crow = 1;crow <= ItFill(thMESSTAB2); crow++)
					//{
						/*tMESSTAB2 = ItGetLine(thMESSTAB2,crow);
						if (tMESSTAB2 == NULL)
							rfc_error("ItGetLineBAPIRET2");*/

					GETCHAR(iRETURN.Message,s);
					OUTS("MESSAGE",10,30,s);
					//fprintf(fsuccess,"\nReturn message : %s",s);

					//printf("\tRetval:[%d]",iRetval);fflush(stdout);
					printf("\nno of row fetched thE1CUCFG:[%d]",ItFill(thE1CUCFG));fflush(stdout);
					printf("\nno of row fetched thE1CUINS:[%d]",ItFill(thE1CUINS));fflush(stdout);
					printf("\nno of row fetched thE1CUVAL:[%d]",ItFill(thE1CUVAL));fflush(stdout);
					printf("\nno of row fetched thE1CUCOM:[%d]",ItFill(thE1CUCOM));fflush(stdout);

					printf("\nno of row fetched thE1CUCFG_W:[%d]",ItFill(thE1CUCFG_W));fflush(stdout);
					printf("\nno of row fetched thE1CUINS_W:[%d]",ItFill(thE1CUINS_W));fflush(stdout);
					printf("\nno of row fetched thE1CUVAL_W:[%d]",ItFill(thE1CUVAL_W));fflush(stdout);
					printf("\nno of row fetched thE1CUCOM_W:[%d]",ItFill(thE1CUCOM_W));fflush(stdout);

					printf("\nno of row fetched thRETURNMESSAGES:[%d]\n",ItFill(thRETURNMESSAGES));fflush(stdout);
					//fprintf(fsuccess,"\nno of row fetched:[%d]",ItFill(thRETURNMESSAGES));
					for (crow = 1;crow <= ItFill(thRETURNMESSAGES); crow++)
					{
						tRETURNMESSAGES = ItGetLine(thRETURNMESSAGES,crow);
						if (tRETURNMESSAGES == NULL)
							printf("ItGetLineBAPIRET2");

						GETCHAR(tRETURNMESSAGES->MESSAGE,s);
						OUTS("MESSAGE",10,30,s);
						/*GETCHAR(tRETURNMESSAGES->TCODE,s);
						OUTS("TCODE",10,30,s);
						GETCHAR(tRETURNMESSAGES->DYNAME,s);
						OUTS("DYNAME",10,30,s);
						GETNUM(tRETURNMESSAGES->DYNUMB,s);
						OUTS("DYNUMB",10,30,s);
						GETCHAR(tRETURNMESSAGES->MSGTYP,s);
						OUTS("MSGTYP",10,30,s);
						GETCHAR(tRETURNMESSAGES->MSGSPRA,s);
						OUTS("MSGSPRA",10,30,s);
						GETNUM(tRETURNMESSAGES->MSGID,s);
						OUTS("MSGID",10,30,s);
						GETCHAR(tRETURNMESSAGES->MSGNR,s);
						OUTS("MSGNR",10,30,s);
						GETCHAR(tRETURNMESSAGES->MSGV1,s);
						OUTS("MSGV1",10,30,s);
						GETCHAR(tRETURNMESSAGES->MSGV2,s);
						OUTS("MSGV2",10,30,s);
						GETCHAR(tRETURNMESSAGES->MSGV3,s);
						OUTS("MSGV3",10,30,s);
						GETCHAR(tRETURNMESSAGES->MSGV4,s);
						OUTS("MSGV4",10,30,s);
						GETINT(tRETURNMESSAGES->ENV,s);
						OUTS("ENV",10,30,s);
						GETCHAR(tRETURNMESSAGES->FLDNAME,s);
						OUTS("FLDNAME",10,30,s);*/
						NL;
					}
				break;
				case RFC_EXCEPTION:
					printf("\nRFC Exception : %s",xException);fflush(stdout);
				break;
				case RFC_SYS_EXCEPTION:
					printf("\nSystem Exception Raised!!!");fflush(stdout);
				break;
				case RFC_FAILURE:
					printf("\nFailure!!!");fflush(stdout);
				break;
				default:
					printf("\nOther Failure!");fflush(stdout);
			}
			RfcClose(hRfc);
			//if (ItDelete(thMESSTAB2) != 0)
			 // rfc_error("ItDelete MESSTAB2");
		//}
	}
}
//fclose(fr);
fclose(fsuccess);
RfcClose(hRfc);
/*clLogout();
clTerminate();*/
CLEANUP:
return 0;
}




