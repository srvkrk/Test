/*=============================================================================
                Copyright (c) Siemens
                   Unpublished - All Rights Reserved
===============================================================================
File description:

    Filename: FolderCreateInsert.c
    
	Usecase: Program creates a Folder object in Teamcenter and Active Workspace.
	Then, the program locks, modifies, and unlocks the Folder post creation to
	demonstrate how a modification process works.

		NOTE: This code is for demonstration purposes only. It is recommeneded to set
		all property values prior to creating the object via code versus modifying post
		creation to save in performance. The code below demonstrates a process.

===============================================================================*/

/********************************************************************************
//BEGIN INCLUDES:

	Add included header files. The header files provide access to the functionality
	in each module of the API's. For example, here the emh.h header file is added
	to provide access to the Error Message Handling (EMH) funtionality and APIs.

*********************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/tc_macros.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/tc_util.h>
#include <fclasses/tc_string.h>
#include <stdlib.h>
#include <string.h>
//END INCLUDES


/********************************************************************************
//BEGIN MAIN FUNCTION:

	ITK_user_main is the primary function for C command line utilities in Teamcenter.
	Main functions for all ITK utility.

   TIP: Create your own implementation of this utility to address your needs. The utility will need to be linked with itk_main.o,
   which is done if the linkitk.sh or linkitk.bat script from ADK (Application Development Kit) is called.

   The Teamcenter infrastructure will call your utility ITK_user_main upon execution.

   @param[in] argc The number of input arguments via command line.
   @param[in] argv The array of input arguments via command line.

*********************************************************************************/
int ITK_user_main(int argc, char* argv[]) {
	
	
	/****************************************************************************
	DECLARE VARIABLES: Variables store imporant information for use in other
	functions or to write to the UI for example.

	****************************************************************************/
	
	//Declare variable 'cliFolderName' to store input from user in the command line.
	char*	cliFolderName = NULL;

	//Variable to store the inputed value in preparation to convert to const * &
	char	folderName[WSO_name_size_c +1] = "";

	//Variable array to store display name for folde name.
	char**	stringArray;

	//Tag_t variables to store the tag of the Folder type [ template ]
	//The 'folderCreInTag' stores the Create Input element of the Folder object type.
	//The 'newFolderTag' stores the new Folder in preparation for creation in the database.
	tag_t	folderTypeTag = NULLTAG,
			folderCreInTag = NULLTAG,
			newFolderTag = NULLTAG;

	//Provides Journaling files to capture data regarding custom code into Journal Files [ optional ]
	ITKCALL(ITK_set_journalling(TRUE));

	//Necessary for retrieving text strings for errors [ reommended if using the EMH module or other modules which call to it ].
	ITKCALL(ITK_initialize_text_services (0));
	
	//Obtain the Name of the Folder via the command line arguments. The "-n=" value will be the name of the Folder.
	//Store the value into the cliFolderName variable
	cliFolderName = ITK_ask_cli_argument("-n=");

	//Determine if the the "-n-" value was entered to the command line. If [ NULL ] then provide feedback to the user and exit the program.
	//Else, copy the value with the correct size or number of characters to the folderName variable.
	if( cliFolderName == NULL )	{	
		ITKCALL(TC_printf("\nMust provide a Folder name at the command line.\n"));
		ITKCALL(TC_printf("Example: FolderCreateInsert -n=\"New Folder\"\n" ));
		return -1;
	}else{	
		tc_strncpy( folderName, cliFolderName, WSO_name_size_c );
		TC_printf("Attempting to create Folder named: %s\n", folderName);
	}

	//Prepare the "stringArray" to contain 1 value at index [0].
	stringArray = MEM_alloc( sizeof *stringArray );
	
	//Print out to inform the user regarding the upcoming attempt to login to the Teamcenter/Active Workspace server.
	ITKCALL(TC_printf("\nAttempting auto login to Teamcenter...\n"));

	//Connect and Login to the Teamcenter | Active Workspace server. An alternate function is ITK_init_module();
	//If using ITK_auto_login, optimize the login process with the TC_auto_login preference set to true in Development Environments.
	ITKCALL(ITK_auto_login ());
	
	//Provide feedback that the login was successfull.
	ITKCALL(TC_printf("\nLogin Successful.\n"));
	ITKCALL(TC_printf("\nHello Teamcenter !!!\n"));
	

	//Locate the type tag for a folder object. Think of this like obtaining the template to define a Folder.
	ITKCALL( TCTYPE_find_type( "Folder", NULL, &folderTypeTag) );

	//Create a Create Input oject to update display values such as object name and object desc.
	ITKCALL( TCTYPE_construct_create_input( folderTypeTag, &folderCreInTag) );

	//Take the 'folderName' value and store it [copy] it to the 'stringArrary[0]. This is to ensure the parameter
	//is set to correct parameter character type.
	tc_strcpy( stringArray[0], folderName );
	ITKCALL( TCTYPE_set_create_display_value( folderCreInTag, "object_name", 1, stringArray) );
	
	//Create the new folder in memory and store in the 'newFolderTag' tag_t.
	ITKCALL( TCTYPE_create_object( folderCreInTag, &newFolderTag) );

	//Use either the AOM_save_with_extensions or AOM_save_without_extensions functions to save the new folder.
	ITKCALL( AOM_save_with_extensions(newFolderTag) );

	//Release the lock on the new object to enable users to work with it.
	ITKCALL( AOM_unlock(newFolderTag) );

	//[optionally] Place the new Folder object into the running user's Newstuff Folder.
	ITKCALL(FL_user_update_newstuff_folder(newFolderTag));

	/**************************************************************************************************
	MODIFICATION PROCESS:
	The process below is to be used to lock, modify, save, and released.
	***************************************************************************************************/

	//Lock the object so noone else can modify while the program.
	ITKCALL( AOM_lock(newFolderTag) );

	//With the object locked, use the 'AOM_set_value_string' function to update the 'object_desc' property on the object.
	ITKCALL( AOM_set_value_string(newFolderTag, "object_desc", "Modified after creation") );

	//Use either the AOM_save_with_extensions or AOM_save_without_extensions functions to save the new folder.
	ITKCALL( AOM_save_without_extensions(newFolderTag) );

	//Release the object lock to enable user editting or modification.
	ITKCALL( AOM_unlock(newFolderTag) );

	//Free the memory allocated by 'MEM_alloc" earlier in the file.
	MEM_free(stringArray);
	
	//Log off of the Teamcenter Server.
	ITK_exit_module(TRUE);
	
	//Return ITK_ok.
	return ITK_ok;
}


