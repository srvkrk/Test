/*=============================================================================
				Copyright (c) Siemens
				   Unpublished - All Rights Reserved
===============================================================================
File description:

	Filename: HelloTc.c

	Usecase: Program connects to and logs into the [ Teamcenter | Active Workspace ]
	Server. Upon a successful connection and login, the program prints a message
	to the user in the command line.

		NOTE: This code is for [ demonstration | training ] purposes only.
		Code defined for training may need reworked prior to implementing to a
		production environment to optimize for release.

===============================================================================*/

/********************************************************************************
//BEGIN INCLUDES:

	Add included header files. The header files provide access to the functionality
	in each module of the API's. For example, here the emh.h header file is added
	to provide access to the Error Message Handling (EMH) funtionality and APIs.

*********************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tc/tc_util.h>
#include <tc/tc_macros.h>

/********************************************************************************
//BEGIN MAIN FUNCTION:

	ITK_user_main is the primary function for C command line utilities in Teamcenter.
	Main functions for all ITK utility.

	TIP: Create your own implementation of this utility to address your needs. The utility will need to be linked with itk_main.o,
	which is done if the linkitk.sh or linkitk.bat script from ADK (Application Development Kit) is called.

	The Teamcenter infrastructure will call your utility ITK_user_main upon execution.

	@param[in] argc The number of input arguments via command line.
	@param[in] argv The array of input arguments via command line.

*********************************************************************************/
int ITK_user_main(int argc, char* argv[]){

	
	/************************************************************************************************************************
	//ITKCALL INTRODUCTION:
		
		The 'ITKCALL' macro is called to provide a standardized method of error handling. To use the 'ITKCALL' macro for
		error handling the #include <tc/tc_macros.h> include must be added.

		'TC_printf' writes a message to the command line. In this case to let the user know about the attempt to login.
	*************************************************************************************************************************/
	TC_printf("\n\t ------ Attempting auto login to Teamcenter -----\t\n\n");

	
	//Connect and Login to the Teamcenter | Active Workspace server. An alternate function is ITK_init_module();
	//If using ITK_auto_login, optimize the login process with the TC_auto_login preference set to true in Development Environments.
	ITKCALL(ITK_auto_login());
	
	//If the login is successful in the ITK_auto_login function, print status messages to the user in the command line.
	TC_printf("\n\t ------ Login Successful -----\t\n\n");		
	TC_printf("\n\t ------ Hello Teamcenter -----\t\n\n");
	
	//Terminate the session
	ITK_exit_module(TRUE);
	
	return ITK_ok;
}