/*=============================================================================
                Copyright (c) 2010 Siemens PLM Software
                   Unpublished - All Rights Reserved
===============================================================================
File description:

    Filename: GRMList.c
    Module  : TRN9
	Author	: S Susewitt
	Date	: Jun 21, 2012

===============================================================================*/

#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/workspaceobject.h>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <tc/tc_util.h>
#include <fclasses/tc_string.h>




int ITK_user_main(int argc, char* argv[])
{
	int   status;
	char* message;

	int idx;
    WSO_search_criteria_t wsoCriteria;
    int iHits = 0;
    tag_t *aTagLst = NULLTAG;
	GRM_relation_t *relObjTags = NULLTAG;
	char *objName;
	char typeName[TCTYPE_name_size_c+1];

	ITK_set_journalling(TRUE);
	ITK_initialize_text_services (0);
	


	//
	// LOGIN TO TEAMCENTER
	//
	TC_printf("\nAttempting auto login to Teamcenter...\n");

	status = ITK_auto_login ();
	if (status != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);

		TC_printf("%3d error(s) with ITK_auto_login\n", n_ifails);

		for( index=0; index<n_ifails; index++)
		{
			TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return status;
	}
	else
	{
		TC_printf("\nLogin Successful.\n");
		TC_printf("\nHello Teamcenter !!!\n");
	}
	


	//
	// PREPARE THE CRITERIA OBJECT
	//
	TC_printf("Preparing search criteria...\n");

	if( WSOM_clear_search_criteria(&wsoCriteria) != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);

		TC_printf("%3d error(s) with WSOM_clear_search_criteria\n", n_ifails);

		for( index=0; index<n_ifails; index++)
		{
			TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);

			TC_write_syslog("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return ifails[0];
	}


    tc_strncpy( wsoCriteria.class_name, "DocumentRevision", sizeof(wsoCriteria.class_name) - 1 );
    tc_strncpy( wsoCriteria.name, "MSWord", sizeof(wsoCriteria.name) - 1 );



	//
	// EXECUTE THE SEARCH
	//

	TC_printf("Executing search...\n");

	if( WSOM_search( wsoCriteria, &iHits, &aTagLst ) != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);

		TC_printf("%3d error(s) with WSOM_search\n", n_ifails);

		for( index=0; index<n_ifails; index++)
		{
			TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);
			TC_write_syslog("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return ifails[0];
	}
	if( iHits == 0 )
	{
		TC_printf("\tDocumentRevision \"MSWord\" not found.\n");
		return ITK_ok;
	}


	//
	// RETRIEVE RELATED OBJECTS
	//
	TC_printf("Retrieving related objects...\n");

	if( GRM_list_secondary_objects( aTagLst[0], NULLTAG, &iHits, &relObjTags) != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);

		TC_printf("%3d error(s) with GRM_list_secondary_objects\n", n_ifails);

		for( index=0; index<n_ifails; index++)
		{
			TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);
			TC_write_syslog("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return ifails[0];
	}
	TC_printf("\t%d relations found.\n", iHits);
	if( iHits == 0 )
		return ITK_ok;



	//
	// DISPLAY RELATIONS
	//
	TC_printf("Displaying related objects...\n");
	TC_printf("\n\t%3s%30s%30s%30s\n", "#", "Rel Type", "Name", "Type");

	for( idx=0; idx<iHits; idx++ )
	{
		TC_printf("\t%3d", idx+1);
		TCTYPE_ask_name( relObjTags[idx].relation_type, typeName);

		TC_printf("%30s", typeName);
		AOM_ask_value_string( relObjTags[idx].secondary, "object_name", &objName);
		TC_printf("%30s", objName);

		AOM_ask_value_string( relObjTags[idx].secondary, "object_type", &objName);
		TC_printf("%30s\n", objName);
	}



	//
	// CLEANUP
	//
	MEM_free( aTagLst );
	MEM_free( relObjTags );



	ITK_exit_module(TRUE);
	
	return status;
}


