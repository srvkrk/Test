#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <vector>
#include <string>


#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tc/tc_util.h>
#include <fclasses/tc_string.h>

#include <qry/qry.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			TC_printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\




static int RunSavedQuery(
						void
						);




int ITK_user_main(int /*argc*/, char** /*argv[]*/)
{
	int    status;
	char* message;

	ITK_initialize_text_services (0);

	ITK_CALL(ITK_auto_login ());

	ITK_set_journalling (TRUE);

	/* Call your function(s) here.  */

	RunSavedQuery();


	ITK_exit_module (TRUE);

	return status;
}





static int RunSavedQuery( void )
{
	int    status, index, critEntries;
	char* message;

	tag_t queryTag	= NULLTAG;

	int		entryCount;
	char**	entryNames;
	char**	entryValues;

	int		resultCount;
	tag_t*	resultTags;
	char*	resultName;
	char*	resultID;




	//*********************************************
	// LOCATE QUERY
	//*********************************************

	std::string sQueryName = "Item Revision...";

	std::cout << "\tLooking for Saved Query: " << sQueryName << std::endl;
	ITK_CALL( QRY_find2(sQueryName.c_str(), &queryTag) );
	std::cout << "\t\tFound." << std::endl;



	//*********************************************
	// DISPLAY THE VALUE ENTRIES, JUST FYI
	//*********************************************

	std::cout << "\tLooking for available criteria for (" << sQueryName << "): " << std::endl;
	ITK_CALL( QRY_find_user_entries(queryTag, &entryCount, &entryNames, &entryValues) );
	if( entryCount )
	{
		for( index=0; index<entryCount; index++ )
		{
			std::cout << "\t\t" << entryNames[index] << std::endl;
		}
		MEM_free(entryNames);
		MEM_free(entryValues);
	}
	else
	{
		std::cout << "/t/tNONE FOUND!" << std::endl;
	}


	//*********************************************
	// BUILD THE CRITERIA ARRAYS
	//*********************************************

	std::cout << "\tBuilding criteria arrays: ";

	/* Initialize arrays */

	std::vector<std::string> vCritNames;
	std::vector<std::string> vCritValues;

	vCritNames.clear();
	vCritValues.clear();


	//
	// MODIFY THIS SECTION
	//
	/* Add as many pairs as needed. */

	vCritNames.push_back("Item ID");
	vCritValues.push_back("0*");

	vCritNames.push_back("Revision");
	vCritValues.push_back("A");

	vCritNames.push_back("Owning User");
	vCritValues.push_back("infodba");



	/* Double-check there are pairs */
	if( vCritNames.size() == vCritValues.size() )
	{
		critEntries = vCritNames.size();
		std::cout << critEntries << " pairs" << std::endl;
		for( int index=0; index<critEntries; index++ )
			std::cout << "\t\t" << vCritNames[index] << " = " << vCritValues[index] << std::endl;
	}
	else
	{
		std::cout << std::endl << "\t\t" << "MISMATCHED PAIRS!" << std::endl;
		return -1;
	}


	/* Convert vector<string> to char** */
	char** critNames = new char*[vCritNames.size()];
	for( index=0; index<vCritNames.size(); index++)
	{	critNames[index] = new char[vCritNames[index].size()+1];
		strncpy(critNames[index], vCritNames[index].c_str(), vCritNames[index].size()+1 );
	}

	char** critValues = new char*[vCritValues.size()];
	for( index=0; index<vCritValues.size(); index++)
	{	critValues[index] = new char[vCritValues[index].size()+1];
		strncpy(critValues[index], vCritValues[index].c_str(), vCritValues[index].size()+1 );
	}




	//*********************************************
	// EXECUTE THE QUERY
	//*********************************************


	std::cout << "\tExecuting (" << sQueryName << "): " << std::endl;
	ITK_CALL( QRY_execute(queryTag, critEntries, critNames, critValues, &resultCount, &resultTags) );

	std::cout << "\t\t" << resultCount << " Results" << std::endl;
	for( index=0; index<resultCount; index++ )
	{
		ITK_CALL( AOM_ask_name(resultTags[index], &resultName) );
		ITK_CALL( AOM_ask_value_string(resultTags[index], "item_id", &resultID) );
		TC_printf("%7d - %s %s\n", index+1, resultID, resultName);
	}




	//*********************************************
	// CLEANUP  (OF & NEW)
	//*********************************************

	MEM_free(resultName);
	MEM_free(resultTags);

	for( index=0; index<vCritNames.size(); index++)
		delete[] critNames[index];
	delete[] critNames;



	return ITK_ok;
}