#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>

#include <qry/qry.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>



#define NUM_ENTRIES 3

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			TC_printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\






static int RunSavedQuery(				/* Function used to List Saved Queries*/
						void
						);




int ITK_user_main(int argc, char* argv[])
{
	int    status;
	char* message;

	ITK_initialize_text_services (0);

	ITK_CALL(ITK_auto_login ());

	ITK_set_journalling (TRUE);

	/* Call your function(s) here.  */

	RunSavedQuery();


	ITK_exit_module (TRUE);
	return status;
}




static int RunSavedQuery( void )
{
	int 	status, index;
	char*	resultName;

	int		entryCount;
	char**	entryNames;
	char**	entryValues;

	tag_t	queryTag	= NULLTAG;
	char**	critNames;
	char**	critValues;
	int		resultCount;
	tag_t*	resultTags;


	char	entryNamesArray[NUM_ENTRIES][QRY_uid_name_size_c+1]	= { "Item ID", "Owning User", "Revision" };
	char	entryValuesArray[NUM_ENTRIES][QRY_clause_size_c+1]	= { "*", "Students", "A" };

	//*********************************************
	// BUILD THE CRITERIA ARRAYS
	//*********************************************

	critNames = malloc( NUM_ENTRIES * sizeof *critNames );
	for( index=0; index<NUM_ENTRIES; index++ )
	{
		critNames[index] = malloc( strlen(entryNamesArray[index] + 1) );
		if( critNames[index] )
			tc_strcpy( critNames[index], entryNamesArray[index] );
	}

	critValues = malloc( NUM_ENTRIES * sizeof *critValues );
	for( index=0; index<NUM_ENTRIES; index++ )
	{
		critValues[index] = malloc( strlen(entryValuesArray[index] + 1) );
		if( critValues[index] )
			tc_strcpy( critValues[index], entryValuesArray[index] );
	}


	//*********************************************
	// LOCATE QUERY
	//*********************************************

	ITK_CALL( QRY_find("Item Revision...", &queryTag) );
	TC_printf("\tFound Item Revision... query.\n");



	//*********************************************
	// DISPLAY THE VALUE ENTRIES, JUST FYI
	//*********************************************

	ITK_CALL( QRY_find_user_entries(queryTag, &entryCount, &entryNames, &entryValues) );
	
	TC_printf("\tPossible Criteria for this Query:\n");
	
	for( index=0; index<entryCount; index++ )
	{
		TC_printf("\t\t%s\n", entryNames[index]);
	}
	
	
	MEM_free(entryNames);
	MEM_free(entryValues);


	//*********************************************
	// DISPLAY THE CRITERIA
	//*********************************************

	TC_printf("\tUsed Criteria:\n");
	
	for( index=0; index<NUM_ENTRIES; index++ )
	{
		TC_printf("\t\t%s \t= %s\n", critNames[index], critValues[index]);
	}


	//*********************************************
	// EXECUTE THE QUERY
	//*********************************************

	ITK_CALL( QRY_execute(queryTag, NUM_ENTRIES, critNames, critValues, &resultCount, &resultTags) );

	TC_printf("\n%d Results\n", resultCount);
	if( resultCount )
	{
		for( index=0; index<resultCount; index++ )
		{
			ITK_CALL( AOM_ask_name(resultTags[index], &resultName) );
			TC_printf("%7d - %s\n", index+1, resultName);
		}
		
		MEM_free(resultName);
		MEM_free(resultTags);
	}


	return ITK_ok;
}
