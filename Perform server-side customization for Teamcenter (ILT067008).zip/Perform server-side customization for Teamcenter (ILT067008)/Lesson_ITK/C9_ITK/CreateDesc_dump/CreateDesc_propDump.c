#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tc/tc_util.h>
#include <fclasses/tc_string.h>

#include <tccore/tctype.h>

#include <pom/pom/pom.h>
#include <property/propdesc.h>
#include <constants/constants.h>



#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			TC_printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\



static int GetUserString(
		const char *pPrompt,      /* Input : Prompt the user with this message */
		char *pInput,             /* Output : Input supplied by the user */
		int iInputSz              /* Input : size of the pInput Array */
);


static int GetCreateDesc(				/* Function used to create the items */
						void
						);

static int listCreDescProps(		/* Function to display properties from a Create Descriptor */
						tag_t CreDescTag,
						int level
						);





int ITK_user_main(int argc, char* argv[])
{
	int    status;
	char* message;

	ITK_initialize_text_services (0);

	ITK_CALL(ITK_auto_login ());

	TC_printf("Auto login to Teamcenter successful.\n");

	ITK_set_journalling (TRUE);

	/* Call your function(s) here.  */

	GetCreateDesc();


	ITK_exit_module (TRUE);
	return status;
}






static int GetCreateDesc( void )
{
	int		status;
	int		index;

	char	boTypeName[WSO_name_size_c +1];

	tag_t	ItemTypeTag;
	tag_t	CreDescTag;

	GetUserString( "Which object type [End]:\t",boTypeName, sizeof(boTypeName) );

	ITK_CALL(TCTYPE_find_type( boTypeName, NULL, &ItemTypeTag ));

	ITK_CALL(TCTYPE_ask_create_descriptor( ItemTypeTag, &CreDescTag ));

	listCreDescProps( CreDescTag, 0 );

	return ITK_ok;
}



static int listCreDescProps( tag_t CreDescTag, int level )
{
	int			index1, index2, status;
	char*		prefix="";

	int			n_propDescTags;
	tag_t*		propDescTags;
	int			n_secPropNames;
	char**		secPropNames;
	tag_t*		secBOTypeTags;
	logical*	isRequired;
	logical*	isArray;
	int*		compoundingCtxts;
	tag_t*		secCreateDescTags;
	logical		propConstReqBool;


	ITK_CALL(TCTYPE_ask_create_prop_descriptors ( CreDescTag,
			&n_propDescTags, &propDescTags,
			&n_secPropNames, &secPropNames, &secBOTypeTags,
			&isRequired, &isArray, &compoundingCtxts,
			&secCreateDescTags));;


	prefix[0] = '\0';
	for( index1=0; index1<(level+1); index1++)
	{
		tc_strcat( prefix, "\t" );
	}

	TC_printf("\n\n%s===============================================\n", prefix);
	TC_printf("%sNumber of properties on Create Descriptor: %d\n", prefix, n_propDescTags);

	for( index1=0; index1<n_propDescTags; index1++ )
	{
		char*		propName;
		PROP_type_t valtype;
		char*		valtypeName;
		char*		propConstReq;

		TC_printf("%s", prefix );

		ITK_CALL(PROPDESC_is_required( propDescTags[index1], &propConstReqBool ));
		TC_printf("- REQ: %d", propConstReqBool);

		ITK_CALL(PROPDESC_ask_name( propDescTags[index1], &propName ));
		TC_printf("- %32s", propName);

		ITK_CALL(PROPDESC_ask_value_type( propDescTags[index1], &valtype, &valtypeName ));
		TC_printf("- %s", valtypeName);

		TC_printf("\n");
	}


	TC_printf("\n%sNumber of relation props : %d\n\n", prefix, n_secPropNames);
	for( index1=0; index1<n_secPropNames; index1++ )
	{
		char typeName[TCTYPE_name_size_c + 1];

		prefix[0] = '\0';
		for( index2=0; index2<(level+1); index2++)
		{
			strcat( prefix, "\t" );
		}
		TC_printf("\t%s", prefix );
		TC_printf("%s", (isRequired[index1]?"REQ":""));
		TC_printf("\t- %s", secPropNames[index1]);
		ITK_CALL( TCTYPE_ask_name(secBOTypeTags[index1], typeName) );
		TC_printf("\t- %s", typeName );
		listCreDescProps( secCreateDescTags[index1], level+1 );
	}

	return ITK_ok;
}





static int
GetUserString( const char *pPrompt, char *pInput, int iInputSz )
/*
 * PURPOSE : Gather Generic Input from a user
 *
 * RETURN : Information input from the user on pIrompt and the length of
 *          the new stream in the return portion.
 *
 * NOTES : requires the size of the input array and uses fgets to read
 *         from the input stream stdin. Must call fflush to clear the buffer
 *         between calls. Any input of only a \n is overwritten with '\0'
 */
{
	register int i=0;
	fflush(stdout);
	fflush(stderr);
	TC_printf("%s", pPrompt);
	fflush(stdout);
	fflush(stderr);
	fgets(pInput, iInputSz, stdin );
	fflush(stdin);

	for( i=0; i<iInputSz; i++)
	{
		if( pInput[i] == '\n' )
		{
			pInput[i] = '\0';
		}
	}

	return (int) strlen( pInput );
}
