#include <string.h>

#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/workspaceobject.h>
#include <tc/tc_util.h>
#include <fclasses/tc_string.h>

//
// DECLARE FUNCTION
//
static void PrintWsoDesc(
    const WSO_description_p_t pWsoDesc, /* Input : description pointer */
    int iCurObj,                        /* Input : Current object being printed */
    int iTotObj                         /* Input : Total number of objects */
);

//
// MAIN PROGRAM
//
int ITK_user_main(int argc, char* argv[])
{	
	int idx = 0;
	char *cliObjType = NULL;
	char *cliObjName = NULL;

    int iHits = 0;
    char aObjType[WSO_name_size_c + 1] = { "" };
    char aObjName[WSO_name_size_c + 1] = { "" };
    WSO_search_criteria_t wsoCriteria;
    WSO_description_t wsoDesc;
    tag_t *aTagLst = NULLTAG;


	TC_printf("\n\nBEGIN\n====================\n");

	//
	// GET TYPE AND NAME FROM COMMAND LINE
	//
	cliObjType = ITK_ask_cli_argument("-t=");
	cliObjName = ITK_ask_cli_argument("-n=");


	// VALIDATE TYPE AND NAME ARE FILLED OUT
	if( (cliObjType == NULL) || (cliObjName == NULL) )
	{	
		
		TC_printf("\nMust privide an Object Type and Object Name at the command line.\n");
		TC_printf("Example: WSOMQuery -t=\"Item\" -n=\"Sample Item\"\n" );
		return -1;
	}
	else
		TC_printf("Looking for %s(s) with name of: %s\n", cliObjType, cliObjName);




	//
	// LOGIN TO TEAMCENTER
	//
	TC_printf("Logging into Teamcenter...\n");
	
	if( ITK_auto_login() != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		TC_printf("%3d error(s) with ITK_auto_login\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);
			TC_write_syslog("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return ifails[0];
	}


	//
	// PREPARE THE CRITERIA OBJECT
	//
	TC_printf("Preparing search criteria...\n");

	if( WSOM_clear_search_criteria(&wsoCriteria) != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);

		TC_printf("%3d error(s) with WSOM_clear_search_criteria\n", n_ifails);

		for( index=0; index<n_ifails; index++)
		{
			TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);
			TC_write_syslog("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return ifails[0];
	}

	// Takes the Character Array and Stores value as String to class_name / name attributes of criteria structure.
    tc_strncpy( wsoCriteria.class_name, cliObjType, sizeof(wsoCriteria.class_name) - 1 );
    tc_strncpy( wsoCriteria.name, cliObjName, sizeof(wsoCriteria.name) - 1 );


	//
	// EXECUTE THE SEARCH
	//
	TC_printf("Executing search...\n");

	if( WSOM_search( wsoCriteria, &iHits, &aTagLst ) != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		
		TC_printf("%3d error(s) with WSOM_search\n", n_ifails);

		for( index=0; index<n_ifails; index++)
		{
			TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);
			TC_write_syslog("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return ifails[0];
	}


	//
	// DISPLAY NUMBER OF RESULTS
	//
	if ( iHits == 0 )
		TC_fprintf( stdout, "\tNo Items Found\n" );
	else if ( iHits == 1 )
		TC_fprintf( stdout, "\tOne Item Found\n" );
	else
		TC_fprintf( stdout, "\t%d Items Found\n", iHits );


	//
	// OBJECT(S) PROPERTY DUMP
	//
	for ( idx = 0; idx < iHits; idx++ )
	{
		if( WSOM_describe( aTagLst[idx], &wsoDesc ) != ITK_ok )
		{
			int				index = 0;
			int				n_ifails = 0;
			const int*		severities = 0;
			const int*		ifails = 0;
			const char**	texts = NULL;
			
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
			
			TC_printf("%3d error(s) with WSOM_search\n", n_ifails);

			for( index=0; index<n_ifails; index++)
			{
				TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);
				TC_write_syslog("\tError #%d, %s\n", ifails[index], texts[index]);
			}
			return ifails[0];
		}
		PrintWsoDesc( &wsoDesc, idx, iHits );
	}



	//
	// CLEAN UP (OF)
	//
	MEM_free( aTagLst );

	TC_printf("====================\nEND\n");

	return ITK_ok;
}






static void
PrintWsoDesc( const WSO_description_p_t pWsoDesc, int iCurObj, int iTotObj  )
/*
*
* PURPOSE : Function to print out a WSO_description structure
*
* RETURN : Returns nothing
*
* NOTES : I use tabs to space. On a terminal with non standard tabbing. The
*         columns may not come out aligned properly
*
*/
{
    TC_fprintf( stdout,
        "\n\n|--------------------------------------------------------|" );
    TC_fprintf( stdout,
          "\n|\n| Object (%0d/%0d)\n|", iCurObj+1, iTotObj );
    TC_fprintf( stdout,
        "" );
    TC_fprintf( stdout, "\n| Object Name:\t\t%s", pWsoDesc->object_name );
    TC_fprintf( stdout, "\n| Object Type:\t\t%s", pWsoDesc->object_type );
    TC_fprintf( stdout, "\n| Owner's Name:\t\t%s", pWsoDesc->owners_name );
    TC_fprintf( stdout, "\n| Owning Group:\t\t%s", pWsoDesc->owning_group_name );
    TC_fprintf( stdout, "\n| Description:\t\t%s", pWsoDesc->description );
    TC_fprintf( stdout, "\n| Date Created:\t\t%s", pWsoDesc->date_created );
    TC_fprintf( stdout, "\n| Date Modified:\t%s", pWsoDesc->date_modified );
    TC_fprintf( stdout, "\n| Application:\t\t%s", pWsoDesc->application );
    TC_fprintf( stdout, "\n| Date Released:\t%s", pWsoDesc->date_released );
    TC_fprintf( stdout, "\n| Released For:\t\t%s", pWsoDesc->released_for );
    TC_fprintf( stdout, "\n| ID String:\t\t%s", pWsoDesc->id_string );
    TC_fprintf( stdout, "\n| Revision Number:\t%d", pWsoDesc->revision_number );
    TC_fprintf( stdout, "\n| Revision Limit:\t%d", pWsoDesc->revision_limit );
    TC_fprintf( stdout, "\n| Last Modifier:\t%s", pWsoDesc->last_modifying_user_name );
    TC_fprintf( stdout, "\n| Archive Date:\t\t%s", pWsoDesc->archive_date );
    TC_fprintf( stdout, "\n| Backup Date:\t\t%s", pWsoDesc->backup_date );
    TC_fprintf( stdout, "\n| Is Frozen:\t\t%d", pWsoDesc->is_frozen );
    TC_fprintf( stdout, "\n| Is Reserved:\t\t%d", pWsoDesc->is_reserved );
    TC_fprintf( stdout, "\n| Revision ID:\t\t%s", pWsoDesc->revision_id );

    TC_fprintf( stdout,
        "\n|--------------------------------------------------------|\n" );
}