#include <stdlib.h>
#include <stdio.h>

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tc/tc_util.h>
#include <fclasses/tc_string.h>

#include <tccore/tctype.h>
#include <pom/pom/pom.h>
#include <property/propdesc.h>
#include <constants/constants.h>
#include <tccore/aom_prop.h>
#include <tc/folder.h>
#include <tccore/item.h>
#include <tccore/aom.h>



#define ITK_CALL(X) 							\
		TC_printf(#X);							\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			TC_printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				TC_printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			TC_printf("\tSUCCESS\n");				\
		}										\


static int GetUserString(
							const char *pPrompt,      /* Input : Prompt the user with this message */
							char *pInput,             /* Output : Input supplied by the user */
							int iInputSz              /* Input : size of the pInput Array */
							);


static int CreateItem( void ); /* Function used to create the item */
						


// MAIN PROGRAM FUNCTION (COMMAND LINE ONLY)
int ITK_user_main(int argc, char* argv[])
{
	int    status;
	char* message;


	// CREATE SESSION & LOGIN
	ITK_CALL(ITK_auto_login ());

	/* Call your function(s) here.  */
	CreateItem();

	// EXIT SESSION
	ITK_exit_module (TRUE);

	return status;
}



// CUSTOM FUNCTION TO CREATE ITEM
static int CreateItem( void )
{

	int		index, status;
	int		n_strings = 1;
	int		l_strings = 128;			// Arbitrary values - Please verify proper lengths for your application!
	int		tempStrLength = 128;		// Arbitrary values - Please verify proper lengths for your application!

	tag_t	itemTypeTag, itemMstrTypeTag, itemRevTypeTag, itemRevMstrTypeTag;
	tag_t	itemCreInTag, itemMstrCreInTag, itemRevCreInTag, itemRevMstrCreInTag;
	tag_t	newItemTag;

	char**	stringArray = NULL;
	char*	tempString = NULL;

	char	ItmId[ITEM_id_size_c +1];
	char	RevId[ITEM_id_size_c +1];

	char	typeName[TCTYPE_name_size_c +1];

	stringArray = malloc( n_strings * sizeof *stringArray );
	for( index=0; index<n_strings; index++ )
	{
		stringArray[index] = malloc( l_strings + 1 );
	}

	tempString = MEM_alloc( tempStrLength + 1 );


	// RETRIEVE COMMAND LINE ENTRIES FOR ITEM ID, AND REVISION ID
	GetUserString( "Enter the Item ID: ", ItmId, sizeof(ItmId) ); // ITEM ID IS STORED IN: ItmId
	GetUserString( "Enter the Rev  ID: ", RevId, sizeof(RevId) ); // ITEM REVISION ID IS STORED IN: RevID


	/***********************************************************************/
	// GET ALL OBJECT TYPES: Item, Item Master, Revision, Revision Master
	/***********************************************************************/

	ITK_CALL( TCTYPE_find_type( "Item", NULL, &itemTypeTag) ); // STORES TYPEDEF OF ITEM TYPE
	ITK_CALL( TCTYPE_find_type( "ItemRevision", NULL, &itemRevTypeTag) ); // STORES TYPEDEF OF ITEM REVISION TYPE


	/***********************************************************************/
	// CREATE INPUT OBJECTS FOR ALL OBJECT TYPES
	/***********************************************************************/

	ITK_CALL( TCTYPE_construct_create_input( itemTypeTag, &itemCreInTag) );
	ITK_CALL( TCTYPE_construct_create_input( itemRevTypeTag, &itemRevCreInTag) );


	/***********************************************************************/
	// BUILD THE ITEM INPUT STRUCTURE
	/***********************************************************************/

	ITK_CALL( AOM_tag_to_string(itemRevCreInTag, &tempString) );
	tc_strncpy( stringArray[0], tempString, l_strings );
	ITK_CALL( TCTYPE_set_create_display_value( itemCreInTag, "revision", 1, stringArray) );


	/***********************************************************************/
	// POPULATE SYSTEM REQUIRED PROPERTIES
	/***********************************************************************/

	tc_strncpy( stringArray[0], ItmId, l_strings );
	ITK_CALL( TCTYPE_set_create_display_value( itemCreInTag, "item_id", 1, stringArray) );

	tc_strncpy( stringArray[0], "Test Item from ITK", l_strings);
	ITK_CALL( TCTYPE_set_create_display_value( itemCreInTag, "object_name", 1, stringArray) );

	tc_strncpy( stringArray[0], RevId, l_strings );
	ITK_CALL( TCTYPE_set_create_display_value( itemRevCreInTag, "item_revision_id", 1, stringArray) );


	/***********************************************************************/
	// POPULATE OPTIONAL PROPERTIES
	/***********************************************************************/

	tc_strncpy( stringArray[0], "New and Improved! Now made with TCType!", l_strings);
	ITK_CALL( TCTYPE_set_create_display_value( itemCreInTag, "object_desc", 1, stringArray) );

	/***********************************************************************/
	// CREATE ITEM
	/***********************************************************************/

	ITK_CALL( TCTYPE_create_object( itemCreInTag, &newItemTag) );
	ITK_CALL( AOM_save_with_extensions(newItemTag) );
	ITK_CALL( AOM_unlock(newItemTag) );
	ITK_CALL( FL_user_update_newstuff_folder(newItemTag) );


	/***********************************************************************/
	// CLEANUP
	/***********************************************************************/

	for( index=0; index<n_strings; index++ )
	{
		free(stringArray[index]);
	}
	
	free(stringArray);

	MEM_free(tempString);

	return ITK_ok;
}




static int GetUserString( const char *pPrompt, char *pInput, int iInputSz )
/*
 * PURPOSE : Gather Generic Input from a user
 *
 * RETURN : Information input from the user on pIrompt and the length of
 *          the new stream in the return portion.
 *
 * NOTES : requires the size of the input array and uses fgets to read
 *         from the input stream stdin. Must call fflush to clear the buffer
 *         between calls. Any input of only a \n is overwritten with '\0'
 */
{
	register int i=0;
	fflush(stdout);
	fflush(stderr);
	TC_printf("%s", pPrompt);
	fflush(stdout);
	fflush(stderr);
	TC_fgets(pInput, iInputSz, stdin );
	fflush(stdin);

	for( i=0; i<iInputSz; i++)
	{
		if( pInput[i] == '\n' )
		{
			pInput[i] = '\0';
		}
	}

	return (int) strlen( pInput );
}
