//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension C9_WFVerify
 *
 */
#include <C9_VerifyHandler/C9_WFVerify.hxx>

#include <epm/epm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/envelope.h>
#include <tc/folder.h>
#include <tccore/tctype.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <tc/tc_util.h>
#include <fclasses/tc_string.h>

#include <metaframework/OperationInput.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <tc/Envelope.hxx>

//#include <common/emh_const.h>
//#define C9_ItemRev_Prop_Fail (EMH_USER_error_base + 2)

#ifdef __cplusplus
extern "C" {
#endif

EPM_decision_t C9_VerifyDimensions( EPM_rule_message_t msg )
{
	EPM_decision_t decision = EPM_go;

	register int i = 0;
    int iNumAttch = 0;
    tag_t * pTagAttch;

    tag_t C9_ItemRevTypeTag = NULLTAG;
    char*  type_name[TCTYPE_name_size_c+1];

    char*	itemid;
    char*	revid;

    char*	c9_ContactValue = "";
    char*  	c9_VendorValue = "";
    double  c9_WeightValue = 0.0;



	//Hard coded check for C9boltRevision type: this is to check against the attributes diameter and length later.
    ITKCALL( TCTYPE_find_type("C9_ItemRevision", "", &C9_ItemRevTypeTag));
    ITKCALL( EPM_ask_attachments( msg.task, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	//Loop through attachments to obtain information and check for attributes:
    for (i=0; i < iNumAttch; i++)
    {
    	tag_t objTypeTag = NULLTAG;

    	ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
    	ITKCALL( TCTYPE_ask_name2( objTypeTag, type_name) );

		//Check to validate if the attached object is a C9_ItemRevision.
		//Note: can only check against the property values (c9_Contact) & (c9_Vendor) & (c9_Weight) if the object type is C9_ItemRevision
    	if( objTypeTag == C9_ItemRevTypeTag )
    	{
    		//REQUEST ITEM_ID AND ITEM_REVISION_ID TO PROVIDE FEEDBACK IN SYSLOG
			ITKCALL( AOM_ask_value_string(pTagAttch[i], "item_id", &itemid) );
			ITKCALL( AOM_ask_value_string(pTagAttch[i], "item_revision_id", &revid) );

			//OBTAIN ATTRIBUTE VALUES TO VALIDATE AGAINST
			ITKCALL( AOM_ask_value_string(pTagAttch[i], "c9_Contact", &c9_ContactValue) );
			ITKCALL( AOM_ask_value_string(pTagAttch[i], "c9_Vendor", &c9_VendorValue) );
			ITKCALL( AOM_ask_value_double(pTagAttch[i], "c9_Weight", &c9_WeightValue) );

			/* PRINT TO SYSLOG: VALIDATION MESSAGE */
			TC_write_syslog("\n******************************************************\n");
			TC_write_syslog("\tThe C9_VerifyDimensions program is running against: ( %3d | %s | %s | %s )\n", i, itemid, revid, type_name);
			TC_write_syslog("******************************************************\n\n");

			if (c9_ContactValue == NULL || c9_ContactValue == (char*)"NULL" || tc_strlen(c9_ContactValue) == 0){
						decision = EPM_nogo;
	//					EMH_store_error_s3( EMH_severity_error, C9_ItemRev_Prop_Fail, itemid, revid, "CCC Contact" );
			}
    		if (c9_VendorValue == NULL || c9_VendorValue == (char*)"NULL" || tc_strlen(c9_VendorValue) == 0){
    					decision = EPM_nogo;
    //					EMH_store_error_s3( EMH_severity_error, C9_ItemRev_Prop_Fail, itemid, revid, "CCC Vendor" );
    		}
    		if( c9_WeightValue <= 0){
    					decision = EPM_nogo;
    //					EMH_store_error_s3 ( EMH_severity_error, C9_ItemRev_Prop_Fail, itemid, revid, "CCC Weight");
			}

    	}
    }

	return decision;
}

int C9_WFVerify( METHOD_message_t * /*msg*/, va_list /*args*/ ){
 
	EPM_register_rule_handler("C9-verify-dimensions", "", C9_VerifyDimensions);

	TC_write_syslog("\n******************************************************\n");
	TC_write_syslog("\n\t ------ The C9_WFVerify Rule Handler is Registered! ------\t\n");
	TC_write_syslog("\n******************************************************\n\n");

	return 0;

}

//ITKCALL(TC_printf("\n\t ------ Hello Teamcenter -----\t\n\n"));
#ifdef __cplusplus
}
#endif
