//@<COPYRIGHT>@
//==================================================
//Copyright $2019.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension C9_WFNotify
 *
 */
#include <C9_NotifyHandler/C9_WFNotify.hxx>

#include <epm/epm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/envelope.h>
#include <tc/folder.h>
#include <tccore/tctype.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <tc/tc_util.h>
#include <metaframework/OperationInput.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <tc/Envelope.hxx>

#include <metaframework/libmetaframework_exports.h>

using namespace Teamcenter;

#ifdef __cplusplus
extern "C" {
#endif

int C9_SendToOwner( EPM_action_message_t msg )
{
	register int i = 0;
    int iNumAttch = 0;
    tag_t root_task, tagOwner, tagEnvelope;
    tag_t * pTagAttch;


	ITKCALL(EPM_ask_root_task(msg.task, &root_task));
	ITKCALL(EPM_ask_attachments(root_task, EPM_target_attachment, &iNumAttch, &pTagAttch));

    for (i=0; i < iNumAttch; i++)
    {
    	//Get owner of this target attachment
    	ITKCALL( AOM_ask_owner( pTagAttch[i], &tagOwner) );

    	// Prepare a CreateInput object for an Envelope
    	Teamcenter::CreateInput* pEnvCreInput
    		= dynamic_cast<Teamcenter::CreateInput*>
    			(Teamcenter::BusinessObjectRegistry::instance()
    				.createInputObject("Envelope", OPERATIONINPUT_CREATE));

    	// Populate the CreateInput object
    	pEnvCreInput->setString("object_name", "Mail for you", false);
    	pEnvCreInput->setString("object_desc", "Workflow Information", false);

    	// Create the Envelope
    	BusinessObjectRef<Teamcenter::Envelope> pEnvelope
    		= dynamic_cast<Teamcenter::Envelope*>
    			(Teamcenter::BusinessObjectRegistry::instance()
    				.createBusinessObject(pEnvCreInput));


    	// Convert to a tag_t
    	tagEnvelope = pEnvelope.tag();

    	// Refresh this target attachment and add it to the Envelope
    	ITKCALL( AOM_refresh(pTagAttch[i], FALSE) );
    	ITKCALL( FL_insert(tagEnvelope, pTagAttch[i], 0) );

    	// Add the owner of the target attachment as the mail recipient
    	ITKCALL( MAIL_add_envelope_receiver(tagEnvelope, tagOwner) );

    	// Send the mail
    	ITKCALL( MAIL_send_envelope(tagEnvelope) );
    }

    MEM_free( pTagAttch );

    return ITK_ok;
}


int C9_WFNotify( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
 

	ITKCALL( EPM_register_action_handler("C9-send-to-owner", "", C9_SendToOwner) );

	TC_write_syslog("\n******************************************************\n");
	TC_write_syslog("\tThe C9_WFNotify Action Handler is Registered!");
	TC_write_syslog("******************************************************\n\n");

	return 0;

}

#ifdef __cplusplus
}
#endif
