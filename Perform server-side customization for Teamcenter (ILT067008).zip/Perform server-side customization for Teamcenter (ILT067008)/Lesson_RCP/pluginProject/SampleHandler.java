package com.c9.custplugin.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import com.c9.services.rac.lib.TrainingService;
import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.kernel.TCSession;

import org.eclipse.jface.dialogs.MessageDialog;

public class SampleHandler extends AbstractHandler {

	@Override
public Object execute(ExecutionEvent event) throws ExecutionException {
		
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
	      System.out.println("Getting Session info");
	      TCSession session = null;
	      try {
	         session = (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
	         System.out.println(session.getUserName());
	      } catch (Exception e1) {
	         System.out.println("\tException (session)");
	         e1.printStackTrace();
	      }
	      
	      
	      //initialize service return variable
	      String serviceReturn = null;
	      
	      try {
	         System.out.println("Calling Service");
	         
	         //call service stub for the current session
	         TrainingService myServiceStub = TrainingService.getService(session);
	         
	         //invoke service method and store return (string) value into serviceReturn
	         serviceReturn = myServiceStub.stringReturn();
	      } catch (Exception e) {

	         System.out.println("\tException (service)");
	         e.printStackTrace();
	      }

	      
	      //Open Eclipse dialog window
	      //Provide Title "Training Service Test Result"
	      //Place Training Service Return into content of dialog.
	      
	      MessageDialog.openInformation(
	            window.getShell(),
	            "Training Service Test Result",
	            serviceReturn);

	      return null;
	   }
}
