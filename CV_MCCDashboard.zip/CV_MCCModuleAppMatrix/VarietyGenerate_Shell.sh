#!/bin/bash

echo "Report File: -----> "$1

echo "User Email: -----> "$2

# Input CSV file
input_file=$1

# Derive timestamp from input filename
timestamp=$(echo "$input_file" | sed -n 's/.*Rpt_\(.*\)\.csv/\1/p')

# Output TXT file with dynamic timestamp
output_file="module_variety_rpt_${timestamp}.txt"

# Step 1: Extract unique Module names starting from row 9, excluding last row and empty names
tail -n +9 "$input_file" | head -n -1 | cut -d',' -f3 | grep -v '^$' | sort -u > temp_modules.txt

# Step 2: Write header to output file
echo "Module | VarietyCount | Combinations" > "$output_file"

# Step 3: For each unique module, collect full column sequences after Quantity
while read -r module; do
    # Extract all rows for this module, excluding last row
    module_rows=$(tail -n +9 "$input_file" | head -n -1 | awk -F',' -v m="$module" '$3==m')

    # Number of fields in the CSV
    num_fields=$(echo "$module_rows" | head -1 | awk -F',' '{print NF}')

    sequences=""
    for ((col=11; col<=num_fields; col++)); do
        # Build full column sequence across all rows for this module
        seq=$(echo "$module_rows" | awk -F',' -v c=$col '{printf "%s,", $c} END{print ""}' | sed 's/,$//')
        
        # Skip if sequence is empty or contains only commas
        if [[ "$seq" =~ YES|NO ]]; then
            sequences="$sequences\n($seq)"
        fi
    done

    # Get distinct sequences
    distinct_sequences=$(echo -e "$sequences" | grep -v '^$' | sort -u)

    # Count distinct sequences
    distinct_count=$(echo "$distinct_sequences" | wc -l)

    # Join distinct sequences with "|"
    combinations=$(echo "$distinct_sequences" | paste -sd "|" -)

    # Append result to output file
    echo "$module | $distinct_count | $combinations" >> "$output_file"
done < temp_modules.txt

# Cleanup
rm temp_modules.txt

# ls -lrt $1
# if [ $? == 0 ]
      # then
        # echo "File Successfully Found on Server"
        # echo "Sending Part Applicability Matrix Report To User Email"
        # echo -e "Dear All, \n\n                Please Check Attached MCC MBOM Part Applicability Matrix Report.\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS: MCC MBOM Part Applicability Matrix Report" -a $1 $output_file $2 souravk.ttl@tatamotors.com
      # else
        # echo "File NOT Foud on server"
        # echo "Sending Part Applicability Matrix Repor To Developer Email"
        # echo -e "Dear Team, \n\n                There is Some Issue in MCC MBOM Part Applicability Matrix Report Generation.\n                Please Check Log & Support User.\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED: MCC MBOM Part Applicability Matrix Report" souravk.ttl@tatamotors.com
# fi
# echo -e "\nReport Send To User Email Ended...."