/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   MCC MBOM Library Details Report Calling Exe  
*  File Name    :   tm_mbommccdasboardrpt.c
*  Created on   :   SOct 14th, 2025
*  Usage        :   tm_mbommccdasboardrpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     14/10/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_string.h>


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of MCC MBOM Library Details Report Main Function ************* \n");fflush(stdout);
	
	char* sysCmnd = NULL;
	//char* PrtStr = ITK_ask_cli_argument( "-PartList=");
	//char* UsrStr = ITK_ask_cli_argument( "-User=");
	//char* EmlStr = ITK_ask_cli_argument( "-Email=");
	sysCmnd=(char *) MEM_alloc(400);
	//tc_strcpy(sysCmnd,"/user/infodba04/sourav/MCCRPT/CallingShell.sh");
	tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMSubModuleDashboardDetails/CallingShell.sh");
	//tc_strcat(sysCmnd,PrtStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,UsrStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,EmlStr);
	
	printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
	system(sysCmnd);
	//MEM_free(sysCmnd);
						

	printf("\n*********** End Of MCC MBOM Library Details Report Main Function ************* \n");fflush(stdout);	
	return ifail;
}

/***************************************************************************
*
* // ./compile tm_mbommccdasboardrpt.c
* // ./linkitk -o tm_mbommccdasboardrpt tm_mbommccdasboardrpt.o
* // scp cvprod@172.22.99.106:/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMSubModuleDashboardDetails/tm_mbommccdasboardrpt .
* // scp cvprod@172.22.99.106:/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMSubModuleDashboardDetails/SendEmail.sh .
*
***************************************************************************/