./compile tm_mbommccdasboardrpt.c
./linkitk -o tm_mbommccdasboardrpt tm_mbommccdasboardrpt.o
chmod 777 tm_mbommccdasboardrpt*
