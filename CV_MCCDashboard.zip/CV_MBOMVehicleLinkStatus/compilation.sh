./compile tm_MBOMInputVehicleLinkStatus.c
./linkitk -o tm_MBOMInputVehicleLinkStatus tm_MBOMInputVehicleLinkStatus.o
chmod 777 tm_MBOMInputVehicleLinkStatus*
