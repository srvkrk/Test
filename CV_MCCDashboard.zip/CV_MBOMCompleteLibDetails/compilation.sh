./compile tm_mccmbomcompleterpt.c
./linkitk -o tm_mccmbomcompleterpt tm_mccmbomcompleterpt.o
chmod 777 tm_mccmbomcompleterpt*
