/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   MCC MBOM Complete Library Details Report Calling Exe  
*  File Name    :   tm_mccmbomcompleterpt.c
*  Created on   :   Jan 12th, 2026
*  Usage        :   tm_mccmbomcompleterpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/01/2026                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_string.h>


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of MCC MBOM Complete Library Details Main Function ************* \n");fflush(stdout);
	
	char* sysCmnd = NULL;
	sysCmnd=(char *) MEM_alloc(400);
	//tc_strcpy(sysCmnd,"/user/infodba04/sourav/MCCRPT/CallingShell.sh");
	tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMCompleteLibDetails/CallingShell.sh");
	//tc_strcat(sysCmnd,PrtStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,UsrStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,EmlStr);
	
	printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
	system(sysCmnd);
	//MEM_free(sysCmnd);
						

	printf("\n*********** End Of MCC MBOM Complete Library Details Main Function ************* \n");fflush(stdout);	
	return ifail;
}

/***************************************************************************
*
* // ./compile tm_mccmbomcompleterpt.c
* // ./linkitk -o tm_mccmbomcompleterpt tm_mccmbomcompleterpt.o
* // scp cvprod@172.22.99.106:/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMCompleteLibDetails/tm_mccmbomcompleterpt .
* // scp cvprod@172.22.99.106:/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMCompleteLibDetails/exepatch.sh .
* // scp cvprod@172.22.99.106:/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMCompleteLibDetails/SendEmail.sh .
*
***************************************************************************/
