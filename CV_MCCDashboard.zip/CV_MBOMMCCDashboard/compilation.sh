./compile tm_mbommccrpt.c
./linkitk -o tm_mbommccrpt tm_mbommccrpt.o
chmod 777 tm_mbommccrpt*
