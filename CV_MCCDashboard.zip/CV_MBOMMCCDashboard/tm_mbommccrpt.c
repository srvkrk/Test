/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   MCC MBOM Dashboard Report Calling Exe  
*  File Name    :   tm_mbommccrpt.c
*  Created on   :   Oct 14h, 2025
*  Usage        :   tm_mbommccrpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     14/10/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_string.h>


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of MCC MBOM Dashboard Main Function ************* \n");fflush(stdout);
	
	char* sysCmnd = NULL;
	//char* PrtStr = ITK_ask_cli_argument( "-PartList=");
	//char* UsrStr = ITK_ask_cli_argument( "-User=");
	//char* EmlStr = ITK_ask_cli_argument( "-Email=");
	sysCmnd=(char *) MEM_alloc(400);
	//tc_strcpy(sysCmnd,"/user/infodba04/sourav/MCCRPT/CallingShell.sh");
	tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMMCCDashboard/CallingShell.sh");
	//tc_strcat(sysCmnd,PrtStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,UsrStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,EmlStr);
	
	printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
	system(sysCmnd);
	//MEM_free(sysCmnd);
						

	printf("\n*********** End Of MCC MBOM Dashboard Main Function ************* \n");fflush(stdout);	
	return ifail;
}

/***************************************************************************
*
* // ./compile tm_mbommccrpt.c
* // ./linkitk -o tm_mbommccrpt tm_mbommccrpt.o
* // scp cvprod@172.22.99.106:/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMMCCDashboard/tm_mbommccrpt .
* // scp cvprod@172.22.99.106:/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MBOMMCCDashboard/SendEmail.sh .
*
***************************************************************************/