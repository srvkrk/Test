/user/cvprod/MBOMMCCCRONJOB/tm_mbom_mcc_update_maxardr_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=Output_MaxARDR_Status_Rpt_File.txt
