######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : JANUARY-2026
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'Duplicate Entry Remove Start...'
echo  "-----------------------------------------------------------------------------------------"

echo "Input File Name: $1"
FILENAME="TEMP_$(date '+%d_%b_%Y_%H_%M_%S').txt"
echo "Temporary File Created: $FILENAME"
touch "$FILENAME"
sort -u $1 > $FILENAME
truncate -s 0 $1
cat $FILENAME >> $1
rm -rf $FILENAME

echo  "-----------------------------------------------------------------------------------------"
echo  'Duplicate Entry Remove Finished...'
echo  "-----------------------------------------------------------------------------------------"
