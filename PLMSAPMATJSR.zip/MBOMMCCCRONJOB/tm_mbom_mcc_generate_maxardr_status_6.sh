/user/cvprod/MBOMMCCCRONJOB/tm_mbom_mcc_generate_maxardr_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=input_maxardr_mcc_valid_system_submodule.txt
