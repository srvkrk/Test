######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : MARCH-2024
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'Weekly MCC Library Refresh Program Started...'
echo  "-----------------------------------------------------------------------------------------"

echo "STEP-1 : Valid ALL Submodules from System (Weekly) i.e after removing IFD, ECU, and other given Mod-Addresses"
start_time1=$(date)
echo " Exe-1: [tm_mcc_valid_system_submodule] Start-Time: $start_time1"
/user/cvprod/MCCCRONJOB/tm_mcc_valid_system_submodule -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
end_time1=$(date)
echo " Exe-1: [tm_mcc_valid_system_submodule] End-Time: $end_time1"
sleep 5

echo "STEP-2 : New Modules Insertion in MCC Library which are not present in Library i.e NR-Revision cases."
start_time2=$(date)
echo " Exe-2: [tm_mcc_new_moduleaddress_create] Start-Time: $start_time2"
/user/cvprod/MCCCRONJOB/tm_mcc_new_moduleaddress_create -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=/user/cvprod/MCCCRONJOB/mcc_valid_system_submodule.txt
end_time2=$(date)
echo " Exe-2: [tm_mcc_new_moduleaddress_create] End-Time: $end_time2"
sleep 5

echo "STEP-3 : Existing Module update as per eligible list of STEP-1 i.e Non-NR Modules (Higher Revisions)"
start_time3=$(date)
echo " Exe-3: [tm_mcc_update_libtable_data] Start-Time: $start_time3"
/user/cvprod/MCCCRONJOB/tm_mcc_update_libtable_data -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=/user/cvprod/MCCCRONJOB/mcc_valid_system_submodule.txt
end_time3=$(date)
echo " Exe-3: [tm_mcc_update_libtable_data] End-Time: $end_time3"
sleep 5

echo "STEP-4 : File Generation for Productline, Platform and Vehicle-Linking Status, Count, Vehicle-String for eligigble Submodules as per STEP-1"
start_time4=$(date)
echo " Exe-4: [tm_mcc_generate_vehplatform_status] Start-Time: $start_time4"
/user/cvprod/MCCCRONJOB/tm_mcc_generate_vehplatform_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=/user/cvprod/MCCCRONJOB/input_vehiclelink_mcc_valid_system_submodule.txt
end_time4=$(date)
echo " Exe-4: [tm_mcc_generate_vehplatform_status] End-Time: $end_time4"
sleep 5

echo "STEP-5 : Update of MCC library special attributes (Productline, Platform, Vehicle-linkig status/count, Vehicle-string) for file generated in STEP-4"
start_time5=$(date)
echo " Exe-5: [tm_mcc_update_vehplatform_status] Start-Time: $start_time5"
/user/cvprod/MCCCRONJOB/tm_mcc_update_vehplatform_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=Output_Vehicle_Link_Pltform_Status_Rpt_File.txt
end_time5=$(date)
echo " Exe-5: [tm_mcc_update_vehplatform_status] End-Time: $end_time5"
sleep 5

echo "STEP-6 : File Generation of Max-DR for Submodules as per STEP-1"
start_time6=$(date)
echo " Exe-6: [tm_mcc_generate_maxardr_status] Start-Time: $start_time6"
/user/cvprod/MCCCRONJOB/tm_mcc_generate_maxardr_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=input_maxardr_mcc_valid_system_submodule.txt
end_time6=$(date)
echo " Exe-6: [tm_mcc_generate_maxardr_status] End-Time: $end_time6"
sleep 5

echo "STEP-7 : Update of Max-DR as per file generated at STEP-6 for eligible Submodules"
start_time7=$(date)
echo " Exe-7: [tm_mcc_update_maxardr_status] Start-Time: $start_time7"
/user/cvprod/MCCCRONJOB/tm_mcc_update_maxardr_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=Output_MaxARDR_Status_Rpt_File.txt
end_time7=$(date)
echo " Exe-7: [tm_mcc_update_maxardr_status] End-Time: $end_time7"
sleep 5

echo "STEP-8 : Generation and update of Serial Numbers in Table-Attribute for Submodules"
start_time8=$(date)
echo " Exe-8: [tm_mcc_update_maxardr_status] Start-Time: $start_time8"
/user/cvprod/MCCCRONJOB/tm_mcc_update_serialno -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
end_time7=$(date)
echo " Exe-8: [tm_mcc_update_maxardr_status] End-Time: $end_time8"
sleep 5
echo  "-----------------------------------------------------------------------------------------"
echo  'Weekly MCC Library Refresh Program Ended...'
echo  "-----------------------------------------------------------------------------------------"