./compile IR_checklist.c
./linkitk -o IR_checklist IR_checklist.o
chmod 777 *
