#!/bin/bash

# Source the bash profile
. /user/cvprod/.bash_profile

# Log file
log="/user/cvprod/IRC_app/Logs/IRC.log"

# Table name from command-line argument
TABLE_NAME="$1"

# Append the table name to the log file
echo "Submodule number is $TABLE_NAME" >> "$log"

# File containing patterns to match
pattern_file="sub_id_creo.txt"

# Initialize flag
pattern_found=false

# Read each pattern from the file and check if it matches the input
while IFS= read -r pattern; do
    if [[ "$TABLE_NAME" == *"$pattern"* ]]; then
        pattern_found=true
        break
    fi
done < "$pattern_file"

# Check if any pattern was found
if $pattern_found; then
echo "$TABLE_NAME is a Creo sub module - Starting IRC execution" >> "$log"
TABLE_NAME="${TABLE_NAME%%_*}"
OUTPUT_FILE="${1}_IR_STS.txt"

REMOTE_USER="prp09516"
REMOTE_SERVER="172.22.99.39"
#REMOTE_DB_FILE="/home/prp09516/Sagar/irc_app.db"
REMOTE_DB_FILE="/startparttemplate/IRC_DB/irc_app.db"

# Quote the table name in the query
query="SELECT * FROM \"$TABLE_NAME\";"

ssh "$REMOTE_USER@$REMOTE_SERVER" "sqlite3 '$REMOTE_DB_FILE' <<EOF -separator '|'
.mode list
.headers on
SELECT * FROM \"$TABLE_NAME\";
EOF" > temp_output.txt

cut -d '|' -f 2,4- temp_output.txt | sed '1d' | awk -F '|' -v OFS='|' '{ for (i=1; i<NF; i++) printf "%s|", $i; gsub(/\n/, "", $NF); printf "\"%s\"\n", $NF }' > "$OUTPUT_FILE"
# Add the table name as the first column

sed -i "s/^/$TABLE_NAME|/" "$OUTPUT_FILE"

echo "Data has been exported to $OUTPUT_FILE" >> "$log"
scp "$REMOTE_USER@$REMOTE_SERVER:/startparttemplate/IRC_DB/${1}_IR_Report.pdf" .

else
    echo "$TABLE_NAME is Not a Creo Sub Module" >> "$log"
fi

# Log that the script is calling the executable
echo "calling exe" >> "$log"

# Uncomment to execute additional commands
# /user/cvprod/IRC_app/IR_checklist -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -file="$OUTPUT_FILE"

# Uncomment to copy the output file to a different directory
# scp "$OUTPUT_FILE" /user/testcmi/Dev/devgroups/Akshay/IR/checkin/

echo "Done" >> "$log"

# Uncomment to execute additional scripts
# /user/testcmi/Dev/devgroups/Akshay/IR/checkin/irc_status.sh "$TABLE_NAME"

