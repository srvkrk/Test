The folder is created for interface rule checklist application
The text and pdf report files will be stored in this directory

Below are SPOC of the project

CAD:
===========Creo=================
1. Prashant Pandarkar- prashant.ttl@tatamotors.com
2. Sagar Daware - sagard1.ttl@tatamotors.com
3. Bhuvan Bharat T- bb.ttl@tatamotors.com
4. Surendra Sarode- ss927416.ttl@tatamotors.com

===========Catia=================
1. Sandip Borkar- sandipb.ttl@tatamotors.com
2. Sandeep Sampatrao Patil- sandeepp.ttl@tatamotors.com
3. Gaurav K - gk926356.ttl@tatamotors.com
4. Vijay Choudekar- vc924893.ttl@tatamotors.com

===========PLM====================
1. Devkant Kedar- devkantk.ttl@tatamotors.com
2. Akshay Toke- at924736.ttl@tatamotors.com


Project Owners:
==========DPDS================
Tushar C Gadhave- tusharg.ttl@tatamotors.com

===========ERC================
Shashi Kant Khanna- shashika.ttl@tatamotors.com







