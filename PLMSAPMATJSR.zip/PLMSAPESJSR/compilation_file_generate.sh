./compile UAEpoch_File_Generate.c
./linkitk -o UAEpoch_File_Generate UAEpoch_File_Generate.o
chmod 777 UAEpoch_File_Generate*
