##############################################  760%7a1eRzJi%J
sftp PLMSAPCV@172.16.1.140:/to_TML/QA/S4HANA/Source <<EOF
mput epochjsr3psd_20251213_1500.txt
exit
EOF
##############################################
