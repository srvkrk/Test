#!/bin/sh
. /user/testcmi/.bash_profile
echo "Start of UA_Epoch.sh --> $1 "

logdt=`date +"%m%d"`

cd /user/testcmi/Dev/devgroups/hps/client_code/UA_Epoch

./UAEpoch -u=hss95428 -p=XYT1ESA -b=CAR -a=$1

for i in `cat /user/testcmi/Dev/devgroups/hps/client_code/UA_Epoch/Email_ID.txt`

do 

mail -s "$1" -a /user/testcmi/Dev/devgroups/hps/client_code/UA_Epoch/epochcarpsdua$logdt.txt $i

done

echo "UA_Epoch.sh is completed"
