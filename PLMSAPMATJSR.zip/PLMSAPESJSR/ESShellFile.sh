#!/bin/bash

# Current time in HHMM (24-hour format)
now=$(date +"%H%M")

# Date pieces
today_ymd=$(date +"%Y-%m-%d")
today_suffix=$(date +"%m%d")
yesterday_ymd=$(date -d "yesterday" +"%Y-%m-%d")
tomorrow_ymd=$(date -d "tomorrow" +"%Y-%m-%d")

# Output format (e.g., 26-Apr-2026 18:00)
fmt="%d-%b-%Y %H:%M"

# Initialize
suffix=""
intime=""
outtime=""

# -------- Time slot logic --------

# Slot 0: 06:00 PM  next day 09:00 AM (crosses midnight)
if ((10#$now <= 901)); then
    #suffix="psd${today_suffix}"

    if [[ $now -ge 1801 ]]; then
        # same day evening  next day morning
		suffix="psd${today_suffix}"
        intime=$(date +"$fmt" -d "$today_ymd 18:00")
        outtime=$(date +"$fmt" -d "$tomorrow_ymd 09:00")
    else
        # after midnight  belongs to previous day's slot
		suffix="psd${today_suffix}"
        intime=$(date +"$fmt" -d "$yesterday_ymd 18:00")
        outtime=$(date +"$fmt" -d "$today_ymd 09:00")
    fi

# Slot 1: 09:00 AM  11:00 AM
elif [[ $now -ge 901 && $now -lt 1101 ]]; then
    suffix="1psd${today_suffix}"
    intime=$(date +"$fmt" -d "$today_ymd 09:00")
    outtime=$(date +"$fmt" -d "$today_ymd 11:00")

# Slot 2: 11:00 AM  02:00 PM
elif [[ $now -ge 1101 && $now -lt 1401 ]]; then
    suffix="2psd${today_suffix}"
    intime=$(date +"$fmt" -d "$today_ymd 11:00")
    outtime=$(date +"$fmt" -d "$today_ymd 14:00")

# Slot 3: 02:00 PM  04:00 PM
elif [[ $now -ge 1401 && $now -lt 1601 ]]; then
    suffix="3psd${today_suffix}"
    intime=$(date +"$fmt" -d "$today_ymd 14:00")
    outtime=$(date +"$fmt" -d "$today_ymd 16:00")

# Slot 4: 04:00 PM  06:00 PM
elif [[ $now -ge 1601 && $now -lt 1801 ]]; then
    suffix="4psd${today_suffix}"
    intime=$(date +"$fmt" -d "$today_ymd 16:00")
    outtime=$(date +"$fmt" -d "$today_ymd 18:00")
fi

# -------- File names --------
file1="inputepochjsr${suffix}.txt"
file2="outputepochjsr${suffix}.txt"
file3="epochjsr${suffix}.txt"
plantname="CVBU JSR"  # For Plant JSR

# -------- Output --------
echo "file1=$file1"
echo "file2=$file2"
echo "file3=$file3"
echo "intime=$intime"
echo "outtime=$outtime"
echo "plantname=$plantname"

touch $file1
touch $file2
touch $file3

echo -e "\nEXE(UAEpoch_File_Generate) Execution Started...."
/user/cvprod/PLMSAPESJSR/UAEpoch_File_Generate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=$file1 -o=$file2 -t1="$intime" -t2="$outtime" -pn="$plantname"
echo -e "\nEXE(UAEpoch_File_Generate) Execution Ended...."

while IFS='^' read -r var1 var2 var3 var4 _; do
    # Skip empty lines
    [[ -z "$var1" ]] && continue

    echo "Processing:"
    echo "var1=$var1"   # EstimateSheet_No
    echo "var2=$var2"   # Product_Line
    echo "var3=$var3"   # Process_EDN_No
    echo "var4=$var4"   # Plant Name

    # Call executable
echo -e "\nEXE(UAEpoch) Execution Started...."
    /user/cvprod/PLMSAPESJSR/UAEpoch -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -a=$var1 -b="$var4" -c=$var2 -d=$var3
echo -e "\nEXE(UAEpoch) Execution Ended...."

done < "$file2"

# Example: plantname should already be set
# plantname="CVBU JSR"

case "$plantname" in
  "CVBU JSR")
    files=epochjsrpsdua*.txt
    ;;
  "CVBU LKO")
    files=epochlkopsdua*.txt
    ;;
  "CVBU PUNE")
    files=epochabupsdua*.txt
    ;;
  "CVBU PNR")
    files=epochutkpsdua*.txt
    ;;
  "DHARWAD")
    files=epochdwdpsdua*.txt
    ;;
  *)
    echo "Unknown plantname: $plantname"
    exit 1
    ;;
esac

# Check if files exist before concatenating
if ls $files 1> /dev/null 2>&1; then
  cat $files >> $file3
else
  echo "No matching files found for $plantname"
fi

echo -e "\nFile Copy in Server Start...."
sshpass -p "760%7a1eRzJi%J" sftp PLMSAPCV@172.16.1.140:/to_TML/PRD/S4HANA/Source <<EOF
mput $file3
quit
EOF
echo -e "\nFile Copy in Server End...."

echo -e "\n~~~~~~~~~~ Estimate Sheet Mail Send STARTED ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "File Name: -----> "$file3

echo -e "\nIn Shell Argument Print Ended...."

echo -e "\nFile Send To User Email Started...."
ls -lrt $file3
if [ $? == 0 ]
      then
        echo "File Successfully Found on Server"
        echo "Sending File To User Email"
        cat $file3|Mail -s "SUCCESS: JSR PSD-Released Estimate Sheets From $intime To $outtime" -a $file3 souravk.ttl@tatamotors.com prasadb1.ttl@tatamotors.com nishantp.ttl@tatamotors.com poonams.ttl@tatamotors.com ujjawalk.ttl@tatamotors.com vikash.kumar1@tatamotors.com pawan_kumar@tatamotors.com skb306930@tatamotors.com sunny.saurabh@tatamotors.com bipul.mahato@tatamotors.com bhattacharya.anindya@tatamotors.com RAJA.SINGH@tatamotors.com ankush.mahajan@tatamotors.com nitish.kumar@tatamotors.com sudarshan.vattamwar@tatamotors.com
      else
        echo "File NOT Foud on server"
        echo "Sending File To Developer Email"
        echo -e "Hi, \n\n                There is Some Issue in Cron Job of PSD-Released Estimate Sheets\n                Please Check Cron Job & Re-Execute Job.\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED: PSD-Released Estimate Sheets From $intime To $outtime" souravk.ttl@tatamotors.com poonams.ttl@tatamotors.com prasadb1.ttl@tatamotors.com nishantp.ttl@tatamotors.com ujjawalk.ttl@tatamotors.com
fi
echo -e "\nFile Send To User Email Ended...."
echo -e "\n~~~~~~~~~~ Estimate Sheet Mail Send Ended ~~~~~~~~~~~~"

sleep 5

echo -e "\nFile Move Start...."
mv $files /user/cvprod/PLMSAPESJSR/DAILY_ES_FILE/
mv $file1 /user/cvprod/PLMSAPESJSR/DAILY_ES_FILE/
mv $file2 /user/cvprod/PLMSAPESJSR/DAILY_ES_FILE/
mv $file3 /user/cvprod/PLMSAPESJSR/DAILY_ES_FILE/
echo -e "\nFile Move End...."