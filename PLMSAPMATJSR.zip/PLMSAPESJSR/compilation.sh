./compile UAEpoch.c
./linkitk -o UAEpoch UAEpoch.o
chmod 777 UAEpoch*
