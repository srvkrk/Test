######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : SEPT-2024
#
#######################################################################################
. /user/cvprod/.bash_profile

echo -e "\n~~~~~~~~~~ P R O J E C T   C O D E   L I V E   S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo "SUBSYSCD(Project_Code): -----> "$1

echo "Information-7(Serial_No): -----> "$2

cd /user/cvprod/PLMSAPMATJSR/
echo -e "\nEXE(control_object) Creation Started...."
/user/cvprod/PLMSAP/liveXfr_po/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=$1 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=$2
echo -e "\nEXE(control_object) Creation Ended...."

echo -e "\n~~~~~~~~~~ P R O J E C T   C O D E   L I V E   S H E L L   E N D E D ~~~~~~~~~~~~"
