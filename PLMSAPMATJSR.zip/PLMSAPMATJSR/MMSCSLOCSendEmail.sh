######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it.
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : April-2024
#
#######################################################################################

echo -e "\n~~~~~~~~~~ MMSC SLOC UPDATE FOR JSR VC SHELL STARTED ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "Report File Name: -----> "$1

echo -e "\nIn Shell Argument Print Ended...."

echo -e "\nReport Send To User Email Started...."
ls -lrt $1
if [ $? == 0 ]
      then
        echo "File Successfully Found on Server"
        echo "Sending Report To User Email"
        cat $1|Mail -s "SUCCESS: JSR RELEASED VC MMSC SLOC UPDATE" -a $1 souravk.ttl@tatamotors.com poonams.ttl@tatamotors.com ujjawalk.ttl@tatamotors.com pawan_kumar@tatamotors.com sunny.saurabh@tatamotors.com bipul.mahato@tatamotors.com bhattacharya.anindya@tatamotors.com nitish.kumar@tatamotors.com sudarshan.vattamwar@tatamotors.com
      else
        echo "File NOT Foud on server"
        echo "Sending Report To Developer Email"
        echo -e "Hi, \n\n                There is Some Issue in Cron Job of JSR Released VC MMSC SLOC Update\n                Please Check Cron Job & Re-Execute Job.\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED: JSR RELEASED VC MMSC SLOC UPDATE" $2 souravk.ttl@tatamotors.com 
fi
echo -e "\nReport Send To User Email Ended...."
echo -e "\n~~~~~~~~~~ MMSC SLOC UPDATE FOR JSR VC SHELL ENDED ~~~~~~~~~~~~"

sleep 5

echo -e "\nFile Move Start...."
cp $1 /user/cvprod/PLMSAPMATJSR/MMSC_SLOC_FILE/
echo -e "\nFile Move End...."
