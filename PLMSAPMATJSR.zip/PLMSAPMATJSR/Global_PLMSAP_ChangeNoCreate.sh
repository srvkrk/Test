######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : FEBRUARY-2026
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'S4Hana Change No CREATE) Program Started...'
echo  "-----------------------------------------------------------------------------------------"
echo "Change Number Generation Start"
DATE=$(date +"%d%m%y")
cno="CORRCT$DATE"
echo "Generated Change No: $cno"
echo "Change Number Generation End"

start_time=$(date)
echo "SOURAV: Change No CREATE Start-Time: $start_time"
echo "EXE Calling Start....."
/user/cvprod/PLMSAP/liveXfr_po/ChangeNoCreate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -d=$cno -s=CVP
echo "EXE Calling End......."
end_time=$(date)
echo "SOURAV: Change No CREATE End-Time: $end_time"
date
echo "Sending Change No Create Email"
echo -e "Dear All, \n\n                Below Change No Created in SAP S4Hana.\n                Change No: $cno\n                Create Date: $start_time\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS: Change No Create in SAP S4Hana" souravk.ttl@tatamotors.com prasadb1.ttl@tatamotors.com nishantp.ttl@tatamotors.com poonams.ttl@tatamotors.com ujjawalk.ttl@tatamotors.com
echo  "-----------------------------------------------------------------------------------------"
echo  'S4Hana Change No CREATE) Program Finished...'
echo  "-----------------------------------------------------------------------------------------"
