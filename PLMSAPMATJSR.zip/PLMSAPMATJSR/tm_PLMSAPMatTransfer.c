/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP
*  Description  :   Query APLJ Released DML & Transfer Eligible Part To SAP
*  File Name    :   tm_PLMSAPMatTransfer.c
*  Created on   :   Apr 13th, 2024
*  Usage        :   tm_PLMSAPMatTransfer
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     13/04/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_SNoStatus()
{
	tag_t tSNItemobj = NULLTAG;
	int n_sn_entries = 6;
	int n_sn_itemobj_found = 0;
	tag_t* tsnitemobj_results = NULLTAG;
	char* SNoStatus = NULL;
	
	ITK_CALL(QRY_find2("Control Objects...",&tSNItemobj));
	if(tSNItemobj != NULLTAG)
	{
		printf("\n Query[Control Objects...] Found Successfully..!!\n");fflush(stdout);
		char *cSNEntries[6]  = {"SYSCD","SUBSYSCD","Information-1","Information-2","Information-3","Information-4"};
		char *cSNValues[6]  = {"XFRDML","*","APLJ","STDJ","2001","SAPLIVE"};
		//char *cSNValues[6]  = {"XFRDML","*","APLJ","STDJ","2001","SAPLIVE"};
		ITK_CALL(QRY_execute(tSNItemobj, n_sn_entries, cSNEntries, cSNValues, &n_sn_itemobj_found, &tsnitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Control Objects...] Found: [%d]\n",n_sn_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_sn_itemobj_found > 0)
		{
			printf("\n Control Objects Found So, Continue..!!\n");fflush(stdout);
			char snostr[10];
		    tostring(snostr, n_sn_itemobj_found);
		    tc_strdup(snostr,&SNoStatus);
		}
		else
		{
			printf("\n No Control Object Found in XFRDML..!!\n");fflush(stdout);
			tc_strdup("1",&SNoStatus);
		}					
	}
	else
	{
		printf(" Query[Control Objects...] Tag Not Found..!!");fflush(stdout);
		tc_strdup("1",&SNoStatus);
	}
	   
	return SNoStatus;
}

char* TC_ProjCodeStatus(char* PCode)
{
	trimwhitespace(PCode);
	tag_t tPItemobj = NULLTAG;
	int n_p_entries = 6;
	int n_p_itemobj_found = 0;
	tag_t* tpitemobj_results = NULLTAG;
	char* PCodeStatus = NULL;
	char* SRFind = NULL;
	
	ITK_CALL(QRY_find2("Control Objects...",&tPItemobj));
	if(tPItemobj != NULLTAG)
	{
		printf("\n Query[Control Objects...] Found Successfully..!!\n");fflush(stdout);
		char *cPEntries[6]  = {"SYSCD","SUBSYSCD","Information-1","Information-2","Information-3","Information-4"};
		char *cPValues[6]  = {"XFRDML",PCode,"APLJ","STDJ","2001","SAPLIVE"};
		//char *cPValues[6]  = {"XFRDML","5185","APLJ","STDJ","2001","SAPLIVE"};
		ITK_CALL(QRY_execute(tPItemobj, n_p_entries, cPEntries, cPValues, &n_p_itemobj_found, &tpitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Control Objects...] Found: [%d]\n",n_p_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_p_itemobj_found > 0)
		{
			printf("\n Control Objects Already Present For project Code: [%s]\n",PCode);fflush(stdout);
		    tc_strdup("Yes",&PCodeStatus);
		}
		else
		{
			printf("\n Control Objects Already Not Present For project Code: [%s]\n",PCode);fflush(stdout);
			printf("\n Project Code Live Control Object Creation Start..!!\n");fflush(stdout);
			SRFind = TC_SNoStatus();
			int SRFindIn;
			SRFindIn = atoi(SRFind);
			SRFindIn = SRFindIn + 1;
			printf("\n Final Serial No: [%d]\n",SRFindIn);fflush(stdout);
			char SRFindInStr[10];
		    tostring(SRFindInStr, SRFindIn);
			printf("\n Final Serial No: [%s]\n",SRFindInStr);fflush(stdout);
			
			char command[512];
			printf("\n Shell Call Started...");fflush(stdout);
			sprintf(command,"/user/cvprod/PLMSAPMATJSR/ProjCodeLive.sh %s %s",PCode,SRFindInStr);
			system(command);
			printf("\n Shell Call Ended...");
			printf("\n Project Code Live Control Object Creation End..!!\n");fflush(stdout);
			tc_strdup("Yes",&PCodeStatus);
		}					
	}
	else
	{
		printf(" Query[Control Objects...] Tag Not Found..!!");fflush(stdout);
		tc_strdup("No",&PCodeStatus);
	}
	   
	return PCodeStatus;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *DMLNo = NULL;
	char *DMLNoDup = NULL;
	char *RptFile = (char *) malloc(30*sizeof(char));
	FILE *fpOutput_file = NULL;
	char *DMLPCode = NULL;
	char *DMLPCodeDup = NULL;
	char *DMLPCodeStatus = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"DMLList.lst");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	tc_strcat(CurDateFinalDup," 00:00");
	printf(" Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    3 - D A Y S   B E F O R E   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDate[100] = "";
	char* BfrDateDup = NULL;
	char *BfrDateFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-3);
	nextinfo = localtime(&t3);
	strftime(BfrDate,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDate);
	if(BfrDate!=NULL)tc_strdup(BfrDate,&BfrDateDup);
	tc_strcpy(BfrDateFinalDup,BfrDateDup);
	tc_strcat(BfrDateFinalDup," 00:00");
	printf(" [1]: Input Formatted Before Date(BfrDateFinalDup): [%s]\n",BfrDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	ITK_CALL(QRY_find2("APL_DML_PLMSAP",&tItemobj));
    if(tItemobj != NULLTAG)
    {
		printf("\n Query [APL_DML_PLMSAP] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Released_After","Release_Status"};
		char *cValues[2]  = {BfrDateFinalDup,"T5_LcsApljRlzd"};
		//char *cValues[2]  = {"20-Dec-2022 10:22","T5_LcsApljRlzd"};
	    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of APLJ Released DML Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" APLJ Released DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&DMLNo));
				if(tc_strlen(DMLNo)>0)
				{
					tc_strdup(DMLNo,&DMLNoDup);
				}
				else
				{
					printf("\n DML No is NULL..!!");fflush(stdout);
				}
				printf("\n DML No(DMLNoDup): [%s]\n",DMLNoDup);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_cprojectcode",&DMLPCode));
				if(tc_strlen(DMLPCode)>0)
				{
					tc_strdup(DMLPCode,&DMLPCodeDup);
				}
				else
				{
					printf("\n DML Project Code No is NULL..!!");fflush(stdout);
				}
				printf("\n DML Project Code(DMLPCodeDup): [%s]\n",DMLPCodeDup);fflush(stdout);
				DMLPCodeStatus = TC_ProjCodeStatus(DMLPCodeDup);
				if(tc_strcmp(DMLPCodeStatus,"Yes")==0)
				{
					printf("\n Project Code Control Object Already Live or Created..!!");fflush(stdout);
				}
				else
				{
					printf("\n !!!!!!! SERIOUS ISSUE REGARDING PROJECT CODE CONTROL OBJECT !!!!!!!");fflush(stdout);
				}
				fprintf(fpOutput_file,"%s\n",DMLNoDup);fflush(fpOutput_file);
			}
		}
		else
		{
			printf("\n APLJ Released DML Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\n Query Tag[APL_DML_PLMSAP] is NULL..!!");fflush(stdout);
	}
	
    if (titemobj_results)
	{
	  MEM_free(titemobj_results);
	}
	fclose(fpOutput_file); 		
    printf("\n All DML Written Successfully on the Output File....\n");fflush(stdout); 
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PLMSAPMatTransfer.c
* // ./linkitk -o tm_PLMSAPMatTransfer tm_PLMSAPMatTransfer.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PLMSAPMatTransfer/tm_PLMSAPMatTransfer .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PLMSAPMatTransfer/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PLMSAPMatTransfer/usage.txt .
* // ./tm_PLMSAPMatTransfer -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_PLMSAPMatTransfer -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/