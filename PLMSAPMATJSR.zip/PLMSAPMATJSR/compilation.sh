./compile tm_PLMSAPMatTransfer.c
./linkitk -o tm_PLMSAPMatTransfer tm_PLMSAPMatTransfer.o
chmod 777 *
