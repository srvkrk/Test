/user/cvprod/MCCCRONJOB/tm_mcc_update_vehplatform_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=Output_Vehicle_Link_Pltform_Status_Rpt_File.txt
