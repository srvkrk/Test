/user/cvprod/MCCCRONJOB/tm_mcc_update_serialno -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
