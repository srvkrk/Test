######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : JUNE-2024
#
#######################################################################################

echo -e "\n~~~~~~~~~~ F I L E   C O P Y   S H E L L   S T A R T E D ~~~~~~~~~~~~"

cd /usr1/people/sapmaster/PLM_DATA/PROD/2489/PLM_Excel/
START="dc_vehicle_details_from_plm_"
GENDATETIME=`date +"%d_%b_%Y"`
END="_bkp.csv"
BKPFILENAME="${START}${GENDATETIME}${END}"
echo "Backup File Name: " $BKPFILENAME

ls -lrt dc_vehicle_details_from_plm.csv
if [ $? == 0 ]
    then
        echo "Old Report File[dc_vehicle_details_from_plm.csv] Already Exist. So Move Start..!!"
        mv dc_vehicle_details_from_plm.csv /usr1/people/sapmaster/PLM_DATA/PROD/2489/PLM_Excel/Backup/$BKPFILENAME
        echo "Old Report File[dc_vehicle_details_from_plm.csv] Move End..!!"
    else
        echo "Old Report File[dc_vehicle_details_from_plm.csv] Does Not Exist..!!"
fi
sleep 2
echo -e "\n~~~~~~~~~~ F I L E   C O P Y   S H E L L   E N D E D ~~~~~~~~~~~~"