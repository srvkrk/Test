./compile tm_VehicleDataReport.c
./linkitk -o tm_VehicleDataReport tm_VehicleDataReport.o
chmod 777 tm_VehicleDataReport*
