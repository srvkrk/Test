######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : JUNE-2024
#
#######################################################################################
. /user/cvprod/.bash_profile

echo -e "\n~~~~~~~~~~ C R O N  S H E L L   S T A R T E D ~~~~~~~~~~~~"

cd /user/cvprod/DATACONSOLIDATE/
START="dc_vehicle_details_from_plm_"
GENDATETIME=`date +"%d_%b_%Y"`
END="_bkp.csv"
BKPFILENAME="${START}${GENDATETIME}${END}"
echo "Backup File Name: " $BKPFILENAME

ls -lrt dc_vehicle_details_from_plm.csv
if [ $? == 0 ]
    then
        echo "Old Report File[dc_vehicle_details_from_plm.csv] Already Exist. So Move Start..!!"
        mv dc_vehicle_details_from_plm.csv /user/cvprod/DATACONSOLIDATE/Backup/$BKPFILENAME
        echo "Old Report File[dc_vehicle_details_from_plm.csv] Move End..!!"
    else
        echo "Old Report File[dc_vehicle_details_from_plm.csv] Does Not Exist..!!"
fi
echo -e "\nEXE(tm_VehicleDataReport) Execution Started...."
/user/cvprod/DATACONSOLIDATE/tm_VehicleDataReport -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
echo -e "\nEXE(tm_VehicleDataReport) Execution Ended...."
sleep 10
rm -rf *.txt

ls -lrt dc_vehicle_details_from_plm.csv
if [ $? == 0 ]
    then
        echo "Report File[dc_vehicle_details_from_plm.csv] Generated..!!"
		echo "Report File[dc_vehicle_details_from_plm.csv] Sanitize Start..!!"
		sed -i -e 's/"//g' dc_vehicle_details_from_plm.csv
		echo "Report File[dc_vehicle_details_from_plm.csv] Sanitize End..!!"
        echo -e "\n#-----------------------------------------------------#"
        echo -e "\nVehicle File Copy To Path(Souvik Karmakar) Start..!!"
        ssh sapmaster@172.22.99.133 -n "sh /usr1/people/sapmaster/PLM_DATA/PROD/2479/VC_INFO/FileCopy_Shell.sh"
        scp dc_vehicle_details_from_plm.csv sapmaster@172.22.99.133:/usr1/people/sapmaster/PLM_DATA/PROD/2479/VC_INFO/
        echo -e "\nVehicle File Copy To Path(Souvik Karmakar) End..!!"
        echo -e "\nVehicle File Copy To Path(Vaibhav Kanade) Start..!!"
        ssh sapmaster@172.22.99.133 -n "sh /usr1/people/sapmaster/PLM_DATA/PROD/2489/PLM_Excel/FileCopy_Shell.sh"
        scp dc_vehicle_details_from_plm.csv sapmaster@172.22.99.133:/usr1/people/sapmaster/PLM_DATA/PROD/2489/PLM_Excel/
        echo -e "\nVehicle File Copy To Path(Vaibhav Kanade) End..!!"
        echo -e "\n#-----------------------------------------------------#"
        echo -e "\nFile Copy in Both Location End..!!"
        echo "Success Report Send To Email Start..!!"
        echo -e "Dear All, \n\n                Please Check Attached Report of Vehicle Data-Consolidation.\n                File Also Copied on Shared Location. Please Check.\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Plese do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS : Vehicle Data-Consolidation" -a dc_vehicle_details_from_plm.csv souravk.ttl@tatamotors.com pawar.abhijit@tatamotors.com
        echo "Success Report Send To Email End..!!"
    else
        echo "Report File[dc_vehicle_details_from_plm.csv] Not Present..!!"
        echo "Failed Report Send To Developer Email Start..!!"
        echo -e "Dear Team, \n\n                There is Some Issue in Vehicle Data Consolidator Program.\n                Please Check Log & Re-Run Job.\n\nRegrds,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED : Vehicle Data-Consolidation" souravk.ttl@tatamotors.com
        echo "Failed Report Send To Developer Email End..!!"
fi
echo -e "\n~~~~~~~~~~ C R O N  S H E L L   E N D E D ~~~~~~~~~~~~"
