package com.tml.techspec.handlers;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Shell;

import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.commands.unreserve.UnReserveHandler;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.tml.classification.modules.GetClassDescriptions;
import com.tml.classification.modules.TechSpecUtil;
import com.tml.techspec.dialogs.GetProjVehClass;
//import com.teamcenter.rac.tml.ui.modulecreation.ModuleInfoDialog;
import com.tml.techspec.dialogs.ModuleClassificationDialog;

public class TMLUnReserveHandler extends UnReserveHandler {
	
	
	protected void tcExecute()
		    throws Exception
		  {
		boolean success=false;
		 InterfaceAIFComponent[] arrayOfInterfaceAIFComponent = getTargetComponents();
		 
		 TCComponentItemRevision itemrev=(TCComponentItemRevision) arrayOfInterfaceAIFComponent[0];
		 String classtype= arrayOfInterfaceAIFComponent[0].getType();
		 System.out.println("classtype="+classtype);
		 Shell localShell = getActiveShell();
		 String parttype=null;
		 String partprojcode=null;
		 String TSBusiUnit=null;
		 String ProjBusiUnit=null;
		 String ModuleAddress=null;
		 String classdesc = null;
	    // MessageDialog.openQuestion(localShell,"CheckIn", "You must have to do classify before Check-In?" );
		 AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		    TCSession session=(TCSession) app.getSession();
		 if(classtype.equals("Design Revision"))
		 {
	     parttype= itemrev.getProperty("t5_PartType");
	    System.out.println("parttype="+parttype);
	    
	    partprojcode= itemrev.getProperty("t5_ProjectCode");
	    System.out.println("partprojcode="+partprojcode);
	  //  ProjBusiUnit= itemrev.getProperty("t5_BussUnitType");
	    //System.out.println("partprojcode="+partprojcode);
		 }
		 else 
		 {
			 parttype= classtype;
		 }
		 
		 
		 System.out.println("outside parttype="+parttype);
		 
		 if(parttype.equals("Module")==false )
			{
				System.out.println("part Type is not Module, Auto classification dialog only valid for Module check-in ");
				
		    	//MessageBox.post(localShell,"Part Type Module Revision only allowed for this option!","WARNING",SWT.ICON_WARNING);
		    	return ;
			}
		 
		 if(parttype.equals("Vehicle") || parttype.equals("Vehicle Combination") || parttype.equals("Configurable VC") || parttype.equals("Vehicle Combination CR"))//Case For : VC/Vehicle
			{
				TCComponent[] techspec=itemrev.getTCProperty("T5_VCSpec").getReferenceValueArray();
				//TCComponentItemRevision techspec=selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
				if (techspec!=null && techspec.length>0) // If  TechSpec is attached to VC/Vehicle Show Classification Dialog for resp. BU
				{
					//UpdDlgFlg=true;
					TSBusiUnit = techspec[0].getTCProperty("t5_VCClassName").getDisplayableValue();
					System.out.println("in vehicle selection TSBusiUnit:-"+TSBusiUnit);
				}
				
			}
		 if(parttype.equals("T5_TSCompRevision"))
		 {
			 TSBusiUnit = itemrev.getTCProperty("t5_VCClassName").getDisplayableValue();
				System.out.println("in TechSpec selection TSBusiUnit:-"+TSBusiUnit);
		 }
		 System.out.println(" TSBusiUnit:-"+TSBusiUnit);
		 if(TSBusiUnit==null)
		 {
			 
			 	String retval=null;
				String tmpstr=null;
				
				String VehCls1=null;
				 ModuleAddress=itemrev.getProperty("t5_ModuleAddress");
					System.out.println("ModuleAddress:----------  "+ModuleAddress);
					//ModuleAddress="HCV"+ModuleAddress;
				if(partprojcode!=null)
				{
					try {
						VehCls1=new TechSpecUtil().getVehClsNmaeForProj(partprojcode);
						System.out.println("Check-in dlg VehCls1="+VehCls1 );
						if(VehCls1.contains("PRD")==false) //if not PRD then set TSBusiUnit
						{ 
							retval=VehCls1;
						}
						else
						{
							//ProjBusiUnit=new TechSpecUtil().getBusUnitForProj(partprojcode);
							//System.out.println("ProjBusiUnit:----------  "+ProjBusiUnit);
							//if(ProjBusiUnit.contains("CVBU")==true)
							//{	
								/*if(ModuleAddress!=null)
								{
									classdesc=new TechSpecUtil().getcheckClsAvlForModArs(ModuleAddress);
									//ModuleAddress="HCV"+ModuleAddress;
									//classdesc=new GetClassDescriptions().getClassDesc(session,ModuleAddress);
									//if(classdesc==null)
									//{
									//	ModuleAddress="MCV"+ModuleAddress;
									//}
								}
								System.out.println("TMLUnReserveHandler classdesc="+classdesc );
								if(classdesc!=null) 
								{*/
									GetProjVehClass GetProjVehClassDlg= new GetProjVehClass(localShell);
									GetProjVehClassDlg.open();
									retval=GetProjVehClassDlg.getProjVehClsSelectedVal1();
									System.out.println("TMLUnReserveHandler retval="+retval );
								//}
//							}
//							else
//							{
//								retval="CAR";
//							}
						}
					}  catch (TCException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				//System.out.println("check-in TSBusiUnit="+TSBusiUnit );
				
			
//				GetProjVehClass GetProjVehClassDlg= new GetProjVehClass(localShell);
//				GetProjVehClassDlg.open();
//				retval=GetProjVehClassDlg.getProjVehClsSelectedVal1();
				
//				if(retval==null)
//				{
//					System.out.println("User not choosen the value for PRD-, so abort the process=");
//					//return;
//				}
				
				//if(retval!=null || retval.isEmpty()==false)
				if(retval!=null)
				{
					System.out.println("Module Part Type is valid for Technical specification update for PRD class with retval="+retval);
					TSBusiUnit=retval;
				}
				
		 }
		 System.out.println(" final checkin handler TSBusiUnit:-"+TSBusiUnit);
		//date:-04/04/2019 
		 //if(parttype.equals("Vehicle")||parttype.equals("T5_TSCompRevision")||parttype.equals("Module")||parttype.equals("Vehicle Combination")||parttype.equals("Configurable VC"))
		 if(TSBusiUnit!=null)
		 {	 
			 if(parttype.equals("Module")==true)
			 {

				 System.out.println("allowed this option for parttype="+parttype);
				 //			 AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
				 //			    TCSession session=(TCSession) app.getSession();
				 //success= new TechSpecUtil().invokeDlg(localShell, session,this.m_event, itemrev,TSBusiUnit);	   
				 success= new TechSpecUtil().invokeChkInDlg(localShell, session,this.m_event, itemrev,TSBusiUnit);

			 }
		 }
		 else
		 {
			 System.out.println(" Classification class ["+ModuleAddress +"]"+ "not defined in Classification ,checkin allowed without classification ");
			 success=true;
		 }
		 System.out.println("classification process during check-in is completed successfully with flag="+success);
		 if(success)
		 super.tcExecute();	 
}	  		 
	 
	    // String classtype= arrayOfInterfaceAIFComponent[0].getType();
	    //System.out.println("parttype="+parttype);
	   // if()
	    

}
