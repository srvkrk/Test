package com.tml.techspec.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
//import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.common.handlers.AbstractTCHandler;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentGroup;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentRole;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.soa.exceptions.NotLoadedException;
//import com.temcenter.techspec.forms.ModuleClassificationDialog;
import com.tml.classification.modules.GetClassifiedAttr;
import com.tml.classification.modules.ICOValues;
import com.tml.classification.modules.TechSpecUtil;
import com.tml.techspec.dialogs.ModuleClassificationDialog;
import com.tml.techspec.dialogs.UpdateTechSpecDialog;
import com.tml.techspec.handlers.ArcNodeToPwrtrnRelHandler;

public class UpdateModHandler extends AbstractTCHandler{
	
	private ICOValues val =null;
	 private String userIdS;
	 private boolean bypassUsrflg=false;
	 private boolean AccessFlag;
	 private int ModuleErrFlag=0;
	 private String PartType;
	 private String selecteditem;
	 private String ErrMsg;
	public void tcExecute() throws Exception  {
		/*IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		MessageDialog.openInformation(
				window.getShell(),
				"Modules",
				"Hello, Eclipse world");*/
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(this.m_event);
		Shell shell =window.getShell();
	//	ModuleInfoDialog dialog = new ModuleInfoDialog(shell);
		//LoginTCFun();
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		TCSession session=(TCSession) app.getSession();
		System.out.println("Session User:----------  "+session.getUser());
		AIFComponentContext selectedobject=null;
		final ISelection selection = HandlerUtil.getCurrentSelection(this.m_event);
		
		InterfaceAIFComponent[] selectedobjs=getTargetComponents();
		
		//calling
		
				
	   // selectedobject=(AIFComponentContext)((IStructuredSelection)selection).getFirstElement();
	    
	   
	    if(selectedobjs[0] instanceof TCComponentItemRevision )
	    {
	    	System.out.println("Allowed this option");
	    	TCComponent selectedObj = (TCComponent) selectedobjs[0];// selectedobject.getComponent();	
	    	TCComponentUser user = session.getUser();
	    	int grpFlag = 0;
			TCComponentGroup[] grps;
			
			TCComponentGroup ercDesignGrp = null;
	    	userIdS = user.getUserId();
	    	System.out.println("\nSession User Login Name == " + userIdS + "\n");
	    	System.out.println("b4 bypassflg="+bypassUsrflg);
	    	bypassUsrflg=new TechSpecUtil().bypassUsrfunc(userIdS,"ByPassUser");
			 System.out.println("bypassflg="+bypassUsrflg);
	    	
			try {
				selecteditem=selectedObj.getTCProperty("item_id").getDisplayableValue();
				PartType=selectedObj.getTCProperty("t5_PartType").getDisplayableValue();
				System.out.println("user getGroupMembers="+user.getGroupMembers()[0].toString());
				System.out.println("selecteditem="+selecteditem +" PartType="+PartType);
				
				if(PartType.equals("Module")==false )
				{
					System.out.println("part Type is not Module, option only valid for Module");
					
			    	MessageBox.post(shell,"Part Type Module Revision only allowed for this option!","WARNING",SWT.ICON_WARNING);
			    	return ;
				}
				grps = user.getGroups();
				
				for (TCComponentGroup grp : grps)
				{
					String grpName = grp.getGroupName();
					System.out.println("1grpName="+grpName.toString());
					
					if (grpName.contains("Vehicle_Integration") || grpName.contains("Vehicle Integration"))
					{
						ercDesignGrp = grp;
						//if(grpName.contains(designGroupS))
						//{
							grpFlag = 1;
							AccessFlag=true;
							break;
						//}
						
					}
					
				}
				System.out.println("AccessFlag="+AccessFlag);
				ModuleErrFlag=0;
				System.out.println(" AccessFlag="+AccessFlag  +"start ModuleErrFlag="+ModuleErrFlag+ " bypassUsrflg="+bypassUsrflg);
				if(AccessFlag==true || bypassUsrflg==true)
				{
					if(bypassUsrflg==true)
					{
						AccessFlag=bypassUsrflg;
					}
					if(PartType.equalsIgnoreCase("Module"))
					{
						System.out.println("Allow to uopdate classification for Module"+selecteditem);
						
					}
					else
					{
						ModuleErrFlag++;
						ErrMsg="only Change Reference's attached Module Revision valid for this option, for Further Contact PLM Administrator";
						MessageBox.post(shell,ErrMsg,"ERROR",SWT.ICON_WARNING);
						return; 
					}
				}
				else
				{
					ModuleErrFlag++;
					ErrMsg="Only Vehicle Integration Group has access to update module's Technical attributes by this option, for Further Contact PLM Administrator";
					MessageBox.post(shell,ErrMsg,"ERROR",SWT.ICON_WARNING);
					return;
				}
				
			} catch (TCException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	    	
			System.out.println("2 AccessFlag="+AccessFlag  +"start ModuleErrFlag="+ModuleErrFlag+ " bypassUsrflg="+bypassUsrflg);
		   new TechSpecUtil().invokeDlgForModUpd(shell,session,this.m_event, selectedObj,AccessFlag);
	    	// new TechSpecUtil().invokeDlgMDM(shell,session,this.m_event, selectedObj);
	    }
	    else
	    {
	    	System.out.println("part Type is not Module revision, option only valid for Module");
			
	    	MessageBox.post(shell,"Part Type Module Revision only allowed for this option!","WARNING",SWT.ICON_WARNING);
	    	
			/* MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
	               messageBox1.setText("Information.");
	               messageBox1.setMessage("Part Type Vehicle/Module Revision only allowed for this option ");
	               messageBox1.open(); */ 
	               
	               return ;
	    }
	    	
	
		
		
		return ;
	}
	
	

	
}
