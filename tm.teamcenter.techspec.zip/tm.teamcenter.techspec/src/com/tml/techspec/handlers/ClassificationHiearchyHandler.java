package com.tml.techspec.handlers;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.handlers.HandlerUtil;

import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.common.amrule.AMRuleTreeNode;
import com.teamcenter.rac.common.handlers.AbstractTCHandler;
import com.teamcenter.rac.kernel.TCClassificationService;
import com.teamcenter.rac.kernel.TCComponentAMTree;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.ics.ICSAdminClass;
import com.teamcenter.rac.kernel.ics.ICSAdminClassAttribute;
import com.teamcenter.rac.kernel.ics.ICSKeyLov;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.services.rac.classification._2007_01.Classification.ChildDef;
import com.teamcenter.services.rac.classification._2007_01.Classification.GetChildrenResponse;

public class ClassificationHiearchyHandler  extends AbstractTCHandler{
	
	private TCSession session;
	private TCClassificationService classServ;
	private ClassificationService clsService;
	private FileWriter clazfile;
	private FileWriter lovfile;
	
	public void tcExecute() throws Exception  {
		System.out.println("inside ClassificationHiearchyHandler ::");
		IStructuredSelection theSelection = (IStructuredSelection) HandlerUtil.getCurrentSelection(this.m_event);
		Object selection=theSelection.getFirstElement();
		if(selection instanceof AMRuleTreeNode)
		{
			AMRuleTreeNode selectnode=(AMRuleTreeNode) selection	;
			System.out.println("datatttt::"+selectnode.getChildCount());
			TCComponentAMTree localTCComponentAMTree = (TCComponentAMTree)selectnode.getUserObject();
			String classid=localTCComponentAMTree.toDisplayString();
		System.out.println("gffdfddds::"+classid);
		clazfile=new FileWriter("C:\\ico\\"+classid+"_claz.csv");
		lovfile=new FileWriter("C:\\ico\\"+classid+"_clazlov.csv");
		
		//getICMHiearchy("CARVCATTR01");
		getICMHiearchy("ICM0101");//ICM010102
		clazfile.close();
		lovfile.close();
		
		MessageBox.post(this.getActiveShell(),"Export Operation Completed for:"+classid,"Operation Completed",MessageBox.INFORMATION);
		
	}
	}
	public void getClassDetail(String clsid) throws TCException, IOException
	{
		 GetChildrenResponse childrenResponse=clsService.getChildren(new String[]{clsid});
		 Map children=childrenResponse.children;
		 
		 for( Object key : children.keySet())
         {
            System.out.println("map1.get(key)="+key);
           
            System.out.println("Val="+children.get(key));
          
            ChildDef[] childdef=(ChildDef[]) children.get(key);
      for(int g=0;g<childdef.length;g++)
      {
            String childid=childdef[g].id;
            String childname=childdef[g].name;
            
            System.out.println("childid="+childid);
            System.out.println("childname="+childname);
		
        ICSAdminClass icsadmin = classServ.newICSAdminClass();
        icsadmin.load(childid);
        if(icsadmin.isAbstract())
        getClassDetail(childid);
        else
        {
        for(int i=0;i<icsadmin.getAttributeCount(0);i++)
        {
        	ICSAdminClassAttribute icsadminattr= icsadmin.getAttributes()[i];
        	String clazfwval=icsadmin.askClassId()+","+icsadmin.getId()+","+icsadmin.getName()+","+icsadminattr.getAttributeId()+","+icsadminattr.getName()+","+ icsadminattr.getFormat1().toString()+","+ icsadminattr.getFormat2().toString()+","+ icsadminattr.getVLALength();
        	System.out.println(clazfwval);
        	clazfile.write("\n"+clazfwval);
        	String lovfwval=icsadmin.askClassId()+","+icsadmin.getId()+","+icsadmin.getName()+","+icsadminattr.getAttributeId()+","+icsadminattr.getName()+","+ icsadminattr.getFormat1().toString()+","+icsadminattr.getFormat2().toString()+","+icsadminattr.getFormat1().getDisplayString();
        	 ICSKeyLov keylov=icsadminattr.getFormat1().getKeyLov();
        	 if(keylov!=null)
        	 {
        	
        		 System.out.println(lovfwval);
        		 lovfile.write("\n"+clazfwval);
        	 String[] dispval=keylov.getDisplayValues();
        	 for(int k=0;k<dispval.length;k++)
        	 {
        		 System.out.println(dispval[k]);
        		 System.out.println(dispval[k]);
        		 lovfile.write("\n"+",,"+dispval[k]);
        	 }
        	 }
        }
         }
         }
         }
	}
	
	public void getICMHiearchy(String clsid) throws TCException, IOException
	{
		
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		session=(TCSession) app.getSession();
		classServ =session.getClassificationService();
		
		 clsService = ClassificationService.getService(session);
		 getClassDetail( clsid);
		
	}
	
	/*
	 * public void tcExecute() throws Exception {
	 * 
	 * IStructuredSelection theSelection = (IStructuredSelection)
	 * HandlerUtil.getCurrentSelection(this.m_event); Object
	 * selection=theSelection.getFirstElement(); if(selection instanceof
	 * AMRuleTreeNode) { AMRuleTreeNode selectnode=(AMRuleTreeNode) selection ;
	 * System.out.println("datatttt::"+selectnode.getChildCount());
	 * TCComponentAMTree localTCComponentAMTree =
	 * (TCComponentAMTree)selectnode.getUserObject(); String
	 * classid=localTCComponentAMTree.toDisplayString();
	 * System.out.println("gffdfddds::"+classid); clazfile=new
	 * FileWriter("C:\\ico\\"+classid+"_claz.csv"); lovfile=new
	 * FileWriter("C:\\ico\\"+classid+"_clazlov.csv");
	 * 
	 * //getICMHiearchy("CARVCATTR01"); getICMHiearchy("ICM0101");//ICM010102
	 * clazfile.close(); lovfile.close();
	 * 
	 * MessageBox.post(this.getActiveShell(),"Export Operation Completed for:"
	 * +classid,"Operation Completed",MessageBox.INFORMATION);
	 * 
	 * } }
	 */

}
