package com.tml.techspec.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;
//import org.w3.x2000.x09.xmldsig.ObjectType;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentGroup;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRole;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.tml.classification.modules.TechSpecUtil;
import com.tml.techspec.dialogs.ArcNodeToPwrTrnModRelDlg;
import com.tml.techspec.dialogs.CreateArcNodetoPwrTrnRel;

public class ArcNodeToPwrtrnRelHandler extends AbstractHandler {
	
	private TCSession tcsession;
	private TCComponent selectedobjs;
	 private String objType;
	 private String moduleAddress;
	 private String projectCodeS;
	 private String designGroupS;
	 private String roleName;
	 private String ErrMsg;
	 private String selecteditem;
	 private String ExistingEngType;
	 private String userIdS;
	 private int AccessFlag;
	 private String bypassUser;
		private int ModuleErrFlag=0;
		private boolean bypassflg=false;
		//
		private TCComponent[] queryControlObjs(String queryname ,String []qryNames,String []qryValues) throws TCException
	    {
	                 
		 	TCComponent []qryResults          = null;
			//System.out.println(" In Query for DML ::"+queryname);  
			TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();		        
			try {
				   // System.out.println(" Before setting the session ::");  
					TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");                     
					TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);//"Item...");
					//System.out.println(" After setting the session ::");                                                 
					
	   
					if (mmcomponentquery != null)				     
					{
			            //System.out.println(" Results found ::"); 
		                qryResults=mmcomponentquery.execute(qryNames,qryValues);
					}
					
			
					 
				} catch (TCException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
			
			return qryResults; 
		}	
		private boolean bypassfunc(String sessionuser) {
			// TODO Auto-generated method stub
			
			//tempCHCHBbypassUser = new HashSet<String>();
			//String[] CHCHBbypassUserArr = null;
			TCComponent[] contrlObjs = null;
			boolean retstate=false;
			/* String qry="ControlObjects"; 	

			 String []qryNames	= new String[]{"SYSCD"};
			 String []qryValues	= new String[]{plant};
			 */
			 String qry="Control Objects..."; 
			 String []qryNames	= new String[]{"SUBSYSCD"};
			 String []qryValues	= new String[]{"ArcNodeToPwrtrnRel"};
			 try {
				 contrlObjs =(TCComponent[])queryControlObjs(qry, qryNames, qryValues);
				 if(contrlObjs != null)
				 {
					 if(contrlObjs.length >0)
					 {
						 for(int c=0;c<contrlObjs.length;c++)
						 {
							 String ctrlClass = "";
							 ctrlClass = contrlObjs[c].getStringProperty("object_type");
							 if(!ctrlClass.equals("T5_ControlObject"))
							 {
								 System.out.println("Not a Control Object Class");
								 continue;
							 }
							 else
							 {

									 String syscdStr = "";
									 syscdStr = contrlObjs[c].getStringProperty("t5_SubSyscd");
									 String plantFromCtr = "";
									 plantFromCtr = contrlObjs[c].getStringProperty("t5_Userinfo1");
									 System.out.println("t5_Userinfo1==>" + plantFromCtr + "\nSubsyscdStr==>" + syscdStr);
									 // if(syscdStr.equals(plant))
									 
										 System.out.println("syscd==>" + syscdStr + "\nSubsyscdStr==>" + syscdStr +"sessionuser="+sessionuser);
										 bypassUser ="";
										 bypassUser = contrlObjs[c].getStringProperty("t5_Syscd");
										 System.out.println("bypassUser==>" + bypassUser);
										if (bypassUser.contains(sessionuser))
										{
											 System.out.println("bypassUser==>" + bypassUser +"sessionuser="+sessionuser);
											 retstate= true;
										}
										else
										{
											retstate= false;
										}
										 
									 
									
								 
								 
							 }
						 }
					 }
				 }
				 
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
			 System.out.println("End of Function bypassfunc");
			 return retstate;
		}
		//End
	public Object execute(ExecutionEvent event) throws ExecutionException {
		
		System.out.println("Hello I am In Code CreateArcNodetoPwrTrnRelHandler");
		
		tcsession=(TCSession)AIFUtility.getActiveDesktop().getCurrentApplication().getSession();
		
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		
		Shell parentshell=window.getShell();
		//InterfaceAIFComponent[] selectedobjs=getTargetComponents();
		
		IStructuredSelection theSelection = (IStructuredSelection) HandlerUtil.getCurrentSelection(event);
		AIFComponentContext aifctxt=(AIFComponentContext)theSelection.getFirstElement();
		selectedobjs  = (TCComponentItemRevision) aifctxt.getComponent();
		objType=selectedobjs.getType();
//		if(selectedobjs instanceof TCComponentItemRevision )
	    {
	    	System.out.println("Allowed this option");
	    	TCComponentItemRevision selectedObj = (TCComponentItemRevision) selectedobjs;// selectedobject.getComponent();	

	    	
	    	
			
			TCComponentUser user = tcsession.getUser();
			//TCComponentGroup[] grps = user.getGroups();
			
			
			
			
			
			
			int grpFlag = 0;
			TCComponentGroup[] grps;
			
			TCComponentGroup ercDesignGrp = null;
			
			
			System.out.println("in Arc Node to Powertrain Module Relation Dialog objType="+objType);
			
			try {
				userIdS = user.getUserId();
				//Start
				System.out.println("b4 bypassflg="+bypassflg);
				  bypassflg=bypassfunc(userIdS);
				 System.out.println("bypassflg="+bypassflg);
				//End
			} catch (TCException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			System.out.println("\nSession User Login Name == " + userIdS + "\n");
			
			
			
//			if(objType.equals("TCComponentItemRevision")|| objType.equals("Design Revision"))
			//{
				try {
					selecteditem=selectedObj.getTCProperty("item_id").getDisplayableValue();
					ExistingEngType=selectedObj.getTCProperty("object_type").getDisplayableValue();
					System.out.println("ObjectType="+ExistingEngType +" " +"selecteditem="+selecteditem );
					//TCComponentItemRevision Rev= (TCComponentItemRevision) selectedObj.getRelatedComponent("revision_list");
					if(ExistingEngType.equals("Architecture Module Revision"))
					//if(Rev!=null)
					{
						moduleAddress=selectedObj.getTCProperty("t5_ArchModuleAddress").getDisplayableValue();
						projectCodeS = selectedObj.getProperty("t5_ArchProjectCode");
						designGroupS = selectedObj.getProperty("t5_ArchDesignGrp");
						System.out.println("\nProject Code == " + projectCodeS + " :: Design Group == " + designGroupS +"moduleAddress="+moduleAddress);
					}
					else
					{
						MessageBox.post(parentshell,"Select the valid Architecture Module Revision only  !!!","WARNING",SWT.ICON_INFORMATION);
						return false;
					}
					
						
					System.out.println("moduleAddress="+moduleAddress);
					
					
					
					
					//TCComponentItemRevision[] Rev= (TCComponentItemRevision[]) selectedObj.getReferenceProperty("revision_list");
					
					//moduleAddress=Rev.getTCProperty("t5_ModuleAddress").getDisplayableValue();
					System.out.println("111ExistingEngType="+ExistingEngType +" " +"selecteditem="+selecteditem  +" " +"moduleAddress="+moduleAddress);
				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("tttt bypassflg="+bypassflg);
				
				if (userIdS.compareToIgnoreCase("infodba") == 0 || userIdS.compareToIgnoreCase("loader") == 0 || (bypassflg==true))
				{
					System.out.println("\nBypass for Admin Login\n");
					AccessFlag++;
				}
				else
				{				
				
				try {
					
					System.out.println("user getGroupMembers="+user.getGroupMembers()[0].toString());
					grps = user.getGroups();
					
					for (TCComponentGroup grp : grps)
					{
						String grpName = grp.getGroupName();
						System.out.println("1grpName="+grpName.toString());
						
						if (grpName.contains("Designers") || grpName.contains("Managers"))
						{
							ercDesignGrp = grp;
							//if(grpName.contains(designGroupS))
							//{
								grpFlag = 1;
								break;
							//}
							
						}
					}
					if(grpFlag==1)
					{	
						TCComponentRole[] roles = user.getRoles(ercDesignGrp);
						for (TCComponentRole role : roles)
						{
							roleName = role.getRoleName();
							System.out.println("11user Role="+roleName);
							String temDesgrp=designGroupS+"_"+"Designers";
							String temMangrp=designGroupS+"_"+"Managers";
							System.out.println("temDesgrp="+temDesgrp.toString() +"temMangrp="+temMangrp);
							if (roleName.contains(temMangrp) || roleName.contains(temDesgrp))
							{
								System.out.println("user having Role Access="+roleName);
								
							}
							
							
						}
						System.out.println("user Role="+roleName);
						
						String[] projectIds = user.getProjectNames();
						for (String projectID : projectIds)
						{
							System.out.println("user projectID="+projectID);
							if(projectID.contains(projectCodeS))
							{
								AccessFlag++;
							}
							
						}
					}
					
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
				ModuleErrFlag=0;
				System.out.println(" AccessFlag="+AccessFlag +"11moduleAddress="+moduleAddress +"start ModuleErrFlag="+ModuleErrFlag);
				if(AccessFlag>0)
				{
					
					if(moduleAddress.equalsIgnoreCase("MP1A01"))
					{
						System.out.println("Allow to uopdate Engine Type for Module"+selecteditem);
						
					}
					else
					{
						ModuleErrFlag++;
						ErrMsg="Selected Module must belongs to Powertrain Module(MP1A01) for Engine Type update, for Further Contact PLM Administrator";
						//MessageBox.post(parentShell,"Selected Module must belongs to Powertrain Module(MP1A01) for Engine Type update, for Further Contact PLM Administrator","ERROR",SWT.ICON_WARNING);
						//return; 
					}
				}
				else
				{
					ModuleErrFlag++;
					ErrMsg="Project & Design Group Access required for this, for Further Contact PLM Administrator";
					
				}
				
			/*}
			else
			{
				System.out.println("Selected Part is not valid to update Engine Type,Pls select Module Master only");
				
				ModuleErrFlag++;
				ErrMsg="Selected Part is not valid to update Engine Type,Pls select Module Master only or Contact PLM Administrator";
				
				//MessageBox.post(parentShell,"Selected Part is not valid to update Engine Type,Pls select Module Master only or Contact PLM Administrator","ERROR",SWT.ICON_WARNING);
				//return;
			}
			System.out.println("ModuleErrFlag="+ModuleErrFlag +"ErrMsg="+ErrMsg);*/
			
		
	    	
	    	
	    	
				// new TechSpecUtil().invokeDlg(parentshell,tcsession,event, selectedObj);
				
				//CreateArcNodetoPwrTrnRel CreateArcNodetoPwrTrnRelDlg = new CreateArcNodetoPwrTrnRel(parentshell,tcsession, selectedobjs,event);
				//CreateArcNodetoPwrTrnRelDlg.open();  
				
				ArcNodeToPwrTrnModRelDlg CreateArcNodetoPwrTrnRelDlg = new ArcNodeToPwrTrnModRelDlg(parentshell,tcsession, selectedobjs,event);
				CreateArcNodetoPwrTrnRelDlg.open();
				//CreateArcNodetoPwrTrnRel CreDlg= new CreateArcNodetoPwrTrnRel(parentshell,tcsession, selectedobjs,event);
				
	    
		
//		System.out.println("ModuleErrFlag="+ModuleErrFlag +"ErrMsg="+ErrMsg);
//		if(ModuleErrFlag>=1)
//		{
//			MessageBox.post(parentshell,ErrMsg,"ERROR",SWT.ICON_WARNING);
//			return null;
//		}
//		else
//		{
//			CreateArcNodetoPwrTrnRel CreateArcNodetoPwrTrnRelDlg = new CreateArcNodetoPwrTrnRel(parentshell,tcsession, selectedobjs);
//			CreateArcNodetoPwrTrnRelDlg.open();
//			
//		}
    	
	    
		
		
		//MessageBox.post(parentshell, "Please Select DML. Selection is Empty !!", "DML Transfer Error !!", MessageBox.ERROR);
			//}
	    }
				return null;
				
				
	   	
			}
		
	private InterfaceAIFComponent[] getTargetComponents() {
		// TODO Auto-generated method stub
		return null;
	
	}

}
