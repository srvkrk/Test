package com.tml.techspec.handlers;

import java.util.Vector;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.handlers.HandlerUtil;

import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.classification.icadmin.ICAAdminApplication;
import com.teamcenter.rac.classification.icadmin.ICAdminContext;
import com.teamcenter.rac.classification.icadmin.keylov.ICAKeyLOVContext;
import com.teamcenter.rac.classification.icadmin.keylov.operations.ICAKeyLOVCreateorUpdateOperation;
import com.teamcenter.rac.common.handlers.AbstractTCHandler;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentSiteType;
import com.teamcenter.rac.kernel.TCSiteInfo;
import com.teamcenter.rac.kernel.ics.ICSKeyLovValue;
import com.tml.classification.modules.TMLKeyLOVCreateorUpdateOperation;
import com.tml.techspec.dialogs.TMLCreateUpdateLOVDialog;

public class TMLCreateUpdateLOVHandler  extends AbstractTCHandler{

	
	protected void tcExecute() throws Exception {
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		System.out.println("inside the TMLCreateUpdateLOVHandler= "+app.getApplicationId());
		//if(app instanceof ICAAdminApplication)
		{
			
			IStructuredSelection theSelection = (IStructuredSelection) HandlerUtil.getCurrentSelection(this.m_event);
			Object selection=theSelection.getFirstElement();
			//System.out.println("gffdfddds::"+selection.getClass());
			System.out.println("gffdfddds::");
			//ICAAdminApplication icsapp=(ICAAdminApplication)app ;
			ICAAdminApplication icsapp=new ICAAdminApplication() ;
			//TMLCreateUpdateLOVDialog dlg= new TMLCreateUpdateLOVDialog(icsapp.getDesktop().getShell(),icsapp);
			TMLCreateUpdateLOVDialog dlg= new TMLCreateUpdateLOVDialog(icsapp.getDesktop().getShell(),icsapp);
			
			dlg.open();
			
			//ICAdminContext admintx=new ICAdminContext(icsapp,"ICA");
			//admintx.getKeyLOVContext().getICSAdminKeyLOV().load("-1001");
			//ICAKeyLOVContext m_context=admintx.getKeyLOVContext();
			
		//	ICAKeyLOVCreateorUpdateOperation op = new ICAKeyLOVCreateorUpdateOperation(m_context);
			//m_context.setICAKeyLOVPanel(arg0)
			//TMLKeyLOVCreateorUpdateOperation  op = new TMLKeyLOVCreateorUpdateOperation(m_context);
		  // op.executeOperation();
		}
		
		
			
		
	}

}
