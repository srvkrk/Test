package com.tml.techspec.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
//import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.common.handlers.AbstractTCHandler;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.soa.exceptions.NotLoadedException;
//import com.temcenter.techspec.forms.ModuleClassificationDialog;
import com.tml.classification.modules.GetClassifiedAttr;
import com.tml.classification.modules.ICOValues;
import com.tml.classification.modules.TechSpecUtil;
import com.tml.techspec.dialogs.ModuleClassificationDialog;
import com.tml.techspec.dialogs.UpdateTechSpecDialog;

public class UpdateModuleClassification extends AbstractTCHandler{
	
	private ICOValues val =null;
	
	
	public void tcExecute() throws Exception  {
		/*IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		MessageDialog.openInformation(
				window.getShell(),
				"Modules",
				"Hello, Eclipse world");*/
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(this.m_event);
		Shell shell =window.getShell();
	//	ModuleInfoDialog dialog = new ModuleInfoDialog(shell);
		//LoginTCFun();
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		TCSession session=(TCSession) app.getSession();
		//TCSession session=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		System.out.println("Session User:----------  "+session.getUser());
		AIFComponentContext selectedobject=null;
		final ISelection selection = HandlerUtil.getCurrentSelection(this.m_event);
		
		InterfaceAIFComponent[] selectedobjs=getTargetComponents();
		
		//calling
		String VehTSBuinessUnit=null;
				
	   // selectedobject=(AIFComponentContext)((IStructuredSelection)selection).getFirstElement();
	    
	   
	    if(selectedobjs[0] instanceof TCComponentItemRevision || selectedobjs[0] instanceof TCComponentSavedVariantRule)
	    {
	    	System.out.println("Allowed this option update technical specification attributes");
	    	TCComponent selectedObj = (TCComponent) selectedobjs[0];// selectedobject.getComponent();	

	    	//for VC Update
	    	String SelobjType= selectedObj.getType();

	    	System.out.println("\nSelobjType="+SelobjType);

	    	String SelectedPartType = selectedObj.getPropertyDisplayableValue("t5_PartType");
	    	System.out.println("SelectedPartType:-"+SelectedPartType +"SelectedPartType.matches(\"Vehicle\")="+SelectedPartType.matches("Vehicle"));

	    	if(SelectedPartType.equals("Vehicle") || SelectedPartType.equals("Vehicle Combination") || SelectedPartType.equals("Configurable VC") || SelobjType.equals("T5_TSCompRevision") || SelectedPartType.equals("Module")|| SelectedPartType.equals("Vehicle Combination CR"))
	    		//if(SelectedPartType.equals("Vehicle")==false)
	    	{

	    		if(SelobjType.equals("T5_TSCompRevision")) //Case :1 Selected Object is techspec-Header
	    		{
	    			VehTSBuinessUnit = selectedObj.getPropertyDisplayableValue("t5_VCClassName");
	    			System.out.println("Tech Spec BuinessUnit:----------  "+VehTSBuinessUnit);
	    		}			

	    		if(SelectedPartType.equals("Vehicle") || SelectedPartType.equals("Vehicle Combination") || SelectedPartType.equals("Configurable VC")|| SelectedPartType.equals("Vehicle Combination CR"))
	    		{
	    			TCComponent[] TechSpecObj=  selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
	    			//TCComponent CmvrObj=TechSpecUtil.SecondaryToPrimary("T5_CmvrVeh",(TCComponentItemRevision) selectedObj);
	    			//				TCComponentItem CmvrObj=(TCComponentItem) selectedObj.getReferenceProperty("t5_VehForCmvr");  // getReferenceValue();
	    			//				String cmvrno=null;
	    			//				if (CmvrObj!=null)
	    			//				{
	    			//				cmvrno=CmvrObj.getTCProperty("t5_CmvrNo").getDisplayableValue();
	    			//				}
	    			//				System.out.println("cmvrno:----------  "+cmvrno);
	    			String retcmvrno=null;
	    			int TSByPassNRChkflg=0;
	    			retcmvrno = TechSpecUtil.getCmvrNoFrmVC((TCComponentItemRevision) selectedObj,retcmvrno);
	    			System.out.println("retcmvrno:----------  "+retcmvrno);
	    			//return ;

	    			//String rev=null;
	    			String RevSeq=selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
	    			System.out.println("RevSeq:----------  "+RevSeq);

	    			//newly added
	    			
	    			//boolean Hybridstatus=new TechSpecUtil().getHybridVCFlag(session,(TCComponentItemRevision) selectedObj);
					//System.out.println("Hybrid status  "+Hybridstatus);
	    			
	    			TCComponentUser user = session.getUser();
	    			String userIdS=null;
	    			try {
	    				userIdS = user.getUserId();
	    			} catch (TCException e) {
	    				// TODO Auto-generated catch block
	    				e.printStackTrace();
	    			}
	    			//Start
	    			System.out.println("userIdS="+userIdS);

	    			boolean bypassUsrflg=new TechSpecUtil().bypassUsrfunc(userIdS,"ByPassUser");
	    			 System.out.println("bypassflg="+bypassUsrflg);
	    			 TSByPassNRChkflg=new TechSpecUtil().getControlObj("TSByPassNRChk");
	    			 System.out.println("in UpdateModuleClassification dlg TSByPassNRChkflg="+TSByPassNRChkflg);
	    			if ((bypassUsrflg==true)|| (userIdS.contains("loader")||userIdS.contains("infodba")))
	    			{
	    				//
	    				System.out.println("allow this option with edit mode for user="+userIdS);
	    			}
	    			else
	    			{
	    				if(TSByPassNRChkflg<=0)
	    				{
	    					if(RevSeq.contains("NR")==false)
	    					{

	    						boolean answer=MessageDialog.openQuestion(shell,"TechSpec Update Validation","VC attributes should not updated by Revised VC process, pls take MDM DML to update it.if you want see the VC attributes value in Read Only Mode then click on Ok else No");
	    						System.out.println("answer:----------  "+answer);
	    						if(answer==true)
	    						{
	    							System.out.println("User selected Yes ,therefore read only classification dialog would appear!! ");
	    						}
	    						else
	    						{
	    							System.out.println("User selected No , therefore read only classification dialog would not be appear!! ");
	    							return ;
	    						}
	    						//MessageBox.post(shell,"VC attributes should not updated by Revised VC process, pls take MDM DML to update it!","WARNING",SWT.ICON_WARNING);
	    						//return ;
	    					}
	    				}
	    			}
	    			if(TechSpecObj!=null && TechSpecObj.length>0)
	    			{
	    				VehTSBuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
	    				System.out.println("Veh/CCVC BuinessUnit:----------  "+VehTSBuinessUnit);


	    			}
	    		}

	    		new TechSpecUtil().invokeDlg(shell,session,this.m_event, selectedObj,VehTSBuinessUnit);

	    	}
	    	else
	    	{

	    		System.out.println("not valid part Type is not VC/Vehicle/Module/Technical Specification Revision, option only valid for Vehicle/Module");

	    		MessageBox.post(shell,"Part Type VC/Vehicle/Module Revision/Technical Specification Revision only allowed for this option!","WARNING",SWT.ICON_WARNING);
	    		return ;
	    	}
	    }
	    else
	    {
	    	System.out.println("class type is not TCComponentItemRevision or Type is not VC/Vehicle/Module/Technical Specification Revision, option only valid for Vehicle/Module");
			
	    	MessageBox.post(shell,"Part Type VC/Vehicle/Module Revision/Technical Specification Revision only allowed for this option!","WARNING",SWT.ICON_WARNING);
	    	
			/* MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
	               messageBox1.setText("Information.");
	               messageBox1.setMessage("Part Type Vehicle/Module Revision only allowed for this option ");
	               messageBox1.open(); */ 
	               
	               return ;
	    }
	    	
	 /*   TCComponent selectedObj = (TCComponent) selectedobjs[0];// selectedobject.getComponent();	
	    
	    new TechSpecUtil().invokeDlg(shell,session,this.m_event, selectedObj);*/
	    
	  /* String SelobjType= selectedObj.getType();
	   try {
		System.out.println("selectedObj.getTCProperty.getDisplayableValue()="+selectedObj.getPropertyDisplayableValue("t5_TechSNumDes"));
	} catch (NotLoadedException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
	   System.out.println("\nSelobjType="+SelobjType);
	   if(SelobjType.equals("T5_TSCompRevision"))
	   {
		 
		   TCComponentItemRevision VCObj = null;
		try {
			VCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
			System.out.println("VCObj:-"+VCObj);
			if(VCObj==null) //need to discuss for this msg
			{
				System.out.println("Tech Spec does not relate with any vehicle, so Update Technical specification attribute can't invoke");
				
				 MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
		               messageBox1.setText("Warning.");
		               messageBox1.setMessage("Tech Spec does not relate with any vehicle, so Update Technical specification attribute can't invoke !!!");
		               messageBox1.open();  
		               
		               return null;
			}
			
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			if(VCObj!=null)
			{
				UpdateTechSpecDialog UpdTechObj= new UpdateTechSpecDialog(shell,session,VCObj,selectedObj);
			    UpdTechObj.open();
			}
		   
	    
	   }
	   else
	   {
			   String modulenum=null;
			   String SelectedObjType=null;
			   String BuinessUnit=null;
			   String revid=null;
			try {
				modulenum = selectedObj.getPropertyDisplayableValue("item_id");
				revid = selectedObj.getPropertyDisplayableValue("item_revision_id");
				System.out.println("modulenum====="+modulenum +"revid"+revid);
				//for VC Update
				SelectedObjType = selectedObj.getPropertyDisplayableValue("t5_PartType");
				System.out.println("SelectedObjType:-"+SelectedObjType);
				if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") )
				{
					System.out.println("part Type is Vehicle/Module, process can execute");
				}
				else
				{
					
					System.out.println("part Type is not Vehicle/Module, option only valid for Vehicle/Module");
				
					 MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
			               messageBox1.setText("Information.");
			               messageBox1.setMessage("Part Type Vehicle/Module Revision only allowed for this option ");
			               messageBox1.open();  
			               
			               return null;
					
				}
				if(SelectedObjType.equals("Vehicle") )
				{
					TCComponent[] TechSpecObj=  selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
					if(TechSpecObj!=null && TechSpecObj.length>0)
					{
						BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
						System.out.println("BuinessUnit:----------  "+BuinessUnit);
					}
					
					
				}
				
				
				
			} catch (Exception  e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
				System.out.println("Selected part Number====="+selectedObj.toString());
				
				GetClassifiedAttr getProps= new GetClassifiedAttr(selectedObj,session);
				try {
					val=getProps.getICOProps();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ModuleClassificationDialog updateDialog= null;//new ModuleClassificationDialog(shell,"","",modulenum,SelectedObjType,session);
				String moduleaddress="";
					
				if(SelectedObjType.equals("Vehicle"))
				{
					moduleaddress=BuinessUnit+"VCATTR01";
					//updateDialog= new ModuleClassificationDialog(shell,BuinessUnit+"VCATTR01",modulenum+"/NR;1",modulenum,SelectedObjType,session);
					//Added on 27082018
					
					
					
					try {
						TCComponent[] TechSpecObj=  selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
						System.out.println("TechSpecObj.length="+TechSpecObj.length);
						if(TechSpecObj!=null && TechSpecObj.length>0)
						{
							BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
							System.out.println("BuinessUnit:----------  "+BuinessUnit);
						}
						else
						{
							System.out.println("Vehicle does not relate with any Tech Spec, so Update Technical specification attribute can't invoke");
							
							 MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
					               messageBox1.setText("Warning.");
					               messageBox1.setMessage("Vehicle does not relate with any Tech Spec, so Update Technical specification attribute can't invoke !!!");
					               messageBox1.open();  
					               
					               return null;
						}
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//End
				}
				else 
				{
					try {
						moduleaddress=selectedObj.getPropertyDisplayableValue("t5_ModuleAddress");
					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//updateDialog= new ModuleClassificationDialog(shell,"","",modulenum,SelectedObjType,session);
				}
				
				//updateDialog= new ModuleClassificationDialog(shell,moduleaddress,modulenum+"/NR;1",modulenum,SelectedObjType,session);
				updateDialog= new ModuleClassificationDialog(shell,moduleaddress,modulenum+"/"+revid,modulenum,SelectedObjType,session);
				if(val !=null)
					updateDialog.updateICOVal(val)	;
				updateDialog.open();
	}	*/
		//updateDialog.
			
		/*TCComponentSite SessionSite = session.getCurrentSite();
		session.getPreferenceService().getStringValue("ARM_delete_objects");
		System.out.println("SessionSite and ARM delete objects values are: -------   "+SessionSite);
		System.out.println("ARM delete objects values are: -------   "+session.getPreferenceService().getStringValue("ARM_delete_objects"));
		
		String[] values =  session.getPreferenceService().getStringValues("Mfg0MEStudy_ColumnWidthPreferences");
		int len = session.getPreferenceService().getStringValues("Mfg0MEStudy_ColumnWidthPreferences").length;
		System.out.println("SessionSite -------   "+SessionSite);
		System.out.println("lenght  -------   "+len);
		
		for (int i = 0; i < len; i++) 
		{
			System.out.println("ARM delete objects values are: -------   "+values[i]);
		}*/
			
		
		
		/*AIFComponentContext selectedobject=null;
		final ISelection selection = HandlerUtil.getCurrentSelection(event);
		
				
	    selectedobject=(AIFComponentContext)((IStructuredSelection)selection).getFirstElement();
	    TCComponent selectedObj = (TCComponent) selectedobject.getComponent();		
		System.out.println("Selected part Number====="+selectedObj.toString());
		
		dialog.getselectedobj(selectedObj);
		
		dialog.open();	*/
		
		
		return ;
	}
	
	private void LoginTCFun() {
		// TODO Auto-generated method stub
		
	}

	
}
