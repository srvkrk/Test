package com.tml.techspec.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;
//import org.eclipse.ui.handlers.HandlerUtil;
//import org.eclipse.jface.dialogs.MessageDialog;
//import org.eclipse.jface.viewers.ISelection;
//import org.eclipse.jface.viewers.IStructuredSelection;

//import com.teamcenter.com.modules.handlers.ModuleInfoDialog;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
//import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
//import com.teamcenter.rac.kernel.TCComponent;
//import com.teamcenter.rac.kernel.TCComponentSite;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
//import com.teamcenter.rac.ui.commands.create.bo.NewBOWizard;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class CreateModuleHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public CreateModuleHandler() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context.
	 */
	public Object execute(ExecutionEvent event) throws ExecutionException {
		/*IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		MessageDialog.openInformation(
				window.getShell(),
				"Modules",
				"Hello, Eclipse world");*/
		
		Shell shell = new Shell();
		//ModuleInfoDialog dialog = new ModuleInfoDialog(shell);
		//LoginTCFun();
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		TCSession session=(TCSession) app.getSession();
		System.out.println("Session User:----------  "+session.getUser());
	
		/*TCComponentSite SessionSite = session.getCurrentSite();
		session.getPreferenceService().getStringValue("ARM_delete_objects");
		System.out.println("SessionSite and ARM delete objects values are: -------   "+SessionSite);
		System.out.println("ARM delete objects values are: -------   "+session.getPreferenceService().getStringValue("ARM_delete_objects"));
		
		String[] values =  session.getPreferenceService().getStringValues("Mfg0MEStudy_ColumnWidthPreferences");
		int len = session.getPreferenceService().getStringValues("Mfg0MEStudy_ColumnWidthPreferences").length;
		System.out.println("SessionSite -------   "+SessionSite);
		System.out.println("lenght  -------   "+len);
		
		for (int i = 0; i < len; i++) 
		{
			System.out.println("ARM delete objects values are: -------   "+values[i]);
		}*/
			
		
		
		AIFComponentContext selectedobject=null;
		final ISelection selection = HandlerUtil.getCurrentSelection(event);
		
				
	    selectedobject=(AIFComponentContext)((IStructuredSelection)selection).getFirstElement();
	    TCComponent selectedObj = (TCComponent) selectedobject.getComponent();		
		System.out.println("Selected part Number====="+selectedObj.toString());
		
		//dialog.getselectedobj(selectedObj);
		
		//.open();	
		//
		
		return null;
	}
	
	private void LoginTCFun() {
		// TODO Auto-generated method stub
		
	}	
}
