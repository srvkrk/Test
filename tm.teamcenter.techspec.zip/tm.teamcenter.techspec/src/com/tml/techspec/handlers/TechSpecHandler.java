package com.tml.techspec.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Shell;

import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.soa.exceptions.NotLoadedException;
import com.tml.classification.modules.TechSpecUtil;
import com.tml.techspec.dialogs.CreateTechSpec;
import com.tml.techspec.dialogs.cpyVcAttrS;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class TechSpecHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public TechSpecHandler() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context.
	 */
	public Object execute(ExecutionEvent event) throws ExecutionException {
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		/*MessageDialog.openInformation(
				window.getShell(),
				"TechSpec",
				"Hello, Eclipse world");*/
		
		Shell shell =window.getShell();
		String info=null;
		//	ModuleInfoDialog dialog = new ModuleInfoDialog(shell);
			//LoginTCFun();
			//AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
			TCSession session=(TCSession) app.getSession();
			System.out.println("inside CreateTechSpecHandler Session User:----------  "+session.getUser());
			
			
			String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
			String [] qryValues={"CreTechSpec","Live","0"};
			//int r;
			TCComponent[] objvec;
			try {
				objvec = TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
				
				if(objvec!=null)
				{
					for(int f=0;f<objvec.length;f++)
					{
						TCComponent objcntrl=objvec[f];
						
						
							
						
							 info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
							 if(info!=null)
							 {
							 info+=objcntrl.getPropertyDisplayableValue("t5_Userinfo2");
							 }
							 else
							 {
								 info=objcntrl.getPropertyDisplayableValue("t5_Userinfo2");
							 }
				
					}
				}
				
				System.out.println("in CreateTechSpecHandler session user = "+session.getUser().getUserId().toString() +" valid user to access ="+info);
				if(info==null)
				{
					MessageBox.post(shell,"This option has been revoked as per requirement, Contact PLM Support Team for more details  !!!","WARNING",SWT.ICON_INFORMATION);
					return null;
				}
				else if(info.contains(session.getUser().getUserId().toString()))
				{
					CreateTechSpec TSFrm=new CreateTechSpec(window.getShell());
					TSFrm.open();
				}
				else
				{
					MessageBox.post(shell,"This option has been revoked as per requirement, Contact PLM Support Team for more details  !!!","WARNING",SWT.ICON_INFORMATION);
					//return false;
				} 
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NotLoadedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			System.out.println("End CreateTechSpecHandler call !! ");
		
		//CreateTechSpec TSFrm=new CreateTechSpec(window.getShell());
		//TSFrm.open();
		return null;
	}
}
