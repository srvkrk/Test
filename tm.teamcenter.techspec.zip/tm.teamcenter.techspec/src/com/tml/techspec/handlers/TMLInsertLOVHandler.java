package com.tml.techspec.handlers;

import java.util.Vector;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.ui.handlers.HandlerUtil;

import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.classification.icadmin.ICAAdminApplication;
import com.teamcenter.rac.classification.icadmin.ICAdminContext;
import com.teamcenter.rac.classification.icadmin.keylov.ICAKeyLOVContext;
import com.teamcenter.rac.classification.icadmin.keylov.operations.ICAKeyLOVCreateorUpdateOperation;
import com.teamcenter.rac.common.handlers.AbstractTCHandler;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentSiteType;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCSiteInfo;
import com.teamcenter.rac.kernel.ics.ICSKeyLovValue;
import com.teamcenter.rac.util.MessageBox;
import com.tml.classification.modules.TMLKeyLOVCreateorUpdateOperation;
import com.tml.classification.modules.TechSpecUtil;
import com.tml.techspec.dialogs.TMLCreateUpdateLOVDialog;
import com.tml.techspec.dialogs.TMLInsertLOVDialog;

public class TMLInsertLOVHandler  extends AbstractTCHandler{

	
	protected void tcExecute() throws Exception {
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		//if(app instanceof ICAAdminApplication)
		{
			
			/*IStructuredSelection theSelection = (IStructuredSelection) HandlerUtil.getCurrentSelection(this.m_event);
			Object selection=theSelection.getFirstElement();
			System.out.println("gffdfddds::"+selection.getClass());*/
			//ICAAdminApplication icsapp=(ICAAdminApplication)app ;
			
			System.out.println("Inside the TMLInsertLOVHandler::");
			
			TCSession session=(TCSession) app.getSession();
			System.out.println("inside TMLInsertLOVHandler Session User:----------  "+session.getUser());
			
			
			String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
			String [] qryValues={"AddLovTechSpec","Live","0"};
			//int r;
			TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
			String info=null;
			if(objvec!=null)
			{
				for(int f=0;f<objvec.length;f++)
				{
					TCComponent objcntrl=objvec[f];
					
						 info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
			
				}
			}
			System.out.println("in TMLInsertLOVHandler session user = "+session.getUser().getUserId().toString() +" valid user to access ="+info);
			if(info==null)
			{
				MessageBox.post(app.getDesktop().getShell(),"This option is not valid for your login and only accessible for PLM Support Team, Contact PLM Support Team for more details  !!!","WARNING",SWT.ICON_INFORMATION);
				//return false;
			}
			else if(info.contains(session.getUser().getUserId().toString()))
			{
			TMLInsertLOVDialog dlg= new TMLInsertLOVDialog(app.getDesktop().getShell());
			
			dlg.open();
			}
			else
			{
				MessageBox.post(app.getDesktop().getShell(),"This option is not valid for your login and only accessible for PLM Support Team, Contact PLM Support Team for more details  !!!","WARNING",SWT.ICON_INFORMATION);
				//return false;
			} 
			//ICAdminContext admintx=new ICAdminContext(icsapp,"ICA");
			//admintx.getKeyLOVContext().getICSAdminKeyLOV().load("-1001");
			//ICAKeyLOVContext m_context=admintx.getKeyLOVContext();
			
		//	ICAKeyLOVCreateorUpdateOperation op = new ICAKeyLOVCreateorUpdateOperation(m_context);
			//m_context.setICAKeyLOVPanel(arg0)
			//TMLKeyLOVCreateorUpdateOperation  op = new TMLKeyLOVCreateorUpdateOperation(m_context);
		  // op.executeOperation();
		}
		
		
			
		
	}

}
