package com.tml.techspec.handlers;

import java.util.Vector;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.classification.icadmin.ICAAdminApplication;
import com.teamcenter.rac.classification.icadmin.ICAdminContext;
import com.teamcenter.rac.classification.icadmin.keylov.ICAKeyLOVContext;
import com.teamcenter.rac.classification.icadmin.keylov.operations.ICAKeyLOVCreateorUpdateOperation;
import com.teamcenter.rac.common.handlers.AbstractTCHandler;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentSiteType;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCSiteInfo;
import com.teamcenter.rac.kernel.ics.ICSKeyLovValue;
import com.teamcenter.rac.util.MessageBox;
import com.tml.classification.modules.TMLKeyLOVCreateorUpdateOperation;
import com.tml.classification.modules.TechSpecUtil;
import com.tml.techspec.dialogs.TechSpecRptDlg;
import com.tml.techspec.dialogs.cpyVcAttrS;

public class TechSpecRptHandler  extends AbstractTCHandler{

	
	protected void tcExecute() throws Exception {
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(this.m_event);
		Shell shell =window.getShell();
	//	ModuleInfoDialog dialog = new ModuleInfoDialog(shell);
		//LoginTCFun();
		//AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		TCSession session=(TCSession) app.getSession();
		System.out.println("inside TechSpecRptHandler Session User:----------  "+session.getUser());
		TCComponentUser user = session.getUser();
		
		String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
		String [] qryValues={"RptTechSpec","Live","0"};
		//int r;
		TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
		String info=null;
		if(objvec!=null)
		{
			for(int f=0;f<objvec.length;f++)
			{
				TCComponent objcntrl=objvec[f];
				
					 info=objcntrl.getPropertyDisplayableValue("t5_Userinfo2");
		
			}
		}
		System.out.println("in TechSpecRptHandler session user = "+session.getUser().getUserId().toString() +" valid user to access ="+info);
		//if(info==null || session.getUser().toString().contains(info))
		//if(info.contains(session.getUser().getUserId().toString()))
		//{
		TechSpecRptDlg dlg= new TechSpecRptDlg(shell);
		dlg.open();
		//}
		//else
		//{
		//	MessageBox.post(shell,"This option is under development, Contact PLM Support Team for more details  !!!","WARNING",SWT.ICON_INFORMATION);
			//return false;
		//} 
		System.out.println("End TechSpecRptHandler call !! ");
//		if(app instanceof ICAAdminApplication)
//		{
//			
//			IStructuredSelection theSelection = (IStructuredSelection) HandlerUtil.getCurrentSelection(this.m_event);
//			Object selection=theSelection.getFirstElement();
//			System.out.println("gffdfddds::"+selection.getClass());
//			ICAAdminApplication icsapp=(ICAAdminApplication)app ;
//			
//			cpyVcAttrS dlg= new cpyVcAttrS(shell);
//			
//			dlg.open();
//			
//			
//		}
		
		
			
		
	}

}
