package com.tml.techspec.dialogs;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class Create extends TitleAreaDialog {
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text_4;
	private Text text_5;
	private Text text_6;

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public Create(Shell parentShell) {
		super(parentShell);
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	protected Control createDialogArea(Composite parent) {
		setTitle("Create Technical Specification Header Dialog");
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setBounds(29, 10, 68, 15);
		lblNewLabel.setText("Project Code");
		
		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setBounds(29, 41, 102, 15);
		lblNewLabel_1.setText("Owner Desgin Dept");
		
		Label lblNewLabel_2 = new Label(container, SWT.NONE);
		lblNewLabel_2.setBounds(29, 75, 99, 15);
		lblNewLabel_2.setText("Owner Design Unit");
		
		Label lblNewLabel_3 = new Label(container, SWT.NONE);
		lblNewLabel_3.setBounds(29, 113, 19, 15);
		lblNewLabel_3.setText("Rev");
		
		Label lblNewLabel_4 = new Label(container, SWT.NONE);
		lblNewLabel_4.setBounds(29, 150, 68, 15);
		lblNewLabel_4.setText("VC Sub Class");
		
		Label lblNewLabel_5 = new Label(container, SWT.NONE);
		lblNewLabel_5.setBounds(29, 197, 185, 15);
		lblNewLabel_5.setText("Techincal Specification Description");
		
		Label lblNewLabel_6 = new Label(container, SWT.NONE);
		lblNewLabel_6.setBounds(29, 246, 77, 15);
		lblNewLabel_6.setText("Work Location");
		
		text = new Text(container, SWT.BORDER);
		text.setBounds(307, 7, 201, 21);
		
		text_1 = new Text(container, SWT.BORDER);
		text_1.setBounds(307, 38, 201, 21);
		
		text_2 = new Text(container, SWT.BORDER);
		text_2.setBounds(307, 72, 201, 21);
		
		text_3 = new Text(container, SWT.BORDER);
		text_3.setBounds(307, 110, 201, 21);
		
		text_4 = new Text(container, SWT.BORDER);
		text_4.setBounds(307, 147, 201, 21);
		
		text_5 = new Text(container, SWT.BORDER);
		text_5.setBounds(307, 194, 201, 21);
		
		text_6 = new Text(container, SWT.BORDER);
		text_6.setBounds(307, 243, 201, 21);

		return area;
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,
				true);
		createButton(parent, IDialogConstants.CANCEL_ID,
				IDialogConstants.CANCEL_LABEL, false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	protected Point getInitialSize() {
		return new Point(736, 504);
	}
}
