package com.tml.techspec.dialogs;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
//import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Table;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.layout.TableColumnLayout;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.IColorProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.ColumnPixelData;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.Viewer;



import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

//import com.teamcenter.com.modules.handlers.ModuleInfoDialog;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2011_12.Classification.AttributeValues;
import com.teamcenter.services.rac.classification._2011_12.Classification.Value;
import com.tml.classification.modules.ClassificationLineProvider;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.CreateOrUpdateICOSample;
import com.tml.classification.modules.GetClassDescriptions;
import com.tml.classification.modules.GetKeyLOVs2Sample;
import com.tml.classification.modules.GetModuleAttributesForClasses;
import com.tml.classification.modules.ICOValues;

public class ModuleClassificationDialog extends TitleAreaDialog {
	private Text text;
	private String ModuleAddress;
	private String ObjectID;
	private TCSession session;
	private ClassificationLineProvider tabLineModel;
	private ArrayList<ClassificationTableLine> classificationList;
	private HashMap <String,Object> namevalueP;
	private Map<String,String> arrayAttr;
	private Table table;
	private TableViewer tableViewer;
	private Text text_1;
	private ICOValues icoval;
	private Text text_2;
	private String ModuleNum;
	private String SelObjType;
	private ClassificationObject clsobjs;
	private Text text_3;
	private Shell parentShell;
	private Exception openexception;
	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public ModuleClassificationDialog(Shell parentShell,String moduleAddress,String ObjectID,String ModuleNum,String SelObjType,TCSession session) {
		super(parentShell);
		this.ModuleAddress=moduleAddress;
		this.ObjectID=ObjectID;
		this.session=session;
		this.ModuleNum=ModuleNum;
		this.SelObjType=SelObjType;
		this.parentShell=parentShell;
		namevalueP=new HashMap <String,Object>();
		arrayAttr=new HashMap <String,String>();
		System.out.println("1ModuleAddress="+moduleAddress);
		System.out.println("InstanceID="+ObjectID);
		
		
	}
	
	
	
	
	public Exception getOpenexception() {
		return openexception;
	}




	protected boolean isResizable() {
	    return true;
	}
	
	public void populateField()
	{
		System.out.println("2ModuleAddress="+ModuleAddress);
		System.out.println("2InstanceID="+ObjectID);
		try {
			text.setText(ModuleAddress);
			classificationList=new GetModuleAttributesForClasses(ModuleAddress,session).testgetGetAttributesForClasses();
		} catch (ServiceException | TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			openexception=e;
		}
	}
	

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		setTitle(" Classification Properties");
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		//Composite comp = new Composite(container, SWT.NONE);
		//container.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		//container.setLayout(new FillLayout());
		
		Group grpGeneralInfo = new Group(container, SWT.NONE);
		grpGeneralInfo.setEnabled(false);
		grpGeneralInfo.setText("General info");
		grpGeneralInfo.setBounds(0, 0, 746, 122);
		
		Label lblModuleAddress = new Label(grpGeneralInfo, SWT.NONE);
		lblModuleAddress.setBounds(30, 35, 135, 15);
		lblModuleAddress.setText("Classification Address");
		
		text = new Text(grpGeneralInfo, SWT.BORDER | SWT.READ_ONLY);
		text.setBounds(203, 35, 213, 21);
		
		text_2 = new Text(grpGeneralInfo, SWT.BORDER);
		text_2.setEditable(false);
		text_2.setBounds(203, 8, 213, 21);
		text_2.setText(ModuleNum);
		
		Label lblModuleNumber = new Label(grpGeneralInfo, SWT.NONE);
		lblModuleNumber.setBounds(31, 14, 120, 15);
		//lblModuleNumber.setText("Module Number");
		System.out.println("SelObjType="+SelObjType);
		String ModuleVehicleNum=SelObjType +" Number";
		System.out.println("ModuleVehicleNum="+ModuleVehicleNum);
		lblModuleNumber.setText(ModuleVehicleNum);
		
		Label lblClassifiedInstanceName = new Label(grpGeneralInfo, SWT.NONE);
		lblClassifiedInstanceName.setBounds(30, 65, 123, 15);
		lblClassifiedInstanceName.setText("Classification Name");
		
		text_3 = new Text(grpGeneralInfo, SWT.BORDER);
		text_3.setBounds(203, 62, 213, 21);
		//text_3.setText(ObjectID);
		text_1 = new Text(grpGeneralInfo, SWT.BORDER | SWT.READ_ONLY);
		text_1.setBounds(205, 89, 211, 21);
		text_1.setText(ObjectID);
		
		Label lblClassifiedInstanceId = new Label(grpGeneralInfo, SWT.NONE);
		lblClassifiedInstanceId.setBounds(30, 92, 135, 15);
		lblClassifiedInstanceId.setText("Classified Instance ID");
		//lblModuleNumber.
		Group grpClassificationPropertiesValues = new Group(container, SWT.NONE);
		grpClassificationPropertiesValues.setText("Classification Properties Values");
		grpClassificationPropertiesValues.setBounds(0, 128, 750, 523);
		grpClassificationPropertiesValues.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		//grpClassificationPropertiesValues.setLayout(new FillLayout());
		
		 tableViewer = new TableViewer(grpClassificationPropertiesValues, SWT.BORDER | SWT.FULL_SELECTION);
		table = tableViewer.getTable();
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setBounds(10, 23, 732, 490);
		grpClassificationPropertiesValues.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL | GridData.GRAB_HORIZONTAL));
		
		table.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true)); 
		
		TableViewerColumn tableViewerColumn = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnNewColumn = tableViewerColumn.getColumn();
		tblclmnNewColumn.setWidth(60);
		tblclmnNewColumn.setText("SrlNo");
	//	tableViewerColumn.setEditingSupport(new ClassificationEditingSupport1(tableViewer));
		
		TableViewerColumn tableViewerColumn_1 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnNewColumn_1 = tableViewerColumn_1.getColumn();
		tblclmnNewColumn_1.setWidth(85);
		tblclmnNewColumn_1.setText("Attribute ID");
		//tableViewerColumn_1.setEditingSupport(new ClassificationEditingSupport2(tableViewer));
		
		TableViewerColumn tableViewerColumn_2 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnNewColumn_2 = tableViewerColumn_2.getColumn();
		tblclmnNewColumn_2.setWidth(142);
		tblclmnNewColumn_2.setText("Attribute Name");
		//tableViewerColumn_2.setEditingSupport(new ClassificationEditingSupport3(tableViewer));
		
		TableViewerColumn tableViewerColumn_3 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnAttributeValue = tableViewerColumn_3.getColumn();
		tblclmnAttributeValue.setWidth(155);
		tblclmnAttributeValue.setText("Attribute Value");
	//	tableViewerColumn_3.setEditingSupport(new ClassificationEditingSupport4(tableViewer));
		
		
		
//tableViewer.setContentProvider(ArrayContentProvider.getInstance());
		
tableViewerColumn_3.setEditingSupport(new EditingSupport(tableViewerColumn_3.getViewer()) {
			
			ArrayList<String> str;

			@Override
			protected void setValue(Object element, Object value) {
				
				
				
				String val=((ClassificationTableLine) element).getAttrValue();
				String lovid=((ClassificationTableLine) element).getLovID();
				int i;
				for( i=0;i<str.size();i++)
				{
					
					System.out.println(str.get(i)+":xdxddfdr::"+i);
				}
				System.out.println("Before val::"+value.toString());
				try
				{
				if(Integer.parseInt(value.toString())<0)
				{
					value="0";
					System.out.println("Input value does not exist in LOV, so choose value from LOV only");
					MessageBox.post(parentShell,"Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator !!!","WARNING",SWT.ICON_WARNING);
					/* MessageBox msgbox = new MessageBox(parentShell, SWT.ICON_INFORMATION);
			               msgbox.setText("Information.");
			               msgbox.setMessage("Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator ");
			               msgbox.open();   */          
			             
					
				}
				 } catch(NumberFormatException e) { 
				       e.printStackTrace();
				    } 

				if(Integer.parseInt(lovid)<0)
                {
		
			((ClassificationTableLine) element).setAttrValue(str.get(Integer.parseInt(value.toString())));
                }
				else
				{
					((ClassificationTableLine) element).setAttrValue(value.toString());
				}
				
			
			//	((MyModel) element).setAttributevalue("jkjhvghvgh");//value.toString());
				
				
				System.out.println(((ClassificationTableLine) element).toString());
				getViewer().update(element, null);
			}

			@Override
			protected Object getValue(Object element) {
				// We need to calculate back to the index
				
				String val=((ClassificationTableLine) element).getAttrValue();
				String lovid=((ClassificationTableLine) element).getLovID();
				if(Integer.parseInt(lovid)<0)
                {
			int i;	
			
			for( i=0;i<str.size();i++)
			{
				
				System.out.println(str.get(i)+":gfxfsdfsIDX::"+i);
			}
			
			
			System.out.println("str.indexOf(val)="+str.indexOf(val));
			
			boolean match=false;
			for( i=0;i<str.size();i++)
			{
				
				if(str.get(i).equals(val))
				{
					match=true;
					break;
				}
			}
				if(match==false)
				{
					i=0;
				}
				System.out.println(val+":IDX::"+i);
				return Integer.valueOf(i);
                }
				
				
				return val;
			}

			@Override
			protected CellEditor getCellEditor(Object element) {
				str=new ArrayList<String>();
				String classid=((ClassificationTableLine) element).getParent().getParent().getModuleAddress();
				String attrid=((ClassificationTableLine) element).getAttrID();
				String val=((ClassificationTableLine) element).getAttrValue();
				String lovid=((ClassificationTableLine) element).getLovID();
				String deptattr=((ClassificationTableLine) element).getDepattr();
				String deptcfg=((ClassificationTableLine) element).getDepattrcfg();
				int arraysize=((ClassificationTableLine) element).getArraySize();
				String deptval=null;//modifedvalueMap.get(deptattr);
				if(Integer.parseInt(lovid)<0)
                {
                	
                	try {
                	///// LATER	str=	new GetKeyLOVs2Sample().testGetKeyLOVs2(lovid);
                		new GetKeyLOVs2Sample().testGetKeyLOVs2(classid,attrid,lovid,deptattr,deptcfg,deptval,arraysize);
                		return new ComboBoxCellEditor(
        						tableViewer.getTable(), str.toArray(new String[str.size()]),SWT.READ_ONLY);
					} catch (ServiceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                	
                }
				
				
					return new TextCellEditor(tableViewer.getTable());
				
				
				
				
			}

			@Override
			protected boolean canEdit(Object element) {
				return true;
			}
		});
		
		/*CellEditor[] editors = new CellEditor[4];
	    editors[0] = new TextCellEditor(table);
	    editors[1] = new TextCellEditor(table);
	    editors[2] = new TextCellEditor(table);
	    editors[3] = new ComboBoxCellEditor(table);*/

		
		//lblModuleNumber.setText("lmnkmnk");
		
		
if(icoval!=null)
			
		{
			ModuleAddress=icoval.getCid();
			ObjectID=icoval.getIcoId();
			text.setText(ModuleAddress);
			text_1.setText(ObjectID);
			clsobjs=icoval.getClsobjs();
			
			
			System.out.println("icoval!=null clsobjs="+clsobjs);
			
		}

String classdesc;
try {
	classdesc = new GetClassDescriptions().getClassDesc(session,ModuleAddress);
	System.out.println("classdesc="+classdesc);
	text_3.setText(classdesc);
} catch (ServiceException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

populateField();
System.out.println("Calling populateTable func");

if(icoval!=null)
{
	
	 Map<BigInteger,AttributeValues> map2=icoval.getAttrValuesMap();
	for( Object key2 : map2.keySet())
     {
       // System.out.println("keyw.get(key2)="+key2.getClass());
       
       // System.out.println("kssl="+map2.get(key2).getClass());
       AttributeValues fv=map2.get(key2);
	       for(int f=0;f<classificationList.size();f++)
	       {
	    	   ClassificationTableLine tabline=classificationList.get(f);
	    	   
	    	   if(tabline.getAttrID().equals(key2.toString()))
	    		   
	    	   {
	    		 
	       
	    		  Value[] vals=  fv.values;
			      for(int x1=0;x1<vals.length;x1++)
			      {
			      // System.out.println("key2"+key2+" Val:"+vals[x1].attrValue);		      
			       tabline.setAttrValue(vals[x1].attrValue);
			     
			      }
	    	   }
	       }
	  }
}
		
	
		
		TableViewerColumn tableViewerColumn_4 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnNewColumn_3 = tableViewerColumn_4.getColumn();
		tblclmnNewColumn_3.setWidth(93);
		tblclmnNewColumn_3.setText("Unit");
		
		TableViewerColumn tableViewerColumn_5 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnNewColumn_4 = tableViewerColumn_5.getColumn();
		tblclmnNewColumn_4.setWidth(109);
		tblclmnNewColumn_4.setText("LovID");
		
		
		tableViewerColumn.setLabelProvider(new ColumnLabelProvider() {
		 
		    public String getText(Object element) {
		    	ClassificationTableLine p = (ClassificationTableLine) element;
		        return p.getSrlNo();
		    }
		});
		tableViewerColumn_1.setLabelProvider(new ColumnLabelProvider() {
		   
		    public String getText(Object element) {
		    	ClassificationTableLine p = (ClassificationTableLine) element;
			        return p.getAttrID();
		    }
		});
		
		tableViewerColumn_2.setLabelProvider(new ColumnLabelProvider() {
		   
		    public String getText(Object element) {
		    	ClassificationTableLine p = (ClassificationTableLine) element;
			        return p.getAttrName();
		    }
		});
		
		tableViewerColumn_3.setLabelProvider(new ColumnLabelProvider() {
		   
		    public String getText(Object element) {
		    	ClassificationTableLine p = (ClassificationTableLine) element;
		        return p.getAttrValue();
		    }
		});
		
		tableViewerColumn_4.setLabelProvider(new ColumnLabelProvider() {
		
		    public String getText(Object element) {
		    	ClassificationTableLine p = (ClassificationTableLine) element;
		        return p.getUnit();
		    }
		});
		
		tableViewerColumn_5.setLabelProvider(new ColumnLabelProvider() {
			
		    public String getText(Object element) {
		    	ClassificationTableLine p = (ClassificationTableLine) element;
		        return p.getLovID();
		    }
		});
		
		TableViewerColumn tableViewerColumn_6 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnNewColumn_5 = tableViewerColumn_6.getColumn();
		tblclmnNewColumn_5.setWidth(79);
		tblclmnNewColumn_5.setText("Array");
		
		tableViewerColumn_6.setLabelProvider(new ColumnLabelProvider() {
			
		    public String getText(Object element) {
		    	ClassificationTableLine p = (ClassificationTableLine) element;
		        return p.getArraySize()+"";
		    }
		});
		
		
		tableViewer.setContentProvider(ArrayContentProvider.getInstance());//new TableContentProvider());
		//tableViewer.setLabelProvider(new TableLabelProvider(tableViewer));
		tableViewer.setInput( classificationList);
		
		
		
		return area;
	}
	public void updateICOVal(ICOValues val)
	{
		//text.setText(val.getCid());
		this.icoval=val;
		
		//classificationList.length
	}
	
	 public void populateTable() 
	    {
			// TODO Auto-generated method stub		
		
			
		 tabLineModel= new ClassificationLineProvider();
		 for(int i=0;i<classificationList.size();i++)
		 {
		 System.out.println("classificationList="+classificationList.get(i));
		 }
			tabLineModel.setClassificationLine(classificationList);
			
			 tableViewer.setContentProvider(new TableContentProvider());
			tableViewer.setInput( classificationList);
				
		
		}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		Button button = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,
				true);
		button.addSelectionListener(new SelectionAdapter() {
			/*@Override
			public void widgetSelected(SelectionEvent e) {
				
				//Rajesh
        		 // String ModuleAddress = null;
        		  System.out.println("going to call CreateOrUpdateICOSample");
        		  	AbstractAIFUIApplication app1=AIFUtility.getCurrentApplication();
        		  	
        		  	int itemCount = table.getItemCount();
        		  	for(int itemIndex = 0; itemIndex < itemCount; itemIndex++) {
        		  	    TableItem item = table.getItem(itemIndex);
        		  	  System.out.println("item.getText(1)="+item.getText(1));
        		  	  System.out.println("item.getText(3)="+item.getText(3));
        		  	  namevalueP.put(item.getText(1),item.getText(3))   ;
        		  	  
        		  	    }
        		  	
        		  	//ArrayList<ClassificationTableLine> classificationList1=(ArrayList<ClassificationTableLine>) tableViewer.getInput();
        		  //	System.out.println("tableViewer.getInput()="+tableViewer.get.getInput());
        		  //	 System.out.println("classificationList1 size="+classificationList1.size());
        		  	//for(int i=0;i<classificationList1.size();i++)
        			// {
        			// System.out.println("classificationList1="+classificationList1.get(i));
        			// }
        		  //	CreateOrUpdateICOSample CreUpdclassification= new CreateOrUpdateICOSample(app1.getDesktop().getShell(),ModuleAddress,ObjectID,session);
        		  //	CreUpdclassification.open();
					             		  
        		  //End
			}*/
		});
		createButton(parent, IDialogConstants.CANCEL_ID,
				IDialogConstants.CANCEL_LABEL, false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(772, 811);
	}
	
	@Override
	   protected void okPressed() {
	       // TODO Auto-generated method stub
		//Rajesh
		 // String ModuleAddress = null;
		  System.out.println("going to call CreateOrUpdateICOSample");
		  	AbstractAIFUIApplication app1=AIFUtility.getCurrentApplication();
		  	
		  	int itemCount = table.getItemCount();
		  	for(int itemIndex = 0; itemIndex < itemCount; itemIndex++) {
		  	    TableItem item = table.getItem(itemIndex);
		  	  System.out.println("item.getText(1)="+item.getText(1));
		  	  System.out.println("item.getText(3)="+item.getText(3));
		  	  
		  	 System.out.println("item.getText(5)="+item.getText(5));
		  	 // namevalueP.put(item.getText(1),"v"+itemIndex)   ;
		  	 if(Integer.parseInt(item.getText(5))<0)
		  	 {
		  		 if(item.getText(3).trim().length()>0)
		  		 {
		  		namevalueP.put(item.getText(1),new StringTokenizer(item.getText(3)," ").nextToken());
		  		 }
		  		 else
		  		 {
		  			namevalueP.put(item.getText(1),item.getText(3))   ;
		  		 }
		  	
		  	 }
		  	 else
		  	 {
		  		namevalueP.put(item.getText(1),item.getText(3))   ;
		  	 }
		  	  
		  	    }
		  	
		  	 System.out.println("CreateOrUpdateICOSample clsobjs="+clsobjs + "ModuleNum="+ModuleNum);
		  	 CreateOrUpdateICOSample icos=new  CreateOrUpdateICOSample(null,clsobjs, ModuleAddress, ObjectID, ModuleNum,namevalueP,arrayAttr , session);
		  	 try {
				icos.createAndUpdateICO();
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       super.okPressed();
	   }
	//used to set the Title in the dialog window
	@Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        newShell.setText("TML Classification Window");
    } 
}

 class TableLabelProvider 	extends LabelProvider 	implements ITableLabelProvider {
	
	private TableViewer tableViewer;
	
	

	
	
	
	/*static {
imageRegistry.put("smileImage", ImageDescriptor.createFromFile(
TableViewerExample.class,
"smile.jpg"));
}*/
	public TableLabelProvider(TableViewer tableViewer) {
		this.tableViewer = tableViewer;
	}
	
	
	
	
	  public String getColumnText(Object element, int columnIndex) {
		  ClassificationTableLine tabline = (ClassificationTableLine) element;
		  System.out.println("1columnIndex="+columnIndex);
	    switch (columnIndex) {
	    case 0:
	    	 System.out.println("1tabline.getSrlNo()="+tabline.getSrlNo());
		      return tabline.getSrlNo()+"";
		    case 1:
		    	System.out.println("1tabline.getAttrID()="+tabline.getAttrID());
		      return tabline.getAttrID();
		    case 2:
		    	System.out.println("1tabline.getAttrName()="+tabline.getAttrName());
		      return tabline.getAttrName();		      
		    case 3:
		    	System.out.println("1abline.getAttrValue()="+tabline.getAttrValue());
			  return tabline.getAttrValue();
		    case 4:
		    	System.out.println("1abline.UnitName()="+tabline.getUnit());
			  return tabline.getUnit();
		    case 5:
		    	System.out.println("1abline.getLovID()="+tabline.getLovID());
			  return tabline.getLovID();
	    }
	    
	    return "";
}




	@Override
	public Image getColumnImage(Object arg0, int arg1) {
		// TODO Auto-generated method stub
		return null;
	}









}


 class ClassificationEditingSupport extends EditingSupport
 {

    private  TableViewer viewer;
    private  CellEditor editor;
    private int column;

    public ClassificationEditingSupport(TableViewer viewer,int coloumn ) {
        super(viewer);
        this.viewer = viewer;
       this.column=column;
       // this.editor = new TextCellEditor(viewer.getTable());
    }

  /*  @Override
    protected CellEditor getCellEditor(Object element) {
        String[] gender = new String[2];
      
     gender[0] = "male";
      gender[1] = "female";

        return new TextCellEditor(viewer.getTable());// new ComboBoxCellEditor(viewer.getTable(), gender);
    }

*/
    @Override
    protected boolean canEdit(Object element) {
    	System.out.println("canEdit column="+column);
    	//if(column==3 )
    	return true;
    	//return false;
    }

    
    
    @Override
    protected Object getValue(Object element) {
    	
    	ClassificationTableLine tabline=((ClassificationTableLine) element);
    	
    	  switch (column) {
  	    case 0:
  	    	 System.out.println("2tabline.getSrlNo()="+tabline.getSrlNo());
  		      return tabline.getSrlNo()+"";
  		    case 1:
  		    	System.out.println("2tabline.getAttrID()="+tabline.getAttrID());
  		      return tabline.getAttrID();
  		    case 2:
  		    	System.out.println("2tabline.getAttrName()="+tabline.getAttrName());
  		      return tabline.getAttrName();		      
  		    case 3:
  		    	System.out.println("2abline.getAttrValue()="+tabline.getAttrValue());
  			  return tabline.getAttrValue();
  	    }
    
			 return "";
    	
    	
    }

    @Override
    protected void setValue(Object element, Object userInputValue) {
    	ClassificationTableLine tabline=((ClassificationTableLine) element);
    	
    	System.out.println("HGH"+String.valueOf(userInputValue));
			
    	
			 switch (column) {
		  	    case 0:
		  	    	 System.out.println("3tabline.getSrlNo()="+tabline.getSrlNo());
		  		     tabline.setSrlNo(String.valueOf(userInputValue));
		  		    case 1:
		  		    	System.out.println("3tabline.getAttrID()="+tabline.getAttrID());
		  		       tabline.setAttrID(String.valueOf(userInputValue));
		  		    case 2:
		  		    	System.out.println("3tabline.getAttrName()="+tabline.getAttrName());
		  		      tabline.setAttrName(String.valueOf(userInputValue));		      
		  		    case 3:
		  		    	System.out.println("3tabline.getAttrValue()="+tabline.getAttrValue());
		  		    	tabline.setAttrValue(String.valueOf(userInputValue));
		  	    }
   	 
    }

	@Override
	protected CellEditor getCellEditor(Object arg0) {
		// TODO Auto-generated method stub
		return  new TextCellEditor(viewer.getTable());
	}
    
   
    
}
 
 
 //
 
 class ClassificationEditingSupport1 extends EditingSupport
 {

    private  TableViewer viewer;
    private  CellEditor editor;
    private int column;

    public ClassificationEditingSupport1(TableViewer viewer) {
        super(viewer);
        this.viewer = viewer;
      
    }

  /*  @Override
    protected CellEditor getCellEditor(Object element) {
        String[] gender = new String[2];
      
     gender[0] = "male";
      gender[1] = "female";

        return new TextCellEditor(viewer.getTable());// new ComboBoxCellEditor(viewer.getTable(), gender);
    }

*/
    @Override
    protected boolean canEdit(Object element) {
    	
    	
    	return false;
    }

    
    
    @Override
    protected Object getValue(Object element) {
    	
    	ClassificationTableLine tabline=((ClassificationTableLine) element);
    	
  		      return tabline.getSrlNo()+"";
  		  
    	
    	
    }

    @Override
    protected void setValue(Object element, Object userInputValue) {
    	ClassificationTableLine tabline=((ClassificationTableLine) element);
    	
    	System.out.println("INPUT VALUE:-"+String.valueOf(userInputValue));
			
    	
			 
		  	    	 System.out.println("3tabline.getSrlNo()="+tabline.getSrlNo());
		  		     tabline.setSrlNo(String.valueOf(userInputValue));
		  		   viewer.update(element, null);
		  	    
   	 
    }

	@Override
	protected CellEditor getCellEditor(Object arg0) {
		// TODO Auto-generated method stub
		return  new TextCellEditor(viewer.getTable());
	}
    
   
    
}
 
 //
 

 ///
 
 class ClassificationEditingSupport2 extends EditingSupport
 {

    private  TableViewer viewer;
    private  CellEditor editor;
    private int column;

    public ClassificationEditingSupport2(TableViewer viewer) {
        super(viewer);
        this.viewer = viewer;
      
    }

  /*  @Override
    protected CellEditor getCellEditor(Object element) {
        String[] gender = new String[2];
      
     gender[0] = "male";
      gender[1] = "female";

        return new TextCellEditor(viewer.getTable());// new ComboBoxCellEditor(viewer.getTable(), gender);
    }

*/
    @Override
    protected boolean canEdit(Object element) {
    	
    	
    	return false;
    }

    
    
    @Override
    protected Object getValue(Object element) {
    	
    	ClassificationTableLine tabline=((ClassificationTableLine) element);
    	
  		      return tabline.getAttrID()+"";
  		  
    	
    	
    }

    @Override
    protected void setValue(Object element, Object userInputValue) {
    	ClassificationTableLine tabline=((ClassificationTableLine) element);
    	
    	System.out.println("INPUT VALUE:-"+String.valueOf(userInputValue));
			
    	
			 
		  	    	 System.out.println("3tabline.getAttrID()="+tabline.getAttrID());
		  		     tabline.setAttrID(String.valueOf(userInputValue));
		  		   viewer.update(element, null);
		  	    
   	 
    }

	@Override
	protected CellEditor getCellEditor(Object arg0) {
		// TODO Auto-generated method stub
		return  new TextCellEditor(viewer.getTable());
	}
    
   
    
}
 
 ///
 
 ////
 class ClassificationEditingSupport3 extends EditingSupport
 {

    private  TableViewer viewer;
    private  CellEditor editor;
    private int column;

    public ClassificationEditingSupport3(TableViewer viewer) {
        super(viewer);
        this.viewer = viewer;
      
    }

  /*  @Override
    protected CellEditor getCellEditor(Object element) {
        String[] gender = new String[2];
      
     gender[0] = "male";
      gender[1] = "female";

        return new TextCellEditor(viewer.getTable());// new ComboBoxCellEditor(viewer.getTable(), gender);
    }

*/
    @Override
    protected boolean canEdit(Object element) {
    	
    	
    	return true;
    }

    
    
    @Override
    protected Object getValue(Object element) {
    	
    	ClassificationTableLine tabline=((ClassificationTableLine) element);
    	
  		      return tabline.getAttrName()+"";
  		  
    	
    	
    }

    @Override
    protected void setValue(Object element, Object userInputValue) {
    	ClassificationTableLine tabline=((ClassificationTableLine) element);
    	
    	System.out.println("INPUT VALUE:-"+String.valueOf(userInputValue));
			
    	
			 
		  	    	 System.out.println("3tabline.getAttrName()="+tabline.getAttrName());
		  		     tabline.setAttrName(String.valueOf(userInputValue));
		  		   viewer.update(element, null);
		  		   
		  	    
   	 
    }

	@Override
	protected CellEditor getCellEditor(Object arg0) {
		// TODO Auto-generated method stub
		return  new TextCellEditor(viewer.getTable());
	}
    
   
    
}
 ////

 
/////
class ClassificationEditingSupport4 extends EditingSupport
{

   private  TableViewer viewer;
   private  CellEditor editor;
   private int column;

   public ClassificationEditingSupport4(TableViewer viewer) {
       super(viewer);
       this.viewer = viewer;
     
   }

 /*  @Override
   protected CellEditor getCellEditor(Object element) {
       String[] gender = new String[2];
     
    gender[0] = "male";
     gender[1] = "female";

       return new TextCellEditor(viewer.getTable());// new ComboBoxCellEditor(viewer.getTable(), gender);
   }

*/
   @Override
   protected boolean canEdit(Object element) {
   	
   	
   	return true;
   }

   
   
   @Override
   protected Object getValue(Object element) {
   	
   	ClassificationTableLine tabline=((ClassificationTableLine) element);
   	
 		      return tabline.getAttrValue()+"";
 		  
   	
   	
   }

   @Override
   protected void setValue(Object element, Object userInputValue) {
   	ClassificationTableLine tabline=((ClassificationTableLine) element);
   	
   	System.out.println("INPUT VALUE:-"+String.valueOf(userInputValue));
			
   	
			 
		  	    	 System.out.println("3tabline.getAttrValue()="+tabline.getAttrValue());
		  		     tabline.setAttrValue(String.valueOf(userInputValue));
		  		   viewer.update(element, null);
		  	    
  	 
   }

	@Override
	protected CellEditor getCellEditor(Object arg0) {
		// TODO Auto-generated method stub
		return  new TextCellEditor(viewer.getTable());
	}
   
  
   
}
/////
 
 class TableContentProvider implements IStructuredContentProvider {
	  public Object[] getElements(Object inputElement) {
		  ArrayList<ClassificationTableLine> list= (ArrayList<ClassificationTableLine>) inputElement;
		  
		  Object[] obj=list.toArray();
		  
		  for(int x=0;x<obj.length;x++)
		  {
			  
			  System.out.println("GHH::"+obj[x].toString());
			  
		  }
	    return list.toArray();
	  }

	  public void dispose() {
	  }

	  

	@Override
	public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}
	}
