package com.tml.techspec.dialogs;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.jface.viewers.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import java.util.Arrays;
import java.util.List;

public class TableViewerSearchExample {

	public static class Person {
		private String name;
		private String email;

		public Person(String name, String email) {
			this.name = name;
			this.email = email;
		}

		public String getName() {
			return name;
		}

		public String getEmail() {
			return email;
		}

		@Override
		public String toString() {
			return name + " - " + email;
		}
	}

	private List<Person> people = Arrays.asList(new Person("rrb", "rrb@example.com"),
			new Person("djk", "dkkk@example.com"), new Person("sourav", "skk@example.com"),
			new Person("pooo", "plku@example.com"));

	public void open() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("TableViewer Search Filter Example");
		shell.setLayout(new GridLayout(1, false));
		shell.setSize(400, 300);

		// Search Text Box
		Text searchText = new Text(shell, SWT.BORDER | SWT.SEARCH | SWT.ICON_SEARCH | SWT.CANCEL);
		searchText.setMessage("Search by name or email...");
		searchText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));

		// TableViewer
		TableViewer viewer = new TableViewer(shell, SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL);
		viewer.setContentProvider(ArrayContentProvider.getInstance());
		viewer.getTable().setHeaderVisible(true);
		viewer.getTable().setLinesVisible(true);
		viewer.getTable().setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		// Name Column
		TableViewerColumn nameCol = new TableViewerColumn(viewer, SWT.NONE);
		nameCol.getColumn().setText("Name");
		nameCol.getColumn().setWidth(150);
		nameCol.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				return ((Person) element).getName();
			}
		});

		// Email Column
		TableViewerColumn emailCol = new TableViewerColumn(viewer, SWT.NONE);
		emailCol.getColumn().setText("Email");
		emailCol.getColumn().setWidth(200);
		emailCol.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				return ((Person) element).getEmail();
			}
		});

		viewer.setInput(people);

		// Filter
		ViewerFilter filter = new ViewerFilter() {
			public boolean select(Viewer viewer, Object parentElement, Object element) {
				String search = searchText.getText().toLowerCase();
				if (search.isEmpty())
					return true;

				Person p = (Person) element;
				return p.getName().toLowerCase().contains(search) || p.getEmail().toLowerCase().contains(search);
			}
		};

		// Filter hook
		searchText.addModifyListener(e -> {
			viewer.setFilters(new ViewerFilter[] { filter });
		});

		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] args) {
		new TableViewerSearchExample().open();
	}
}
