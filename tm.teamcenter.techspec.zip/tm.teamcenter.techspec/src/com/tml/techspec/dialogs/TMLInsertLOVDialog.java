package com.tml.techspec.dialogs;

import java.awt.Toolkit;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Vector;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.jface.viewers.TableViewerColumn;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.classification.icadmin.ICAAdminApplication;
import com.teamcenter.rac.classification.icadmin.ICAdminContext;
import com.teamcenter.rac.classification.icadmin.keylov.ICAKeyLOVContext;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCUserService;
import com.teamcenter.rac.kernel.ics.ICSKeyLov;
import com.teamcenter.rac.kernel.ics.ICSKeyLov.KeyLov;
import com.teamcenter.rac.kernel.ics.ICSKeyLovValue;
import com.teamcenter.rac.util.MessageBox;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.GetClassDescriptions;
import com.tml.classification.modules.GetModuleAttributesForClasses;
import com.tml.classification.modules.GetModuleAttributesForClassesLOVAdd;
import com.tml.classification.modules.KeyValueLOV;
import com.tml.classification.modules.TMLKeyLOVCreateorUpdateOperation;
import org.eclipse.jface.viewers.CheckboxTableViewer;

public class TMLInsertLOVDialog extends TitleAreaDialog {
	private Text text;
	private Text text_1;
	private Table table_New;
	private int tableitemcount;
	private Shell parentShell;
	private Text text_2;

	private HashMap<String, String> keyvalue;
	private HashMap<String, String> keyvalue1;
	// private int k;
	private Table table_Existing;
	private Text text_3;
	private Text text_4;
	private Table tableAttribute;
	private Text searchText;
	private TCSession session;
	private LOVSearchViewerFilter searchFilter;
	private String lovid;
	private TableViewer tableViewer_2;

	/**
	 * Create the dialog.
	 * 
	 * @param parentShell
	 */
	public TMLInsertLOVDialog(Shell parentShell) {
		super(parentShell);
		this.parentShell = parentShell;

		keyvalue = new HashMap<String, String>();
		keyvalue1 = new HashMap<String, String>();
		AbstractAIFUIApplication app = AIFUtility.getCurrentApplication();
		session = (TCSession) app.getSession();

	}

	/**
	 * Create contents of the dialog.
	 * 
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		setTitle("Add LOV Entry for TechSpec");
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));

		Group grpExistingEntries = new Group(container, SWT.NONE);
		grpExistingEntries.setLocation(10, 357);
		grpExistingEntries.setSize(659, 210);
		grpExistingEntries.setText("Existing LOV Values");

		TableViewer tableViewer_1 = new TableViewer(grpExistingEntries, SWT.BORDER | SWT.FULL_SELECTION);
		table_Existing = tableViewer_1.getTable();
		table_Existing.setLinesVisible(true);
		table_Existing.setHeaderVisible(true);
		table_Existing.setBounds(10, 29, 639, 171);

		TableViewerColumn tableViewerColumn_3 = new TableViewerColumn(tableViewer_1, SWT.NONE);
		TableColumn tableColumn = tableViewerColumn_3.getColumn();
		tableColumn.setWidth(57);
		tableColumn.setText("Sl No");

		TableViewerColumn tableViewerColumn_4 = new TableViewerColumn(tableViewer_1, SWT.NONE);
		TableColumn tableColumn_1 = tableViewerColumn_4.getColumn();
		tableColumn_1.setWidth(147);
		tableColumn_1.setText("LOV Key");

		TableViewerColumn tableViewerColumn_5 = new TableViewerColumn(tableViewer_1, SWT.NONE);
		TableColumn tableColumn_2 = tableViewerColumn_5.getColumn();
		tableColumn_2.setWidth(422);
		tableColumn_2.setText("LOV Value");

		Group grpGeneral = new Group(container, SWT.NONE);
		grpGeneral.setText("General");
		grpGeneral.setBounds(10, 10, 659, 57);

		Label lblLovId = new Label(grpGeneral, SWT.NONE);
		lblLovId.setBounds(10, 24, 123, 20);
		lblLovId.setText("Module/VC Address :");

		text = new Text(grpGeneral, SWT.BORDER);
		text.setBounds(139, 22, 113, 26);

		text_1 = new Text(grpGeneral, SWT.BORDER);
		text_1.setBounds(258, 21, 291, 26);
		text_1.setEditable(false);

		Button btnNewButton_1 = new Button(grpGeneral, SWT.NONE);
		btnNewButton_1.setBounds(555, 18, 104, 30);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				try {

					tableAttribute.removeAll();
					String moduleaddress = text.getText();
					if (moduleaddress == null || moduleaddress.length() == 0)
						return;

					GetClassDescriptions class_desc = new GetClassDescriptions();
					String desc = class_desc.getClassDesc(session, moduleaddress);
					text_1.setText(desc);

					GetModuleAttributesForClassesLOVAdd module_address_class = new GetModuleAttributesForClassesLOVAdd(
							moduleaddress, session);
					ArrayList<ClassificationTableLine> all_attr = module_address_class.testgetGetAttributesForClasses();

					for (int p = 0; p < all_attr.size(); p++) {
						ClassificationTableLine tab = all_attr.get(p);
						String lov_id = tab.getLovID();
						if (Integer.parseInt(lov_id) > 0) {
							all_attr.remove(p);
							continue;
						}
						/*
						 * TableItem item = new TableItem(tableAttribute, SWT.NONE);
						 * item.setText(0,(p+1)+""); item.setText(1,tab.getAttrID());
						 * item.setText(2,tab.getAttrName()); item.setText(3,lov_id);
						 */
					}

					tableViewer_2.setInput(all_attr);
					/*
					 * String lovid=text.getText(); System.out.println("lovid:"+lovid); ICSKeyLov
					 * keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovid));
					 * 
					 * text_1.setText(keylov.getName());
					 * 
					 * KeyLov[] arrayOfICSKeyLovValue = keylov.getEntries(true);
					 * 
					 * for( int k1=0;k1<arrayOfICSKeyLovValue.length;k1++) {
					 * 
					 * String key=arrayOfICSKeyLovValue[k1].getKey(); String
					 * val=arrayOfICSKeyLovValue[k1].getValue();
					 * System.out.println("HH:"+key+":"+val); TableItem item = new
					 * TableItem(table_Existing, SWT.NONE);
					 * 
					 * item.setText(0, (k1+1)+""); item.setText(1, key); item.setText(2, val);
					 * keyvalue.put(key, val); keyvalue1.put(val,key);
					 * 
					 * 
					 * 
					 * }
					 */
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnNewButton_1.setText("Get Attribute");

		Group grpNewEntry = new Group(container, SWT.NONE);
		grpNewEntry.setBounds(10, 568, 659, 270);
		grpNewEntry.setText("New LOV Value Entries");

		TableViewer tableViewer = new TableViewer(grpNewEntry, SWT.BORDER | SWT.FULL_SELECTION);
		table_New = tableViewer.getTable();
		table_New.setBounds(10, 21, 639, 153);
		table_New.setLinesVisible(true);
		table_New.setHeaderVisible(true);

		TableViewerColumn tableViewerColumn = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnSlNo = tableViewerColumn.getColumn();
		tblclmnSlNo.setWidth(57);
		tblclmnSlNo.setText("Sl No");

		TableViewerColumn tableViewerColumn_1 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnLovKey = tableViewerColumn_1.getColumn();
		tblclmnLovKey.setWidth(183);
		tblclmnLovKey.setText("LOV Key");

		TableViewerColumn tableViewerColumn_2 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnLovValue = tableViewerColumn_2.getColumn();
		tblclmnLovValue.setWidth(388);
		tblclmnLovValue.setText("LOV Value");

		Button btnAdd = new Button(grpNewEntry, SWT.NONE);
		btnAdd.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				int k = table_New.getItemCount();
				String key = text_3.getText();
				String val = text_4.getText();

				if (keyvalue.get(key) != null)
					return;

				if (keyvalue1.get(val) != null)
					return;
				TableItem item = new TableItem(table_New, SWT.NONE);
				item.setText(0, (k + 1) + "");
				item.setText(1, key);
				item.setText(2, val);
				keyvalue.put(key, val);
				keyvalue1.put(val, key);
				// k++;

			}
		});
		btnAdd.setBounds(433, 189, 90, 30);
		btnAdd.setText("Add");

		Button btnDel = new Button(grpNewEntry, SWT.NONE);
		btnDel.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				int selindex = table_New.getSelectionIndex();
				if (selindex < 0)
					return;
				TableItem itm = table_New.getItem(selindex);

				keyvalue.remove(itm.getText(1));
				keyvalue1.remove(itm.getText(2));

				table_New.remove(table_New.getSelectionIndex());

				table_New.redraw();

			}
		});
		btnDel.setBounds(541, 189, 90, 30);
		btnDel.setText("Del");

		text_3 = new Text(grpNewEntry, SWT.BORDER);
		text_3.setBounds(65, 191, 78, 26);

		text_4 = new Text(grpNewEntry, SWT.BORDER);
		text_4.setBounds(212, 191, 205, 26);

		Label lblVal = new Label(grpNewEntry, SWT.NONE);
		lblVal.setBounds(162, 194, 44, 20);
		lblVal.setText("Val:");

		Label lblKey = new Label(grpNewEntry, SWT.NONE);
		lblKey.setBounds(10, 194, 53, 20);
		lblKey.setText("Key :");

		Label lblLovValuesFile = new Label(grpNewEntry, SWT.NONE);
		lblLovValuesFile.setText("LOV Values File Path(.csv) :");
		lblLovValuesFile.setBounds(10, 233, 164, 26);

		Button btnBrowse = new Button(grpNewEntry, SWT.NONE);
		btnBrowse.setBounds(180, 230, 75, 25);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				FileDialog opendlg = new FileDialog(TMLInsertLOVDialog.this.getShell(), SWT.OPEN);
				String filenamefilter = "*.csv";
				opendlg.setText("Select the LOV File :");
				opendlg.setFilterNames(new String[] { "Comma seperated CSV Files (*.csv*)" });
				opendlg.setFilterExtensions(new String[] { "*.csv" });
				// opendlg.setFilterPath("c:\\"); // Windows path
				// opendlg.setFileName(filenamefilter);
				String path = opendlg.open();
				if (path == null)
					return;
				text_2.setText(path);

				File fl = new File(path);

				try {
					BufferedReader reader = new BufferedReader(new FileReader(path));

					String line;

					while ((line = reader.readLine()) != null) {
						StringTokenizer s1 = new StringTokenizer(line, ",");

						int k = table_New.getItemCount();

						String key = s1.nextToken().toString();
						String val = s1.nextToken().toString();
						if (keyvalue1.get(val) != null)
							continue;
						TableItem item = new TableItem(table_New, SWT.NONE);
						item.setText(0, (k + 1) + "");
						item.setText(1, key);
						item.setText(2, val);
						keyvalue.put(key, val);
						keyvalue1.put(val, key);

					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnBrowse.setText("Browse...");

		text_2 = new Text(grpNewEntry, SWT.BORDER);
		text_2.setBounds(261, 230, 398, 26);
		text_2.setEditable(false);

		Label label_1 = new Label(grpNewEntry, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_1.setBounds(-1, 225, 660, 2);

		Label label_2 = new Label(grpNewEntry, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_2.setBounds(-1, 180, 660, 2);

		Group grpAttribute = new Group(container, SWT.NONE);
		grpAttribute.setText("Attributes");
		grpAttribute.setBounds(10, 129, 659, 222);

		tableViewer_2 = new TableViewer(grpAttribute, SWT.BORDER | SWT.FULL_SELECTION);
		tableAttribute = tableViewer_2.getTable();
		tableAttribute.setLinesVisible(true);
		tableAttribute.setHeaderVisible(true);
		tableAttribute.setBounds(10, 27, 639, 185);

		TableViewerColumn tableViewerColumn_6 = new TableViewerColumn(tableViewer_2, SWT.NONE);
		TableColumn tblclmnSlNo_1 = tableViewerColumn_6.getColumn();
		tblclmnSlNo_1.setWidth(79);
		tblclmnSlNo_1.setText("Sl No");

		TableViewerColumn tableViewerColumn_7 = new TableViewerColumn(tableViewer_2, SWT.NONE);
		TableColumn tblclmnAttributeId = tableViewerColumn_7.getColumn();
		tblclmnAttributeId.setWidth(100);
		tblclmnAttributeId.setText("Attribute ID");

		TableViewerColumn tableViewerColumn_8 = new TableViewerColumn(tableViewer_2, SWT.NONE);
		TableColumn tblclmnNewColumn = tableViewerColumn_8.getColumn();
		tblclmnNewColumn.setWidth(335);
		tblclmnNewColumn.setText("Attribute Name");

		TableViewerColumn tableViewerColumn_9 = new TableViewerColumn(tableViewer_2, SWT.NONE);
		TableColumn tblclmnLovId = tableViewerColumn_9.getColumn();
		tblclmnLovId.setWidth(112);
		tblclmnLovId.setText("LOV ID");

		tableViewer_2.setLabelProvider(new AttributeTableLabelProvider(tableViewer_2));

		tableViewer_2.setContentProvider(new TableContentProvider());

		searchFilter = new LOVSearchViewerFilter();
		tableViewer_2.addFilter(searchFilter);

		searchText = new Text(container, SWT.BORDER);
		searchText.setBounds(98, 89, 308, 26);

		searchText.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent ke) {
				System.out.print("kjk:" + searchText.getText());
				searchFilter.setSearchText(searchText.getText());
				tableViewer_2.refresh();

			}
		});

		Button btnGetLov = new Button(container, SWT.NONE);
		btnGetLov.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				table_Existing.removeAll();
				keyvalue.clone();
				keyvalue1.clear();
				int selid = tableAttribute.getSelectionIndex();
				lovid = tableAttribute.getItem(selid).getText(3);

				ICSKeyLov keylov = ICSKeyLov.getICSKeyLov(Integer.parseInt(lovid));

				KeyLov[] arrayOfICSKeyLovValue = keylov.getEntries(true);

				for (int k1 = 0; k1 < arrayOfICSKeyLovValue.length; k1++) {

					String key = arrayOfICSKeyLovValue[k1].getKey();
					String val = arrayOfICSKeyLovValue[k1].getValue();
					System.out.println("HH:" + key + ":" + val);
					TableItem item = new TableItem(table_Existing, SWT.NONE);

					item.setText(0, (k1 + 1) + "");
					item.setText(1, key);
					item.setText(2, val);
					keyvalue.put(key, val);
					keyvalue1.put(val, key);

				}
			}
		});
		btnGetLov.setBounds(440, 87, 109, 30);
		btnGetLov.setText("Get LOV Value");

		Label lblSearchLabel = new Label(container, SWT.NONE);
		lblSearchLabel.setBounds(30, 92, 62, 20);
		lblSearchLabel.setText("Search:");

		return area;
	}

	/**
	 * Create contents of the button bar.
	 * 
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, false);
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, true);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(727, 1069);
	}

	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Technical-Specification LOV Window");

	}

	@Override
	protected void okPressed() {
		// TODO Auto-generated method stub
		System.out.println("OKKKKKK");
		System.out.println("okPressed invoked with input LovID" + lovid);
		String[] lovkey = null;
		String[] lovVal = null;
		// String[] lovkey1={"fsddf","fhtd","fdfgdx"};
		// String[] lovVal1={"fsddf1","fhtd1","fdfgdx1"};
		int totalNoItem = table_New.getItemCount();
		lovkey = new String[totalNoItem];
		lovVal = new String[totalNoItem];
		for (int i = 0; i < totalNoItem; i++) {
			TableItem tab1 = table_New.getItem(i);
			String srlNo = tab1.getText(0);
			lovkey[i] = tab1.getText(1);
			lovVal[i] = tab1.getText(2);
			System.out.println("srlNo=" + srlNo + "lovkey=" + lovkey[i] + "lovVal=" + lovVal[i]);
		}

		Object objects[];
		objects = new Object[5];

		objects[0] = lovid;
		objects[1] = "";
		objects[2] = totalNoItem;
		objects[3] = lovkey;
		objects[4] = lovVal;
		System.out.println("[TCUA] Going to call IcsLovUpdateServiceFunc Service....");

		TCSession tcsession = (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		TCUserService service = tcsession.getUserService();

		try {
			System.out.println("[before call IcsLovUpdateServiceFunc User Service....");
			// String return_data = (String)
			service.call("IcsLovUpdateServiceCall", objects);

			System.out.println("[after call IcsLovUpdateServiceFunc User Service....");
			ICSKeyLov.removeCacheEntry(Integer.parseInt(lovid));
			MessageBox.post(parentShell, "LOV Value uploaded Successfully!", "INFORMATION", SWT.ICON_INFORMATION);
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			MessageBox.post(parentShell, "LOV Value unable to upload Successfully!" + e.getMessage(), "WARNING",
					SWT.ICON_WARNING);
		}

		/*
		 * TMLKeyLOVCreateorUpdateOperation op = new
		 * TMLKeyLOVCreateorUpdateOperation(m_context,keyvalue); try {
		 * op.executeOperation(); } catch (TCException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); }
		 */
		super.okPressed();
	}
}

class AttributeTableLabelProvider extends LabelProvider implements ITableLabelProvider {

	private TableViewer tableViewer;

	public AttributeTableLabelProvider(TableViewer tableViewer) {
		this.tableViewer = tableViewer;
	}

	public String getColumnText(Object element, int columnIndex) {
		ClassificationTableLine tabline = (ClassificationTableLine) element;
		System.out.println("1columnIndex=" + columnIndex);
		switch (columnIndex) {
		case 0:
			System.out.println("1tabline.getSrlNo()=" + tabline.getSrlNo());
			return tabline.getSrlNo() + "";
		case 1:
			System.out.println("1tabline.getAttrID()=" + tabline.getAttrID());
			return tabline.getAttrID();
		case 2:
			System.out.println("1tabline.getAttrName()=" + tabline.getAttrName());
			return tabline.getAttrName();
		case 3:
			System.out.println("1abline.getLovID()=" + tabline.getLovID());
			return tabline.getLovID();
		}

		return "";
	}

	@Override
	public Image getColumnImage(Object arg0, int arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
