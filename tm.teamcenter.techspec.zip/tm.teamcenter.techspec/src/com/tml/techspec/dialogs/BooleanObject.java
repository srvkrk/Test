package com.tml.techspec.dialogs;

public class BooleanObject {
	
	private boolean value;
	
	
	

	public BooleanObject(boolean value) {
		super();
		this.value = value;
	}

	public boolean isValue() {
		return value;
	}

	public void setValue(boolean value) {
		this.value = value;
	}
	
	

}
