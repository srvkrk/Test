package com.tml.techspec.dialogs;

import com.teamcenter.rac.aifrcp.AppThemeHelper;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.SWTUIUtilities;
import com.teamcenter.rac.util.controls.IColumnBasedControl;
import com.teamcenter.rac.util.controls.IColumnControl;

import org.eclipse.jface.viewers.CheckboxTreeViewer;
import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.ViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.ui.part.ViewPart;

public class CheckedErrorTreeTableView
  extends ViewPart
{
  private CheckboxTreeViewer  m_treeViewer;
  private ViewerColumn m_itemColumn;
  private ViewerColumn m_errorColumn;
  static final int OBJECT_COLUMN_WIDTH = 200;
  static final int RESULT_COLUMN_WIDTH = 300;
  static final int ITEM_COLUMN_ORDER = 0;
  static final int ERROR_COLUMN_ORDER = 1;
  static final int ERROR_TREE_HEIGHT = 75;
  static final int ERROR_TREE_WIDTH = 400;
  
  public void createPartControl(Composite paramComposite)
  {
    GridLayout localGridLayout = new GridLayout(1, true);
    paramComposite.setLayout(localGridLayout);
    m_treeViewer = new CheckboxTreeViewer (paramComposite, SWT.MULTI);
    m_treeViewer.getControl().addControlListener(new ControlAdapter()
    {
      public void controlResized(ControlEvent paramAnonymousControlEvent)
      {
        final TreeColumn[] arrayOfTreeColumn = m_treeViewer.getTree().getColumns();
        SWTUIUtilities.asyncExec(new Runnable()
        {
          public void run()
          {
           // TreeColumn[] arrayOfTreeColumn;
            int j = arrayOfTreeColumn.length;
            for (int i = 0; i < j; i++)
            {
              TreeColumn localTreeColumn = arrayOfTreeColumn[i];
              localTreeColumn.pack();
            }
          }
        });
      }
    });
    GridData localGridData = new GridData(4, 4, true, true);
   int heightHint = 75;
    int widthHint = 400;
    Tree localTree = m_treeViewer.getTree();
    localTree.setLayoutData(localGridData);
    SWTUIUtilities.setControlColors(localTree, AppThemeHelper.getTreeForeground(), AppThemeHelper.getTreeBackground());
    addViewerColumns(m_treeViewer);
  }
  
  public void setFocus()
  {
    m_treeViewer.getTree().setFocus();
  }
  
  public Tree getTree()
  {
    return m_treeViewer.getTree();
  }
  
  public CheckboxTreeViewer getTreeViewer()
  {
    return m_treeViewer;
  }
  
  public void addViewerColumns(ColumnViewer paramColumnViewer)
  {
    Control localControl = paramColumnViewer.getControl();
    IColumnBasedControl localIColumnBasedControl = (IColumnBasedControl)AdapterUtil.getAdapter(localControl, IColumnBasedControl.class);
    Object localObject;
    if (localIColumnBasedControl != null)
    {
      localIColumnBasedControl.setHeaderVisible(false);
      m_itemColumn = localIColumnBasedControl.insertColumn(paramColumnViewer, 0);
      Item localItem = localIColumnBasedControl.getColumn(0);
      localObject = (IColumnControl)AdapterUtil.getAdapter(localItem, IColumnControl.class);
      ((IColumnControl)localObject).setMoveable(true);
      ((IColumnControl)localObject).setResizable(true);
      ((IColumnControl)localObject).setWidth(200);
      m_errorColumn = localIColumnBasedControl.insertColumn(paramColumnViewer, 1);
      localItem = localIColumnBasedControl.getColumn(1);
      localObject = (IColumnControl)AdapterUtil.getAdapter(localItem, IColumnControl.class);
      ((IColumnControl)localObject).setMoveable(true);
      ((IColumnControl)localObject).setResizable(true);
      ((IColumnControl)localObject).setWidth(300);
    }
    localControl.setRedraw(false);
    if (localIColumnBasedControl != null)
    {
      int i = 2;
      while (i < localIColumnBasedControl.getColumns().length)
      {
        localObject = localIColumnBasedControl.getColumn(i);
        ((Item)localObject).dispose();
      }
    }
    if (localIColumnBasedControl != null)
    {
      int[] arrayOfInt = new int[localIColumnBasedControl.getColumnCount()];
      for (int j = 0; j < arrayOfInt.length; j++) {
        arrayOfInt[j] = j;
      }
      localIColumnBasedControl.setColumnOrder(arrayOfInt);
    }
    localControl.setRedraw(true);
    paramColumnViewer.refresh();
  }
  
  public ViewerColumn getItemColumn()
  {
    return m_itemColumn;
  }
  
  public ViewerColumn getErrorColumn()
  {
    return m_errorColumn;
  }
}