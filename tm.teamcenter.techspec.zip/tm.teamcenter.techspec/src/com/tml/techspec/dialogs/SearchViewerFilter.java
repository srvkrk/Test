package com.tml.techspec.dialogs;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

import com.tml.classification.modules.ClassificationAnnotationLine;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.ClassificationTreeLine;



public class SearchViewerFilter extends ViewerFilter {

    private String searchString;

    public void setSearchText(String s) {
        // ensure that the value can be used for matching
        this.searchString = ".*" + s.toLowerCase() + ".*";
    }

    @Override
    public boolean select(Viewer viewer,
            Object parentElement,
            Object element) {
    	//System.out.println("inside SearchViewerFilter func call with element="+element.toString());
        if (searchString == null || searchString.length() == 0) {
            return true;
        }
         if(element instanceof ClassificationTreeLine)
        {
        	 ClassificationTreeLine tabline = (ClassificationTreeLine) element;
        	
   		    	
   		     //  if(tabline.getModuleAddress().matches(searchString) || tabline.getClassificationName().matches(searchString)||tabline.getObjectid().matches(searchString))
   		    	   return true;
        }  
        else if(element instanceof ClassificationAnnotationLine)
        {
        	ClassificationAnnotationLine tabline = (ClassificationAnnotationLine) element;
        	
   		    	
   		      // if(tabline.getAnnotation().matches(searchString) )
   		    	   return true;
        }  
        else if(element instanceof ClassificationTableLine)
        {
        	ClassificationTableLine tabline = (ClassificationTableLine) element;
        	
   		    	
   		       if(tabline.getAttrID().toLowerCase().matches(searchString) || tabline.getAttrName().toLowerCase().matches(searchString)||tabline.getAttrValue().toLowerCase().matches(searchString)||tabline.getUnit().toLowerCase().matches(searchString))
   		    	   return true;
        }  
        
       
        return false;
    }

}
