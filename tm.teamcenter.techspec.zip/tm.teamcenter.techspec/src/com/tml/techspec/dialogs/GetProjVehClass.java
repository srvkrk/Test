package com.tml.techspec.dialogs;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.kernel.ServiceData;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentForm;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateIn;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateInput;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateOut;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateResponse;
import com.teamcenter.services.rac.query.SavedQueryService;
//import com.tml.techspec.dialogs.ChassisTypeCreate.ProjVehClsValDialog;
//import com.tml.techspec.dialogs.ChassisTypeCreate.ProjVehValDialog;

public class GetProjVehClass extends TitleAreaDialog{
	
	private boolean isOkPressed;
	public Composite area1;
	private Shell parentshell;
	//private TCSession session;
	private Set<String> ProjVehClsLst = null;
	
	String newPartNumberGenrated = null;
	String FinalStr = null;
	private Text ProjVehClsText;
	
	private String selectedProjVehClsVal = null;
	
	private Button ProjVehClsValbutton;
	
	protected ProjVehValDialog ProjVehClsValDlg;
	//protected ProjVehClsValDialog ProjVehClsValDlg1;
	public GetProjVehClass(Shell parentShell) {
		super(parentShell);
		// TODO Auto-generated constructor stub
		//super(parentShell);
		isOkPressed=false;
		//setTitleImage(ResourceManager.getPluginImage("tm.teamcenter.regulationproj", "icons/T5_tm_chTypeNum16.png"));
		setTitle("Select Project Vehicle Class");

		this.selectedProjVehClsVal=selectedProjVehClsVal;
	}
	
	
	public Set<String> queryProjVehClsValueInDB(String queryname ,String []qryNames,String []qryValues) throws TCException
	 {

		 Set<String> ProjVehClsSet = new TreeSet<String>();
		 
		 System.out.println(" In Query for Index Number For ::"+queryname);  
		 TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();		        
		 try {
			 System.out.println(" Before setting the session ::");  
			 TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");                     
			 TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);//"Item...");
			 System.out.println(" After setting the session ::");                                                 
			 TCComponent []qryResults          = null;

			 if (mmcomponentquery != null)				     
			 {
				 System.out.println(" Results found ::"); 
				 qryResults=mmcomponentquery.execute(qryNames,qryValues);
			 }

			 if(qryResults.length>0)
			 {
				 for(int i=0;i<qryResults.length;i++)
				 {
					// System.out.println(i+":"+qryResults[i].getTCProperty("user_name").getDisplayableValue());	
					// plannerlist.add(qryResults[i].getTCProperty("user_name").getDisplayableValue());
					System.out.println(i+":"+qryResults[i].getTCProperty("t5_VehicleClass").getDisplayableValue());	
					 
					 ProjVehClsSet.add(qryResults[i].getTCProperty("t5_VehicleClass").getDisplayableValue());
					// System.out.println(i+":"+qryResults[i].getTCProperty("object_string").getDisplayableValue());
					// ProjVehClsSet.add(qryResults[i].getTCProperty("object_string").getDisplayableValue());
				 }	
				 System.out.println("FOUND  In Query for Index number for CHBarrel ::"+qryNames[0].toString());							
			 }				

		 } catch (TCException e2) {
			 // TODO Auto-generated catch block
			 e2.printStackTrace();
		 }

		 return ProjVehClsSet; 
	 }
	
	public class ProjVehValDialog extends Dialog {
		private ArrayList<String> ProjVehClsSelectedList;
		private String ProjVehClsSelectedVal = null;
		
		TableItem[] tblItem;
		Table tbl;
		private Set<String> ProjVehClsValueSet = null;
		
		protected ProjVehValDialog(Shell parentShell) {
			super(parentShell);
			//setTitle("Available Index Number List");
			getVehClsValList();
			// TODO Auto-generated constructor stub
		}
		
		private void getVehClsValList()
		{
			 String qry="Qury_Project"; 	

			 String []qryNames	= new String[]{"Name"};
			 String []qryValues	= new String[]{"*"};
			 
/*			 String qry="UserFind"; 	

			 String []qryNames	= new String[]{"Id"};
			 String []qryValues	= new String[]{"*"};*/
			 try {
				ProjVehClsValueSet = queryProjVehClsValueInDB(qry,qryNames,qryValues);
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 System.out.println("Returned from function...\nno of IndexValue====>" + ProjVehClsValueSet.size());     
			
		}
		/* (non-Javadoc)
		 * @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
		 */
		@Override
		protected Control createDialogArea(Composite parent) {
			// TODO Auto-generated method stub
			final Composite body = (Composite)super.createDialogArea(parent);
			GridData gd_container1 = new GridData(GridData.FILL_BOTH);
			gd_container1.heightHint = 200;
			body.setLayoutData(gd_container1);
			final TableViewer viewer = new TableViewer(body, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
			tbl = viewer.getTable();
			tbl.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
			viewer.setContentProvider(new ArrayContentProvider());
			viewer.setInput(ProjVehClsValueSet);
			return body;
		}

		/* (non-Javadoc)
		 * @see org.eclipse.jface.dialogs.Dialog#cancelPressed()
		 */
		@Override
		protected void cancelPressed() {
			// TODO Auto-generated method stub
			super.cancelPressed();
		}

		/* (non-Javadoc)
		 * @see org.eclipse.jface.dialogs.Dialog#okPressed()
		 */
		@Override
		protected void okPressed() {
			// TODO Auto-generated method stub
			
			tblItem =  tbl.getSelection();
			ProjVehClsSelectedList = new ArrayList<String>();
			for(int i=0; i<tblItem.length; i++)
			{
				ProjVehClsSelectedList.add(tblItem[i].getText());
				ProjVehClsSelectedVal = tblItem[i].getText();
			}
			
			System.out.println("selected ProjVehClass: " + ProjVehClsSelectedVal );
			ProjVehClsValbutton.setSelection(false);
			close();  
			//super.okPressed();
		}

		/**
		 * @return the ProjVehClsSelectedVal
		 */
		public String getProjVehClsSelectedVal() {
			return ProjVehClsSelectedVal;
		}

			/**
		 * @return the ProjVehClsValueSet
		 */
		public Set<String> getProjVehClsValueSet() {
			return ProjVehClsValueSet;
		}


		
	}
	
	
	
//Sevicedataerror
	
	 protected boolean ServiceDataError(final ServiceData data)
    {
		 String msgs=null;
		 Shell shell=new Shell();
             if (data.sizeOfPartialErrors() > 0)
             {
           	 
                     for (int i = 0; i < data.sizeOfPartialErrors(); i++)
                     {
                              for (String msg :data.getPartialError(i).getMessages())
                              {
                                      System.out.println("Error Msg="+msg);
                              
                              msgs=msgs+" "+msg;
                              }
                              
                     }
                     MessageBox.post(parentshell,msgs,"WARNING",SWT.ICON_WARNING);
                     //MessageBox.post(parentshell,"Not Created Successfully,refer the exception  !!","WARNING",SWT.ICON_WARNING);
                    /* msgs= msgs+ " Not Created Successfully,refer the exception  !!";
               	  MessageBox msgbox = new MessageBox(shell, SWT.ERROR);
                     msgbox.setText("Information.");
                     msgbox.setMessage(msgs);
                     msgbox.open();*/   
                     return true;
             }
            
             return false;
    }
	 
	 //End
	
	
	//Create Chassis Type Function
	
	//public void queryItems(TCSession tcSession)
		//private void CreateChassisType(TCSession tcSession,String itemclassName,String itemRevisionClass,String ProductType,String IndexNum,String IssueNum,String ChassisTypeNum,String Desc)

	
	//End function for get Vehicle Value
	

public String processProjVehclsSelVal()
{
	  System.out.println("Inside Ok_pressed for get Vehicle Value");
	  	
	  
		TCSession session= (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
	
		System.out.println("Calling processProjVehclsSelVal Func");
		System.out.println("\ninput selected ProjVehClsText="+ProjVehClsText.getText());			
		
	if ((!ProjVehClsText.getText().isEmpty()))
	{		
		selectedProjVehClsVal=ProjVehClsText.getText();
		
		//CreateChassisType(session,"T5_ChnDlg",ProductTypeText.getText(),ProjVehClsText.getText(),IssueNumberText.getText(),ChassisTypeNumText.getText());
		System.out.println("After call processProjVehclsSelVal Func");
	}
	else
	{
		System.out.println("selected values: " + ProjVehClsText.getText()  );
		System.out.println("Please select Project Vehicle class to proceed ahead ");

		 MessageBox.post(parentshell,"Project Vehicle class selection is mandatory to process ahead","ERROR",SWT.ICON_ERROR);
		/*MessageBox messageBox = new MessageBox(new Shell(), 289);
		messageBox.setText("ERROR");
		messageBox.setMessage("All values are mandatory for creation of Chassis Type Number");
		messgeBox.open();*/
	}
	return ProjVehClsText.getText();
}





	
	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	protected Control createDialogArea(Composite parent) {
		setTitle("Select Project Vehicle Class for PRD Project");
		TCSession session= (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		GridData gd_container = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		//gd_container.widthHint = 467;
		gd_container.widthHint = 420;
		gd_container.heightHint = 117;
		container.setLayoutData(gd_container);
		container.setTouchEnabled(true);
		GridLayout gl_container = new GridLayout(4, false);
		gl_container.marginWidth = 10;
		gl_container.marginRight = 3;
		gl_container.marginTop = 20;
		gl_container.marginBottom = 10;
		gl_container.marginLeft = 20;
		container.setLayout(gl_container);
		GridData gd_container1 = new GridData(GridData.FILL_BOTH);
		//gd_container.widthHint = 500;
		gd_container1.widthHint = 200;
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		
		Label lblVehCls = new Label(container, SWT.NONE);
		lblVehCls.setText("Vehicle Class");
		
		ProjVehClsText = new Text(container, SWT.BORDER);
		//IndexNumberText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		//IndexNumberText.setBounds(109, 22, 104, 21);
		ProjVehClsValbutton = new Button(container, SWT.CHECK);
		ProjVehClsValbutton.addSelectionListener(new SelectionAdapter() {
			@Override
			
			public void widgetSelected(SelectionEvent e) {

				ProjVehClsValbutton.setSelection(false);
				ProjVehClsValDlg = new ProjVehValDialog(getShell());
				ProjVehClsValDlg.open();
				ProjVehClsLst = ProjVehClsValDlg.getProjVehClsValueSet();
				if(ProjVehClsValDlg.getProjVehClsSelectedVal()!=null)
					ProjVehClsText.setText(ProjVehClsValDlg.getProjVehClsSelectedVal());
				
				
			
			}
		});

		area1=area;
		return area;
	}
	
	public String getProjVehClsSelectedVal1() {
		return selectedProjVehClsVal;
	}

	@Override
	   protected void okPressed() {
	       // TODO Auto-generated method stub
		//Rajesh
		 // String TechSpecAddress = null;
		 System.out.println("Inside Ok_pressed for get Vehicle Value before processProjVehclsSelVal call");
		 isOkPressed=true;
		String selval= processProjVehclsSelVal();
		this.selectedProjVehClsVal=selval;
		//selectedProjVehClsVal
		 System.out.println("Inside Ok_pressed for get Vehicle Value after processProjVehclsSelVal call with selval="+selval);
		 close();
	   }

	


}
