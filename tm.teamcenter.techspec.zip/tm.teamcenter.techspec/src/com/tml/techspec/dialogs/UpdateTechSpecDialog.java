package com.tml.techspec.dialogs;




import java.awt.Frame;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.StringTokenizer;
import java.util.TreeMap;

import javax.swing.SwingUtilities;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.common.NotDefinedException;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandImageService;
import org.eclipse.ui.commands.ICommandService;
import org.eclipse.wb.swt.SWTResourceManager;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

import com.swt.multicombo.MultiValueTextCellEditor;
import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.AbstractAIFOperation;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.classification.icm.ShowClassificationViewHandler;
import com.teamcenter.rac.commands.open.OpenCommand;
import com.teamcenter.rac.commands.properties.PropertiesCommand;
import com.teamcenter.rac.common.CommandTargetState;
import com.teamcenter.rac.common.MultiTargetControllerJob;
import com.teamcenter.rac.common.TCTypeRenderer;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentDataset;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCPreferenceService;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.ics.ICSKeyLov;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.loose.core.DataManagementService;
import com.teamcenter.services.loose.core._2006_03.DataManagement.CreateDatasetsResponse;
import com.teamcenter.services.loose.core._2006_03.DataManagement.DatasetProperties;
import com.teamcenter.services.loose.core._2006_03.FileManagement.DatasetFileInfo;
import com.teamcenter.services.loose.core._2006_03.FileManagement.GetDatasetWriteTicketsInputData;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVDefinition2;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVEntry;
import com.teamcenter.services.rac.classification._2011_12.Classification.AttributeValues;
import com.teamcenter.services.rac.classification._2011_12.Classification.Value;
import com.teamcenter.soa.client.FileManagementUtility;
import com.teamcenter.soa.client.model.ModelObject;
import com.teamcenter.soa.client.model.ServiceData;
import com.teamcenter.soa.exceptions.NotLoadedException;
import com.tml.classification.modules.BOMExpansion;
import com.tml.classification.modules.ClassificationAnnotationLine;
import com.tml.classification.modules.ClassificationLineProvider;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.ClassificationTreeLine;
import com.tml.classification.modules.CreateOrUpdateICOSample;
import com.tml.classification.modules.GetClassifiedAttr;
import com.tml.classification.modules.GetKeyLOVs2Sample;
import com.tml.classification.modules.GetKeyLOVs2Sample3;
import com.tml.classification.modules.GetModuleAttributesForClasses;
import com.tml.classification.modules.ICOValues;
import com.tml.classification.modules.KeyValueLOV;
import com.tml.classification.modules.PreferenceValue;
import com.tml.classification.modules.TMLDataBean;
import com.tml.classification.modules.TechSpecUtil;



public class UpdateTechSpecDialog extends TitleAreaDialog {
	private Text tsdesc;
	private String ModuleAddress;
	private String ObjectID;
	private TCSession session;
	private ClassificationLineProvider tabLineModel;
	private ArrayList<ClassificationTableLine> classificationList;
	private HashMap <String,Object> namevalueP;
	private Tree tree;
	private ArrayList<String> mandatorylist;
	private ArrayList<String> modulemandatorylist;
	private ArrayList<AIFComponentContext> aifcomponentctxtList;
	private TreeViewer treeViewer;
	private Text tsbu;
	private ICOValues icoval;
	private Text tsnum;
	private String ModuleNum;
	private String SelObjType;
	private ClassificationObject clsobjs;
	private Text tsou;
	private Shell parentShell;
	private Text tsvsc;
	private Text tsodu;
	private Text tsodd;
	private TCComponentItemRevision ItemRev;
	private TCComponent selectedObj;
	private List<CommandTargetState> m_commandTargetStateList;
	private List<CommandTargetState> m_commandTargetStateList1;
	private List<CommandTargetState> m_commandTargetStateList2;
	private List<CommandTargetState> m_commandTargetStateList3;
	private AIFComponentContext localAIFComponentContext;
	private ArrayList<AIFComponentContext> localAIFComponentContextList;
	private InterfaceAIFComponent parent_item;
	private ExecutionEvent exe_evt;
	private boolean isUpdatable;
	private boolean fullexpandable;
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private ArrayList<AIFComponentContext> uniqueErrObj;
	private Map<String,KeyValueLOV> keylovList;
	private Map<String,String> modifedvalueMap;
	private Map<String,String> modifedactvalueMap;
	private Map<String,String> depmodifedactvalueMap;
	private Map<String,String> attrNameIDMap;
	private Map<String,String> initialValMap;
	private Map<String,String> depmodifedvalueMap;
	private Map<String,String> tmpdepmodifedvalueMap;
	private Text searchText;
	private SearchViewerFilter searchFilter;
	private boolean isSuccess;
	private ArrayList<TCComponentItemRevision> ccvList;
	private String moduleAddr;
	private String SelBusUnit;
	private String SelTSDesc;
	private String SelVCSubClass;
	private String SelDsgnOwnCpy;
	private String SelDsgnDeptCpy;
	private String SelPartNum;
	private BOMExpansion bomexpansion;
	private  Map<String,String> arrayAttr;
	private TCComponentItemRevision ErcDMLObj;
	private String objType;
	private String SelParttype;
	private String IcoModCntrlInfo=null;
	private ArrayList<TCComponentItemRevision> class_not_found;
	private ArrayList<AIFComponentContext> ccvselList;
	private BooleanObject lastvalcopy;
	private ClassificationObject[] firstccvclsobj;
	private Exception openexception;
	private String wf_type="VCATTR";
	private String step_wf=null;
	private HashMap <String,String> moduleMandatoryMap;
	private String cmvrno;
	private String modClsname=null;
	private boolean isBypass =false;//added
	private boolean bypassUsrflg=false;
	private boolean cmvrValnullFlg=false;
	private String attrid=null;
	private String attrval=null;
	private String cmvrattrid=null;
	private String cmvrattrval=null;
	private boolean exceptionflg=false;
	private boolean DeptAttrFlg=false;
	private String prodlineattrval=null;
	private KeyLOVEntry[] keyLOVEntries;
	private KeyLOVDefinition2 lovDef;
	private int depattrcntrlobjsize=0;
	private String techspecno=null;
	private boolean  Hybridstatus=false;
	/**
	 * Create the dialog.
	 * @param parentShell
	 * @param selectedObj 
	 */
	public UpdateTechSpecDialog(Shell parentShell,TCSession session,ExecutionEvent exe_evt,TCComponentItemRevision ItemRev, TCComponent selectedObj,ArrayList<TCComponentItemRevision> ccvList) {
		super(parentShell);
		setShellStyle(SWT.SHELL_TRIM | SWT.BORDER);
		parentShell.setMaximized(true);
		this.session=session;
		this.ccvList=ccvList;
		this.ItemRev=ItemRev;
		this.selectedObj=selectedObj;
		this.attrid=attrid;
		this.attrval=attrval;
		//this.cmvrattrid=cmvrattrid;
		this.exceptionflg=exceptionflg;
		this.parentShell=parentShell;
		this.exe_evt=exe_evt;
		this.objType=selectedObj.getType();
		this.isUpdatable=isObjectUpdatable();
		this.mandatorylist=new ArrayList();
		this.modulemandatorylist=new ArrayList();
		this.aifcomponentctxtList=new ArrayList();
		this.fullexpandable=fullExpand(this.selectedObj);
		this.uniqueErrObj=new ArrayList();
		this.modClsname=modClsname;
		this.isBypass=isBypass;
		this.bypassUsrflg=bypassUsrflg;
		this.cmvrValnullFlg=cmvrValnullFlg;
		//	this.isUpdatable=true;
		namevalueP=new HashMap <String,Object>();
		m_commandTargetStateList = new ArrayList();
		m_commandTargetStateList1 = new ArrayList();
		m_commandTargetStateList2 = new ArrayList();
		m_commandTargetStateList3 = new ArrayList();
		localAIFComponentContextList= new ArrayList(); 
		this.keylovList=new TreeMap<String,KeyValueLOV>();
		this.modifedvalueMap=new TreeMap<String,String>();
		this.attrNameIDMap=new TreeMap<String,String>();
		this.initialValMap=new TreeMap<String,String>();
		this.modifedactvalueMap=new TreeMap<String,String>();
		this.depmodifedactvalueMap=new TreeMap<String,String>();
		this.depmodifedvalueMap=new TreeMap<String,String>();
		this.tmpdepmodifedvalueMap=new TreeMap<String,String>();
		this.isSuccess=false;
		this.prodlineattrval=prodlineattrval;
		this.keyLOVEntries=keyLOVEntries;
		this.lovDef=lovDef;
		this.DeptAttrFlg=DeptAttrFlg;
		bomexpansion=new BOMExpansion();
		
		TCComponent[] CmvrObjs=null;
		TCComponentItem CmvrObj=null;
		//int depcntrlobjsize=0;
		try {
			
			if(objType.equals("T5_TSCompRevision"))
			{
				System.out.println("objType:::"+objType );
				this.SelBusUnit=selectedObj.getTCProperty("t5_VCClassName").getDisplayableValue();
				this.SelTSDesc=selectedObj.getTCProperty("object_desc").getDisplayableValue();
				this.SelVCSubClass=selectedObj.getTCProperty("t5_VCSubClass").getDisplayableValue();
				this.SelDsgnOwnCpy=selectedObj.getTCProperty("t5_DsgnOwnCpy").getDisplayableValue();
				this.SelDsgnDeptCpy=selectedObj.getTCProperty("t5_DsgnDeptCpy").getDisplayableValue();
				TCComponentItemRevision tecspecVCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
				this.SelParttype=tecspecVCObj.getTCProperty("t5_PartType").getDisplayableValue();
				this.ErcDMLObj=TechSpecUtil.SecondaryToPrimaryObj("CMHasSolutionItem",tecspecVCObj);
				this.cmvrno=TechSpecUtil.getCmvrNoFrmVC((TCComponentItemRevision) tecspecVCObj,cmvrno);
				this.cmvrattrid=TechSpecUtil.getCmvrattridFunc(SelBusUnit);
				this.techspecno=selectedObj.getTCProperty("item_id").getDisplayableValue();
				//this.depprodlineval=TechSpecUtil.getDepattridFunc(SelBusUnit);
				 this.depattrcntrlobjsize=TechSpecUtil.getDepattridFuncSize(SelBusUnit);
				System.out.println("if in updateTechspecdlg class by func getCmvrNoFrmVC cmvr Primary Object="+cmvrno +" cmvrattrid="+cmvrattrid  +" depattrcntrlobjsize="+depattrcntrlobjsize);
			// this.depattrcntrlobjsize=depcntrlobjsize;
				
				//TCComponentItem cmvrobj = (TCComponentItem) tecspecVCObj.getTCProperty("t5_VehForCmvr").getReferenceValue();
				//this.cmvrno=cmvrobj.getTCProperty("t5_CmvrNo").getDisplayableValue();
			}
			else
			{
				this.SelParttype=selectedObj.getTCProperty("t5_PartType").getDisplayableValue();
				if(SelParttype.equals("Vehicle") || SelParttype.equals("Vehicle Combination") || SelParttype.equals("Configurable VC") || SelParttype.equals("Vehicle Combination CR"))//Case For : VC/Vehicle
				{
					//CmvrObj=TechSpecUtil.SecondaryToPrimary("T5_CmvrVeh",(TCComponentItemRevision) selectedObj);
					//CmvrObj=(TCComponentItem) selectedObj.getTCProperty("t5_VehForCmvr").getReferenceValue();
					
					this.cmvrno=TechSpecUtil.getCmvrNoFrmVC((TCComponentItemRevision) selectedObj,cmvrno);
					System.out.println("if in updateTechspecdlg class by func getCmvrNoFrmVC cmvr Primary Object="+cmvrno);
					
					
					//TCComponentItem cmvrobj = (TCComponentItem) selectedObj.getTCProperty("t5_VehForCmvr").getReferenceValue();
					//this.cmvrno=cmvrobj.getTCProperty("t5_CmvrNo").getDisplayableValue();
					this.ErcDMLObj=TechSpecUtil.SecondaryToPrimaryObj("CMHasSolutionItem",selectedObj);
					TCComponent[] techspec=selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
					//TCComponentItemRevision techspec=selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
					if (techspec!=null && techspec.length>0) // If  TechSpec is attached to VC/Vehicle Show Classification Dialog for resp. BU
					{
						//UpdDlgFlg=true;
						this.techspecno=techspec[0].getTCProperty("item_id").getDisplayableValue();
						SelBusUnit = techspec[0].getTCProperty("t5_VCClassName").getDisplayableValue();
						System.out.println("in vehicle selection TSBusiUnit:-"+SelBusUnit);
						this.SelTSDesc=techspec[0].getTCProperty("object_desc").getDisplayableValue();
						this.SelVCSubClass=techspec[0].getTCProperty("t5_VCSubClass").getDisplayableValue();
						this.SelDsgnOwnCpy=techspec[0].getTCProperty("t5_DsgnOwnCpy").getDisplayableValue();
						this.SelDsgnDeptCpy=techspec[0].getTCProperty("t5_DsgnDeptCpy").getDisplayableValue();
						this.cmvrattrid=TechSpecUtil.getCmvrattridFunc(SelBusUnit);
						//this.depprodlineval=TechSpecUtil.getDepattridFunc(SelBusUnit);
						 this.depattrcntrlobjsize=TechSpecUtil.getDepattridFuncSize(SelBusUnit);
						//						tsdesc.setText(selectedObj.getPropertyDisplayableValue("object_desc"));
						//						tsbu.setText(selectedObj.getPropertyDisplayableValue("t5_VCClassName")); 
						//						tsvsc.setText(selectedObj.getPropertyDisplayableValue("t5_VCSubClass"));
						//						tsodu.setText(selectedObj.getPropertyDisplayableValue("t5_DsgnOwnCpy"));
						//						tsodd.setText(selectedObj.getPropertyDisplayableValue("t5_DsgnDeptCpy"));
						
						//System.out.println("inside vehicle selection cmvrattrid:----------  "+cmvrattrid +" depattrcntrlobjsize="+depattrcntrlobjsize);
					}
					
					this.Hybridstatus=new TechSpecUtil().getHybridVCFlag(session,(TCComponentItemRevision) selectedObj);
					System.out.println("inside vehicle selection cmvrattrid:----------  "+cmvrattrid +" depattrcntrlobjsize="+depattrcntrlobjsize+ " Hybridstatus="+Hybridstatus);
				}
				else if(SelParttype.equals("Module") || SelParttype.equals("M"))
				{

					try {
						String classdesc = null;
						this.SelPartNum=selectedObj.getPropertyDisplayableValue("item_id");
						this.moduleAddr=selectedObj.getPropertyDisplayableValue("t5_ModuleAddress");
						System.out.println("moduleAddr:----------  "+moduleAddr);
						String projcode=SelPartNum.substring(0,4);
						System.out.println("b4 call getClsNmaeForModuleAdd projcode="+projcode +"ModuleAddress="+moduleAddr );
						//String modClsname;
						this.techspecno=SelPartNum;
						SelBusUnit = TechSpecUtil.getClsNmaeForModuleAdd(projcode,moduleAddr);
					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					System.out.println("after call getClsNmaeForModuleAdd SelBusUnit="+SelBusUnit );
				}			
				
				else
				{
					System.out.println("Part Type ["+SelParttype +"]" + "is not Module/vehicle/TechSpec !!" );
					//return true;
				}


			}
			System.out.println("Final TSBusiUnit:-"+SelBusUnit +"  Report file name would be="+techspecno);
			ShowClassificationViewHandler viewCls=new ShowClassificationViewHandler();
			//System.out.println(" CMVRNO="+cmvrno );
			System.out.println("viewCls:-"+viewCls.getClass());
		} catch (TCException | NotLoadedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//this.ErcDMLObj=TechSpecUtil.SecondaryToPrimaryObj("CMHasSolutionItem",selectedObj);
		//System.out.println(" 22CMVRNO="+cmvrno );
		if(ErcDMLObj==null)
		{
			String step_wf1="Update VC attribute*";
			System.out.println("step_wf1:::"+step_wf1 );
			ErcDMLObj=TechSpecUtil.getAttachedDML((TCComponentItemRevision) selectedObj,"CMHasSolutionItem",/*"Update VC attributes and Tech Spec Header""Update VC attributes*"*/step_wf1);

		}
		this.class_not_found=new ArrayList<TCComponentItemRevision>();
		ccvselList= new ArrayList<AIFComponentContext>();
		this.lastvalcopy=new BooleanObject(false);
		moduleMandatoryMap=new HashMap <String,String>();

		System.out.println("1SelParttype:::"+SelParttype );
		try {
			if(ErcDMLObj!=null)
			{
				System.out.println("ErcDMLObj:::"+ErcDMLObj.getTCProperty("object_string").getDisplayableValue() );
			}
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Exception getOpenexception() {
		return openexception;
	}


	public int constructCheckedInfoDialog()
	{

		int checkdlg = 0;
		TCComponentItem parent_item1=null;
		ArrayList<CommandTargetState> mul_commandTargetStateList=new ArrayList<CommandTargetState>();
		// ArrayList<AIFComponentContext> mul_aifcomponentctxtList=new ArrayList<AIFComponentContext>();
		AIFComponentContext localMultiAIFComponentContext;
		ArrayList<AIFComponentContext> localMulAIFComponentContextList=new ArrayList<AIFComponentContext>();
		int sz=ccvList.size();
		for (int f=0;f<sz;f++)  
		{


			TCComponentItemRevision item_rev1=ccvList.get(f);

			// System.out.println("item_rev1 cons:"+item_rev1.toDisplayString());

			try {
				parent_item1 = item_rev1.getItem();
				localMultiAIFComponentContext=new AIFComponentContext(parent_item1,item_rev1,"structure_revision");
				CommandTargetState cmdstate1=new CommandTargetState(localMultiAIFComponentContext,null);
				String desc=item_rev1.getTCProperty("object_name").getDisplayableValue();
				cmdstate1.setCaughtException(new TCException(desc));
				cmdstate1.setDone(true);
				localMulAIFComponentContextList.add(localMultiAIFComponentContext);
				mul_commandTargetStateList.add(cmdstate1);

			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



		}
		if(localMulAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localMulAIFComponentContextList.toArray(new AIFComponentContext[localMulAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			final Shell shl=app.getDesktop().getShell();

			TCSession session=(TCSession) app.getSession();

			TMLDataBean databean= new TMLDataBean(session, null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside localMulAIFComponentContextList update status printing step2");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(mul_commandTargetStateList);

			checkdlg=  TMLCheckedMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },2,"Please Select CCV to Copy Same Classification Data:",ccvselList, lastvalcopy);

			/* 
        checkdlg.getM_treeTableView().getTreeViewer().addCheckStateListener(new ICheckStateListener() {
		      public void checkStateChanged(CheckStateChangedEvent event) {
		        // If the item is checked . . .


		    	  MessageBox.post(shl, "vgfgf", "hhghg", MessageBox.INFORMATION);

		    	  if(event.getChecked())
		    	  {
		    		  //event.
		    		  AIFComponentContext aif_ctx=checkdlg.getIC_AIFContext(event.getElement());
		    		  System.out.println("Checked::"+aif_ctx.getComponent().toString());
		    		  ccvselList.add(aif_ctx);
		    		  //selectitem. event.getChecked()
		    	  }
		      }
		    });*/
		}

		//return selecetdobj;

		return checkdlg;

	}


	public int constructMultiInfoDialog(LinkedHashMap <TCComponentItemRevision,String> ccvResult,boolean[] successList,String dismsg)
	{
		int processfurther = 0;
		TCComponentItem parent_item1=null;
		ArrayList<CommandTargetState> mul_commandTargetStateList=new ArrayList<CommandTargetState>();
		// ArrayList<AIFComponentContext> mul_aifcomponentctxtList=new ArrayList<AIFComponentContext>();
		AIFComponentContext localMultiAIFComponentContext;
		ArrayList<AIFComponentContext> localMulAIFComponentContextList=new ArrayList<AIFComponentContext>();
		HashMap<String,TCComponentItemRevision> no_cls_found=bomexpansion.getClass_not_found();
		int x=0;
		for (Map.Entry<TCComponentItemRevision,String> entry2 : ccvResult.entrySet())  
		{


			TCComponentItemRevision item_rev1=entry2.getKey();
			String msg=entry2.getValue();

			// System.out.println("item_rev1 cons:"+item_rev1.toDisplayString());

			try {
				parent_item1 = item_rev1.getItem();
				localMultiAIFComponentContext=new AIFComponentContext(parent_item1,item_rev1,"structure_revision");
				CommandTargetState cmdstate1=new CommandTargetState(localMultiAIFComponentContext,null);
				cmdstate1.setCaughtException(new TCException(msg));
				cmdstate1.setDone(successList[x++]);
				localMulAIFComponentContextList.add(localMultiAIFComponentContext);
				mul_commandTargetStateList.add(cmdstate1);

			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



		}
		if(localMulAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localMulAIFComponentContextList.toArray(new AIFComponentContext[localMulAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			TCSession session=(TCSession) app.getSession();

			TMLDataBean databean= new TMLDataBean(session, null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside update status printing step3");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(mul_commandTargetStateList);

			// TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },1,null);
			processfurther=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },2,dismsg);

			// return false;
		}



		return processfurther;

	}


	public boolean constructMultiErrorDialog()
	{
		int processfurther = 0;
		TCComponentItem parent_item1=null;
		ArrayList<CommandTargetState> mul_commandTargetStateList=new ArrayList<CommandTargetState>();
		// ArrayList<AIFComponentContext> mul_aifcomponentctxtList=new ArrayList<AIFComponentContext>();
		AIFComponentContext localMultiAIFComponentContext;
		ArrayList<AIFComponentContext> localMulAIFComponentContextList=new ArrayList<AIFComponentContext>();
		HashMap<String,TCComponentItemRevision> no_cls_found=bomexpansion.getClass_not_found();
		for (Map.Entry<String, TCComponentItemRevision> entry2 : no_cls_found.entrySet())  
		{
			String msg=entry2.getKey();

			TCComponentItemRevision item_rev1=entry2.getValue();

			// System.out.println("item_rev1 cons:"+item_rev1.toDisplayString());

			try {
				parent_item1 = item_rev1.getItem();
				localMultiAIFComponentContext=new AIFComponentContext(parent_item1,item_rev1,"structure_revision");
				CommandTargetState cmdstate1=new CommandTargetState(localMultiAIFComponentContext,null);
				cmdstate1.setCaughtException(new TCException(msg));
				cmdstate1.setDone(false);
				localMulAIFComponentContextList.add(localMultiAIFComponentContext);
				mul_commandTargetStateList.add(cmdstate1);

			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



		}
		if(localMulAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localMulAIFComponentContextList.toArray(new AIFComponentContext[localMulAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			TCSession session=(TCSession) app.getSession();

			TMLDataBean databean= new TMLDataBean(session, null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside update status printing stepxx");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(mul_commandTargetStateList);

			// TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },1,null);
			processfurther=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.YES_LABEL , IDialogConstants.NO_LABEL },1,"Below Modules Cassification-Hierarchy is Missing.\nDo you want to Continue ? ");

			// return false;
		}

		System.out.println("processfurther::"+processfurther);
		if(processfurther==0)
			return true;

		return false;

	}




	public boolean isSuccess() {
		return isSuccess;
	}



	protected boolean ServiceDataError(final ServiceData data)
	{

		if(data.sizeOfPartialErrors() > 0)
		{
			for(int i = 0; i < data.sizeOfPartialErrors(); i++)
			{
				for(String msg :
					data.getPartialError(i).getMessages())
					System.out.println("ServiceDataError:"+msg);
			}

			return true;
		}

		return false;
	}


	// Determines whether to Exapnd upto to Second Level( return true)
	// For all Case (CCV/VC/Vehicle/Techspes Header/Super SVR) except Module  Exapnd upto to Second Level
	public boolean fullExpand(TCComponent obj)
	{

		System.out.println("fullExpand function \n");
		String SelobjType= selectedObj.getType();
		System.out.println("fullExpand function SelobjType=  "+SelobjType+ "\nItemRev="+ItemRev);
		//boolean Hybridstatus=false;
		if(SelobjType.length()<=0)
		{
			return false;
		}
		if(SelobjType.equals("Design Revision"))
		{

			try {
				String SelectedObjType=selectedObj.getTCProperty("t5_PartType").getDisplayableValue();
				if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Vehicle Combination")|| SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))
//					 Hybridstatus=new TechSpecUtil().getHybridVCFlag(selectedObj.getSession(),(TCComponentItemRevision) selectedObj);
//				System.out.println("inside fullExpand Hybrid status  "+Hybridstatus);
//				if(Hybridstatus==true)
//				{
//					return false;
//				}
//				else
//				{
//					return true;
//				}
				
					return true;
				else
					return false;
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		



		return true; // return false;


	}



	public Object[] getAllTreeObjects(ArrayList<ClassificationTreeLine> treeobjs) throws TCException
	{

		for(int d=0;d<treeobjs.size();d++)
		{

			ClassificationTreeLine parentElement=treeobjs.get(d);

			if(parentElement instanceof ClassificationTreeLine)
			{

				ClassificationTreeLine p = (ClassificationTreeLine) parentElement;
				System.out.println("parentElement::>>>>"+parentElement);
				String clsObjName=parentElement.getObjectid();
				System.out.println("clsObjName::>>>>"+clsObjName);
				String projcode=clsObjName.substring(0, 4);
				String modaddress=p.getModuleAddress();
				System.out.println("modaddress::>>>>"+modaddress);
				TCComponentItemRevision modulerev=p.getItemrev();
				System.out.println("modulerev::>>>>"+modulerev);
				TCComponentItemRevision latRelModRev=null;
				TCComponentItemRevision ercdml_rev=null;
				latRelModRev=TechSpecUtil.getLatestReleasedPart(modulerev);
				//this.clsobjs=p.getClsobjs(); //newly added on 03/02/2026



				String childparttype=null;
				try {
					childparttype=modulerev.getTCProperty("t5_PartType").getDisplayableValue();
				} catch (TCException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				System.out.println("in UpdateTechSpecDialog b4 call getClsNmaeForModuleAdd projcode="+projcode +"modaddress="+modaddress +"childparttype="+childparttype );

				/*
				 * try { //modClsname =
				 * TechSpecUtil.getClsNmaeForModuleAdd(projcode,modaddress); } catch
				 * (NotLoadedException e2) { // TODO Auto-generated catch block
				 * e2.printStackTrace(); } catch (TCException e2) { // TODO Auto-generated catch
				 * block e2.printStackTrace(); }
				 */

				//System.out.println("in UpdateTechSpecDialog after call getClsNmaeForModuleAdd modClsname="+modClsname );

				SortedMap <String,ArrayList<ClassificationTableLine>> annotatonMap=new TreeMap <String,ArrayList<ClassificationTableLine>>();
				TCComponentItemRevision tcrev= p.getItemrev();
				AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
				TCSession session=(TCSession) app.getSession();
				TCComponentItem tc_ico_item=null;
				try {
					tc_ico_item=tcrev.getItem();
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//GetClassifiedAttr getProps= new GetClassifiedAttr(tc_ico_item,session); //hashed on 07/Nov/2023
				GetClassifiedAttr getProps= new GetClassifiedAttr(tc_ico_item,session,SelBusUnit); //added on 07/Nov/2023
//hashed on 09122022 by rajesh
				//getProps.getICOProps().
				String modadd=null;
				boolean valsetflg=false;
				if(getProps!=null)
				{
					try {
						//if(getProps.getICOProps(SelBusUnit)!=null)
						System.out.println("b4 call getProps.getICOProps()  modaddress="+modaddress);
						if(getProps.getICOProps1(modaddress)!=null)
							//if(getProps.getICOProps()!=null)
							//modaddress=getProps.getICOProps(SelBusUnit).getCid();
							//modaddress=getProps.getICOProps().getCid();
							//modadd=getProps.getICOProps().getCid();
						modadd=getProps.getICOProps1(modaddress).getCid();
						System.out.println("xxcc modadd="+modadd +" modaddress="+modaddress);
							if(modaddress!=null && modadd!=null)
							{
								System.out.println("inside modaddress!=null && modadd!=null "+modaddress); 
								if(modaddress.equals(modadd))
								{
									modaddress=modadd;
									valsetflg=true;
									System.out.println("inside modaddress.equals(modadd) valsetflg="+valsetflg); 
								}
							}
						System.out.println("xxcc modaddress="+modaddress); 
						
					} catch (ServiceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
////End by rajesh on 09122022
				ArrayList<ClassificationTableLine> classificationList=new ArrayList<ClassificationTableLine>();
				try {
					//classificationList = new GetModuleAttributesForClasses(modaddress,session).testgetGetAttributesForClasses();
					System.out.println("b4 call GetModuleAttributesForClasses modaddress:::"+modaddress + "SelParttype="+SelParttype +"childparttype="+childparttype);
					//if(SelParttype.isEmpty()==false)
					classificationList = new GetModuleAttributesForClasses(modaddress,session).testgetGetAttributesForClasses();
					
					//classificationList = new GetModuleAttributesForClasses(modaddress,session).testgetGetAttributesForClasses();
					
					/*
					 * if(childparttype!=null) { if(childparttype.equals("Module")) {
					 * classificationList = new GetModuleAttributesForClasses(modClsname,session).
					 * testgetGetAttributesForClasses(); } else { classificationList = new
					 * GetModuleAttributesForClasses(modaddress,session).
					 * testgetGetAttributesForClasses(); } } else { classificationList = new
					 * GetModuleAttributesForClasses(modaddress,session).
					 * testgetGetAttributesForClasses(); }
					 */
				} catch (ServiceException | TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					openexception=e;
					this.isSuccess=false;
				}
				LinkedHashMap<String,ClassificationTableLine> classificationList1=new LinkedHashMap<String,ClassificationTableLine>();
				System.out.println("UpdateTechSpecDialog classificationList1 classificationList.size()="+classificationList.size());
				if(classificationList.size()>0) //added newly on 22 Jan 2026
				{
					for(int a=0;a<classificationList.size();a++)
					{
						ClassificationTableLine clstb=classificationList.get(a);
						//System.out.println("classificationList1.put for clstb.getAttrID()="+clstb.getAttrID());
						classificationList1.put(clstb.getAttrID(), clstb);
						//System.out.println("classificationList1.put for clstb="+clstb);

					}
				}
					System.out.println("UpdateTechSpecDialog for modaddress="+modaddress);
					try {
						//if(getProps.getICOProps(SelBusUnit)!=null)
						System.out.println(" valsetflg="+valsetflg);
						if(valsetflg==true)
						{
							//if(getProps.getICOProps()!=null)
							if(getProps.getICOProps1(modaddress)!=null)
							{
								Map<BigInteger, AttributeValues> map2 = null;

								map2 = getProps.getICOProps1(modaddress).getAttrValuesMap();
								//map2 = getProps.getICOProps().getAttrValuesMap();

								for( Object key2 : map2.keySet())
								{
									//System.out.println("UpdateTechSpecDialog keyw.get(key2)="+key2.getClass());

									//System.out.println("UpdateTechSpecDialog="+map2.get(key2).getClass());
									AttributeValues fv=map2.get(key2);
									// for(int f=0;f<classificationList.size();f++)
									{
										// ClassificationTableLine tabline=classificationList.get(f);

										//if(tabline.getAttrID().equals(key2.toString()))
										if(classificationList1!=null) //newly added on 30Jun2025
										{
											ClassificationTableLine tabline=classificationList1.get(key2.toString());
											if(tabline!=null) //newly added on 30Jun2025
											{


												Value[] vals=  fv.values;
												String allvalue="";
												//System.out.println("1VVVkey2::"+key2+" Val:"+vals.length);	
												for(int x1=0;x1<vals.length;x1++)
												{
													//System.out.println("key2"+key2+" Val:"+vals[x1].attrValue +" cmvrattrid="+cmvrattrid);	
													//if(key2.equals("8171"))
													if(key2.equals(cmvrattrid))
													{
														if(vals[x1].attrValue.isEmpty()||vals[x1].attrValue.length()==0)
														{
															//tabline.setAttrValue("NA");
															allvalue+="NA";
														}
														else
														{
															allvalue+=vals[x1].attrValue;
														}
													}
													else
													{

														allvalue+=vals[x1].attrValue;
													}
													if(x1<vals.length-1)
														allvalue+=PreferenceValue.getARRAY_DELMITER();

												}
												System.out.println("11allvalue::"+allvalue);
												if(allvalue.length()>0 && (tabline!=null))
												{

													tabline.setAttrValue(allvalue);
													System.out.println("allvalue::"+allvalue);
													//attrNameIDMap.put(tabline.getAttrID(), tabline.getAttrName()); //added on 10122022

												}
												else
												{

												}


												///////nnnn
												if(tabline!=null)
												{
													attrNameIDMap.put(tabline.getAttrID(), tabline.getAttrName()); //hashed on 10122022
												}
											}
										}
									}
								}

							}
						}
					} catch (ServiceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					moduleMandatoryMap=new HashMap <String,String>();
					//start portion for bypass tabline 
					String info=null;
					String UsrData1=null;
					String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
					String [] qryValues={"SKIPTECHSPECATTR","SKIPTECHSPECATTR","0"};
					//int r;
					TCComponent[] objvec;
					try {
						objvec = TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);

						if(objvec!=null)
						{
							for(int f=0;f<objvec.length;f++)
							{
								TCComponent objcntrl=objvec[f];
								info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
								System.out.println("inside skipTech Spec attr info="+info);
							}
						}
					} catch (TCException | NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("2inside skipTech Spec attr's info="+info + " Hybridstatus = "+Hybridstatus);
					for(int r=0;r<classificationList.size();r++)
					{
						//Map<Object, AttributeValues> AttrValMap=getProps.getICOProps().getAttrValuesMap();

						ClassificationTableLine tab_line=classificationList.get(r);
						System.out.println("ANNO:"+ tab_line);
						String anno_txt=tab_line.getAnnotation();
						initialValMap.put(tab_line.getAttrID(), tab_line.getAttrValue());
						System.out.println("ANNO TXT::"+ anno_txt);
						ClassificationAnnotationLine annot_lin=new ClassificationAnnotationLine(anno_txt);
						ArrayList<ClassificationTableLine> annotation_clastabline=annotatonMap.get(anno_txt);
						attrid=tab_line.getAttrID();
						attrval=tab_line.getAttrValue();
						boolean reqattrFlg=tab_line.isIsmandatory();
						System.out.println("attrid:"+attrid +"attrval:"+ attrval +"reqattrFlg:"+reqattrFlg+"clsObjName="+clsObjName);
						System.out.println("attrval.isEmpty()::"+ attrval.isEmpty());

						System.out.println("attrid.contains(\"171\")="+attrid.contains("171"));
						//this.cmvrattrid="";
						this.cmvrattrval="";

						if(attrid.contains("171")==true)
						{
							//this.cmvrattrid+=attrid;
							//this.cmvrattrval+=attrval;
							System.out.println("attrval::"+ attrval +"cmvrno="+cmvrno);
							if(attrval.isEmpty())
							{
								//cmvrValnullFlg=true;
								attrval+="NA";
							}
							else
							{
								attrval=cmvrno;
							}

						}
						//System.out.println("value set for cmvrattrid="+cmvrattrid+  "cmvrValnullFlg=" +cmvrValnullFlg);






						//End portion for bypass tabline

						String modarrsbypass=null;
						String tobemodarrs=null;
						String ErcDmlNo=null;
						if(reqattrFlg==true)
						{
							if(!Hybridstatus)
							{
								if(info==null)
								{
									if(anno_txt.contains("MODULE"))
									{
										String clsObjNameCpy=clsObjName;
										String basemodaddr=clsObjNameCpy.substring(4,(clsObjNameCpy.length()-5));
										modarrsbypass=null;
										basemodaddr="M"+basemodaddr;
										tobemodarrs=null;
										if(SelBusUnit.contains("CAR"))
										{
											tobemodarrs=basemodaddr;	
										}
										else
										{
											tobemodarrs=SelBusUnit+basemodaddr;
										}
										System.out.println("basemodaddr="+basemodaddr +" SelBusUnit="+SelBusUnit +" tobemodarrs="+tobemodarrs);
										try {
											modarrsbypass=TechSpecUtil.getBypassModAddrs(tobemodarrs);
										} catch (NotLoadedException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										} catch (TCException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}

										System.out.println(" modarrsbypass="+modarrsbypass);
										if(modarrsbypass.contains("FALSE"))
										{								
											if(attrval.isEmpty()==true)
											{
												//moduleMandatoryMap.put(clsObjName,attrid);

												System.out.println("in loop attrid="+attrid +" attrval.length()= "+attrval.length() +" clsObjName="+clsObjName );
												/*
												 * if(uniqueErrObj.contains(localAIFComponentContext)==false) {
												 * System.out.println("in loop attrval="+attrval
												 * +"attrval.length()="+attrval.length()+
												 * "!uniqueErrObj.contains(localAIFComponentContext)"+uniqueErrObj.contains(
												 * localAIFComponentContext)); modulemandatorylist.
												 * add("Please Fill the below Module's Mandatory Attributes !! ");
												 * aifcomponentctxtList.add(localAIFComponentContext);
												 * uniqueErrObj.add(localAIFComponentContext);
												 * System.out.println("localAIFComponentContext="+localAIFComponentContext ); }
												 */
												//if(ErcDMLObj !=null && modulerev !=null)
												//{
												System.out.println("b4 ChldModuleToTaskAttachRel");
												if(ErcDMLObj!=null)
												{

													try {
														ErcDmlNo = ErcDMLObj.getTCProperty("item_id").getDisplayableValue();
													} catch (TCException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
													}
													//ErcDmlNo="10PP131333"; //need to delete before check in
													System.out.println("b4 ChldModuleToTaskAttachRel ErcDmlNo="+ErcDmlNo +"ErcDmlNo.length()="+ErcDmlNo.length());

												}

												try {
													IcoModCntrlInfo=TechSpecUtil.getICOMODCntrlObjInfo(clsObjName);
												} catch (NotLoadedException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
												} catch (TCException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
												}
												System.out.println("IcoModCntrlInfo = "+IcoModCntrlInfo);
												latRelModRev=TechSpecUtil.getLatestReleasedPart(modulerev);

												//}
												if(SelParttype!=null)
												{
													if(SelParttype.equals("Module")==false)
													{
														if(ErcDmlNo!=null && ErcDmlNo.contains("APL")==false && ErcDmlNo.length()==13)
														{
															if(IcoModCntrlInfo!=null)
															{
																System.out.println("IcoModCntrlInfo.contains(attrid) = "+IcoModCntrlInfo.contains(attrid) +"attrid="+attrid);
																if(IcoModCntrlInfo.contains(attrid)==false)
																{				  			
																	modulemandatorylist.add(clsObjName+":"+attrid);
																	//to create child module relation relation with ERC task to update classification
																	//TechSpecUtil.ChldModuleToTaskAttachRel(ErcDMLObj,modulerev);
																	try {

																		//ErcDMLObj.add("CMReferences", modulerev);
																		latRelModRev=TechSpecUtil.getLatestReleasedPart(modulerev);
																		//ErcDMLObj.add("IMAN_reference", modulerev);
																		if(latRelModRev!=null)
																		{
																			ErcDMLObj.lock();
																			ErcDMLObj.add("IMAN_reference", latRelModRev);
																			ErcDMLObj.save();
																			ErcDMLObj.unlock();
																		}


																	} catch (TCException e) {
																		// TODO Auto-generated catch block
																		e.printStackTrace();
																	}
																}
															}
															else
															{	
																System.out.println("mandatory value is null for latRelModRev="+clsObjName +" and attrid= "+attrid +" isUpdatable= "+isUpdatable);
																if(isUpdatable==true)
																{
																	modulemandatorylist.add(clsObjName+":"+attrid);
																	System.out.println("ErcDMLObj="+ErcDMLObj +" latRelModRev= "+latRelModRev);
																	//to create child module relation relation with ERC task to update classification
																	if(ErcDMLObj!=null && latRelModRev!=null)
																	{
																		//TechSpecUtil.ChldModuleToTaskAttachRel(ErcDMLObj,modulerev);
																		try {
																			ErcDMLObj.lock();
																			//ErcDMLObj.add("CMReferences", modulerev);
																			//ErcDMLObj.add("CMHasImpactedItem", modulerev);

																			ErcDMLObj.add("IMAN_reference", latRelModRev);
																			ErcDMLObj.save();
																			ErcDMLObj.unlock();
																		} catch (TCException e) {
																			// TODO Auto-generated catch block
																			ErcDMLObj.unlock();
																			e.printStackTrace();
																		}
																	}
																}

															}
														}

													}
												}
												//aifcomponentctxtList.add(localAIFComponentContext);

											}
										}
									}
								}
								else
								{	
									if(anno_txt.contains(info)==false)
									{
										if(anno_txt.contains("MODULE"))
										{
											String clsObjNameCpy=clsObjName;
											String basemodaddr=clsObjNameCpy.substring(4,(clsObjNameCpy.length()-5));
											modarrsbypass=null;
											basemodaddr="M"+basemodaddr;
											tobemodarrs=null;
											if(SelBusUnit.contains("CAR"))
											{
												tobemodarrs=basemodaddr;	
											}
											else
											{
												tobemodarrs=SelBusUnit+basemodaddr;
											}
											System.out.println("basemodaddr="+basemodaddr +" SelBusUnit="+SelBusUnit +" tobemodarrs="+tobemodarrs);
											try {
												modarrsbypass=TechSpecUtil.getBypassModAddrs(tobemodarrs);
											} catch (NotLoadedException e1) {
												// TODO Auto-generated catch block
												e1.printStackTrace();
											} catch (TCException e1) {
												// TODO Auto-generated catch block
												e1.printStackTrace();
											}

											System.out.println(" modarrsbypass="+modarrsbypass);
											if(modarrsbypass.contains("FALSE"))
											{								
												if(attrval.isEmpty()==true)
												{
													//moduleMandatoryMap.put(clsObjName,attrid);

													System.out.println("in loop attrid="+attrid +" attrval.length()= "+attrval.length() +" clsObjName="+clsObjName );
													/*
													 * if(uniqueErrObj.contains(localAIFComponentContext)==false) {
													 * System.out.println("in loop attrval="+attrval
													 * +"attrval.length()="+attrval.length()+
													 * "!uniqueErrObj.contains(localAIFComponentContext)"+uniqueErrObj.contains(
													 * localAIFComponentContext)); modulemandatorylist.
													 * add("Please Fill the below Module's Mandatory Attributes !! ");
													 * aifcomponentctxtList.add(localAIFComponentContext);
													 * uniqueErrObj.add(localAIFComponentContext);
													 * System.out.println("localAIFComponentContext="+localAIFComponentContext ); }
													 */
													//if(ErcDMLObj !=null && modulerev !=null)
													//{
													System.out.println("b4 ChldModuleToTaskAttachRel");
													if(ErcDMLObj!=null)
													{

														try {
															ErcDmlNo = ErcDMLObj.getTCProperty("item_id").getDisplayableValue();
														} catch (TCException e) {
															// TODO Auto-generated catch block
															e.printStackTrace();
														}
														//ErcDmlNo="10PP131333"; //need to delete before check in
														System.out.println("b4 ChldModuleToTaskAttachRel ErcDmlNo="+ErcDmlNo +"ErcDmlNo.length()="+ErcDmlNo.length());

													}

													try {
														IcoModCntrlInfo=TechSpecUtil.getICOMODCntrlObjInfo(clsObjName);
													} catch (NotLoadedException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
													} catch (TCException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
													}
													System.out.println("IcoModCntrlInfo = "+IcoModCntrlInfo);
													latRelModRev=TechSpecUtil.getLatestReleasedPart(modulerev);

													//}
													if(SelParttype!=null)
													{
														if(SelParttype.equals("Module")==false)
														{
															if(ErcDmlNo!=null && ErcDmlNo.contains("APL")==false && ErcDmlNo.length()==13)
															{
																if(IcoModCntrlInfo!=null)
																{
																	System.out.println("IcoModCntrlInfo.contains(attrid) = "+IcoModCntrlInfo.contains(attrid) +"attrid="+attrid);
																	if(IcoModCntrlInfo.contains(attrid)==false)
																	{				  			
																		modulemandatorylist.add(clsObjName+":"+attrid);
																		//to create child module relation relation with ERC task to update classification
																		//TechSpecUtil.ChldModuleToTaskAttachRel(ErcDMLObj,modulerev);
																		try {

																			//ErcDMLObj.add("CMReferences", modulerev);
																			latRelModRev=TechSpecUtil.getLatestReleasedPart(modulerev);
																			//ErcDMLObj.add("IMAN_reference", modulerev);
																			if(latRelModRev!=null)
																			{
																				ErcDMLObj.lock();
																				ErcDMLObj.add("IMAN_reference", latRelModRev);
																				ErcDMLObj.save();
																				ErcDMLObj.unlock();
																			}


																		} catch (TCException e) {
																			// TODO Auto-generated catch block
																			e.printStackTrace();
																		}
																	}
																}
																else
																{	
																	System.out.println("mandatory value is null for latRelModRev="+clsObjName +" and attrid= "+attrid +" isUpdatable= "+isUpdatable);
																	if(isUpdatable==true)
																	{
																		modulemandatorylist.add(clsObjName+":"+attrid);
																		System.out.println("ErcDMLObj="+ErcDMLObj +" latRelModRev= "+latRelModRev);
																		//to create child module relation relation with ERC task to update classification
																		if(ErcDMLObj!=null && latRelModRev!=null)
																		{
																			//TechSpecUtil.ChldModuleToTaskAttachRel(ErcDMLObj,modulerev);
																			try {
																				ErcDMLObj.lock();
																				//ErcDMLObj.add("CMReferences", modulerev);
																				//ErcDMLObj.add("CMHasImpactedItem", modulerev);

																				ErcDMLObj.add("IMAN_reference", latRelModRev);
																				ErcDMLObj.save();
																				ErcDMLObj.unlock();
																			} catch (TCException e) {
																				// TODO Auto-generated catch block
																				ErcDMLObj.unlock();
																				e.printStackTrace();
																			}
																		}
																	}

																}
															}

														}
													}
													//aifcomponentctxtList.add(localAIFComponentContext);

												}
											}
										}
									}
								}
							}
						}

						//System.out.println(" before tabline add modarrsbypass="+modarrsbypass);
						if(modarrsbypass==null|| modarrsbypass.isEmpty()||modarrsbypass.contains("FALSE"))
						{
							if(annotation_clastabline==null)
							{
								annotation_clastabline=new ArrayList<ClassificationTableLine>();
								annotation_clastabline.add(tab_line);
								annotatonMap.put(tab_line.getAnnotation(), annotation_clastabline);
							}
							else
							{

								annotation_clastabline.add(tab_line);

							}
						}
					}
					System.out.println(" before tabline add annotatonMap.values()="+annotatonMap.values() +" annotatonMap.values().size() ="+annotatonMap.values().size()); 
					if(annotatonMap.values().size()>0) //removing the module which module address has bypassed to set in dialog
					{
						Set<String> keys = annotatonMap.keySet();
						ArrayList<ClassificationAnnotationLine> cl_annotlist1=new ArrayList<ClassificationAnnotationLine>();
						for(String key: keys){
							ClassificationAnnotationLine clsanno_line=new ClassificationAnnotationLine(key);
							clsanno_line.setParent(p);
							cl_annotlist1.add(clsanno_line);

							ArrayList<ClassificationTableLine> arList=annotatonMap.get(key);
							clsanno_line.setAttrList(arList);

							for(int k=0;k<arList.size();k++)
							{

								arList.get(k).setParent(clsanno_line);

							}
							// System.out.println("Value of "+key+" is: "+hm.get(key));
						}


						p.setAttrList(cl_annotlist1);

						ArrayList<Object> allobjs=new ArrayList<Object>();
						allobjs.addAll(cl_annotlist1);
						allobjs.addAll(classificationList);
						//	return allobjs.toArray();//classificationList.toArray();
					}
				
			}

			else
			{
				//return null;
			}
		}
		
		
		//Newly added on TZ 1.67 for module exception error before updating VC attribute
		System.out.println("going to call Cmodule exception error before updating VC attribute=="+isUpdatable);
		
		if(isUpdatable==true)
		{
		String errMsgStr=null;
		String moderrlist=null;
		boolean x=modulemandatorylist.isEmpty();
		System.out.println("Module's mandatory's valueset :"+modulemandatorylist.size());
		if(modulemandatorylist.size()>0)
		{

			exceptionflg=true;
			errMsgStr= "Module's Mandatory Attribute is not filled,Pls check & update below Module's Attributes by below option then retry to update Technical Specification attribute for VC/CCVC \n";
			errMsgStr=errMsgStr+"File-->New-->Document Management-->Tech Spec-->Update Module Attribute";

			//{

			for(int m1=0;m1<modulemandatorylist.size();m1++)
			{
				System.out.println("required modulemandatorylist  " + modulemandatorylist.get(m1) +"moderrlist="+moderrlist);

				if(m1<=0)
				{
					System.out.println("\ninside moderrlist is null");
					moderrlist=modulemandatorylist.get(m1);
				}
				else
				{
					System.out.println("\ninside moderrlist is not null");
					moderrlist=moderrlist.concat("\t");
					moderrlist=moderrlist.concat(";");
					moderrlist=moderrlist.concat(modulemandatorylist.get(m1));

				}
				System.out.println("moderrlist="+moderrlist);
				

			}
			if(isBypass==true || bypassUsrflg==true)
			{
				System.out.println("Module exception for bypass user \n");
			}
			else
			{
				System.out.println("newly added moderrlist.length() " +moderrlist.length()
				+" moderrlist="+moderrlist); if(moderrlist.length()>0) {
					modulemandatorylist.clear(); errMsgStr=errMsgStr.concat("\n");
					errMsgStr=errMsgStr.concat(moderrlist); // errMsgStr=errMsgStr.concat("\t");
					System.out.println("outside loop errMsgStr " +errMsgStr);
					MessageBox.post(parentShell,errMsgStr,"WARNING",SWT.ICON_WARNING);
					//UpdateTechSpecDialog.this.close(); moderrlist=null;
				}
			}
		}
	}
	
		//End Newly added on TZ 1.67 for module exception error before updating VC attribute
		
		
		return null;
	}

	private boolean isObjectUpdatable() 
	{
		// TODO Auto-generated method stub
		//boolean checkedout=selectedObj.isCheckedOut();
		//TTT
		String userIdS=null;
		isBypass =session.hasBypass();//added
		bypassUsrflg=false;
		TCComponentUser user = session.getUser();
		try {
			userIdS = user.getUserId();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	System.out.println("\nSession User Login Name == " + userIdS + "\n");
    	System.out.println("b4 bypassflg="+bypassUsrflg);
    	bypassUsrflg=new TechSpecUtil().bypassUsrfunc(userIdS,"ByPassUser");
		 System.out.println("bypassflg="+bypassUsrflg);
		 
		if(isBypass==true || bypassUsrflg==true)
		{

			boolean answer=MessageDialog.openQuestion(parentShell,"TechSpec Update Validation", "Do you Want to Bypass TechSpec Update Validation?" );
			if(answer==true)
				return answer;


		}


		/**** Rule for Classification Updation/Edit****/

		//Rule:1 -> For Selected CCV/Vehicle/Module:-> A. If Session User is Checked-out Owner(During Check-in, Classification Dialog will show ) ;[Editable]
		//OR 
		//B. If Part is not Check-out  ,part attached to Task is User-WrkList in Step-Name :Update VC attributes and Tech Spec Header;[Editable]


		//Rule:2 -> For  Selected TechSpec Header:->  A. VC/ vehicle Should be Attached to Tech-Spec (may not be attach/not attach to DML) ;[Not-Editable]
		//AND
		// B. Tech-Spec attached to Task should be in  User Work List in Step-Name :Update VC attributes and Tech Spec Header;[Editable]


		//Rule:3 -> For  Selected Super-SVR:->  A. Super-SVR(VariantRule) attached to Task should be in Reference Item  User Work List in Step-Name :Update VC attributes and Tech Spec Header ;[Editable]


		/*****************END Rule********************/
//newly added for revised vC check
		String RevSeq;
		try {
			RevSeq = selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
			System.out.println("RevSeq:----------  "+RevSeq);
			if(RevSeq.contains("NR")==false)
			{
				System.out.println("b4 ByPassNRChkVCAttrUpd="+bypassUsrflg);
		    	new TechSpecUtil();
				int bypassByPassNRChkVCAttrUpdFlg=TechSpecUtil.getControlObj("ByPassNRChkVCAttrUpd");
				 System.out.println("bypassByPassNRChkVCAttrUpdFlg="+bypassByPassNRChkVCAttrUpdFlg);
				 
				if(bypassByPassNRChkVCAttrUpdFlg>=1 )
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		} catch (TCException | NotLoadedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		TCComponentItemRevision primaryObj=null;
		TCComponent[] allprimaryObj=null;
		if(objType.equals("Design Revision"))
		{
			//Rule :1-A
			boolean is_Checkout=selectedObj.isCheckedOut();	
			System.out.println("in isObjectUpdatableis_Checkout="+is_Checkout);
			if(is_Checkout)
			{
				TCComponent check_user=null;
				try {
					check_user = selectedObj.getTCProperty("checked_out_user").getReferenceValue();
				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				System.out.println("in check_user::->"+check_user.toDisplayString()+":SES:"+ session.getUser());
				if(check_user!=null && session.getUser().equals(check_user))
				{

					System.out.println("in check_user!=null && session.getUser().equals(check_user)::->"+true);
					return true;
				}

			}
			//Rule :1-B
			allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMHasSolutionItem",selectedObj);
			System.out.println("in isObjectUpdatable Primary Object="+primaryObj);
		}
		else if(objType.equals("VariantRule"))
		{
			//Rule 2
			allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMReferences",selectedObj);
		}
		else if(objType.equals("T5_TSCompRevision")) 
		{
			//Rule 3
			try {
				TCComponentItemRevision VCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
				allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMHasSolutionItem",VCObj);
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		try {
			//primaryObj should be in  User Work List in Step-Name :Update VC attributes and Tech Spec Header ;

			if(allprimaryObj!=null)
			{
				for(int h=0;h<allprimaryObj.length;h++)
				{
					primaryObj=(TCComponentItemRevision) allprimaryObj[h];
					System.out.println("if in isObjectUpdatable Primary Object="+primaryObj.toDisplayString());
					String taskID=null;
					System.out.println("in isObjectUpdatable objType="+objType);
					taskID=primaryObj.getTCProperty("item_id").getDisplayableValue();

					//19-05-2021

					try {
						step_wf=TechSpecUtil.getWFStepName(wf_type);
					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (TCException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					if(step_wf==null)
						step_wf="Update VC attribute*";
					System.out.println(wf_type+":"+step_wf);
					//end

					boolean in_wfstep=TechSpecUtil.getwrkflowActivobj(selectedObj.getSession(),taskID,/*"Update VC attribute*"*/step_wf,"4",session.getUserName());
					if(in_wfstep)
					{
						System.out.println("["+h+"]Taking "+taskID+" as WFSTEP::"+in_wfstep);
						return in_wfstep;

					}

					else
					{

						System.out.println("["+h+"]Skipping "+taskID+" as WFSTEP::"+in_wfstep);
					}
					//return	false;
				}
			}
			else 
			{
				System.out.println("else in isObjectUpdatable Primary Object=null");
				return false;
			}
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public static void addAutoCompleteFeature(CCombo combo)
	{
		// Add a key listener
		System.out.println(" inside addAutoCompleteFeature func");
		combo.addKeyListener(new KeyAdapter()
		{
			public void keyReleased(KeyEvent keyEvent)
			{
				CCombo cmb = ((CCombo) keyEvent.getSource());
				setClosestMatch(cmb);
			}

			// Move the highlight back by one character for backspace
			public void keyPressed(KeyEvent keyEvent)
			{
				if (keyEvent.keyCode == SWT.BS)
				{
					CCombo cmb = ((CCombo) keyEvent.getSource());
					Point pt = cmb.getSelection();
					cmb.setSelection(new Point(Math.max(0, pt.x - 1), pt.y));
				}
			}

			private void setClosestMatch(CCombo combo)
			{
				String str = combo.getText();
				String[] cItems = combo.getItems();
				// Find Item in CCombo Items. If full match returns index
				int index = -1;
				for (int i = 0; i < cItems.length; i++)
				{
					if (cItems[i].toLowerCase().startsWith(str.toLowerCase()))
					{
						index = i;
						break;
					}
				}

				if (index != -1)
				{
					Point pt = combo.getSelection();
					combo.select(index);
					combo.setText(cItems[index]);
					combo.setSelection(new Point(pt.x, cItems[index].length()));
				}
				else
				{
					combo.setText("");
				}
			}
		});
	}
	public Point getCenterPoint()
	{
		Shell localShell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		Rectangle localRectangle = localShell.getBounds();
		return new Point(localRectangle.x + localRectangle.width / 2, (localRectangle.y + localRectangle.height) / 2);
	}

	protected
	Point getInitialLocation(Point paramPoint)
	{
		Point localPoint = getCenterPoint();
		return new Point(localPoint.x - paramPoint.x / 2, localPoint.y - paramPoint.y / 2);
	}


	public void populateField()
	{
		System.out.println("2ModuleAddress="+ModuleAddress);
		System.out.println("2InstanceID="+ObjectID);
		try {
			tsdesc.setText(ModuleAddress);
			classificationList=new GetModuleAttributesForClasses(ModuleAddress,session).testgetGetAttributesForClasses();
		} catch (ServiceException | TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			openexception=e;
			this.isSuccess=false;
		}
	}


	protected void fillContextMenu(IMenuManager contextMenu,final IStructuredSelection selection) {
		contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));

		final IWorkbenchWindow  workbenchWindow =  PlatformHelper.getCurrentWorkbenchWindow();

		String opentcid="com.teamcenter.rac.ui.lhn.sendto";
		String viewpropid="com.teamcenter.rac.lhn.properties";

		ICommandService commandService = (ICommandService) workbenchWindow.getService(ICommandService.class);
		Command opentccmd=commandService.getCommand(opentcid);
		Command viewpropcmd=commandService.getCommand(viewpropid);

		ICommandImageService commandImageService = (ICommandImageService) workbenchWindow.getService(ICommandImageService.class);
		ImageDescriptor imgdestc=commandImageService.getImageDescriptor(opentcid);
		ImageDescriptor imgdescprop=commandImageService.getImageDescriptor(viewpropid);




		try {
			contextMenu.add(new Action(opentccmd.getName(),imgdestc) {
				@Override
				public void run() {
					// implement this

					ClassificationTreeLine treeline=(ClassificationTreeLine) selection.getFirstElement();

					new OpenCommand(AIFUtility.getCurrentApplication().getDesktop(),treeline.getItemrev()).executeModeless();
				}
			});
		} catch (NotDefinedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			contextMenu.add(new Action(viewpropcmd.getName(),imgdescprop) {
				@Override
				public void run() {

					// don't do anything here
					ClassificationTreeLine treeline=(ClassificationTreeLine) selection.getFirstElement();

					/* ICommandService commandService = (ICommandService) workbenchWindow.getService(ICommandService.class);
                         Command cmd=commandService.getCommand("com.teamcenter.rac.checkIn");

                        ExecutionEvent eventWithParam = new ExecutionEvent(cmd, 
                                      Collections.singletonMap(ConstantsCOMMAND_PARAM, "true"), null, null);
                         try {
                                     cmd.execute(eventWithParam);
                              } catch (ExecutionException e) {
                                     // TODO Auto-generated catch block
                                     e.printStackTrace();
                              } catch (NotHandledException e) {
                                     // TODO Auto-generated catch block
                                     e.printStackTrace();
                              }

                         IHandlerService handlerService = (IHandlerService) workbenchWindow.getService(IHandlerService.class);
                         try {
                             handlerService.executeCommand("com.teamcenter.rac.checkIn", null);
                             } catch (Exception ex) {
                                 ex.printStackTrace();
                                 // Give message
                                 }*/


					new PropertiesCommand(treeline.getItemrev(),new Frame()).executeModeless();
				}
			});
		} catch (NotDefinedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		setTitle("Update Tech Spec Header ");
		final Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));






		//if(this.fullexpandable==false)
		//{
		try 
		{

			String type=selectedObj.getType();
			if(type.equals("T5_TSCompRevision"))
				this.SelObjType="Tech Spec";
			else if(type.equals("Design Revision"))
				this.SelObjType=selectedObj.getTCProperty("t5_PartType").getDisplayableValue();
			else if(type.equals("VariantRule"))
				this.SelObjType="SVR";

			setTitle("Update "+this.SelObjType+" Technical Specification Dialog ");
		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		//}

		Group grpGeneralInfo = new Group(container, SWT.NONE);
		grpGeneralInfo.setForeground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		grpGeneralInfo.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		grpGeneralInfo.setEnabled(false);
		grpGeneralInfo.setText("General info");
		grpGeneralInfo.setBounds(0, 0, 761, 122);
		grpGeneralInfo.setVisible(this.fullexpandable);

		String ModuleVehicledsc=SelObjType +" Description";
		System.out.println("ModuleVehicledsc="+ModuleVehicledsc);

		Label lblModuleAddress = new Label(grpGeneralInfo, SWT.NONE);
		lblModuleAddress.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		lblModuleAddress.setBounds(30, 51, 135, 15);
		lblModuleAddress.setText(ModuleVehicledsc);//"Tech Spec Description");

		tsdesc = new Text(grpGeneralInfo, SWT.BORDER | SWT.READ_ONLY | SWT.MULTI);
		tsdesc.setBounds(203, 47, 213, 48);

		tsnum = new Text(grpGeneralInfo, SWT.BORDER);
		tsnum.setEditable(false);
		tsnum.setBounds(203, 19, 213, 21);
		//text_2.setText(ModuleNum);


		Label lblModuleNumber = new Label(grpGeneralInfo, SWT.NONE);
		lblModuleNumber.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		lblModuleNumber.setBounds(30, 23, 120, 15);

		//lblModuleNumber.setText("Module Number");

		System.out.println("SelObjType="+SelObjType);
		String ModuleVehicleNum=SelObjType +" Number";
		System.out.println("ModuleVehicleNum="+ModuleVehicleNum);
		lblModuleNumber.setText(ModuleVehicleNum);//"Tech Spec Number");

		Label lblClassifiedInstanceName = new Label(grpGeneralInfo, SWT.NONE);
		lblClassifiedInstanceName.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblClassifiedInstanceName.setBounds(422, 25, 94, 15);
		lblClassifiedInstanceName.setText("Ownning User");

		tsou = new Text(grpGeneralInfo, SWT.BORDER);
		tsou.setBounds(544, 19, 201, 21);
		//text_3.setText(ObjectID);
		tsbu = new Text(grpGeneralInfo, SWT.BORDER | SWT.READ_ONLY);
		tsbu.setBounds(213, 101, 211, 21);
		//text_1.setText(ObjectID);
		//Setting TS value in dialog


		Label lblClassifiedInstanceId = new Label(grpGeneralInfo, SWT.NONE);
		lblClassifiedInstanceId.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblClassifiedInstanceId.setBounds(30, 104, 135, 15);
		lblClassifiedInstanceId.setText("Business Unit");
		//lblModuleNumber.
		final Group grpClassificationPropertiesValues = new Group(container, SWT.NONE);
		/*	
		//if(isUpdatable==false)
				{


					String readonlypath="icons/readonly.png";
					Bundle bundle_bg = FrameworkUtil.getBundle(this.getClass());

					URL readonlyurl = FileLocator.find(bundle_bg,  new Path(readonlypath), null);
					ImageDescriptor imageDescriptor_readonly = ImageDescriptor.createFromURL(readonlyurl);
					Image bgimg=imageDescriptor_readonly.createImage();


					 setbackGroundWaterMark(grpClassificationPropertiesValues,bgimg,bgimg.getImageData().width,bgimg.getImageData().height);


				//	parentShell.setImage(imageDescriptor_readonly.createImage());

				  //     parentShell.setBackgroundMode(SWT.INHERIT_FORCE);  

				}
		 */

		grpClassificationPropertiesValues.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpClassificationPropertiesValues.setText("Classification Properties Values");
		grpClassificationPropertiesValues.setBounds(10, 128, 751, 475);

		searchText = new Text(grpClassificationPropertiesValues, SWT.BORDER);
		searchText.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent ke) {
				System.out.print("kjk:"+searchText.getText());
				searchFilter.setSearchText(searchText.getText());
				treeViewer.refresh();
				treeViewer.expandAll();

			}

		});
		searchText.setBounds(120, 25, 609, 26);

		treeViewer = new TreeViewer(grpClassificationPropertiesValues, SWT.BORDER | SWT.FULL_SELECTION);
		tree = treeViewer.getTree();

		searchFilter=new SearchViewerFilter();
		treeViewer.addFilter(searchFilter);

		tree.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		tree.setLinesVisible(true);
		tree.setHeaderVisible(true);
		tree.setBounds(10, 57, 719, 392);

		TreeViewerColumn treeViewerColumn = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn = treeViewerColumn.getColumn();
		tblclmnNewColumn.setWidth(122);
		tblclmnNewColumn.setText("Classified Objects");

		TreeViewerColumn treeViewerColumn_7 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblcmnType = treeViewerColumn_7.getColumn();
		tblcmnType.setWidth(80);
		tblcmnType.setText("Type");
		//	treeViewerColumn.setEditingSupport(new ClassificationEditingSupport1(treeViewer));

		TreeViewerColumn treeViewerColumn_1 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_1 = treeViewerColumn_1.getColumn();
		tblclmnNewColumn_1.setWidth(100);
		tblclmnNewColumn_1.setText("Attribute ID");

		TreeViewerColumn treeViewerColumn_8 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn trclmnTceAttrId = treeViewerColumn_8.getColumn();
		trclmnTceAttrId.setWidth(100);
		trclmnTceAttrId.setText("TCE Attr ID");
		//treeViewerColumn_1.setEditingSupport(new ClassificationEditingSupport2(treeViewer));

		TreeViewerColumn treeViewerColumn_2 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_2 = treeViewerColumn_2.getColumn();
		tblclmnNewColumn_2.setWidth(100);
		tblclmnNewColumn_2.setText("Attribute Name");
		//treeViewerColumn_2.setEditingSupport(new ClassificationEditingSupport3(treeViewer));

		TreeViewerColumn treeViewerColumn_3 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnAttributeValue = treeViewerColumn_3.getColumn();
		tblclmnAttributeValue.setWidth(100);
		tblclmnAttributeValue.setText("Attribute Value");
		//	treeViewerColumn_3.setEditingSupport(new ClassificationEditingSupport4(treeViewer));

		Group group = new Group(container, SWT.NONE);
		group.setText("General info");
		group.setEnabled(false);
		//group.setBounds(11, 144, 746, 122);
		group.setBounds(0, 0, 745, 122);
		group.setVisible(!this.fullexpandable);

		Label label = new Label(group, SWT.NONE);
		label.setText("Classification Address");
		label.setBounds(30, 35, 135, 15);

		text = new Text(group, SWT.BORDER | SWT.READ_ONLY);
		text.setText("<dynamic>");
		text.setBounds(203, 35, 213, 21);

		text_1 = new Text(group, SWT.BORDER);
		text_1.setText("<dynamic>");
		text_1.setEditable(false);
		text_1.setBounds(203, 8, 213, 21);

		Label label_1 = new Label(group, SWT.NONE);
		label_1.setText("<dynamic> Number");
		label_1.setBounds(31, 14, 120, 15);

		Label label_2 = new Label(group, SWT.NONE);
		label_2.setText("Classification Name");
		label_2.setBounds(30, 65, 123, 15);

		text_2 = new Text(group, SWT.BORDER);
		text_2.setText("<dynamic>");
		text_2.setBounds(203, 62, 213, 21);

		text_3 = new Text(group, SWT.BORDER | SWT.READ_ONLY);
		text_3.setText("<dynamic>");
		text_3.setBounds(205, 89, 211, 21);

		Label label_3 = new Label(group, SWT.NONE);
		label_3.setText("Classified Instance ID");
		label_3.setBounds(30, 92, 135, 15);




		label_1.setText(ModuleVehicleNum);
		System.out.println("1111isUpdatable="+isUpdatable);
		//System.out.println("isUpdatable()="+isObjectUpdatable());
		//treeViewer.setContentProvider(ArrayContentProvider.getInstance());

		treeViewerColumn_3.setEditingSupport(new EditingSupport(treeViewerColumn_3.getViewer()) {

			ArrayList<String> str;

			@Override
			protected void setValue(Object element, Object value) {

				//Added by rajesh on 27/09/2022			

				System.out.println("str="+str); //here str is LOV's value array
				String key2beUpd=null;
				if(element instanceof ClassificationTableLine)
				{
					String id=((ClassificationTableLine) element).getAttrID();
					String val=((ClassificationTableLine) element).getAttrValue();
					String lovid=((ClassificationTableLine) element).getLovID();
					int arraysize=((ClassificationTableLine) element).getArraySize();
					String deptcfg1=((ClassificationTableLine) element).getDepattrcfg();
					String deptval1=((ClassificationTableLine) element).getDepval();
					String depAttrId=((ClassificationTableLine) element).getDepattr();
					System.out.println("id="+id+" 11val="+val +" arraysize="+arraysize +" deptcfg1="+deptcfg1+ " lovid="+lovid +" deptval1="+deptval1 + " depAttrId="+depAttrId);
					String valchg=val+":";
					//keylovList
//Added on 27/07/2023 need to remove after test
//					if(id.contains("240"))
//					{
//						 try {
//							String retstr=TechSpecUtil.getDepEditedHashMapFunc(element, value, depmodifedvalueMap);
//							System.out.println("retstr="+retstr);
//						 } catch (NotLoadedException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						} catch (TCException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
						
						
						 
//					}
//End on 27/07/2023 need to remove after test
					KeyLOVEntry[] keyLOVEntries2=null;
					//KeyLOVDefinition2 lovDef=null;
					int lovvalsize=0;
					KeyValueLOV keyval1=null;
					String actval1=null;
					TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
					ClassificationService clsService = ClassificationService.getService(session);
					KeyValueLOV keylovval=null;
					String[] keyLOVIds = new String[1];
					//KeyLOVEntry keyLOVEntries1 = null;
					keyLOVIds[0] =lovid;
					System.out.println("Calling GetKeyandValueFromLOV ");
					com.teamcenter.services.rac.classification._2009_10.Classification.GetKeyLOVsResponse2 response=null;
					if(lovid.equals("99")==false)
					{
						try {
							response=clsService.getKeyLOVs2( keyLOVIds );

							if ( response.data.sizeOfPartialErrors() > 0)

								throw new ServiceException( "ClassificationService.getKeyLOVs2 returned a partial Error.");
						} catch (ServiceException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						@SuppressWarnings("unchecked")
						Map<String, KeyLOVDefinition2> keyLOVs = response.keyLOVs;
						System.out.println("*****Lov Details******* "+keyLOVs.size());
						Set<String> keys = keyLOVs.keySet();
						ArrayList<String> lovlist=new ArrayList<String>();
						for(Iterator<String> itr = keys.iterator();itr.hasNext();)
						{
							String id1 = itr.next();
							System.out.println("id1= "+id1);
							//KeyLOVDefinition2 lovDef = keyLOVs.get( id1 );
							lovDef = keyLOVs.get( id1 );
							// lovDef1 = keyLOVs.get( id1 );
							ICSKeyLov keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id),deptcfg1);
							keylovval=new KeyValueLOV(keylov.getId(),keylov);
							boolean ishidekey=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id)).isHideKeys();
							System.out.println(" GetKeyandValueFromLOV KeyLOV Id             : "+lovDef.id);
							System.out.println(" GetKeyandValueFromLOV KeyLOV Name           : "+lovDef.name);
							System.out.println(" GetKeyandValueFromLOV KeyLOV Options        : "+lovDef.options);
							System.out.println(" GetKeyandValueFromLOV KeyLOV Owning Site    : "+lovDef.owningSite.getUid());
							System.out.println(" GetKeyandValueFromLOV KeyLOV tag         : "+lovDef.keyLovtag.getUid());
							System.out.println(" GetKeyandValueFromLOV KeyLOV HIDEKEY         : "+ishidekey);
							System.out.println(" GetKeyandValueFromLOV KeyLOV Share Sites : "+lovDef.sharedSites);
							//KeyLOVEntry[] keyLOVEntries =lovDef.keyLovEntries; //hashed on 19/07/2023
							keyLOVEntries =lovDef.keyLovEntries; //added on 19/07/2023
							//keyLOVEntries =lovDef.keyLovEntries;

							System.out.println("GetKeyandValueFromLOV Number of KeyLOV's : "+keyLOVEntries.length);

							
							//lovSize=keyLOVEntries.length;
						
							System.out.println("lovSize="+keyLOVEntries.length +" arraysize="+arraysize +" str="+str +" lovDef.id="+lovDef.id);
							

//							if(arraysize<=1)
//							{
//								if(str.size()>0)
//								{
//								actval1=str.get(Integer.parseInt(value.toString()));
//								System.out.println("actval1::"+actval1);
//								}
//							}
							
							if(str.size()>0)
							{
							//actval1=str.get(Integer.parseInt(value.toString()));
								if (value != null && !value.toString().trim().isEmpty()) {
								    try {
								    	System.out.println("iivalue.toString()="+value.toString()+" str="+str);
								        int index = Integer.parseInt(value.toString().trim());
								        System.out.println("iiiindex="+index);
								        if (str != null && index >= 0 && index < str.size()) {
								            actval1 = str.get(index);
								        }
								    } catch (NumberFormatException e) {
								        // invalid number input – actval1 stays null
								    	System.out.println("NumberFormatException for actval1::"+actval1);
								    	actval1 =null;
								    }
								}
								else
								{
									actval1 =null;
								}
							System.out.println("actval1::"+actval1);
							}
							String prodlineval=null;
							String platformaval=null;
							//String prodlineval=null;
							for(int k=0;k<keyLOVEntries.length;k++)
							{
								//if(lovDef.id.contains("241")) //hashed on 27/07
//								if(id.contains("240"))
//								{
//
//									// prodlineval=initialValMap.get(depprodlineval); //hashed on 27/07
//									//platformaval=initialValMap.get("8241");
//									prodlineval=((ClassificationTableLine) element).getAttrValue(); //newly add 27/07
//									if(prodlineval!=null)
//									{
//										//prodlineval=((ClassificationTableLine) element).getAttrValue(); //newly add 27/07
//										//									prodlineval=initialValMap.get(depprodlineval);
//									}
//									else
//									{
//										prodlineval=initialValMap.get(depprodlineval);
//									}
//									//								 if(prodlineval==null)//newly add 27/07
//									//								 {
//									//									 prodlineval=initialValMap.get(depprodlineval);//newly add 27/07
//									//								 }
//
//								}
								KeyLOVEntry keyLOVEntries1 = lovDef.keyLovEntries[k];
								//KeyLOVEntry[] keyLOVEntries2 = keyLOVEntries1;
								System.out.println("GetKeyandValueFromLOV KeyLOV Entry Key     : "+keyLOVEntries1.lovKey);
								System.out.println("GetKeyandValueFromLOV KeyLOV Entry Value   : "+keyLOVEntries1.lovValue);
								System.out.println("GetKeyandValueFromLOV depmodifedvalueMap : "+depmodifedvalueMap+ " keyLOVEntries1.lovValue.length()="+keyLOVEntries1.lovValue.length() + " prodlineval="+prodlineval);
								System.out.println("prodlineval: "+prodlineval );
								if(keyLOVEntries1.lovValue.length()>0)
								{ 

									//Added on 02/08/2023
									String tmpUpdattr=null;
									String prefx=null;									
									String prevattrid=null;
									String tobekeylov=null;
									String validDepattrid=null;
									String tmpaatrid=null;
									String genattrid=null;
									tmpaatrid=id;
									
									System.out.println("tmpaatrid="+tmpaatrid +" depAttrId="+depAttrId);
									
									if(depAttrId!=null && depAttrId.isEmpty()==false)
									{
										DeptAttrFlg=true;
										System.out.println("validDepattrid="+depAttrId);
										tobekeylov=null;
										tmpUpdattr=id;
										//prefx=tmpUpdattr.substring(0,1);
										//prevattrid=prefx+validDepattrid;
										prevattrid=depAttrId;
										tobekeylov=depmodifedactvalueMap.get(prevattrid);
									}
									
//									System.out.println("tmpaatrid="+tmpaatrid);
//									genattrid=tmpaatrid.substring(1,tmpaatrid.length());
//									System.out.println("genattrid="+genattrid);
//									try {
//										validDepattrid=TechSpecUtil.getDeprattridFunc(genattrid);
//									} catch (NotLoadedException e) {
//										// TODO Auto-generated catch block
//										e.printStackTrace();
//									} catch (TCException e) {
//										// TODO Auto-generated catch block
//										e.printStackTrace();
//									}
//									//validDepattridCpy=validDepattrid;
//									//validDepattrid=TechSpecUtil.getDeprattridFunc(id);
//									System.out.println("11validDepattrid="+validDepattrid);
//									//if(id.contains("241"))
//									if(validDepattrid!=null && validDepattrid.isEmpty()==false)
//									{
//										DeptAttrFlg=true;
//										System.out.println("validDepattrid="+validDepattrid);
//										tobekeylov=null;
//										 tmpUpdattr=id;
//										 prefx=tmpUpdattr.substring(0,1);
//										 prevattrid=prefx+validDepattrid;
//										 tobekeylov=depmodifedactvalueMap.get(prevattrid);
										
										
//									if(id.contains("241"))
//									{
//										tobekeylov=null;
//										 tmpUpdattr=id;
//										 prefx=tmpUpdattr.substring(0,1);
//										 prevattrid=prefx+"240";
//										 tobekeylov=depmodifedactvalueMap.get(prevattrid);
//									}
//									if(id.contains("242"))
//									{
//										tobekeylov=null;
//										 tmpUpdattr=id;
//										 prefx=tmpUpdattr.substring(0,1);
//										 prevattrid=prefx+"241";
//										 tobekeylov=depmodifedactvalueMap.get(prevattrid);
//									}
//									if(id.contains("243"))
//									{
//										tobekeylov=null;
//										 tmpUpdattr=id;
//										 prefx=tmpUpdattr.substring(0,1);
//										 prevattrid=prefx+"242";
//										 tobekeylov=depmodifedactvalueMap.get(prevattrid);
//									}
									
//								}
									System.out.println("id="+id+"prefx="+prefx +" prevattrid="+prevattrid +" tobekeylov="+tobekeylov +" actval1="+actval1);
									
									if(tobekeylov==null)
									{
										if(actval1!=null)
										{
											if(actval1.equals(keyLOVEntries1.lovValue))
											{
												key2beUpd=keyLOVEntries1.lovKey;
												System.out.println(" 221tobekeylov="+tobekeylov +" 221key2beUpd"+key2beUpd);
												//depmodifedactvalueMap.put(UpdAttrId,tobekeylov); //added on 02/08/2023
												//key2beUpd=tobekeylov; //added on 02/08/2023
												break;
											}
										}
									}
									else
									{
										//if(SelBusUnit.contains("CAR") || SelBusUnit.contains("MUV"))
										if(depattrcntrlobjsize >0)
										{
											System.out.println("inside CAR/MUV VC condition for dependent LOV with actval1"+actval1);
											if(actval1!=null)
											{
											if(actval1.equals(keyLOVEntries1.lovValue))
											{
												if(keyLOVEntries1.lovKey.contains(tobekeylov))
												{
													key2beUpd=keyLOVEntries1.lovKey;
													System.out.println(" 223tobekeylov="+tobekeylov +" 223key2beUpd"+key2beUpd);
													//depmodifedactvalueMap.put(UpdAttrId,tobekeylov); //added on 02/08/2023
													//added on 02/08/2023
													break;
												}
											}
											}
										}
										else
										{
											System.out.println("inside CVBU VC condition for dependent LOV with actval1"+actval1);
											if(actval1.equals(keyLOVEntries1.lovValue))
											{
												//if(keyLOVEntries1.lovKey.contains(tobekeylov))
												//{
												key2beUpd=keyLOVEntries1.lovKey;
												System.out.println(" 223tobekeylov="+tobekeylov +" 223key2beUpd"+key2beUpd);
												//depmodifedactvalueMap.put(UpdAttrId,tobekeylov); //added on 02/08/2023
												//added on 02/08/2023
												break;
												//}
											}
										}
									}
									System.out.println(" 22tobekeylov="+tobekeylov +" 22key2beUpd"+key2beUpd);
									/*
									if(prodlineval!=null ) //here prodlineval would be vehiclass class name like platform X4,X2 etc
									{
										System.out.println("inside prodlineval="+prodlineval);
										if(keyLOVEntries1.lovKey.contains(prodlineval)) 
										{								
											if(actval1!=null)
											{
												if(actval1.equals(keyLOVEntries1.lovValue))
												{
													key2beUpd=keyLOVEntries1.lovKey;
													break;
												}
											}
										}
										else
										{
											System.out.println("prodlineval : "+prodlineval +" not matched with LOV value ");
										}
									}
									else
									{
										System.out.println("Outside dependent value cond. keyLOVEntries1.lovValue="+keyLOVEntries1.lovValue +" keyLOVEntries1.lovKey="+keyLOVEntries1.lovKey);
										if(actval1!=null) 
										{
											if(actval1.equals(keyLOVEntries1.lovValue))
											{
												key2beUpd=keyLOVEntries1.lovKey;
												break;
											}
										}
									}
*/

								}
							}


						}

					}
					//End by Rajesh on 27/09/2022

					//String valchg=val+":";


					int i;
					String b4Val="0";
					for( i=0;i<str.size();i++)
					{

						//System.out.println(str.get(i)+":xdxddfdr::"+i);
						if(val.equals(str.get(i)))
						{
							System.out.println(str.get(i)+":xdxddfdr::"+i);
							b4Val=i+"";
							break;
						}


					}

					System.out.println("Before val::"+b4Val +" val="+val);
					System.out.println("value.toString()"+value.toString() + "val.toString()="+val.toString());
/*					try
					{
						if(arraysize<=1 && lovid.equals("99")==false)
						{
							if(Integer.parseInt(value.toString())<0)
							//if(Integer.parseInt(val.toString())<0)
							{
								value=b4Val;
								System.out.println("Input value does not exist in LOV, so choose value from LOV only");

								MessageBox.post(parentShell,"Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);

								// MessageBox msgbox = new MessageBox(parentShell, SWT.ICON_INFORMATION);
				             //  msgbox.setText("Information.");
				            //   msgbox.setMessage("Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator ");
				            //   msgbox.open();           
							}     

						}
						else
						{
							System.out.println("skip for non LOV String value ");
						}
					} 
					catch(NumberFormatException e) 
					{ 
						e.printStackTrace();
					}

*/					if(Integer.parseInt(lovid)<0)
					{
						System.out.println("key2beUpd ="+key2beUpd +" str.size()="+str.size());
						
							if(arraysize<=1 && str.size()>0)
							{
								String actval=str.get(Integer.parseInt(value.toString()));
								System.out.println("key2beUpd ="+key2beUpd +" str.size()="+str.size()+" actval="+actval +" actval1="+actval1);
								valchg+=":"+actval;		
								//((ClassificationTableLine) element).setAttrValue(str.get(Integer.parseInt(value.toString()))); //unhashed on 31/07
								((ClassificationTableLine) element).setAttrValue(actval); //hashed on 31/07
								//((ClassificationTableLine) element).setAttrValue(key2beUpd);
								KeyValueLOV keylov= keylovList.get(((ClassificationTableLine) element).getLovID());
								//System.out.println(i+":"+keylov.getValue().get(i)+"GGGGGGKKK:"+keylov.getKey().get(i));
								System.out.println("keylov.getKey().get(Integer.parseInt(value.toString()=="+keylov.getKey().get(Integer.parseInt(value.toString())));
								//if(id.contains("240") || id.contains("241") || id.contains("242") || id.contains("243"))
								System.out.println(" b4 setChangeValue DeptAttrFlg="+DeptAttrFlg);
								if(DeptAttrFlg==true && depAttrId.length()>0)
								{
								((ClassificationTableLine) element).setChangeValue(keylov.getKey().get(Integer.parseInt(value.toString())));
								key2beUpd=keylov.getKey().get(Integer.parseInt(value.toString()));
								}
								else
								{
									((ClassificationTableLine) element).setChangeValue(key2beUpd);
								}
								//((ClassificationTableLine) element).setChangeValue(key2beUpd);

								System.out.println("b4 set modifedvalueMap attrid="+((ClassificationTableLine) element).getAttrID() +" modifedvalueMap change value="+ ((ClassificationTableLine) element).getChangeValue() +" new value="+((ClassificationTableLine) element).getAttrValue());

								modifedvalueMap.put(((ClassificationTableLine) element).getAttrID(),((ClassificationTableLine) element).getChangeValue());
							}
						

						/*else if(arraysize>1)
					{

						System.out.println("PPPPPPPPPPP1111value.toString()"+value.toString());

						((ClassificationTableLine) element).setAttrValue(value.toString());
						valchg+=":"+value;
					}*/
					}
					else
					{
						((ClassificationTableLine) element).setAttrValue(value.toString());
						valchg+=":"+value;
					}


					System.out.println("b4 set modifedvalueMap id="+id +" modifedvalueMap change value="+valchg);
					//	((MyModel) element).setAttributevalue("jkjhvghvgh");//value.toString());
					
					//Newly added on 28/07 start
					System.out.println("value.toString()"+value.toString() + "val.toString()="+val.toString());
					try
					{
						if(arraysize<=1 && lovid.equals("99")==false)
						{
							if(Integer.parseInt(value.toString())<0)
							//if(Integer.parseInt(val.toString())<0)
							{
								value=b4Val;
								System.out.println("Input value does not exist in LOV, so choose value from LOV only");

								MessageBox.post(parentShell,"Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);

								/* MessageBox msgbox = new MessageBox(parentShell, SWT.ICON_INFORMATION);
				               msgbox.setText("Information.");
				               msgbox.setMessage("Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator ");
				               msgbox.open();    */         
							}     

						}
						else
						{
							System.out.println("skip for non LOV String value ");
						}
					} 
					catch(NumberFormatException e) 
					{ 
						e.printStackTrace();
					}

					//Newly added on 28/07 end
					
					modifedactvalueMap.put(id,valchg);

					System.out.println(((ClassificationTableLine) element).toString());
					getViewer().update(element, null);
					
					
					//Added newly to restrict cmvrno value update by designer
					
					String Updval=((ClassificationTableLine) element).getAttrValue();
					String UpdAttrId=((ClassificationTableLine) element).getAttrID();
					//String UpdvalKey=((ClassificationTableLine) element).
					System.out.println("UpdAttrId="+UpdAttrId +" Updval="+Updval +" key2beUpd="+key2beUpd +"cmvrno="+cmvrno +"attrid="+attrid +"attrval="+attrval);
					if(UpdAttrId!=null && Updval!=null)
					{
					//depmodifedactvalueMap.put(UpdAttrId,Updval);
//						if(key2beUpd!=null)
//						{
//						depmodifedactvalueMap.put(UpdAttrId,key2beUpd);
//						}
//						else
						
						
//						{
						
//						if(UpdAttrId.contains("240"))
//						{
//							System.out.println("b4 clearing depmodifedactvalueMap for lov selection for 240 click");
//							depmodifedactvalueMap.clear();
//						}
						//if(UpdAttrId.contains("240") || UpdAttrId.contains("241") || UpdAttrId.contains("242") || UpdAttrId.contains("243"))
						System.out.println(" b4 remove depmodifedactvalueMap DeptAttrFlg="+DeptAttrFlg);
						//if(validDepattridCpy!=null && validDepattridCpy.isEmpty()==false)
						if(DeptAttrFlg==true)
						{
							System.out.println("b4 clearing depmodifedactvalueMap for lov selection for 240/241/242/243 click");
							depmodifedactvalueMap.remove(UpdAttrId);
							System.out.println("after depmodifedactvalueMap.remove call depmodifedactvalueMap for lov selection for 240/241/242/243 click"+depmodifedactvalueMap);

//							for(int k1=0;k1<keyLOVEntries.length;k1++)
//							{
//								KeyLOVEntry keyLOVEntries11 = lovDef.keyLovEntries[k1];
//
//								System.out.println("2GetKeyandValueFromLOV KeyLOV Entry Key     : "+keyLOVEntries11.lovKey);
//								System.out.println("2GetKeyandValueFromLOV KeyLOV Entry Value   : "+keyLOVEntries11.lovValue);
//								System.out.println("2b4 put depmodifedactvalueMap   : "+depmodifedactvalueMap +" Updval="+Updval);
//								if(keyLOVEntries11.lovValue.contains(Updval))
//								{
//								
//									
//									//End added on 02/08/2023
//									System.out.println("adding key for depmodifedactvalueMap keyLOVEntries11.lovKey="+keyLOVEntries11.lovKey );
//
//									//depmodifedactvalueMap.put(UpdAttrId,keyLOVEntries11.lovKey); //hashed on 02/08/2023
//									//key2beUpd=keyLOVEntries11.lovKey;//hashed on 02/08/2023
//									//depmodifedactvalueMap.put(UpdAttrId,tobekeylov); //added on 02/08/2023
//									//key2beUpd=tobekeylov; //added on 02/08/2023
//									//break;
//									depmodifedactvalueMap.put(UpdAttrId,key2beUpd);
//								}
//							}
							System.out.println("222 UpdAttrId="+UpdAttrId + "222 key2beUpd="+key2beUpd +"222 Updval="+Updval);
							depmodifedactvalueMap.put(UpdAttrId,key2beUpd);
//							if(UpdAttrId.contains("240"))
//							{
//								depmodifedactvalueMap.put(UpdAttrId,Updval);
//							}
//							else
//							{
//								depmodifedactvalueMap.put(UpdAttrId,key2beUpd);
//							}
							
						}
//						}
					}
					System.out.println("2323depmodifedactvalueMap="+depmodifedactvalueMap +"cmvrno="+cmvrno);
					if(UpdAttrId.contains("171"))
					{
						if(Updval.isEmpty())
						{
							MessageBox.post(parentShell,"CMVR Value for 171 attribute can be only allow to update NA via this option if CMVR Value is NULL in this stage, so choose NA value from LOV only or Contact PLM Support Team","WARNING",SWT.ICON_WARNING);
							return;
						}
						if(cmvrno!=null)
						{
							if( Updval.contains(cmvrno))
							{
								System.out.println("Allow to update valid CMVR No !!");
								
							}
							//added on 10/06/2024
							else if(Updval.contains("NA") && cmvrno.contains("NA"))
							{
								System.out.println("Allow to update NA as CMVR not linked with VC !!");
							}
							else
							{
								//MessageBox.post(parentShell,"CMVR Value for 171 attribute can be only allow to update NA via this option, if CMVR Value is NULL in this stage, so choose NA value from LOV only or Contact PLM Support Team","WARNING",SWT.ICON_WARNING);
								//return;
								
								Updval=cmvrno;
								System.out.println("going to update actual CMVR no as per VC linked "+cmvrno);
							}
						}						
						else if(Updval.contains("NA") && (cmvrno==null || cmvrno.isEmpty()))
						{
							System.out.println("VC and CMVR linked not been created for this VC, therefore Allow to update NA in such case");
						}
						
						else
						{
							MessageBox.post(parentShell,"CMVR Value for 171 attribute can be only allow to update NA via this option, if CMVR Value is NULL in this stage, so choose NA value from LOV only or Contact PLM Support Team","WARNING",SWT.ICON_WARNING);
							return;
						}
					}
					
					// End newly to restrict cmvrno value update by designer

				}


			}

			@Override
			protected Object getValue(Object element) {
				// We need to calculate back to the index
				if(element instanceof ClassificationTableLine)
				{
					String val=((ClassificationTableLine) element).getAttrValue();
					String lovid=((ClassificationTableLine) element).getLovID();
					int arraysize=((ClassificationTableLine) element).getArraySize();
					if(Integer.parseInt(lovid)<0 && arraysize<=1)
					{
						int i;	

						/*
						 * for( i=0;i<str.size();i++) {
						 * 
						 * System.out.println(str.get(i)+":gfxfsdfsIDX::"+i); }
						 */


						System.out.println("getValue str.indexOf(val)="+str.indexOf(val)+" str.size()="+str.size());

						boolean match=false;
						for( i=0;i<str.size();i++)
						{

							if(str.get(i).equals(val))
							{
								match=true;
								break;
							}
						}
						if(match==false)
						{
							i=0;
						}
						System.out.println("in getValue val="+val+":IDX::"+i);
						//KeyValueLOV keylov= keylovList.get(((ClassificationTableLine) element).getLovID());
						//((ClassificationTableLine) element).setLovKeyValue(keylov.getKey().get(i));
						return Integer.valueOf(i);
					}


					return val;
				}

				return element;
			}

			@Override
			protected CellEditor getCellEditor(final Object element) {
				if(element instanceof ClassificationTableLine)
				{
					str=new ArrayList<String>();
					String classid=((ClassificationTableLine) element).getParent().getParent().getModuleAddress();
					String attrid=((ClassificationTableLine) element).getAttrID();
					String val=((ClassificationTableLine) element).getAttrValue();
					String lovid=((ClassificationTableLine) element).getLovID();
					int arraysize=((ClassificationTableLine) element).getArraySize();
					String deptattr=((ClassificationTableLine) element).getDepattr();
					String deptcfg=((ClassificationTableLine) element).getDepattrcfg();
					String deptval2=((ClassificationTableLine) element).getDepval();
					String deptval=modifedvalueMap.get(deptattr);
					
					if(deptval==null)
					{
						deptval=((ClassificationTableLine) element).getDepval();
					}
					ClassificationTableLine tabline=((ClassificationTableLine) element);
					//((ClassificationTableLine) element).getAnnotation()
					if(deptval==null)
						//deptval=initialValMap.get(deptattr);
						deptval=depmodifedvalueMap.get(deptattr);
					 System.out.println("before call testGetKeyLOVs2 func lovid="+lovid +"deptattr="+deptattr +" deptval="+deptval +" deptval2="+deptval2);
					 String prodline=tabline.getParent().getAnnotation();
					//prodlineattrval=initialValMap.get("8240");
					// String tmpdepprodlineval=depprodlineval;
					// String fstchar=tmpdepprodlineval.substring(0, 1);
					// String tmpattrid=fstchar+"241";
					// System.out.println("depprodlineval="+depprodlineval );
					 //String platformattrval=initialValMap.get("8241");
					 //String platformattrval=initialValMap.get(tmpattrid);
					// String platform=tabline.getParent().getParent().getObjectid_moduleAddress();
					// String platform1=tabline.getParent().getParent().getAttrList().get(8240).getAnnotation().toString().valueOf("8240");
					 System.out.println("before call testGetKeyLOVs2 func prodline="+prodline +" tabline="+tabline +" ((ClassificationTableLine) element).getAnnotation()="+((ClassificationTableLine) element).getAnnotation() +" prodlineattrval="+prodlineattrval );
					// if(deptattr.contains("240") || deptattr.contains("241") || deptattr.contains("242") || deptattr.contains("243") )
						System.out.println(" b4 remove depmodifedvalueMap DeptAttrFlg="+DeptAttrFlg);
						if(DeptAttrFlg==true)
						{
							if(deptval==null || deptval.length()<=0)
							{
								System.out.println("inside null deptval="+deptval);
								 deptval=tabline.getAttrValue();
							}
							System.out.println("after get deptval="+deptval);
							if(prodlineattrval!=null && deptval!=null)
							{	
								if(deptval.contains(prodlineattrval))
								{
									depmodifedvalueMap.put(deptattr,deptval);
								}
							}
						}
					 
						//start added on 28/07
						System.out.println("before set classification value "+((ClassificationTableLine) element).toString());
						String depattridnew=((ClassificationTableLine) element).getDepattr();
						String depvalnew=null;
						if(depattridnew!=null)
						{
						 depvalnew=depmodifedactvalueMap.get(depattridnew);
							//depvalnew=depmodifedactvalueMap.get("6240");
						}
						
						System.out.println("depattridnew="+depattridnew +" depvalnew="+depvalnew);
//						if(depvalnew!=null )
//						{
						//	((ClassificationTableLine) element).setDepval(depvalnew);
//							Object element2=null;
//							if(element2 instanceof ClassificationTableLine)
//							{
//
//								String id2=((ClassificationTableLine) element2).getAttrID();
//								String val1=((ClassificationTableLine) element2).getAttrValue();
//								String lovid2=((ClassificationTableLine) element2).getLovID();
//								int arraysize2=((ClassificationTableLine) element2).getArraySize();
//								String deptcfg2=((ClassificationTableLine) element2).getDepattrcfg();
//								String deptval3=((ClassificationTableLine) element2).getDepval();
//								
//								System.out.println("inside dependent attribute condition id2 : "+id2 +" val1="+val1 +" lovid2="+lovid2 +" arraysize2="+arraysize2 +" deptcfg2="+deptcfg2 +" deptval3="+deptval3);
//								
//								if(id2.contains(depattridnew))
//								{
//									((ClassificationTableLine) element2).setDepval(val1);
//								}
//							}
//						}
						
						//String newdepval=((ClassificationTableLine) element).getAttrValue();
						
						System.out.println("aftr dependent value set depvalnew="+depvalnew);
						//End changes on 28/07
					 
					 System.out.println("before call testGetKeyLOVs2 func depmodifedvalueMap="+depmodifedvalueMap);
					if(Integer.parseInt(lovid)<0 )
					{
						try {
							//str=new GetKeyLOVs2Sample().testGetKeyLOVs2(lovid);
							System.out.println("2222deptval="+depvalnew +" deptattr="+deptattr+" tmpdepmodifedvalueMap="+tmpdepmodifedvalueMap);
//							if(deptval==null || deptval.isEmpty()||deptval.contains(""))
//							{
//								deptval=tmpdepmodifedvalueMap.get(deptattr);
//							}
							System.out.println("3333deptval="+depvalnew +" tmpdepmodifedvalueMap="+tmpdepmodifedvalueMap);
							//final KeyValueLOV keyvallov=	new GetKeyLOVs2Sample().testGetKeyLOVs2(classid,attrid,lovid,deptattr,deptcfg,deptval); //hasded on 28/07
							final KeyValueLOV keyvallov=	new GetKeyLOVs2Sample().testGetKeyLOVs2(classid,attrid,lovid,deptattr,deptcfg,depvalnew,arraysize); //newly added on 28/07
							keylovList.put(lovid, keyvallov);
							str=keyvallov.getValue();

							if(arraysize<=1 && str!=null)
							{


								ComboBoxCellEditor cmbboxeditor=new ComboBoxCellEditor(
										treeViewer.getTree(), str.toArray(new String[str.size()]));

								final CCombo cmb=(CCombo) cmbboxeditor.getControl();

								cmb.addSelectionListener(new SelectionListener(){

									@Override
									public void widgetSelected(SelectionEvent e) {
										// TODO Auto-generated method stub.
										CCombo cmb1=(CCombo)e.widget;

										((ClassificationTableLine) element).setChangeValue(keyvallov.getKey().get(cmb1.getSelectionIndex()));

									}

									@Override
									public void widgetDefaultSelected(SelectionEvent e) {
										// TODO Auto-generated method stub

									}

								});

								/*	
                		cmbboxeditor.addListener(new ICellEditorListener(){
						    public void applyEditorValue(){
						        Object selection=((IStructuredSelection)treeViewer.getSelection()).getFirstElement();
						        if (selection instanceof ClassificationTableLine) {
						        	ClassificationTableLine ctab=(ClassificationTableLine)selection;

						        }
						    }

							@Override
							public void cancelEditor() {
								// TODO Auto-generated method stub

							}

							@Override
							public void editorValueChanged(
									boolean oldValidState, boolean newValidState) {
								// TODO Auto-generated method stub

							}
                		}

			);*/
								return new ComboBoxCellEditor(
										treeViewer.getTree(), str.toArray(new String[str.size()]),SWT.READ_ONLY);
								//treeViewer.getTree(), str.toArray(new String[str.size()]),SWT.SEARCH);
							} 

							else
							{
								System.out.println("GGG::"+element);
								MultiValueTextCellEditor tce = new MultiValueTextCellEditor(treeViewer.getTree(),treeViewer,keyvallov,element,0) {
									@Override
									public String[] getProposal(String currentText) {

										
										return str.toArray(new String[str.size()]);
										
									}
								};
								//tce.getMultiCombo().setTableLine(element);
								//tbv.setCellEditors(new CellEditor[] { tce });
								return tce;//new MultiValueTextCellEditor(treeViewer.getTree());
							}
						}
						catch (ServiceException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

					TextCellEditor txtcell=new TextCellEditor(treeViewer.getTree());
					Text celltxt=((Text)txtcell.getControl());
					celltxt.addModifyListener(new ModifyListener(){



						@Override
						public void modifyText(ModifyEvent e) {
							// TODO Auto-generated method stub
							Text celtxt=(Text) e.widget;
							ClassificationTableLine clselement=((ClassificationTableLine) element);
							clselement.setChangeValue(celtxt.getText());

							System.out.println("MODDDDDDD:"+clselement.getAttrValue()+":>"+clselement.getChangeValue());

						}

					});


					return txtcell;//new TextCellEditor(treeViewer.getTree());

				}

				else
				{
					TextCellEditor txtcell=new TextCellEditor(treeViewer.getTree());
					Text celltxt=((Text)txtcell.getControl());
					celltxt.addModifyListener(new ModifyListener(){



						@Override
						public void modifyText(ModifyEvent e) {
							// TODO Auto-generated method stub

							ClassificationTableLine clselement=((ClassificationTableLine) element);
							clselement.setChangeValue(clselement.getAttrValue());

						}

					});
					return txtcell;// new TextCellEditor(treeViewer.getTree());

				}


			}


			@Override
			protected boolean canEdit(Object element) {
				System.out.println("in CanEdit isUpdatable="+isUpdatable);
				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine tabline=((ClassificationTableLine) element);
					if(UpdateTechSpecDialog.this.fullexpandable)
					{
						try {
							String parttype=tabline.getParent().getParent().getItemrev().getTCProperty("t5_PartType").getDisplayableValue();
							if(parttype.equals("Module"))
							{
								return false;
							}

						} catch (TCException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

					boolean isprotected=tabline.isProtected();

					String attrname=tabline.getAttrName();
					String attrval=tabline.getAttrValue();
					System.out.println("attrname="+attrname+ "in CanEdit isprotected="+isprotected);
					if(attrval!=null && attrval.length()!=0)
					{
						if(isprotected)
						{
							return !isprotected;
						}
					}

					/*if(tabline.getArraySize()>0)
						return true;*/
					return isUpdatable;
				}
				return isUpdatable;
			}
		});

		/*CellEditor[] editors = new CellEditor[4];
	    editors[0] = new TextCellEditor(tree);
	    editors[1] = new TextCellEditor(tree);
	    editors[2] = new TextCellEditor(tree);
	    editors[3] = new ComboBoxCellEditor(tree);*/


		//lblModuleNumber.setText("lmnkmnk");


		if(icoval!=null)

		{
			ModuleAddress=icoval.getCid();
			ObjectID=icoval.getIcoId();
			tsdesc.setText(ModuleAddress);
			tsbu.setText(ObjectID);
			clsobjs=icoval.getClsobjs();


			System.out.println("icoval!=null clsobjs="+clsobjs);

		}


		Label lblVcSubClass = new Label(grpGeneralInfo, SWT.NONE);
		lblVcSubClass.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblVcSubClass.setBounds(422, 50, 87, 21);
		lblVcSubClass.setText("VC Sub Class");

		tsvsc = new Text(grpGeneralInfo, SWT.BORDER);
		tsvsc.setText("<dynamic>");
		tsvsc.setBounds(544, 47, 201, 21);

		Label lblNewLabel = new Label(grpGeneralInfo, SWT.NONE);
		lblNewLabel.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblNewLabel.setBounds(422, 74, 108, 21);
		lblNewLabel.setText("Owner Design Unit");

		tsodu = new Text(grpGeneralInfo, SWT.BORDER);
		tsodu.setBounds(544, 74, 201, 21);

		Label lblOwnerDesign = new Label(grpGeneralInfo, SWT.NONE);
		lblOwnerDesign.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblOwnerDesign.setBounds(422, 104, 108, 18);
		lblOwnerDesign.setText("Owner Design Dept");

		tsodd = new Text(grpGeneralInfo, SWT.BORDER);
		tsodd.setBounds(544, 101, 201, 21);



		/**************MENU used to send the object into My Teamcenter from custom dialog*********/

		MenuManager menuMgr = new MenuManager();
		menuMgr.setRemoveAllWhenShown(true);

		menuMgr.addMenuListener(new IMenuListener() {
			@Override
			public void menuAboutToShow(IMenuManager menuManager) {
				IStructuredSelection selection = (IStructuredSelection) treeViewer.getSelection();
				if(selection.getFirstElement() instanceof ClassificationTreeLine)
					fillContextMenu(menuManager,selection);

			}


		});



		Menu menu = menuMgr.createContextMenu(treeViewer.getControl());

		treeViewer.getControl().setMenu(menu);
		/**************END MENU*********************/


		//populateField();
		System.out.println("Calling populateTable func");

		if(icoval!=null)
		{

			Map<BigInteger,AttributeValues> map2=icoval.getAttrValuesMap();
			for( Object key2 : map2.keySet())
			{
				System.out.println("keyw.get(key2)="+key2.getClass());

				System.out.println("kssl="+map2.get(key2).getClass());
				AttributeValues fv=map2.get(key2);
				for(int f=0;f<classificationList.size();f++)
				{
					ClassificationTableLine tabline=classificationList.get(f);

					if(tabline.getAttrID().equals(key2.toString()))

					{


						Value[] vals=  fv.values;
						String allvalue="";
						System.out.println("VVVkey2::"+key2+" Val:"+vals.length);	
						for(int x1=0;x1<vals.length;x1++)
						{
							//System.out.println("key2"+key2+" Val:"+vals[x1].attrValue);		      
							allvalue+=vals[x1].attrValue;

							if(x1<vals.length-1)
								allvalue+=PreferenceValue.getARRAY_DELMITER();

						}

						if(allvalue.length()>0 && tabline!=null)
						{
							tabline.setAttrValue(allvalue);
							System.out.println("allvalue::"+allvalue);
						}
					}
				}
			}
		}



		TreeViewerColumn treeViewerColumn_4 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_3 = treeViewerColumn_4.getColumn();
		tblclmnNewColumn_3.setWidth(78);
		tblclmnNewColumn_3.setText("Unit");

		TreeViewerColumn treeViewerColumn_5 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_4 = treeViewerColumn_5.getColumn();
		tblclmnNewColumn_4.setWidth(67);
		tblclmnNewColumn_4.setText("LovID");

		TreeViewerColumn treeViewerColumn_6 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_5 = treeViewerColumn_6.getColumn();
		tblclmnNewColumn_5.setWidth(63);
		tblclmnNewColumn_5.setText("Array");



		treeViewerColumn.setLabelProvider(new ColumnLabelProvider() {



			public Image getImage(Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					TCComponentItemRevision tcobj=p.getItemrev();
					String classicon=null;
					try {
						String objecttype=tcobj.getPropertyDisplayableValue("t5_PartType");
						//System.out.println("objecttype="+objecttype);
						if(objecttype.matches("Vehicle"))
						{
							classicon="icons/tmlpart_16.png";
						}
						else if (objecttype.matches("Module"))
						{
							classicon="icons/moduleIcon.png";
						}


					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


					/*Bundle bundle = FrameworkUtil.getBundle(this.getClass());
		    		// use the org.eclipse.core.runtime.Path as import
		    		System.out.println("classicon="+classicon);
		    		URL url = FileLocator.find(bundle,
		    		    new Path(classicon), null);
		    		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);*/

					return TCTypeRenderer.getImage(tcobj); //imageDescriptor.createImage();
					//return TCTypeRenderer.getTypeImage(tcobj.getType(), null); //imageDescriptor.createImage();
					//return imageDescriptor.createImage();
				}
				return null;
			}

			public String getText(Object element) {

				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return p.getClassifiedObject();
				}
				return null;
			}

			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}

		});
		treeViewerColumn_1.setLabelProvider(new ColumnLabelProvider() {
			public Image getImage(Object element) {
				if(element instanceof ClassificationTableLine) 
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					Bundle bundle = FrameworkUtil.getBundle(this.getClass());
					// use the org.eclipse.core.runtime.Path as import
					String path="icons/AttrIcon16x16.png";;
					if(p.isIsmandatory())
						path="icons/AttrReqIcon16x16.png";

					URL url = FileLocator.find(bundle,
							new Path(path), null);
					ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
					return imageDescriptor.createImage();
					//return null;
				}
				return null;
			}

			public String getText(Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return p.getModuleAddress();
				}
				else if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getAttrID();
				}
				else
				{
					return null;
				}
			}
			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});

		treeViewerColumn_2.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return p.getClassificationName();
				}
				else if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getAttrName();
				}
				return null;
			}
			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});


		treeViewerColumn_3.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {
				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getAttrValue();
				}
				return null;
			}
			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});

		treeViewerColumn_4.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getUnit();
				}
				return null;
			}
			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});

		treeViewerColumn_5.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getLovID();
				}
				return null;
			}
		});


		treeViewerColumn_6.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getArraySize()+"";
				}
				return null;
			}
		});


		treeViewerColumn_7.setLabelProvider(new ColumnLabelProvider() {

			public Image getImage(Object element) {
				if(element instanceof ClassificationAnnotationLine) 
				{
					ClassificationAnnotationLine p = (ClassificationAnnotationLine) element;
					Bundle bundle = FrameworkUtil.getBundle(this.getClass());
					String mname=p.getAnnotation();
					String iconmodule="MISC";
					if(mname!=null && mname.contains("[") && mname.contains("]"))
					{
						String temp_iconmodule=mname.substring(mname.indexOf("[")+1, mname.indexOf("]"));
						//System.out.println("SSS::"+temp_iconmodule);
						if(temp_iconmodule!=null)
							iconmodule=temp_iconmodule;

					}
					String iconname=iconmodule+".PNG";
					// use the org.eclipse.core.runtime.Path as import
					String path="icons/"+iconname;

					//System.out.println("UpdateTechSpecDlg Event Thread status ="+SwingUtilities.isEventDispatchThread());
					URL url = FileLocator.find(bundle,
							new Path(path), null);
					ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
					return imageDescriptor.createImage();
					//return null;
				}
				return null;
			}

			public String getText(Object element) {

				if(element instanceof ClassificationAnnotationLine)
				{
					ClassificationAnnotationLine p = (ClassificationAnnotationLine) element;
					return p.getAnnotation();
				}
				return null;
			}
		});

		treeViewerColumn_8.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getTcentattrID();
				}
				return null;
			}
		});

		Button btnErase = new Button(grpClassificationPropertiesValues, SWT.NONE);
		btnErase.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				clearFilter();

			}
		});
		btnErase.setBounds(10, 23, 47, 30);

		Bundle bundle = FrameworkUtil.getBundle(this.getClass());

		// use the org.eclipse.core.runtime.Path as import
		String path="icons/eraser.PNG";


		URL url = FileLocator.find(bundle,
				new Path(path), null);
		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);


		btnErase.setImage(imageDescriptor.createImage());

		Button btnSearch = new Button(grpClassificationPropertiesValues, SWT.NONE);
		btnSearch.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				System.out.print("kjk:"+searchText.getText());
				searchFilter.setSearchText(searchText.getText());
				treeViewer.refresh();
			}
		});
		btnSearch.setBounds(63, 23, 51, 30);

		// use the org.eclipse.core.runtime.Path as import
		path="icons/search.jpg";


		url = FileLocator.find(bundle,new Path(path), null);
		imageDescriptor = ImageDescriptor.createFromURL(url);				
		btnSearch.setImage(imageDescriptor.createImage());	

		treeViewer.setContentProvider(new TreeContentProvider());//new TableContentProvider());
		//treeViewer.setLabelProvider(new TableLabelProvider(treeViewer));
		try {
			ArrayList<ClassificationTreeLine> inputtree =new ArrayList<ClassificationTreeLine>();

			String parttype=ItemRev.getTCProperty("t5_PartType").getDisplayableValue();
			System.out.print("b4 bomexpansion for UpdateTechSpec parttype="+parttype);
			if(parttype.equals("Vehicle") || parttype.equals("Configurable VC") || parttype.equals("Vehicle Combination CR"))
			{
				inputtree=bomexpansion.getTCUAStructureSnapshot(session, ItemRev,this.fullexpandable,SelBusUnit,Hybridstatus);
				System.out.print("after snapshot bomexpansion inputtree size="+inputtree.size());
				if(inputtree.size()<=1)
				{
					inputtree=bomexpansion.getTCUAStructure(session, ItemRev,this.fullexpandable,SelBusUnit,Hybridstatus);
					System.out.print("after manuual bomexpansion for structure manager BOM inputtree size="+inputtree.size());
				}
			}
			else
			{
				//boolean Hybridstatus=new TechSpecUtil().getHybridVCFlag(session,ItemRev);
				System.out.println("inside in Update TechSpec b4 BOMExpansion Hybrid status  "+Hybridstatus);
				if(Hybridstatus==false)
				{
				inputtree=bomexpansion.getTCUAStructure(session, ItemRev,this.fullexpandable,SelBusUnit,Hybridstatus);
				}

			}

			boolean goahead=constructMultiErrorDialog();

			if(goahead==false)
			{
				this.close();
				return area;
			}


			if(inputtree != null)
			{
				getAllTreeObjects(inputtree);
				System.out.println("inputtree.size()="+inputtree.size());
				
				//added on 30/11/2022 for giving error msg for mandatory attributes value for module's prior to VC attribute updation 
				
				/*
				 * boolean isBypass1 =session.hasBypass();//added
				 * 
				 * if(isBypass1==true) {
				 * 
				 * boolean answer=MessageDialog.openQuestion(
				 * parentShell,"Bypass check mandatory attributes value for module's prior to VC attribute updation  "
				 * , "Do you Want to Bypass TechSpec Update Validation?" ); if(answer==true)
				 * return answer;
				 * 
				 * 
				 * }
				 */
				//boolean exceptionflg=false;
				System.out.println("before update dialog construction exceptionflg="+exceptionflg);
				if(exceptionflg == true)
				{
					//super.close(); //hashed in TZ1.87
					//this.close();
				}
				
				System.out.println("going for update dialog construction="+selectedObj.getPropertyDisplayableValue("item_id")+"\ninputtree="+inputtree);
				//end on 30/11/2022 for giving error msg for mandatory attributes value for module's prior to VC attribute updation
				if(inputtree.size()>0)
				{
					if(treeViewer!=null)
					{
						treeViewer.setInput( inputtree);
						System.out.println("this.fullexpandable="+this.fullexpandable);
						if(this.fullexpandable==false)
						{
							ClassificationTreeLine ctl=inputtree.get(0);
							text.setText(ctl.getModuleAddress());
							// text_1.setText(ctl.getItemrev().toDisplayString());
							text_1.setText(ctl.getItemrev().getTCProperty("item_id").getDisplayableValue());
							text_2.setText(ctl.getClassificationName());
							text_3.setText(ctl.getObjectid());
						}
						else //this else need to be remove after test ,added 03 Feb 2026 
						{
							
							ClassificationTreeLine ctl=inputtree.get(0);
							System.out.println("inputtree.get(0)="+inputtree.get(0) + "\n ctl.getAttrList().size()=" +ctl.getAttrList().size());
							if(ctl.getAttrList().size()>0)
							{
							//ClassificationTreeLine ctl=inputtree.get(0);
							text.setText(ctl.getModuleAddress());
							
							text_1.setText(ctl.getItemrev().getTCProperty("item_id").getDisplayableValue());
							text_2.setText(ctl.getClassificationName());
							text_3.setText(ctl.getObjectid());
							}
						}
					}

				}


			}

		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotLoadedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		treeViewer.expandAll();


		try {
			System.out.println("selectedObj.getObjectString"+selectedObj.getObjectString());
			System.out.println("selectedObj.DisplayString"+selectedObj.toDisplayString());
			//TTT
			if(selectedObj instanceof TCComponentItemRevision)
				tsnum.setText(selectedObj.getTCProperty("item_id").getDisplayableValue());
			else
				tsnum.setText(selectedObj.toDisplayString());
			tsou.setText(selectedObj.getTCProperty("owning_user").getDisplayableValue());
			System.out.println("11111selectedObj.getTCProperty.getDisplayableValue()="+selectedObj.getPropertyDisplayableValue("t5_TechSNumDes"));
			//System.out.println("ItemRev.getTCProperty.getDisplayableValue()111="+ItemRev.getTCProperty("t5_TechSNumDes").getDisplayableValue());
			tsdesc.setText(selectedObj.getPropertyDisplayableValue("object_desc"));
			//			tsbu.setText(selectedObj.getPropertyDisplayableValue("t5_VCClassName")); 
			//			tsvsc.setText(selectedObj.getPropertyDisplayableValue("t5_VCSubClass"));
			//			tsodu.setText(selectedObj.getPropertyDisplayableValue("t5_DsgnOwnCpy"));
			//			tsodd.setText(selectedObj.getPropertyDisplayableValue("t5_DsgnDeptCpy"));
			System.out.println("SelBusUnit="+SelBusUnit +"SelVCSubClass="+SelVCSubClass +"SelDsgnOwnCpy="+SelDsgnOwnCpy+"SelDsgnDeptCpy"+SelDsgnDeptCpy);
			if(SelBusUnit!=null)
			{
				tsbu.setText(SelBusUnit);
			}
			if(SelVCSubClass!=null)
			{
				tsvsc.setText(SelVCSubClass);
			}
			if(SelDsgnOwnCpy!=null)
			{
				tsodu.setText(SelDsgnOwnCpy);
			}
			if(SelDsgnDeptCpy!=null)
			{
				tsodd.setText(SelDsgnDeptCpy);
			}
			//			tsvsc.setText(SelVCSubClass);
			//			tsodu.setText(SelDsgnOwnCpy);
			//			tsodd.setText(SelDsgnDeptCpy);

		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotLoadedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Start Tree 
		//treeViewer.setInput(input)
		//viewer.setInput(File.listRoots());

		//End 


		area.addControlListener(new ControlAdapter() {
			public void controlResized(ControlEvent e) {
				System.out.println("jghgfgdfdf");
				Rectangle area1 = area.getClientArea();
				Point preferredSize = tree.computeSize(SWT.DEFAULT, SWT.DEFAULT);
				int width = area1.width - 2*tree.getBorderWidth();
				if (preferredSize.y > area1.height + tree.getHeaderHeight()) {
					// Subtract the scrollbar width from the total column width
					// if a vertical scrollbar will be required
					Point vBarSize = tree.getVerticalBar().getSize();
					width -= vBarSize.x;
				}
				Point oldSize = tree.getSize();
				if (oldSize.x > area1.width) {
					// table is getting smaller so make the columns 
					// smaller first and then resize the table to
					// match the client area width

					grpClassificationPropertiesValues.setSize(area1.width, area1.height);
					searchText.setSize(area1.width, searchText.getSize().y);
					// searchText.setSize(searchText.getSize().x, area1.height-160);
					// tree.setSize(area1.width-10, area1.height-160);

					tree.setSize(area1.width-20, area1.height-200);
					int delta=(oldSize.x-area1.width)/(2*tree.getColumnCount());
					for(int f=0;f<tree.getColumnCount();f++)
					{

						tree.getColumn(f).setWidth(tree.getColumn(f).getWidth()-delta);

					}
				} else {
					// table is getting bigger so make the table 
					// bigger first and then make the columns wider
					// to match the client area width
					grpClassificationPropertiesValues.setSize(area1.width, area1.height);
					searchText.setSize(area1.width, searchText.getSize().y);
					tree.setSize(area1.width-20, area1.height-200);
					int delta=(area1.width-oldSize.x)/(2*tree.getColumnCount());
					for(int f=0;f<tree.getColumnCount();f++)
					{

						tree.getColumn(f).setWidth(tree.getColumn(f).getWidth()+delta);

					}

				}
			}
		});





		return area;
	}


	public void setbackGroundWaterMark(final Composite container,final Image image,final int width,final int height)
	{


		container.setBackgroundMode(SWT.INHERIT_FORCE);

		//Display display=new Display();
		//	final Shell shell=new Shell(display);
		//final Image image=new Image(display,this.getClass().getResourceAsStream("/image/readonly.png"));
		System.out.println("sfdfdfdfpaintControlpaintControlpaintControl");

		image.getImageData().setAlpha(0, 0, 0); // just to force alpha array allocation with the right size
		Arrays.fill(image.getImageData().alphaData, (byte) 0); // set whole image as transparent


		container.addPaintListener(new PaintListener()
		{


			public void paintControl(PaintEvent e) {
				// TODO Auto-generated method stub
				System.out.println("paintControlpaintControlpaintControl");
				Rectangle rect=container.getClientArea();
				e.gc.drawImage(new Image(container.getDisplay(),image.getImageData()), 0, 0,width,height,0,0,rect.width,rect.height);

			}


		});





	}


	public void updateICOVal(ICOValues val)
	{
		//text.setText(val.getCid());
		this.icoval=val;

		//classificationList.length
	}





	private TCComponent getComponent(Object paramObject)
	{
		AIFComponentContext localAIFComponentContext = (AIFComponentContext)AdapterUtil.getAdapter(paramObject, AIFComponentContext.class);
		Assert.isNotNull(localAIFComponentContext);
		TCComponent localTCComponent = (TCComponent)AdapterUtil.getAdapter(localAIFComponentContext.getComponent(), TCComponent.class);
		Assert.isNotNull(localTCComponent);
		return localTCComponent;
	}

	private TCComponent getTCComponent(AIFComponentContext localAIFComponentContext)
	{
		TCComponent localTCComponent = (TCComponent)AdapterUtil.getAdapter(localAIFComponentContext.getComponent(), TCComponent.class);
		Assert.isNotNull(localTCComponent);
		return localTCComponent;
	}


	public void populateTable() 
	{
		// TODO Auto-generated method stub		




		tabLineModel= new ClassificationLineProvider();
		for(int i=0;i<classificationList.size();i++)
		{
			System.out.println("classificationList="+classificationList.get(i));
		}
		tabLineModel.setClassificationLine(classificationList);

		treeViewer.setContentProvider(new TreeTableContentProvider());//TreeTable
		treeViewer.setInput( classificationList);


	}
	// used to clear filter search	
	public void clearFilter()
	{
		searchText.setText("");
		System.out.print("Inside clearFilter func:"+searchText.getText());
		searchFilter.setSearchText(searchText.getText());
		treeViewer.refresh();
	}

	private static void getAllItems(Tree tree, List<TreeItem> allItems)
	{

		for(TreeItem item : tree.getItems())
		{
			allItems.add(item);
			getAllItems(item, allItems);
		}
	}

	private static void getAllItems(TreeItem currentItem, List<TreeItem> allItems)
	{
		TreeItem[] children = currentItem.getItems();

		for(int i = 0; i < children.length; i++)
		{
			children[i].setExpanded(true);

			allItems.add(children[i]);

			getAllItems(children[i], allItems);
		}
	}

	public void addNamedReference(File tobeuploadfile,TCComponentDataset dataset)
	{
		System.out.print("Inside the function addNamedReference");
		FileManagementUtility fmsFileManagement =new FileManagementUtility(session.getSoaConnection());//, null, null, Bootstrap_Urls, cacheDir);
		try
		{
			GetDatasetWriteTicketsInputData[] inputs = { getSingleGetDatasetWriteTicketsInputData(tobeuploadfile,dataset) };
			ServiceData response = fmsFileManagement.putFiles(inputs);
			TechSpecUtil.ServiceDataError(response);
		}
		finally
		{
			// Close FMS connection when done
			fmsFileManagement.term();
		}

		System.out.print("End the function addNamedReference");
	}


	/*************************************************************************/
	private GetDatasetWriteTicketsInputData getSingleGetDatasetWriteTicketsInputData(File tobeuploadfile,TCComponentDataset dataset)
	{
		// Assume this file is in current dir
		//FileInfo file1 = new FileInfo();
		String cacheDir=System.getProperty("java.io.tmpdir");	
		TCPreferenceService pref=session.getPreferenceService();
		String FMS_Bootstrap_Urls=pref.getPreferenceDescription("FMS_Bootstrap_Urls");
		String[] Bootstrap_Urls={FMS_Bootstrap_Urls};
		//String[] FMS_Bootstrap_Urls = session.getPreferenceService();
		System.out.print("FMS_Bootstrap_Urls:-"+FMS_Bootstrap_Urls+"Bootstrap_Urls="+Bootstrap_Urls[0]);
		//FileManagementUtility fmsFileManagement =new FileManagementUtility(session.getSoaConnection());//, null, null, Bootstrap_Urls, cacheDir);

		String filenametobeupload=tobeuploadfile.getName().replaceAll(";", "_");//21-05-2021
		String filepath=tobeuploadfile.getPath();
		System.out.print("filenametobeupload:-"+filenametobeupload+ "filepath="+filepath);
		String WholefileName = filepath + filenametobeupload;
		System.out.print("WholefileName:-"+WholefileName);

		// Create a file to associate with dataset
		DatasetFileInfo fileInfo = new DatasetFileInfo();

		fileInfo.clientId = fileInfo.toString();
		fileInfo.fileName = filepath;
		fileInfo.allowReplace=true;
		fileInfo.isText = false;
		fileInfo.namedReferencedName = "excel";

		DatasetFileInfo[] fileInfos = { fileInfo };

		GetDatasetWriteTicketsInputData inputData = new GetDatasetWriteTicketsInputData();
		inputData.dataset = dataset;
		inputData.createNewVersion = false;
		inputData.datasetFileInfos = fileInfos;

		return inputData;

	}



	public TCComponentDataset CreateDataset(TCComponentItemRevision techspecobj,String datasetname,String Desc,File filetobeupload) throws TCException
	{
		System.out.print("inside CreateDataset func");
		DataManagementService dservice = DataManagementService.getService(session.getSoaConnection());
		String filenametobeupload=filetobeupload.getName();
		String filepath=filetobeupload.getPath().replaceAll(";", "_");//21-05-2021;
		System.out.print("filenametobeupload:-"+filenametobeupload+ "filepath="+filepath);
		String WholefileName = filepath + filenametobeupload;
		System.out.print("WholefileName:-"+WholefileName);
		DatasetProperties[] dataProps = new DatasetProperties[1];
		dataProps[0] = new DatasetProperties();
		dataProps[0].clientId = datasetname;
		dataProps[0].name = datasetname;
		dataProps[0].description = Desc;
		//dataProps[0].
		dataProps[0].relationType = "IMAN_reference";
		dataProps[0].type = "MSExcelX";
		dataProps[0].toolUsed = "MSExcel";
		dataProps[0].container = techspecobj;
		CreateDatasetsResponse dataResp = dservice.createDatasets(dataProps);
		TechSpecUtil.ServiceDataError(dataResp.serviceData);
		if(dataResp.serviceData.sizeOfCreatedObjects()>0)
		{
			ModelObject dataset = dataResp.output[0].dataset;

			// refresh Objects
			//   TCComponent[] objs = { techspecobj.getItem(), techspecobj, dataset };
			//   dservice.refreshObjects(objs);
			System.out.print("End CreateDataset func");
			return (TCComponentDataset) dataset;
		}

		return null;
		// System.out.print("End CreateDataset func");
	}

	/*	 	
	 */	
	private File createClsUpdatedHistoryRpt(String DmlNo,TCComponent selObj,boolean showMsg) 
	{
		// create a workbook
		XSSFWorkbook wb = new XSSFWorkbook();

		// add a worksheet
		XSSFSheet sheet = wb.createSheet("Updated VC Attributes History");

		// shade the background of the header row
		XSSFCellStyle headerStyle = wb.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
//		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
//		headerStyle.setBorderTop(CellStyle.BORDER_THIN);
//		headerStyle.setBorderBottom(CellStyle.BORDER_THIN);
//		headerStyle.setBorderLeft(CellStyle.BORDER_THIN);
//		headerStyle.setBorderRight(CellStyle.BORDER_THIN);
//		headerStyle.setAlignment(HorizontalAlignment.CENTER);

		headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headerStyle.setBorderTop(BorderStyle.THIN);
		headerStyle.setBorderBottom(BorderStyle.THIN);
		headerStyle.setBorderLeft(BorderStyle.THIN);
		headerStyle.setBorderRight(BorderStyle.THIN);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		
		Tree tree=treeViewer.getTree();


		List<TreeItem> allItems = new ArrayList<TreeItem>();

		getAllItems(tree, allItems);

		// System.out.println("XXXXXXXtreeitem="+allItems);
		TreeItem[] treeitem= tree.getItems();

		for(int l=0;l<allItems.size();l++)
		{
			for(int m=0;m<8;m++)
			{
				System.out.print("XXXXXXXtreeitem="+allItems.get(l).getText(m));
			}
			System.out.println(" ");
		}

		// add header row

		TreeColumn[] columns = tree.getColumns();
		int rowIndex = 0;
		int cellIndex = 0;
		XSSFRow header = sheet.createRow((short) rowIndex++);
		for (TreeColumn column : columns) {
			String columnName = column.getText();
			XSSFCell cell = header.createCell(cellIndex++);
			cell.setCellValue(column.getText());
			cell.setCellStyle(headerStyle);
		}

		// add data rows

		for(int l=0;l<allItems.size();l++)
		{
			// create a new row
			TreeItem item=allItems.get(l);
			XSSFRow row = sheet.createRow((short) rowIndex++);
			cellIndex = 0;

			for (int i = 0; i < columns.length; i++) {
				// create a new cell
				// String columnName = TreeColumnNames[i];
				XSSFCell cell = row.createCell(cellIndex++);

				// set the horizontal alignment (default to RIGHT)
				XSSFCellStyle cellStyle = wb.createCellStyle();
				HorizontalAlignment ha = HorizontalAlignment.RIGHT;
				cellStyle.setAlignment(ha);
				cell.setCellStyle(cellStyle);

				// set the cell's value
				String text = item.getText(i);
				cell.setCellValue(text);
			}
		}

		// autofit the columns
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn((short) i);
		}
		String selecteditem=null;
		String rev=null;
		try {

			System.out.println("in createClsUpdatedHistoryRpt func objType="+objType);
			if(objType.equals("Design Revision"))
			{
				selecteditem=selObj.getTCProperty("item_id").getDisplayableValue();
				rev=selObj.getTCProperty("item_revision_id").getDisplayableValue();
			}
			else
			{
				selecteditem=selObj.getTCProperty("object_name").getDisplayableValue();
				rev="NR";
			}



		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print("inside createWorkbookFromTree fun with report file name=" +techspecno + "rev="+rev + "selectedObj display string="+selectedObj.toDisplayString());

		// DirectoryDialog dialog = new DirectoryDialog(parentShell);
		// String path=dialog.open();		    
		// String expfilename=null;
		// expfilename=path+"\\"+selecteditem+"_"+rev+".xlsx";
		// System.out.print("expfilename="+expfilename);
		// exportWorkbookToAFile(wb,expfilename);

		String expfilename=null;
		String path=System.getProperty("java.io.tmpdir");	
		expfilename=path+"\\"+selecteditem+"_"+rev+"_NRVCATTRS_ModifiedBy_"+DmlNo+".xlsx";
		exportWorkbookToAFile(wb,expfilename,showMsg); //added newly on 06052019
		//fos.close();
		System.out.println(expfilename+" written successfully"); 
		/*try {
				//FileOutputStream fos;
				//fos = new FileOutputStream(expfilename);


				exportWorkbookToAFile(wb,expfilename); //added newly on 06052019
				//fos.close();
				System.out.println(expfilename+" written successfully"); 

				//fos.write(fos);

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/

		//File fileObj = new File(expfilename);
		return new File(expfilename);
	}

	private XSSFWorkbook createWorkbookFromTree(boolean showMsg) {
		// create a workbook
		XSSFWorkbook wb = new XSSFWorkbook();

		// add a worksheet
		XSSFSheet sheet = wb.createSheet("Exported VC Attributes");

		// shade the background of the header row
		XSSFCellStyle headerStyle = wb.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
//		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
//		headerStyle.setBorderTop(CellStyle.BORDER_THIN);
//		headerStyle.setBorderBottom(CellStyle.BORDER_THIN);
//		headerStyle.setBorderLeft(CellStyle.BORDER_THIN);
//		headerStyle.setBorderRight(CellStyle.BORDER_THIN);
//		headerStyle.setAlignment(HorizontalAlignment.CENTER);

		headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headerStyle.setBorderTop(BorderStyle.THIN);
		headerStyle.setBorderBottom(BorderStyle.THIN);
		headerStyle.setBorderLeft(BorderStyle.THIN);
		headerStyle.setBorderRight(BorderStyle.THIN);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		Tree tree=treeViewer.getTree();


		List<TreeItem> allItems = new ArrayList<TreeItem>();

		getAllItems(tree, allItems);

		// System.out.println("XXXXXXXtreeitem="+allItems);
		TreeItem[] treeitem= tree.getItems();

		for(int l=0;l<allItems.size();l++)
		{
			for(int m=0;m<8;m++)
			{
				System.out.print("XXXXXXXtreeitem="+allItems.get(l).getText(m));
			}
			System.out.println(" ");
		}

		// add header row

		TreeColumn[] columns = tree.getColumns();
		int rowIndex = 0;
		int cellIndex = 0;
		XSSFRow header = sheet.createRow((short) rowIndex++);
		for (TreeColumn column : columns) {
			String columnName = column.getText();
			XSSFCell cell = header.createCell(cellIndex++);
			cell.setCellValue(column.getText());
			cell.setCellStyle(headerStyle);
		}

		// add data rows

		for(int l=0;l<allItems.size();l++)
		{
			// create a new row
			TreeItem item=allItems.get(l);
			XSSFRow row = sheet.createRow((short) rowIndex++);
			cellIndex = 0;

			for (int i = 0; i < columns.length; i++) {
				// create a new cell
				// String columnName = TreeColumnNames[i];
				XSSFCell cell = row.createCell(cellIndex++);

				// set the horizontal alignment (default to RIGHT)
				XSSFCellStyle cellStyle = wb.createCellStyle();
				HorizontalAlignment ha = HorizontalAlignment.RIGHT;
				cellStyle.setAlignment(ha);
				cell.setCellStyle(cellStyle);

				// set the cell's value
				String text = item.getText(i);
				cell.setCellValue(text);
			}
		}

		// autofit the columns
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn((short) i);
		}
		String selecteditem=null;
		String rev=null;
		try {
			System.out.println("in createWorkbookFromTree objType="+objType);
			if(objType.equals("Design Revision"))
			{
				selecteditem=selectedObj.getTCProperty("item_id").getDisplayableValue();
				rev=selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
			}
			else
			{
				selecteditem=selectedObj.getTCProperty("object_name").getDisplayableValue();
				rev="NR";
			}

		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print("inside createWorkbookFromTree fun with to be filename =" +techspecno + " selecteditem="+selecteditem+" rev="+rev + " selectedObj display string="+selectedObj.toDisplayString());

		DirectoryDialog dialog = new DirectoryDialog(parentShell);
		String path=dialog.open();		    
		String expfilename=null;
		//expfilename=path+"\\"+selecteditem+"_"+rev+".xlsx";
		expfilename=path+"\\"+techspecno+"_"+"VC_ATTRIBUTES_REPORT"+".xlsx";
		System.out.print("expfilename="+expfilename);
		exportWorkbookToAFile(wb,expfilename,showMsg);
		return wb;
	}

	public void exportWorkbookToAFile(XSSFWorkbook wb, String filename,boolean showMsg) {
		try {

			FileOutputStream fos = new FileOutputStream(filename);
			wb.write(fos);
			fos.close();
			if(showMsg)
			{
				MessageDialog.openInformation(parentShell,
						"Save Workbook Successful",
						"Workbook saved to the file:\n\n" + filename);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
			String msg = ioe.getMessage();
			MessageDialog.openError(parentShell, 
					"Save Workbook Failed",
					"Could not save workbook to the file:\n\n" + msg);
		}
	}

	//Added by Rajesh on 22/05/2019 for change history report will get attached with other CCV as well.
	public TCComponent ChangeHistObjCre(TCSession session,TCComponent selectedObj,TCComponentItemRevision ErcDMLObj,boolean showMsg) throws TCException
	{
		TCComponentDataset dataset=null;

		String ErcDmlNo;
		System.out.println("22ErcDMLObj="+ErcDMLObj);
		try {
			if(ErcDMLObj!=null)
			{
				ErcDmlNo = ErcDMLObj.getTCProperty("item_id").getDisplayableValue();
				//ErcDmlNo="10PP131333"; //need to delete before check in
				System.out.println("222ErcDmlNo="+ErcDmlNo);
				File UpdatedRptHist=createClsUpdatedHistoryRpt(ErcDmlNo,selectedObj,showMsg);
				String selectedobjName=selectedObj.getTCProperty("item_id").getDisplayableValue();
				System.out.println("going to create change history dataset for respective CCV"+selectedobjName);
				String RevSeq=selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
				RevSeq=RevSeq.replace(";", "_");
				System.out.println("RevSeq="+RevSeq);
				String datasetname=selectedobjName+"_"+RevSeq+"_NRVCATTRS_ModifiedBy_"+ErcDmlNo;

				System.out.println("B4 Dataset Qry call");
				TCComponent datasetExist=TechSpecUtil.qryObj(session,"Dataset Name","Dataset Name",datasetname);
				System.out.println("After Dataset Qry call");
				if(datasetExist!=null)
				{
					System.out.println("Dataset already available in system, only Named refrence will attach\n");
					System.out.println("Going to Add name refrence with dataset\n");
					addNamedReference(UpdatedRptHist,(TCComponentDataset)datasetExist);
				}
				else
				{
					System.out.print("111B4 CreateDataset func call with datasetname="+datasetname);						
					dataset=CreateDataset((TCComponentItemRevision)selectedObj,datasetname,selectedObj.getTCProperty("object_name").getDisplayableValue(),UpdatedRptHist);
					System.out.println("Going to Add name refrence with dataset\n");
					addNamedReference(UpdatedRptHist,dataset);
				}
				//getSingleGetDatasetWriteTicketsInputData(UpdatedRptHist,dataset);
				//System.out.println("Going to Add name refrence with dataset\n");
				//addNamedReference(UpdatedRptHist,dataset);
				System.out.println("Added name refrence with dataset\n");
			}
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.print("2222After CreateDataset func call");


		return null;

	}

	//End of func ChangeHistObjCre

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		Button button = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,
				true);

		Bundle bundle = FrameworkUtil.getBundle(this.getClass());

		// use the org.eclipse.core.runtime.Path as import
		String path="icons/Ok_16x16.png";


		URL url = FileLocator.find(bundle,
				new Path(path), null);
		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);


		button.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/Ok_16x16.png"));
		button.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		Button button_1 = createButton(parent, IDialogConstants.CANCEL_ID,
				IDialogConstants.CANCEL_LABEL, false);



		// use the org.eclipse.core.runtime.Path as import
		path="icons/close_16x16.png";


		url=FileLocator.find(bundle,
				new Path(path), null);
		imageDescriptor = ImageDescriptor.createFromURL(url);
		button_1.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/close_16x16.png"));

		Button button_3 = createButton(parent, IDialogConstants.FINISH_ID,
				"Export To XLS", false);
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override

			public void widgetSelected(SelectionEvent e) {
				clearFilter();
				createWorkbookFromTree(true);

			}
		});



		// use the org.eclipse.core.runtime.Path as import
		path="icons/excel.png";


		url=FileLocator.find(bundle,
				new Path(path), null);
		imageDescriptor = ImageDescriptor.createFromURL(url);
		button_3.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/close_16x16.png"));
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		Rectangle size=getShell().getDisplay().getPrimaryMonitor().getClientArea();
		//System.out.println("SSSSSSSSSSSSSSSSSSSSSS::"+size);
		return new Point(size.width,size.height);//789, 809);

	}

	@Override
	protected void okPressed() {
		// TODO Auto-generated method stub
		//Rajesh
		// String ModuleAddress = null;
		System.out.println("going to call CreateOrUpdateICOSample==isUpdatable=="+isUpdatable);
		String errMsgStr=null;
		String moderrlist=null;


		int chkdlg=	constructCheckedInfoDialog();

		System.out.println("chkdlg::"+chkdlg);
		if( chkdlg==-1)
			return;


		if(isUpdatable==false )
		{
			super.okPressed();
			return;
		}

		/*
		 * System.out.println("in OkPressed cmvrattrid " +cmvrattrid
		 * +"cmvrattrval="+cmvrattrval); if(cmvrattrid.contains("171")) {
		 * if(cmvrattrval.isEmpty()) { MessageBox.post(
		 * parentShell,"CMVR Value for 171 attribute can be NULL,update NA if CMVR has not linked with Vehicle, Contact PLM Support Team for further details if required."
		 * ,"WARNING",SWT.ICON_WARNING); return; } }
		 */
		System.out.println("in OkPressed cmvrValnullFlg " +cmvrValnullFlg);
		if(cmvrValnullFlg==true)
		{
			MessageBox.post(parentShell,"CMVR Value for 171 attribute can not be NULL,update NA if CMVR has not linked with Vehicle, Contact PLM Support Team for further details if required.","WARNING",SWT.ICON_WARNING); 
			return;  
		}
		//Added newly to restrict cmvrno value update by designer
		
//		String Updval=((ClassificationTableLine) element).getAttrValue();
//		String UpdAttrId=((ClassificationTableLine) element).getAttrID();
//		System.out.println("UpdAttrId="+UpdAttrId +" Updval="+Updval);
//		if(UpdAttrId.contains("171"))
//		{
//			if(Updval.contains("NA"))
//			{
//				System.out.println("Allow to go ahead");
//			}
//			else
//			{
//				MessageBox.post(parentShell,"CMVR Value can't be allow to update via this option, so choose NA value from LOV only or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);
//			}
//		}
		
		// End newly to restrict cmvrno value update by designer

		//boolean x= moduleMandatoryMap.isEmpty();
		boolean x=modulemandatorylist.isEmpty();
		System.out.println("Module's mandatory's valueset :"+modulemandatorylist.size());
		if(modulemandatorylist.size()>0)
		{


			errMsgStr= "Module's Mandatory Attribute is not filled,Pls check & update below Module's Attributes by below option then retry to update Technical Specification attribute for VC/CCVC \n";
			errMsgStr=errMsgStr+"File-->New-->Document Management-->Tech Spec-->Update Module Attribute";

			//{

			for(int m1=0;m1<modulemandatorylist.size();m1++)
			{
				System.out.println("required modulemandatorylist  " + modulemandatorylist.get(m1) +"moderrlist="+moderrlist);

				if(m1<=0)
				{
					System.out.println("\ninside moderrlist is null");
					moderrlist=modulemandatorylist.get(m1);
				}
				else
				{
					System.out.println("\ninside moderrlist is not null");
					moderrlist=moderrlist.concat("\t");
					moderrlist=moderrlist.concat(";");
					moderrlist=moderrlist.concat(modulemandatorylist.get(m1));

				}
				System.out.println("moderrlist="+moderrlist);
				//moderrlist.concat(";");
				//moderrlist.concat(modulemandatorylist.get(m1));

				//			  		CommandTargetState cmdstate=new CommandTargetState(aifcomponentctxtList.get(m1),null);
				//	                cmdstate.setCaughtException(new TCException(modulemandatorylist.get(m1)));
				//	                cmdstate.setDone(true);
				//	             
				//		  	         m_commandTargetStateList1.add(cmdstate);

			}
			//}





			System.out.println("moderrlist.length() " +moderrlist.length()
			+" moderrlist="+moderrlist); if(moderrlist.length()>0) {
				modulemandatorylist.clear(); errMsgStr=errMsgStr.concat("\n");
				errMsgStr=errMsgStr.concat(moderrlist); // errMsgStr=errMsgStr.concat("\t");
				System.out.println("outside loop errMsgStr " +errMsgStr);
				MessageBox.post(parentShell,errMsgStr,"WARNING",SWT.ICON_WARNING);
				//UpdateTechSpecDialog.this.close(); moderrlist=null;

			}



			super.okPressed();
			return;
		}

		

		/* Object[] selchk=chkdlg.getM_treeTableView().getTreeViewer().getCheckedElements();
		 System.out.println("All tree Checked Size::"+selchk.length);
		 for(int x1=0;x1<selchk.length;x1++)
		 {
		 AIFComponentContext aif_ctx=chkdlg.getIC_AIFContext(selchk[x1]);
		  System.out.println("All tree Checked::"+aif_ctx.getComponent().toString());
		  ccvselList.add(aif_ctx);
		 }
		 */	 
		Map<ClassificationObject,HashMap<String, Object>> classmap=new HashMap<ClassificationObject,HashMap<String, Object>> ();

		AbstractAIFUIApplication app1=AIFUtility.getCurrentApplication();


		ArrayList treelist=(ArrayList) treeViewer.getInput();
		System.out.println("treelist.Size()="+treelist.size());
		for(int i=0;i<treelist.size();i++)
		{
			if(treelist.get(i) instanceof ClassificationTreeLine)
			{
				ClassificationTreeLine treeObj=(ClassificationTreeLine) treelist.get(i);
				if(UpdateTechSpecDialog.this.fullexpandable)
				{
					try {
						String parttype=treeObj.getItemrev().getTCProperty("t5_PartType").getDisplayableValue();
						if(parttype.equals("Module"))
						{
							continue;
						}

					} catch (TCException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}


				namevalueP=new HashMap <String,Object>();

				arrayAttr=new HashMap <String,String>();

				//ClassificationObject clsobjs=treeObj.getClsobjs();
				this.clsobjs=treeObj.getClsobjs();
				System.out.println("after clsobjs get="+clsobjs);
				moduleAddr=treeObj.getModuleAddress();

				//	StringTokenizer stk= new StringTokenizer(moduleAddr,"[]");
				//	ModuleAddress=stk.nextToken();
				//	ObjectID=stk.nextToken();
				ModuleAddress=treeObj.getModuleAddress();
				ObjectID=treeObj.getObjectid();
				ArrayList<ClassificationAnnotationLine> treechildren=treeObj.getAttrList();
				try {
					ModuleNum= treeObj.getItemrev().getTCProperty("item_id").getDisplayableValue();
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.println("parttype:::"+SelParttype +"ModuleNum="+ModuleNum);
				String projcode=ModuleNum.substring(0,4);
				System.out.println("projcode:::"+projcode +"ModuleNum="+ModuleNum);
				//ModuleNum= treeObj.getItemrev().getTCProperty("item_id").getDisplayableValue();
				localAIFComponentContext =null;// (AIFComponentContext)AdapterUtil.getAdapter(treeObj.getItemrev(), AIFComponentContext.class);
				TCComponentItemRevision item_rev=treeObj.getItemrev();


				try {

					parent_item=item_rev.getItem();
					localAIFComponentContext=new AIFComponentContext(parent_item,item_rev,"structure_revision");
					System.out.println("fggdfdfsdsasasa:::"+localAIFComponentContext.toString());
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.println("treelist.getClass()="+treelist.getClass());
				System.out.println("treelist.tostring()="+treelist.toString());
				System.out.println("11ModuleNum="+ModuleNum);



				for(int j=0;j<treechildren.size();j++)
				{

					ClassificationAnnotationLine  annot_lin=treechildren.get(j);
					ArrayList<ClassificationTableLine> treechildren1=annot_lin.getAttrList();
					for(int g=0;g<treechildren1.size();g++)
					{

						if(treechildren1.get(g) instanceof ClassificationTableLine)
						{
							ClassificationTableLine treeTabObj=(ClassificationTableLine) treechildren1.get(g);
//((ClassificationTableLine) element).setChangeValue(keyvallov.getKey().get(cmb1.getSelectionIndex()));
							String attrid=treeTabObj.getAttrID();
							String attrval=treeTabObj.getAttrValue();
							String lovId=treeTabObj.getLovID();
							String attrname=treeTabObj.getAttrName();
							boolean ismandatory=treeTabObj.isIsmandatory();
							//String Cls=treeTabObj.getClass();
							int arrsize=treeTabObj.getArraySize();
							String deptattr=treeTabObj.getDepattr();
							String deptcfg=treeTabObj.getDepattrcfg();
							String deptval=modifedvalueMap.get(deptattr);
							if(deptval==null)
							{
								deptval=treeTabObj.getAttrValue();
							}
							System.out.println("ismandatory="+ismandatory);
							System.out.println("attrname="+attrname +"attrid="+attrid +"attrval="+attrval +" arrsize="+arrsize +" cmvrno="+cmvrno);
							String kk1=null;
							//String kv="NA";
							if(attrid.contains("171"))
							{
								String kv=cmvrno;
								//if(attrval.isEmpty())
								{
									try {
										final KeyValueLOV keyvallov=	new GetKeyLOVs2Sample3().testGetKeyLOVs2(ModuleAddress,attrid,lovId,deptattr,deptcfg,deptval,arrsize);
										ArrayList<String> keylovlst=keyvallov.getKey();
										ArrayList<String> keylovlst1=keyvallov.getValue();

										System.out.println("keylovlst.size()="+keylovlst.size());
										for(int r=0;r<keylovlst.size();r++)
										{

											//kk=keylovlst.get(r);
											System.out.println("keylovlst1.get(r)="+keylovlst1.get(r) );
											if(keylovlst1.get(r).equals(kv))
											{
												kk1=keylovlst.get(r);
												break;
											}


										}
										System.out.println("key="+kk1 +"kv="+kv);
									} catch (ServiceException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
								}
							}
							if(ismandatory)
							{
								System.out.println("attrval="+attrval +"attrval.length()="+attrval.length());
								if(attrval==null || attrval.length()==0)
								{
									System.out.println("in loop attrval="+attrval +"attrval.length()="+attrval.length());
									if(uniqueErrObj.contains(localAIFComponentContext)==false)
									{
										System.out.println("in loop attrval="+attrval +"attrval.length()="+attrval.length()+"!uniqueErrObj.contains(localAIFComponentContext)"+uniqueErrObj.contains(localAIFComponentContext));
										mandatorylist.add("Please Fill the below Mandatory Attributes !! ");
										aifcomponentctxtList.add(localAIFComponentContext);
										uniqueErrObj.add(localAIFComponentContext);
										System.out.println("localAIFComponentContext="+localAIFComponentContext );
									}
									mandatorylist.add(attrname);
									aifcomponentctxtList.add(localAIFComponentContext);
								}
							} 
							System.out.println("22attrid="+attrid +"attrval="+attrval + "lovId="+lovId +"attrid.contains(\"171\")="+attrid.contains("171"));
							cmvrattrid="";
							cmvrattrval="";
							if(attrid.contains("171"))
							{
								//MessageBox.post(parentShell,"CMVR attribute 171  can not be modified other than NA or linked Intent's cmvr no,update NA if CMVR has not linked with Vehicle, Contact PLM Support Team for further details if required.","WARNING",SWT.ICON_WARNING);
								
								if(attrval.isEmpty())
								{
								//cmvrattrid+=attrid;
								//cmvrattrval+=attrval;
									//attrval+="NA";
								//cmvrValnullFlg=true;
									//((ClassificationTableLine) treeTabObj).setChangeValue(keyvallov.getKey().get(cmb1.getSelectionIndex()));
									System.out.println("Key for NA value is "+kk1);
									//if(kk1.isEmpty()==false && kk1!=null)
									if(kk1!=null && kk1.isEmpty() )
									{
										System.out.println("Key is empty for NA value is "+kk1);
									}
									else
									{
									//treeTabObj.setChangeValue("NA"); //need to set the key instead of value
										treeTabObj.setChangeValue(kk1);
									}
									
								}
								else
								{
									if(attrval.equals("NA")==false)
									{
										if(attrval.equals(cmvrno)==false)
										{
										MessageBox.post(parentShell,"CMVR attribute 171  can not be modified other than NA or linked Intent's cmvr no,update NA if CMVR has not linked with Vehicle, Contact PLM Support Team for further details if required.","WARNING",SWT.ICON_WARNING);
										return ;
										}
									}
									System.out.println("Key for cmvrno="+cmvrno +"key value is "+kk1);
									treeTabObj.setChangeValue(kk1);
									
								}
							}
							System.out.println("value set for cmvrattrid " +attrid +"cmvrattrval="+attrval +"cmvrValnullFlg="+cmvrValnullFlg);
							
							// namevalueP.put(item.getText(1),"v"+itemIndex)   ;
							try
							{
								if(Integer.parseInt(lovId)<0)
								{
									if(treeTabObj.getChangeValue()==null)
										continue;
									if(treeTabObj.getChangeValue()!=null)
										attrval=treeTabObj.getChangeValue();
									System.out.println("attrval="+attrval);
									if(treeTabObj.getArraySize()>1)
									{

										arrayAttr.put(attrid, treeTabObj.getArraySize()+"");


										List<String> selList1=new ArrayList<String>();
										String valueadd="";
										if(attrval!=null && attrval.trim().length()>0)
										{
											selList1=(Arrays.asList(attrval.trim().split(PreferenceValue.getARRAY_DELMITER())));
											valueadd="";
											for(int f=0;f<selList1.size();f++)
											{
												String tokenval=new StringTokenizer(selList1.get(f), /*" "*/PreferenceValue.getKeyvalueDelmiter()).nextToken();
												valueadd+=tokenval;
												if(f<selList1.size()-1)
													valueadd+=PreferenceValue.getARRAY_DELMITER();//",";


											}

											//namevalueP.put(attrid,valueadd)   ;
										}
										//else
										namevalueP.put(attrid,attrval)   ;
										namevalueP.put(attrid,valueadd)   ;

										System.out.println("valueadd ::"+ valueadd);
										//namevalueP.put(attrid,"@"+attrval)   ;
									}
									else
									{
										// if(treeTabObj.getLovKeyValue()!=null)
										//attrval=treeTabObj.getLovKeyValue();
										if(attrval.trim().length()>0)
										{
											namevalueP.put(attrid,new StringTokenizer(attrval,/*" "*/PreferenceValue.getKeyvalueDelmiter()).nextToken());
											//namevalueP.put(attrid,attrval);
										}
										else
										{

											namevalueP.put(attrid,attrval)   ;
										}
									}
								}
								else
								{
									if(treeTabObj.getChangeValue()==null)
										continue;
									if(treeTabObj.getChangeValue()!=null)
										attrval=treeTabObj.getChangeValue();
									namevalueP.put(attrid,attrval)   ;
								}
							} catch(NumberFormatException e) { 
								e.printStackTrace();
							}

						}

					}//annot

				}//klkl

				if(mandatorylist.size()>0)
				{
					for(int m=0;m<mandatorylist.size();m++)
					{
						CommandTargetState cmdstate=new CommandTargetState(aifcomponentctxtList.get(m),null);
						cmdstate.setCaughtException(new TCException(mandatorylist.get(m)));
						cmdstate.setDone(false);

						m_commandTargetStateList1.add(cmdstate);

					}

					if(aifcomponentctxtList.size()>0)
					{
						AIFComponentContext[] selobjs=aifcomponentctxtList.toArray(new AIFComponentContext[aifcomponentctxtList.size()]);
						System.out.println("selobjs="+selobjs.length);
						AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

						TCSession session=(TCSession) app.getSession();

						TMLDataBean databean= new TMLDataBean(parent_item.getSession(), null,selobjs,exe_evt);
						databean.setTargetContexts(selobjs);

						MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
						System.out.println("inside update status printing step5");
						paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList1);

						TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },1,null);
					}
					aifcomponentctxtList.clear();
					mandatorylist.clear();
					m_commandTargetStateList1.clear();
					uniqueErrObj.clear();
					return;
				}
				System.out.println("CreateOrUpdateICOSample clsobjs="+clsobjs);


				if(namevalueP.isEmpty())
				{


					CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
					cmdstate.setCaughtException(new TCException("No Value to Update"));
					cmdstate.setDone(true);
					localAIFComponentContextList.add(localAIFComponentContext);
					m_commandTargetStateList.add(cmdstate);
					isSuccess=true;

				}
				else
				{
					TCComponentItem treeitem=null;
					try {
						treeitem=treeObj.getItemrev().getItem();
					} catch (TCException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					CreateOrUpdateICOSample icos=null;
					System.out.println("b4 call CreateOrUpdateICOSample modClsname:::"+modClsname +" ModuleAddress="+ModuleAddress);		
					if(SelParttype!=null)
					{
						if(SelParttype.equals("Module"))
						{
							//CreateOrUpdateICOSample icos=new  CreateOrUpdateICOSample(treeitem,clsobjs, ModuleAddress, ObjectID, ModuleNum,namevalueP, arrayAttr,session);
							if(modClsname!=null)
							{
								icos=new  CreateOrUpdateICOSample(treeitem,clsobjs, modClsname, ObjectID, ModuleNum,namevalueP, arrayAttr,session);
							}
							else
							{
								System.out.println("2b4 call CreateOrUpdateICOSample modClsname:::"+modClsname +" ModuleAddress="+ModuleAddress);	
								icos=new  CreateOrUpdateICOSample(treeitem,clsobjs, ModuleAddress, ObjectID, ModuleNum,namevalueP, arrayAttr,session);
							}
						}
						else
						{
							icos=new  CreateOrUpdateICOSample(treeitem,clsobjs, ModuleAddress, ObjectID, ModuleNum,namevalueP, arrayAttr,session);
						}
					}
					else
					{
						icos=new  CreateOrUpdateICOSample(treeitem,clsobjs, ModuleAddress, ObjectID, ModuleNum,namevalueP, arrayAttr,session);
					}
					try {
						icos.createAndUpdateICO();
						isSuccess=true;
					} catch (ServiceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					finally
					{
						/*localAIFComponentContext =null;// (AIFComponentContext)AdapterUtil.getAdapter(treeObj.getItemrev(), AIFComponentContext.class);
		  		 TCComponentItemRevision item_rev=treeObj.getItemrev();


				try {

					 parent_item=item_rev.getItem();
					 localAIFComponentContext=new AIFComponentContext(parent_item,item_rev,"structure_revision");
					 System.out.println("fggdfdfsdsasasa:::"+localAIFComponentContext.toString());
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
						 */
						ServiceData data=icos.getServiceData();
						firstccvclsobj=icos.getCreateUpdatedclobj();
						if(SelParttype.equals("Module")==false)
						{



							//Added by rajesh on 22/05/2019
							String parttype=null;

							try {
								parttype = treeObj.getItemrev().getTCProperty("t5_PartType").getDisplayableValue();
								//System.out.println("\n4444parttype="+parttype);
							} catch (TCException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							System.out.println("\n4444parttype="+parttype);
							//if(parttype.equals("Vehicle Combination"))
							if(treeObj.getItemrev()!=null)
							{
								//ErcDMLObj=TechSpecUtil.SecondaryToPrimaryObj("CMHasSolutionItem",ccv_item);

								ErcDMLObj=TechSpecUtil.getAttachedDML(treeObj.getItemrev(),"CMHasSolutionItem",/*"Update VC attributes and Tech Spec Header""Update VC attributes*"*/step_wf);

								System.out.println("before call func ChangeHistObjCre1 with input ErcDMLObj="+ErcDMLObj +"ccv_item="+treeObj.getItemrev() +"bypassUsrflg="+bypassUsrflg);
								if(treeObj.getItemrev() instanceof TCComponentItemRevision)
								{
									if(bypassUsrflg==false || isBypass==false)
									{
									try {
										
										ChangeHistObjCre((TCSession) session,treeObj.getItemrev(),ErcDMLObj,false);
									} catch (TCException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									System.out.println("End call func ChangeHistObjCre1 ");
									//End 
									}
								}
							}

							if(data!=null && data.sizeOfPartialErrors() > 0)
							{
								localAIFComponentContextList.clear();
								m_commandTargetStateList.clear();
								for(int ij = 0; ij < data.sizeOfPartialErrors(); ij++)
								{
									for(String msg :
										data.getPartialError(ij).getMessages())
									{
										System.out.println("ServiceDataError1:"+msg);
										CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
										cmdstate.setCaughtException(new TCException(msg));
										cmdstate.setDone(false);
										localAIFComponentContextList.add(localAIFComponentContext);
										m_commandTargetStateList.add(cmdstate);


										/*     
				  	        AIFComponentContext[] selobjs={localAIFComponentContext};//selectedobject};
				  			TMLDataBean bn=new TMLDataBean(parent_item.getSession(), null,selobjs);
				  			bn.setTargetContexts(selobjs);
				  			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1], bn );
				  			paramMultiTargetControllerJob.getCommandTargetStateList().add(cmdstate);
				  			TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob);*/
									}
								}
								//System.out.println("localAIFComponentContext.toString()=:"+localAIFComponentContext.toString());



							}

							else
							{
								localAIFComponentContextList.clear();
								m_commandTargetStateList.clear();
								CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
								cmdstate.setCaughtException(new TCException("Updated Successfully. Please Click for Details."));
								cmdstate.setDone(true);
								localAIFComponentContextList.add(localAIFComponentContext);
								m_commandTargetStateList.add(cmdstate);


								for (Map.Entry<String, String> entry : modifedactvalueMap.entrySet())//modifedvalueMap.entrySet())
								{
									/* ClassificationPropertyValue[] ico_prop_values1 = new ClassificationPropertyValue[1];
		  			    System.out.println(entry.getKey() + " = " + entry.getValue());        
		  		        ico_prop_values1[0] = new ClassificationPropertyValue();
		  		        ico_prop_values1[0].dbValue = (String) entry.getValue();
									 */
									String attid=(String) entry.getKey();
									String attval=(String) entry.getValue();
									String attname=attrNameIDMap.get(attid);
									cmdstate=new CommandTargetState(localAIFComponentContext,null);
									cmdstate.setCaughtException(new TCException("["+attid+"]"+attname+"-->"+attval));
									cmdstate.setDone(true);

									m_commandTargetStateList.add(cmdstate);

								}


							}

						}
					}
				}
			}
		}
		if(localAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localAIFComponentContextList.toArray(new AIFComponentContext[localAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			TCSession session=(TCSession) app.getSession();

			TMLDataBean databean= new TMLDataBean(parent_item.getSession(), null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside update status printing step6");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList);

			TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },2,null);
			System.out.println("inside update status printing step ccvselList "+ccvselList.size());
			//for(int t=0;t<ccvList.size();t++)
			LinkedHashMap <TCComponentItemRevision,String> ccvResult = new LinkedHashMap <TCComponentItemRevision,String>();
			boolean[] successList =new boolean[ccvselList.size()] ;
			for(int t=0;t<ccvselList.size();t++)
			{

				TCComponentItemRevision ccv_item=(TCComponentItemRevision) getTCComponent(ccvselList.get(t));//ccvList.get(t);

				try
				{
					String ccv_itemID=ccv_item.getPropertyDisplayableValue("item_id");

					String ccv_revid=ccv_item.getPropertyDisplayableValue("item_revision_id");
					String object_id_ccv=ccv_itemID;//+"/"+ccv_revid;

					ModuleNum=ccv_itemID;
					System.out.println("ModuleNum="+ModuleNum +"object_id_ccv="+object_id_ccv);
					//ClassificationObject clsobjs=bomexpansion.getClassificationObject(ccv_item);
					ClassificationObject clsobjs=bomexpansion.getClassificationObject(ccv_item,SelBusUnit);

					TCComponentItem clsitem=null;
					try {
						clsitem=ccv_item.getItem();
					} catch (TCException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					CreateOrUpdateICOSample icos_ccv=new  CreateOrUpdateICOSample(clsitem,clsobjs, ModuleAddress, object_id_ccv, ModuleNum,namevalueP, arrayAttr,session);

					if(clsobjs!=null && lastvalcopy.isValue()==true)
						icos_ccv.createAndUpdateICO();

					else
					{
						if(firstccvclsobj!=null && firstccvclsobj.length>0)
							icos_ccv.copyICO(firstccvclsobj[0],attrNameIDMap);




					}

					//ServiceData data1=icos_ccv.getServiceData();

					//Added by rajesh on 22/05/2019
					if(SelParttype.equals("Module")==false)
					{

						if(ccv_item!=null)
						{
							//ErcDMLObj=TechSpecUtil.SecondaryToPrimaryObj("CMHasSolutionItem",ccv_item);

							ErcDMLObj=TechSpecUtil.getAttachedDML(ccv_item,"CMHasSolutionItem",/*"Update VC attributes and Tech Spec Header""Update VC attributes*"*/step_wf);

							System.out.println("before call func ChangeHistObjCre1 with input ErcDMLObj="+ErcDMLObj +"ccv_item="+ccv_item);
							if(ccv_item instanceof TCComponentItemRevision)
							{
								if(bypassUsrflg==false || isBypass==false)
								{
								try {
									ChangeHistObjCre((TCSession) session,ccv_item,ErcDMLObj,false);
								} catch (TCException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								//System.out.println("End call func ChangeHistObjCre1 ");
								}
								//End 
							}
						}

						ServiceData data1=icos_ccv.getServiceData();
						if(data1!=null && data1.sizeOfPartialErrors()>0)
						{

							isSuccess=false;
							String err_msg="";
							String[] err_msgs=data1.getPartialError(0).getMessages();
							if(err_msgs!=null && err_msgs.length>0)
							{
								err_msg =err_msgs[0];
								ccvResult.put(ccv_item, err_msg);
								successList[t]=false;
							}
							MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updation ERROR  !!"+ ccv_item.toDisplayString()+":"+err_msg,"INFORAMTION",SWT.ICON_ERROR);
							break;
						}

						else
						{

							ccvResult.put(ccv_item, "Classification Successfully Copied from :"+ItemRev.toDisplayString());
							successList[t]=true;

						}
					}

				} catch (NotLoadedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			if(ccvList.size()>0)
			{
				if(isSuccess==true)
				{


					constructMultiInfoDialog(ccvResult,successList,"All child SVR having same VC attribute value .\nplease check the classification value for all attached CCVs then update accordingly!!");
					//MessageBox.post(PlatformHelper.getCurrentShell(),"All child SVR having same VC attribute value .\nplease check the classification value for all attached CCVs then update accordingly!!","INFORAMTION",SWT.ICON_INFORMATION);

				}
			}	
			//CreateDataset(); //added by Rajesh on 02052019

			//Added by rajesh on 22/05/2019

			System.out.println("before call func ChangeHistObjCre2 with input ErcDMLObj="+ErcDMLObj +"selectedObj="+selectedObj);
			if(selectedObj instanceof TCComponentItemRevision)
			{
				try 
				{
					ErcDMLObj=TechSpecUtil.getAttachedDML((TCComponentItemRevision) selectedObj,"CMHasSolutionItem",/*"Update VC attributes and Tech Spec Header""Update VC attributes*"*/step_wf);

					if(bypassUsrflg==false || isBypass==false)
					{
					ChangeHistObjCre((TCSession) session,selectedObj,ErcDMLObj,false);
					

					System.out.println("End call func ChangeHistObjCre2 ");
					}
				}
				catch (TCException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//End 

			/*  TCComponentDataset dataset=null;

	  		String ErcDmlNo;
				try {
					if(ErcDMLObj!=null)
					{
						ErcDmlNo = ErcDMLObj.getTCProperty("item_id").getDisplayableValue();
						//ErcDmlNo="10PP131333"; //need to delete before check in
						System.out.println("111ErcDmlNo="+ErcDmlNo);
						File UpdatedRptHist=createClsUpdatedHistoryRpt(ErcDmlNo);
						String selectedobjName=selectedObj.getTCProperty("item_id").getDisplayableValue();
						String RevSeq=selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
						RevSeq=RevSeq.replace(";", "_");
						System.out.println("RevSeq="+RevSeq);
						String datasetname=selectedobjName+"_"+RevSeq+"_ModifiedBy_"+ErcDmlNo;

						System.out.println("B4 Dataset Qry call");
						TCComponent datasetExist=TechSpecUtil.qryObj(session,"Dataset Name","Dataset Name",datasetname);
						System.out.println("After Dataset Qry call");
						if(datasetExist!=null)
						{
							System.out.println("Dataset already available in system, only Named refrence will attach\n");
							System.out.println("Going to Add name refrence with dataset\n");
							addNamedReference(UpdatedRptHist,(TCComponentDataset)datasetExist);
						}
						else
						{
						System.out.print("111B4 CreateDataset func call with datasetname="+datasetname);						
						dataset=CreateDataset((TCComponentItemRevision)selectedObj,datasetname,selectedObj.getTCProperty("object_name").getDisplayableValue(),UpdatedRptHist);
						System.out.println("Going to Add name refrence with dataset\n");
						addNamedReference(UpdatedRptHist,dataset);
						}
						//getSingleGetDatasetWriteTicketsInputData(UpdatedRptHist,dataset);
						//System.out.println("Going to Add name refrence with dataset\n");
						//addNamedReference(UpdatedRptHist,dataset);
						System.out.println("Added name refrence with dataset\n");
					}
				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 */
			//System.out.print("1111After CreateDataset func call");
		}
		else
		{
			MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updated successfully  !!","INFORAMTION",SWT.ICON_INFORMATION);






		}

		/*
		 * System.out.println("moderrlist.length() " +moderrlist.length()
		 * +" moderrlist="+moderrlist); if(moderrlist.length()>0) {
		 * modulemandatorylist.clear(); errMsgStr=errMsgStr.concat("\n");
		 * errMsgStr=errMsgStr.concat(moderrlist); // errMsgStr=errMsgStr.concat("\t");
		 * System.out.println("outside loop errMsgStr " +errMsgStr);
		 * MessageBox.post(parentShell,errMsgStr,"WARNING",SWT.ICON_WARNING);
		 * //UpdateTechSpecDialog.this.close(); moderrlist=null;
		 * 
		 * }
		 */
		String SelobjType= selectedObj.getType();

		System.out.println("\nSelobjType="+SelobjType);
		String SelectedPartType=null;
		try {
			SelectedPartType = selectedObj.getPropertyDisplayableValue("t5_PartType");
		} catch (NotLoadedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("SelectedPartType:-"+SelectedPartType +"SelectedPartType.matches(\"Vehicle\")="+SelectedPartType.matches("Vehicle"));
		if(SelectedPartType.equals("Vehicle") || SelectedPartType.equals("Configurable VC") || SelectedPartType.equals("Vehicle Combination CR") || SelobjType.equals("T5_TSCompRevision"))
		{
			MessageBox.post(PlatformHelper.getCurrentShell(),"Kindly fill/update Word file attach to Tech Spec Header of Vehicle/VC/CCV revision available under folder <Has Tech Spec> ","INFORAMTION",SWT.ICON_INFORMATION);
		}
		System.out.println("Update VC Attributes step completed!!");



		super.okPressed();
	}


	@Override
	protected void cancelPressed() {


		boolean buttonpressed=false;
		int buttonpressed1=-1;
		localAIFComponentContextList.clear();
		m_commandTargetStateList.clear();

		ArrayList treelist=(ArrayList) treeViewer.getInput();
		System.out.println("treelist.Size()="+treelist.size());
		if(treelist.size()<=0 )
		{
			buttonpressed=true;
		}
		for(int i=0;i<treelist.size();i++)
		{
			if(treelist.get(i) instanceof ClassificationTreeLine)
			{
				ClassificationTreeLine treeObj=(ClassificationTreeLine) treelist.get(i);


				TCComponentItemRevision item_rev=treeObj.getItemrev();

				try {
					String parttype=treeObj.getItemrev().getTCProperty("t5_PartType").getDisplayableValue();
					if(parttype.equals("Module"))
					{
						continue;
					}

				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


				try {

					parent_item=item_rev.getItem();
					localAIFComponentContext=new AIFComponentContext(parent_item,item_rev,"structure_revision");
					System.out.println("fggdfdfsdsasasa:::"+localAIFComponentContext.toString());
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

if( modifedactvalueMap.entrySet().size()>0)
{
				CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
				cmdstate.setCaughtException(new TCException("Below Values are modified. Do you want to Close ?"));
				cmdstate.setDone(true);
				localAIFComponentContextList.add(localAIFComponentContext);
				m_commandTargetStateList.add(cmdstate);


				for (Map.Entry<String, String> entry : modifedactvalueMap.entrySet())//modifedvalueMap.entrySet())
				{
					/* ClassificationPropertyValue[] ico_prop_values1 = new ClassificationPropertyValue[1];
			    System.out.println(entry.getKey() + " = " + entry.getValue());        
		        ico_prop_values1[0] = new ClassificationPropertyValue();
		        ico_prop_values1[0].dbValue = (String) entry.getValue();
					 */
					String attid=(String) entry.getKey();
					String attval=(String) entry.getValue();
					String attname=attrNameIDMap.get(attid);
					cmdstate=new CommandTargetState(localAIFComponentContext,null);
					cmdstate.setCaughtException(new TCException("["+attid+"]"+attname+"-->"+attval));
					System.out.println("["+attid+"]"+attname+"-->"+attval);
					cmdstate.setDone(true);

					m_commandTargetStateList.add(cmdstate);

				}
			}
				/*

	       if(localAIFComponentContextList.size()>0)
		  	{
		  	AIFComponentContext[] selobjs=localAIFComponentContextList.toArray(new AIFComponentContext[localAIFComponentContextList.size()]);
		  	 System.out.println("selobjs="+selobjs.length);
		  	AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

           TCSession session=(TCSession) app.getSession();


           TMLDataBean databean= new TMLDataBean(parent_item.getSession(), null,selobjs,exe_evt);
           databean.setTargetContexts(selobjs);

            MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
           System.out.println("inside update status printing step");
           paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList);

           buttonpressed=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.YES_LABEL , IDialogConstants.NO_LABEL },3);
		  	}
		  	else
	  	{
		  		MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updated successfully  !!","INFORAMTION",SWT.ICON_INFORMATION);
		  	}
				 */
			}
		}

		if(localAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localAIFComponentContextList.toArray(new AIFComponentContext[localAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			TCSession session=(TCSession) app.getSession();


			TMLDataBean databean= new TMLDataBean(parent_item.getSession(), null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside localAIFComponentContextList update status printing step");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList);

			//buttonpressed=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.YES_LABEL , IDialogConstants.NO_LABEL },3,null);
			buttonpressed1=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.YES_LABEL , IDialogConstants.NO_LABEL },3,null);
		}
		else
		{
			System.out.println("in cancel button buttonpressed1::"+buttonpressed1 +" isUpdatable= "+isUpdatable);
			if(isUpdatable==true)
			{
			MessageBox.post(PlatformHelper.getCurrentShell(),"No Value to Update !!","INFORAMTION",SWT.ICON_INFORMATION);
			}
			//MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updated successfully  !!","INFORAMTION",SWT.ICON_INFORMATION);
		} 	
		System.out.println("buttonpressed1::"+buttonpressed1);
		if(buttonpressed1==0  || buttonpressed || buttonpressed1==-1)//if(buttonpressed)
			super.cancelPressed();
	}

	//used to set the Title in the dialog window
	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Technical-Specification Window");

	} 
}

class TreeContentProvider implements ITreeContentProvider {
	@Override
	public boolean hasChildren(Object element) {
		if(element instanceof ClassificationTreeLine)
		{

			return ((ClassificationTreeLine)element).getAttrList().size()==0? false:true;
		}

		else if(element instanceof ClassificationAnnotationLine)
		{

			return ((ClassificationAnnotationLine)element).getAttrList().size()==0? false:true;
		}
		else
			return false;
		/*if(element instanceof ClassificationTreeLine)
    	{

    		ClassificationTreeLine p = (ClassificationTreeLine) element;
    		TCComponentItemRevision tcrev= p.getItemrev();
    		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
    		TCSession session=(TCSession) app.getSession();
    		GetClassifiedAttr getProps= new GetClassifiedAttr(tcrev,session);
    		String modaddress=p.getModuleAddress();
    		if(getProps!=null)
    		{
    			try {
    				if(getProps.getICOProps()!=null)
					modaddress=getProps.getICOProps().getCid();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		ArrayList<ClassificationTableLine> classificationList=new ArrayList<ClassificationTableLine>();
			try {
				classificationList = new GetModuleAttributesForClasses(modaddress,session).testgetGetAttributesForClasses();
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

    		//for(int k=0;k<classificationList.size();k++)
    		//{

    		//	classificationList.get(k).setParent(p);
    		//}
    		//p.setAttrList(classificationList);
    		//return classificationList.size()==0? false:true;
    	}
    	else
    	{
    	return false;
    	}*/
	}

	@Override
	public Object getParent(Object element) {
		if(element instanceof ClassificationAnnotationLine)
		{
			ClassificationAnnotationLine p = (ClassificationAnnotationLine) element;

			return p.getParent();
		}

		else if(element instanceof ClassificationTableLine)
		{
			ClassificationTableLine p = (ClassificationTableLine) element;

			return p.getParent();
		}

		return null;
	}

	@Override
	public Object[] getElements(Object inputElement) {


		return ArrayContentProvider.getInstance().getElements(inputElement);
	}

	@Override
	public Object[] getChildren(Object parentElement) {

		if(parentElement instanceof ClassificationTreeLine)
		{
			ClassificationTreeLine p = (ClassificationTreeLine) parentElement;
			return p.getAttrList().toArray();
		}

		else if (parentElement instanceof ClassificationAnnotationLine)
		{
			ClassificationAnnotationLine p = (ClassificationAnnotationLine) parentElement;
			return p.getAttrList().toArray();
		}
		else
			return null;

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		// TODO Auto-generated method stub

	}
}

class TreeTableLabelProvider 	extends LabelProvider 	implements ITableLabelProvider {

	private TreeViewer treeViewer;






	/*static {
imageRegistry.put("smileImage", ImageDescriptor.createFromFile(
TableViewerExample.class,
"smile.jpg"));
}*/
	public TreeTableLabelProvider(TreeViewer treeViewer) {
		this.treeViewer = treeViewer;
	}




	public String getColumnText(Object element, int columnIndex) {
		
		

		if(element instanceof ClassificationTableLine)
		{
			
			ClassificationTableLine tabline = (ClassificationTableLine) element;
			System.out.println("1columnIndex="+columnIndex);
			//UsrData1=tabline.getParent().getAnnotation();
			//System.out.println("inside getColumnText func with UsrData1="+UsrData1);
			//if(info.contains(UsrData1)==false)
			//{
				switch (columnIndex) {
				case 0:
					System.out.println("1tabline.getSrlNo()="+tabline.getSrlNo());
					return tabline.getSrlNo()+"";
					/* case 1:
	    	 System.out.println("1tabline.getAnnotation()="+tabline.getParent().getAnnotation());
		      return tabline.getParent().getAnnotation();*/
				case 2:
					System.out.println("1tabline.getAttrID()="+tabline.getAttrID());
					return tabline.getAttrID();
				case 3:
					System.out.println("1tabline.getAttrName()="+tabline.getAttrName());
					return tabline.getAttrName();		      
				case 4:
					System.out.println("1abline.getAttrValue()="+tabline.getAttrValue());
					return tabline.getAttrValue();
				case 5:
					System.out.println("1abline.UnitName()="+tabline.getUnit());
					return tabline.getUnit();
				case 6:
					System.out.println("1abline.getLovID()="+tabline.getLovID());
					return tabline.getLovID();

				case 7:
					System.out.println("1abline.getArray()="+tabline.getArraySize());
					return tabline.getArraySize()+"";
				}
			//}
		}

		else if(element instanceof ClassificationAnnotationLine)
		{
			ClassificationAnnotationLine tabline = (ClassificationAnnotationLine) element;
			System.out.println("1columnIndex="+columnIndex);
			switch (columnIndex) {

			case 1:
				System.out.println("1tabline.getAnnotation()="+tabline.getAnnotation());
				return tabline.getAnnotation();
			}
		}
		return "";
	}




	@Override
	public Image getColumnImage(Object arg0, int arg1) {
		// TODO Auto-generated method stub
		return null;
	}









}




class TreeTableContentProvider implements IStructuredContentProvider {
	public Object[] getElements(Object inputElement) {
		ArrayList<ClassificationTableLine> list= (ArrayList<ClassificationTableLine>) inputElement;

		Object[] obj=list.toArray();

//		for(int x=0;x<obj.length;x++)
//		{
//
//			System.out.println("GHH::"+obj[x].toString());
//
//		}
		return list.toArray();
	}

	public void dispose() {
	}



	@Override
	public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub

	}
}
