package com.tml.techspec.dialogs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import javax.swing.JButton;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.classification.icadmin.ICAAdminApplication;
import com.teamcenter.rac.classification.icadmin.ICAdminContext;
import com.teamcenter.rac.classification.icadmin.ICAdminPanel;
import com.teamcenter.rac.classification.icadmin.keylov.ICAKeyLOVContext;
import com.teamcenter.rac.kernel.ListOfValuesInfo;
import com.teamcenter.rac.kernel.TCClassificationService;
import com.teamcenter.rac.kernel.TCComponentListOfValues;
import com.teamcenter.rac.kernel.TCComponentListOfValuesType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.ics.ICSAdminClass;
import com.teamcenter.rac.kernel.ics.ICSAdminClassAttribute;
import com.teamcenter.rac.kernel.ics.ICSFormat;
import com.teamcenter.rac.kernel.ics.ICSKeyLovValue;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.tml.classification.modules.ClassificationLineProvider;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.ClsKeyLovTableLine;
import com.tml.classification.modules.ClsLovLineProvider;
import com.tml.classification.modules.TMLKeyLOVCreateorUpdateOperation;
import com.tml.classification.modules.TechSpecUtil;
import org.eclipse.jface.viewers.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class TMLCreateUpdateLOVDialog extends TitleAreaDialog {
	private Text text;
	private Text text_1;
	private Table table;
	private Button btnNewButton;
	private int tableitemcount;
	private Text searchText;
	private com.tml.techspec.dialogs.SearchLovViewerFilter searchFilter;
	private TableViewer tableViewer;
	private Shell parentShell;
	private Text text_2;
	private ICAdminContext admintx;
	private ICAKeyLOVContext m_context;
	private ICAAdminApplication icsapp;
	private TreeMap<Object, String> keyvalue;
	private TreeMap<String, String> keyvalue1;
	private ClsKeyLovTableLine lovTable;
	private ArrayList<ClsKeyLovTableLine> ClsKeyLovList;
	private ArrayList<ClsKeyLovTableLine> MasterClsKeyLovList;
	private ClsLovLineProvider tabLineModel;
	private int k;
	protected TreeViewer treeViewer;
	private SearchViewerFilter SearchLovViewerFilter;
	// private TCSession session;

	/**
	 * Create the dialog.
	 * 
	 * @param parentShell
	 */
	public TMLCreateUpdateLOVDialog(Shell parentShell, ICAAdminApplication icsapp) {
		super(parentShell);
		this.parentShell = parentShell;
		// this.session=session;
		this.icsapp = icsapp;
		keyvalue = new TreeMap<Object, String>();
		keyvalue1 = new TreeMap<String, String>();
		ClsKeyLovList = new ArrayList<ClsKeyLovTableLine>();
		MasterClsKeyLovList = new ArrayList<ClsKeyLovTableLine>();

	}

	public boolean isInteger(Object val) {

		boolean isnum = false;
		try {
			Integer.parseInt(val.toString());
			isnum = true;
		} catch (NumberFormatException e) {
			isnum = false;
		}

		return isnum;
	}

	public boolean isDouble(Object val) {

		boolean isnum = false;
		try {
			Double.parseDouble(val.toString());
			isnum = true;
		} catch (NumberFormatException e) {
			isnum = false;
		}

		return isnum;
	}

	/**
	 * Create contents of the dialog.
	 * 
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		setTitle("Technical specification LOV's value list");
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));

		Group group = new Group(container, SWT.NONE);
		group.setBounds(0, 10, 803, 495);

		text = new Text(group, SWT.BORDER);
		/*
		 * text.addSelectionListener(new SelectionAdapter() {
		 * 
		 * @Override public void widgetSelected(SelectionEvent e) {
		 * 
		 * try {
		 * 
		 * admintx=new ICAdminContext(icsapp,"ICA");
		 * admintx.getKeyLOVContext().getICSAdminKeyLOV().load(text.getText());
		 * m_context=admintx.getKeyLOVContext();
		 * text_1.setText(admintx.getKeyLOVContext().getICSAdminKeyLOV().getName());
		 * 
		 * ICSKeyLovValue[] arrayOfICSKeyLovValue =
		 * m_context.getICSAdminKeyLOV().getEntries(true);
		 * 
		 * for(int k=0;k<arrayOfICSKeyLovValue.length;k++) {
		 * 
		 * String key=arrayOfICSKeyLovValue[k].getKey(); String
		 * val=arrayOfICSKeyLovValue[k].getValue();
		 * System.out.println("HH:"+key+":"+val); TableItem item = new TableItem(table,
		 * SWT.NONE);
		 * 
		 * 
		 * item.setText(0, key); item.setText(1, val);
		 * 
		 * 
		 * 
		 * } } catch (Exception e1) { // TODO Auto-generated catch block
		 * e1.printStackTrace(); }
		 * 
		 * 
		 * 
		 * } });
		 */
		text.setBounds(348, 27, 78, 26);

		text_1 = new Text(group, SWT.BORDER);
		text_1.setEditable(false);
		text_1.setBounds(432, 27, 265, 26);

		Label lblVcClass = new Label(group, SWT.NONE);
		lblVcClass.setBounds(10, 30, 70, 23);
		lblVcClass.setText(" VC Class");

		Combo combo = new Combo(group, SWT.NONE);
		combo.setBounds(86, 27, 116, 28);
		// combo.add("HCV");
		// combo.add("MCV");
		// combo.add("CAR");
		combo.setFocus();
		AbstractAIFUIApplication app = AIFUtility.getCurrentApplication();

		TCSession session = (TCSession) app.getSession();
		TCComponentListOfValuesType TypeLov;
		try {
			TypeLov = (TCComponentListOfValuesType) session.getTypeComponent("ListOfValues");
			TCComponentListOfValues[] BusUnitLov = TypeLov.find("T5_CommnSet");
			if (BusUnitLov[0] != null) {
				ListOfValuesInfo LOVvalues = BusUnitLov[0].getListOfValues();
				String[] listValues = LOVvalues.getLOVDisplayValues();
				int listvaluelength = listValues.length;
				// VcSubClass.add("");
				for (int t = 0; t < listvaluelength; t++) {
					System.out.print("\nOOOOOOOOOOOOOOOOO");
					System.out.println("\nBusUnitLov=" + listValues[t]);
					combo.add(listValues[t]);

				}
			}

		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		// combo.setEnabled(true);
		Label lblLovId = new Label(group, SWT.NONE);
		lblLovId.setBounds(208, 30, 134, 20);
		lblLovId.setText("TCE/TCUA Attribute ID");
		/*
		 * Label lblBomFilePathcsv = new Label(group, SWT.NONE);
		 * lblBomFilePathcsv.setBounds(20, 77, 133, 26);
		 * lblBomFilePathcsv.setText("LOV File Path(.csv) :");
		 * 
		 * Button btnBrowse = new Button(group, SWT.NONE); btnBrowse.setLocation(223,
		 * 75); btnBrowse.setSize(75, 25); btnBrowse.addSelectionListener(new
		 * SelectionAdapter() {
		 * 
		 * @Override public void widgetSelected(SelectionEvent e) {
		 * 
		 * FileDialog opendlg = new FileDialog(TMLCreateUpdateLOVDialog.this.getShell(),
		 * SWT.OPEN); String filenamefilter = "*.csv";
		 * opendlg.setText("Select the LOV File :"); opendlg.setFilterNames(new String[]
		 * { "Comma seperated CSV Files (*.csv*)" }); opendlg.setFilterExtensions(new
		 * String[] { "*.csv" }); // opendlg.setFilterPath("c:\\"); // Windows path //
		 * opendlg.setFileName(filenamefilter); String path = opendlg.open(); if (path
		 * == null) return; text_2.setText(path); btnNewButton.setEnabled(true);
		 * 
		 * File fl = new File(path);
		 * 
		 * try { BufferedReader reader = new BufferedReader(new FileReader(path));
		 * 
		 * String line; while ((line = reader.readLine()) != null) { StringTokenizer s1
		 * = new StringTokenizer(line, ",");
		 * 
		 * String key = s1.nextToken().toString(); String val =
		 * s1.nextToken().toString(); if (keyvalue1.get(val) != null) continue;
		 * TableItem item = new TableItem(table, SWT.NONE); item.setText(0, (k + 1) +
		 * ""); item.setText(1, key); item.setText(2, val); if (isInteger(key))
		 * keyvalue.put(new Integer(key), val); else keyvalue.put(key, val);
		 * keyvalue1.put(val, key); k++;
		 * 
		 * } } catch (IOException e1) { // TODO Auto-generated catch block
		 * e1.printStackTrace(); }
		 * 
		 * } }); btnBrowse.setText("Browse...");
		 * 
		 * text_2 = new Text(group, SWT.BORDER); text_2.setEditable(false);
		 * text_2.setBounds(309, 77, 258, 26);
		 */
		tableViewer = new TableViewer(group, SWT.BORDER | SWT.FULL_SELECTION);
		table = tableViewer.getTable();
		table.setLocation(62, 121);
		table.setSize(693, 364);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);

		TableViewerColumn tableViewerColumn = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnSlNo = tableViewerColumn.getColumn();
		tblclmnSlNo.setWidth(57);
		tblclmnSlNo.setText("Sl No");

		TableViewerColumn tableViewerColumn_1 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnLovKey = tableViewerColumn_1.getColumn();
		tblclmnLovKey.setWidth(147);
		tblclmnLovKey.setText("LOV Key");

		tableViewerColumn_1.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if (element instanceof ClsKeyLovTableLine) {
					ClsKeyLovTableLine p = (ClsKeyLovTableLine) element;
					return p.getlovKey();
				}
				return null;
			}
		});

		TableViewerColumn tableViewerColumn_2 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnLovValue = tableViewerColumn_2.getColumn();
		tblclmnLovValue.setWidth(436);
		tblclmnLovValue.setText("LOV Value");

		tableViewerColumn_2.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if (element instanceof ClsKeyLovTableLine) {
					ClsKeyLovTableLine p = (ClsKeyLovTableLine) element;
					return p.getlovVal();
				}
				return null;
			}
		});

		Button btnNewButton_1 = new Button(group, SWT.NONE);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				table.removeAll();
				keyvalue.clone();
				keyvalue1.clear();
				ClsKeyLovList = new ArrayList<ClsKeyLovTableLine>();
				MasterClsKeyLovList = new ArrayList<ClsKeyLovTableLine>();
				try {
					if (text.getText() == null || text.getText().length() <= 0) {
						MessageBox.post(PlatformHelper.getCurrentShell(), "Attribute ID input is mandatory field !! ",
								"INFORAMTION", SWT.ICON_INFORMATION);
						return;
					}
					String attrid = text.getText();
					int attridInt = Integer.parseInt(attrid);
					// String keyLovId = "-" + text.getText();
					admintx = new ICAdminContext(icsapp, "ICA");
					ICAdminPanel icspanel = null;
					ICSAdminClass icsadmin = null;
					TCSession session = new TCSession();
					// ClassificationService clsService = ClassificationService.getService(session);

					String Busunit = combo.getText();
					if (Busunit == null || Busunit.length() <= 0) {
						MessageBox.post(PlatformHelper.getCurrentShell(),
								"VC class input is mandatory field choose value from list ", "INFORAMTION",
								SWT.ICON_INFORMATION);
						return;
					}

					String RetUAAttrID = null;
					// table.removeAll();
					if (text.getText().length() < 4) {
						RetUAAttrID = TechSpecUtil.getTSClsAttrIDFunc(Busunit, attrid);
					} else {
						RetUAAttrID = text.getText();
					}
					System.out.println("RetUAAttrID= " + RetUAAttrID);

					if (RetUAAttrID == null || RetUAAttrID.length() <= 0) {
						MessageBox.post(PlatformHelper.getCurrentShell(),
								"Input VC class is not configured for LOV value list , Pls contact PLM Admin Team ",
								"INFORAMTION", SWT.ICON_INFORMATION);
						return;
					}

					int NewattridInt = Integer.parseInt(RetUAAttrID);
					System.out.println("NewattridInt= " + NewattridInt);
					TCClassificationService classServ = session.getClassificationService();

					icsadmin = classServ.newICSAdminClass();
					// icsadmin.load("*");
					// ICSAdminClassAttribute icsatt=icsadmin.getAttribute(attridInt);
					ICSAdminClassAttribute icsatt = icsadmin.addAttribute(NewattridInt);
					System.out.println("attrLOVID= " + icsatt.getFormat(NewattridInt));
					ICSFormat keyLovId = icsatt.getFormat(NewattridInt);
					String lovname = keyLovId.toString();
					System.out.println("lovname= " + lovname);

					if (lovname == null || lovname.contains("-") == false) {
						MessageBox.post(
								PlatformHelper.getCurrentShell(), "No LOV exist for input Attribute= " + text.getText()
										+ " w.r.t business unit [" + Busunit + "]",
								"INFORAMTION", SWT.ICON_INFORMATION);
						return;
					}
					// Fnd0AdminLOVValue adminLOVValue = new Fnd0AdminLOVValue();
					// System.out.println("attrID= " +
					// admintx.getKeyLOVContext().getDictionaryPanel().getFormat(attridInt));
					// admintx.getKeyLOVContext().getICSAdminKeyLOV().load(text.getText());

					try {
						admintx.getKeyLOVContext().getICSAdminKeyLOV().load(lovname);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						MessageBox.post(
								PlatformHelper.getCurrentShell(), "No LOV exist for input Attribute= " + text.getText()
										+ " w.r.t business unit [" + Busunit + "]",
								"INFORAMTION", SWT.ICON_INFORMATION);
						return;

					}
					m_context = admintx.getKeyLOVContext();
					text_1.setText(admintx.getKeyLOVContext().getICSAdminKeyLOV().getName());

					ICSKeyLovValue[] arrayOfICSKeyLovValue = m_context.getICSAdminKeyLOV().getEntries(true);
					ArrayList<ClsKeyLovTableLine> listv = new ArrayList<ClsKeyLovTableLine>();
					// lovTable=new ClsKeyLovTableLine();
					for (k = 0; k < arrayOfICSKeyLovValue.length; k++) {

						String key = arrayOfICSKeyLovValue[k].getKey();
						String val = arrayOfICSKeyLovValue[k].getValue();
						System.out.println("HH:" + key + ":" + val);
						// listv.add(new ClsKeyLovTableLine((k + 1) + "", key, val));
						ClsKeyLovList.add(new ClsKeyLovTableLine((k + 1) + "", key, val));
						MasterClsKeyLovList.add(new ClsKeyLovTableLine((k + 1) + "", key, val));
						TableItem item = new TableItem(table, SWT.NONE);

						item.setText(0, (k + 1) + "");
						item.setText(1, key);
						item.setText(2, val);

						if (isInteger(key)) {
							// keyvalue.put(new Integer(key), val);
							keyvalue.put(key, val);
							// ClsKeyLovList.add(new ClsKeyLovTableLine((k + 1) + "", key, val));
						}
//						else if(isDouble(key))
//						{
//							keyvalue.put(new Double (key), val);
//						}
						else
							keyvalue.put(key, val);
						// ClsKeyLovList.add(new ClsKeyLovTableLine((k + 1) + "", key, val));
						keyvalue1.put(val, key);

						lovTable = new ClsKeyLovTableLine((k + 1) + "", key, val);
						// System.out.println("lovTable:" + lovTable.getlovKey() + ":" +
						// lovTable.getlovVal());
						// ClsKeyLovList.add(lovTable);
						// ClsKeyLovList.add(new ClsKeyLovTableLine((k + 1) + "", key, val));
						// ClsKeyLovList.add(new ClsKeyLovTableLine((k + 1) + "", key, val));
						// ClsKeyLovList.add(lovTable);
					}

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				/*
				 * ICSKeyLovValue[] arrayOfICSKeyLovValue1 =
				 * m_context.getICSAdminKeyLOV().getEntries(true); ArrayList<ClsKeyLovTableLine>
				 * list = new ArrayList<ClsKeyLovTableLine>(); for (int ki = 0; ki <
				 * arrayOfICSKeyLovValue1.length; ki++) {
				 * 
				 * String key1 = arrayOfICSKeyLovValue1[ki].getKey(); String val1 =
				 * arrayOfICSKeyLovValue1[ki].getValue();
				 * 
				 * System.out.println("ClsKeyLovList HH:" + (ki + 1) + "" + ":" + key1 + ":" +
				 * val1); // ClsKeyLovList list = new ClsKeyLovList(); list.add(new
				 * ClsKeyLovTableLine((ki + 1) + "", key1, val1)); }
				 */

				System.out.println("ClsKeyLovList:" + ClsKeyLovList.toString());
				// System.out.println("lovTable:" + lovTable.getlovKey() + ":" +
				// lovTable.getlovVal());
//				int tabsize = Integer.parseInt(lovTable.getSrlNo());
//				for (int p = 0; p < tabsize; p++) {
//					ClsKeyLovList.add(
//							new ClsKeyLovTableLine(lovTable.getSrlNo(), lovTable.getlovKey(), lovTable.getlovVal()));
//					System.out.println("ClsKeyLovList:" + ClsKeyLovList.get(p));
//				}

				// ClsKeyLovList.add(lovTable);
				// tableViewer.setContentProvider(ArrayContentProvider.getInstance());// new
				// tableViewer.TableLovContentProvider()); // tableViewer.setLabelProvider(new
				// TablLabelProvider(tableViewer)); tableViewer.setInput(ClsKeyLovList);

				tabLineModel = new ClsLovLineProvider();
				for (int i = 0; i < ClsKeyLovList.size(); i++) {
					System.out.println("ClsKeyLovList=" + ClsKeyLovList.get(i));
				}
				tabLineModel.setClassificationLine(ClsKeyLovList);

				// tableViewer.setContentProvider(new TableLovContentProvider());
				// tableViewer.setContentProvider(ArrayContentProvider.getInstance());// new
				// tableViewer.setInput(ClsKeyLovList);

			}
		});

		btnNewButton_1.setBounds(703, 25, 90, 30);
		btnNewButton_1.setText("Get LOV");

		Label lblSearchLabel = new Label(group, SWT.NONE);
		lblSearchLabel.setBounds(86, 81, 90, 20);
		lblSearchLabel.setText("Search Text");

		// tableViewer.setLabelProvider(new
		// AttributeLovTableLabelProvider(tableViewer));

		// tableViewer.setLabelProvider(new
		// AttributeLovTableLabelProvider(tableViewer));

		// tableViewer.setContentProvider(new TableLovContentProvider());
		tableViewer.setLabelProvider(new AttributeTableLabelProvider(tableViewer));
		tableViewer.setContentProvider(new TableContentProvider());
		tableViewer.setInput(ClsKeyLovList);
		// treeViewer.setInput(ClsKeyLovList);
		// searchFilter = new LOVSearchViewerFilter4LovList();

		searchText = new Text(group, SWT.BORDER);
		searchText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) 
			{
				String keyword = (searchText.getText().trim().toLowerCase());
				System.out.println("mannual search keyword=" + keyword);
				if(keyword.length()>0)
				{
					table.removeAll();
					ClsKeyLovList = new ArrayList<ClsKeyLovTableLine>();
				}
				else if(keyword.length()==0)
				{
					table.removeAll();
					for (int i = 0; i < MasterClsKeyLovList.size(); i++) 
					{
						ClsKeyLovList.add(new ClsKeyLovTableLine(MasterClsKeyLovList.get(i).getSrlNo(),MasterClsKeyLovList.get(i).getlovKey(), MasterClsKeyLovList.get(i).getlovVal()));
						TableItem item = new TableItem(table, SWT.NONE);
						item.setText(0, MasterClsKeyLovList.get(i).getSrlNo());
						item.setText(1, MasterClsKeyLovList.get(i).getlovKey());
						item.setText(2, MasterClsKeyLovList.get(i).getlovVal());
					}
					return;
				}
				for (int i = 0; i < MasterClsKeyLovList.size(); i++)
				{
					if (MasterClsKeyLovList.get(i).getlovVal().toLowerCase().contains(keyword)||
						MasterClsKeyLovList.get(i).getlovVal().toUpperCase().contains(keyword))
					{
						
						ClsKeyLovList.add(new ClsKeyLovTableLine(MasterClsKeyLovList.get(i).getSrlNo(),MasterClsKeyLovList.get(i).getlovKey(), MasterClsKeyLovList.get(i).getlovVal()));
						TableItem item = new TableItem(table, SWT.NONE);

						item.setText(0, MasterClsKeyLovList.get(i).getSrlNo());
						item.setText(1, MasterClsKeyLovList.get(i).getlovKey());
						item.setText(2, MasterClsKeyLovList.get(i).getlovVal());
					}
				}
				System.out.println("List size = " + ClsKeyLovList.size());
				tableViewer.refresh();
			}
		});
		searchText.setBounds(208, 78, 308, 26);

		Button btnSearch = new Button(group, SWT.NONE);
		btnSearch.setBounds(549, 78, 90, 30);
		btnSearch.setText("Search");

		/*btnSearch.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// System.out.println("Search Button clicked!");
				boolean found = false;
				// String keyword = (".*" + searchText.getText().trim() + ".*");
				String keyword = (searchText.getText().trim().toLowerCase());
				// listModel.clear();
				System.out.println("mannual search keyword=" + keyword);
				for (int i = 0; i < ClsKeyLovList.size(); i++) {
					// System.out.println("mannual search ClsKeyLovList=" + ClsKeyLovList.get(i));

					if (ClsKeyLovList.get(i).getlovVal().toLowerCase().equals(keyword)) {
						found = true;
						MessageBox.post(PlatformHelper.getCurrentShell(),
								"Search Text [" + keyword + "] found in this List of Value !!", "INFORAMTION",
								SWT.ICON_INFORMATION);

					}
				}
				System.out.println("mannual search found=" + found);
				if (found == false) {
					MessageBox.post(PlatformHelper.getCurrentShell(),
							"Search Text [" + keyword + "] not found in this List of Value !!", "INFORAMTION",
							SWT.ICON_INFORMATION);
				}
			}
		});*/
		
		btnSearch.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				boolean found = false;
				String keyword = (searchText.getText().trim().toLowerCase());
				System.out.println("mannual search keyword=" + keyword);
				if(keyword.length()>0)
				{
					table.removeAll();
					ClsKeyLovList = new ArrayList<ClsKeyLovTableLine>();
				}
				else if(keyword.length()==0)
				{
					table.removeAll();
					for (int i = 0; i < MasterClsKeyLovList.size(); i++) 
					{
						ClsKeyLovList.add(new ClsKeyLovTableLine(MasterClsKeyLovList.get(i).getSrlNo(),MasterClsKeyLovList.get(i).getlovKey(), MasterClsKeyLovList.get(i).getlovVal()));
						TableItem item = new TableItem(table, SWT.NONE);
						item.setText(0, MasterClsKeyLovList.get(i).getSrlNo());
						item.setText(1, MasterClsKeyLovList.get(i).getlovKey());
						item.setText(2, MasterClsKeyLovList.get(i).getlovVal());
					}
					return;
				}
				for (int i = 0; i < MasterClsKeyLovList.size(); i++)
				 {
					if (MasterClsKeyLovList.get(i).getlovVal().toLowerCase().contains(keyword)||
						MasterClsKeyLovList.get(i).getlovVal().toUpperCase().contains(keyword))
					{
						found = true;
						ClsKeyLovList.add(new ClsKeyLovTableLine(MasterClsKeyLovList.get(i).getSrlNo(),MasterClsKeyLovList.get(i).getlovKey(), MasterClsKeyLovList.get(i).getlovVal()));
						TableItem item = new TableItem(table, SWT.NONE);

						item.setText(0, MasterClsKeyLovList.get(i).getSrlNo());
						item.setText(1, MasterClsKeyLovList.get(i).getlovKey());
						item.setText(2, MasterClsKeyLovList.get(i).getlovVal());
					}
				}
				System.out.println("mannual search found1=" + found);
				System.out.println("List size = " + ClsKeyLovList.size());

				for (Object obj : ClsKeyLovList) 
				{
				    System.out.println(obj);
				}
				tableViewer.refresh();
				System.out.println("mannual search found=" + found);
				if (found == false) {
					MessageBox.post(PlatformHelper.getCurrentShell(),
							"Search Text [" + keyword + "] not found in this List of Value !!", "INFORAMTION",
							SWT.ICON_INFORMATION);
				}
			}
		});


		/*
		 * searchText.addKeyListener(new KeyAdapter() { public void keyReleased(KeyEvent
		 * ke) { System.out.println("lovTable:" + lovTable.toString());
		 * System.out.print("kjk LOV search:" + searchText.getText());
		 * searchFilter.setSearchText(searchText.getText()); tableViewer.refresh(); //
		 * treeViewer.refresh();
		 * 
		 * } });
		 */
		searchFilter = new SearchLovViewerFilter();
		tableViewer.addFilter(searchFilter);
		// treeViewer.addFilter(searchFilter);
		// searchFilter = new SearchLovViewerFilter();
		// tableViewer.addFilter(searchFilter);
		/*
		 * btnNewButton = new Button(container, SWT.NONE);
		 * btnNewButton.setEnabled(false); btnNewButton.addSelectionListener(new
		 * SelectionAdapter() {
		 * 
		 * @Override public void widgetSelected(SelectionEvent e) {
		 * 
		 * table.removeAll(); File file = new File(text.getText()); String filename =
		 * file.getName();
		 * 
		 * System.out.println("filename:" + filename);
		 * 
		 * // if(filename.equals(text_1.getText()+".csv")) {
		 * 
		 * ArrayList<Vector> displayArrayList = new ArrayList<Vector>();
		 * 
		 * for (int i = 0; i < displayArrayList.size(); i++) {
		 * 
		 * TableItem item = new TableItem(table, SWT.NONE); Vector linevec =
		 * displayArrayList.get(i); // item.setText(1, (i+1)+"");
		 * 
		 * for (int j = 0; j < linevec.size(); j++) { item.setText(j,
		 * linevec.get(j).toString()); }
		 * 
		 * }
		 * 
		 * }
		 * 
		 * tableitemcount = table.getItemCount();
		 * 
		 * // if(tableitemcount>0) // button.setEnabled(true);
		 * 
		 * } });
		 * 
		 * btnNewButton.setBounds(574, 98, 75, 25); btnNewButton.setText("Dry Run");
		 * 
		 */
		// parentShell.pack();
		return area;

	}

	/**
	 * Create contents of the button bar.
	 * 
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, false);
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(831, 700);
	}

	@Override
	protected void okPressed() {
		// TODO Auto-generated method stub
		System.out.println("OKKKKKK keyvalue=" + keyvalue);
		if (keyvalue == null || keyvalue.size() <= 0) {
			MessageBox.post(PlatformHelper.getCurrentShell(),
					" input value VC Class and Attribute ID are mandatory field !! ", "INFORAMTION",
					SWT.ICON_INFORMATION);
			return;
		}
		TMLKeyLOVCreateorUpdateOperation op = new TMLKeyLOVCreateorUpdateOperation(m_context, keyvalue);
		try {
			op.executeOperation();
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		super.okPressed();
	}
}

class TableLovContentProvider implements IStructuredContentProvider {
	public Object[] getElements(Object inputElement) {
		ArrayList<ClsKeyLovTableLine> list = (ArrayList<ClsKeyLovTableLine>) inputElement;

		Object[] obj = list.toArray();

		for (int x = 0; x < obj.length; x++) {

			System.out.println(" TableLovContentProvider obj=" + obj[x].toString());

		}
		return list.toArray();
	}

	public void dispose() {
	}

	@Override
	public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub

	}
}

class AttributeLovTableLabelProvider extends LabelProvider implements ITableLabelProvider {

	private TableViewer tableViewer;

	public AttributeLovTableLabelProvider(TableViewer tableViewer) {
		this.tableViewer = tableViewer;
		System.out.println("inside AttributeLovTableLabelProvider=" + tableViewer);
	}

	public String getColumnText(Object element, int columnIndex) {
		System.out.println("getColumnText=" + columnIndex);
		ClsKeyLovTableLine tabline = (ClsKeyLovTableLine) element;

		System.out.println("1columnIndex=" + columnIndex + " tabline= " + tabline.toString());
		switch (columnIndex) {
		case 0:
			System.out.println("1tabline.getSrlNo()=" + tabline.getSrlNo());
			// return tabline.getSrlNo()+"";
		case 1:
			System.out.println("1tabline.getAttrID()=" + tabline.getlovKey());
			return tabline.getlovKey().toString();
		case 2:
			System.out.println("1tabline.getAttrName()=" + tabline.getlovVal());
			return tabline.getlovVal().toString();
		// case 3:
		// System.out.println("1abline.getLovID()="+tabline.getLovid());
		// return tabline.getLovid();
		}

		return "";
	}

	@Override
	public Image getColumnImage(Object arg0, int arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
