package com.tml.techspec.dialogs;

import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCUserService;
import com.teamcenter.rac.util.MessageBox;

public class cpyVcAttrS extends TitleAreaDialog {
	private boolean isOkPressed;
	private Shell parentshell;
	private Text NewVcText;
	private Button OldVcValbutton;
	private Button NewVcValbutton;
	private Text OldVCtext;
	private Shell parentShell;

	public cpyVcAttrS(Shell parentShell) {
		super(parentShell);
		isOkPressed = false;
		// setTitleImage(ResourceManager.getPluginImage("tm.teamcenter.regulationproj",
		// "icons/T5_tm_chTypeNum16.png"));
		setTitle("Copy Technical Specification VC Attributes");
		// TODO Auto-generated constructor stub
	}

	/**
	 * Create contents of the dialog.
	 * 
	 * @param parent
	 */
	protected Control createDialogArea(Composite parent) {
		setTitle("Copy Technical Specification VC Attributes");
		TCSession session = (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		GridData gd_container = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		// gd_container.widthHint = 467;
		gd_container.widthHint = 535;
		gd_container.heightHint = 161;
		container.setLayoutData(gd_container);
		container.setTouchEnabled(true);
		GridLayout gl_container = new GridLayout(4, false);
		gl_container.marginWidth = 10;
		gl_container.marginRight = 3;
		gl_container.marginTop = 20;
		gl_container.marginBottom = 10;
		gl_container.marginLeft = 20;
		container.setLayout(gl_container);
		GridData gd_container1 = new GridData(GridData.FILL_BOTH);
		// gd_container.widthHint = 500;
		gd_container1.widthHint = 200;

		Label lblNewLabel_3 = new Label(container, SWT.NONE);
		lblNewLabel_3.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		lblNewLabel_3.setText("Source VC");
		new Label(container, SWT.NONE);

		OldVCtext = new Text(container, SWT.BORDER);
		GridData gd_OldVCtext = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gd_OldVCtext.widthHint = 262;
		OldVCtext.setLayoutData(gd_OldVCtext);

		OldVcValbutton = new Button(container, SWT.CHECK);
		OldVcValbutton.addSelectionListener(new SelectionAdapter() {
			@Override

			public void widgetSelected(SelectionEvent e) {

				OldVcValbutton.setSelection(false);
//				indexValDlg = new IndexValDialog(getShell());
//				indexValDlg.open();
//				IndexNumLst = indexValDlg.getIndexValueSet();
//				if(indexValDlg.getSelectedIndexVal()!=null)
//					NewVcText.setText(indexValDlg.getSelectedIndexVal());

			}
		});
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setText("Destination VC");
		new Label(container, SWT.NONE);

		NewVcText = new Text(container, SWT.BORDER);
		GridData gd_NewVcText = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_NewVcText.widthHint = 337;
		NewVcText.setLayoutData(gd_NewVcText);
		// NewVcText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1,
		// 1));
		// NewVcText.setBounds(109, 22, 104, 21);
		NewVcValbutton = new Button(container, SWT.CHECK);
		NewVcValbutton.addSelectionListener(new SelectionAdapter() {
			@Override

			public void widgetSelected(SelectionEvent e) {

				NewVcValbutton.setSelection(false);
//				indexValDlg = new IndexValDialog(getShell());
//				indexValDlg.open();
//				IndexNumLst = indexValDlg.getIndexValueSet();
//				if(indexValDlg.getSelectedIndexVal()!=null)
//					NewVcText.setText(indexValDlg.getSelectedIndexVal());

			}
		});
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		// IssueNumberText = new Text(container, SWT.BORDER);
		// IssueNumberText.setText("1");
		GridData gd_IssueNumberText = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		// gd_IssueNumberText.widthHint = 112;
		gd_IssueNumberText.widthHint = 12;
		// IssueNumberText.setLayoutData(gd_IssueNumberText);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		// Label lblNewLabel_5 = new Label(container, SWT.NONE);
		// lblNewLabel_5.setText("Chassis Type Number");
		// new Label(container, SWT.NONE);

		/*
		 * ChassisTypeNumText = new Text(container, SWT.BORDER); GridData
		 * gd_ChassisTypeNumText = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1,
		 * 1); //gd_ChassisTypeNumText.widthHint = 325; gd_ChassisTypeNumText.widthHint
		 * = 25; //ChassisTypeNumText.setLayoutData(gd_ChassisTypeNumText);
		 * ChassisTypeNumText.setForeground(SWTResourceManager.getColor(SWT.
		 * COLOR_WIDGET_FOREGROUND));
		 * 
		 * ChassisTypebutton = new Button(container, SWT.CHECK);
		 * 
		 * ChassisTypebutton.addSelectionListener(new SelectionAdapter() {
		 * 
		 * @Override public void widgetSelected(SelectionEvent e) {
		 * 
		 * ChassisTypebutton.setSelection(false); chassisTypeNumDlg = new
		 * ChassisTypeDialog(getShell()); chassisTypeNumDlg.open(); ChassisTypeNumLst =
		 * chassisTypeNumDlg.getChassisTypeNumSet();
		 * if(chassisTypeNumDlg.getSelectedChassisTypeNumVal()!=null)
		 * ChassisTypeNumText.setText(chassisTypeNumDlg.getSelectedChassisTypeNumVal());
		 * 
		 * 
		 * } });
		 * 
		 * area1=area;
		 */
		return area;
	}

	@Override
	protected void okPressed() {
		// TODO Auto-generated method stub
		// Rajesh
		// String TechSpecAddress = null;
		System.out.println("Inside Ok_pressed for CpyTechSpecVCattrtoNewVC call");
		isOkPressed = true;
		// eND TESTING
		Object objects[];
		objects = new Object[2];
		System.out.println("[before call CpyTechSpecVCattrtoNewVC User Service with OldVCtext=" + OldVCtext.getText()
				+ " and NewVcText=" + NewVcText.getText());
		objects[0] = OldVCtext.getText();
		objects[1] = NewVcText.getText();
		// objects[0]= datasetname;
		TCSession session = (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		TCUserService service = session.getUserService();

		System.out.println("[before call CpyTechSpecVCattrtoNewVC User Service....");
		// String return_data = (String)
		try {
			service.call("CpyTechSpecVCattrtoNewVC", objects);
			MessageBox.post(parentShell, "Copy process has initiated,Wait for while for completeion ....", "WARNING",
					SWT.ICON_INFORMATION);
		} catch (TCException e) {
			// TODO Auto-generated catch block
			MessageBox.post(parentShell,
					"There is some issue in Copy Process,Either input issue or system issue,Contact PLM Support Team !!!",
					"WARNING", SWT.ICON_WARNING);
			e.printStackTrace();
		}

		System.out.println("[after call CpyTechSpecVCattrtoNewVC User Service....");

		super.okPressed();
		return;
	}

	@Override
	protected void cancelPressed() {
		System.out.println("Inside cancelPressed for CpyTechSpecVCattrtoNewVC call");
		super.cancelPressed();
	}
}
