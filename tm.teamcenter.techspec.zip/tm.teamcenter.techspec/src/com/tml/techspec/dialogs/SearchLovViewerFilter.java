package com.tml.techspec.dialogs;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

import com.tml.classification.modules.ClsKeyLovTableLine;



public class SearchLovViewerFilter extends ViewerFilter {

    private String searchString;

    public void setSearchText(String s) {
        // ensure that the value can be used for matching
       // this.searchString = ".*" + s.toLowerCase() + ".*";
    	this.searchString = ".*" + s.toString() + ".*";
        System.out.println("inside SearchLovViewerFilter func call with search text="+s.toString());
    }

    @Override
    public boolean select(Viewer viewer,
            Object parentElement,
            Object element) {
    	System.out.println("inside SearchLovViewerFilter func call with element="+element.toString());
        if (searchString == null || searchString.length() == 0) {
            return true;
        }
         if(element instanceof ClsKeyLovTableLine)
        {
        	 ClsKeyLovTableLine tabline = (ClsKeyLovTableLine) element;
        	
        	 System.out.println("inside SearchLovViewerFilter func call with searchString="+searchString +" for tabline value ="+tabline.getlovVal().toString());
   		     String tmpval=tabline.getlovVal().toString(); 
        	 //if(tabline.getlovKey().matches(searchString) || tabline.getlovVal().matches(searchString))
   		  if(tabline.getlovKey().matches(searchString) || tmpval.matches(searchString))
   		    	System.out.println("inside SearchLovViewerFilter func call with matched searchString="+searchString +" for tabline value ="+tabline.getlovVal().toString());
   		    	   return true;
        }  
          
        
       
        return false;
    }

}
