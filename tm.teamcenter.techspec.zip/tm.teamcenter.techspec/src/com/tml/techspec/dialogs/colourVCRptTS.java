package com.tml.techspec.dialogs;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentDataset;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCPreferenceService;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCUserService;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.teamcenter.services.loose.core.DataManagementService;
import com.teamcenter.services.loose.core._2006_03.DataManagement.CreateDatasetsResponse;
import com.teamcenter.services.loose.core._2006_03.FileManagement.DatasetFileInfo;
import com.teamcenter.services.loose.core._2006_03.FileManagement.GetDatasetWriteTicketsInputData;
import com.teamcenter.services.loose.core._2008_06.DataManagement.DatasetProperties2;
import com.teamcenter.soa.client.FileManagementUtility;
import com.teamcenter.soa.client.model.ModelObject;
import com.teamcenter.soa.client.model.ServiceData;
import com.tml.classification.modules.TechSpecUtil;

public class colourVCRptTS extends TitleAreaDialog {
	private boolean isOkPressed;
	private Shell parentshell;
	private TCSession session;
	private Set<String> tempKDUpdValset;
	private Combo UpdValCombo1_1;
	// private Button btnDateRange;
	private Button btnUserInput;
	private String ErrMsg;
	private Shell Pshell;

	protected Shell shell;
	private Text filePathText;
	private Button chkDateRange;
	private Button chkUserInput;
	private Button btnBrowse;
	private DateTime dateTime;
	private DateTime dateTime_1;
	private Text text;
	private Button btnBrowse_1;
	private Label lblFile;
	private Button chkDateRange_1;
	private Button chkUserInput_1;

	public colourVCRptTS(Shell parentShell) {
		super(parentShell);
		isOkPressed = false;
		AbstractAIFUIApplication app = AIFUtility.getCurrentApplication();
		this.session = (TCSession) app.getSession();
		this.UpdValCombo1_1 = UpdValCombo1_1;
		// this.btnDateRange = btnDateRange;
		this.btnUserInput = btnUserInput;
		// setTitleImage(ResourceManager.getPluginImage("tm.teamcenter.regulationproj",
		// "icons/T5_tm_chTypeNum16.png"));
		setTitle("Colour VC Report with Tech Spec Parameters");
		// TODO Auto-generated constructor stub
	}

	/*************************************************************************/
	private GetDatasetWriteTicketsInputData getSingleGetDatasetWriteTicketsInputData(File tobeuploadfile,
			TCComponentDataset dataset) {
		// Assume this file is in current dir
		// FileInfo file1 = new FileInfo();
		String cacheDir = System.getProperty("java.io.tmpdir");
		TCPreferenceService pref = session.getPreferenceService();
		String FMS_Bootstrap_Urls = pref.getPreferenceDescription("FMS_Bootstrap_Urls");
		String[] Bootstrap_Urls = { FMS_Bootstrap_Urls };
		// String[] FMS_Bootstrap_Urls = session.getPreferenceService();
		System.out.print("FMS_Bootstrap_Urls:-" + FMS_Bootstrap_Urls + "Bootstrap_Urls=" + Bootstrap_Urls[0]
				+ " cacheDir=" + cacheDir);
		// FileManagementUtility fmsFileManagement =new
		// FileManagementUtility(session.getSoaConnection());//, null, null,
		// Bootstrap_Urls, cacheDir);

		String filenametobeupload = tobeuploadfile.getName().replaceAll(";", "_");// 21-05-2021
		String filepath = tobeuploadfile.getPath();
		System.out.print("filenametobeupload:-" + filenametobeupload + "filepath=" + filepath);
		// String WholefileName = filepath + filenametobeupload;
		String WholefileName = filepath;
		System.out.print("WholefileName:-" + WholefileName);

		// Create a file to associate with dataset
		DatasetFileInfo fileInfo = new DatasetFileInfo();

		fileInfo.clientId = fileInfo.toString();
		fileInfo.fileName = filepath;
		fileInfo.allowReplace = true;
		// fileInfo.isText = false;
		fileInfo.isText = true;
		fileInfo.namedReferencedName = "Text";

		DatasetFileInfo[] fileInfos = { fileInfo };

		GetDatasetWriteTicketsInputData inputData = new GetDatasetWriteTicketsInputData();
		inputData.dataset = dataset;
		inputData.createNewVersion = false;
		inputData.datasetFileInfos = fileInfos;

		return inputData;

	}

	public TCComponentDataset CreateDataset(String datasetname, String Desc, File filetobeupload) throws TCException {
		System.out.print("inside CreateDataset func");
		// TCSession session = null;
		// DataManagementService dservice = DataManagementService.getService(session);
		DataManagementService dservice = DataManagementService.getService(session.getSoaConnection());
		String filenametobeupload = filetobeupload.getName();
		String filepath = filetobeupload.getPath().replaceAll(";", "_");// 21-05-2021;
		System.out.print("filenametobeupload:-" + filenametobeupload + "filepath=" + filepath);
		// String WholefileName = filepath + filenametobeupload;
		String WholefileName = filepath;
		System.out.print("WholefileName:-" + WholefileName);
		DatasetProperties2[] dataProps1 = new DatasetProperties2[1];

		dataProps1[0] = new DatasetProperties2();
		dataProps1[0].clientId = datasetname;
		dataProps1[0].name = datasetname;
		dataProps1[0].description = Desc;
		// dataProps[0].
		// dataProps[0].relationType = "IMAN_reference";
		dataProps1[0].type = "Text";
		dataProps1[0].toolUsed = "TextEditor";

		CreateDatasetsResponse dataResp = dservice.createDatasets2(dataProps1);

		/*
		 * DatasetInfo[] dataProps = new DatasetInfo[1]; dataProps[0] = new
		 * DatasetInfo(); dataProps[0].clientId=datasetname;
		 * dataProps[0].name=datasetname; dataProps[0].description=Desc; //dataProps[0].
		 * //dataProps[0].relationType = "IMAN_reference"; dataProps[0].type="Text";
		 * dataProps[0].toolUsed="TextEditor";
		 */ // dataProps[0].container = techspecobj;
		// CreateDatasetsResponse dataResp = dservice.createDatasets(dataProps1);
		// CreateDatasetsResponse dataResp = (dservice).crea
		TechSpecUtil.ServiceDataError(dataResp.serviceData);
		if (dataResp.serviceData.sizeOfCreatedObjects() > 0) {
			ModelObject dataset = dataResp.output[0].dataset;

			// refresh Objects
			// TCComponent[] objs = { techspecobj.getItem(), techspecobj, dataset };
			// dservice.refreshObjects(objs);
			System.out.print("End CreateDataset func for " + datasetname);
			return (TCComponentDataset) dataset;
		}
//datasetnamegetNewStuffFolder().add("contents", data.getCreatedObject(0));
		// ((TCComponent)
		// dataResp.serviceData.getCreatedObject(0)).getSession().getUser().getNewStuffFolder().add("contents",
		// dataResp.serviceData.getCreatedObject(0));
		return null;
		// System.out.print("End CreateDataset func");
	}

	public void addNamedReference(File tobeuploadfile, TCComponentDataset dataset) {
		System.out.print("Inside the function addNamedReference");
		FileManagementUtility fmsFileManagement = new FileManagementUtility(session.getSoaConnection());// , null, null,
																										// Bootstrap_Urls,
																										// cacheDir);
		try {
			GetDatasetWriteTicketsInputData[] inputs = {
					getSingleGetDatasetWriteTicketsInputData(tobeuploadfile, dataset) };
			System.out.print("tobeuploadfile=" + tobeuploadfile.getName() + " inputs=" + inputs.toString());
			ServiceData response = fmsFileManagement.putFiles(inputs);
			TechSpecUtil.ServiceDataError(response);
		} finally {
			// Close FMS connection when done
			fmsFileManagement.term();
		}

		System.out.print("End the function addNamedReference");
	}

	private TCComponent[] queryControlObjs(String queryname, String[] qryNames, String[] qryValues) throws TCException {

		TCComponent[] qryResults = null;
		// System.out.println(" In Query for DML ::"+queryname);
		TCSession tcsession = (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		try {
			// System.out.println(" Before setting the session ::");
			TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");
			TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);// "Item...");
			// System.out.println(" After setting the session ::");

			if (mmcomponentquery != null) {
				// System.out.println(" Results found ::");
				qryResults = mmcomponentquery.execute(qryNames, qryValues);
			}

		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		return qryResults;
	}

	private void populateUpdValSet(String subsycd) {
		// TODO Auto-generated method stub

		tempKDUpdValset = new HashSet<String>();
		String[] CHKDUpdValArr = null;
		TCComponent[] contrlObjs = null;
		/*
		 * String qry="ControlObjects";
		 * 
		 * String []qryNames = new String[]{"SYSCD"}; String []qryValues = new
		 * String[]{plant};
		 */
		String qry = "Control Objects...";
		String[] qryNames = new String[] { "SUBSYSCD" };
		// String []qryValues = new String[]{"ChassisUpdVal"};
		String[] qryValues = new String[] { subsycd };
		try {
			contrlObjs = (TCComponent[]) queryControlObjs(qry, qryNames, qryValues);
			if (contrlObjs != null) {
				if (contrlObjs.length > 0) {
					for (int c = 0; c < contrlObjs.length; c++) {
						String ctrlClass = "";
						ctrlClass = contrlObjs[c].getStringProperty("object_type");
						if (!ctrlClass.equals("T5_ControlObject")) {
							System.out.println("Not a Control Object Class");
							continue;
						} else {

							String syscdStr = "";
							syscdStr = contrlObjs[c].getStringProperty("t5_SubSyscd");
							String plantFromCtr = "";
							plantFromCtr = contrlObjs[c].getStringProperty("t5_Userinfo1");
							System.out.println("t5_Userinfo1==>" + plantFromCtr + "\nSubsyscdStr==>" + syscdStr);
							// if(syscdStr.equals(plant))

							System.out.println("syscd==>" + syscdStr + "\nSubsyscdStr==>" + syscdStr);
							String KDUpdVal = "";
							KDUpdVal = contrlObjs[c].getStringProperty("t5_Syscd");
							// VehModcombo.add(KDUpdVal);
							tempKDUpdValset.add(KDUpdVal);

							System.out.println("tempKDUpdValset==>" + tempKDUpdValset.size());

						}
					}
				}
			}

		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void processColTeschSpecVCWiseRpt(String pathNF) {
		System.out.println("Inside func processChColVCRptCre for create with input pathNF=" + pathNF);
		File toUpldfile = null;
		File toUpldfile1 = null;

		String currentDateTime = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date());
		String cacheDir = System.getProperty("java.io.tmpdir");
		String filename = pathNF;
		String tmpDir = pathNF;
		cacheDir = pathNF;
		String filename1 = "TechSpecVCWiseRpt" + currentDateTime + ".txt";
		// String tmpDir1 = cacheDir + "\\" + filename1;
		String tmpDir1 = filename1;
		System.out.println("cacheDir=" + pathNF + " tmpDir1: " + tmpDir1 + " currentDateTime=" + currentDateTime);
		// File myObj = new
		// File("D:\\CAD11218\\Desktop_Data\\TCUA\\keywordDesc\\partlist.txt");
		File myObj = new File(tmpDir);
		File myObj1 = new File(tmpDir1);
		session = (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();

		// System.out.println("Calling processChColVCRptCre Func");

		// System.out.println("\nbtnDateRange=" + btnDateRange.getEnabled());
		// 54^T&T^CTS^-^-^WIRING HARNESS,PIGTAIL WIF SENSOR

		try {
			// File myObj = new File(pathNF);
			if (myObj.createNewFile()) {
				toUpldfile = myObj;
				System.out.println("File created: " + myObj.getName());
				// FileWriter myWriter = new
				// FileWriter("D:\\CAD11218\\Desktop_Data\\TCUA\\keywordDesc\\partlist.txt");

				// Create Data set and Add named reference logic

				// Create Data set and Add named reference logic End
				System.out.println("2tmpDir: " + tmpDir);
				FileWriter myWriter = new FileWriter(tmpDir);

				// myWriter.write("Files in Java might be tricky, but it is fun enough!\n");
				// myWriter.write(DesGrptext.getText()+"^"+ModuleNameText.getText()+"^"+partfamtext.getText());
				// myWriter.close();
				System.out.println("Successfully wrote to the file.");
			} else {
				System.out.println("File already exists.");
			}
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}

		try {
			// File myObj = new
			// File("D:\\CAD11218\\Desktop_Data\\TCUA\\keywordDesc\\partlist.txt");
			if (myObj1.createNewFile()) {
				toUpldfile1 = myObj1;
				System.out.println("File created: " + myObj1.getName());
				// FileWriter myWriter = new
				// FileWriter("D:\\CAD11218\\Desktop_Data\\TCUA\\keywordDesc\\partlist.txt");

				System.out.println("2tmpDir1: " + tmpDir1);
				FileWriter myWriter1 = new FileWriter(tmpDir1);

				// myWriter.write("Files in Java might be tricky, but it is fun enough!\n");
				// myWriter.write(DesGrptext.getText()+"^"+ModuleNameText.getText()+"^"+partfamtext.getText());
				// myWriter.close();
				System.out.println("Successfully wrote to the file2.");
			} else {
				System.out.println("File already exists2.");
			}

		} catch (IOException e1) {
			System.out.println("An error occurred.");
			e1.printStackTrace();
		}

		TCComponentDataset dataset = null;
		// TCComponentDataset dataset1=null;

		String datasetname = "ColVCwiseTechSpecRpt" + currentDateTime;
		// String datasetname1="keywordupdate"+currentDateTime;
		// System.out.print("111B4 CreateDataset func call with
		// datasetname="+datasetname+" toUpldfile name"+myObj.getName());
		try {
			dataset = CreateDataset(datasetname, datasetname, myObj);
			// dataset1=CreateDataset(datasetname1,datasetname1,myObj1);
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Going to Add name refrence with dataset\n");

		System.out.print("inside namedref add for ADD option with toUpldfile1=" + myObj.getName());
		addNamedReference(myObj, dataset);

		// getting actual file from dataset's named reference which will be passed in
		// argument

		System.out.println("B4 Dataset Qry call");
		String datasetfilepath = null;
		TCComponent datasetExist;
		AIFComponentContext[] datasetNamedRef;
		try {
			datasetExist = TechSpecUtil.qryObj(session, "Dataset Name", "Dataset Name", filename);
			System.out.println("After Dataset Qry call");
			if (datasetExist != null) {
				System.out.println("Dataset already available in system, only Named refrence will get\n");
				// datasetfilepath
				datasetNamedRef = datasetExist.getRelated();
				// datasetfilepath=datasetNamedRef[0].

//						tc_strcpy(FileLoc,"/tmp/");
//						tc_strcat(FileLoc,Filename);
//						printf("\n FileLoc====>[%s]", FileLoc);fflush(stdout);
//						printf("\n After dataset name ====>[%s]", dsetName);fflush(stdout);
//						 ifail = AE_export_named_ref(dataset, "word", FileLoc);
				// System.out.println("Going to Add name refrence with dataset\n");
				// addNamedReference(UpdatedRptHist,(TCComponentDataset)datasetExist);
			}
		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		// fOR TESTING TO GET THE NAMED REFERENCE
		TCComponent[] datasetobj1;
		String[] qryNames1 = { "Dataset Name" };
		String[] qryValues1 = { datasetname };
		try {
			datasetobj1 = TechSpecUtil.queryObjTCUA("Dataset Name", qryNames1, qryValues1);
			System.out.println("datasetobj1.length=" + datasetobj1.length);
			if (datasetobj1.length > 0) {

				FileManagementUtility fmsFileManagement = new FileManagementUtility(session.getSoaConnection());// ,
																												// null,
																												// null,
																												// Bootstrap_Urls,
																												// cacheDir);
				try {
					TCComponent[] datafile = datasetobj1[0].getReferenceListProperty("ref_list");
					// datafile.getObjectString()
					System.out.println("dataset class obj name=" + datafile[0].getObjectString());
					String[] xx = dataset.getDatasetDefinitionComponent().getNamedReferences();
					System.out.println("dataset class name=" + xx[0]);
					TCComponent[] datafile1 = dataset.getNamedReferences();
					System.out.println("dataset class obj name=" + datafile1[0].getObjectString());

					// try
					{
						ModelObject[] objs = dataset.getReferenceListProperty("ref_list");

						for (ModelObject obj : objs) {
							if (obj instanceof File) {
								// String fileName = ((File)obj).get_original_file_name();
								String fileName = ((File) obj).getPath();
								System.out.println("fileName: " + fileName);
								// com.teamcenter.fms.clientcache.proxy.IFileCacheProxyCB cb;
								// GetFileResponse fileResp = FileManagementUtility.getFileToLocation(obj,
								// "/tmp/rrb/" + fileName, cb , new String("My Custom Object"));

//					                    for(File file : fileResp.getFiles())
//					                    {
//					                        System.out.println("Name: " + file.getName() + ", " + file.length());
//					                    }
							}
						}
					}
					// catch(NotLoadedException e)
					// {
					// e.printStackTrace();
					// }

					// System.out.println("dataset class
					// name="+datasetobj1[0].getReferenceProperty("ref_list").toString());
					// GetDatasetWriteTicketsInputData[] inputs = {
					// getSingleGetDatasetWriteTicketsInputData(datasetfile,dataset) };
					// File responsefile = fmsFileManagement.getFile(datasetname);
					// GetDatasetWriteTicketsInputData[] inputs = {
					// getSingleGetDatasetWriteTicketsInputData(responsefile,dataset) };
					// System.out.println("datasetobj1.responsefile="+responsefile);
					// TechSpecUtil.ServiceDataError(responsefile);
				} finally {
					// Close FMS connection when done
					fmsFileManagement.term();
				}
			}

		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		// eND TESTING
		Object objects[];
		objects = new Object[1];

		objects[0] = datasetname;

		TCUserService service = session.getUserService();

		System.out.println("[before call ColVCwiseTechSpecRpt User Service....");
		// String return_data = (String)
		try {
			service.call("ColVCWiseTechSpecRpt", objects);
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("[after call ColVCwiseTechSpecRpt User Service....");

//					Object objects1[];
//			        objects1 = new Object[1];
//			        
//			        objects1[0]= datasetname;
//					
//					TCUserService service1 =session.getUserService();
//			        
//	                
//	              	  System.out.println("[before call UpdateKeywordDesc User Service....");
//						//String return_data = (String) 
//								try {
//									service.call("LoadUpdKeywordDescUsrServ", objects1);
//								} catch (TCException e) {
//									// TODO Auto-generated catch block
//									e.printStackTrace();
//								}
//						
//						System.out.println("[after call UpdateKeywordDesc User Service....");
//

		// Need to delete dataset after upload keyword desc
	}

	/**
	 * Create contents of the dialog.
	 * 
	 * @param parent
	 */

	/*
	 * protected Control createDialogArea(Composite parent) {
	 * setTitle("Technical Specification Report"); TCSession session= (TCSession)
	 * AIFDesktop.getActiveDesktop().getCurrentApplication().getSession(); Composite
	 * area = (Composite) super.createDialogArea(parent); Composite container = new
	 * Composite(area, SWT.NONE); GridData gd_container = new GridData(SWT.LEFT,
	 * SWT.CENTER, false, false, 1, 1); //gd_container.widthHint = 467;
	 * gd_container.widthHint = 750; gd_container.heightHint = 369;
	 * container.setLayoutData(gd_container); container.setTouchEnabled(true);
	 * GridLayout gl_container = new GridLayout(3, false); gl_container.marginWidth
	 * = 10; gl_container.marginRight = 3; gl_container.marginTop = 20;
	 * gl_container.marginBottom = 10; gl_container.marginLeft = 20;
	 * container.setLayout(gl_container); GridData gd_container1 = new
	 * GridData(GridData.FILL_BOTH); //gd_container.widthHint = 500;
	 * gd_container1.widthHint = 200;
	 * 
	 * chkDateRange_1 = new Button(container, SWT.CHECK);
	 * chkDateRange_1.setText("Date Range Report"); new Label(container, SWT.NONE);
	 * new Label(container, SWT.NONE); new Label(container, SWT.NONE); new
	 * Label(container, SWT.NONE); new Label(container, SWT.NONE);
	 * 
	 * // IssueNumberText = new Text(container, SWT.BORDER); //
	 * IssueNumberText.setText("1"); GridData gd_IssueNumberText = new
	 * GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
	 * //gd_IssueNumberText.widthHint = 112; gd_IssueNumberText.widthHint = 12;
	 * 
	 * lblAddupdate = new Label(container, SWT.NONE);
	 * lblAddupdate.setText("         From Date");
	 * 
	 * dateTime = new DateTime(container, SWT.BORDER); new Label(container,
	 * SWT.NONE); new Label(container, SWT.NONE); new Label(container, SWT.NONE);
	 * new Label(container, SWT.NONE); System.out.println("deug===========>" ) ;
	 * Label DesGrpLabel = new Label(container, SWT.NONE);
	 * DesGrpLabel.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1,
	 * 1)); DesGrpLabel.setText("         To Date");
	 * 
	 * dateTime_1 = new DateTime(container, SWT.BORDER); new Label(container,
	 * SWT.NONE); new Label(container, SWT.NONE); new Label(container, SWT.NONE);
	 * new Label(container, SWT.NONE);
	 * 
	 * chkUserInput_1 = new Button(container, SWT.CHECK);
	 * chkUserInput_1.setText("User Input"); new Label(container, SWT.NONE); new
	 * Label(container, SWT.NONE); new Label(container, SWT.NONE); new
	 * Label(container, SWT.NONE); new Label(container, SWT.NONE);
	 * 
	 * lblFile = new Label(container, SWT.NONE); lblFile.setText("Select File:");
	 * lblFile.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1,
	 * 1));
	 * 
	 * text = new Text(container, SWT.BORDER); text.setEnabled(false);
	 * text.setEditable(false); text.setLayoutData(new GridData(SWT.FILL,
	 * SWT.CENTER, true, false, 1, 1));
	 * 
	 * btnBrowse_1 = new Button(container, SWT.NONE); btnBrowse_1.setText("Browse");
	 * btnBrowse_1.setEnabled(false);
	 * 
	 * 
	 * populateUpdValSet("ChassisUpdVal");
	 * 
	 * String strArray[] = tempKDUpdValset.toArray(new
	 * String[tempKDUpdValset.size()]);
	 * System.out.println("tempCHVehModel Array Values:"+Arrays.toString(strArray));
	 * 
	 * for(int i=0; i<strArray.length; i++) { //UpdValCombo.add(strArray[i]); //
	 * UpdValCombo.add(strArray[i]);
	 * System.out.println("Keyword Description Update Value set : " + strArray[i]);
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * chkDateRange_1.addSelectionListener(new SelectionAdapter() {
	 * 
	 * @Override public void widgetSelected(SelectionEvent e) { boolean selected =
	 * chkDateRange_1.getSelection(); fromDate.setEnabled(selected);
	 * toDate.setEnabled(selected); chkUserInput_1.setSelection(false);
	 * filePathText.setEnabled(!selected && chkUserInput_1.getSelection());
	 * btnBrowse.setEnabled(!selected && chkUserInput_1.getSelection()); } });
	 * 
	 * chkUserInput_1.addSelectionListener(new SelectionAdapter() {
	 * 
	 * @Override public void widgetSelected(SelectionEvent e) { boolean selected =
	 * chkUserInput_1.getSelection(); filePathText.setEnabled(selected);
	 * btnBrowse.setEnabled(selected); chkDateRange_1.setSelection(false);
	 * fromDate.setEnabled(!selected); toDate.setEnabled(!selected); } });
	 * 
	 * 
	 * return area; }
	 */
	protected Control createDialogArea(Composite parent) {
		setTitle("Chassis Colour VC Report with Technical Spec Parameters");
		TCSession session = (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);

		GridData gd_container = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_container.widthHint = 750;
		gd_container.heightHint = 156;
		container.setLayoutData(gd_container);
		container.setTouchEnabled(true);

		GridLayout gl_container = new GridLayout(3, false);
		gl_container.marginWidth = 10;
		gl_container.marginRight = 3;
		gl_container.marginTop = 20;
		gl_container.marginBottom = 10;
		gl_container.marginLeft = 20;
		container.setLayout(gl_container);

		// Second Radio Button for File Selection
		btnUserInput = new Button(container, SWT.RADIO);
		btnUserInput.setText("User VC Input wise");
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		lblFile = new Label(container, SWT.NONE);
		lblFile.setText("Select File:");
		lblFile.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));

		filePathText = new Text(container, SWT.BORDER);
		filePathText.setEnabled(false);
		filePathText.setEditable(false);
		filePathText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btnBrowse = new Button(container, SWT.NONE);
		btnBrowse.setText("Browse");
		btnBrowse.setEnabled(false);

		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog fileDialog = new FileDialog(container.getShell(), SWT.OPEN);
				fileDialog.setText("Select a File");
				fileDialog.setFilterExtensions(new String[] { "*.*" });
				String selectedFile = fileDialog.open();

				if (selectedFile != null) {
					filePathText.setText(selectedFile);
				}
			}
		});

		btnUserInput.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				boolean selected = btnUserInput.getSelection();
				filePathText.setEnabled(selected);
				btnBrowse.setEnabled(selected);
				// fromDate.setEnabled(!selected);
				// toDate.setEnabled(!selected);
			}
		});

		return area;
	}

	public static String convertnumtocharmonths(int m) {
		String charname = null;
		if (m == 1) {
			charname = "Jan";
		}
		if (m == 2) {
			charname = "Feb";
		}
		if (m == 3) {
			charname = "Mar";
		}
		if (m == 4) {
			charname = "Apr";
		}
		if (m == 5) {
			charname = "May";
		}
		if (m == 6) {
			charname = "Jun";
		}
		if (m == 7) {
			charname = "Jul";
		}
		if (m == 8) {
			charname = "Aug";
		}
		if (m == 9) {
			charname = "Sep";
		}
		if (m == 10) {
			charname = "Oct";
		}
		if (m == 11) {
			charname = "Nov";
		}
		if (m == 12) {
			charname = "Dec";
		}
		return charname;
	}

	@Override
	protected void okPressed() {
		// TODO Auto-generated method stub
		// Rajesh
		// String TechSpecAddress = null;
		// this.btnDateRange = btnDateRange;
		// System.out.println(
		// "Inside Ok_pressed for Keyword Description addition/create before
		// processChColVCRptCre call with UpdValCombo1_1.getText()= "
		// + btnDateRange.getSelection());

		isOkPressed = true;
		// boolean selection = btnDateRange.getSelection();
		boolean selection1 = btnUserInput.getSelection();
		// System.out.println(" 1btnDateRange selection status =" + selection);
		System.out.println(" 1btnUserInput selection status =" + selection1);
		// if (btnDateRange.getSelection() == false && btnUserInput.getSelection() ==
		// false) {
		if (btnUserInput.getSelection() == false) {
			MessageBox.post(PlatformHelper.getCurrentShell(),
					"please select valid option for generate report either Vc wise !!  !!", "INFORAMTION",
					SWT.ICON_INFORMATION);
			return;
		}
//		if (btnDateRange.getSelection() == true) {
//			System.out.println(" btnDateRange selection status =" + btnDateRange.getText()
//					+ " fromDate.getData().toString()=" + fromDate.getDay() + "/" + fromDate.getMonth() + "/"
//					+ fromDate.getYear() + " toDate.getData().toString()=" + toDate.getDay() + "/" + toDate.getMonth()
//					+ "/" + toDate.getYear() + "month Nmae =" + Month.of(fromDate.getMonth()));

		// if(DesGrptext.getText().length()<=0 || ModuleNameText.getText().length()<=0
		// || partfamtext.getText().length()<=0 || keywordDesctext.getText().length()<=0
		// )
//			String frmMonthName = convertnumtocharmonths(fromDate.getMonth());
//			System.out.println("frmMonthName=" + frmMonthName);
//			String toMonthName = convertnumtocharmonths(toDate.getMonth());
//			System.out.println("toMonthName=" + toMonthName);
//			String frmdate = fromDate.getDay() + "-" + frmMonthName + "-" + fromDate.getYear();
//			String Todate = toDate.getDay() + "-" + toMonthName + "-" + toDate.getYear();
//			System.out.println("frmdate=" + frmdate + "	Todate=" + Todate);
//			Object objects[];
//			objects = new Object[2];

		// objects[0] = frmdate;
		// objects[1] = Todate;
		// TCUserService service = session.getUserService();

//			System.out.println("[before call TechSpecReportDateRange User Service....");
		// String return_data = (String)
//			try {
//			//	service.call("TechSpecReportDateRange", objects);
//				System.out.println(
//						"Date Range wise Tech Spec Report generation is under process ,wait for completion !\\n for Further Contact PLM Administrator");
//				ErrMsg = "Report generation has completed ,please wait for while and check folder<Technical_Specification_Reports> for generated report !!!";
//				MessageBox.post(Pshell, ErrMsg, "INFORAMTION", SWT.ICON_INFORMATION);
//				super.okPressed();
//				return;
//			} catch (TCException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}

		System.out.println("[after call TechSpecReportDateRange User Service....");

//		}
		if (btnUserInput.getSelection() == true) {
			System.out.println(" btnUserInput selection status =" + btnUserInput.getText() + " with input file path="
					+ filePathText.getText());
			String filepath = filePathText.getText();
			processColTeschSpecVCWiseRpt(filepath);
			System.out.println(
					"Chassis Colour VC wise Tech Spec Report generation is under process ,wait for completion !\\n for Further Contact PLM Administrator");
			ErrMsg = "Report generation has completed ,please wait for while,refresh and check folder<Chassis_Colour_VC_Reports> for latest generated report !!!";
			MessageBox.post(Pshell, ErrMsg, "INFORAMTION", SWT.ICON_INFORMATION);
			super.okPressed();
			return;
		}

		System.out.println("Inside Ok_pressed  after processChColVCRptCre call");

		// super.okPressed();
		/*
		 * try { Thread.sleep(15000); //wait 15 sec } catch (InterruptedException e) {
		 * // TODO Auto-generated catch block e.printStackTrace(); }
		 */
		MessageBox.post(PlatformHelper.getCurrentShell(),
				"Report generation has completed ,please wait for while,refresh and check folder<Chassis_Colour_VC_Reports> for latest generated report  !!",
				"INFORAMTION", SWT.ICON_INFORMATION);
		return;
	}

	@Override
	protected void cancelPressed() {
		System.out.println("Inside cancelPressed for Chassis_Colour_VC_Reports before processChColVCRptCre call");
		super.cancelPressed();
	}

}