package com.tml.techspec.dialogs;



import java.awt.Frame;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.StringTokenizer;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.common.NotDefinedException;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandImageService;
import org.eclipse.ui.commands.ICommandService;
import org.eclipse.wb.swt.SWTResourceManager;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

import com.swt.multicombo.MultiValueTextCellEditor;
import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.AbstractAIFOperation;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.commands.open.OpenCommand;
import com.teamcenter.rac.commands.properties.PropertiesCommand;
import com.teamcenter.rac.common.CommandTargetState;
import com.teamcenter.rac.common.MultiTargetControllerJob;
import com.teamcenter.rac.common.TCTypeRenderer;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentDataset;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCPreferenceService;
import com.teamcenter.rac.kernel.TCProperty;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.ics.ICSKeyLov;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.loose.core.DataManagementService;
import com.teamcenter.services.loose.core._2006_03.DataManagement.CreateDatasetsResponse;
import com.teamcenter.services.loose.core._2006_03.DataManagement.DatasetProperties;
import com.teamcenter.services.loose.core._2006_03.FileManagement.DatasetFileInfo;
import com.teamcenter.services.loose.core._2006_03.FileManagement.GetDatasetWriteTicketsInputData;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVDefinition2;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVEntry;
import com.teamcenter.services.rac.classification._2011_12.Classification.AttributeValues;
import com.teamcenter.services.rac.classification._2011_12.Classification.Value;
import com.teamcenter.soa.client.FileManagementUtility;
import com.teamcenter.soa.client.model.ModelObject;
import com.teamcenter.soa.client.model.ServiceData;
import com.teamcenter.soa.exceptions.NotLoadedException;
import com.tml.classification.modules.BOMExpansion;
import com.tml.classification.modules.BOMExpansion4ModException;
import com.tml.classification.modules.ClassificationAnnotationLine;
import com.tml.classification.modules.ClassificationLineProvider;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.ClassificationTreeLine;
import com.tml.classification.modules.CreateOrUpdateICOSample;
import com.tml.classification.modules.GetClassifiedAttr2;
import com.tml.classification.modules.GetKeyLOVs2Sample;
import com.tml.classification.modules.GetKeyLOVs2Sample3;
import com.tml.classification.modules.GetModuleAttributesForCheckINClasses;
import com.tml.classification.modules.GetModuleAttributesForClasses;
import com.tml.classification.modules.ICOValues;
import com.tml.classification.modules.KeyValueLOV;
import com.tml.classification.modules.PreferenceValue;
import com.tml.classification.modules.TMLDataBean;
//import org.eclipse.swt.widgets.MessageBox;
import com.tml.classification.modules.TechSpecUtil;



public class UpdateMDMDlgForPRD extends TitleAreaDialog {
	private Text tsdesc;
	private String ModuleAddress;
	private String ObjectID;
	private TCSession session;
	private ClassificationLineProvider tabLineModel;
	private ArrayList<ClassificationTableLine> classificationList;
	private HashMap <String,Object> namevalueP;
	private Tree tree;
	private ArrayList<String> mandatorylist;
	private ArrayList<AIFComponentContext> aifcomponentctxtList;
	protected TreeViewer treeViewer;
	private Text tsbu;
	private ICOValues icoval;
	private Text tsnum;
	private String ModuleNum;
	private String SelObjType;
	private ClassificationObject clsobjs;
	private String attrid=null;
	private String attrval=null;
	private Text tsou;
	private Shell parentShell;
	private Text tsvsc;
	private Text tsodu;
	private Text tsodd;
	private TCComponentItemRevision ItemRev;
	private TCComponent selectedObj;
	private List<CommandTargetState> m_commandTargetStateList;
	private List<CommandTargetState> m_commandTargetStateList1;
	private AIFComponentContext localAIFComponentContext;
	private ArrayList<AIFComponentContext> localAIFComponentContextList;
	private InterfaceAIFComponent parent_item;
	private ExecutionEvent exe_evt;
	protected boolean isUpdatable;
	protected boolean fullexpandable;
	private boolean DeptAttrFlg;
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private ArrayList<AIFComponentContext> uniqueErrObj;
	protected Map<String,KeyValueLOV> keylovList;
	protected Map<String,String> modifedvalueMap;
	protected Map<String,String> modifedactvalueMap;
	protected Map<String,String> attrNameIDMap;
	protected Map<String,String> initialValMap;
	private Text searchText;
	private SearchViewerFilter searchFilter;
	private boolean isSuccess;
	private ArrayList<TCComponentItemRevision> ccvList;
	private String moduleAddr;
	private BOMExpansion bomexpansion;
	private BOMExpansion4ModException bom4modexpansion;
	private  Map<String,String> arrayAttr;
	private TCComponentItemRevision ErcDMLObj;
	private String objType;
	private ArrayList<TCComponentItemRevision> class_not_found;
	private ArrayList<AIFComponentContext> ccvselList;
	private BooleanObject lastvalcopy;
	private ClassificationObject[] firstccvclsobj;
	private boolean selck=false;
	private LinkedHashMap<String, String> modattrlist;
	boolean isreview=false;
	private Exception openexception;
	private Image tickimg;
	private String wf_type="MDM";
	private String step_wf=null;
	//private boolean isdlgSuccess;
	private String TSBusiUnit=null;
	private String cmvrno=null;
	private String desparttype=null;
	//private ArrayList<String> arr = null;
	private boolean isBypass =false;//added
	private boolean bypassUsrflg=false;
	protected Map<String,String> depmodifedactvalueMap;
	protected int depattrcntrlobjsize=0;
	private String SelBusUnit;
	private String SelParttype;
	private boolean  Hybridstatus=false;
	protected KeyLOVEntry[] keyLOVEntries;
	protected KeyLOVDefinition2 lovDef;
	protected Map<String,String> depmodifedvalueMap;
	protected Map<String,String> tmpdepmodifedvalueMap;
	/**
	 * Create the dialog.
	 * @param parentShell
	 * @param selectedObj 
	 */
	public UpdateMDMDlgForPRD(Shell parentShell,TCSession session,ExecutionEvent exe_evt,TCComponentItemRevision ItemRev, TCComponent selectedObj,ArrayList<TCComponentItemRevision> ccvList,String ProjPrdCls ) {
		super(parentShell);
		setShellStyle(SWT.SHELL_TRIM | SWT.BORDER);
		parentShell.setMaximized(true);
		this.session=session;
		this.ccvList=ccvList;
		this.ItemRev=ItemRev;
		this.selectedObj=selectedObj;
		this.parentShell=parentShell;
		this.exe_evt=exe_evt;
		this.objType=selectedObj.getType();
		this.isUpdatable=isObjectUpdatable();
		this.mandatorylist=new ArrayList();
		this.aifcomponentctxtList=new ArrayList();
		this.fullexpandable=fullExpand(this.selectedObj);
		this.uniqueErrObj=new ArrayList();
		this.isBypass=isBypass;
		this.attrid=attrid;
		this.attrval=attrval;
		this.bypassUsrflg=bypassUsrflg;
		namevalueP=new HashMap <String,Object>();
		m_commandTargetStateList = new ArrayList();
		m_commandTargetStateList1 = new ArrayList();
		localAIFComponentContextList= new ArrayList(); 
		this.keylovList=new TreeMap<String,KeyValueLOV>();
		this.modifedvalueMap=new TreeMap<String,String>();
		this.attrNameIDMap=new TreeMap<String,String>();
		this.initialValMap=new TreeMap<String,String>();
		this.modifedactvalueMap=new TreeMap<String,String>();
		this.isSuccess=false;
		this.keyLOVEntries=keyLOVEntries;
		this.lovDef=lovDef;
		this.DeptAttrFlg=DeptAttrFlg;
		bomexpansion=new BOMExpansion();
		this.ErcDMLObj=TechSpecUtil.SecondaryToPrimaryObj("CMHasSolutionItem",selectedObj);
		this.class_not_found=new ArrayList<TCComponentItemRevision>();
		ccvselList= new ArrayList<AIFComponentContext>();
		this.lastvalcopy=new BooleanObject(false);
		this.depmodifedactvalueMap=new TreeMap<String,String>();
		this.depmodifedvalueMap=new TreeMap<String,String>();
		this.tmpdepmodifedvalueMap=new TreeMap<String,String>();
		//try {	
			this.SelBusUnit=ProjPrdCls;
			this.TSBusiUnit=ProjPrdCls;
			System.out.println("UpdateMDMDlgForPRD TSBusiUnit="+TSBusiUnit );
		
			try {
				this.SelParttype=selectedObj.getTCProperty("t5_PartType").getDisplayableValue();
				if(SelParttype.equals("Vehicle") || SelParttype.equals("Vehicle Combination") || SelParttype.equals("Configurable VC") )//Case For : VC/Vehicle
				{
					this.Hybridstatus=new TechSpecUtil().getHybridVCFlag(session,(TCComponentItemRevision) selectedObj);
					System.out.println("inside vehicle  Hybridstatus="+Hybridstatus);
				}
			} catch (TCException | NotLoadedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		/*
		if(objType.equals("T5_TSCompRevision"))
		{
			System.out.println("objType:::"+objType );
			
				this.SelBusUnit=selectedObj.getTCProperty("t5_VCClassName").getDisplayableValue();
				this.depattrcntrlobjsize=TechSpecUtil.getDepattridFuncSize(SelBusUnit);
			
		 
		}
		else
		{

			
				this.SelParttype=selectedObj.getTCProperty("t5_PartType").getDisplayableValue();
			
			if(SelParttype.equals("Vehicle") || SelParttype.equals("Vehicle Combination") || SelParttype.equals("Configurable VC") )//Case For : VC/Vehicle
			{
				
				
				TCComponent[] techspec;
				
					techspec = selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
					if (techspec!=null && techspec.length>0) // If  TechSpec is attached to VC/Vehicle Show Classification Dialog for resp. BU
					{
						//UpdDlgFlg=true;
						SelBusUnit = techspec[0].getTCProperty("t5_VCClassName").getDisplayableValue();
						System.out.println("in vehicle selection TSBusiUnit:-"+SelBusUnit);
						
						 this.depattrcntrlobjsize=TechSpecUtil.getDepattridFuncSize(SelBusUnit);
						
						System.out.println("inside vehicle selection " +" depattrcntrlobjsize="+depattrcntrlobjsize);
					}
				
				
				

			}
					
			
			else
			{
				System.out.println("Part Type ["+SelParttype +"]" + "is not vehicle/TechSpec !!" );
				//return true;
				this.ModuleAddress=selectedObj.getTCProperty("t5_ModuleAddress").getDisplayableValue();
				String PartNo=selectedObj.getTCProperty("item_id").getDisplayableValue();
				if(TSBusiUnit==null || TSBusiUnit.isEmpty())
				{
					String VehCls1=null;
					String PartProjCode=PartNo.substring(0, 4);
					System.out.println("UpdateMDMDialog PartProjCode="+PartProjCode +" ModuleAddress="+ModuleAddress);
					if(PartProjCode!=null)
					{
						try {
							VehCls1=new TechSpecUtil().getVehClsNmaeForProj(PartProjCode);
							System.out.println("UpdateMDMDialog VehCls1="+VehCls1 );
							if(VehCls1.contains("PRD")==false) //if not PRD then set TSBusiUnit
							{ 
								TSBusiUnit=VehCls1;
							}
						} catch (NotLoadedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (TCException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					System.out.println("UpdateMDMDialog TSBusiUnit="+TSBusiUnit );
					
				}
			}


		
		}
		*/
		
		
		

	}

	public Exception getOpenexception() {
		return openexception;
	}


	public int constructCheckedInfoDialog()
	{

		int checkdlg = 0;
		TCComponentItem parent_item1=null;
		ArrayList<CommandTargetState> mul_commandTargetStateList=new ArrayList<CommandTargetState>();
		// ArrayList<AIFComponentContext> mul_aifcomponentctxtList=new ArrayList<AIFComponentContext>();
		AIFComponentContext localMultiAIFComponentContext;
		ArrayList<AIFComponentContext> localMulAIFComponentContextList=new ArrayList<AIFComponentContext>();
		int sz=ccvList.size();
		for (int f=0;f<sz;f++)  
		{


			TCComponentItemRevision item_rev1=ccvList.get(f);

			// System.out.println("item_rev1 cons:"+item_rev1.toDisplayString());

			try {
				parent_item1 = item_rev1.getItem();
				localMultiAIFComponentContext=new AIFComponentContext(parent_item1,item_rev1,"structure_revision");
				CommandTargetState cmdstate1=new CommandTargetState(localMultiAIFComponentContext,null);
				String desc=item_rev1.getTCProperty("object_name").getDisplayableValue();
				cmdstate1.setCaughtException(new TCException(desc));
				cmdstate1.setDone(true);
				localMulAIFComponentContextList.add(localMultiAIFComponentContext);
				mul_commandTargetStateList.add(cmdstate1);

			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



		}
		if(localMulAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localMulAIFComponentContextList.toArray(new AIFComponentContext[localMulAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			final Shell shl=app.getDesktop().getShell();

			TCSession session=(TCSession) app.getSession();

			TMLDataBean databean= new TMLDataBean(session, null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside update status printing step");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(mul_commandTargetStateList);

			checkdlg=  TMLCheckedMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },2,"Please Select CCV to Copy Same Classification Data:",ccvselList, lastvalcopy);

			/* 
        checkdlg.getM_treeTableView().getTreeViewer().addCheckStateListener(new ICheckStateListener() {
		      public void checkStateChanged(CheckStateChangedEvent event) {
		        // If the item is checked . . .


		    	  MessageBox.post(shl, "vgfgf", "hhghg", MessageBox.INFORMATION);

		    	  if(event.getChecked())
		    	  {
		    		  //event.
		    		  AIFComponentContext aif_ctx=checkdlg.getIC_AIFContext(event.getElement());
		    		  System.out.println("Checked::"+aif_ctx.getComponent().toString());
		    		  ccvselList.add(aif_ctx);
		    		  //selectitem. event.getChecked()
		    	  }
		      }
		    });*/
		}

		//return selecetdobj;

		return checkdlg;

	}


	public int constructMultiInfoDialog(LinkedHashMap <TCComponentItemRevision,String> ccvResult,boolean[] successList,String dismsg)
	{
		int processfurther = 0;
		TCComponentItem parent_item1=null;
		ArrayList<CommandTargetState> mul_commandTargetStateList=new ArrayList<CommandTargetState>();
		// ArrayList<AIFComponentContext> mul_aifcomponentctxtList=new ArrayList<AIFComponentContext>();
		AIFComponentContext localMultiAIFComponentContext;
		ArrayList<AIFComponentContext> localMulAIFComponentContextList=new ArrayList<AIFComponentContext>();
		HashMap<String,TCComponentItemRevision> no_cls_found=bomexpansion.getClass_not_found();
		int x=0;
		for (Map.Entry<TCComponentItemRevision,String> entry2 : ccvResult.entrySet())  
		{


			TCComponentItemRevision item_rev1=entry2.getKey();
			String msg=entry2.getValue();

			// System.out.println("item_rev1 cons:"+item_rev1.toDisplayString());

			try {
				parent_item1 = item_rev1.getItem();
				localMultiAIFComponentContext=new AIFComponentContext(parent_item1,item_rev1,"structure_revision");
				CommandTargetState cmdstate1=new CommandTargetState(localMultiAIFComponentContext,null);
				cmdstate1.setCaughtException(new TCException(msg));
				cmdstate1.setDone(successList[x++]);
				localMulAIFComponentContextList.add(localMultiAIFComponentContext);
				mul_commandTargetStateList.add(cmdstate1);

			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



		}
		if(localMulAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localMulAIFComponentContextList.toArray(new AIFComponentContext[localMulAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			TCSession session=(TCSession) app.getSession();

			TMLDataBean databean= new TMLDataBean(session, null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside update status printing step");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(mul_commandTargetStateList);

			// TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },1,null);
			processfurther=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },2,dismsg);

			// return false;
		}



		return processfurther;

	}


	public boolean constructMultiErrorDialog()
	{
		int processfurther = 0;
		TCComponentItem parent_item1=null;
		ArrayList<CommandTargetState> mul_commandTargetStateList=new ArrayList<CommandTargetState>();
		// ArrayList<AIFComponentContext> mul_aifcomponentctxtList=new ArrayList<AIFComponentContext>();
		AIFComponentContext localMultiAIFComponentContext;
		ArrayList<AIFComponentContext> localMulAIFComponentContextList=new ArrayList<AIFComponentContext>();
		HashMap<String,TCComponentItemRevision> no_cls_found=bomexpansion.getClass_not_found();
		for (Map.Entry<String, TCComponentItemRevision> entry2 : no_cls_found.entrySet())  
		{
			String msg=entry2.getKey();

			TCComponentItemRevision item_rev1=entry2.getValue();

			// System.out.println("item_rev1 cons:"+item_rev1.toDisplayString());

			try {
				parent_item1 = item_rev1.getItem();
				localMultiAIFComponentContext=new AIFComponentContext(parent_item1,item_rev1,"structure_revision");
				CommandTargetState cmdstate1=new CommandTargetState(localMultiAIFComponentContext,null);
				cmdstate1.setCaughtException(new TCException(msg));
				cmdstate1.setDone(false);
				localMulAIFComponentContextList.add(localMultiAIFComponentContext);
				mul_commandTargetStateList.add(cmdstate1);

			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



		}
		if(localMulAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localMulAIFComponentContextList.toArray(new AIFComponentContext[localMulAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			TCSession session=(TCSession) app.getSession();

			TMLDataBean databean= new TMLDataBean(session, null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside update status printing step");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(mul_commandTargetStateList);

			// TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },1,null);
			processfurther=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.YES_LABEL , IDialogConstants.NO_LABEL },1,"Below Modules Cassification-Hierarchy is Missing.\nDo you want to Continue ? ");

			// return false;
		}

		System.out.println("processfurther::"+processfurther);
		if(processfurther==0)
			return true;

		return false;

	}

	public boolean isSuccess() {
		return isSuccess;
	}



	protected boolean ServiceDataError(final ServiceData data)
	{

		if(data.sizeOfPartialErrors() > 0)
		{
			for(int i = 0; i < data.sizeOfPartialErrors(); i++)
			{
				for(String msg :
					data.getPartialError(i).getMessages())
					System.out.println("ServiceDataError:"+msg);
			}

			return true;
		}

		return false;
	}


	// Determines whether to Exapnd upto to Second Level( return true)
	// For all Case (CCV/VC/Vehicle/Techspes Header/Super SVR) except Module  Exapnd upto to Second Level
	public boolean fullExpand(TCComponent obj)
	{

		System.out.println("fullExpand function \n");
		String SelobjType= selectedObj.getType();
		System.out.println("fullExpand function SelobjType=  \n"+SelobjType+ "ItemRev="+ItemRev);
		if(SelobjType.equals("Design Revision"))
		{

			try {
				String SelectedObjType=selectedObj.getTCProperty("t5_PartType").getDisplayableValue();
				if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Vehicle Combination")|| SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))
					return true;
				else
					return false;
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}



		return true; // return false;


	}



	public Object[] getAllTreeObjects(ArrayList<ClassificationTreeLine> treeobjs)
	{

		String PartProjCode=null;
		for(int d=0;d<treeobjs.size();d++)
		{

			ClassificationTreeLine parentElement=treeobjs.get(d);

			if(parentElement instanceof ClassificationTreeLine)
			{

				ClassificationTreeLine p = (ClassificationTreeLine) parentElement;
				System.out.println("parentElement::>>>>"+parentElement);
				SortedMap <String,ArrayList<ClassificationTableLine>> annotatonMap=new TreeMap <String,ArrayList<ClassificationTableLine>>();
				TCComponentItemRevision tcrev= p.getItemrev();
				AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
				TCSession session=(TCSession) app.getSession();
				//GetClassifiedAttr getProps= new GetClassifiedAttr(tcrev,session);

				TCComponentItem tc_ico_item=null;
				try {
					tc_ico_item=tcrev.getItem();
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				//GetClassifiedAttr getProps= new GetClassifiedAttr(tc_ico_item,session);
				//GetClassifiedAttr2 getProps= new GetClassifiedAttr2(tc_ico_item,session);
				String modaddress=p.getModuleAddress();
				System.out.println("UpdateTechSpecDialog TSBusiUnit="+TSBusiUnit);
				if(TSBusiUnit==null || TSBusiUnit.isEmpty())
				{
					String PartNo=parentElement.getObjectid();
					PartProjCode=PartNo.substring(0, 4);
					System.out.println("UpdateMDMDialog PartProjCode="+PartProjCode +" ModuleAddress="+ModuleAddress);
					if(PartProjCode!=null)
					{
						try {
							TSBusiUnit=new TechSpecUtil().getClsNmaeForModuleAdd(PartProjCode,ModuleAddress);
						} catch (NotLoadedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (TCException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					System.out.println("UpdateMDMDialog TSBusiUnit="+TSBusiUnit );
					
				}
				GetClassifiedAttr2 getProps= new GetClassifiedAttr2(tc_ico_item,session);
				if(getProps!=null)
				{
					try {
						//if(getProps.getICOProps(TSBusiUnit)!=null)
						//if(getProps.getICOProps2()!=null)
							//modaddress=getProps.getICOProps(TSBusiUnit).getCid();
						if(getProps.getICOProps(TSBusiUnit)!=null)
							//modaddress=getProps.getICOProps2().getCid();
							modaddress=getProps.getICOProps(TSBusiUnit).getCid();
					} catch (ServiceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				ArrayList<ClassificationTableLine> classificationList=new ArrayList<ClassificationTableLine>();
				try {
					classificationList = new GetModuleAttributesForClasses(modaddress,session).testgetGetAttributesForClasses();
				} catch (ServiceException | TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					openexception=e;
					this.isSuccess=false;
				}
				LinkedHashMap<String,ClassificationTableLine> classificationList1=new LinkedHashMap<String,ClassificationTableLine>();
				for(int a=0;a<classificationList.size();a++)
				{
					ClassificationTableLine clstb=classificationList.get(a);
					classificationList1.put(clstb.getAttrID(), clstb);

				}


				////

				for(Map.Entry<String, String> modentval: modattrlist.entrySet())
				{

					String key=modentval.getKey();
					String modval=modentval.getValue();

					ClassificationTableLine p1 = classificationList1.get(key);

					if(modval!=null&&p1!=null)
					{

						//String classid=p1.getParent().getParent().getModuleAddress();
						String attrid=p1.getAttrID();
						String val=p1.getAttrValue();
						String lovid=p1.getLovID();
						int arraysize=p1.getArraySize();
						String deptattr=p1.getDepattr();
						String deptcfg=p1.getDepattrcfg();
						String deptval=modifedvalueMap.get(deptattr);
						if(deptval==null)
							deptval=initialValMap.get(deptattr);
						String kv=modval;
						String kk="";
						if(Integer.parseInt(lovid)<0 )
						{

							try {
								final KeyValueLOV keyvallov=	new GetKeyLOVs2Sample3().testGetKeyLOVs2(modaddress,attrid,lovid,deptattr,deptcfg,deptval,arraysize);

								ArrayList<String> keylovlst=keyvallov.getKey();
								ArrayList<String> keylovlst1=keyvallov.getValue();


								for(int r=0;r<keylovlst.size();r++)
								{

									kk=keylovlst.get(r);
									if(kk.equals(modval))
									{
										kv=keylovlst1.get(r);
										break;
									}


								}
							} catch (ServiceException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}			

						else
							kv=modval;
						p1.setNewValue(kv);
					}
				}
				/////

				
				System.out.println(" 2222TSBusiUnit:-"+TSBusiUnit);
				try {
					//if(getProps.getICOProps(TSBusiUnit)!=null)
					//if(getProps.getICOProps2()!=null)
					if(getProps.getICOProps(TSBusiUnit)!=null)
					{
						Map<BigInteger, AttributeValues> map2 = null;

						//map2 = getProps.getICOProps(TSBusiUnit).getAttrValuesMap();
						//map2 = getProps.getICOProps2().getAttrValuesMap();
						map2 = getProps.getICOProps(TSBusiUnit).getAttrValuesMap();
						for( Object key2 : map2.keySet())
						{
							//System.out.println("UpdateTechSpecDialog keyw.get(key2)="+key2.getClass());

							//System.out.println("UpdateTechSpecDialog="+map2.get(key2).getClass());
							AttributeValues fv=map2.get(key2);
							// for(int f=0;f<classificationList.size();f++)
							{
								// ClassificationTableLine tabline=classificationList.get(f);

								// if(tabline.getAttrID().equals(key2.toString()))
								ClassificationTableLine tabline=classificationList1.get(key2.toString());
								if(tabline!=null)
								{


									Value[] vals=  fv.values;
									String allvalue="";
									System.out.println("1VVVkey2::"+key2+" Val:"+vals.length);	
									for(int x1=0;x1<vals.length;x1++)
									{
										//System.out.println("key2"+key2+" Val:"+vals[x1].attrValue);		      
										allvalue+=vals[x1].attrValue;

										if(x1<vals.length-1)
											allvalue+=PreferenceValue.getARRAY_DELMITER();

									}

									if(vals.length>0)
									{
										tabline.setAttrValue(allvalue);
										System.out.println("allvalue::"+allvalue);
									}


									///////nnnn
									attrNameIDMap.put(tabline.getAttrID(), tabline.getAttrName());

								}
							}
						}

					}
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				for(int r=0;r<classificationList.size();r++)
				{
					//Map<Object, AttributeValues> AttrValMap=getProps.getICOProps().getAttrValuesMap();

					ClassificationTableLine tab_line=classificationList.get(r);
					System.out.println("ANNO:"+ tab_line);
					String anno_txt=tab_line.getAnnotation();
					initialValMap.put(tab_line.getAttrID(), tab_line.getAttrValue());
					System.out.println("ANNO TXT::"+ anno_txt);
					ClassificationAnnotationLine annot_lin=new ClassificationAnnotationLine(anno_txt);
					ArrayList<ClassificationTableLine> annotation_clastabline=annotatonMap.get(anno_txt);



					if(annotation_clastabline==null)
					{
						annotation_clastabline=new ArrayList<ClassificationTableLine>();
						annotation_clastabline.add(tab_line);
						annotatonMap.put(tab_line.getAnnotation(), annotation_clastabline);
					}
					else
					{

						annotation_clastabline.add(tab_line);

					}
				}

				Set<String> keys = annotatonMap.keySet();
				ArrayList<ClassificationAnnotationLine> cl_annotlist1=new ArrayList<ClassificationAnnotationLine>();
				for(String key: keys){
					ClassificationAnnotationLine clsanno_line=new ClassificationAnnotationLine(key);
					clsanno_line.setParent(p);
					cl_annotlist1.add(clsanno_line);

					ArrayList<ClassificationTableLine> arList=annotatonMap.get(key);
					clsanno_line.setAttrList(arList);

					for(int k=0;k<arList.size();k++)
					{

						arList.get(k).setParent(clsanno_line);

					}
					// System.out.println("Value of "+key+" is: "+hm.get(key));
				}


				p.setAttrList(cl_annotlist1);

				ArrayList<Object> allobjs=new ArrayList<Object>();
				allobjs.addAll(cl_annotlist1);
				allobjs.addAll(classificationList);
				//	return allobjs.toArray();//classificationList.toArray();
			}

			else
			{
				//return null;
			}
		}
		return null;
	}

	public boolean isObjectUpdatable() 
	{
		// TODO Auto-generated method stub
		//boolean checkedout=selectedObj.isCheckedOut();
		//TTT

		String userIdS=null;
		isBypass =session.hasBypass();//added
		bypassUsrflg=false;
		TCComponentUser user = session.getUser();
		try {
			userIdS = user.getUserId();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	System.out.println("\nSession User Login Name == " + userIdS + "\n");
    	System.out.println("b4 bypassflg="+bypassUsrflg);
    	bypassUsrflg=new TechSpecUtil().bypassUsrfunc(userIdS,"ByPassUser");
		 System.out.println("bypassflg="+bypassUsrflg);
		 
		if(isBypass==true || bypassUsrflg==true)
		{
		

			boolean answer=MessageDialog.openQuestion(parentShell,"TechSpec Update Validation", "Do you Want to Bypass TechSpec Update Validation?" );
			 System.out.println("bypassflg answer="+answer);
			if(answer==true)
			{
				return answer;
			}
			else
			{
				return false;
			}


		}

		if(bypassUsrflg==false)
		{

		/**** Rule for Classification Updation/Edit****/

		//Rule:1 -> For Selected CCV/Vehicle/Module:-> A. If Session User is Checked-out Owner(During Check-in, Classification Dialog will show ) ;[Editable]
		//OR 
		//B. If Part is not Check-out  ,part attached to Task is User-WrkList in Step-Name :Update VC attributes and Tech Spec Header;[Editable]


		//Rule:2 -> For  Selected TechSpec Header:->  A. VC/ vehicle Should be Attached to Tech-Spec (may not be attach/not attach to DML) ;[Not-Editable]
		//AND
		// B. Tech-Spec attached to Task should be in  User Work List in Step-Name :Update VC attributes and Tech Spec Header;[Editable]


		//Rule:3 -> For  Selected Super-SVR:->  A. Super-SVR(VariantRule) attached to Task should be in Reference Item  User Work List in Step-Name :Update VC attributes and Tech Spec Header ;[Editable]


		/*****************END Rule********************/



		TCComponentItemRevision primaryObj=null;
		TCComponent[] allprimaryObj=null;
		if(objType.equals("Design Revision"))
		{
			//Rule :1-A
			boolean is_Checkout=selectedObj.isCheckedOut();	
			System.out.println("in isObjectUpdatableis_Checkout="+is_Checkout);
			if(is_Checkout)
			{
				TCComponent check_user=null;
				try {
					check_user = selectedObj.getTCProperty("checked_out_user").getReferenceValue();
				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				System.out.println("in check_user::->"+check_user.toDisplayString()+":SES:"+ session.getUser());
				if(check_user!=null && session.getUser().equals(check_user))
				{

					System.out.println("in check_user!=null && session.getUser().equals(check_user)::->"+true);
					return true;
				}

			}
			//Rule :1-B
			allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMReferences",selectedObj);
			System.out.println("in isObjectUpdatable Primary Object="+allprimaryObj);

			if(allprimaryObj==null || allprimaryObj.length==0)
				allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMHasSolutionItem",selectedObj);
		}
		else if(objType.equals("VariantRule"))
		{
			//Rule 2
			allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMReferences",selectedObj);
		}
		else if(objType.equals("T5_TSCompRevision")) 
		{
			//Rule 3
			try {
				TCComponentItemRevision VCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
				allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMHasSolutionItem",selectedObj);
				System.out.println("in isObjectUpdatable Primary Object="+primaryObj);

				if(allprimaryObj==null || allprimaryObj.length==0)
					allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMReferences",selectedObj);
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		try {
			//primaryObj should be in  User Work List in Step-Name :Update VC attributes and Tech Spec Header ;

			if(allprimaryObj!=null)
			{
				for(int h=0;h<allprimaryObj.length;h++)
				{
					primaryObj=(TCComponentItemRevision) allprimaryObj[h];
					System.out.println("if in isObjectUpdatable Primary Object="+primaryObj.toDisplayString());
					String taskID=null;
					System.out.println("in isObjectUpdatable objType="+objType);
					taskID=primaryObj.getTCProperty("item_id").getDisplayableValue();


					//19-05-2021

					try {
						step_wf=TechSpecUtil.getWFStepName(wf_type);
					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (TCException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					if(step_wf==null)
						//step_wf="Update VC attribute*";
						step_wf="Add affected parts into Reference Item*";
					System.out.println(wf_type+":"+step_wf);
					//end

					boolean in_wfstep=TechSpecUtil.getwrkflowActivobj(selectedObj.getSession(),taskID,/*"Update VC Attribute Assignment"*/step_wf,"4",session.getUserName());

					if(in_wfstep)
					{
						System.out.println("["+h+"]Taking "+taskID+" as WFSTEP::"+in_wfstep);
						return in_wfstep;

					}

					else
					{

						System.out.println("["+h+"]Skipping "+taskID+" as WFSTEP::"+in_wfstep);
					}

				}
				//return	false;
			}
			else 
			{
				System.out.println("else in isObjectUpdatable Primary Object=null");
				return false;
			}
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

		return false;
	}


	public Point getCenterPoint()
	{
		Shell localShell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		Rectangle localRectangle = localShell.getBounds();
		return new Point(localRectangle.x + localRectangle.width / 2, (localRectangle.y + localRectangle.height) / 2);
	}

	protected
	Point getInitialLocation(Point paramPoint)
	{
		Point localPoint = getCenterPoint();
		return new Point(localPoint.x - paramPoint.x / 2, localPoint.y - paramPoint.y / 2);
	}


	public void populateField()
	{
		System.out.println("2ModuleAddress="+ModuleAddress);
		System.out.println("2InstanceID="+ObjectID);
		try {
			tsdesc.setText(ModuleAddress);
			classificationList=new GetModuleAttributesForClasses(ModuleAddress,session).testgetGetAttributesForClasses();
		} catch (ServiceException | TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			openexception=e;
			this.isSuccess=false;
		}
	}


	protected void fillContextMenu(IMenuManager contextMenu,final IStructuredSelection selection) {
		contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));

		final IWorkbenchWindow  workbenchWindow =  PlatformHelper.getCurrentWorkbenchWindow();

		String opentcid="com.teamcenter.rac.ui.lhn.sendto";
		String viewpropid="com.teamcenter.rac.lhn.properties";

		ICommandService commandService = (ICommandService) workbenchWindow.getService(ICommandService.class);
		Command opentccmd=commandService.getCommand(opentcid);
		Command viewpropcmd=commandService.getCommand(viewpropid);

		ICommandImageService commandImageService = (ICommandImageService) workbenchWindow.getService(ICommandImageService.class);
		ImageDescriptor imgdestc=commandImageService.getImageDescriptor(opentcid);
		ImageDescriptor imgdescprop=commandImageService.getImageDescriptor(viewpropid);




		try {
			contextMenu.add(new Action(opentccmd.getName(),imgdestc) {
				@Override
				public void run() {
					// implement this

					ClassificationTreeLine treeline=(ClassificationTreeLine) selection.getFirstElement();

					new OpenCommand(AIFUtility.getCurrentApplication().getDesktop(),treeline.getItemrev()).executeModeless();
				}
			});
		} catch (NotDefinedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			contextMenu.add(new Action(viewpropcmd.getName(),imgdescprop) {
				@Override
				public void run() {

					// don't do anything here
					ClassificationTreeLine treeline=(ClassificationTreeLine) selection.getFirstElement();

					/* ICommandService commandService = (ICommandService) workbenchWindow.getService(ICommandService.class);
                         Command cmd=commandService.getCommand("com.teamcenter.rac.checkIn");

                        ExecutionEvent eventWithParam = new ExecutionEvent(cmd, 
                                      Collections.singletonMap(ConstantsCOMMAND_PARAM, "true"), null, null);
                         try {
                                     cmd.execute(eventWithParam);
                              } catch (ExecutionException e) {
                                     // TODO Auto-generated catch block
                                     e.printStackTrace();
                              } catch (NotHandledException e) {
                                     // TODO Auto-generated catch block
                                     e.printStackTrace();
                              }

                         IHandlerService handlerService = (IHandlerService) workbenchWindow.getService(IHandlerService.class);
                         try {
                             handlerService.executeCommand("com.teamcenter.rac.checkIn", null);
                             } catch (Exception ex) {
                                 ex.printStackTrace();
                                 // Give message
                                 }*/


					new PropertiesCommand(treeline.getItemrev(),new Frame()).executeModeless();
				}
			});
		} catch (NotDefinedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		setTitle("Update Tech Spec Header ");
		final Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));


		tickimg=ImageDescriptor.createFromURL(FileLocator.find(FrameworkUtil.getBundle(this.getClass()),new Path("icons/tick.jpg"), null)).createImage();



		//if(this.fullexpandable==false)
		//{
		try 
		{

			String type=selectedObj.getType();
			if(type.equals("T5_TSCompRevision"))
				this.SelObjType="Tech Spec";
			else if(type.equals("Design Revision"))
				this.SelObjType=selectedObj.getTCProperty("t5_PartType").getDisplayableValue();
			else if(type.equals("VariantRule"))
				this.SelObjType="SVR";

			setTitle("Update "+this.SelObjType+" Header ");
		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		//}

		Group grpGeneralInfo = new Group(container, SWT.NONE);
		grpGeneralInfo.setForeground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		grpGeneralInfo.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		grpGeneralInfo.setEnabled(false);
		grpGeneralInfo.setText("General info");
		grpGeneralInfo.setBounds(0, 0, 761, 122);
		grpGeneralInfo.setVisible(this.fullexpandable);

		String ModuleVehicledsc=SelObjType +" Description";
		System.out.println("ModuleVehicledsc="+ModuleVehicledsc);

		Label lblModuleAddress = new Label(grpGeneralInfo, SWT.NONE);
		lblModuleAddress.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		lblModuleAddress.setBounds(30, 51, 135, 15);
		lblModuleAddress.setText(ModuleVehicledsc);//"Tech Spec Description");

		tsdesc = new Text(grpGeneralInfo, SWT.BORDER | SWT.READ_ONLY | SWT.MULTI);
		tsdesc.setBounds(203, 47, 213, 48);

		tsnum = new Text(grpGeneralInfo, SWT.BORDER);
		tsnum.setEditable(false);
		tsnum.setBounds(203, 19, 213, 21);
		//text_2.setText(ModuleNum);


		Label lblModuleNumber = new Label(grpGeneralInfo, SWT.NONE);
		lblModuleNumber.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		lblModuleNumber.setBounds(30, 23, 120, 15);

		//lblModuleNumber.setText("Module Number");

		System.out.println("SelObjType="+SelObjType);
		String ModuleVehicleNum=SelObjType +" Number";
		System.out.println("ModuleVehicleNum="+ModuleVehicleNum);
		lblModuleNumber.setText(ModuleVehicleNum);//"Tech Spec Number");

		Label lblClassifiedInstanceName = new Label(grpGeneralInfo, SWT.NONE);
		lblClassifiedInstanceName.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblClassifiedInstanceName.setBounds(422, 25, 94, 15);
		lblClassifiedInstanceName.setText("Ownning User");

		tsou = new Text(grpGeneralInfo, SWT.BORDER);
		tsou.setBounds(544, 19, 201, 21);
		//text_3.setText(ObjectID);
		tsbu = new Text(grpGeneralInfo, SWT.BORDER | SWT.READ_ONLY);
		tsbu.setBounds(203, 101, 211, 21);
		//text_1.setText(ObjectID);
		//Setting TS value in dialog


		Label lblClassifiedInstanceId = new Label(grpGeneralInfo, SWT.NONE);
		lblClassifiedInstanceId.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblClassifiedInstanceId.setBounds(30, 104, 135, 15);
		lblClassifiedInstanceId.setText("Business Unit");
		//lblModuleNumber.
		final Group grpClassificationPropertiesValues = new Group(container, SWT.NONE);
		/*	
		//if(isUpdatable==false)
				{


					String readonlypath="icons/readonly.png";
					Bundle bundle_bg = FrameworkUtil.getBundle(this.getClass());

					URL readonlyurl = FileLocator.find(bundle_bg,  new Path(readonlypath), null);
					ImageDescriptor imageDescriptor_readonly = ImageDescriptor.createFromURL(readonlyurl);
					Image bgimg=imageDescriptor_readonly.createImage();


					 setbackGroundWaterMark(grpClassificationPropertiesValues,bgimg,bgimg.getImageData().width,bgimg.getImageData().height);


				//	parentShell.setImage(imageDescriptor_readonly.createImage());

				  //     parentShell.setBackgroundMode(SWT.INHERIT_FORCE);  

				}
		 */

		grpClassificationPropertiesValues.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpClassificationPropertiesValues.setText("Classification Properties Values");
		grpClassificationPropertiesValues.setBounds(10, 128, 751, 475);

		searchText = new Text(grpClassificationPropertiesValues, SWT.BORDER);
		searchText.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent ke) {
				System.out.print("kjk:"+searchText.getText());
				searchFilter.setSearchText(searchText.getText());
				treeViewer.refresh();
				treeViewer.expandAll();

			}

		});
		searchText.setBounds(120, 25, 609, 26);

		treeViewer = new TreeViewer(grpClassificationPropertiesValues, SWT.BORDER | SWT.FULL_SELECTION);
		tree = treeViewer.getTree();

		searchFilter=new SearchViewerFilter();
		treeViewer.addFilter(searchFilter);

		tree.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		tree.setLinesVisible(true);
		tree.setHeaderVisible(true);
		tree.setBounds(10, 57, 719, 392);

		TreeViewerColumn treeViewerColumn = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn = treeViewerColumn.getColumn();
		tblclmnNewColumn.setWidth(122);
		tblclmnNewColumn.setText("Classified Objects");

		TreeViewerColumn treeViewerColumn_7 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblcmnType = treeViewerColumn_7.getColumn();
		tblcmnType.setWidth(80);
		tblcmnType.setText("Type");
		//	treeViewerColumn.setEditingSupport(new ClassificationEditingSupport1(treeViewer));

		TreeViewerColumn treeViewerColumn_1 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_1 = treeViewerColumn_1.getColumn();
		tblclmnNewColumn_1.setWidth(100);
		tblclmnNewColumn_1.setText("Attribute ID");

		TreeViewerColumn treeViewerColumn_8 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn trclmnTceAttrId = treeViewerColumn_8.getColumn();
		trclmnTceAttrId.setWidth(100);
		trclmnTceAttrId.setText("TCE Attr ID");
		//treeViewerColumn_1.setEditingSupport(new ClassificationEditingSupport2(treeViewer));

		TreeViewerColumn treeViewerColumn_2 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_2 = treeViewerColumn_2.getColumn();
		tblclmnNewColumn_2.setWidth(100);
		tblclmnNewColumn_2.setText("Attribute Name");
		//treeViewerColumn_2.setEditingSupport(new ClassificationEditingSupport3(treeViewer));

		TreeViewerColumn treeViewerColumn_3 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnAttributeValue = treeViewerColumn_3.getColumn();
		tblclmnAttributeValue.setWidth(100);
		tblclmnAttributeValue.setText("Attribute Value");


		TreeViewerColumn treeViewerColumn_9 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn trclmnNewValueColumn = treeViewerColumn_9.getColumn();
		trclmnNewValueColumn.setWidth(100);
		trclmnNewValueColumn.setText("New Value");

		///

		treeViewerColumn_9.setLabelProvider(new ColumnLabelProvider() {


			public Image getImage(Object element) {
				if(isreview&&modattrlist.size()>0)
				{
					if(element instanceof ClassificationTableLine) 
					{
						ClassificationTableLine p = (ClassificationTableLine) element;
						if(modattrlist.get(p.getAttrID())!=null)
						{
							return tickimg;
						}
					}
					//return null;
				}

				return null;
			}

			public String getText(Object element) {
				//if(isreview&&modattrlist.size()>0)
				{
					if(element instanceof ClassificationTableLine)
					{




						ClassificationTableLine p = (ClassificationTableLine) element;

						return p.getNewValue();
					}

				}

				return null;
			}

			public Color getBackground(final Object element) {

				if(isreview&&modattrlist.size()>0)
				{
					if(element instanceof ClassificationTableLine) 
					{
						ClassificationTableLine p = (ClassificationTableLine) element;
						if(modattrlist.get(p.getAttrID())!=null)
						{
							return  Display.getCurrent().getSystemColor(SWT.COLOR_YELLOW);
						}
					}
				}


				return super.getBackground(element);
			}

			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});

		///

		//	treeViewerColumn_3.setEditingSupport(new ClassificationEditingSupport4(treeViewer));

		Group group = new Group(container, SWT.NONE);
		group.setText("General info");
		group.setEnabled(false);
		//group.setBounds(11, 144, 746, 122);
		group.setBounds(0, 0, 745, 122);
		group.setVisible(!this.fullexpandable);

		Label label = new Label(group, SWT.NONE);
		label.setText("Classification Address");
		label.setBounds(30, 35, 135, 15);

		text = new Text(group, SWT.BORDER | SWT.READ_ONLY);
		text.setText("<dynamic>");
		text.setBounds(203, 35, 213, 21);

		text_1 = new Text(group, SWT.BORDER);
		text_1.setText("<dynamic>");
		text_1.setEditable(false);
		text_1.setBounds(203, 8, 213, 21);

		Label label_1 = new Label(group, SWT.NONE);
		label_1.setText("<dynamic> Number");
		label_1.setBounds(31, 14, 120, 15);

		Label label_2 = new Label(group, SWT.NONE);
		label_2.setText("Classification Name");
		label_2.setBounds(30, 65, 123, 15);

		text_2 = new Text(group, SWT.BORDER);
		text_2.setText("<dynamic>");
		text_2.setBounds(203, 62, 213, 21);

		text_3 = new Text(group, SWT.BORDER | SWT.READ_ONLY);
		text_3.setText("<dynamic>");
		text_3.setBounds(205, 89, 211, 21);

		Label label_3 = new Label(group, SWT.NONE);
		label_3.setText("Classified Instance ID");
		label_3.setBounds(30, 92, 135, 15);




		label_1.setText(ModuleVehicleNum);
		System.out.println("1111isUpdatable="+isUpdatable);
		//System.out.println("isUpdatable()="+isObjectUpdatable());
		//treeViewer.setContentProvider(ArrayContentProvider.getInstance());

		treeViewerColumn_3.setEditingSupport(new MDMEditingSupport4PRD(this,treeViewerColumn_3.getViewer(),false,1));
		treeViewerColumn_9.setEditingSupport(new MDMEditingSupport4PRD(this,treeViewerColumn_9.getViewer(),true,1));

		/*CellEditor[] editors = new CellEditor[4];
	    editors[0] = new TextCellEditor(tree);
	    editors[1] = new TextCellEditor(tree);
	    editors[2] = new TextCellEditor(tree);
	    editors[3] = new ComboBoxCellEditor(tree);*/


		//lblModuleNumber.setText("lmnkmnk");


		if(icoval!=null)

		{
			ModuleAddress=icoval.getCid();
			ObjectID=icoval.getIcoId();
			tsdesc.setText(ModuleAddress);
			tsbu.setText(ObjectID);
			clsobjs=icoval.getClsobjs();


			System.out.println("icoval!=null clsobjs="+clsobjs);

		}


		Label lblVcSubClass = new Label(grpGeneralInfo, SWT.NONE);
		lblVcSubClass.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblVcSubClass.setBounds(422, 50, 87, 21);
		lblVcSubClass.setText("VC Sub Class");

		tsvsc = new Text(grpGeneralInfo, SWT.BORDER);
		tsvsc.setText("<dynamic>");
		tsvsc.setBounds(544, 47, 201, 21);

		Label lblNewLabel = new Label(grpGeneralInfo, SWT.NONE);
		lblNewLabel.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblNewLabel.setBounds(422, 74, 108, 21);
		lblNewLabel.setText("Owner Design Unit");

		tsodu = new Text(grpGeneralInfo, SWT.BORDER);
		tsodu.setBounds(544, 74, 201, 21);

		Label lblOwnerDesign = new Label(grpGeneralInfo, SWT.NONE);
		lblOwnerDesign.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblOwnerDesign.setBounds(422, 104, 108, 18);
		lblOwnerDesign.setText("Owner Design Dept");

		tsodd = new Text(grpGeneralInfo, SWT.BORDER);
		tsodd.setBounds(544, 101, 201, 21);



		/**************MENU used to send the object into My Teamcenter from custom dialog*********/

		MenuManager menuMgr = new MenuManager();
		menuMgr.setRemoveAllWhenShown(true);

		menuMgr.addMenuListener(new IMenuListener() {
			@Override
			public void menuAboutToShow(IMenuManager menuManager) {
				IStructuredSelection selection = (IStructuredSelection) treeViewer.getSelection();
				if(selection.getFirstElement() instanceof ClassificationTreeLine)
					fillContextMenu(menuManager,selection);

			}


		});

		//Query New Value

		try {
			isReview();
			modattrlist=queryUpdatedControlObject();
		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (NotLoadedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		///END Query New Value

		Menu menu = menuMgr.createContextMenu(treeViewer.getControl());

		treeViewer.getControl().setMenu(menu);
		/**************END MENU*********************/


		//populateField();
		System.out.println("Calling populateTable func for modattrlist="+modattrlist);

		if(icoval!=null)
		{

			Map<BigInteger,AttributeValues> map2=icoval.getAttrValuesMap();
			for( Object key2 : map2.keySet())
			{
				//System.out.println("keyw.get(key2)="+key2.getClass());

				//System.out.println("kssl="+map2.get(key2).getClass());
				AttributeValues fv=map2.get(key2);
				for(int f=0;f<classificationList.size();f++)
				{
					ClassificationTableLine tabline=classificationList.get(f);

					if(tabline.getAttrID().equals(key2.toString()))

					{


						Value[] vals=  fv.values;
						String allvalue="";
						System.out.println("VVVkey2::"+key2+" Val:"+vals.length);	
						for(int x1=0;x1<vals.length;x1++)
						{
							//System.out.println("key2"+key2+" Val:"+vals[x1].attrValue);		      
							allvalue+=vals[x1].attrValue;

							if(x1<vals.length-1)
								allvalue+=PreferenceValue.getARRAY_DELMITER();

						}

						if(vals.length>0)
						{
							tabline.setAttrValue(allvalue);
							System.out.println("allvalue::"+allvalue);
						}
					}
				}
			}
		}



		TreeViewerColumn treeViewerColumn_4 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_3 = treeViewerColumn_4.getColumn();
		tblclmnNewColumn_3.setWidth(78);
		tblclmnNewColumn_3.setText("Unit");

		TreeViewerColumn treeViewerColumn_5 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_4 = treeViewerColumn_5.getColumn();
		tblclmnNewColumn_4.setWidth(67);
		tblclmnNewColumn_4.setText("LovID");

		TreeViewerColumn treeViewerColumn_6 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_5 = treeViewerColumn_6.getColumn();
		tblclmnNewColumn_5.setWidth(63);
		tblclmnNewColumn_5.setText("Array");



		treeViewerColumn.setLabelProvider(new ColumnLabelProvider() {



			public Image getImage(Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					TCComponentItemRevision tcobj=p.getItemrev();
					String classicon=null;
					try {
						String objecttype=tcobj.getPropertyDisplayableValue("t5_PartType");
						System.out.println("objecttype="+objecttype);
						if(objecttype.matches("Vehicle"))
						{
							classicon="icons/tmlpart_16.png";
						}
						else if (objecttype.matches("Module"))
						{
							classicon="icons/moduleIcon.png";
						}


					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


					/*Bundle bundle = FrameworkUtil.getBundle(this.getClass());
		    		// use the org.eclipse.core.runtime.Path as import
		    		System.out.println("classicon="+classicon);
		    		URL url = FileLocator.find(bundle,
		    		    new Path(classicon), null);
		    		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);*/

					return TCTypeRenderer.getImage(tcobj); //imageDescriptor.createImage();
					//return TCTypeRenderer.getTypeImage(tcobj.getType(), null); //imageDescriptor.createImage();
					//return imageDescriptor.createImage();
				}
				return null;
			}

			public String getText(Object element) {

				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return p.getClassifiedObject();
				}
				return null;
			}

			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}

		});
		treeViewerColumn_1.setLabelProvider(new ColumnLabelProvider() {
			public Image getImage(Object element) {
				if(element instanceof ClassificationTableLine) 
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					Bundle bundle = FrameworkUtil.getBundle(this.getClass());
					// use the org.eclipse.core.runtime.Path as import
					String path="icons/AttrIcon16x16.png";;
					if(p.isIsmandatory())
						path="icons/AttrReqIcon16x16.png";

					URL url = FileLocator.find(bundle,
							new Path(path), null);
					ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
					return imageDescriptor.createImage();
					//return null;
				}
				return null;
			}

			public String getText(Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return p.getModuleAddress();
				}
				else if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getAttrID();
				}
				else
				{
					return null;
				}
			}
			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});

		treeViewerColumn_2.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return p.getClassificationName();
				}
				else if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getAttrName();
				}
				return null;
			}
			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});


		treeViewerColumn_3.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {
				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getAttrValue();
				}
				return null;
			}

			public Color getBackground(final Object element) {

				if(isreview&&modattrlist.size()>0)
				{
					if(element instanceof ClassificationTableLine) 
					{
						ClassificationTableLine p = (ClassificationTableLine) element;
						if(modattrlist.get(p.getAttrID())!=null)
						{
							return  Display.getCurrent().getSystemColor(SWT.COLOR_YELLOW);
						}
					}
				}


				return super.getBackground(element);
			}

			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});

		treeViewerColumn_4.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getUnit();
				}
				return null;
			}
			public Color getForeground(final Object element) {
				if(element instanceof ClassificationTreeLine) 
				{
					ClassificationTreeLine p = (ClassificationTreeLine) element;
					return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
				}

				return super.getBackground(element);
			}
		});

		treeViewerColumn_5.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getLovID();
				}
				return null;
			}
		});


		treeViewerColumn_6.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getArraySize()+"";
				}
				return null;
			}
		});


		treeViewerColumn_7.setLabelProvider(new ColumnLabelProvider() {

			public Image getImage(Object element) {
				if(element instanceof ClassificationAnnotationLine) 
				{
					ClassificationAnnotationLine p = (ClassificationAnnotationLine) element;
					Bundle bundle = FrameworkUtil.getBundle(this.getClass());
					String mname=p.getAnnotation();
					String iconmodule="MISC";
					if(mname!=null && mname.contains("[") && mname.contains("]"))
					{
						String temp_iconmodule=mname.substring(mname.indexOf("[")+1, mname.indexOf("]"));
						System.out.println("SSS::"+temp_iconmodule);
						if(temp_iconmodule!=null)
							iconmodule=temp_iconmodule;

					}
					String iconname=iconmodule+".PNG";
					// use the org.eclipse.core.runtime.Path as import
					String path="icons/"+iconname;


					URL url = FileLocator.find(bundle,
							new Path(path), null);
					ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
					return imageDescriptor.createImage();
					//return null;
				}
				return null;
			}

			public String getText(Object element) {

				if(element instanceof ClassificationAnnotationLine)
				{
					ClassificationAnnotationLine p = (ClassificationAnnotationLine) element;
					return p.getAnnotation();
				}
				return null;
			}
		});

		treeViewerColumn_8.setLabelProvider(new ColumnLabelProvider() {

			public String getText(Object element) {

				if(element instanceof ClassificationTableLine)
				{
					ClassificationTableLine p = (ClassificationTableLine) element;
					return p.getTcentattrID();
				}
				return null;
			}
		});
		/*
treeViewerColumn_9.setLabelProvider(new ColumnLabelProvider() {

	////
	public Image getImage(Object element) {

		if(isreview&&modattrlist.size()>0)
		{
		if(element instanceof ClassificationTableLine) 
    	{
			ClassificationTableLine p = (ClassificationTableLine) element;
			if(modattrlist.contains(p.getAttrID()))
			{
    		Bundle bundle = FrameworkUtil.getBundle(this.getClass());

    		// use the org.eclipse.core.runtime.Path as import
    		String path="icons/new.gif";


    		URL url = FileLocator.find(bundle,
    		    new Path(path), null);
    		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
    		return imageDescriptor.createImage();
			}
    		//return null;
    	}
		}
    	return null;
	}
    public String getText(Object element) {
    	if(element instanceof ClassificationTableLine)
    	{
    	ClassificationTableLine p = (ClassificationTableLine) element;
        return p.getNewValue();
    	}
    	return null;
    }
    public Color getForeground(final Object element) {
    	if(element instanceof ClassificationTreeLine) 
    	{
    		ClassificationTreeLine p = (ClassificationTreeLine) element;
    		 return  Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
    	}

        return super.getBackground(element);
    }
});*/
		Button btnErase = new Button(grpClassificationPropertiesValues, SWT.NONE);
		btnErase.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				clearFilter();

			}
		});
		btnErase.setBounds(10, 23, 47, 30);

		final Bundle bundle = FrameworkUtil.getBundle(this.getClass());

		// use the org.eclipse.core.runtime.Path as import
		String path="icons/eraser.PNG";


		URL url = FileLocator.find(bundle,
				new Path(path), null);
		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);


		btnErase.setImage(imageDescriptor.createImage());

		Button btnSearch = new Button(grpClassificationPropertiesValues, SWT.NONE);
		btnSearch.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				System.out.print("kjk:"+searchText.getText());
				searchFilter.setSearchText(searchText.getText());
				treeViewer.refresh();
			}
		});
		btnSearch.setBounds(63, 23, 51, 30);

		// use the org.eclipse.core.runtime.Path as import
		path="icons/search.jpg";


		url = FileLocator.find(bundle,
				new Path(path), null);
		imageDescriptor = ImageDescriptor.createFromURL(url);


		btnSearch.setImage(imageDescriptor.createImage());

		treeViewer.setContentProvider(new MDMTreeContentProvider4PRD());//new TableContentProvider());
		//treeViewer.setLabelProvider(new TableLabelProvider(treeViewer));
		try {
			ArrayList<ClassificationTreeLine> inputtree =new ArrayList<ClassificationTreeLine>();

			String parttype=ItemRev.getTCProperty("t5_PartType").getDisplayableValue();

			System.out.println("outside parttype="+parttype);
			//String TSBusiUnit=null;
			if(parttype.equals("Vehicle") || parttype.equals("Vehicle Combination") || parttype.equals("Configurable VC") || parttype.equals("Vehicle Combination CR") )//Case For : VC/Vehicle
			{
				TCComponent[] techspec=ItemRev.getTCProperty("T5_VCSpec").getReferenceValueArray();
				//TCComponentItemRevision techspec=selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
				if (techspec!=null && techspec.length>0) // If  TechSpec is attached to VC/Vehicle Show Classification Dialog for resp. BU
				{
					//UpdDlgFlg=true;
					TSBusiUnit = techspec[0].getTCProperty("t5_VCClassName").getDisplayableValue();
					System.out.println("in vehicle selection TSBusiUnit:-"+TSBusiUnit);
				}
				

			}
			if(parttype.equals("T5_TSCompRevision"))
			{
				TSBusiUnit = ItemRev.getTCProperty("t5_VCClassName").getDisplayableValue();
				System.out.println("in TechSpec selection TSBusiUnit:-"+TSBusiUnit);
				TCComponentItemRevision tecspecVCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
				
			}
			System.out.println(" b4 bomexpansion call TSBusiUnit:-"+TSBusiUnit);

			if(parttype.equals("Vehicle Combination")|| parttype.equals("Configurable VC") || parttype.equals("Vehicle Combination CR") )
				inputtree=bomexpansion.getTCUAStructureSnapshot(session, ItemRev,this.fullexpandable,TSBusiUnit,Hybridstatus);
			else
				inputtree=bomexpansion.getTCUAStructure(session, ItemRev,this.fullexpandable,TSBusiUnit,Hybridstatus);


			boolean goahead=constructMultiErrorDialog();

			if(goahead==false)
			{
				this.close();
				return area;
			}


			if(inputtree != null)
			{
				getAllTreeObjects(inputtree);
				System.out.println("inputtree.size()="+inputtree.size());
				if(inputtree.size()>0)
				{
					treeViewer.setInput( inputtree);
					if(this.fullexpandable==false)
					{
						ClassificationTreeLine ctl=inputtree.get(0);
						text.setText(ctl.getModuleAddress());
						// text_1.setText(ctl.getItemrev().toDisplayString());
						text_1.setText(ctl.getItemrev().getTCProperty("item_id").getDisplayableValue());
						text_2.setText(ctl.getClassificationName());
						text_3.setText(ctl.getObjectid());
					}

				}


			}

		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotLoadedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		treeViewer.expandAll();


		try {
			System.out.println("selectedObj.getObjectString"+selectedObj.getObjectString());
			System.out.println("selectedObj.DisplayString"+selectedObj.toDisplayString());
			//TTT
			if(selectedObj instanceof TCComponentItemRevision)
				tsnum.setText(selectedObj.getTCProperty("item_id").getDisplayableValue());
			else
				tsnum.setText(selectedObj.toDisplayString());
			tsou.setText(selectedObj.getTCProperty("owning_user").getDisplayableValue());
			System.out.println("11111selectedObj.getTCProperty.getDisplayableValue()="+selectedObj.getPropertyDisplayableValue("t5_TechSNumDes"));
			//System.out.println("ItemRev.getTCProperty.getDisplayableValue()111="+ItemRev.getTCProperty("t5_TechSNumDes").getDisplayableValue());
			tsdesc.setText(selectedObj.getPropertyDisplayableValue("object_desc"));
			tsbu.setText(selectedObj.getPropertyDisplayableValue("t5_VCClassName")); 
			tsvsc.setText(selectedObj.getPropertyDisplayableValue("t5_VCSubClass"));
			tsodu.setText(selectedObj.getPropertyDisplayableValue("t5_DsgnOwnCpy"));
			tsodd.setText(selectedObj.getPropertyDisplayableValue("t5_DsgnDeptCpy"));
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotLoadedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Start Tree 
		//treeViewer.setInput(input)
		//viewer.setInput(File.listRoots());

		//End 


		area.addControlListener(new ControlAdapter() {
			public void controlResized(ControlEvent e) {
				System.out.println("jghgfgdfdf");
				Rectangle area1 = area.getClientArea();
				Point preferredSize = tree.computeSize(SWT.DEFAULT, SWT.DEFAULT);
				int width = area1.width - 2*tree.getBorderWidth();
				if (preferredSize.y > area1.height + tree.getHeaderHeight()) {
					// Subtract the scrollbar width from the total column width
					// if a vertical scrollbar will be required
					Point vBarSize = tree.getVerticalBar().getSize();
					width -= vBarSize.x;
				}
				Point oldSize = tree.getSize();
				if (oldSize.x > area1.width) {
					// table is getting smaller so make the columns 
					// smaller first and then resize the table to
					// match the client area width

					grpClassificationPropertiesValues.setSize(area1.width, area1.height);
					searchText.setSize(area1.width, searchText.getSize().y);
					// searchText.setSize(searchText.getSize().x, area1.height-160);
					// tree.setSize(area1.width-10, area1.height-160);

					tree.setSize(area1.width-20, area1.height-200);
					int delta=(oldSize.x-area1.width)/(2*tree.getColumnCount());
					for(int f=0;f<tree.getColumnCount();f++)
					{

						tree.getColumn(f).setWidth(tree.getColumn(f).getWidth()-delta);

					}
				} else {
					// table is getting bigger so make the table 
					// bigger first and then make the columns wider
					// to match the client area width
					grpClassificationPropertiesValues.setSize(area1.width, area1.height);
					searchText.setSize(area1.width, searchText.getSize().y);
					tree.setSize(area1.width-20, area1.height-200);
					int delta=(area1.width-oldSize.x)/(2*tree.getColumnCount());
					for(int f=0;f<tree.getColumnCount();f++)
					{

						tree.getColumn(f).setWidth(tree.getColumn(f).getWidth()+delta);

					}

				}
			}
		});





		return area;
	}


	public void setbackGroundWaterMark(final Composite container,final Image image,final int width,final int height)
	{


		container.setBackgroundMode(SWT.INHERIT_FORCE);

		//Display display=new Display();
		//	final Shell shell=new Shell(display);
		//final Image image=new Image(display,this.getClass().getResourceAsStream("/image/readonly.png"));
		System.out.println("sfdfdfdfpaintControlpaintControlpaintControl");

		image.getImageData().setAlpha(0, 0, 0); // just to force alpha array allocation with the right size
		Arrays.fill(image.getImageData().alphaData, (byte) 0); // set whole image as transparent


		container.addPaintListener(new PaintListener()
		{


			public void paintControl(PaintEvent e) {
				// TODO Auto-generated method stub
				System.out.println("paintControlpaintControlpaintControl");
				Rectangle rect=container.getClientArea();
				e.gc.drawImage(new Image(container.getDisplay(),image.getImageData()), 0, 0,width,height,0,0,rect.width,rect.height);

			}


		});





	}


	public void updateICOVal(ICOValues val)
	{
		//text.setText(val.getCid());
		this.icoval=val;

		//classificationList.length
	}





	private TCComponent getComponent(Object paramObject)
	{
		AIFComponentContext localAIFComponentContext = (AIFComponentContext)AdapterUtil.getAdapter(paramObject, AIFComponentContext.class);
		Assert.isNotNull(localAIFComponentContext);
		TCComponent localTCComponent = (TCComponent)AdapterUtil.getAdapter(localAIFComponentContext.getComponent(), TCComponent.class);
		Assert.isNotNull(localTCComponent);
		return localTCComponent;
	}

	private TCComponent getTCComponent(AIFComponentContext localAIFComponentContext)
	{
		TCComponent localTCComponent = (TCComponent)AdapterUtil.getAdapter(localAIFComponentContext.getComponent(), TCComponent.class);
		Assert.isNotNull(localTCComponent);
		return localTCComponent;
	}


	public void populateTable() 
	{
		// TODO Auto-generated method stub		




		tabLineModel= new ClassificationLineProvider();
		for(int i=0;i<classificationList.size();i++)
		{
			System.out.println("classificationList="+classificationList.get(i));
		}
		tabLineModel.setClassificationLine(classificationList);

		treeViewer.setContentProvider(new MDMTreeTableContentProvider4PRD());//TreeTable
		treeViewer.setInput( classificationList);


	}
	// used to clear filter search	
	public void clearFilter()
	{
		searchText.setText("");
		System.out.print("Inside clearFilter func:"+searchText.getText());
		searchFilter.setSearchText(searchText.getText());
		treeViewer.refresh();
	}

	private static void getAllItems(Tree tree, List<TreeItem> allItems)
	{

		for(TreeItem item : tree.getItems())
		{
			allItems.add(item);
			getAllItems(item, allItems);
		}
	}

	private static void getAllItems(TreeItem currentItem, List<TreeItem> allItems)
	{
		TreeItem[] children = currentItem.getItems();

		for(int i = 0; i < children.length; i++)
		{
			children[i].setExpanded(true);

			allItems.add(children[i]);

			getAllItems(children[i], allItems);
		}
	}

	public void addNamedReference(File tobeuploadfile,TCComponentDataset dataset)
	{
		System.out.print("Inside the function addNamedReference");
		FileManagementUtility fmsFileManagement =new FileManagementUtility(session.getSoaConnection());//, null, null, Bootstrap_Urls, cacheDir);
		try
		{
			GetDatasetWriteTicketsInputData[] inputs = { getSingleGetDatasetWriteTicketsInputData(tobeuploadfile,dataset) };
			ServiceData response = fmsFileManagement.putFiles(inputs);
			TechSpecUtil.ServiceDataError(response);
		}
		finally
		{
			// Close FMS connection when done
			fmsFileManagement.term();
		}

		System.out.print("End the function addNamedReference");
	}


	/*************************************************************************/
	private GetDatasetWriteTicketsInputData getSingleGetDatasetWriteTicketsInputData(File tobeuploadfile,TCComponentDataset dataset)
	{
		// Assume this file is in current dir
		//FileInfo file1 = new FileInfo();
		String cacheDir=System.getProperty("java.io.tmpdir");	
		TCPreferenceService pref=session.getPreferenceService();
		String FMS_Bootstrap_Urls=pref.getPreferenceDescription("FMS_Bootstrap_Urls");
		String[] Bootstrap_Urls={FMS_Bootstrap_Urls};
		//String[] FMS_Bootstrap_Urls = session.getPreferenceService();
		System.out.print("FMS_Bootstrap_Urls:-"+FMS_Bootstrap_Urls+"Bootstrap_Urls="+Bootstrap_Urls[0]);
		//FileManagementUtility fmsFileManagement =new FileManagementUtility(session.getSoaConnection());//, null, null, Bootstrap_Urls, cacheDir);

		String filenametobeupload=tobeuploadfile.getName().replaceAll(";", "_");//21-05-2021
		String filepath=tobeuploadfile.getPath();
		System.out.print("filenametobeupload:-"+filenametobeupload+ "filepath="+filepath);
		String WholefileName = filepath + filenametobeupload;
		System.out.print("WholefileName:-"+WholefileName);

		// Create a file to associate with dataset
		DatasetFileInfo fileInfo = new DatasetFileInfo();

		fileInfo.clientId = fileInfo.toString();
		fileInfo.fileName = filepath;
		fileInfo.allowReplace=true;
		fileInfo.isText = false;
		fileInfo.namedReferencedName = "excel";

		DatasetFileInfo[] fileInfos = { fileInfo };

		GetDatasetWriteTicketsInputData inputData = new GetDatasetWriteTicketsInputData();
		inputData.dataset = dataset;
		inputData.createNewVersion = false;
		inputData.datasetFileInfos = fileInfos;

		return inputData;

	}



	public TCComponentDataset CreateDataset(TCComponentItemRevision techspecobj,String datasetname,String Desc,File filetobeupload) throws TCException
	{
		System.out.print("inside CreateDataset func");
		DataManagementService dservice = DataManagementService.getService(session.getSoaConnection());
		String filenametobeupload=filetobeupload.getName();
		String filepath=filetobeupload.getPath().replaceAll(";", "_");//21-05-2021;
		System.out.print("filenametobeupload:-"+filenametobeupload+ "filepath="+filepath);
		String WholefileName = filepath + filenametobeupload;
		System.out.print("WholefileName:-"+WholefileName);
		DatasetProperties[] dataProps = new DatasetProperties[1];
		dataProps[0] = new DatasetProperties();
		dataProps[0].clientId = datasetname;
		dataProps[0].name = datasetname;
		dataProps[0].description = Desc;
		//dataProps[0].
		dataProps[0].relationType = "IMAN_reference";
		dataProps[0].type = "MSExcelX";
		dataProps[0].toolUsed = "MSExcel";
		dataProps[0].container = techspecobj;
		CreateDatasetsResponse dataResp = dservice.createDatasets(dataProps);
		TechSpecUtil.ServiceDataError(dataResp.serviceData);
		if(dataResp.serviceData.sizeOfCreatedObjects()>0)
		{
			ModelObject dataset = dataResp.output[0].dataset;

			// refresh Objects
			//   TCComponent[] objs = { techspecobj.getItem(), techspecobj, dataset };
			//   dservice.refreshObjects(objs);
			System.out.print("End CreateDataset func");
			return (TCComponentDataset) dataset;
		}

		return null;
		// System.out.print("End CreateDataset func");
	}

	/*	 	
	 */	
	private File createClsUpdatedHistoryRpt(String DmlNo,TCComponent selObj,boolean showMsg) 
	{
		// create a workbook
		XSSFWorkbook wb = new XSSFWorkbook();

		// add a worksheet
		XSSFSheet sheet = wb.createSheet("Updated VC Attributes History");

		// shade the background of the header row
		XSSFCellStyle headerStyle = wb.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
//		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
//		headerStyle.setBorderTop(CellStyle.BORDER_THIN);
//		headerStyle.setBorderBottom(CellStyle.BORDER_THIN);
//		headerStyle.setBorderLeft(CellStyle.BORDER_THIN);
//		headerStyle.setBorderRight(CellStyle.BORDER_THIN);
//		headerStyle.setAlignment(HorizontalAlignment.CENTER);

		headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headerStyle.setBorderTop(BorderStyle.THIN);
		headerStyle.setBorderBottom(BorderStyle.THIN);
		headerStyle.setBorderLeft(BorderStyle.THIN);
		headerStyle.setBorderRight(BorderStyle.THIN);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		
		Tree tree=treeViewer.getTree();


		List<TreeItem> allItems = new ArrayList<TreeItem>();

		getAllItems(tree, allItems);

		// System.out.println("XXXXXXXtreeitem="+allItems);
		TreeItem[] treeitem= tree.getItems();

		for(int l=0;l<allItems.size();l++)
		{
			for(int m=0;m<8;m++)
			{
				System.out.print("XXXXXXXtreeitem="+allItems.get(l).getText(m));
			}
			System.out.println(" ");
		}

		// add header row

		TreeColumn[] columns = tree.getColumns();
		int rowIndex = 0;
		int cellIndex = 0;
		XSSFRow header = sheet.createRow((short) rowIndex++);
		for (TreeColumn column : columns) {
			String columnName = column.getText();
			XSSFCell cell = header.createCell(cellIndex++);
			cell.setCellValue(column.getText());
			cell.setCellStyle(headerStyle);
		}

		// add data rows

		for(int l=0;l<allItems.size();l++)
		{
			// create a new row
			TreeItem item=allItems.get(l);
			XSSFRow row = sheet.createRow((short) rowIndex++);
			cellIndex = 0;

			for (int i = 0; i < columns.length; i++) {
				// create a new cell
				// String columnName = TreeColumnNames[i];
				XSSFCell cell = row.createCell(cellIndex++);

				// set the horizontal alignment (default to RIGHT)
				XSSFCellStyle cellStyle = wb.createCellStyle();
				HorizontalAlignment ha = HorizontalAlignment.RIGHT;
				cellStyle.setAlignment(ha);
				cell.setCellStyle(cellStyle);

				// set the cell's value
				String text = item.getText(i);
				cell.setCellValue(text);
			}
		}

		// autofit the columns
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn((short) i);
		}
		String selecteditem=null;
		String rev=null;
		try {

			System.out.println("in createClsUpdatedHistoryRpt func objType="+objType);
			if(objType.equals("Design Revision"))
			{
				selecteditem=selObj.getTCProperty("item_id").getDisplayableValue();
				rev=selObj.getTCProperty("item_revision_id").getDisplayableValue();
			}
			else
			{
				selecteditem=selObj.getTCProperty("object_name").getDisplayableValue();
				rev="NR";
			}



		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print("inside createWorkbookFromTree fun" +selecteditem + "rev="+rev + "selectedObj display string="+selectedObj.toDisplayString());

		// DirectoryDialog dialog = new DirectoryDialog(parentShell);
		// String path=dialog.open();		    
		// String expfilename=null;
		// expfilename=path+"\\"+selecteditem+"_"+rev+".xlsx";
		// System.out.print("expfilename="+expfilename);
		// exportWorkbookToAFile(wb,expfilename);

		String expfilename=null;
		String path=System.getProperty("java.io.tmpdir");	
		expfilename=path+"\\"+selecteditem+"_"+rev+"_MDMVCAttrsModifiedBy_"+DmlNo+".xlsx";
		exportWorkbookToAFile(wb,expfilename,showMsg); //added newly on 06052019
		//fos.close();
		System.out.println(expfilename+" written successfully"); 
		/*try {
				//FileOutputStream fos;
				//fos = new FileOutputStream(expfilename);


				exportWorkbookToAFile(wb,expfilename); //added newly on 06052019
				//fos.close();
				System.out.println(expfilename+" written successfully"); 

				//fos.write(fos);

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/

		//File fileObj = new File(expfilename);
		return new File(expfilename);
	}

	private XSSFWorkbook createWorkbookFromTree(boolean showMsg) {
		// create a workbook
		XSSFWorkbook wb = new XSSFWorkbook();

		// add a worksheet
		XSSFSheet sheet = wb.createSheet("Exported VC Attributes");

		// shade the background of the header row
		XSSFCellStyle headerStyle = wb.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
//		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
//		headerStyle.setBorderTop(CellStyle.BORDER_THIN);
//		headerStyle.setBorderBottom(CellStyle.BORDER_THIN);
//		headerStyle.setBorderLeft(CellStyle.BORDER_THIN);
//		headerStyle.setBorderRight(CellStyle.BORDER_THIN);
//		headerStyle.setAlignment(HorizontalAlignment.CENTER);

		headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headerStyle.setBorderTop(BorderStyle.THIN);
		headerStyle.setBorderBottom(BorderStyle.THIN);
		headerStyle.setBorderLeft(BorderStyle.THIN);
		headerStyle.setBorderRight(BorderStyle.THIN);
		headerStyle.setAlignment(HorizontalAlignment.CENTER);
		
		Tree tree=treeViewer.getTree();


		List<TreeItem> allItems = new ArrayList<TreeItem>();

		getAllItems(tree, allItems);

		// System.out.println("XXXXXXXtreeitem="+allItems);
		TreeItem[] treeitem= tree.getItems();

		for(int l=0;l<allItems.size();l++)
		{
			for(int m=0;m<8;m++)
			{
				System.out.print("XXXXXXXtreeitem="+allItems.get(l).getText(m));
			}
			System.out.println(" ");
		}

		// add header row

		TreeColumn[] columns = tree.getColumns();
		int rowIndex = 0;
		int cellIndex = 0;
		XSSFRow header = sheet.createRow((short) rowIndex++);
		for (TreeColumn column : columns) {
			String columnName = column.getText();
			XSSFCell cell = header.createCell(cellIndex++);
			cell.setCellValue(column.getText());
			cell.setCellStyle(headerStyle);
		}

		// add data rows

		for(int l=0;l<allItems.size();l++)
		{
			// create a new row
			TreeItem item=allItems.get(l);
			XSSFRow row = sheet.createRow((short) rowIndex++);
			cellIndex = 0;

			for (int i = 0; i < columns.length; i++) {
				// create a new cell
				// String columnName = TreeColumnNames[i];
				XSSFCell cell = row.createCell(cellIndex++);

				// set the horizontal alignment (default to RIGHT)
				XSSFCellStyle cellStyle = wb.createCellStyle();
				HorizontalAlignment ha = HorizontalAlignment.RIGHT;
				cellStyle.setAlignment(ha);
				cell.setCellStyle(cellStyle);

				// set the cell's value
				String text = item.getText(i);
				cell.setCellValue(text);
			}
		}

		// autofit the columns
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn((short) i);
		}
		String selecteditem=null;
		String rev=null;
		try {
			System.out.println("in createWorkbookFromTree objType="+objType);
			if(objType.equals("Design Revision"))
			{
				selecteditem=selectedObj.getTCProperty("item_id").getDisplayableValue();
				rev=selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
			}
			else
			{
				selecteditem=selectedObj.getTCProperty("object_name").getDisplayableValue();
				rev="NR";
			}

		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print("inside createWorkbookFromTree fun" +selecteditem + "rev="+rev + "selectedObj display string="+selectedObj.toDisplayString());

		DirectoryDialog dialog = new DirectoryDialog(parentShell);
		String path=dialog.open();		    
		String expfilename=null;
		expfilename=path+"\\"+selecteditem+"_"+rev+".xlsx";
		System.out.print("expfilename="+expfilename);
		exportWorkbookToAFile(wb,expfilename,showMsg);
		return wb;
	}

	public void exportWorkbookToAFile(XSSFWorkbook wb, String filename,boolean showMsg) {
		try {

			FileOutputStream fos = new FileOutputStream(filename);
			wb.write(fos);
			fos.close();
			if(showMsg)
			{
				MessageDialog.openInformation(parentShell,
						"Save Workbook Successful",
						"Workbook saved to the file:\n\n" + filename);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
			String msg = ioe.getMessage();
			MessageDialog.openError(parentShell, 
					"Save Workbook Failed",
					"Could not save workbook to the file:\n\n" + msg);
		}
	}

	//Added by Rajesh on 22/05/2019 for change history report will get attached with other CCV as well.
	public TCComponent ChangeHistObjCre(TCSession session,TCComponent selectedObj,TCComponentItemRevision ErcDMLObj,boolean showMsg) throws TCException
	{
		TCComponentDataset dataset=null;

		String ErcDmlNo;
		System.out.println("22ErcDMLObj="+ErcDMLObj);
		try {
			if(ErcDMLObj!=null)
			{
				ErcDmlNo = ErcDMLObj.getTCProperty("item_id").getDisplayableValue();
				//ErcDmlNo="10PP131333"; //need to delete before check in
				System.out.println("222ErcDmlNo="+ErcDmlNo);
				File UpdatedRptHist=createClsUpdatedHistoryRpt(ErcDmlNo,selectedObj,showMsg);
				String selectedobjName=selectedObj.getTCProperty("item_id").getDisplayableValue();
				System.out.println("going to create change history dataset for respective CCV"+selectedobjName);
				String RevSeq=selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
				RevSeq=RevSeq.replace(";", "_");
				System.out.println("RevSeq="+RevSeq);
				String datasetname=selectedobjName+"_"+RevSeq+"_MDMVCAttrsModifiedBy_"+ErcDmlNo;

				System.out.println("B4 Dataset Qry call");
				TCComponent datasetExist=TechSpecUtil.qryObj(session,"Dataset Name","Dataset Name",datasetname);
				System.out.println("After Dataset Qry call");
				if(datasetExist!=null)
				{
					System.out.println("Dataset already available in system, only Named refrence will attach\n");
					System.out.println("Going to Add name refrence with dataset\n");
					addNamedReference(UpdatedRptHist,(TCComponentDataset)datasetExist);
				}
				else
				{
					System.out.print("111B4 CreateDataset func call with datasetname="+datasetname);						
					dataset=CreateDataset((TCComponentItemRevision)selectedObj,datasetname,selectedObj.getTCProperty("object_name").getDisplayableValue(),UpdatedRptHist);
					System.out.println("Going to Add name refrence with dataset\n");
					addNamedReference(UpdatedRptHist,dataset);
				}
				//getSingleGetDatasetWriteTicketsInputData(UpdatedRptHist,dataset);
				//System.out.println("Going to Add name refrence with dataset\n");
				//addNamedReference(UpdatedRptHist,dataset);
				System.out.println("Added name refrence with dataset\n");
			}
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.print("2222After CreateDataset func call");


		return null;

	}

	//End of func ChangeHistObjCre

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		Button button = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,
				true);

		Bundle bundle = FrameworkUtil.getBundle(this.getClass());

		// use the org.eclipse.core.runtime.Path as import
		String path="icons/Ok_16x16.png";


		URL url = FileLocator.find(bundle,
				new Path(path), null);
		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);


		button.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/Ok_16x16.png"));
		button.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		Button button_1 = createButton(parent, IDialogConstants.CANCEL_ID,
				IDialogConstants.CANCEL_LABEL, false);



		// use the org.eclipse.core.runtime.Path as import
		path="icons/close_16x16.png";


		url=FileLocator.find(bundle,
				new Path(path), null);
		imageDescriptor = ImageDescriptor.createFromURL(url);
		button_1.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/close_16x16.png"));

		Button button_3 = createButton(parent, IDialogConstants.FINISH_ID,
				"Export To XLS", false);
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override

			public void widgetSelected(SelectionEvent e) {
				clearFilter();
				createWorkbookFromTree(true);

			}
		});



		// use the org.eclipse.core.runtime.Path as import
		path="icons/excel.png";


		url=FileLocator.find(bundle,
				new Path(path), null);
		imageDescriptor = ImageDescriptor.createFromURL(url);
		button_3.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/close_16x16.png"));
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		Rectangle size=getShell().getDisplay().getPrimaryMonitor().getClientArea();
		//System.out.println("SSSSSSSSSSSSSSSSSSSSSS::"+size);
		return new Point(size.width,size.height);//789, 809);

	}

	@Override
	protected void okPressed() {
		// TODO Auto-generated method stub
		//Rajesh
		// String ModuleAddress = null;
		System.out.println("going to call CreateOrUpdateICOSample==isUpdatable=="+isUpdatable);

		int chkdlg=	constructCheckedInfoDialog();

		System.out.println("chkdlg::"+chkdlg);
		if( chkdlg==-1)
			return;


		if(isUpdatable==false )
		{
			super.okPressed();
			return;
		}





		/* Object[] selchk=chkdlg.getM_treeTableView().getTreeViewer().getCheckedElements();
		 System.out.println("All tree Checked Size::"+selchk.length);
		 for(int x1=0;x1<selchk.length;x1++)
		 {
		 AIFComponentContext aif_ctx=chkdlg.getIC_AIFContext(selchk[x1]);
		  System.out.println("All tree Checked::"+aif_ctx.getComponent().toString());
		  ccvselList.add(aif_ctx);
		 }
		 */	 
		Map<ClassificationObject,HashMap<String, Object>> classmap=new HashMap<ClassificationObject,HashMap<String, Object>> ();

		AbstractAIFUIApplication app1=AIFUtility.getCurrentApplication();


		ArrayList treelist=(ArrayList) treeViewer.getInput();
		System.out.println("treelist.Size()="+treelist.size());
		for(int i=0;i<treelist.size();i++)
		{
			if(treelist.get(i) instanceof ClassificationTreeLine)
			{
				ClassificationTreeLine treeObj=(ClassificationTreeLine) treelist.get(i);
				if(UpdateMDMDlgForPRD.this.fullexpandable)
				{
					try {
						String parttype=treeObj.getItemrev().getTCProperty("t5_PartType").getDisplayableValue();
						if(parttype.equals("Module"))
						{
							continue;
						}

					} catch (TCException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}


				namevalueP=new HashMap <String,Object>();

				arrayAttr=new HashMap <String,String>();

				ClassificationObject clsobjs=treeObj.getClsobjs();
				moduleAddr=treeObj.getModuleAddress();

				//	StringTokenizer stk= new StringTokenizer(moduleAddr,"[]");
				//	ModuleAddress=stk.nextToken();
				//	ObjectID=stk.nextToken();
				ModuleAddress=treeObj.getModuleAddress();
				ObjectID=treeObj.getObjectid();
				ArrayList<ClassificationAnnotationLine> treechildren=treeObj.getAttrList();
				try {
					ModuleNum= treeObj.getItemrev().getTCProperty("item_id").getDisplayableValue();
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				localAIFComponentContext =null;// (AIFComponentContext)AdapterUtil.getAdapter(treeObj.getItemrev(), AIFComponentContext.class);
				TCComponentItemRevision item_rev=treeObj.getItemrev();


				try {

					parent_item=item_rev.getItem();
					localAIFComponentContext=new AIFComponentContext(parent_item,item_rev,"structure_revision");
					System.out.println("fggdfdfsdsasasa:::"+localAIFComponentContext.toString());
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.println("treelist.getClass()="+treelist.getClass());
				System.out.println("treelist.tostring()="+treelist.toString());
				System.out.println("11ModuleNum="+ModuleNum);



				for(int j=0;j<treechildren.size();j++)
				{

					ClassificationAnnotationLine  annot_lin=treechildren.get(j);
					ArrayList<ClassificationTableLine> treechildren1=annot_lin.getAttrList();
					for(int g=0;g<treechildren1.size();g++)
					{

						if(treechildren1.get(g) instanceof ClassificationTableLine)
						{
							ClassificationTableLine treeTabObj=(ClassificationTableLine) treechildren1.get(g);

							String attrid=treeTabObj.getAttrID();
							String attrval=treeTabObj.getNewValue();//.getAttrValue();
							String lovId=treeTabObj.getLovID();
							String attrname=treeTabObj.getAttrName();
							boolean ismandatory=treeTabObj.isIsmandatory();
							System.out.println("ismandatory="+ismandatory);
							System.out.println("attrname="+attrname);
							if(ismandatory)
							{
								System.out.println("attrval="+attrval +"attrval.length()="+attrval.length());
								if(attrval==null || attrval.length()==0)
								{
									String attrval1=treeTabObj.getAttrValue();
									if(attrval1==null || attrval1.length()==0)
									{
										System.out.println("in loop attrval="+attrval +"attrval.length()="+attrval.length());
										if(uniqueErrObj.contains(localAIFComponentContext)==false)
										{
											System.out.println("in loop attrval="+attrval +"attrval.length()="+attrval.length()+"!uniqueErrObj.contains(localAIFComponentContext)"+uniqueErrObj.contains(localAIFComponentContext));
											mandatorylist.add("Please Fill the below Mandatory Attributes !! ");
											aifcomponentctxtList.add(localAIFComponentContext);
											uniqueErrObj.add(localAIFComponentContext);
											System.out.println("localAIFComponentContext="+localAIFComponentContext );
										}
										mandatorylist.add(attrname);
										aifcomponentctxtList.add(localAIFComponentContext);
									}
								}
							} 
							System.out.println("attrid="+attrid +"attrval="+attrval + "lovId="+lovId);
							// namevalueP.put(item.getText(1),"v"+itemIndex)   ;
							try
							{
								if(Integer.parseInt(lovId)<0)
								{
									if(treeTabObj.getChangeValue()==null)
										continue;
									if(treeTabObj.getChangeValue()!=null)
										attrval=treeTabObj.getChangeValue();

									if(treeTabObj.getArraySize()>1)
									{

										arrayAttr.put(attrid, treeTabObj.getArraySize()+"");


										List<String> selList1=new ArrayList<String>();
										String valueadd="";
										if(attrval!=null && attrval.trim().length()>0)
										{
											selList1=(Arrays.asList(attrval.trim().split(PreferenceValue.getARRAY_DELMITER())));
											valueadd="";
											for(int f=0;f<selList1.size();f++)
											{
												String tokenval=new StringTokenizer(selList1.get(f), /*" "*/PreferenceValue.getKeyvalueDelmiter()).nextToken();
												valueadd+=tokenval;
												if(f<selList1.size()-1)
													valueadd+=PreferenceValue.getARRAY_DELMITER();//",";


											}

											//namevalueP.put(attrid,valueadd)   ;
										}
										//else
										namevalueP.put(attrid,attrval)   ;
										namevalueP.put(attrid,valueadd)   ;

										System.out.println("valueadd ::"+ valueadd);
										//namevalueP.put(attrid,"@"+attrval)   ;
									}
									else
									{
										// if(treeTabObj.getLovKeyValue()!=null)
										//attrval=treeTabObj.getLovKeyValue();
										if(attrval.trim().length()>0)
										{
											namevalueP.put(attrid,new StringTokenizer(attrval,/*" "*/PreferenceValue.getKeyvalueDelmiter()).nextToken());
											//namevalueP.put(attrid,attrval);
										}
										else
										{

											namevalueP.put(attrid,attrval)   ;
										}
									}
								}
								else
								{
									if(treeTabObj.getChangeValue()==null)
										continue;
									if(treeTabObj.getChangeValue()!=null)
										attrval=treeTabObj.getChangeValue();
									namevalueP.put(attrid,attrval)   ;
								}
							} catch(NumberFormatException e) { 
								e.printStackTrace();
							}

						}

					}//annot

				}//klkl

				if(mandatorylist.size()>0)
				{
					for(int m=0;m<mandatorylist.size();m++)
					{
						CommandTargetState cmdstate=new CommandTargetState(aifcomponentctxtList.get(m),null);
						cmdstate.setCaughtException(new TCException(mandatorylist.get(m)));
						cmdstate.setDone(false);

						m_commandTargetStateList1.add(cmdstate);

					}

					if(aifcomponentctxtList.size()>0)
					{
						AIFComponentContext[] selobjs=aifcomponentctxtList.toArray(new AIFComponentContext[aifcomponentctxtList.size()]);
						System.out.println("selobjs="+selobjs.length);
						AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

						TCSession session=(TCSession) app.getSession();

						TMLDataBean databean= new TMLDataBean(parent_item.getSession(), null,selobjs,exe_evt);
						databean.setTargetContexts(selobjs);

						MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
						System.out.println("inside update status printing step");
						paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList1);

						TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },1,null);
					}
					aifcomponentctxtList.clear();
					mandatorylist.clear();
					m_commandTargetStateList1.clear();
					uniqueErrObj.clear();
					return;
				}
				System.out.println("CreateOrUpdateICOSample clsobjs="+clsobjs +" ModuleAddress="+ModuleAddress);


				if(namevalueP.isEmpty())
				{


					CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
					cmdstate.setCaughtException(new TCException("No Value to Update"));
					cmdstate.setDone(true);
					localAIFComponentContextList.add(localAIFComponentContext);
					m_commandTargetStateList.add(cmdstate);
					isSuccess=true;

				}
				else
				{

					TCComponentItem treeitem=null;
					try {
						treeitem=treeObj.getItemrev().getItem();
					} catch (TCException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}

					CreateOrUpdateICOSample icos=new  CreateOrUpdateICOSample(treeitem,clsobjs, ModuleAddress, ObjectID, ModuleNum,namevalueP, arrayAttr,session);
					try {
						//icos.createAndUpdateICO();//LLLLLAT
						try {
							createUpdateControlObject(ObjectID,namevalueP,ModuleAddress);
						} catch (TCException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (NotLoadedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						isSuccess=true;
					} catch (ServiceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					finally
					{
						/*localAIFComponentContext =null;// (AIFComponentContext)AdapterUtil.getAdapter(treeObj.getItemrev(), AIFComponentContext.class);
		  		 TCComponentItemRevision item_rev=treeObj.getItemrev();


				try {

					 parent_item=item_rev.getItem();
					 localAIFComponentContext=new AIFComponentContext(parent_item,item_rev,"structure_revision");
					 System.out.println("fggdfdfsdsasasa:::"+localAIFComponentContext.toString());
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
						 */


						ServiceData data=icos.getServiceData();
						firstccvclsobj=icos.getCreateUpdatedclobj();

						//Added by rajesh on 22/05/2019
						String parttype=null;

						try {
							parttype = treeObj.getItemrev().getTCProperty("t5_PartType").getDisplayableValue();
							//System.out.println("\n4444parttype="+parttype);
						} catch (TCException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println("\n4444parttype="+parttype);
						//if(parttype.equals("Vehicle Combination"))
						boolean isBypass =session.hasBypass();
						System.out.println("\nb4 getAttachedDML isBypass="+isBypass +" bypassUsrflg"+bypassUsrflg);
						if( bypassUsrflg==false)
						{
						if(isBypass==false) 
						{
							if(treeObj.getItemrev()!=null)
							{
								//ErcDMLObj=TechSpecUtil.SecondaryToPrimaryObj("CMHasSolutionItem",ccv_item);

								ErcDMLObj=TechSpecUtil.getAttachedDML(treeObj.getItemrev(),"CMReferences",/*"Update VC attributes and Tech Spec Header""Update VC attributes*"*/step_wf);


								//// 19-05-2021

								try {

									TCComponentItemRevision ercdml_rev=null;
									ercdml_rev=TechSpecUtil.SecondaryToPrimaryObj("T5_DMLTaskRelation", ErcDMLObj);
									if(ercdml_rev!=null )
									{

										TCProperty prop=ercdml_rev.getTCProperty("t5_mdmrlstype");

										prop.setStringValueData("VC ATTR");

										ercdml_rev.setTCProperties(new TCProperty[] {prop});
										try {
											String t5_mdmrlstypeval=ercdml_rev.getPropertyDisplayableValue("t5_mdmrlstype");
											System.out.println("t5_mdmrlstypeval is ::"+ t5_mdmrlstypeval+ " for DML:"+ercdml_rev.toDisplayString());
										} catch (NotLoadedException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}
									else
									{


										System.out.println("No DML for ::"+ ErcDMLObj.toDisplayString());
									}
								}
								catch (TCException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}


								////


								System.out.println("before call func ChangeHistObjCre1 with input ErcDMLObj="+ErcDMLObj +"ccv_item="+treeObj.getItemrev());
								if(treeObj.getItemrev() instanceof TCComponentItemRevision)
								{
									if(bypassUsrflg==false || isBypass==false)
									{
										try {
											ChangeHistObjCre((TCSession) session,treeObj.getItemrev(),ErcDMLObj,false);
										} catch (TCException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										System.out.println("End call func ChangeHistObjCre1 ");
										//End 
									}
								}
							}
						}
					}
						if(data!=null && data.sizeOfPartialErrors() > 0)
						{
							localAIFComponentContextList.clear();
							m_commandTargetStateList.clear();
							for(int ij = 0; ij < data.sizeOfPartialErrors(); ij++)
							{
								for(String msg :
									data.getPartialError(ij).getMessages())
								{
									System.out.println("ServiceDataError1:"+msg);
									CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
									cmdstate.setCaughtException(new TCException(msg));
									cmdstate.setDone(false);
									localAIFComponentContextList.add(localAIFComponentContext);
									m_commandTargetStateList.add(cmdstate);


									/*     
				  	        AIFComponentContext[] selobjs={localAIFComponentContext};//selectedobject};
				  			TMLDataBean bn=new TMLDataBean(parent_item.getSession(), null,selobjs);
				  			bn.setTargetContexts(selobjs);
				  			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1], bn );
				  			paramMultiTargetControllerJob.getCommandTargetStateList().add(cmdstate);
				  			TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob);*/
								}
							}
							//System.out.println("localAIFComponentContext.toString()=:"+localAIFComponentContext.toString());



						}

						else
						{
							localAIFComponentContextList.clear();
							m_commandTargetStateList.clear();
							CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
							cmdstate.setCaughtException(new TCException("Updated Successfully. Please Click for Details."));
							cmdstate.setDone(true);
							localAIFComponentContextList.add(localAIFComponentContext);
							m_commandTargetStateList.add(cmdstate);


							for (Map.Entry<String, String> entry : modifedactvalueMap.entrySet())//modifedvalueMap.entrySet())
							{
								/* ClassificationPropertyValue[] ico_prop_values1 = new ClassificationPropertyValue[1];
		  			    System.out.println(entry.getKey() + " = " + entry.getValue());        
		  		        ico_prop_values1[0] = new ClassificationPropertyValue();
		  		        ico_prop_values1[0].dbValue = (String) entry.getValue();
								 */
								String attid=(String) entry.getKey();
								String attval=(String) entry.getValue();
								String attname=attrNameIDMap.get(attid);
								cmdstate=new CommandTargetState(localAIFComponentContext,null);
								cmdstate.setCaughtException(new TCException("["+attid+"]"+attname+"-->"+attval));
								cmdstate.setDone(true);

								m_commandTargetStateList.add(cmdstate);

							}


						}


					}
				}
			}
		}
		if(localAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localAIFComponentContextList.toArray(new AIFComponentContext[localAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			TCSession session=(TCSession) app.getSession();

			TMLDataBean databean= new TMLDataBean(parent_item.getSession(), null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside update status printing step");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList);

			TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.OK_LABEL },2,null);
			System.out.println("inside update status printing step ccvselList "+ccvselList.size());
			//for(int t=0;t<ccvList.size();t++)
			LinkedHashMap <TCComponentItemRevision,String> ccvResult = new LinkedHashMap <TCComponentItemRevision,String>();
			boolean[] successList =new boolean[ccvselList.size()] ;
			for(int t=0;t<ccvselList.size();t++)
			{

				TCComponentItemRevision ccv_item=(TCComponentItemRevision) getTCComponent(ccvselList.get(t));//ccvList.get(t);

				try
				{
					String ccv_itemID=ccv_item.getPropertyDisplayableValue("item_id");

					String ccv_revid=ccv_item.getPropertyDisplayableValue("item_revision_id");
					String object_id_ccv=ccv_itemID;//+"/"+ccv_revid;

					ModuleNum=ccv_itemID;
					System.out.println("ModuleNum="+ModuleNum +"object_id_ccv="+object_id_ccv);
					//ClassificationObject clsobjs=bomexpansion.getClassificationObject(ccv_item);
					ClassificationObject clsobjs=bom4modexpansion.getClassificationObject2(ccv_item);
					TCComponentItem clsitem=null;
					try {
						clsitem=ccv_item.getItem();
					} catch (TCException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					CreateOrUpdateICOSample icos_ccv=new  CreateOrUpdateICOSample(clsitem,clsobjs, ModuleAddress, object_id_ccv, ModuleNum,namevalueP, arrayAttr,session);

					if(clsobjs!=null && lastvalcopy.isValue()==true)
						icos_ccv.createAndUpdateICO();

					else
					{
						if(firstccvclsobj!=null && firstccvclsobj.length>0)
							icos_ccv.copyICO(firstccvclsobj[0],attrNameIDMap);




					}

					ServiceData data1=icos_ccv.getServiceData();

					//Added by rajesh on 22/05/2019
					if(ccv_item!=null)
					{
						//ErcDMLObj=TechSpecUtil.SecondaryToPrimaryObj("CMHasSolutionItem",ccv_item);

						ErcDMLObj=TechSpecUtil.getAttachedDML(ccv_item,"CMReferences",/*"Update VC attributes and Tech Spec Header""Update VC attributes*"*/step_wf);

						System.out.println("before call func ChangeHistObjCre1 with input ErcDMLObj="+ErcDMLObj +"ccv_item="+ccv_item);
						if(ccv_item instanceof TCComponentItemRevision)
						{
							if(bypassUsrflg==false || isBypass==false)
							{
								try {
									ChangeHistObjCre((TCSession) session,ccv_item,ErcDMLObj,false);
								} catch (TCException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								System.out.println("End call func ChangeHistObjCre1 ");
								//End 
							}
						}
					}
					if(data1!=null && data1.sizeOfPartialErrors()>0)
					{

						isSuccess=false;
						String err_msg="";
						String[] err_msgs=data1.getPartialError(0).getMessages();
						if(err_msgs!=null && err_msgs.length>0)
						{
							err_msg =err_msgs[0];
							ccvResult.put(ccv_item, err_msg);
							successList[t]=false;
						}
						MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updation ERROR  !!"+ ccv_item.toDisplayString()+":"+err_msg,"INFORAMTION",SWT.ICON_ERROR);
						break;
					}

					else
					{

						ccvResult.put(ccv_item, "Classification Successfully Copied from :"+ItemRev.toDisplayString());
						successList[t]=true;

					}


				} catch (NotLoadedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			if(ccvList.size()>0)
			{
				if(isSuccess==true)
				{


					constructMultiInfoDialog(ccvResult,successList,"All child SVR having same VC attribute value .\nplease check the classification value for all attached CCVs then update accordingly!!");
					//MessageBox.post(PlatformHelper.getCurrentShell(),"All child SVR having same VC attribute value .\nplease check the classification value for all attached CCVs then update accordingly!!","INFORAMTION",SWT.ICON_INFORMATION);

				}
			}	
			//CreateDataset(); //added by Rajesh on 02052019

			//Added by rajesh on 22/05/2019

			System.out.println("before call func ChangeHistObjCre2 with input ErcDMLObj="+ErcDMLObj +"selectedObj="+selectedObj);
			if(selectedObj instanceof TCComponentItemRevision)
			{
				try 
				{
					ErcDMLObj=TechSpecUtil.getAttachedDML((TCComponentItemRevision) selectedObj,"CMReferences",/*"Update VC attributes and Tech Spec Header""Update VC attributes**/step_wf);

					if(bypassUsrflg==false || isBypass==false)
					{
					ChangeHistObjCre((TCSession) session,selectedObj,ErcDMLObj,false);


					System.out.println("End call func ChangeHistObjCre2 ");
					}
				}
				catch (TCException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//End 

			/*  TCComponentDataset dataset=null;

	  		String ErcDmlNo;
				try {
					if(ErcDMLObj!=null)
					{
						ErcDmlNo = ErcDMLObj.getTCProperty("item_id").getDisplayableValue();
						//ErcDmlNo="10PP131333"; //need to delete before check in
						System.out.println("111ErcDmlNo="+ErcDmlNo);
						File UpdatedRptHist=createClsUpdatedHistoryRpt(ErcDmlNo);
						String selectedobjName=selectedObj.getTCProperty("item_id").getDisplayableValue();
						String RevSeq=selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
						RevSeq=RevSeq.replace(";", "_");
						System.out.println("RevSeq="+RevSeq);
						String datasetname=selectedobjName+"_"+RevSeq+"_ModifiedBy_"+ErcDmlNo;

						System.out.println("B4 Dataset Qry call");
						TCComponent datasetExist=TechSpecUtil.qryObj(session,"Dataset Name","Dataset Name",datasetname);
						System.out.println("After Dataset Qry call");
						if(datasetExist!=null)
						{
							System.out.println("Dataset already available in system, only Named refrence will attach\n");
							System.out.println("Going to Add name refrence with dataset\n");
							addNamedReference(UpdatedRptHist,(TCComponentDataset)datasetExist);
						}
						else
						{
						System.out.print("111B4 CreateDataset func call with datasetname="+datasetname);						
						dataset=CreateDataset((TCComponentItemRevision)selectedObj,datasetname,selectedObj.getTCProperty("object_name").getDisplayableValue(),UpdatedRptHist);
						System.out.println("Going to Add name refrence with dataset\n");
						addNamedReference(UpdatedRptHist,dataset);
						}
						//getSingleGetDatasetWriteTicketsInputData(UpdatedRptHist,dataset);
						//System.out.println("Going to Add name refrence with dataset\n");
						//addNamedReference(UpdatedRptHist,dataset);
						System.out.println("Added name refrence with dataset\n");
					}
				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 */
			System.out.print("1111After CreateDataset func call");
		}
		else
		{
			MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updated successfully  !!","INFORAMTION",SWT.ICON_INFORMATION);






		}
		System.out.println("inside update status printing step completed!!");



		super.okPressed();
	}

	public boolean isReview()
	{

		/*TCComponentItemRevision dmlObj=null;

		ArrayList treelist=(ArrayList) treeViewer.getInput();
	  //	System.out.println("treelist.Size()="+treelist.size());
	  //	if(treelist.size()>0)
	//  	{
	 // 		if(treelist.get(0) instanceof ClassificationTreeLine)
	 // 		{
	  //			ClassificationTreeLine treeln=(ClassificationTreeLine)treelist.get(0);
		dmlObj=TechSpecUtil.getAttachedDML((TCComponentItemRevision)this.selectedObj,"CMHasSolutionItem","Review the Changes");
		if(dmlObj==null)
			dmlObj=TechSpecUtil.getAttachedDML((TCComponentItemRevision)this.selectedObj,"CMHasSolutionItem","BOM Process Group Review");
	  	//	}
	  	//}
		if(dmlObj!=null)
			isreview=true;
		 */
		isreview=true;
		return isreview;
	}
	private LinkedHashMap<String,String> queryUpdatedControlObject() throws TCException, NotLoadedException
	{
		// TODO Auto-generated method stub


		LinkedHashMap<String,String> modattrlist=new LinkedHashMap<String,String>();

		if(isreview==false)
			return modattrlist;


		String seltyp=selectedObj.getType();
		String objectID2=null;
		if(seltyp.equals("T5_TSCompRevision"))
		{


			objectID2=this.selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue().getTCProperty("item_id").getDisplayableValue();
		}

		else
			objectID2=this.selectedObj.getTCProperty("item_id").getDisplayableValue();
		String infostr="";


		String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
		String [] qryValues={"ICOUPDLIST",objectID2,"0"};
		int r;
		TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
		String info=null;
		if(objvec!=null)
		{
			for(int f=0;f<objvec.length;f++)
			{
				TCComponent objcntrl=objvec[f];



				String[] infoattr=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_Userinfo10"};

				int len=infoattr.length;

				for(r=len-1;r>=0;r--)
				{

					info=objcntrl.getPropertyDisplayableValue(infoattr[r]);

					if(info==null||info.isEmpty()==true||info.trim().length()==0) continue;

					else
						infostr+=info.toString()+",";



				}



				StringTokenizer stkinfostr=new StringTokenizer(infostr,",");

				while(stkinfostr.hasMoreElements())
				{

					String attrs=stkinfostr.nextToken();
					if(attrs.contains(":"))
					{
						String[] attrval=attrs.split(":");
						if(modattrlist.containsKey(attrval[0])==false)
							modattrlist.put(attrval[0],attrval[1]);
					}

				}


			}
		}


		return modattrlist;


	}

	//String truncate function based on limit with regular expression
	
	
    static ArrayList<String> arr = new ArrayList<String>();
    public static void cutting(String s,int Limit1,int Limit2)
    {    
        String Rec="";
        String Rem="";
       // arr.clear();
        if(s.length()<Limit1 && s.length()<Limit2)
        {
        	arr.add(s);
            return;
        }
        String FirstOcc = String.valueOf(s.charAt(Limit1));
        System.out.print("\n Character Found in First Limit Position: "+FirstOcc);
        if(FirstOcc.contains(",")==false)
        {
        	for(int x=Limit1;x<Limit2;x++)
        	{
        		String val=String.valueOf(s.charAt(x));
        		System.out.print("\n Val="+val);
        		if(val.contains(","))
        		{
        			 arr.add(s.substring(0, x));
        			 
        			 System.out.print("\n String1: "+arr);
        	            Rec = s.substring(0, (x+1));
        	            System.out.print("\n Substring For Limit1: "+Rec);
        	            Rem = s.substring((x+1), (s.length()));
        	            System.out.print("\n Remainder Substring For Limit1: "+Rem);
        	            cutting(Rem,Limit1,Limit2);      
        		}
        	}
        	
        }
        else
        {
        	
        	arr.add(s.substring(0, Limit1));
    		
    		//if(val.contains(","))
    		{
    			// arr.add(s.substring(0, x));
    			 
    			 System.out.print("\n found in first match String1: "+arr);
    			 String val=String.valueOf(s.charAt(Limit1+1));
    			 System.out.print("\nfound in first match Val="+val);
    	            Rec = s.substring(0, (Limit1+1));
    	            System.out.print("\nfound in first match Substring For Limit1: "+Rec);
    	            Rem = s.substring((Limit1+1), (s.length()));
    	            System.out.print("\nfound in first match Remainder Substring For Limit1: "+Rem);
    	            cutting(Rem,Limit1,Limit2);      
    		}
        }
       
       // String SecondOcc = String.valueOf(s.charAt(Limit2));
      //  System.out.print("\n Character Found in Second Limit Position: "+SecondOcc);
        
		/*
		 * if(FirstOcc.equals(",")) {
		 * System.out.print("\n Character Found At First Limit: "+Limit1);
		 * arr.add(s.substring(0, Limit1)); System.out.print("\n String1: "+arr); Rec =
		 * s.substring(0, (Limit1+1));
		 * System.out.print("\n Substring For Limit1: "+Rec); Rem =
		 * s.substring((Limit1+1), (s.length()));
		 * System.out.print("\n Remainder Substring For Limit1: "+Rem);
		 * cutting(Rem,Limit1,Limit2); } else if(SecondOcc.equals(",")) { System.out.
		 * print("\n Character Not Found in First Limit So Going To Second Limit...");
		 * System.out.print("\n Character Found At Second Limit: "+Limit2);
		 * arr.add(s.substring(0, Limit2)); System.out.print("\n String2: "+arr); Rec =
		 * s.substring(0, (Limit2+1));
		 * System.out.print("\n Substring For Limit2: "+Rec); Rem =
		 * s.substring((Limit2+1), (s.length()));
		 * System.out.print("\n Remainder Substring For Limit2: "+Rem);
		 * cutting(Rem,Limit1,Limit2); }
		 */
        return;
    }


//End String trunc func
	
	private void processData(TCComponent objcntrl,TreeMap<String, Object> namevalueP2) throws NotLoadedException, TCException
	{


		String attrmodids="";

		//objcntrl.lock();
		ArrayList<String> ModattrsList =new ArrayList<String>();
		for (Map.Entry<String, Object> entry : namevalueP2.entrySet())
		{
			attrmodids+=","+entry.getKey()+":"+entry.getValue();
			ModattrsList.add(entry.getKey());
		}

		System.out.println("value to be update in control obj="+attrmodids);
		String infostr="";

		String info;
		String info1;
		int r1 = 0;


		String[] infoattr=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_userinfo10"};

		int len=infoattr.length;

		for(int r=0;r<len ;r++)
		{

			info=objcntrl.getPropertyDisplayableValue(infoattr[r]);

			//r1=r;

			if(info==null||info.isEmpty()==true||info.trim().length()==0) break;

			else
				infostr+=info.toString()+",";


		}

		//cleaning existing value for control object
		
		objcntrl.lock();
		for( int l=0;l<len ;l++)
		{

			info1=objcntrl.getPropertyDisplayableValue(infoattr[l]);
			System.out.println("b4 cleaning controlobj's exiting val="+info1);

			objcntrl.setProperty(infoattr[l],"");
			System.out.println("removing each row i:"+l);


		}

		objcntrl.save();
		objcntrl.unlock();
		
		//End Cleaning 
		

		System.out.println("b4 removeDuplicates infostr="+infostr +" ModattrsList="+ModattrsList);
		String infostr1=null;
		if(infostr.isEmpty()==false)
		{
			infostr1=TechSpecUtil.removeDuplicates1(infostr,attrmodids,ModattrsList);
			System.out.println("after removeDuplicates infostr1="+infostr1);


			int k=0;
			if(infostr1.length()<200)
			{

				r1=k;
				System.out.println("b4 removeDuplicates len="+len);
				objcntrl.lock();
				for( int i=0;i<len ;i++)
				{

					info1=objcntrl.getPropertyDisplayableValue(infoattr[i]);
					System.out.println("b4 removeing controlobj's exiting val="+info1);

					objcntrl.setProperty(infoattr[i],"");
					System.out.println("removeDuplicates i:"+i);


				}

				objcntrl.save();
				objcntrl.unlock();
			}
			else
			{
				k++;
				r1=k;
			}
		}
		int totallen=0;
		if(infostr1!=null)
		{
		infostr1=","+infostr1;
		 totallen=infostr1.length()+attrmodids.length();
		}

		System.out.println("totallen="+totallen);
		objcntrl.lock();
		if(totallen <195)
		{

			String infostrDup=infostr1;
			String attrmodidsDup=attrmodids;

			System.out.println(r1+"b4 removeDuplicates infostr="+infostrDup+" attrmodids="+attrmodids);
			if(infostrDup!=null)
			{
				if(infostrDup.length()>0)
				{
					int postion=attrmodidsDup.indexOf(":");
					System.out.println(" postion="+postion);
					infostrDup=infostrDup.substring(1, postion);
				}
			}
			if(attrmodidsDup!=null)
			{
				if(attrmodidsDup.length()>0)
				{
					//attrmodidsDup=attrmodidsDup.substring(1, 5);
					int postion=attrmodidsDup.indexOf(":");
					System.out.println(" postion="+postion);
					attrmodidsDup=attrmodidsDup.substring(1, postion);
				}
			}
			//infostr.
			//TechSpecUtil.removeDuplicates(infostr);	

			System.out.println(r1+"After substring infostrDup="+infostrDup+" attrmodidsDup="+attrmodidsDup);
			//StringTokenizer stkinfostr1=new StringTokenizer(infostrDup,":");
			//StringTokenizer stkinfostr2=new StringTokenizer(attrmodidsDup,":");
			//System.out.println("stkinfostr1="+stkinfostr1 +" stkinfostr2="+stkinfostr2 +"infostrDup="+infostrDup+" attrmodidsDup="+attrmodidsDup);
			if(infostrDup!=null)
			{
				if(infostrDup.length()>0)
				{
					if(infostrDup.contains(attrmodidsDup)==true)
					{				
						objcntrl.setProperty(infoattr[r1],attrmodids);
					}
					else
					{				
						objcntrl.setProperty(infoattr[r1],infostr1+attrmodids);
					}
				}
			}
			else
			{
				if(attrmodids.length()<195)
				{
				if(attrmodids!=null)
				{
				objcntrl.setProperty(infoattr[r1],attrmodids);
				}
				}
				else
				{
				
					int chunkSize =1;
					//List<String> chunks;
					if(attrmodids.length()>192 && attrmodids.length()<=395)
					{
					 chunkSize = 192;
					 //String[] chunks=attrmodids.split(",",chunkSize);
			         //chunks = attrmodids.split("(?<=\\G.{" + chunkSize + "})");
					 //chunks=TechSpecUtil.split(attrmodids,chunkSize);
			         //System.out.println("chunkSize="+chunkSize +"splitted value="+TechSpecUtil.split(attrmodids,chunkSize));
				        //System.out.println("After Split > 195 ="+chunks);
					arr.clear();
					 cutting(attrmodids,192,196);
				        System.out.println("\n arr size="+arr.size());
				        for(String o:arr)
				        {
				            System.out.println("Splitted string "+o);
				            if(arr.size()==1)				        	
					        {
					        	objcntrl.setProperty(infoattr[r1],o);
					        }
				            else
				            {
				            	objcntrl.setProperty(infoattr[r1],o);
				            	r1++;
				            }
				        }
					 
				        
				       // System.out.println("chunks.length="+chunks.length+ " Chunk value:-"+Arrays.toString(chunks));
			         
					}
//					else
//					{
//						chunkSize=attrmodids.length()/195;
//						 chunks = attrmodids.split("(?<=\\G.{" + chunkSize + "})");
//					}
					
				}
			}
			System.out.println(r1+":00::"+infostr+attrmodids+":"+totallen);
		}
		else
		{
			String tempattrmodids="";
			String tempattrmodids1="";
			String tempkeyval;

			for (Map.Entry<String, Object> entry : namevalueP2.entrySet())
			{
				System.out.println("tempattrmodids1="+tempattrmodids1 +" tempattrmodids1.length="+tempattrmodids1.length()+" tempattrmodids="+tempattrmodids);
				tempkeyval=","+entry.getKey()+":"+entry.getValue();
				tempattrmodids1=tempattrmodids+tempkeyval;
				if(tempattrmodids1.length()<195)
				{
					//tempattrmodids+=","+entry.getKey()+":"+entry.getValue();
					tempattrmodids=tempattrmodids1;
					objcntrl.setProperty(infoattr[r1],tempattrmodids);
				}
				else
				{
					objcntrl.setProperty(infoattr[r1],tempattrmodids);
					r1++;
					tempattrmodids="";
					tempattrmodids1=tempattrmodids+tempkeyval;
					tempattrmodids=tempattrmodids1;


				}

				System.out.println(r1+":11::"+tempattrmodids+":"+tempattrmodids.length());
			}

			//objcntrl.setProperty(infoattr[r1+1],attrmodids);
		}


		objcntrl.save();
		objcntrl.unlock();
	}

	
	private void UpdateData(
	        TCComponent objcntrl,
	        TreeMap<String, Object> namevalueP2)
	        throws NotLoadedException, TCException {

	    final int MAX_LEN = 195;
	    final String[] INFO_ATTRS = {
	            "t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_userinfo10"
	    };

	    /* -----------------------------------
	     * Step 1: Build attrmodids & modAttrList
	     * ----------------------------------- */
	    StringBuilder attrmodids = new StringBuilder();
	   // List<String> modAttrsList = new ArrayList<>();
	    ArrayList<String> modAttrsList =new ArrayList<String>();
	    for (Map.Entry<String, Object> e : namevalueP2.entrySet()) {
	        attrmodids.append(",").append(e.getKey()).append(":").append(e.getValue());
	        modAttrsList.add(e.getKey());
	    }

	    /* -----------------------------------
	     * Step 2: Read existing values
	     * ----------------------------------- */
	    StringBuilder existing = new StringBuilder();
	    for (String attr : INFO_ATTRS) {
	        String val = objcntrl.getPropertyDisplayableValue(attr);
	        if (val == null || val.trim().isEmpty()) break;
	        existing.append(val).append(",");
	    }

	    /* -----------------------------------
	     * Step 3: Clean existing properties
	     * ----------------------------------- */
	    objcntrl.lock();
	    for (String attr : INFO_ATTRS) {
	        objcntrl.setProperty(attr, "");
	    }
	    objcntrl.save();
	    objcntrl.unlock();

	    /* -----------------------------------
	     * Step 4: Optimize duplicity
	     * ----------------------------------- */
	    String optimized = "";
	    if (existing.length() > 0) {
	        optimized = TechSpecUtil.optimizeDuplicity(
	                existing.toString(),
	                attrmodids.toString(),
	                modAttrsList
	        );
	    }

	    /* -----------------------------------
	     * Step 5: Write back with size handling
	     * ----------------------------------- */
	    objcntrl.lock();

	    int index = 0;
	    StringBuilder buffer = new StringBuilder();

	    if (optimized != null && !optimized.isEmpty()) {
	        buffer.append(",").append(optimized);
	    }

	    for (Map.Entry<String, Object> e : namevalueP2.entrySet()) {
	        String chunk = "," + e.getKey() + ":" + e.getValue();

	        if (buffer.length() + chunk.length() >= MAX_LEN) {
	            objcntrl.setProperty(INFO_ATTRS[index++], buffer.toString());
	            buffer.setLength(0);
	        }
	        buffer.append(chunk);
	    }

	    if (buffer.length() > 0 && index < INFO_ATTRS.length) {
	        objcntrl.setProperty(INFO_ATTRS[index], buffer.toString());
	    }

	    objcntrl.save();
	    objcntrl.unlock();
	}
	
	private void createUpdateControlObject(String objectID2,HashMap<String, Object> namevalueH2,String ModAddress) throws TCException, ServiceException, NotLoadedException 
	{
		// TODO Auto-generated method stub

		/*	String attrmodids="";

		for (Map.Entry<String, Object> entry : namevalueP2.entrySet())
        {
			attrmodids+=","+entry.getKey()+":"+entry.getValue();
        }


		String infostr="";
		 */


		TreeMap<String, Object> namevalueP2=new TreeMap<String,Object>();

		namevalueP2.putAll(namevalueH2);

		String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
		String [] qryValues={"ICOUPDLIST",objectID2,"0"};
		int r1 = 0;
		TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
		String info=null;
		TCComponent objcntrl=null;

		if(objvec!=null&&objvec.length>0)
		{

			objcntrl=objvec[objvec.length-1];
			System.out.println("updateWO");


		}

		else
		{
			String classname="T5_ControlObject";
			TreeMap<String,String> propvalues=new TreeMap<String,String>();
			propvalues.put("t5_Syscd", "ICOUPDLIST");
			propvalues.put("t5_SubSyscd", objectID2);
			propvalues.put("object_name", ModAddress);

			objcntrl=TechSpecUtil.createWO( this.session,classname,propvalues);

			System.out.println("createWO");


		}	
		//processData(objcntrl,namevalueP2);
		UpdateData(objcntrl,namevalueP2);


		////




		////


	}



	@Override
	protected void cancelPressed() {


		boolean buttonpressed=false;
		int buttonpressed1=-1;
		localAIFComponentContextList.clear();
		m_commandTargetStateList.clear();

		ArrayList treelist=(ArrayList) treeViewer.getInput();
		System.out.println("treelist.Size()="+treelist.size());
		if(treelist.size()<=0 )
		{
			buttonpressed=true;
		}
		for(int i=0;i<treelist.size();i++)
		{
			if(treelist.get(i) instanceof ClassificationTreeLine)
			{
				ClassificationTreeLine treeObj=(ClassificationTreeLine) treelist.get(i);


				TCComponentItemRevision item_rev=treeObj.getItemrev();

				try {
					String parttype=treeObj.getItemrev().getTCProperty("t5_PartType").getDisplayableValue();
					if(parttype.equals("Module"))
					{
						continue;
					}

				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


				try {

					parent_item=item_rev.getItem();
					localAIFComponentContext=new AIFComponentContext(parent_item,item_rev,"structure_revision");
					System.out.println("fggdfdfsdsasasa:::"+localAIFComponentContext.toString());
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}


				CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
				cmdstate.setCaughtException(new TCException("Below Values are modified. Do you want to Close ?"));
				cmdstate.setDone(true);
				localAIFComponentContextList.add(localAIFComponentContext);
				m_commandTargetStateList.add(cmdstate);


				for (Map.Entry<String, String> entry : modifedactvalueMap.entrySet())//modifedvalueMap.entrySet())
				{
					/* ClassificationPropertyValue[] ico_prop_values1 = new ClassificationPropertyValue[1];
			    System.out.println(entry.getKey() + " = " + entry.getValue());        
		        ico_prop_values1[0] = new ClassificationPropertyValue();
		        ico_prop_values1[0].dbValue = (String) entry.getValue();
					 */
					String attid=(String) entry.getKey();
					String attval=(String) entry.getValue();
					String attname=attrNameIDMap.get(attid);
					cmdstate=new CommandTargetState(localAIFComponentContext,null);
					cmdstate.setCaughtException(new TCException("["+attid+"]"+attname+"-->"+attval));
					System.out.println("["+attid+"]"+attname+"-->"+attval);
					cmdstate.setDone(true);

					m_commandTargetStateList.add(cmdstate);

				}
				/*

	       if(localAIFComponentContextList.size()>0)
		  	{
		  	AIFComponentContext[] selobjs=localAIFComponentContextList.toArray(new AIFComponentContext[localAIFComponentContextList.size()]);
		  	 System.out.println("selobjs="+selobjs.length);
		  	AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

           TCSession session=(TCSession) app.getSession();


           TMLDataBean databean= new TMLDataBean(parent_item.getSession(), null,selobjs,exe_evt);
           databean.setTargetContexts(selobjs);

            MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
           System.out.println("inside update status printing step");
           paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList);

           buttonpressed=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.YES_LABEL , IDialogConstants.NO_LABEL },3);
		  	}
		  	else
	  	{
		  		MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updated successfully  !!","INFORAMTION",SWT.ICON_INFORMATION);
		  	}
				 */
			}
		}

		if(localAIFComponentContextList.size()>0)
		{
			AIFComponentContext[] selobjs=localAIFComponentContextList.toArray(new AIFComponentContext[localAIFComponentContextList.size()]);
			System.out.println("selobjs="+selobjs.length);
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();

			TCSession session=(TCSession) app.getSession();


			TMLDataBean databean= new TMLDataBean(parent_item.getSession(), null,selobjs,exe_evt);
			databean.setTargetContexts(selobjs);

			MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
			System.out.println("inside update status printing step");
			paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList);

			//buttonpressed=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.YES_LABEL , IDialogConstants.NO_LABEL },3,null);
			buttonpressed1=TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob,new String[] { IDialogConstants.YES_LABEL , IDialogConstants.NO_LABEL },3,null);
		}
		else
		{
			MessageBox.post(PlatformHelper.getCurrentShell(),"No Value to Update !!","INFORAMTION",SWT.ICON_INFORMATION);
			//MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updated successfully  !!","INFORAMTION",SWT.ICON_INFORMATION);
		} 	
		System.out.println("buttonpressed1::"+buttonpressed1);
		if(buttonpressed1==0|| buttonpressed1==-1)//if(buttonpressed)
			super.cancelPressed();
	}

	//used to set the Title in the dialog window
	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Technical-Specification Window");

	} 
}

class MDMTreeContentProvider4PRD implements ITreeContentProvider {
	@Override
	public boolean hasChildren(Object element) {
		if(element instanceof ClassificationTreeLine)
		{

			return ((ClassificationTreeLine)element).getAttrList().size()==0? false:true;
		}

		else if(element instanceof ClassificationAnnotationLine)
		{

			return ((ClassificationAnnotationLine)element).getAttrList().size()==0? false:true;
		}
		else
			return false;
		/*if(element instanceof ClassificationTreeLine)
    	{

    		ClassificationTreeLine p = (ClassificationTreeLine) element;
    		TCComponentItemRevision tcrev= p.getItemrev();
    		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
    		TCSession session=(TCSession) app.getSession();
    		GetClassifiedAttr getProps= new GetClassifiedAttr(tcrev,session);
    		String modaddress=p.getModuleAddress();
    		if(getProps!=null)
    		{
    			try {
    				if(getProps.getICOProps()!=null)
					modaddress=getProps.getICOProps().getCid();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		ArrayList<ClassificationTableLine> classificationList=new ArrayList<ClassificationTableLine>();
			try {
				classificationList = new GetModuleAttributesForClasses(modaddress,session).testgetGetAttributesForClasses();
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

    		//for(int k=0;k<classificationList.size();k++)
    		//{

    		//	classificationList.get(k).setParent(p);
    		//}
    		//p.setAttrList(classificationList);
    		//return classificationList.size()==0? false:true;
    	}
    	else
    	{
    	return false;
    	}*/
	}

	@Override
	public Object getParent(Object element) {
		if(element instanceof ClassificationAnnotationLine)
		{
			ClassificationAnnotationLine p = (ClassificationAnnotationLine) element;

			return p.getParent();
		}

		else if(element instanceof ClassificationTableLine)
		{
			ClassificationTableLine p = (ClassificationTableLine) element;

			return p.getParent();
		}

		return null;
	}

	@Override
	public Object[] getElements(Object inputElement) {


		return ArrayContentProvider.getInstance().getElements(inputElement);
	}

	@Override
	public Object[] getChildren(Object parentElement) {

		if(parentElement instanceof ClassificationTreeLine)
		{
			ClassificationTreeLine p = (ClassificationTreeLine) parentElement;
			return p.getAttrList().toArray();
		}

		else if (parentElement instanceof ClassificationAnnotationLine)
		{
			ClassificationAnnotationLine p = (ClassificationAnnotationLine) parentElement;
			return p.getAttrList().toArray();
		}
		else
			return null;

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		// TODO Auto-generated method stub

	}
}

class MDMTreeTableLabelProvider4PRD 	extends LabelProvider 	implements ITableLabelProvider {

	private TreeViewer treeViewer;






	/*static {
imageRegistry.put("smileImage", ImageDescriptor.createFromFile(
TableViewerExample.class,
"smile.jpg"));
}*/
	public MDMTreeTableLabelProvider4PRD(TreeViewer treeViewer) {
		this.treeViewer = treeViewer;
	}




	public String getColumnText(Object element, int columnIndex) {

		if(element instanceof ClassificationTableLine)
		{
			ClassificationTableLine tabline = (ClassificationTableLine) element;
			System.out.println("1columnIndex="+columnIndex);
			switch (columnIndex) {
			case 0:
				System.out.println("1tabline.getSrlNo()="+tabline.getSrlNo());
				return tabline.getSrlNo()+"";
				/* case 1:
	    	 System.out.println("1tabline.getAnnotation()="+tabline.getParent().getAnnotation());
		      return tabline.getParent().getAnnotation();*/
			case 2:
				System.out.println("1tabline.getAttrID()="+tabline.getAttrID());
				return tabline.getAttrID();
			case 3:
				System.out.println("1tabline.getAttrName()="+tabline.getAttrName());
				return tabline.getAttrName();		      
			case 4:
				System.out.println("1abline.getAttrValue()="+tabline.getAttrValue());
				return tabline.getAttrValue();
			case 5:
				System.out.println("1abline.getNewValue()="+tabline.getNewValue());
				return tabline.getNewValue();
			case 6:
				System.out.println("1abline.UnitName()="+tabline.getUnit());
				return tabline.getUnit();
			case 7:
				System.out.println("1abline.getLovID()="+tabline.getLovID());
				return tabline.getLovID();

			case 8:
				System.out.println("1abline.getArray()="+tabline.getArraySize());
				return tabline.getArraySize()+"";
			}
		}

		else if(element instanceof ClassificationAnnotationLine)
		{
			ClassificationAnnotationLine tabline = (ClassificationAnnotationLine) element;
			System.out.println("1columnIndex="+columnIndex);
			switch (columnIndex) {

			case 1:
				System.out.println("1tabline.getAnnotation()="+tabline.getAnnotation());
				return tabline.getAnnotation();
			}
		}
		return "";
	}




	@Override
	public Image getColumnImage(Object arg0, int arg1) {
		// TODO Auto-generated method stub
		return null;
	}









}




class MDMTreeTableContentProvider4PRD implements IStructuredContentProvider {
	public Object[] getElements(Object inputElement) {
		ArrayList<ClassificationTableLine> list= (ArrayList<ClassificationTableLine>) inputElement;

		Object[] obj=list.toArray();

		for(int x=0;x<obj.length;x++)
		{

			System.out.println("GHH::"+obj[x].toString());

		}
		return list.toArray();
	}

	public void dispose() {
	}



	@Override
	public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub

	}
}


class MDMEditingSupport4PRD extends EditingSupport
{

	private ArrayList<String> str;
	private ColumnViewer viewer;
	private UpdateMDMDlgForPRD mdmdlg;
	private boolean valupdatable;
	private int idx;

	public  MDMEditingSupport4PRD(UpdateMDMDlgForPRD mdmdlg,ColumnViewer viewer,boolean valupdatable,int idx) {

		super(viewer);
		this.mdmdlg=mdmdlg;
		this.viewer=viewer;
		this.valupdatable=valupdatable;
		this.idx=idx;

	}

	@Override

	protected void setValue(Object element, Object value) {


		//Added by rajesh on 27/09/2022			
		boolean DepnAttrFlg=false;
		System.out.println("str="+str + " element="+element); //here str is LOV's value array
		String key2beUpd=null;
		if(element instanceof ClassificationTableLine)
		{
//			String id=((ClassificationTableLine) element).getAttrID();
//			String val=((ClassificationTableLine) element).getAttrValue();
//			String lovid=((ClassificationTableLine) element).getLovID();
//			int arraysize=((ClassificationTableLine) element).getArraySize();
//			String deptcfg1=((ClassificationTableLine) element).getDepattrcfg();
//			String deptval1=((ClassificationTableLine) element).getDepval();
			String id=((ClassificationTableLine) element).getAttrID();
			String val=((ClassificationTableLine) element).getAttrValue();
			String lovid=((ClassificationTableLine) element).getLovID();
			int arraysize=((ClassificationTableLine) element).getArraySize();
			String deptcfg1=((ClassificationTableLine) element).getDepattrcfg();
			String deptval1=((ClassificationTableLine) element).getDepval();
			String depAttrId=((ClassificationTableLine) element).getDepattr();

			System.out.println("id="+id+" 11val="+val +" arraysize="+arraysize +" deptcfg1="+deptcfg1+ " lovid="+lovid +" deptval1="+deptval1);
			String valchg=val+":";
			//keylovList
//Added on 27/07/2023 need to remove after test
//			if(id.contains("240"))
//			{
//				 try {
//					String retstr=TechSpecUtil.getDepEditedHashMapFunc(element, value, depmodifedvalueMap);
//					System.out.println("retstr="+retstr);
//				 } catch (NotLoadedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (TCException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
				
				
				 
//			}
//End on 27/07/2023 need to remove after test
			KeyLOVEntry[] keyLOVEntries2=null;
			//KeyLOVDefinition2 lovDef=null;
			int lovvalsize=0;
			KeyValueLOV keyval1=null;
			String actval1=null;
			TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
			ClassificationService clsService = ClassificationService.getService(session);
			KeyValueLOV keylovval=null;
			String[] keyLOVIds = new String[1];
			//KeyLOVEntry keyLOVEntries1 = null;
			keyLOVIds[0] =lovid;
			System.out.println("Calling GetKeyandValueFromLOV ");
			com.teamcenter.services.rac.classification._2009_10.Classification.GetKeyLOVsResponse2 response=null;
			if(lovid.equals("99")==false)
			{
				try {
					response=clsService.getKeyLOVs2( keyLOVIds );

					if ( response.data.sizeOfPartialErrors() > 0)

						throw new ServiceException( "ClassificationService.getKeyLOVs2 returned a partial Error.");
				} catch (ServiceException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				@SuppressWarnings("unchecked")
				Map<String, KeyLOVDefinition2> keyLOVs = response.keyLOVs;
				System.out.println("*****Lov Details******* "+keyLOVs.size());
				Set<String> keys = keyLOVs.keySet();
				ArrayList<String> lovlist=new ArrayList<String>();
				for(Iterator<String> itr = keys.iterator();itr.hasNext();)
				{
					String id1 = itr.next();
					System.out.println("id1= "+id1);
					//KeyLOVDefinition2 lovDef = keyLOVs.get( id1 );
					mdmdlg.lovDef = keyLOVs.get( id1 );
					// lovDef1 = keyLOVs.get( id1 );
					ICSKeyLov keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(mdmdlg.lovDef.id),deptcfg1);
					keylovval=new KeyValueLOV(keylov.getId(),keylov);
					boolean ishidekey=ICSKeyLov.getICSKeyLov(Integer.parseInt(mdmdlg.lovDef.id)).isHideKeys();
					System.out.println(" GetKeyandValueFromLOV KeyLOV Id             : "+mdmdlg.lovDef.id);
					System.out.println(" GetKeyandValueFromLOV KeyLOV Name           : "+mdmdlg.lovDef.name);
					System.out.println(" GetKeyandValueFromLOV KeyLOV Options        : "+mdmdlg.lovDef.options);
					System.out.println(" GetKeyandValueFromLOV KeyLOV Owning Site    : "+mdmdlg.lovDef.owningSite.getUid());
					System.out.println(" GetKeyandValueFromLOV KeyLOV tag         : "+mdmdlg.lovDef.keyLovtag.getUid());
					System.out.println(" GetKeyandValueFromLOV KeyLOV HIDEKEY         : "+ishidekey);
					System.out.println(" GetKeyandValueFromLOV KeyLOV Share Sites : "+mdmdlg.lovDef.sharedSites);
					//KeyLOVEntry[] keyLOVEntries =lovDef.keyLovEntries; //hashed on 19/07/2023
					mdmdlg.keyLOVEntries =mdmdlg.lovDef.keyLovEntries; //added on 19/07/2023
					//keyLOVEntries =lovDef.keyLovEntries;

					System.out.println("GetKeyandValueFromLOV Number of KeyLOV's : "+mdmdlg.keyLOVEntries.length);

					
					//lovSize=keyLOVEntries.length;
				
					System.out.println("lovSize="+mdmdlg.keyLOVEntries.length +" arraysize="+arraysize +" str="+str +" lovDef.id="+mdmdlg.lovDef.id);
					

/*					if(arraysize<=1)
					{
						if(str.size()>0)
						{
						actval1=str.get(Integer.parseInt(value.toString()));
						System.out.println("actval1::"+actval1);
						}
					}
*/
					if(str.size()>0)
					{
					//actval1=str.get(Integer.parseInt(value.toString()));
						if (value != null && !value.toString().trim().isEmpty()) {
						    try {
						        int index = Integer.parseInt(value.toString().trim());

						        if (str != null && index >= 0 && index < str.size()) {
						            actval1 = str.get(index);
						        }
						    } catch (NumberFormatException e) {
						        // invalid number input – actval1 stays null
						    	System.out.println("NumberFormatException for actval1::"+actval1);
						    	actval1 ="NA";
						    }
						}
						else
						{
							actval1 ="NA";
						}
					System.out.println("actval1::"+actval1);
					}
					String prodlineval=null;
					String platformaval=null;
					//String prodlineval=null;
					for(int k=0;k<mdmdlg.keyLOVEntries.length;k++)
					{
						//if(lovDef.id.contains("241")) //hashed on 27/07
//						if(id.contains("240"))
//						{
//
//							// prodlineval=initialValMap.get(depprodlineval); //hashed on 27/07
//							//platformaval=initialValMap.get("8241");
//							prodlineval=((ClassificationTableLine) element).getAttrValue(); //newly add 27/07
//							if(prodlineval!=null)
//							{
//								//prodlineval=((ClassificationTableLine) element).getAttrValue(); //newly add 27/07
//								//									prodlineval=initialValMap.get(depprodlineval);
//							}
//							else
//							{
//								prodlineval=initialValMap.get(depprodlineval);
//							}
//							//								 if(prodlineval==null)//newly add 27/07
//							//								 {
//							//									 prodlineval=initialValMap.get(depprodlineval);//newly add 27/07
//							//								 }
//
//						}
						KeyLOVEntry keyLOVEntries1 = mdmdlg.lovDef.keyLovEntries[k];
						//KeyLOVEntry[] keyLOVEntries2 = keyLOVEntries1;
						System.out.println("GetKeyandValueFromLOV KeyLOV Entry Key     : "+keyLOVEntries1.lovKey);
						System.out.println("GetKeyandValueFromLOV KeyLOV Entry Value   : "+keyLOVEntries1.lovValue);
						System.out.println("GetKeyandValueFromLOV depmodifedvalueMap : "+mdmdlg.depmodifedvalueMap+ " keyLOVEntries1.lovValue.length()="+keyLOVEntries1.lovValue.length() + " prodlineval="+prodlineval);
						System.out.println("prodlineval: "+prodlineval );
						if(keyLOVEntries1.lovValue.length()>0)
						{ 

							//Added on 02/08/2023
							String tmpUpdattr=null;
							String prefx=null;
							String prevattrid=null;
							String tobekeylov=null;
							String validDepattrid=null;
							String tmpaatrid=null;
							String genattrid=null;
							tmpaatrid=id;
							System.out.println("tmpaatrid="+tmpaatrid +" depAttrId="+depAttrId);
							
							if(depAttrId!=null && depAttrId.isEmpty()==false)
							{
								DepnAttrFlg=true;
								System.out.println("validDepattrid="+depAttrId);
								tobekeylov=null;
								tmpUpdattr=id;
								//prefx=tmpUpdattr.substring(0,1);
								//prevattrid=prefx+validDepattrid;
								prevattrid=depAttrId;
								tobekeylov=mdmdlg.depmodifedactvalueMap.get(prevattrid);
							}
							/*
							genattrid=tmpaatrid.substring(1,tmpaatrid.length());
							System.out.println("genattrid="+genattrid);
							
							
							if(depAttrId!=null)
							{
								try {
									validDepattrid=null;
									validDepattrid=TechSpecUtil.getDeprattridFunc(genattrid);
								} catch (NotLoadedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (TCException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								System.out.println("11validDepattrid="+validDepattrid);
								//if(id.contains("241"))
								if(validDepattrid!=null && validDepattrid.isEmpty()==false)
								{
									DepnAttrFlg=true;
									System.out.println("validDepattrid="+validDepattrid);
									tobekeylov=null;
									tmpUpdattr=id;
									prefx=tmpUpdattr.substring(0,1);
									prevattrid=prefx+validDepattrid;
									tobekeylov=mdmdlg.depmodifedactvalueMap.get(prevattrid);
								}
							}
							*/
						/*	
							if(id.contains("241"))
							{
								tobekeylov=null;
								 tmpUpdattr=id;
								 prefx=tmpUpdattr.substring(0,1);
								 prevattrid=prefx+"240";
								 tobekeylov=mdmdlg.depmodifedactvalueMap.get(prevattrid);
							}
							if(id.contains("242"))
							{
								tobekeylov=null;
								 tmpUpdattr=id;
								 prefx=tmpUpdattr.substring(0,1);
								 prevattrid=prefx+"241";
								 tobekeylov=mdmdlg.depmodifedactvalueMap.get(prevattrid);
							}
							if(id.contains("243"))
							{
								tobekeylov=null;
								 tmpUpdattr=id;
								 prefx=tmpUpdattr.substring(0,1);
								 prevattrid=prefx+"242";
								 tobekeylov=mdmdlg.depmodifedactvalueMap.get(prevattrid);
							}
						*/
							System.out.println("prefx="+prefx +" prevattrid="+prevattrid +" tobekeylov="+tobekeylov +" actval1="+actval1);
							if(actval1!=null)
							{	
								if(tobekeylov==null)
								{
									if(actval1.equals(keyLOVEntries1.lovValue))
									{
										key2beUpd=keyLOVEntries1.lovKey;
										System.out.println(" 221tobekeylov="+tobekeylov +" 221key2beUpd"+key2beUpd);
										//depmodifedactvalueMap.put(UpdAttrId,tobekeylov); //added on 02/08/2023
										//key2beUpd=tobekeylov; //added on 02/08/2023
										break;
									}
								}
								else
								{
									//if(SelBusUnit.contains("CAR") || SelBusUnit.contains("MUV"))
									if(mdmdlg.depattrcntrlobjsize >0)
									{
										System.out.println("inside CAR/MUV VC condition for dependent LOV");
										if(actval1.equals(keyLOVEntries1.lovValue))
										{
											if(keyLOVEntries1.lovKey.contains(tobekeylov))
											{
												key2beUpd=keyLOVEntries1.lovKey;
												System.out.println(" 223tobekeylov="+tobekeylov +" 223key2beUpd"+key2beUpd);
												//depmodifedactvalueMap.put(UpdAttrId,tobekeylov); //added on 02/08/2023
												//added on 02/08/2023
												break;
											}
										}
									}
									else
									{
										System.out.println("inside CVBU VC condition for dependent LOV");
										if(actval1!=null)
										{
											if(actval1.equals(keyLOVEntries1.lovValue))
											{
												//if(keyLOVEntries1.lovKey.contains(tobekeylov))
												//{
												key2beUpd=keyLOVEntries1.lovKey;
												System.out.println(" 223tobekeylov="+tobekeylov +" 223key2beUpd"+key2beUpd);
												//depmodifedactvalueMap.put(UpdAttrId,tobekeylov); //added on 02/08/2023
												//added on 02/08/2023
												break;
												//}
											}
										}
									}
								}
							}
							System.out.println(" 22tobekeylov="+tobekeylov +" 22key2beUpd"+key2beUpd);
							/*
							if(prodlineval!=null ) //here prodlineval would be vehiclass class name like platform X4,X2 etc
							{
								System.out.println("inside prodlineval="+prodlineval);
								if(keyLOVEntries1.lovKey.contains(prodlineval)) 
								{								
									if(actval1!=null)
									{
										if(actval1.equals(keyLOVEntries1.lovValue))
										{
											key2beUpd=keyLOVEntries1.lovKey;
											break;
										}
									}
								}
								else
								{
									System.out.println("prodlineval : "+prodlineval +" not matched with LOV value ");
								}
							}
							else
							{
								System.out.println("Outside dependent value cond. keyLOVEntries1.lovValue="+keyLOVEntries1.lovValue +" keyLOVEntries1.lovKey="+keyLOVEntries1.lovKey);
								if(actval1!=null) 
								{
									if(actval1.equals(keyLOVEntries1.lovValue))
									{
										key2beUpd=keyLOVEntries1.lovKey;
										break;
									}
								}
							}
*/

						}
					}


				}

			}
			//End by Rajesh on 27/09/2022

			//String valchg=val+":";


			int i;
			String b4Val="0";
			for( i=0;i<str.size();i++)
			{

				System.out.println(str.get(i)+":xdxddfdr::"+i);
				if(val.equals(str.get(i)))
				{
					b4Val=i+"";
					break;
				}


			}

			System.out.println("Before val::"+b4Val +" val="+val);
			System.out.println("value.toString()"+value.toString() + "val.toString()="+val.toString());
/*					try
			{
				if(arraysize<=1 && lovid.equals("99")==false)
				{
					if(Integer.parseInt(value.toString())<0)
					//if(Integer.parseInt(val.toString())<0)
					{
						value=b4Val;
						System.out.println("Input value does not exist in LOV, so choose value from LOV only");

						MessageBox.post(parentShell,"Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);

						// MessageBox msgbox = new MessageBox(parentShell, SWT.ICON_INFORMATION);
		             //  msgbox.setText("Information.");
		            //   msgbox.setMessage("Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator ");
		            //   msgbox.open();           
					}     

				}
				else
				{
					System.out.println("skip for non LOV String value ");
				}
			} 
			catch(NumberFormatException e) 
			{ 
				e.printStackTrace();
			}

*/					if(Integer.parseInt(lovid)<0)
			{
				System.out.println("key2beUpd ="+key2beUpd +" str.size()="+str.size());
				
					if(arraysize<=1 && str.size()>0)
					{
						String actval=str.get(Integer.parseInt(value.toString()));
						System.out.println("key2beUpd ="+key2beUpd +" str.size()="+str.size()+" actval="+actval +" actval1="+actval1);
						valchg+=":"+actval;		
						//((ClassificationTableLine) element).setAttrValue(str.get(Integer.parseInt(value.toString()))); //unhashed on 31/07
						((ClassificationTableLine) element).setNewValue(actval); //hashed on 31/07
						//((ClassificationTableLine) element).setAttrValue(key2beUpd);
						KeyValueLOV keylov= mdmdlg.keylovList.get(((ClassificationTableLine) element).getLovID());
						//System.out.println(i+":"+keylov.getValue().get(i)+"GGGGGGKKK:"+keylov.getKey().get(i));
						System.out.println("keylov.getKey().get(Integer.parseInt(value.toString()=="+keylov.getKey().get(Integer.parseInt(value.toString())));
						if(id.contains("240") || id.contains("241") || id.contains("242") || id.contains("243"))
						{
						((ClassificationTableLine) element).setChangeValue(keylov.getKey().get(Integer.parseInt(value.toString())));
						key2beUpd=keylov.getKey().get(Integer.parseInt(value.toString()));
						}
						else
						{
							((ClassificationTableLine) element).setChangeValue(key2beUpd);
						}
						//((ClassificationTableLine) element).setChangeValue(key2beUpd);

						System.out.println("b4 set modifedvalueMap attrid="+((ClassificationTableLine) element).getAttrID() +" modifedvalueMap change value="+ ((ClassificationTableLine) element).getChangeValue() +" new value="+((ClassificationTableLine) element).getAttrValue());

						mdmdlg.modifedvalueMap.put(((ClassificationTableLine) element).getAttrID(),((ClassificationTableLine) element).getChangeValue());
					}
					
				

				/*else if(arraysize>1)
			{

				System.out.println("PPPPPPPPPPP1111value.toString()"+value.toString());

				((ClassificationTableLine) element).setAttrValue(value.toString());
				valchg+=":"+value;
			}*/
			}
			else
			{
				((ClassificationTableLine) element).setNewValue(value.toString());
				valchg+=":"+value;
			}


			System.out.println("b4 set modifedvalueMap id="+id +" modifedvalueMap change value="+valchg);
			//	((MyModel) element).setAttributevalue("jkjhvghvgh");//value.toString());
			
			//Newly added on 28/07 start
			/*
			 * System.out.println("value.toString()"+value.toString() +
			 * "val.toString()="+val.toString()); if(value.toString().length()>0) {
			 * 
			 * mdmdlg.modifedvalueMap.put(id,value.toString());
			 * System.out.println("After set modifedvalueMap id="+id
			 * +" modifedvalueMap change value="+valchg); }
			 */
			try
			{
				if(arraysize<=1 && lovid.equals("99")==false)
				{
					if(Integer.parseInt(value.toString())<0)
					//if(Integer.parseInt(val.toString())<0)
					{
						value=b4Val;
						System.out.println("Input value does not exist in LOV, so choose value from LOV only");

						MessageBox.post(mdmdlg.getShell(),"Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);

						/* MessageBox msgbox = new MessageBox(parentShell, SWT.ICON_INFORMATION);
		               msgbox.setText("Information.");
		               msgbox.setMessage("Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator ");
		               msgbox.open();    */         
					}     

				}
				else
				{
					System.out.println("skip for non LOV String value ");
				}
			} 
			catch(NumberFormatException e) 
			{ 
				e.printStackTrace();
			}

			//Newly added on 28/07 end
			
			mdmdlg.modifedactvalueMap.put(id,valchg);

			System.out.println(((ClassificationTableLine) element).toString());
			getViewer().update(element, null);
			
			
			//Added newly to restrict cmvrno value update by designer
			
			//String Updval=((ClassificationTableLine) element).getAttrValue();
			String Updval=((ClassificationTableLine) element).getNewValue();
			String UpdAttrId=((ClassificationTableLine) element).getAttrID();
			//String UpdvalKey=((ClassificationTableLine) element).
			System.out.println("UpdAttrId="+UpdAttrId +" Updval="+Updval +" key2beUpd="+key2beUpd );
			if(UpdAttrId!=null && Updval!=null)
			{
			//depmodifedactvalueMap.put(UpdAttrId,Updval);
//				if(key2beUpd!=null)
//				{
//				depmodifedactvalueMap.put(UpdAttrId,key2beUpd);
//				}
//				else
				
				
//				{
				
//				if(UpdAttrId.contains("240"))
//				{
//					System.out.println("b4 clearing depmodifedactvalueMap for lov selection for 240 click");
//					depmodifedactvalueMap.clear();
//				}
				System.out.println(" b4 remove depmodifedvalueMap DepnAttrFlg="+DepnAttrFlg);
				if(DepnAttrFlg==true)
				//if(UpdAttrId.contains("240") || UpdAttrId.contains("241") || UpdAttrId.contains("242") || UpdAttrId.contains("243"))
				{
					System.out.println("b4 clearing depmodifedactvalueMap for lov selection for 240/241/242/243/401/402/403 click");
					mdmdlg.depmodifedactvalueMap.remove(UpdAttrId);
					System.out.println("after depmodifedactvalueMap.remove call depmodifedactvalueMap for lov selection for 240/241/242/243 click"+mdmdlg.depmodifedactvalueMap);

//					for(int k1=0;k1<keyLOVEntries.length;k1++)
//					{
//						KeyLOVEntry keyLOVEntries11 = lovDef.keyLovEntries[k1];
//
//						System.out.println("2GetKeyandValueFromLOV KeyLOV Entry Key     : "+keyLOVEntries11.lovKey);
//						System.out.println("2GetKeyandValueFromLOV KeyLOV Entry Value   : "+keyLOVEntries11.lovValue);
//						System.out.println("2b4 put depmodifedactvalueMap   : "+depmodifedactvalueMap +" Updval="+Updval);
//						if(keyLOVEntries11.lovValue.contains(Updval))
//						{
//						
//							
//							//End added on 02/08/2023
//							System.out.println("adding key for depmodifedactvalueMap keyLOVEntries11.lovKey="+keyLOVEntries11.lovKey );
//
//							//depmodifedactvalueMap.put(UpdAttrId,keyLOVEntries11.lovKey); //hashed on 02/08/2023
//							//key2beUpd=keyLOVEntries11.lovKey;//hashed on 02/08/2023
//							//depmodifedactvalueMap.put(UpdAttrId,tobekeylov); //added on 02/08/2023
//							//key2beUpd=tobekeylov; //added on 02/08/2023
//							//break;
//							depmodifedactvalueMap.put(UpdAttrId,key2beUpd);
//						}
//					}
					System.out.println("222 UpdAttrId="+UpdAttrId + "222 key2beUpd="+key2beUpd);
					mdmdlg.depmodifedactvalueMap.put(UpdAttrId,key2beUpd);
				}
//				}
			}
			System.out.println("2323depmodifedactvalueMap="+mdmdlg.depmodifedactvalueMap);
			
			
			// End newly to restrict cmvrno value update by designer

		}


	
	}


	/*
	protected void setValue(Object element, Object value) {

		 if(element instanceof ClassificationTableLine)
		 {
			 String id=((ClassificationTableLine) element).getAttrID();
			 String val=((ClassificationTableLine) element).getNewValue();//.getAttrValue();
			 String val1="";
			 if(val==null)
				 val=	((ClassificationTableLine) element).getAttrValue();//.getAttrValue();
			 val1=((ClassificationTableLine) element).getAttrValue();
			 String lovid=((ClassificationTableLine) element).getLovID();
			 int arraysize=((ClassificationTableLine) element).getArraySize();

			 String valchg=val1+":";


			 int i;
			 String b4Val="0";
			 for( i=0;i<str.size();i++)
			 {
				 System.out.println(str.get(i)+":xdxddfdr::"+i);
				 System.out.println(":vval::"+val);
				 //				if(val==null)
				 //					val="";
				 if(val.equals(str.get(i)))
				 {
					 b4Val=i+"";
					 break;
				 }


			 }

			 System.out.println("Before val::"+b4Val +" val="+val +" lovid="+lovid);
			 System.out.println("value.toString()"+value.toString() +" arraysize="+arraysize);
			 try
			 {
				 if(arraysize<=1 && lovid.equals("99")==false)
				 {
					 if(Integer.parseInt(value.toString())<0)
					 {
						 value=b4Val;
						 System.out.println("Input value does not exist in LOV, so choose value from LOV only");

						 MessageBox.post(mdmdlg.getShell(),"Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);

						 //					 MessageBox msgbox = new MessageBox(parentShell, SWT.ICON_INFORMATION);
						 //			               msgbox.setText("Information.");
						 //			               msgbox.setMessage("Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator ");
						 //			               msgbox.open();            
					 }     

				 }
				 else
				 {
					 System.out.println("skip for non LOV String value ");
				 }
			 } 
			 catch(NumberFormatException e) 
			 { 
				 e.printStackTrace();
			 }

			 System.out.println("Integer.parseInt(lovid)="+Integer.parseInt(lovid));
			 if(Integer.parseInt(lovid)<0)
			 {

				 //if(arraysize<=1)
				 if(arraysize<=0)
				 {
					 String actval=str.get(Integer.parseInt(value.toString()));
					 valchg+=":"+actval;		
					 //((ClassificationTableLine) element).setAttrValue(str.get(Integer.parseInt(value.toString())));
					 ((ClassificationTableLine) element).setNewValue(actval);//.setAttrValue(actval);
					 KeyValueLOV keylov= mdmdlg.keylovList.get(((ClassificationTableLine) element).getLovID());
					 //System.out.println(i+":"+keylov.getValue().get(i)+"GGGGGGKKK:"+keylov.getKey().get(i));
					 ((ClassificationTableLine) element).setChangeValue(keylov.getKey().get(Integer.parseInt(value.toString())));


					 mdmdlg.modifedvalueMap.put(((ClassificationTableLine) element).getAttrID(),((ClassificationTableLine) element).getChangeValue());
				 }

				 //				else if(arraysize>1)
				 //				{
				 //					
				 //					System.out.println("PPPPPPPPPPP1111value.toString()"+value.toString());
				 //					
				 //					((ClassificationTableLine) element).setAttrValue(value.toString());
				 //					valchg+=":"+value;
				 //				}
			 }
			 else
			 {
				 ((ClassificationTableLine) element).setNewValue(value.toString());//.setAttrValue();
				 valchg+=":"+value;
				 System.out.println("valchg="+valchg);
			 }


			 //	((MyModel) element).setAttributevalue("jkjhvghvgh");//value.toString());
			 mdmdlg.modifedactvalueMap.put(id,valchg);

			 System.out.println(((ClassificationTableLine) element).toString());
			 //getViewer().update(element, null);
			 viewer.update(element, null);

		 }


	 }

	 */

	@Override
	protected Object getValue(Object element) {
		// We need to calculate back to the index
		if(element instanceof ClassificationTableLine)
		{
			String val=null;
			if(!valupdatable)
				val=((ClassificationTableLine) element).getAttrValue();
			else
				val=((ClassificationTableLine) element).getNewValue();
			String lovid=((ClassificationTableLine) element).getLovID();
			int arraysize=((ClassificationTableLine) element).getArraySize();
			if(Integer.parseInt(lovid)<0 && arraysize<=1)
			{
				int i;	

				for( i=0;i<str.size();i++)
				{

					System.out.println(str.get(i)+":gfxfsdfsIDX::"+i);
				}


				System.out.println("str.indexOf(val)="+str.indexOf(val));

				boolean match=false;
				for( i=0;i<str.size();i++)
				//for( i=1;i<=str.size();i++)
				{

					if(str.get(i).equals(val))
					{
						match=true;
						break;
					}
				}
				if(match==false)
				{
					i=0;
				}
				System.out.println(val+":IDX::"+i);
				//KeyValueLOV keylov= keylovList.get(((ClassificationTableLine) element).getLovID());
				//((ClassificationTableLine) element).setLovKeyValue(keylov.getKey().get(i));
				return Integer.valueOf(i);
			}


			return val;
		}

		return element;
	}

	@Override
	protected CellEditor getCellEditor(final Object element) {
		if(element instanceof ClassificationTableLine)
		{
			str=new ArrayList<String>();
			String classid=((ClassificationTableLine) element).getParent().getParent().getModuleAddress();
			//String attrid=((ClassificationTableLine) element).getAttrID();
			//String val=((ClassificationTableLine) element).getAttrValue(); //hashed on 11/12/2023
			String attrid=((ClassificationTableLine) element).getAttrID();
			String val=((ClassificationTableLine) element).getNewValue(); //added on 11/12/2023
			String lovid=((ClassificationTableLine) element).getLovID();
			int arraysize=((ClassificationTableLine) element).getArraySize();
			String deptattr=((ClassificationTableLine) element).getDepattr();
			String deptcfg=((ClassificationTableLine) element).getDepattrcfg();
			String deptval=mdmdlg.modifedvalueMap.get(deptattr);
			if(deptval==null)
				deptval=mdmdlg.initialValMap.get(deptattr);
			if(Integer.parseInt(lovid)<0 )
			{
				try {
					//str=new GetKeyLOVs2Sample().testGetKeyLOVs2(lovid);
					final KeyValueLOV keyvallov=	new GetKeyLOVs2Sample().testGetKeyLOVs2(classid,attrid,lovid,deptattr,deptcfg,deptval,arraysize);
					mdmdlg.keylovList.put(lovid, keyvallov);
					str=keyvallov.getValue();

					if(arraysize<=1)
					{


						ComboBoxCellEditor cmbboxeditor=new ComboBoxCellEditor(
								mdmdlg.treeViewer.getTree(), str.toArray(new String[str.size()]),SWT.READ_ONLY);

						final CCombo cmb=(CCombo) cmbboxeditor.getControl();

						cmb.addSelectionListener(new SelectionListener(){

							@Override
							public void widgetSelected(SelectionEvent e) {
								// TODO Auto-generated method stub.
								CCombo cmb1=(CCombo)e.widget;
								((ClassificationTableLine) element).setChangeValue(keyvallov.getKey().get(cmb1.getSelectionIndex()));

							}

							@Override
							public void widgetDefaultSelected(SelectionEvent e) {
								// TODO Auto-generated method stub

							}

						});

						/*	
         		cmbboxeditor.addListener(new ICellEditorListener(){
					    public void applyEditorValue(){
					        Object selection=((IStructuredSelection)treeViewer.getSelection()).getFirstElement();
					        if (selection instanceof ClassificationTableLine) {
					        	ClassificationTableLine ctab=(ClassificationTableLine)selection;

					        }
					    }

						@Override
						public void cancelEditor() {
							// TODO Auto-generated method stub

						}

						@Override
						public void editorValueChanged(
								boolean oldValidState, boolean newValidState) {
							// TODO Auto-generated method stub

						}
         		}

		);*/
						return new ComboBoxCellEditor(
								mdmdlg.treeViewer.getTree(), str.toArray(new String[str.size()]),SWT.READ_ONLY);
					} 

					else
					{
						System.out.println(idx+"::GGG::"+element);
						MultiValueTextCellEditor tce = new MultiValueTextCellEditor(mdmdlg.treeViewer.getTree(),mdmdlg.treeViewer,keyvallov,element,idx) {
							@Override
							public String[] getProposal(String currentText) {


								return str.toArray(new String[str.size()]);
							}
						};
						//tce.getMultiCombo().setTableLine(element);
						//tbv.setCellEditors(new CellEditor[] { tce });
						return tce;//new MultiValueTextCellEditor(treeViewer.getTree());
					}
				}
				catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

			TextCellEditor txtcell=new TextCellEditor(mdmdlg.treeViewer.getTree());
			Text celltxt=((Text)txtcell.getControl());
			celltxt.addModifyListener(new ModifyListener(){



				@Override
				public void modifyText(ModifyEvent e) {
					// TODO Auto-generated method stub
					Text celtxt=(Text) e.widget;
					ClassificationTableLine clselement=((ClassificationTableLine) element);
					clselement.setChangeValue(celtxt.getText());

					System.out.println("MODDDDDDD:"+clselement.getAttrValue()+":>"+clselement.getChangeValue());

				}

			});


			return txtcell;//new TextCellEditor(treeViewer.getTree());

		}

		else
		{
			TextCellEditor txtcell=new TextCellEditor(mdmdlg.treeViewer.getTree());
			Text celltxt=((Text)txtcell.getControl());
			celltxt.addModifyListener(new ModifyListener(){



				@Override
				public void modifyText(ModifyEvent e) {
					// TODO Auto-generated method stub

					ClassificationTableLine clselement=((ClassificationTableLine) element);
					clselement.setChangeValue(clselement.getNewValue());//.getAttrValue(););

				}

			});
			return txtcell;// new TextCellEditor(treeViewer.getTree());

		}


	}


	@Override
	protected boolean canEdit(Object element) {
		System.out.println("in CanEdit isUpdatable="+mdmdlg.isUpdatable);

		if(!valupdatable)
			return valupdatable;


		if(element instanceof ClassificationTableLine)
		{
			ClassificationTableLine tabline=((ClassificationTableLine) element);
			if(mdmdlg.fullexpandable)
			{
				try {
					String parttype=tabline.getParent().getParent().getItemrev().getTCProperty("t5_PartType").getDisplayableValue();
					if(parttype.equals("Module"))
					{
						return false;
					}

				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

			boolean isprotected=tabline.isProtected();

			String attrname=tabline.getAttrName();
			String attrval=tabline.getNewValue();//.getAttrValue();
			System.out.println("attrname="+attrname+ "in CanEdit isprotected="+isprotected);
			if(attrval!=null && attrval.length()!=0)
			{
				if(isprotected)
				{
					return !isprotected;
				}
			}

			/*if(tabline.getArraySize()>0)
					return true;*/
			return mdmdlg.isUpdatable;
		}
		return mdmdlg.isUpdatable;
	}



}

