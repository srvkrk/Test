package com.tml.techspec.dialogs;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

import com.tml.classification.modules.ClassificationAnnotationLine;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.ClassificationTreeLine;



public class LOVSearchViewerFilter extends ViewerFilter {

    private String searchString;

    public void setSearchText(String s) {
        // ensure that the value can be used for matching
        this.searchString = ".*" + s.toLowerCase() + ".*";
    }

    @Override
    public boolean select(Viewer viewer,
            Object parentElement,
            Object element) {
    	System.out.println("inside LOVSearchViewerFilter func call");
        if (searchString == null || searchString.length() == 0) {
            return true;
        }
        if(element instanceof ClassificationTableLine)
        {
        	ClassificationTableLine tabline = (ClassificationTableLine) element;
        	
   		    	
   		       if(tabline.getAttrID().matches(searchString) || tabline.getAttrName().toLowerCase().matches(searchString)||tabline.getLovID().matches(searchString))
   		    	   return true;
        }  
        
       
        return false;
    }

}
