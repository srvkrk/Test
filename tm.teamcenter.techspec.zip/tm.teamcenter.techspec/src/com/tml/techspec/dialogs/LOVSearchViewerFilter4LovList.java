package com.tml.techspec.dialogs;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

import com.tml.classification.modules.ClassificationAnnotationLine;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.ClassificationTreeLine;
import com.tml.classification.modules.ClsKeyLovTableLine;
import com.teamcenter.rac.kernel.ics.ICSKeyLov;
import com.teamcenter.rac.kernel.ics.ICSKeyLov.KeyLov;
import com.teamcenter.rac.kernel.ics.ICSKeyLovValue;


public class LOVSearchViewerFilter4LovList extends ViewerFilter {

    private String searchString;

    public void setSearchText(String s) {
        // ensure that the value can be used for matching
    	System.out.println("inside LOVSearchViewerFilter4LovList with input ="+s);
        this.searchString = ".*" + s.toLowerCase() + ".*";
        System.out.println("inside LOVSearchViewerFilter4LovList with searchString ="+searchString);
        //System.out.println("lovTable:" + lovTable.getlovKey() + ":" + lovTable.getlovVal());
    }

    @Override
    public boolean select(Viewer viewer,Object parentElement,Object element) {
    	System.out.println("inside LOVSearchViewerFilter4LovList func call with element="+element.toString());
        if (searchString == null || searchString.length() == 0) {
            return true;
        }
        if(element instanceof ClsKeyLovTableLine)
        {
        	ClsKeyLovTableLine tabline = (ClsKeyLovTableLine) element;
        	
        	System.out.println(" LOVSearchViewerFilter4LovList func call");
   		       if(tabline.getlovKey().matches(searchString) || tabline.getlovVal().toLowerCase().matches(searchString))
   		    	   return true;
        }  
        
       
        return false;
    }

}
