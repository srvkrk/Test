package com.tml.techspec.dialogs;

import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
//import com.teamcenter.rac.kernel.TCComponentRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.soa.exceptions.NotLoadedException;
//import com.tml.classification.modules.TechSpecUtil;
import com.tml.classification.modules.TechSpecUtil;
import com.tml.techspec.dialogs.ModuleClassificationDialog;

//import tm.teamcenter.regulationproj.dialogs.enginetype.EngineTypeListDialog;

public class CreateArcNodetoPwrTrnRel extends TitleAreaDialog{

	private boolean isOkPressed;
	public Composite area1;
	private Shell parentshell;
	private TCSession session;
	private String SelObjType;
	private TCComponent selectedObj;
	private TCComponent ModuleRev;
	 private String objType;
	 private String PwrTrnModule;
	 private String ModType;
	 private String selecteditem;
	 private String selectedObjtype;	 
	 private String moduleAddress;
	 private String ModAddress;
	 private String modulenum;
	 private String projectCodeS;
	 private String designGroupS;
	 private String roleName;
	 private String ErrMsg;
	 private String userIdS;
	 private String InpModule;
	 private ExecutionEvent mevent;
	protected boolean isUpdatable;
	private Text PwrTrnModuleText;
	private Text ArcModuleText;
	//private int AccessFlag;
	//private int ModuleErrFlag;
	//private Set<String> EngineTypeLst = null;
	//protected EngineTypeListDialog engineTypeLovDlg;
	public CreateArcNodetoPwrTrnRel(Shell parentShell,TCSession session,TCComponent selectedObj,ExecutionEvent m_event) {
		super(parentShell);
		parentShell.setMaximized(true);
		this.session=session;
		
		//this.ccvList=ccvList;
		//this.ItemRev=ItemRev;
		this.selectedObj=selectedObj;
		this.parentshell=parentShell;
		this.mevent=m_event;
		//this.ModAddress=ModAddress;
		//this.modulenum=modulenum;
		this.objType=selectedObj.getType();
		//super(parentShell);
		//super(parentShell);
		setTitle("Architecture Node to Powertrain Module Relation ");
		// TODO Auto-generated constructor stub
		//System.out.println("Inside CreateArcNodetoPwrTrnRel dialog with input Module="+InpModule);
		
		this.setBlockOnOpen(false);
		try {
			selecteditem=selectedObj.getTCProperty("item_id").getDisplayableValue();
			selectedObjtype=selectedObj.getTCProperty("object_type").getDisplayableValue();
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
	}

	
	
	
	protected Control createDialogArea(Composite parent) {
		setTitle("Architecture Node to Powertrain Module Relation");
		TCSession session= (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		GridData gd_container = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		//gd_container.widthHint = 467;
		gd_container.widthHint = 433;
		gd_container.heightHint = 100;
		container.setLayoutData(gd_container);
		container.setTouchEnabled(true);
		container.setLayout(new GridLayout(2, false));
		GridData gd_container1 = new GridData(GridData.FILL_BOTH);
		//gd_container.widthHint = 500;
		gd_container1.widthHint = 200;
		
		Label lblEngineModule = new Label(container, SWT.NONE);
		lblEngineModule.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblEngineModule.setText("Architecture Module");
		
		ArcModuleText = new Text(container, SWT.BORDER);
		GridData gd_ArcModuleText = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gd_ArcModuleText.widthHint = 283;
		ArcModuleText.setLayoutData(gd_ArcModuleText);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		System.out.println("selecteditem="+selecteditem);
		if(!selecteditem.isEmpty())
		{
			ArcModuleText.setText(selecteditem);
		}
		
		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setText("Powertrain Module");
		
		PwrTrnModuleText = new Text(container, SWT.BORDER);
		GridData gd_PwrTrnModuleText = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_PwrTrnModuleText.widthHint = 269;
		PwrTrnModuleText.setLayoutData(gd_PwrTrnModuleText);
//		if(!PwrTrnModule.isEmpty())
//		{
//			//PwrTrnModuleText.setText(PwrTrnModule);
//		}
		
		
		
		area1=area;
		return area;
	}
	@Override
		   protected void okPressed() {
		       // TODO Auto-generated method stub
			//Rajesh
			 // String TechSpecAddress = null;
			// System.out.println("Inside Ok_pressed for Engine Type with EngineTypeValue="+EngineTypeNewText.getText());
			 isOkPressed=true;
	
			 try {
				ModuleRev=QryPart(PwrTrnModuleText.getText());
				modulenum = ModuleRev.getPropertyDisplayableValue("item_id");
				ModAddress = ModuleRev.getProperty("t5_ModuleAddress");
				ModType = ModuleRev.getType();
			} catch (NotLoadedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
				System.out.println("modulenum="+modulenum);
				 
				 System.out.println("ModType="+ModType);
				 
				 System.out.println("ModAddress="+ModAddress);
			// processchassisTypeCre();
			 
			/*
			 * try { //selectedObj.setProperty("t5_EngineType",
			 * EngineTypeNewText.getText()); } catch (TCException e) { // TODO
			 * Auto-generated catch block e.printStackTrace(); }
			 */
//			 System.out.println("2PwrTrnModule="+PwrTrnModuleText.getText().toString() +" " +"selecteditem="+selecteditem);
//			 
//			 System.out.println("INSIDE createButtonsForButtonBar PwrTrnModule="+PwrTrnModuleText.getText().toString() +" " +"selecteditem="+selecteditem);
//				
//			 try {
//				 TCComponent ModuleRev=QryPart(PwrTrnModuleText.getText());
//				modulenum = ModuleRev.getPropertyDisplayableValue("item_id");
//				System.out.println("modulenum="+modulenum);
//				 String ModType = ModuleRev.getType();
//				 System.out.println("ModType="+ModType);
//				 System.out.println("before func createStructure call");
//				//CreateArcNodetoPwrTrnRel.
//				 this.setBlockOnOpen(false);
//				 boolean stat = new TechSpecUtil().invokeDlg(parentshell,session,mevent, ModuleRev);
//				  System.out.println("stat="+stat);
//				  if(stat==true)
//				  {
//				// createStructure(session,selectedObj,ModuleRev,mevent);
//				  }
//				  else 
//				  {
//					  System.out.println("Classification is mandatory for Module's Tech Spec attribute prior to make relation Architecture Node !!");
//					  MessageBox.post(parentshell,"Classification is mandatory for Module's Tech Spec attribute prior to make relation with Architecture Node !","WARNING",SWT.ICON_WARNING); 
//				  }
//				 System.out.println("after func createStructure call");
//			} catch (NotLoadedException | TCException e2) {
//				// TODO Auto-generated catch block
//				e2.printStackTrace();
//			}			
			 
//			 try {
//				 TCComponent ModuleRev=QryPart(PwrTrnModuleText.getText());
//				 modulenum = ModuleRev.getPropertyDisplayableValue("item_id");
//				 System.out.println("modulenum="+modulenum);
//				 String ModType = ModuleRev.getType();
//				 System.out.println("ModType="+ModType);
//				 System.out.println("before func createStructure call");
//				// this.close();
//				 createStructure(session,selectedObj,ModuleRev,mevent);
//				 System.out.println("after func createStructure call");
//				 
//			} catch (NotLoadedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} 
//			 catch (TCException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			 System.out.println("oK_Press call end!!");
			 //MessageBox.post(parentshell,"Engine Type updated successfuly with value="+EngineTypeNewText.getText(),"INFORAMTION",SWT.ICON_WARNING);
			// super.okPressed();
				//return;
		   }
	
	
	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		Button button = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				 System.out.println("2PwrTrnModule="+PwrTrnModuleText.getText().toString() +" " +"selecteditem="+selecteditem);
				 
				 System.out.println("1INSIDE createButtonsForButtonBar PwrTrnModule="+PwrTrnModuleText.getText().toString() +" " +"selecteditem="+selecteditem);
				 System.out.println("2modulenum="+modulenum);
				 System.out.println("3ModAddress="+ModAddress);
				 
				 //String ModType =
				/*
				 * try { // ModuleRev=QryPart(PwrTrnModuleText.getText()); //modulenum =
				 * ModuleRev.getPropertyDisplayableValue("item_id");
				 * System.out.println("modulenum="+modulenum); //String ModType =
				 * ModuleRev.getType(); System.out.println("ModType="+ModType); //ModAddress =
				 * ModuleRev.getProperty("t5_ModuleAddress");
				 * System.out.println("ModAddress="+ModAddress);
				 * System.out.println("before func createStructure call");
				 * //CreateArcNodetoPwrTrnRel.mo //this.setBlockOnOpen(false);
				 * 
				 * System.out.println("after func createStructure call"); } catch
				 * (NotLoadedException | TCException e2) { // TODO Auto-generated catch block
				 * e2.printStackTrace(); }
				 */		
				
				 try {
						ModuleRev=QryPart(PwrTrnModuleText.getText());
						modulenum = ModuleRev.getPropertyDisplayableValue("item_id");
						ModAddress = ModuleRev.getProperty("t5_ModuleAddress");
						ModType = ModuleRev.getType();
					} catch (NotLoadedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (TCException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				 System.out.println("11modulenum="+modulenum);
				 
				 System.out.println("11ModType="+ModType);
				 
				 System.out.println("11ModAddress="+ModAddress);
				 Job job = new Job("update Tech Spec dialog .....") { boolean errFlag = false; protected IStatus run(IProgressMonitor monitor) {
				 // TODO Auto-generated method stub
				 
					 try
					 {
						 if(ModuleRev instanceof TCComponentItemRevision )
						    {
							    	System.out.println("Allowed this option");
							    	TCComponent selectedObj1 = (TCComponent) ModuleRev;// selectedobject.getComponent();	
							    	
							    	;
							    	String ArcModAddress;
									try {
										
										ArcModAddress=selectedObj.getProperty("t5_ArchModuleAddress");
										
										 System.out.println("going to call ModuleClassificationDialog with ModAddress="+ModAddress +"modulenum="+modulenum + "ArcModule="+ArcModAddress);
										if(ArcModAddress.equalsIgnoreCase(ModAddress))
										{		  
										  if(ModAddress.contains("P") )
										  {
											  System.out.println("inside calling TechSpecUtil ");
											  boolean stat = new TechSpecUtil().invokeDlg(new Shell(),session,mevent, selectedObj1,null);
											 
											  System.out.println("stat="+stat);
											  if(stat==true)
											  {
											// createStructure(session,selectedObj,ModuleRev,mevent);
											 
											 System.out.println("Structure created successfully between Arc Module= "+selectedObj.getProperty("item_id") + "and Powertrain Module ="+modulenum);
											  MessageBox.post(parentshell,"Structure created successfully between Arc Module and Powertrain module !","WARNING",SWT.ICON_INFORMATION);
											 
											  }
											  else 
											  {
												  System.out.println("Classification is mandatory for Module's Tech Spec attribute prior to make relation Architecture Node !!");
												  MessageBox.post(parentshell,"Classification is mandatory for Module's Tech Spec attribute prior to make relation with Architecture Node !","WARNING",SWT.ICON_WARNING); 
											  }
//											  boolean stat = new TechSpecUtil().invokeDlg(parentshell,session,event, selectedObj);
//											  System.out.println("stat="+stat);
//											    TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
//												TCComponentBOMWindow bomWin = bowWinType.create(currentrevrule);	// create bom window configured with the default revision rule 
//												TCComponentBOMLine bl= bomWin.setWindowTopLine(null, (TCComponentItemRevision) assemblyRevision,null, null);
//												bl.addBOMLine(bl, selectedObj, null);
										  }
										  else 
										  {
											  System.out.println("no Powertrain module found in child for create relation with arhictecture node, so this option is not valid except Powertrain Module Relation !!");
											  MessageBox.post(parentshell,"Powertrain Module relation with Arch Module only allowed by this option!","WARNING",SWT.ICON_WARNING);
										  }
										  
										}
										else 
										  {
											  System.out.println("Module's Address & Arch module's address is diffrent !!");
											  MessageBox.post(parentshell,"Mismatch Module Address between Powertrain Module and Architecture Module !","WARNING",SWT.ICON_WARNING);
										  }
										   
									} catch (TCException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
							    	 
							    	 // Rajesh // String ModuleAddress = null;
									 
									  //AbstractAIFUIApplication app1 = AIFUtility.getCurrentApplication();
									 // ModuleClassificationDialog mcd = new  ModuleClassificationDialog (parentshell,ModAddress,modulenum + "/NR;1",modulenum, "Module",session); 
									//  mcd.open();
									  
									  // End
							    	//
						 
						    }
						    else
						    {
						    	System.out.println("part Type is not VC/Vehicle/Module, option only valid for Vehicle/Module");
								
						    	MessageBox.post(parentshell,"Part Type VC/Vehicle/Module Revision only allowed for this option!","WARNING",SWT.ICON_WARNING);
						    	
								/* MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
						               messageBox1.setText("Information.");
						               messageBox1.setMessage("Part Type Vehicle/Module Revision only allowed for this option ");
						               messageBox1.open(); */ 
						               
						               //return ;
						    }
					 }
					 catch (Exception e)
					 {}
					
				 finally{
				 Display.getDefault().asyncExec(new Runnable() {
				 public void run() {
				 //if(!errFlag)MessageBox.post("ESO Status object created successfully and related to the selected part " , "", "Create ESO Status", MessageBox.INFORMATION);
				 }
				 });
				 }
				 return Status.OK_STATUS;
				 }
				 };
				 job.setUser(false);
				 job.schedule();
				 
				 
				
				
				
				
//				 System.out.println("INSIDE createButtonsForButtonBar PwrTrnModule="+PwrTrnModuleText.getText().toString() +" " +"selecteditem="+selecteditem);
//					
//					 try {
//						 TCComponent ModuleRev=QryPart(PwrTrnModuleText.getText());
//						modulenum = ModuleRev.getPropertyDisplayableValue("item_id");
//						System.out.println("modulenum="+modulenum);
//						 String ModType = ModuleRev.getType();
//						 System.out.println("ModType="+ModType);
//						 System.out.println("before func createStructure call");
//						// CreateArcNodetoPwrTrnRel.setBlockOnOpen(false);
//						 boolean stat = new TechSpecUtil().invokeDlg(parentshell,session,mevent, ModuleRev);
//						  System.out.println("stat="+stat);
//						  if(stat==true)
//						  {
//						// createStructure(session,selectedObj,ModuleRev,mevent);
//						  }
//						  else 
//						  {
//							  System.out.println("Classification is mandatory for Module's Tech Spec attribute prior to make relation Architecture Node !!");
//							  MessageBox.post(parentshell,"Classification is mandatory for Module's Tech Spec attribute prior to make relation with Architecture Node !","WARNING",SWT.ICON_WARNING); 
//						  }
//						 System.out.println("after func createStructure call");
//					} catch (NotLoadedException | TCException e2) {
//						// TODO Auto-generated catch block
//						e2.printStackTrace();
//					}
//					 
					 
				//parentshell.dispose();
				//getShell().dispose(); 
			}
			
		});
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
	}
	
	@SuppressWarnings("deprecation")
	public void createStructure(TCSession tcsession,TCComponent assemblyRevision,TCComponent childRev,ExecutionEvent event) throws TCException
	{

		
		//IWorkbenchWindow window;
		Shell shell ;
		TCComponent[] bvr = assemblyRevision.getRelatedComponents("structure_revisions");// get bvrs
		
		
		System.out.println("Listing All Revision Rule");
		
		TCComponentRevisionRule[] revrule=TCComponentRevisionRule.listAllRules(tcsession);
		//String revrulename="EBOM_Upload_View";
		//String revrulename="ERC release and above";
		String revrulename=null;
		try {
			revrulename = new TechSpecUtil().gettechspecrevrule("techspecrevrule");
		} catch (NotLoadedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("output revrulename="+revrulename);
		if(revrulename==null)
		{
			 revrulename="ERC release and above";
		}
		TCComponentRevisionRule currentrevrule=null;
		for(int j=0;j<revrule.length;j++)
		{
			
			if(revrulename.equals(revrule[j].getProperty("object_name")))
			{
				currentrevrule=revrule[j];
					break;
			}
			
			//System.out.println(revrulename);
			
		}
		
		System.out.println("Found the Revision Rule "+currentrevrule);
		
		System.out.println("before BOM Create with child="+childRev.getProperty("item_id"));
		TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
		TCComponentBOMWindow bomWin = bowWinType.create(currentrevrule);	// create bom window configured with the default revision rule 
		TCComponentBOMLine bl= bomWin.setWindowTopLine(null, (TCComponentItemRevision) assemblyRevision,null, null);
		bl.addBOMLine(bl, childRev, null);
		bl.save();
		 
		
		

		System.out.println("=========================================END TCUA  BOM Create=======");

		
		
		
		return ;

	}
	
	public static TCComponent []  queryObjInTCUA(String queryname,String [] qryNames,String [] qryValues) throws TCException
	{

		
		TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		
		com.teamcenter.rac.kernel.TCComponentContextList imancomponentcontextlist = null;
		

		TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");

		TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);

		TCComponent []qryResults	= null;
		
		


		if (mmcomponentquery != null)

		{
			System.out.println(" In Query for qryValues ::"+qryValues[0]);
			System.out.println(" In Query for qryNames ::"+qryNames[0]);
			
			qryResults=(TCComponent[]) mmcomponentquery.execute( qryNames, qryValues );

			
		}
		return qryResults;

	}
	
	
	public static TCComponent QryPart(String PartNo) throws NotLoadedException, TCException
	{
		//MDM
		//VCATTR
		String [] qryNames={"Item ID"};
		String [] qryValues={PartNo};
		int r;
		TCComponent[] objvec=queryObjInTCUA("Item Revision...", qryNames,qryValues);
		TCComponent RetPartObj=null;
		if(objvec!=null)
		{
			for(int f=0;f<objvec.length;f++)
			{
				//RetPartObj=( objvec[f].getTCProperty("revision_list").getReferenceValue());
				
				RetPartObj=objvec[f];
					
				
				
				//RetPartObj=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
		
			}
		}
		
		return RetPartObj;
	}
	
	//public class EngineTypeListDialog extends Dialog {}
	
	

	


}
