package com.tml.classification.modules;

import java.util.ArrayList;

import com.teamcenter.rac.kernel.ics.ICSKeyLov;

public class KeyValueLOV {
	
	private int lovid;
	private ArrayList<String> key;
	private ArrayList<String> value;
	private ICSKeyLov keylov;
	
	public KeyValueLOV(int lovid, ICSKeyLov keylov2)
	{
		this.lovid=lovid;
	}
	
	public int getLovid() {
		return lovid;
	}
	public void setLovid(int lovid) {
		this.lovid = lovid;
	}
	public ICSKeyLov getKeylov() {
		return keylov;
	}
	public void setKeylov(ICSKeyLov keylov) {
		this.keylov = keylov;
	}

	public ArrayList<String> getKey() {
		return key;
	}

	public void setKey(ArrayList<String> key) {
		this.key = key;
	}

	public ArrayList<String> getValue() {
		return value;
	}

	public void setValue(ArrayList<String> value) {
		this.value = value;
	}
	
	

}
