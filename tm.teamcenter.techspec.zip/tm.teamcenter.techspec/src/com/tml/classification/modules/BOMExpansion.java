package com.tml.classification.modules;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.StringTokenizer;

import org.eclipse.swt.SWT;



import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.structuremanagement._2011_06.Structure.ClosureRuleVariableInfo;
import com.teamcenter.soa.exceptions.NotLoadedException;



public class BOMExpansion {


	private HashMap<String,TCComponentItemRevision> class_not_found;
	private HashMap<String,LinkedHashSet<String>> expansion_address;
	
	private LinkedHashSet<String> expansionupto;
	private String modClsname =null;
	public BOMExpansion() {
		super();
		class_not_found=new HashMap<String,TCComponentItemRevision>();
		try {
			expansion_address=populateExpansionAddress();
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}


	public ClassificationObject getClassificationObject(TCComponentItemRevision assemblyRevision,String SelBusUnit)
	{

		
		TCComponentItem tc_ico_item=null;
		try {
			tc_ico_item=assemblyRevision.getItem();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println(" inside getClassificationObject TSBusiUnit:-"+SelBusUnit);
		GetClassifiedAttr getProps= new GetClassifiedAttr(tc_ico_item,assemblyRevision.getSession(),SelBusUnit);

		ClassificationObject clsobjs=null;

		System.out.println("inside getClassificationObject BOM Expansion TSBusiUnit:-"+modClsname);
		ICOValues icoval;
		try {
			//icoval = getProps.getICOProps(modClsname);
			//icoval = getProps.getICOProps();
			icoval = getProps.getICOProps1(SelBusUnit);

			if(icoval != null)
			{
				/*	ModuleAddress=icoval.getCid();
					ObjectID=icoval.getIcoId();
					childrevDispStr=assemblyRevision.toDisplayString();*/

				clsobjs=icoval.getClsobjs();					

			}
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clsobjs;

	}
	// Classification Attribute/Value for a assemblyRevision
	public ClassificationTreeLine setclsValues(TCComponentItemRevision assemblyRevision,TCSession tcsession,String SelVehTSBusUnit,boolean Hybridstatus) throws TCException
	{

		System.out.println("inside the   fun setclsValues= "+assemblyRevision.toDisplayString() +" SelVehTSBusUnit="+SelVehTSBusUnit); 
		
		TCComponentItem tc_ico_item=null;
		try {
			tc_ico_item=assemblyRevision.getItem();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		GetClassifiedAttr getProps= new GetClassifiedAttr(tc_ico_item,tcsession,SelVehTSBusUnit);
		ClassificationTreeLine treeline=null;
		String ModuleAddress=null;
		String ObjectID=null;
		String childrevDispStr=null;
		String SelectedObjType=null;
		String BuinessUnit = null;
		String itemID=null;
		String revid=null;
		ClassificationObject clsobjs=null;
		String projcode=null;
		String childparttype=null;
		ICOValues icoval=null;
		//String modClsname =null;
		//boolean Hybridstatus=false;
		childparttype=assemblyRevision.getTCProperty("t5_PartType").getDisplayableValue();
		System.out.println("in setclsValues func 1childparttype:-"+childparttype);
		try {
			//ICOValues icoval=getProps.getICOProps(SelVehTSBusUnit);
			//ICOValues icoval=getProps.getICOProps();
			if(childparttype.equals("Vehicle") || childparttype.equals("Vehicle Combination") || childparttype.equals("Configurable VC")|| childparttype.equals("Vehicle Combination CR"))
			{

				//Hybridstatus=new TechSpecUtil().getHybridVCFlag(tcsession,assemblyRevision);
				System.out.println("inside BOMExpansion Hybrid status  "+Hybridstatus);
				if(Hybridstatus==true)
				{
					String tmpmodAdr=SelVehTSBusUnit+"HBRDVCATTR01";
					icoval=getProps.getICOPropsHYBRD(tmpmodAdr);
				}
				else
				{
					System.out.println("inside BOMExpansion non-Hybrid status  "+Hybridstatus);
					icoval=getProps.getICOProps1(SelVehTSBusUnit);
				}
				
			}
			else
			{
				icoval=getProps.getICOProps1(SelVehTSBusUnit);
			}
	
			//ICOValues icoval=getProps.getICOProps1(SelVehTSBusUnit);
			if(icoval != null)
			{
				ModuleAddress=icoval.getCid();
				ObjectID=icoval.getIcoId();
				childrevDispStr=assemblyRevision.toDisplayString();
				clsobjs=icoval.getClsobjs();					

			}
			else
			{

				try {
					SelectedObjType = assemblyRevision.getPropertyDisplayableValue("t5_PartType");
					System.out.println("SelectedObjType:-"+SelectedObjType);
					//date:-04/04/2019 
					//if(SelectedObjType.equals("Vehicle") )
					if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Vehicle Combination") || SelectedObjType.equals("Configurable VC")|| SelectedObjType.equals("Vehicle Combination CR"))
					{
						TCComponent[] TechSpecObj=  assemblyRevision.getTCProperty("T5_VCSpec").getReferenceValueArray();
						if(TechSpecObj!=null && TechSpecObj.length>0)
						{
							//New Hybrid Vc logic 
							//TCSession tcsession
							//boolean Hybridstatus1=new TechSpecUtil().getHybridVCFlag(tcsession,assemblyRevision);
							System.out.println("Hybrid status2  "+Hybridstatus);
							if(Hybridstatus==true)
							{
								System.out.println("BuinessUnit:----------  "+BuinessUnit);
								itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
								System.out.println("inside Hybrid VC process :----------  "+itemID);
								ModuleAddress=SelVehTSBusUnit+"HBRDVCATTR01";
								//itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
								revid=assemblyRevision.getPropertyDisplayableValue("item_revision_id");
								ObjectID=itemID;//+"/"+revid;
								childrevDispStr=assemblyRevision.toDisplayString();
							}
							else
							{
							BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
							System.out.println("BuinessUnit:----------  "+BuinessUnit);
							ModuleAddress=BuinessUnit+"VCATTR01";
							itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
							revid=assemblyRevision.getPropertyDisplayableValue("item_revision_id");
							ObjectID=itemID;//+"/"+revid;
							childrevDispStr=assemblyRevision.toDisplayString();
							}
						}



					}
					else
						//if(SelectedObjType.equals("Vehicle") )
					{
						//TCComponent[] TechSpecObj=  assemblyRevision.getTCProperty("T5_VCSpec").getReferenceValueArray();

						//BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
						//System.out.println("BuinessUnit:----------  "+BuinessUnit);
						ModuleAddress=assemblyRevision.getPropertyDisplayableValue("t5_ModuleAddress");
						System.out.println("ModuleAddress:----------  "+ModuleAddress);
						itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
						revid=assemblyRevision.getPropertyDisplayableValue("item_revision_id");
						ObjectID=itemID;//+"/"+revid;
						childrevDispStr=assemblyRevision.toDisplayString();
						
						projcode=itemID.substring(0, 4);
						//System.out.println("module's projcode:----------  "+projcode);
//			    		 try {
//							childparttype=assemblyRevision.getTCProperty("t5_PartType").getDisplayableValue();
//						} catch (TCException e3) {
//							// TODO Auto-generated catch block
//							e3.printStackTrace();
//						}
			    		//System.out.println("inside BOMExpansion child projcode="+projcode +"modaddress="+ModuleAddress +"childparttype="+childparttype );



					}
				} catch (NotLoadedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			
			
			System.out.println("in BOMExpansion b4 call getClsNmaeForModuleAdd projcode="+projcode +"modaddress="+ModuleAddress +"childparttype="+childparttype +" SelVehTSBusUnit="+SelVehTSBusUnit );
			try {
				if(SelVehTSBusUnit==null)
				{
				 modClsname = TechSpecUtil.getClsNmaeForModuleAdd(projcode,ModuleAddress);
				}
				else if(SelVehTSBusUnit.equals("CAR"))
				{
					modClsname=ModuleAddress;
				}				
				else if(ModuleAddress.contains(SelVehTSBusUnit))
				{
					modClsname=ModuleAddress;
				}
				else
				{
					System.out.println("in BOMExpansion SelVehTSBusUnit is not CAR="+SelVehTSBusUnit +" ModuleAddress="+ModuleAddress );
					String tmpModClsname=null;
					if((SelVehTSBusUnit.length()>6) && (SelVehTSBusUnit.contains(ModuleAddress)))
					//if(SelVehTSBusUnit.contains(ModuleAddress))
					{
						//System.out.println("module address found in SelVehTSBusUnit");
					 tmpModClsname=SelVehTSBusUnit;
					}
					else
					{
						//System.out.println("module address not found in SelVehTSBusUnit");
						 tmpModClsname=SelVehTSBusUnit+ModuleAddress;
					}
					System.out.println("in BOMExpansion tmpModClsname="+tmpModClsname );
					  if(ModuleAddress.contains(SelVehTSBusUnit) || (ModuleAddress.length()>6))
					  {						  
					  modClsname=ModuleAddress; 
					  }
					  else
					  {
						  System.out.println("inside condition no BusinessUnitSuffix on module address tmpModClsname="+tmpModClsname );
						  modClsname=tmpModClsname; 
					  }
					 
				}
					
			} catch (NotLoadedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("in BOMExpansion after call getClsNmaeForModuleAdd modClsname="+modClsname );
			boolean modaddallwflg;
			
			if(SelVehTSBusUnit==null)
			 {
				 modaddallwflg=true;
			 }
			
			else if(SelVehTSBusUnit.contains("CAR"))
			{
				if(modClsname.length()>=6)
				{
					System.out.println("in BOMExpansion after getting final modClsname="+modClsname +" then allow to proceed !!" );
					modaddallwflg=true;
				}
				else
				{
					System.out.println("do not proceed ahead as SelVehTSBusUnit is CAR but module address having prefix");
					modaddallwflg=false;
				}
			}
			else
			{
				
				 if(modClsname.contains(SelVehTSBusUnit))
				 {
					 modaddallwflg=true;
				 }
				 else
				 {
					 modaddallwflg=false;
				 }
			}
			System.out.println(" modaddallwflg= "+modaddallwflg);
			if(modaddallwflg==true)
			{
				if(childparttype!=null)
				{
					if(childparttype.equals("Module"))
					{
						String classdesc = new GetClassDescriptions().getClassDesc(tcsession,modClsname);
						System.out.println("in BOMExpansion newModuleAddress-  "+modClsname +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
						treeline =new ClassificationTreeLine(childrevDispStr, modClsname,ObjectID,assemblyRevision,clsobjs,classdesc);
					}
					else
					{
						String classdesc = new GetClassDescriptions().getClassDesc(tcsession,ModuleAddress);
						System.out.println("2 in BOMExpansion ModuleAddress-  "+ModuleAddress +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
						treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,assemblyRevision,clsobjs,classdesc);
					}
				}
				else
				{
					//if(assemblyRevision.)
					String PartType=assemblyRevision.getTCProperty("t5_PartType").getDisplayableValue();

					if(PartType.equals("Vehicle") || PartType.equals("Configurable VC") || PartType.equals("Vehicle Combination CR"))
					{
						String classdesc = new GetClassDescriptions().getClassDesc(tcsession,ModuleAddress);
						System.out.println("3 in BOMExpansion ModuleAddress-  "+ModuleAddress +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
						treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,assemblyRevision,clsobjs,classdesc);
					}
					else
					{
						String classdesc = new GetClassDescriptions().getClassDesc(tcsession,modClsname);
						System.out.println("4 in BOMExpansion ModuleAddress-  "+modClsname +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
						treeline =new ClassificationTreeLine(childrevDispStr, modClsname,ObjectID,assemblyRevision,clsobjs,classdesc);
					}
				}

			}
//			String classdesc = new GetClassDescriptions().getClassDesc(tcsession,ModuleAddress);
//			System.out.println("ModuleAddress-  "+ModuleAddress +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
//			treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,assemblyRevision,clsobjs,classdesc);
			//ClassifyList.add(treeline);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			////////////	MessageBox.post(PlatformHelper.getCurrentShell(),e.getMessage(),"ERROR",SWT.ICON_ERROR);

			
			//class_not_found.put("Classification "+ ModuleAddress + " Not Found ",assemblyRevision);
			if(childparttype!=null)
			{
				if(childparttype.equals("Module"))
			  	{
					class_not_found.put("Classification "+ modClsname + " Not Found ",assemblyRevision);
			  	}
			}
			else
			{
				class_not_found.put("Classification "+ ModuleAddress + " Not Found ",assemblyRevision);
			}
			e.printStackTrace();
		}

		return treeline;

	}
	
	HashMap<String,LinkedHashSet<String>> populateExpansionAddress() throws TCException
	{
		
		HashMap<String,LinkedHashSet<String>> exp_addr=new HashMap<String,LinkedHashSet<String>>();
		
		
		
String infostr="";
		
		
		String [] qryNames={"SYSCD","SUBSYSCD"};
		String [] qryValues={"ICOEXPLIST","TECHSPEC"};
		int r;
		TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
		Object info=null;
		if(objvec!=null)
		{
			for(int f=0;f<objvec.length;f++)
			{
				TCComponent objcntrl=objvec[f];
				
				
					
				String[] infoattr=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_Userinfo10"};
				
				int len=infoattr.length;
				
				for(r=0;r<len;r++)
				{
				
				 info=objcntrl.getTCProperty(infoattr[r]);
				
				if(info==null) continue;
				if(info!=null)
					infostr+=info.toString()+",";	
							
				
				
				}
				
				
				
				StringTokenizer stkinfostr=new StringTokenizer(infostr,",");
				
					while(stkinfostr.hasMoreElements())
				{
					
					String attrs=stkinfostr.nextToken();
					String[] attrs1=attrs.split(":");
					
					LinkedHashSet<String> attrlist=new LinkedHashSet<String>();
					
					if(attrs1[1].contains("+"))
					{
						String[] attrs2=attrs1[1].split("+");
						
						for (int y=0;y<attrs2.length;y++)
							attrlist.add(attrs2[y]);
						
					}
					else
					{
						
						attrlist.add(attrs1[1]);
					}
					
					exp_addr.put(attrs1[0],attrlist);
					
					
				}
					
			
			}
		}
		
		
		
		return exp_addr ;
	}

	// Get Structure from Snapshot Attached to CCV  under T5_PartHasSnapShot
	public ArrayList<ClassificationTreeLine> getTCUAStructureSnapshot(TCSession tcsession,TCComponentItemRevision assemblyRevision,boolean fullexpandable,String SelVehTSBusUnit,boolean Hybridstatus) throws TCException, NotLoadedException
	{

		//     TCComponentItemRevision assemblyRevision=(TCComponentItemRevision)assemblyRevision1;
		ArrayList<TCComponentItemRevision> allbomlist=new ArrayList<TCComponentItemRevision>();
		ArrayList<ClassificationTreeLine> ClassifyList=new  ArrayList<ClassificationTreeLine>();
		ClassificationTreeLine clsval=setclsValues(assemblyRevision,tcsession,SelVehTSBusUnit,Hybridstatus);
		String IcoClsID;
		ArrayList<String> clsset=null;
		ClassificationHiearchyClasses hie_cls=new ClassificationHiearchyClasses();
		//ArrayList<String> clsset=hie_cls.getClsHiearchy("ICM010102");
		//ArrayList<String> clsset=hie_cls.getClsHiearchy("ICM0101"); //need to unhash after below test
		String InpParttype=assemblyRevision.getPropertyDisplayableValue("t5_PartType");
		System.out.println("getTCUAStructureSnapshot InpParttype ::"+InpParttype);
		if(InpParttype.equals("Vehicle") || InpParttype.equals("Vehicle Combination") || InpParttype.equals("Configurable VC")|| InpParttype.equals("Vehicle Combination CR"))
		{
			if(Hybridstatus==true)
			{
				IcoClsID=SelVehTSBusUnit+"HBRDVCATTR01";
				clsset=hie_cls.getClsHiearchy(IcoClsID); // for TPL/HYBRID
			}
			else
			{
				IcoClsID=SelVehTSBusUnit+"VCATTR01";
				//clsset=hie_cls.getClsHiearchy("ICM0101");
				clsset=hie_cls.getClsHiearchy(IcoClsID);
			}
		}
		else
		{
		
			if(InpParttype.equals("Module"))
			{
				String mAddress=assemblyRevision.getPropertyDisplayableValue("t5_ModuleAddress");
				System.out.println(" mAddress::"+mAddress);
				if(SelVehTSBusUnit.contains("CAR"))
				{
					if(mAddress.length()>0)
					{
						clsset=hie_cls.getClsHiearchy(mAddress);
					}
				}
				else
				{
					IcoClsID=SelVehTSBusUnit+mAddress;
					System.out.println(" for module IcoClsID::"+IcoClsID);
					if(IcoClsID.length()>0)
					{
						clsset=hie_cls.getClsHiearchy(IcoClsID);
					}
				}
			}
		}
		System.out.println("getTCUAStructureSnapshot clsval::"+clsval.toString() +" SelVehTSBusUnit="+SelVehTSBusUnit);
		
		if(clsval!=null)
			ClassifyList.add(clsval);
		
		
		if(InpParttype.equals("Vehicle") || InpParttype.equals("Vehicle Combination") || InpParttype.equals("Configurable VC")|| InpParttype.equals("Vehicle Combination CR"))
		{
			//boolean Hybridstatus=new TechSpecUtil().getHybridVCFlag(tcsession,(TCComponentItemRevision) assemblyRevision);
			
			System.out.println("inside getTCUAStructureSnapshot Hybrid status  "+Hybridstatus);
			if(Hybridstatus==true)
			{
				return ClassifyList;
			}
		}
		TCComponent[] snapshot = assemblyRevision.getTCProperty("T5_PartHasSnapShot").getReferenceValueArray();// get bvrs
		System.out.println("snapshot="+snapshot );
		if(snapshot!=null && snapshot.length>0)
		{

			TCComponent snapshotdata=snapshot[0];

			TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
			TCComponentBOMWindow bomWin = bowWinType.create(snapshotdata);       // create bom window from snapshot
		
			System.out.println("bomWin= "+bomWin  );

			System.out.println("snapshotdata="+snapshotdata  );
			
			
			 ClosureRuleVariableInfo[] crVarInfos = new ClosureRuleVariableInfo[1];


		  		crVarInfos[0] = new ClosureRuleVariableInfo();


		  		crVarInfos[0].name = ""; 


		  		crVarInfos[0].value = "";

		  		//String closureRuleName="BOMLineskipforunconfigured";
		  		String closureRuleName="BOMLineSkipZeroQtyMaskUnconfig";
		  		
		  		//bomWin.setClosureRuleName(closureRuleName);
		  		//bomWin.setClosureRule(clrule);
		  		
		  		//Structure.ClosureRuleVariableInfo   clvar=new Structure.ClosureRuleVariableInfo();
		  		//HashMap localHashMap = new HashMap();
		  		//  localHashMap.put(clvar.name, clvar.value);
		  		//  System.out.println("localHashMap="+localHashMap);
		  		//bomWin.setClosureRuleUserEntriesMap(localHashMap) ;

		  		
		  		com.teamcenter.services.rac.structuremanagement.StructureService  structureService=com.teamcenter.services.rac.structuremanagement.StructureService.getService(tcsession);
		  						structureService.setClosureRuleVariablesAndValues(bomWin, closureRuleName, crVarInfos);




			TCComponentBOMLine bl=   bomWin.getTopBOMLine();
			System.out.println("New bl ="+bl  );
			int bomsize=0;
			 bomsize=bl.getChildren().length;

			System.out.println("b4 call fun ppassemblyRevision= "+assemblyRevision.toDisplayString() +" bomsize=" +bomsize); 
			
			if (bl.hasChildren()){

				AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

				//TCComponentBOMLine[] childContext =bl.getPackedLines();
				System.out.println("BOM Children count is "+childContext.length);

				System.out.println("=======================Listing Children=============");
				for(int i = 0; i < childContext.length; i++){
					//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
					TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
					TCComponentItem item = child.getItem();
					TCComponentItemRevision childItemrev=child.getItemRevision();

					String itemidval=item.getTCProperty("item_id").getDisplayableValue();
					System.out.println("itemidval:::"+itemidval);
					int itemidlength=itemidval.length();
					System.out.println("itemidlength:::"+itemidlength);
					int Begindx=itemidlength-6;
					System.out.println("Begindx:::"+Begindx);
					String Platform=itemidval.substring(Begindx);
					System.out.println(" Platform"+Platform);

					System.out.println("22Platform:----------  "+Platform +" SelVehTSBusUnit="+SelVehTSBusUnit);
					if(SelVehTSBusUnit!=null)
					{
					if(SelVehTSBusUnit.contains("CAR"))
					{
						System.out.println("No Prefix required for Module address:----------  \n"+Platform);
					}
					else
					{
						if(Platform.length()<=6 )
						{
						System.out.println(" Prefix required for Module address:----------  for module fetch"+Platform);
						Platform=SelVehTSBusUnit+Platform;
						}
						else
						{
							if(Platform.contains(SelVehTSBusUnit))
							{
							System.out.println("No Prefix required for Module address:---------- because it has already prefix \n"+Platform);
							}
							else
							{
								System.out.println(" module address > 6 & Prefix not available for passed SelVehTSBusUnit , required for Module address:----------  for module fetch"+Platform);
								Platform=SelVehTSBusUnit+Platform;
							}
						}
						
					}
					}
					System.out.println(" final Platform Module address:----------  for module fetch"+Platform);
					if(clsset.contains(Platform))
					{
						System.out.println("33Platform:----------  "+Platform +"child="+child);
						ArrayList<TCComponentItemRevision> bomlist=getTCUAStructureInt(child);
						System.out.println("bomlist:----------  "+bomlist );
						allbomlist.addAll(bomlist);
			
					}
				}

				System.out.println("====================END of Listing Children=============");
			}
			
			System.out.println("getTCUAStructureSnapshot Hybridstatus="+Hybridstatus);
			for(int x=0;x<allbomlist.size();x++)
			{
				TCComponentItemRevision moduleRevision=allbomlist.get(x);
				System.out.println(" allbomlist::"+moduleRevision);
				String mAddress=moduleRevision.getPropertyDisplayableValue("t5_ModuleAddress");
				System.out.println(" mAddress::"+mAddress);
				if(mAddress==null || mAddress.length()<=0)
					continue;
				ClassificationTreeLine clstree= setclsValues(moduleRevision,tcsession,SelVehTSBusUnit,Hybridstatus);
				//System.out.println(" clstree::"+clstree);
				if(clstree!=null)
				{
					ClassifyList.add(clstree);
				}

			}
		}
		return ClassifyList;
	}

	// Get Structure Under VC/Vehicle :-> Normal BOM Expansion
	public ArrayList<ClassificationTreeLine> getTCUAStructure(TCSession tcsession,TCComponentItemRevision assemblyRevision,boolean fullexpandable,String SelVehTSBusUnit,boolean Hybridstatus) throws TCException, NotLoadedException
	{

		//     TCComponentItemRevision assemblyRevision=(TCComponentItemRevision)assemblyRevision1;
		ArrayList<ClassificationTreeLine> ClassifyList=new  ArrayList<ClassificationTreeLine>();
		System.out.println("inside getTCUAStructure SelVehTSBusUnit="+SelVehTSBusUnit +"  Hybridstatus="+Hybridstatus);
		
		ClassificationTreeLine clsval=setclsValues(assemblyRevision,tcsession,SelVehTSBusUnit,Hybridstatus);
		if(clsval!=null)
			ClassifyList.add(clsval);
		System.out.println("inside getTCUAStructure fullexpandable="+fullexpandable +" clsval="+clsval);

		if(!fullexpandable )
			return ClassifyList;

		
		String InpParttype=assemblyRevision.getPropertyDisplayableValue("t5_PartType");
		System.out.println("getTCUAStructure InpParttype ::"+InpParttype);
		
		if(InpParttype.equals("Vehicle") || InpParttype.equals("Vehicle Combination") || InpParttype.equals("Configurable VC")|| InpParttype.equals("Vehicle Combination CR"))
		{
			//boolean Hybridstatus=new TechSpecUtil().getHybridVCFlag(tcsession,(TCComponentItemRevision) assemblyRevision);
			System.out.println("inside getTCUAStructure Hybrid status  "+Hybridstatus);
			if(Hybridstatus==true)
			{
				return ClassifyList;
			}
		}
		
		TCComponent[] bvr = assemblyRevision.getRelatedComponents("structure_revisions");// get bvrs



		System.out.println("Listing All Revision Rule");

		TCComponentRevisionRule[] revrule=TCComponentRevisionRule.listAllRules(tcsession);
		//String revrulename="Latest Working";
		//String revrulename="ERC release and above";
		
		String revrulename=new TechSpecUtil().gettechspecrevrule("techspecrevrule");
		System.out.println("output revrulename="+revrulename);
		if(revrulename==null)
		{
			 revrulename="ERC release and above";
		}
		TCComponentRevisionRule currentrevrule=null;
		for(int j=0;j<revrule.length;j++)
		{

			if(revrulename.equals(revrule[j].getProperty("object_name")))
			{
				currentrevrule=revrule[j];
				break;
			}

			//System.out.println(revrulename);

		}

		System.out.println("Found the Revision Rule "+revrulename);

		TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
		TCComponentBOMWindow bomWin = bowWinType.create(currentrevrule);       // create bom window configured with the default revision rule 
		
		TCComponentBOMLine bl= bomWin.setWindowTopLine(null, assemblyRevision,null, null);

	
		int bomsize=0;
		 bomsize=bl.getChildren().length;

		System.out.println("b4 call fun ppassemblyRevision= "+assemblyRevision.toDisplayString() +" bomsize=" +bomsize); 
		

		System.out.println("=========================================Getting TCUA  BOM/Global Alternate=============");

		if (bl.hasChildren()){

			AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

			//TCComponentBOMLine[] childContext =bl.getPackedLines();
			System.out.println("BOM Children count is "+childContext.length);

			System.out.println("=======================Listing Children=============");
			for(int i = 0; i < childContext.length; i++){
				//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
				TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
				TCComponentItem item = child.getItem();
				TCComponentItemRevision childItemrev=null;//child.getItemRevision();
				System.out.println("child ::"+item.getObjectString().toString()+"::="+item.getPropertyDisplayableValue("item_id"));
				ArrayList<TCComponentItemRevision> itnlist =new ArrayList<TCComponentItemRevision>();
				if(child!=null)
				{
						expandModule(child,itnlist);
				}
						ClassificationTreeLine clstree = null;
						System.out.println("itnlist.size()::"+itnlist.size());
				if(itnlist.size()>0)
				{
					//System.out.println("from childItemrev::"+childItemrev.toDisplayString());
					childItemrev=itnlist.get(0);
					//System.out.println("to childItemrev::"+childItemrev.toDisplayString());
				

				System.out.println("b4 call fun childItemrev= "+childItemrev.toDisplayString() +" Hybridstatus="+Hybridstatus); 

				clstree= setclsValues(childItemrev,tcsession,SelVehTSBusUnit,Hybridstatus);
			
				//System.out.println(" clstree::"+clstree);
				}
				if(clstree!=null)
				{
					ClassifyList.add(clstree);
				}



			}

			System.out.println("====================END of Listing Children=============");
		}
		return ClassifyList;
	}

	// Get Second Level Structure Normal BOM Expansion
	public  ArrayList<TCComponentItemRevision> getTCUAStructureInt(TCComponentBOMLine bl) throws TCException
	{

		System.out.println("=========================================inside getTCUAStructureInt=============");

		ArrayList<TCComponentItemRevision> bomlist=new ArrayList<TCComponentItemRevision>();

		if (bl.hasChildren()){

			AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

			//TCComponentBOMLine[] childContext =bl.getPackedLines();
			System.out.println("getTCUAStructureInt SVR BOM Children count is "+childContext.length);

			System.out.println("=======================getTCUAStructureInt SVR BOM Listing Children=============");
			for(int i = 0; i < childContext.length; i++){
				//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
				TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();

				TCComponentItemRevision item = child.getItem().getLatestItemRevision();
				ArrayList<TCComponentItemRevision> itnlist =new ArrayList<TCComponentItemRevision>();
				expandModule(child,itnlist);
				if(itnlist.size()>0)
				{
					bomlist.add(itnlist.get(0));
				}
					//bomlist.add(item);
				System.out.println("getTCUAStructureInt SVR BOM Children  is "+item.toDisplayString());		

				System.out.println("====================getTCUAStructureInt END of Listing Children=============");
			}

		}


		return bomlist;


	}

	public ArrayList<TCComponentItemRevision> expandModule(TCComponentBOMLine bl,ArrayList<TCComponentItemRevision> bomlist) throws TCException
	{
		
		
		TCComponentItemRevision item = bl.getItem().getLatestItemRevision();
		
		String mAddress=null;
		try {
			mAddress = item.getPropertyDisplayableValue("t5_ModuleAddress");
			String PartNum = item.getPropertyDisplayableValue("item_id");
			System.out.println("expandModule mAddress::"+mAddress +" PartNum="+PartNum);
			if(mAddress.equals("MT3Z01"))
			{
				
				System.out.println("fffffffffffffffff");
			}
		} catch (NotLoadedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("expandModule b4 expansionupto="+expansionupto);
		if((mAddress!=null && mAddress.isEmpty()==false ) || expansionupto!=null)
		{
		 if(expansionupto==null )
		 {
			 if(expansion_address.containsKey(mAddress)==true)
			 {
			 expansionupto=expansion_address.get(mAddress);
			 }
			else
				 bomlist.add(item);
		}
		 else
		 {
			if(expansionupto.contains(mAddress)) 
			{
				bomlist.add(item);
				expansionupto=null;
			}
		 }
		}
		System.out.println("expandModule final expansionupto="+expansionupto);
		if(expansionupto!=null)
		{
			if(bl.hasChildren())
			{
				
				AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

				//TCComponentBOMLine[] childContext =bl.getPackedLines();
				System.out.println("expandModule BOM Children count is "+childContext.length);

				System.out.println("=======================expandModule Listing Children=============");
				for(int i = 0; i < childContext.length; i++){
					//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
					TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
					if(child!=null)
					{
						System.out.println("expandModule CCC name::"+child.getTCProperty("bl_item_object_name").getDisplayableValue());
						System.out.println("expandModule CCC type::"+child.getTCProperty("bl_Design Revision_t5_PartType").getDisplayableValue());
						String blPartType=null;
						blPartType=child.getTCProperty("bl_Design Revision_t5_PartType").getDisplayableValue();
						if(blPartType!=null)
						{
						//String parttype=child.getItemRevision().getPropertyDisplayableValue("t5_PartType");
						System.out.println("parttype="+blPartType);
						if(blPartType.equals("Module")){
							expandModule(child,bomlist);
						}
						}
					}

			
				}
			}
		}
	

	return bomlist;
		
		
	}

	public HashMap<String, TCComponentItemRevision> getClass_not_found() {
		return class_not_found;
	}


	public void setClass_not_found(
			HashMap<String, TCComponentItemRevision> class_not_found) {
		this.class_not_found = class_not_found;
	}


	

}
