package com.tml.classification.modules;

public class ClassificationLineModelwq {
	private int srl;	
	private String AttrID;
	private String AttrName;
	private String AttrValue;
	
	public ClassificationLineModelwq(int srl,String AttrID,String AttrName,String AttrValue) {
		super();
		// TODO Auto-generated constructor stub
		this.srl=srl;
		this.AttrID=AttrID;
		this.AttrName=AttrName;
		this.AttrValue=AttrValue;
	}
	
	public int getSrl() {
		return srl;
	}
	public void setSrl(int srl) {
		this.srl = srl;
	}
	public String getAttrID() {
		return AttrID;
	}
	public void setAttrID(String attrID) {
		AttrID = attrID;
	}
	public String getAttrName() {
		return AttrName;
	}
	public void setAttrName(String attrName) {
		AttrName = attrName;
	}
	public String getAttrValue() {
		return AttrValue;
	}
	public void setAttrValue(String attrValue) {
		AttrValue = attrValue;
	}
	
	
	

}
