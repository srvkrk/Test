// Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2011.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.tml.classification.modules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;

import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationProperty;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationPropertyValue;
import com.teamcenter.services.rac.classification._2007_01.Classification.CreateClassificationObjectsResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.UpdateClassificationObjectsResponse;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.soa.client.model.ServiceData;

//import com.teamcenter.clientx.AppXSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;



/**
 *   This sample program create and update the standalone ICO.
 *
 *   The following data must be created before executing the test.
 *      Create a string attribute with ID=4001
 *      Create Class with ID=ICM4001
 *      Add the attribute 4001 to the class ICM4001.
 *      
 *   Refer TDoc for creating classification data.
 */
public class CreateOrUpdateICOSample
    
{
    ClassificationObject[]                  newICOs             = new ClassificationObject[1];
    CreateClassificationObjectsResponse     createICOResponse;
    UpdateClassificationObjectsResponse     updateICOResponse;
    private TCSession session;
    
    private Text text;
	private String ModuleAddress;
	private String ObjectID;
	private HashMap <String,Object> namevalueP;
	private ClassificationLineProvider tabLineModel;
	private ArrayList<ClassificationTableLine> classificationList;
	private Table table;
	private TableViewer tableViewer;
	private String moduleNum;
	private ClassificationObject clobj;
	private ClassificationObject[] createUpdatedclobj;
	private ServiceData data;
	private Map <String,String> arrayAttr;
	private TCComponentItem ICOItem;
    /**
     *  This API create and update the standalone ICO object.
     * @throws ServiceException
     */
    public CreateOrUpdateICOSample(TCComponentItem ICOItem,ClassificationObject clobj,String ModuleAddress,String ObjectID,String moduleNum,HashMap <String,Object> namevalueP,Map <String,String> arrayAttr,TCSession session) {
    	
    	
		super();
		// TODO Auto-generated constructor stub
		this.ModuleAddress=ModuleAddress;
		this.ObjectID=ObjectID;
		this.namevalueP=namevalueP;
		this.arrayAttr=arrayAttr;
		this.session=session;
		this.moduleNum=moduleNum;
		this.clobj=clobj;
		if(ICOItem==null)
		{
			try {
				ICOItem=QryIcoTcComponent( session, ObjectID);
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.ICOItem=ICOItem;
		System.out.println("1ModuleAddress="+ModuleAddress);
		System.out.println("InstanceID="+ObjectID);
		System.out.println("session="+session);
		
		
	}
    
 
    public TCComponentItem  QryIcoTcComponent(TCSession tcsession,String item_id) throws TCException
    {
               
               System.out.println(" In Query for IcoTCComponent For ::"+item_id);
               
               TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");
                   
                                            TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find("Item ID");
                                            
                                            TCComponent []qryResults           = null;
                                            String []qryNames                                          = new String[]{"Item ID"};
                                            String []qryValues                                          = new String[1];
                                            
                                            qryValues[0]=item_id;
                                            //qryValues[1]="T9TCUAToTCETransfer";   
                                            
                                            
                                                 
                                            if (mmcomponentquery != null)
                                                 
                                            {
                                                 
                                            	qryResults= mmcomponentquery.execute( qryNames, qryValues );
                                            	return (TCComponentItem) qryResults[0];
                                                         
                                            }
                                            
                                            
                                            
                                            return null;
                                            
                                            
               
               
    }


public ClassificationObject[] getCreateUpdatedclobj() {
		return createUpdatedclobj;
	}


protected boolean ServiceDataError(final ServiceData data)
{
	this.data=data;
    if(data.sizeOfPartialErrors() > 0)
    {
            for(int i = 0; i < data.sizeOfPartialErrors(); i++)
            {
                     for(String msg :
data.getPartialError(i).getMessages())
                             System.out.println("ServiceDataError:"+msg);
            }

            return true;
    }

    return false;
}

public ServiceData getServiceData()
{
	return this.data;
}




public void copyICO(ClassificationObject from_cls_objs_val,Map<String,String> attrNameIDMap)throws ServiceException
{
    ClassificationService clsService = ClassificationService.getService(session);
    System.out.println("Calling Classification::copyICO() ...");

   
    ClassificationProperty[] from_ico_props =from_cls_objs_val.properties;
    
    ArrayList<ClassificationProperty> ico_props_list=new ArrayList<ClassificationProperty>();
    
    for(int y=0;y<from_ico_props.length;y++)
    {
    	
    	ClassificationProperty from_ico_att_prop=from_ico_props[y];
    	int fromattrid=from_ico_att_prop.attributeId;
    	
    
    	
    	if(attrNameIDMap.containsKey(fromattrid+""))
    	{
    	
    		System.out.println("ico_props["+y+"]"+from_ico_att_prop.attributeId+":::");	
    		
    		
    		
    		
    		ClassificationPropertyValue[] propvalary1= from_ico_att_prop.values;
    		
    		if(propvalary1==null || propvalary1.length==0)
    			continue;
    		System.out.println("ico_props1["+y+"]"+from_ico_att_prop.attributeId+":::");	
    		
    		/*ClassificationPropertyValue[] propvalary= new ClassificationPropertyValue[propvalary1.length];
    		for(int p=0;p<propvalary1.length;p++)
    		{
    		
    		propvalary[p]=new ClassificationPropertyValue();
    		propvalary[p].dbValue= propvalary1[p].dbValue;//new StringTokenizer((String) selList.get(p)," ").nextToken();
    		}
    		
	        ClassificationProperty ic_prop = new ClassificationProperty();
    		ic_prop.attributeId =fromattrid;
    		ic_prop.values =propvalary;
    	*/
    	ico_props_list.add(from_ico_att_prop);	//ic_prop
    	/*ClassificationPropertyValue[] icoval=from_ico_att_prop.values;
    	
    	for(int s=0;s<icoval.length;s++)
    	{
    		
    		System.out.println("ico_propsval["+s+"]"+icoval[s].displayValue+"->"+icoval[s].dbValue+":");
    		
    	}
    	*/
    }
    
    }
    
    ClassificationProperty[] ico_props=ico_props_list.toArray(new ClassificationProperty[ico_props_list.size()]);
    
    ClassificationObject[] icos = new ClassificationObject[1];
int count=0;

System.out.println("ICOItemRev="+ICOItem);

   
    //End 
    icos[0] = new ClassificationObject();
    icos[0].classId = ModuleAddress;
    icos[0].clsObjTag = null;
    icos[0].instanceId = ObjectID;
    icos[0].properties = ico_props;
    icos[0].unitBase = "METRIC";
    // wsoId is null for standalone ICO. 
    System.out.println("b4 ICOItemRev set ="+ICOItem);
    icos[0].wsoId = ICOItem;
    System.out.println("clobj="+clobj);
    
    System.out.println("ModuleAddress="+ModuleAddress);
    
    System.out.println("ObjectID="+ObjectID);
    
    // Create the ICO object
    if(clobj==null)
    {
    createICOResponse = clsService.createClassificationObjects( icos );
    
    if ( createICOResponse.data.sizeOfPartialErrors() > 0)
    {
     ServiceDataError(createICOResponse.data);
        throw new ServiceException( "ClassificationService.createClassificationObjects returned a partial Error.");
}
    if ( createICOResponse.clsObjs.length > 0 )
    {
    	createUpdatedclobj=createICOResponse.clsObjs;
    	clobj=createICOResponse.clsObjs[0];
    }
    
    }
    System.out.println("... completed Classification::createClassificationObjects()");
  
    //if ( createICOResponse.clsObjs.length > 0 )
    if(clobj!=null)
    {
        // Set the data on classification property value for updating on ICO
    	int count1=0;
    	/*for (Map.Entry<String, Object> entry : namevalueP.entrySet())
        {
        icos[0].properties[count1].values[0].dbValue = (String) entry.getValue() ;
        count1++;
        }*/
        // Set the classification object tag to be updated.
      //  icos[0].clsObjTag = createICOResponse.clsObjs[0].clsObjTag;
        icos[0]=clobj;
        icos[0].properties = ico_props;
      updateICOResponse = clsService.updateClassificationObjects( icos );
        System.out.println("... completed Classification::updateClassificationObjects()");
        
        if ( updateICOResponse.data.sizeOfPartialErrors() > 0)
        {
        	 ServiceDataError(updateICOResponse.data);
            throw new ServiceException( "ClassificationService.updateClassificationObjects returned a partial Error.");
        
        }
        int objCount = updateICOResponse.clsObjs.length ;
        createUpdatedclobj=updateICOResponse.clsObjs;
        if ( objCount <= 0 )
        {
            System.out.println("Nothing was done");
        }
        else
        {               
            ClassificationObject[]  updatedICOs = new ClassificationObject[objCount];
            for ( int jnx = 0 ;jnx < objCount ; jnx++ )
            {
                updatedICOs[jnx] = updateICOResponse.clsObjs[jnx];

                System.out.println( "Class ID: " + updatedICOs[jnx].classId );
                System.out.println( "ICO ID: " + updatedICOs[jnx].instanceId );
                System.out.println( "Unit Base: " + updatedICOs[jnx].unitBase );
                System.out.println( "WSO Id: " + updatedICOs[jnx].wsoId );
                for( int attrIndex=0; attrIndex < updatedICOs[jnx].properties.length; attrIndex++)
                {
                    if( ico_props.length>0 && updatedICOs[jnx].properties[attrIndex].attributeId == ico_props[0].attributeId )
                    {
                        System.out.println( " Updated Attr ID: " + ico_props[0].attributeId );
                       // if(updatedICOs[jnx].properties[attrIndex].values!= null)
                      //  System.out.println( "  Attr value: " + updatedICOs[jnx].properties[attrIndex].values[0].dbValue );
                    }
                }
             }
        }
               
    }
}


    
    public void createAndUpdateICO()throws ServiceException
    {
        ClassificationService clsService = ClassificationService.getService(session);
        System.out.println("Calling Classification::createClassificationObjects() ...");

       
        ClassificationProperty[] ico_props = new ClassificationProperty[namevalueP.size()];
        ClassificationObject[] icos = new ClassificationObject[1];
int count=0;

        for (Map.Entry<String, Object> entry : namevalueP.entrySet())
        {
        	/* ClassificationPropertyValue[] ico_prop_values1 = new ClassificationPropertyValue[1];
		    System.out.println(entry.getKey() + " = " + entry.getValue());        
	        ico_prop_values1[0] = new ClassificationPropertyValue();
	        ico_prop_values1[0].dbValue = (String) entry.getValue();
	        */
        	String attval=(String) entry.getValue();
        	List<String> selList=new ArrayList<String>();
    		
        	//if(attval.contains("@"))
        	if(arrayAttr.containsKey(entry.getKey()))
        	{
        		selList=(Arrays.asList(attval.trim().split(PreferenceValue.getARRAY_DELMITER())));
        		//selList=(Arrays.asList(attval.trim().substring(1).split(",")));
        		System.out.println("arrayList:->"+selList.size());
        	}
        	else
        	{
        		selList.add((String) entry.getValue());
        	}
        	if(selList.size()>0)
        	{
        		
        		
        		ClassificationPropertyValue[] propvalary= new ClassificationPropertyValue[selList.size()];
        		for(int p=0;p<selList.size();p++)
        		{
        			System.out.println("P::"+selList.get(p));
        		propvalary[p]=new ClassificationPropertyValue();
        		System.out.println("selList.get(p):->"+selList.get(p) +" Integer.parseInt(entry.getKey()="+Integer.parseInt(entry.getKey()));
        		propvalary[p].dbValue= selList.get(p);//new StringTokenizer((String) selList.get(p)," ").nextToken();
        		}
    	        ico_props[count] = new ClassificationProperty();
    	        ico_props[count].attributeId =Integer.parseInt(entry.getKey()) ;
    	        ico_props[count].values =propvalary;
        		
        	}
        	else
        	{
	        ClassificationPropertyValue propval= new ClassificationPropertyValue();
	        propval.dbValue= (String) entry.getValue();
	        ico_props[count] = new ClassificationProperty();
	        ico_props[count].attributeId =Integer.parseInt(entry.getKey()) ;
	        ico_props[count].values =new ClassificationPropertyValue[]{propval};//ico_prop_values1};// ico_prop_values1;
        	
	       // System.out.println(ico_props[count].attributeId + " = " + ico_prop_values1[0].dbValue);
	        System.out.println(ico_props[count].attributeId + " = " + propval.dbValue);
        	}
	        count++;
        }
        
        //Qry TcComponent 
        
        System.out.println("ICOItemRev="+ICOItem);
        //End 
        icos[0] = new ClassificationObject();
        icos[0].classId = ModuleAddress;
        icos[0].clsObjTag = null;
        icos[0].instanceId = ObjectID;
        icos[0].properties = ico_props;
        icos[0].unitBase = "METRIC";
        // wsoId is null for standalone ICO. 
        System.out.println("b4 ICOItemRev set ="+ICOItem);
        icos[0].wsoId = ICOItem;
        System.out.println("in createAndUpdateICO clobj="+clobj);
        // Create the ICO object
        if(clobj==null)
        {
        	createICOResponse = clsService.createClassificationObjects( icos );

        	if ( createICOResponse.data.sizeOfPartialErrors() > 0)
        	{
        		ServiceDataError(createICOResponse.data);
        		//  throw new ServiceException( "ClassificationService.createClassificationObjects returned a partial Error.");
        	}
        	if ( createICOResponse.clsObjs.length > 0 )
        	{
        		createUpdatedclobj=createICOResponse.clsObjs;
        		clobj=createICOResponse.clsObjs[0];
        	}

        }
        System.out.println("... completed Classification::createClassificationObjects()");
      
        //if ( createICOResponse.clsObjs.length > 0 )
        if(clobj!=null)
        {
            // Set the data on classification property value for updating on ICO
        	int count1=0;
        	/*for (Map.Entry<String, Object> entry : namevalueP.entrySet())
            {
            icos[0].properties[count1].values[0].dbValue = (String) entry.getValue() ;
            count1++;
            }*/
            // Set the classification object tag to be updated.
          //  icos[0].clsObjTag = createICOResponse.clsObjs[0].clsObjTag;
            icos[0]=clobj;
            icos[0].properties = ico_props;
          updateICOResponse = clsService.updateClassificationObjects( icos );
            System.out.println("... completed Classification::updateClassificationObjects()");
            
            if ( updateICOResponse.data.sizeOfPartialErrors() > 0)
            {
            	 ServiceDataError(updateICOResponse.data);
                throw new ServiceException( "ClassificationService.updateClassificationObjects returned a partial Error.");
            
            }
            int objCount = updateICOResponse.clsObjs.length ;
            createUpdatedclobj=updateICOResponse.clsObjs;
            if ( objCount <= 0 )
            {
                System.out.println("Nothing was done");
            }
            else
            {               
                ClassificationObject[]  updatedICOs = new ClassificationObject[objCount];
                for ( int jnx = 0 ;jnx < objCount ; jnx++ )
                {
                    updatedICOs[jnx] = updateICOResponse.clsObjs[jnx];

                    System.out.println( "Class ID: " + updatedICOs[jnx].classId );
                    System.out.println( "ICO ID: " + updatedICOs[jnx].instanceId );
                    System.out.println( "Unit Base: " + updatedICOs[jnx].unitBase );
                    System.out.println( "WSO Id: " + updatedICOs[jnx].wsoId );
                    for( int attrIndex=0; attrIndex < updatedICOs[jnx].properties.length; attrIndex++)
                    {
                        if( ico_props.length>0 && updatedICOs[jnx].properties[attrIndex].attributeId == ico_props[0].attributeId )
                        {
                            System.out.println( " Updated Attr ID: " + ico_props[0].attributeId );
                           // if(updatedICOs[jnx].properties[attrIndex].values!= null)
                          //  System.out.println( "  Attr value: " + updatedICOs[jnx].properties[attrIndex].values[0].dbValue );
                        }
                    }
                 }
            }
                   
        }
    }
	
}
