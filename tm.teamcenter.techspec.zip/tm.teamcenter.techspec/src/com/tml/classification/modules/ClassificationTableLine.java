package com.tml.classification.modules;

public class ClassificationTableLine {
	  private String SrlNo;
	  private String AttrID;
	  private String tcentattrID;
	  private String AttrName;
	  private String AttrValue;
	  private String newValue;
	  private String ChangeValue;
	  private String Unit;
	  private String LovID;
	  private ClassificationAnnotationLine parent;
	  private boolean ismandatory;
	  private boolean isProtected;
	  private int arraySize;
	  private String annotation;
	  private String depattr;
	  private String depval;
      private String depattrcfg;
	public ClassificationTableLine(String srlNo, String attrID,String tcentattrID,
			String attrName, String attrValue, String unit, String lovID,boolean ismandatory,boolean isProtected,int arraySize,String annotation,String depattr,String depattrcfg) {
		super();
		SrlNo = srlNo;
		AttrID = attrID;
		this.tcentattrID= tcentattrID;
		AttrName = attrName;
		AttrValue = attrValue;
		this.newValue="";
		Unit = unit;
		LovID = lovID;
		this.ismandatory=ismandatory;
		this.isProtected=isProtected;
		this.arraySize=arraySize;
		this.annotation=annotation;
		this.depattr=depattr;
		this.depval=depval;
		this.depattrcfg=depattrcfg;
	}
	public String getSrlNo() {
		return SrlNo;
	}
	public void setSrlNo(String srlNo) {
		SrlNo = srlNo;
	}
	public String getAttrID() {
		return AttrID;
	}
	public void setAttrID(String attrID) {
		AttrID = attrID;
	}
			
	public String getTcentattrID() {
		return tcentattrID;
	}
	public void setTcentattrID(String tcentattrID) {
		this.tcentattrID = tcentattrID;
	}
	public String getAttrName() {
		return AttrName;
	}
	public void setAttrName(String attrName) {
		AttrName = attrName;
	}
	public String getAttrValue() {
		return AttrValue;
	}
	public void setAttrValue(String attrValue) {
		AttrValue = attrValue;
	}
	public String getUnit() {
		return Unit;
	}
	public void setUnit(String unit) {
		Unit = unit;
	}
	public String getLovID() {
		return LovID;
	}
	public void setLovID(String lovID) {
		LovID = lovID;
	}	
	
	public boolean isIsmandatory() {
		return ismandatory;
	}
	public void setIsmandatory(boolean ismandatory) {
		this.ismandatory = ismandatory;
	}
	public boolean isProtected() {
		return isProtected;
	}
	public void setProtected(boolean isProtected) {
		this.isProtected = isProtected;
	}
	public ClassificationAnnotationLine getParent() {
		return parent;
	}
	public void setParent(ClassificationAnnotationLine parent) {
		this.parent = parent;
	}
	
	
	public int getArraySize() {
		return arraySize;
	}
	public void setArraySize(int arraySize) {
		this.arraySize = arraySize;
	}
	
	
	
	
	public String getChangeValue() {
		return ChangeValue;
	}
	public void setChangeValue(String changeValue) {
		ChangeValue = changeValue;
	}
	public String getAnnotation() {
		return this.annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	
	
	public String getDepattr() {
		return depattr;
	}
	public void setDepattr(String depattr) {
		this.depattr = depattr;
	}
	
	public String getDepval() {
		return depval;
	}
	public void setDepval(String depval) {
		this.depval = depval;
	}
	public String getDepattrcfg() {
		return depattrcfg;
	}
	public void setDepattrcfg(String depattrcfg) {
		this.depattrcfg = depattrcfg;
	}
	
	
	
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
	@Override
	public String toString() {
		return "ClassificationTableLine [SrlNo=" + SrlNo + ", AttrID=" + AttrID
				+ ", tcentattrID=" + tcentattrID + ", AttrName=" + AttrName
				+ ", AttrValue=" + AttrValue + ", newValue=" + newValue
				+ ", ChangeValue=" + ChangeValue + ", Unit=" + Unit
				+ ", LovID=" + LovID + ", parent=" + parent + ", ismandatory="
				+ ismandatory + ", isProtected=" + isProtected + ", arraySize="
				+ arraySize + ", annotation=" + annotation + ", depattr="
				+ depattr + ", depval="+ depval+ ", depattrcfg=" + depattrcfg + "]";
	}
	  
	 /* 
	@Override
	public String toString() {
		return "ClassificationTableLine [SrlNo=" + SrlNo + ", AttrID=" + AttrID
				+ ", tcentattrID=" + tcentattrID + ", AttrName=" + AttrName
				+ ", AttrValue=" + AttrValue + ", ChangeValue=" + ChangeValue
				+ ", Unit=" + Unit + ", LovID=" + LovID + ", parent=" + parent
				+ ", ismandatory=" + ismandatory + ", isProtected="
				+ isProtected + ", arraySize=" + arraySize + ", annotation="
				+ annotation + ", depattr=" + depattr + ", depattrcfg="
				+ depattrcfg + "]";
	} 
	*/
	  
	  
	  

}
