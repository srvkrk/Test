package com.tml.classification.modules;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
//import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import java.util.ArrayList;
import java.util.List;
import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentForm;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentProject;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCComponentUnitOfMeasure;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.soa.exceptions.NotLoadedException;
import com.tml.techspec.dialogs.GetProjVehClass;
import com.tml.techspec.dialogs.ModuleClassificationDialog;
import com.tml.techspec.dialogs.UpdateCheckInMDMDialog;
import com.tml.techspec.dialogs.UpdateMDMDialog;
import com.tml.techspec.dialogs.UpdateMDMDlgForPRD;
import com.tml.techspec.dialogs.UpdateModDialog;
import com.tml.techspec.dialogs.UpdateTechSpecDialog;
import com.tml.techspec.dialogs.GetProjVehClass;

import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2007_01.Classification.FindClassificationObjectsResponse;
import com.teamcenter.services.rac.classification._2011_12.Classification.AttributeValues;
import com.teamcenter.services.rac.classification._2011_12.Classification.Value;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core._2007_06.DataManagement.RelationAndTypesFilter;
import com.teamcenter.services.rac.core._2007_09.DataManagement.ExpandGRMRelationsData2;
import com.teamcenter.services.rac.core._2007_09.DataManagement.ExpandGRMRelationsOutput2;
import com.teamcenter.services.rac.core._2007_09.DataManagement.ExpandGRMRelationsPref2;
import com.teamcenter.services.rac.core._2007_09.DataManagement.ExpandGRMRelationsResponse2;
import com.teamcenter.services.rac.core._2007_09.DataManagement.ExpandGRMRelationship;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateIn;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateInput;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateOut;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateResponse;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateOrUpdateRelationsInfo;
import com.teamcenter.services.rac.query.SavedQueryService;
import com.teamcenter.services.rac.query._2006_03.SavedQuery.GetSavedQueriesResponse;
import com.teamcenter.services.rac.query._2007_09.SavedQuery.QueryResults;
import com.teamcenter.services.rac.query._2007_09.SavedQuery.SavedQueriesResponse;
import com.teamcenter.services.rac.query._2008_06.SavedQuery.QueryInput;
import com.teamcenter.services.rac.core._2008_06.DataManagement.SecondaryData;
import com.teamcenter.soa.client.model.ServiceData;
import com.teamcenter.soa.exceptions.NotLoadedException;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVDefinition2;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import com.tml.techspec.dialogs.UpdateMDMDialog;
public class TechSpecUtil {	

	private Set<String> ProjVehClsValueSet = null;

public static String getWFStepName(String wftype) throws NotLoadedException, TCException
{
	//MDM
	//VCATTR
	String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
	String [] qryValues={"STEPNAME",wftype,"0"};
	int r;
	TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
	String info=null;
	if(objvec!=null)
	{
		for(int f=0;f<objvec.length;f++)
		{
			TCComponent objcntrl=objvec[f];
			
			
				
			
			
				 info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
	
		}
	}
	
	return info;
}



public static String getBypassModAddrs(String ModAddrss) throws NotLoadedException, TCException
{
	//MDM
	//VCATTR
	//String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
	String [] qryNames={"SYSCD","Delete Indicator"};
	String [] qryValues={"BypassModAdrs","0"};
	//int r;
	TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
	String info=null;
	String retval="";
	String infostr="";
	int r;
	if(objvec!=null)
	{
		for(int f=0;f<objvec.length;f++)
		{
			TCComponent objcntrl=objvec[f];
			
			
			String[] infoattr=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_Userinfo10"};

			int len=infoattr.length;

			for(r=len-1;r>=0;r--)
			{

				info=objcntrl.getPropertyDisplayableValue(infoattr[r]);
	
				if(info==null||info.isEmpty()==true||info.trim().length()==0) continue;

				else
					infostr+=info.toString()+",";
					//infostr=info.toString()+",";

			
				 //info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
				
			}
			
			
	
		}
		System.out.println("inside getBypassModAddrs infostr="+infostr +" ModAddrss="+ModAddrss);
		 if(infostr.contains(ModAddrss))
		 {
			 retval="TRUE";
			// return 
		 }
		 else
		 {
			 retval="FALSE";
		 }
	}
	else
	{
		retval="FALSE";
	}
	System.out.println("End  getBypassModAddrs func with infostr="+infostr +" ModAddrss="+ModAddrss);
	return retval;
}

public static String getICOMODCntrlObjInfo(String ModNum) throws NotLoadedException, TCException
{
	//MDM
	//VCATTR
	String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
	String [] qryValues={"ICOMODUPD",ModNum,"0"};
	//int r;
	TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
	String info=null;
	if(objvec!=null)
	{
		for(int f=0;f<objvec.length;f++)
		{
			TCComponent objcntrl=objvec[f];
			
			
				
			
			
				 info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
	
		}
	}
	
	return info;
}

public static int getDepattridFuncSize(String VehCls) throws NotLoadedException, TCException
{
	System.out.println("inside getDepattridFuncSize func with input VehCls ="+VehCls );
	   	 TCComponent[] contrlObjs = null;	
		 String qry="Control Objects..."; 
		// String retdepattrid=null;
		 String []qryNames	= new String[]{"SUBSYSCD","Name","Delete Indicator"};
		// String []qryValues	= new String[]{VehCls,"ClsDepAttrId","0"};
		 String []qryValues	= new String[]{VehCls,"ClsCmvrattrID","0"};
		// try {
			 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
			 if(contrlObjs != null)
			 {
				 System.out.println("contrlObjs.length="+contrlObjs.length);
				 return contrlObjs.length;
			 }
		 //}
		 
			System.out.println("End in TechSpecUtil getDepattridFunc func with output for  return contrlObjs.length="+ contrlObjs.length);
	return contrlObjs.length;
}

public static int getControlObj(String inp) throws NotLoadedException, TCException
{
	System.out.println("inside getControlObj func with input VehCls ="+inp );
	   	 TCComponent[] contrlObjs = null;	
		 String qry="Control Objects..."; 
		// String retdepattrid=null;
		 String []qryNames	= new String[]{"SUBSYSCD","Delete Indicator"};
		// String []qryValues	= new String[]{VehCls,"ClsDepAttrId","0"};
		 String []qryValues	= new String[]{inp,"0"};
		// try {
			 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
	//			 if(contrlObjs != null)
	//			 {
	//				 System.out.println("contrlObjs.length="+contrlObjs.length);
	//				 return contrlObjs.length;
	//			 }
			 //}
		 
			System.out.println("End in TechSpecUtil getControlObj func with output for  return contrlObjs.length="+ contrlObjs.length);
	return contrlObjs.length;
}


public String getbypassUsr(String inp) throws NotLoadedException, TCException
{
	System.out.println("inside getbypassUsr func with input ="+inp );
	 String bypassusr = null;          
	 TCComponent[] contrlObjs = null;	
	 String qry="Control Objects..."; 
	 String []qryNames	= new String[]{"SUBSYSCD","Delete Indicator"};
	 String []qryValues	= new String[]{inp,"0"};
		 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
			 if(contrlObjs.length >0)
			 {
				 bypassusr= contrlObjs[0].getStringProperty("t5_Userinfo1");
				 System.out.println( "\n getbypassUsr bypassusr==>" + bypassusr);
				 
			 }
			System.out.println("End getbypassUsr func with bypassusr="+bypassusr );
			
			
			
	return bypassusr;
}


public String gettechspecrevrule(String inp) throws NotLoadedException, TCException
{
	System.out.println("inside gettechspecrevrule func with input ="+inp );
	 String revrulename = null;          
	 TCComponent[] contrlObjs = null;	
	 String qry="Control Objects..."; 
	 String []qryNames	= new String[]{"SUBSYSCD","Delete Indicator"};
	 String []qryValues	= new String[]{inp,"0"};
		 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
			 if(contrlObjs.length >0)
			 {
				 revrulename= contrlObjs[0].getStringProperty("t5_Userinfo1");
				 System.out.println( "\n gettechspecrevrule revrulename==>" + revrulename);
				 
			 }
			System.out.println("End gettechspecrevrule func with revrulename="+revrulename );
			
			
			
	return revrulename;
}


public static String getDepattridFunc(String VehCls) throws NotLoadedException, TCException
{
	System.out.println("inside getDepattridFunc func with input VehCls ="+VehCls );
	   	 TCComponent[] contrlObjs = null;	
		 String qry="Control Objects..."; 
		 String retdepattrid=null;
		 String []qryNames	= new String[]{"SUBSYSCD","Name","Delete Indicator"};
		 String []qryValues	= new String[]{VehCls,"ClsDepAttrId","0"};
		// try {
			 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
			 if(contrlObjs != null)
			 {
				 if(contrlObjs.length >0)
				 {
					// cntrlobjlen=contrlObjs.length;
					 for(int c=0;c<contrlObjs.length;c++)
					 {
						 String ctrlClass = "";
						 ctrlClass = contrlObjs[c].getStringProperty("object_type");
						 if(!ctrlClass.equals("T5_ControlObject"))
						 {
							 System.out.println("Not a Control Object Class");
							 continue;
						 }
						 else
						 {

								 String userinfo2 = "";
								 userinfo2 = contrlObjs[c].getStringProperty("t5_Userinfo2");
								 System.out.println( "\n userinfo2==>" + userinfo2);
								 if(userinfo2.length()>0)
								 {
									 retdepattrid=userinfo2;
								 }
								 else
								 {
									 retdepattrid="8240";
								 }
								 System.out.println( "\n retdepattrid==>" + retdepattrid);
								 
								// return retdepattrid;
								
						 }
					 }
				 }
				 else
				 {
					 retdepattrid="8240";
					 //return retCmvrattrid;
				 }
			 }
		 //}
		 
			System.out.println("End in TechSpecUtil getDepattridFunc func with output for retdepattrid="+retdepattrid);
	return retdepattrid;
}

//Start getDepEditedHashMapFunc 

public static String getReqClsattridFunc(String VehCls,String attrid) throws NotLoadedException, TCException
{
	System.out.println("inside getReqClsattridFunc func with input VehCls ="+VehCls + " attrid="+attrid );
	   	 TCComponent[] contrlObjs = null;	
		 String qry="Control Objects..."; 
		 String retdepattrid=null;
		 String []qryNames	= new String[]{"SUBSYSCD","Name","Delete Indicator"};
		 String []qryValues	= new String[]{VehCls,"ClsDepAttrIdNew","0"};
		// try {
			 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
			 if(contrlObjs != null)
			 {
				 if(contrlObjs.length >0)
				 {
					 for(int c=0;c<contrlObjs.length;c++)
					 {
						 String ctrlClass = "";
						 ctrlClass = contrlObjs[c].getStringProperty("object_type");
						 if(!ctrlClass.equals("T5_ControlObject"))
						 {
							 System.out.println("Not a Control Object Class");
							 continue;
						 }
						 else
						 {

								 String userinfo1 = "";
								 String userinfo2 = "";
								 String userinfo3 = "";
								 String userinfo4 = "";
								 String userinfo5 = "";
								 String userinfo6 = "";
								 String userinfo7 = "";
								 String userinfo8 = "";
								 String userinfo9 = "";
								 String userinfo10 = "";
								 userinfo1 = contrlObjs[c].getStringProperty("t5_Userinfo1"); // for 240 
								 System.out.println( "\n userinfo1==>" + userinfo1);
								 userinfo2 = contrlObjs[c].getStringProperty("t5_Userinfo2"); //for 241
								 System.out.println( "\n userinfo2==>" + userinfo2);
								 userinfo3 = contrlObjs[c].getStringProperty("t5_Userinfo3"); //for 242
								 System.out.println( "\n userinfo3==>" + userinfo3);
								 userinfo4 = contrlObjs[c].getStringProperty("t5_Userinfo4"); //for 243
								 System.out.println( "\n userinfo4==>" + userinfo4);
								 userinfo5 = contrlObjs[c].getStringProperty("t5_Userinfo5"); // for 100
								 System.out.println( "\n userinfo5==>" + userinfo5);
								 userinfo6 = contrlObjs[c].getStringProperty("t5_Userinfo6"); //for 226
								 System.out.println( "\n userinfo2==>" + userinfo2);
								 userinfo7 = contrlObjs[c].getStringProperty("t5_Userinfo7"); // for prefix
								 System.out.println( "\n userinfo7==>" + userinfo7);
								 userinfo8 = contrlObjs[c].getStringProperty("t5_Userinfo8"); // reserverd
								 System.out.println( "\n userinfo8==>" + userinfo8);
								 userinfo9 = contrlObjs[c].getStringProperty("t5_Userinfo9"); // reserverd
								 System.out.println( "\n userinfo9==>" + userinfo9);
								 userinfo10 = contrlObjs[c].getStringProperty("t5_userinfo10"); // reserverd
								 System.out.println( "\n userinfo10==>" + userinfo10);
								 
								 if(userinfo1.length()>0 )
								 {
									 if( userinfo1.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo1.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo1;
											 
										 }
									 }
									 if( userinfo1.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo1.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo1;
											 
										 }
									 }
								 }
								 if(userinfo2.length()>0 )
								 {
									 if( userinfo2.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo2.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo2;
											 
										 }
									 }
									 if( userinfo2.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo2.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo2;
											 
										 }
									 }
								 }
								  if(userinfo3.length()>0 )
								 {
									  if( userinfo3.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo3.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo3;
											 
										 }
									 }
									 if( userinfo3.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo3.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo3;
											 
										 }
									 }
								 }
								 if(userinfo4.length()>0 )
								 {
									 if( userinfo4.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo4.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo4;
											 
										 }
									 }
									 if( userinfo4.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo4.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo4;
											 
										 }
									 }
								 }
								 if(userinfo5.length()>0 )
								 {
									
									 if( userinfo5.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo5.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo5;
											 
										 }
									 }
									 if( userinfo5.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo5.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo5;
											 
										 }
									 }
								 }
								 if(userinfo6.length()>0 )
								 {
									 if( userinfo6.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo6.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo6;
											 
										 }
									 }
									 if( userinfo6.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo6.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo6;
											 
										 }
									 }
								 }
								 if(userinfo7.length()>0 )
								 {
									 //String tmpstr = attrid.substring(1,attrid.length);
									 
									 if( userinfo7.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo7.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo7;
											 
										 }
									 }
									 if( userinfo7.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo7.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo7;
											 
										 }
									 }
								 }
								 if(userinfo8.length()>0)
								 {
									 if( userinfo8.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo8.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo8;
											 
										 }
									 }
									 if( userinfo8.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo8.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo8;
											 
										 }
									 }
								 }
								 if(userinfo9.length()>0 )
								 {
									 if( userinfo9.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo9.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo9;
											 
										 }
									 }
									  if(userinfo9.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo9.contains(tmpstr))
										 {
											retdepattrid=userinfo9;
											 
										 }
									 }
								 }
								 if(userinfo10.length()>0  )
								 {
									 if(userinfo10.length()==4)
									 {
										 String tmpstr = attrid.substring(1,attrid.length());
										 if(userinfo10.contains(tmpstr))
										 {
											
											 retdepattrid=userinfo10;
											 
										 }
									 }
									 if(userinfo4.length()==5)
									 {
										 String tmpstr = attrid.substring(2,attrid.length());
										 if(userinfo10.contains(tmpstr))
										 {
											retdepattrid=userinfo10;
											 
										 }
									 }
								 }
								 
								if(retdepattrid.length()<=0)
								 {
									 retdepattrid=attrid;
								 }
								 System.out.println( "\n retdepattrid==>" + retdepattrid);
								 
								// return retdepattrid;
								
						 }
					 }
				 }
				 else
				 {
					 String tmpattrstr=null;
					if(VehCls.contains("HCV"))
					{
							
							
						if(attrid.contains("240") || attrid.contains("241") || attrid.contains("242") || attrid.contains("243"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
							//tc_strcpy(tmpattrstr,"6");
							//tc_strcat(tmpattrstr,TcuaAttrIDDup);
							
						}
						else if(attrid.contains("100"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else if(attrid.contains("226"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else
						{
							if((attrid.length())==1)
							{
								tmpattrstr="";
								tmpattrstr="600"+attrid;
								
							}
							if((attrid.length())==2)							
							{
								tmpattrstr="";
								tmpattrstr="60"+attrid;
								
							}
							if((attrid.length())==3)
							{
								tmpattrstr="";
								tmpattrstr="6"+attrid;
							}
						}
							//tc_strcpy(ToBeClsNameTmp,"HCVVCATTR01");
							//tc_strcat(ToBeClsClassName,moduleAddress);
					}
					 
					if(VehCls.contains("MCV"))
					{
							
							
						if(attrid.contains("240") || attrid.contains("241") || attrid.contains("242") || attrid.contains("243"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
							//tc_strcpy(tmpattrstr,"6");
							//tc_strcat(tmpattrstr,TcuaAttrIDDup);
							
						}
						else if(attrid.contains("100"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else if(attrid.contains("226"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else
						{
							if((attrid.length())==1)
							{
								tmpattrstr="";
								tmpattrstr="500"+attrid;
								
							}
							if((attrid.length())==2)							
							{
								tmpattrstr="";
								tmpattrstr="50"+attrid;
								
							}
							if(attrid.length()==3)
							{
								tmpattrstr="";
								tmpattrstr="5"+attrid;
							}
						}
							//tc_strcpy(ToBeClsNameTmp,"HCVVCATTR01");
							//tc_strcat(ToBeClsClassName,moduleAddress);
					} 
					if(VehCls.contains("BUS"))
					{
							
							
						if(attrid.contains("240") || attrid.contains("241") || attrid.contains("242") || attrid.contains("243"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
							//tc_strcpy(tmpattrstr,"6");
							//tc_strcat(tmpattrstr,TcuaAttrIDDup);
							
						}
						else if(attrid.contains("100"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else if(attrid.contains("226"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else
						{
							if((attrid.length())==1)
							{
								tmpattrstr="";
								tmpattrstr="700"+attrid;
								
							}
							if((attrid.length())==2)							
							{
								tmpattrstr="";
								tmpattrstr="70"+attrid;
								
							}
							if((attrid.length())==3)
							{
								tmpattrstr="";
								tmpattrstr="7"+attrid;
							}
						}
							//tc_strcpy(ToBeClsNameTmp,"HCVVCATTR01");
							//tc_strcat(ToBeClsClassName,moduleAddress);
					}
					if(VehCls.contains("LCV"))
					{
							
							
						if(attrid.contains("240") || attrid.contains("241") || attrid.contains("242") || attrid.contains("243"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
							//tc_strcpy(tmpattrstr,"6");
							//tc_strcat(tmpattrstr,TcuaAttrIDDup);
							
						}
						else if(attrid.contains("100"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else if(attrid.contains("226"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else
						{
							if((attrid.length())==1)
							{
								tmpattrstr="";
								tmpattrstr="400"+attrid;
								
							}
							if((attrid.length())==2)							
							{
								tmpattrstr="";
								tmpattrstr="40"+attrid;
								
							}
							if((attrid.length())==3)
							{
								tmpattrstr="";
								tmpattrstr="4"+attrid;
							}
						}
							//tc_strcpy(ToBeClsNameTmp,"HCVVCATTR01");
							//tc_strcat(ToBeClsClassName,moduleAddress);
					}
					if(VehCls.contains("LMV"))
					{
							
							
						if(attrid.contains("240") || attrid.contains("241") || attrid.contains("242") || attrid.contains("243"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
							//tc_strcpy(tmpattrstr,"6");
							//tc_strcat(tmpattrstr,TcuaAttrIDDup);
							
						}
						else if(attrid.contains("100"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else if(attrid.contains("226"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else
						{
							if((attrid.length())==1)
							{
								tmpattrstr="";
								tmpattrstr="200"+attrid;
								
							}
							if((attrid.length())==2)							
							{
								tmpattrstr="";
								tmpattrstr="20"+attrid;
								
							}
							if((attrid.length())==3)
							{
								tmpattrstr="";
								tmpattrstr="2"+attrid;
							}
						}
							//tc_strcpy(ToBeClsNameTmp,"HCVVCATTR01");
							//tc_strcat(ToBeClsClassName,moduleAddress);
					}
					if(VehCls.contains("ICV"))
					{
							
							
						if(attrid.contains("240") || attrid.contains("241") || attrid.contains("242") || attrid.contains("243"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
							//tc_strcpy(tmpattrstr,"6");
							//tc_strcat(tmpattrstr,TcuaAttrIDDup);
							
						}
						else if(attrid.contains("100"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else if(attrid.contains("226"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else
						{
							if((attrid.length())==1)
							{
								tmpattrstr="";
								tmpattrstr="300"+attrid;
								
							}
							if((attrid.length())==2)							
							{
								tmpattrstr="";
								tmpattrstr="30"+attrid;
								
							}
							if((attrid.length())==3)
							{
								tmpattrstr="";
								tmpattrstr="3"+attrid;
							}
						}
							//tc_strcpy(ToBeClsNameTmp,"HCVVCATTR01");
							//tc_strcat(ToBeClsClassName,moduleAddress);
					}
					if(VehCls.contains("UV_VAN"))
					{
							
							
						if(attrid.contains("240") || attrid.contains("241") || attrid.contains("242") || attrid.contains("243"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
							//tc_strcpy(tmpattrstr,"6");
							//tc_strcat(tmpattrstr,TcuaAttrIDDup);
							
						}
						else if(attrid.contains("100"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else if(attrid.contains("226"))
						{
							tmpattrstr="";
							tmpattrstr="6"+attrid;
						}
						else
						{
							if((attrid.length())==1)
							{
								tmpattrstr="";
								tmpattrstr="1000"+attrid;
								
							}
							if((attrid.length())==2)							
							{
								tmpattrstr="";
								tmpattrstr="100"+attrid;
								
							}
							if((attrid.length())==3)
							{
								tmpattrstr="";
								tmpattrstr="10"+attrid;
							}
							if((attrid.length())==5)
							{
								tmpattrstr="";
								tmpattrstr=attrid;
							}
						}
							//tc_strcpy(ToBeClsNameTmp,"HCVVCATTR01");
							//tc_strcat(ToBeClsClassName,moduleAddress);
					}
					 retdepattrid="8240";
					 //return retCmvrattrid;
				 }
			 }
		 //}
		 
			System.out.println("End in TechSpecUtil getReqClsattridFunc func with output for retdepattrid="+retdepattrid);
	return retdepattrid;
}



//public static String getDepEditedHashMapFunc(Object editedClsRow,KeyLOVDefinition2 lovDef, KeyLOVEntry[] keyLOVEntries2,Object value,Map<String,String> depmodifedvalueMap1) throws NotLoadedException, TCException
public static String getDepEditedHashMapFunc(Object editedClsRow,Object value,Map<String,String> depmodifedvalueMap1) throws NotLoadedException, TCException
{
	System.out.println("inside getDepEditedHashMapFunc func with input editedClsRow ="+editedClsRow );
	   //	 TCComponent[] contrlObjs = null;	
	//27/07/23 start
	String[] keyLOVIds2 = new String[1];
	//KeyLOVEntry keyLOVEntries1 = null;
	keyLOVIds2[0] ="-6241";
	com.teamcenter.services.rac.classification._2009_10.Classification.GetKeyLOVsResponse2 response=null;
	TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
	ClassificationService clsService = ClassificationService.getService(session);
	try {
		response=clsService.getKeyLOVs2(keyLOVIds2);
	} catch (ServiceException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	Map<String, KeyLOVDefinition2> keyLOVs = response.keyLOVs;
	System.out.println("*****Lov Details******* "+keyLOVs.size());
	Set<String> keys2 = keyLOVs.keySet();
	ArrayList<String> lovlist=new ArrayList<String>();
	
  KeyLOVDefinition2 lovDef1 = keyLOVs.get( "-6241" );
  KeyLOVEntry[] keyLOVEntries3 =lovDef1.keyLovEntries;
//  KeyLOVEntry[] keyLOVEntries4 =lovDef1.keyLovEntries;
	
	//27/07/2023 end
	
	
	
	   	KeyLOVEntry keyLOVEntriesNew =null;
			for(int kk=0;kk<keyLOVEntries3.length;kk++)
			{
								//KeyLOVEntry keyLOVEntriesNew = lovDef.keyLOVEntries[kk];
								 keyLOVEntriesNew = lovDef1.keyLovEntries[kk];
								 //String tmpattrb4put=((ClassificationTableLine) editedClsRow).getAttrID();
								//KeyLOVEntry[] keyLOVEntries2 = keyLOVEntriesNew;
								System.out.println("getDepEditedHashMapFunc GetKeyandValueFromLOV KeyLOV Entry Key     : "+keyLOVEntriesNew.lovKey);
								System.out.println("getDepEditedHashMapFunc GetKeyandValueFromLOV KeyLOV Entry Value   : "+keyLOVEntriesNew.lovValue);
								//ClassificationTableLine latesttabline=  ClassificationTableLine;
								
								String tmpattrb4put=((ClassificationTableLine) editedClsRow).getAttrID();
								String tmpvalb4put=null;
								
								//String newval=str.get(Integer.parseInt(value.toString()));
								String newval=((ClassificationTableLine) editedClsRow).getAttrValue();
								String tmpProlineval2=null;
								System.out.println("getDepEditedHashMapFunc newval="+newval +"222element   : "+editedClsRow);
								if(tmpattrb4put.contains("240") || tmpattrb4put.contains("241") || tmpattrb4put.contains("242") || tmpattrb4put.contains("243"))
								{
									if(tmpattrb4put.contains("240")==false)
									{
										tmpProlineval2=depmodifedvalueMap1.get("8240");
									}
									else
									{
										tmpProlineval2=newval;
									}
									System.out.println("getDepEditedHashMapFunc tmpProlineval2="+tmpProlineval2);
									if(keyLOVEntriesNew.lovKey.contains(tmpProlineval2))
									{
										if(keyLOVEntriesNew.lovValue.contains(newval))
										{
											//tmpvalb4put=((ClassificationTableLine) element).getAttrValue();
											tmpvalb4put=newval;
											System.out.println("getDepEditedHashMapFunc tmpattrb4put="+tmpattrb4put +" tmpvalb4put="+tmpvalb4put);
											depmodifedvalueMap1.put(tmpattrb4put, keyLOVEntriesNew.lovKey);
										}
									}
								}
			}
			
			 
		
		 
			System.out.println("End in TechSpecUtil getDepEditedHashMapFunc func with output for depmodifedvalueMap1="+depmodifedvalueMap1);
	return keyLOVEntriesNew.lovValue;
}


//End getDepEditedHashMapFunc


public static void ChldModuleToTaskAttachRel(TCComponentItemRevision DmlTask, TCComponentItemRevision ChildModule)
{
		 System.out.println("inside ChldModuleToTaskAttachRel function:::");
		 String taskID=null;
		 String ModId=null;
	 	TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
	    TCComponentItemRevision primaryobj= DmlTask;
		DataManagementService dmService= DataManagementService.getService(tcsession);
		try {
			if(primaryobj!=null) 
			{
			 taskID=primaryobj.getTCProperty("item_id").getDisplayableValue();
			}
			if(ChildModule!=null) 
			{
			 ModId=ChildModule.getTCProperty("item_id").getDisplayableValue();
			}
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("inside ChldModuleToTaskAttachRel taskID="+taskID +" ModId="+ModId);
		boolean modFoundInTask=false;
		TCComponent[] allprimaryObj=null;
		TCComponentItemRevision primaryObj=null; 
		 allprimaryObj=TechSpecUtil.SecondaryToPrimaryObjs("CMHasSolutionItem",ChildModule);
			if(allprimaryObj!=null)
			{
				for(int h=0;h<allprimaryObj.length;h++)
				{
					primaryObj=(TCComponentItemRevision) allprimaryObj[h];
				System.out.println("if in isObjectUpdatable Primary Object="+primaryObj.toDisplayString());
					String PrimarytaskID=null;
					
					try {
						PrimarytaskID=primaryObj.getTCProperty("item_id").getDisplayableValue();
					} catch (TCException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("in ChldModuleToTaskAttachRel PrimarytaskID="+PrimarytaskID);
					if(PrimarytaskID.equals(taskID)==true)
					{
						modFoundInTask=true;
					}
				}
			}
		 System.out.println("inside ChldModuleToTaskAttachRel function taskID::: "+taskID +" modFoundInTask="+ modFoundInTask);
		 if(modFoundInTask==false)
		 {
			 try {
				primaryobj.lock();
				CreateOrUpdateRelationsInfo[] crinfo =new CreateOrUpdateRelationsInfo[1];
				 crinfo[0]=new CreateOrUpdateRelationsInfo();
				 crinfo[0].clientId="taskTopartRel";
				 crinfo[0].primaryObject=primaryobj;
				 crinfo[0].relationType="CMReferences";
				 //crinfo[0].secondaryData=ChildModule;
				 SecondaryData data[]=new SecondaryData[1];
				 data[0]=new SecondaryData();
				 data[0].secondary=ChildModule;
				
				 crinfo[0].secondaryData=data;
				 dmService.createOrUpdateRelations(crinfo, false); 
				 primaryobj.save();
				 primaryobj.unlock();
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
		 }
		 else
		 {
			 System.out.println("inside ChldModuleToTaskAttachRel relation already exist for Module="+ ChildModule +"with taskID::: "+ taskID +" with modFoundInTask="+ modFoundInTask);
		 }
		 System.out.println("End  ChldModuleToTaskAttachRel function:::");
}

public static String getClsNmaeForModuleAdd(String projcode,String ModuleAdd) throws NotLoadedException, TCException
{
	System.out.println("inside getClsNmaeForModuleAdd func with input projcode="+projcode +"ModuleAdd="+ModuleAdd);
	            //Start query project
            String [] qryNames={"Name"};
			String [] qryValues={projcode};
			//int r;
			TCComponent[] projobjs=TechSpecUtil.queryObjTCUA("Qury_Project", qryNames,qryValues);
			//String VehCls=null;
			String VehCls=null;
			if(projobjs!=null)
			{
				for(int f=0;f<projobjs.length;f++)
				{
					TCComponent projobj=projobjs[f];
					VehCls="";
					VehCls=projobj.getPropertyDisplayableValue("t5_VehicleClass");
			
				}
			}
			
			System.out.println("VehCls="+VehCls +" ModuleAdd="+ModuleAdd);
			
			String modClsname=null;
			if(VehCls!=null)
			{	
				if(VehCls.equals("CAR"))
				{
					if(ModuleAdd.length()>6)
					{
						String tmpCarModAddrs=ModuleAdd.substring(ModuleAdd.length()-6, ModuleAdd.length());
						System.out.println("VehCls="+VehCls +" tmpCarModAddrs="+ModuleAdd);
					modClsname=tmpCarModAddrs;
					}
					else
					{
						modClsname=ModuleAdd;
					}
				}
//				else if(VehCls.equals("PRD"))
//				{
//					modClsname=ModuleAdd;
//				}
				else
				{
					if(VehCls.equals("PRD"))
					{
						modClsname=ModuleAdd;
					}
					else if(ModuleAdd!=null)
					{
						if(ModuleAdd.contains(VehCls))
						{
							modClsname=ModuleAdd;
						}
						else
						{
							modClsname=VehCls+ModuleAdd;
						}
					}
					else
					{
						modClsname=VehCls;
					}
				}
											
				
			}
			else
			{
				modClsname=ModuleAdd;
			}
			
			System.out.println("modClsname="+modClsname );
			
			//End query project 
			
			System.out.println("End in TechSpecUtil getClsNmaeForModuleAdd func with output modClsname="+modClsname +" for ModuleAdd="+ModuleAdd);
	return modClsname;
}

public String getVehClsNmaeForProj(String projcode) throws NotLoadedException, TCException
{
	System.out.println("inside getVehClsNmaeForProj func with input projcode="+projcode );
	            //Start query project
            String [] qryNames={"Name"};
			String [] qryValues={projcode};
			//int r;
			TCComponent[] projobjs=TechSpecUtil.queryObjTCUA("Qury_Project", qryNames,qryValues);
			String VehCls=null;
			if(projobjs!=null)
			{
				for(int f=0;f<projobjs.length;f++)
				{
					TCComponent projobj=projobjs[f];
					
					VehCls=projobj.getPropertyDisplayableValue("t5_VehicleClass");
			
				}
			}
			
			System.out.println("VehCls="+VehCls );
			
			
			//System.out.println("modClsname="+modClsname );
			
			//End query project 
			
			System.out.println("End in TechSpecUtil getVehClsNmaeForProj func with output VehCls="+VehCls );
	return VehCls;
}



    public List<String> splitString(String text, int length, String specialCharacters) {
        List<String> parts = new ArrayList<>();
        Pattern pattern = Pattern.compile("[" + Pattern.quote(specialCharacters) + "]");

        for (int i = 0; i < text.length(); i += length) {
            int end = Math.min(i + length, text.length());
            String sub = text.substring(i, end);
            String[] splitSub = pattern.split(sub);
            parts.addAll(Arrays.asList(splitSub));
        }
        return parts;
    }



public String getBusUnitForProj(String projcode) throws NotLoadedException, TCException
{
	System.out.println("inside getBusUnitForProj func with input projcode="+projcode );
	            //Start query project
            String [] qryNames={"Name"};
			String [] qryValues={projcode};
			//int r;
			TCComponent[] projobjs=TechSpecUtil.queryObjTCUA("Qury_Project", qryNames,qryValues);
			String ProjBusUnit=null;
			if(projobjs!=null)
			{
				for(int f=0;f<projobjs.length;f++)
				{
					TCComponent projobj=projobjs[f];
					
					ProjBusUnit=projobj.getPropertyDisplayableValue("t5_BussUnitType");
			
				}
			}
			
			System.out.println("ProjBusUnit="+ProjBusUnit );
			
			
			//System.out.println("modClsname="+modClsname );
			
			//End query project 
			
			System.out.println("End in TechSpecUtil getBusUnitForProj func with output ProjBusUnit="+ProjBusUnit );
	return ProjBusUnit;
}


	public static boolean ServiceDataError(final ServiceData data)
	{

		if(data.sizeOfPartialErrors() > 0)
		{
			for(int i = 0; i < data.sizeOfPartialErrors(); i++)
			{
				for(String msg :
					data.getPartialError(i).getMessages())
					System.out.println("ServiceDataError:"+msg);
			}

			return true;
		}

		return false;
	}

	public String getcheckClsAvlForModArs(String basemodars) throws NotLoadedException, TCException
	{
		System.out.println("inside getcheckClsAvlForModArs func with input basemodars="+basemodars );
		            //Start query project
		 AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		    TCSession session=(TCSession) app.getSession();
		    String tmpbasemodars=null;
		    //ICOCmvrAttrNo
		    String classdesc=null;
		    TCComponent[] contrlObjs = null;	
			 String qry="Control Objects..."; 
			 String retVehClassname=null;
			 //String []qryNames	= new String[]{"SUBSYSCD"};
			 String []qryNames	= new String[]{"Name","Delete Indicator"};
			 String []qryValues	= new String[]{"ClsCmvrattrID","0"};
			// try {
				 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
				 if(contrlObjs != null)
				 {
					 if(contrlObjs.length >0)
					 {
						 for(int c=0;c<contrlObjs.length;c++)
						 {
							 
							 

									 String subsyscdStr = "";
									 subsyscdStr = contrlObjs[c].getStringProperty("t5_SubSyscd");
									 System.out.println( "\ngetcheckClsAvlForModArs subsyscdStr==>" + subsyscdStr);
									 if(subsyscdStr.length()>0)
									 {
										 retVehClassname=subsyscdStr;
										 if(retVehClassname!=null)
										 {
											 if(retVehClassname.contains("CAR"))
											 {
												 tmpbasemodars=basemodars;

											 }
											 else
											 {
												 tmpbasemodars=retVehClassname+basemodars;
											 }
											 System.out.println( "\ngetcheckClsAvlForModArs tmpbasemodars==>" + tmpbasemodars);
											 try {
												 classdesc=new GetClassDescriptions().getClassDesc(session,tmpbasemodars);
												 //classdesc=new GetClassDescriptions().getClassDesc(session,basemodars);
											 } catch (ServiceException e) {
												 // TODO Auto-generated catch block
												 e.printStackTrace();
											 }
											 System.out.println( "\ngetcheckClsAvlForModArs classdesc==>" + classdesc);
											 if(classdesc!=null)											
											 {
												 break;
											 }
										 }
									 }
//									 else
//									 {
//										 retVehClassname="";
//									 }
									 System.out.println( "\n retVehClassname==>" + retVehClassname);
									 
									// return retCmvrattrid;
									
							 
						 }
					 }
			/*
			 * else { retCmvrattrid="8171"; //return retCmvrattrid; }
			 */
				 }
			 //}
			 
		    
		    
		    
		
				
				System.out.println("basemodars="+basemodars );
				
				
				//System.out.println("modClsname="+modClsname );
				
				//End query project 
				
				System.out.println("End in TechSpecUtil getcheckClsAvlForModArs func with output classdesc="+classdesc );
		return classdesc;
	}
	public static String getCmvrNoFrmVC(TCComponentItemRevision VCrev,String cmvrno) throws NotLoadedException, TCException
	{
		System.out.println("inside getCmvrNoFrmVC func with input VCrev="+VCrev );
		TCComponentItemRevision vehrev=null;          
		TCComponentItem VCMstr=VCrev.getItem();
		
		TCComponent[] revlist=VCMstr.getRelatedComponents("revision_list");// get revs
		
		if(revlist.length>0)
		{
			for(int i=revlist.length-1;i>=0;i--)
			{
				 vehrev= (TCComponentItemRevision) revlist[i];
				TCComponentItem CmvrObj=(TCComponentItem) vehrev.getReferenceProperty("t5_VehForCmvr");  // getReferenceValue();
				 cmvrno=null;
				if (CmvrObj!=null)
				{
				cmvrno=CmvrObj.getTCProperty("t5_CmvrNo").getDisplayableValue();
					if(cmvrno!=null)
					{
						break;
					}
				}
				System.out.println("cmvrno:----------  "+cmvrno);
			}
		}
				System.out.println("inside getCmvrNoFrmVC cmvrno="+cmvrno );
				
				//End query project 
		if(cmvrno==null)
		{
			cmvrno="NA";
		}
				System.out.println("End in TechSpecUtil getCmvrNoFrmVC func with output cmvrno="+cmvrno +" vehrev="+vehrev);
		return cmvrno;
	}
	
	public static TCComponentItemRevision SecondaryToPrimaryObj(String relName,TCComponent secondaryObj)
	{
		TCComponentItemRevision primaryobj=null;
		DataManagementService dmService= DataManagementService.getService(secondaryObj.getSession());
		ExpandGRMRelationsPref2 pref2=new ExpandGRMRelationsPref2();
		RelationAndTypesFilter filter=new RelationAndTypesFilter();
		// filter.otherSideObjectTypes=new String[] {"T5_ChangeTaskRevision"};
		filter.relationTypeName=relName;
		pref2.returnRelations=true;
		pref2.info=new RelationAndTypesFilter[]{filter};
		ExpandGRMRelationsResponse2 response=   dmService.expandGRMRelationsForSecondary(new TCComponent []{secondaryObj}, pref2);
		if(ServiceDataError(response.serviceData)==false)
		{
			ExpandGRMRelationsOutput2[] out2=response.output;
			System.out.println("out2 length="+out2.length);
			for(int p1=0;p1<out2.length;p1++)
			{
				ExpandGRMRelationsData2[] data=out2[p1].relationshipData;
				System.out.println("data length="+data.length);
				for(int p2=0;p2<data.length;p2++)
				{
					ExpandGRMRelationship[] rel=data[p2].relationshipObjects;
					System.out.println("rel length="+rel.length);

					for(int p3=0;p3<rel.length;p3++)
					{
						primaryobj=(TCComponentItemRevision) rel[p3].otherSideObject;
						System.out.println("Other side object="+primaryobj.toDisplayString());

						System.out.println("Rel object="+rel[p3].relation.toDisplayString());
						return primaryobj;
					}

				}

				// System.out.println("Task name="+taskrev.toDisplayString());
			}
		}
		return primaryobj;
	}

	public static TCComponentItem SecondaryToPrimary(String relName,TCComponentItemRevision secondaryObj)
	{
		TCComponentItem primaryobj=null;
		System.out.println("inside SecondaryToPrimary func with secondaryObj="+secondaryObj.toDisplayString());
		DataManagementService dmService= DataManagementService.getService(secondaryObj.getSession());
		ExpandGRMRelationsPref2 pref2=new ExpandGRMRelationsPref2();
		RelationAndTypesFilter filter=new RelationAndTypesFilter();
		// filter.otherSideObjectTypes=new String[] {"T5_ChangeTaskRevision"};
		filter.relationTypeName=relName;
		pref2.returnRelations=true;
		pref2.info=new RelationAndTypesFilter[]{filter};
		ExpandGRMRelationsResponse2 response=   dmService.expandGRMRelationsForSecondary(new TCComponent []{secondaryObj}, pref2);
		if(ServiceDataError(response.serviceData)==false)
		{
			ExpandGRMRelationsOutput2[] out2=response.output;
			System.out.println("out2 length="+out2.length);
			for(int p1=0;p1<out2.length;p1++)
			{
				ExpandGRMRelationsData2[] data=out2[p1].relationshipData;
				System.out.println("data length="+data.length +"data= "+data.toString());
				for(int p2=0;p2<data.length;p2++)
				{
					ExpandGRMRelationship[] rel=data[p2].relationshipObjects;
					System.out.println("rel length="+rel.length + " relname="+data[p2].relationName);
					
					for(int p3=0;p3<rel.length;p3++)
					{
						primaryobj=(TCComponentItem) rel[p3].otherSideObject;
						System.out.println("Other side object="+primaryobj.toDisplayString());

						System.out.println("Rel object="+rel[p3].relation.toDisplayString());
						return primaryobj;
					}

				}

				// System.out.println("Task name="+taskrev.toDisplayString());
			}
		}
		System.out.println("End SecondaryToPrimary func !");
		return primaryobj;
	}
	
	public static String getDeprattridFunc(String InpAttrId) throws NotLoadedException, TCException
	{
		System.out.println("inside getDeprattridFunc func with input InpAttrId ="+InpAttrId);
		   	 TCComponent[] contrlObjs = null;	
			 String VehCls=null;
			 String qry="Control Objects..."; 
			 String retDepattrid=null;
			 //String []qryNames	= new String[]{"SUBSYSCD"};
			 String []qryNames	= new String[]{"SUBSYSCD","Name","Delete Indicator"};
			 String []qryValues	= new String[]{InpAttrId,"ClsDepAttrLOV","0"};
			// try {
				 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
				 if(contrlObjs != null)
				 {
					 if(contrlObjs.length >0)
					 {
						 for(int c=0;c<contrlObjs.length;c++)
						 {
							 String ctrlClass = "";
							 ctrlClass = contrlObjs[c].getStringProperty("object_type");
							 if(!ctrlClass.equals("T5_ControlObject"))
							 {
								 System.out.println("Not a Control Object Class");
								 continue;
							 }
							 else
							 {

									 String syscdStr = "";
									 syscdStr = contrlObjs[c].getStringProperty("t5_Syscd");
									 System.out.println( "\n syscdStr==>" + syscdStr);
									 if(syscdStr.length()>0)
									 {
										 retDepattrid=syscdStr;
									 }
									 
									 System.out.println( "\n retDepattrid==>" + retDepattrid);
									 
									// return retDepattrid;
									
							 }
						 }
					 }
					 
				 }
			 //}
			 
				System.out.println("End in TechSpecUtil getDeprattridFunc func with output for retDepattrid="+retDepattrid);
		return retDepattrid;
	}
	
	//Start getDepEditedHashMapFunc 

	public static String getTSClsAttrIDFunc(String VehCls,String attrid) throws NotLoadedException, TCException
	{
		System.out.println("inside getTSClsAttrIDFunc func with input VehCls ="+VehCls + " attrid="+attrid );
		   	 TCComponent[] contrlObjs = null;	
			 String qry="Control Objects..."; 
			 String retdepattrid=null;
			 String tmpattrstr=null;
			 String []qryNames	= new String[]{"SUBSYSCD","Name","Delete Indicator"};
			 String []qryValues	= new String[]{VehCls,"ClsAttrId4TCEAttr","0"};
			// try {
				 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
				 if(contrlObjs != null)
				 {
//					 String infostr="";
//					String info;
//					String info1;
//					int r1 = 0;
//					 for(int f=0;f<contrlObjs.length;f++)
//						{
//							TCComponent objcntrl=contrlObjs[f];

					//String[] infoattr=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_userinfo10"};

					//int len=infoattr.length;

					for(int r=0;r<contrlObjs.length ;r++)
					{
						 String userinfo1 = "";
						 String userinfo2 = "";
						 String syscd = "";
						  userinfo1= contrlObjs[r].getStringProperty("t5_Userinfo1");
						 System.out.println( "\n getTSClsAttrIDFunc userinfo1==>" + userinfo1);
						 userinfo2 = contrlObjs[r].getStringProperty("t5_Userinfo2");
						 System.out.println( "\n getTSClsAttrIDFunc userinfo2==>" + userinfo2);
						  syscd = contrlObjs[r].getStringProperty("t5_Syscd");
						 System.out.println( "\n getTSClsAttrIDFunc syscd==>" + syscd);
						 //if(VehCls.contains("CAR"))
						// {
						 if(attrid.contains("240") || attrid.contains("241") || attrid.contains("242") || attrid.contains("243"))
							{
								tmpattrstr="";
								tmpattrstr=userinfo1+attrid;
								//tc_strcpy(tmpattrstr,"6");
								//tc_strcat(tmpattrstr,TcuaAttrIDDup);
								
							}
							else if(attrid.contains("100"))
							{
								tmpattrstr="";
								tmpattrstr=userinfo1+attrid;
							}
							else if(attrid.contains("226"))
							{
								tmpattrstr="";
								tmpattrstr=userinfo1+attrid;
							}
							else
							{
								if((attrid.length())==1)
								{
									tmpattrstr="";
									tmpattrstr=syscd+"00"+attrid;
									
								}
								if((attrid.length())==2)							
								{
									tmpattrstr="";
									tmpattrstr=syscd+"0"+attrid;
									
								}
								if((attrid.length())==3)
								{
									tmpattrstr="";
									tmpattrstr=syscd+attrid;
								}
								if((attrid.length())==4)
								{
									tmpattrstr="";
									tmpattrstr=attrid;
								}
							}

						// }
					}
					 
						//}
				 }
				 System.out.println("End in TechSpecUtil getTSClsAttrIDFunc func with output for tmpattrstr="+tmpattrstr);
		return tmpattrstr;
	}
	
	public static String getCmvrattridFunc(String VehCls) throws NotLoadedException, TCException
	{
		System.out.println("inside getCmvrattridFunc func with input VehCls ="+VehCls );
		   	 TCComponent[] contrlObjs = null;	
			 String qry="Control Objects..."; 
			 String retCmvrattrid=null;
			 //String []qryNames	= new String[]{"SUBSYSCD"};
			 String []qryNames	= new String[]{"SUBSYSCD","Name","Delete Indicator"};
			 String []qryValues	= new String[]{VehCls,"ClsCmvrattrID","0"};
			// try {
				 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
				 if(contrlObjs != null)
				 {
					 if(contrlObjs.length >0)
					 {
						 for(int c=0;c<contrlObjs.length;c++)
						 {
							 String ctrlClass = "";
							 ctrlClass = contrlObjs[c].getStringProperty("object_type");
							 if(!ctrlClass.equals("T5_ControlObject"))
							 {
								 System.out.println("Not a Control Object Class");
								 continue;
							 }
							 else
							 {

									 String syscdStr = "";
									 syscdStr = contrlObjs[c].getStringProperty("t5_Syscd");
									 System.out.println( "\n syscdStr==>" + syscdStr);
									 if(syscdStr.length()>0)
									 {
										 retCmvrattrid=syscdStr;
									 }
									 else
									 {
										 retCmvrattrid="8171";
									 }
									 System.out.println( "\n retCmvrattrid==>" + retCmvrattrid);
									 
									// return retCmvrattrid;
									
							 }
						 }
					 }
					 else
					 {
						 retCmvrattrid="8171";
						 //return retCmvrattrid;
					 }
				 }
			 //}
			 
				System.out.println("End in TechSpecUtil getCmvrattridFunc func with output for retCmvrattrid="+retCmvrattrid);
		return retCmvrattrid;
	}
	
	// Get Hybrid VC availability status 
	public boolean getHybridVCFlag(TCSession tcsession,TCComponentItemRevision assemblyRevision) throws TCException, NotLoadedException
	{

		
		boolean retstate=false;
		String ChildParttype=null;
		
		
		//Newly added
		
		
		
		
		String [] qryNames={"SYSCD","Delete Indicator"};
		String [] qryValues={"HybridPartType","0"};
		//int r;
		TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
		String info=null;
		String retval="";
		String infostr="";
		int r;
		String infostr1="";
		int r1;
		if(objvec!=null)
		{
			for(int f=0;f<objvec.length;f++)
			{
				TCComponent objcntrl=objvec[f];
				
				
				String[] infoattr=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_Userinfo10"};

				int len=infoattr.length;

				for(r=len-1;r>=0;r--)
				{

					info=objcntrl.getPropertyDisplayableValue(infoattr[r]);
		
					if(info==null||info.isEmpty()==true||info.trim().length()==0) continue;

					else
						infostr+=info.toString()+",";
						//infostr=info.toString()+",";

				
					 //info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
					
				}
				
				
		
			}
		}
			System.out.println("Final HybridAllowPartType infostr="+infostr );
			 
			String [] qryNames1={"SYSCD","Delete Indicator"};
			String [] qryValues1={"HybridSkipPartType","0"};
			
			TCComponent[] objvec1=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames1,qryValues1);
			
			String info1=null;
			String retval1="";


			if(objvec1!=null)
			{
				for(int f1=0;f1<objvec1.length;f1++)
				{
					TCComponent objcntrl1=objvec1[f1];
					
					
					String[] infoattr1=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_Userinfo10"};

					int len1=infoattr1.length;

					for(r1=len1-1;r1>=0;r1--)
					{

						info1=objcntrl1.getPropertyDisplayableValue(infoattr1[r1]);
			
						if(info1==null||info1.isEmpty()==true||info1.trim().length()==0) continue;

						else
							infostr1+=info1.toString()+",";
							//infostr=info.toString()+",";

					
						 //info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
						
					}
					
					
			
				}
				
			}
		//End newly change
		
		System.out.println("final HybridSkipPartType infostr1="+infostr1 );
		String childId=assemblyRevision.getPropertyDisplayableValue("item_id");
		String InpChildParttype=assemblyRevision.getPropertyDisplayableValue("t5_PartType");
		System.out.println("InpChildParttype ::"+InpChildParttype +" childId="+childId);
		
		
				
		//if(InpChildParttype.equals("Technical Part List") || InpChildParttype.equals("T"))
		if(infostr1.contains(InpChildParttype))
		{
			System.out.println("no further structure expansion for ChildParttype in getHybridVCFlag  func::"+InpChildParttype +" for childId="+childId);
			retstate= true;
			return retstate;
		}
		
		if(infostr.contains(InpChildParttype))
		 {
			System.out.println("no further structure expansion for ChildParttype, in  getHybridVCFlag  func::"+InpChildParttype +" for childId="+childId);
			retstate= false;
			return retstate;
		 }
		
//		if(InpChildParttype.equals("Module") || InpChildParttype.equals("M")|| InpChildParttype.equals("CAD Module"))
//		{
//			System.out.println("no further structure expansion for ChildParttype, in  getHybridVCFlag  func::"+InpChildParttype +" for childId="+childId);
//			retstate= false;
//			return retstate;
//		}
		if(InpChildParttype.equals("Vehicle") || InpChildParttype.equals("Vehicle Combination") || InpChildParttype.equals("Configurable VC")|| InpChildParttype.equals("Vehicle Combination CR"))
		{
			
			String VcBomType=assemblyRevision.getPropertyDisplayableValue("t5_Part_Info");
			System.out.println("VcBomType ::"+VcBomType );
			
			if(VcBomType.contains("TPL")|| VcBomType.contains("HYBRID"))
			{
				System.out.println("in getHybridVCFlag, no further structure expansion for this VC as HYBRID/TPL found with BOM Type ::"+VcBomType );
				retstate= true;
				return retstate;
			}
			
			if(VcBomType.contains("MODULAR"))
			{
				System.out.println("in getHybridVCFlag, no further structure expansion for this VC as MODULAR found with BOM Type ::"+VcBomType );
				retstate= false;
				return retstate;
			}
			
			TCComponent[] bvr = assemblyRevision.getRelatedComponents("structure_revisions");// get bvrs



			System.out.println("getHybridVCFlag Listing All Revision Rule");

			TCComponentRevisionRule[] revrule=TCComponentRevisionRule.listAllRules(tcsession);
			//String revrulename="Latest Working";
			//String revrulename="ERC release and above";

			String revrulename=new TechSpecUtil().gettechspecrevrule("techspecrevrule");
			System.out.println("output revrulename="+revrulename);
			if(revrulename==null)
			{
				revrulename="ERC release and above";
			}
			TCComponentRevisionRule currentrevrule=null;
			for(int j=0;j<revrule.length;j++)
			{

				if(revrulename.equals(revrule[j].getProperty("object_name")))
				{
					currentrevrule=revrule[j];
					break;
				}

				//System.out.println(revrulename);

			}

			System.out.println("getHybridVCFlag Found the Revision Rule "+revrulename);

			TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
			TCComponentBOMWindow bomWin = bowWinType.create(currentrevrule);       // create bom window configured with the default revision rule 

			TCComponentBOMLine bl= bomWin.setWindowTopLine(null, assemblyRevision,null, null);

			if(bl!=null)
			{

				int bomsize=0;
				bomsize=bl.getChildren().length;

				System.out.println("b4 getHybridVCFlag call fun ppassemblyRevision= "+assemblyRevision.toDisplayString() +" bomsize=" +bomsize); 


				//System.out.println("=========================================Getting TCUA  BOM/Global Alternate=============");
				if(bomsize<=0)
				{
					System.out.println("found getHybridVCFlag ppassemblyRevision ::"+assemblyRevision.toDisplayString());
					retstate= true;
				}
				if (bl.hasChildren()){

					AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

					//TCComponentBOMLine[] childContext =bl.getPackedLines();
					System.out.println(" getHybridVCFlag func BOM Children count is "+childContext.length);

					System.out.println("=======================Listing Children=============");
					retstate= false;
					for(int i = 0; i < childContext.length; i++){
						//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
						TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
						//TCComponentItem item = child.getItem();
						TCComponentItemRevision item = child.getItem().getLatestItemRevision();
						TCComponentItemRevision citem = bl.getItem().getLatestItemRevision();
						//System.out.println("getHybridVCFlag func child ::"+item.getPropertyDisplayableValue("item_id"));
						System.out.println("getHybridVCFlag func child obj name::"+item.getPropertyDisplayableValue("object_string"));
						childId=item.getPropertyDisplayableValue("item_id");
						//TCComponentItemRevision childItemrev=child.getItemRevision();
						// if(child!=null)
						if(item!=null)
						{



							// ChildParttype=child.getPropertyDisplayableValue("t5_PartType");
							ChildParttype=item.getPropertyDisplayableValue("t5_PartType");
							// System.out.println("getHybridVCFlag func ChildParttype ::"+ChildParttype +" childId="+childId);
							// if(ChildParttype.equals("Technical Part List") || ChildParttype.equals("T"))
							if(ChildParttype.length()>0)
							{
								if (infostr1 != null && ChildParttype != null && infostr1.contains(ChildParttype))
								{
									System.out.println("found getHybridVCFlag ChildParttype ::"+ChildParttype +" for childId="+childId);
									retstate= true;
									break;
								}
							}
						}



					}

					System.out.println("====================END of getHybridVCFlag func with output = "+retstate);
				}
			}
		}
		return retstate;
	}

	
	public boolean bypassUsrfunc(String sessionuser,String bypasssubsyscd) {
		// TODO Auto-generated method stub
		String CHBbypassUser=null;
		//tempCHCHBbypassUser = new HashSet<String>();
		//String[] CHCHBbypassUserArr = null;
		TCComponent[] contrlObjs = null;
		boolean retstate=false;
		/* String qry="ControlObjects"; 	

		 String []qryNames	= new String[]{"SYSCD"};
		 String []qryValues	= new String[]{plant};
		 */
		 String qry="Control Objects..."; 
		 String []qryNames	= new String[]{"SUBSYSCD"};
		 String []qryValues	= new String[]{bypasssubsyscd};
		 try {
			 contrlObjs =(TCComponent[])queryObjTCUA(qry, qryNames, qryValues);
			 if(contrlObjs != null)
			 {
				 if(contrlObjs.length >0)
				 {
					 for(int c=0;c<contrlObjs.length;c++)
					 {
						 String ctrlClass = "";
						 ctrlClass = contrlObjs[c].getStringProperty("object_type");
						 if(!ctrlClass.equals("T5_ControlObject"))
						 {
							 System.out.println("Not a Control Object Class");
							 continue;
						 }
						 else
						 {

								 String syscdStr = "";
								 syscdStr = contrlObjs[c].getStringProperty("t5_Syscd");
								 String plantFromCtr = "";
								 plantFromCtr = contrlObjs[c].getStringProperty("t5_Userinfo1");
								 System.out.println("t5_Userinfo1==>" + plantFromCtr + "\nsyscdStr==>" + syscdStr);
								 // if(syscdStr.equals(plant))
								 
									 System.out.println("syscd==>" + syscdStr + "\nSubsyscdStr==>" + bypasssubsyscd +" sessionuser="+sessionuser);
									 CHBbypassUser ="";
									 CHBbypassUser = contrlObjs[c].getStringProperty("t5_Syscd");
									 System.out.println("CHBbypassUser==>" + CHBbypassUser);
									//if (CHBbypassUser.contains(sessionuser))
									 if (sessionuser.contains(CHBbypassUser))
									{
										 System.out.println("CHBbypassUser==>" + CHBbypassUser +"sessionuser="+sessionuser);
										 retstate= true;
										 break;
									}
									else
									{
										retstate= false;
									}
									 
								 
								
							 
							 
						 }
					 }
				 }
			 }
			 
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 System.out.println("End of Function bypassfunc");
		 return retstate;
	}
	//End
	
	public static TCComponent[] SecondaryToPrimaryObjs(String relName,TCComponent secondaryObj)
	{
		ArrayList<TCComponent> all_otherside=new ArrayList<TCComponent>();
		TCComponent primaryobj=null;
		DataManagementService dmService= DataManagementService.getService(secondaryObj.getSession());
		ExpandGRMRelationsPref2 pref2=new ExpandGRMRelationsPref2();
		RelationAndTypesFilter filter=new RelationAndTypesFilter();
		filter.otherSideObjectTypes=new String[] {"T5_ChangeTaskRevision"};
		filter.relationTypeName=relName;
		pref2.returnRelations=true;
		pref2.info=new RelationAndTypesFilter[]{filter};
		ExpandGRMRelationsResponse2 response=   dmService.expandGRMRelationsForSecondary(new TCComponent []{secondaryObj}, pref2);
		if(ServiceDataError(response.serviceData)==false)
		{
			ExpandGRMRelationsOutput2[] out2=response.output;
			System.out.println("out2 length="+out2.length);
			for(int p1=0;p1<out2.length;p1++)
			{
				ExpandGRMRelationsData2[] data=out2[p1].relationshipData;
				System.out.println("data length="+data.length);
				for(int p2=0;p2<data.length;p2++)
				{
					ExpandGRMRelationship[] rel=data[p2].relationshipObjects;
					System.out.println("rel length="+rel.length);

					for(int p3=0;p3<rel.length;p3++)
					{
						primaryobj= rel[p3].otherSideObject;
						System.out.println("Other side object="+primaryobj.toDisplayString());

						System.out.println("Rel object="+rel[p3].relation.toDisplayString());
						all_otherside.add( primaryobj);
					}

				}

				// System.out.println("Task name="+taskrev.toDisplayString());
			}
		}
		
	
		return all_otherside.toArray(new TCComponent[all_otherside.size()]);
	}
	public Set<String> queryProjVehClsValueInDB(String queryname ,String []qryNames,String []qryValues) throws TCException
	 {

		 Set<String> ProjVehClsSet = new TreeSet<String>();
		 
		 System.out.println(" In Query for Index Number For ::"+queryname);  
		 TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();		        
		 try {
			 System.out.println(" Before setting the session ::");  
			 TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");                     
			 TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);//"Item...");
			 System.out.println(" After setting the session ::");                                                 
			 TCComponent []qryResults          = null;

			 if (mmcomponentquery != null)				     
			 {
				 System.out.println(" Results found ::"); 
				 qryResults=mmcomponentquery.execute(qryNames,qryValues);
			 }

			 if(qryResults.length>0)
			 {
				 for(int i=0;i<qryResults.length;i++)
				 {
					// System.out.println(i+":"+qryResults[i].getTCProperty("user_name").getDisplayableValue());	
					// plannerlist.add(qryResults[i].getTCProperty("user_name").getDisplayableValue());
					System.out.println(i+":"+qryResults[i].getTCProperty("t5_VehicleClass").getDisplayableValue());	
					 
					 ProjVehClsSet.add(qryResults[i].getTCProperty("t5_VehicleClass").getDisplayableValue());
					// System.out.println(i+":"+qryResults[i].getTCProperty("object_string").getDisplayableValue());
					// ProjVehClsSet.add(qryResults[i].getTCProperty("object_string").getDisplayableValue());
				 }	
				 System.out.println("FOUND  In Query for Index number for CHBarrel ::"+qryNames[0].toString());							
			 }				

		 } catch (TCException e2) {
			 // TODO Auto-generated catch block
			 e2.printStackTrace();
		 }

		 return ProjVehClsSet; 
	 }
	
	private void getVehClsValList()
	{
		ProjVehClsValueSet = null;
		 String qry="Qury_Project"; 	

		 String []qryNames	= new String[]{"Name"};
		 String []qryValues	= new String[]{"*"};
		 
/*			 String qry="UserFind"; 	

		 String []qryNames	= new String[]{"Id"};
		 String []qryValues	= new String[]{"*"};*/
		 try {
			ProjVehClsValueSet = queryProjVehClsValueInDB(qry,qryNames,qryValues);
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 System.out.println("Returned from function...\nno of IndexValue====>" + ProjVehClsValueSet.size());     
		
	}

	public static TCComponentItemRevision SecondaryToPrimaryObjs1(String relName,TCComponent secondaryObj)
	{
		TCComponentItemRevision primaryobj=null;
		DataManagementService dmService= DataManagementService.getService(secondaryObj.getSession());
		ExpandGRMRelationsPref2 pref2=new ExpandGRMRelationsPref2();
		RelationAndTypesFilter filter=new RelationAndTypesFilter();
		// filter.otherSideObjectTypes=new String[] {"T5_ChangeTaskRevision"};
		filter.relationTypeName=relName;
		pref2.returnRelations=true;
		pref2.info=new RelationAndTypesFilter[]{filter};
		ExpandGRMRelationsResponse2 response=   dmService.expandGRMRelationsForSecondary(new TCComponent []{secondaryObj}, pref2);
		if(ServiceDataError(response.serviceData)==false)
		{
			ExpandGRMRelationsOutput2[] out2=response.output;
			System.out.println("out2 length="+out2.length);
			for(int p1=0;p1<out2.length;p1++)
			{
				ExpandGRMRelationsData2[] data=out2[p1].relationshipData;
				System.out.println("data length="+data.length);
				for(int p2=0;p2<data.length;p2++)
				{
					ExpandGRMRelationship[] rel=data[p2].relationshipObjects;
					System.out.println("rel length="+rel.length);

					for(int p3=0;p3<rel.length;p3++)
					{
						primaryobj=(TCComponentItemRevision) rel[rel.length-1].otherSideObject;
						System.out.println("Other side object="+primaryobj.toDisplayString());

						System.out.println("Rel object="+rel[p3].relation.toDisplayString());
						return primaryobj;
					}

				}

				// System.out.println("Task name="+taskrev.toDisplayString());
			}
		}
		return primaryobj;
	}
	
	
	
	 public static TCComponent createWO(TCSession tcSession, String classname,TreeMap<String,String> propvalues) throws ServiceException 
	    {
		 DataManagementService	dmService = DataManagementService.getService(tcSession);
	    	CreateIn woDef = new CreateIn();
	        CreateInput itemRevisionDef = new CreateInput();
	        TCComponentUnitOfMeasure uom1= new TCComponentUnitOfMeasure();

	 
	        woDef.data.boName = classname;
	        
	       
	        
	        
	        for (Map.Entry<String, String> entry : propvalues.entrySet())
	        {
	            System.out.println("inside createWO "+entry.getKey() + "/" + entry.getValue());
	            
	           
	            woDef.data.stringProps.put(entry.getKey(), entry.getValue());
	            
	        }
	        
	      woDef.data.boolProps.put("t5_DelInd", false);
	        
	  
	        
	        
	 
	        try
	        {
	        	CreateResponse createObjResponse = dmService.createObjects(new CreateIn[]{ woDef });
	 
	            if(!ServiceDataError(createObjResponse.serviceData))
	            {
	            	for(CreateOut out : createObjResponse.output)
	                {
	            		for(TCComponent obj : out.objects)
	                    {
	            			
	            			
	            			 return obj;
	                    }
	                }
	            }
	        }
	        catch (ServiceException e)
	        {
	        	MessageBox.post(e.getMessage(), "ERROR MESSAGE", MessageBox.ERROR);
				e.printStackTrace();
	        }
	        return null;
	    }
	
	public static TCComponent []  queryObjTCUA(String queryname,String [] qryNames,String [] qryValues) throws TCException
	{

		
		TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		
		com.teamcenter.rac.kernel.TCComponentContextList imancomponentcontextlist = null;
		

		TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");

		TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);

		TCComponent []qryResults	= null;
		
		


		if (mmcomponentquery != null)

		{
			System.out.println(" In Query for qryValues ::"+qryValues[0]);
			System.out.println(" In Query for qryNames ::"+qryNames[0]);
			
			qryResults=mmcomponentquery.execute( qryNames, qryValues );

			
		}
		return qryResults;

	}
	
	

	//Qry Object based on saved query name & their object name
	
	public static TCComponent qryObj(TCSession session,String SavedQryName,String argsname,String argsvalue) throws TCException
	{
		
		//TCSession session;
		//proj="5042";		
		//String qryprojId = TempId.concat("*");
		System.out.println("Inside function qryObj");
        System.out.println("\nSavedQryName="+SavedQryName +"argsname="+argsname +"argsvalue: "+argsvalue);
        String[] qvalue = { argsvalue };
        String[] qname = { argsname };
        //System.out.println("proj Number: "+proj);
        TCComponentQueryType qtype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
        System.out.println("After getTypeComponent");
        TCComponentQuery query = (TCComponentQuery)qtype.find(SavedQryName);
        System.out.println("After qtype.find");
        TCComponent[] Qcomp = query.execute(qname, qvalue);
        System.out.println("Number of SavedQryName found in database =" + Qcomp.length);
        	for(int i=0;i<Qcomp.length;i++)
        	{
        		System.out.println("SavedQryName FOUND BY QUERY "+Qcomp[i].toString());	        		        		
        	}
        
        if (Qcomp.length > 0)
        {
        	//int					latestObjindex			= -1;
        	//for(int i=0;i<Qcomp.length;i++)
        	//{
        		System.out.println("SavedQryName FOUND BY QUERY "+Qcomp[0].toString());	      
        		
        		return (TCComponent) Qcomp[0];
        }
        
        return null;
		
	}
	
	//End Qry object
	
	public static String removeDuplicates1(String input,String newval,ArrayList<String> ToBeattrsList)
	{
	    String result = "";
	    String TempStr= "";
	    String inputDup=input;
	    String newvalDup=newval;
	    int count=0;
	    System.out.println("\n inside removeDuplicates with input="+input +" newval= "+newval +"ToBeattrsList="+ToBeattrsList);
	    StringTokenizer stkinfostr=new StringTokenizer(inputDup,",");
	    System.out.println("\n inside removeDuplicates with stkinfostr="+stkinfostr);
	    //StringTokenizer stkinfostr1=new StringTokenizer(newvalDup,":");
	    //System.out.println("\n inside removeDuplicates tokenize for new value="+stkinfostr1);
	    String attrTochk=null;
	   
	    
	    
	    
		while(stkinfostr.hasMoreElements())
		{
			
			String attrs=stkinfostr.nextToken();
			System.out.println("\n inside removeDuplicates with attrs="+attrs);
			 for(int l=0;l<ToBeattrsList.size();l++)
				{
			    	attrTochk=ToBeattrsList.get(l);
			    	System.out.println("\n inside removeDuplicates attrTochk ="+attrTochk);
			    	if(attrs.contains(attrTochk))
			    	{
			    		System.out.println("\n inside removeDuplicates removing duplicates ="+attrs);
			    		attrs="";
			    	}
				}
			 System.out.println("\n inside removeDuplicates after remove duplicate attrs="+attrs);
			if(attrs.contains(":"))
			{
				if(attrs.contains(attrTochk)==false)
				{
					if(count==0)
					{
						String firsttmpattrs=attrs;
						System.out.println("\n inside removeDuplicates with firsttmpattrs="+firsttmpattrs);
						TempStr=attrs;

					}


					System.out.println("\n inside removeDuplicates with TempStr="+TempStr +" attrs="+attrs + "count="+count);
					if(count>0)
					{
						String attrsDup=attrs;
						String attrid=attrsDup.substring(0, 4);
						System.out.println("\n attrid="+attrid);
						//if(TempStr.contains(attrid)==false)
						if(TempStr.contains(attrid)==false && newval.contains(attrid)==false)
						{
							TempStr=TempStr+","+attrs;
						}
					}
				}
				count++;
			
			
			}
			
		}
		System.out.println("\n final TempStr="+TempStr);
	    
	   if(TempStr!=null)
	   {
		   result=TempStr;
	   }
	  
	    return result;
	}
	public static String optimizeDuplicity(
			String input,
			String newval,
			ArrayList<String> toBeAttrsList) 
	{

		if (input == null || input.isEmpty()) {
			return "";
		}

		StringBuilder result = new StringBuilder();
		Set<String> blockedAttrs = new HashSet<>(toBeAttrsList);
		Set<String> seenAttrIds = new HashSet<>();

		String[] tokens = input.split(",");

		for (String attr : tokens) {

			// Skip attributes that match blocked list
			boolean skip = false;
			for (String block : blockedAttrs) {
				if (attr.contains(block)) {
					skip = true;
					break;
				}
			}
			if (skip) continue;

			// Process only key:value entries
			if (!attr.contains(":")) continue;

			// Extract attribute ID safely
			if (attr.length() < 4) continue;
			String attrId = attr.substring(0, 4);

			// Skip duplicates and values present in newval
			if (seenAttrIds.contains(attrId) || newval.contains(attrId)) {
				continue;
			}

			// Append to result
			if (result.length() > 0) {
				result.append(",");
			}
			result.append(attr);

			seenAttrIds.add(attrId);
		}

		return result.toString();
	}
	
	
	public void UpdateData(
	        TCComponent objcntrl,
	        TreeMap<String, Object> namevalueP2)
	        throws NotLoadedException, TCException {

	    final int MAX_LEN = 195;
	    final String[] INFO_ATTRS = {
	            "t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_userinfo10"
	    };

	    /* -----------------------------------
	     * Step 1: Build attrmodids & modAttrList
	     * ----------------------------------- */
	    StringBuilder attrmodids = new StringBuilder();
	   // List<String> modAttrsList = new ArrayList<>();
	    ArrayList<String> modAttrsList =new ArrayList<String>();
	    for (Map.Entry<String, Object> e : namevalueP2.entrySet()) {
	        attrmodids.append(",").append(e.getKey()).append(":").append(e.getValue());
	        modAttrsList.add(e.getKey());
	    }

	    /* -----------------------------------
	     * Step 2: Read existing values
	     * ----------------------------------- */
	    StringBuilder existing = new StringBuilder();
	    for (String attr : INFO_ATTRS) {
	        String val = objcntrl.getPropertyDisplayableValue(attr);
	        if (val == null || val.trim().isEmpty()) break;
	        existing.append(val).append(",");
	    }

	    /* -----------------------------------
	     * Step 3: Clean existing properties
	     * ----------------------------------- */
	    objcntrl.lock();
	    for (String attr : INFO_ATTRS) {
	        objcntrl.setProperty(attr, "");
	    }
	    objcntrl.save();
	    objcntrl.unlock();

	    /* -----------------------------------
	     * Step 4: Optimize duplicity
	     * ----------------------------------- */
	    String optimized = "";
	    if (existing.length() > 0) {
	        optimized = TechSpecUtil.optimizeDuplicity(
	                existing.toString(),
	                attrmodids.toString(),
	                modAttrsList
	        );
	    }

	    /* -----------------------------------
	     * Step 5: Write back with size handling
	     * ----------------------------------- */
	    objcntrl.lock();

	    int index = 0;
	    StringBuilder buffer = new StringBuilder();

	    if (optimized != null && !optimized.isEmpty()) {
	        buffer.append(",").append(optimized);
	    }

	    for (Map.Entry<String, Object> e : namevalueP2.entrySet()) {
	        String chunk = "," + e.getKey() + ":" + e.getValue();

	        if (buffer.length() + chunk.length() >= MAX_LEN) {
	            objcntrl.setProperty(INFO_ATTRS[index++], buffer.toString());
	            buffer.setLength(0);
	        }
	        buffer.append(chunk);
	    }

	    if (buffer.length() > 0 && index < INFO_ATTRS.length) {
	        objcntrl.setProperty(INFO_ATTRS[index], buffer.toString());
	    }

	    objcntrl.save();
	    objcntrl.unlock();
	}

	
	
	public static boolean getwrkflowActivobj(TCSession session,String taskId,String WFStep,String WFStatus,String WFUser)
	{
		TCComponentQuery  query = null;


		System.out.println("Inside getwrkflowActivobj function with parameters"+taskId +WFStep +WFStatus +WFUser);


		// Get the service stub.
		SavedQueryService queryService = SavedQueryService.getService(session);
		DataManagementService dmService= DataManagementService.getService(session);

		// DataManagementService dmService= DataManagementService.getService(tcSession);
		try
		{

			// *****************************
			// Execute the service operation
			// *****************************
			GetSavedQueriesResponse savedQueries = queryService.getSavedQueries();


			if (savedQueries.queries.length == 0)
			{
				System.out.println("There are no saved queries in the system.");
				return false;
			}

			// Find one called 'Item Name'
			for (int i = 0; i < savedQueries.queries.length; i++)
			{

				if (savedQueries.queries[i].name.equals("ERC TASK WF Query"))
				{
					query = savedQueries.queries[i].query;
					break;
				}
			}
		}
		catch (ServiceException e)
		{
			System.out.println("GetSavedQueries service request failed.");
			System.out.println(e.getMessage());
			return false;
		}

		if (query == null)
		{
			System.out.println("There is not an 'Item Name' query.");
			return false;
		}

		try
		{
			//Search for all Items, returning a maximum of 25 objects

			QueryInput savedQueryInput[] = new QueryInput[1];
			savedQueryInput[0] = new QueryInput();
			savedQueryInput[0].query = query;
			savedQueryInput[0].maxNumToReturn = 25;
			savedQueryInput[0].limitList = new TCComponent[0];
			savedQueryInput[0].entries = new String[]{"TASK ID","WF Step","Current Status","WFSignOffUser"};
			savedQueryInput[0].values =new String[]{taskId,WFStep,WFStatus,WFUser};

			/*
            savedQueryInput[1] = new QueryInput();
            //savedQueryInput[1].entries = new String[]{"WF Step" };
            savedQueryInput[1].values = new String[1];
            savedQueryInput[1].values[0] = WFStep;

            savedQueryInput[2] = new QueryInput();
            //savedQueryInput[2].entries = new String[]{"Current Status" };
            savedQueryInput[2].values = new String[1];
            savedQueryInput[2].values[0] = WFStatus;

            savedQueryInput[3] = new QueryInput();
            savedQueryInput[3].entries = new String[]{"WFSignOffUser" };
            savedQueryInput[3].values = new String[1];
            savedQueryInput[3].values[0] = WFUser;
			 */
			//*****************************
			//Execute the service operation
			//*****************************
			SavedQueriesResponse savedQueryResult = queryService.executeSavedQueries(savedQueryInput);
			QueryResults found = savedQueryResult.arrayOfResults[0]; 

			System.out.println("");
			System.out.println("Found Items:"+found);

			ServiceData sd = dmService.loadObjects( found.objectUIDS );
			System.out.println("ServiceData:"+sd +" sd.sizeOfPlainObjects()="+sd.sizeOfPlainObjects());
			if (sd.sizeOfPlainObjects() > 0)
			{
				//for( int k =0; k< sd.sizeOfPlainObjects(); k++)
				//{
				TCComponentItemRevision Item= (TCComponentItemRevision) sd.getPlainObject(0);             

				System.out.println("Item="+Item.toDisplayString());
				return true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return false;
		///return true;
		// }
}

	public static TCComponentItemRevision getAttachedDML(TCComponentItemRevision selectedObj,String ObjRelName,String assignmentName)
	{
		System.out.println("Inside func getAttachedDML with input value selectedObj="+selectedObj.toDisplayString()+"ObjRelName="+ObjRelName +"assignmentName="+assignmentName);
		TCComponentItemRevision taskrev=null;//SecondaryToPrimaryObjs("CMReferences", selectedObj); //Check
			
			TCComponent[] allprimaryObj=SecondaryToPrimaryObjs(ObjRelName, selectedObj);
			System.out.println("\nallprimaryObj.length="+allprimaryObj.length);
			if(allprimaryObj!=null)
			{
				for(int h=0;h<allprimaryObj.length;h++)
				{
					TCComponentItemRevision	primaryObj=(TCComponentItemRevision) allprimaryObj[h];
				System.out.println("if in isObjectUpdatable Primary Object="+primaryObj.toDisplayString());
			String taskID=null;
		
			try {
				taskID=primaryObj.getTCProperty("item_id").getDisplayableValue();
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			boolean in_wfstep=TechSpecUtil.getwrkflowActivobj(selectedObj.getSession(),taskID,assignmentName,"4",selectedObj.getSession().getUserName());
				if(in_wfstep)
				{
					taskrev= primaryObj;
					return taskrev;
					
					//break;
			
				}
				}
			}
		return taskrev;
	}
	
	public static TCComponentItemRevision getLatestReleasedPart(TCComponentItemRevision selectedObj)
	{
		System.out.println("Inside func getLatestReleasedPart with input value selectedObj="+selectedObj.toDisplayString());
		TCComponent itemrevs=null;//SecondaryToPrimaryObjs("CMReferences", selectedObj); //Check
		TCComponentItemRevision retrelrev=null;
		TCComponentItemRevision itmrev=null;
		boolean retflg=false;	
		try {
			TCComponentItem item=selectedObj.getItem();
			//itemrevs=item.getRelatedComponent("revision_list");
			//String itemid=itemrevs.getPropertyDisplayableValue("item_id");
			
			TCComponent[] revlist=item.getRelatedComponents("revision_list");// get revs
			
			if(revlist.length>0)
			{
				for(int i=revlist.length-1;i>=0;i--)
				{
					//System.out.println("\nretflg="+retflg );
					if(retflg!=true)
					{
						itmrev= (TCComponentItemRevision) revlist[i];
						TCComponent[] RelStatus =  itmrev.getRelatedComponents("release_status_list");
						//System.out.println("\nRelStatus.length="+RelStatus.length +" for revision "+itmrev.toDisplayString());
						if(RelStatus.length>0)
						{
							for(int r=0;r<RelStatus.length;r++)
							{
								//System.out.println("\nRelStatus="+RelStatus[r] );
								if(RelStatus[r].toDisplayString().contains("ERC Release"))
								{
									System.out.println("\nRelStatus="+RelStatus[r] + " retflg="+retflg);
									System.out.println("\ninside compare cond itemrevs="+itmrev );
									retflg=true;
									retrelrev=(TCComponentItemRevision) itmrev;
									break;
								}
							}
						}
					}
					else
					{
						break;
					}
				}
			}
			
//			String relstat=itemrevs.getProperty("release_status_list");
//			System.out.println("\nitemid="+itemid +" relstat="+relstat);
//			//if(relstat.compareTo("ERC Release")==0)
//			if(relstat.contains("ERC Release"))
//			{
//				System.out.println("\ninside compare cond itemid="+itemid );
//				 //retflg=true;
//				 retrelrev=(TCComponentItemRevision) itemrevs;
//				
//			}
		} catch (TCException  e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		System.out.println("\nreturn func with retrelrev="+retrelrev );
		return retrelrev;
	}
	
	
	
	
	//
	public boolean invokeDlg(Shell shell,TCSession session,ExecutionEvent exe_evt,TCComponent selectedObj,String selectedBusUnit)
	{
		ICOValues val =null;
		UpdateTechSpecDialog UpdTechObj = null;
		String TSBusiUnit=null;
		String SelObjRevSeq=null;
		String SelobjType= selectedObj.getType();

		System.out.println("\nSelobjType="+SelobjType + " selectedBusUnit="+selectedBusUnit);

		try {
			SelObjRevSeq=selectedObj.getTCProperty("item_revision_id").getDisplayableValue();
		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		System.out.println("SelObjRevSeq:----------  "+SelObjRevSeq);

		TCComponentUser user = session.getUser();
		String userIdS=null;
		try {
			userIdS = user.getUserId();
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Start
		System.out.println("userIdS="+userIdS);

	
//		if(SelObjRevSeq.contains("NR")==false)
//		{
//			boolean answer=MessageDialog.openQuestion(shell,"TechSpec Update Validation","VC attributes should not updated by Revised VC process, pls take MDM DML to update it.if you want see the VC attributes value then click on Ok else No");
//			System.out.println("answer:----------  "+answer);
//			if(answer==true)
//			{
//				System.out.println("Revised VC's technical specification value can't be update during VC release, update VC attributes by MDM DML release first for revised VC/Part.  ");

				//MessageBox.post(shell,"VC attributes should not updated by Revised VC process, pls take MDM DML to update it!","WARNING",SWT.ICON_WARNING);
				//return ;


				if(SelobjType.equals("T5_TSCompRevision")) //Case :1 Selected Object is techspec-Header
				{

					//Rule : VC/Vehicle  should be attached to Techspec Header,
					//Othewise No Classification Dialog will be Open (return false)

					TCComponentItemRevision VCObj = null;
					try {
						VCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
						System.out.println("VCObj:-"+VCObj);
						
						//newly added to get latest released VC
						TCComponentItemRevision latestVCrev=null;
						 latestVCrev=getLatestReleasedPart(VCObj);
						 System.out.println("latestVCrev:-"+latestVCrev);
						
						if(latestVCrev!=null)
						{
							VCObj=latestVCrev;
						}
						
						System.out.println("final processing VC:-"+VCObj);
						TSBusiUnit = selectedObj.getTCProperty("t5_VCClassName").getDisplayableValue();
						System.out.println("TSBusiUnit:-"+TSBusiUnit);
						if(VCObj==null) //need to discuss for this msg.
						{
							System.out.println("Tech Spec does not relate with any VC/CCV/SVR/Vehicle, so Update Technical specification attribute can't invoke");

							MessageBox.post(shell,"Tech Spec does not relate with any VC/CCV/SVR/Vehicle, so Update Technical specification attribute can't invoke !!!","WARNING",SWT.ICON_WARNING);


							return false; // No Classification Dialog will be Open 
						}

					} catch (TCException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(VCObj!=null) // THe Clasification Doalog will prompt 
					{
						ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
						UpdTechObj= new UpdateTechSpecDialog(shell,session,exe_evt,VCObj,selectedObj,ccvList);
						try{
							UpdTechObj.open();
							Exception opex=UpdTechObj.getOpenexception();
							if(opex!=null)
							{

								MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
								UpdTechObj.close();

							}

						}catch(Exception e)
						{

							e.printStackTrace();
						}	
					}


				}

				else if(SelobjType.equals("VariantRule") ) // If Super-SVR is Selected , which is attached to Reference Item in  Task Of DML(relaese Type "SVR Cluster Release")
				{


					//GET super-SVR selected in Reference Item attached to Task
					TCComponentItemRevision taskrev=null;//SecondaryToPrimaryObjs("CMReferences", selectedObj); //Check

					TCComponent[] allprimaryObj=SecondaryToPrimaryObjs("CMReferences", selectedObj);

					if(allprimaryObj!=null)
					{
						for(int h=0;h<allprimaryObj.length;h++)
						{
							TCComponentItemRevision	primaryObj=(TCComponentItemRevision) allprimaryObj[h];
							System.out.println("if in isObjectUpdatable Primary Object="+primaryObj.toDisplayString());
							String taskID=null;

							try {
								taskID=primaryObj.getTCProperty("item_id").getDisplayableValue();
							} catch (TCException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							//19-05-2021
							String wf_type="VCATTR";
							String step_wf=null;
							try {
								step_wf=TechSpecUtil.getWFStepName(wf_type);
							} catch (NotLoadedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (TCException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							if(step_wf==null)
								step_wf="Update VC attribute*";
							System.out.println(wf_type+":"+step_wf);
							//end 
							boolean in_wfstep=TechSpecUtil.getwrkflowActivobj(selectedObj.getSession(),taskID,step_wf,"4",session.getUserName());
							if(in_wfstep)
							{
								taskrev= primaryObj;
								break;

							}
						}

						TCComponent[] sol_items=null;
						TCComponentItemRevision VCObj = null;
						ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
						//GET Parts/CCV attached to Task and add all Sol-Item/CCV to ccvList for copying Same Data to other CCV
						if(taskrev!=null)
						{
							try {
								sol_items=taskrev.getTCProperty("CMHasSolutionItem").getReferenceValueArray();
								if(sol_items!=null && sol_items.length>0)
								{

									for(int x=0;x<sol_items.length;x++)
									{

										String parttype=sol_items[x].getTCProperty("t5_PartType").getDisplayableValue();

										if(parttype.equals("Vehicle") || parttype.equals("Vehicle Combination") || parttype.equals("Configurable VC")|| parttype.equals("Vehicle Combination CR"))
										{
											if(x==0)
												VCObj=(TCComponentItemRevision) sol_items[x];
											else
												ccvList.add((TCComponentItemRevision) sol_items[x]);
										}
									}

									if(VCObj!=null)
									{
										UpdTechObj= new UpdateTechSpecDialog(shell,session,exe_evt,VCObj, selectedObj,ccvList);
										//UpdTechObj.open();
										try{
											UpdTechObj.open();
											Exception opex=UpdTechObj.getOpenexception();
											if(opex!=null)
											{

												MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
												UpdTechObj.close();

											}
										}catch(Exception e)
										{

											//e.printStackTrace();
										}
									}
								}
								else
								{
									MessageBox.post(shell,"No CCV attached to solution Item or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);
									return false;
								}

							} catch (TCException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						else
						{

							//If Task Rev ==null

							MessageBox.post(shell,"No Active Workflow Exists","WARNING",SWT.ICON_WARNING);
							/////////return false;
							return true;
							/*	
				UpdTechObj= new UpdateTechSpecDialog(shell,session,exe_evt,VCObj, selectedObj,ccvList);

				try{
					UpdTechObj.open();
					}catch(Exception e)
					{

						//e.printStackTrace();
					}
							 */
						}

					}

				}

				else // If CCV or Vehicle or Module is selected
				{


					String modulenum=null;
					String SelectedObjType=null;
					String BuinessUnit=null;
					String revid=null;
					String projcode=null;
					try {
						boolean UpdDlgFlg=true; // This flag is taken to show/not show check-in dialog ; 
						//false:-> do not show check-in Dialog ,
						// true:-> show check-in Dialog
						modulenum = selectedObj.getPropertyDisplayableValue("item_id");
						revid = selectedObj.getPropertyDisplayableValue("item_revision_id");
						System.out.println("modulenum====="+modulenum +"revid"+revid);
						//for VC Update
						SelectedObjType = selectedObj.getPropertyDisplayableValue("t5_PartType");
						System.out.println("SelectedObjType:-"+SelectedObjType);

						projcode = modulenum.substring(0,4);
						System.out.println("projcode:-"+projcode);
						//t5_ProjectCode



						if(SelectedObjType==null)
						{
							UpdDlgFlg=false;
							MessageBox.post(PlatformHelper.getCurrentShell(),"Part Type can not be NULL for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
							return UpdDlgFlg;
						}

						//if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") )
						//date:-04/04/2019 
						String noClsClassFndErrMsg=null;
						if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") || SelectedObjType.equals("Vehicle Combination") || SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))
						{

							System.out.println("part Type is VC/Vehicle/Module, process can execute");
							if(SelectedObjType.equals("Module")) //Case For : Module
							{
								String ModuleAddress=selectedObj.getPropertyDisplayableValue("t5_ModuleAddress");
								System.out.println("ModuleAddress:----------  "+ModuleAddress);



								if(ModuleAddress==null || ModuleAddress.length()<=0)
								{
									UpdDlgFlg=false;
									MessageBox.post(PlatformHelper.getCurrentShell(),"Module Address is not available for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
									//return UpdTechObj.isSuccess();
									return UpdDlgFlg;
								}
								else
								{
									//Added by Rajesh on 10052019 to avoid the classification window if clsobj is not found
									String classdesc = null;
									String modClsname=null;
									System.out.println("b4 call getClsNmaeForModuleAdd projcode="+projcode +"ModuleAddress="+ModuleAddress +" selectedBusUnit="+selectedBusUnit );
									if(selectedBusUnit==null)
									{
										modClsname=getClsNmaeForModuleAdd(projcode,ModuleAddress);
									}
									else
									{
										if(selectedBusUnit.equals("CAR"))
										{
											modClsname=ModuleAddress;
										}
										else
										{
											modClsname=selectedBusUnit+ModuleAddress;
										}
									}
									System.out.println("after call getClsNmaeForModuleAdd modClsname="+modClsname );
									try
									{
										//classdesc=new GetClassDescriptions().getClassDesc(session,ModuleAddress); //hashed on 10/06/2022
										//if(modClsname.length()>0)
										if(modClsname!=null)
										{
											classdesc=new GetClassDescriptions().getClassDesc(session,modClsname);
										}
									}
									catch (ServiceException s)
									{
										s.printStackTrace();
									}
									//if Module-Address is not Present is Classification -Hiearchy,
									//do not show classification Dialog , check-in Dialog is shown.
									if(classdesc==null) 
									{
										UpdDlgFlg=true;//show checkin dialog
										noClsClassFndErrMsg="Module-Address [";
										noClsClassFndErrMsg=noClsClassFndErrMsg+modClsname;
										noClsClassFndErrMsg=noClsClassFndErrMsg+"] is not Present is Classification -Hiearchy,Contact PLM Admin Team!";
										System.out.println("noClsClassFndErrMsg="+noClsClassFndErrMsg );
										MessageBox.post(shell,noClsClassFndErrMsg,"WARNING",SWT.ICON_WARNING);
										return UpdDlgFlg;
									}
									else
									{
										UpdDlgFlg=true;//show checkin dialog
									}


								}

							}
							else if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Vehicle Combination") || SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))//Case For : VC/Vehicle
							{
								TCComponent[] techspec=selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
								//TCComponentItemRevision techspec=selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
								if (techspec!=null && techspec.length>0) // If  TechSpec is attached to VC/Vehicle Show Classification Dialog for resp. BU
								{
									UpdDlgFlg=true;
									String TSCls = techspec[0].getTCProperty("object_type").getDisplayableValue();
									if(TSCls.equals("T5_TSCompRevision"))
									{
										TSBusiUnit = techspec[0].getTCProperty("t5_VCClassName").getDisplayableValue();
										System.out.println("in vehicle selection TSBusiUnit:-"+TSBusiUnit);
									}
								}
								else
								{
									UpdDlgFlg=true;

									MessageBox.post(PlatformHelper.getCurrentShell(),"No Tech Spec attached with selected object","ERROR",SWT.ICON_ERROR);
									return UpdDlgFlg;
								}
							}
							System.out.println("UpdDlgFlg="+UpdDlgFlg);

							if(UpdDlgFlg==true)
							{
								ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
								UpdTechObj= new UpdateTechSpecDialog(shell,session,exe_evt,(TCComponentItemRevision)selectedObj,selectedObj,ccvList);
								try{
									UpdTechObj.open();
									Exception opex=UpdTechObj.getOpenexception();
									if(opex!=null)
									{

										MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
										UpdTechObj.close();

									}
								}catch(Exception e)
								{

									e.printStackTrace();
								}
							}
						}
						else
						{

							System.out.println("part Type is not VC/Vehicle/Module/Technical Specification Revision, option only valid for VC/Vehicle/Module");

							MessageBox.post(shell,"Part Type VC/Vehicle/Module Revision/Technical Specification Revision only allowed for this option !!","WARNING",SWT.ICON_WARNING);
							return false;//UpdTechObj.isSuccess();

						}

					} catch (Exception  e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
			//}
//			else
//			{
//				return false;
//			}
		//}
		return UpdTechObj.isSuccess();	
	}
	
	public boolean invokeDlgMDM4PRDModule(Shell shell,TCSession session,ExecutionEvent exe_evt,TCComponent selectedObj,String ProjCls)
	{
		ICOValues val =null;
		//ArrayList<TCComponentItemRevision> ccvList1=;
		UpdateMDMDlgForPRD UpdTechObj=null ;
		//ArrayList<TCComponentItemRevision> ccvList1=new ArrayList<TCComponentItemRevision>();
		TCComponent master;
		//if(selectedObj instanceof TCComponentItemRevision)
		//{
		//	 master=(TCComponentItemRevision) selectedObj.getTCProperty("items_tag").getReferenceValue();
		//}
		//UpdTechObj= new UpdateMDMDialog(shell,session,exe_evt,selectedObj,master,ccvList1);
		
		//boolean isUpdatable=false;
		
		//ArrayList<TCComponentItemRevision> ccvList2=new ArrayList<TCComponentItemRevision>();
		//UpdTechObj= new UpdateMDMDialog(shell,session,exe_evt,(TCComponentItemRevision)selectedObj,selectedObj,ccvList2);
		//boolean isUpdatable=UpdTechObj.isObjectUpdatable();


		String SelobjType= selectedObj.getType();

	//	System.out.println("\ninvokeDlgMDM dialog with SelobjType="+SelobjType +" isUpdatable="+isUpdatable);

		System.out.println("\ninvokeDlgMDM4Module dialog with SelobjType="+SelobjType +" ProjCls="+ProjCls );
		if(SelobjType.equals("T5_TSCompRevision")) //Case :1 Selected Object is techspec-Header
		{

			//Rule : VC/Vehicle  should be attached to Techspec Header,
			//Othewise No Classification Dialog will be Open (return false)

			TCComponentItemRevision VCObj = null;
			try {
				VCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
				System.out.println("VCObj:-"+VCObj);
				if(VCObj==null) //need to discuss for this msg
				{
					System.out.println("invokeDlgMDM4PRDModule Tech Spec does not relate with any VC/CCV/SVR/Vehicle, so Update Technical specification attribute can't invoke");

					MessageBox.post(shell,"invokeDlgMDM4PRDModule Tech Spec does not relate with any VC/CCV/SVR/Vehicle, so Update Technical specification attribute can't invoke !!!","WARNING",SWT.ICON_WARNING);


					return false; // No Classification Dialog will be Open 
				}

			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(VCObj!=null) // THe Clasification Doalog will prompt 
			{
				ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
				UpdTechObj= new UpdateMDMDlgForPRD(shell,session,exe_evt,VCObj,selectedObj,ccvList,ProjCls);
				try{
					UpdTechObj.open();
					Exception opex=UpdTechObj.getOpenexception();
					if(opex!=null)
					{
						
						MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
						UpdTechObj.close();
						
					}
					}catch(Exception e)
					{
						
						//e.printStackTrace();
					}	
			}


		}

		else if(SelobjType.equals("VariantRule") ) // If Super-SVR is Selected , which is attached to Reference Item in  Task Of DML(relaese Type "SVR Cluster Release")
		{


			//GET super-SVR selected in Reference Item attached to Task
			TCComponentItemRevision taskrev=null;//SecondaryToPrimaryObjs("CMReferences", selectedObj); //Check
			
			TCComponent[] allprimaryObj=SecondaryToPrimaryObjs("CMReferences", selectedObj);
			
			if(allprimaryObj!=null)
			{
				for(int h=0;h<allprimaryObj.length;h++)
				{
					TCComponentItemRevision	primaryObj=(TCComponentItemRevision) allprimaryObj[h];
				System.out.println("if in isObjectUpdatable Primary Object="+primaryObj.toDisplayString());
			String taskID=null;
		
			try {
				taskID=primaryObj.getTCProperty("item_id").getDisplayableValue();
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//19-05-2021
			String wf_type="MDM";
			String step_wf=null;
			try {
				step_wf=TechSpecUtil.getWFStepName(wf_type);
			} catch (NotLoadedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(step_wf==null)
				step_wf="Update VC attribute*";
			System.out.println(wf_type+":"+step_wf);
			//end 
			
			boolean in_wfstep=TechSpecUtil.getwrkflowActivobj(selectedObj.getSession(),taskID,/*"Update VC attribute*"*/step_wf,"4",session.getUserName());
				if(in_wfstep)
				{
					taskrev= primaryObj;
					break;
			
				}
				}

			TCComponent[] sol_items=null;
			TCComponentItemRevision VCObj = null;
			ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
			//GET Parts/CCV attached to Task and add all Sol-Item/CCV to ccvList for copying Same Data to other CCV
			if(taskrev!=null)
			{
			try {
				sol_items=taskrev.getTCProperty("CMHasSolutionItem").getReferenceValueArray();
				if(sol_items!=null && sol_items.length>0)
				{

					for(int x=0;x<sol_items.length;x++)
					{

						String parttype=sol_items[x].getTCProperty("t5_PartType").getDisplayableValue();

						if(parttype.equals("Vehicle") || parttype.equals("Vehicle Combination") || parttype.equals("Configurable VC") || parttype.equals("Vehicle Combination CR"))
						{
							if(x==0)
								VCObj=(TCComponentItemRevision) sol_items[x];
							else
								ccvList.add((TCComponentItemRevision) sol_items[x]);
						}
					}

					if(VCObj!=null)
					{
						UpdTechObj= new UpdateMDMDlgForPRD(shell,session,exe_evt,VCObj, selectedObj,ccvList,ProjCls);
						//UpdTechObj.open();
						try{
							UpdTechObj.open();
							Exception opex=UpdTechObj.getOpenexception();
							if(opex!=null)
							{
								
								MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
								UpdTechObj.close();
								
							}
							}catch(Exception e)
							{
								
								//e.printStackTrace();
							}
					}
				}
				else
				{
					MessageBox.post(shell," invokeDlgMDM4PRDModule No CCV attached to solution Item or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);
					return false;
				}

			} catch (TCException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
			else
			{
				
				//If Task Rev ==null
				UpdTechObj= new UpdateMDMDlgForPRD(shell,session,exe_evt,VCObj, selectedObj,ccvList,ProjCls);
				try{
					UpdTechObj.open();
					Exception opex=UpdTechObj.getOpenexception();
					if(opex!=null)
					{
						
						MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
						UpdTechObj.close();
						
					}
					}catch(Exception e)
					{
						
						//e.printStackTrace();
					}
			}

			}

		}

		else // If CCV or Vehicle or Module is selected
		{


			String modulenum=null;
			String SelectedObjType=null;
			String BuinessUnit=null;
			String revid=null;
			String noClsClassFndErrMsg=null;
			try {
				boolean UpdDlgFlg=true; // This flag is taken to show/not show check-in dialog ; 
				//false:-> do not show check-in Dialog ,
				// true:-> show check-in Dialog
				modulenum = selectedObj.getPropertyDisplayableValue("item_id");
				revid = selectedObj.getPropertyDisplayableValue("item_revision_id");
				System.out.println("invokeDlgMDM4PRDModule modulenum====="+modulenum +"revid"+revid);
				//for VC Update
				SelectedObjType = selectedObj.getPropertyDisplayableValue("t5_PartType");
				System.out.println("invokeDlgMDM4PRDModule SelectedObjType:-"+SelectedObjType);
				if(SelectedObjType==null)
				{
					UpdDlgFlg=false;
					MessageBox.post(PlatformHelper.getCurrentShell(),"Part Type can not be NULL for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
					return UpdDlgFlg;
				}

				//if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") )
				//date:-04/04/2019 
				if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") || SelectedObjType.equals("Vehicle Combination")|| SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))
				{

					System.out.println("invokeDlgMDM4PRDModule part Type is VC/Vehicle/Module, process can execute");
					if(SelectedObjType.equals("Module")) //Case For : Module
					{
						String ModuleAddress=selectedObj.getPropertyDisplayableValue("t5_ModuleAddress");
						System.out.println("invokeDlgMDM4PRDModule ModuleAddress:----------  "+ModuleAddress);
						if(ModuleAddress==null || ModuleAddress.length()<=0)
						{
							UpdDlgFlg=false;
							MessageBox.post(PlatformHelper.getCurrentShell(),"Module Address is not available for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
							//return UpdTechObj.isSuccess();
							return UpdDlgFlg;
						}
						else
						{
							//Added by Rajesh on 10052019 to avoid the classification window if clsobj is not found
							String classdesc = null;
							String retval=null;
							String projcode=modulenum.substring(0,4);
							System.out.println("invokeDlgMDM4PRDModule b4 call getClsNmaeForModuleAdd projcode="+projcode +"ModuleAddress="+ModuleAddress +" ProjCls="+ProjCls );
							//String modClsname=getClsNmaeForModuleAdd(projcode,ModuleAddress);
							
							//String modClsname=ProjCls+ModuleAddress;
							String modClsname;
							if(ProjCls.contains("CAR"))
							{
								modClsname=ModuleAddress;
							}
							else
							{
							modClsname=ProjCls+ModuleAddress;
							}
							System.out.println("invokeDlgMDM4PRDModule after call getClsNmaeForModuleAdd modClsname="+modClsname );
							System.out.println("invokeDlgMDM4PRDModule start newly added for PRD class logic with isUpdatable=" );
							/*
							if(modClsname.contains("PRD"))
							{
								//boolean isUpdatable1= UpdTechObj.isObjectUpdatable();
								//if(isUpdatable==true )
								//{
									String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
									String [] qryValues={"ICOUPDLIST",modulenum,"0"};
									int r;
									TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
									String info=null;
									//if(objvec!=null)
									if(objvec.length>0)
									{
										//for(int f=0;f<objvec.length;f++)
										//{
										TCComponent objcntrl=objvec[0];

										String ClsName=objcntrl.getPropertyDisplayableValue("object_name");

										modClsname=ClsName;

										//}
									}
									else
									{
										GetProjVehClass GetProjVehClassDlg= new GetProjVehClass(shell);
										GetProjVehClassDlg.open();
										retval=GetProjVehClassDlg.getProjVehClsSelectedVal1();
										// retval=GetProjVehClassDlg.getShell().getText();						}
										System.out.println("invokeDlgMDM4PRDModule end newly added for PRD class logic with retval="+retval);
										if(retval!=null || retval.isEmpty()==false)
										{
											String modClsnamecpy=modClsname;
											//String tmpaddrsstr=(modClsnamecpy.substring(modClsnamecpy.length()-6)),modClsnamecpy.length());

											String tmpaddrsstr=modClsnamecpy.substring(modClsnamecpy.length()-6, modClsnamecpy.length());
											modClsname=retval+tmpaddrsstr;
										}
									}
								//}
								
							}
							*/
							System.out.println("invokeDlgMDM4PRDModule final modClsname="+modClsname);
							try
							{
								//classdesc=new GetClassDescriptions().getClassDesc(session,ModuleAddress);
								if(modClsname.length()>0)
								{
								classdesc=new GetClassDescriptions().getClassDesc(session,modClsname);
								}
							}
							catch (ServiceException s)
							{
								s.printStackTrace();
							}
							//if Module-Address is not Present is Classification -Hiearchy,
							//do not show classification Dialog , check-in Dialog is shown.
							System.out.println("invokeDlgMDM4PRDModule final classdesc="+classdesc);
							if(classdesc==null) 
							{
								UpdDlgFlg=true;//show checkin dialog
								//Attention msg newly added on 19/04/2023
								noClsClassFndErrMsg="Module-Address [";
								noClsClassFndErrMsg=noClsClassFndErrMsg+modClsname;
								noClsClassFndErrMsg=noClsClassFndErrMsg+"] is not Present is Classification -Hiearchy,Contact PLM Admin Team!";
								System.out.println("noClsClassFndErrMsg="+noClsClassFndErrMsg );
								MessageBox.post(shell,noClsClassFndErrMsg,"WARNING",SWT.ICON_WARNING);
								//MessageBox.post(shell,"Module-Address is not Present is Classification -Hiearchy,Contact PLM Admin Team!","WARNING",SWT.ICON_WARNING);
								return UpdDlgFlg;
							}
							else
							{
								UpdDlgFlg=true;//show checkin dialog
							}


						}

					}
					else if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Vehicle Combination") || SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))//Case For : VC/Vehicle
					{
						TCComponent[] techspec=selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray(); 
						if (techspec!=null && techspec.length>0) // If  TechSpec is attached to VC/Vehicle Show Classification Dialog for resp. BU
						{
							UpdDlgFlg=true;
						}
						else
						{
							UpdDlgFlg=true;

							MessageBox.post(PlatformHelper.getCurrentShell(),"No Tech Spec attached with selected object","ERROR",SWT.ICON_ERROR);
							return UpdDlgFlg;
						}
					}
					System.out.println("invokeDlgMDM4PRDModule UpdDlgFlg="+UpdDlgFlg);

					if(UpdDlgFlg==true)
					{
						ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
						UpdTechObj= new UpdateMDMDlgForPRD(shell,session,exe_evt,(TCComponentItemRevision)selectedObj,selectedObj,ccvList,ProjCls);
						//boolean xx=UpdTechObj.isObjectUpdatable();
						try{
							UpdTechObj.open();
							Exception opex=UpdTechObj.getOpenexception();
							if(opex!=null)
							{
								
								MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
								UpdTechObj.close();
								
							}
							}catch(Exception e)
							{
								
								e.printStackTrace();
							}
					}
				}
				else
				{

					System.out.println("invokeDlgMDM4PRDModule part Type is not VC/Vehicle/Module, option only valid for VC/Vehicle/Module");

					MessageBox.post(shell,"Part Type VC/Vehicle/Module Revision only allowed for this option !!","WARNING",SWT.ICON_WARNING);
					return false;//UpdTechObj.isSuccess();

				}

			} catch (Exception  e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
		return UpdTechObj.isSuccess();	
	}
	
	
	public boolean invokeDlgMDM(Shell shell,TCSession session,ExecutionEvent exe_evt,TCComponent selectedObj)
	{
		ICOValues val =null;
		//ArrayList<TCComponentItemRevision> ccvList1=;
		UpdateMDMDialog UpdTechObj=null ;
		String modClsname=null;
		//ArrayList<TCComponentItemRevision> ccvList1=new ArrayList<TCComponentItemRevision>();
		TCComponent master;
		//if(selectedObj instanceof TCComponentItemRevision)
		//{
		//	 master=(TCComponentItemRevision) selectedObj.getTCProperty("items_tag").getReferenceValue();
		//}
		//UpdTechObj= new UpdateMDMDialog(shell,session,exe_evt,selectedObj,master,ccvList1);
		
		//boolean isUpdatable=false;
		
		//ArrayList<TCComponentItemRevision> ccvList2=new ArrayList<TCComponentItemRevision>();
		//UpdTechObj= new UpdateMDMDialog(shell,session,exe_evt,(TCComponentItemRevision)selectedObj,selectedObj,ccvList2);
		//boolean isUpdatable=UpdTechObj.isObjectUpdatable();


		String SelobjType= selectedObj.getType();

	//	System.out.println("\ninvokeDlgMDM dialog with SelobjType="+SelobjType +" isUpdatable="+isUpdatable);

		System.out.println("\ninvokeDlgMDM dialog with SelobjType="+SelobjType );
		if(SelobjType.equals("T5_TSCompRevision")) //Case :1 Selected Object is techspec-Header
		{

			//Rule : VC/Vehicle  should be attached to Techspec Header,
			//Othewise No Classification Dialog will be Open (return false)

			TCComponentItemRevision VCObj = null;
			try {
				VCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
				System.out.println("VCObj:-"+VCObj);
				if(VCObj==null) //need to discuss for this msg
				{
					System.out.println("Tech Spec does not relate with any VC/CCV/SVR/Vehicle, so Update Technical specification attribute can't invoke");

					MessageBox.post(shell,"Tech Spec does not relate with any VC/CCV/SVR/Vehicle, so Update Technical specification attribute can't invoke !!!","WARNING",SWT.ICON_WARNING);


					return false; // No Classification Dialog will be Open 
				}

			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(VCObj!=null) // THe Clasification Doalog will prompt 
			{
				ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
				UpdTechObj= new UpdateMDMDialog(shell,session,exe_evt,VCObj,selectedObj,ccvList,modClsname);
				try{
					UpdTechObj.open();
					Exception opex=UpdTechObj.getOpenexception();
					if(opex!=null)
					{
						
						MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
						UpdTechObj.close();
						
					}
					}catch(Exception e)
					{
						
						//e.printStackTrace();
					}	
			}


		}

		else if(SelobjType.equals("VariantRule") ) // If Super-SVR is Selected , which is attached to Reference Item in  Task Of DML(relaese Type "SVR Cluster Release")
		{


			//GET super-SVR selected in Reference Item attached to Task
			TCComponentItemRevision taskrev=null;//SecondaryToPrimaryObjs("CMReferences", selectedObj); //Check
			
			TCComponent[] allprimaryObj=SecondaryToPrimaryObjs("CMReferences", selectedObj);
			
			if(allprimaryObj!=null)
			{
				for(int h=0;h<allprimaryObj.length;h++)
				{
					TCComponentItemRevision	primaryObj=(TCComponentItemRevision) allprimaryObj[h];
				System.out.println("if in isObjectUpdatable Primary Object="+primaryObj.toDisplayString());
			String taskID=null;
		
			try {
				taskID=primaryObj.getTCProperty("item_id").getDisplayableValue();
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//19-05-2021
			String wf_type="MDM";
			String step_wf=null;
			try {
				step_wf=TechSpecUtil.getWFStepName(wf_type);
			} catch (NotLoadedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(step_wf==null)
				step_wf="Update VC attribute*";
			System.out.println(wf_type+":"+step_wf);
			//end 
			
			boolean in_wfstep=TechSpecUtil.getwrkflowActivobj(selectedObj.getSession(),taskID,/*"Update VC attribute*"*/step_wf,"4",session.getUserName());
				if(in_wfstep)
				{
					taskrev= primaryObj;
					break;
			
				}
				}

			TCComponent[] sol_items=null;
			TCComponentItemRevision VCObj = null;
			ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
			//GET Parts/CCV attached to Task and add all Sol-Item/CCV to ccvList for copying Same Data to other CCV
			if(taskrev!=null)
			{
			try {
				sol_items=taskrev.getTCProperty("CMHasSolutionItem").getReferenceValueArray();
				if(sol_items!=null && sol_items.length>0)
				{

					for(int x=0;x<sol_items.length;x++)
					{

						String parttype=sol_items[x].getTCProperty("t5_PartType").getDisplayableValue();

						if(parttype.equals("Vehicle") || parttype.equals("Vehicle Combination") || parttype.equals("Configurable VC")|| parttype.equals("Vehicle Combination CR"))
						{
							if(x==0)
								VCObj=(TCComponentItemRevision) sol_items[x];
							else
								ccvList.add((TCComponentItemRevision) sol_items[x]);
						}
					}

					if(VCObj!=null)
					{
						UpdTechObj= new UpdateMDMDialog(shell,session,exe_evt,VCObj, selectedObj,ccvList,modClsname);
						//UpdTechObj.open();
						try{
							UpdTechObj.open();
							Exception opex=UpdTechObj.getOpenexception();
							if(opex!=null)
							{
								
								MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
								UpdTechObj.close();
								
							}
							}catch(Exception e)
							{
								
								//e.printStackTrace();
							}
					}
				}
				else
				{
					MessageBox.post(shell,"No CCV attached to solution Item or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);
					return false;
				}

			} catch (TCException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
			else
			{
				
				//If Task Rev ==null
				UpdTechObj= new UpdateMDMDialog(shell,session,exe_evt,VCObj, selectedObj,ccvList,modClsname);
				try{
					UpdTechObj.open();
					Exception opex=UpdTechObj.getOpenexception();
					if(opex!=null)
					{
						
						MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
						UpdTechObj.close();
						
					}
					}catch(Exception e)
					{
						
						//e.printStackTrace();
					}
			}

			}

		}

		else // If CCV or Vehicle or Module is selected
		{


			String modulenum=null;
			String SelectedObjType=null;
			String BuinessUnit=null;
			String revid=null;
			String noClsClassFndErrMsg=null;
			//String modClsname=null;
			try {
				boolean UpdDlgFlg=true; // This flag is taken to show/not show check-in dialog ; 
				//false:-> do not show check-in Dialog ,
				// true:-> show check-in Dialog
				modulenum = selectedObj.getPropertyDisplayableValue("item_id");
				revid = selectedObj.getPropertyDisplayableValue("item_revision_id");
				System.out.println("modulenum====="+modulenum +"revid"+revid);
				//for VC Update
				SelectedObjType = selectedObj.getPropertyDisplayableValue("t5_PartType");
				System.out.println("SelectedObjType:-"+SelectedObjType);
				if(SelectedObjType==null)
				{
					UpdDlgFlg=false;
					MessageBox.post(PlatformHelper.getCurrentShell(),"Part Type can not be NULL for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
					return UpdDlgFlg;
				}

				//if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") )
				//date:-04/04/2019 
				if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") || SelectedObjType.equals("Vehicle Combination")|| SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))
				{

					System.out.println("part Type is VC/Vehicle/Module, process can execute");
					if(SelectedObjType.equals("Module")) //Case For : Module
					{
						String ModuleAddress=selectedObj.getPropertyDisplayableValue("t5_ModuleAddress");
						System.out.println("ModuleAddress:----------  "+ModuleAddress);
						if(ModuleAddress==null || ModuleAddress.length()<=0)
						{
							UpdDlgFlg=false;
							MessageBox.post(PlatformHelper.getCurrentShell(),"Module Address is not available for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
							//return UpdTechObj.isSuccess();
							return UpdDlgFlg;
						}
						else
						{
							//Added by Rajesh on 10052019 to avoid the classification window if clsobj is not found
							String classdesc = null;
							String retval=null;
							String projcode=modulenum.substring(0,4);
							System.out.println("b4 call getClsNmaeForModuleAdd projcode="+projcode +"ModuleAddress="+ModuleAddress );
							 modClsname=getClsNmaeForModuleAdd(projcode,ModuleAddress);
							
							System.out.println("after call getClsNmaeForModuleAdd modClsname="+modClsname );
							System.out.println("start newly added for PRD class logic with isUpdatable=" );
							/*
							if(modClsname.contains("PRD"))
							{
								//boolean isUpdatable1= UpdTechObj.isObjectUpdatable();
								//if(isUpdatable==true )
								//{
									String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
									String [] qryValues={"ICOUPDLIST",modulenum,"0"};
									int r;
									TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
									String info=null;
									//if(objvec!=null)
									if(objvec.length>0)
									{
										//for(int f=0;f<objvec.length;f++)
										//{
										TCComponent objcntrl=objvec[0];

										String ClsName=objcntrl.getPropertyDisplayableValue("object_name");

										modClsname=ClsName;

										//}
									}
									else
									{
										GetProjVehClass GetProjVehClassDlg= new GetProjVehClass(shell);
										GetProjVehClassDlg.open();
										retval=GetProjVehClassDlg.getProjVehClsSelectedVal1();
										// retval=GetProjVehClassDlg.getShell().getText();						}
										System.out.println("end newly added for PRD class logic with retval="+retval);
										if(retval!=null || retval.isEmpty()==false)
										{
											String modClsnamecpy=modClsname;
											//String tmpaddrsstr=(modClsnamecpy.substring(modClsnamecpy.length()-6)),modClsnamecpy.length());

											String tmpaddrsstr=modClsnamecpy.substring(modClsnamecpy.length()-6, modClsnamecpy.length());
											modClsname=retval+tmpaddrsstr;
										}
									}
								
							}
							*/
							System.out.println("final modClsname="+modClsname);
							try
							{
								//classdesc=new GetClassDescriptions().getClassDesc(session,ModuleAddress);
								if(modClsname.length()>0)
								{
								classdesc=new GetClassDescriptions().getClassDesc(session,modClsname);
								}
							}
							catch (ServiceException s)
							{
								s.printStackTrace();
							}
							//if Module-Address is not Present is Classification -Hiearchy,
							//do not show classification Dialog , check-in Dialog is shown.
							System.out.println("final classdesc="+classdesc);
							if(classdesc==null) 
							{
								UpdDlgFlg=true;//show checkin dialog
								//Attention msg newly added on 19/04/2023
								noClsClassFndErrMsg="Module-Address [";
								noClsClassFndErrMsg=noClsClassFndErrMsg+modClsname;
								noClsClassFndErrMsg=noClsClassFndErrMsg+"] is not Present is Classification -Hiearchy,Contact PLM Admin Team!";
								System.out.println("noClsClassFndErrMsg="+noClsClassFndErrMsg );
								MessageBox.post(shell,noClsClassFndErrMsg,"WARNING",SWT.ICON_WARNING);
								//MessageBox.post(shell,"Module-Address is not Present is Classification -Hiearchy,Contact PLM Admin Team!","WARNING",SWT.ICON_WARNING);
								return UpdDlgFlg;
							}
							else
							{
								UpdDlgFlg=true;//show checkin dialog
							}


						}

					}
					else if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Vehicle Combination") || SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))//Case For : VC/Vehicle
					{
						TCComponent[] techspec=selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray(); 
						if (techspec!=null && techspec.length>0) // If  TechSpec is attached to VC/Vehicle Show Classification Dialog for resp. BU
						{
							UpdDlgFlg=true;
						}
						else
						{
							UpdDlgFlg=true;

							MessageBox.post(PlatformHelper.getCurrentShell(),"No Tech Spec attached with selected object","ERROR",SWT.ICON_ERROR);
							return UpdDlgFlg;
						}
					}
					System.out.println("UpdDlgFlg="+UpdDlgFlg);

					if(UpdDlgFlg==true)
					{
						ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
						UpdTechObj= new UpdateMDMDialog(shell,session,exe_evt,(TCComponentItemRevision)selectedObj,selectedObj,ccvList,modClsname);
						//boolean xx=UpdTechObj.isObjectUpdatable();
						try{
							UpdTechObj.open();
							Exception opex=UpdTechObj.getOpenexception();
							if(opex!=null)
							{
								
								MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
								UpdTechObj.close();
								
							}
							}catch(Exception e)
							{
								
								e.printStackTrace();
							}
					}
				}
				else
				{

					System.out.println("part Type is not VC/Vehicle/Module, option only valid for VC/Vehicle/Module");

					MessageBox.post(shell,"Part Type VC/Vehicle/Module Revision only allowed for this option !!","WARNING",SWT.ICON_WARNING);
					return false;//UpdTechObj.isSuccess();

				}

			} catch (Exception  e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
		return UpdTechObj.isSuccess();	
	}
	
	 public static List<String> split(String s, int chunkSize) {
	        List<String> chunks = new ArrayList<>();
	        for (int i = 0; i < s.length(); i += chunkSize) {
	            chunks.add(s.substring(i, Math.min(s.length(), i + chunkSize)));
	        }
	        return chunks;
	    }
	public boolean invokeDlgForModUpd(Shell shell,TCSession session,ExecutionEvent exe_evt,TCComponent selectedObj,boolean EditFlg)
	{
		ICOValues val =null;
		UpdateModDialog UpdTechObj = null;
		TCComponent[] Taskobjs=null;
		TCComponentItemRevision Taskobj=null;
		TCComponent[] VCObjs=null;
		TCComponentItemRevision VCObj =null;
		String SelobjType= selectedObj.getType();
		String taskID=null;
		String analystUserID=null;
		String VehBU=null;
		String step_wf=null;
		String modClsname=null;
		boolean in_wfstep;
		boolean bypassUsrflg=false;
		TCComponentItemRevision taskrev=null;//SecondaryToPrimaryObjs("CMReferences", selectedObj); //Check
		System.out.println("\nSelobjType="+SelobjType +" EditFlg="+EditFlg);
		String userIdS=null;
		TCComponentUser user = session.getUser();
		try {
			userIdS = user.getUserId();
		} catch (TCException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
    	System.out.println("\nSession User Login Name == " + userIdS + "\n");
		Taskobjs=TechSpecUtil.SecondaryToPrimaryObjs("IMAN_reference",selectedObj);
		
		if(Taskobjs.length>0)
		{
			for(int h=0;h<Taskobjs.length;h++)
			{
				Taskobj=(TCComponentItemRevision) Taskobjs[h];
				System.out.println("if in invokeDlgForModUpd Primary Object="+Taskobj.toDisplayString());
				try {
					taskID=Taskobj.getTCProperty("item_id").getDisplayableValue();
					analystUserID=Taskobj.getTCProperty("analyst_user_id").getDisplayableValue();
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println("if in invokeDlgForModUpd b4 call getwrkflowActivobj func taskID ="+taskID);
				if(step_wf==null)
					step_wf="Update VC attribute*";
				System.out.println("step_wf:"+step_wf);
				System.out.println("if in invokeDlgForModUpd analystUserID="+analystUserID);
				if(Taskobj!=null)
				{
					System.out.println("b4 bypassflg="+bypassUsrflg);
					if(userIdS!=null)
					{
			    	bypassUsrflg=new TechSpecUtil().bypassUsrfunc(userIdS,"ByPassUser");
					 System.out.println("in invokeDlgForModUpd bypassflg="+bypassUsrflg);
					
					}
					if(bypassUsrflg==true)
					{
						taskrev= Taskobj;
						EditFlg=false;
						break; 
					}
					else if(EditFlg==true)
					{
						in_wfstep=TechSpecUtil.getwrkflowActivobj(Taskobj.getSession(),taskID,/*"Update VC attribute*"*/step_wf,"4",analystUserID);
					}
					else
					{
						in_wfstep=TechSpecUtil.getwrkflowActivobj(Taskobj.getSession(),taskID,/*"Update VC attribute*"*/step_wf,"4",session.getUserName());
					}
					System.out.println("in invokeDlgForModUpd in_wfstep:"+in_wfstep +" Taskobj="+Taskobj.toDisplayString());
					if(in_wfstep)
					{
						taskrev= Taskobj;
						break;

					}
				}
			}
				//System.out.println("1if in invokeDlgForModUpd taskrev="+taskrev.toDisplayString());
				
				if(taskrev!=null)
				{
					try {
						//String assignmentStepName=Taskobj.getTCProperty("fnd0ActuatedInteractiveTsks").getDisplayableValue();

						System.out.println("if in invokeDlgForModUpd taskrev="+taskrev.toDisplayString());

						//taskID=taskrev.getTCProperty("item_id").getDisplayableValue();

						VCObjs=taskrev.getTCProperty("CMHasSolutionItem" ).getReferenceValueArray();
						if(VCObjs!=null)
						{

							for(int x=0;x<VCObjs.length;x++)
							{
								VCObj=(TCComponentItemRevision) VCObjs[x];
								String type=VCObj.getTCProperty("t5_PartType").getDisplayableValue();
								System.out.println("TYPE::"+type);
								//if(type.equals("Vehicle") || type.equals("Vehicle Combination") || type.equals("Configurable VC") )//Case For : VC/Vehicle
								if(type.equals("Vehicle") || type.equals("Configurable VC") || type.equals("Vehicle Combination CR"))//Case For : VC/Vehicle
								{
									if(VCObj!=null)
									{
										//VCObj=(TCComponentItemRevision) VCObjs[0];
										System.out.println("in invokeDlgForModUpd VCObj="+VCObj);
										//TCComponentItemRevision TechSpecObj = (TCComponentItemRevision) VCObj.getTCProperty("t5_VCSpec").getReferenceValue();
										TCComponent[] techspec=VCObj.getTCProperty("T5_VCSpec").getReferenceValueArray(); 
										VehBU=techspec[0].getTCProperty("t5_VCClassName").getDisplayableValue();
										break;
									}
								}

							}
						}

						// VCObjs =  Taskobj.getTCProperty("CMHasSolutionItem").getReferenceValue();
						System.out.println("in invokeDlgForModUpd Primary Object="+taskID);


					} catch (TCException  e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}				
				else
				{
					System.out.println("inside the else part of task not available invokeDlgForModUpd VehBU="+VehBU);
					boolean UpdDlgFlg1=true;

					UpdDlgFlg1=false;
					System.out.println("Selected Module revision is not attached to any CCV/VC Release Type DML, Module Revision must be added to IMAN_Ref foldef(Reference) folder of respective Task");

					MessageBox.post(PlatformHelper.getCurrentShell(),"Selected Module revision is not attached to any Vehicle Release Type DML and Module Revision must be added to Reference folder of respective Task.\nPlease Check or Contact PLM Support Team !","ERROR",SWT.ICON_ERROR);

					return UpdDlgFlg1;

				}
			

			System.out.println("in invokeDlgForModUpd VehBU="+VehBU);
			//			if(VehBU!=null)
			//			{
			//				
			//			}

			String modulenum=null;
			String SelectedObjType=null;
			String BuinessUnit=null;
			String revid=null;
			try {
				boolean UpdDlgFlg=true; // This flag is taken to show/not show check-in dialog ; 
				//false:-> do not show check-in Dialog ,
				// true:-> show check-in Dialog
				modulenum = selectedObj.getPropertyDisplayableValue("item_id");
				revid = selectedObj.getPropertyDisplayableValue("item_revision_id");
				System.out.println("modulenum====="+modulenum +"revid"+revid);
				//for VC Update
				SelectedObjType = selectedObj.getPropertyDisplayableValue("t5_PartType");
				System.out.println("SelectedObjType:-"+SelectedObjType);
				boolean isBypass =session.hasBypass();//added
				System.out.println("isBypass:-"+isBypass);
				if(isBypass==false)
				{
					if(VehBU==null)
					{
						UpdDlgFlg=false;
						System.out.println("Selected Module's Vehicle/CCVC revision is not attached to any CCV/VC release DML Task, Module must be added to Change Reference folder of  Task");

						MessageBox.post(PlatformHelper.getCurrentShell(),"Selected Module's Vehicle/CCVC revision is not attached to any Vehicle release DML Task and referenced Vehicle/CCV must have the TechSpec and added to solutions of Task.\nPlease Check or Contact PLM Support Team !","ERROR",SWT.ICON_ERROR);

						return UpdDlgFlg;
					}
				}
				if(SelectedObjType==null)
				{
					UpdDlgFlg=false;
					MessageBox.post(PlatformHelper.getCurrentShell(),"Part Type can not be NULL for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
					return UpdDlgFlg;
				}

				//if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") )
				//date:-04/04/2019 


				System.out.println("part Type is Module, process can execute");
				if(SelectedObjType.equals("Module")) //Case For : Module
				{
					String ModuleAddress=selectedObj.getPropertyDisplayableValue("t5_ModuleAddress");
					System.out.println("ModuleAddress:----------  "+ModuleAddress);
					if(ModuleAddress==null || ModuleAddress.length()<=0)
					{
						UpdDlgFlg=false;
						MessageBox.post(PlatformHelper.getCurrentShell(),"Module Address is not available for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
						//return UpdTechObj.isSuccess();
						return UpdDlgFlg;
					}
					else
					{
						//Added by Rajesh on 10052019 to avoid the classification window if clsobj is not found
						String classdesc = null;
						modClsname=null;
						String noClsClassFndErrMsg=null;
						String projcode=modulenum.substring(0,4);
						System.out.println("b4 call getClsNmaeForModuleAdd projcode="+projcode +"ModuleAddress="+ModuleAddress );
						if(VehBU!=null)
						{
							//modClsname=getClsNmaeForModuleAdd(projcode,ModuleAddress);
							if(VehBU.equals("CAR"))	
							{
								modClsname=ModuleAddress;
							}
							else
							{
								modClsname=VehBU+ModuleAddress;
							}
						}
						else
						{
							modClsname=getClsNmaeForModuleAdd(projcode,ModuleAddress);
						}
						System.out.println("after call getClsNmaeForModuleAdd modClsname="+modClsname );

						try
						{
							//classdesc=new GetClassDescriptions().getClassDesc(session,ModuleAddress);
							if(modClsname.length()>0)
							{
								classdesc=new GetClassDescriptions().getClassDesc(session,modClsname);
							}
						}
						catch (ServiceException s)
						{
							s.printStackTrace();
						}
						//if Module-Address is not Present is Classification -Hiearchy,
						//do not show classification Dialog , check-in Dialog is shown.
						if(classdesc==null) 
						{
							UpdDlgFlg=true;//show checkin dialog
							noClsClassFndErrMsg="Module-Address [";
							noClsClassFndErrMsg=noClsClassFndErrMsg+modClsname;
							noClsClassFndErrMsg=noClsClassFndErrMsg+"] is not Present is Classification -Hiearchy,Contact PLM Admin Team!";
							System.out.println("noClsClassFndErrMsg="+noClsClassFndErrMsg );
							MessageBox.post(shell,noClsClassFndErrMsg,"WARNING",SWT.ICON_WARNING);
							return UpdDlgFlg;
						}
						else
						{
							UpdDlgFlg=true;//show checkin dialog
						}


					}

				}
				else
				{

					System.out.println("part Type is not Module, option only valid to update Module's attribute only  ");

					MessageBox.post(shell,"Part Type Module Revision only allowed for this option !!","WARNING",SWT.ICON_WARNING);
					return false;//UpdTechObj.isSuccess();

				}
				System.out.println("UpdDlgFlg="+UpdDlgFlg);

				if(UpdDlgFlg==true)
				{
					ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
					UpdTechObj= new UpdateModDialog(shell,session,exe_evt,(TCComponentItemRevision)selectedObj,selectedObj,ccvList,EditFlg,VehBU);
					try{
						UpdTechObj.open();
						Exception opex=UpdTechObj.getOpenexception();
						if(opex!=null)
						{

							MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
							UpdTechObj.close();

						}
					}catch(Exception e)
					{

						e.printStackTrace();
					}
				}


			} catch (Exception  e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
		return UpdTechObj.isSuccess();	
	}
	
	public boolean invokeChkInDlg(Shell shell,TCSession session,ExecutionEvent exe_evt,TCComponent selectedObj,String selectedBusUnit)
	{
		ICOValues val =null;
		UpdateCheckInMDMDialog UpdTechObj = null;
		String TSBusiUnit=null;

		String SelobjType= selectedObj.getType();

		System.out.println("\nstart invokeChkInDlg SelobjType="+SelobjType + " selectedBusUnit="+selectedBusUnit);





		 // If CCV or Vehicle or Module is selected
		


			String modulenum=null;
			String SelectedObjType=null;
			String BuinessUnit=null;
			String revid=null;
			String projcode=null;
			try {
				boolean UpdDlgFlg=true; // This flag is taken to show/not show check-in dialog ; 
				//false:-> do not show check-in Dialog ,
				// true:-> show check-in Dialog
				modulenum = selectedObj.getPropertyDisplayableValue("item_id");
				revid = selectedObj.getPropertyDisplayableValue("item_revision_id");
				System.out.println("modulenum====="+modulenum +"revid"+revid);
				//for VC Update
				SelectedObjType = selectedObj.getPropertyDisplayableValue("t5_PartType");
				System.out.println("SelectedObjType:-"+SelectedObjType);
				
				projcode = modulenum.substring(0,4);
				System.out.println("projcode:-"+projcode);
				//t5_ProjectCode
				
				
				
				if(SelectedObjType==null)
				{
					UpdDlgFlg=false;
					MessageBox.post(PlatformHelper.getCurrentShell(),"Part Type can not be NULL for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
					return UpdDlgFlg;
				}

				//if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") )
				//date:-04/04/2019 
				if(SelectedObjType.equals("Module") || SelectedObjType.equals("M"))
				{

					System.out.println("part Type is Module, process can execute");
					if(SelectedObjType.equals("Module")) //Case For : Module
					{
						String ModuleAddress=selectedObj.getPropertyDisplayableValue("t5_ModuleAddress");
						System.out.println("ModuleAddress:----------  "+ModuleAddress);
						
						
						
						if(ModuleAddress==null || ModuleAddress.length()<=0)
						{
							UpdDlgFlg=false;
							MessageBox.post(PlatformHelper.getCurrentShell(),"Module Address is not available for this selected object,Please Check or Contact PLM Support Team ","ERROR",SWT.ICON_ERROR);
							//return UpdTechObj.isSuccess();
							return UpdDlgFlg;
						}
						else
						{
							//Added by Rajesh on 10052019 to avoid the classification window if clsobj is not found
							String classdesc = null;
							String modClsname=null;
							System.out.println("b4 call getClsNmaeForModuleAdd projcode="+projcode +"ModuleAddress="+ModuleAddress +" selectedBusUnit="+selectedBusUnit );
							if(selectedBusUnit==null)
							{
								modClsname=getClsNmaeForModuleAdd(projcode,ModuleAddress);
								if(modClsname.contains("PRD"))
								{
									String retval=null;
									String tmpstr=null;
									GetProjVehClass GetProjVehClassDlg= new GetProjVehClass(shell);
									GetProjVehClassDlg.open();
									retval=GetProjVehClassDlg.getProjVehClsSelectedVal1();
									System.out.println("Module Part Type is valid for Technical specification update for PRD class with retval="+retval);
									
									
									if(retval!=null || retval.isEmpty()==false)
									{
										tmpstr=retval;
										String modClsnamecpy=modClsname;
										//String tmpaddrsstr=(modClsnamecpy.substring(modClsnamecpy.length()-6)),modClsnamecpy.length());

										String tmpaddrsstr=modClsnamecpy.substring(modClsnamecpy.length()-6, modClsnamecpy.length());
										System.out.println("PRD tmpaddrsstr="+tmpaddrsstr );
										if(retval.contains("CAR"))
										{
											modClsname=tmpaddrsstr;
										}
										else
										{
										modClsname=retval+tmpaddrsstr;
										}
										System.out.println("final PRD tmpaddrsstr="+modClsname );
									}
								}
									
							}
							
							
						/*
						 * else if(selectedBusUnit.contains("PRD")) { String retval=null;
						 * System.out.println("start newly added for PRD class logic " );
						 * //if(modClsname.contains("PRD")) //{ GetProjVehClass GetProjVehClassDlg= new
						 * GetProjVehClass(shell); GetProjVehClassDlg.open();
						 * retval=GetProjVehClassDlg.getProjVehClsSelectedVal1(); //
						 * retval=GetProjVehClassDlg.getShell().getText(); }
						 * System.out.println("end newly added for PRD class logic with retval="+retval)
						 * ; if(retval!=null || retval.isEmpty()==false) { String
						 * modClsnamecpy=modClsname; //String
						 * tmpaddrsstr=(modClsnamecpy.substring(modClsnamecpy.length()-6)),modClsnamecpy
						 * .length());
						 * 
						 * String tmpaddrsstr=modClsnamecpy.substring(modClsnamecpy.length()-6,
						 * modClsnamecpy.length()); modClsname=retval+tmpaddrsstr; } //}
						 * System.out.println("final modClsname="+modClsname);
						 * 
						 * }
						 */
							else
							{
								if(selectedBusUnit.equals("CAR"))
								{
									modClsname=ModuleAddress;
								}
								else
								{
									modClsname=selectedBusUnit+ModuleAddress;
								}
							}
							System.out.println("after call getClsNmaeForModuleAdd modClsname="+modClsname );
							
							try
							{
								//classdesc=new GetClassDescriptions().getClassDesc(session,ModuleAddress); //hashed on 10/06/2022
								//if(modClsname.length()>0)
								if(modClsname!=null)
								{
									classdesc=new GetClassDescriptions().getClassDesc(session,modClsname);
								}
							}
							catch (ServiceException s)
							{
								s.printStackTrace();
							}
							//if Module-Address is not Present is Classification -Hiearchy,
							//do not show classification Dialog , check-in Dialog is shown.
							if(classdesc==null) 
							{
								UpdDlgFlg=true;//show checkin dialog
								return UpdDlgFlg;
							}
							else
							{
								UpdDlgFlg=true;//show checkin dialog
							}


						}

					}
					
					System.out.println("UpdDlgFlg="+UpdDlgFlg);

					if(UpdDlgFlg==true)
					{
						ArrayList<TCComponentItemRevision> ccvList=new ArrayList<TCComponentItemRevision>();
						//UpdTechObj= new UpdateTechSpecDialog(shell,session,exe_evt,(TCComponentItemRevision)selectedObj,selectedObj,ccvList);
						UpdTechObj= new UpdateCheckInMDMDialog(shell,session,exe_evt,(TCComponentItemRevision)selectedObj,selectedObj,ccvList,selectedBusUnit);
						try{
							UpdTechObj.open();
							Exception opex=UpdTechObj.getOpenexception();
							if(opex!=null)
							{
								
								MessageBox.post(shell,opex.getMessage(),"Error",SWT.ICON_WARNING);
								UpdTechObj.close();
								
							}
							}catch(Exception e)
							{
								
								e.printStackTrace();
							}
					}
				}
				else
				{

					System.out.println("part Type is not Module Revision, option only valid for Module,so skip technical attributes for module check-in");

					//MessageBox.post(shell,"Part Type Module Revision only allowed for this option !!","WARNING",SWT.ICON_WARNING);
					//return false;//UpdTechObj.isSuccess();

				}

			} catch (Exception  e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			System.out.println("\n End invokeChkInDlg with UpdTechObj.isSuccess()="+UpdTechObj.isSuccess() );
		
		return UpdTechObj.isSuccess();	
	}
	

}
