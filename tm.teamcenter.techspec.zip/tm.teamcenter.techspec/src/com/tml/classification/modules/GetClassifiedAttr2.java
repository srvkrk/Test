package com.tml.classification.modules;

import java.math.BigInteger;
import java.util.Map;

import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentICO;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
//import com.teamcenter.services.loose.classification._2011_12.Classification;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationProperty;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationPropertyValue;
import com.teamcenter.services.rac.classification._2007_01.Classification.CreateClassificationObjectsResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.FindClassificationObjectsResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.FindClassifiedObjectsResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.GetClassDescriptionsResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.GetClassificationObjectsResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.SearchClassAttributes;
import com.teamcenter.services.rac.classification._2007_01.Classification.SearchResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.UpdateClassificationObjectsResponse;
import com.teamcenter.services.rac.classification._2011_12.Classification.AttrDescriptor;
import com.teamcenter.services.rac.classification._2011_12.Classification.AttributeValues;
import com.teamcenter.services.rac.classification._2011_12.Classification.ClassAttrDescriptor;
import com.teamcenter.services.rac.classification._2011_12.Classification.ClassAttrInfo;
import com.teamcenter.services.rac.classification._2011_12.Classification.ClassificationInfoResponse;
import com.teamcenter.services.rac.classification._2011_12.Classification.Value;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.soa.client.model.ModelObject;
import com.teamcenter.soa.client.model.ServiceData;
import com.teamcenter.soa.exceptions.NotLoadedException;

public class GetClassifiedAttr2 
{

	private TCComponentItem selectedObj;
	private TCSession session;
	public GetClassifiedAttr2(TCComponentItem selectedObj,TCSession session) 
	{
		super();
		// TODO Auto-generated constructor stub
		this.selectedObj=selectedObj;
		this.session=session;
		
		
		
	}

	//clsService.findClassificationObjects(null).icos.
	
	// public  ICOValues getICOProps()throws ServiceException
	//public  ICOValues getICOProps(String SelVehTSBusUnit)throws ServiceException  //this has been added newly on 02/12/2022
	public  ICOValues getICOProps(String VCBU)throws ServiceException  //this has been added newly on 02/12/2022  
	{
	        ClassificationService clsService = ClassificationService.getService(session);
	        System.out.println("Calling Classification::createClassificationObjects() ... VCBU="+VCBU);
	        
	       SearchClassAttributes attr=new SearchClassAttributes();
	        
	      //  attr.classIds=new String[]{"MB1A01"};
	      //  SearchResponse resp=clsService.search(new SearchClassAttributes[]{attr});
	       // Map<Object,Object> map= resp.clsObjTags;
	
	       FindClassificationObjectsResponse response =clsService.findClassificationObjects(new TCComponentItem []{selectedObj});
	        Map<TCComponent, TCComponent[]> map= response.icos;
	        System.out.println("\t Class Details1 -");
	        for( TCComponent key : map.keySet())
	         {
					/*
					 * try { System.out.println("map.get(key) getClassificationClass="+key.
					 * getClassificationClass()); } catch (TCException e1) { // TODO Auto-generated
					 * catch block e1.printStackTrace(); }
					 */
	            TCComponent[] objs=map.get(key);
	            System.out.println("objs.length="+objs.length);
	            for(int x=0;x<objs.length;x++)
	            {
	            TCComponentICO fg=(TCComponentICO) objs[x];
	           
	        
	         //  fg.get
	           // System.out.println("Val1="+objs[x].getUid());
	            try {
					System.out.println("cls name="+objs[x].getClassificationClass().indexOf(-1));
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	           // int v[]={0};
	           // int v[]=x;
	            
	            ClassificationInfoResponse re= null;
	            try
	            {
	           re= clsService.getClassificationObjectInfo(new String[]{objs[x].getUid()},new int[0] , false, true, "en_US");
	            }catch(Exception e)
	            {
	            	
	            	e.printStackTrace();
	            }
	            if(re==null)
	            	return null;
	           // System.out.println("jgfgfdbvmap1 key="+key);
	            GetClassificationObjectsResponse getresp=clsService.getClassificationObjects(( TCComponent[])map.get(key));
	            Map<TCComponent, ClassificationObject> map_11=getresp.clsObjs;
	            ClassificationObject clsobj=null;
	           // System.out.println("map_11.size()="+map_11.size()+ " map_11.keySet()="+map_11.keySet()+ "VCBU="+VCBU +"map_11 VAL"+map_11.keySet());
	            for( Object key_11 : map_11.keySet())
     	         {
     	           // System.out.println("jgfgfdbvmap1.get(key)="+key_11.getClass());
     	            
     	           
     	           // System.out.println("aaqasdjhVal="+map_11.get(key_11).getClass());
     	          // System.out.println(" map_11.keySet() name="+map_11.keySet().toString() +"map_11.keySet() size="+map_11.keySet().size());
     	          clsobj=map_11.get(key_11);
     	         }
     	          // clsobj=map_11.get(key_11);
     	        //}
	            
	         /*   Map<String,AttrDescriptor> map11=re.classAttributeDesc;
	            
	            
	            
	            for( Object key11 : map11.keySet())
      	         {
      	            System.out.println("jgfgfdbvmap1.get(key)="+key11.getClass());
      	           
      	            System.out.println("aaqasdjhVal="+map11.get(key11).getClass());
      	          Map<Object,ClassAttrDescriptor> map12=  map11.get(key11).attrDescMap;
      	          
      	          
      	        for( Object key12 : map11.keySet())
     	         {
     	            System.out.println("jgfgfdbvmap1.get(key)="+key12.getClass());
     	           
     	            System.out.println("aaqasdjhVal="+map11.get(key12).getClass());
     	           ClassAttrDescriptor cls= map12.get(key12);
     	          
     	       
     	         }
      	       
      	         }
	            
	         */   
	            
	            Map<String, ClassAttrInfo> map1= re.classificationObjectInfo;
	           	        
	           	        System.out.println("\t Class Details2 -");
	           	        for( String key1 : map1.keySet())
	           	         {
	           	        // System.out.println("jbvmap1.get(key) val="+key1);
	           	         //   System.out.println("jbvmap1.get(key)="+key1.getClass());
	           	           
	           	       //     System.out.println("jhVal="+map1.get(key1).getClass());
	           	        
	           	         
	           	         ClassAttrInfo info= map1.get(key1);
	           	      Map<BigInteger, AttributeValues> map2= info.attrValuesMap;
	           	      System.out.println("Classified Item="+info.icoId);
	           	        System.out.println("Classified class="+info.cid);
	           	        //if(info.cid.contains(SelVehTSBusUnit)) //this has been added newly on 02/12/2022
	           	     if(info.cid.contains(VCBU)) //this has been added newly on 02/12/2022
	           	        {
	           	        	for( Object key2 : map2.keySet())
	           	        	{
	           	        		//System.out.println("keyw.get(key2)="+key2.getClass());

	           	        		//System.out.println("kssl="+map2.get(key2).getClass());
	           	        		AttributeValues fv=map2.get(key2);
	           	        		Value[] vals=  fv.values;
//	           	        		for(int x1=0;x1<vals.length;x1++)
//	           	        		{
//	           	        			System.out.println("key2"+key2+" Val:"+vals[x1].attrValue);
//	           	        		}
	           	        	}
	           	         //clsobj=map_11.get(key_11);
	           	         //System.out.println("ICOValues clsobj="+clsobj);
		           	        return new ICOValues(clsobj,info.icoId,info.cid,map2);
	           	        }
	           	     else
	           	     {
	           	    	 if((info.cid.length()<=6) && VCBU.contains("CAR"))
	           	    	 {
	           	    		for( Object key2 : map2.keySet())
	           	        	{
	           	        		//System.out.println("keyw.get(key2)="+key2.getClass());

	           	        		//System.out.println("kssl="+map2.get(key2).getClass());
	           	        		AttributeValues fv=map2.get(key2);
	           	        		Value[] vals=  fv.values;
//	           	        		for(int x1=0;x1<vals.length;x1++)
//	           	        		{
//	           	        			System.out.println("key2"+key2+" Val:"+vals[x1].attrValue);
//	           	        		}
	           	        	}
	           	         //clsobj=map_11.get(key_11);
	           	         System.out.println("ICOValues clsobj="+clsobj);
		           	        return new ICOValues(clsobj,info.icoId,info.cid,map2); 
	           	    	 }
	           	     }
	           	      //  System.out.println("ICOValues(clsobj="+clsobj);
	           	       // return new ICOValues(clsobj,info.icoId,info.cid,map2);
	           	         }
     	         //}
	            }
	         }
	       /* 
	        GetClassDescriptionsResponse  classDescResponse = clsService.getClassDescriptions( new String[]{"MB1A01"} );
	        
	        
 Map<Object,Object> map1= classDescResponse.descriptions;
	        
	        System.out.println("\t Class Details -");
	        for( Object key : map1.keySet())
	         {
	            System.out.println("map1.get(key)="+key.getClass());
	           
	            System.out.println("Val="+map1.get(key).getClass());
	          
	           
	         }*/
	      /*  FindClassificationObjectsResponse response =clsService.findClassificationObjects(new TCComponentItemRevision []{selectedObj});
	        Map<Object,Object> map= response.icos;
	        ServiceDataError(response.data);
	       
	        System.out.println("\t Class Details -");
	        for( Object key : map.keySet())
	         {
	            System.out.println("map.get(key)="+((TCComponent)key).toDisplayString());
	            TCComponent[] icosval=(TCComponent[])map.get(key);
	            System.out.println("Val="+map.get(key));
	            System.out.println("Val1="+icosval[0].toDisplayString());
	           
	         }
	        */
	        
	        return null;
	    }	
	public  ICOValues getICOProps2()throws ServiceException  //this has been added newly on 02/12/2022  
	{
	        ClassificationService clsService = ClassificationService.getService(session);
	        System.out.println("Calling Classification::createClassificationObjects() ..."+clsService +" selectedObj="+selectedObj);
	        
	       SearchClassAttributes attr=new SearchClassAttributes();
	        
	      //  attr.classIds=new String[]{"MB1A01"};
	      //  SearchResponse resp=clsService.search(new SearchClassAttributes[]{attr});
	       // Map<Object,Object> map= resp.clsObjTags;
	
	       FindClassificationObjectsResponse response =clsService.findClassificationObjects(new TCComponentItem []{selectedObj});
	       //response.getClass()
	       Map<TCComponent, TCComponent[]> map= response.icos;
	        System.out.println("\t Class Details1 -");
	        System.out.println("\t map.keySet() -"+map.keySet());
	        for( TCComponent key : map.keySet())
	         {
	           // System.out.println("map.get(key)="+key.getClass());
	            TCComponent[] objs=map.get(key);
	            System.out.println("objs.length="+objs.length);
	            for(int x=0;x<objs.length;x++)
	            {
	            	
	            //TCComponentICO fg=(TCComponentICO) objs[x];
	           
	            String classname="";
				try {
					System.out.println("getObjectString="+objs[x].getPropertyDisplayableValue("cid"));
					classname = objs[x].getClassificationClass();
				} catch (TCException | NotLoadedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	            }
	         //  fg.get
	            System.out.println("Val1="+objs[0].getUid()  );
	           // int v[]={0};
	           // int v[]=x;
	            
	            ClassificationInfoResponse re= null;
	            try
	            {
	          // re= clsService.getClassificationObjectInfo(new String[]{objs[x].getUid()},new int[0] , false, true, "en_US");
	            	 re= clsService.getClassificationObjectInfo(new String[]{objs[0].getUid()},new int[0] , false, true, "en_US");
	            }catch(Exception e)
	            {
	            	
	            	e.printStackTrace();
	            }
	            if(re==null)
	            	return null;
	            GetClassificationObjectsResponse getresp=clsService.getClassificationObjects(( TCComponent[])map.get(key));
	            Map<TCComponent, ClassificationObject> map_11=getresp.clsObjs;
	            ClassificationObject clsobj=null;
	            for( Object key_11 : map_11.keySet())
     	         {
     	           // System.out.println("jgfgfdbvmap1.get(key)="+key_11.getClass());
     	           
     	            //System.out.println("aaqasdjhVal="+map_11.get(key_11).getClass());
     	           clsobj=map_11.get(key_11);
     	         }
	            
	         /*   Map<String,AttrDescriptor> map11=re.classAttributeDesc;
	            
	            
	            
	            for( Object key11 : map11.keySet())
      	         {
      	            System.out.println("jgfgfdbvmap1.get(key)="+key11.getClass());
      	           
      	            System.out.println("aaqasdjhVal="+map11.get(key11).getClass());
      	          Map<Object,ClassAttrDescriptor> map12=  map11.get(key11).attrDescMap;
      	          
      	          
      	        for( Object key12 : map11.keySet())
     	         {
     	            System.out.println("jgfgfdbvmap1.get(key)="+key12.getClass());
     	           
     	            System.out.println("aaqasdjhVal="+map11.get(key12).getClass());
     	           ClassAttrDescriptor cls= map12.get(key12);
     	          
     	       
     	         }
      	       
      	         }
	            
	         */   
	            
	            Map<String, ClassAttrInfo> map1= re.classificationObjectInfo;
	          //  Map<String, ClassAttrInfo> map1= re.        
	           	        System.out.println("\t Class Details2 -"+map1.size());
	           	        for( String key1 : map1.keySet())
	           	         {
	           	        // System.out.println("jbvmap1.get(key) val="+key1);
	           	         //   System.out.println("jbvmap1.get(key)="+key1.getClass());
	           	           
	           	         //   System.out.println("jhVal="+map1.get(key1).getClass());          	          
	           	         ClassAttrInfo info= map1.get(key1);
	           	      //System.out.println("map1.values()= "+map1.values().size());
	           	      Map<BigInteger, AttributeValues> map2= info.attrValuesMap;
	           	      System.out.println("Classified Item="+info.icoId);
	           	        System.out.println("Classified class="+info.cid);
	           	        //if(info.cid.contains(SelVehTSBusUnit)) //this has been added newly on 02/12/2022
	           	        //if(info.cid.contains(SelVehTSBusUnit)) //this has been added newly on 02/12/2022
	           	        {
	           	        	for( Object key2 : map2.keySet())
	           	        	{
	           	        		//System.out.println("keyw.get(key2)="+key2.getClass());

	           	        		//System.out.println("kssl="+map2.get(key2).getClass());
	           	        		AttributeValues fv=map2.get(key2);
	           	        		Value[] vals=  fv.values;
//	           	        		for(int x1=0;x1<vals.length;x1++)
//	           	        		{
//	           	        			System.out.println("key2"+key2+" Val:"+vals[x1].attrValue);
//	           	        		}
	           	        	}
	           	        }
	           	        System.out.println("ICOValues clsobj="+clsobj);
	           	        return new ICOValues(clsobj,info.icoId,info.cid,map2);
	           	         }
	            //}
	         }
	       /* 
	        GetClassDescriptionsResponse  classDescResponse = clsService.getClassDescriptions( new String[]{"MB1A01"} );
	        
	        
 Map<Object,Object> map1= classDescResponse.descriptions;
	        
	        System.out.println("\t Class Details -");
	        for( Object key : map1.keySet())
	         {
	            System.out.println("map1.get(key)="+key.getClass());
	           
	            System.out.println("Val="+map1.get(key).getClass());
	          
	           
	         }*/
	      /*  FindClassificationObjectsResponse response =clsService.findClassificationObjects(new TCComponentItemRevision []{selectedObj});
	        Map<Object,Object> map= response.icos;
	        ServiceDataError(response.data);
	       
	        System.out.println("\t Class Details -");
	        for( Object key : map.keySet())
	         {
	            System.out.println("map.get(key)="+((TCComponent)key).toDisplayString());
	            TCComponent[] icosval=(TCComponent[])map.get(key);
	            System.out.println("Val="+map.get(key));
	            System.out.println("Val1="+icosval[0].toDisplayString());
	           
	         }
	        */
	        
	        return null;
	    }
	
	 protected boolean ServiceDataError(final ServiceData data)
	 {
	     if(data.sizeOfPartialErrors() > 0)
	     {
	             for(int i = 0; i < data.sizeOfPartialErrors(); i++)
	             {
	                      for(String msg :
	 data.getPartialError(i).getMessages())
	                              System.out.println("ServiceDataError:"+msg);
	             }

	             return true;
	     }

	     return false;
	 }
	
}
