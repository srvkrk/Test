package com.tml.classification.modules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.StringTokenizer;

import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.structuremanagement._2011_06.Structure.ClosureRuleVariableInfo;
import com.teamcenter.soa.exceptions.NotLoadedException;

public class BOMExpansion4ModException {

	private HashMap<String,TCComponentItemRevision> class_not_found;
	private HashMap<String,LinkedHashSet<String>> expansion_address;
	private String modClsname =null;
	 
	private LinkedHashSet<String> expansionupto;
	public BOMExpansion4ModException() {
		// TODO Auto-generated constructor stub
		super();
		class_not_found=new HashMap<String,TCComponentItemRevision>();
		try {
			expansion_address=populateExpansionAddress();
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	public ClassificationObject getClassificationObject1(TCComponentItemRevision assemblyRevision)
	{

		
		TCComponentItem tc_ico_item=null;
		try {
			tc_ico_item=assemblyRevision.getItem();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//GetClassifiedAttr getProps= new GetClassifiedAttr(tc_ico_item,assemblyRevision.getSession());
		GetClassifiedAttr2 getProps= new GetClassifiedAttr2(tc_ico_item,assemblyRevision.getSession());

		ClassificationObject clsobjs=null;

		
		ICOValues icoval;
		try {
			//icoval = getProps.getICOProps(modClsname);
			//icoval = getProps.getICOProps();
			icoval = getProps.getICOProps2();

			if(icoval != null)
			{
				/*	ModuleAddress=icoval.getCid();
					ObjectID=icoval.getIcoId();
					childrevDispStr=assemblyRevision.toDisplayString();*/

				clsobjs=icoval.getClsobjs();					

			}
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clsobjs;

	}
	
	public ClassificationObject getClassificationObject2(TCComponentItemRevision assemblyRevision)
	{

		
		TCComponentItem tc_ico_item=null;
		try {
			tc_ico_item=assemblyRevision.getItem();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println(" inside getClassificationObject ");
		GetClassifiedAttr2 getProps= new GetClassifiedAttr2(tc_ico_item,assemblyRevision.getSession());

		ClassificationObject clsobjs=null;

		System.out.println("inside getClassificationObject BOM Expansion TSBusiUnit:-"+modClsname);
		ICOValues icoval;
		try {
			//icoval = getProps.getICOProps(modClsname);
			icoval = getProps.getICOProps2();

			if(icoval != null)
			{
				/*	ModuleAddress=icoval.getCid();
					ObjectID=icoval.getIcoId();
					childrevDispStr=assemblyRevision.toDisplayString();*/

				clsobjs=icoval.getClsobjs();					

			}
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clsobjs;

	}
	// Classification Attribute/Value for a assemblyRevision
	public ClassificationTreeLine setclsValues1(TCComponentItemRevision assemblyRevision,TCSession tcsession,String SelVehTSBusUnit) throws TCException
	{

		System.out.println("inside the   fun ssetclsValues11 "+assemblyRevision.toDisplayString() +" SelVehTSBusUnit="+SelVehTSBusUnit); 
		ClassificationTreeLine treeline=null;
		String ModuleAddress=null;
		String ObjectID=null;
		String childrevDispStr=null;
		String SelectedObjType=null;
		String BuinessUnit = null;
		String itemID=null;
		String revid=null;
		ClassificationObject clsobjs=null;
		String projcode=null;
		String childparttype=null;
		String actualModAddrs=null;
		try {
			SelectedObjType = assemblyRevision.getPropertyDisplayableValue("t5_PartType");
			if(SelectedObjType!=null)
			{
				if(SelectedObjType.contains("Module"))
				{
					childparttype=SelectedObjType;
					actualModAddrs = assemblyRevision.getPropertyDisplayableValue("t5_ModuleAddress");
				}
			}
		} catch (NotLoadedException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		System.out.println("inside setclsValues1 func SelectedObjType:-"+SelectedObjType +" childparttype="+childparttype);
		TCComponentItem tc_ico_item=null;
		try {
			tc_ico_item=assemblyRevision.getItem();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		GetClassifiedAttr getProps= new GetClassifiedAttr(tc_ico_item,tcsession,SelVehTSBusUnit);
		
		//String modClsname =null;
		try {
			//ICOValues icoval=getProps.getICOProps(modClsname);
			ICOValues icoval=getProps.getICOProps();
			if(icoval != null)
			{
				ModuleAddress=icoval.getCid();
				ObjectID=icoval.getIcoId();
				childrevDispStr=assemblyRevision.toDisplayString();
				clsobjs=icoval.getClsobjs();					

			}
			else
			{

				try {
					SelectedObjType = assemblyRevision.getPropertyDisplayableValue("t5_PartType");
					System.out.println("SelectedObjType:-"+SelectedObjType);
					if(SelectedObjType!=null)
					{
						if(SelectedObjType.contains("Module"))
						{
						childparttype+=SelectedObjType;
						}
					}
					System.out.println("childparttype:-"+childparttype);
					//date:-04/04/2019 
					//if(SelectedObjType.equals("Vehicle") )
					if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Vehicle Combination") || SelectedObjType.equals("Configurable VC") || SelectedObjType.equals("Vehicle Combination CR"))
					{
						TCComponent[] TechSpecObj=  assemblyRevision.getTCProperty("T5_VCSpec").getReferenceValueArray();
						if(TechSpecObj!=null && TechSpecObj.length>0)
						{
							BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
							System.out.println("BuinessUnit:----------  "+BuinessUnit);
							ModuleAddress=BuinessUnit+"VCATTR01";
							itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
							revid=assemblyRevision.getPropertyDisplayableValue("item_revision_id");
							ObjectID=itemID;//+"/"+revid;
							childrevDispStr=assemblyRevision.toDisplayString();

						}



					}
					else
						//if(SelectedObjType.equals("Vehicle") )
					{
						//TCComponent[] TechSpecObj=  assemblyRevision.getTCProperty("T5_VCSpec").getReferenceValueArray();

						//BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
						//System.out.println("BuinessUnit:----------  "+BuinessUnit);
						ModuleAddress=assemblyRevision.getPropertyDisplayableValue("t5_ModuleAddress");
						System.out.println("ModuleAddress:----------  "+ModuleAddress);
						childparttype=assemblyRevision.getPropertyDisplayableValue("t5_PartType");
						System.out.println("childparttype:----------  "+childparttype);
						itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
						revid=assemblyRevision.getPropertyDisplayableValue("item_revision_id");
						ObjectID=itemID;//+"/"+revid;
						childrevDispStr=assemblyRevision.toDisplayString();
						projcode=itemID.substring(0, 4);
						
						/*
						 * try { childparttype=assemblyRevision.getTCProperty("t5_PartType").
						 * getDisplayableValue(); } catch (TCException e3) { // TODO Auto-generated
						 * catch block e3.printStackTrace(); }
						 */
			    		System.out.println("inside BOMExpansion child projcode="+projcode +"modaddress="+ModuleAddress +"childparttype="+childparttype );



					}
				} catch (NotLoadedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			
			
			System.out.println("in BOMExpansion b4 call getClsNmaeForModuleAdd projcode="+projcode +"modaddress="+ModuleAddress +"childparttype="+childparttype +" SelVehTSBusUnit="+SelVehTSBusUnit );
			try {
				if(SelVehTSBusUnit==null)
				{
				 modClsname = TechSpecUtil.getClsNmaeForModuleAdd(projcode,ModuleAddress);
				}
				else if(SelVehTSBusUnit.equals("CAR"))
				{
					System.out.println("actualModAddrs="+actualModAddrs);
					//modClsname=ModuleAddress;
					modClsname=actualModAddrs;
				}
				else if((SelVehTSBusUnit.length()>6) && (SelVehTSBusUnit.contains(ModuleAddress)))
				{
					modClsname=SelVehTSBusUnit;
				}
				else if(ModuleAddress.contains(SelVehTSBusUnit))
				{
					modClsname=ModuleAddress;
				}
				else
				{
					modClsname=SelVehTSBusUnit+actualModAddrs;
				}
					
			} catch (NotLoadedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("in BOMExpansion after call getClsNmaeForModuleAdd modClsname="+modClsname+" childparttype="+childparttype );
			if(childparttype!=null)
			{
				if(childparttype.equals("Module"))
			  	{
					String classdesc = new GetClassDescriptions().getClassDesc(tcsession,modClsname);
					System.out.println("in BOMExpansion newModuleAddress-  "+modClsname +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr+" assemblyRevision"+assemblyRevision+"clsobjs="+clsobjs+" classdesc="+classdesc);
					treeline =new ClassificationTreeLine(childrevDispStr, modClsname,ObjectID,assemblyRevision,clsobjs,classdesc);
			  	}
				else
				{
					String classdesc = new GetClassDescriptions().getClassDesc(tcsession,ModuleAddress);
					System.out.println("2 in BOMExpansion ModuleAddress-  "+ModuleAddress +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
					treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,assemblyRevision,clsobjs,classdesc);
				}
			}
			else
			{
				String classdesc = new GetClassDescriptions().getClassDesc(tcsession,ModuleAddress);
				System.out.println("3 in BOMExpansion ModuleAddress-  "+ModuleAddress +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
				treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,assemblyRevision,clsobjs,classdesc);
			}
//			String classdesc = new GetClassDescriptions().getClassDesc(tcsession,ModuleAddress);
//			System.out.println("ModuleAddress-  "+ModuleAddress +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
//			treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,assemblyRevision,clsobjs,classdesc);
			//ClassifyList.add(treeline);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			////////////	MessageBox.post(PlatformHelper.getCurrentShell(),e.getMessage(),"ERROR",SWT.ICON_ERROR);

			
			//class_not_found.put("Classification "+ ModuleAddress + " Not Found ",assemblyRevision);
			if(childparttype!=null)
			{
				if(childparttype.equals("Module"))
			  	{
					class_not_found.put("Classification "+ modClsname + " Not Found ",assemblyRevision);
			  	}
			}
			else
			{
				class_not_found.put("Classification "+ ModuleAddress + " Not Found ",assemblyRevision);
			}
			e.printStackTrace();
		}

		return treeline;

	}
	
	HashMap<String,LinkedHashSet<String>> populateExpansionAddress() throws TCException
	{
		
		HashMap<String,LinkedHashSet<String>> exp_addr=new HashMap<String,LinkedHashSet<String>>();
		
		
		
String infostr="";
		
		
		String [] qryNames={"SYSCD","SUBSYSCD"};
		String [] qryValues={"ICOEXPLIST","TECHSPEC"};
		int r;
		TCComponent[] objvec=TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
		Object info=null;
		if(objvec!=null)
		{
			for(int f=0;f<objvec.length;f++)
			{
				TCComponent objcntrl=objvec[f];
				
				
					
				String[] infoattr=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_Userinfo10"};
				
				int len=infoattr.length;
				
				for(r=0;r<len;r++)
				{
				
				 info=objcntrl.getTCProperty(infoattr[r]);
				
				if(info==null) continue;
				if(info!=null)
					infostr+=info.toString()+",";	
							
				
				
				}
				
				
				
				StringTokenizer stkinfostr=new StringTokenizer(infostr,",");
				
					while(stkinfostr.hasMoreElements())
				{
					
					String attrs=stkinfostr.nextToken();
					String[] attrs1=attrs.split(":");
					
					LinkedHashSet<String> attrlist=new LinkedHashSet<String>();
					
					if(attrs1[1].contains("+"))
					{
						String[] attrs2=attrs1[1].split("+");
						
						for (int y=0;y<attrs2.length;y++)
							attrlist.add(attrs2[y]);
						
					}
					else
					{
						
						attrlist.add(attrs1[1]);
					}
					
					exp_addr.put(attrs1[0],attrlist);
					
					
				}
					
			
			}
		}
		
		
		
		return exp_addr ;
	}

	// Get Structure from Snapshot Attached to CCV  under T5_PartHasSnapShot
	public ArrayList<ClassificationTreeLine> getTCUAStructureSnapshot(TCSession tcsession,TCComponentItemRevision assemblyRevision,boolean fullexpandable,String SelVehTSBusUnit) throws TCException, NotLoadedException
	{

		//     TCComponentItemRevision assemblyRevision=(TCComponentItemRevision)assemblyRevision1;
		ArrayList<TCComponentItemRevision> allbomlist=new ArrayList<TCComponentItemRevision>();
		ArrayList<ClassificationTreeLine> ClassifyList=new  ArrayList<ClassificationTreeLine>();
		ClassificationTreeLine clsval=setclsValues1(assemblyRevision,tcsession,SelVehTSBusUnit);
		
		ClassificationHiearchyClasses hie_cls=new ClassificationHiearchyClasses();
		ArrayList<String> clsset=hie_cls.getClsHiearchy("ICM010102");
		
		System.out.println("clsset::"+clsset.toString());
		
		if(clsval!=null)
			ClassifyList.add(clsval);


		TCComponent[] snapshot = assemblyRevision.getTCProperty("T5_PartHasSnapShot").getReferenceValueArray();// get bvrs
		System.out.println("snapshot="+snapshot );
		if(snapshot!=null && snapshot.length>0)
		{

			TCComponent snapshotdata=snapshot[0];

			TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
			TCComponentBOMWindow bomWin = bowWinType.create(snapshotdata);       // create bom window from snapshot
		
			System.out.println("bomWin= "+bomWin  );

			System.out.println("snapshotdata="+snapshotdata  );
			
			
			 ClosureRuleVariableInfo[] crVarInfos = new ClosureRuleVariableInfo[1];


		  		crVarInfos[0] = new ClosureRuleVariableInfo();


		  		crVarInfos[0].name = ""; 


		  		crVarInfos[0].value = "";

		  		//String closureRuleName="BOMLineskipforunconfigured";
		  		String closureRuleName="BOMLineSkipZeroQtyMaskUnconfig";
		  		
		  		//bomWin.setClosureRuleName(closureRuleName);
		  		//bomWin.setClosureRule(clrule);
		  		
		  		//Structure.ClosureRuleVariableInfo   clvar=new Structure.ClosureRuleVariableInfo();
		  		//HashMap localHashMap = new HashMap();
		  		//  localHashMap.put(clvar.name, clvar.value);
		  		//  System.out.println("localHashMap="+localHashMap);
		  		//bomWin.setClosureRuleUserEntriesMap(localHashMap) ;

		  		
		  		com.teamcenter.services.rac.structuremanagement.StructureService  structureService=com.teamcenter.services.rac.structuremanagement.StructureService.getService(tcsession);
		  						structureService.setClosureRuleVariablesAndValues(bomWin, closureRuleName, crVarInfos);




			TCComponentBOMLine bl=   bomWin.getTopBOMLine();
			System.out.println("New bl ="+bl  );


			if (bl.hasChildren()){

				AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

				//TCComponentBOMLine[] childContext =bl.getPackedLines();
				System.out.println("BOM Children count is "+childContext.length);

				System.out.println("=======================Listing Children=============");
				for(int i = 0; i < childContext.length; i++){
					//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
					TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
					TCComponentItem item = child.getItem();
					TCComponentItemRevision childItemrev=child.getItemRevision();

					String itemidval=item.getTCProperty("item_id").getDisplayableValue();
					System.out.println("itemidval:::"+itemidval);
					int itemidlength=itemidval.length();
					System.out.println("itemidlength:::"+itemidlength);
					int Begindx=itemidlength-6;
					System.out.println("Begindx:::"+Begindx);
					String Platform=itemidval.substring(Begindx);
					System.out.println(" Platform"+Platform);

					System.out.println("22Platform:----------  "+Platform);
					if(clsset.contains(Platform))
					{
						ArrayList<TCComponentItemRevision> bomlist=getTCUAStructureInt(child);
						
						allbomlist.addAll(bomlist);
			
					}
				}

				System.out.println("====================END of Listing Children=============");
			}

			for(int x=0;x<allbomlist.size();x++)
			{
				TCComponentItemRevision moduleRevision=allbomlist.get(x);
				System.out.println(" allbomlist::"+moduleRevision);
				String mAddress=moduleRevision.getPropertyDisplayableValue("t5_ModuleAddress");
				System.out.println(" mAddress::"+mAddress);
				if(mAddress==null || mAddress.length()<=0)
					continue;
				ClassificationTreeLine clstree= setclsValues1(moduleRevision,tcsession,SelVehTSBusUnit);
				System.out.println(" clstree::"+clstree);
				if(clstree!=null)
				{
					ClassifyList.add(clstree);
				}

			}
		}
		return ClassifyList;
	}

	// Get Structure Under VC/Vehicle :-> Normal BOM Expansion
	public ArrayList<ClassificationTreeLine> getTCUAStructure(TCSession tcsession,TCComponentItemRevision assemblyRevision,boolean fullexpandable,String SelVehTSBusUnit) throws TCException, NotLoadedException
	{

		//     TCComponentItemRevision assemblyRevision=(TCComponentItemRevision)assemblyRevision1;
		ArrayList<ClassificationTreeLine> ClassifyList=new  ArrayList<ClassificationTreeLine>();
		ClassificationTreeLine clsval=setclsValues1(assemblyRevision,tcsession,SelVehTSBusUnit);
		if(clsval!=null)
			ClassifyList.add(clsval);


		if(!fullexpandable )
			return ClassifyList;

		TCComponent[] bvr = assemblyRevision.getRelatedComponents("structure_revisions");// get bvrs



		System.out.println("Listing All Revision Rule");

		TCComponentRevisionRule[] revrule=TCComponentRevisionRule.listAllRules(tcsession);
		//String revrulename="Latest Working";
		//String revrulename="ERC release and above";
		String revrulename=new TechSpecUtil().gettechspecrevrule("techspecrevrule");
		System.out.println("output revrulename="+revrulename);
		if(revrulename==null)
		{
			 revrulename="ERC release and above";
		}
		TCComponentRevisionRule currentrevrule=null;
		for(int j=0;j<revrule.length;j++)
		{

			if(revrulename.equals(revrule[j].getProperty("object_name")))
			{
				currentrevrule=revrule[j];
				break;
			}

			//System.out.println(revrulename);

		}

		System.out.println("Found the Revision Rule "+revrulename);

		TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
		TCComponentBOMWindow bomWin = bowWinType.create(currentrevrule);       // create bom window configured with the default revision rule 
		
		TCComponentBOMLine bl= bomWin.setWindowTopLine(null, assemblyRevision,null, null);

	



		System.out.println("b4 call fun ppassemblyRevision= "+assemblyRevision.toDisplayString()); 
		

		System.out.println("=========================================Getting TCUA  BOM/Global Alternate=============");

		if (bl.hasChildren()){

			AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

			//TCComponentBOMLine[] childContext =bl.getPackedLines();
			System.out.println("BOM Children count is "+childContext.length);

			System.out.println("=======================Listing Children=============");
			for(int i = 0; i < childContext.length; i++){
				//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
				TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
				TCComponentItem item = child.getItem();
				TCComponentItemRevision childItemrev=null;//child.getItemRevision();

				ArrayList<TCComponentItemRevision> itnlist =new ArrayList<TCComponentItemRevision>();
						expandModule(child,itnlist);
						ClassificationTreeLine clstree = null;
				
				if(itnlist.size()>0)
				{
					//System.out.println("from childItemrev::"+childItemrev.toDisplayString());
					childItemrev=itnlist.get(0);
					System.out.println("to childItemrev::"+childItemrev.toDisplayString());
				

				System.out.println("b4 call fun childItemrev= "+childItemrev.toDisplayString()); 

				clstree= setclsValues1(childItemrev,tcsession,SelVehTSBusUnit);
			
				System.out.println(" clstree::"+clstree);
				}
				if(clstree!=null)
				{
					ClassifyList.add(clstree);
				}



			}

			System.out.println("====================END of Listing Children=============");
		}
		return ClassifyList;
	}

	// Get Second Level Structure Normal BOM Expansion
	public  ArrayList<TCComponentItemRevision> getTCUAStructureInt(TCComponentBOMLine bl) throws TCException
	{

		System.out.println("=========================================Getting TCUA  BOM/Global Alternate=============");

		ArrayList<TCComponentItemRevision> bomlist=new ArrayList<TCComponentItemRevision>();

		if (bl.hasChildren()){

			AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

			//TCComponentBOMLine[] childContext =bl.getPackedLines();
			System.out.println("SVR BOM Children count is "+childContext.length);

			System.out.println("=======================SVR BOM Listing Children=============");
			for(int i = 0; i < childContext.length; i++){
				//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
				TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();

				TCComponentItemRevision item = child.getItem().getLatestItemRevision();
				ArrayList<TCComponentItemRevision> itnlist =new ArrayList<TCComponentItemRevision>();
				expandModule(child,itnlist);
				if(itnlist.size()>0)
				{
					bomlist.add(itnlist.get(0));
				}
					//bomlist.add(item);
				System.out.println("SVR BOM Children  is "+item.toDisplayString());		

				System.out.println("====================END of Listing Children=============");
			}

		}


		return bomlist;


	}

	public ArrayList<TCComponentItemRevision> expandModule(TCComponentBOMLine bl,ArrayList<TCComponentItemRevision> bomlist) throws TCException
	{
		
		
		TCComponentItemRevision item = bl.getItem().getLatestItemRevision();
		
		String mAddress=null;
		try {
			mAddress = item.getPropertyDisplayableValue("t5_ModuleAddress");
			System.out.println("mAddress::"+mAddress);
			if(mAddress.equals("MT3Z01"))
			{
				
				System.out.println("fffffffffffffffff");
			}
		} catch (NotLoadedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if((mAddress!=null && mAddress.isEmpty()==false ) || expansionupto!=null)
		{
		 if(expansionupto==null )
		 {
			 if(expansion_address.containsKey(mAddress)==true)
			 {
			 expansionupto=expansion_address.get(mAddress);
			 }
			else
				 bomlist.add(item);
		}
		 else
		 {
			if(expansionupto.contains(mAddress)) 
			{
				bomlist.add(item);
				expansionupto=null;
			}
		 }
		}
		
		if(expansionupto!=null)
		{
			if(bl.hasChildren())
			{
				
				AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()

				//TCComponentBOMLine[] childContext =bl.getPackedLines();
				System.out.println("BOM Children count is "+childContext.length);

				System.out.println("=======================Listing Children=============");
				for(int i = 0; i < childContext.length; i++){
					//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
					TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
					try {
						String parttype=child.getItemRevision().getPropertyDisplayableValue("t5_PartType");
						System.out.println("CCC::"+child.getItemRevision().toDisplayString());
						if(parttype.equals("Module")||parttype.equals("M")){
						expandModule(child,bomlist);
						}
					
					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

			
				}
			}
		}
	

	return bomlist;
		
		
	}

	public HashMap<String, TCComponentItemRevision> getClass_not_found() {
		return class_not_found;
	}


	public void setClass_not_found(
			HashMap<String, TCComponentItemRevision> class_not_found) {
		this.class_not_found = class_not_found;
	}
	

}
