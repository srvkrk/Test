// Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2011.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.tml.classification.modules;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.InterfaceAIFOperationListener;
import com.teamcenter.rac.kernel.TCClassificationService;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.ics.ICSAdminClass;
import com.teamcenter.rac.kernel.ics.ICSAdminClassAttribute;
import com.teamcenter.rac.kernel.ics.ICSConfiguredKeyLov;
import com.teamcenter.rac.kernel.ics.ICSDependentAttributesOperation;
import com.teamcenter.rac.kernel.ics.ICSKeyLov;
import com.teamcenter.rac.kernel.ics.ICSKeyLov.KeyLov;
import com.teamcenter.rac.kernel.ics.ICSProperty;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVDefinition2;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVEntry;
import com.teamcenter.services.rac.classification._2015_03.Classification;
import com.teamcenter.services.rac.classification._2015_03.Classification.DependencyAttributeStruct;
import com.teamcenter.services.rac.classification._2015_03.Classification.DependencyAttributeValue;
import com.teamcenter.services.rac.classification._2015_03.Classification.DependencyKeyLOVDescriptor;
import com.teamcenter.services.rac.classification._2015_03.Classification.GetDependencyKeyLOVsResponse;
import java.util.Arrays;
import java.util.regex.Pattern;
import java.util.*;
import java.util.stream.Collectors;
//import com.teamcenter.clientx.AppXSession;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;

/**
 *  This sample program get the keyLOV definitions for the specified key LOV id's.
 *  
 *  The following data must be created before executing this test.
 *     Create KeyLov with ID=-2894
 *     Add set of key value entries to -2894
 *     
 *  Refer TDoc for classification data creation
 *  
 */

public class GetKeyLOVs2Sample3  
{
      
   /**
   * get the KeyLOV definitions from keyLOV ID's.
   * 
   * @throws ServiceException
   */
    public KeyValueLOV testGetKeyLOVs2(String classID,String attrid,String lovid,String deptattr,String deptcfg,String deptval,int arrsize)throws ServiceException
    {
    	TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
        ClassificationService clsService = ClassificationService.getService(session);
        System.out.println("inside GetKeyLOVs2Sample3 testGetKeyLOVs2 func"+lovid +" classID="+classID +"deptattr="+deptattr +"arrsize="+arrsize);
        KeyValueLOV keylovval=null;
        
        if(deptattr!=null && deptattr.length()>0)
        	keylovval=depGetKeyLOVs( classID, attrid ,lovid, deptattr, deptcfg, deptval);
        else
        	keylovval=commonGetKeyLOVs(classID, attrid, lovid, deptattr, deptcfg, deptval,arrsize);
       
        
        return keylovval;

    }
    
    //Added by Rajesh on 27/09/2022
    
    private Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");

    public boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false; 
        }
        return pattern.matcher(strNum).matches();
    }
    
    public void relativeOrderSort1(List<String> list) 
    {
        /* Create a list of just the integers and just the strings
         * from the original list.
         */
    	System.out.println("inside relativeOrderSort1 func"+list);
        List<Integer> intList = new ArrayList<Integer>();
        List<String> strList = new ArrayList<String>();
        List<Double> DblList = new ArrayList<Double>();
        List<Number> IntDbllist = new ArrayList<Number>();
        int[] xx;
        System.out.println("inside original list size"+list.size());
        for (int ii = 0; ii < list.size(); ii++) {
        	String Str=list.get(ii).toString();
    		boolean isnum=isNumeric(Str);
    		System.out.println("inside relativeOrderSort1 Str"+Str +" isnum"+isnum);
			
			  if(isnum==true) 
			  { 
				  // intList.add((Integer) Str); 
				  try 
				  { 
					  //intList.add((Str);
					  intList.add(Integer.parseInt(Str)); 
					  //IntDbllist.add((Integer) Integer.parseInt(Str));
					  //Double.parseDouble(number);

				  } 
				  catch(NumberFormatException e)
				  { //not a double 
					  DblList.add(Double.parseDouble(Str));
					  // String p = Double.parseDouble(Str);
					  // Double.parseDouble(Str)); strList=Arrays.asList(Str); //String q =
					  // Integer.toString(Str); }
			  
				  } 
				 
			  }
			  else
			  {
				  if (Str instanceof String) 
				  { 
					  strList.add((String) Str);

				  }
				  else
				  {
					  //strList=Arrays.asList(Str); } else { 
					  throw new  IllegalArgumentException("List has a non-int, non-string member."); }

			  }
    		//strList=Arrays.asList(Str);
        }
        System.out.println("b4 sort inside relativeOrderSort1 intList"+intList +" strList"+strList);
        /* Sort the lists. */
        Collections.sort(intList);
        Collections.sort(DblList);
       // Arrays.sort(IntDbllist);
       // List<String>sortedList=strList.stream().sorted().collect(Collectors.toList());
       // sortedList.forEach(System.out::println);
        Collections.sort(strList);

        System.out.println("AFter sort inside relativeOrderSort1 intList"+intList +" Collections.sort(strList)="+strList +"DblList="+DblList);
     //   sortedList.forEach(System.out::println);
        /* Merge the lists back together. */
        int intIndex = 0, strIndex = 0;
        System.out.println("inside original list size"+list.size()+"intList size= "+ intList.size() +" DblList size = "+DblList.size()+" strList size= "+strList.size());
        for (int i = 0; i < intList.size(); i++) {
        	if(intList.size()>0)
        	{
        	list.set(i,String.valueOf(intList.get(intIndex++)));
        	}
        	//list.set(i,strList.get(strIndex++));
        	
			/*
			 * boolean isnum1=isNumeric(intList.get(i).toString()); if(isnum1==true){ // if
			 * (list.get(i) instanceof Integer) { // list.set(i, intList.get(intIndex++));
			 * //for (Integer k: intList) { //list.add(String.valueOf(intList.get(k)));
			 * list.add(String.valueOf(intList.get(intIndex++))); //}
			 * //list.add(intList.get(intIndex++).toString()); } else { //list.set(i,
			 * strList.get(strIndex++)); list.add(strList.get(strIndex++)); }
			 */
        }
        
        int idx=intList.size();
        System.out.println("idx="+idx );
        if(DblList.size()>0)
    	{
        	for (int s = 0; s < DblList.size(); s++)
        	{ 

        		//list.set(i,strList.get(strIndex).toString());

        		list.set(idx++,String.valueOf(DblList.get(s)));
        		//idx++;
        	}
        }
        int idx1=intList.size()+DblList.size();
        //idx1=idx1-1;
        System.out.println("idx1="+idx1 );
        if(strList.size()>0)
    	{
        	for (int s = 0; s < strList.size(); s++)
        	{ 

        		//list.set(i,strList.get(strIndex).toString());

        		list.set(idx1++,strList.get(s));
        		;
        	}
        }
    }
    
    //End by Rajesh on 27/09/2022
   /* 
    public KeyValueLOV commonGetKeyLOVs(String classID,String attrid,String lovid,String deptattr,String deptcfg,String deptval)throws ServiceException
    {
    	TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
        ClassificationService clsService = ClassificationService.getService(session);
        KeyValueLOV keylovval=null;
        String[] keyLOVIds = new String[1];
        keyLOVIds[0] =lovid;
        System.out.println("Calling the SOA getKeyLOVs2");
        com.teamcenter.services.rac.classification._2009_10.Classification.GetKeyLOVsResponse2 response = clsService.getKeyLOVs2( keyLOVIds );
        if ( response.data.sizeOfPartialErrors() > 0)
           throw new ServiceException( "ClassificationService.getKeyLOVs2 returned a partial Error.");
        @SuppressWarnings("unchecked")
        Map<String, KeyLOVDefinition2> keyLOVs = response.keyLOVs;
        System.out.println("*****Lov Details******* "+keyLOVs.size());
        Set<String> keys = keyLOVs.keySet();
        ArrayList<String> lovlist=new ArrayList<String>();
        for(Iterator<String> itr = keys.iterator();itr.hasNext();)
        {
            String id = itr.next();
            KeyLOVDefinition2 lovDef = keyLOVs.get( id );
            ICSKeyLov keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id),deptcfg);
            keylovval=new KeyValueLOV(keylov.getId(),keylov);
            boolean ishidekey=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id)).isHideKeys();
            System.out.println("KeyLOV Id             : "+lovDef.id);
            System.out.println("KeyLOV Name           : "+lovDef.name);
            System.out.println("KeyLOV Options        : "+lovDef.options);
            System.out.println("KeyLOV Owning Site    : "+lovDef.owningSite.getUid());
            System.out.println("KeyLOV tag         : "+lovDef.keyLovtag.getUid());
            System.out.println("KeyLOV HIDEKEY         : "+ishidekey);
            System.out.println("KeyLOV Share Sites : "+lovDef.sharedSites);
            KeyLOVEntry[] keyLOVEntries =lovDef.keyLovEntries;

            System.out.println("Number of KeyLOV's : "+keyLOVEntries.length);
            System.out.println("*************************************************************");
            
          
           ArrayList<String> key=new  ArrayList<String>();
       	   ArrayList<String> value=new  ArrayList<String>();
       	 if(PreferenceValue.isNaRequired()==true)
       	 {
             lovlist.add("");
             key.add("");
             value.add("");
       	 }
       	 //if(deptval!=null && deptval.length()>0)
       //	keylov.dump("kjjkhj");
       	KeyLov[] klovary=keylov.getEntries(false);
            for(int i=0;i<klovary.length;i++)
            {
            	
            	
                
                String keyval="";
                if(ishidekey==false)
                	keyval=klovary[i].getKey()+PreferenceValue.getKeyvalueDelmiter()+klovary[i].getValue();
                else
                	keyval=klovary[i].getValue();
                System.out.println(ishidekey+"::HIDEKEY>> : "+keyval);
                key.add(klovary[i].getKey());
                value.add(keyval);
                lovlist.add(keyval);
               // lovlist.add(keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue);
            }
            
            keylovval.setKey(key);
            keylovval.setValue(value);
        }
        
        return keylovval;

    }
    */
 
    public KeyValueLOV commonGetKeyLOVs2(String classID,String attrid,String lovid,String deptattr,String deptcfg,String deptval,int arraysize)throws ServiceException
    {
    	TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
        ClassificationService clsService = ClassificationService.getService(session);
        KeyValueLOV keylovval=null;
        boolean 	depreFlg=false;
        String[] keyLOVIds = new String[1];
        keyLOVIds[0] =lovid;
        System.out.println("Calling the SOA getKeyLOVs2");
              
        System.out.println("in commonGetKeyLOVs2 arraysize="+arraysize);
        com.teamcenter.services.rac.classification._2009_10.Classification.GetKeyLOVsResponse2 response = clsService.getKeyLOVs2( keyLOVIds );
        if ( response.data.sizeOfPartialErrors() > 0)
           throw new ServiceException( "ClassificationService.getKeyLOVs2 returned a partial Error.");
        @SuppressWarnings("unchecked")
        Map<String, KeyLOVDefinition2> keyLOVs = response.keyLOVs;
        System.out.println("*****Lov Details******* "+keyLOVs.size());
        Set<String> keys = keyLOVs.keySet();
        ArrayList<String> lovlist=new ArrayList<String>();
        for(Iterator<String> itr = keys.iterator();itr.hasNext();)
        {
            String id = itr.next();
            KeyLOVDefinition2 lovDef = keyLOVs.get( id );
            ICSKeyLov keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id),deptcfg);
            keylovval=new KeyValueLOV(keylov.getId(),keylov);
            boolean ishidekey=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id)).isHideKeys();
            System.out.println("KeyLOV Id             : "+lovDef.id);
            System.out.println("KeyLOV Name           : "+lovDef.name);
            System.out.println("KeyLOV Options        : "+lovDef.options);
            System.out.println("KeyLOV Owning Site    : "+lovDef.owningSite.getUid());
            System.out.println("KeyLOV tag         : "+lovDef.keyLovtag.getUid());
            System.out.println("KeyLOV HIDEKEY         : "+ishidekey);
            System.out.println("KeyLOV Share Sites : "+lovDef.sharedSites);
            KeyLOVEntry[] keyLOVEntries =lovDef.keyLovEntries;

            System.out.println("Number of KeyLOV's : "+keyLOVEntries.length);
            System.out.println("*************************************************************");
            
            for(int k=0;k<keyLOVEntries.length;k++)
            {
                KeyLOVEntry keyLOVEntries1 = lovDef.keyLovEntries[k];
                System.out.println("rrb KeyLOV Entry Key     : "+keyLOVEntries1.lovKey);
                System.out.println("rrb KeyLOV Entry Value   : "+keyLOVEntries1.lovValue);
            }
          
           ArrayList<String> key=new  ArrayList<String>();
       	   ArrayList<String> value=new  ArrayList<String>();
       	 ArrayList<String> OldNosortvalSet=new  ArrayList<String>();
       	 if(PreferenceValue.isNaRequired()==true)
       	 {
             lovlist.add("");
             key.add("");
             value.add("");
             OldNosortvalSet.add("");
       	 }
       	 //if(deptval!=null && deptval.length()>0)
       //	keylov.dump("kjjkhj");
       	KeyLov[] klovary=keylov.getEntries(false);
       	for(int i=0;i<klovary.length;i++)
       	{
       		depreFlg=klovary[i].isDeprecated();
       		System.out.println("depreFlg: "+depreFlg);
       		if(depreFlg==false)
       		{          	
       			String keyval="";
       			if(ishidekey==false)
       				keyval=klovary[i].getKey()+PreferenceValue.getKeyvalueDelmiter()+klovary[i].getValue();
       			else
       				keyval=klovary[i].getValue();
       			System.out.println(ishidekey+"::HIDEKEY>> : "+keyval);
       			key.add(klovary[i].getKey());

       			value.add(keyval);
       			lovlist.add(keyval);
       		}
       		// lovlist.add(keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue);
       	}
            
 //added by rrb for sorting value in lov
                
            for(int c1=0;c1<value.size();c1++)
            {
            	 System.out.println("::before Sort LOV>> : "+value.get(c1));
            	 OldNosortvalSet.add(value.get(c1));
            }
            System.out.println("commonGetKeyLOVs2::arraysize>> : "+arraysize);
            if(arraysize<=0)
            {
            	Collections.sort(value);
            	relativeOrderSort1(value);

            	for(int c=0;c<value.size();c++)
            	{
            		System.out.println("::After Sort LOV>> : "+value.get(c));
            	}
            }
 //End by rrb for sorting value in lov         
            keylovval.setKey(key);
            
           
            System.out.println("::b4 setValue LOV value>> : "+OldNosortvalSet); 
            keylovval.setValue(value);
            //keylovval.setValue(OldNosortvalSet);
        }
        
        return keylovval;

    }
    public KeyValueLOV commonGetKeyLOVs(String classID,String attrid,String lovid,String deptattr,String deptcfg,String deptval,int arrvalsize)throws ServiceException
    {
    	TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
        ClassificationService clsService = ClassificationService.getService(session);
        KeyValueLOV keylovval=null;
        boolean depreFlg=false;
        String[] keyLOVIds = new String[1];
        keyLOVIds[0] =lovid;
        System.out.println("Calling commonGetKeyLOVs with arrvalsize="+arrvalsize);
        com.teamcenter.services.rac.classification._2009_10.Classification.GetKeyLOVsResponse2 response = clsService.getKeyLOVs2( keyLOVIds );
        if ( response.data.sizeOfPartialErrors() > 0)
           throw new ServiceException( "ClassificationService.getKeyLOVs2 returned a partial Error.");
        @SuppressWarnings("unchecked")
        Map<String, KeyLOVDefinition2> keyLOVs = response.keyLOVs;
        System.out.println("*****Lov Details******* "+keyLOVs.size());
        Set<String> keys = keyLOVs.keySet();
        ArrayList<String> lovlist=new ArrayList<String>();
        for(Iterator<String> itr = keys.iterator();itr.hasNext();)
        {
            String id = itr.next();
            KeyLOVDefinition2 lovDef = keyLOVs.get( id );
            ICSKeyLov keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id),deptcfg);
            keylovval=new KeyValueLOV(keylov.getId(),keylov);
            boolean ishidekey=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id)).isHideKeys();
            System.out.println("KeyLOV Id             : "+lovDef.id);
            System.out.println("KeyLOV Name           : "+lovDef.name);
            System.out.println("KeyLOV Options        : "+lovDef.options);
            System.out.println("KeyLOV Owning Site    : "+lovDef.owningSite.getUid());
            System.out.println("KeyLOV tag         : "+lovDef.keyLovtag.getUid());
            System.out.println("KeyLOV HIDEKEY         : "+ishidekey);
            System.out.println("KeyLOV Share Sites : "+lovDef.sharedSites);
            KeyLOVEntry[] keyLOVEntries =lovDef.keyLovEntries;

            System.out.println("Number of KeyLOV's : "+keyLOVEntries.length);
            System.out.println("*************************************************************");
            
            for(int k=0;k<keyLOVEntries.length;k++)
            {
                KeyLOVEntry keyLOVEntries1 = lovDef.keyLovEntries[k];
                System.out.println("rrb KeyLOV Entry Key     : "+keyLOVEntries1.lovKey);
                System.out.println("rrb KeyLOV Entry Value   : "+keyLOVEntries1.lovValue);
            }
          
           ArrayList<String> key=new  ArrayList<String>();
       	   ArrayList<String> value=new  ArrayList<String>();
       	 ArrayList<String> OldNosortvalSet=new  ArrayList<String>();
       	 if(PreferenceValue.isNaRequired()==true)
       	 {
             lovlist.add("");
             key.add("");
             value.add("");
             OldNosortvalSet.add("");
       	 }
       	 //if(deptval!=null && deptval.length()>0)
       //	keylov.dump("kjjkhj");
       	KeyLov[] klovary=keylov.getEntries(false);
       	for(int i=0;i<klovary.length;i++)
       	{
       		depreFlg=klovary[i].isDeprecated();
       		System.out.println("depreFlg: "+depreFlg);
       		if(depreFlg==false)
       		{                    
       			String keyval="";
       			if(ishidekey==false)
       				keyval=klovary[i].getKey()+PreferenceValue.getKeyvalueDelmiter()+klovary[i].getValue();
       			else
       				keyval=klovary[i].getValue();
       			System.out.println(ishidekey+"::HIDEKEY>> : "+keyval);
       			key.add(klovary[i].getKey());

       			value.add(keyval);
       			lovlist.add(keyval);
       		}
       		// lovlist.add(keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue);
       	}
            
 //added by rrb for sorting value in lov
                
            for(int c1=0;c1<value.size();c1++)
            {
            	 System.out.println("::before Sort LOV>> : "+value.get(c1));
            	 OldNosortvalSet.add(value.get(c1));
            }
            
          // Collections.sort(value);
           // relativeOrderSort1(value);
            
//            for(int c=0;c<value.size();c++)
//            {
//            	 System.out.println("::After Sort LOV>> : "+value.get(c));
//            }
 //End by rrb for sorting value in lov         
            keylovval.setKey(key);
            //keylovval.setValue(value);
            System.out.println("commonGetKeyLOVs-key>> : "+key);
            System.out.println("commonGetKeyLOVs::value>> : "+value); 
            
            Collections.sort(OldNosortvalSet);
            keylovval.setValue(OldNosortvalSet);
        }
        
        return keylovval;

    }
    public KeyValueLOV commonGetKeyLOVs1(String classID,String attrid,String lovid,String deptattr,String deptcfg,String deptval)throws ServiceException
    {
    	TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
        ClassificationService clsService = ClassificationService.getService(session);
        KeyValueLOV keylovval=null;
        String[] keyLOVIds = new String[1];
        keyLOVIds[0] =lovid;
        System.out.println("Calling the SOA getKeyLOVs2");
        com.teamcenter.services.rac.classification._2009_10.Classification.GetKeyLOVsResponse2 response = clsService.getKeyLOVs2( keyLOVIds );
        if ( response.data.sizeOfPartialErrors() > 0)
           throw new ServiceException( "ClassificationService.getKeyLOVs2 returned a partial Error.");
        @SuppressWarnings("unchecked")
        Map<String, KeyLOVDefinition2> keyLOVs = response.keyLOVs;
        System.out.println("*****Lov Details******* "+keyLOVs.size());
        Set<String> keys = keyLOVs.keySet();
        ArrayList<String> lovlist=new ArrayList<String>();
        for(Iterator<String> itr = keys.iterator();itr.hasNext();)
        {
            String id = itr.next();
            KeyLOVDefinition2 lovDef = keyLOVs.get( id );
            ICSKeyLov keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id));
            keylovval=new KeyValueLOV(keylov.getId(),keylov);
            boolean ishidekey=keylov.isHideKeys();
            System.out.println("KeyLOV Id             : "+lovDef.id);
            System.out.println("KeyLOV Name           : "+lovDef.name);
            System.out.println("KeyLOV Options        : "+lovDef.options);
            System.out.println("KeyLOV Owning Site    : "+lovDef.owningSite.getUid());
            System.out.println("KeyLOV tag         : "+lovDef.keyLovtag.getUid());
            System.out.println("KeyLOV HIDEKEY         : "+ishidekey);
            System.out.println("KeyLOV Share Sites : "+lovDef.sharedSites);
            KeyLOVEntry[] keyLOVEntries =lovDef.keyLovEntries;

            System.out.println("Number of KeyLOV's : "+keyLOVEntries.length);
            System.out.println("*************************************************************");
            
          
           ArrayList<String> key=new  ArrayList<String>();
       	   ArrayList<String> value=new  ArrayList<String>();
       	 if(PreferenceValue.isNaRequired()==true)
       	 {
             lovlist.add("");
             key.add("");
             value.add("");
       	 }
            for(int i=0;i<keyLOVEntries.length;i++)
            {
                KeyLOVEntry keyLOVEntries1 = lovDef.keyLovEntries[i];
                System.out.println("KeyLOV Entry Key     : "+keyLOVEntries1.lovKey);
                System.out.println("KeyLOV Entry Value   : "+keyLOVEntries1.lovValue);
                System.out.println("Deprecated Status : "+keyLOVEntries1.deprecatedSatus);
                System.out.println("*************************************************************");
                String keyval="";
                if(ishidekey==false)
                	keyval=keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue;
                else
                	keyval=keyLOVEntries1.lovValue;
                System.out.println(ishidekey+"::HIDEKEY>> : "+keyval);
                key.add(keyLOVEntries1.lovKey);
                value.add(keyval);
                lovlist.add(keyval);
               // lovlist.add(keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue);
            }
            
            keylovval.setKey(key);
            keylovval.setValue(value);
        }
        
        return keylovval;

    }

    public KeyValueLOV depGetKeyLOVs(String m_classID,String attrid,String lovid,String deptattr,String deptcfg,String deptval)throws ServiceException
    {
    	TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
        ClassificationService clsService = ClassificationService.getService(session);
        KeyValueLOV keylovval=null;
        String[] keyLOVIds = new String[1];
        keyLOVIds[0] =lovid;
        System.out.println("Calling the SOA depGetKeyLOVs"+":"+ m_classID+":"+attrid+":"+ lovid+":"+ deptattr+":"+ deptcfg +":"+ deptval);
        ICSKeyLov keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovid));
        keylovval=new KeyValueLOV(keylov.getId(),keylov);
        ArrayList<String> key=new  ArrayList<String>();
  	   ArrayList<String> value=new  ArrayList<String>();
        if(deptval==null || deptval.length()==0)
        {
        	key.add("");
            value.add("");
            keylovval.setKey(key);
            keylovval.setValue(value);
        	return keylovval;
        }
        ICSProperty[] m_properties= new ICSProperty[]{new ICSProperty(Integer.parseInt(attrid))};
        ICSProperty m_changedProperty=new ICSProperty(Integer.parseInt(deptattr),deptval);
                
        Classification.DependencyAttributeStruct[] arrayOfDependencyAttributeStruct = new Classification.DependencyAttributeStruct[1];
        arrayOfDependencyAttributeStruct[0] = new Classification.DependencyAttributeStruct();
        arrayOfDependencyAttributeStruct[0].classID = m_classID;
        arrayOfDependencyAttributeStruct[0].selectedAttributeID = m_changedProperty.getId();
        arrayOfDependencyAttributeStruct[0].selectedValue = m_changedProperty.getValue();
        Classification.DependencyAttributeValue[] arrayOfDependencyAttributeValue = new Classification.DependencyAttributeValue[m_properties.length];
        for (int i = 0; i < m_properties.length; i++)
        {
          arrayOfDependencyAttributeValue[i] = new Classification.DependencyAttributeValue();
          arrayOfDependencyAttributeValue[i].attributeID = m_properties[i].getId();
          arrayOfDependencyAttributeValue[i].value = m_properties[i].getValue();
        }
        arrayOfDependencyAttributeStruct[0].attributeValues = arrayOfDependencyAttributeValue;
        ClassificationService localClassificationService = ClassificationService.getService(session);
        Classification.GetDependencyKeyLOVsResponse localGetDependencyKeyLOVsResponse = localClassificationService.getKeyLOVsForDependentAttributes(arrayOfDependencyAttributeStruct);
        ICSConfiguredKeyLov[] m_configuredKeyLOV = new ICSConfiguredKeyLov[localGetDependencyKeyLOVsResponse.dependencyKeyLOVs.length];
        int j = 0;
        for (Classification.DependencyKeyLOVDescriptor localDependencyKeyLOVDescriptor : localGetDependencyKeyLOVsResponse.dependencyKeyLOVs)
        {
          KeyLOVDefinition2 localKeyLOVDefinition2 = localDependencyKeyLOVDescriptor.keyLOVDefinition;
          KeyLOVEntry[] arrayOfKeyLOVEntry = localKeyLOVDefinition2.keyLovEntries;
          ICSKeyLov.KeyLov[] arrayOfKeyLov = new ICSKeyLov.KeyLov[arrayOfKeyLOVEntry.length];
          
          System.out.println("arrayOfKeyLovarrayOfKeyLovKeyLOV Owning Site    : "+arrayOfKeyLov.length);
          
          System.out.println("getting the SOA depGetKeyLOVs");
          ArrayList<String> lovlist=new ArrayList<String>();
            

              System.out.println("Number of KeyLOV's : "+arrayOfKeyLOVEntry.length);
              System.out.println("*************************************************************");
              
              
              boolean ishidekey=keylov.isHideKeys();
           
         	 if(PreferenceValue.isNaRequired()==true)
         	 {
               lovlist.add("");
               key.add("");
               value.add("");
         	 }
              for(int i=0;i<arrayOfKeyLOVEntry.length;i++)
              {
                  KeyLOVEntry keyLOVEntries1 = arrayOfKeyLOVEntry[i];
                  System.out.println("KeyLOV Entry Key     : "+keyLOVEntries1.lovKey);
                  System.out.println("KeyLOV Entry Value   : "+keyLOVEntries1.lovValue);
                  System.out.println("Deprecated Status : "+keyLOVEntries1.deprecatedSatus);
                  System.out.println("*************************************************************");
                  String keyval="";
                  if(ishidekey==false)
                  	keyval=keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue;
                  else
                  	keyval=keyLOVEntries1.lovValue;
                  System.out.println(ishidekey+"::HIDEKEY>> : "+keyval);
                  key.add(keyLOVEntries1.lovKey);
                  value.add(keyval);
                  lovlist.add(keyval);
                 // lovlist.add(keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue);
              }
              
              keylovval.setKey(key);
              keylovval.setValue(value);
          }
        
        
       /* Classification.DependencyAttributeStruct[] arrayOfDependencyAttributeStruct = new Classification.DependencyAttributeStruct[1];
        arrayOfDependencyAttributeStruct[0] = new Classification.DependencyAttributeStruct();
        arrayOfDependencyAttributeStruct[0].classID = m_classID;
        arrayOfDependencyAttributeStruct[0].selectedAttributeID = Integer.parseInt(attrid);
        arrayOfDependencyAttributeStruct[0].selectedValue = "X0";//deptval;
        Classification.DependencyAttributeValue[] arrayOfDependencyAttributeValue = new Classification.DependencyAttributeValue[1];
        //for (int i = 0; i < this.m_properties.length; i++)
        {
        //	int i=0;
          arrayOfDependencyAttributeValue[0] = new Classification.DependencyAttributeValue();
          arrayOfDependencyAttributeValue[0].attributeID = Integer.parseInt(deptattr);
          arrayOfDependencyAttributeValue[0].value = "TIGOR";//this.m_properties[i].getValue();
        }
       arrayOfDependencyAttributeStruct[0].attributeValues = arrayOfDependencyAttributeValue;
       
        Classification.GetDependencyKeyLOVsResponse localGetDependencyKeyLOVsResponse = clsService.getKeyLOVsForDependentAttributes(arrayOfDependencyAttributeStruct);
        
        int j = 0;
        for (Classification.DependencyKeyLOVDescriptor localDependencyKeyLOVDescriptor : localGetDependencyKeyLOVsResponse.dependencyKeyLOVs)
        {
          KeyLOVDefinition2 lovDef = localDependencyKeyLOVDescriptor.keyLOVDefinition;
          KeyLOVEntry[] arrayOfKeyLOVEntry = lovDef.keyLovEntries;
        
          System.out.println("getting the SOA depGetKeyLOVs");
        ArrayList<String> lovlist=new ArrayList<String>();
           String id = lovDef.id;
           
            ICSKeyLov keylov=ICSKeyLov.getICSKeyLov(Integer.parseInt(lovDef.id));
            keylovval=new KeyValueLOV(keylov.getId(),keylov);
            boolean ishidekey=keylov.isHideKeys();
            System.out.println("KeyLOV Id             : "+lovDef.id);
            System.out.println("KeyLOV Name           : "+lovDef.name);
            System.out.println("KeyLOV Options        : "+lovDef.options);
            System.out.println("KeyLOV Owning Site    : "+lovDef.owningSite.getUid());
            System.out.println("KeyLOV tag         : "+lovDef.keyLovtag.getUid());
            System.out.println("KeyLOV HIDEKEY         : "+ishidekey);
            System.out.println("KeyLOV Share Sites : "+lovDef.sharedSites);
            KeyLOVEntry[] keyLOVEntries =lovDef.keyLovEntries;

            System.out.println("Number of KeyLOV's : "+keyLOVEntries.length);
            System.out.println("*************************************************************");
            
          
           ArrayList<String> key=new  ArrayList<String>();
       	   ArrayList<String> value=new  ArrayList<String>();
       	 if(PreferenceValue.isNaRequired()==true)
       	 {
             lovlist.add("");
             key.add("");
             value.add("");
       	 }
            for(int i=0;i<keyLOVEntries.length;i++)
            {
                KeyLOVEntry keyLOVEntries1 = lovDef.keyLovEntries[i];
                System.out.println("KeyLOV Entry Key     : "+keyLOVEntries1.lovKey);
                System.out.println("KeyLOV Entry Value   : "+keyLOVEntries1.lovValue);
                System.out.println("Deprecated Status : "+keyLOVEntries1.deprecatedSatus);
                System.out.println("*************************************************************");
                String keyval="";
                if(ishidekey==false)
                	keyval=keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue;
                else
                	keyval=keyLOVEntries1.lovValue;
                System.out.println(ishidekey+"::HIDEKEY>> : "+keyval);
                key.add(keyLOVEntries1.lovKey);
                value.add(keyval);
                lovlist.add(keyval);
               // lovlist.add(keyLOVEntries1.lovKey+PreferenceValue.getKeyvalueDelmiter()+keyLOVEntries1.lovValue);
            }
            
            keylovval.setKey(key);
            keylovval.setValue(value);
        }
        */
        return keylovval;

    }

}
