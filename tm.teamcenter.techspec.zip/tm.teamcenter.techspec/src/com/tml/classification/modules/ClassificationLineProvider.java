package com.tml.classification.modules;
import java.util.ArrayList;
import java.util.List;
public class ClassificationLineProvider 
{
	private List<ClassificationTableLine> tabline;
	
	 public ClassificationLineProvider() {
	    	tabline = new ArrayList<ClassificationTableLine>();
	        // Image here some fancy database access to read the persons and to
	        // put them into the model
	       
	    } 
	public List<ClassificationTableLine> getClassificationLine() {
		return tabline;
	}

	public void setClassificationLine(List<ClassificationTableLine> tabline) {
		this.tabline = tabline;
	}

	

   
    
    
    public void addTabLine(ClassificationTableLine model)
    {
    	
    	
    	tabline.add(model);
    	
    	
    }

}
