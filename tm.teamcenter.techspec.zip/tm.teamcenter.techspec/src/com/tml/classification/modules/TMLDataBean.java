package com.tml.classification.modules;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.common.NotDefinedException;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.commands.ICommandImageService;
import org.eclipse.ui.menus.CommandContributionItem;
import org.eclipse.ui.menus.CommandContributionItemParameter;

import com.teamcenter.rac.aif.AbstractAIFOperation;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.AbstractAIFSession;
import com.teamcenter.rac.common.MultiTargetDataBean;
import com.teamcenter.rac.kernel.TCComponentBOMView;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.util.PlatformHelper;


public class TMLDataBean extends MultiTargetDataBean {
	
	
	  private AIFComponentContext[] m_publishedTargets = null;
	  private ExecutionEvent exe_evt=null;
	 
	  
	  public TMLDataBean(AbstractAIFSession paramAbstractAIFSession, ISelection paramISelection,AIFComponentContext[] m_publishedTargets,ExecutionEvent exe_evt)
	  {
	    super(paramAbstractAIFSession, paramISelection);
	    this.m_publishedTargets = m_publishedTargets;
	    this.exe_evt=exe_evt;
	    setTargetContexts(m_publishedTargets);
	   
	   
	  }
	  
	  protected AbstractAIFOperation[] getOperations()
	  {
	    
		  return new AbstractAIFOperation[1];
	  
	  }
	  
	  public String getCommandTitle()
	  {
		  String title="Information : ";
		  
		  try {
			title=this.exe_evt.getCommand().getName();
		} catch (NotDefinedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
		  return title;
	  }
	  
	  public String getCommandMessage()
	  {
	   
		  
		  
		  String desc="Message for : ";
		  
		  try {
			  desc+=this.exe_evt.getCommand().getDescription();
		} catch (NotDefinedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  
		  return desc;
	  }
	  
	  public Image getCommandIconImage()
	  {
		  IWorkbenchWindow  workbenchWindow =  PlatformHelper.getCurrentWorkbenchWindow();
		
		  
		  ICommandImageService commandImageService = (ICommandImageService) workbenchWindow.getService(ICommandImageService.class);
		  ImageDescriptor imgdesc=commandImageService.getImageDescriptor(this.exe_evt.getCommand().getId());
		
		 //return imgdesc.createImage();//PlatformHelper.getCurrentShell().getImage();
		  if(imgdesc==null)
			{
				return null;
			}
			else
			{
				return imgdesc.createImage();//PlatformHelper.getCurrentShell().getImage();
				
			}
	  }
	  
	  public String getCommandToolTip()
	  {
	   
		  String tooltip="";
		  
		  try {
			  tooltip=this.exe_evt.getCommand().getName();
		} catch (NotDefinedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
		  return tooltip;
	  }
	  
	  
	  
	  public AIFComponentContext[] getPublishedTargets()
	  {
	    return this.m_publishedTargets;
	  }
	  
	 
}
