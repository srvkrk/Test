package com.tml.classification.modules;

import java.util.ArrayList;

public class ClassificationAnnotationLine {
	
	private ArrayList<ClassificationTableLine> attrList;
	private String annotation;
	private ClassificationTreeLine parent;

	public ClassificationAnnotationLine(String annotation) {
		
		this.annotation=annotation;
		attrList = new ArrayList<ClassificationTableLine> ();
		
	}

	public ArrayList<ClassificationTableLine> getAttrList() {
		return attrList;
	}

	public void setAttrList(ArrayList<ClassificationTableLine> attrList) {
		this.attrList = attrList;
	}

	public String getAnnotation() {
		return annotation;
	}

	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}

	public ClassificationTreeLine getParent() {
		return parent;
	}

	public void setParent(ClassificationTreeLine parent) {
		this.parent = parent;
	}
	
	

}
