package com.tml.classification.modules;

import com.teamcenter.rac.aif.AbstractAIFOperation;
import com.teamcenter.rac.classification.icadmin.ICAdminContext;
import com.teamcenter.rac.classification.icadmin.keylov.ICAKeyLOVContext;
import com.teamcenter.rac.classification.icadmin.keylov.ICAKeyLOVPanel;
import com.teamcenter.rac.kernel.ServiceData;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentSite;
import com.teamcenter.rac.kernel.TCComponentSiteType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCSiteInfo;
import com.teamcenter.rac.kernel.ics.ICSAdminKeyLOV;
import com.teamcenter.rac.kernel.ics.ICSKeyLov;
import com.teamcenter.rac.kernel.ics.ICSKeyLovValue;
import com.teamcenter.rac.services.ITogglePropertiesService;
import com.teamcenter.rac.tcapps.TcappsPlugin;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.OSGIUtil;
import com.teamcenter.rac.util.Registry;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.internal.rac.core._2010_04.DataManagement;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.services.rac.classification._2007_01.Classification;
import com.teamcenter.services.rac.classification._2007_01.Classification.KeyLOVDefinition;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVDefinition2;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVEntry;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core._2010_04.DataManagement.LocalizedPropertyValuesInfo;
import com.teamcenter.soa.client.model.ErrorStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

public class TMLKeyLOVCreateorUpdateOperation
  extends AbstractAIFOperation
{
	 ICAKeyLOVContext m_context = null;
	  private ClassificationService clsservice;
	  public DataManagementService dmService;
	  private boolean m_isSuccess = false;
	  private TreeMap<Object,String> keyvalue;
	  
	  public TMLKeyLOVCreateorUpdateOperation(ICAKeyLOVContext paramICAKeyLOVContext, TreeMap<Object,String> keyvalue)
	  {
	    this.m_context = paramICAKeyLOVContext;
	    this.clsservice = ClassificationService.getService(this.m_context.getAdminContext().getSession());
	    this.dmService = DataManagementService.getService(this.m_context.getAdminContext().getSession());
	    this.keyvalue=keyvalue;
	    
	  }
	  
	  public void executeOperation()
	    throws TCException
	  {
	    ServiceData localServiceData1 = null;
	    this.m_isSuccess = false;
	    try
	    {
	      ICSKeyLovValue[] arrayOfICSKeyLovValue = this.m_context.getICSAdminKeyLOV().getEntries(true);
	      if(keyvalue!=null && keyvalue.size()>0)
	      {
	      ArrayList<ICSKeyLovValue> ICSKeyLovValueList=new ArrayList<ICSKeyLovValue>();
	      for(Map.Entry<Object, String> entry:keyvalue.entrySet())
	      {
	    	  
	    	  ICSKeyLovValueList.add( new ICSKeyLovValue(entry.getKey().toString(), entry.getValue())) ;
	    	  ICSKeyLovValueList.toArray(new ICSKeyLovValue[keyvalue.size()]);
	      }
	      arrayOfICSKeyLovValue=ICSKeyLovValueList.toArray(new ICSKeyLovValue[keyvalue.size()]);
	      }
	      TCSiteInfo[] arrayOfTCSiteInfo = ((TCComponentSiteType)this.m_context.getAdminContext().getSession().getCurrentSite().getTypeComponent()).getAllSiteInfo();
	      Vector localVector = this.m_context.getICSAdminKeyLOV().getShareSites();
	      TCComponent[] arrayOfTCComponent = new TCComponent[localVector.size()];
	      int i = 0;
	      for (TCSiteInfo siteInfo : arrayOfTCSiteInfo) {
	        if (localVector.indexOf(siteInfo.getSiteName()) != -1)
	        {
	          TCComponentSiteType localTCComponentSiteType = (TCComponentSiteType)this.m_context.getAdminContext().getSession().getTypeComponent("POM_imc");
	          arrayOfTCComponent[(i++)] = localTCComponentSiteType.find(siteInfo.getSiteID());
	        }
	      }
	      KeyLOVDefinition2[] arrayOfKeyLOVDefinition2 = new KeyLOVDefinition2[1];
	      KeyLOVEntry[] arrayOfKeyLOVEntry = new KeyLOVEntry[arrayOfICSKeyLovValue.length];
	     for (int k = 0; k < arrayOfICSKeyLovValue.length; k++)
	     
	     {
	        arrayOfKeyLOVEntry[k] = new KeyLOVEntry();
	        arrayOfKeyLOVEntry[k].lovKey = arrayOfICSKeyLovValue[k].getKey();
	        arrayOfKeyLOVEntry[k].lovValue = arrayOfICSKeyLovValue[k].getValue();
	        arrayOfKeyLOVEntry[k].deprecatedSatus = arrayOfICSKeyLovValue[k].isDeprecated();
	       
	      }
	      arrayOfKeyLOVDefinition2[0] = new KeyLOVDefinition2();
	      arrayOfKeyLOVDefinition2[0].id = this.m_context.getICSAdminKeyLOV().getId();
	      arrayOfKeyLOVDefinition2[0].name = this.m_context.getICSAdminKeyLOV().getName();
	      arrayOfKeyLOVDefinition2[0].options = this.m_context.getICSAdminKeyLOV().getFlags();
	      arrayOfKeyLOVDefinition2[0].keyLovEntries = arrayOfKeyLOVEntry;
	      arrayOfKeyLOVDefinition2[0].sharedSites = arrayOfTCComponent;
	      ServiceData localServiceData2 = this.clsservice.createOrUpdateKeyLOVs(arrayOfKeyLOVDefinition2);
	      Object localObject1 = new StringBuffer();
	      int n;
	      for (int m = 0; m < localServiceData2.sizeOfPartialErrors(); m++)
	      {
	        Object localObject2 = localServiceData2.getPartialError(m);
	        String[] localObject3 = ((ErrorStack)localObject2).getMessages();
	        if (localObject3 != null)
	        {
	          String[] localObject5;
	          int i1 = (localObject5 = localObject3).length;
	          for (n = 0; n < i1; n++)
	          {
	            String localObject4 = localObject5[n];
	            ((StringBuffer)localObject1).append(localObject4 + "\n");
	          }
	        }
	      }
	      String str1 = ((StringBuffer)localObject1).toString();
	      if (localServiceData2.sizeOfPartialErrors() > 0) {
	        throw new TCException(str1);
	      }
	      ICSKeyLov.removeCacheEntry(Integer.parseInt(m_context.getICSAdminKeyLOV().getId()));
	     /* Object localObject2 = m_context.getICAKeyLOVPanel().getLocalizePropertyValue("name");
	      int i4;
	      if (localObject2 != null)
	      {
	        localServiceData1 = dmService.setLocalizedProperties((LocalizedPropertyValuesInfo)localObject2);
	        if ((localServiceData1 != null) && (localServiceData1.sizeOfPartialErrors() > 0))
	        {
	          Object localObject3 = new StringBuilder();
	          Object localObject4 = m_context.getRegistry().getString("Localization.MESSAGE.TITLE");
	          for (n = 0; n < localServiceData1.sizeOfPartialErrors(); n++)
	          {
	            String[] arrayOfString1;
	            i4 = (arrayOfString1 = localServiceData1.getPartialError(n).getMessages()).length;
	            for (int i3 = 0; i3 < i4; i3++)
	            {
	              String str3 = arrayOfString1[i3];
	              localObject3 = ((StringBuilder)localObject3).append("\n" + str3);
	            }
	          }
	          new MessageBox(((StringBuilder)localObject3).toString(), "", (String)localObject4, 1, true).setVisible(true);
	        }
	      }
	      LocalizedPropertyValuesInfo localObject3 = m_context.getICAKeyLOVPanel().getLocalizePropertyValue("value");
	      if (localObject3 != null)
	      {
	        localServiceData1 = dmService.setLocalizedPropertyValues(new LocalizedPropertyValuesInfo[] { localObject3 });
	        if ((localServiceData1 != null) && (localServiceData1.sizeOfPartialErrors() > 0))
	        {
	          Object localObject4 = "";
	          String str2 = m_context.getRegistry().getString("Localization.MESSAGE.TITLE");
	          for (int i2 = 0; i2 < localServiceData1.sizeOfPartialErrors(); i2++)
	          {
	            String[] arrayOfString2;
	            int i5 = (arrayOfString2 = localServiceData1.getPartialError(i2).getMessages()).length;
	            for (i4 = 0; i4 < i5; i4++)
	            {
	              String str4 = arrayOfString2[i4];
	              localObject4 = localObject4 + "\n" + str4;
	            }
	          }
	          new MessageBox((String)localObject4, "", str2, 1, true).setVisible(true);
	        }
	      }
	      */
	      m_isSuccess = true;
	      Object localObject4 = (ITogglePropertiesService)OSGIUtil.getService(TcappsPlugin.getDefault(), ITogglePropertiesService.class);
	      ((ITogglePropertiesService)localObject4).setToggleProperty("ICAADMIN_SELECTED", "SELECTED", new Object());
	    }
	    catch (ServiceException localServiceException)
	    {
	      m_isSuccess = false;
	      throw new TCException(localServiceException);
	    }
	  }
	  
	  public boolean isOperationSuccess()
	  {
	    return this.m_isSuccess;
	  }
}