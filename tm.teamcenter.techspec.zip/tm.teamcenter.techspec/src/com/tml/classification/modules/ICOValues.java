package com.tml.classification.modules;

import java.math.BigInteger;
import java.util.Map;

import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2011_12.Classification.AttributeValues;

public class ICOValues {
	
	private ClassificationObject clsobjs;
	 private String icoId;
    private   String  cid;
        
        private Map<BigInteger,AttributeValues> attrValuesMap;

		public ICOValues(ClassificationObject clsobjs,String icoId, String cid,
				Map<BigInteger, AttributeValues> attrValuesMap) {
			super();
			this.icoId = icoId;
			this.cid = cid;
			this.attrValuesMap = attrValuesMap;
			this.clsobjs=clsobjs;
		}

		public String getIcoId() {
			return icoId;
		}

		public void setIcoId(String icoId) {
			this.icoId = icoId;
		}

		public String getCid() {
			return cid;
		}

		public void setCid(String cid) {
			this.cid = cid;
		}

		public Map<BigInteger, AttributeValues> getAttrValuesMap() {
			return attrValuesMap;
		}

		public void setAttrValuesMap(Map<BigInteger, AttributeValues> attrValuesMap) {
			this.attrValuesMap = attrValuesMap;
		}

		public ClassificationObject getClsobjs() {
			return clsobjs;
		}

		public void setClsobjs(ClassificationObject clsobjs) {
			this.clsobjs = clsobjs;
		}

        
        
        
}
