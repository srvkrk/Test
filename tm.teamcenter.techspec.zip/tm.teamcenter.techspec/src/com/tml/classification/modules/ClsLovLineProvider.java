package com.tml.classification.modules;
import java.util.ArrayList;
import java.util.List;
public class ClsLovLineProvider 
{
	private List<ClsKeyLovTableLine> tabline;
	
	 public ClsLovLineProvider() {
	    	tabline = new ArrayList<ClsKeyLovTableLine>();
	        // Image here some fancy database access to read the persons and to
	        // put them into the model
	       
	    } 
	public List<ClsKeyLovTableLine> getClassificationLine() {
		return tabline;
	}

	public void setClassificationLine(List<ClsKeyLovTableLine> tabline) {
		this.tabline = tabline;
	}

	

   
    
    
    public void addTabLine(ClsKeyLovTableLine model)
    {
    	
    	
    	tabline.add(model);
    	
    	
    }

}
