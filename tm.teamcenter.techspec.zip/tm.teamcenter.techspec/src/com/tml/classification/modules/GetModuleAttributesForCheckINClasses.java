package com.tml.classification.modules;
import com.teamcenter.rac.kernel.TCClassificationService;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.ics.ICSAdminClass;
import com.teamcenter.rac.kernel.ics.ICSAdminClassAttribute;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassAttribute;
import com.teamcenter.services.rac.classification._2007_01.Classification.GetAttributesForClassesResponse;
import com.teamcenter.soa.exceptions.NotLoadedException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;


public class GetModuleAttributesForCheckINClasses {

	private String ModuleAddress;
	private TCSession session;

	    /**
	     * get the classification class attributes from the class ID's.
	     * 
	     * @throws ServiceException
	     */
	public GetModuleAttributesForCheckINClasses(String moduleAddress,TCSession session)
	{
		
		this.ModuleAddress=moduleAddress;
		this.session=session;
	}
	    public ArrayList<ClassificationTableLine> testgetGetAttributesForClasses()
	        throws ServiceException, TCException
	    {
	        ClassificationService clsService = ClassificationService.getService(session);
	        String[] classIds = new String[1];
	        System.out.println( "Calling the SOA testgetGetAttributesForClasses ModuleAddress="+ModuleAddress);
	        classIds[0] = ModuleAddress;
	        System.out.println( "Calling the SOA testgetGetAttributesForClasses..." );
	        GetAttributesForClassesResponse response = clsService.getAttributesForClasses( classIds );
	        if ( response.data.sizeOfPartialErrors() > 0)
	            throw new ServiceException( "ClassificationService.getAttributesForClasses returned a partial Error.");

	        ClassAttribute[] clsattr = new ClassAttribute[1];
	        @SuppressWarnings("unchecked")
	        Map<String, ClassAttribute[]> attributes = response.attributes;
	        System.out.println( "After Call SOA " );
	        ICSAdminClass icsadmin=null;
	        try {
	        	TCClassificationService classServ =session.getClassificationService();
                 icsadmin=classServ.newICSAdminClass();
                             icsadmin.load(ModuleAddress);
                            
                      } catch (TCException e) {
                             // TODO Auto-generated catch block
                             e.printStackTrace();
                             throw e;
                      }

	        
	       // ClassificationLineProvider tabLineModel= new ClassificationLineProvider();
	        
	      //start portion for bypass tabline 
			String info=null;
			String UsrData1=null;
			String [] qryNames={"SYSCD","SUBSYSCD","Delete Indicator"};
			String [] qryValues={"SKIPTECHSPECATTR","SKIPTECHSPECATTR","0"};
			//int r;
			TCComponent[] objvec;
			try {
				objvec = TechSpecUtil.queryObjTCUA("Control Objects...", qryNames,qryValues);
				
				if(objvec!=null)
				{
					for(int f=0;f<objvec.length;f++)
					{
						TCComponent objcntrl=objvec[f];
						info=objcntrl.getPropertyDisplayableValue("t5_Userinfo1");
						System.out.println("inside testgetGetAttributesForClasses info="+info);
					}
				}
			} catch (TCException | NotLoadedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("2inside testgetGetAttributesForClasses info="+info);
			//End portion for bypass tabline
	        
	        ArrayList<ClassificationTableLine> model=new ArrayList<ClassificationTableLine>();

	        Set<String> keys = attributes.keySet();
	        for( Iterator<String> itr = keys.iterator(); itr.hasNext(); )
	        {
	            String id = itr.next();
	            clsattr = attributes.get(id  );
	            
	            System.out.println (clsattr);
	            for( int i = 0; i < clsattr.length; i++ )
	            {

	                ClassAttribute clsattrs = clsattr[i];
	                
	                String annotation=null;
	                boolean ismandatory=false;
	                boolean isprotected=false;
	                String depattr="";
	                String depattrcfg="";
	                int arraysize=0;
	                String tcentAttrID = null;
					try {
						
						ICSAdminClassAttribute icsatt=icsadmin.getAttribute(clsattrs.id);
						depattr=icsatt.getDependencyAttribute();
						depattrcfg=icsatt.getDependencyConfiguration();
						tcentAttrID=icsatt.getShortName();
						ismandatory = icsatt.isMandatory();
						isprotected=icsatt.isProtected();
						arraysize=clsattrs.arraySize;
	                    System.out.println( "isprotected=" + isprotected);
	                    
	                    System.out.println(clsattrs.id+ ":getUser1=" + icsadmin.getAttribute(clsattrs.id).getUser1());
	                    
	                   
	                    
	                    if(icsadmin.getAttribute(clsattrs.id).getUser1()==null ||icsadmin.getAttribute(clsattrs.id).getUser1().trim().length()==0)
	                    {
	                    	annotation="MISC";
	                    }
	                    else
	                    	annotation=icsadmin.getAttribute(clsattrs.id).getUser1();
		                
	                    
					} catch (TCException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                    System.out.println( "ismandatory" + ismandatory +" annotation="+annotation +" info="+info);
                    
                    
                    	 model.add(new ClassificationTableLine((i+1)+"",clsattrs.id+"",tcentAttrID,clsattrs.name,"",clsattrs.unitName,clsattrs.format.formatLength+"",ismandatory,isprotected,arraysize,annotation,depattr,depattrcfg));

     	                
     	                System.out.println( "Attr Id: " + clsattrs.id );
     	                System.out.println( "Name: " + clsattrs.name );
     	                System.out.println( "shortname: " + clsattrs.shortName );
     	                System.out.println( "description: " + clsattrs.description );
     	                System.out.println( "annotation: " + annotation );
     	                System.out.println( "arraysize: " + clsattrs.arraySize );
     	                System.out.println( "options: " + clsattrs.options );
     	                System.out.println( "Attribute Length: " + clsattrs.altFormat.formatLength );
     	                System.out.println( "Attribute Modifier1: " + clsattrs.altFormat.formatModifier1 );
     	                System.out.println( "Attribute Modifier2: " + clsattrs.altFormat.formatModifier2 );
     	                System.out.println( "Attribute Type: " + clsattrs.altFormat.formatType );
     	                System.out.println( "Annotation: " + clsattrs.annotation );
     	                System.out.println( "Default Value: " + clsattrs.defaultValue );
     	                System.out.println( "Config: " + clsattrs.config );
     	                System.out.println( "Maximum Value: " + clsattrs.maxValue );
     	                System.out.println( "Minimum Value: " + clsattrs.minValue );
     	                System.out.println( "Post Config: " + clsattrs.postConfig );
     	                System.out.println( "Pre Config: " + clsattrs.preConfig );
     	                System.out.println( "Unit Name: " + clsattrs.unitName );
     	                System.out.println( "****************************************************" );

                    
    
	            }
	            System.out.println( "****************************************************" );

	        }
	        return model;

	    }
}
