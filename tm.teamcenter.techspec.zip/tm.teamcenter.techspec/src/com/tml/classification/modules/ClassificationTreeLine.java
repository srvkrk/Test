package com.tml.classification.modules;

import java.util.ArrayList;

import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;

public class ClassificationTreeLine {
	  private String classifiedObject;
	  private String moduleAddress;
	  private String objectid;
	  private String objectid_moduleAddress;
	  private TCComponentItemRevision itemrev;
	  private String classificationName;
		private ArrayList<ClassificationAnnotationLine> attrList;
		private ClassificationObject clsobjs;
	 public ClassificationTreeLine(String classifiedObject,String moduleAddress, String objectid,TCComponentItemRevision itemrev,ClassificationObject clsobjs,String classificationName) {
		super();
		this.classifiedObject = classifiedObject;
		this.moduleAddress = moduleAddress;
		this.itemrev = itemrev;
		this.clsobjs = clsobjs;
		this.objectid=objectid;
		this.classificationName=classificationName;
		attrList = new ArrayList<ClassificationAnnotationLine> ();
	}

	
	@Override
	public String toString() {
		return "ClassificationTreeLine [classifiedObject=" + classifiedObject
				+ ", moduleAddress=" + moduleAddress + ", objectid=" + objectid
				+ ", itemrev=" + itemrev + ", classificationName="
				+ classificationName + ", attrList=" + attrList + ", clsobjs="
				+ clsobjs + "]";
	}
	public String getClassifiedObject() {
		return classifiedObject;
	}
	public void setClassifiedObject(String classifiedObject) {
		this.classifiedObject = classifiedObject;
	}
	public String getModuleAddress() {
		return moduleAddress;
	}
	public void setModuleAddress(String moduleAddress) {
		this.moduleAddress = moduleAddress;
	}
	public ArrayList<ClassificationAnnotationLine> getAttrList() {
		return attrList;
	}
	public void setAttrList(ArrayList<ClassificationAnnotationLine> attrList) {
		this.attrList = attrList;
	}


	public TCComponentItemRevision getItemrev() {
		return itemrev;
	}


	public void setItemrev(TCComponentItemRevision itemrev) {
		this.itemrev = itemrev;
	}


	public ClassificationObject getClsobjs() {
		return clsobjs;
	}


	public void setClsobjs(ClassificationObject clsobjs) {
		this.clsobjs = clsobjs;
	}


	public String getObjectid() {
		return objectid;
	}


	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}


	public String getObjectid_moduleAddress() {
		return moduleAddress+"["+objectid+"]";
	}


	public String getClassificationName() {
		return classificationName;
	}


	public void setClassificationName(String classificationName) {
		this.classificationName = classificationName;
	}
	  
	  

}
