package com.tml.classification.modules;

public class  PreferenceValue {
	
	private static final String ARRAY_DELMITER=";";
	private static final String KEYVALUE_DELMITER=" ";
	private static final boolean NA_REQUIRED=false;
	
	
	public static String getARRAY_DELMITER()
	{
		return ARRAY_DELMITER;
	}


	public static String getArrayDelmiter() {
		return ARRAY_DELMITER;
	}


	public static String getKeyvalueDelmiter() {
		return KEYVALUE_DELMITER;
	}


	public static boolean isNaRequired() {
		return NA_REQUIRED;
	}
	
	

}
