package com.tml.classification.modules;

import java.util.List;


import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentItemType;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;
import com.teamcenter.rac.kernel.TCComponentVariantRule;
import com.teamcenter.rac.kernel.TCComponentVariantRuleType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.structuremanagement.VariantManagementService;
import com.teamcenter.services.rac.structuremanagement._2013_05.VariantManagement.BOMVariantOptionValueEntry;
import com.teamcenter.services.rac.structuremanagement._2013_05.VariantManagement.BOMVariantRuleContents;
import com.teamcenter.services.rac.structuremanagement._2013_05.VariantManagement.SetBOMVariantRuleData;
import com.teamcenter.services.rac.structuremanagement._2013_05.VariantManagement.SetBOMVariantRulesResponse;
import com.teamcenter.soa.client.model.ClientDataModel;
import com.teamcenter.soa.exceptions.NotLoadedException;

public class VariantUtil {

	/**
	 * @param args
	 */
	
	
	 public static TCComponent[] queryDB(String queryname ,String []qryNames,String []qryValues) throws TCException
	 {

		// dbObjects=new ArrayList<String>();
		 System.out.println(" In Query for class ::"+queryname);  
		 TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();		        
		 try {
			 System.out.println(" Before setting the session ::");  
			 TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");                     
			 TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);//"Item...");
			 System.out.println(" After setting the session ::");                                                 
			 TCComponent []qryResults          = null;
			 
			 for(String n1:qryNames)
				 System.out.println(n1);
			 for(String v1:qryValues)
				  System.out.println(v1);

			 if (mmcomponentquery != null)				     
			 {
				 
				 qryResults=mmcomponentquery.execute(qryNames,qryValues);
				 System.out.println(" Results found size::"+ qryResults.length); 
				
			 }

			 return   qryResults;

		 } catch (TCException e2) {
			 // TODO Auto-generated catch block
			 e2.printStackTrace();
		 }

		 return null; 
	 }		
	
	
	
	public void getTCUAStructure(TCSession tcsession,TCComponentItemRevision assemblyRevision) throws TCException
	{

	
		TCComponent[] bvr = assemblyRevision.getRelatedComponents("structure_revisions");// get bvrs
		
		
		
		System.out.println("Listing All Revision Rule");
		
		TCComponentRevisionRule[] revrule=TCComponentRevisionRule.listAllRules(tcsession);
		//String revrulename="EBOM_Upload_View";
		//String revrulename="ERC release and above";
		String revrulename=null;
		try {
			revrulename = new TechSpecUtil().gettechspecrevrule("techspecrevrule");
			System.out.println("output revrulename="+revrulename);
			
		} catch (NotLoadedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(revrulename==null)
		{
			 revrulename="ERC release and above";
		}
		TCComponentRevisionRule currentrevrule=null;
		for(int j=0;j<revrule.length;j++)
		{
			
			if(revrulename.equals(revrule[j].getProperty("object_name")))
			{
				currentrevrule=revrule[j];
					break;
			}
			
			//System.out.println(revrulename);
			
		}
		
		System.out.println("Found the Revision Rule "+revrulename);
		
		TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
		TCComponentBOMWindow bomWin = bowWinType.create(currentrevrule);	// create bom window configured with the default revision rule 
		//TCComponentBOMLine bl= bomWin.setWindowTopLine(_tcItem, itemRev, null, null);
		
		//Modified on 08-12-15
		TCComponentBOMLine bl= bomWin.setWindowTopLine(null, assemblyRevision,null, null);
		
		//TCComponentBOMLine bl= bomWin.setWindowTopLine(null, assemblyRevision,null, bvr[0]);
		
		/*TCComponentVariantRule paramTCComponentVariantRule=new TCComponentVariantRule();
		
		TCComponentVariantRuleType varRuleType = (TCComponentVariantRuleType)paramTCComponentVariantRule.getTypeComponent();
		
		System.out.println("YY0::"+varRuleType);
		
		 TCComponent[] arrayOfTCComponent = varRuleType.listVRules(assemblyRevision);
		 
		 for(int x=0;x<arrayOfTCComponent.length;x++)
			{
				TCComponentSavedVariantRule rule1=(TCComponentSavedVariantRule) arrayOfTCComponent[x];
				
				System.out.println("YY::"+arrayOfTCComponent[x]);
			}

		*/
		
		//TCComponentItemType itemType = (TCComponentItemType )tcsession.getTypeComponent("Item");
		
		//ClientDataModel cd=tcsession.getSoaConnection().getClientDataModel();
	//	tcsession.getSoaConnection().getClientMetaModel().getType("VariantRule", tcsession.getSoaConnection());
		//TCComponentItemType varRuleType = (TCComponentItemType )tcsession.getTypeComponent("VariantRule");
		
		//TCComponentVariantRuleType varRuleType = (TCComponentVariantRuleType )tcsession.getSoaConnection().getClientMetaModel().getType("VariantRule", tcsession.getSoaConnection()); 
		
		//TCComponent[]  rule=varRuleType.listVRules(assemblyRevision);//getSavedVariantRules(assemblyRevision);
		
		TCComponent[]  rule=assemblyRevision.getItem().getTCProperty("Smc0HasVariantConfigContext").getReferenceValueArray()[0].getTCProperty("IMAN_reference").getReferenceValueArray();
		for(int x=0;x<rule.length;x++)
		{
			TCComponentSavedVariantRule rule1=(TCComponentSavedVariantRule) rule[x];
			
			System.out.println("XX::"+rule[x]);
		}

		String varrule=rule[0].getTCProperty("object_name").getDisplayValue();
		TCComponent[] obj=queryDB("General...",new String[]{"Type","Name"},new String[]{"VariantRule",varrule});
		BOMVariantRuleContents[] ruleContents = new BOMVariantRuleContents[1];
		ruleContents[0] = new BOMVariantRuleContents();
		//ruleContents[0].bomVariantOptionValueEntry = new BOMVariantOptionValueEntry[bomVariantRuleModel.getOptions().size()];
		ruleContents[0].svr = obj[0];
		
		SetBOMVariantRuleData input = new SetBOMVariantRuleData();
		input.window = bomWin;
		input.rules = ruleContents;

		VariantManagementService vmService = VariantManagementService.getService( tcsession );
		try {
			SetBOMVariantRulesResponse response = vmService.setBOMVariantRules( new SetBOMVariantRuleData[] { input } );
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("=========================================Getting TCUA  BOM/Global Alternate=============");
			
		if (bl.hasChildren()){
			
				AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()
				
				//TCComponentBOMLine[] childContext =bl.getPackedLines();
				System.out.println("BOM Children count is "+childContext.length);
				
				System.out.println("=======================Listing Children=============");
				for(int i = 0; i < childContext.length; i++){
					//TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
					TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
					TCComponentItem item = child.getItem();
					String cpartno=child.getTCProperty("bl_rev_item_id").toString();
					String cpartrev=child.getTCProperty("bl_rev_item_revision_id").toString();
					String csrlno=child.getTCProperty("bl_sequence_no").toString();
					String cqty=child.getTCProperty("bl_quantity").toString();
					
					if(csrlno==null || csrlno.length()==0)
					{
						System.out.println("CAUTION !!! Main-Serial/Find No is blank, Setting the value to multiplier of 10");
						csrlno=""+(i+1)*10;
					}
					
					if(cqty==null || cqty.length()==0)
					{
						System.out.println("CAUTION !!! Quantity is blank, Setting the value of 'bl_real_quantity' .");
						cqty=child.getTCProperty("bl_real_quantity").toString();
						cqty=""+1;
						
					}
					
					
					}
				
				System.out.println("====================END of Listing Children=============");
			}
		
		else
		   System.out.println("The BOM has no Child");
			
		
		/***    FOR GLOBAL Alternate ************************/
		
		
	   System.out.println("==============================Getting Global-Alternate For Part=============");
		    
		if(bl.hasGlobalAlternates())
		
		
		
		System.out.println("=========================================END TCUA  BOM/Global Alternate=============");

		
		
		
		return ;

	}
	
	
	

}
