package com.tml.classification.modules;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCClassificationService;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.ics.ICSAdminClass;
import com.teamcenter.rac.kernel.ics.ICSAdminClassAttribute;
import com.teamcenter.rac.kernel.ics.ICSKeyLov;
import com.teamcenter.services.rac.classification._2007_01.Classification.ChildDef;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassAttribute;
import com.teamcenter.services.rac.classification._2007_01.Classification.GetAttributesForClassesResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.GetChildrenResponse;
import com.teamcenter.services.rac.classification._2015_10.Classification.GetClassDefinitionsResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;


public class ClassificationHiearchyClasses {

	private TCSession session;
	private TCClassificationService classServ;
	private ClassificationService clsService;
	    /**
	     * get the classification class attributes from the class ID's.
	     * 
	     * @throws ServiceException
	     */
	 
	
	
	public void  getClsDetail(String clsid,ArrayList<String> clsset) throws TCException, IOException
	{
		System.out.println("in getClsDetail input clsid="+clsid);
		 GetChildrenResponse childrenResponse=clsService.getChildren(new String[]{clsid});
		 clsset.add(clsid);
		 Map children=childrenResponse.children;
		 
		 for( Object key : children.keySet())
         {
            System.out.println("map1.get(key)="+key);
           
           // System.out.println("Val="+children.get(key));
          
            ChildDef[] childdef=(ChildDef[]) children.get(key);
      for(int g=0;g<childdef.length;g++)
      {
            String childid=childdef[g].id;
            String childname=childdef[g].name;
            
            System.out.println("IcsClsid="+childid);
            System.out.println("IcsClsname="+childname);
            
           GetClassDefinitionsResponse clsresp= clsService.getClassDefinitions(new String[]{childid});
         // Map clsmap= clsresp.classAttributesDefinitionMap;  //commented on 22 Jan 2026   
          
          System.out.println("servicedara="+TechSpecUtil.ServiceDataError(clsresp.serviceData));
          //commented on 22 Jan 2026            
//          for( Object key1 : clsmap.keySet())
//          {
//   
//        	  System.out.println("CLSS::"+clsmap.get(key1).getClass());
//        	
//          }
     //commented on 22 Jan 2026     
//  Map clsdefmap= clsresp.classDefinitionMap;
//          
//          for( Object key2 : clsdefmap.keySet())
//          {
//   
//        	  System.out.println("CLSSDEF::"+clsdefmap.get(key2).getClass());
//        	
//          }
          
      /*  ICSAdminClass icsadmin = classServ.newICSAdminClass();
        icsadmin.load(childid);
        if(icsadmin.isAbstract())*/
        	getClsDetail(childid,clsset);
       
         }
         }
	}
	
	public ArrayList<String>  getClsHiearchy(String clsid) 
	{
		System.out.println("\ninside getClsHiearchy for clsid="+clsid);
		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		session=(TCSession) app.getSession();
		classServ =session.getClassificationService();
		ArrayList<String> clsset=new ArrayList<String>();
		 clsService = ClassificationService.getService(session);
		 try
		 {
			 if(clsid.length()>0)
			 {
				 getClsDetail( clsid,clsset);
			 }
		 }
		 catch(IOException | TCException ie)
		 {
			 System.out.println("\nIOException for func getClsDetail");
		 }
		 return clsset;
		
	}
}
