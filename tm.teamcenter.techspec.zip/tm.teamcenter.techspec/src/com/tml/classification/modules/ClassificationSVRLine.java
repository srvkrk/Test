package com.tml.classification.modules;

import java.util.ArrayList;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;


public class ClassificationSVRLine {

	private TCComponentSavedVariantRule svr;

	private ArrayList<ClassificationTreeLine> treeLineList;

	public ClassificationSVRLine(TCComponentSavedVariantRule svr) {
		super();
		this.svr = svr;

		treeLineList = new ArrayList<ClassificationTreeLine>();
	}

	public TCComponentSavedVariantRule getSvr() {
		return svr;
	}

	public void setSvr(TCComponentSavedVariantRule svr) {
		this.svr = svr;
	}

	public ArrayList<ClassificationTreeLine> getTreeLineList() {
		return treeLineList;
	}

	public void setTreeLineList(ArrayList<ClassificationTreeLine> treeLineList) {
		this.treeLineList = treeLineList;
	}

	@Override
	public String toString() {
		return "ClassificationSVRLine [svr=" + svr + ", treeLineList="
				+ treeLineList + "]";
	}

}
