package com.tml.classification.modules;

import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentItemRevision;

public class BOMNodeLine {

	/**
	 * @param args
	 */
	private boolean selected;
	private int srl;
	private TCComponentItemRevision itemRev;
	private TCComponentBOMLine bomline;
	private String descrption ;
	private String status ;
	
	
	
	
	
	
	public BOMNodeLine(boolean selected,int srl, TCComponentItemRevision itemRev,
			TCComponentBOMLine bomline, String descrption) {
		super();
		this.selected=selected;
		this.srl = srl;
		this.itemRev = itemRev;
		this.bomline = bomline;
		this.descrption = descrption;
		this.status="";
	}
	
	

	public boolean isSelected() {
		return selected;
	}



	public void setSelected(boolean selected) {
		this.selected = selected;
	}



	public int getSrl() {
		return srl;
	}

	public void setSrl(int srl) {
		this.srl = srl;
	}

	public TCComponentItemRevision getItemRev() {
		return itemRev;
	}
	public void setItemRev(TCComponentItemRevision itemRev) {
		this.itemRev = itemRev;
	}
	public String getDescrption() {
		return descrption;
	}
	public void setDescrption(String descrption) {
		this.descrption = descrption;
	}
	
	public TCComponentBOMLine getBomline() {
		return bomline;
	}

	public void setBomline(TCComponentBOMLine bomline) {
		this.bomline = bomline;
	}
	
	

	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	@Override
	public String toString() {
		return "BOMNodeLine [selected=" + selected + ", srl=" + srl
				+ ", itemRev=" + itemRev + ", bomline=" + bomline
				+ ", descrption=" + descrption + "]";
	}
	
	
	
	
	
}
