package com.tml.classification.modules;

public class ClsKeyLovTableLine {
	  private String SrlNo;
	  private String lovkey;
	  private String lovvalue;
	  
	public ClsKeyLovTableLine(String srlNo, String Lovkey,String lovval) {
		super();
		this.SrlNo = srlNo;
		this.lovkey = Lovkey;
		this.lovvalue=lovval;
		
	}
	public String getSrlNo() {
		return SrlNo;
	}
	public void setSrlNo(String srlNo) {
		SrlNo = srlNo;
	}
	public String getlovKey() {
		return lovkey;
	}
	public void setlovkey(String Lovkey) {
		lovkey = Lovkey;
	}
	public String getlovVal() {
		return lovvalue;
	}
	public void setlovval(String Lovval) {
		lovvalue = Lovval;
	}
	
			
	
	
	@Override
	public String toString() {
		return "ClsKeyLovTableLine [SrlNo=" + SrlNo + ", lovkey=" + lovkey
				+ ", lovvalue=" + lovvalue + "]";
	}
	  
	 /* 
	@Override
	public String toString() {
		return "ClassificationTableLine [SrlNo=" + SrlNo + ", AttrID=" + AttrID
				+ ", tcentattrID=" + tcentattrID + ", AttrName=" + AttrName
				+ ", AttrValue=" + AttrValue + ", ChangeValue=" + ChangeValue
				+ ", Unit=" + Unit + ", LovID=" + LovID + ", parent=" + parent
				+ ", ismandatory=" + ismandatory + ", isProtected="
				+ isProtected + ", arraySize=" + arraySize + ", annotation="
				+ annotation + ", depattr=" + depattr + ", depattrcfg="
				+ depattrcfg + "]";
	} 
	*/
	  
	  
	  

}
