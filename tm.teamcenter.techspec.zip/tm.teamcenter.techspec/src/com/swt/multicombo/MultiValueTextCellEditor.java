package com.swt.multicombo;


import org.eclipse.core.runtime.Assert;
import org.eclipse.jface.bindings.keys.KeyStroke;
import org.eclipse.jface.fieldassist.ContentProposalAdapter;
import org.eclipse.jface.fieldassist.SimpleContentProposalProvider;
import org.eclipse.jface.fieldassist.TextContentAdapter;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.tml.classification.modules.KeyValueLOV;



//import com.ibm.icu.text.MessageFormat;

/**
 * A cell editor that manages a text entry field. The cell editor's value is the text string itself.
 *

 * This class may be instantiated or subclassed.
 * 

 */
public abstract class MultiValueTextCellEditor extends CellEditor {

    /**
     * The text control; initially <code>null</code>.
     */
    public Text text;
    
    private Button[] buttons;

    private ModifyListener modifyListener;
    
    private  MultiCheckSelectionCombo c;
    
    private TreeViewer treeViewer;
    
    private Object element;
    
    private KeyValueLOV keyvallov;

    /**
     * State information for updating action enablement
     */
    private boolean isSelection = false;

    private boolean isDeleteable = false;

    private boolean isSelectable = false;
    
    private int idx ;

    ContentProposalAdapter adapter;

    /**
     * Default TextCellEditor style specify no borders on text widget as cell outline in table already provides the look of a border.
     */
    private static final int defaultStyle = SWT.SINGLE;

    /**
     * Creates a new text string cell editor with no control The cell editor value is the string itself, which is initially the empty
     * string. Initially, the cell editor has no cell validator.
     *
     * @since 2.1
     */
    public MultiValueTextCellEditor() {
        setStyle(defaultStyle);
    }

    /**
     * Creates a new text string cell editor parented under the given control. The cell editor value is the string itself, which is
     * initially the empty string. Initially, the cell editor has no cell validator.
     *
     * @param parent
     *            the parent control
     */
    public MultiValueTextCellEditor(Composite parent,TreeViewer treeViewer,Object element,int idx) {
       // this(parent, defaultStyle,null);
    	super(parent, defaultStyle);
       
        this.element=element;
        this.treeViewer=treeViewer;
        this.keyvallov= keyvallov;
        this.idx=idx;
        System.out.println(this.idx+"::"+idx+"::hhhhhhggg:"+element);
        if(c==null)
        {
        	  System.out.println(this.idx+":iid111:"+idx);
            c = new MultiCheckSelectionCombo(new Shell(), treeViewer,text, SWT.NONE,this.element,keyvallov,idx);
        }
        else
        {
        	  System.out.println(this.idx+":iid112:"+idx);
        	System.out.println("hhhhhhggg23-1:"+this.element);
        	c.setElement(element);
        	c.setTreeViewer(treeViewer);
        	c.setKeyvallov(keyvallov);
        	c.setIdx(idx);
        }
    }

    /**
     * Creates a new text string cell editor parented under the given control. The cell editor value is the string itself, which is
     * initially the empty string. Initially, the cell editor has no cell validator.
     *
     * @param parent
     *            the parent control
     * @param keyvallov
     *            the style bits
     * @since 2.1
     */
    public MultiValueTextCellEditor(Composite parent, TreeViewer treeViewer,KeyValueLOV keyvallov,Object element,int idx) {
        super(parent);
        System.out.println("hhhhhhggg1:"+element);
        this.element=element;
        this.treeViewer=treeViewer;
        this.keyvallov= keyvallov;
        this.idx=idx;
       
        if(c==null)
        {
        	 System.out.println(this.idx+":iid113:"+idx);
            c = new MultiCheckSelectionCombo(new Shell(), treeViewer,text, SWT.NONE,this.element,keyvallov,idx);
        }
        else
        {
        	 System.out.println(this.idx+":iid114:"+idx);
        	System.out.println("hhhhhhggg230:"+this.element);
        	c.setElement(element);
        	c.setTreeViewer(treeViewer);
        	c.setKeyvallov(keyvallov);
        	c.setIdx(idx);
        }
    }

    /**
     * Checks to see if the "deletable" state (can delete/ nothing to delete) has changed and if so fire an enablement changed notification.
     */
    private void checkDeleteable() {
        boolean oldIsDeleteable = isDeleteable;
        isDeleteable = isDeleteEnabled();
        if (oldIsDeleteable != isDeleteable) {
            fireEnablementChanged(DELETE);
        }
    }

    /**
     * Checks to see if the "selectable" state (can select) has changed and if so fire an enablement changed notification.
     */
    private void checkSelectable() {
        boolean oldIsSelectable = isSelectable;
        isSelectable = isSelectAllEnabled();
        if (oldIsSelectable != isSelectable) {
            fireEnablementChanged(SELECT_ALL);
        }
    }

    /**
     * Checks to see if the selection state (selection / no selection) has changed and if so fire an enablement changed notification.
     */
    private void checkSelection() {
        boolean oldIsSelection = isSelection;
        isSelection = text.getSelectionCount() > 0;
        if (oldIsSelection != isSelection) {
            fireEnablementChanged(COPY);
            fireEnablementChanged(CUT);
        }
    }

    /*
     * (non-Javadoc) Method declared on CellEditor.
     */
    protected Control createControl(Composite parent) {
        text = new Text(parent, getStyle());
        text.addSelectionListener(new SelectionAdapter() {
            public void widgetDefaultSelected(SelectionEvent e) {
                handleDefaultSelection(e);
            }
        });
        text.addKeyListener(new KeyAdapter() {
            // hook key pressed - see PR 14201
            public void keyPressed(KeyEvent e) {
                keyReleaseOccured(e);

                // as a result of processing the above call, clients may have
                // disposed this cell editor
                if ((getControl() == null) || getControl().isDisposed()) {
                    return;
                }
                checkSelection(); // see explanation below
                checkDeleteable();
                checkSelectable();
            }
        });
        text.addTraverseListener(new TraverseListener() {
            public void keyTraversed(TraverseEvent e) {
                if (e.detail == SWT.TRAVERSE_ESCAPE || e.detail == SWT.TRAVERSE_RETURN) {
                    e.doit = false;
                }
            }
        });
        // We really want a selection listener but it is not supported so we
        // use a key listener and a mouse listener to know when selection
        // changes
        // may have occurred
        text.addMouseListener(new MouseAdapter() {
            public void mouseUp(MouseEvent e) {
                checkSelection();
                checkDeleteable();
                checkSelectable();
            }
        });
        text.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
            	MultiValueTextCellEditor.this.focusLost();
            }
        });
        text.setFont(parent.getFont());
        text.setBackground(parent.getBackground());
        //text.setText("");//$NON-NLS-1$
        text.addModifyListener(getModifyListener());
        System.out.println("hhhhhhggg2:"+this.element);
        if(c==null)
            c = new MultiCheckSelectionCombo(new Shell(), treeViewer,text, SWT.NONE,this.element,keyvallov,idx);
        else
        {
        	System.out.println("hhhhhhggg23:"+this.element);
        	c.setElement(element);
        	c.setTreeViewer(treeViewer);
        	c.setKeyvallov(keyvallov);
        }
        System.out.println(" text.getText():"+text.getText());   
       
        String[] inputs  = getProposal(text.getText());// {"aasdfasdfasdf", "basdfasdfasdf", "casdfasdfasf", "dasdfasdfasf", "easdfasdfasdf", "fasdfasdfasdf", "gasdfasdfasf", "hasdfasdfasdf"};
		for (String s : inputs) {
			c.add(s);
		}
       

       // setAutoComplete();
        c.showFloatShell();
        text.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent ke) {
            	c.showFloatShell(); //setAutoComplete();
            }
        });

        return text;
    }
    
   
		
		/* KeyStroke ks = KeyStroke.getInstance(SWT.CTRL, SWT.SPACE);
		 ContentProposalAdapter adapter = new ContentProposalAdapter(text, new TextContentAdapter(), scp, ks, null);
         adapter.setProposalAcceptanceStyle(ContentProposalAdapter.PROPOSAL_REPLACE);*/
 //   }

    private void setAutoComplete() {
        try {
       // 	showFloatShell(text);
          /*  ContentProposalAdapter adapter = null;
            String[] defaultProposals = getProposal(text.getText());
            SimpleContentProposalProvider scp = new SimpleContentProposalProvider(defaultProposals);
            scp.setProposals(defaultProposals);
            KeyStroke ks = KeyStroke.getInstance(SWT.CTRL, SWT.SPACE);
            adapter = new ContentProposalAdapter(text, new TextContentAdapter(), scp, ks, null);
            adapter.setProposalAcceptanceStyle(ContentProposalAdapter.PROPOSAL_REPLACE);*/
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public abstract String[] getProposal(String currentText);

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> framework method returns the text string.
     *
     * @return the text string
     */
    protected Object doGetValue() {
        return text.getText();
    }

    /*
     * (non-Javadoc) Method declared on CellEditor.
     */
    protected void doSetFocus() {
        if (text != null) {
            text.selectAll();
            text.setFocus();
            checkSelection();
            checkDeleteable();
            checkSelectable();
        }
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> framework method accepts a text string (type
     * <code>String</code>).
     *
     * @param value
     *            a text string (type <code>String</code>)
     */
    protected void doSetValue(Object value) {
     //   Assert.isTrue(text != null && (value instanceof String));
    	System.out.println("inside doSetValue Val::::"+ value);
    	Assert.isTrue(text != null );
    	//Assert.isTrue(value instanceof String);
        text.removeModifyListener(getModifyListener());
       // text.setText((String) value);
        text.setText( value.toString());
        text.addModifyListener(getModifyListener());
    }

    /**
     * Processes a modify event that occurred in this text cell editor. This framework method performs validation and sets the error message
     * accordingly, and then reports a change via <code>fireEditorValueChanged</code>. Subclasses should call this method at appropriate
     * times. Subclasses may extend or reimplement.
     *
     * @param e
     *            the SWT modify event
     */
    protected void editOccured(ModifyEvent e) {
        String value = text.getText();
        System.out.println("editOccured0"+value);
        if (value == null) {
        	System.out.println("editOccured"+value);
            value = "";//$NON-NLS-1$
        }
        Object typedValue = value;
        boolean oldValidState = isValueValid();
        boolean newValidState = isCorrect(typedValue);
        System.out.println("oldValidState="+oldValidState +" newValidValState="+newValidState);
        if (!newValidState) {
            // try to insert the current value into the error message.
            setErrorMessage(getErrorMessage()/* MessageFormat.format(getErrorMessage(), new Object[] { value }) */);
        }
        valueChanged(oldValidState, newValidState);
    }

    /**
     * Since a text editor field is scrollable we don't set a minimumSize.
     */
    public LayoutData getLayoutData() {
        LayoutData data = new LayoutData();
        data.minimumWidth = 0;
        return data;
    }

    /**
     * Return the modify listener.
     */
    private ModifyListener getModifyListener() {
        if (modifyListener == null) {
            modifyListener = new ModifyListener() {
                public void modifyText(ModifyEvent e) {
                    editOccured(e);
                }
            };
        }
        return modifyListener;
    }

    /**
     * Handles a default selection event from the text control by applying the editor value and deactivating this cell editor.
     *
     * @param event
     *            the selection event
     *
     * @since 3.0
     */
    protected void handleDefaultSelection(SelectionEvent event) {
        // same with enter-key handling code in keyReleaseOccured(e);
        fireApplyEditorValue();
        deactivate();
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method returns <code>true</code> if the current
     * selection is not empty.
     */
    public boolean isCopyEnabled() {
        if (text == null || text.isDisposed()) {
            return false;
        }
        return text.getSelectionCount() > 0;
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method returns <code>true</code> if the current
     * selection is not empty.
     */
    public boolean isCutEnabled() {
        if (text == null || text.isDisposed()) {
            return false;
        }
        return text.getSelectionCount() > 0;
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method returns <code>true</code> if there is a
     * selection or if the caret is not positioned at the end of the text.
     */
    public boolean isDeleteEnabled() {
        if (text == null || text.isDisposed()) {
            return false;
        }
        return text.getSelectionCount() > 0 || text.getCaretPosition() < text.getCharCount();
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method always returns <code>true</code>.
     */
    public boolean isPasteEnabled() {
        if (text == null || text.isDisposed()) {
            return false;
        }
        return true;
    }

    /**
     * Check if save all is enabled
     *
     * @return true if it is
     */
    public boolean isSaveAllEnabled() {
        if (text == null || text.isDisposed()) {
            return false;
        }
        return true;
    }

    /**
     * Returns <code>true</code> if this cell editor is able to perform the select all action.
     *

     * This default implementation always returns <code>false</code>.
     * 

     *

     * Subclasses may override
     * 

     *
     * @return <code>true</code> if select all is possible, <code>false</code> otherwise
     */
    public boolean isSelectAllEnabled() {
        if (text == null || text.isDisposed()) {
            return false;
        }
        return text.getCharCount() > 0;
    }

    /**
     * Processes a key release event that occurred in this cell editor.
     *

     * The <code>TextCellEditor</code> implementation of this framework method ignores when the RETURN key is pressed since this is handled
     * in <code>handleDefaultSelection</code>. An exception is made for Ctrl+Enter for multi-line texts, since a default selection event is
     * not sent in this case.
     * 

     *
     * @param keyEvent
     *            the key event
     */
    protected void keyReleaseOccured(KeyEvent keyEvent) {
        if (keyEvent.character == '\r') { // Return key
            // Enter is handled in handleDefaultSelection.
            // Do not apply the editor value in response to an Enter key event
            // since this can be received from the IME when the intent is -not-
            // to apply the value.
            // See bug 39074 [CellEditors] [DBCS] canna input mode fires bogus
            // event from Text Control
            //
            // An exception is made for Ctrl+Enter for multi-line texts, since
            // a default selection event is not sent in this case.
            if (text != null && !text.isDisposed() && (text.getStyle() & SWT.MULTI) != 0) {
                if ((keyEvent.stateMask & SWT.CTRL) != 0) {
                    super.keyReleaseOccured(keyEvent);
                }
            }
            return;
        }
        super.keyReleaseOccured(keyEvent);
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method copies the current selection to the clipboard.
     */
    public void performCopy() {
        text.copy();
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method cuts the current selection to the clipboard.
     */
    public void performCut() {
        text.cut();
        checkSelection();
        checkDeleteable();
        checkSelectable();
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method deletes the current selection or, if there is
     * no selection, the character next character from the current position.
     */
    public void performDelete() {
        if (text.getSelectionCount() > 0) {
            // remove the contents of the current selection
            text.insert(""); //$NON-NLS-1$
        } else {
            // remove the next character
            int pos = text.getCaretPosition();
            if (pos < text.getCharCount()) {
                text.setSelection(pos, pos + 1);
                text.insert(""); //$NON-NLS-1$
            }
        }
        checkSelection();
        checkDeleteable();
        checkSelectable();
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method pastes the the clipboard contents over the
     * current selection.
     */
    public void performPaste() {
        text.paste();
        checkSelection();
        checkDeleteable();
        checkSelectable();
    }

    /**
     * The <code>TextCellEditor</code> implementation of this <code>CellEditor</code> method selects all of the current text.
     */
    public void performSelectAll() {
        text.selectAll();
        checkSelection();
        checkDeleteable();
    }

    /**
     * This implementation of {@link CellEditor#dependsOnExternalFocusListener()} returns false if the current instance's class is
     * TextCellEditor, and true otherwise. Subclasses that hook their own focus listener should override this method and return false. See
     * also bug 58777.
     *
     * @since 3.4
     */
    protected boolean dependsOnExternalFocusListener() {
        return getClass() != MultiValueTextCellEditor.class;
    }
    
    
}

