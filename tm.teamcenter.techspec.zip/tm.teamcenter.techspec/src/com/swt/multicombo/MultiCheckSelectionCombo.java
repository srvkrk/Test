package com.swt.multicombo;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.ICheckStateProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.KeyValueLOV;
import com.tml.classification.modules.PreferenceValue;

public class MultiCheckSelectionCombo extends Composite {
	private Composite parent;
	private Button okay;
	private Button cancel;
	private List<Option> options = new ArrayList<Option>();
	private Button[] buttons;
	private Table table;
	private CheckboxTableViewer checkboxTableViewer;
	private List<ModifyListener> modifyListeners = new ArrayList<ModifyListener>();
	private List<SelectionListener> selectionListeners = new ArrayList<SelectionListener>();
	private List<VerifyListener> verifyListeners = new ArrayList<VerifyListener>();
	private KeyValueLOV keyvallov;
	
	private String defaultText = "";//"options";
	private Text display;
	private Object element;
	private TreeViewer treeViewer;
	private int col;
	private int idx;
	
	private class Option {
		String text;
		boolean selection = false;
		Option(String text) {
			if (text == null) throw new IllegalArgumentException();
			this.text = text;
		}
		Option(String text, boolean selection) {
			if (text == null) throw new IllegalArgumentException();
			this.text = text;
			this.selection = selection;
		}		
	}
	
    /**
    *
    * Constructs a new instance of this class given its parent and a style value describing its behavior and appearance.
    *
    * The style value is either one of the style constants defined in class SWT which is applicable to instances of this class, or must be built by bitwise OR'ing together (that is, using the int "|" operator) two or more of those SWT style constants. The class description lists the style constants that are applicable to the class. Style bits are also inherited from superclasses.
    * 
    * @param parent a composite control which will be the parent of the new instance (cannot be null)
    * @param style the style of control to construct
     * @param keyvallov 
    * @throws IllegalArgumentException if the parent is null
    * @throws SWTException if not called from the thread that created the parent
    * @since version 1.0.0.0
    */
	public MultiCheckSelectionCombo(Composite parent, TreeViewer treeViewer,Text display,int style,Object element, KeyValueLOV keyvallov,int idx) {
		super(parent, style);
		this.parent=parent;
		this.display=display;
		this.element=element;
		this.treeViewer=treeViewer;
		this.keyvallov=keyvallov;
		this.idx=idx;
		System.out.println(this.idx+"::"+idx+"::KKO:"+element);
		init();
	}
	
    public KeyValueLOV getKeyvallov() {
		return keyvallov;
	}

	public void setKeyvallov(KeyValueLOV keyvallov) {
		this.keyvallov = keyvallov;
	}
	
	

	public int getIdx() {
		return idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	/**
    *
    * Constructs a new instance of this class given its parent, a style value describing its behavior and appearance, and default text
    *
    * The style value is either one of the style constants defined in class SWT which is applicable to instances of this class, or must be built by bitwise OR'ing together (that is, using the int "|" operator) two or more of those SWT style constants. The class description lists the style constants that are applicable to the class. Style bits are also inherited from superclasses.
    * 
    * The default text is displayed when no options are selected.
    * 
    * @param parent a composite control which will be the parent of the new instance (cannot be null)
    * @param style the style of control to construct
    * @param defaultText the default text to display when no options are selected
    * @throws IllegalArgumentException if the parent is null
    * @throws IllegalArgumentException if the defaultText is null
    * @throws SWTException if not called from the thread that created the parent
    * @since version 1.0.0.0
    */
	public MultiCheckSelectionCombo(Composite parent, TreeViewer treeViewer,Text display,int style, String defaultText,Object element,int idx) {
		super(parent, style);
		this.display=display;
		this.element=element;
		this.treeViewer=treeViewer;
		this.idx=idx;
		this.keyvallov=keyvallov;
		System.out.println("KKO1:"+element);
		if (defaultText == null) throw new IllegalArgumentException("Default Text cannot be null");
		this.defaultText = defaultText;
		init();
	}
	
	private void init() {
		GridLayout layout = new GridLayout();
		layout.marginBottom = 0;
		layout.marginTop = 0;
		layout.marginLeft = 0;
		layout.marginRight = 0;
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		setLayout(layout);
		display.setEditable(false);
		//display = new Text(this, SWT.BORDER | SWT.READ_ONLY);
	   // display.setLayoutData(new GridData(GridData.FILL_BOTH));
		//display.setText(defaultText);
	    display.addListener(SWT.MouseDown, new Listener(){
			public void handleEvent(Event e) {
				System.out.println("jkhgjhgfgyyy");
	    	showFloatShell();
			}
	    });
	}

    public Option getOption(String text)
    {
    
    	for(int x=0;x<options.size();x++)
    	{
    		
    		if(options.get(x).text.equals(text))
    			return options.get(x);
    		
    		
    			
    	}
    	
    	return null;
    }
    
	void showFloatShell() {
		
		
	
		final Shell shell = new Shell(MultiCheckSelectionCombo.this.getShell(), SWT.BORDER);
		
		shell.setLayout(new GridLayout(2,false));
		/*
		Button toggle = new Button(shell, SWT.BUTTON1);
		toggle.setText("Toggle");
		toggle.addListener(SWT.MouseDown, new Listener(){
			public void handleEvent(Event e){
			toggleAll();
			for (SelectionListener l : selectionListeners) {
				l.widgetSelected(new SelectionEvent(e));
			}
			}
		});
		*/
		System.out.println("SZ::"+options.size());
		buttons = new Button[options.size()];
		String displaytext=display.getText();
		List<String> selList=new ArrayList<String>();
		if(displaytext!=null && displaytext.trim().length()>0)
		{
			selList=(Arrays.asList(displaytext.trim().split(PreferenceValue.getARRAY_DELMITER())));
			
			
		}
		
		checkboxTableViewer = CheckboxTableViewer.newCheckList(shell, SWT.BORDER | SWT.FULL_SELECTION | SWT.MULTI);
	    checkboxTableViewer.setAllChecked(false);
	    table = checkboxTableViewer.getTable();
	    table.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
	    table.setLinesVisible(true);
	    table.setHeaderVisible(true);
	    //table.setBounds(10, 142, 398, 104);
	    
	   TableViewerColumn tableViewerColumn_3 = new TableViewerColumn(checkboxTableViewer, SWT.NONE);
	    TableColumn tblclmnNewColumn_3 = tableViewerColumn_3.getColumn();
	    tblclmnNewColumn_3.setWidth(70);
	    tblclmnNewColumn_3.setText("Srl No");
	   // tableViewerColumn_3.setLabelProvider(labelProvider)
	   
	    TableViewerColumn tableViewerColumn_4 = new TableViewerColumn(checkboxTableViewer, SWT.NONE);
	    TableColumn tblclmnNewColumn_4 = tableViewerColumn_4.getColumn();
	    tblclmnNewColumn_4.setWidth(320);
	    tblclmnNewColumn_4.setText("Value");
	    
	    col=0;
	    
	    checkboxTableViewer.setContentProvider(new IStructuredContentProvider()
	    {

			@Override
			public void dispose() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void inputChanged(Viewer viewer, Object oldInput,
					Object newInput) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public Object[] getElements(Object inputElement) {
				// TODO Auto-generated method stub
				System.out.println("HHHHHHHHHHHHHHHHH::"+options.size());
				return options.toArray(new Option[options.size()]);
				
				
			}
	    	
	    	
	    	
	    });
	    
	    checkboxTableViewer.setLabelProvider(new ITableLabelProvider()
	    {

			@Override
			public void addListener(ILabelProviderListener listener) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void dispose() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public boolean isLabelProperty(Object element, String property) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public void removeListener(ILabelProviderListener listener) {
				// TODO Auto-generated method stub
				
			}

			/*@Override
			public Image getImage(Object element) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getText(Object element) {
				// TODO Auto-generated method stub
				System.out.println("HHHHHHHHHzfsdfsdfHHHHHHHH::"+element);
				return ((Option)element).text;
			}
*/
			@Override
			public Image getColumnImage(Object element, int columnIndex) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getColumnText(Object element, int columnIndex) {
				// TODO Auto-generated method stub
				switch(columnIndex)
				{
				case 0:return (++col)+"";
				
				case 1:return ((Option)element).text;
				}
				
				return null;
			}
	    	
	    });
		
		/*table =  new Table(shell, SWT.CHECK | SWT.BORDER | SWT.V_SCROLL| SWT.H_SCROLL);
	    table.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));//setLayoutData(new GridData(SWT.NONE, SWT.NONE, true, true, 1, 1));
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    */
	  // TableColumn col0=new TableColumn(table,SWT.NULL);
	  //  col0.setText("Srl");
	    /*
	    TableColumn col1=new TableColumn(table,SWT.NULL);
	    col1.setText("Value");
		*/
	    
	    for (int i =0; i < options.size(); i++) {
			
			
			Option o = options.get(i);
			if(selList.contains(o.text))
			{
				
				o.selection=true;
			}
			else
			{
				o.selection=false;
			}
	    }
		
	    checkboxTableViewer.setCheckStateProvider(new ICheckStateProvider() { 
	    	public boolean isGrayed(Object element)
	    	{ 
	    		return false; 
	    	} 
	    	
	    	public boolean isChecked(Object element) 
	    	{
	    		
	    		return ((Option)element).selection; 
	    		} 
	    	});
		
		/*table.addListener(SWT.Selection,new Listener(){
			public void handleEvent(Event e){
				TableItem[] selection=table.getItems();
				
				for(int g=0;g<selection.length;g++)
				{
					String optxt=selection[g].getText(1);
					if(optxt.equals("(NA)"))
						optxt="";
					Option op=getOption(optxt);
					op.selection=selection[g].getChecked();
				
				}
				
			for (SelectionListener l : selectionListeners) {
				l.widgetSelected(new SelectionEvent(e));
			}
			}
		});
		*/
	    
	    checkboxTableViewer.addCheckStateListener(new ICheckStateListener() {
		      public void checkStateChanged(CheckStateChangedEvent event) {
		        // If the item is checked . . .
		      
		    	  Option seloption=(Option) event.getElement();
		    	  seloption.selection=event.getChecked();
		    	  
		    	  if(checkboxTableViewer.getCheckedElements().length==0)
		    	  {
		    		  okay.setEnabled(false);
		    	  }
		    	  
		    	  else
		    		  okay.setEnabled(true);
		        	
		        	
		      }
		    });
		checkboxTableViewer.setInput(options);
		
		//shell.setLayout(new GridLayout(2,false));
		GridData data = new GridData(GridData.HORIZONTAL_ALIGN_END| GridData.VERTICAL_ALIGN_CENTER);
		shell.setLayoutData(data);
		
		
		okay = new Button(shell, SWT.NONE);
		okay.setText(" OK ");
		Bundle bundle = FrameworkUtil.getBundle(this.getClass());
		
		// use the org.eclipse.core.runtime.Path as import
		String path="icons/Ok_16x16.png";
		
		
		URL url = FileLocator.find(bundle,
		    new Path(path), null);
		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
		
		okay.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/Ok_16x16.png"));
		okay.addListener(SWT.Selection, new Listener(){
			public void handleEvent(Event e){
				if(e.type==SWT.Selection)
				{
					/*System.out.println("BUTTON");
				TableItem[] selection=table.getItems();
				System.out.println("BUTTON33:"+selection.length);
				//for(int g=0;g<options.size();g++)
				//	options.get(g).selection=false;
				
				for(int g=0;g<selection.length;g++)
				{
					Option op=getOption(selection[g].getText(0));
					op.selection=selection[g].getChecked();
					System.out.println("HJK:"+ op);
				}
			*/	
				 displayText(display);
				 shell.dispose();   
			//toggleAll();
			//for (SelectionListener l : selectionListeners) {
			//	l.widgetSelected(new SelectionEvent(e));
			//}
			}
			}
		});
		
		cancel = new Button(shell, SWT.NONE);
		cancel.setText("Cancel");

		
		 path="icons/close_16x16.png";
			
			
		 url=FileLocator.find(bundle,
		    new Path(path), null);
		imageDescriptor = ImageDescriptor.createFromURL(url);
		cancel.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/close_16x16.png"));
		cancel.addListener(SWT.Selection, new Listener(){
			public void handleEvent(Event e){
			
				if(e.type==SWT.Selection)
				{
				shell.dispose();
				}
			}
		});
		
	    shell.pack();
	    
	   /* 
	    Point p = display.getParent().toDisplay(display.getLocation());
		Point size = shell.getSize();
		Rectangle monitor_rect=parent.getBounds();//Display.getCurrent().getMonitors()[0].getBounds();
		
		int modY;
		if(p.y + size.y>monitor_rect.y)
			modY=p.y - size.y;
		else
			modY=p.y + size.y;
		
		System.out.println("POPUUU:"+monitor_rect.y+":"+p.y +":"+ size.y+":"+modY);
		*/
	    
	    Display localDisplay = getDisplay();
	      Rectangle localRectangle1 = this.table.getBounds();
	      Rectangle localRectangle2 = localDisplay.map(getParent(), null, getBounds());
	      Point localPoint3 = getSize();
	      
	      Rectangle localRectangle3 = getMonitor().getClientArea();
	      int m = Math.max(localPoint3.x, localRectangle1.width + 2);
	      
	      //  this.table.setBounds(1, 1, m - 5, localPoint2.y);
	    
	      int n = localRectangle1.height + 2;
	      int i1 = localRectangle2.x;
	      int i2 = localRectangle2.y + localPoint3.y;
	      if (i2 + n > localRectangle3.y + localRectangle3.height) {
	        i2 = localRectangle2.y - n;
	      }
	      if ((i1 + m > localRectangle3.x + localRectangle3.width) ) {
	        i1 = localRectangle3.x + localRectangle3.width - localRectangle1.width;
	      }
	    
		//Rectangle shellRect = new Rectangle(i1, i2, m, n);
	      
	      
	      
	      Point p = this.display.getParent().toDisplay(this.display.getLocation());
	      Point size = shell.getSize();
	      Rectangle monitor_rect = this.parent.getBounds();
	      int modY;
	      
	      if (p.y + size.y > monitor_rect.y) {
	        modY = p.y - size.y;
	      } else {
	        modY = p.y + size.y;
	      }
	      System.out.println("POPUUU:" + monitor_rect.y + ":" + p.y + ":" + size.y + ":" + modY);
	      
	      Rectangle shellRect = new Rectangle(p.x, modY, size.x, 0);
	      

	      shell.setLocation(shellRect.x, shellRect.y);  
	//	Rectangle shellRect = new Rectangle(p.x, p.y + size.y, size.x, 0);
	    
	   //	shell.setLocation(shellRect.x, shellRect.y);
	   	
	   	shell.addListener(SWT.Deactivate, new Listener(){
			public void handleEvent(Event e) {
       	 if (shell != null && !shell.isDisposed()) {
    		 shell.setVisible(false);
    		 for (SelectionListener l : selectionListeners) {
    			 l.widgetDefaultSelected(new SelectionEvent(e));
    		 }
    		 for (VerifyListener l : verifyListeners) {
    			 VerifyEvent v = new VerifyEvent(e);
    			 v.doit =false;
    			 l.verifyText(v);
    		 }
    		 
    		// displayText(display);
    		 
    		 for (ModifyListener l : modifyListeners) {
    			 l.modifyText(new ModifyEvent(e));
    		 }
    		/* for (Button b : buttons) {
    			 b.dispose();
    		 }*/
    		 buttons = null;
    		 shell.dispose();    		 
    	 }
			}
	   	});
		
	   	shell.open();
	}
	
	private void displayText(Text display) {
		StringBuffer sb = new StringBuffer();
		StringBuffer sbkey = new StringBuffer();
		ArrayList<String> lovkey=keyvallov.getKey();
		boolean first = true;
		int indx=0;
		for (Option o : options) {
			if (o.selection) {
				sb.append(first? o.text : PreferenceValue.getARRAY_DELMITER() + o.text);
				String keyval=lovkey.get(indx);
				sbkey.append(first? keyval : PreferenceValue.getARRAY_DELMITER() + keyval);
				first = false;
			}	
			
			indx++;
		}
		System.out.println(sbkey.toString()+":"+element+"::IDX jkk:"+ sb.toString()+":"+idx);
		//display.setText((sb.length() > 0)? sb.toString() : defaultText);
		display.setText( sb.toString() );
		if(first==false)
		{
		if(idx==0)
		((ClassificationTableLine) element).setAttrValue(sb.toString());
			else
				((ClassificationTableLine) element).setNewValue(sb.toString());
			
		((ClassificationTableLine) element).setChangeValue(sbkey.toString());
		}
		treeViewer.update(element, null);
		display.pack();
		this.pack();
	}
	
    /**
    *
    * Sets the default display text to the argument. 
    * 
    * The default text is displayed when no options are selected.
    *
    * @param defaultText the default text to be set
    * @throws IllegalArgumentException if the string is null
    * @since version 1.0.0.0
    */
	public void setDefaultText(String defaultText) {
		if (defaultText == null) throw new IllegalArgumentException("Default Text cannot be null");
		this.defaultText = defaultText;
	}
	
    /**
    *
    * Adds the argument to the end of the receiver's list.
    *
    * @param string the option to be added
    * @throws IllegalArgumentException if the string is null
    * @since version 1.0.0.0
    */
	public void add(String string) {
		options.add(new Option(string));
	}
	
    /**
    *
    * Adds the argument with selection to the end of the receiver's list.
    *
    * @param string the new item
    * @param selection default selection of the new item
    * @throws IllegalArgumentException if the string is null
    * @since version 1.0.0.0
    */
	public void add(String string, boolean selection) {
		options.add(new Option(string, selection));
	}
	
    /**
    *
    * Adds the argument to the receiver's list at the given zero-relative index.
    *
    * @param string the new item
    * @param index the index for the item
    * @throws IllegalArgumentException if the string is null
    * @throws IllegalArgumentException if the index is not between 0 and the number of elements in the list (inclusive)
    * @since version 1.0.0.0
    */
	public void add(String string, int index) {
		if (index < 0 || index > options.size()) throw new IllegalArgumentException("ERROR_INVALID_RANGE");
		options.add(index, new Option(string));
	}
	
    /**
    *
    * Adds the argument with selection to the receiver's list at the given zero-relative index.
    *
    * @param string the new item
    * @param selection default selection of the new item
    * @param index the index for the item
    * @throws IllegalArgumentException if the string is null
    * @throws IllegalArgumentException if the index is not between 0 and the number of elements in the list (inclusive)
    * @since version 1.0.0.0
    */
	public void add(String string, boolean selection, int index) {
		if (index < 0 || index > options.size()) throw new IllegalArgumentException("ERROR_INVALID_RANGE");
		options.add(index, new Option(string, selection));
	}	
	
    /**
    *
    * Adds the listener to the collection of listeners who will be notified when the receiver's text is modified, by sending it one of the messages defined in the ModifyListener interface..
    *
    * @param listener the listener which should be notified
    * @throws IllegalArgumentException if the listener is null
    * @since version 1.0.0.0
    */
	public void addModifyListener(ModifyListener listener) {
		if (listener == null) throw new IllegalArgumentException();
		modifyListeners.add(listener);
	}
	
    /**
    *
	* Adds the listener to the collection of listeners who will be notified when the user changes the receiver's selection, by sending it one of the messages defined in the SelectionListener interface.
    *
    * widgetSelected is called when the user changes the multi-check-selection-combo's list selection. widgetDefaultSelected is called when the floating shell is deactivated.
	* 
	* @param listener the listener which should be notified
    * @throws IllegalArgumentException if the listener is null
    * @since version 1.0.0.0
    */
	public void addSelectionListener(SelectionListener listener) {
		if (listener == null) throw new IllegalArgumentException();
		selectionListeners.add(listener);
	}
	
    /**
    *
	* Adds the listener to the collection of listeners who will be notified when the receiver's text is verified, by sending it one of the messages defined in the VerifyListener interface.
	*
	* @param listener the listener which should be notified
    * @throws IllegalArgumentException if the listener is null
    * @since version 1.0.0.0
    */
	public void addVerifyListener(VerifyListener listener) {
		if (listener == null) throw new IllegalArgumentException();
		verifyListeners.add(listener);
	}
	
    /**
    *
	* Returns the preferred size of the receiver. 
	* The preferred size of a control is the size that it would best be displayed at. The width hint and height hint arguments allow the caller to ask a control questions such as "Given a particular width, how high does the control need to be to show all of the contents?" To indicate that the caller does not wish to constrain a particular dimension, the constant SWT.DEFAULT is passed for the hint.
	*
	* If the changed flag is true, it indicates that the receiver's contents have changed, therefore any caches that a layout manager containing the control may have been keeping need to be flushed. When the control is resized, the changed flag will be false, so layout manager caches can be retained.
	*
	* @param wHint the width hint (can be SWT.DEFAULT)
	* @param hHint the height hint (can be SWT.DEFAULT)
	* @param changed true if the control's contents have changed, and false otherwise
	* @return the preferred size of the control
    * @since version 1.0.0.0
    */
	public Point computeSize(int wHint, int hHint, boolean changed) {
		return display.computeSize(wHint, hHint);
	}
	
    /**
    *
    * Deselects the item at the given zero-relative index in the receiver's list. If the item at the index was already deselected, it remains deselected. Indices that are out of range are ignored.
	*
	* @param index the index of the item to deselect
    * @since version 1.0.0.0
    */
	public void deselect(int index) {
		if (index >= 0 && index < options.size()) {
			options.get(index).selection = false;
			if (buttons != null) {
				buttons[index].setSelection(false);
			}
		}
	}
	
    /**
    *
	* Deselects all selected items in the receiver's list.
	* 
    * @since version 1.0.0.0
    */
	public void deselectAll() {
		for (Option o : options) {
			o.selection = false;
		}
		if (buttons != null) {
			for (int i=0; i < options.size(); i++){
				buttons[i].setSelection(false);
			}
		}
	}
	
    /**
    *
	* Returns the item at the given, zero-relative index in the receiver's list. Throws an exception if the index is out of range.
	* 
	* @param index the index of the item to return
	* @return the item at the given index
	* @throws IllegalArgumentException if the index is not between 0 and the number of elements in the list minus 1 (inclusive)
    * @since version 1.0.0.0
    */
	public String getItem(int index) {
		checkrange(index);
		return options.get(index).text;
	}
	

	
    /**
    *
	* Returns the number of items contained in the receiver's list.
	* 
	* @return the number of items
    * @since version 1.0.0.0
    */
	public int getItemCount() {
		return options.size();
	}
	
    /**
    *
	* Returns the zero-relative indices of the items which are currently selected in the receiver's list, or empty array if no item is selected.
	* 
	* @return the indices of the selected items
    * @since version 1.0.0.0
    */
	public int[] getSelectionIndices() {
		ArrayList<Integer> selections = new ArrayList<Integer>();
		for (int i = 0; i<options.size(); i++) {
			if (options.get(i).selection) {
				selections.add(i);
			}
		}
		
		int[] indices=new int[selections.size()];
		
		for(int k=0;k<indices.length;k++)
		{
			
			indices[k]=selections.get(k).intValue();
		}
		
		return indices;
	}
	
    /**
    *
	* Returns the items which are currently selected in the receiver's list, or empty array if no item is selected.
	* 
	* @return array of the selected items
    * @since version 1.0.0.0
    */
	public String[] getSelections() {
		ArrayDeque<String> selections = new ArrayDeque<String>();
		for (int i = 0; i<options.size(); i++) {
			Option o = options.get(i);
			if (o.selection) {
				selections.add(o.text);
			}
		}
		return selections.toArray(new String[selections.size()]);
	}
	
    /**
    *
	* Returns a string containing a copy of the contents of the receiver's text field
	* 
	* @return the receiver's text
    * @since version 1.0.0.0
    */
	public String getText() {
		return display.getText();
	}
	
    /**
    *
	* Returns the height of the receivers's text field
	* 
	* @return the text height
    * @since version 1.0.0.0
    */
	public int getTextHeight() {
		return display.getLineHeight();
	}
	
	/**
    *
	* Returns the maximum number of characters that the receiver's text field is capable of holding.
	* 
	* @return the text limit
    * @since version 1.0.0.0
    */
	public int getTextLimit() {
		return display.getTextLimit();
	}

    /**
    *
	* Searches the receiver's list starting at the first item (index 0) until an item is found that is equal to the argument, and returns the index of that item. If no item is found, returns -1.
	* 
	* @param string the search item
	* @return index of the item
	* @throws IllegalArgumentException if the string is null
    * @since version 1.0.0.0
    */
	public int indexOf(String string) {
		if (string == null) throw new IllegalArgumentException();
		for (int i=0; i <options.size(); i++) {
			if (options.get(i).text.equals(string)) {
				return i;
			}
		}
		return -1;
	}
	
    /**
    *
	* Searches the receiver's list starting at the given, zero-relative index until an item is found that is equal to the argument, and returns the index of that item. If no item is found or the starting index is out of range, returns -1.
	* 
	* @param string the search item
	* @param start the zero-relative index at which to begin the search
	* @return index of the item
	* @throws IllegalArgumentException if the string is null
    * @since version 1.0.0.0
    */
	public int indexOf(String string, int start) {
		if (string == null) throw new IllegalArgumentException();
		if (start < 0 || start >= options.size()) return -1;
		for (int i=start; i <options.size(); i++) {
			if (options.get(i).text.equals(string)) {
				return i;
			}
		}
		return -1;
	}

	/**
    *
	* Removes the item from the receiver's list at the given zero-relative index.
	* 
	* Disables but does not remove buttons from the floating shell if it is open. The floating shell will be updated when it is deactivated and re-populated
	* 
	* @param index index for the item
	* @throws IllegalArgumentException if the index is not between 0 and the number of elements in the list minus 1 (inclusive)
    * @since version 1.0.0.0
    */
	public void remove(int index) {
		checkrange(index);
		options.remove(index);
		if (buttons != null) {
			buttons[index].setEnabled(false);
		}
	}
	
	/**
    *
	* Removes the items from the receiver's list which are between the given zero-relative start and end indices (inclusive).
	* 
	* Disables but does not remove buttons from the floating shell if it is open. The floating shell will be updated when it is deactivated and re-populated
	* 
	* @param start start of range
	* @param end end of range
	* @throws IllegalArgumentException  if either the start or end are not between 0 and the number of elements in the list minus 1 (inclusive)
    * @since version 1.0.0.0
    */
	public void remove(int start, int end) {
		checkrange(start);
		checkrange(end);
		assert start <= end;
		for (int i = start; i <= end; i++) {
			options.remove(i);
			if (buttons != null) {
				buttons[i].setEnabled(false);
			}
		}
	}
	
	/**
    *
	* Searches the receiver's list starting at the first item until an item is found that is equal to the argument, and removes that item from the list.
	* 
	* Disables but does not remove buttons from the floating shell if it is open. The floating shell will be updated when it is deactivated and re-populated
	* 
	* @param string the item to remove
	* @throws IllegalArgumentException if the string is null
    * @throws IllegalArgumentException if the string is not found in the list.
    * @since version 1.0.0.0
    */
	public void remove(String string) {
		if (string != null) {
			for (int i=0; i < options.size(); i++) {
				if (options.get(i).text.equals(string)) {
					options.remove(i);
					if (buttons != null) {
						buttons[i].setEnabled(false);
					}
					return;
				}
			}
		}
		throw new IllegalArgumentException();
	}
	
	/**
    *
	* Removes all of the items from the receiver's list and restores receiver's text field to default.
	* 
	* Disables but does not remove buttons from the floating shell if it is open. The floating shell will be updated when it is deactivated and re-populated
	* 
    * @since version 1.0.0.0
    */
	public void removeAll() {
		options.clear();
		if (buttons != null) {
			for (Button b : buttons) {
				b.setEnabled(false);
			}
		}
		display.setText(defaultText);
		display.pack();
	}

	/**
    *
	* Removes the listener from the collection of listeners who will be notified when the user changes the receiver's selection.
	* 
	* @param listener the listener which should no longer be notified
	* @throws IllegalArgumentException if the listener is null
    * @since version 1.0.0.0
    */
	public void removeSelectionListener(SelectionListener listener) {
		if (listener == null) throw new IllegalArgumentException();
		selectionListeners.remove(listener);
	}

	/**
    *
	* Removes the listener from the collection of listeners who will be notified when the control is verified.
	* 
	* @param listener the listener which should no longer be notified
	* @throws IllegalArgumentException if the listener is null
    * @since version 1.0.0.0
    */
	public void removeVerifyListener(VerifyListener listener) {
		if (listener == null) throw new IllegalArgumentException();
		verifyListeners.remove(listener);
	}
	
	/**
    *
	* Removes the listener from the collection of listeners who will be notified when the receiver's text is modified.
	* 
	* @param listener the listener which should no longer be notified
	* @throws IllegalArgumentException if the listener is null
    * @since version 1.0.0.0
    */
	public void removeModifyListener(ModifyListener listener) {
		if (listener == null) throw new IllegalArgumentException();
		modifyListeners.remove(listener);
	}

	/**
    *
	* Selects the item at the given zero-relative index in the receiver's list. If the item at the index was already selected, it remains selected. Indices that are out of range are ignored.
	* 
	* @param index the index of item to select
	* @since version 1.0.0.0
    */
	public void select(int index) {
		if (index >= 0 && index < options.size()) {
			options.get(index).selection = true;
			if (buttons != null) {
				buttons[index].setSelection(true);
			}
		}
	}
	
	/**
    *
	* Selects the items at the given zero-relative indices in the receiver's list. If the item at the index was already selected, it remains selected. Indices that are out of range are ignored.
	* 
	* @param indices the indices of items to select
	* @since version 1.0.0.0
    */
	public void select(int[] indices) {
		for (int i : indices) {
			select(i);
		}
	}
	
	/**
    *
	* Sets the font that the receiver will use to paint textual information to the font specified by the argument, or to the default font for that kind of control if the argument is null.
	* 
	* @param font the new font (or null)
	* @since version 1.0.0.0
    */
	public void setFont(Font font) {
		display.setFont(font);
	}
	
	/**
    *
	* Sets the text of the item in the receiver's list at the given zero-relative index to the string argument.
	* 
	* @param index the index for the item
	* @param string new text for the item
	* @throws IllegalArgumentException if the index is not between 0 and the number of elements in the list minus 1 (inclusive)
	* @throws IllegalArgumentException if the string is null
	* @since version 1.0.0.0
    */
	public void setItem(int index, String string) {
		checkrange(index);
		if (string == null) throw new IllegalArgumentException();
		options.get(index).text = string;
		if (buttons != null) {
			buttons[index].setText(string);
			buttons[index].pack();
		}
	}
	
	/**
    *
	* Sets the receiver's list to be the given array of items.
	* 
	* @param items the array of items
	* @throws IllegalArgumentException if the items array is null
	* @throws IllegalArgumentException if an item in the items array is null

	* @since version 1.0.0.0
    */	
	public void setItems(String[] items) {
		options = new ArrayList<Option>(items.length);
		for (String s : items) {
			add(s);
		}
	}
	
	/**
    *
	* Toggles the selection of each item in the receiver's list.
	* 
	* @since version 1.0.0.0
    */	
	public void toggleAll() {
		for (Option o : options) {
			o.selection = !o.selection;
		}
		if (buttons != null) {
			for (Button b : buttons) {
				b.setSelection(!b.getSelection());
			}
		}
	}


	private void checkrange(int index) {
		if (index < 0 || index >= options.size()) throw new IllegalArgumentException("ERROR_INVALID_RANGE");
	}

	public Object getElement() {
		return element;
	}

	public void setElement(Object element) {
		this.element = element;
	}

	public TreeViewer getTreeViewer() {
		return treeViewer;
	}

	public void setTreeViewer(TreeViewer treeViewer) {
		this.treeViewer = treeViewer;
	}
	
	

	
	
}
