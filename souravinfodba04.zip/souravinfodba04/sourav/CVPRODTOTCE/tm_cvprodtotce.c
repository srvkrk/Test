/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   SSH CVPROD To TCE  
*  File Name    :   tm_cvprodtotce.c
*  Created on   :   Apr 15th, 2024
*  Usage        :   tm_cvprodtotce
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     15/04/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tc/tc.h>


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of SSH CVPROD To TCE Main Function ************* \n");fflush(stdout);
	
	char*	sysCmnd	=	NULL;
	char* PNoStr = ITK_ask_cli_argument( "-PNo=");
	char* RevStr = ITK_ask_cli_argument( "-Rev=");
	char* SeqStr = ITK_ask_cli_argument( "-Seq=");
	char* FNameStr = ITK_ask_cli_argument( "-FName=");
	sysCmnd=(char *) MEM_alloc(400);
	tc_strcpy(sysCmnd,"/user/cvprod/sourav/CVPRODTOTCE/CallingShell.sh ");
	tc_strcat(sysCmnd,PNoStr);
	tc_strcat(sysCmnd," ");
	tc_strcat(sysCmnd,RevStr);
	tc_strcat(sysCmnd," ");
	tc_strcat(sysCmnd,SeqStr);
	tc_strcat(sysCmnd," ");
	tc_strcat(sysCmnd,FNameStr);
	
	printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
	system(sysCmnd);
	MEM_free(sysCmnd);
						

	printf("\n*********** End Of SSH CVPROD To TCE Main Function ************* \n");fflush(stdout);	
	return ifail;
}

/***************************************************************************
*
* // ./compile tm_cvprodtotce.c
* // ./linkitk -o tm_cvprodtotce tm_cvprodtotce.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/CVPRODTOTCE/tm_cvprodtotce .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/CVPRODTOTCE/exepatch.sh .
*
***************************************************************************/