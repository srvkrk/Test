/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   Cntrlobj.c
*  Author		 :   Sudhir
*  Module		 :   Control Object create in TCUA
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;
	
int ITK_user_main(int argc,char* argv[])
{
	int z;
	int status;

	
	FILE* fptr = NULL;
	FILE* fptr1 = NULL;
				
	char *inputline = NULL;
	

	char *MasterItemidDup=NULL;
	char *MasterItemid=NULL;
	char *MasterItemTypeDup=NULL;
	char *MasterItemType=NULL;
	char *updated_id=NULL;
	char *master_id=NULL;
	char *Tempupdate_id=NULL;
	char *master_type=NULL;
	char *master_type1=NULL;
	char *master_id1=NULL;

	const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;

	

	char	*f	=NULL;
	char	result1 [ 100000 ] ;
	char	result2 [ 100000 ] ;

	 int
        //error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii,cnt = 0;
		int i = 0;
		int n_entries1 = 1;
		int n_found1 = 0;
		int cnt1 = 0;

	tag_t	query				= NULLTAG;
	tag_t	criteria_object		= NULLTAG;
	tag_t	*criteria_objects	= NULLTAG;
	tag_t	query1				= NULLTAG;
	tag_t	criteria_object1	= NULLTAG;
	tag_t	*criteria_objects1	= NULLTAG;
       

	char
        *qry_entries[2] = {"Item ID","Type"},
        *qry_values[2]	= {"*","*"};

	char
        *qry_entries1[1] = {"Item ID"},
        *qry_values1[1]	= {"*"};
	
	
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
	printf("\n\n\t Attempting Logging\n ");

	z=ITK_CALL(ITK_auto_login());
	if(z!=ITK_ok)
	{
		printf("\n\n\t OMG Login Not Successfull\n ");
	}
	else
	{
	  printf("\n\n\t Login Successfull\n ");
	}

	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-p=");
	g = ITK_ask_cli_argument( "-g=");

	
	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		fptr1=fopen("/user/cvprod/sudhir/RenameMasterData/ISStdDocMasterList.txt","r");
		fptr=fopen("/user/cvprod/sudhir/RenameMasterData/ISStdDocList.txt","w");
		if(fptr!=NULL)
		{
			fprintf(fptr,"\n");
			fprintf(fptr,"IS STD DOC Number~Type~AVAILABLE IN TCUA");
			fprintf(fptr,"\n");
		}
		if(fptr1!=NULL)
		{
			inputline=(char *) MEM_alloc(50000);
			while(fgets(inputline,50000,fptr1)!=NULL)
			{
				for (i = 0; i < strlen(inputline); i++)
				{
					if ( inputline[i] == '\n' || inputline[i] == '\r' )
						inputline[i] = '\0';
				}
				while(1)
				{
					f = strstr(inputline,",,");
					if(f==NULL)
					{
						break;
					}

					strcpy(result2,f+1);					
					*(f+1)=' ';
					*(f+2)='\0';
					strcat(f,result2);
				}
				strcpy(result1,inputline);
				printf("\n inputline .......%s\n",result1);fflush(stdout);
				qry_values[0] = result1;
				//qry_values[1] = "TML Standard Class";
				qry_values[1] = "IS Standard Class";

				printf("\n qry_values[0] .......%s\n",qry_values[0]);fflush(stdout);
				printf("\n qry_values[1] .......%s\n",qry_values[1]);fflush(stdout);
				ITK_CALL(QRY_find("Item...", &query));
				ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &criteria_objects));
				printf("\n n_found=====>%d", n_found);fflush(stdout);
				if(n_found>0)
				{
					for(cnt=0;cnt<n_found;cnt++)
					{
						criteria_object = criteria_objects[cnt];
						AOM_ask_value_string(criteria_object,"item_id",&master_id);
						printf("\n master_id %s",master_id);fflush(stdout);

						AOM_ask_value_string(criteria_object,"object_type",&master_type);
						printf("\n master_type %s",master_type);fflush(stdout);

						fprintf(fptr,"%s",master_id);
						fprintf(fptr,"~");
						fprintf(fptr,"%s",master_type);
						fprintf(fptr,"~");
						fprintf(fptr,"YES");
						fprintf(fptr,"\n");
					}
				}
				else
				{
					printf("\n result1=====>%s", result1);fflush(stdout);
					qry_values1[0] = result1;
					//qry_values1[1] = "*";
					ITK_CALL(QRY_find("Item...", &query1));
					if(query1!=NULLTAG)
					{
						ITK_CALL(QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &criteria_objects1));
						printf("\n n_found1=====>%d", n_found1);fflush(stdout);
						if(n_found1>0)
						{
							for(cnt1=0;cnt1<n_found1;cnt1++)
							{
								criteria_object1 = criteria_objects1[cnt1];
								AOM_ask_value_string(criteria_object1,"item_id",&master_id1);
								printf("\n master_id1 %s",master_id1);fflush(stdout);

								AOM_ask_value_string(criteria_object1,"object_type",&master_type1);
								printf("\n master_type1 %s",master_type1);fflush(stdout);

								fprintf(fptr,"%s",master_id1);
								fprintf(fptr,"~");
								fprintf(fptr,"%s",master_type1);
								fprintf(fptr,"~");
								fprintf(fptr,"OTHER OBJECT TYPE");
								fprintf(fptr,"\n");
							}
						}
						else
						{
							fprintf(fptr,"%s",result1); //doc num
							fprintf(fptr,"~");
							fprintf(fptr,"OTHER TYPE"); //Type
							fprintf(fptr,"~");
							fprintf(fptr,"NO");
							fprintf(fptr,"\n");
						}
					}
					
				}
				//MEM_free(criteria_objects);
				//MEM_free(criteria_objects1);
			}
		}
	}
	 
	 fclose(fptr);
	 fclose(fptr1);
	 return ITK_ok;
}
