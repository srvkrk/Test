/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Update UOM For Input Part No 
*  File Name    :   tm_uomupdate.c
*  Created on   :   Nov 21th, 2024
*  Usage        :   tm_uomupdate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     21/11/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int TM_UOMUpdate(tag_t item, char* Uom)
{
	printf("\n Inside Function: TM_UOMUpdate Start..!!\n");fflush(stdout);	
	int	status;
	int	ifail = 0;
	char* ent_uom = NULL;
	tag_t unit_of_measure = NULLTAG;
	ent_uom =(char *) MEM_alloc(10 * sizeof(char *));

	ITK_CALL(AOM_lock(item));

	if(tc_strcmp(Uom,"1")==0)
	{
		tc_strcpy(ent_uom,ONE);
	}
	else if(tc_strcmp(Uom,"2")==0)
	{
		tc_strcpy(ent_uom,TWO);
	}
	else if(tc_strcmp(Uom,"3")==0)
	{
		tc_strcpy(ent_uom,THREE);
	}
	else if(tc_strcmp(Uom,"4")==0)
	{
		tc_strcpy(ent_uom,FOUR);
	}
	else if(tc_strcmp(Uom,"5")==0)
	{
		tc_strcpy(ent_uom,FIVE);
	}
	else if(tc_strcmp(Uom,"6")==0)
	{
		tc_strcpy(ent_uom,SIX);
	}
	else if(tc_strcmp(Uom,"7")==0)
	{
		tc_strcpy(ent_uom,SEVEN);
	}
	else if(tc_strcmp(Uom,"8")==0)
	{
		tc_strcpy(ent_uom,EIGHT);
	}
	else
	{
		tc_strcpy(ent_uom,"-");
	}

	ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
	/* if(ITK_ok != (ifail =ITEM_set_unit_of_measure(item, unit_of_measure)))
	{
		return ifail;
	} */
	ITK_CALL(AOM_set_value_string(item,"t5_uom",ent_uom));
	ITK_CALL(AOM_save(item));
	ITK_CALL(AOM_unlock(item));
	printf("\n Inside Function: TM_UOMUpdate End..!!\n");fflush(stdout);
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	//char *item_revseq_str = NULL;
	//char *item_propname_str = NULL;
	char *item_propvalue_str = NULL;
	char *item_id_strDup = NULL;
	//char *item_revseq_strDup = NULL;
    //char *item_propname_strDup = NULL;
    char *item_propvalue_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t titemmaster = NULLTAG;
	char *MstrUOMVal = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			//item_revseq_str=strtok(NULL,"^");
			//item_propname_str=strtok(NULL,"^");
			item_propvalue_str=strtok(NULL,"^");
			printf(" Part Property Value(item_propvalue_str): [%s]\n",item_propvalue_str);
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			//if(item_revseq_str!=NULL)tc_strdup(item_revseq_str,&item_revseq_strDup);
			//if(item_propname_str!=NULL)tc_strdup(item_propname_str,&item_propname_strDup);
			if(item_propvalue_str!=NULL)tc_strdup(item_propvalue_str,&item_propvalue_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			//if(item_revseq_strDup!=NULL)trimwhitespace(item_revseq_strDup);
			//if(item_propname_strDup!=NULL)trimwhitespace(item_propname_strDup);
			if(item_propvalue_strDup!=NULL)trimwhitespace(item_propvalue_strDup);
			
			printf(" Part No(item_id_strDup): [%s]\n",item_id_strDup);
			//printf(" Part RevSeq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			//printf(" Part Property Name(item_propname_strDup): [%s]\n",item_propname_strDup);
			printf(" Part Property Value(item_propvalue_strDup): [%s]\n",item_propvalue_strDup);
			
			ITK_CALL(QRY_find2("Item ID",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"Item ID"};
				char *cValues[1]  = {item_id_strDup};
				//char *cValues[1]  = {"5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Item Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				for (i = 0; i < n_itemobj_found; i++)
		        {
					titemmaster = titemobj_results[i];
					ITK_CALL(AOM_UIF_ask_value(titemmaster,"t5_uom",&MstrUOMVal));
					printf("\n Master UOM Value: [%s]\n", MstrUOMVal);fflush(stdout);
					printf("\n Function1: UOM Update Start..!!\n");fflush(stdout);
					TM_UOMUpdate(titemmaster,item_propvalue_strDup);
					printf("\n Function1: UOM Update End..!!\n");fflush(stdout);
				}
			}
		    else
			{
				printf("\n After Query Execution No User Found..!!");fflush(stdout);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_uomupdate.c
* // ./linkitk -o tm_uomupdate tm_uomupdate.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UOMUpdate/tm_uomupdate .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UOMUpdate/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UOMUpdate/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UOMUpdate/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UOMUpdate/SendEmail.sh .
* // ./tm_uomupdate -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_uomupdate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_uomupdate -u=loader -p=loader123 -g=dba
*
***************************************************************************/