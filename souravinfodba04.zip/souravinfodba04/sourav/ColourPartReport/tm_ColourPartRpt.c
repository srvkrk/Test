/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Compare Input Part with TCUA Part & Print it's Properties on Report  
*  File Name    :   tm_ColourPartRpt.c
*  Created on   :   Apr 11th, 2024
*  Usage        :   tm_ColourPartRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     11/04/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_revseq_str = NULL;
	char *part_type_str = NULL;
	char *tce_cind_str = NULL;
	char *tce_cmp_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_strDup = NULL;
	char *part_type_strDup = NULL;
	char *tce_cind_strDup = NULL;
	char *tce_cmp_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *tcua_cind_str = NULL;
	char *tcua_cind_strDup = NULL;
	char *tcua_cmp_str = NULL;
	char *tcua_cmp_strDup = NULL;
	int i = 0;
	char *RptFile = (char *) malloc(200*sizeof(char));
	char *responsestring = (char *) malloc(20*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t DesRev_tag = NULLTAG;
	
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"TCE_TCUA_Compare_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");
    fpOutput_file = fopen(RptFile, "w");
	
    fprintf(fpOutput_file,"PART_NO, REV_SEQ, PART_TYPE, TCE_COLOUR_IND, TCE_COMP_CODE, TCUA_COLOUR_IND, TCUA_COMP_CODE, STATUS\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_revseq_str=strtok(NULL,"^");
			part_type_str=strtok(NULL,"^");
			tce_cind_str=strtok(NULL,"^");
			tce_cmp_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_revseq_str!=NULL)tc_strdup(item_revseq_str,&item_revseq_strDup);
			if(part_type_str!=NULL)tc_strdup(part_type_str,&part_type_strDup);
			if(tce_cind_str!=NULL)tc_strdup(tce_cind_str,&tce_cind_strDup);
			if(tce_cmp_str!=NULL)tc_strdup(tce_cmp_str,&tce_cmp_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_revseq_strDup!=NULL)trimwhitespace(item_revseq_strDup);
			if(part_type_strDup!=NULL)trimwhitespace(part_type_strDup);
			if(tce_cind_strDup!=NULL)trimwhitespace(tce_cind_strDup);
			if(tce_cmp_strDup!=NULL)trimwhitespace(tce_cmp_strDup);
			
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Rev&Seq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			printf("\n Part Type(part_type_strDup): [%s]\n",part_type_strDup);
			printf("\n Part Colour Indicator(tce_cind_strDup): [%s]\n",tce_cind_strDup);
			printf("\n Part Comp Code(tce_cmp_strDup): [%s]\n",tce_cmp_strDup);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						DesRev_tag = titemobj_results[i];
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_ColourInd",&tcua_cind_str));
						if(tc_strlen(tcua_cind_str)>0)
						{
							tc_strdup(tcua_cind_str,&tcua_cind_strDup);
							trimwhitespace(tcua_cind_strDup);
						}
						else
						{
							//tc_strdup("--",&tcua_cind_strDup);
							printf("\n TCUA Colour_Indicator Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_PrtCatCode",&tcua_cmp_str));
						if(tc_strlen(tcua_cmp_str)>0)
						{
							tc_strdup(tcua_cmp_str,&tcua_cmp_strDup);
							trimwhitespace(tcua_cmp_strDup);
						}
						else
						{
							//tc_strdup("--",&tcua_cmp_strDup);
							printf("\n TCUA Comp_Code Value is NULL..!!");fflush(stdout);
						}
						
						if((tc_strcmp(tce_cind_strDup,tcua_cind_str) == 0) && (tc_strcmp(tce_cmp_strDup,tcua_cmp_strDup) == 0))
						{
						  tc_strcpy(responsestring,"OK");
						}
						else
						{
						  tc_strcpy(responsestring,"Not_OK");
						}
						
						printf(" Part Details Start...!!\n");fflush(stdout);
						printf("[1] Part_No: [%s]\n",item_id_strDup);fflush(stdout);
						printf("[2] Revision & Sequence: [%s]\n",item_revseq_strDup);fflush(stdout);
						printf("[3] Part Type: [%s]\n",part_type_strDup);fflush(stdout);
						printf("[4] TCE Colour Indicator: [%s]\n",tce_cind_strDup);fflush(stdout);
						printf("[5] TCE Comp Code: [%s]\n",tce_cmp_strDup);fflush(stdout);
						printf("[6] TCUA Colour Indicator: [%s]\n",tcua_cind_strDup);fflush(stdout);
						printf("[7] TCUA Comp Code: [%s]\n",tcua_cmp_strDup);fflush(stdout);
						printf("[8] Status: [%s]\n",responsestring);fflush(stdout);
						printf(" Part Details End...!!\n");fflush(stdout);
						
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_revseq_strDup,part_type_strDup,tce_cind_strDup,tce_cmp_strDup,tcua_cind_strDup,tcua_cmp_strDup,responsestring);fflush(fpOutput_file);
					}
				}
				else
                {
					printf(" DesignRevision Not Found..!!\n");fflush(stdout);
					fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_revseq_strDup,part_type_strDup,tce_cind_strDup,tce_cmp_strDup,"Not_Present","Not_Present","Not_Present");fflush(fpOutput_file);
				}
			}
			else
            {
				printf(" DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
		    }
			if(titemobj_results)
			{
				MEM_free(titemobj_results);
			}
		}
		fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
		fclose(fpOutput_file);	
		printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ColourPartRpt.c
* // ./linkitk -o tm_ColourPartRpt tm_ColourPartRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ColourPartReport/tm_ColourPartRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ColourPartReport/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ColourPartReport/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ColourPartReport/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ColourPartReport/SendEmail.sh .
* // ./tm_ColourPartRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_ColourPartRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/