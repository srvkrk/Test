/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   SubModule Variety Count Report
*  File Name    :   tm_MMCSubModCountRpt.c
*  Created on   :   Apr 03rd, 2024
*  Usage        :   tm_MMCSubModCountRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     03/04/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *MstrSubDet_str = NULL;
	char *MstrSubDet_strDup = NULL;
	FILE *fpMstr_List = NULL;
	char Buffer1[1024];
	FILE *fpGen_List = NULL;
	char Buffer2[1024];
	char *RptFile = (char *) malloc(100*sizeof(char));
	FILE *fpOutput_file = NULL;
	char *GenSubDet_str = NULL;
	char *GenSubDet_strDup = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"VarietyCountRpt");
	tc_strcat(RptFile,".txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	fpOutput_file = fopen(RptFile, "w");
	fpMstr_List = fopen("MasterList.txt","r");
	
	if(fpMstr_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer1,1024,fpMstr_List)!=NULL)
		{
			MstrSubDet_str=strtok(Buffer1,"^");
			if(MstrSubDet_str!=NULL)tc_strdup(MstrSubDet_str,&MstrSubDet_strDup);
			if(MstrSubDet_strDup!=NULL)trimwhitespace(MstrSubDet_strDup);	
            printf(" [1]: Master_SubMod_Details(MstrSubDet_strDup): [%s]\n",MstrSubDet_strDup);
			int VarietyCount = 0;
			if(tc_strlen(MstrSubDet_strDup)>0)
			{
				fpGen_List = fopen("SubModDetails.txt","r");
				if(fpGen_List != NULL)
	            {
					printf(" Generated File Not Null..!!\n");fflush(stdout);
					while(fgets(Buffer2,1024,fpGen_List)!=NULL)
					{
						GenSubDet_str=strtok(Buffer2,"^");
						if(GenSubDet_str!=NULL)tc_strdup(GenSubDet_str,&GenSubDet_strDup);
						if(GenSubDet_strDup!=NULL)trimwhitespace(GenSubDet_strDup);	
						printf(" [1]: Generated_SubMod_Details(GenSubDet_strDup): [%s]\n",GenSubDet_strDup);
						if(tc_strlen(GenSubDet_strDup)>0)
						{
							if(tc_strcmp(MstrSubDet_strDup,GenSubDet_strDup) == 0)
						    {
								VarietyCount = VarietyCount + 1;
							}
							else
							{
								printf(" SubModule Details Not Matched..!!\n");fflush(stdout);
							}
						}
						else
						{
							printf(" Generated SubModule Details NULL..!!\n");fflush(stdout);
						}
					}
                    fclose(fpGen_List);
	                printf("\n Generated_File CLosed");fflush(stdout);
                    fprintf(fpOutput_file,"%s^%d^\n",MstrSubDet_strDup,VarietyCount);fflush(fpOutput_file);					
				}
				else 
				{
					printf("\n Generated_File is NULL..!!\n");fflush(stdout);
				}
			}
            else
			{
				printf(" Master SubModule Details NULL..!!\n");fflush(stdout);
			}
		}
        fclose(fpMstr_List);
		printf("\n Master_Input_File Closed..!!");fflush(stdout);
        fclose(fpOutput_file);
        printf("\n Output_File Closed..!!");fflush(stdout);		
	}
	else 
	{
		printf("\n Master_Input_File is NULL..!!\n");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_MMCSubModCountRpt.c
* // ./linkitk -o tm_MMCSubModCountRpt tm_MMCSubModCountRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MMCSubModCountReport/tm_MMCSubModCountRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MMCSubModCountReport/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MMCSubModCountReport/usage.txt .
* // ./tm_MMCSubModCountRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_MMCSubModCountRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/