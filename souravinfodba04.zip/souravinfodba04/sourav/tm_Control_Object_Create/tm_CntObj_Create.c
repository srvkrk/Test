/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create Control Object From Input File Object Properties 
*  File Name    :   tm_CntObj_Create.c
*  Created on   :   Aug 09th, 2023
*  Usage        :   tm_CntObj_Create
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     09/08/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* CtrlObjName_Str = NULL;
	char* Syscd_Str = NULL;
	char* SubSyscd_Str = NULL;
	char* RcrdType_Str = NULL;
	char* Inf1_Str = NULL;
	char* Inf2_Str = NULL;
	char* Inf3_Str = NULL;
	char* Inf4_Str = NULL;
	char* Inf5_Str = NULL;
	char* Inf6_Str = NULL;
	char* Inf7_Str = NULL;
	char* Inf8_Str = NULL;
	char* Inf9_Str = NULL;
	char* Inf10_Str = NULL;
	char* DelInd_Str = NULL;
	char* CtrlObjName_StrDup = NULL;
	char* Syscd_StrDup = NULL;
	char* SubSyscd_StrDup = NULL;
	char* RcrdType_StrDup = NULL;
	char* Inf1_StrDup = NULL;
	char* Inf2_StrDup = NULL;
	char* Inf3_StrDup = NULL;
	char* Inf4_StrDup = NULL;
	char* Inf5_StrDup = NULL;
	char* Inf6_StrDup = NULL;
	char* Inf7_StrDup = NULL;
	char* Inf8_StrDup = NULL;
	char* Inf9_StrDup = NULL;
	char* Inf10_StrDup = NULL;
	char* DelInd_StrDup = NULL;	
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tObjCreate_Input=NULLTAG;
	tag_t tCtrlObj_Type=NULLTAG;
	tag_t new_object=NULLTAG;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("InputList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			CtrlObjName_Str=strtok(Buffer,"^");
			Syscd_Str=strtok(NULL,"^");
			SubSyscd_Str=strtok(NULL,"^");
			Inf1_Str=strtok(NULL,"^");
			Inf2_Str=strtok(NULL,"^");
			Inf3_Str=strtok(NULL,"^");
			Inf4_Str=strtok(NULL,"^");
			Inf5_Str=strtok(NULL,"^");
			Inf6_Str=strtok(NULL,"^");
			Inf7_Str=strtok(NULL,"^");
			Inf8_Str=strtok(NULL,"^");
			Inf9_Str=strtok(NULL,"^");
			Inf10_Str=strtok(NULL,"^");
			RcrdType_Str=strtok(NULL,"^");
			DelInd_Str=strtok(NULL,"^");
			
			if(CtrlObjName_Str!=NULL)tc_strdup(CtrlObjName_Str,&CtrlObjName_StrDup);
			if(Syscd_Str!=NULL)tc_strdup(Syscd_Str,&Syscd_StrDup);
			if(SubSyscd_Str!=NULL)tc_strdup(SubSyscd_Str,&SubSyscd_StrDup);
			if(Inf1_Str!=NULL)tc_strdup(Inf1_Str,&Inf1_StrDup);
			if(Inf2_Str!=NULL)tc_strdup(Inf2_Str,&Inf2_StrDup);
			if(Inf3_Str!=NULL)tc_strdup(Inf3_Str,&Inf3_StrDup);
			if(Inf4_Str!=NULL)tc_strdup(Inf4_Str,&Inf4_StrDup);
			if(Inf5_Str!=NULL)tc_strdup(Inf5_Str,&Inf5_StrDup);
			if(Inf6_Str!=NULL)tc_strdup(Inf6_Str,&Inf6_StrDup);
			if(Inf7_Str!=NULL)tc_strdup(Inf7_Str,&Inf7_StrDup);
			if(Inf8_Str!=NULL)tc_strdup(Inf8_Str,&Inf8_StrDup);
			if(Inf9_Str!=NULL)tc_strdup(Inf9_Str,&Inf9_StrDup);
			if(Inf10_Str!=NULL)tc_strdup(Inf10_Str,&Inf10_StrDup);
			if(RcrdType_Str!=NULL)tc_strdup(RcrdType_Str,&RcrdType_StrDup);
			if(DelInd_Str!=NULL)tc_strdup(DelInd_Str,&DelInd_StrDup);
					
			if(CtrlObjName_StrDup!=NULL)trimwhitespace(CtrlObjName_StrDup);
			if(Syscd_StrDup!=NULL)trimwhitespace(Syscd_StrDup);
			if(SubSyscd_StrDup!=NULL)trimwhitespace(SubSyscd_StrDup);
			if(Inf1_StrDup!=NULL)trimwhitespace(Inf1_StrDup);
			if(Inf2_StrDup!=NULL)trimwhitespace(Inf2_StrDup);
			if(Inf3_StrDup!=NULL)trimwhitespace(Inf3_StrDup);
			if(Inf4_StrDup!=NULL)trimwhitespace(Inf4_StrDup);
			if(Inf5_StrDup!=NULL)trimwhitespace(Inf5_StrDup);
			if(Inf6_StrDup!=NULL)trimwhitespace(Inf6_StrDup);
			if(Inf7_StrDup!=NULL)trimwhitespace(Inf7_StrDup);
			if(Inf8_StrDup!=NULL)trimwhitespace(Inf8_StrDup);
			if(Inf9_StrDup!=NULL)trimwhitespace(Inf9_StrDup);
			if(Inf10_StrDup!=NULL)trimwhitespace(Inf10_StrDup);
			if(RcrdType_StrDup!=NULL)trimwhitespace(RcrdType_StrDup);
			if(DelInd_StrDup!=NULL)trimwhitespace(DelInd_StrDup);
			
			printf(" Control Object Name(CtrlObjName_StrDup): [%s]\n",CtrlObjName_StrDup);
			printf(" SYSCD(Syscd_StrDup): [%s]\n",Syscd_StrDup);
			printf(" SUBSYSCD(SubSyscd_StrDup): [%s]\n",SubSyscd_StrDup);
			printf(" Information-1(Inf1_StrDup): [%s]\n",Inf1_StrDup);
			printf(" Information-2(Inf2_StrDup): [%s]\n",Inf2_StrDup);
			printf(" Information-3(Inf3_StrDup): [%s]\n",Inf3_StrDup);
			printf(" Information-4(Inf4_StrDup): [%s]\n",Inf4_StrDup);
			printf(" Information-5(Inf5_StrDup): [%s]\n",Inf5_StrDup);
			printf(" Information-6(Inf6_StrDup): [%s]\n",Inf6_StrDup);
			printf(" Information-7(Inf7_StrDup): [%s]\n",Inf7_StrDup);
			printf(" Information-8(Inf8_StrDup): [%s]\n",Inf8_StrDup);
			printf(" Information-9(Inf9_StrDup): [%s]\n",Inf9_StrDup);
			printf(" Information-10(Inf10_StrDup): [%s]\n",Inf10_StrDup);
			printf(" Record Type(RcrdType_StrDup): [%s]\n",RcrdType_StrDup);
			printf(" Delete Indicator(DelInd_StrDup): [%s]\n",DelInd_StrDup);
			
			ITK_CALL(QRY_find2("Control Objects...",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("Control Objects... Found Successfully..!!\n");fflush(stdout);
				char *cEntries[3]  = {"Name","SYSCD","SUBSYSCD"};
				char *cValues[3]  = {CtrlObjName_StrDup,Syscd_StrDup,SubSyscd_StrDup};
				//char *cValues[3]  = {"MATCLS-ZI-33","MATCLS","ZI","Ferrous metal & alloys"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Control Objects Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				
					if(n_itemobj_found > 0)
					{
						printf(" Control Object Already Exist..!!\n");fflush(stdout);
					}
					else
					{
						printf("\n ~~~~~~~~ C R E A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 
						ITK_CALL(TCTYPE_find_type ("T5_ControlObject", NULL, &tCtrlObj_Type));
						ITK_CALL(TCTYPE_construct_create_input(tCtrlObj_Type, &tObjCreate_Input));
						if(tObjCreate_Input != NULLTAG)
						{
							printf(" Input Tag Not NULL..!!\n");fflush(stdout);
							if((tc_strcmp(Syscd_StrDup," ") !=0) && (tc_strcmp(Syscd_StrDup," ") !=0))
							{
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"object_name",CtrlObjName_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Syscd",Syscd_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_SubSyscd",SubSyscd_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo1",Inf1_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo2",Inf2_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo3",Inf3_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo4",Inf4_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo5",Inf5_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo6",Inf6_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo7",Inf7_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo8",Inf8_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Userinfo9",Inf9_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_userinfo10",Inf10_StrDup));
								ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_RecordType",RcrdType_StrDup));
								//ITK_CALL(AOM_set_value_logical(tObjCreate_Input,"t5_DelInd",false));
								ITK_CALL(TCTYPE_create_object(tObjCreate_Input, &new_object));
								if(new_object != NULLTAG) 
								{
									printf(" Control Objects Created..!! \n");fflush(stdout);
								}
								else
								{
									printf(" Control Objects Not Created..!! \n");fflush(stdout);
								}
						        ITK_CALL(AOM_save(new_object));
								printf("\n Save...!!\n");
						        ITK_CALL(AOM_unlock(new_object));
								printf("\n Unlock..!!\n");
							}
						}
						else
						{
							printf(" Input Tag NULL..!!\n");fflush(stdout);
						}
						printf("\n ~~~~~~~~ C R E A T I O N   E N D ~~~~~~~~\n");fflush(stdout); 
					}				
			}
		    else
			{
				printf(" Control Object Tag Not Found..!!");fflush(stdout);
			}
			if (titemobj_results)
			{
				MEM_free(titemobj_results);
			}		

		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_CntObj_Create.c
* // ./linkitk -o tm_CntObj_Create tm_CntObj_Create.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Control_Object_Create/tm_CntObj_Create .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Control_Object_Create/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Control_Object_Create/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Control_Object_Create/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Control_Object_Create/SendEmail.sh .
* // ./tm_CntObj_Create -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_CntObj_Create -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_CntObj_Create -u=loader -p=loader123 -g=dba
*
***************************************************************************/