/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Team
*  Module       :   WSOM
*  Description  :   Green Report Uploader Code  
*  File Name    :   tm_GreenRptUpload.c
*  Created on   :   Dec 5th, 2023
*  Usage        :   tm_GreenRptUpload
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     08/02/2024                   Team
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 10000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\
		
int update_creation_date(tag_t, date_t);

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void trimLeading(char * str)
{
    int index, i, j;
    index = 0;
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }
    if(index != 0)
    {
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; 
    }
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* MonthAbbreviation (char* MonthNo)
{
	char *ResponseMonth = (char *) malloc(400*sizeof(char));
	printf("\n Input Month No in String: --------> [%s]\n", MonthNo);fflush(stdout);
	int monno = atoi(MonthNo);
	printf("\n Input Month No in Integer: --------> [%d]\n", monno);fflush(stdout);
	switch(monno)
   {
	case 1:
	       tc_strcpy(ResponseMonth,"Jan");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 2:
	       tc_strcpy(ResponseMonth,"Feb");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 3:
	       tc_strcpy(ResponseMonth,"Mar");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 4:
	       tc_strcpy(ResponseMonth,"Apr");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 5:
	       tc_strcpy(ResponseMonth,"May");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 6:
	       tc_strcpy(ResponseMonth,"Jun");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 7:
	       tc_strcpy(ResponseMonth,"Jul");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 8:
	       tc_strcpy(ResponseMonth,"Aug");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 9:
	       tc_strcpy(ResponseMonth,"Sep");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 10:
	       tc_strcpy(ResponseMonth,"Oct");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 11:
	       tc_strcpy(ResponseMonth,"Nov");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 12:
	       tc_strcpy(ResponseMonth,"Dec");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	default:
	       printf("Invalid Number");
	       break;
      }
	  return ResponseMonth;
}

char* DateFormatConstruct (char* InputDt)
{
	char* FormatDtRlzd = (char *) malloc(400*sizeof(char));
	char* RespMonth = NULL;
	char* InpYear = NULL;
	char* InpMonth = NULL;
	char* InpRemainDay = NULL;
	char* InpSeperate = NULL;
	char* InpHour = NULL;
	char* InpMin = NULL;
	char* InpSec = NULL;
	char* InpRemainMinHour = NULL;
	char* InpDay = NULL;
	InpYear=strtok(InputDt,"/");
	InpMonth=strtok(NULL,"/");
	InpRemainDay=strtok(NULL,"/");
	printf("\n Input Year: [%s]\n", InpYear);fflush(stdout);
	printf("\n Input Month: [%s]\n", InpMonth);fflush(stdout);
	printf("\n Input Remain Day: [%s]\n", InpRemainDay);fflush(stdout);
	InpDay=strtok(InpRemainDay,"-");
	InpRemainMinHour=strtok(NULL,"-");
	printf("\n Input Day: [%s]\n", InpDay);fflush(stdout);
	printf("\n Input Remain Minute & Hour: [%s]\n", InpRemainMinHour);fflush(stdout);
	InpHour=strtok(InpRemainMinHour,":");
	InpMin=strtok(NULL,":");
	InpSec=strtok(NULL,":");
	printf("\n Input Hour: [%s]\n", InpHour);fflush(stdout);
	printf("\n Input Minute: [%s]\n", InpMin);fflush(stdout);
	printf("\n Input Second: [%s]\n", InpSec);fflush(stdout);
	RespMonth = MonthAbbreviation(InpMonth);
	printf("\n Input Month Abbreviated Form: [%s]\n", RespMonth);fflush(stdout);
	tc_strcpy(FormatDtRlzd,InpDay);
	tc_strcat(FormatDtRlzd,"-");
	tc_strcat(FormatDtRlzd,RespMonth);
	tc_strcat(FormatDtRlzd,"-");
    tc_strcat(FormatDtRlzd,InpYear);
	tc_strcat(FormatDtRlzd," ");
    tc_strcat(FormatDtRlzd,InpHour);
    tc_strcat(FormatDtRlzd,":");
    tc_strcat(FormatDtRlzd,InpMin);
    printf("\n Formatted Date Released: [%s]\n", FormatDtRlzd);fflush(stdout);
	return FormatDtRlzd;
}

int update_creation_date(tag_t obj_tag, date_t date_created1)
{
	printf("\n Function[update_creation_date] Start..!!");fflush(stdout);
	int	ifail = ITK_ok;
	tag_t attr_id1=NULLTAG;
	printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);  
	ITK_CALL(AOM_refresh(obj_tag, POM_modify_lock));
	printf("\n Lock..!!\n");fflush(stdout);  
	POM_set_creation_date(obj_tag, date_created1);
	printf("\n Set Property Value..!!\n");fflush(stdout);  
	ITK_CALL(POM_save_instances(1, &obj_tag, true));
	printf("\n Save...!!\n");fflush(stdout);  
	ITK_CALL(AOM_refresh(obj_tag, POM_no_lock));
    printf("\n Unlock..!!\n");fflush(stdout);
	printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
	if(ifail == ITK_ok)
	{
		printf("\n CreationDate Updated.....!!");fflush(stdout);
	}
    printf("\n Function[update_creation_date] End..!!");fflush(stdout);
 
	return ifail;
}

int update_release_date(tag_t obj_tag, date_t date_rel)
{
	printf("\n Function(update_release_date) Start..!!\n");
	int	ifail = ITK_ok;
	tag_t attr_id1=NULLTAG;
	char* dateReleasedtest = NULL;
	printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 	
	ITK_CALL(AOM_refresh(obj_tag, POM_modify_lock));
	printf("\n Lock..!!\n");fflush(stdout);
	ITK_CALL(POM_attr_id_of_attr("date_released", "ReleaseStatus", &attr_id1));
	printf("\n Attr_Id:  [%d]",attr_id1);fflush(stdout);  
	printf("\n Property Name Tag Found..!!\n");fflush(stdout); 
	ITK_CALL(POM_set_attr_date(1, &obj_tag, attr_id1, date_rel));
	printf("\n Set Property Value..!!\n");fflush(stdout);  
	ITK_CALL(POM_save_instances(1, &obj_tag, true));
	printf("\n Save...!!\n");fflush(stdout);
	ITK_CALL(AOM_refresh(obj_tag, POM_no_lock));
	printf("\n Unlock..!!\n");fflush(stdout);
	ITK_CALL(AOM_UIF_ask_value(obj_tag,"date_released",&dateReleasedtest));
	printf("\n  ******dateReleased test is..[%s]\n",dateReleasedtest);fflush(stdout);	
	printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
	if(ifail == ITK_ok)
	{
		printf("\n Date Release Updated.....!!");fflush(stdout);
	}
    printf("\n Function(update_release_date) End..!!\n");
 
	return ifail;
}

int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS)
{
	printf("\n------Processing to create effectivity------- \n");

                tag_t   release_status =NULLTAG;
                char   *ReleaseStatus=NULL;
                logical  retain_released_date =false;
                logical  is_v7  ;
                char FrmNextDate[20]={0};
                char ToNextDate[20]={0};
                date_t test_date_1;
                date_t DayTommorow ;
                date_t test_date_2;
                date_t *start_end_date = NULL;
                tag_t eff_d = NULLTAG;
				
                int             ifail   =0;
                char* lcsToset= "T5_LcsErcRlzd";
                tag_t class_id=NULLTAG;
                char* class_name=NULL;
				

                int        status_count=0;
                int        status_countnew=0;
                int        ss=0;
                int        StatusFlg=0;
                tag_t* status_list = NULLTAG;
                tag_t* status_list_Neww = NULLTAG;
                tag_t status_list_One = NULLTAG;

                lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

                //printf("\n lifeCycleS: [%s]\n",lifeCycleS);fflush(stdout);


                //if((tc_strcmp(lifeCycleS,"T5_LcsErcRlzd")==0) || (tc_strcmp(lifeCycleS,"T5_LcsReview") == 0))
                if(tc_strcmp(lifeCycleS,"T5_LcsErcRlzd")==0)
                {
						{strcpy(lcsToset,"T5_LcsErcRlzd");}
                        ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
                        printf("Existing Status_count: %d\n",status_count);
                        if (status_count == 0) /* No Status, so the Item is not yet Released */
                        {
                                printf("No Existing Status, so the Item is not yet Released \n");
                        }
                        else
                        {
                                for(ss=0; ss<status_count ; ss++)
                                {
                                        ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
                                        printf("\n Existing Status : %s\n",class_name);
                                        if(strcmp(class_name,lcsToset)==0)
                                        {
											printf("\nstatus flag is greater than 0 and ERC Released \n");
                                                StatusFlg ++;
                                        }
                                }
                        }
						
						printf("Out from loop\n");						
                        //if(StatusFlg != 0) return ITK_ok;
                        printf("Stamping Releasing Item\n");
                        printf("FromDate : [%s]\n",FromDate);
                        printf("ToDate : [%s]\n",ToDate);
                        if((strcmp(FromDate,"-")==0) || (strcmp(ToDate,"-")==0))  return 0;

                        ITK_CALL(WSOM_ask_effectivity_mode(&is_v7));
                        printf("v7 Effectivity is:%d\n",is_v7);
						
						if(ITK_ok != (ifail = ITK_string_to_date(FromDate, &test_date_1 )))
                        {
                                return ifail;
                        }
						if(ITK_ok != (ifail = ITK_string_to_date(ToDate, &test_date_2 )))
                        {
                                return ifail;
                        }
                        
						
						//char *input_date = "31-Dec-9999 00:00";
						
						//RS						
						/* struct tm tm_date;
						if (strptime(FromDate, "%d-%b-%Y %H:%M", &tm_date) == NULL) {
							fprintf(stderr, "Error parsing date.\n");
							return 1;
						}
						// Format date as "2022/01/31"
						char converted_From_date[20];
						strftime(converted_From_date, sizeof(converted_From_date), "%Y/%m/%d", &tm_date);
						printf("Converted date: %s\n", converted_From_date);
						return 0;												
						printf("test after conversion ----------\n");
						printf("test after conversion **********\n"); */
						//END
						
                        //getNextDate(FromDate,FrmNextDate);
                        //getNextDate(converted_From_date,FrmNextDate);
                        //getNextDate(ToDate,ToNextDate);
                        //printf("FrmNextDate:%s\n",FrmNextDate);
                        //printf("ToNextDate:%s\n",ToNextDate);

                        /* if(ITK_ok != (ifail = ITK_string_to_date(FromDate, &test_date_1 )))
                        {
                                return ifail;
                        } 
                        if(ITK_ok != (ifail = ITK_string_to_date(ToNextDate, &test_date_2 )))
                        {
                                return ifail;
                        } */
						
						ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_countnew,&status_list_Neww));
						//ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
                        printf("Existing status_countnew New: %d\n",status_countnew);
						status_list_One = status_list_Neww[0];
						
						printf("test after conversion ----------\n");
                        start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);


                        start_end_date[0] = test_date_1;
                        start_end_date[1] = test_date_2;

                        ITK_CALL(WSOM_status_clear_effectivities ( status_list_One));
                        ITK_CALL(WSOM_effectivity_create_with_dates(status_list_One, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
                        ITK_CALL(AOM_save(eff_d));
                        ITK_CALL(AOM_save(status_list_One));
                        ITK_CALL(AOM_refresh( status_list_One, 0 ));
                        printf("Effectivity Stamping Completed : %s\n",FrmNextDate);

						
						
						
						
						
						
                        //RS date_released Start
                       /*   char* updatedDate = NULL;
                        date_t Req_Dt_Rlzd_tag;
                        tag_t RlzStat_AttrID = NULLTAG;
                        printf("\n ~~~~~~ U P D A T E   S T A R T ~~~~~~");fflush(stdout);
                        ITK_CALL(ITK_string_to_date(FrmNextDate,&Req_Dt_Rlzd_tag));
                        AOM_refresh(release_status, POM_modify_lock);
                        POM_attr_id_of_attr("date_released", "ReleaseStatus", &RlzStat_AttrID);
                        POM_set_attr_date(1, &release_status, RlzStat_AttrID, Req_Dt_Rlzd_tag);
                        POM_save_instances(1, &release_status, true);
                        AOM_refresh(release_status, POM_no_lock);
                        printf("\n ~~~~~~ U P D A T E   E N D ~~~~~~");fflush(stdout);

                        ITK_CALL(AOM_UIF_ask_value(release_status,"date_released",&updatedDate));
                        printf("\n After Updation [date_released] : %s\n",updatedDate); */

                        //RS date_released END


                }
               
   return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* FileName1, char* FileName2, char* FileName3, char* FileName4)
 {
		//const char *        DesignGrp                            = NULL;
		char                *TestItemNo                               = NULL;
		char                *TestItemNoDup                               = NULL;
		char                *LegacyMCTD                           = NULL;
		const char *        TestSubGrp                              = NULL;
		const char *        Aggregates                              = NULL;
		 char *        AggregatesDup                              = NULL;
		const char *        DescOfComp                               = NULL;
		char               *InternalDept                            = NULL;
		char               *DesGrp                                  = NULL;
		char                *PartFmly                               = NULL;
		char                *Keyword                                = NULL;
		const char *        MCTDcreator                             = NULL;
		char                *DeptHead                                = NULL;
		const char *        Remark                                  = NULL;
		const char *        Amendments                              = NULL;
		
		char                *GrpHead                                 = NULL;
		char                *Creator                                  = NULL;
		char                *CreatorDup                                  = NULL;
		char                *ParamValue                                = NULL;
		char                *itemid_para                               = NULL;
		tag_t               item_type_tag                              = NULLTAG;
		tag_t               item_create_input_tag                        = NULLTAG;
		tag_t               object                                      = NULLTAG;
		tag_t                parent_rev = NULLTAG;
		char                temp[10000];
		int                 n_items                                       = 0;
		//FILE                * fp                                         = NULL;
		FILE                * fp1                                         = NULL;
		FILE                * fp2                                         = NULL;
		FILE                * fp3                                         = NULL;
		tag_t               *item_tags                                    = NULL;
		//char                                   * Filename1               = NULL;

         FILE                * fpt                                                                  = NULL;
        const char *        Tablename                                                               = NULL;
       // const char *        OutTblname                                                               = NULL;
	    char   *OutTblname= NULL;
	    char   *OutTblname2= NULL;
		char *tempRev_ID	=NULL;
		char* tempOutTblname =NULL;
		char* tempOutTblname22 =NULL;
		const char *        testtye                                                                 = NULL;
		const char *        TsDesc                                                                  = NULL;
		const char *        TsSpec                                                                  = NULL;
		const char *        AccCrt                                                                   = NULL;
		const char *        AprOwn                                                                    = NULL;
		const char *        Mctdfclt                                                                  = NULL;
		const char *        MCTDSno                                                                  = NULL;
		const char *        pdfname                                                               = NULL;
		const char *        PdfFullPath                                                                 = NULL;
		const char *        PDFseq                                                                  = NULL;
		int                n_items1                                                                    = 0;
		int                n_items12                                                                    = 0;
		int                                                       t5SrNo                            = 0;
		int                                                       t5SrNo2                            = 0;
		tag_t                                     object1                                            = NULLTAG;
		tag_t                                     object2                                            = NULLTAG;
		tag_t                                     item_type_tag1                                     = NULLTAG;
		tag_t                                     item_type_tag12                                     = NULLTAG;
		tag_t                                     parent_rev1                                         = NULLTAG;
		tag_t                                     parent_rev2                                         = NULLTAG;
		tag_t                                     *item_tags1                                           = NULL;
		tag_t                                     *item_tags12                                           = NULL;
		tag_t                                     item_create_input_tag1                                = NULLTAG;
		tag_t                                     item_create_input_tag2                                = NULLTAG;
		char                                       temp1[10000];
		char                                       temp2[10000];
		
	    char                *CreationDate                               = NULL;
		char                *CreationDateDup                               = NULL;
		char                *LastUp                               = NULL;
		char                *LastUpDup                               = NULL;
		char                *DocumentDesc                               = NULL;
		char                *DocumentDescDup                               = NULL;
		char                *Revision                               = NULL;
		char                *RevisionDup                               = NULL;
		char                *Seq                               = NULL;
		char                *SeqDup                               = NULL;
		char                *DesignGrp                               = NULL;
		char                *PoojectCode2                               = NULL;
		char                *DesignGrpDup                               = NULL;
		char                *PoojectCode2Dup                               = NULL;
		//char                *TestItemNo                               = NULL;
		char                *RepRelType                               = NULL;
		char                *RepRelTypeDup                               = NULL;
		//char                *RepRelTypeDup                               = NULL;
		char                *RsnFrCndRelTyp                               = NULL;
		char                *RsnFrCndRelTypDup                               = NULL;
		char                *QualityDocumentType                               = NULL;
		char                *QualityDocumentTypeDup                               = NULL;
		char                *Verticle_Program                               = NULL;
		char                *Verticle_ProgramDup                               = NULL;
		//char                *Aggregates                               = NULL;
		char                *GRN_PDF_Document_Name                               = NULL;
		char                *GRN_PDF_Document_NameDup                               = NULL;
		char                *Conclusion                               = NULL;
		char                *ConclusionDup                               = NULL;
		//char Conclusion[MAX_LINE_LENGTH];
		char                *Clustureheadcmmt                               = NULL;
		char                *ClustureheadcmmtDup                               = NULL;
		char                *Grpheadcomment                               = NULL;
		char                *GrpheadcommentDup                               = NULL;
		char                *Intro                               = NULL;
		char                *IntroDup                               = NULL;
		char                *DimInspRprt                               = NULL;
		char                *DimInspRprtDup                               = NULL;
		char                *MatInspRpt                               = NULL;
		char                *MatInspRptDup                               = NULL;
		char                *Test                               = NULL;
		char                *TestDup                               = NULL;
		char                *Observation                               = NULL;
		char                *ObservationDup                               = NULL;
		char                *Vehicle_Fitment                               = NULL;
		char                *Vehicle_FitmentDup                               = NULL;
		char                *Copies_to                               = NULL;
		char                *Copies_toDup                               = NULL;
		char                *Equipment                               = NULL;
		char                *EquipmentDup                               = NULL;
		char                *Enclosure                               = NULL;
		char                *EnclosureDup                               = NULL;
		//char                *Creator                               = NULL;
		char                *LCstate                               = NULL;
		char                *LCstateDup                               = NULL;
		char                *PartRevSeq                               = NULL;
		char                *PartRevSeqDup                               = NULL;
		char                *DocumentName                               = NULL;
		char                *DocumentNameDup                               = NULL;
		char                *GrnRevSeq                               = NULL;
		char                *FormatCreateDate                               = NULL;
		char                *FormatReleasedDate                               = NULL;

		char *Srno=NULL;
        char *Vehicle_No=NULL; 
        char *Engine_no=NULL; 
        char *chessis_NO=NULL; 
        char *Test1=NULL; 
        char *VehCov=NULL; 
        char *Remarks=NULL; 
		
		char *Srno2=NULL;
		char *Testdsc=NULL;
		char *Testspecification=NULL;
		char *Acccriteria=NULL;
		char *NoOfSamp=NULL;
		char *obs=NULL;
		char *ResRem=NULL;
		//char *Srno2=NULL;
		
		char                Buffer[10000];
		date_t set_date;
		date_t date_created;
		date_t date_released;
        int iFail = ITK_ok;
		int ifail = 0;

		tag_t relation_type1;
		tag_t relation2_type2;
		tag_t relation = NULLTAG;
		tag_t relationPart2 = NULLTAG;
		tag_t relation2 = NULLTAG;

		tag_t item_tagexist = NULLTAG;
		tag_t item_tagexisttbl = NULLTAG;
		tag_t item_tagexisttb2 = NULLTAG;
		tag_t NewRevTag =NULL;
		tag_t item_tag =NULL;
		tag_t release_status =NULL;
		
	char Buffer1[10000];
	char Buffer2[10000];
	char Buffer3[10000];
	char replace_buffer[MAX_LINE_LENGTH];
	//char Buffer1[20000];
	char *partNoIP = NULL;
	partNoIP = (char *)MEM_alloc(250);
	char *PartRevSeq1 = NULL;
	PartRevSeq1 = (char *)MEM_alloc(50);
													
	tc_strcpy(partNoIP, "");	
	tc_strcpy(PartRevSeq1, "");
	char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	//char *cEntries[2]  = {"ID","Revision"};
	char *cEntries[2]  = {"Item ID","Revision"};
	tag_t* titemobj_results = NULLTAG;
	tag_t itemtag  = NULLTAG;
	char *PartID = NULL;
		
	fp1 = fopen(FileName1, "r");
	if(fp1 == NULL)
	{
		printf("\n Unable to Open GreenReport Information File:  [%s]\n",fp1);fflush(stdout);
		return iFail;
	}
    else
	{
		printf(" Input_File[MetaData Information] Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer1,MAX_LINE_LENGTH,fp1)!=NULL)
		//while(fgets(Buffer1,20000,fp1)!=NULL)
		{
			            printf("\n Buffer is ---%s \n",Buffer1);
			          
                    
		                 CreationDate=strtok(Buffer1,"~");
						 if(CreationDate!=NULL)tc_strdup(CreationDate,&CreationDateDup);
				         if(CreationDateDup!=NULL)trimwhitespace(CreationDateDup);
						 printf("\nInput CreationDate:%s\n",CreationDateDup);
						
						 //ITK_string_to_date(CreationDateDup, &set_date);
		                 DocumentDesc=strtok(NULL,"~");
						 if(DocumentDesc!=NULL)tc_strdup(DocumentDesc,&DocumentDescDup);
				         if(DocumentDescDup!=NULL)trimwhitespace(DocumentDescDup);
						 printf("\nInput DocumentDesc:%s\n",DocumentDescDup);
						 DocumentName=strtok(NULL,"~");
						 if(DocumentName!=NULL)tc_strdup(DocumentName,&DocumentNameDup);
				         if(DocumentNameDup!=NULL)trimwhitespace(DocumentNameDup);
						 printf("\nInput DocumentName:%s\n",DocumentNameDup);
		                 Revision=strtok(NULL,"~");
						 if(Revision!=NULL)tc_strdup(Revision,&RevisionDup);
				         if(RevisionDup!=NULL)trimwhitespace(RevisionDup);
						 printf("\nInput Revision:%s\n",RevisionDup);
		                 Seq=strtok(NULL,"~");
						 if(Seq!=NULL)tc_strdup(Seq,&SeqDup);
				         if(SeqDup!=NULL)trimwhitespace(SeqDup);
                         printf("\nInput Seq:%s\n",SeqDup);
						 GrnRevSeq=(char *)MEM_alloc(100);
						 tc_strcpy(GrnRevSeq,RevisionDup);
						 tc_strcat(GrnRevSeq,";");
						 tc_strcat(GrnRevSeq,SeqDup);
						 printf("\nInput GrnRevSeq:%s\n",GrnRevSeq);
                         PoojectCode2=strtok(NULL,"~");	
						 if(PoojectCode2!=NULL)tc_strdup(PoojectCode2,&PoojectCode2Dup);
				         if(PoojectCode2Dup!=NULL)trimwhitespace(PoojectCode2Dup);
						 printf("\nInput PoojectCode2 :%s\n",PoojectCode2Dup);
						 DesignGrp=strtok(NULL,"~");	
						 if(DesignGrp!=NULL)tc_strdup(DesignGrp,&DesignGrpDup);
				         if(DesignGrpDup!=NULL)trimwhitespace(DesignGrpDup);
						 printf("\nInput DesignGrp :%s\n",DesignGrpDup);
						 TestItemNo = strtok(NULL, "~");
						 if(TestItemNo!=NULL)tc_strdup(TestItemNo,&TestItemNoDup);
				         if(TestItemNoDup!=NULL)trimwhitespace(TestItemNoDup);
						 printf("\nInput TestItemNo:%s\n",TestItemNoDup);
						 RepRelType = strtok(NULL, "~");
						 if(RepRelType!=NULL)tc_strdup(RepRelType,&RepRelTypeDup);
				         if(RepRelTypeDup!=NULL)trimwhitespace(RepRelTypeDup);
						 printf("\nRepRelType:%s\n",RepRelTypeDup);
						 RsnFrCndRelTyp = strtok(NULL, "~");
						 if(RsnFrCndRelTyp!=NULL)tc_strdup(RsnFrCndRelTyp,&RsnFrCndRelTypDup);
				         if(RsnFrCndRelTypDup!=NULL)trimwhitespace(RsnFrCndRelTypDup);
						 printf("\nRsnFrCndRelTyp  --%s\n",RsnFrCndRelTypDup);
						 QualityDocumentType = strtok(NULL, "~");
						 if(QualityDocumentType!=NULL)tc_strdup(QualityDocumentType,&QualityDocumentTypeDup);
				         if(QualityDocumentTypeDup!=NULL)trimwhitespace(QualityDocumentTypeDup);
						 printf("QualityDocumentType%s\n", QualityDocumentTypeDup);
						 Verticle_Program = strtok(NULL, "~");
						 if(Verticle_Program!=NULL)tc_strdup(Verticle_Program,&Verticle_ProgramDup);
				         if(Verticle_ProgramDup!=NULL)trimwhitespace(Verticle_ProgramDup);
						 printf("\nVerticle_Program  is  --%s\n", Verticle_ProgramDup);
						 Aggregates = strtok(NULL, "~");
						 if(Aggregates!=NULL)tc_strdup(Aggregates,&AggregatesDup);
				         if(AggregatesDup!=NULL)trimwhitespace(AggregatesDup);
						 printf("\nAggregates is  --%s\n", AggregatesDup);
						 GRN_PDF_Document_Name = strtok(NULL, "~");
						 if(GRN_PDF_Document_Name!=NULL)tc_strdup(GRN_PDF_Document_Name,&GRN_PDF_Document_NameDup);
				         if(GRN_PDF_Document_NameDup!=NULL)trimwhitespace(GRN_PDF_Document_NameDup);
						 printf("\nGRN_PDF_Document_Name  is  --%s\n", GRN_PDF_Document_NameDup);
						 Conclusion = strtok(NULL, "~");
						 if(Conclusion!=NULL)tc_strdup(Conclusion,&ConclusionDup);
				         if(ConclusionDup!=NULL)trimwhitespace(ConclusionDup);
						 printf("\nConclusion is %s\n", ConclusionDup);
						 Clustureheadcmmt = strtok(NULL, "~");
						 if(Clustureheadcmmt!=NULL)tc_strdup(Clustureheadcmmt,&ClustureheadcmmtDup);
				         if(ClustureheadcmmtDup!=NULL)trimwhitespace(ClustureheadcmmtDup);
						 printf("\n Clustureheadcmmt is %s\n", ClustureheadcmmtDup);							
						 Grpheadcomment = strtok(NULL, "~");
						 if(Grpheadcomment!=NULL)tc_strdup(Grpheadcomment,&GrpheadcommentDup);
				         if(GrpheadcommentDup!=NULL)trimwhitespace(GrpheadcommentDup);
						 printf("\nGrpheadcomment is :%s\n", GrpheadcommentDup);
						 Intro = strtok(NULL, "~");
						 if(Intro!=NULL)tc_strdup(Intro,&IntroDup);
				         if(IntroDup!=NULL)trimwhitespace(IntroDup);
						 printf("Intro:%s\n", IntroDup);
						 DimInspRprt = strtok(NULL, "~");
						 if(DimInspRprt!=NULL)tc_strdup(DimInspRprt,&DimInspRprtDup);
				         if(DimInspRprtDup!=NULL)trimwhitespace(DimInspRprtDup);
						 printf("\nDimInspRprt  is  --:%s\n", DimInspRprtDup);
						 MatInspRpt = strtok(NULL, "~");
						 if(MatInspRpt!=NULL)tc_strdup(MatInspRpt,&MatInspRptDup);
				         if(MatInspRptDup!=NULL)trimwhitespace(MatInspRptDup);
						 printf("\nMatInspRpt  -- %s\n", MatInspRptDup);
					     Test = strtok(NULL, "~");
						 if(Test!=NULL)tc_strdup(Test,&TestDup);
				         if(TestDup!=NULL)trimwhitespace(TestDup);
					     printf("\nTest is  --:%s\n", TestDup);
					     Observation = strtok(NULL, "~");
						 if(Observation!=NULL)tc_strdup(Observation,&ObservationDup);
				         if(ObservationDup!=NULL)trimwhitespace(ObservationDup);
					     printf("\nObservation is  -- %s\n", ObservationDup);
					     Vehicle_Fitment = strtok(NULL, "~");
						 if(Vehicle_Fitment!=NULL)tc_strdup(Vehicle_Fitment,&Vehicle_FitmentDup);
				         if(Vehicle_FitmentDup!=NULL)trimwhitespace(Vehicle_FitmentDup);
					     printf("\nVehicle_Fitment is  -- %s\n", Vehicle_FitmentDup);										
					     Copies_to = strtok(NULL, "~");
						 if(Copies_to!=NULL)tc_strdup(Copies_to,&Copies_toDup);
				         if(Copies_toDup!=NULL)trimwhitespace(Copies_toDup);
					     printf("\nCopies_to is  -- %s\n", Copies_toDup);	
                         Equipment = strtok(NULL, "~");
						 if(Equipment!=NULL)tc_strdup(Equipment,&EquipmentDup);
				         if(EquipmentDup!=NULL)trimwhitespace(EquipmentDup);
	                     printf("\nEquipmentis  -- %s\n", EquipmentDup);				
						 Enclosure = strtok(NULL, "~");
						 if(Enclosure!=NULL)tc_strdup(Enclosure,&EnclosureDup);
				         if(EnclosureDup!=NULL)trimwhitespace(EnclosureDup);
						 printf("\nEnclosure is  -- %s\n", EnclosureDup);											
						 Creator = strtok(NULL, "~");
						 if(Creator!=NULL)tc_strdup(Creator,&CreatorDup);
				         if(CreatorDup!=NULL)trimwhitespace(CreatorDup);
						 printf("\nCreator is  -- %s\n", CreatorDup);											
						 LCstate = strtok(NULL, "~");
						 if(LCstate!=NULL)tc_strdup(LCstate,&LCstateDup);
				         if(LCstateDup!=NULL)trimwhitespace(LCstateDup);
						 printf("\nLCstate is  -- %s\n", LCstateDup);
						 LastUp=strtok(NULL,"~");
						 if(LastUp!=NULL)tc_strdup(LastUp,&LastUpDup);
				         if(LastUpDup!=NULL)trimwhitespace(LastUpDup);
						 printf("\nInput LastUpDup:%s\n",LastUpDup);
						 PartRevSeq = strtok(NULL, "~");
						 if(PartRevSeq!=NULL)tc_strdup(PartRevSeq,&PartRevSeqDup);
				         if(PartRevSeqDup!=NULL)trimwhitespace(PartRevSeqDup);
						 printf("\nPartRevSeqis  -- %s\n", PartRevSeqDup);


											//const char *item_id="IDT/MCTD/AETE/0131";
											//const char *item_name="mctd";

									ifail = ITEM_find (DocumentNameDup, &n_items, &item_tags);
									printf("\nNo. of Green Report found:%d\n", n_items);

								if(n_items == 0)
				                {
									printf("\nRequired parameter not found, hence going to create new parameter...!!)))))))))))))))\n");
									ifail = TCTYPE_find_type("T5_GrnRep", "Document", &item_type_tag);  
                                     printf("\n inside TCTYPE_find_type   \n");									
									ifail = TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);
									 printf("\n inside TCTYPE_construct_create_input   \n");	
					                // ifail=TCTYPE_set_create_display_value(item_create_input_tag,"object_name",1,&item_name);
					                // ITK_CALL(AOM_set_value_string(object,"object_desc","IDT/MCTD/AETE/0147"));
									//ITK_CALL(AOM_set_value_string(object,"object_name","IDT/MCTD/AETE/0147"));
									
									ifail = TCTYPE_create_object (item_create_input_tag, &object);
                                    printf("\n inside TCTYPE_create_object   \n");
									//ifail=TCTYPE_create_object(item_create_input_tag,&object);  

										if(object != NULLTAG)
									    {
											printf("\n ############  \n");

											printf("\n T5_ControlObject : object created.");
											ITK_CALL(AOM_save(object));
											printf("\n T5_ControlObject : object Saved.");
											ITK_CALL(AOM_unlock(object));

											ITK_CALL(AOM_refresh(object,1));
							
											ITK_CALL(AOM_set_value_string(object,"item_id",DocumentNameDup));
											//ITK_CALL(AOM_set_value_string(object,"object_desc",DesignGrp));
											//ITK_CALL(AOM_set_value_string(object,"object_name",DesignGrp));
											//ITK_CALL(AOM_set_value_string(object,"item_revision_id","A;1"));
											ITK_CALL(AOM_save(object));
											ITK_CALL(AOM_refresh(object,0));
											ITK_CALL(ITEM_ask_latest_rev(object,&parent_rev));
											if(parent_rev != NULLTAG)
											{
													printf("\n inside property set on main object   \n");
													ITK_CALL(AOM_refresh(parent_rev,1));
													FormatCreateDate = DateFormatConstruct(CreationDateDup);
													ITK_CALL(ITK_string_to_date(FormatCreateDate,&date_created));
													ifail = update_creation_date(parent_rev, date_created);
													
													tag_t itemTag = NULLTAG;
												    ifail = ITEM_find_item(DocumentNameDup, &itemTag);
			                                        if(itemTag != NULLTAG)
			                                        {
												       printf("\n Function[update_creation_date] Call Start..!!");fflush(stdout);
						                               ifail = update_creation_date(itemTag, date_created);
						                               printf("\n Function[update_creation_date] Call End..!!");fflush(stdout);
													}
													else
													{
														printf("\n Item Tag is NULL..!!");fflush(stdout);
													}
													
													//release start
													if(tc_strcmp(LCstateDup,"LcsReleased")!=0)
													{
													    printf(" ******  Release Status not matched********** \n");
													}
													else
													{
														printf(" ******Now Stamping Release Status********** \n");
														ITK_CALL(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
														ITK_CALL(RELSTAT_add_release_status(release_status,1,&parent_rev,false));
														
														FormatReleasedDate = DateFormatConstruct(LastUpDup);
														ITK_CALL(ITK_string_to_date(FormatReleasedDate,&date_released));
														//update_release_date(Stat_tag, date_rlzd);
														ifail = update_release_date(parent_rev, date_released);
														
														printf("\n Function[*****Create Effectivity Status*****] Call Start..!!");fflush(stdout);
														ITK_CALL(CreateEffctivity(parent_rev,FormatReleasedDate,"31-Dec-9999 00:00","T5_LcsErcRlzd"));
													    printf("\n Function[*****Create Effectivity Status*****] Call End..!!");fflush(stdout);
														
														int status_count = 0;
														tag_t* relStatus_list = NULLTAG;
														char* latest_rev_Rel_Status = NULL;
														char* latest_rev_Rel_StatusDup = NULL;
														//char* latest_rev_Part_Type = NULL;
														//char* PrtShellCommandLine = NULL;
														//PrtShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
														//char* dt_rlzd =    NULL;
														//char* dt_rlzdDup = NULL;
														//char* InpYear = NULL;
														//char* InpMonth = NULL;
														//char* InpRemainDay = NULL;
														//char* InpSeperate = NULL;
														//char* InpHour = NULL;
														//char* InpMin = NULL;
														//char* InpSec = NULL;
														//char* InpRemainMinHour = NULL;
														//char* InpDay = NULL;
														//char* FormatDtRlzd = (char *) malloc(400*sizeof(char));
														char* Up_dt_rlzd = NULL;
														//char* RespMonth = NULL;
														//date_t	FormatDtRlzd1 = NULLDATE;
														//date_t Req_Dt_Rlzd_tag;
														tag_t Stat_tag = NULLTAG;
														tag_t RlzStat_AttrID = NULLTAG;
														printf("\n >>>>>>> DATE RELEASED UPDATE ON FLAG <<<<<<<< \n");fflush(stdout);
														printf("\n Input [Last Modified Date]: [%s]\n",LastUpDup);fflush(stdout);
														WSOM_ask_release_status_list(parent_rev, &status_count, &relStatus_list);
									                    printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
														if(status_count>0)
														{
															int k = 0;
															for(k = 0; k<status_count; k++)
															{
																AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_StatusDup);
																printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);

																if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0))
																{
																	/*ITK_CALL(AOM_UIF_ask_value(relStatus_list[k],"date_released",&dt_rlzd));
																	printf(" \n Release Status Date Released String: ------> <%s>\n",dt_rlzd);fflush(stdout);
																	if(tc_strlen(dt_rlzd)>0)
																	{
																		tc_strdup(dt_rlzd,&dt_rlzdDup);
																		tc_strdup(latest_rev_Rel_StatusDup,&latest_rev_Rel_Status);
																		printf("\n Date Released Value --------> [%s]\n", dt_rlzdDup);fflush(stdout);
																		printf("\n Latest_Rev_Rel_Status Value --------> [%s]\n", latest_rev_Rel_Status);fflush(stdout);
																	}
																	else
																	{
																		tc_strdup("",&dt_rlzdDup);
																		tc_strdup("",&latest_rev_Rel_Status);
																		printf("\n Date Released Value is NULL \n");fflush(stdout);
																		printf("\n Latest Rev Released Status Value is NULL \n");fflush(stdout);
																	}
																	trimLeading(dt_rlzdDup);
																	trimLeading(latest_rev_Rel_Status);
																	printf("\n Date Released Value After Trim --------> [%s]\n", dt_rlzdDup);fflush(stdout);
																	printf("\n Latest Rev Released Status Value After Trim --------> [%s]\n", latest_rev_Rel_Status);fflush(stdout);
																	
																	InpYear=strtok(LastUpDup,"/");
																	InpMonth=strtok(NULL,"/");
																	InpRemainDay=strtok(NULL,"/");
																	printf("\n Input Year --------> [%s]\n", InpYear);fflush(stdout);
																	printf("\n Input Month --------> [%s]\n", InpMonth);fflush(stdout);
																	printf("\n Input Remain Day --------> [%s]\n", InpRemainDay);fflush(stdout);
																	
																	InpDay=strtok(InpRemainDay,"-");
																	InpRemainMinHour=strtok(NULL,"-");
																	printf("\n Input Day --------> [%s]\n", InpDay);fflush(stdout);
																	printf("\n Input Remain Minute & Hour --------> [%s]\n", InpRemainMinHour);fflush(stdout);
																	
																	InpHour=strtok(InpRemainMinHour,":");
																	InpMin=strtok(NULL,":");
																	InpSec=strtok(NULL,":");
																	
																	printf("\n Input Hour --------> [%s]\n", InpHour);fflush(stdout);
																	printf("\n Input Minute --------> [%s]\n", InpMin);fflush(stdout);
																	printf("\n Input Second --------> [%s]\n", InpSec);fflush(stdout);
																	
																	RespMonth = MonthAbbreviation(InpMonth);
																	printf("\n Input Month Abbreviated Form --------> [%s]\n", RespMonth);fflush(stdout);
																	
																	tc_strcpy(FormatDtRlzd,InpDay);
																	tc_strcat(FormatDtRlzd,"-");
																	tc_strcat(FormatDtRlzd,RespMonth);
																	tc_strcat(FormatDtRlzd,"-");
																	tc_strcat(FormatDtRlzd,InpYear);
																	tc_strcat(FormatDtRlzd," ");
																	tc_strcat(FormatDtRlzd,InpHour);
																	tc_strcat(FormatDtRlzd,":");
																	tc_strcat(FormatDtRlzd,InpMin);
																	printf("\n Formatted Date Released --------> [%s]\n", FormatDtRlzd);fflush(stdout);
																	*/
																	Stat_tag = relStatus_list[k];
																	
																    printf("\n ~~~~~~ U P D A T E   S T A R T ~~~~~~");fflush(stdout);
																	//ITK_CALL(ITK_string_to_date(FormatDtRlzd,&Req_Dt_Rlzd_tag));
																	ITK_CALL(AOM_refresh(relStatus_list[k], POM_modify_lock));
																	ITK_CALL(POM_attr_id_of_attr("date_released", "ReleaseStatus", &RlzStat_AttrID));
																	ITK_CALL(POM_set_attr_date(1, &relStatus_list[k], RlzStat_AttrID, date_released));
																	ITK_CALL(POM_save_instances(1, &relStatus_list[k], true));
																	ITK_CALL(AOM_refresh(relStatus_list[k], POM_no_lock));
																	printf("\n ~~~~~~ U P D A T E   E N D ~~~~~~");fflush(stdout);
																	
																	ITK_CALL(AOM_UIF_ask_value(Stat_tag,"date_released",&Up_dt_rlzd));
																	printf("\n############################################\n");fflush(stdout);
																    printf(" \n Updated Released Date: ------> <%s>\n",Up_dt_rlzd);fflush(stdout);
																	printf("\n############################################\n");fflush(stdout);
																}
																else
																{
														           printf("\n Latest Revision Release Status Not ERC Released..!!\n");fflush(stdout);
																}
															}
														}
														else
														{
															printf("\n Release Status Not Present[status_count] Zero..!!\n");fflush(stdout);
														}
													}
												//	else
												//	{
												//		printf("\n Input File LC State Not ERC Released..!!\n");fflush(stdout);
												//	}
												
												    /* tag_t itemTag = NULLTAG;
												    ifail = ITEM_find_item(DocumentNameDup, &itemTag);
			                                        if(itemTag != NULLTAG)
			                                        {
												       printf("\n Function[update_creation_date] Call Start..!!");fflush(stdout);
						                               ifail = update_creation_date(itemTag, date_released);
						                               printf("\n Function[update_creation_date] Call End..!!");fflush(stdout);
													}
													else
													{
														printf("\n Item Tag is NULL..!!");fflush(stdout);
													} */
													
												    printf("\n ** Value Set To Object Start *** \n"); fflush(stdout);
													ITK_CALL(AOM_set_value_string(parent_rev,"object_desc",DocumentDescDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"object_name",DocumentNameDup));
													 printf("\nInput GrnRevSeq:%s\n",GrnRevSeq);
													ITK_CALL(AOM_set_value_string(parent_rev,"item_revision_id",GrnRevSeq));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_GRprojcode",PoojectCode2Dup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5designgroup",DesignGrpDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_TestItmNoGr",TestItemNoDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_GrnRepRlsType",RepRelTypeDup));
													//ITK_CALL(AOM_set_value_string(parent_rev,"t5_RsnFrCndRelTyp",RsnFrCndRelTypDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_AggregatesGr",AggregatesDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_GRNPDFDocName",GRN_PDF_Document_NameDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_ConclusionGCHcmtGR",ClustureheadcmmtDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_ConclusionGGHcmt",GrpheadcommentDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_ConclusionGR",ConclusionDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_IntroductionGR",IntroDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_DirGR",DimInspRprtDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_MirGR",MatInspRptDup));
                                                    ITK_CALL(AOM_set_value_string(parent_rev,"t5_TestGR",TestDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_ObservationGR",ObservationDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_VehFitmentGR",Vehicle_FitmentDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_CopiesToGR",Copies_toDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_EnclosureGR",EnclosureDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_EquipmentsGR",EquipmentDup));
													ITK_CALL(AOM_save(parent_rev));
													ITK_CALL(AOM_refresh(parent_rev,0));
													printf("\n ** Value Set To Object End *** \n"); fflush(stdout);
														
											}
											else
											{
												printf("\n Latest Revision Not Present..!!\n");fflush(stdout);
											}
													
										}
										else
										{
											printf("\n Object NULLTAG..!!\n");fflush(stdout);
										}                                 
                                }
								 else //Item aleady exists						
								 {
                                    printf("\nItem aleady exists\n");

									 //declare item_tag
									 item_tag = item_tags[0]; 
							         ITK_CALL(ITEM_find_revision(item_tag,DocumentName,&parent_rev));
									 if(parent_rev != NULLTAG)
									 {
										//revision already present
										 printf("\nItem Revision aleady exists\n");

									 }
									 else 
									 {
										 //mater present ..revision not present
										 ITK_CALL(ITEM_create_rev(item_tag,DocumentName,&parent_rev));
                                                    ITK_CALL(AOM_refresh(parent_rev,1));
													FormatCreateDate = DateFormatConstruct(CreationDateDup);
													ITK_CALL(ITK_string_to_date(FormatCreateDate,&date_created));
													ifail = update_creation_date(parent_rev, date_created);
													ITK_CALL(AOM_set_value_string(parent_rev,"object_desc",DocumentDescDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"object_name",DocumentNameDup));
												//	ITK_CALL(AOM_set_value_string(parent_rev,"item_revision_id",GrnRevSeq));

													ITK_CALL(AOM_set_value_string(parent_rev,"t5designgroup",DesignGrpDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_TestItmNoGr",TestItemNoDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_GrnRepRlsType",RepRelTypeDup));
													//ITK_CALL(AOM_set_value_string(parent_rev,"t5_RsnFrCndRelTyp",RsnFrCndRelTypDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_AggregatesGr",AggregatesDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_GRNPDFDocName",GRN_PDF_Document_NameDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_ConclusionGR",ConclusionDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_IntroductionGR",IntroDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_DirGR",DimInspRprtDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_MirGR",MatInspRptDup));
                                                    ITK_CALL(AOM_set_value_string(parent_rev,"t5_TestGR",TestDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_ObservationGR",ObservationDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_VehFitmentGR",Vehicle_FitmentDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_ConclusionGCHcmtGR",ClustureheadcmmtDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_ConclusionGGHcmt",GrpheadcommentDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_CopiesToGR",Copies_toDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_EnclosureGR",EnclosureDup));
													ITK_CALL(AOM_set_value_string(parent_rev,"t5_EquipmentsGR",EquipmentDup));
			
										            ITK_CALL(AOM_save(parent_rev));
										            ITK_CALL(AOM_unlock(parent_rev));

									 
									 }
								

								 
								 }
                                                
								   printf("\n OBJECT CREATION ***************************************\n");
								   	ITK_CALL(ITEM_find_item(DocumentName,&item_tagexist));
									printf("\n ITEM_find_item\n");
									
								    ITK_CALL(ITEM_ask_latest_rev(item_tagexist,&parent_rev));
									if(parent_rev != NULLTAG)
									{
										printf("\n inside item_tags parent_rev is not null  \n");

									}

										tc_strcpy(Buffer1, "");
										
				// Adding logic for cretae relation with part
				        partNoIP = strtok(PartRevSeqDup,"_");
						PartRevSeq1 = strtok(NULL,"_");
						
												
						printf("\n partNoIP-----------> :%s\n",partNoIP);fflush(stdout);
						printf("\n PartRevSeq1-----------> :%s\n",PartRevSeq1);fflush(stdout);
						
						printf("\n ===========Saurabh Yadav============= ");fflush(stdout);
					
					
						cValues[0] = partNoIP;
						//cValues[0] = "900191000101";
						cValues[1] = PartRevSeq1;
						//cValues[1] = "NR;1";
						//cValues[2] = "Design Revision";
						
						ITK_CALL(QRY_find2("Item Revision...",&tItemobj));						
						//ITK_CALL(QRY_find2("DesignRevision PartType",&tItemobj));						
						ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));		
						printf("\n n_itemobj_found --> %d ",n_itemobj_found);fflush(stdout);
						if(n_itemobj_found>0)														
						{
							 	itemtag=titemobj_results[0];
                                //itemtag1=titemobj_results[0];	
                                tag_t relationPart = NULLTAG;								
								ITKCALL(AOM_ask_value_string(itemtag,"item_id",&PartID));
								ITKCALL(AOM_ask_value_string(itemtag,"item_revision_id",&PartRevSeq1));									
								printf("\nPartID PartRevSeq1  :%s %s",partNoIP,PartRevSeq1);fflush(stdout);
								 //ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&reln_type_tag2));
								//GRM_create_relation(parent_rev, itemtag, reln_type_tag2,  NULLTAG, &relation);
								//if(GRM_save_relation (relation));
								ITK_CALL(GRM_find_relation_type("T5_GR_DesRev_Rel",&relationPart));
								if(relationPart != NULLTAG)
								{
									printf("\n 7777777777777777  \n"); fflush(stdout);
								  ITK_CALL(GRM_create_relation(parent_rev,itemtag,relationPart,NULLTAG,&relationPart2));
								  printf("\n 88888888888888   \n"); fflush(stdout);
								 // ITK_CALL(AOM_unlock(relationPart2));
								  printf("\n 9999999999999999999  \n"); fflush(stdout);
								  GRM_save_relation(relationPart2);
								 //   ITK_CALL(AOM_lock(relationPart2));
								   printf("\nRELATIONSHIP CREATED  \n");fflush(stdout);
								}
						}
                        else
						{
							printf("\n ===========Unable to query Part hence not creating relation============= ");fflush(stdout);
						}						
							
							
                //end logic for create relation with part				
										
										
										
                               }
                }
				 fclose(fp1);
    //table file1 goin to open
    fp2 = fopen(FileName2, "r");
	if(fp2 == NULL)
	{
		printf("\n Unable to Open Vehicle info File:  [%s]\n",fp2);fflush(stdout);
		return iFail;
	}
	 else
	{
		printf(" Input_File[Vehicle info] Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer2,MAX_LINE_LENGTH,fp2)!=NULL)
		//while(fgets(Buffer1,20000,fp1)!=NULL)
		{
          

          printf("\n Buffer2 is ---%s \n",Buffer2);
          Srno = strtok(Buffer2, "~");
		  printf("\n Srno   -- %s\n", Srno);
		  Vehicle_No = strtok(NULL, "~");
		  printf("\nFor Vehicle_No  --:%s\n", Vehicle_No);
		  Engine_no = strtok(NULL, "~");
		  printf("\nFor Engine_no  --:%s\n", Engine_no);
		  chessis_NO = strtok(NULL, "~");
		  printf("\nFor chessis_NO  --:%s\n", chessis_NO);
		  Test1 = strtok(NULL, "~");
		  printf("\nFor Test1  --:%s\n", Test1);
		  VehCov = strtok(NULL, "~");
		  printf("\nFor VehCov  --:%s\n", VehCov);
		  Remarks = strtok(NULL, "~");
		  printf("\nFor Remarks  --:%s\n", Remarks);
          
		  //table logic start
		   if(tc_strlen(DocumentNameDup) > 0) 
					{
						
						/*ITK_CALL(STRNG_replace_str(DocumentNameDup,"MCTD","MD",&OutTblname));
						printf("\n TABLE CREATED with updated name---%s \n",OutTblname);
						// Add Rev and Seq to OutTblname
						
                          */
						//printf("\n After STRNG_replace_str tempRev_ID  -%s \n",tempRev_ID);

						tempOutTblname=(char *)MEM_alloc(100);
						tc_strcpy(tempOutTblname,"");
						tc_strcpy(tempOutTblname,DocumentNameDup);
						tc_strcat(tempOutTblname,"_");
						tc_strcat(tempOutTblname,"VFT");
						tc_strcat(tempOutTblname,"_");
						tc_strcat(tempOutTblname,Srno);
                        tc_strcat(tempOutTblname,"/");
						tc_strcat(tempOutTblname,stripBlanks(GrnRevSeq));
						tc_strcat(tempOutTblname,";");
						tc_strcat(tempOutTblname,"1");
						tc_strcat(tempOutTblname,"-");
						tc_strcat(tempOutTblname,Srno);

						printf("\n tempOutTblname After adding the Rev and Seq---%s \n",tempOutTblname);

						OutTblname=(char *)MEM_alloc(100);
						tc_strcpy(OutTblname,"");
						tc_strcpy(OutTblname,tempOutTblname);


						printf("\n OutTblname after copy ---%s \n",OutTblname);

					      ifail = ITEM_find (OutTblname, &n_items1, &item_tags1);
						  printf("\nTable No. of GreenReport found:%d\n", n_items1);

								if(n_items1 == 0)
							   {
									ifail = TCTYPE_find_type("T5_Veh_Info", "Document", &item_type_tag1);         
									ifail = TCTYPE_construct_create_input(item_type_tag1, &item_create_input_tag1);
																								
									//ifail = TCTYPE_create_object (item_create_input_tag1, &object1);
									ifail=TCTYPE_create_object(item_create_input_tag1,&object1);
															
											 if(object1 != NULLTAG)
											  {
												printf("\n ~~~~~~~~~~~~~~~~~~~ \n");

												printf("\n TABLE CREATED  object created \n");
												ITK_CALL(AOM_save(object1));
												printf("\n TABLE CREATED   object Saved. \n");
												ITK_CALL(AOM_unlock(object1));

												ITK_CALL(AOM_refresh(object1,1));
												//ITK_CALL(STRNG_replace_str(Tablename,"MCTD","MD",&OutTblname));
												//printf("\n TABLE CREATED with updated name---%s \n",OutTblname);
											
												ITK_CALL(AOM_set_value_string(object1,"item_id",OutTblname));
												ITK_CALL(AOM_set_value_string(object1,"object_name",OutTblname));
												ITK_CALL(AOM_save(object1));
												ITK_CALL(AOM_refresh(object1,0));

												ITK_CALL(ITEM_ask_latest_rev(object1,&parent_rev1));
												if(parent_rev1 != NULLTAG)
												{
														printf("\n 1For table inside property set on main object   \n");

													ITK_CALL(AOM_unlock(parent_rev1));

													ITK_CALL(AOM_refresh(parent_rev1,1));

													if( AOM_set_value_string(parent_rev1,"t5_VehNo",Vehicle_No)!=ITK_ok);
													if( AOM_set_value_string(parent_rev1,"t5_EngineNo",Engine_no)!=ITK_ok);
													if( AOM_set_value_string(parent_rev1,"t5_ChassisNo",chessis_NO)!=ITK_ok);
													if(tc_strcmp(Srno,"")!=0)
													{
															t5SrNo=atoi(Srno);
															printf("\n SRNO-------------  [%d]\n",t5SrNo); fflush(stdout);
															printf("\ninside string NULL check for SRNO  [%s]\n",Srno); fflush(stdout);
															
															if( AOM_set_value_int(parent_rev1,"t5_MCTDSno",t5SrNo)!=ITK_ok);
															printf("\nINT value set   [%s]\n",Srno); fflush(stdout);
													}



													
													if( AOM_set_value_string(parent_rev1,"t5_TestV",Test1)!=ITK_ok);
													if( AOM_set_value_string(parent_rev1,"t5_VehCov",VehCov)!=ITK_ok);
													if( AOM_set_value_string(parent_rev1,"t5_RemarkV",Remarks)!=ITK_ok);
													//if( AOM_set_value_string(parent_rev1,"object_desc",Srno)!=ITK_ok);
													//if( AOM_set_value_string(parent_rev1,"object_name",Srno)!=ITK_ok);
													//if( AOM_set_value_string(parent_rev1,"item_revision_id",GrnRevSeq)!=ITK_ok);
												

													printf("\n ** For table Value set to object *** \n"); fflush(stdout);
													printf("\n 888888888888888888888888899999966623232  \n"); fflush(stdout);

													ITK_CALL(AOM_save(parent_rev1));
													ITK_CALL(AOM_refresh(parent_rev1,0));

													printf("\n 4444444444444444444  \n"); fflush(stdout);

													ITK_CALL(GRM_find_relation_type("T5_GR_VI_REL",&relation_type1));
													if(relation_type1 != NULLTAG)
													{
														printf("\n 7777777777777777  \n"); fflush(stdout);
													  ITK_CALL(GRM_create_relation(parent_rev,parent_rev1,relation_type1,NULLTAG,&relation));
													  printf("\n 88888888888888   \n"); fflush(stdout);
													  ITK_CALL(AOM_unlock(relation));
													  printf("\n 9999999999999999999  \n"); fflush(stdout);
													  GRM_save_relation(relation);
													    ITK_CALL(AOM_lock(relation));
													   printf("\nRELATIONSHIP CREATED  \n");fflush(stdout);
													}



												   }

																			

												 }

                                              }
											  else
						                      {
														printf("\n In elde for relation OBJECT CREATION **\n");
														ITK_CALL(ITEM_find_item(OutTblname,&item_tagexisttbl));
														ITK_CALL(ITEM_ask_latest_rev(item_tagexisttbl,&parent_rev1));
														if(parent_rev1 != NULLTAG)
														{
															printf("\nElse  inside item_tags parent_rev1 is not null  \n");

														}

														ITK_CALL(GRM_find_relation_type("T5_GR_VI_REL",&relation_type1));
													   if(relation_type1 != NULLTAG)
													   {
														  printf("\n aaaaaaaaaa \n"); fflush(stdout);
														  ITK_CALL(GRM_create_relation(parent_rev,parent_rev1,relation_type1,NULLTAG,&relation));
														  printf("\n bbbbbbbbbb   \n"); fflush(stdout);
														  ITK_CALL(AOM_unlock(relation));
														  printf("\n cccccccccccccc   \n"); fflush(stdout);
														  GRM_save_relation(relation);
														  ITK_CALL(AOM_lock(relation));
															printf("\n IN ELSE RELATIONSHIP CREATED  \n");fflush(stdout);
													 }
													
											  }

                                  }
		  //table logic end


		}
	}
	fclose(fp2);

	   //table file3 goin to open
    fp3 = fopen(FileName3, "r");
	if(fp3 == NULL)
	{
		printf("\n Unable to Open  CTR Test case  File:  [%s]\n",fp3);fflush(stdout);
		return iFail;
	}
	 else
	{
		printf(" Input_File[CTR Test case] Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer3,MAX_LINE_LENGTH,fp3)!=NULL)
		//while(fgets(Buffer1,20000,fp1)!=NULL)
		{
          

          printf("\n Buffer3 is ---%s \n",Buffer3);
          Srno2 = strtok(Buffer3, "~");
		  printf("\n Srno2   -- %s\n", Srno2);
		  Testdsc = strtok(NULL, "~");
		  printf("\nFor Testdsc  --:%s\n", Testdsc);
		  Testspecification = strtok(NULL, "~");
		  printf("\nFor Testspecification  --:%s\n", Testspecification);
		  Acccriteria = strtok(NULL, "~");
		  printf("\nFor Acccriteria  --:%s\n", Acccriteria);
		  NoOfSamp = strtok(NULL, "~");
		  printf("\nFor NoOfSamp  --:%s\n", NoOfSamp);
		  obs = strtok(NULL, "~");
		  printf("\nFor obs  --:%s\n", obs);
		  ResRem = strtok(NULL, "~");
		  printf("\nFor ResRem  --:%s\n", ResRem);
          
		  //table logic start
		   if(tc_strlen(DocumentNameDup) > 0) 
					{
						
						/*ITK_CALL(STRNG_replace_str(DocumentNameDup,"MCTD","MD",&OutTblname2));
						printf("\n TABLE CREATED with updated name---%s \n",OutTblname2);
						// Add Rev and Seq to OutTblname2
						
                          */
						//printf("\n After STRNG_replace_str tempRev_ID  -%s \n",tempRev_ID);

						tempOutTblname22=(char *)MEM_alloc(100);
						tc_strcpy(tempOutTblname22,"");
						tc_strcpy(tempOutTblname22,DocumentNameDup);
						tc_strcat(tempOutTblname22,"_");
						tc_strcat(tempOutTblname22,"TC");
						tc_strcat(tempOutTblname22,"_");
						tc_strcat(tempOutTblname22,Srno2);
                        tc_strcat(tempOutTblname22,"/");
						tc_strcat(tempOutTblname22,stripBlanks(GrnRevSeq));
						tc_strcat(tempOutTblname22,";");
						tc_strcat(tempOutTblname22,"1");
						tc_strcat(tempOutTblname22,"-");
						tc_strcat(tempOutTblname22,Srno2);

						printf("\n tempOutTblname22 After adding the Rev and Seq---%s \n",tempOutTblname22);

						OutTblname2=(char *)MEM_alloc(100);
						tc_strcpy(OutTblname2,"");
						tc_strcpy(OutTblname2,tempOutTblname22);


						printf("\n OutTblname2 after copy ---%s \n",OutTblname2);

					      ifail = ITEM_find (OutTblname2, &n_items12, &item_tags12);
						  printf("\nTable No. of GreenReport found:%d\n", n_items12);

								if(n_items12 == 0)
							   {

                                    printf("\ninside create \n");
									ifail = TCTYPE_find_type("T5_FIR_TESTCASE", "Document", &item_type_tag12);   
									printf("\ninside create2 \n");
									ifail = TCTYPE_construct_create_input(item_type_tag12, &item_create_input_tag2);
									printf("\ninside create3 \n");	
						
									//ifail = TCTYPE_create_object (item_create_input_tag2, &object2);
									//if(item_create_input_tag2!=NULLTAG)
								 //  {
									ifail=TCTYPE_create_object(item_create_input_tag2,&object2);
								  // }
													printf("\ninside create4 \n");		
											 if(object2 != NULLTAG)
											  {
												printf("\n ~~~~~~~~~~~~~~~~~~~ \n");

												printf("\n TABLE CREATED  object created \n");
												ITK_CALL(AOM_save(object2));
												printf("\n TABLE CREATED   object Saved. \n");
												ITK_CALL(AOM_unlock(object2));

												ITK_CALL(AOM_refresh(object2,1));
												//ITK_CALL(STRNG_replace_str(Tablename,"MCTD","MD",&OutTblname2));
												//printf("\n TABLE CREATED with updated name---%s \n",OutTblname2);
											
												ITK_CALL(AOM_set_value_string(object2,"item_id",OutTblname2));
												ITK_CALL(AOM_set_value_string(object2,"object_name",OutTblname2));
												ITK_CALL(AOM_save(object2));
												ITK_CALL(AOM_refresh(object2,0));

												ITK_CALL(ITEM_ask_latest_rev(object2,&parent_rev2));
												if(parent_rev2 != NULLTAG)
												{
														printf("\n 1For table inside property set on main object   \n");

													ITK_CALL(AOM_unlock(parent_rev2));

													ITK_CALL(AOM_refresh(parent_rev2,1));

													if( AOM_set_value_string(parent_rev2,"t5_TestDesc",Testdsc)!=ITK_ok);
													if( AOM_set_value_string(parent_rev2,"t5_TstSpec",Testspecification)!=ITK_ok);
													if( AOM_set_value_string(parent_rev2,"t5_AccCri",Acccriteria)!=ITK_ok);
													if(tc_strcmp(Srno2,"")!=0)
													{
															t5SrNo2=atoi(Srno2);
															printf("\n SRNO-------------  [%d]\n",t5SrNo2); fflush(stdout);
															printf("\ninside string NULL check for SRNO2  [%s]\n",Srno2); fflush(stdout);
															
															if( AOM_set_value_int(parent_rev2,"t5_SrNosInt",t5SrNo2)!=ITK_ok);
															printf("\nINT value set   [%s]\n",Srno2); fflush(stdout);
													}



													
													if( AOM_set_value_string(parent_rev2,"t5_Sample",NoOfSamp)!=ITK_ok);
													if( AOM_set_value_string(parent_rev2,"t5_Obser",obs)!=ITK_ok);
													//if( AOM_set_value_string(parent_rev2,"t5_RemarkV",ResRem)!=ITK_ok);
													//if( AOM_set_value_string(parent_rev2,"object_desc",Srno2)!=ITK_ok);
													//if( AOM_set_value_string(parent_rev2,"object_name",Srno2)!=ITK_ok);
													//if( AOM_set_value_string(parent_rev2,"item_revision_id",GrnRevSeq)!=ITK_ok);
												

													printf("\n ** For table Value set to object *** \n"); fflush(stdout);
													printf("\n 888888888888888888888888899999966623232  \n"); fflush(stdout);

													ITK_CALL(AOM_save(parent_rev2));
													ITK_CALL(AOM_refresh(parent_rev2,0));

													printf("\n 4444444444444444444  \n"); fflush(stdout);

													ITK_CALL(GRM_find_relation_type("T5_GR_CTR_TP_REL",&relation2_type2));
													if(relation2_type2 != NULLTAG)
													{
														printf("\n 7777777777777777  \n"); fflush(stdout);
													  ITK_CALL(GRM_create_relation(parent_rev,parent_rev2,relation2_type2,NULLTAG,&relation2));
													  printf("\n 88888888888888   \n"); fflush(stdout);
													  ITK_CALL(AOM_unlock(relation2));
													  printf("\n 9999999999999999999  \n"); fflush(stdout);
													  GRM_save_relation(relation2);
													    ITK_CALL(AOM_lock(relation2));
													   printf("\nRELATIONSHIP CREATED  \n");fflush(stdout);
													}



												   }

																			

												 }

                                              }
											  else
						                      {
														printf("\n In elde for relation2 OBJECT CREATION **\n");
														ITK_CALL(ITEM_find_item(OutTblname2,&item_tagexisttb2));
														ITK_CALL(ITEM_ask_latest_rev(item_tagexisttb2,&parent_rev2));
														if(parent_rev2 != NULLTAG)
														{
															printf("\nElse  inside item_tags parent_rev2 is not null  \n");

														}

														ITK_CALL(GRM_find_relation_type("T5_GR_CTR_TP_REL",&relation2_type2));
													   if(relation2_type2 != NULLTAG)
													   {
														  printf("\n aaaaaaaaaa \n"); fflush(stdout);
														  ITK_CALL(GRM_create_relation(parent_rev,parent_rev2,relation2_type2,NULLTAG,&relation2));
														  printf("\n bbbbbbbbbb   \n"); fflush(stdout);
														  ITK_CALL(AOM_unlock(relation2));
														  printf("\n cccccccccccccc   \n"); fflush(stdout);
														  GRM_save_relation(relation2);
														  ITK_CALL(AOM_lock(relation2));
															printf("\n IN ELSE RELATIONSHIP CREATED  \n");fflush(stdout);
													 }
													
											  }

                                  }
		  //table logic end


		}
	}
	fclose(fp3);
	

 }



int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	//tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	//int n_itemobj_found = 0;
	//tag_t* titemobj_results = NULLTAG;
	char *MetaDataFile = NULL;
	char *VehInfoFile = NULL;
	char *CTRTestCaseFile = NULL;
	char *DatasetInfoFile = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *item_revseq_strdup = (char *) malloc(400*sizeof(char));
	char *item_prjcdup = (char *) malloc(400*sizeof(char));
	char *ProjCode = NULL;
	char *ProjCodeDup = NULL;


    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	MetaDataFile = ITK_ask_cli_argument("-File1=");
	VehInfoFile = ITK_ask_cli_argument("-File2=");
	CTRTestCaseFile = ITK_ask_cli_argument("-File3=");
	DatasetInfoFile = ITK_ask_cli_argument("-File4=");
	
	trimwhitespace(MetaDataFile);
	trimwhitespace(VehInfoFile);
	trimwhitespace(CTRTestCaseFile);
	trimwhitespace(DatasetInfoFile);
	
	printf(" [1]: Input MetaData(MetaDataFile): [%s]\n",MetaDataFile);
	printf(" [2]: Input VehInfo(VehInfoFile): [%s]\n",VehInfoFile);
	printf(" [3]: Input CTRTestCase(CTRTestCaseFile): [%s]\n",CTRTestCaseFile);
	printf(" [4]: Input Dataset(DatasetInfoFile): [%s]\n",DatasetInfoFile);
	
	printf("\n Function[1]: File Read Start..!!\n");fflush(stdout);
	read_value_from_file(MetaDataFile,VehInfoFile,CTRTestCaseFile,DatasetInfoFile);

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));
    printf("\n ~~~~~~~~ V E H I C L E - P L A T F O R M   U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PartPlatformUpdate.c
* // ./linkitk -o tm_PartPlatformUpdate tm_PartPlatformUpdate.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Platform_Update/tm_PartPlatformUpdate .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Platform_Update/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Platform_Update/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Platform_Update/SendEmail.sh .
* // ./tm_PartPlatformUpdate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Veh=51780353R -Rev=A -Seq=2
* // ./tm_PartPlatformUpdate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Veh=51780353R -Rev=A -Seq=2
*
***************************************************************************/
