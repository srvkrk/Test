/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Latest Vehicle & Print its Properties on Reports  
*  File Name    :   tm_VehicleDetailsRpt.c
*  Created on   :   Jan 25th, 2024
*  Usage        :   tm_VehicleDetailsRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     25/01/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#include <ics/ics2.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
int ITK_CALL(int ifail)
{
	char* cError = NULL;
    if(ifail!=ITK_ok)
	{
	  EMH_ask_error_text(ifail, &cError);
	  printf("\n Error is : %s", cError);fflush(stdout);
	  exit(0);
	}
	return ifail;
}
/*#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			//return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}	*/									\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSeqSrch)
{
	
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char *Item_revseq = NULL;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision PartType",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision PartType Query Found Successfully..!!");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[n];
				if(LC_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpLCQryobj_results[n],"release_status_list",&sRelStatus);
					printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						tc_strdup("--",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
					printf("\n Item Release Status After Dup & Trim: [%s]", sRelStatusDup);fflush(stdout);
					STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
					printf("\n Item Release Status Final Value: [%s]", sRelStatusDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&sRelStatusDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&sRelStatusDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&sRelStatusDup);
		printf("\nSorry! DesignRevision PartType Query Tag Not Found...");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

char* TC_PlantWise_ReleasedDate(tag_t VehRev_tag, char* InpRelStatus)
{
	int  status_count = 0;
	tag_t* relStatus_list = NULLTAG;
	char* Rev_Rel_Status = NULL;
	char* dt_rlzd = NULL;
	char* dt_rlzdDup = NULL;
	ITK_CALL(WSOM_ask_release_status_list(VehRev_tag, &status_count, &relStatus_list));
	printf("\n No of Release Status Found:   <%d> \n",status_count);fflush(stdout);
	if(status_count>0)
	{
		int k = 0;
		for(k = 0; k<status_count; k++)
		{
		    ITK_CALL(AOM_ask_value_string(relStatus_list[k],"object_name",&Rev_Rel_Status));
			printf("\n Latest_Rev_Rel_Status:  <%s> \n",Rev_Rel_Status);fflush(stdout);
			if(tc_strcmp(Rev_Rel_Status,InpRelStatus) == 0)
			{							
                ITK_CALL(AOM_UIF_ask_value(relStatus_list[k],"date_released",&dt_rlzd));
				printf(" \n Release Status Date Released String: ------> <%s>\n",dt_rlzd);fflush(stdout);
				if(tc_strlen(dt_rlzd)>0)
				{
					tc_strdup(dt_rlzd,&dt_rlzdDup);
				    trimwhitespace(dt_rlzdDup);
					printf("\n Date Released Value --------> %s\n", dt_rlzdDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&dt_rlzdDup);
					printf("\n Date Released Value is NULL For Given Release Status..!!\n");fflush(stdout);
				}
			}
		}
		if(tc_strlen(dt_rlzdDup)>0)
	    {
			printf("\n Date Released Value Avaialble..!!\n");fflush(stdout);
		}
		else
		{
			tc_strdup("--",&dt_rlzdDup);
			printf("\n Date Released Value is NULL For Given Release Status..!!\n");fflush(stdout);
		}
	}
	else
	{
		tc_strdup("--",&dt_rlzdDup);
		printf("\n Date Released Value is NULL For Given Release Status..!!\n");fflush(stdout);
	}
	
	return dt_rlzdDup;
}

char* TC_Classification_Attr_Value(tag_t veh_tag, char* ctrObjAttrid)
{
	printf("\n Inside Function1..!!");fflush(stdout);
	int	status = 0;
	//trimwhitespace(ctrObjAttrid);
	printf("\n Inside Function2..!!");fflush(stdout);
	tag_t VehMstrTag = NULLTAG;
	int cnt	= 0;
	tag_t *ClsObjTag_results = NULLTAG;
	char *AttrKeyValue = NULL;
	char *key_lov_name = NULL;
	int options = 0;
	int n_lov_entries = 0;
	char **  lov_keys;
	char **  lov_values;
	logical * deprecated_staus;
	char *owning_site = NULL;
	int n_shared_sites = 0;
	char ** shared_sites;
	char *Responsestring = (char *) malloc(400*sizeof(char));
	int p = 0;
	char *key_lov_id = (char *) malloc(400*sizeof(char));
	char *ResponsestringDup = NULL;
	
	printf("\n Generating Key_LOV_ID..!!");fflush(stdout);
	tc_strcpy(key_lov_id,"-");
	tc_strcat(key_lov_id,ctrObjAttrid);
	printf("\n Key_LOV_ID: [%s]", ctrObjAttrid);fflush(stdout);
	printf("\n Key_LOV_ID Generated..!!");fflush(stdout);
				
	ITK_CALL(ITEM_ask_item_of_rev(veh_tag,&VehMstrTag));
	ITK_CALL(AOM_ask_value_tags(VehMstrTag,"IMAN_classification",&cnt,&ClsObjTag_results));
	printf("\n Vehicle Master Object Count: [%d]\n", cnt); fflush(stdout);
	ITK_CALL(ICS_ask_attribute_value(*ClsObjTag_results,ctrObjAttrid,&AttrKeyValue));
	printf("\n Attribute Value: [%s] \n",AttrKeyValue); fflush(stdout);
				
	//ITK_CALL(ICS_keylov_get_keylov("-6100",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
	ITK_CALL(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
	printf("\n key_lov_name: [%s] | n_lov_entries: [%d] | options: [%d]",key_lov_name,n_lov_entries,options); fflush(stdout);
	for(p=0; p<n_lov_entries; p++)								
	{
		if(tc_strcmp(AttrKeyValue,lov_keys[p])==0)
		{
			printf("\n Classified Object Value: \n Mascot lov_keys: [%s] | lov_values: [%s]\n",lov_keys[p],lov_values[p]); fflush(stdout);
			tc_strcpy(Responsestring,lov_values[p]);
			printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"); fflush(stdout);
			printf("\n Attribute Value[RESPONSE]: [%s]",Responsestring); fflush(stdout);
            printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n"); fflush(stdout);						
		}									
	}
	if(tc_strlen(Responsestring)>0)
    {
		tc_strdup(Responsestring,&ResponsestringDup);
		trimwhitespace(ResponsestringDup);
	}
	else
	{
		tc_strdup("--",&ResponsestringDup);
		printf("\n Classification Attribute Value is NULL..!!");fflush(stdout);
	}
	
	return ResponsestringDup;
}

char* TC_ESO_Details(tag_t veh_tag)
{
	int	status = 0;
	tag_t RelationFindESO = NULLTAG;
	int sec_counteso = 0;
	tag_t *sec_esoobjects = NULLTAG;
	char *esono_str = NULL;
	char *esono_strDup = NULL;
	
	ITK_CALL(GRM_find_relation_type("T5_PartEsoRel",&RelationFindESO));
	if(RelationFindESO!=NULLTAG)
	{									
		printf("\n Sudo Folder Part Has ESO Status(T5_PartEsoRel) Relation Found..!!\n");fflush(stdout);
		ITK_CALL(GRM_list_secondary_objects_only(veh_tag, RelationFindESO, &sec_counteso, &sec_esoobjects));
		printf("\n Total ESO Objects Found(T5_PartEsoRel): [%d]\n", sec_counteso);
		if(sec_counteso > 0)
		{
			ITK_CALL(AOM_ask_value_string(sec_esoobjects[0],"object_string",&esono_str));
			printf("\n ESO No: [%s]\n",esono_str);fflush(stdout);
			if(tc_strlen(esono_str)>0)
			{
				tc_strdup(esono_str,&esono_strDup);
				trimwhitespace(esono_strDup);
			}
			else
			{
				tc_strdup("--",&esono_strDup);
				printf("\n ESO Number Value is NULL..!!");fflush(stdout);
			}
		}
		else
		{
			tc_strdup("--",&esono_strDup);
			printf("\n ESO Not Attached with Vehicle..!!");fflush(stdout);
		}
    }
	else
	{
		tc_strdup("--",&esono_strDup);
		printf("\n Sudo Folder Part Has ESO Status(T5_PartEsoRel) Tag Not Found..!!");fflush(stdout);
	}
	
	return esono_strDup;
}

char* TC_FDJ_Details(tag_t veh_tag)
{
	int	status = 0;
	tag_t RelationFindFDJ = NULLTAG;
	int sec_countfdj = 0;
	tag_t *sec_fdjobjects = NULLTAG;
	char *fdjno_str = NULL;
	char *fdjno_strDup = NULL;
	
	
	ITK_CALL(GRM_find_relation_type("T5_AssmhasFDJ",&RelationFindFDJ));
	if(RelationFindFDJ!=NULLTAG)
	{									
		printf("\n Sudo Folder VC Has FDJ Status(T5_AssmhasFDJ) Relation Found..!!\n");fflush(stdout);
		ITK_CALL(GRM_list_secondary_objects_only(veh_tag, RelationFindFDJ, &sec_countfdj, &sec_fdjobjects));
		printf("\n Total FDJ Objects Found(T5_PartEsoRel): [%d]\n", sec_countfdj);
		if(sec_countfdj > 0)
		{
			ITK_CALL(AOM_ask_value_string(sec_fdjobjects[0],"object_string",&fdjno_str));
			printf("\n FDJ No: [%s]\n",fdjno_str);fflush(stdout);
			if(tc_strlen(fdjno_str)>0)
			{
				tc_strdup(fdjno_str,&fdjno_strDup);
				trimwhitespace(fdjno_strDup);
			}
			else
			{
				tc_strdup("--",&fdjno_strDup);
				printf("\n FDJ Number Value is NULL..!!");fflush(stdout);
			}
		}
		else
		{
			tc_strdup("--",&fdjno_strDup);
			printf("\n FDJ Not Attached with Vehicle..!!");fflush(stdout);
		}
    }
	else
	{
		tc_strdup("--",&fdjno_strDup);
		printf("\n Sudo Folder VC Has FDJ Status(T5_AssmhasFDJ) Tag Not Found..!!");fflush(stdout);
	}
	
	return fdjno_strDup;
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport)
{
		char* cItem_Id = NULL;
		char* cModAggr = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cLowerVal = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* cItemDes = NULL;
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			cModAggr=subString(cItem_Id,4,3);
			trimwhitespace(cModAggr);
			printf("\n Module Aggregate Value After Trim: [%s]\n", cModAggr);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartStatus", &cArDrStatus));
			if(tc_strlen(cArDrStatus)>0)
			{
				tc_strdup(cArDrStatus,&cArDrStatusDup);
			}
			else
			{
				tc_strdup("NA",&cArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(cArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", cArDrStatusDup);fflush(stdout);
			if(tc_strcmp(cArDrStatusDup,"NA")==0)
			{
				tc_strdup("0",&cLowerVal);
			}
			else if ((tc_strcmp(cArDrStatusDup,"DR0")==0) || (tc_strcmp(cArDrStatusDup,"AR0")==0))
			{
				tc_strdup("1",&cLowerVal);
			}
			else if ((tc_strcmp(cArDrStatusDup,"DR1")==0) || (tc_strcmp(cArDrStatusDup,"AR1")==0))
			{
				tc_strdup("2",&cLowerVal);
			}
			else if ((tc_strcmp(cArDrStatusDup,"DR2")==0) || (tc_strcmp(cArDrStatusDup,"AR2")==0))
			{
				tc_strdup("3",&cLowerVal);
			}
			else if ((tc_strcmp(cArDrStatusDup,"DR3")==0) || (tc_strcmp(cArDrStatusDup,"AR3")==0))
			{
				tc_strdup("4",&cLowerVal);
			}
			else if ((tc_strcmp(cArDrStatusDup,"DR4")==0) || (tc_strcmp(cArDrStatusDup,"AR4")==0))
			{
				tc_strdup("5",&cLowerVal);
			}
			else if ((tc_strcmp(cArDrStatusDup,"DR5")==0) || (tc_strcmp(cArDrStatusDup,"AR5")==0))
			{
				tc_strdup("6",&cLowerVal);
			}
			else
			{
				printf("\n Top Lower Value is Blank..!!");fflush(stdout);
			}
			printf("\n Lower Value: [%s]\n", cLowerVal);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("NA",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Module Aggregate: [%s]", cModAggr);
			printf("\nChild_Level Part AR/DR Status: [%s]", cArDrStatusDup);
			printf("\nChild_Level Lower Value: [%s]", cLowerVal);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if(tc_strcmp(cPartTypeDup,"Module")==0)
				{
				   fprintf(FP_OutputReport,"%s^%s^%s^%s^%s^\n",cItem_Id,cModAggr,cArDrStatusDup,cLowerVal,cPartTypeDup);fflush(FP_OutputReport);
				}
			}
			/*ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			}*/
		}
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRS,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	char* ctopSubLevel = NULL;
	char* ctopSubMAddress = NULL;
	char* ctopSubMAddressDup = NULL;
	char* ctopSubMAdd = NULL;
	char* ctopSubItem_Id = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopModAggr = NULL;
	char* ctopLowerVal = NULL;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	//ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	ITK_CALL(ITEM_ask_latest_rev(top_item,&topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {
			
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			ctopModAggr=subString(ctopSubItem_Id,4,3);
			trimwhitespace(ctopModAggr);
			printf("\n Module Aggregate Value After Trim: [%s]\n", ctopModAggr);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartStatus", &ctopSubArDrStatus));
			if(tc_strlen(ctopSubArDrStatus)>0)
			{
				tc_strdup(ctopSubArDrStatus,&ctopSubArDrStatusDup);
			}
			else
			{
				tc_strdup("NA",&ctopSubArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", ctopSubArDrStatusDup);fflush(stdout);
			if(tc_strcmp(ctopSubArDrStatusDup,"NA")==0)
			{
				tc_strdup("0",&ctopLowerVal);
			}
			else if ((tc_strcmp(ctopSubArDrStatusDup,"DR0")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR0")==0))
			{
				tc_strdup("1",&ctopLowerVal);
			}
			else if ((tc_strcmp(ctopSubArDrStatusDup,"DR1")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR1")==0))
			{
				tc_strdup("2",&ctopLowerVal);
			}
			else if ((tc_strcmp(ctopSubArDrStatusDup,"DR2")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR2")==0))
			{
				tc_strdup("3",&ctopLowerVal);
			}
			else if ((tc_strcmp(ctopSubArDrStatusDup,"DR3")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR3")==0))
			{
				tc_strdup("4",&ctopLowerVal);
			}
			else if ((tc_strcmp(ctopSubArDrStatusDup,"DR4")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR4")==0))
			{
				tc_strdup("5",&ctopLowerVal);
			}
			else if ((tc_strcmp(ctopSubArDrStatusDup,"DR5")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR5")==0))
			{
				tc_strdup("6",&ctopLowerVal);
			}
			else
			{
				printf("\n Top Lower Value is Blank..!!");fflush(stdout);
			}
			printf("\n Lower Value: [%s]\n", ctopLowerVal);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("NA",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Module Aggregate: [%s]", ctopModAggr);
			printf("\nTop_Level Part AR/DR Status: [%s]", ctopSubArDrStatusDup);
			printf("\nTop_Level Lower Value: [%s]", ctopLowerVal);
			printf("\nTop_Level Part Type: [%s] - %d", ctopSubPartTypeDup,tc_strlen(ctopSubPartTypeDup));
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if(tc_strcmp(ctopSubPartTypeDup,"Module")==0)
				{
					printf("ABCD1"); fflush(stdout);
				   fprintf(VehRpt,"%s^%s^%s^%s^%s^\n",ctopSubItem_Id,ctopModAggr,ctopSubArDrStatusDup,ctopLowerVal,ctopSubPartTypeDup);fflush(VehRpt);
				   printf("ABCD2"); fflush(stdout);
				}
			}
       printf("\n Call BOM_line_ask_all_child_lines.....\n");fflush(stdout);
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				//bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	    if (ttop_BOM_Children) MEM_free(ttop_BOM_Children);
	    if (subclosurerule) MEM_free(subclosurerule);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *DRStatus = NULL;
	char *DRStatusDup = NULL;
	char *Platform = NULL;
	char *PlatformDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	int i = 0;
	//char *RptFile = (char *) malloc(400*sizeof(char));
	char *VehFile = (char *) malloc(500*sizeof(char));
	//char *VehRevSeq = (char *) malloc(20*sizeof(char));
	char *RptFile = NULL;
    RptFile =(char *)MEM_alloc(400);
	//char *VehFile = NULL;
    //VehFile =(char *)MEM_alloc(400);
	//char *VehRevSeq = NULL;
    //VehRevSeq =(char *)MEM_alloc(20);
	char *VehRevSeq = NULL;
	VehRevSeq = (char *) malloc(20*sizeof(char));
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *ERCRlzdDt = NULL;
	FILE *fpOutput_file = NULL;
	FILE *VehOutput_file = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *FDJNoDup = NULL;
	char *ESONoDup = NULL;
	//FILE *fpMaster_List = NULL;
	//FILE *fpPart_List = NULL;
	char Buffer1[MAX_LINE_LENGTH];
	char Buffer2[MAX_LINE_LENGTH];
	char *MasterModAgg_Str = NULL;
	char *ModNo_Str = NULL;
	char *ModAgg_Str = NULL;
	char *ModDrAr_Str = NULL;
	char *ModStat_Str = NULL;
	//char *DRARFile = (char *) malloc(500*sizeof(char));
	char *DRARFile = NULL;
    DRARFile =(char *)MEM_alloc(500);
	char *PPPMCodeDup = NULL;
	char *PPPMVarDup = NULL;
	char *cItem_RevSeq = NULL;
	cItem_RevSeq =(char *)MEM_alloc(20);
	char* cItem_LCDetails = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Vehicle_Details_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	printf("Test");fflush(stdout);
	char* APLP_Status = NULL;
	char* APLJ_Status = NULL;
	char* APLL_Status = NULL;
	char* APLD_Status = NULL;
	char* APLU_Status = NULL;
	char* APLS_Status = NULL;
	char* APLC_Status = NULL;
	char* APLA_Status = NULL;
	char* APLV_Status = NULL;
	char* MBOM_Status = NULL;
	char* APLPStat = "T5_LcsAplpRlzd";
	char* APLJStat = "T5_LcsApljRlzd";
	char* APLLStat = "T5_LcsApllRlzd";
	char* APLDStat = "T5_LcsApldRlzd";
	char* APLUStat = "T5_LcsApluRlzd";
	char* APLSStat = "T5_LcsAplsRlzd";
	char* APLCStat = "T5_LcsAplRlzd";
	char* APLAStat = "T5_LcsAplaRlzd";
	char* APLVStat = "T5_LcsAplvRlzd";
	char* MBOMStat = "T5_MBOMReleased";
	printf("Test");fflush(stdout);
	/* trimwhitespace(APLPStat);
	trimwhitespace(APLJStat);
	trimwhitespace(APLLStat);
	trimwhitespace(APLDStat);
	trimwhitespace(APLUStat);
	trimwhitespace(APLSStat);
	trimwhitespace(APLCStat);
	trimwhitespace(APLAStat);
	trimwhitespace(APLVStat);
	trimwhitespace(MBOMStat); */
	printf("Test");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ V E H I C L E   D E T A I L S   R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
    fprintf(fpOutput_file,"VEH_NO, VEH_REV, VEH_SEQ, VEH_DES, VEH_DR/AR, VEH_CLASS, FDJ, ESO, PPPM_PROJ_CODE, PPPM_VAR_CODE, Release_Status, APLP Released, APLJ Released, APLL Released, APLD Released, APLU Released, APLS Released, APLC Released, APLA Released, APLV Released, MBOM Released, A1A, A1B, A1C, A9Z, D1A, D1B, D1C, D1D, D2A, D2B, D2C, D2D, D3A, D4A, D9W, D9X, D9Y, D9Z, F1A, F1B, F1C, F1D, F1E, F2A, F2B, F2C, F2D, F3A, F3B, F3C, F4A, F4B, F4C, F5A, F5B, F9Y, F9Z, G1A, G1B, G1C, G2A, G3A, G3B, G4A, G4B, G4C, H1A, H2A, H2B, H2C, H2D, H2E, H2F, H3A, H3B, H9W, H9X, H9Y, H9Z, K1A, K2A\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	printf("\n Finding Query[Latest Released Design Revision for ERC]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n Latest Released Design Revision for ERC Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Item ID","Part Type"};
		char *cValues[2]  = {"*","V"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Vehicle Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
			//for (i = 0; i < n_itemobj_found; i++)
			for (i = 0; i < 11; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
			    if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
					trimwhitespace(item_id_strDup);
				}
				else
			    {
					tc_strdup("--",&item_id_strDup);
					printf("\n Vehicle Number Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
			    if(tc_strlen(item_revseq_str)>0)
				{
					tc_strdup(item_revseq_str,&item_revseq_strDup);
					trimwhitespace(item_revseq_strDup);
					item_rev_str=strtok(item_revseq_strDup,";");
			        item_seq_str=strtok(NULL,";");
					if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			        if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
					trimwhitespace(item_rev_strDup);
					trimwhitespace(item_seq_strDup);
				}
				else
			    {
					tc_strdup("--",&item_revseq_strDup);
					printf("\n Vehicle Revision Sequence Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"object_desc",&cItem_Desc));
				printf("\n Vehicle Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
				if(tc_strlen(cItem_Desc)>0)
				{
					tc_strdup(cItem_Desc,&cItem_DescDup);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\n Vehicle Description Value is NULL..!!");fflush(stdout);
				}
				trimwhitespace(cItem_DescDup);
				printf("\n Vehicle Description Value After Dup & Trim: --------> <%s>", cItem_DescDup);fflush(stdout);
			    STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
			    STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
			    STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
				printf("\n Vehicle Description Final Value: --------> [%s]\n", cItem_DescDup);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartStatus",&DRStatus));
			    if(tc_strlen(DRStatus)>0)
				{
					tc_strdup(DRStatus,&DRStatusDup);
				}
				else
			    {
					tc_strdup("--",&DRStatusDup);
					printf("\n DR Status Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Platform",&Platform));
				if(tc_strlen(Platform)>0)
				{
					tc_strdup(Platform,&PlatformDup);
				}
				else
				{
					tc_strdup("--",&PlatformDup);
					printf("\n Platform Value is NULL..!!");fflush(stdout);
				}
				printf("\n Function1: FDJ Details Find Start");fflush(stdout);
				FDJNoDup = TC_FDJ_Details(DesRev_tag);
			    printf("\n Function1: FDJ Details Find End\n");fflush(stdout);
				printf("\n Function2: ESO Details Find Start");fflush(stdout);
				ESONoDup = TC_ESO_Details(DesRev_tag);
			    printf("\n Function2: ESO Details Find End\n");fflush(stdout);
				
				char *PPPMProjObjAttrid = "6702";
				char *PPPMVarObjAttrid = "6703";
				printf("\n Function3: PPPM Project_Code Details Find Start..!!\n");fflush(stdout);
				//PPPMCodeDup = TC_Classification_Attr_Value(DesRev_tag,PPPMProjObjAttrid);
			    printf("\n Function3: PPPM Project_Code Details Find End..!!\n");fflush(stdout);
				printf("\n Function4: PPPM Variant_Code Details Find Start..!!\n");fflush(stdout);
				//PPPMVarDup = TC_Classification_Attr_Value(DesRev_tag,PPPMVarObjAttrid);
			    printf("\n Function4: PPPM Variant_Code Details Find End..!!\n");fflush(stdout);
				
				printf("\n Function5: Release Status Details Find Start..!!\n");fflush(stdout);
				tc_strcpy(cItem_RevSeq,item_rev_strDup);
	            tc_strcat(cItem_RevSeq,"*");
	            tc_strcat(cItem_RevSeq,item_seq_strDup);
	            printf("Item RevSeq: [%s] \n", cItem_RevSeq);fflush(stdout);
				cItem_LCDetails = TC_PartLCDetails(item_id_strDup,cItem_RevSeq);
			    printf("\n Part Release Status Value After Dup & Trim: [%s]", cItem_LCDetails);fflush(stdout);
				printf("\n Function5: Release Status Details Find End..!!\n");fflush(stdout);
				
				printf("\n Function6: Various Plants Release Date Find Start..!!\n");fflush(stdout);
				APLP_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLPStat);
				APLJ_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLJStat);
				APLL_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLLStat);
				APLD_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLDStat);
				APLU_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLUStat);
				APLS_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLSStat);
				APLC_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLCStat);
				APLA_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLAStat);
				APLV_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLVStat);
				MBOM_Status = TC_PlantWise_ReleasedDate(DesRev_tag, MBOMStat);
				printf("\n Function6: Various Plants Release Date Find End..!!\n");fflush(stdout);
				
				printf(" Vehicle Details Start...!!\n");fflush(stdout);
				printf("[1] Vehicle_No: [%s]\n",item_id_strDup);fflush(stdout);
				printf("[2] Revision: [%s]\n",item_rev_strDup);fflush(stdout);
				printf("[3] Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
				printf("[4] Description: [%s]\n",cItem_DescDup);fflush(stdout);
				printf("[5] DR/AR Status: [%s]\n",DRStatusDup);fflush(stdout);
				printf("[6] PlatForm: [%s]\n",PlatformDup);fflush(stdout);
				printf("[7] FDJ[VC Has FDJ Status]: [%s]\n",FDJNoDup);fflush(stdout);
				printf("[8] ESO[Part Has ESO Status]: [%s]\n",ESONoDup);fflush(stdout);
				printf("[9] PPPM Project Code: [%s]\n",PPPMCodeDup);fflush(stdout);
				printf("[10] PPPM Variant Code: [%s]\n",PPPMVarDup);fflush(stdout);
				printf("[11] Release Status Details: [%s]\n",cItem_LCDetails);fflush(stdout);
				printf("[12] APLP Release Date: [%s]\n",APLP_Status);fflush(stdout);
				printf("[13] APLJ Release Date: [%s]\n",APLJ_Status);fflush(stdout);
				printf("[14] APLL Release Date: [%s]\n",APLL_Status);fflush(stdout);
				printf("[15] APLD Release Date: [%s]\n",APLD_Status);fflush(stdout);
				printf("[16] APLU Release Date: [%s]\n",APLU_Status);fflush(stdout);
				printf("[17] APLS Release Date: [%s]\n",APLS_Status);fflush(stdout);
				printf("[18] APLC Release Date: [%s]\n",APLC_Status);fflush(stdout);
				printf("[19] APLA Release Date: [%s]\n",APLA_Status);fflush(stdout);
				printf("[20] APLV Release Date: [%s]\n",APLV_Status);fflush(stdout);
				printf("[21] MBOM Release Date: [%s]\n",MBOM_Status);fflush(stdout);
				printf(" Vehicle Details End...!!\n");fflush(stdout);
				
				printf("\n Vehicle Child[99 Level] Generation Start..!!");fflush(stdout);
				printf("\n Generating Vehicle Child[99 Level] File Name..!!");fflush(stdout);
				
				//tc_strcpy(VehFile,"/tmp/");
				tc_strcpy(VehFile,item_id_strDup);
				tc_strcat(VehFile,"_");
				tc_strcat(VehFile,item_rev_strDup);
				tc_strcat(VehFile,"_");
				tc_strcat(VehFile,item_seq_strDup);
				tc_strcat(VehFile,"_");
				tc_strcat(VehFile,GenDate);
				tc_strcat(VehFile,".txt");
				printf("\n Vehicle Child[99 Level] Report File Name: [%s]", VehFile);fflush(stdout);
				printf("\n Vehicle Child[99 Level] Report File Generated..!!");fflush(stdout);
				
				VehOutput_file = fopen(VehFile, "w");
				if(VehOutput_file == NULL)
				{
					printf("\n Unable to Create Vehicle Child[99 Level] Report File: --------> [%s]",VehFile);fflush(stdout);
					return 0;
				}
				tc_strcpy(VehRevSeq,item_rev_strDup);
				tc_strcat(VehRevSeq,";");
				tc_strcat(VehRevSeq,item_seq_strDup);
				trimwhitespace(VehRevSeq);
				printf("\n Vehicle No: [%s]", item_id_strDup);fflush(stdout);
				printf("\n Vehicle Rev&Seq: [%s]", VehRevSeq);fflush(stdout);
				
				printf("\n Function3: Vehicle Child Details Find Start");fflush(stdout);
				TC_VehChild_Details(item_id_strDup,VehRevSeq,VehOutput_file);
			    printf("\n Function3: Vehicle Child Details Find End\n");fflush(stdout);
				printf("\n Vehicle Child[99 Level] Generation End..!!\n");fflush(stdout);
				fclose(VehOutput_file);
				printf("\n Vehicle Child[99 Level] Report File Closed..!!\n");fflush(stdout);
				
				
				FILE *fpMaster_List = fopen("MasterList.txt", "r");
				tc_strcpy(DRARFile,"");
                if(fpMaster_List != NULL)
				{
					printf(" Master_File Not Null..!!\n");fflush(stdout);
					while(fgets(Buffer1,MAX_LINE_LENGTH,fpMaster_List)!=NULL)
                    {
						int FinalModStat_Str = 6;
						char *LowestDrArDup = NULL;
                        MasterModAgg_Str=strtok(Buffer1,"^");
                        if(MasterModAgg_Str!=NULL)trimwhitespace(MasterModAgg_Str);
                        printf(" Master Mod Aggregate(MasterModAgg_Str): [%s]\n",MasterModAgg_Str);fflush(stdout);
                        FILE *fpPart_List = fopen(VehFile, "r");						
						if(fpPart_List != NULL)
						{
							printf(" Input_File Not Null..!!\n");fflush(stdout);
							while(fgets(Buffer2,MAX_LINE_LENGTH,fpPart_List)!=NULL)
							{
								ModNo_Str=strtok(Buffer2,"^");
								ModAgg_Str=strtok(NULL,"^");
								ModDrAr_Str=strtok(NULL,"^");
								ModStat_Str=strtok(NULL,"^");
								if(ModAgg_Str!=NULL)trimwhitespace(ModAgg_Str);
								if(ModDrAr_Str!=NULL)trimwhitespace(ModDrAr_Str);
								if(ModStat_Str!=NULL)trimwhitespace(ModStat_Str);
								printf(" Input_File Module Aggregate(ModAgg_Str): [%s]\n",ModAgg_Str);fflush(stdout);
								printf(" Input_File Module AR/DR(ModDrAr_Str): [%s]\n",ModDrAr_Str);fflush(stdout);
								printf(" Input_File Module Status(ModStat_Str): [%s]\n",ModStat_Str);fflush(stdout);
								int ModStat = atoi(ModStat_Str);
								printf(" Module Status(ModStat) in Integer: [%d]\n",ModStat);fflush(stdout);
								if(tc_strcmp(MasterModAgg_Str,ModAgg_Str)==0)
								{
									if(ModStat<=FinalModStat_Str)
									{
										tc_strdup(ModDrAr_Str,&LowestDrArDup);
										FinalModStat_Str = ModStat;
										printf("\n Module Aggregate Matched..!!\n");fflush(stdout);
									}
								}
								else
								{
									printf("\n Module Aggregate Not Matched..!!\n");fflush(stdout);
								}
							}
						}
						else 
						{
							printf("\n Input_File is NULL..!!\n");fflush(stdout);
						}
						fclose(fpPart_List);
						if(tc_strlen(LowestDrArDup)>0)
						{
						  tc_strcat(DRARFile,LowestDrArDup);
						}
						else
						{
						  tc_strcat(DRARFile,"No_Module_Found");
						}
				        tc_strcat(DRARFile,",");
					}
				}
				else 
				{
					printf("\n Master_File is NULL..!!\n");fflush(stdout);
				}
				fclose(fpMaster_List);
				printf("\n AR/DR File: [%s]\n",DRARFile);fflush(stdout);
				
				
				if(remove(VehFile) == 0) 
				{
					printf("\n Vehicle Child[99 Level] File Deleted Successfully..!!\n");fflush(stdout);
				} 
				else 
				{
					printf("\n Vehicle Child[99 Level] File Delete Failed..!!\n");fflush(stdout);
				}
				
				fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,cItem_DescDup,DRStatusDup,PlatformDup,FDJNoDup,ESONoDup,PPPMCodeDup,PPPMVarDup,cItem_LCDetails,APLP_Status,APLJ_Status,APLL_Status,APLD_Status,APLU_Status,APLS_Status,APLC_Status,APLA_Status,APLV_Status,MBOM_Status,DRARFile);fflush(fpOutput_file);
				//exit(0);
			}
		}
		else
        {
			printf(" Vehicle Found Zero[0] on Latest Released Design Revision for ERC..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	if(titemobj_results)
	{
		MEM_free(titemobj_results);
	}
	
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
	fclose(fpOutput_file);           
	printf("\n All Vehicle Details Written Successfully on the Output File....\n");fflush(stdout);

    printf("\n Report File Attach To Users Home Folder Start..!!\n");fflush(stdout);
	char *Filename = NULL;
	char *FileLoc = NULL;
	char *dataSetName = NULL;
	IMF_file_t	fileDescriptor;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	tag_t tUser = NULLTAG;
	tag_t tHomeFolder = NULLTAG;
	
    dataSetName = (char *) MEM_alloc( 70 * sizeof(char) );
	tc_strcpy(dataSetName,"VEHICLE-DR-MATRIX-RPT-");
	tc_strcat(dataSetName,GenDate);
	printf(" Dataset Name: [%s]\n", dataSetName);fflush(stdout);
	
	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(Filename,RptFile);
	printf(" File Name: [%s]\n", Filename);fflush(stdout);

	tc_strcpy(FileLoc,"/user/cvprod/sourav/Vehicle_Details_Report/");
	tc_strcat(FileLoc,Filename);
	printf(" File Location: [%s]\n", FileLoc);fflush(stdout);

	ITK_CALL(AE_find_datasettype2("MSExcel",&datasettype));
	ITK_CALL(AE_find_tool2("MSExcel", &tool));
	ITK_CALL(AE_create_dataset_with_id(datasettype,dataSetName,"",NULL,NULL,&Newdataset));
	ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
	ITK_CALL(AE_set_dataset_format2(Newdataset,"BINARY_REF"));
	ITK_CALL(AOM_save(Newdataset));
    //ITK_CALL(AE_save_myself(Newdataset));	
	ITK_CALL(IMF_fmsfile_import(FileLoc,Filename,SS_BINARY,&filetag,&fileDescriptor));
	if(filetag == NULLTAG)
	{
		printf(" File Tag Not Found..!!\n");fflush(stdout);
	}
	ITK_CALL(AOM_refresh(Newdataset,TRUE));
	ITK_CALL(AE_add_dataset_named_ref2(Newdataset, "excel", AE_PART_OF, filetag));
	ITK_CALL(AOM_save(Newdataset));
	//ITK_CALL(AE_save_myself(Newdataset));
	ITK_CALL(AOM_refresh(Newdataset,FALSE));
	
	ITK_CALL(SA_find_user2("souravk.ttl",&tUser));
	ITK_CALL(SA_ask_user_home_folder(tUser,&tHomeFolder));
	ITK_CALL(AOM_lock(tHomeFolder));
	ITK_CALL(FL_insert(tHomeFolder,Newdataset,999));
    ITK_CALL(AOM_save(tHomeFolder));
	ITK_CALL(AOM_unlock(tHomeFolder));
	//ITK_CALL(AOM_refresh(tHomeFolder,1));
	printf("\n Report File Attach To Users Home Folder End..!!\n");fflush(stdout);
		
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_VehicleDetailsRpt.c
* // ./linkitk -o tm_VehicleDetailsRpt tm_VehicleDetailsRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehicleDetailsRpt/tm_VehicleDetailsRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehicleDetailsRpt/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehicleDetailsRpt/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehicleDetailsRpt/SendEmail.sh .
* // ./tm_VehicleDetailsRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_VehicleDetailsRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/