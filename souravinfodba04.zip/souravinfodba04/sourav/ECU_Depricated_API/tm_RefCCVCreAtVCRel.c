#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <tc/tc_startup.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <tccore/item_msg.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <fnd0booleansolve/booleansolve.h>
#define ITK_err 919002
#define GMD_err (EMH_USER_error_base +26)
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define PLM_error (EMH_USER_error_base+25)
#define PLM_error1 (EMH_USER_error_base+26)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PLM_error2 (EMH_USER_error_base+26)
#define PLM_error3 (EMH_USER_error_base+26)
#define PLM_error4 (EMH_USER_error_base+26)
#define PLM_error5 (EMH_USER_error_base+26)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
			  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "Error(PrintErrorStack): \n");
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}
	return ITK_ok;
}
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -p=<project name> (required)\n"
        );	
}
int tm_RefCCVCreAtVCRel(char*);
void FindLatestVCID(tag_t*,int , tag_t*);

int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Dmlid					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Dmlid 			= ITK_ask_cli_argument("-i=");

	int			ifail 				= ITK_ok;
		
/*	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);*/
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Dmlid)) == 0)
	{
		print_requirement();
		return -1;
	}
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));

	ifail = ITK_auto_login();

	ITK_CALL(ITK_set_journalling( TRUE ));

	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	ifail = tm_RefCCVCreAtVCRel(Dmlid);
	
		
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}






int tm_RefCCVCreAtVCRel( char* sDmlTaskNo)
{//22CU052987
int nAttachment = 0;
	char *username = NULL;
	char *sCurrentTask = NULL;
	char *sParentName = NULL;
//	char *sDmlTaskNo = NULL;
	tag_t rootTask = NULLTAG;
	tag_t tDMLTask = NULLTAG;
	tag_t *tpAttachments = NULLTAG;

	int n_Input_VCID = 2;
	int nModCnt = 0;
	int nVCIDCnt = 0;
	int nVcCnt = 0;
	int iVCCnt = 0;
	int ifail;
	logical lIsVCFound = false;
	char	*qry_Input_VCID[2] = {"Item ID", "Type"};
	char	*values[3];
	char	*values1[2];
	char	*sModNum = NULL;
	char	*VCIDNum1 = NULL;
	char	*VCIDNum2 = NULL;
	char	*VCIDNumAst = NULL;
	char	*sVcidNo = NULL;
	char	*sVcidRvSq = NULL;
	char	*sVCNum = NULL;
	tag_t	ProQryVCObj = NULLTAG;
	tag_t	ProQryCCIDObj = NULLTAG;
	tag_t	*tpVCObj = NULLTAG;
	tag_t	*tpMod = NULLTAG;
	tag_t	*tpVCIDObj = NULLTAG;
	tag_t	*tpVCs = NULLTAG;
	tag_t	VC_Obj = NULLTAG;
	tag_t	tECUMod = NULLTAG;
	tag_t	Mod_Obj = NULLTAG;
	tag_t	VCID_Obj = NULLTAG;
	tag_t	LtstVCIDObj = NULLTAG;
	tag_t	RefCCVTag = NULLTAG;
	tag_t	tRelatn = NULLTAG;
	int tDmltoTsk_cnt = 0;
	int iTCnt = 0;
	int nPrtCnt = 0;
	int iHrnBl = 0;
	int iPCnt = 0;
	char *sTskid = NULL;
	char *sTaskobj_type = NULL;
	char *sVCVehNum = NULL;
	char *sVCVehPrtTyp = NULL;
	char *finalInfoHornbillWay = NULL;
	char *sVCIDenvName = NULL;
	char *sSysStr = NULL;
	char *info1HornbillWay			 = NULL;
	char *info2HornbillWay			 = NULL;
	char *info3HornbillWay			 = NULL;
	char *info4HornbillWay			 = NULL;
	char *info5HornbillWay			 = NULL;
	char *info6HornbillWay			 = NULL;
	char *info7HornbillWay			 = NULL;
	char *info8HornbillWay			 = NULL;
	char *info9HornbillWay			 = NULL;
	char *info10HornbillWay			 = NULL;
	tag_t	tDml = NULLTAG;
	tag_t	tDmlRev = NULLTAG;
	tag_t	tDmltoTsk = NULLTAG;
	tag_t	*tpDmltoTsk_obj = NULLTAG;
	tag_t	*tpParts = NULLTAG;
	tag_t HornbillWayQuery			 = NULLTAG;
	int	   noOfInputHornbillWay			 = 2;
	char *qryInputForHornbillWay[2]       = {"SYSCD", "SUBSYSCD"};
	char *qryProjValForHornbillWay[2]     = {"Hornbill_Way_VC", "Hornbill_Way"};
	int   HornbillWayCount				 = 0;
	tag_t *HornbillWayCnObj				 = NULL;
	finalInfoHornbillWay = (char *) MEM_alloc(5000 * sizeof(char *));
    tag_t VC_Objmstr =NULLTAG;//new
	
	char* finalVcidString       = NULL;
    finalVcidString= (char *) MEM_alloc(10000 * sizeof(char *));
	tc_strcpy(finalVcidString,"");

	char	*qry_IpVeh[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_ValsVeh[2] = {"Bypass","REFCCVREL"};
	int		n_IpVeh		 = 2;
	int     QCountVeh		 = 0;
	tag_t QryContObjVeh = NULLTAG;
	tag_t	*CnObjCntVeh	 = NULLTAG;
	if(QRY_find2("ControlObjQry", &QryContObjVeh));
	if(QryContObjVeh)
	{
	
	  if(QRY_execute(QryContObjVeh, n_IpVeh, qry_IpVeh, qry_ValsVeh, &QCountVeh, &CnObjCntVeh));

	  printf("\n Control Object found for tm_RefCCVCreAtVCRel == %d\n", QCountVeh);fflush(stdout);
	  if(QCountVeh >0)
	  {
			


		  
		
	//********

/*	ITK_CALL(POM_get_user_id (&username));
	printf("\nkk.Session login User : %s\n",username); fflush(stdout);

	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
	{
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&sCurrentTask));
		printf("\nkk.sCurrentTask: %s",sCurrentTask);fflush(stdout);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&sParentName));
		printf("\nkk.Parent Name: %s",sParentName);fflush(stdout);

		CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&nAttachment,&tpAttachments));
		printf("\nkk.Target Attachment:%d",nAttachment);fflush(stdout);

		if(nAttachment>0)
		{
			tDMLTask = tpAttachments[0];
			if(AOM_ask_value_string(tDMLTask,"item_id",&sDmlTaskNo)!=ITK_ok)PrintErrorStack();
			printf("\nkk.sDmlTaskNo: [%s]",sDmlTaskNo);fflush(stdout);*/

			if(ITEM_find_item(sDmlTaskNo,&tDml)!=ITK_ok)PrintErrorStack();
			if (tDml != NULLTAG)
			{
				if(ITEM_ask_latest_rev(tDml,&tDmlRev)!=ITK_ok)PrintErrorStack();
				ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&tDmltoTsk));
				ITK_CALL(GRM_list_secondary_objects_only(tDmlRev,tDmltoTsk,&tDmltoTsk_cnt,&tpDmltoTsk_obj));
				printf("\nkk.tDmltoTsk_cnt count is [%d]",tDmltoTsk_cnt);fflush(stdout);
				if(tDmltoTsk_cnt>0)
				{
					for(iTCnt=0; iTCnt<tDmltoTsk_cnt; ++iTCnt)
					{
						ITK_CALL(AOM_ask_value_string(tpDmltoTsk_obj[iTCnt],"object_type",&sTaskobj_type));
						ITK_CALL(AOM_UIF_ask_value(tpDmltoTsk_obj[iTCnt],"item_id",&sTskid));
						printf("\nkk.[Task obj Type,item id][%s,%s]\n",sTaskobj_type,sTskid);fflush(stdout);
					
						if((tc_strcmp(sTaskobj_type,"T5_ChangeTaskRevision")==0) && (tc_strstr(sTskid,"_00")!=NULL))
						{
							if(AOM_ask_value_tags(tpDmltoTsk_obj[iTCnt],"CMHasSolutionItem",&nPrtCnt,&tpParts)!=ITK_ok)PrintErrorStack();
							printf("\nkk.Number of parts are [%d]",nPrtCnt);fflush(stdout);
							if(nPrtCnt>0)
							{
								tc_strcpy(finalInfoHornbillWay," ");
								if(QRY_find2("ControlObjQry",&HornbillWayQuery));
								if(HornbillWayQuery)
								{
									 if(QRY_execute(HornbillWayQuery, noOfInputHornbillWay, qryInputForHornbillWay, qryProjValForHornbillWay,&HornbillWayCount,&HornbillWayCnObj));
									 printf("\nkk.Ctrl for HornbillWay CntrlObj = %d\n", HornbillWayCount);fflush(stdout);
								}
								else
								{
									printf("\nkk.ContrlObj for HornbillWay not found.");fflush(stdout);
								}
								if(HornbillWayCount >0)
								{
									for(iHrnBl=0; iHrnBl<HornbillWayCount ; ++iHrnBl)
									{
										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo1",&info1HornbillWay)!=ITK_ok);
										printf("\n info1HornbillWay Project Codes List [%s]",info1HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo2",&info2HornbillWay)!=ITK_ok);
										printf("\n info2HornbillWay Project Codes List [%s]",info2HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo3",&info3HornbillWay)!=ITK_ok);
										printf("\n info3HornbillWay Project Codes List [%s]",info3HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo4",&info4HornbillWay)!=ITK_ok);
										printf("\n info4HornbillWay Project Codes List [%s]",info4HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo5",&info5HornbillWay)!=ITK_ok);
										printf("\n info5HornbillWay Project Codes List [%s]",info5HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo6",&info6HornbillWay)!=ITK_ok);
										printf("\n info6HornbillWay Project Codes List [%s]",info6HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo7",&info7HornbillWay)!=ITK_ok);
										printf("\n info7HornbillWay Project Codes List [%s]",info7HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo8",&info8HornbillWay)!=ITK_ok);
										printf("\n info8HornbillWay Project Codes List [%s]",info8HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_Userinfo9",&info9HornbillWay)!=ITK_ok);
										printf("\n info9HornbillWay Project Codes List [%s]",info9HornbillWay); fflush(stdout);

										if (AOM_ask_value_string(HornbillWayCnObj[iHrnBl],"t5_userinfo10",&info10HornbillWay)!=ITK_ok);
										printf("\n info10HornbillWay Project Codes List [%s]",info10HornbillWay); fflush(stdout);

										if(info1HornbillWay == NULL)
										{
											tc_strcat(info1HornbillWay,"");
										}
										if(info2HornbillWay == NULL)
										{
											tc_strcat(info2HornbillWay,"");
										}
										if(info3HornbillWay == NULL)
										{
											tc_strcat(info3HornbillWay,"");
										}
										if(info4HornbillWay == NULL)
										{
											tc_strcat(info4HornbillWay,"");
										}
										if(info5HornbillWay == NULL)
										{
											tc_strcat(info5HornbillWay,"");
										}
										if(info6HornbillWay == NULL)
										{
											tc_strcat(info6HornbillWay,"");
										}
										if(info7HornbillWay == NULL)
										{
											tc_strcat(info7HornbillWay,"");
										}
										if(info8HornbillWay == NULL)
										{
											tc_strcat(info8HornbillWay,"");
										}
										if(info9HornbillWay == NULL)
										{
											tc_strcat(info9HornbillWay,"");
										}
										if(info10HornbillWay == NULL)
										{
											tc_strcat(info10HornbillWay,"");
										}

										tc_strcpy(finalInfoHornbillWay,info1HornbillWay);
										tc_strcat(finalInfoHornbillWay,info2HornbillWay);
										tc_strcat(finalInfoHornbillWay,info3HornbillWay);
										tc_strcat(finalInfoHornbillWay,info4HornbillWay);
										tc_strcat(finalInfoHornbillWay,info5HornbillWay);
										tc_strcat(finalInfoHornbillWay,info6HornbillWay);
										tc_strcat(finalInfoHornbillWay,info7HornbillWay);
										tc_strcat(finalInfoHornbillWay,info8HornbillWay);
										tc_strcat(finalInfoHornbillWay,info9HornbillWay);
										tc_strcat(finalInfoHornbillWay,info10HornbillWay);
									}
								}
								printf("\nkk.final InfoHornbillWay string value [%s]\n",finalInfoHornbillWay);
								for(iPCnt=0; iPCnt<nPrtCnt; ++iPCnt)
								{
									lIsVCFound = false;
									VC_Obj = tpParts[iPCnt];

									ITK_CALL(AOM_UIF_ask_value(VC_Obj,"item_id",&sVCVehNum));
									ITK_CALL(AOM_UIF_ask_value(VC_Obj,"t5_PartType",&sVCVehPrtTyp));
									printf("\nkk.[Part number,Part Type] is [%s,%s]",sVCVehNum,sVCVehPrtTyp);fflush(stdout);

									if(tc_strcmp(sVCVehPrtTyp,"CCVC")==0 && tc_strstr(finalInfoHornbillWay,sVCVehNum)==NULL)
									{
										printf("\nkk.non-Hornbill way CCVC found, continue...\n");fflush(stdout);
										continue;
									}

									ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&tECUMod));
									printf("\nkk.Tag Found.\n");fflush(stdout);

									ITK_CALL(GRM_list_secondary_objects_only(VC_Obj,tECUMod,&nModCnt,&tpMod));
									printf("\nkk.Module count is [%d]\n",nModCnt); fflush(stdout);

									if(nModCnt>0)
									{
										Mod_Obj = tpMod[0];

										if (AOM_ask_value_string(Mod_Obj,"item_id",&sModNum)!=ITK_ok);
										printf("\nkk.Module number is [%s]",sModNum); fflush(stdout);

										VCIDNum1=subString(sModNum,0,9);
										VCIDNum2=subString(sModNum,11,3);
										printf("\nkk.sub str is [%s,%s]",VCIDNum1,VCIDNum2); fflush(stdout);

										VCIDNumAst=(char *) MEM_alloc(30);
										tc_strcpy(VCIDNumAst,VCIDNum1);
										tc_strcat(VCIDNumAst,VCIDNum2);
										tc_strcat(VCIDNumAst,"_*");
										printf("\nkk.VCID to search [%s]",VCIDNumAst); fflush(stdout);

										values1[0] = VCIDNumAst;
										values1[1] = "VCID";

										if(QRY_find2("Item...",&ProQryCCIDObj));
										if(ProQryCCIDObj)
										{
											if(QRY_execute(ProQryCCIDObj, n_Input_VCID, qry_Input_VCID, values1,&nVCIDCnt,&tpVCIDObj));
											printf("\nkk.VCID count is %d.", nVCIDCnt);fflush(stdout);

											if(nVCIDCnt>0)
											{
												FindLatestVCID(tpVCIDObj,nVCIDCnt,&VCID_Obj);
												if(VCID_Obj)
												{
													ITK_CALL(ITEM_ask_latest_rev(VCID_Obj,&LtstVCIDObj));
													if(LtstVCIDObj)
													{
														if(AOM_ask_value_string(LtstVCIDObj,"item_id",&sVcidNo)!=ITK_ok);
														if(AOM_ask_value_string(LtstVCIDObj,"item_revision_id",&sVcidRvSq)!=ITK_ok);
														printf("\nkk.Latest VCID is [%s,%s]",sVcidNo,sVcidRvSq);fflush(stdout);

														ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&RefCCVTag));
														ITK_CALL(GRM_list_secondary_objects_only(LtstVCIDObj,RefCCVTag,&nVcCnt,&tpVCs));
														printf("\nkk.VC count is [%d]  \n",nVcCnt); fflush(stdout);
														if(nVcCnt>0)
														{
															for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
															{
																if(AOM_ask_value_string(tpVCs[iVCCnt],"item_id",&sVCNum)!=ITK_ok);
																printf("\nkk.checking VC [%s]",sVCNum); fflush(stdout);
																if(tc_strcmp(sVCVehNum,sVCNum)==0)
																{
																	printf("\nkk.References CCV relation exists for VC %s\n",sVCVehNum); fflush(stdout);
																	lIsVCFound = true;
																	break;
																}
															}
														}
														if(lIsVCFound == false)
														{
															
															printf("\nkk.References CCV relation Does not exists for VC %s \n",sVCVehNum); fflush(stdout);
															printf("\nkk.Creating References CCV relation...\n"); fflush(stdout);
															
															if(ITEM_find_item(sVCVehNum,&VC_Objmstr)!=ITK_ok)PrintErrorStack();
															ITK_CALL(GRM_create_relation(LtstVCIDObj,VC_Objmstr, RefCCVTag, NULLTAG,&tRelatn));
															printf("\nkk.Created relation between [%s,%s] and [%s]",sVcidNo,sVcidRvSq,sVCVehNum);fflush(stdout);
															ITK_CALL(GRM_save_relation(tRelatn));

															//Initiate data transfer
															ITK_CALL(PREF_ask_char_value("CCID_TRANSFERPATH", 0 ,&sVCIDenvName ));
															printf("\nkk.Transfer path [%s]\n",sVCIDenvName);fflush(stdout);
															if(!sVCIDenvName)
															{
																printf("\nkk.VCID env Name not found!!!\n");fflush(stdout);
																EMH_clear_errors();
																EMH_store_error_s1(EMH_severity_error,ITK_err,"Preference not found.. Please check the preference CCID_TRANSFERPATH");
																return ITK_err;
															}
															else
															{
																char               *tempRev_ID	          =NULL;
																ITK_CALL(STRNG_replace_str(sVcidRvSq,";","_",&tempRev_ID));
																sSysStr = malloc(500);


																tc_strcpy(sSysStr,"nohup ");
																tc_strcat(sSysStr,sVCIDenvName);
																tc_strcat(sSysStr,"/");
																tc_strcat(sSysStr,"BSL_UA_UV_Transfer.sh ");
																tc_strcat(sSysStr,sVcidNo);
																tc_strcat(sSysStr," '");
																tc_strcat(sSysStr,sVcidRvSq);
																tc_strcat(sSysStr,"'");
																tc_strcat(sSysStr," > /tmp/");
																tc_strcat(sSysStr,sVcidNo);
																tc_strcat(sSysStr,"_");
																tc_strcat(sSysStr,tempRev_ID);
																tc_strcat(sSysStr,"_VehTransfer.log &");

																if (tc_strstr(finalVcidString,sVcidNo)!=NULL)
																{
																	printf("\nkk.data Transfer is already in process:[%s]\n",sVcidNo);fflush(stdout);

																}
																else
																{
																  printf("\nkk.VCID transfer command:[%s]\n",sSysStr);fflush(stdout);
																  tc_strcat(finalVcidString,sVcidNo);															
																  tc_strcat(finalVcidString," ");
																  printf("\n finalVcidString:[%s]\n",finalVcidString);fflush(stdout);

															      //	system(sSysStr);
																}
															
															}


														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			printf("\nkk.ContrlObj for tm_RefCCVCreAtVCRel not found.");fflush(stdout);
		}
	}
	printf("\n tm_RefCCVCreAtVCRel Ends.\n");fflush(stdout);

	return ITK_ok;
}
void FindLatestVCID(tag_t* tpVCIDList,int nVCnt, tag_t* VCIDObj)
{
	int iVCnt = 0;
	int iMaxSq = 0;
	int nVcidSeq = 0;
	char* sVCIDNum = NULL;
	char* vcid_id = NULL;
	char* vcid_seq = NULL;
	for(iVCnt=0; iVCnt<nVCnt; ++iVCnt)
	{
		if (AOM_ask_value_string(tpVCIDList[iVCnt],"item_id",&sVCIDNum)!=ITK_ok);
		printf("\nkk.VCID number is [%s]",sVCIDNum); fflush(stdout);

		vcid_id = tc_strtok(sVCIDNum,"_");
		vcid_seq = tc_strtok(NULL,"_");
		nVcidSeq = atoi(vcid_seq);
		if(nVcidSeq>iMaxSq)
		{
			iMaxSq=nVcidSeq;
			VCIDObj[0]=tpVCIDList[iVCnt];
		}
	}
	printf("\nkk.Max sequence is [%d]",iMaxSq); fflush(stdout);
}

