#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <res/res_itk.h>
#include <bom/bom.h> 
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h> 
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/vrule.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define TCTYPE_name_size_c 100
FILE 		*output 			= NULL;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
struct BomChldStrut_ECU
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut_ECU;
void Multi_Get_Part_BOM_Lvl_ECU(tag_t inputPart,int reqLevel,int level,tag_t revRule,struct BomChldStrut_ECU BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n_Cnt=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;

	char*			partColInd					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;
	char* PrtCmpCode 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	/*ITKCALL(AOM_ask_value_string(inputPart,"t5_ColourInd",&partColInd));
	printf("\n partColInd===>%s\n",partColInd);fflush(stdout);

	if( tc_strcmp(partColInd,"Y"))
	{
		goto CLEANUP;
	}*/



	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	//ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));

		BOM_set_window_top_line(window, null_tag,inputPart ,null_tag, &top_line);
		BOM_window_show_suppressed(window);//TZ 3.42 Backend
		ITKCALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n_Cnt);fflush(stdout);

		if (level==0)
		{
			BomChldStrut[*StructChldCnt].child_objs = inputPart;
			BomChldStrut[*StructChldCnt].child_objs_bvr=top_line;
			BomChldStrut[*StructChldCnt].child_objs_lvl=level;
		}

		level = level + 1;
		for (k = 0; k < n_Cnt; k++)
		{
			BOM_line_unpack (children[k]);
			BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			if(t_ChildItemRev!=NULLTAG)
			{

				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;
				

				Multi_Get_Part_BOM_Lvl_ECU(t_ChildItemRev,reqLevel,level,revRule,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
ECU_BOM_Report(char* EcuMod,char* Ecurev,char* EcuSeq,struct BomChldStrut_ECU ECU_Structure[],int StructChldCnt)
{
	FILE	*ECU_BOM_Fp		=	NULL;
	char* filenameS=NULL;
	filenameS = (char	*)MEM_alloc(100);
	tc_strcpy(filenameS,EcuMod);
	tc_strcat(filenameS,"_");
	tc_strcat(filenameS,Ecurev);
	tc_strcat(filenameS,"_");
	tc_strcat(filenameS,EcuSeq);
	tc_strcat(filenameS,"_ECUBOM.csv");



	ECU_BOM_Fp=fopen(filenameS,"w");
	fflush(ECU_BOM_Fp);

	int j=0;
	for (j=0;j <= StructChldCnt;j++ )
	{
		tag_t objChild		= NULLTAG;
		tag_t objChild_bvr	= NULLTAG;
		
		int  child_lvl       =0;
		
		char* ItemName=NULL;
		char* child_revision=NULL;
		char* child_EcuType=NULL;
		char* child_AppForEOL=NULL;
		char* child_EPReadable=NULL;
		char* child_SwPartType=NULL;


		//printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=ECU_Structure[j].child_objs;
		objChild_bvr=ECU_Structure[j].child_objs_bvr;
		child_lvl=ECU_Structure[j].child_objs_lvl;
		
		AOM_ask_value_string(objChild,"item_id",&ItemName);
		AOM_ask_value_string(objChild,"item_revision_id",&child_revision);

		fprintf(ECU_BOM_Fp,"%d,`%s,%s,",child_lvl,ItemName,child_revision); 

			AOM_ask_value_string(objChild,"t5_SwPartType",&child_SwPartType);
			AOM_ask_value_string(objChild,"t5_EcuType",&child_EcuType);
			AOM_ask_value_string(objChild,"t5_AppForEOL",&child_AppForEOL);
			AOM_ask_value_string(objChild,"t5_EPReadable",&child_EPReadable);
			fprintf(ECU_BOM_Fp,"%s,%s,%s,%s,",child_SwPartType,child_EcuType,child_AppForEOL,child_EPReadable);
		
		fprintf(ECU_BOM_Fp,"\n");
		printf("\n%d \t\t\t ItemName==>%s",child_lvl,ItemName);fflush(stdout);
	}
fclose(ECU_BOM_Fp);

}

ECU_Con_Report(char* EcuMod,char* Ecurev,char* EcuSeq,struct BomChldStrut_ECU ECU_Structure[],int StructChldCnt)
{
	FILE	*ECU_Con_Fp		=	NULL;
	char* filenameS=NULL;
	filenameS = (char	*)MEM_alloc(100);
	tc_strcpy(filenameS,EcuMod);
	tc_strcat(filenameS,"_");
	tc_strcat(filenameS,Ecurev);
		tc_strcat(filenameS,"_");
	tc_strcat(filenameS,EcuSeq);
	tc_strcat(filenameS,"_CON.csv");



	ECU_Con_Fp=fopen(filenameS,"w");
	fflush(ECU_Con_Fp);

	fprintf (ECU_Con_Fp,"ItemName,child_revision,CAL_ID,CAL_revision,ECUType,HWC_ID,HWC_revision,CFG_ID,CFG_revision,APP_ID,APP_revision,PBL_ID,PBL_revision,SBL_ID,SBL_revision\n");


	int j=0;
	for (j=0;j <= StructChldCnt;j++ )
	{
		tag_t objChild		= NULLTAG;
		tag_t objChild_Con	= NULLTAG;
		tag_t objChild_bvr	= NULLTAG;
		
		tag_t relation_type	= NULLTAG;
		tag_t sec_tag_para	= NULLTAG;
		tag_t sec_tag_para_rel	= NULLTAG;
		
		int  child_lvl       =0;
		int Con_Flag=0;
		
		char* ItemName=NULL;
		char* child_revision=NULL;
		char* child_EcuType=NULL;

		char* child_SwPartType=NULL;

			char* EPType=NULL;
		char* CAL_ID		=NULL;
		char* CAL_revision     =NULL;
		char* CON_child_ECUType=NULL;
		char* HWC_ID	       =NULL;
		char* HWC_revision     =NULL;
		char* CFG_ID	       =NULL;
		char* CFG_revision     =NULL;
		char* APP_ID	       =NULL;
		char* APP_revision     =NULL;
		char* PBL_ID	       =NULL;
		char* PBL_revision     =NULL;
		char* SBL_ID	       =NULL;
		char* SBL_revision     =NULL;

	char* Para_child_Type=NULL;
	
	char* ItemName_CON=NULL;
	char* child_revision_CON=NULL;
	GRM_relation_t *rellist;

	int k=0;


		//printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=ECU_Structure[j].child_objs;
		objChild_bvr=ECU_Structure[j].child_objs_bvr;
		child_lvl=ECU_Structure[j].child_objs_lvl;
		
		AOM_ask_value_string(objChild,"item_id",&ItemName);
		AOM_ask_value_string(objChild,"item_revision_id",&child_revision);
		AOM_ask_value_string(objChild,"t5_SwPartType",&child_SwPartType);

		if (tc_strcmp(child_SwPartType,"CON")==0)
		{
			CAL_ID		="";
			CAL_revision     ="";
			CON_child_ECUType="";
			HWC_ID	       ="";
			HWC_revision     ="";
			CFG_ID	       ="";
			CFG_revision     ="";
			APP_ID	       ="";
			APP_revision     ="";
			PBL_ID	       ="";
			PBL_revision     ="";
			SBL_ID	       ="";
			SBL_revision     ="";
			int n=0,kk=0;
			tag_t* children=NULL;
			tag_t ChildTg=NULLTAG;
			char* CON_child_SwType=NULL;
			printf("\n Container child SW Type %s" ,CON_child_SwType);fflush(stdout);
			AOM_ask_value_string(objChild,"t5_EcuType",&CON_child_ECUType);

			ITKCALL(BOM_line_ask_child_lines (objChild_bvr, &n, &children));
			for (kk = 0; kk < n; kk++)
			{
				int lineItemRevTag=0;
				CON_child_SwType="";
				ITKCALL(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &lineItemRevTag));
				ITKCALL(BOM_line_ask_attribute_tag(children[kk], lineItemRevTag, &ChildTg));

				AOM_ask_value_string(ChildTg,"t5_SwPartType",&CON_child_SwType);
				printf("\n Container child SW Type %s" ,ItemName);fflush(stdout);

				if (CON_child_SwType)
				{
					if (tc_strcmp(CON_child_SwType,"CAL")==0)
					{
						AOM_ask_value_string(ChildTg,"item_id",&CAL_ID);
						AOM_ask_value_string(ChildTg,"item_revision_id",&CAL_revision);
					}
					else if (tc_strcmp(CON_child_SwType,"HWC")==0)
					{
						AOM_ask_value_string(ChildTg,"item_id",&HWC_ID);
						AOM_ask_value_string(ChildTg,"item_revision_id",&HWC_revision);
					}
					else if (tc_strcmp(CON_child_SwType,"CFG")==0)
					{
						AOM_ask_value_string(ChildTg,"item_id",&CFG_ID);
						AOM_ask_value_string(ChildTg,"item_revision_id",&CFG_revision);
					}
					else if (tc_strcmp(CON_child_SwType,"APP")==0)
					{
						AOM_ask_value_string(ChildTg,"item_id",&APP_ID);
						AOM_ask_value_string(ChildTg,"item_revision_id",&APP_revision);						
					}
					else if (tc_strcmp(CON_child_SwType,"PBL")==0)
					{
						AOM_ask_value_string(ChildTg,"item_id",&PBL_ID);
						AOM_ask_value_string(ChildTg,"item_revision_id",&PBL_revision);
					}
					else if (tc_strcmp(CON_child_SwType,"SBL")==0)
					{
						AOM_ask_value_string(ChildTg,"item_id",&SBL_ID);
						AOM_ask_value_string(ChildTg,"item_revision_id",&SBL_revision);
					}
				}
			}
			fprintf (ECU_Con_Fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",ItemName,child_revision,CAL_ID,CAL_revision,CON_child_ECUType,HWC_ID,HWC_revision,CFG_ID,CFG_revision,APP_ID,APP_revision,PBL_ID,PBL_revision,SBL_ID,SBL_revision);

		}
	}

	fclose(ECU_Con_Fp);
}
ECU_Para_Mismatch_Report(tag_t objChild)
{


	int j=0;

		tag_t objChild_Con	= NULLTAG;
		
		tag_t relation_type	= NULLTAG;
		tag_t sec_tag_para	= NULLTAG;
		tag_t sec_tag_para_rel	= NULLTAG;
		
		int  child_lvl       =0;
		int Con_Flag=0;
		
		char* ItemName=NULL;
		char* child_revision=NULL;
		char* child_EcuType=NULL;
		char* child_AppForEOL=NULL;
		char* child_EPReadable=NULL;
		char* child_SwPartType=NULL;
		char* Para_child_EcuType=NULL;
			char* EPType=NULL;
	char* EPDesc=NULL;
	char* EPUnit=NULL;
	char* EPLen=NULL;
	char* EPValueList=NULL;
	char* ECUType=NULL;
	char* EPDidValue=NULL;
	char* EPReadable=NULL;
	char* EPApplicable=NULL;
	char* ECUVendor=NULL;
	char* ECUVersion=NULL;
	char* EP_ID=NULL;
	char* ECUBitValue=NULL;
	char* ECUParamValue=NULL;
	char* CON_child_ECUType=NULL;
	char* Para_child_Type=NULL;
	char* EPDesc_O=NULL;
	char* EP_ID_O=NULL;
	
	char* ItemName_CON=NULL;
	char* child_revision_CON=NULL;
	char* child_revision_O=NULL;
	GRM_relation_t *rellist;

	int k=0;


		//printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		//objChild=ECU_Structure[j].child_objs;
		
		//printf("FUn1");fflush(stdout);
		
		AOM_ask_value_string(objChild,"item_id",&ItemName);
		AOM_ask_value_string(objChild,"item_revision_id",&child_revision);
		AOM_ask_value_string(objChild,"t5_SwPartType",&child_SwPartType);

		if (tc_strcmp(child_SwPartType,"PRM")==0)
		{
			//printf("\nPRM!!!!!\n");fflush(stdout);
			AOM_ask_value_string(objChild,"t5_EcuType",&Para_child_EcuType);


			int count=0,i=0;


			GRM_find_relation_type ("T5_EEPrm", &relation_type);
			GRM_list_secondary_objects(objChild,relation_type, &count, &rellist);



			for (i=0;i<count ;i++ )
			{
				EPType="";      
				EPDesc="";      
				EPUnit="";      
				EPLen="";       
				EPValueList=""; 
				ECUType="";     
				EPDidValue="";  
				EPReadable="";  
				EPApplicable="";
				ECUVendor="";   
				ECUVersion="";  
				EP_ID="";  
				EP_ID_O="";  
				ECUBitValue="";  
				ECUParamValue="";  
				EPDesc_O="";  
				child_revision_O="";  
				sec_tag_para=rellist[i].secondary;
				sec_tag_para_rel=rellist[i].the_relation;
				
				AOM_ask_value_string(sec_tag_para, "object_name", &EP_ID);
				AOM_ask_value_string(sec_tag_para, "t5_EPType", &EPType);
				AOM_ask_value_string(sec_tag_para, "t5_t5EPDesc", &EPDesc);
				AOM_ask_value_string(sec_tag_para, "t5_EPUnit", &EPUnit);
				AOM_ask_value_string(sec_tag_para, "t5_EPLen", &EPLen);
				AOM_ask_value_string(sec_tag_para, "t5_EPValueList", &EPValueList);
				AOM_ask_value_string(sec_tag_para, "t5_ECUType", &ECUType);
				AOM_ask_value_string(sec_tag_para, "t5_EPDidValue", &EPDidValue);
				AOM_ask_value_string(sec_tag_para, "t5_EPReadable", &EPReadable);
				AOM_ask_value_string(sec_tag_para, "t5_EPApplicable", &EPApplicable);
				AOM_ask_value_string(sec_tag_para, "t5_ECUVendor", &ECUVendor);
				AOM_ask_value_string(sec_tag_para, "t5_ECUVersion", &ECUVersion);
				AOM_ask_value_string(sec_tag_para_rel, "t5_BitValue", &ECUBitValue);
				AOM_ask_value_string(sec_tag_para_rel, "t5_ParamValue", &ECUParamValue);
				STRNG_replace_str(EPDesc,",",";",&EPDesc_O);
				STRNG_replace_str(EP_ID,",",";",&EP_ID_O);
				STRNG_replace_str(child_revision,";","_",&child_revision_O);
							//printf("\nPRM!!!!!\n");fflush(stdout);

				fprintf (output,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,\n",ItemName,child_revision_O,EP_ID_O,Para_child_EcuType,ECUVendor,ECUVersion,EPType,EPDidValue,EPApplicable,EPReadable,EPLen,EPUnit);
							//printf("\nPRM!!!!!\n");fflush(stdout);


			}
		}




}


int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	
	char 			*itemid					= NULL;
	char 			*Lvl					= NULL;
	char 			*Rev					= NULL;
	char 			*Seq					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
		
	printf("File  to Open...!!");fflush(stdout);
	if (fp != NULL)
	{
		printf("File  Open succesfully...!!");fflush(stdout);
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
			count++;

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				if (count>2)
				{
				
				Lvl = strtok(temp, "^");
				itemid = strtok(NULL, "^");						
				Rev = strtok(NULL, "^");						
				Seq = strtok(NULL, "^");						
				printf("\nInput Item_id:<%s> <%s> <%s>" ,itemid,Rev,Seq);fflush(stdout);
				ifail = Query_attr(itemid, Rev,Seq);
				}

				
				
				
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");fflush(stdout);
	}
	fclose(fp);
	return ifail;
}

get_ReleaseStatus(tag_t itemrev)
 {
	int		status				= 0;
	int st_count1=0,cnt=0,VaultStsFlagRel=0,VaultStsFlagWIP=0;
	tag_t*    status_list1=NULLTAG;
	char *WSO_Name = NULL;
	char* VaultSts = NULL;
	char* effectivityStr = NULL;
	date_t			date_Rel;

	WSOM_ask_release_status_list(itemrev,&st_count1,&status_list1);
	//printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
	fprintf (output,"%d,",st_count1);

	//if(st_count1==1)
	//{
		//ITK_CALL(AOM_ask_name(status_list1[0],&WSO_Name));
		//printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
		//if (tc_strcmp(WSO_Name,"T5_LcsErcRlzd")==0 || tc_strcmp(WSO_Name,"ERC Released")==0)
		//{
			
			//ITK_CALL(AOM_ask_value_string(status_list1[cnt],"effectivity_text",&effectivityStr));
			//ITK_CALL(AOM_get_value_date(status_list1[cnt], "date_released", &date_Rel));
			//printf("\n effectivityStr----><%s> <%d/%d/%d>\n",effectivityStr,date_Rel.day,date_Rel.month,date_Rel.year );fflush(stdout);

			//fprintf (output,"%d/%d/%d,%s,",date_Rel.day,date_Rel.month,date_Rel.year,effectivityStr);
		//}

	//}
	//else if(st_count1>1)
	//{
		for (cnt=0;cnt< st_count1;cnt++ )
		{
			AOM_ask_name(status_list1[cnt],&WSO_Name);
			//printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);  //T5_LcsReview //ERC Released or T5_LcsErcRlzd// Released
			///if (tc_strcmp(WSO_Name,"T5_LcsErcRlzd")==0 || tc_strcmp(WSO_Name,"ERC Released")==0 )
			//{
				VaultStsFlagRel=1;
				AOM_ask_value_string(status_list1[cnt],"effectivity_text",&effectivityStr);
				AOM_get_value_date(status_list1[cnt], "date_released", &date_Rel);
				printf("\n <%s> effectivityStr----><%s> <%d/%d/%d>\n",WSO_Name,effectivityStr,date_Rel.day,date_Rel.month,date_Rel.year );fflush(stdout);
				fprintf (output,"%s,%d/%d/%d,%s,",WSO_Name,date_Rel.day,date_Rel.month,date_Rel.year,effectivityStr);
			//}

		}
	//}

 }

int Query_attr(char* item_id, char* Rev, char* Seq)
{
	int				ifail 						= ITK_ok;
	int status;	
	char *EcuRevSeq=NULL;
	EcuRevSeq = (char	*)MEM_alloc(100);

	tc_strcpy(EcuRevSeq,Rev);
	tc_strcat(EcuRevSeq,";");
	tc_strcat(EcuRevSeq,Seq);

	fprintf (output,"%s,%s,",item_id,EcuRevSeq);


	tag_t EcuMod_tag=NULLTAG;
	tag_t EcuMod_Rev_tag=NULLTAG;
	ITK_CALL(ITEM_find_item( item_id, &EcuMod_tag ));
	ITK_CALL(ITEM_find_revision(EcuMod_tag,EcuRevSeq,&EcuMod_Rev_tag));

	if (EcuMod_Rev_tag)
	{
		//printf("EcuMod_Rev_tag found...!!");fflush(stdout);


		get_ReleaseStatus(EcuMod_Rev_tag);
		//printf("EcuMod_Rev_tag completede...!!");fflush(stdout);

	}

	fprintf (output,",\n");


	return ifail;
}

extern int ITK_user_main (int argc, char ** argv )
{
	int status;		
	char *EcuMod=NULL;	
	char *Ecurev=NULL;
	char *EcuSeq=NULL;
	char *EcuRevSeq=NULL;
	char *EcuFile=NULL;
	char *OutFile=NULL;
	tag_t EcuMod_tag=NULLTAG;
	tag_t EcuMod_Rev_tag=NULLTAG;
	tag_t rule=NULLTAG;


	EcuMod = (char	*)MEM_alloc(100);
	Ecurev = (char	*)MEM_alloc(100);
	EcuSeq = (char	*)MEM_alloc(100);
	EcuRevSeq = (char	*)MEM_alloc(100);

	struct			BomChldStrut_ECU	ECU_Structure[5000];
		
	EcuMod = ITK_ask_cli_argument("-i=");	
	Ecurev = ITK_ask_cli_argument("-r=");	
	EcuSeq = ITK_ask_cli_argument("-s=");	
	EcuFile = ITK_ask_cli_argument("-InpFile=");	
	OutFile = ITK_ask_cli_argument("-OutFile=");	
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\n EcuFile is  ====> %s\n",EcuFile );fflush(stdout);

	if (EcuFile)
	{	
		
		output = fopen(OutFile,"w+");                  
		if (output == NULL)                               
		{                                                 
			printf("ERROR: Cannot open File\n");fflush(stdout);          
			return -1;                                    
		}                                                 
		else                                              
		{                                                 
			printf("File opened successfully.\n");fflush(stdout);       
			ITK_CALL(read_value_from_file(EcuFile));    
		}  
		fclose(output);
		                                                  



	}




	ITK_CALL(POM_logout(false));
	return status;
}

