
/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: parameter_creation.c
**
** Functions:-  This utility takes the item id and attribute values from file and creates custom document(T5_EPara)
**                              and update it's attribute values as per given input file and creates relation with part.
**
**
**
**      Date                                                    Author                                                          Modification
**      10-May-2019                                             Prajakta Dhawan                                        Code creation
**
** command to run:
** parameter_creation -u=<username> -pf=<password> -g=<group> -file=<input_file>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/tctype.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define PROP_set_value_string_msg   "PROP_set_value_string"

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

FILE            *output                         = NULL;
int                     ifail                           = ITK_ok;
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
         int                            index                           = 0;
         int                            n_ifails                        = 0;
         const int*                     severities                      = 0;
         const int*                     ifails                          = 0;
         const char**           texts                           = NULL;

         EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
         printf("%3d error(s)\n", n_ifails);
         for( index=0; index<n_ifails; index++)
         {
              printf("ERROR: %d\tERROR MSG: [%s]\n", ifails[index], texts[index]);
              TC_write_syslog("ERROR: %d\tERROR MSG: [%s]\n", ifails[index], texts[index]);
              printf ("FUNCTION: [%s]\nFILE: [%s] LINE: %d\n\n", function, file, line);
              TC_write_syslog("FUNCTION: [%s]\nFILE: [%s] LINE: %d\n", function, file, line);
         }
         EMH_clear_errors();
    }
    return return_code;
}

int read_value_from_file(char*);
int set_attr_values(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);
int create_relation(char*, char*, tag_t, char*, char*);
void print_requirement()
{
        printf(
        "\nHELP:\n"
        "parameter_creation -u=<username> -pf=<password file path> -g=<group> -file=<input filename>\n"
        "-------------------------------------------------------------------------------------------\n\n"
        );
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
                                        It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
        char                    * userid                                        = NULL;
        char                    * password                                      = NULL;
        char                    * group                                         = NULL;
        char                    * Filename                                      = NULL;


        userid                  = ITK_ask_cli_argument("-u=");
        password                = ITK_ask_cli_argument("-pf=");
        group                   = ITK_ask_cli_argument("-g=");
        Filename                = ITK_ask_cli_argument("-file=");

        if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
        {
                print_requirement();
                return -1;
        }

        ifail = ITK_auto_login();
        //ifail = ITK_init_module(userid, password, group);
        if (ifail != ITK_ok)
        {
                printf("Error in Login to Teamcenter\n");
                return ifail;
        }
        else
                {
                        printf("\nLogin Successfull.....!!\n");
                        printf("\nWelcome to Teamcenter.....!!\n");
                }
        ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
        {
                printf("\nUser is not Privileged Admin User \n\n");
                return -1;
        }



        ifail = read_value_from_file(Filename);


        printf("\nEnd of program.....!!\n");
        printf("\n*********************\n");
        ifail = ITK_exit_module(true);
        return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
        char                    *part_no                                        = NULL;
        char                    *rev_id                                         = NULL;
        char                    *itemid_para                            = NULL;
        char                    *rev_para                                       = NULL;
        char                    *EPType                                         = NULL;
        char                    *EPDesc                                         = NULL;
        char                    *EPUnit                                         = NULL;
        char                    *EPLen                                          = NULL;
        char                    *ECUType                                        = NULL;
        char                    *EPDidValue                                     = NULL;
        char                    *EPReadable                                     = NULL;
        char                    *EPApplicable                           = NULL;
        char                    *ECUVendor                                      = NULL;
        char                    *ECUVersion                                     = NULL;
        char                    *BitValue                                       = NULL;
        char                    *ParamValue                                     = NULL;
                char                    *EPValueList                            = NULL;
        char                    temp[10000];

        FILE            * fp                                    = NULL;

        fp = fopen(Filename, "r");
        if (fp != NULL)
        {
                while (fgets(temp, 10000, fp)!= NULL)
                {
                        tc_strcpy(temp,stripBlanks(temp));

                        if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
                        {
                               part_no = strtok(temp, "^");
                                printf("\nInput part_no:%s",part_no);

                                rev_id = strtok(NULL, "^");
                                printf("\nInput rev_id:%s",rev_id);

                                itemid_para = strtok(NULL, "^");
                                printf("\nInput Parametr Item_id:[%s]",itemid_para);

                                                                rev_para = strtok(NULL, "^");
                                printf("\nInput rev_para:%s",rev_para);

                                                                EPType = strtok(NULL, "^");
                                printf("\nInput EPType:[%s]", EPType);

                                EPDesc = strtok(NULL, "^");
                                printf("\nInput EPDesc:[%s]", EPDesc);

                                                                EPUnit = strtok(NULL, "^");
                                printf("\nInput EPUnit:[%s]", EPUnit);

                                                                EPLen = strtok(NULL, "^");
                                printf("\nInput EPLen:[%s]", EPLen);

                                                                EPValueList = strtok(NULL, "^");
                                printf("\nInput EPValueList:%s", EPValueList);

                                ECUType = strtok(NULL, "^");
                                printf("\nInput ECUType:[%s]", ECUType);

                                EPDidValue = strtok(NULL, "^");
                                printf("\nInput EPDidValue:[%s]", EPDidValue);

                                                                EPReadable = strtok(NULL, "^");
                                printf("\nInput EPReadable:[%s]", EPReadable);

                                                                EPApplicable = strtok(NULL, "^");
                                printf("\nInput EPApplicable:[%s]", EPApplicable);

                                ECUVendor = strtok(NULL, "^");
                                printf("\nInput ECUVendor:[%s]", ECUVendor);

                                ECUVersion = strtok(NULL, "^");
                                printf("\nInput ECUVersion:[%s]", ECUVersion);

                                                                BitValue = strtok(NULL, "^");
                                printf("\nInput BitValue:%s", BitValue);

                                ParamValue = strtok(NULL, "^");
                                printf("\nInput ParamValue:%s\n", ParamValue);


                               ifail = Set_attr_values(part_no, rev_id, itemid_para, rev_para, EPType, EPDesc, EPUnit, EPLen, EPValueList, ECUType, EPDidValue, EPReadable, EPApplicable, ECUVendor, ECUVersion, BitValue, ParamValue);
                        }
                        printf("\n***************************************\n");
                         tc_strcpy(temp, "");
                }
        }
        else
        {
                printf("File Unable to Open...!!");
        }
        fclose(fp);
        return ifail;
}


/******************************************************************************************************
    Function:       Set_attr_values
    Description:    This function takes the attribute values and print the same.
*******************************************************************************************************/
int Set_attr_values(char* part_no, char* rev_id, char* itemid_para, char* rev_para, char* EPType, char* EPDesc, char* EPUnit, char* EPLen, char* EPValueList, char* ECUType, char* EPDidValue, char* EPReadable, char* EPApplicable, char* ECUVendor, char* ECUVersion, char* BitValue, char* ParamValue)
{
        int                             i                                                               = 0;
        int                             n_items                                                 = 0;
        int                             objectfound                                             = 0;

        char                    *EPType_cp                                              = NULL;
        char                    *EPDesc_cp                                              = NULL;
        char                    *EPUnit_cp                                              = NULL;
        char                    *EPLen_cp                                               = NULL;
        char                    *ECUType_cp                                             = NULL;
        char                    *EPDidValue_cp                                  = NULL;
        char                    *EPReadable_cp                                  = NULL;
        char                    *EPApplicable_cp                                = NULL;
        char                    *ECUVendor_cp                                   = NULL;
        char                    *ECUVersion_cp                                  = NULL;
        char* errormsg=NULL;
        tag_t                   object                                                  = NULLTAG;
        tag_t                   new_object                                              = NULLTAG;
        tag_t                   relation_type                                   = NULLTAG;
        tag_t                   new_relation                                    = NULLTAG;
        tag_t                   item_type_tag                                   = NULLTAG;
        tag_t                   para_rev_tag                                    = NULLTAG;
        tag_t                   item_create_input_tag                   = NULLTAG;

        tag_t                   *item_tags                                              = NULL;
char*filename1=NULL;
                filename1=(char *) MEM_alloc(100);
                filename1=strcpy(filename1,"Found.txt");
                FILE* fp1 = NULL;
                //fp1 = fopen(filename1,"a+");
      char*filename2=NULL;
                filename2=(char *) MEM_alloc(100);
                filename2=strcpy(filename2,"not_Found.txt");
                FILE* fp2 = NULL;
                //fp2 = fopen(filename2,"a+");
           char *Token_01=NULL;
           char *Token_02=NULL;
       tag_t KWDescQry     = NULLTAG;
            tag_t *moduleTags   = NULL;
                int modCount=0;
                int Entry_count=11;
                char **Values = (char **) MEM_alloc(500 * sizeof(char *));

                char* itemid_para_tok=NULL;
        char* itemid_para_Fin=NULL;
                char* EPDesc_tok=NULL;
        char* EPDesc_Fin=NULL;
                char* ECUVendor_tok=NULL;
        char* ECUVendor_Fin=NULL;

                //item_id tokenmisation

                itemid_para_tok=(char *) MEM_alloc(500);
                itemid_para_Fin=(char *) MEM_alloc(500);
                itemid_para_tok=tc_strcpy(itemid_para_tok,"");
                itemid_para_tok=tc_strcpy(itemid_para_tok,itemid_para);
                if(tc_strstr(itemid_para, ":") !=NULL)
                {

                       Token_01=tc_strtok(itemid_para_tok, ":");
                                           Token_02 =tc_strtok(NULL, ":");
                                           itemid_para_Fin=tc_strcpy(itemid_para_Fin,"");
                                   itemid_para_Fin=tc_strcpy(itemid_para_Fin,Token_01);
                                   itemid_para_Fin=tc_strcat(itemid_para_Fin,"*");
                                   itemid_para_Fin=tc_strcat(itemid_para_Fin,Token_02);
                }
                                else
                                {
                                        itemid_para_Fin=tc_strcpy(itemid_para_Fin,"");
                                itemid_para_Fin=tc_strcpy(itemid_para_Fin,itemid_para);
                                }


                        printf("\naitemid_para_tok:[%s]",itemid_para_Fin);



                //Paramter descp tokenisation

                EPDesc_tok=(char *) MEM_alloc(500);
                EPDesc_Fin=(char *) MEM_alloc(500);
                EPDesc_tok=tc_strcpy(EPDesc_tok,"");
                EPDesc_tok=tc_strcpy(EPDesc_tok,EPDesc);
                if(tc_strstr(EPDesc, ":") !=NULL)
                {

                       Token_01=tc_strtok(EPDesc_tok, ":");
                                           Token_02 =tc_strtok(NULL, ":");
                                           EPDesc_Fin=tc_strcpy(EPDesc_Fin,"");
                                   EPDesc_Fin=tc_strcpy(EPDesc_Fin,Token_01);
                                   EPDesc_Fin=tc_strcat(EPDesc_Fin,"*");
                                   EPDesc_Fin=tc_strcat(EPDesc_Fin,Token_02);
                }
                                else
                                {
                                        EPDesc_Fin=tc_strcpy(EPDesc_Fin,"");
                                EPDesc_Fin=tc_strcpy(EPDesc_Fin,EPDesc);
                                }
                        printf("\naEPDesc_tok:[%s]",EPDesc_Fin);

                        //supplier tokenisation

                ECUVendor_tok=(char *) MEM_alloc(500);
                ECUVendor_Fin=(char *) MEM_alloc(500);
                ECUVendor_tok=tc_strcpy(ECUVendor_tok,"");
                ECUVendor_tok=tc_strcpy(ECUVendor_tok,ECUVendor);
                if(tc_strstr(ECUVendor, ":") !=NULL)
                {

                       Token_01=tc_strtok(ECUVendor_tok, ":");
                                           Token_02 =tc_strtok(NULL, ":");
                                           ECUVendor_Fin=tc_strcpy(ECUVendor_Fin,"");
                                   ECUVendor_Fin=tc_strcpy(ECUVendor_Fin,Token_01);
                                   ECUVendor_Fin=tc_strcat(ECUVendor_Fin,"*");
                                   ECUVendor_Fin=tc_strcat(ECUVendor_Fin,Token_02);
                }
                                else
                                {
                                        ECUVendor_Fin=tc_strcpy(ECUVendor_Fin,"");
                                ECUVendor_Fin=tc_strcpy(ECUVendor_Fin,ECUVendor);
                                }


                        printf("\naECUVendor_tok:[%s]",ECUVendor_Fin);



char *Entries[11] = {"Name","ECU Type","Paramter Desc","Supplier","Versions","Data Type","Unit","Length","DID Value","Applicable to","Read/Write"};

Values[0]= itemid_para_Fin;
Values[1]= ECUType;
Values[2]= EPDesc_Fin;
Values[3]= ECUVendor_Fin;
Values[4]= ECUVersion;
Values[5]= EPType;
Values[6]= EPUnit;
Values[7]= EPLen;
Values[8]= EPDidValue;
Values[9]= EPApplicable;
Values[10]=EPReadable;



           ifail=QRY_find("EEPara", &KWDescQry);
           if (KWDescQry)
{


        QRY_execute(KWDescQry, Entry_count, Entries, Values, &modCount, &moduleTags);

         printf("\nMod count = %d\n",modCount);
        if(modCount>0)
        {
         printf("\nparameter Found successfully!!\n");

                //fprintf(fp1,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s\n",itemid_para, ECUType, ECUVendor, ECUVersion, EPApplicable, EPDesc, EPDidValue,EPLen,EPReadable,EPType, EPUnit);

                ITK_CALL(create_relation(part_no, rev_id, moduleTags[0], BitValue, ParamValue));
        }
        else
        {

                    if((tc_strcmp(EPUnit, " ") == 0) || tc_strlen(EPUnit) == 0)
                        {
                                tc_strcpy(EPUnit, "NA");
                        }
                        if(tc_strcmp(EPLen, " ") == 0 || tc_strlen(EPLen) == 0)
                        {
                                tc_strcpy(EPLen, "NA");
                        }
                        if((tc_strcmp(EPValueList, " ") == 0) || tc_strlen(EPValueList) == 0)
                        {
                                tc_strcpy(EPValueList, "NA");
                        }
               printf("\nRequired parameter not found, hence going to create new parameter...!!\n");
                ifail = TCTYPE_find_type("T5_EPara", "Document", &item_type_tag);
                ifail = TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);
                                ifail = AOM_UIF_set_value(item_create_input_tag, "item_id", itemid_para);
                ifail = AOM_UIF_set_value(item_create_input_tag, "object_name", itemid_para);
                                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPType", EPType);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPUnit", EPUnit);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPLen", EPLen);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_ECUType", ECUType);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPDidValue", EPDidValue);
                ifail = AOM_UIF_set_value(item_create_input_tag,"t5_EPReadable",EPReadable);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPApplicable", EPApplicable);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_ECUVendor", ECUVendor);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_ECUVersion", ECUVersion);
                ifail = TCTYPE_create_object (item_create_input_tag, &object);
                                ifail=AOM_save(object);


                                if(ifail==ITK_ok)
                                {
                                         printf("\nitem created successfully!!\n");
                                                                                 ifail = AOM_refresh (object, 1);

                                            ifail = AOM_UIF_set_value (object, "t5_t5EPDesc",EPDesc);

                                            ifail = AOM_save (object);

                                            ifail = AOM_refresh (object, 0);

                                                                                ITK_CALL(create_relation(part_no, rev_id, object, BitValue, ParamValue));

                                }
                                else
                         {
                         printf("\nitem not created successfully!!\n");
                                //fprintf(fp2,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s\n",itemid_para, ECUType, ECUVendor, ECUVersion, EPApplicable, EPDesc, EPDidValue,EPLen,EPReadable,EPType, EPUnit);

                                }
                        ifail=EMH_ask_error_text(ifail,&errormsg);
            printf("\n[%s]\n",errormsg);








        }
        MEM_free(moduleTags);

        //fclose(fp1);
        //fclose(fp2);
}

        return ifail;
}


int create_relation(char* part_no, char* rev_id, tag_t object, char* BitValue, char* ParamValue)
{
        int                             i                                                       = 0;
        int                             count                                           = 0;

        char                    *obj_string                                     = NULL;

        tag_t                   *sec_tag                                        = NULL;

        tag_t                   ee_part_rev_tag                         = NULLTAG;
        tag_t                   relation_type                           = NULLTAG;
        tag_t                   new_relation                            = NULLTAG;
        tag_t                   rel_exist                                       = NULLTAG;


                int     number_of_types2;

                tag_t *         type_tag3_R;

                tag_t   object_create_input_tag3_R                  = NULLTAG;



        printf("\nGoing to create relation between EE Part and ECU Parameter Master...!!\n");
        ITK_CALL(ITEM_find_rev (part_no, rev_id, &ee_part_rev_tag));
        printf("\npart:%s and rev:%s\n", part_no, rev_id);
        if(ee_part_rev_tag != NULLTAG)
        {
                printf("\nEE part revision found...!!\n");
                ITK_CALL(GRM_find_relation_type ("T5_EEPrm", &relation_type));

                if(relation_type != NULLTAG)
                {

                        ITK_CALL(TCTYPE_find_types_for_class("T5_EEPrm",&number_of_types2,&type_tag3_R));
                        ITK_CALL(TCTYPE_construct_create_input(type_tag3_R[0], &object_create_input_tag3_R));

                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"primary_object",ee_part_rev_tag));
                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"secondary_object",object));
                        ITK_CALL(AOM_UIF_set_value(object_create_input_tag3_R,"t5_BitValue",BitValue));
                        ITK_CALL(TCTYPE_create_object(object_create_input_tag3_R, &new_relation));
                                                ITK_CALL(AOM_save(new_relation));
                        ITK_CALL(AOM_refresh(new_relation,0));
                        ITK_CALL(AOM_unlock(new_relation));

                        printf("\nRelation type found...!!\n");



                }
        }
        return ifail;
}

