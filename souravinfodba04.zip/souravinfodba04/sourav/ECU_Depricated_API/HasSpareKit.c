#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <res/res_itk.h>
#include <bom/bom.h> 
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h> 
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define TCTYPE_name_size_c 100

extern int ITK_user_main (int argc, char ** argv )
{

    int status;
		char* inputline=NULL;
		FILE *fptr;

		char *SprKitPartNumber = NULL;
		char *SprKitRev = NULL;
		char *SprKitSeq = NULL;
		char *designPartNumber = NULL;
		char *RevSeq = NULL;

	tag_t *tags_found = NULL;
	int n_tags_found= 0;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	tag_t *tags_found_1 = NULL;
	int n_tags_found_1= 0;
	char **attrs_1 = (char **) MEM_alloc(1 * sizeof(char *));
	char **values_1 = (char **) MEM_alloc(1 * sizeof(char *));			
	int Item_count=0;
	tag_t	*rev_list = NULL;
	char 	*rev_id	= NULL;
	tag_t tRelationFind ,Rel_task= NULLTAG;	

	//inputfile = ITK_ask_cli_argument("-i=");
	
	//ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	//printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login());
	
	//if( ITK_init_module("loader","loader7","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
    ITK_CALL(ITK_set_journalling( TRUE ));
	//printf("\n Line  ====%s ",inputfile );fflush(stdout);
	//itemId=tc_strtok(inputfile,"^");
	
	fptr=fopen("SprKitIsForPart.txt","r");
	printf("\n opening file  ====" );fflush(stdout);

	if(fptr!=NULL)
	{
		printf("\n inside loop ====" );fflush(stdout);
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fptr)!=NULL)
		{
			//fputs(inputline,stdout);	
			printf("\n inputline :%s",inputline);fflush(stdout);

			SprKitPartNumber=tc_strtok(inputline,"^");
			printf("\n SprKitPartNumber => %s ",SprKitPartNumber );fflush(stdout);
			SprKitRev=tc_strtok(NULL,"^");
			printf("\n SprKitRev => %s ",SprKitRev );fflush(stdout);
			SprKitSeq=tc_strtok(NULL,"^");
			printf("\n SprKitSeq => %s ",SprKitSeq );fflush(stdout);
			designPartNumber=tc_strtok(NULL,"^");
			printf("\n designPartNumber => %s ",designPartNumber );fflush(stdout);

			RevSeq = NULL;
							RevSeq=(char *) MEM_alloc(10);
							strcpy(RevSeq,SprKitRev);
							strcat(RevSeq,";");
							strcat(RevSeq,SprKitSeq);



			attrs[0] ="item_id";
			values[0] = (char *)SprKitPartNumber;	
			ITEM_find_item_revs_by_key_attributes	(1,attrs,values,RevSeq, &n_tags_found, &tags_found);
			printf ("\n Queried Spare kit rev found count:  %d \n\n",n_tags_found);



//to query design

			attrs_1[0] ="item_id";
			values_1[0] =(char *) MEM_alloc(50);			
			strcpy(values_1[0],designPartNumber);	
	
			 ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs_1, values_1,&n_tags_found_1, &tags_found_1));
			printf ("\n adkQueried Design Matsers count:  %d \n\n",n_tags_found_1);
			if (n_tags_found_1 == 0)
			{
				printf ("adk ITEM_find_items_by_key_attributes returns success,  but didn't find   Design Master\n");
				//return 0;
			}
			else
			{
					ITEM_list_all_revs (tags_found_1[0], &Item_count, &rev_list);
					printf("\nadk Total rev found: %d.", Item_count);fflush(stdout);
					AOM_UIF_ask_value (rev_list[Item_count-1], "item_revision_id", &rev_id);					
					printf("\nadk Latest Revision found is:%s",rev_id);

					GRM_find_relation_type ("T5_HasSpareKit",&tRelationFind);
					if (tRelationFind!=NULLTAG)
					{
						if (rev_list[Item_count-1]!=NULLTAG && tags_found[0]!=NULLTAG)
						 { 
							printf("\n inside if loop \n");fflush(stdout);
							GRM_create_relation(rev_list[Item_count-1],tags_found[0],tRelationFind,NULLTAG,&Rel_task);
							printf("\n inside if loop \n");fflush(stdout);
							//AOM_load(Rel_task);
							//printf("\nAOM_load-----\n");fflush(stdout);
							GRM_save_relation(Rel_task); 
							ITK_CALL(AOM_refresh(rev_list[Item_count-1],0));
							printf("\nRelation Created Successfully...\n");fflush(stdout);
						 }
					}

			}
				

						

					//GRM_find_relation_type ("T5_HasSpareKit",&tRelationFind);
					//if (tRelationFind!=NULLTAG)
					//{
					//	if (rev_list[Item_count-1]!=NULLTAG && tags_found[0]!=NULLTAG)
					//	 { 
					//		printf("\n inside if loop \n");fflush(stdout);
					//		GRM_create_relation(rev_list[Item_count-1],tags_found[0],tRelationFind,NULLTAG,&Rel_task);
					//		printf("\n inside if loop \n");fflush(stdout);
					//		//AOM_load(Rel_task);
					//		//printf("\nAOM_load-----\n");fflush(stdout);
					//		GRM_save_relation(Rel_task); 
					//		ITK_CALL(AOM_refresh(rev_list[Item_count-1],0));
					//		printf("\nRelation Created Successfully...\n");fflush(stdout);
					//	 }
					//}

			

		}
	}

	ITK_CALL(POM_logout(false));
	return status;
}

