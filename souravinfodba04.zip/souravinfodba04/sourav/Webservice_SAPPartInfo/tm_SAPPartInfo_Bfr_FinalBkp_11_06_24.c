/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP
*  Description  :   Query Part From SAP & Return It's Details As a Response via Web-Service 
*  File Name    :   tm_SAPPartInfo.c
*  Created on   :   May 22nd, 2024
*  Usage        :   tm_SAPPartInfo
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     22/05/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include "wmhelpe.h"
#include "bapi.h"
#include "saprfc.h"
#include "sapitab.h"
#include "t.h"
#include "malloc.h"
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\
		
void rfc_error(char *);
void cll_zrfc_ac_view_create(void);
void cll_zbapi_material_savedata_mrp(void);

RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA *,BAPI_MARAX *,BAPI_MARC *,BAPI_MARCX *,BAPI_MPGD *,BAPI_MPGDX *,BAPI_MARD *,BAPI_MARDX *,BAPI_MBEW *,BAPI_MBEWX *,RMMG1_AENNR *,BAPIRET2 *,ITAB_H ,ITAB_H ,ITAB_H,ITAB_H ,ITAB_H ,char *);
RFC_RC zbapi_material_savedata_mrpCreate(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARA	*eBasicView,BAPI_MARAX	*eBasicViewx,BAPI_MARC	*eMrpView,BAPI_MARCX	*eMrpViewx,BAPI_MPGD	*eBapi_Mpgd,BAPI_MPGDX	*eBapi_Mpgdx,BAPI_MARD	*eBapi_Mard,BAPI_MARDX	*eBapi_Mardx,BAPI_MBEW	*eAccView,BAPI_MBEWX	*eAccViewx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,ITAB_H thBapi_Marm,ITAB_H thBapi_Marmx,ITAB_H thBAPIE1PAREX3,ITAB_H thBAPIE1PAREXX3,char *xException);
RFC_RC BAPI_MATERIAL_MARD(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARD *eBapi_Mard,BAPI_MARDX *eBapi_Mardx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,char *xException);
RFC_RC allocate_insp_type(void);
RFC_RC allocate_insp_type_vc(void);

RFC_RC cll_zrfc_insptype_alloc(RFC_HANDLE);
RFC_RC vc_zrfc_insptype_alloc(RFC_HANDLE );
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
RFC_RC WIN_DLL_EXPORT_FLAGS zpprfc_revisionnum_change(RFC_HANDLE hRfc,AENNR *eAennr,CCMATNR *eMatnr,CC_REVLV *eRevlv,BAPIRET2 *iMessg,SYST_SUBRC *iRetval,char *xException);

void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);


char* InpPrt_str = NULL;
char* InpPlnt_str = NULL;
char* InpPrt_strDup = NULL;
char* InpPlnt_strDup = NULL;
char* plantcode = NULL;

WERKS_D eWerks;
static MATNR eMatnr;

char *proc_type;
char *inputPart = NULL;
char *iPlantCode = NULL;
char *iSapServer = "CVP";
char *sap_proc_type = NULL;
char *sap_spproc_type = NULL;
char *SAPpstat = NULL;
char *MRPpstat = NULL;
char pstat;
char *Plant_StoreLoc = NULL;
char *Plant_MakeBuy = NULL;
char *profit_centre2 = NULL;
char *plan_calendar2 = NULL;
char *overhd_grp2 = NULL;
char *origin_group2 = NULL;
char *origin_group = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *sloc1_type = NULL;
char *sloc2_type = NULL;

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_PartCS(tag_t PartRevtag, char* PartPlantName)
{
	
	trimwhitespace(PartPlantName);
	char *PartPlmCS = NULL;
	PartPlmCS = (char *) malloc(500*sizeof(char));
	char* PartPlmCSVal = NULL;
	char* PartPlmCSValDup = NULL;
	
	printf("\n Part Plant Name Value: [%s]\n", PartPlantName);fflush(stdout);
	if(tc_strcmp(PartPlantName,"1001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_PunMakeBuyIndicator"); //APLP
	}
	else if(tc_strcmp(PartPlantName,"1100")==0)
	{
		tc_strcpy(PartPlmCS,"t5_CarMakeBuyIndicator"); //APLC
	}
	else if(tc_strcmp(PartPlantName,"1500")==0)
	{
		tc_strcpy(PartPlmCS,"t5_DwdMakeBuyIndicator"); //APLD
	}
	else if(tc_strcmp(PartPlantName,"2001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_JsrMakeBuyIndicator"); //APLJ
	}
	else if(tc_strcmp(PartPlantName,"3001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_LkoMakeBuyIndicator"); //APLL
	}
	else if(tc_strcmp(PartPlantName,"3100")==0)
	{
		tc_strcpy(PartPlmCS,"t5_PnrMakeBuyIndicator"); //APLU
	}
	else if(tc_strcmp(PartPlantName,"E201")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_AhdMakeBuyIndicator"); //APLA
	}
	else if(tc_strcmp(PartPlantName,"7501")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_JdlMakeBuyIndicator"); //APLS
	}
	else if(tc_strcmp(PartPlantName,"1140")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_PunUVMakeBuyIndicator"); //APLV
	}
	else
	{
		printf(" Plant Code Invalid..!!\n");fflush(stdout);
	}
	trimwhitespace(PartPlmCS);
	printf("\n Part PLM CS(PartPlmCS):  [%s] \n",PartPlmCS);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(PartRevtag,PartPlmCS,&PartPlmCSVal));
	if(tc_strlen(PartPlmCSVal)>0)
	{
		tc_strdup(PartPlmCSVal,&PartPlmCSValDup);
	}
	else
	{
		tc_strdup("Blank",&PartPlmCSValDup);
		printf("\n Part PLM CS Value is NULL");fflush(stdout);
	}
	printf("\n Part PLM CS Final Value(PartPlmCSValDup):  [%s]\n",PartPlmCSValDup);fflush(stdout);
	return PartPlmCSValDup;	
}

char* TC_PartSLOC(tag_t PartRevtag, char* PartPlantName)
{
	
	trimwhitespace(PartPlantName);
	char *PartPlmSloc = NULL;
	PartPlmSloc = (char *) malloc(20*sizeof(char));
	char* PartPlmSlocVal = NULL;
	char* PartPlmSlocValDup = NULL;
	
	printf("\n Part Plant Name Value: [%s]\n", PartPlantName);fflush(stdout);
	if(tc_strcmp(PartPlantName,"1001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_PunStoreLocation"); //APLP
	}
	else if(tc_strcmp(PartPlantName,"1100")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_CarStoreLocation"); //APLC
	}
	else if(tc_strcmp(PartPlantName,"1500")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_DwdStoreLocation"); //APLD
	}
	else if(tc_strcmp(PartPlantName,"2001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_JsrStoreLocation"); //APLJ
	}
	else if(tc_strcmp(PartPlantName,"3001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_LkoStoreLocation"); //APLL
	}
	else if(tc_strcmp(PartPlantName,"3100")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_PnrStoreLocation"); //APLU
	}
	else if(tc_strcmp(PartPlantName,"E201")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_AhdStoreLocation"); //APLA
	}
	else if(tc_strcmp(PartPlantName,"7501")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_JdlStoreLocation"); //APLS
	}
	else if(tc_strcmp(PartPlantName,"1140")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_PunUVStoreLocation"); //APLV
	}
	else
	{
		printf(" Plant Code Invalid..!!\n");fflush(stdout);
	}
	trimwhitespace(PartPlmSloc);
	printf("\n Part PLM SLOC(PartPlmSloc):  [%s] \n",PartPlmSloc);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(PartRevtag,PartPlmSloc,&PartPlmSlocVal));
	if(tc_strlen(PartPlmSlocVal)>0)
	{
		tc_strdup(PartPlmSlocVal,&PartPlmSlocValDup);
	}
	else
	{
		tc_strdup("Blank",&PartPlmSlocValDup);
		printf("\n Part PLM SLOC Value is NULL");fflush(stdout);
	}
	printf("\n Part PLM SLOC Final Value(PartPlmSlocValDup):  [%s]\n",PartPlmSlocValDup);fflush(stdout);
	return PartPlmSlocValDup;	
}

RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException)
{
	RFC_RC RfcRc;
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfMATNR;
	Exporting[0].leng = sizeof(MATNR);
	Exporting[0].addr = eMatnr;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfWERKS_D;
	Exporting[1].leng = sizeof(WERKS_D);
	Exporting[1].addr = eWerks;

	Exporting[2].name = NULL;


	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_GETALL",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "CLIENTDATA";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCLIENTDATA;
			Importing[0].leng = sizeof(CLIENTDATA);
			Importing[0].addr = iView;

			Importing[1].name = "PLANTDATA";
			Importing[1].nlen = 9;
			Importing[1].type = handleOfPLANTDATA;
			Importing[1].leng = sizeof(PLANTDATA);
			Importing[1].addr = iMrpView;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
		default: ;
	}
	return RfcRc;
}

int GetCSPstat(void)
{
    char *xException = NULL;
	RFC_HANDLE hRfc;
	RFC_RC RfcRc;
	MATNR eMatnr;
	WERKS_D eWerks;
	PLANTDATA iMrpView;
	CLIENTDATA iView;

    printf("\n In Function[GetCSPstat] ---> Part_NO: [%s]   Plant_Code: [%s]",InpPrt_strDup,plantcode);
    hRfc = BapiLogon();
    sap_proc_type = (char *) malloc(20*sizeof(char));
	sap_spproc_type = (char *) malloc(20*sizeof(char));
	SAPpstat = (char *) malloc(100*sizeof(char));
	MRPpstat = (char *) malloc(100*sizeof(char));
	sloc1_type = (char *) malloc(20*sizeof(char));
	sloc2_type = (char *) malloc(20*sizeof(char));
    //tc_strcpy(sap_proc_type,"");
    //tc_strcpy(sap_spproc_type,"");
	tc_strcpy(SAPpstat,"");
	tc_strcpy(MRPpstat,"");
	
	SETCHAR(eMatnr.Matnr,InpPrt_strDup);
    SETCHAR(eWerks.WerksD,plantcode);
	
    RfcRc = export_CSpastat(hRfc
				,&eMatnr
				,&eWerks
				,&iMrpView
				,&iView
				,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\n In RFC_OK[GetCSPstat] case..!!\n");fflush(stdout);
			GETCHAR(iMrpView.PROC_TYPE, sap_proc_type);
			GETCHAR(iMrpView.SPPROCTYPE, sap_spproc_type);
			GETCHAR(iMrpView.ISS_ST_LOC, sloc1_type);
			GETCHAR(iMrpView.SLOC_EXPRC, sloc2_type);

			GETCHAR(iView.MAINT_STAT, SAPpstat);
			SAPpstat[14] = '\0';

			GETCHAR(iMrpView.MAINT_STAT, MRPpstat);
			MRPpstat[14] = '\0';
			
			printf("\n In Function[GetCSPstat] ---> sap_proc_type: [%s]    sap_spproc_type: [%s]    SAPpstat: [%s]    MRPpstat: [%s]\n",sap_proc_type,sap_spproc_type,SAPpstat,MRPpstat);
            printf("\n In Function[GetCSPstat] ---> sloc1_type: [%s]    sloc2_type: [%s]\n",sloc1_type,sloc2_type);			
		break;
		
		case RFC_EXCEPTION:
			printf("\n RFC Exception: [%s]",xException);fflush(stdout);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\n System Exception Raised..!!\n");fflush(stdout);
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\n Failure..!!\n");fflush(stdout);
			exit(0);
		break;
		default:
			printf("\n Other Failure..!!\n");fflush(stdout);
			exit(0);
	}
	
    RfcClose(hRfc);
    return 0;
}

FetchPlantSpecificData(char* plantcode)
{
	char	*DMLNo			= NULL;
	char	*PlantSuffix	= NULL;
	char	*SAPLivFlg		= NULL;
	
	int     n_entry			= 3;
	int     p_entry			= 2;
	int		ContObjCnt		= 0;

	tag_t   PlantCodeQryTag     = NULLTAG;
	tag_t   MakeBuyQryTag		= NULLTAG;
	tag_t   PlantDataQryTag     = NULLTAG;
	tag_t   *ContorlObjTag     = NULLTAG;

	char    *qry_entryApl[3]  = {"SYSCD","SUBSYSCD","Information-1"};
	char    *qry_entryStd[3]  = {"SYSCD","SUBSYSCD","Information-2"};

	char    *qry_entryMake[2] = {"SYSCD","SUBSYSCD"};

	PlantSuffix  = strtok ( NULL, "_" );
	
	if(QRY_find("Control Objects...", &PlantCodeQryTag));
	if(PlantCodeQryTag)
	{
		printf("\n Function[FetchPlantSpecificData] Found Query[Control Objects...]!!\n"); fflush(stdout);
		char *qry_MakeValue[2] = {"MAKEBUY",plantcode};
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_MakeValue,&ContObjCnt,&ContorlObjTag));
		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&Plant_StoreLoc);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&Plant_MakeBuy);
			printf("\n Function[FetchPlantSpecificData]: Plant Code: [%s]	  Plant_MakeBuy: [%s]	  Plant_StoreLoc: [%s]\n",plantcode,Plant_MakeBuy,Plant_StoreLoc);fflush(stdout);
		}
		else
		{
			printf("\n Function[FetchPlantSpecificData]: Plant Code: [%s] does not have entry in Control Object[MAKEBUY] hence exiting..!!\n",plantcode);fflush(stdout);
			goto CLEANUP;
		}

		char *qry_PlantValue[2] = {"PLANTDATA",plantcode};
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_PlantValue,&ContObjCnt,&ContorlObjTag));
		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&profit_centre2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&plan_calendar2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&overhd_grp2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&origin_group2);

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);
			tc_strdup(plan_calendar2,&plan_calendar);
			tc_strdup(overhd_grp2,&overhd_grp);
			tc_strdup(origin_group2,&origin_group);

			printf("\n Function[FetchPlantSpecificData]: Plant code:  [%s]",plantcode);
			printf("\n Function[FetchPlantSpecificData]: Profit_Centre:  [%s]",profit_centre_sap);
			printf("\n Function[FetchPlantSpecificData]: Plan_Calendar:  [%s]",plan_calendar);
			printf("\n Function[FetchPlantSpecificData]: Overhd_Group:  [%s]",overhd_grp);
			printf("\n Function[FetchPlantSpecificData]: Origin_Group:  [%s]",origin_group);
		}
	}

	CLEANUP:
	return ContObjCnt;
}

BapiLogon()
{
	static RFC_OPTIONS RfcOptions;
	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;
	tag_t SapServerQry = NULLTAG;
	tag_t *SSQObjTags = NULLTAG;
	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char *two_fields[2] = {"SYSCD","SUBSYSCD"};
	if(QRY_find("Control Objects...", &SapServerQry));
	if(SapServerQry)
	{
		printf("\n Found Control Objects[SAPSERVER]..!!\n"); fflush(stdout);
		char *two_value[2] = {"SAPCON",iSapServer};
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));
		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi(SSSysnr);
			printf("\n Connecting to SAP Server:  [%s]\n",iSapServer);fflush(stdout);

			RfcOptions.destination = SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname = SSHostName;
			RfcConnoptR3only.gateway_host = SSHostName;
			RfcConnoptR3only.gateway_service = SSGateway;
			RfcConnoptR3only.sysnr = nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\n SAP Server: [%s] details not found exiting..!!\n",iSapServer);fflush(stdout);
			exit(0);
		}

		printf("\n Connecting to:  [%s] [%s] [%s]",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\n ERROR RECEIVED CPIC-ERROR..!!\n");fflush(stdout);
			exit(0);
		}
		else
		{
			printf("\n Connected with SAP Server..!!\n");fflush(stdout);
			RfcEnvironment(&RfcEnv);
		}
	}
	return hRfc;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *LCState = NULL;
	LCState = (char *) malloc(50*sizeof(char));
	int n_entries = 2;
	static RFC_RC RfcRc;
	plantcode=(char *) malloc (500 * sizeof(char));
	sap_proc_type = (char *)malloc(500 * sizeof(char));
	sap_spproc_type = (char *)malloc(500 * sizeof(char));
	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	profit_centre_sap = (char *)malloc(500 * sizeof(char));
	sloc1_type = (char *) malloc(500*sizeof(char));
	sloc2_type = (char *) malloc(500*sizeof(char));
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf("\n Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf("\n Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	InpPrt_str = ITK_ask_cli_argument("-I=");
	InpPlnt_str = ITK_ask_cli_argument("-J=");
	
	trimwhitespace(InpPrt_str);
	trimwhitespace(InpPlnt_str);
	if(InpPrt_str!=NULL)tc_strdup(InpPrt_str,&InpPrt_strDup);
	if(InpPlnt_str!=NULL)tc_strdup(InpPlnt_str,&InpPlnt_strDup);
	printf(" [1]: Input Part(InpPrt_strDup): [%s]\n",InpPrt_strDup);
	printf(" [2]: Input Plant(InpPlnt_strDup): [%s]\n",InpPlnt_strDup);
	
	if(tc_strcmp(InpPlnt_strDup,"1001")==0)
	{
		tc_strcpy(LCState,"T5_LcsAplpRlzd"); //APLP
	}
	else if(tc_strcmp(InpPlnt_strDup,"1100")==0)
	{
		tc_strcpy(LCState,"T5_LcsAplRlzd"); //APLC
	}
	else if(tc_strcmp(InpPlnt_strDup,"1500")==0)
	{
		tc_strcpy(LCState,"T5_LcsApldRlzd"); //APLD
	}
	else if(tc_strcmp(InpPlnt_strDup,"2001")==0)
	{
		tc_strcpy(LCState,"T5_LcsApljRlzd"); //APLJ
	}
	else if(tc_strcmp(InpPlnt_strDup,"3001")==0)
	{
		tc_strcpy(LCState,"T5_LcsApllRlzd"); //APLL
	}
	else if(tc_strcmp(InpPlnt_strDup,"3100")==0)
	{
		tc_strcpy(LCState,"T5_LcsApluRlzd"); //APLU
	}
	else if(tc_strcmp(InpPlnt_strDup,"E201")==0) 
	{
		tc_strcpy(LCState,"T5_LcsAplaRlzd"); //APLA
	}
	else if(tc_strcmp(InpPlnt_strDup,"7501")==0) 
	{
		tc_strcpy(LCState,"T5_LcsAplsRlzd"); //APLS
	}
	else if(tc_strcmp(InpPlnt_strDup,"1140")==0) 
	{
		tc_strcpy(LCState,"T5_LcsAplvRlzd"); //APLV
	}
	else
	{
		printf(" Plant Code Invalid..!!\n");fflush(stdout);
	}
	
	tag_t QryTag = NULLTAG;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};
	int resultcount = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t LatestRev = NULLTAG;
	char* LatRevName = NULL;
	char* OwnerName = NULL;
	char* OwnerNameDup = NULL;
	char* PrtRev = NULL;
	char* PrtRevDup = NULL;
	char* PartRelStatus = NULL;
	char* Part_No = NULL;
	char* PPLM_CS = NULL;
	char* PPLM_SLOC = NULL;
	
	ITK_CALL(QRY_find2("Driver VC Query",&QryTag));
	char *qry_entries[] = {"Item ID","Release Status"};
	qry_values[0] = InpPrt_strDup;
    qry_values[1] = LCState;
	ITK_CALL(QRY_execute_with_sort(QryTag, n_entries, qry_entries, qry_values, num_to_sort, keysAttr, sort_order, &resultcount, &titemobj_results));
	if(resultcount > 0)
	{
		LatestRev = titemobj_results[0];
		ITK_CALL(AOM_ask_value_string(LatestRev,"object_string",&LatRevName));
		ITK_CALL(AOM_UIF_ask_value(LatestRev,"owning_user",&OwnerName));
	    tc_strdup(OwnerName,&OwnerNameDup);
	    ITK_CALL(AOM_ask_value_string(LatestRev,"item_revision_id",&PrtRev));
	    PrtRevDup=strtok(PrtRev,";");
		ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));
		ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&Part_No));
		
		printf("\n Part No: [%s]\n",Part_No);fflush(stdout);
		printf("\n Part Revision: [%s]\n",PrtRevDup);fflush(stdout);
		printf("\n Part Details: [%s]\n",LatRevName);fflush(stdout);
		printf("\n Owner Name: [%s]\n",OwnerNameDup);fflush(stdout);
		printf("\n Release Status: [%s]\n",PartRelStatus);fflush(stdout);
		
		if(FetchPlantSpecificData(InpPlnt_strDup)>0)
		{
			printf("\n Got Plant Specific Data..!!\n");fflush(stdout);
		}
		else
		{
			printf("\n Error in Fetching Plant Specific Data..!!\n");fflush(stdout);
			goto CLEANUP;
		}
		tc_strdup(InpPlnt_strDup,&plantcode);
		printf("\n Function[1]: GetCSPstat() Start..!!\n");fflush(stdout);
	    tc_strcpy(sap_proc_type,"");
	    tc_strcpy(sap_spproc_type,"");
	    tc_strcpy(SAPpstat,"");
	    tc_strcpy(MRPpstat,"");
        GetCSPstat(/*Part_No*/);
		printf("\n Function[1]: GetCSPstat() End..!!\n");fflush(stdout);
		
		printf("\n Function[2]: TC_PartCS() Start..!!\n");fflush(stdout);
		PPLM_CS = TC_PartCS(LatestRev, plantcode);
		printf("\n Function[2]: TC_PartCS() End..!!\n");fflush(stdout);
		printf("\n Function[3]: TC_PartSLOC() Start..!!\n");fflush(stdout);
		PPLM_SLOC = TC_PartSLOC(LatestRev, plantcode);
		printf("\n Function[3]: TC_PartSLOC() End..!!\n");fflush(stdout);
		
		printf("\n#---------------------------------------------------------#");fflush(stdout);
		printf("\n Part PLM CS Response(PPLM_CS): [%s]", PPLM_CS);fflush(stdout);
		printf("\n Part PLM SLOC Response(PPLM_SLOC): [%s]", PPLM_SLOC);fflush(stdout);
		printf("\n#---------------------------------------------------------#");fflush(stdout);
		
	}
	else
	{
		printf("\n Latest Revision Not Found..!!");fflush(stdout);
	}

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_SAPPartInfo.c
* // ./linkitk -o tm_SAPPartInfo tm_SAPPartInfo.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_SAPPartInfo/tm_SAPPartInfo .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_SAPPartInfo/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_SAPPartInfo/usage.txt .
* // ./tm_SAPPartInfo -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -I="52186470M10108" -J="2001"
* // ./tm_SAPPartInfo -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I="52186470M10108" -J="2001"
*
***************************************************************************/