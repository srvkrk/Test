/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Particular Design Revision & Check First Level child(BVR) Present or Not   
*  File Name    :   tm_BVR_status.c
*  Created on   :   Sep 19th, 2023
*  Usage        :   tm_BVR_status
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     19/09/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}
;

int BVR_Status(char* Vehicle,char* VehicleRS,char* TCEBOM,FILE* VCReport)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	//int subrulefound = 0;
	//tag_t* subclosurerule = NULL;
	//tag_t sub_close_tag = NULLTAG;
	//char** subrulename = NULL;
    //char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubRevision = NULL;
	char* ctopSubRevisionDup = NULL;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char TCUAChldCnt[10];
	char *fremark= (char *) malloc(400*sizeof(char));
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	if(topchildrev != NULLTAG)
    {
			
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		ITK_CALL(CFM_find("Latest Working", &topsubrule))
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));	
		/* ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n No of Rule Found --------> %d\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout); */
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			printf(" Part Item ID Value After Dup: [%s]\n", ctopSubItem_Id);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubRevision));
			if(tc_strlen(ctopSubRevision)>0)
			{
				tc_strdup(ctopSubRevision,&ctopSubRevisionDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubRevisionDup);
				printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubRevisionDup);
			printf(" Part Rev & Seq Value After Dup: [%s]\n", ctopSubRevisionDup);fflush(stdout);
			
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf(" No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf(" --------------------- C H I L D   P R E S E N T ------------------------\n");fflush(stdout);
				tc_strcpy(fremark,"OK");
		        printf(" Item ID: [%s]\n", Vehicle);fflush(stdout);
		        printf(" Item Rev & Seq: [%s]\n", VehicleRS);fflush(stdout);
		        printf(" TCE BOM: [%s]\n", TCEBOM);fflush(stdout);
				tostring(TCUAChldCnt, itopSubNumber_Child);fflush(stdout);
		        printf(" TCUA BOM: [%s]\n", TCUAChldCnt);fflush(stdout);
				printf(" Status: [%s]\n", fremark);fflush(stdout);
		        printf(" -------------------------------------------------------------------------\n");
				fprintf(VCReport,"%s,%s,%s,%s,%s\n",Vehicle,VehicleRS,TCEBOM,TCUAChldCnt,fremark);fflush(VCReport);
			}
			else
			{
				printf(" --------------------- C H I L D   N O T   P R E S E N T ------------------------\n");fflush(stdout);
				tc_strcpy(fremark,"Not_OK");
		        printf(" Item ID: [%s]\n", Vehicle);
		        printf(" Item Rev & Seq: [%s]\n", VehicleRS);
		        printf(" TCE BOM: [%s]\n", TCEBOM);
		        printf(" TCUA BOM: [%s]\n", "0");
				printf(" Status: [%s]\n", fremark);fflush(stdout);
		        printf(" -------------------------------------------------------------------------\n");
				fprintf(VCReport,"%s,%s,%s,%s,%s\n",Vehicle,VehicleRS,TCEBOM,"0",fremark);fflush(VCReport);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *Part_item_id = NULL;
	char *item_id_str = NULL;
	char *item_revseq_str = NULL;
	char *item_tcebom_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_strDup = NULL;
    char *item_tcebom_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t PropName_AttrID = NULLTAG;
	int i = 0;
	char *RptFile= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	char *remarks= (char *) malloc(400*sizeof(char));
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf(" Generating Report File Name..!!\n");fflush(stdout);
	tc_strcpy(RptFile,"BVR_Status_Rpt_File");
	//tc_strcpy(RptFile,"/tmp/");
	//tc_strcat(RptFile,"BVR_Status_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf(" Report File Name: [%s]\n", RptFile);fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");
	fpOutput_file = fopen(RptFile, "w");
 
    fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ B V R   S T A T U S   C H E C K ~~~~~~~~~~~~~~~");fflush(fpOutput_file);
    fprintf(fpOutput_file,"\n Part_No, Rev_Seq, TCE_BOM, TCUA_BOM, Status\n");fflush(fpOutput_file);  

	if((fpPart_List != NULL) && (fpOutput_file != NULL))
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		printf(" Output_File Opened..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_revseq_str=strtok(NULL,"^");
			item_tcebom_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_revseq_str!=NULL)tc_strdup(item_revseq_str,&item_revseq_strDup);
			if(item_tcebom_str!=NULL)tc_strdup(item_tcebom_str,&item_tcebom_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_revseq_strDup!=NULL)trimwhitespace(item_revseq_strDup);
			if(item_tcebom_strDup!=NULL)trimwhitespace(item_tcebom_strDup);
			
			printf(" Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf(" Part RevSeq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			printf(" Part TCE BOM Count(item_tcebom_strDup): [%s]\n",item_tcebom_strDup);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);	
				if(n_itemobj_found > 0)
				{
					printf(" Function1: First Level Child Expansion Start..!!\n");fflush(stdout);
					BVR_Status(item_id_strDup,item_revseq_strDup,item_tcebom_strDup,fpOutput_file);
					printf(" Function1: First Level Child Expansion End..!!\n");fflush(stdout);
				}
				else
				{
					printf(" Design Revision Not Present: Print Start..!!\n");fflush(stdout);
					tc_strcpy(remarks,"Not_OK");
					printf(" ----------- D E S I G N - R E V I S I O N    N O T   P R E S E N T -------------\n");fflush(stdout);
		            printf(" Item ID: [%s]\n", item_id_strDup);fflush(stdout);
		            printf(" Item Rev & Seq: [%s]\n", item_revseq_strDup);fflush(stdout);
		            printf(" TCE BOM: [%s]\n", item_tcebom_strDup);fflush(stdout);
		            printf(" TCUA BOM: [%s]\n", "Revesion_Not_Present");fflush(stdout);
					printf(" Status: [%s]\n", remarks);fflush(stdout);
		            printf(" -------------------------------------------------------------------------\n");
					fprintf(fpOutput_file,"%s,%s,%s,%s,%s\n",item_id_strDup,item_revseq_strDup,item_tcebom_strDup,"Revesion_Not_Present",remarks);fflush(fpOutput_file);
					printf(" Design Revision Not Present: Print End..!!\n");fflush(stdout);
				}
			}
		    else
			{
				printf(" Design Revision Query Tag Not Found..!!\n");fflush(stdout);
			}
			if (titemobj_results)
			{
				MEM_free(titemobj_results);
			}		

		}
	}
	else 
	{
		printf("\n Input_File is NULL or Output_File Not Opened..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_BVR_status.c
* // ./linkitk -o tm_BVR_status tm_BVR_status.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BVR_Status_Check/tm_BVR_status .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BVR_Status_Check/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BVR_Status_Check/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BVR_Status_Check/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BVR_Status_Check/SendEmail.sh .
* // tm_BVR_status -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_BVR_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_BVR_status -u=loader -p=loader123 -g=dba
*
***************************************************************************/