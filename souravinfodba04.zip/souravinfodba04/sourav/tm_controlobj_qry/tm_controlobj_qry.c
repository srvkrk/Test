/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   SA
*  Description  :   Query Control Object & Print Information
*  File Name    :   tm_controlobj_qry.c
*  Created on   :   March 10th, 2023
*  Usage        :   tm_controlobj_qry -sys=<SYSCD> -subsys=<SUBSYSCD>
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     10/03/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	char* cError = NULL;
	char* username = NULL;
	char* cSYSCD = NULL;
	char* cSUBSYSCD = NULL;
	int n_entries = 3;
	int n_ctrlobj_found = 0;
	char *t5user_inf1 = NULL;
	char *t5user_inf2 = NULL;
	char *t5user_inf3 = NULL;
	char *t5user_inf4 = NULL;
	char *t5user_inf5 = NULL;
	char *t5user_inf6 = NULL;
	char *t5user_inf7 = NULL;
	char *t5user_inf8 = NULL;
	char *t5user_inf9 = NULL;
	char *t5user_inf10 = NULL;
	tag_t tuser = NULLTAG;
	tag_t tCtrlobj = NULLTAG;
	tag_t* tctrlobj_results = NULLTAG;
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 3)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			ITK_CALL(ITK_auto_login());
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			cSYSCD = ITK_ask_cli_argument("-sys=");
			cSUBSYSCD = ITK_ask_cli_argument("-subsys=");
			ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
			printf("\n Return Value From Control Object Query API is --------> %d", iFail);fflush(stdout);
			if(tCtrlobj!=NULLTAG)
			{
			   printf("\n Control Object Query Found Successfully...");
			   char *cEntries[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
			   char *cValues[3]  = {cSYSCD,cSUBSYSCD,"0"};
			   ITK_CALL(QRY_execute(tCtrlobj, n_entries, cEntries, cValues, &n_ctrlobj_found, &tctrlobj_results));
			   printf("\n Return Value From Control Object Query Execute API is --------> %d", iFail);fflush(stdout);
			   printf("\n No of Control Object Found --------> %d\n",n_ctrlobj_found);fflush(stdout);
			   if(n_ctrlobj_found>0)
			   {
				
					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo1", &t5user_inf1));
					printf("\n User Information1 Value --------> %s\n",t5user_inf1);fflush(stdout);

					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo2", &t5user_inf2));
					printf("\n User Information2 Value --------> %s\n",t5user_inf2);fflush(stdout);

                    ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo3", &t5user_inf3));
					printf("\n User Information3 Value --------> %s\n",t5user_inf3);fflush(stdout);

					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo4", &t5user_inf4));
					printf("\n User Information4 Value --------> %s\n",t5user_inf4);fflush(stdout);

					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo5", &t5user_inf5));
					printf("\n User Information5 Value --------> %s\n",t5user_inf5);fflush(stdout);

					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo6", &t5user_inf6));
					printf("\n User Information6 Value --------> %s\n",t5user_inf6);fflush(stdout);

					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo7", &t5user_inf7));
					printf("\n User Information7 Value --------> %s\n",t5user_inf7);fflush(stdout);

					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo8", &t5user_inf8));
					printf("\n User Information8 Value --------> %s\n",t5user_inf8);fflush(stdout);

					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo9", &t5user_inf9));
					printf("\n User Information9 Value --------> %s\n",t5user_inf9);fflush(stdout);

					ITK_CALL(AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo10", &t5user_inf10));
					printf("\n User Information10 Value --------> %s\n",t5user_inf10);fflush(stdout);
			    }
				else
				{
					printf("\n Sorry! No Control Object Found...\n");fflush(stdout);
				}
                if (tctrlobj_results)
			    {
				    MEM_free(tctrlobj_results);
			    }
			}
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}


