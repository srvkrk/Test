/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   This utility takes item_id as input from file and queries it into teamcenter & change it's Group ID from dba to ERC_Designers_Group   
*  File Name    :   tm_Change_Groupid.c
*  Created on   :   Jan 11th, 2024
*  Usage        :   tm_Change_Groupid
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     11/01/2024                 Sourav Karak
***************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>


#define WSO_where_ref_any_depth   -1
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


int                     ifail                           = ITK_ok;
FILE            *output                         = NULL;

int read_value_from_file(char*);
int get_object(char*);
int get_owning_user_and_group(tag_t);
static void report_referencers_of_workspaceobject(tag_t wso);

void print_requirement()
{
        printf(
        "\nHELP:\n"
        "tm_Change_Groupid -u=<username> -pf=<password> -g=<group> -file=<filename>\n"
        "--------------------------------------------------------------------\n\n"
        );fflush(stdout);
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. It checks for the proper Usr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
        int                     a;
        char                    * userid                                        = NULL;
        char                    * password                                      = NULL;
        char                    * group                                         = NULL;
        char                    * Filename                                      = NULL;

        userid                  = ITK_ask_cli_argument("-u=");
        password                = ITK_ask_cli_argument("-pf=");
        group                   = ITK_ask_cli_argument("-g=");
        Filename                = ITK_ask_cli_argument("-file=");

        char                    Data[100]                                       = "";
        char                    outputFile[200]                         = "";

        time_t  now;
        struct  tm when;

        time(&now);
        when = *localtime(&now);

        strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
        sprintf(outputFile,"%s_output.txt",Data);

        if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
        {
                print_requirement();
                return -1;
        }

        ifail = ITK_auto_login();
        //ifail = ITK_init_module(userid, password, group);
        if (ifail != ITK_ok)
        {
                printf("Error in Login to Teamcenter\n");fflush(stdout);
                return ifail;
        }
        else
                {
                        printf("\nLogin Successfull.....!!\n");fflush(stdout);
                        printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
                }
        ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
        {
                printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
                return -1;
        }

        ifail = read_value_from_file(Filename);

        printf("\nEnd of program.....!!\n");fflush(stdout);
        printf("\n*********************\n");fflush(stdout);
        ifail = ITK_exit_module(true);
        return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
        char            *itemid                                 = NULL;
        char            temp[200];

        FILE            * fp                                    = NULL;

        fp = fopen(Filename, "r");
        if (fp != NULL)
        {
                while (fgets(temp, 200, fp)!= NULL)
                {
                        tc_strcpy(temp,stripBlanks(temp));

                        if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
                        {
                                itemid = strtok(temp, "~");
                                printf("\nInput Item_id:%s\n",itemid);fflush(stdout);

                                ifail = get_object(itemid);
                        }
                        printf("***************************************\n");fflush(stdout);
                        tc_strcpy(temp, "");
                }
        }
        else
        {
                printf("File Unable to Open...!!");fflush(stdout);
        }
        fclose(fp);
        return ifail;
}


/********************************************************************************************
    Function:       get_object
    Description:    This function takes the item_id as input and queries into TC and gets item, BV, item_rev, it's BVR, and secondary object.
********************************************************************************************/
int get_object(char* item_id)
{
        int                             i                                                       = 0;
        int                             j                                                       = 0;
        int                             k                                                       = 0;
        int                             bv_count                                        = 0;
        int                             bvr_count                                       = 0;
        int                             sec_count                                       = 0;

        int             relcount        =       0;
        int             ecucount        =       0;
        int             vodcount        =       0;
        int             dcount  =       0;
        int             dfmeacount      =       0;
        int             sparecount      =       0;
        int             vcspec_count    =       0;
        int             cmvrcount       =       0;
        int             refcount        =       0;
        int             relcount1       =       0;
        int             fdjcount        =       0;
        int             esocount        =       0;

        int             doc     = 0;
        int             m = 0;
        int             n = 0;
        int             o = 0;
        int             p       = 0;
        int             q       = 0;
        int             r       = 0;
        int             s       = 0;
        int             t       = 0;
        int             x       = 0;
        int             v       = 0;
        int             eso     = 0;
        int             rendsec_count   = 0;
        int             ren     = 0;
        int             refsec_count    = 0;
        int             ref     = 0;

        tag_t                   item_tag                                        = NULLTAG;
        tag_t                   latest_rev_tag                          = NULLTAG;
        tag_t                   relation                                        = NULLTAG;
        tag_t                   *bv_list                                        = NULL;
        tag_t                   *bvr_list                                       = NULL;
        tag_t                   *sec_objects                            = NULL;
        tag_t                   *rendsec_objects                        = NULL;
        tag_t                   *refsec_objects                 = NULL;

        tag_t   Diago_relation_type             =       NULLTAG;
        tag_t   Chassis_type_relation_type              =       NULLTAG;
        tag_t   ECU_relation_type               =       NULLTAG;
        tag_t   VOD_relation_type               =       NULLTAG;
        tag_t   draw_relation_type              =       NULLTAG;
        tag_t   Dfmea_relation_type             =       NULLTAG;
        tag_t   Ref_dfmearelation_type          =       NULLTAG;
        tag_t   Spare_kit_relation_type         =       NULLTAG;
        tag_t   Vc_spec_relation_type           =       NULLTAG;
        tag_t   Fdj_status_relation_type                =       NULLTAG;
        tag_t   ESO_relation_type               =       NULLTAG;

        tag_t   *ECUObjects             = NULLTAG;
        tag_t   *DiagnoObjects          = NULLTAG;
        tag_t   *ChassisObjects         = NULLTAG;
        tag_t   *VODObjects             = NULLTAG;
        tag_t   *draw_Objects           = NULLTAG;
        tag_t   *DfmeaObjects           = NULLTAG;
        tag_t   *Ref_dfmeObjects                = NULLTAG;
        tag_t   *spare_kitObjects               = NULLTAG;
        tag_t   *Vc_specObjects         = NULLTAG;
        tag_t   *FdjObjects             = NULLTAG;
        tag_t   *CmvrObjects            = NULLTAG;
        tag_t   *EsoObjects             = NULLTAG;

        tag_t   ECUObject               = NULLTAG;
        tag_t   DiagnoObject            = NULLTAG;
        tag_t   ChassisObject           = NULLTAG;
        tag_t   VODObject               = NULLTAG;
        tag_t   D_Object                = NULLTAG;
        tag_t   DfmeaObject             = NULLTAG;
        tag_t   Ref_dfmeObject          = NULLTAG;
        tag_t   spare_kitObject         = NULLTAG;
        tag_t   Vc_specObject   = NULLTAG;
        tag_t   FdjObject       = NULLTAG;
        tag_t   CmvrObject              = NULLTAG;
        tag_t   EsoObject               = NULLTAG;
        tag_t   Diagno_Object   = NULLTAG;
        tag_t   relationrend    = NULLTAG;
        tag_t   relationref     = NULLTAG;
        tag_t   VOD_Object      = NULLTAG;
        tag_t   DObject = NULLTAG;
        tag_t   Dfmea_Object    = NULLTAG;
        tag_t   RefdfmeObject   = NULLTAG;
        tag_t   sparekitObject  = NULLTAG;
        tag_t   VcspecObject    = NULLTAG;
        tag_t   Fdj_Object      = NULLTAG;
        tag_t   EsoRevObject    = NULLTAG;

        char                    *latest_rev_id                          = NULL;

        int n_references = 0;
    int *levels = NULL;
    tag_t *reference_tags = NULL;
    char **relation_type_name = NULL;

        ifail = ITEM_find_item (item_id, &item_tag);
        if(item_tag == NULLTAG)
        {
                printf("Object not found in TC...!!\n");fflush(stdout);
                printf("***************************\n");fflush(stdout);
                return 0;
        }

        ifail = GRM_find_relation_type("T5_HasDiagnosticPartNo",&Diago_relation_type);
        ifail = GRM_find_relation_type("T5_HasChassisTypeNo",&Chassis_type_relation_type);
        ifail = GRM_find_relation_type("T5_CCVCHasECUModule",&ECU_relation_type);
        ifail = GRM_find_relation_type("T5_HasVOD",&VOD_relation_type);
        ifail = GRM_find_relation_type("T5_PartHas4D",&draw_relation_type);
        ifail = GRM_find_relation_type("T5_PartHasDfmea",&Dfmea_relation_type);
        ifail = GRM_find_relation_type("T5_PartHasRef4DDfmea",&Ref_dfmearelation_type);
        ifail = GRM_find_relation_type("T5_HasSpareKit",&Spare_kit_relation_type);
        ifail = GRM_find_relation_type("T5_VCSpec",&Vc_spec_relation_type);
        ifail = GRM_find_relation_type("T5_AssmhasFDJ",&Fdj_status_relation_type);
        ifail = GRM_find_relation_type("T5_PartEsoRel",&ESO_relation_type);

        printf("\nUpdating item");fflush(stdout);
        ifail = get_owning_user_and_group(item_tag);
        CHECK_FAIL;

        printf("\nUpdating bom_view");fflush(stdout);
        ifail = ITEM_list_bom_views (item_tag, &bv_count, &bv_list);
        printf("\nTotal %d Bom_View found...!!\n", bv_count);fflush(stdout);

        for(i=0;i<bv_count;i++)
        {
                ifail = get_owning_user_and_group(bv_list[i]);
                CHECK_FAIL;
        }

        GRM_list_secondary_objects_only(item_tag, Diago_relation_type, &relcount, &DiagnoObjects);
        GRM_list_secondary_objects_only(item_tag, Chassis_type_relation_type, &relcount1, &ChassisObjects);
        printf("\n Digrelcount ==>[%d]",relcount);fflush(stdout);
        printf("\n Chasisrelcount1 ==>[%d]",relcount1);fflush(stdout);
        if(relcount>0)
        {
                for(doc=0;doc<relcount;doc++)
                {
                        DiagnoObject = DiagnoObjects[doc];
                        ITEM_ask_item_of_rev(DiagnoObject,&Diagno_Object);
                        ifail = get_owning_user_and_group(Diagno_Object);
                        ifail = get_owning_user_and_group(DiagnoObject);
                }
        }
        if(relcount1 > 0)
        {
                for(m=0;m<relcount1;m++)
                {
                        ChassisObject = ChassisObjects[m];
                        ifail = get_owning_user_and_group(ChassisObject);
                }

        }

        ifail = ITEM_ask_latest_rev (item_tag, &latest_rev_tag);
        printf("\nUpdating Revision");fflush(stdout);
        ifail = AOM_UIF_ask_value (latest_rev_tag, "item_revision_id", &latest_rev_id);
        printf("\nLatest Rev. found is:%s\n",latest_rev_id);fflush(stdout);

        ifail = get_owning_user_and_group(latest_rev_tag);
        CHECK_FAIL;

        printf("\nUpdating bom_view Revision");fflush(stdout);
        ifail = ITEM_rev_list_bom_view_revs (latest_rev_tag, &bvr_count, &bvr_list);
        printf("\nTotal %d Bom_View Revision found...!!\n", bvr_count);fflush(stdout);

        for(j=0;j<bvr_count;j++)
        {
                ifail = get_owning_user_and_group(bvr_list[j]);
                CHECK_FAIL;
        }

        ifail = GRM_find_relation_type ("IMAN_specification", &relation);
        ifail = GRM_list_secondary_objects_only (latest_rev_tag, relation, &sec_count, &sec_objects);
        CHECK_FAIL;
        printf("\nTotal %d sec_object found...!!\n", sec_count);fflush(stdout);

        printf("\nUpdating datasets\n");fflush(stdout);
        for(k=0;k<sec_count;k++)
        {
                ifail = get_owning_user_and_group(sec_objects[k]);
                CHECK_FAIL;
        }

        ifail = GRM_find_relation_type ("IMAN_Rendering", &relationrend);
        ifail = GRM_list_secondary_objects_only (latest_rev_tag, relationrend, &rendsec_count, &rendsec_objects);
        CHECK_FAIL;
        printf("\nTotal %d sec_object found...!!\n", rendsec_count);fflush(stdout);

        printf("\nUpdating datasets\n");fflush(stdout);
        for(ren=0;ren<rendsec_count;ren++)
        {
                ifail = get_owning_user_and_group(rendsec_objects[ren]);
                CHECK_FAIL;
        }

        ifail = GRM_find_relation_type ("IMAN_reference", &relationref);
        ifail = GRM_list_secondary_objects_only (latest_rev_tag, relationref, &refsec_count, &refsec_objects);
        CHECK_FAIL;
        printf("\nTotal %d sec_object found...!!\n", refsec_count);fflush(stdout);

        printf("\nUpdating datasets\n");fflush(stdout);
        for(ref=0;ref<refsec_count;ref++)
        {
                ifail = get_owning_user_and_group(refsec_objects[ref]);
                CHECK_FAIL;
        }

        GRM_list_secondary_objects_only(latest_rev_tag, ECU_relation_type, &ecucount, &ECUObjects);
        GRM_list_secondary_objects_only(latest_rev_tag, VOD_relation_type, &vodcount, &VODObjects);
        GRM_list_secondary_objects_only(latest_rev_tag, draw_relation_type, &dcount, &draw_Objects);
        GRM_list_secondary_objects_only(latest_rev_tag, Dfmea_relation_type, &dfmeacount, &DfmeaObjects);
        GRM_list_secondary_objects_only(latest_rev_tag, Ref_dfmearelation_type, &refcount, &Ref_dfmeObjects);
        GRM_list_secondary_objects_only(latest_rev_tag, Spare_kit_relation_type, &sparecount, &spare_kitObjects);
        GRM_list_secondary_objects_only(latest_rev_tag, Vc_spec_relation_type, &vcspec_count, &Vc_specObjects);
        GRM_list_secondary_objects_only(latest_rev_tag, Fdj_status_relation_type, &fdjcount, &FdjObjects);
        GRM_list_secondary_objects_only(latest_rev_tag, ESO_relation_type, &esocount, &EsoObjects);

        printf("\n ecucount ==>[%d]",ecucount);fflush(stdout);
        printf("\n vodcount ==>[%d]",vodcount);fflush(stdout);
        printf("\n 4dcount ==>[%d]",dcount);fflush(stdout);
        printf("\n dfmeacount ==>[%d]",dfmeacount);fflush(stdout);
        printf("\n refcount ==>[%d]",refcount);fflush(stdout);
        printf("\n sparecount ==>[%d]",sparecount);fflush(stdout);
        printf("\n vcspec_count ==>[%d]",vcspec_count);fflush(stdout);
        printf("\n fdjcount ==>[%d]",fdjcount);fflush(stdout);
        printf("\n esocount ==>[%d]",esocount);fflush(stdout);

        if(ecucount>0)
        {
                for(n=0;n<ecucount;n++)
                {
                        ECUObject = ECUObjects[n];
                        ifail = get_owning_user_and_group(ECUObject);
                }
        }

        if(vodcount>0)
        {
                for(o=0;o<vodcount;o++)
                {
                        VODObject = VODObjects[o];
                        ITEM_ask_item_of_rev(VODObject,&VOD_Object);
                        ifail = get_owning_user_and_group(VOD_Object);
                        ifail = get_owning_user_and_group(VODObject);
                }
        }

        if(dcount>0)
        {
                for(p=0;p<dcount;p++)
                {
                        D_Object = draw_Objects[p];
                        ITEM_ask_item_of_rev(D_Object,&DObject);
                        ifail = get_owning_user_and_group(DObject);
                        ifail = get_owning_user_and_group(D_Object);
                }
        }

        if(dfmeacount>0)
        {
                for(q=0;q<dfmeacount;q++)
                {
                        DfmeaObject = DfmeaObjects[q];
                        ITEM_ask_item_of_rev(DfmeaObject,&Dfmea_Object);
                        ifail = get_owning_user_and_group(Dfmea_Object);
                        ifail = get_owning_user_and_group(DfmeaObject);
                }
        }

        if(refcount>0)
        {
                for(r=0;r<refcount;r++)
                {
                        Ref_dfmeObject = Ref_dfmeObjects[r];
                        ITEM_ask_item_of_rev(Ref_dfmeObject,&RefdfmeObject);
                        ifail = get_owning_user_and_group(RefdfmeObject);
                        ifail = get_owning_user_and_group(Ref_dfmeObject);
                }
        }

        if(sparecount>0)
        {
                for(s=0;s<sparecount;s++)
                {
                        spare_kitObject = spare_kitObjects[s];
                        ITEM_ask_item_of_rev(spare_kitObject,&sparekitObject);
                        ifail = get_owning_user_and_group(sparekitObject);
                        ifail = get_owning_user_and_group(spare_kitObject);
                }
        }

        if(vcspec_count>0)
        {
                for(t=0;t<vcspec_count;t++)
                {
                        Vc_specObject = Vc_specObjects[t];
                        ITEM_ask_item_of_rev(Vc_specObject,&VcspecObject);
                        ifail = get_owning_user_and_group(VcspecObject);
                        ifail = get_owning_user_and_group(Vc_specObject);
                }
        }

        if(fdjcount>0)
        {
                for(x=0;x<fdjcount;x++)
                {
                        FdjObject = FdjObjects[x];
                        ITEM_ask_item_of_rev(FdjObject,&Fdj_Object);
                        ifail = get_owning_user_and_group(Fdj_Object);
                        ifail = get_owning_user_and_group(FdjObject);
                }
        }

        AOM_ask_value_tags(latest_rev_tag,"t5_VehForCmvr",&cmvrcount,&CmvrObjects);
        printf("\n cmvrcount ==>[%d]",cmvrcount);fflush(stdout);
        if(cmvrcount>0)
        {
                for(v=0;v<cmvrcount;v++)
                {
                        CmvrObject = CmvrObjects[v];
                        ifail = get_owning_user_and_group(CmvrObject);
                }
        }

        if(esocount>0)
        {
                for(eso=0;eso<esocount;eso++)
                {
                        EsoObject = EsoObjects[eso];
                        ifail = ITEM_ask_latest_rev (EsoObject, &EsoRevObject);
                        ifail = get_owning_user_and_group(EsoObject);
                        ifail = get_owning_user_and_group(EsoRevObject);
                }
        }

        report_referencers_of_workspaceobject(latest_rev_tag);
        CHECK_FAIL;

        MEM_free(sec_objects);
        MEM_free(bv_list);
        MEM_free(latest_rev_id);
        MEM_free(bvr_list);


        return ifail;
}


static void report_referencers_of_workspaceobject(tag_t wso)
{
    int n_references = 0, *levels = NULL;
    tag_t *reference_tags = NULL;
    char **relations = NULL;
        int ii = 0;
    ifail = WSOM_where_referenced(wso, -1 , &n_references, &levels,&reference_tags,&relations);

    printf("\n n_references: %d \n", n_references);fflush(stdout);
    for (ii = 0; ii < n_references; ii++)
    {
        char *id = NULL;
        ifail = WSOM_ask_object_id_string(reference_tags[ii], &id);
                //CHECK_FAIL;

        char  type[WSO_name_size_c + 1] = "";
        ifail = WSOM_ask_object_type(reference_tags[ii], type);
                //CHECK_FAIL;
        if ( (relations[ii] != NULL) && (strlen(relations[ii]) > 0 ) )
        {
            printf("   %s (%s) - Relation: %s \n", id, type, relations[ii]);fflush(stdout);
        }
        else printf("   %s (%s) \n", id, type);fflush(stdout);
        MEM_free(id);
    }
    MEM_free(levels);
    MEM_free(reference_tags);
    MEM_free(relations);
}




/********************************************************************************************
    Function:       get_owning_user_and_group
    Description:    This function takes the object_tag as input and get owning user and owning group of perticular object and change it's ownership.
********************************************************************************************/
int get_owning_user_and_group(tag_t object_tag)
{
        tag_t                   new_group_tag                           = NULLTAG;
        tag_t                   owning_user_tag                         = NULLTAG;
        tag_t                   owning_group_tag                        = NULLTAG;

        char                    *obj_owning_user                        = NULL;
        char                    *obj_owning_group                       = NULL;

        ifail = AOM_ask_owner (object_tag, &owning_user_tag);
        ifail = AOM_ask_group (object_tag, &owning_group_tag);

        ifail = AOM_UIF_ask_value (object_tag, "owning_user", &obj_owning_user);
        printf("\nObject owning user:%s",obj_owning_user);fflush(stdout);

        ifail = AOM_UIF_ask_value (object_tag, "owning_group", &obj_owning_group);
        printf("\nObject owning group:%s\n",obj_owning_group);fflush(stdout);

        ifail = SA_find_group("ERC_Designers_Group",&new_group_tag);

        if(tc_strcmp(obj_owning_user, "loader (loader)") == 0 && tc_strcmp(obj_owning_group, "dba") == 0)
        {
                ifail = AOM_set_ownership(object_tag, owning_user_tag, new_group_tag);
                //CHECK_FAIL;
                printf("\nGroup updated...!!\n");fflush(stdout);
        }
        else
        {
                printf("\nRequired owning user or group not found...!!\n");fflush(stdout);
        }
        MEM_free(obj_owning_user);
        MEM_free(obj_owning_group);

        return ifail;
}


/***************************************************************************
*
* // ./compile tm_Change_Groupid.c
* // ./linkitk -o tm_Change_Groupid tm_Change_Groupid.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Change_GroupID/tm_Change_Groupid .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Change_GroupID/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Change_GroupID/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Change_GroupID/usage.txt .
* // tm_Change_Groupid -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -file=PartList.txt
* // tm_Change_Groupid -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -file=PartList.txt
*
***************************************************************************/