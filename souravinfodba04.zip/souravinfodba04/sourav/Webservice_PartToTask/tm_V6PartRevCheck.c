/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Call WebService During Part Attachment To Task To Check Next Revision Availability in CATIAV6
*  File Name    :   tm_V6PartRevCheck.c
*  Created on   :   Feb 12th, 2024
*  Usage        :   tm_V6PartRevCheck
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/02/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_PartRevSeqFormat(char* PartRS)
{
	printf("\n Inside Function[TC_PartRevSeqFormat]..!!");fflush(stdout);
	//char *FRevSeq = (char *) malloc(400*sizeof(char));
	//char *FRevSeq = NULL;
	//FRevSeq = (char *) MEM_alloc(1000*sizeof(char ));
	printf("\n Input Argument: [%s]", PartRS);fflush(stdout);
	char* temp1 = (char *) malloc(tc_strlen(PartRS)*sizeof(char));
	tc_strcpy(temp1,PartRS);
	char* Rev_Str = NULL;
	char* Seq_Str = NULL;
	char* Rev_StrDup = NULL;
	char* Seq_StrDup = NULL;
	printf("\n Before\n");fflush(stdout);
	Rev_Str=tc_strtok(temp1,";");
	Seq_Str=tc_strtok(NULL,";");
	printf("\n After\n");fflush(stdout);
	printf("\n Revision String: [%s]", Rev_Str);fflush(stdout);
	printf("\n Sequence String: [%s]", Seq_Str);fflush(stdout);
	printf("\n Inside Function1..!!");fflush(stdout);
	if(tc_strlen(PartRS)>0)
	{
		tc_strdup(Rev_Str,&Rev_StrDup);
		tc_strdup(Seq_Str,&Seq_StrDup);
	}
	else
	{
		tc_strdup("",&Rev_StrDup);
		tc_strdup("",&Seq_StrDup);
		printf("\n Part Rev-Seq Value is NULL \n");fflush(stdout);
	}
	trimwhitespace(Rev_StrDup);
	trimwhitespace(Seq_StrDup);
	printf("\n Revision Value After Dup & Trim: [%s]\n", Rev_StrDup);fflush(stdout);
	printf("\n Sequence Value After Dup & Trim: [%s]\n", Seq_StrDup);fflush(stdout);
	char *FRevSeq = (char *) malloc(400*sizeof(char));
	tc_strcpy(FRevSeq,Rev_StrDup);
	tc_strcat(FRevSeq,".");
	tc_strcat(FRevSeq,Seq_StrDup);
	printf("\n Final Revision & Sequence Value: [%s]", FRevSeq);fflush(stdout);
	temp1 = NULL;
	printf("\n Outside Function[TC_PartRevSeqFormat]..!!");fflush(stdout);
	return FRevSeq;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	//char* V6Part_No = NULL;
	//char *V6Part_RevSeq = NULL;
	char *V6Part_No = "548161208231";
	char *V6Part_RevSeq = "NR;4";
	char *revseq = NULL;
	revseq=(char *)MEM_alloc(200);
	char *PartProjCode = NULL;
	char *PartDesGroup = NULL;
	char *ShellCommandLine = NULL;
	ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	char *InputFile= (char *) malloc(50*sizeof(char));
	char *OutputFile= (char *) malloc(50000*sizeof(char));
	char *ResponseFile= (char *) malloc(20*sizeof(char));
	FILE *fpInput_file = NULL;
	FILE *fpResponse_file = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *response_str = NULL;
	char *response_strDup = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	//ITK_CALL(AOM_ask_value_string(secondary_object,"item_id",&V6Part_No));
	//ITK_CALL(AOM_ask_value_string(secondary_object,"item_revision_id",&V6Part_RevSeq));
	//trimwhitespace(V6Part_No);
	//trimwhitespace(V6Part_RevSeq);
	printf("\n Part Number: [%s] \n",V6Part_No);fflush(stdout);

	PartProjCode=subString(V6Part_No,0,4);
	trimwhitespace(PartProjCode);
	printf("\n Part Project Code After Trim:  [%s]", PartProjCode);fflush(stdout);

	PartDesGroup=subString(V6Part_No,4,2);
	trimwhitespace(PartDesGroup);
	printf("\n Part Design Group After Trim:  [%s]", PartDesGroup);fflush(stdout);

	printf("\n Part Revision & Sequence: [%s] \n",V6Part_RevSeq);fflush(stdout);
	revseq = TC_PartRevSeqFormat(V6Part_RevSeq);

	printf("\n Generating New Time Stamp");fflush(stdout);
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time:  [%s]", GenDate);fflush(stdout);
	printf("\n New Time Stamp Generated");fflush(stdout);
		
	printf("\n Generating Input File Name");fflush(stdout);
	tc_strcpy(InputFile,"/tmp/");
	tc_strcat(InputFile,V6Part_No);
	tc_strcat(InputFile,"_");
	tc_strcat(InputFile,"V6Revise_Input");
	tc_strcat(InputFile,"_");
	tc_strcat(InputFile,GenDate);
	tc_strcat(InputFile,".txt");
	printf("\n Input File Name: [%s]", InputFile);fflush(stdout);
	printf("\n Input File Name Generated");fflush(stdout);

	printf("\n Generating Log File Name..!!\n");fflush(stdout);
	tc_strcpy(OutputFile,"/tmp/");
	tc_strcat(OutputFile,V6Part_No);
	tc_strcat(OutputFile,"_");
	tc_strcat(OutputFile,"V6Revise_Output");
	tc_strcat(OutputFile,"_");
	tc_strcat(OutputFile,GenDate);
	tc_strcat(OutputFile,".txt");
	printf("\n Log File Name: [%s] \n", OutputFile);fflush(stdout);
	printf("\n Log File Name Generated..!!\n");fflush(stdout);

	printf("\n Generating Response File Name..!!\n");fflush(stdout);
	tc_strcpy(ResponseFile,"/tmp/");
	tc_strcat(ResponseFile,V6Part_No);
	tc_strcat(ResponseFile,"_");
	tc_strcat(ResponseFile,"V6Revise_Response");
	tc_strcat(ResponseFile,"_");
	tc_strcat(ResponseFile,GenDate);
	tc_strcat(ResponseFile,".txt");
	printf("\n Response File Name: [%s] \n", ResponseFile);fflush(stdout);
	printf("\n Response File Name Generated..!!\n");fflush(stdout);
				
	fpInput_file = fopen(InputFile, "w"); 
	if(fpInput_file == NULL)
	{
		printf("\n Unable to Open Input File on Server: [%s] \n",InputFile);fflush(stdout);
		return ITK_ok;
	}
	else
	{
		printf("\n Input File Opened Successfully..!!\n");fflush(stdout);
		printf("\n Data Write on Input File Start..!!\n");fflush(stdout);
		fprintf(fpInput_file,"%s,%s\n",V6Part_No,revseq);fflush(fpInput_file);
		printf("\n Data Write on Input File End..!!\n");fflush(stdout);
	}
	fclose(fpInput_file);
	printf("\n Input File Closed Successfully..!!\n");fflush(stdout);

	printf("\n Control Object Check STARTED...\n");fflush(stdout);
	tag_t tCtrlobj = NULLTAG;
	tag_t* tPathctrlobj_results = NULLTAG;
	int n_pathentries = 4;
	int n_path_ctrlobj_found = 0;
	char *JarCallPath = NULL;
	char *JarPath = NULL;
	ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
	printf("\n Control Object Query Tag Found Successfully...!!\n");
	char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
	char *cPathValues[4]  = {PartProjCode,PartDesGroup,"V6TaskCntObj","0"};
	ITK_CALL(QRY_execute(tCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tPathctrlobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Control Object Found: [%d]\n",n_path_ctrlobj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_path_ctrlobj_found>0)
	{
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo1", &JarCallPath));
		printf("\n JAR Calling Path: [%s]\n",JarCallPath);fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo2", &JarPath));
		printf("\n JAR Path: [%s]\n",JarPath);fflush(stdout);
		printf("\n Jar Calling Path Control Object Found");fflush(stdout);
		printf("\n JAR CALL: Start");fflush(stdout);
		//tc_strcpy(ShellCommandLine,"/user/uaprodtrl/Sourav/V6PartRevise/V6Revise_Shell.sh");
		//tc_strcpy(ShellCommandLine,"/user/cvprod/Sourav/V6PartRevise/V6Revise_Shell.sh");
		tc_strcpy(ShellCommandLine,JarCallPath);
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,InputFile);
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,OutputFile);
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,ResponseFile);
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,JarPath);
		printf("\n CommandLine: [%s]",ShellCommandLine);fflush(stdout);
		system(ShellCommandLine);
		printf("\n JAR CALL: End");fflush(stdout);
		
		fpResponse_file = fopen(ResponseFile, "r"); 
		if(fpResponse_file == NULL)
		{
			printf("\n Unable to Open Response File on Server:: [%s] \n",ResponseFile);fflush(stdout);
			return ITK_ok;
		}
		else
		{
			printf("\n Response File Opened Successfully..!!\n");fflush(stdout);
			while(fgets(Buffer,MAX_LINE_LENGTH,fpResponse_file)!=NULL)
			{
				response_str=strtok(Buffer,"^");
				
				if(response_str!=NULL)tc_strdup(response_str,&response_strDup);
				if(response_strDup!=NULL)trimwhitespace(response_strDup);
				
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf(" Response(response_strDup): [%s]\n",response_strDup);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				
				if(tc_strcmp(response_strDup,"FALSE")==0)
				{
					printf("\n Not Allowed To Attach As Higher Revision Already Available in CATIAV6\n"); fflush(stdout);
					//EMH_clear_errors();
					//EMH_store_error_s1(EMH_severity_error,ITK_err,"Higher Revision Already Available For the Selected Part in CATIAV6");
					//return ITK_err;
				}
				else
				{
					printf("\n Allow To Attach\n"); fflush(stdout);
					return ITK_ok;
				}
			}
			fclose(fpResponse_file);
			printf("\n Response File Closed Successfully..!!\n");fflush(stdout);	
		}
	}
	else
	{
		 printf("\n Sorry! Jar Calling Path Control Object Found & Project Code & Design Group Not Matched");fflush(stdout);
	}
	
    if (tPathctrlobj_results)
	{
	  MEM_free(tPathctrlobj_results);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_V6PartRevCheck.c
* // ./linkitk -o tm_V6PartRevCheck tm_V6PartRevCheck.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_PartToTask/tm_V6PartRevCheck .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_PartToTask/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_PartToTask/usage.txt .
* // ./tm_V6PartRevCheck -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_V6PartRevCheck -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/