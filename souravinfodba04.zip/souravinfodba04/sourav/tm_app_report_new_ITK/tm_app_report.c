/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   BOM
*  Description  :   Expand PlatForm After Applying SVR Multi Level Module Applicability 
*  File Name    :   tm_app_report.c
*  Created on   :   June 21th, 2023
*  Usage        :   tm_app_report
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     21/06/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -plat=<Platform Name> (Required)\n"
		" -svr=<SVR> (Required)\n"
		" -rrule=<Revision Rule> (Required)\n"
		" -pname=<Plant Name> (Required)\n"
        );	
}

char* TC_PartDesc(char* PNSrch)
{
	trimwhitespace(PNSrch);
	printf("\n Searched Part Number Value After Trim --------> %s\n", PNSrch);fflush(stdout);
	int iFail = 0;
	int n_tags_found = 0;
	tag_t *tags_found = NULLTAG;
	tag_t item_t = NULLTAG;
	const char *attrs[1];
	const char *values[1];
	attrs[0] ="item_id";
	values[0] = PNSrch;
	printf("\n values[0] ---> <%s> \n", values[0]);fflush(stdout);
	iFail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
    printf("\n No of Tag Found: ----> <%d> \n",n_tags_found );fflush(stdout);
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	if(n_tags_found > 0)
	{
        //item_t = tags_found[1];
        //AOM_ask_value_string(item_t,"object_desc",&cItem_Desc);
		AOM_ask_value_string(tags_found[0],"object_desc",&cItem_Desc);
		printf("\n Item Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
		if(tc_strlen(cItem_Desc)>0)
		{
			tc_strdup(cItem_Desc,&cItem_DescDup);
		}
		else
		{
		    tc_strdup("NULL",&cItem_DescDup);
			printf("\n Item Description Value is NULL");fflush(stdout);
		}
		trimwhitespace(cItem_DescDup);
		printf("\n Item Description Value After Dup & Trim --------> %s", cItem_DescDup);fflush(stdout);
		STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
		STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
		STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
		STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
		printf("\n Item Description Final Value --------> %s", cItem_DescDup);fflush(stdout);
		
		if(tc_strlen(cItem_DescDup)>0)
		{
			return cItem_DescDup;
		}
		else
		{
			printf("\n Sorry!! Item Description is Null");fflush(stdout);
		}
		
	}
	else
	{
		printf("\n Sorry!! Query Tag Not Found...");fflush(stdout);
	}
	if (tags_found)
    {
		MEM_free(tags_found);
	}   
}

 int bom_stop_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, char* pcs, FILE* FP_OutputReport, FILE* Veh_OutputReport)
{
		char* cLevel = NULL;
		char* cRev_Name = NULL;
		char* cItem_Id = NULL;
		char* cItemDes = NULL;
		char* cItemDesDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		//char* cPType = NULL;
		//cPType = (char *)malloc(20 * sizeof(char));
		char* cRevision = NULL;
		char* cCS = NULL;
		char* cUOM = NULL;
		char* cQuantity = NULL;
		char* cPacked = NULL;
		char* cDRAR = NULL;
		char* cPart_Type = NULL; 
		int j =0;
		int iFail = ITK_ok;
		int iAttribute = 0;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		//FILE *fpOutput_file = NULL;
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_level_starting_0", &cLevel));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_object_desc", &cItemDes));
			if(tc_strlen(cItemDes)>0)
		    {
			  tc_strdup(cItemDes,&cItemDesDup);
		    }
		    else
		    {
				tc_strdup("",&cItemDesDup);
				printf("\n Part Description Value is NULL");fflush(stdout);
		    }
			trimwhitespace(cItemDesDup);
			printf("\n Part Description Value After Dup & Trim --------> %s", cItemDesDup);fflush(stdout);
			STRNG_replace_str(cItemDesDup,","," ",&cItemDesDup);
			STRNG_replace_str(cItemDesDup,";"," ",&cItemDesDup);
			STRNG_replace_str(cItemDesDup,"\n"," ",&cItemDesDup);
			printf("\n Part Description Final Value --------> %s", cItemDesDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cRevision));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
		    {
			   tc_strdup(cPartType,&cPartTypeDup);
		    }
		    else
		    {
			   tc_strdup("",&cPartTypeDup);
			   printf("\n Part Type Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cPartTypeDup);
		    printf("\n Part Type Value After Dup & Trim --------> %s", cPartTypeDup);fflush(stdout);		
			//ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j],pcs,&cCS));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PunMakeBuyIndicator", &cCS));
		    ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design_t5_uom", &cUOM));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nLevel: %s", cLevel);
			printf("\nID: %s", cItem_Id);
			printf("\nDescriptiom: %s", cItemDesDup);
			printf("\nRev & Seq: %s", cRevision);
			printf("\nType: %s", cPartTypeDup);
			printf("\nCS: %s", cCS);
			printf("\nUOM: %s", cUOM);
			printf("\nQuantity: %s", cQuantity);
			
			printf("\n-------------------------------------------------------------------------");
			fprintf(FP_OutputReport,"%s,%s,%s,%s,%s,%s\n",cLevel,cItem_Id,cItemDesDup,cRevision,cPartTypeDup,cCS,cUOM);fflush(FP_OutputReport);
			fprintf(Veh_OutputReport,"%s,%s,%s\n",cItem_Id,cRevision,cQuantity);fflush(Veh_OutputReport);
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found --------> %d\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				//if((tc_strcmp(cCS,"F") != 0) || (tc_strcmp(cCS,"F18") != 0) || (tc_strcmp(cCS,"F30") != 0) || (tc_strcmp(cCS,"F40") != 0))
				if((tc_strstr(cCS,"F") == NULL) || (tc_strstr(cCS,"F18") == NULL) || (tc_strstr(cCS,"F30") == NULL) || (tc_strstr(cCS,"F40") == NULL))
				{
					printf("\nAs CS is Not F/F18/F30/F40 So, Expansion Going on.....");fflush(stdout);
					bom_stop_sub_child(tSubChild,iNumber_SubChild,pcs,FP_OutputReport,Veh_OutputReport);
				}
				/* else
				{
					printf("\nAs CS is F/F18/F30/F40 So, Expansion Stoped.....");fflush(stdout);
					continue;
				} */
			}
		}
		return iFail;
} 

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, char* pcs, FILE* FP_OutputReport, FILE* Veh_OutputReport)
{
		char* cLevel = NULL;
		char* cRev_Name = NULL;
		char* cItem_Id = NULL;
		char* cItemDes = NULL;
		char* cItemDesDup = NULL;
		char* cItemNewDes = NULL;
		char* cItemNewDesDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		//char* cPType = NULL;
		//cPType = (char *)malloc(20 * sizeof(char));
		char* cRevision = NULL;
		char* cRevisionDup  = NULL;
		//char* cParent = NULL;
		//char* cOwn_Group = NULL;
		//char* cOwn_User = NULL;
		char* cCS = NULL;
		char* cCSDup = NULL;
		char* cUOM = NULL;
		char* cUOMDup = NULL;
		char* cQuantity = NULL;
		//char* cFind_No = NULL;
		char* cPacked = NULL;
		char* cDRAR = NULL;
		char* cPart_Type = NULL; 
		int j =0;
		int iFail = ITK_ok;
		int iAttribute = 0;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* cDesGrp = NULL;
		char* cDesGrpDup = NULL;
		//FILE *fpOutput_file = NULL;
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_level_starting_0", &cLevel));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			cItemDesDup = TC_PartDesc(cItem_Id);
			/* ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_object_desc", &cItemDes));
			if(tc_strlen(cItemDes)>0)
		    {
			  tc_strdup(cItemDes,&cItemDesDup);
		    }
		    else
		    {
				tc_strdup("NULL",&cItemDesDup);
				printf("\n Part Description Value is NULL");fflush(stdout);
		    }
			trimwhitespace(cItemDesDup);
			printf("\n Part Description Value After Dup & Trim --------> %s", cItemDesDup);fflush(stdout);
			STRNG_replace_str(cItemDesDup,","," ",&cItemDesDup);
			STRNG_replace_str(cItemDesDup,";"," ",&cItemDesDup);
			STRNG_replace_str(cItemDesDup,"\n"," ",&cItemDesDup); */
			printf("\n Part Description Final Value --------> %s", cItemDesDup);fflush(stdout);
			
			
			/* ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_object_name", &cItemNewDes));
			if(tc_strlen(cItemNewDes)>0)
		    {
			  tc_strdup(cItemNewDes,&cItemNewDesDup);
		    }
		    else
		    {
				tc_strdup("NULL",&cItemNewDesDup);
				printf("\n New Part Description Value is NULL");fflush(stdout);
		    }
			trimwhitespace(cItemNewDesDup);
			printf("\n Part Description Value After Dup & Trim --------> %s", cItemNewDesDup);fflush(stdout);
			STRNG_replace_str(cItemNewDesDup,","," ",&cItemNewDesDup);
			STRNG_replace_str(cItemNewDesDup,";"," ",&cItemNewDesDup);
			STRNG_replace_str(cItemNewDesDup,"\n"," ",&cItemNewDesDup);
			printf("\n New Part Description Final Value --------> %s", cItemNewDesDup);fflush(stdout); */
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_DesignGrp", &cDesGrp));
			if(tc_strlen(cDesGrp)>0)
			{
				tc_strdup(cDesGrp,&cDesGrpDup);
			}
			else
			{
				tc_strdup("NULL",&cDesGrpDup);
				printf("\n Part Design Group Value is NULL");fflush(stdout);
			}
			trimwhitespace(cDesGrpDup);
			printf("\n Part Design Group Value After Dup & Trim --------> %s", cDesGrpDup);fflush(stdout);
			
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cRevision));
			if(tc_strlen(cRevision)>0)
		    {
			   tc_strdup(cRevision,&cRevisionDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cRevisionDup);
			   printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cRevisionDup);
		    printf("\n Part Rev & Seq Value After Dup --------> %s", cRevisionDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
		    {
			   tc_strdup(cPartType,&cPartTypeDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cPartTypeDup);
			   printf("\n Part Type Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cPartTypeDup);
		    printf("\n Part Type Value After Dup & Trim --------> %s", cPartTypeDup);fflush(stdout);
			//ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j],pcs,&cCS));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PunMakeBuyIndicator", &cCS));
			if(tc_strlen(cCS)>0)
		    {
			   tc_strdup(cCS,&cCSDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cCSDup);
			   printf("\n Part CS Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cCSDup);
		    printf("\n Part CS Value After Dup & Trim --------> %s", cCSDup);fflush(stdout);
		    ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design_t5_uom", &cUOM));
			if(tc_strlen(cUOM)>0)
		    {
			   tc_strdup(cUOM,&cUOMDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cUOMDup);
			   printf("\n Part UOM Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cUOMDup);
		    printf("\n Part UOM Value After Dup & Trim --------> %s", cUOMDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nLevel: %s", cLevel);
			printf("\nID: %s", cItem_Id);
			printf("\nDescriptiom: %s", cItemDesDup);
			printf("\nDesign Group: %s", cDesGrpDup);
			printf("\nRev & Seq: %s", cRevisionDup);
			printf("\nType: %s", cPartTypeDup);
			printf("\nCS: %s", cCSDup);
			printf("\nUOM: %s", cUOMDup);
			printf("\nQuantity: %s", cQuantity);
            int cQuantity_in = atoi(cQuantity);
		    printf("\nQuantity in Integer: %d", cQuantity_in);			
			printf("\n-------------------------------------------------------------------------");
			if(cQuantity_in > 0)
			{
			  fprintf(FP_OutputReport,"%s,%s,%s,%s,%s,%s,%s,%s,%s\n",cLevel,cItem_Id,cItemDesDup,cDesGrpDup,cRevisionDup,cPartTypeDup,cCSDup,cUOMDup,cQuantity);fflush(FP_OutputReport);
			  fprintf(Veh_OutputReport,"%s,%s,%s\n",cItem_Id,cRevisionDup,cQuantity);fflush(Veh_OutputReport);
			}
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found --------> %d\n",iNumber_SubChild);fflush(stdout);
			if((iNumber_SubChild > 0) && (cQuantity_in > 0))
			{
				printf("\n!!!!!!!!! C H I L D   P A R T   Q T Y   G R E A T E R   T H A N   Z E R O  &  S U B - C H I L D  A V A I L A B L E !!!!!!!!!!");fflush(stdout);
				bom_sub_child(tSubChild,iNumber_SubChild,pcs,FP_OutputReport,Veh_OutputReport);
			}
		}
		return iFail;
}

int bom_sub_module(tag_t tSub_Children, char* Sub_Child_rrule, char* top_child_qty, char* plantcs, FILE* FReport, FILE* VReport)
{
	
	tag_t Sub_Child_bom_window = NULLTAG;
	tag_t subrule = NULLTAG;
	//int subrulefound = 0;
	//tag_t* subclosurerule = NULL;
	//tag_t sub_close_tag = NULLTAG;
	//char** subrulename = NULL;
    //char** subrulevalue = NULL;
	tag_t tSub_Child = NULLTAG;
	char* cSubLevel = NULL;
	char* cSubRev_Name = NULL;
	char* cSubItem_Id = NULL;
	char* cSubRevision = NULL;
	char* cSubRevisionDup = NULL;
	//char* cSubParent = NULL;
	char* cSubOwn_Group = NULL;
	char* cSubOwn_User = NULL;
	char* cSubItemDes = NULL;
	char* cSubItemDesDup = NULL;
	char* cSubItemNewDes = NULL;
	char* cSubItemNewDesDup = NULL;
	char* cSubPartType = NULL;
	char* cSubPartTypeDup = NULL;
	//char* cSubType = NULL;
	//cSubType = (char *)malloc(20 * sizeof(char));
	char* cSubCS = NULL;
	char* cSubCSDup = NULL;
	char* cSubUOM = NULL;
	char* cSubUOMDup = NULL;
	//char* cSubQuantity = NULL;
	//char* cSubFind_No = NULL;
	int iFail = ITK_ok;
	int iSubNumber_Child = 0;
	tag_t* tBOM_Children = NULLTAG;
	
	char* cSubSubLevel = NULL;
	char* cSubSubItem_Id = NULL;
	char* cSubSubRevision = NULL;
	char* cSubSubParent = NULL;
	char* cSubSubQuantity = NULL;
	char* cSubDesGrp = NULL;
	char* cSubDesGrpDup = NULL;
			
	ITK_CALL(BOM_create_window(&Sub_Child_bom_window));
	printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
    //ITK_CALL(CFM_find("ERC release and above", &rule))
	ITK_CALL(CFM_find(Sub_Child_rrule, &subrule));
	printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
    ITK_CALL(BOM_set_window_config_rule(Sub_Child_bom_window, subrule));
	printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
	/* ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
	printf("\n No of Rule Found --------> %d\n",subrulefound);fflush(stdout);
	if (subrulefound > 0)
	{
		sub_close_tag = subclosurerule[0];
	}
	ITK_CALL(BOM_window_set_closure_rule(Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
	printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout); */
	ITK_CALL(BOM_set_window_pack_all(Sub_Child_bom_window, TRUE));
	printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
	ITK_CALL(BOM_set_window_top_line(Sub_Child_bom_window, NULLTAG, tSub_Children, NULLTAG, &tSub_Child));
	printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
	if(tSub_Child != NULLTAG)
    {
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_level_starting_0", &cSubLevel));
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_item_item_id", &cSubItem_Id));
		cSubItemDesDup = TC_PartDesc(cSubItem_Id);
		/* ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_item_object_desc", &cSubItemDes));
		if(tc_strlen(cSubItemDes)>0)
		{
			tc_strdup(cSubItemDes,&cSubItemDesDup);
		}
		else
		{
			tc_strdup("NULL",&cSubItemDesDup);
			printf("\n Part Description Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubItemDesDup);
		printf("\n Part Description Value After Dup & Trim --------> %s", cSubItemDesDup);fflush(stdout);
		STRNG_replace_str(cSubItemDesDup,","," ",&cSubItemDesDup);
		STRNG_replace_str(cSubItemDesDup,";"," ",&cSubItemDesDup);
		STRNG_replace_str(cSubItemDesDup,"\n"," ",&cSubItemDesDup); */
		printf("\n Part Description Final Value --------> %s", cSubItemDesDup);fflush(stdout);
		
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_Design Revision_t5_DesignGrp", &cSubDesGrp));
		if(tc_strlen(cSubDesGrp)>0)
		{
			tc_strdup(cSubDesGrp,&cSubDesGrpDup);
		}
		else
		{
			tc_strdup("NULL",&cSubDesGrpDup);
			printf("\n Part Design Group Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubDesGrpDup);
		printf("\n Part Design Group Value After Dup & Trim --------> %s", cSubDesGrpDup);fflush(stdout);
		
		/* ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_rev_object_name", &cSubItemNewDes));
		if(tc_strlen(cSubItemNewDes)>0)
		{
			tc_strdup(cSubItemNewDes,&cSubItemNewDesDup);
		}
		else
		{
			tc_strdup("NULL",&cSubItemNewDesDup);
			printf("\n New Part Description Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubItemNewDesDup);
		printf("\n Part Description Value After Dup & Trim --------> %s", cSubItemNewDesDup);fflush(stdout);
		STRNG_replace_str(cSubItemNewDesDup,","," ",&cSubItemNewDesDup);
		STRNG_replace_str(cSubItemNewDesDup,";"," ",&cSubItemNewDesDup);
		STRNG_replace_str(cSubItemNewDesDup,"\n"," ",&cSubItemNewDesDup);
		printf("\n New Part Description Final Value --------> %s", cSubItemNewDesDup);fflush(stdout); */
		
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_rev_item_revision_id", &cSubRevision));
		if(tc_strlen(cSubRevision)>0)
		{
			tc_strdup(cSubRevision,&cSubRevisionDup);
		}
		else
		{
			tc_strdup("NULL",&cSubRevisionDup);
			printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubRevisionDup);
		printf("\n Part Rev & Seq Value After Dup --------> %s", cSubRevisionDup);fflush(stdout);
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_Design Revision_t5_PartType", &cSubPartType));
		if(tc_strlen(cSubPartType)>0)
		{
			tc_strdup(cSubPartType,&cSubPartTypeDup);
		}
		else
		{
			tc_strdup("NULL",&cSubPartTypeDup);
			printf("\n Part Type Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubPartTypeDup);
		printf("\n Part Type Value After Dup & Trim --------> %s", cSubPartTypeDup);fflush(stdout);
		//ITK_CALL(AOM_UIF_ask_value(tSub_Child,plantcs,&cSubCS));
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_Design Revision_t5_PunMakeBuyIndicator", &cSubCS));
		if(tc_strlen(cSubCS)>0)
		{
			tc_strdup(cSubCS,&cSubCSDup);
		}
		else
		{
			tc_strdup("NULL",&cSubCSDup);
			printf("\n Part CS Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubCSDup);
		printf("\n Part CS Value After Dup --------> %s", cSubCSDup);fflush(stdout);
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_Design_t5_uom", &cSubUOM));
		if(tc_strlen(cSubUOM)>0)
		{
			tc_strdup(cSubUOM,&cSubUOMDup);
		}
		else
		{
			tc_strdup("NULL",&cSubUOMDup);
			printf("\n Part UOM Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubUOMDup);
		printf("\n Part UOM Value After Dup --------> %s", cSubUOMDup);fflush(stdout);
		printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
		printf("\nLevel: %s", cSubLevel);
		printf("\nItem ID: %s", cSubItem_Id);
		printf("\nItem Descriptiom: %s", cSubItemDesDup);
		printf("\nItem Design Group: %s", cSubDesGrpDup);
		printf("\nItem Rev & Seq: %s", cSubRevisionDup);
		printf("\nPart Type: %s", cSubPartTypeDup);
		printf("\nPart CS: %s", cSubCSDup);
		printf("\nPart UOM: %s", cSubUOMDup);
		printf("\nPart Quantity: %s", top_child_qty);
		int top_child_qty_in = atoi(top_child_qty);
		printf("\nPart Quantity in Integer: %d", top_child_qty_in);
		printf("\n-------------------------------------------------------------------------");
		if(top_child_qty_in > 0)
		{
		  fprintf(FReport,"%s,%s,%s,%s,%s,%s,%s,%s,%s\n",cSubLevel,cSubItem_Id,cSubItemDesDup,cSubDesGrpDup,cSubRevisionDup,cSubPartTypeDup,cSubCSDup,cSubUOMDup,top_child_qty);fflush(FReport);
		  fprintf(VReport,"%s,%s,%s\n",cSubItem_Id,cSubRevisionDup,top_child_qty);fflush(VReport);
		}
		ITK_CALL(BOM_line_ask_all_child_lines(tSub_Child, &iSubNumber_Child, &tBOM_Children));
		printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
		printf("\n No of Children Found --------> %d\n",iSubNumber_Child);fflush(stdout);
		if((iSubNumber_Child>0) && (top_child_qty_in > 0))
		{
			printf("\n!!!!!!!!! P A R E N T   M O D U L E   Q T Y   G R E A T E R   T H A N   Z E R O  &  C H I L D  A V A I L A B L E !!!!!!!!!!");fflush(stdout);
			/* if(tc_strcmp(expansp,"YES") == 0)
			{
				printf("\n!!!!!!!!! E X P A N S I O N   S E L E C T E D !!!!!!!!!!");fflush(stdout);
				//if((tc_strcmp(plantcs,"F") != 0) || (tc_strcmp(plantcs,"F18") != 0) || (tc_strcmp(plantcs,"F30") != 0) || (tc_strcmp(plantcs,"F40") != 0))
				if((tc_strstr(plantcs,"F") == NULL) || (tc_strstr(plantcs,"F18") == NULL) || (tc_strstr(plantcs,"F30") == NULL) || (tc_strstr(plantcs,"F40") == NULL))
				{
					printf("\nAs CS is Not F/F18/F30/F40 So, Expansion Going on.....");fflush(stdout);
					bom_stop_sub_child(tBOM_Children, iSubNumber_Child, plantcs, FReport, VReport);
				}
				else
				{
					printf("\nAs CS is F/F18/F30/F40 So, Expansion Stoped.....");fflush(stdout);
					continue;
				} 
			} */
			//if(tc_strcmp(expansp,"NO") == 0)
			//{
				//bom_sub_child(tBOM_Children, iSubNumber_Child);
				//printf("\n!!!!!!!!! E X P A N S I O N   N O T   S E L E C T E D !!!!!!!!!!");fflush(stdout);
				printf("\n!!!!!!!!! N O   O F   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(tBOM_Children, iSubNumber_Child, plantcs, FReport, VReport);
				/* int j = 0;
				for(j = 0; j < iSubNumber_Child; j++)
				{
					ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_level_starting_0", &cSubSubLevel));
					ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_item_item_id", &cSubSubItem_Id));
					ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_rev_item_revision_id", &cSubSubRevision));
					ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_formatted_parent_name", &cSubSubParent));
					ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_quantity", &cSubSubQuantity));
					printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
					printf("\nLevel: %s", cSubSubLevel);
					printf("\nItem ID: %s", cSubSubItem_Id);
					printf("\nRevision ID: %s", cSubSubRevision);
					printf("\nParent: %s", cSubSubParent);
					printf("\nQuantity: %s", cSubSubQuantity);
					printf("\n-------------------------------------------------------------------------");
				}
				if(tBOM_Children)
				{
				   MEM_free(tBOM_Children);
				} */
			//}
		}
    }
	ITK_CALL(BOM_close_window(Sub_Child_bom_window));
	printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
	return iFail;
}	

int Platform_SVR(char* Platform,char* SVR,char* RevisionRule,char* csvalue,FILE* PMReport,FILE* SVReport)
{
	FILE 	*InputFile;
	
	//int ifail = ITK_ok;
	int iFail = 0;
	tag_t  objTypeTagDi1=NULLTAG;		
    tag_t  plat = NULLTAG;
	tag_t  rev  = NULLTAG;
	tag_t RevTypTag	= NULLTAG;
	char* RevTyp = NULL;
	tag_t VariqueryTag = NULLTAG;
	
    ITK_CALL(ITEM_find_item(Platform, &plat));
	printf("\nReturn Value From PlatForm Find API --------> %d", iFail);fflush(stdout);	
	ITK_CALL(ITEM_ask_latest_rev(plat, &rev));
    printf("\nReturn Value From PlatForm Latest Rev API --------> %d", iFail);fflush(stdout);	
	ITK_CALL(TCTYPE_ask_object_type(rev, &RevTypTag));
	printf("\nReturn Value From PlatForm Object Type API --------> %d", iFail);fflush(stdout);
	ITK_CALL(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\nReturn Value From PlatForm Name API --------> %d", iFail);fflush(stdout);
	printf("\nPlatform Revision Type: [%s]\n", RevTyp);fflush(stdout);

	ITK_CALL(QRY_find2("VariantRule", &VariqueryTag));
	printf("\nReturn Value From Varient Rule Query API is --------> %d", iFail);fflush(stdout);

	if(VariqueryTag!=NULLTAG)
	{
	   printf("\nVarient Rule Query Found Successfully...");fflush(stdout);
	}
	else
	{
	   printf("\n Varient Rule Query Not Found");fflush(stdout);
	}
    char** valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
	valuesNonColSvr[0] = SVR ;
	//valuesNonColSvr[0] = "54644625000R_A";
	int n_entriesV = 1;
	char *qry_entries3[1] = {"Name"};
	//char *qry_values3[1] = {"*"};
	int resultCountVNCol = 0;
	tag_t* outputVNCol_tags = NULLTAG;
	
    ITK_CALL(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
	printf("\n Return Value From Varient Query Execute API is --------> %d", iFail);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
    printf("\n No of Result Found --------> %d\n",resultCountVNCol);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
    
	tag_t  VarientRuletag = NULLTAG;
	if (resultCountVNCol > 0)
	{
		VarientRuletag = outputVNCol_tags[0];
	}
	else
	{
		printf("\n NonColour-SVR-VarientRule Not Present:  [%s]\n", SVR); fflush(stdout);
		//exit(0);
	}
    char* objecttype = NULL;
	ITK_CALL(AOM_ask_value_string(VarientRuletag,"object_type",&objecttype));
	printf("\n Varient Rule Object Type:  [%s]\n",objecttype);fflush(stdout);
    tag_t bom_view = NULLTAG;
	
	if(tc_strcmp(RevTyp,"T5_PlatformRevision") == 0)
	{

		if(rev != NULLTAG)
		{
			tag_t view_type = NULLTAG;
			ITK_CALL(PS_find_view_type("view", &view_type));
			printf("\n Return Value From View Type Find API is --------> %d", iFail);fflush(stdout);
            if(view_type != NULLTAG)
			{
				tag_t item = NULLTAG;
				int n_bom_views = 0;
				tag_t* bom_views = NULL;
				ITK_CALL(ITEM_ask_item_of_rev(rev, &item));
				printf("\n Return Value From Item of Rev API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(ITEM_list_bom_views(item, &n_bom_views, &bom_views));
				printf("\n Return Value From List BOM View API is --------> %d", iFail);fflush(stdout);
                bom_view = bom_views[0];
			}
			else
			{
				printf("\n View Type Tag Not Found \n");fflush(stdout);
			}
		}


		if(bom_view != NULLTAG)
		{
			tag_t bom_window = NULLTAG;
			tag_t rule = NULLTAG;
			int rulefound = 0;
			tag_t* closurerule = NULL;
			tag_t close_tag = NULLTAG;
			char** rulename = NULL;
            char** rulevalue = NULL;
			tag_t tPlatform = NULLTAG;
			tag_t bom_variant_rule = NULLTAG;
			tag_t objTypeTag = NULLTAG;
			char type_name[TCTYPE_name_size_c+1];
			tag_t e_block = NULLTAG;
			
			ITK_CALL(BOM_create_window(&bom_window));
			printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
			//ITK_CALL(CFM_find("ERC release and above", &rule))
			ITK_CALL(CFM_find(RevisionRule, &rule));
			printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_config_rule(bom_window, rule));
			printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
			ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule));
			//ITK_CALL(PIE_find_closure_rules("GenTPLBOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule));
			printf("\n No of Rule Found --------> %d\n",rulefound);fflush(stdout);
			if (rulefound > 0)
			{
				close_tag = closurerule[0];
			}
			ITK_CALL(BOM_window_set_closure_rule(bom_window,close_tag,0,rulename,rulevalue));
			printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_pack_all(bom_window, FALSE));
			printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, rev, NULLTAG, &tPlatform));
			printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
			ITK_CALL( BOM_window_ask_variant_rule(bom_window, &bom_variant_rule));
			printf("\n Return Value From BOM Window Ask Varient Rule API is --------> %d", iFail);fflush(stdout);
            ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
			printf("\n Return Value From BOM Varient Rule Object Type Tag API is --------> %d", iFail);fflush(stdout);
		    ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
            printf("\nBOM Varient Rule Type Name: [%s]\n", type_name);fflush(stdout);			

			//ITK_CALL(ITEM_ask_rev_variants(rev, &e_block));
			//printf("\n Return Value From Item Ask Revision Varient API is --------> %d", iFail);fflush(stdout);		
			
            int n_lines,n_arcmod = 0;
	        tag_t* tarcmod = NULL;			
			if(tPlatform != NULLTAG)
			{
				//ITK_CALL(BOM_line_ask_child_lines(tPlatform, &n_arcmod, &tarcmod));
				//printf("\n Return Value From BOM Line Ask Child Line API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(BOM_window_hide_unconfigured(bom_window));
				printf("\n Return Value From BOM Window Hide Configured API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(BOM_window_show_variants(bom_window));
				printf("\n Return Value From BOM Window Show Varients API is --------> %d", iFail);fflush(stdout);
				//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config));
				//if(BOM_variant_config_apply (bom_variant_config));
                //if(BOM_variant_rule_apply(primary1));				
				ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
				printf("\n Return Value From BOM Window Apply Varient Configuration API is --------> %d", iFail);fflush(stdout);
               //if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list));
				ITK_CALL(BOM_window_hide_variants(bom_window));
                ITK_CALL(BOM_line_ask_child_lines(tPlatform, &n_arcmod, &tarcmod));
				printf("\n BOM Line Ask Child Lines (Architecture_Module) --------> %d\n",n_arcmod);fflush(stdout);
				int blqu = 0;
				tag_t Childobject4 = NULLTAG;
				tag_t Childobject3 = NULLTAG;
				//int p4 = 0;
				tag_t objTypeTagDi = NULLTAG;
				//tag_t Childobject2 = NULLTAG;
				//char type_name2[TCTYPE_name_size_c+1];
				char* top_child_item_id = NULL;
	            char* top_child_item_revision_id = NULL;
				char* top_child_Quantity = NULL;
	            //char* child_bl_formula = NULL; 
				int n_module = 0;
				tag_t* tmodule = NULLTAG;
                ITK_CALL( BOM_line_look_up_attribute ("bl_quantity",&blqu));
                if (n_arcmod >0)
				{
					int p1 = 0;
					for(p1=0; p1 < n_arcmod; p1++)
					{
						if(Childobject4) Childobject4 = NULLTAG;
						Childobject4=tarcmod[p1];
						//ITK_CALL(BOM_line_unpack(Childobject4));
                        ITK_CALL(BOM_line_ask_child_lines(Childobject4, &n_module, &tmodule));
						printf("\n BOM Line Ask Child Lines (Module) --------> %d\n",n_module);fflush(stdout);
						int n_submodule = 0;
				        tag_t* tsubmodule = NULLTAG;
                        if(n_module >0)
						{
							int p4 = 0;
							for (p4=0; p4 < n_module; p4++)
							{
								if(Childobject3) Childobject3 = NULLTAG;
								Childobject3=tmodule[p4];

								ITK_CALL(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
								printf("\n Return Value From Object Type API is --------> %d", iFail);fflush(stdout);
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_item_item_id", &top_child_item_id ));
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &top_child_item_revision_id));
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_quantity", &top_child_Quantity));
						        printf("\n########## M O D U L E    D E T A I L S #############");fflush(stdout);		
								printf("\nUnique Module ID: %s", top_child_item_id);fflush(stdout);
			                    printf("\nUnique Module Revision ID: %s", top_child_item_revision_id);fflush(stdout);
								printf("\nUnique Module Quantity: %s", top_child_Quantity);fflush(stdout);
								printf("\nUnique Revision Rule: %s", RevisionRule);fflush(stdout);
								printf("\n########## M O D U L E    D E T A I L S #############");fflush(stdout);
								tag_t tchild_item = NULLTAG;
								ITK_CALL(ITEM_find_item(top_child_item_id, &tchild_item));
								printf("\n Return Value From Item Find Item API is --------> %d", iFail);fflush(stdout);
								tag_t Childrev = NULLTAG;
								//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
								ITK_CALL(ITEM_find_revision(tchild_item, top_child_item_revision_id, &Childrev));
								printf("\n Return Value From Item Find Revision API is --------> %d", iFail);fflush(stdout);
								if(Childrev != NULLTAG)
								{
									printf("\n!!!!!!!!! T E S T I N G    O K !!!!!!!!!!");fflush(stdout);
									bom_sub_module(Childrev,RevisionRule,top_child_Quantity,csvalue,PMReport,SVReport);
								}
								//exit(0); 
								//bom_sub_child(tmodule, n_module);
								
										
								//int n_submodule = 0;
				                //tag_t* tsubmodule = NULLTAG;
								//int p5 = 0;
								//char* cLeveltest = NULL;  
								//char* cRev_Nametest = NULL; 
								//char* cItem_Idtest = NULL; 
								/* ITK_CALL(BOM_line_unpack(Childobject3));
								printf("\n Return Value From BOM Line Unpack API is --------> %d", iFail);fflush(stdout);
								ITK_CALL(BOM_line_ask_all_child_lines(Childobject3, &n_submodule, &tsubmodule));
								printf("\n BOM Line Ask Child Lines (Sub_Module) --------> %d\n",n_submodule);fflush(stdout);
								exit(0); */
								/* if(n_submodule > 0)
								{
									for (p5=0; p5 < n_submodule; p5++)
							        {
								       if(Childobject2) Childobject2 = NULLTAG;
								       Childobject2=tsubmodule[p5];
									   ITK_CALL(AOM_UIF_ask_value(Childobject2, "bl_level_starting_0", &cLeveltest));
			                           ITK_CALL(AOM_UIF_ask_value(Childobject2, "bl_rev_object_name", &cRev_Nametest));
			                           ITK_CALL(AOM_UIF_ask_value(Childobject2, "bl_item_item_id", &cItem_Idtest));
									   printf("\n ################# T E S T   R E S U L T    S U B - M O D U L E ###############");
									   printf("\nLevel Test: %s", cLeveltest);
									   printf("\nRevision Name Test: %s", cRev_Nametest);
			                           printf("\nItem ID Test: %s", cItem_Idtest);
									   printf("\n ################# T E S T   R E S U L T    S U B - M O D U L E ###############");
									   //bom_sub_child(Childobject2, n_submodule);
									}
								}  */
								
								
								
								/* ITK_CALL(TCTYPE_ask_name(objTypeTagDi,type_name2));	  
								printf("\nObject Type Name2: [%s]\n", type_name2);fflush(stdout);
								
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_item_item_id", &child_item_id ));
								printf("\nChild Item ID: [%s]\n", child_item_id);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &child_item_revision_id));
								printf("\nChild Item Revision ID: [%s]\n", child_item_revision_id);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_formula", &child_bl_formula));
								printf("\nBOM Line Formula: [%s]\n", child_bl_formula);fflush(stdout); */
                            }
							//bom_sub_child(lines4, n_lines4);
						}
						if(tmodule)
						{
							MEM_free(tmodule);
						}
					}
			    }
				if(tarcmod)
				{
					MEM_free(tarcmod);
				}
				ITK_CALL(BOM_close_window(bom_window));
			    printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
            }
		}
		else
		{
			printf("\n No BOM Window Found \n");fflush(stdout);
		}
					
	}

	return ITK_ok;	
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	time_t	temptime;
	//char GenDate[20];
	//struct tm *timeptr;
	//int ch;
	char *RptFile= (char *) malloc(400*sizeof(char));
	char *MstrRptFile= (char *) malloc(400*sizeof(char));
	char *FinalRptFile= (char *) malloc(400*sizeof(char));
	char *InpRptFile= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	FILE *fpInput_file = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char* Platform = NULL;
	char* SVRList = NULL;
	//char* SVR = NULL;
	char* RevisionRule = NULL;
	char* SVRNoStr = NULL;
	//char* SVRRevStr = NULL;
	//char* stopat = NULL;
	char* plantname = NULL;
	char* SVRShellCommandLine = NULL;
	SVRShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	char* responseString1 = NULL;
	responseString1=(char *)MEM_alloc(200);
	
	printf("\n Generating New Time Stamp");fflush(stdout);
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n New Time Stamp Generated");fflush(stdout);
	
	printf("\n Generating New Report Time Stamp");fflush(stdout);
	char RptDate[100] = "";
	strftime(RptDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Report Time --------> %s", RptDate);fflush(stdout);
	printf("\n New Report Time Stamp Generated");fflush(stdout);

    printf("\n Generating Pre Master Report File Name");fflush(stdout);
	//tc_strcpy(RptFile,"Pre_Master_TPL_App_Matrix");
	tc_strcpy(RptFile,"/tmp/");
	tc_strcat(RptFile,"Pre_Master_TPL_App_Matrix");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Pre Master Report File Name --------> %s", RptFile);fflush(stdout);
	printf("\n Pre Master Report File Name Generated");fflush(stdout);
	
	printf("\n Generating Master Report File Name");fflush(stdout);
	//tc_strcpy(MstrRptFile,"Master_TPL_App_Matrix");
	tc_strcpy(MstrRptFile,"/tmp/");
	tc_strcat(MstrRptFile,"Master_TPL_App_Matrix");
	tc_strcat(MstrRptFile,"_");
	tc_strcat(MstrRptFile,GenDate);
	tc_strcat(MstrRptFile,".csv");
	printf("\n Master Report File Name --------> %s", MstrRptFile);fflush(stdout);
	printf("\n Master Report File Name Generated");fflush(stdout);
	
	printf("\n Generating Final Report File Name");fflush(stdout);
	//tc_strcpy(FinalRptFile,"TPL_App_Matrix");
	tc_strcpy(FinalRptFile,"/tmp/");
	tc_strcat(FinalRptFile,"TPL_App_Matrix");
	tc_strcat(FinalRptFile,"_");
	tc_strcat(FinalRptFile,GenDate);
	tc_strcat(FinalRptFile,".csv");
	printf("\n Final Report File Name --------> %s", FinalRptFile);fflush(stdout);
	printf("\n Final Report File Name Generated");fflush(stdout);
	
	printf("\n Generating Input Report File Name");fflush(stdout);
	//tc_strcpy(InpRptFile,"InputList");
	tc_strcpy(InpRptFile,"/tmp/");
	tc_strcat(InpRptFile,"InputList");
	tc_strcat(InpRptFile,"_");
	tc_strcat(InpRptFile,GenDate);
	tc_strcat(InpRptFile,".csv");
	printf("\n Input Report File Name --------> %s", InpRptFile);fflush(stdout);
	printf("\n Input Report File Name Generated");fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 8)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			//cUSERID = "skk919708";
			//cPASS = "XYT1ESA";
			//cGroup = "PLM_Support_Group";
			Platform = ITK_ask_cli_argument("-plat=");
			SVRList = ITK_ask_cli_argument("-svr=");
	        RevisionRule = ITK_ask_cli_argument("-rrule=");
			//stopat = ITK_ask_cli_argument("-sat=");
			plantname = ITK_ask_cli_argument("-pname=");
			printf("\nUsername --------> %s", cUSERID);fflush(stdout);
			printf("\nPassword --------> %s", cPASS);fflush(stdout);
			printf("\nGroup --------> %s", cGroup);fflush(stdout);
			printf("\nPlatform --------> %s", Platform);fflush(stdout);
			printf("\nSVR List --------> %s", SVRList);fflush(stdout);
			printf("\nRevision Rule --------> %s", RevisionRule);fflush(stdout);
			//printf("\nStop At --------> %s", stopat);fflush(stdout);
			printf("\nPlant Name --------> %s", plantname);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&cUSERID, &tuser);
				printf("\nLogged in Username --------> %s", cUSERID);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			if( tc_strlen(stripBlanks(Platform)) == 0 || tc_strlen(stripBlanks(SVRList)) == 0 || tc_strlen(stripBlanks(RevisionRule)) == 0 || tc_strlen(stripBlanks(plantname)) == 0)
	        {
		        print_requirement();
		        return iFail;
	        }
            
			/* char* stopvalue = NULL;
	        stopvalue =(char *)MEM_alloc(30);
			if(tc_strcmp(stopat,"+")==0)
		    {
			  tc_strcpy(stopvalue,"YES");
		    }
			else if(tc_strcmp(stopat,"-")==0)
			{
				tc_strcpy(stopvalue,"NO");
			}
			else
			{
				tc_strcpy(stopvalue,"");
			}
			printf("\n Final Stop At Value --------> %s", stopvalue);fflush(stdout); */
			printf("\n Copying SVRList in Response String1");fflush(stdout);
			if(tc_strlen(SVRList)>0)
			{
			   tc_strcpy(responseString1,SVRList);
			}
			else
			{
				tc_strcpy(responseString1,"");
				printf("\n Response String1 Value is NULL");fflush(stdout);
			}
			printf("\n SVRList Value --------> %s", SVRList);fflush(stdout);
			printf("\n Response String1 Value --------> %s", responseString1);fflush(stdout);
			printf("\n SVRList Copied in Response String1");fflush(stdout);
			
			char* plantnamedup = NULL;
	        plantnamedup=(char *)MEM_alloc(30);
			if(tc_strlen(plantname)>0)
			{
				tc_strdup(plantname,&plantnamedup);
			}
			else
			{
				tc_strdup("",&plantnamedup);
				printf("\n Plant Name Value is NULL");fflush(stdout);
			}
			trimwhitespace(plantnamedup);
			printf("\n Plant Name Value After Dup & Trim --------> %s", plantnamedup);fflush(stdout);
			char* makebuyind = NULL;
	        makebuyind = (char *)MEM_alloc(200);
			if(tc_strcmp(plantnamedup,"AHD")==0)
		    {
			  tc_strcpy(makebuyind,"bl_Design Revision_t5_AhdMakeBuyIndicator");
		    }
			else if(tc_strcmp(plantnamedup,"CAR")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_CarMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"DHARWARD")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_DwdMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"JSR")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_JsrMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"JSRTMLDL")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_JdlMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"LKO")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_LkoMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"PNR")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_PnrMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"PUNPCBU")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_PunPCBUMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"PUNE")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_PunMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"PUNEUV")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_PunUVMakeBuyIndicator");
			}
			else if(tc_strcmp(plantnamedup,"RJV")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_RjvMakebuyInd");
			}
			else if(tc_strcmp(plantnamedup,"SGR")==0)
			{
				tc_strcpy(makebuyind,"bl_Design Revision_t5_SgrMakeBuyIndicator");
			}
            else
            {
				tc_strcpy(makebuyind,"");
				printf("\n Make Buy Value is Setting As NULL");fflush(stdout);
			}				
			printf("\n Final Make-Buy Value --------> %s", makebuyind);fflush(stdout);
			//exit(0);
			fpOutput_file = fopen(RptFile, "w");
			//fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ S V R   R E P O R T ~~~~~~~~~~~~~~~");fflush(fpOutput_file);
            //fprintf(fpOutput_file,"\n Sr_No,Level,Part_No,Part_Desc,Rev_Seq,Part_Type,CS,UOM");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Log File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			else
	        {
		        printf("\n Output File Opened Successfully");fflush(stdout);
	        }
			
			fpInput_file = fopen(InpRptFile, "w"); 
	        if(fpInput_file == NULL)
	        {
				printf("\n Unable to Create Input File on Server --------> %s",InpRptFile);fflush(stdout);
				return iFail;
	        }
			else
	        {
		        printf("\n Input File Opened Successfully");fflush(stdout);
	        }
			
                char token_list[20][20];
				char* token = strtok(SVRList, ",");
				int num_tokens = 0;
				while(token != NULL) 
				{
					strcpy(token_list[num_tokens], token); 
					num_tokens++;
					token = strtok(NULL, ",");
				}					
				printf("\n No of Tokens: %d",num_tokens);fflush(stdout);
			    int c=0;
                for (c=0; c < num_tokens; c++) 
		        {
					char* SVR = (char *) malloc(20*sizeof(char));
					tc_strcpy(SVR,token_list[c]);
					printf("\n SVR:  --->  [%s]",SVR);fflush(stdout);
				    fprintf(fpInput_file,"%s\n",SVR);fflush(fpInput_file); 
				    //exit(0);
					char *SVRRptFile= (char *) malloc(400*sizeof(char));
	                FILE *fpsvr_output_file = NULL;
					printf("\n Generating Each SVR Report File Name");fflush(stdout);
					trimwhitespace(SVR);
					printf("\n SVR After Trim WhiteSpace:  --->  [%s]",SVR);fflush(stdout);
	                //tc_strcpy(SVRRptFile,SVR);
					tc_strcpy(SVRRptFile,"/tmp/");
	                tc_strcat(SVRRptFile,SVR);
	                tc_strcat(SVRRptFile,".csv");
	                printf("\n SVR Output File Name --------> %s", SVRRptFile);fflush(stdout);
					//exit(0);
					fpsvr_output_file = fopen(SVRRptFile, "w");
					if(fpsvr_output_file == NULL)
	                {
				        printf("\n Unable to Create SVR File on Server --------> %s",SVRRptFile);fflush(stdout);
				        return iFail;
	                }
			        else
	                {
		                printf("\n SVR File Opened Successfully");fflush(stdout);
	                }
					
			        Platform_SVR(Platform,SVR,RevisionRule,makebuyind,fpOutput_file,fpsvr_output_file);
					
					fclose(fpsvr_output_file);
					printf("\n SVR File Closed Successfully");fflush(stdout);
					//exit(0);
				}
			fclose(fpInput_file);
			printf("\n Input File Closed Now\n");fflush(stdout);
			fclose(fpOutput_file);           
			printf("\n All SVR Details Written Successfully on the Output File....\n");fflush(stdout); 
			printf("\n Output File Closed Now\n");fflush(stdout);
			
			//Replace space with specific character ppl for Platform
            char ppl = '_'; 
			int nbk = 0;
            for(nbk = 0; nbk < strlen(Platform); nbk++)
			{  
               if(Platform[nbk] == ' ')  
               Platform[nbk] = ppl;
            }
            printf("\n Final Platform After Replace --------> %s",Platform);fflush(stdout);
			
			//Replace space with specific character rpl for SVR List 
            char spl = '/'; 
			int alk = 0;
            for(alk = 0; alk < strlen(SVRList); alk++)
			{  
               if(SVRList[alk] == ' ')  
               SVRList[alk] = spl;
            }
            printf("\n Final SVR List After Replace --------> %s",SVRList);fflush(stdout);
			
			//Replace space with specific character rpl for Revision Rule 
            char rpl = '-'; 
			int rlk = 0;
            for(rlk = 0; rlk < strlen(RevisionRule); rlk++)
			{  
               if(RevisionRule[rlk] == ' ')  
               RevisionRule[rlk] = rpl;
            }
            printf("\n Final Revision Rule After Replace --------> %s",RevisionRule);fflush(stdout);

            //Replace space with specific character rpl for Plant Name 
            char plantpl = '-'; 
			int plantlk = 0;
            for(plantlk = 0; plantlk < strlen(plantname); plantlk++)
			{  
               if(plantname[plantlk] == ' ')  
               plantname[plantlk] = plantpl;
            }
            printf("\n Final Plant Name After Replace --------> %s",plantname);fflush(stdout);			
			
			
			printf("\n Shell Calling STARTED...");fflush(stdout);
			tc_strcpy(SVRShellCommandLine,"/user/uaprodtrl/Sourav/tm_applicability_report/Execution_Shell.sh");
			//tc_strcpy(SVRShellCommandLine,"/user/infodba04/sourav/tm_app_report/Execution_Shell.sh");
	        tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,responseString1);
	        tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,RptFile);
	        tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,MstrRptFile);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,FinalRptFile);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,"souravk.ttl@tatamotors.com");
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,InpRptFile);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,Platform);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,SVRList);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,RevisionRule);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,plantname);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,RptDate);
	        printf("\n CommandLine: -------> %s",SVRShellCommandLine);fflush(stdout);
	        system(SVRShellCommandLine);
			printf("\n Shell Called Ended...");
			
			
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}