/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Find User Details From Role Tag  
*  File Name    :   tm_user_role.c
*  Created on   :   Dec 18th, 2023
*  Usage        :   tm_user_role
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     18/12/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *group_name_str = NULL;
	char *group_name_strDup = NULL;
	tag_t group_tag	= NULLTAG;
	tag_t user_tag	= NULLTAG;
	tag_t relation_type	= NULLTAG;
	tag_t role_tag = NULLTAG;
	tag_t* role_tags = NULLTAG;
	tag_t* member_tags = NULLTAG;
	int	num_of_roles = 0;
	int	num_of_members = 0;
	int	i = 0;
	int	j = 0;
	char *rolename = NULL;
	char *user_name = NULL;
	tag_t person_tag = NULLTAG;
	char *user_email = NULL;


    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	group_name_str = ITK_ask_cli_argument("-Grp=");
	
	trimwhitespace(group_name_str);
	
	if(group_name_str!=NULL)tc_strdup(group_name_str,&group_name_strDup);
	printf(" [1]: Input Group_Name(group_name_strDup): [%s]\n",group_name_strDup);fflush(stdout);

	ITK_CALL(SA_find_group(group_name_strDup,&group_tag));
	if(group_tag != NULLTAG)
	{
	  ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags));
	  printf("\n No of Role Found: [%d]\n",num_of_roles);fflush(stdout);
		if(num_of_roles>0)
		{
			for(i=0;i<num_of_roles ;i++)
			{
				ITK_CALL(SA_ask_role_name(role_tags[i],rolename));
				printf("\n Role Name: [%s]\n",rolename);fflush(stdout);
				//ITK_CALL(SA_find_role2(rolename,&role_tags));
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Members Found in Group/Role: [%d]\n",num_of_members);
				if(num_of_members>0)
				{
					for (j=0;j<num_of_members ;j++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
						ITK_CALL(SA_ask_user_person_name2(user_tag,&user_name));
						printf("\n User Name:[%s]\n",user_name);fflush(stdout);
						ITK_CALL(SA_find_person2(user_name,&person_tag));
						ITK_CALL(SA_ask_person_email_address(person_tag,&user_email));
						printf("\n User Email: [%s]\n",user_email);fflush(stdout);
					}
				}
				else
				{
					   printf("\n No of Members Found Zero..!!\n");fflush(stdout);
				} 
			}
		}
		else
		{
		   printf("\n No of Roles Found Zero..!!\n");fflush(stdout);
		}  
	}
	else
	{
		printf("\n Group Tag is NULL..!!\n");fflush(stdout);
	}
    if(member_tags)
	{
	  MEM_free(member_tags);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_user_role.c
* // ./linkitk -o tm_user_role tm_user_role.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Find_UserTag_FromRole/tm_user_role .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Find_UserTag_FromRole/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Find_UserTag_FromRole/usage.txt .
* // ./tm_user_role -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Grp="PLM_Support_Group"
* // ./tm_user_role -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Grp="PLM_Support_Group"
*
***************************************************************************/