/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query DR4 Released Module & Print It's Properties For MCC Library  
*  File Name    :   tm_LibraryDataRpt.c
*  Created on   :   Aug 07th, 2024
*  Usage        :   tm_LibraryDataRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     07/08/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSeqSrch)
{
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	int	status_count = 0;
	tag_t* relStatus_list = NULLTAG;
	char* latest_rev_Rel_StatusDup = NULL;
	int	mbom_status_count = 0;
	tag_t* mbom_relStatus_list = NULLTAG;
	char* mbom_latest_rev_Rel_StatusDup = NULL;
			
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision PartType",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision PartType Query Found Successfully..!!\n");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[0];
				if(LC_rev_tags_found != NULLTAG)
				{
                    WSOM_ask_release_status_list(LC_rev_tags_found, &status_count, &relStatus_list);
					printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
					if(status_count>0)
					{
						int g = 0;
						for(g = 0; g<status_count; g++)
						{			  
							AOM_ask_value_string(relStatus_list[g],"object_name",&latest_rev_Rel_StatusDup);
							printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
							if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"ERC Released") == 0))
							{
								tc_strdup("ERCRLZD",&sRelStatus);										
							}
							else
							{
							   continue;
							}			  
						}
					}
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						printf("\n ERC Released Status Not Found So, Continue for MBOM..!!\n");fflush(stdout);
						WSOM_ask_release_status_list(LC_rev_tags_found, &mbom_status_count, &mbom_relStatus_list);
						printf("\n No of Release Status Found: -----> <%d> \n",mbom_status_count);fflush(stdout);
						if(mbom_status_count>0)
						{
							int h = 0;
							for(h = 0; h<mbom_status_count; h++)
							{			  
								AOM_ask_value_string(mbom_relStatus_list[h],"object_name",&mbom_latest_rev_Rel_StatusDup);
								printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",mbom_latest_rev_Rel_StatusDup);fflush(stdout);
								if((tc_strcmp(mbom_latest_rev_Rel_StatusDup,"T5_MBOMReleased") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"MBOM Released") == 0))
								{
									tc_strdup("MBOMRLZD",&sRelStatus);										
								}
								else
								{
								   continue;
								}			  
							}
						}
						tc_strdup("NOTRLZD",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL..!!\n");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
				}
				else
				{
					tc_strdup("NOTRLZD",&sRelStatusDup);
					printf("\nSorry! Design Revision Tag Not Found..!!\n");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("NOTRLZD",&sRelStatusDup);
			printf("\nSorry! Entered Design Revision Not Found..!!\n");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("NOTRLZD",&sRelStatusDup);
		printf("\nSorry! DesignRevision PartType Query Tag Not Found..!!\n");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t DesRev_tag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	char *DRStatus = NULL;
	char *DRStatusDup = NULL;
	char *Platform = NULL;
	char *PlatformDup = NULL;
	char *cItem_RevSeq = NULL;
	cItem_RevSeq = (char *) malloc(20*sizeof(char));
	char *cItem_LCDetails = NULL;
	char *aggrgrp_str = NULL;
	char *aggrgrp_next_str1 = NULL;
	char *aggrgrp_next_str2 = NULL;
	char *aggrgrp_strDup = NULL;
	char *aggr_str = NULL;
	char *aggr_next_str1 = NULL;
	char *aggr_next_str2 = NULL;
	char *aggr_strDup = NULL;
	char *modgrp_str = NULL;
	char *modgrp_next_str1 = NULL;
	char *modgrp_next_str2 = NULL;
	char *modgrp_strDup = NULL;
	char *modaddr_str = NULL;
	char *mod_desc_str = NULL;
	char *mod_desc_strDup = NULL;
	char *ProjectCode = NULL;
	char *ProjectCodeDup = NULL;
	char *PartType = NULL;
	char *PartTypeDup = NULL;
	char *Owner = NULL;
	char *OwnerDup = NULL;
	char *dtcreated = NULL;
	char *dtcreatedDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"mcc_library_data");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"AggregateGroup, Aggregate, ModuleName, ModuleAddress, ModuleNo, Description, Revision, Sequence, ProductLine, Platform, ProjectCode, DR/ARStatus, Owner, ModuleCategory, CreationDate\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	printf("\n Finding Query[DesignRevision PartType]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision PartType",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query [DesignRevision PartType] Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"ID","Part Type"};
		char *cValues[2]  = {"*","M"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total Design Revision[Part Type-Module] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
		    for(i = 0; i < n_itemobj_found; i++)
		    //for(i = 0; i < 100; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_AggregateGroup",&aggrgrp_str));
			    if(tc_strlen(aggrgrp_str)>0)
				{
					aggrgrp_next_str1=strtok(aggrgrp_str,"-");
			        aggrgrp_next_str2=strtok(NULL,"-");
					printf("\n Value[aggrgrp_next_str1]: [%s]\n", aggrgrp_next_str1);fflush(stdout);
					printf("\n Value[aggrgrp_next_str2]: [%s]\n", aggrgrp_next_str2);fflush(stdout);
					tc_strdup(aggrgrp_next_str2,&aggrgrp_strDup);
				}
				else
			    {
					tc_strdup("--",&aggrgrp_strDup);
					printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
				}
				printf("\n Aggregate Group Value After Dup & Trim: --------> <%s>", aggrgrp_strDup);fflush(stdout);
			    STRNG_replace_str(aggrgrp_strDup,","," ",&aggrgrp_strDup);
			    STRNG_replace_str(aggrgrp_strDup,";"," ",&aggrgrp_strDup);
			    STRNG_replace_str(aggrgrp_strDup,"\n"," ",&aggrgrp_strDup);
				STRNG_replace_str(aggrgrp_strDup,"'"," ",&aggrgrp_strDup);
				printf("\n Aggregate Group Value: --------> [%s]\n", aggrgrp_strDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Aggregate",&aggr_str));
			    if(tc_strlen(aggr_str)>0)
				{
					aggr_next_str1=strtok(aggr_str,"-");
			        aggr_next_str2=strtok(NULL,"-");
					printf("\n Value[aggr_next_str1]: [%s]\n", aggr_next_str1);fflush(stdout);
					printf("\n Value[aggr_next_str2]: [%s]\n", aggr_next_str2);fflush(stdout);
					tc_strdup(aggr_next_str2,&aggr_strDup);
				}
				else
			    {
					tc_strdup("--",&aggr_strDup);
					printf("\n Aggregate Value is NULL..!!");fflush(stdout);
				}
				printf("\n Aggregate Value After Dup & Trim: --------> <%s>", aggr_strDup);fflush(stdout);
			    STRNG_replace_str(aggr_strDup,","," ",&aggr_strDup);
			    STRNG_replace_str(aggr_strDup,";"," ",&aggr_strDup);
			    STRNG_replace_str(aggr_strDup,"\n"," ",&aggr_strDup);
				STRNG_replace_str(aggr_strDup,"'"," ",&aggr_strDup);
				printf("\n Aggregate Value: --------> [%s]\n", aggr_strDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Module_Group",&modgrp_str));
			    if(tc_strlen(modgrp_str)>0)
				{
					modgrp_next_str1=strtok(modgrp_str,"-");
			        modgrp_next_str2=strtok(NULL,"-");
					printf("\n Value[modgrp_next_str1]: [%s]\n", modgrp_next_str1);fflush(stdout);
					printf("\n Value[modgrp_next_str2]: [%s]\n", modgrp_next_str2);fflush(stdout);
					tc_strdup(modgrp_next_str2,&modgrp_strDup);
				}
				else
			    {
					tc_strdup("--",&modgrp_strDup);
					printf("\n Module Group Value is NULL..!!");fflush(stdout);
				}
				printf("\n Module Group Value After Dup & Trim: --------> <%s>", modgrp_strDup);fflush(stdout);
			    STRNG_replace_str(modgrp_strDup,","," ",&modgrp_strDup);
			    STRNG_replace_str(modgrp_strDup,";"," ",&modgrp_strDup);
			    STRNG_replace_str(modgrp_strDup,"\n"," ",&modgrp_strDup);
				STRNG_replace_str(modgrp_strDup,"'"," ",&modgrp_strDup);
				printf("\n Module Group Final Value: --------> [%s]\n", modgrp_strDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
			    if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
					trimwhitespace(item_id_strDup);
				}
				else
			    {
					tc_strdup("--",&item_id_strDup);
					printf("\n Module Number Value is NULL..!!");fflush(stdout);
				}
				modaddr_str=subString(item_id_strDup,4,5);
			    printf("\n Module Address Value After[SubString]: [%s]\n", modaddr_str);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"object_desc",&mod_desc_str));
				printf("\n Module Description Before Dup & Trim: ---> <%s> \n",mod_desc_str);fflush(stdout);
				if(tc_strlen(mod_desc_str)>0)
				{
					tc_strdup(mod_desc_str,&mod_desc_strDup);
				}
				else
				{
					tc_strdup("--",&mod_desc_strDup);
					printf("\n Module Description Value is NULL..!!");fflush(stdout);
				}
				trimwhitespace(mod_desc_strDup);
				printf("\n Module Description Value After Dup & Trim: --------> <%s>", mod_desc_strDup);fflush(stdout);
			    STRNG_replace_str(mod_desc_strDup,","," ",&mod_desc_strDup);
			    STRNG_replace_str(mod_desc_strDup,";"," ",&mod_desc_strDup);
			    STRNG_replace_str(mod_desc_strDup,"\n"," ",&mod_desc_strDup);
				STRNG_replace_str(mod_desc_strDup,"'"," ",&mod_desc_strDup);
				printf("\n Module Description Final Value: --------> [%s]\n", mod_desc_strDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
			    if(tc_strlen(item_revseq_str)>0)
				{
					tc_strdup(item_revseq_str,&item_revseq_strDup);
					item_rev_strDup=strtok(item_revseq_strDup,";");
			        item_seq_strDup=strtok(NULL,";");
					printf("\n Module Rev Value After Token: [%s]\n", item_rev_strDup);fflush(stdout);
					printf("\n Module Seq Value After Token: [%s]\n", item_seq_strDup);fflush(stdout);
				}
				else
			    {
					tc_strdup("--",&item_revseq_strDup);
					tc_strdup("--",&item_rev_strDup);
					tc_strdup("--",&item_seq_strDup);
					printf("\n Module Revision Sequence Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Platform",&Platform));
				if(tc_strlen(Platform)>0)
				{
					tc_strdup(Platform,&PlatformDup);
				}
				else
				{
					tc_strdup("--",&PlatformDup);
					printf("\n Platform Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ProjectCode",&ProjectCode));
				if(tc_strlen(ProjectCode)>0)
				{
					tc_strdup(ProjectCode,&ProjectCodeDup);
				}
				else
				{
					tc_strdup("--",&ProjectCodeDup);
					printf("\n Project Code Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartStatus",&DRStatus));
			    if(tc_strlen(DRStatus)>0)
				{
					tc_strdup(DRStatus,&DRStatusDup);
				}
				else
			    {
					tc_strdup("--",&DRStatusDup);
					printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartType",&PartType));
			    if(tc_strlen(PartType)>0)
				{
					tc_strdup(PartType,&PartTypeDup);
				}
				else
			    {
					tc_strdup("NA",&PartTypeDup);
					printf("\n Part Type Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"owning_user",&Owner));
			    if(tc_strlen(Owner)>0)
				{
					tc_strdup(Owner,&OwnerDup);
				}
				else
			    {
					tc_strdup("--",&OwnerDup);
					printf("\n Owner Name Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"creation_date",&dtcreated));
			    if(tc_strlen(dtcreated)>0)
				{
					tc_strdup(dtcreated,&dtcreatedDup);
				}
				else
			    {
					tc_strdup("--",&dtcreatedDup);
					printf("\n Creation Date Value is NULL..!!");fflush(stdout);
				}
				
				printf("\n Function5: Release Status List Find Start..!!\n");fflush(stdout);
				tc_strcpy(cItem_RevSeq,item_rev_strDup);
	            tc_strcat(cItem_RevSeq,"*");
	            tc_strcat(cItem_RevSeq,item_seq_strDup);
	            printf("Item RevSeq: [%s] \n", cItem_RevSeq);fflush(stdout);
				cItem_LCDetails = TC_PartLCDetails(item_id_strDup,cItem_RevSeq);
			    printf("\n Module Release Status Value After Dup & Trim: [%s]", cItem_LCDetails);fflush(stdout);
				printf("\n Function5: Release Status List Find End..!!\n");fflush(stdout);
				
				printf("\n >>>>>>>>>>>>>>> Module Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
				printf("[1] Aggregate_Group: [%s]\n",aggrgrp_strDup);fflush(stdout);
				printf("[2] Aggregate: [%s]\n",aggr_strDup);fflush(stdout);
				printf("[3] Module_Group: [%s]\n",modgrp_strDup);fflush(stdout);
				printf("[4] Module_Address: [%s]\n",modaddr_str);fflush(stdout);
				printf("[5] Module_No: [%s]\n",item_id_strDup);fflush(stdout);
				printf("[6] Module_Description: [%s]\n",mod_desc_strDup);fflush(stdout);
				printf("[7] Revision: [%s]\n",item_rev_strDup);fflush(stdout);
				printf("[8] Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
				printf("[9] Product_Line: [%s]\n",PlatformDup);fflush(stdout);
				printf("[10] Platform: [%s]\n",PlatformDup);fflush(stdout);
				printf("[11] Project_Code: [%s]\n",ProjectCodeDup);fflush(stdout);
				printf("[12] DR/AR Status: [%s]\n",DRStatusDup);fflush(stdout);
				printf("[13] Part Type: [%s]\n",PartTypeDup);fflush(stdout);
				printf("[14] Owner: [%s]\n",OwnerDup);fflush(stdout);
				printf("[15] Creation Date: [%s]\n",dtcreatedDup);fflush(stdout);
				printf("[16] Release Status: [%s]\n",cItem_LCDetails);fflush(stdout);
				printf("\n >>>>>>>>>>>>>>> Module Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
				
				if((tc_strcmp(PartTypeDup,"M")==0) && (tc_strcmp(cItem_LCDetails,"ERCRLZD")==0) && ((tc_strcmp(DRStatusDup,"DR4")==0) || (tc_strcmp(DRStatusDup,"DR5")==0)))
				{
				  fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",aggrgrp_strDup,aggr_strDup,modgrp_strDup,modaddr_str,item_id_strDup,mod_desc_strDup,item_rev_strDup,item_seq_strDup,PlatformDup,PlatformDup,ProjectCodeDup,DRStatusDup,OwnerDup,"ERC",dtcreatedDup);fflush(fpOutput_file);
				}
				if((tc_strcmp(PartTypeDup,"M")==0) && (tc_strcmp(cItem_LCDetails,"MBOMRLZD")==0) && ((tc_strcmp(DRStatusDup,"DR4")==0) || (tc_strcmp(DRStatusDup,"DR5")==0)))
				{
				  fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",aggrgrp_strDup,aggr_strDup,modgrp_strDup,modaddr_str,item_id_strDup,mod_desc_strDup,item_rev_strDup,item_seq_strDup,PlatformDup,PlatformDup,ProjectCodeDup,DRStatusDup,OwnerDup,"MBOM",dtcreatedDup);fflush(fpOutput_file);
				}
			}			
		}
		else
        {
			printf("\n Module Found Zero[0] on DesignRevision PartType..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf("\n Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_LibraryDataRpt.c
* // ./linkitk -o tm_LibraryDataRpt tm_LibraryDataRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LibraryDataHunt/tm_LibraryDataRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LibraryDataHunt/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LibraryDataHunt/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LibraryDataHunt/SendEmail.sh .
* // ./tm_LibraryDataRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_LibraryDataRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/