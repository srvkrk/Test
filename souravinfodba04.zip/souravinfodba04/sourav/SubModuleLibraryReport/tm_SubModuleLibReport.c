/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Generate Full Static SubModule Library Details Report  
*  File Name    :   tm_SubModuleLibReport.c
*  Created on   :   June 18th, 2024
*  Usage        :   tm_SubModuleLibReport
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     18/06/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
    tag_t AggrGrpRev_tag = NULLTAG;
	char* aggrgrp_no = NULL;
	char* aggrgrp_nodup = NULL;
	/* char* aggrgrp_name = NULL;
	char* aggrgrp_namedup = NULL;
    char* aggrgrp_desc = NULL; */
	char* aggrgrp_descdup = NULL;
	tag_t AggrGrpToAggrRel = NULLTAG;
	int sec_countaggr = 0;
	tag_t* sec_aggrobjects = NULLTAG;
	tag_t AggrRev_tag = NULLTAG;
	char* aggr_no = NULL;
	char* aggr_nodup = NULL;
	/* char* aggr_name = NULL;
	char* aggr_namedup = NULL;
	char* aggr_desc = NULL;
	char* aggr_descdup = NULL; */
	tag_t AggrToModRel = NULLTAG;
	int sec_countmod = 0;
	tag_t* sec_modobjects = NULLTAG;
	tag_t ModRev_tag = NULLTAG;
	char* mod_no = NULL;
	char* mod_nodup = NULL;
	/* char* mod_name = NULL;
	char* mod_namedup = NULL;
	char* mod_desc = NULL;
	char* mod_descdup = NULL; */
	tag_t ModToSubModRel = NULLTAG;
	int sec_countsubmod = 0;
	tag_t* sec_submodobjects = NULLTAG;
	tag_t SubModRev_tag = NULLTAG;
	char* submod_no = NULL;
	char* submod_nodup = NULL;
	/* char* submod_name = NULL;
	char* submod_namedup = NULL;
	char* submod_desc = NULL;
	char* submod_descdup = NULL; */
	char* submod_address = NULL;
	char* submod_addressdup = NULL;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
	int iValCnt = 0;
	tag_t ttablerow_rev = NULLTAG;
	char* Tbl_SubModNo = NULL;
	char* Tbl_SubModNodup = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModRevdup = NULL;
	char* Tbl_SubModSeq = NULL;
	char* Tbl_SubModSeqdup = NULL;
	/* char* Tbl_SubModDesc = NULL;
	char* Tbl_SubModDescdup = NULL;
	char* Tbl_SubModProd = NULL;
	char* Tbl_SubModProddup = NULL;
	char* Tbl_SubModPlat = NULL;
	char* Tbl_SubModPlatdup = NULL; */
	char* Tbl_SubModProj = NULL;
	char* Tbl_SubModProjdup = NULL;
	char* Tbl_SubModDRAR = NULL;
	char* Tbl_SubModDRARdup = NULL;
	char variety[100];
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"SubModuleLibraryReport");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n CSV Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating XML Report File Name..!!");fflush(stdout);
	Report=fopen("/tmp/SubModuleLibraryReport.xml","w");
	if(Report == NULL)
	{
		printf("ERROR: Unable To Open XML File..!!\n");
		return -1;
	}
	else
	{
		printf("XML File Opened Successfully..!!\n");
	}

	strftime(GenDate,100,"%d-%m-%Y %H:%M:%S",&when);
	write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	//write2xml(Report,"\n<PLMXML date=\"");
	//write2xml(Report,GenDate);
	//write2xml(Report,"\">\n");
	
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"AGGREGATE_GROUP, AGGREGATES, MODULE, SUBMODULE, SUBMODULE_NO, REVISION, SEQUENCE, SUBMODULE_DESCRIPTION, PRODUCT_LINE, PLATFORM, PROJECT_CODE, AR/DR_STATUS,VARIETY)\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	write2xml(Report,"<SubMooduleDashboard>\n");
	printf("\n Finding Query[SubModuleLibraryAggrGrp]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("SubModuleLibraryAggrGrp",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query SubModuleLibraryAggrGrp Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total SubModule Library Aggregate Group Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
			{
				char* aggrgrp_name = NULL;
				char* aggrgrp_namedup = NULL;
				char* aggrgrp_desc = NULL;
	
				AggrGrpRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"item_id",&aggrgrp_no));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_name",&aggrgrp_name));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_desc",&aggrgrp_desc));
				trimwhitespace(aggrgrp_no);
				trimwhitespace(aggrgrp_name);
				trimwhitespace(aggrgrp_desc);
				if(aggrgrp_no!=NULL)tc_strdup(aggrgrp_no,&aggrgrp_nodup);
				if(aggrgrp_name!=NULL)tc_strdup(aggrgrp_name,&aggrgrp_namedup);
				if(aggrgrp_desc!=NULL)tc_strdup(aggrgrp_desc,&aggrgrp_descdup);
				printf("\n Aggregate Group No(aggrgrp_nodup): [%s]\n", aggrgrp_nodup);
				printf("\n Aggregate Group Name(aggrgrp_namedup): [%s]\n", aggrgrp_namedup);
				printf("\n Aggregate Group Description(aggrgrp_descdup): [%s]\n", aggrgrp_descdup);
				//if(aggrgrp_namedup != NULL) STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
				//if(aggrgrp_descdup != NULL) STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
				//if(tc_strlen(aggrgrp_namedup)>0) STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
				//if(tc_strlen(aggrgrp_descdup)>0) STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
				STRNG_replace_str(aggrgrp_namedup,"&","And",&aggrgrp_namedup);
				STRNG_replace_str(aggrgrp_descdup,"&","And",&aggrgrp_descdup);
				
				if(aggrgrp_namedup != NULL)
				{
					STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,"<","&lt;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,">","&gt;",&aggrgrp_namedup);
				}
				
				if(aggrgrp_descdup != NULL)
				{
					STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,"<","&lt;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,">","&gt;",&aggrgrp_descdup);
				}
				
				ITK_CALL(GRM_find_relation_type("T5_Submdlbagrpagrrel",&AggrGrpToAggrRel));
				if(AggrGrpToAggrRel!=NULLTAG)
				{									
				    printf("\n Sudo Folder Aggregate Details(T5_Submdlbagrpagrrel) Relation Found..!!\n");fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(AggrGrpRev_tag, AggrGrpToAggrRel, &sec_countaggr, &sec_aggrobjects));
				    printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
					if(sec_countaggr > 0)
					{
						for(j = 0; j < sec_countaggr; j++)
			            {
							char* aggr_name = NULL;
							char* aggr_namedup = NULL;
							char* aggr_desc = NULL;
							char* aggr_descdup = NULL; 
	
						    AggrRev_tag = sec_aggrobjects[j];
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"item_id",&aggr_no));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_name",&aggr_name));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_desc",&aggr_desc));
							trimwhitespace(aggr_no);
							trimwhitespace(aggr_name);
							trimwhitespace(aggr_desc);
							if(aggr_no!=NULL)tc_strdup(aggr_no,&aggr_nodup);
							if(aggr_name!=NULL)tc_strdup(aggr_name,&aggr_namedup);
							if(aggr_desc!=NULL)tc_strdup(aggr_desc,&aggr_descdup);
						    printf("\n Aggregate No(aggr_nodup): [%s]\n", aggr_nodup);
							printf("\n Aggregate Name(aggr_namedup): [%s]\n", aggr_namedup);
							printf("\n Aggregate Description(aggr_descdup): [%s]\n", aggr_descdup);
							//if(aggr_namedup != NULL) STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
							//if(aggr_descdup != NULL) STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
							
							//if(tc_strlen(aggr_namedup)>0) STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
				            //if(tc_strlen(aggr_descdup)>0) STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
							
							STRNG_replace_str(aggr_namedup,"&","And",&aggr_namedup);
				            STRNG_replace_str(aggr_descdup,"&","And",&aggr_descdup);
							
							if(aggr_namedup != NULL)
							{
								STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,"<","&lt;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,">","&gt;",&aggr_namedup);
							}
							
							if(aggr_descdup != NULL)
							{
								STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,"<","&lt;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,">","&gt;",&aggr_descdup);
							}
							
							ITK_CALL(GRM_find_relation_type("T5_Submdlbagrmodrel",&AggrToModRel));
							if(AggrToModRel!=NULLTAG)
							{									
								printf("\n Sudo Folder Module Details(T5_Submdlbagrmodrel) Relation Found..!!\n");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AggrRev_tag, AggrToModRel, &sec_countmod, &sec_modobjects));
								printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
								if(sec_countmod > 0)
								{
									for(k = 0; k < sec_countmod; k++)
									{
										char* mod_name = NULL;
										char* mod_namedup = NULL;
										char* mod_desc = NULL;
										char* mod_descdup = NULL;
										
										ModRev_tag = sec_modobjects[k];
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"item_id",&mod_no));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_name",&mod_name));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_desc",&mod_desc));
										trimwhitespace(mod_no);
										trimwhitespace(mod_name);
										trimwhitespace(mod_desc);
										if(mod_no!=NULL)tc_strdup(mod_no,&mod_nodup);
										if(mod_name!=NULL)tc_strdup(mod_name,&mod_namedup);
										if(mod_desc!=NULL)tc_strdup(mod_desc,&mod_descdup);
										printf("\n Module No(mod_nodup): [%s]\n", mod_nodup);
										printf("\n Module Name(mod_name): [%s]\n", mod_namedup);
										printf("\n Module Description(mod_desc): [%s]\n", mod_descdup);
										//if(mod_namedup != NULL) STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
										//if(mod_descdup != NULL) STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
										
										//if(tc_strlen(mod_namedup)>0) STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
				                        //if(tc_strlen(mod_descdup)>0) STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
										
										STRNG_replace_str(mod_namedup,"&","And",&mod_namedup);
				                        STRNG_replace_str(mod_descdup,"&","And",&mod_descdup);
										
										if(mod_namedup != NULL)
										{
											STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
											STRNG_replace_str(mod_namedup,"<","&lt;",&mod_namedup);
											STRNG_replace_str(mod_namedup,">","&gt;",&mod_namedup);
										}
										
										if(mod_descdup != NULL)
										{
											STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
											STRNG_replace_str(mod_descdup,"<","&lt;",&mod_descdup);
											STRNG_replace_str(mod_descdup,">","&gt;",&mod_descdup);
										}

                                        ITK_CALL(GRM_find_relation_type("T5_Submdlbmodsubrel",&ModToSubModRel));
										if(ModToSubModRel!=NULLTAG)
										{									
											printf("\n Sudo Folder SubModule Details(T5_Submdlbmodsubrel) Relation Found..!!\n");fflush(stdout);
											ITK_CALL(GRM_list_secondary_objects_only(ModRev_tag, ModToSubModRel, &sec_countsubmod, &sec_submodobjects));
											printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
											if(sec_countsubmod > 0)
											{
												for(l = 0; l < sec_countsubmod; l++)
												{
													char* submod_name = NULL;
													char* submod_namedup = NULL;
													char* submod_desc = NULL;
													char* submod_descdup = NULL;
	
													SubModRev_tag = sec_submodobjects[l];
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"item_id",&submod_no));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_name",&submod_name));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_desc",&submod_desc));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"t5_ModuleAddrSL",&submod_address));
													trimwhitespace(submod_no);
													trimwhitespace(submod_name);
													trimwhitespace(submod_desc);
													trimwhitespace(submod_address);
													if(submod_no!=NULL)tc_strdup(submod_no,&submod_nodup);
													if(submod_name!=NULL)tc_strdup(submod_name,&submod_namedup);
													if(submod_desc!=NULL)tc_strdup(submod_desc,&submod_descdup);
													if(submod_address!=NULL)tc_strdup(submod_address,&submod_addressdup);
													printf("\n SubModule No(submod_nodup): [%s]\n", submod_nodup);
													printf("\n SubModule Name(submod_namedup): [%s]\n", submod_namedup);
													printf("\n SubModule Description(submod_descdup): [%s]\n", submod_descdup);
													printf("\n Module Address(submod_addressdup): [%s]\n", submod_addressdup);
													//if(submod_namedup != NULL) STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
													//if(submod_descdup != NULL) STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
													//if(submod_addressdup != NULL) STRNG_replace_str(submod_addressdup,"&","&amp;",&submod_addressdup);
													
													//if(tc_strlen(submod_namedup)>0) STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
				                                    //if(tc_strlen(submod_descdup)>0) STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
													//if(tc_strlen(submod_addressdup)>0) STRNG_replace_str(submod_addressdup,"&","&amp;",&submod_addressdup);
													
													STRNG_replace_str(submod_namedup,"&","And",&submod_namedup);
				                                    STRNG_replace_str(submod_descdup,"&","And",&submod_descdup);
													STRNG_replace_str(submod_namedup,"""","",&submod_namedup);
													STRNG_replace_str(submod_descdup,"""","",&submod_descdup);
													
													if(submod_namedup != NULL)
													{
														STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
														STRNG_replace_str(submod_namedup,"<","&lt;",&submod_namedup);
														STRNG_replace_str(submod_namedup,">","&gt;",&submod_namedup);
													}
													
													if(submod_descdup != NULL)
													{
														STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
														STRNG_replace_str(submod_descdup,"<","&lt;",&submod_descdup);
														STRNG_replace_str(submod_descdup,">","&gt;",&submod_descdup);
													}
													
													ITK_CALL(AOM_ask_table_rows(SubModRev_tag,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
													printf("\n No of Table Row [%d]  For SubModule  [%s]\n", n_valid_rows, submod_nodup);fflush(stdout);
													if(n_valid_rows>0)
													{
														for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
														{
															char* Tbl_SubModDesc = NULL;
															char* Tbl_SubModDescdup = NULL;
															char* Tbl_SubModProd = NULL;
															char* Tbl_SubModProddup = NULL;
															char* Tbl_SubModPlat = NULL;
															char* Tbl_SubModPlatdup = NULL;
															
															
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));	
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_rev",&Tbl_SubModRev));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_seq",&Tbl_SubModSeq));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_desc",&Tbl_SubModDesc));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_Platform",&Tbl_SubModPlat));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_projectcode",&Tbl_SubModProj));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",&Tbl_SubModDRAR));
															
															trimwhitespace(Tbl_SubModNo);
															trimwhitespace(Tbl_SubModRev);
															trimwhitespace(Tbl_SubModSeq);
															trimwhitespace(Tbl_SubModDesc);
				                                            printf("\n SubModule Description Value Before Dup & Trim: --------> <%s>", Tbl_SubModDesc);fflush(stdout);
															STRNG_replace_str(Tbl_SubModDesc,","," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,";"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"\n"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"'"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"&","And",&Tbl_SubModDesc);
															trimwhitespace(Tbl_SubModProd);
															trimwhitespace(Tbl_SubModPlat);
															trimwhitespace(Tbl_SubModProj);
															trimwhitespace(Tbl_SubModDRAR);
													        if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
															if(Tbl_SubModRev!=NULL)tc_strdup(Tbl_SubModRev,&Tbl_SubModRevdup);
															if(Tbl_SubModSeq!=NULL)tc_strdup(Tbl_SubModSeq,&Tbl_SubModSeqdup);
															if(Tbl_SubModDesc!=NULL)tc_strdup(Tbl_SubModDesc,&Tbl_SubModDescdup);
															if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
															if(Tbl_SubModPlat!=NULL)tc_strdup(Tbl_SubModPlat,&Tbl_SubModPlatdup);
															if(Tbl_SubModProj!=NULL)tc_strdup(Tbl_SubModProj,&Tbl_SubModProjdup);
															if(Tbl_SubModDRAR!=NULL)tc_strdup(Tbl_SubModDRAR,&Tbl_SubModDRARdup);
													        printf("\n Table SubModule No(Tbl_SubModNodup): [%s]\n", Tbl_SubModNodup);
															printf("\n Table SubModule Rev(Tbl_SubModRevdup): [%s]",Tbl_SubModRevdup);fflush(stdout);
															printf("\n Table SubModule Seq(Tbl_SubModSeqdup): [%s]",Tbl_SubModSeqdup);fflush(stdout);
															printf("\n Table SubModule Description(Tbl_SubModDescdup): [%s]",Tbl_SubModDescdup);fflush(stdout);
															printf("\n Table SubModule Peoductline(Tbl_SubModProddup): [%s]",Tbl_SubModProddup);fflush(stdout);
															printf("\n Table SubModule Platform(Tbl_SubModPlatdup): [%s]",Tbl_SubModPlatdup);fflush(stdout);
															printf("\n Table SubModule Project Code(Tbl_SubModProjdup): [%s]",Tbl_SubModProjdup);fflush(stdout);
															printf("\n Table SubModule DR/AR(Tbl_SubModDRARdup): [%s]",Tbl_SubModDRARdup);fflush(stdout);
															
															printf("\n >>>>>>>>>>>>>>> SubModule Library Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
															printf("[1] Aggregate_Group: [%s]\n",aggrgrp_nodup);fflush(stdout);
															printf("[2] Aggregate_Group_Name: [%s]\n",aggrgrp_namedup);fflush(stdout);
															printf("[3] Aggregate_Group_Description: [%s]\n",aggrgrp_descdup);fflush(stdout);
															printf("[4] Aggregate: [%s]\n",aggr_nodup);fflush(stdout);
															printf("[5] Aggregate_Name: [%s]\n",aggr_namedup);fflush(stdout);
															printf("[6] Aggregate_Description: [%s]\n",aggr_descdup);fflush(stdout);
															printf("[7] Module: [%s]\n",mod_nodup);fflush(stdout);
															printf("[8] Module_Name: [%s]\n",mod_namedup);fflush(stdout);
															printf("[9] Module_Description: [%s]\n",mod_descdup);fflush(stdout);
															printf("[10] SubModule: [%s]\n",submod_nodup);fflush(stdout);
															printf("[11] SubModule_Name: [%s]\n",submod_namedup);fflush(stdout);
															printf("[12] SubModule_Description: [%s]\n",submod_descdup);fflush(stdout);
															printf("[13] Module_Address: [%s]\n",submod_addressdup);fflush(stdout);
															printf("[14] SubModule_No: [%s]\n",Tbl_SubModNodup);fflush(stdout);
															printf("[15] Revision: [%s]\n",Tbl_SubModRevdup);fflush(stdout);
															printf("[16] Sequence: [%s]\n",Tbl_SubModSeqdup);fflush(stdout);
															printf("[17] Description: [%s]\n",Tbl_SubModDescdup);fflush(stdout);
															printf("[18] Product Line: [%s]\n",Tbl_SubModProddup);fflush(stdout);
															printf("[19] Platform: [%s]\n",Tbl_SubModPlatdup);fflush(stdout);
															printf("[20] Project Code: [%s]\n",Tbl_SubModProjdup);fflush(stdout);
															printf("[21] DR/AR Status: [%s]\n",Tbl_SubModDRARdup);fflush(stdout);
															tostring(variety, n_valid_rows);
															printf("[22] Variety: [%s]\n",variety);fflush(stdout);
															printf("\n >>>>>>>>>>>>>>> SubModule Library Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
															
															fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",aggrgrp_nodup,aggr_nodup,mod_nodup,submod_nodup,Tbl_SubModNodup,Tbl_SubModRevdup,Tbl_SubModSeqdup,Tbl_SubModDescdup,Tbl_SubModProddup,Tbl_SubModPlatdup,Tbl_SubModProjdup,Tbl_SubModDRARdup,variety);fflush(fpOutput_file);
															
															//if(aggrgrp_namedup != NULL) STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
															//if(aggrgrp_namedup != NULL) STRNG_replace_str(aggrgrp_namedup,">","&gt;",&aggrgrp_namedup);
															//if(aggrgrp_namedup != NULL) STRNG_replace_str(aggrgrp_namedup,"<","&lt;",&aggrgrp_namedup);
															//if(aggrgrp_namedup != NULL) STRNG_replace_str(aggrgrp_namedup,"'","&apos;",&aggrgrp_namedup);
															//if(aggrgrp_namedup != NULL) STRNG_replace_str(aggrgrp_namedup,"""","&quot",&aggrgrp_namedup);
															//if(aggrgrp_descdup != NULL) STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
															//if(aggrgrp_descdup != NULL) STRNG_replace_str(aggrgrp_descdup,">","&gt;",&aggrgrp_descdup);
															//if(aggrgrp_descdup != NULL) STRNG_replace_str(aggrgrp_descdup,"<","&lt;",&aggrgrp_descdup);
															//if(aggrgrp_descdup != NULL) STRNG_replace_str(aggrgrp_descdup,"'","&apos;",&aggrgrp_descdup);
															//if(aggrgrp_descdup != NULL) STRNG_replace_str(aggrgrp_descdup,"""","&quot",&aggrgrp_descdup);
															//if(aggr_namedup != NULL) STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
															//if(aggr_namedup != NULL) STRNG_replace_str(aggr_namedup,">","&gt;",&aggr_namedup);
															//if(aggr_namedup != NULL) STRNG_replace_str(aggr_namedup,"<","&lt;",&aggr_namedup);
															//if(aggr_namedup != NULL) STRNG_replace_str(aggr_namedup,"'","&apos;",&aggr_namedup);
															//if(aggr_namedup != NULL) STRNG_replace_str(aggr_namedup,"""","&quot",&aggr_namedup);
															//if(aggr_descdup != NULL) STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
															//if(aggr_descdup != NULL) STRNG_replace_str(aggr_descdup,">","&gt;",&aggr_descdup);
															//if(aggr_descdup != NULL) STRNG_replace_str(aggr_descdup,"<","&lt;",&aggr_descdup);
															//if(aggr_descdup != NULL) STRNG_replace_str(aggr_descdup,"'","&apos;",&aggr_descdup);
															//if(aggr_descdup != NULL) STRNG_replace_str(aggr_descdup,"""","&quot",&aggr_descdup);
															//if(mod_namedup != NULL) STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
															//if(mod_namedup != NULL) STRNG_replace_str(mod_namedup,">","&gt;",&mod_namedup);
															//if(mod_namedup != NULL) STRNG_replace_str(mod_namedup,"<","&lt;",&mod_namedup);
															//if(mod_namedup != NULL) STRNG_replace_str(mod_namedup,"'","&apos;",&mod_namedup);
															//if(mod_namedup != NULL) STRNG_replace_str(mod_namedup,"""","&quot",&mod_namedup);
															//if(mod_descdup != NULL) STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
															//if(mod_descdup != NULL) STRNG_replace_str(mod_descdup,">","&gt;",&mod_descdup);
															//if(mod_descdup != NULL) STRNG_replace_str(mod_descdup,"<","&lt;",&mod_descdup);
															//if(mod_descdup != NULL) STRNG_replace_str(mod_descdup,"'","&apos;",&mod_descdup);
															//if(mod_descdup != NULL) STRNG_replace_str(mod_descdup,"""","&quot",&mod_descdup);
															//if(submod_namedup != NULL) STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
															//if(submod_namedup != NULL) STRNG_replace_str(submod_namedup,">","&gt;",&submod_namedup);
															//if(submod_namedup != NULL) STRNG_replace_str(submod_namedup,"<","&lt;",&submod_namedup);
															//if(submod_namedup != NULL) STRNG_replace_str(submod_namedup,"'","&apos;",&submod_namedup);
															//if(submod_namedup != NULL) STRNG_replace_str(submod_namedup,"""","&quot",&submod_namedup);
															//if(submod_descdup != NULL) STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
															//if(submod_descdup != NULL) STRNG_replace_str(submod_descdup,">","&gt;",&submod_descdup);
															//if(submod_descdup != NULL) STRNG_replace_str(submod_descdup,"<","&lt;",&submod_descdup);
															//if(submod_descdup != NULL) STRNG_replace_str(submod_descdup,"'","&apos;",&submod_descdup);
															//if(submod_descdup != NULL) STRNG_replace_str(submod_descdup,"""","&quot",&submod_descdup);
															//if(submod_addressdup != NULL) STRNG_replace_str(submod_addressdup,"&","&amp;",&submod_addressdup);
															//if(submod_addressdup != NULL) STRNG_replace_str(submod_addressdup,">","&gt;",&submod_addressdup);
															//if(submod_addressdup != NULL) STRNG_replace_str(submod_addressdup,"<","&lt;",&submod_addressdup);
															//if(submod_addressdup != NULL) STRNG_replace_str(submod_addressdup,"'","&apos;",&submod_addressdup);
															//if(submod_addressdup != NULL) STRNG_replace_str(submod_addressdup,"""","&quot",&submod_addressdup);
														//if(Tbl_SubModDescdup != NULL) STRNG_replace_str(Tbl_SubModDescdup,"&","&amp;",&Tbl_SubModDescdup);
															//if(Tbl_SubModDescdup != NULL) STRNG_replace_str(Tbl_SubModDescdup,">","&gt;",&Tbl_SubModDescdup);
															//if(Tbl_SubModDescdup != NULL) STRNG_replace_str(Tbl_SubModDescdup,"<","&lt;",&Tbl_SubModDescdup);
															//if(Tbl_SubModDescdup != NULL) STRNG_replace_str(Tbl_SubModDescdup,"'","&apos;",&Tbl_SubModDescdup);
															//if(Tbl_SubModDescdup != NULL) STRNG_replace_str(Tbl_SubModDescdup,"""","&quot",&Tbl_SubModDescdup);
														//if(Tbl_SubModProddup != NULL) STRNG_replace_str(Tbl_SubModProddup,"&","&amp;",&Tbl_SubModProddup);
															//if(Tbl_SubModProddup != NULL) STRNG_replace_str(Tbl_SubModProddup,">","&gt;",&Tbl_SubModProddup);
															//if(Tbl_SubModProddup != NULL) STRNG_replace_str(Tbl_SubModProddup,"<","&lt;",&Tbl_SubModProddup);
															//if(Tbl_SubModProddup != NULL) STRNG_replace_str(Tbl_SubModProddup,"'","&apos;",&Tbl_SubModProddup);
															//if(Tbl_SubModProddup != NULL) STRNG_replace_str(Tbl_SubModProddup,"""","&quot",&Tbl_SubModProddup);
														//if(Tbl_SubModPlatdup != NULL) STRNG_replace_str(Tbl_SubModPlatdup,"&","&amp;",&Tbl_SubModPlatdup);
															//if(Tbl_SubModPlatdup != NULL) STRNG_replace_str(Tbl_SubModPlatdup,">","&gt;",&Tbl_SubModPlatdup);
															//if(Tbl_SubModPlatdup != NULL) STRNG_replace_str(Tbl_SubModPlatdup,"<","&lt;",&Tbl_SubModPlatdup);
															//if(Tbl_SubModPlatdup != NULL) STRNG_replace_str(Tbl_SubModPlatdup,"'","&apos;",&Tbl_SubModPlatdup);
															//if(Tbl_SubModPlatdup != NULL) STRNG_replace_str(Tbl_SubModPlatdup,"""","&quot",&Tbl_SubModPlatdup);
						
															if(tc_strlen(Tbl_SubModDescdup)>0) STRNG_replace_str(Tbl_SubModDescdup,"&","&amp;",&Tbl_SubModDescdup);
				                                            if(tc_strlen(Tbl_SubModProddup)>0) STRNG_replace_str(Tbl_SubModProddup,"&","&amp;",&Tbl_SubModProddup);
													        if(tc_strlen(Tbl_SubModPlatdup)>0) STRNG_replace_str(Tbl_SubModPlatdup,"&","&amp;",&Tbl_SubModPlatdup);
															
															/* write2xml(Report,"<SubmoduleDetail>\n");
															write2xml(Report,"<AggregateGrpName>"); if(aggrgrp_namedup != NULL) write2xml(Report,aggrgrp_namedup); else write2xml(Report,"NA"); write2xml(Report,"</AggregateGrpName>\n");
															write2xml(Report,"<AggregateGrpDesc>"); if(aggrgrp_descdup != NULL) write2xml(Report,aggrgrp_descdup); else write2xml(Report,"NA"); write2xml(Report,"</AggregateGrpDesc>\n");
														    write2xml(Report,"<AggregateName>"); if(aggr_namedup != NULL) write2xml(Report,aggr_namedup); else write2xml(Report,"NA"); write2xml(Report,"</AggregateName>\n");
															write2xml(Report,"<AggregateDesc>"); if(aggr_descdup != NULL) write2xml(Report,aggr_descdup); else write2xml(Report,"NA"); write2xml(Report,"</AggregateDesc>\n");
														    write2xml(Report,"<ModuleName>"); if(mod_namedup != NULL) write2xml(Report,mod_namedup); else write2xml(Report,"NA"); write2xml(Report,"</ModuleName>\n");
															write2xml(Report,"<ModuleDesc>"); if(mod_descdup != NULL) write2xml(Report,mod_descdup); else write2xml(Report,"NA"); write2xml(Report,"</ModuleDesc>\n");
														    write2xml(Report,"<SubmoduleName>"); if(submod_namedup != NULL) write2xml(Report,submod_namedup); else write2xml(Report,"NA"); write2xml(Report,"</SubmoduleName>\n");
															write2xml(Report,"<SubmoduleDesc>"); if(submod_descdup != NULL) write2xml(Report,submod_descdup); else write2xml(Report,"NA"); write2xml(Report,"</SubmoduleDesc>\n");
															write2xml(Report,"<SubmoduleAdd>"); if(submod_addressdup != NULL) write2xml(Report,submod_addressdup); else write2xml(Report,"NA"); write2xml(Report,"</SubmoduleAdd>\n");
														    write2xml(Report,"<TBL_SubmoduleNo>"); if(Tbl_SubModNodup != NULL) write2xml(Report,Tbl_SubModNodup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleNo>\n");
															write2xml(Report,"<TBL_SubmoduleRev>"); if(Tbl_SubModRevdup != NULL) write2xml(Report,Tbl_SubModRevdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleRev>\n");
															write2xml(Report,"<TBL_SubmoduleSeq>"); if(Tbl_SubModSeqdup != NULL) write2xml(Report,Tbl_SubModSeqdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleSeq>\n");
															write2xml(Report,"<TBL_SubmoduleDesc>"); if(Tbl_SubModDescdup != NULL) write2xml(Report,Tbl_SubModDescdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleDesc>\n");
															write2xml(Report,"<TBL_SubmoduleProd>"); if(Tbl_SubModProddup != NULL) write2xml(Report,Tbl_SubModProddup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleProd>\n");
															write2xml(Report,"<TBL_SubmodulePlat>"); if(Tbl_SubModPlatdup != NULL) write2xml(Report,Tbl_SubModPlatdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmodulePlat>\n");
															write2xml(Report,"<TBL_SubmoduleProj>"); if(Tbl_SubModProjdup != NULL) write2xml(Report,Tbl_SubModProjdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleProj>\n");
															write2xml(Report,"<TBL_SubmoduleDrAr>"); if(Tbl_SubModDRARdup != NULL) write2xml(Report,Tbl_SubModDRARdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleDrAr>\n");
															write2xml(Report,"<TBL_SubmoduleVariety>"); if(variety != NULL) write2xml(Report,variety); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleVariety>\n");
															write2xml(Report,"</SubmoduleDetail>\n"); */
															
															write2xml(Report,"<SubmoduleDetail>\n");
															write2xml(Report,"<AggregateGrpName>"); if(tc_strlen(aggrgrp_namedup)>0) write2xml(Report,aggrgrp_namedup); else write2xml(Report,"NA"); write2xml(Report,"</AggregateGrpName>\n");
															write2xml(Report,"<AggregateGrpDesc>"); if(tc_strlen(aggrgrp_descdup)>0) write2xml(Report,aggrgrp_descdup); else write2xml(Report,"NA"); write2xml(Report,"</AggregateGrpDesc>\n");
														    write2xml(Report,"<AggregateName>"); if(tc_strlen(aggr_namedup)>0) write2xml(Report,aggr_namedup); else write2xml(Report,"NA"); write2xml(Report,"</AggregateName>\n");
															write2xml(Report,"<AggregateDesc>"); if(tc_strlen(aggr_descdup)>0) write2xml(Report,aggr_descdup); else write2xml(Report,"NA"); write2xml(Report,"</AggregateDesc>\n");
														    write2xml(Report,"<ModuleName>"); if(tc_strlen(mod_namedup)>0) write2xml(Report,mod_namedup); else write2xml(Report,"NA"); write2xml(Report,"</ModuleName>\n");
															write2xml(Report,"<ModuleDesc>"); if(tc_strlen(mod_descdup)>0) write2xml(Report,mod_descdup); else write2xml(Report,"NA"); write2xml(Report,"</ModuleDesc>\n");
														    write2xml(Report,"<SubmoduleName>"); if(tc_strlen(submod_namedup)>0) write2xml(Report,submod_namedup); else write2xml(Report,"NA"); write2xml(Report,"</SubmoduleName>\n");
															write2xml(Report,"<SubmoduleDesc>"); if(tc_strlen(submod_descdup)>0) write2xml(Report,submod_descdup); else write2xml(Report,"NA"); write2xml(Report,"</SubmoduleDesc>\n");
															write2xml(Report,"<SubmoduleAdd>"); if(tc_strlen(submod_addressdup)>0) write2xml(Report,submod_addressdup); else write2xml(Report,"NA"); write2xml(Report,"</SubmoduleAdd>\n");
														    write2xml(Report,"<TBL_SubmoduleNo>"); if(tc_strlen(Tbl_SubModNodup)>0) write2xml(Report,Tbl_SubModNodup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleNo>\n");
															write2xml(Report,"<TBL_SubmoduleRev>"); if(tc_strlen(Tbl_SubModRevdup)>0) write2xml(Report,Tbl_SubModRevdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleRev>\n");
															write2xml(Report,"<TBL_SubmoduleSeq>"); if(tc_strlen(Tbl_SubModSeqdup)>0) write2xml(Report,Tbl_SubModSeqdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleSeq>\n");
															write2xml(Report,"<TBL_SubmoduleDesc>"); if(tc_strlen(Tbl_SubModDescdup)>0) write2xml(Report,Tbl_SubModDescdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleDesc>\n");
															write2xml(Report,"<TBL_SubmoduleProd>"); if(tc_strlen(Tbl_SubModProddup)>0) write2xml(Report,Tbl_SubModProddup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleProd>\n");
															write2xml(Report,"<TBL_SubmodulePlat>"); if(tc_strlen(Tbl_SubModPlatdup)>0) write2xml(Report,Tbl_SubModPlatdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmodulePlat>\n");
															write2xml(Report,"<TBL_SubmoduleProj>"); if(tc_strlen(Tbl_SubModProjdup)>0) write2xml(Report,Tbl_SubModProjdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleProj>\n");
															write2xml(Report,"<TBL_SubmoduleDrAr>"); if(tc_strlen(Tbl_SubModDRARdup)>0) write2xml(Report,Tbl_SubModDRARdup); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleDrAr>\n");
															write2xml(Report,"<TBL_SubmoduleVariety>"); if(tc_strlen(variety)>0) write2xml(Report,variety); else write2xml(Report,"NA"); write2xml(Report,"</TBL_SubmoduleVariety>\n");
															write2xml(Report,"</SubmoduleDetail>\n");
														}
													}
													else
													{
														printf("\n No Table Row Found For Input SubModule: [%s], submod_nodup\n");fflush(stdout);
													} 
												}
											}
											else
											{
												printf("\n SubModule Not Found For Module: [%s]\n", mod_nodup);fflush(stdout);
											}
										}
										else
										{
											printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
										}										
									}
								}
								else
								{
									printf("\n Module Not Found For Aggregate: [%s]\n", aggr_nodup);fflush(stdout);
								}
							}
							else
							{
								printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Aggregate Not Found For Aggregate Group: [%s]\n", aggrgrp_nodup);fflush(stdout);
					}
				}
				else
				{
					printf("\n Aggregate Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
				}
			}			
		}
		else
        {
			printf(" Aggregate Group Found Zero[0] on SubModuleLibraryAggrGrp..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	write2xml(Report,"</SubMooduleDashboard>\n");
	//write2xml(Report,"</PLMXML>\n");
	fclose(Report);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_SubModuleLibReport.c
* // ./linkitk -o tm_SubModuleLibReport tm_SubModuleLibReport.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/SubModuleLibraryReport/tm_SubModuleLibReport .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/SubModuleLibraryReport/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/SubModuleLibraryReport/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/SubModuleLibraryReport/SendEmail.sh .
* // ./tm_SubModuleLibReport -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_SubModuleLibReport -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/