/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   BOM
*  Description  :   Report for Comparing Standalone VC BOM vs Solved BOM after applying SVR in CVProd 
*  File Name    :   tm_stdvc_svr_bom_rpt.c
*  Created on   :   July 5th, 2023
*  Usage        :   tm_stdvc_svr_bom_rpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     05/07/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -plat=<Platform Name> (Required)\n"
		" -svr=<SVR> (Required)\n"
		" -rrule=<Revision Rule> (Required)\n"
		" -vc=<VC No> (Required)\n"
        );	
}

char* TC_PartDesc(char* PNSrch)
{
	trimwhitespace(PNSrch);
	printf("\n Searched Part Number Value After Trim --------> %s\n", PNSrch);fflush(stdout);
	int iFail = 0;
	int n_tags_found = 0;
	tag_t *tags_found = NULLTAG;
	tag_t item_t = NULLTAG;
	const char *attrs[1];
	const char *values[1];
	attrs[0] ="item_id";
	values[0] = PNSrch;
	printf("\n values[0] ---> <%s> \n", values[0]);fflush(stdout);
	iFail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
    printf("\n No of Tag Found: ----> <%d> \n",n_tags_found );fflush(stdout);
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	if(n_tags_found > 0)
	{
        //item_t = tags_found[1];
        //AOM_ask_value_string(item_t,"object_desc",&cItem_Desc);
		AOM_ask_value_string(tags_found[0],"object_desc",&cItem_Desc);
		printf("\n Item Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
		if(tc_strlen(cItem_Desc)>0)
		{
			tc_strdup(cItem_Desc,&cItem_DescDup);
		}
		else
		{
		    tc_strdup("NULL",&cItem_DescDup);
			printf("\n Item Description Value is NULL");fflush(stdout);
		}
		trimwhitespace(cItem_DescDup);
		printf("\n Item Description Value After Dup & Trim --------> %s", cItem_DescDup);fflush(stdout);
		STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
		STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
		STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
		STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
		printf("\n Item Description Final Value --------> %s", cItem_DescDup);fflush(stdout);
		
		if(tc_strlen(cItem_DescDup)>0)
		{
			return cItem_DescDup;
		}
		else
		{
			printf("\n Sorry!! Item Description is Null");fflush(stdout);
		}
		
	}
	else
	{
		printf("\n Sorry!! Query Tag Not Found...");fflush(stdout);
	}
	if (tags_found)
    {
		MEM_free(tags_found);
	}   
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport, FILE* VCUSNextReport)
{
		char* cLevel = NULL;
		//char* cMAddress = NULL;
		//char* cMAddressDup = NULL;
		char* cMAdd = NULL;
		char* cRev_Name = NULL;
		char* cItem_Id = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		//cPType = (char *)malloc(20 * sizeof(char));
		char* cRevision = NULL;
		char* cRevisionDup  = NULL;
		char* cQuantity = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iAttribute = 0;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		//FILE *fpOutput_file = NULL;
		char* cItemDes = NULL;
		//cItemDes=(char *)MEM_alloc(200);
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_level_starting_0", &cLevel));
			/* ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_ModuleAddress", &cMAddress));
			if(tc_strlen(cMAddress)>0)
			{
				tc_strdup(cMAddress,&cMAddressDup);
			}
			else
			{
				tc_strdup("NULL",&cMAddressDup);
				printf("\n Part Module Address Value is NULL");fflush(stdout);
			}
			trimwhitespace(cMAddressDup);
			printf("\n Part Module Address Value After Dup --------> %s", cMAddressDup);fflush(stdout);
			cMAdd=subString(cMAddressDup,1,5);
			printf("\n Final Part Module Address Value --------> %s", cMAdd);fflush(stdout); */
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			cMAdd=subString(cItem_Id,4,5);
		    printf("\n Final Part Module Address Value --------> %s", cMAdd);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cRevision));
			if(tc_strlen(cRevision)>0)
		    {
			   tc_strdup(cRevision,&cRevisionDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cRevisionDup);
			   printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cRevisionDup);
		    printf("\n Part Rev & Seq Value After Dup --------> %s", cRevisionDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
		    {
			   tc_strdup(cPartType,&cPartTypeDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cPartTypeDup);
			   printf("\n Part Type Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cPartTypeDup);
		    printf("\n Part Type Value After Dup & Trim --------> %s", cPartTypeDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			//tc_strcpy(cItemDes,cItem_Id);
			//TC_PartDesc(cItemDes);
			cItemDes = TC_PartDesc(cItem_Id);
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nLevel: %s", cLevel);
			printf("\nModule Address: %s", cMAdd);
			printf("\nID: %s", cItem_Id);
			printf("\nItem Description: %s", cItemDes);
			printf("\nRev & Seq: %s", cRevisionDup);
			printf("\nType: %s", cPartTypeDup);
			printf("\nQuantity: %s", cQuantity);
			printf("\n-------------------------------------------------------------------------");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if(tc_strcmp(cPartTypeDup,"Module")==0)
				{
			       //fprintf(FP_OutputReport,"%s,%s,%s,%s,%s,%s\n",cLevel,cMAdd,cItem_Id,cRevisionDup,cPartTypeDup,cQuantity);fflush(FP_OutputReport);
				   fprintf(FP_OutputReport,"%s,%s,\n",cItem_Id,cQuantity);fflush(FP_OutputReport);
				   fprintf(VCUSNextReport,"%s,%s,%s,\n",cMAdd,cItemDes,cItem_Id);fflush(VCUSNextReport);
				}
			}
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found --------> %d\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			} */
		}
	return iFail;
}

int Platform_VC(char* Vehicle,char* VehicleRS,char* RevRule,FILE* VCReport,FILE* VCUSReport)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	//int subrulefound = 0;
	//tag_t* subclosurerule = NULL;
	//tag_t sub_close_tag = NULLTAG;
	//char** subrulename = NULL;
    //char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	char* ctopSubLevel = NULL;
	char* ctopSubMAddress = NULL;
	char* ctopSubMAddressDup = NULL;
	char* ctopSubMAdd = NULL;
	char* ctopSubItem_Id = NULL;
	char* ctopSubRevision = NULL;
	char* ctopSubRevisionDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n Return Value From Item Find Item API is --------> %d", iFail);fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n Return Value From Item Find Revision API is --------> %d", iFail);fflush(stdout);
	if(topchildrev != NULLTAG)
    {
			
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
		//ITK_CALL(CFM_find("ERC release and above", &rule))
		ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
		printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
		/* ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n No of Rule Found --------> %d\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout); */
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_level_starting_0", &ctopSubLevel));
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_ModuleAddress", &ctopSubMAddress));
			if(tc_strlen(ctopSubMAddress)>0)
			{
				tc_strdup(ctopSubMAddress,&ctopSubMAddressDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubMAddressDup);
				printf("\n Part Module Address Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubMAddressDup);
			printf("\n Part Module Address Value After Dup --------> %s", ctopSubMAddressDup);fflush(stdout);
			ctopSubMAdd=subString(ctopSubMAddressDup,1,5);
			printf("\n Final Part Module Address Value --------> %s", ctopSubMAdd);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubRevision));
			if(tc_strlen(ctopSubRevision)>0)
			{
				tc_strdup(ctopSubRevision,&ctopSubRevisionDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubRevisionDup);
				printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubRevisionDup);
			printf("\n Part Rev & Seq Value After Dup --------> %s", ctopSubRevisionDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim --------> %s", ctopSubPartTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nLevel: %s", ctopSubLevel);
			printf("\nModule Address: %s", ctopSubMAdd);
			printf("\nItem ID: %s", ctopSubItem_Id);
			printf("\nItem Rev & Seq: %s", ctopSubRevisionDup);
			printf("\nPart Type: %s", ctopSubPartTypeDup);
			printf("\n-------------------------------------------------------------------------");
			//fprintf(VCReport,"%s,%s,%s,%s,%s\n",ctopSubLevel,ctopSubMAdd,ctopSubItem_Id,ctopSubRevisionDup,ctopSubPartTypeDup);fflush(VCReport);
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
			printf("\n No of Children Found --------> %d\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! N O   O F   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VCReport, VCUSReport);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
	}
	return iFail;	
}

int bom_sub_module(tag_t tSub_Children, char* Sub_Child_rrule, char* top_child_qty, FILE* FReport, FILE* USNReport)
{
	
	tag_t Sub_Child_bom_window = NULLTAG;
	tag_t subrule = NULLTAG;
	//int subrulefound = 0;
	//tag_t* subclosurerule = NULL;
	//tag_t sub_close_tag = NULLTAG;
	//char** subrulename = NULL;
    //char** subrulevalue = NULL;
	tag_t tSub_Child = NULLTAG;
	char* cSubLevel = NULL;
	char* cSubRev_Name = NULL;
	char* cSubItem_Id = NULL;
	char* cSubRevision = NULL;
	char* cSubRevisionDup = NULL;
	//char* cSubParent = NULL;
	char* cSubOwn_Group = NULL;
	char* cSubOwn_User = NULL;
	char* cSubItemDes = NULL;
	//cSubItemDes=(char *)MEM_alloc(200);
	char* cSubItemDesDup = NULL;
	char* cSubItemNewDes = NULL;
	char* cSubItemNewDesDup = NULL;
	char* cSubPartType = NULL;
	char* cSubPartTypeDup = NULL;
	//char* cSubType = NULL;
	//cSubType = (char *)malloc(20 * sizeof(char));
	char* cSubCS = NULL;
	char* cSubCSDup = NULL;
	char* cSubUOM = NULL;
	char* cSubUOMDup = NULL;
	//char* cSubQuantity = NULL;
	//char* cSubFind_No = NULL;
	int iFail = ITK_ok;
	int iSubNumber_Child = 0;
	tag_t* tBOM_Children = NULLTAG;
	
	char* cSubSubLevel = NULL;
	char* cSubSubItem_Id = NULL;
	char* cSubSubRevision = NULL;
	char* cSubSubParent = NULL;
	char* cSubSubQuantity = NULL;
	//char* cSubMAddress = NULL;
	//char* cSubMAddressDup = NULL;
	char* cSubMAdd = NULL;
			
	ITK_CALL(BOM_create_window(&Sub_Child_bom_window));
	printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
    //ITK_CALL(CFM_find("ERC release and above", &rule))
	ITK_CALL(CFM_find(Sub_Child_rrule, &subrule));
	printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
    ITK_CALL(BOM_set_window_config_rule(Sub_Child_bom_window, subrule));
	printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
	/* ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
	printf("\n No of Rule Found --------> %d\n",subrulefound);fflush(stdout);
	if (subrulefound > 0)
	{
		sub_close_tag = subclosurerule[0];
	}
	ITK_CALL(BOM_window_set_closure_rule(Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
	printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout); */
	ITK_CALL(BOM_set_window_pack_all(Sub_Child_bom_window, TRUE));
	printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
	ITK_CALL(BOM_set_window_top_line(Sub_Child_bom_window, NULLTAG, tSub_Children, NULLTAG, &tSub_Child));
	printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
	if(tSub_Child != NULLTAG)
    {
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_level_starting_0", &cSubLevel));
		/* ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_Design Revision_t5_ModuleAddress", &cSubMAddress));
		if(tc_strlen(cSubMAddress)>0)
		{
			tc_strdup(cSubMAddress,&cSubMAddressDup);
		}
		else
		{
			tc_strdup("NULL",&cSubMAddressDup);
			printf("\n Part Module Address Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubMAddressDup);
		printf("\n Part Module Address Value After Dup --------> %s", cSubMAddressDup);fflush(stdout);
		cSubMAdd=subString(cSubMAddressDup,1,5);
		printf("\n Final Part Module Address Value --------> %s", cSubMAdd);fflush(stdout); */
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_item_item_id", &cSubItem_Id));
		cSubMAdd=subString(cSubItem_Id,4,5);
		printf("\n Final Part Module Address Value --------> %s", cSubMAdd);fflush(stdout);
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_rev_item_revision_id", &cSubRevision));
		if(tc_strlen(cSubRevision)>0)
		{
			tc_strdup(cSubRevision,&cSubRevisionDup);
		}
		else
		{
			tc_strdup("NULL",&cSubRevisionDup);
			printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubRevisionDup);
		printf("\n Part Rev & Seq Value After Dup --------> %s", cSubRevisionDup);fflush(stdout);
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_Design Revision_t5_PartType", &cSubPartType));
		if(tc_strlen(cSubPartType)>0)
		{
			tc_strdup(cSubPartType,&cSubPartTypeDup);
		}
		else
		{
			tc_strdup("NULL",&cSubPartTypeDup);
			printf("\n Part Type Value is NULL");fflush(stdout);
		}
		trimwhitespace(cSubPartTypeDup);
		printf("\n Part Type Value After Dup & Trim --------> %s", cSubPartTypeDup);fflush(stdout);
		//tc_strcpy(cSubItemDes,cSubItem_Id);
		//TC_PartDesc(cSubItemDes);
		cSubItemDes = TC_PartDesc(cSubItem_Id);
		
		printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
		printf("\nLevel: %s", cSubLevel);
		printf("\nModule Address: %s", cSubMAdd);
		printf("\nItem ID: %s", cSubItem_Id);
		printf("\nItem Description: %s", cSubItemDes);
		printf("\nItem Rev & Seq: %s", cSubRevisionDup);
		printf("\nPart Type: %s", cSubPartTypeDup);
		printf("\nPart Quantity: %s", top_child_qty);
		printf("\n-------------------------------------------------------------------------");
		//fprintf(FReport,"%s,%s,%s,%s,%s,%s\n",cSubLevel,cSubMAdd,cSubItem_Id,cSubRevisionDup,cSubPartTypeDup,top_child_qty);fflush(FReport);
		//fprintf(FReport,"%s,%s,%s,\n",cSubMAdd,cSubItem_Id,top_child_qty);fflush(FReport);
		fprintf(FReport,"%s,%s,\n",cSubItem_Id,top_child_qty);fflush(FReport);
		fprintf(USNReport,"%s,%s,%s,\n",cSubMAdd,cSubItemDes,cSubItem_Id);fflush(USNReport);
    }
	ITK_CALL(BOM_close_window(Sub_Child_bom_window));
	printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
	return iFail;
}	

int Platform_SVR(char* Platform,char* SVR,char* RevisionRule,FILE* PMReport,FILE* USReport)
{
	FILE 	*InputFile;
	
	//int ifail = ITK_ok;
	int iFail = 0;
	tag_t  objTypeTagDi1=NULLTAG;		
    tag_t  plat = NULLTAG;
	tag_t  rev  = NULLTAG;
	tag_t RevTypTag	= NULLTAG;
	char* RevTyp = NULL;
	tag_t VariqueryTag = NULLTAG;
	
    ITK_CALL(ITEM_find_item(Platform, &plat));
	printf("\nReturn Value From PlatForm Find API --------> %d", iFail);fflush(stdout);	
	ITK_CALL(ITEM_ask_latest_rev(plat, &rev));
    printf("\nReturn Value From PlatForm Latest Rev API --------> %d", iFail);fflush(stdout);	
	ITK_CALL(TCTYPE_ask_object_type(rev, &RevTypTag));
	printf("\nReturn Value From PlatForm Object Type API --------> %d", iFail);fflush(stdout);
	ITK_CALL(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\nReturn Value From PlatForm Name API --------> %d", iFail);fflush(stdout);
	printf("\nPlatform Revision Type: [%s]\n", RevTyp);fflush(stdout);

	ITK_CALL(QRY_find2("VariantRule", &VariqueryTag));
	printf("\nReturn Value From Varient Rule Query API is --------> %d", iFail);fflush(stdout);

	if(VariqueryTag!=NULLTAG)
	{
	   printf("\nVarient Rule Query Found Successfully...");fflush(stdout);
	}
	else
	{
	   printf("\n Varient Rule Query Not Found");fflush(stdout);
	}
    char** valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
	valuesNonColSvr[0] = SVR ;
	//valuesNonColSvr[0] = "54644625000R_A";
	int n_entriesV = 1;
	char *qry_entries3[1] = {"Name"};
	//char *qry_values3[1] = {"*"};
	int resultCountVNCol = 0;
	tag_t* outputVNCol_tags = NULLTAG;
	
    ITK_CALL(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
	printf("\n Return Value From Varient Query Execute API is --------> %d", iFail);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
    printf("\n No of Result Found --------> %d\n",resultCountVNCol);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
    
	tag_t  VarientRuletag = NULLTAG;
	if (resultCountVNCol > 0)
	{
		VarientRuletag = outputVNCol_tags[0];
	}
	else
	{
		printf("\n NonColour-SVR-VarientRule Not Present:  [%s]\n", SVR); fflush(stdout);
		//exit(0);
	}
    char* objecttype = NULL;
	ITK_CALL(AOM_ask_value_string(VarientRuletag,"object_type",&objecttype));
	printf("\n Varient Rule Object Type:  [%s]\n",objecttype);fflush(stdout);
    tag_t bom_view = NULLTAG;
	
	if(tc_strcmp(RevTyp,"T5_PlatformRevision") == 0)
	{

		if(rev != NULLTAG)
		{
			tag_t view_type = NULLTAG;
			ITK_CALL(PS_find_view_type("view", &view_type));
			printf("\n Return Value From View Type Find API is --------> %d", iFail);fflush(stdout);
            if(view_type != NULLTAG)
			{
				tag_t item = NULLTAG;
				int n_bom_views = 0;
				tag_t* bom_views = NULL;
				ITK_CALL(ITEM_ask_item_of_rev(rev, &item));
				printf("\n Return Value From Item of Rev API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(ITEM_list_bom_views(item, &n_bom_views, &bom_views));
				printf("\n Return Value From List BOM View API is --------> %d", iFail);fflush(stdout);
                bom_view = bom_views[0];
			}
			else
			{
				printf("\n View Type Tag Not Found \n");fflush(stdout);
			}
		}


		if(bom_view != NULLTAG)
		{
			tag_t bom_window = NULLTAG;
			tag_t rule = NULLTAG;
			int rulefound = 0;
			tag_t* closurerule = NULL;
			tag_t close_tag = NULLTAG;
			char** rulename = NULL;
            char** rulevalue = NULL;
			tag_t tPlatform = NULLTAG;
			tag_t bom_variant_rule = NULLTAG;
			tag_t objTypeTag = NULLTAG;
			char type_name[TCTYPE_name_size_c+1];
			tag_t e_block = NULLTAG;
			
			ITK_CALL(BOM_create_window(&bom_window));
			printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
			//ITK_CALL(CFM_find("ERC release and above", &rule))
			ITK_CALL(CFM_find(RevisionRule, &rule));
			printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_config_rule(bom_window, rule));
			printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
			//ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule));
			ITK_CALL(PIE_find_closure_rules("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule));
			printf("\n No of Rule Found --------> %d\n",rulefound);fflush(stdout);
			if (rulefound > 0)
			{
				close_tag = closurerule[0];
			}
			ITK_CALL(BOM_window_set_closure_rule(bom_window,close_tag,0,rulename,rulevalue)); 
			printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_pack_all(bom_window, FALSE));
			//ITK_CALL(BOM_set_window_pack_all(bom_window, TRUE));
			printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, rev, NULLTAG, &tPlatform));
			printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
			ITK_CALL( BOM_window_ask_variant_rule(bom_window, &bom_variant_rule));
			printf("\n Return Value From BOM Window Ask Varient Rule API is --------> %d", iFail);fflush(stdout);
            ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
			printf("\n Return Value From BOM Varient Rule Object Type Tag API is --------> %d", iFail);fflush(stdout);
		    ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
            printf("\nBOM Varient Rule Type Name: [%s]\n", type_name);fflush(stdout);			

			//ITK_CALL(ITEM_ask_rev_variants(rev, &e_block));
			//printf("\n Return Value From Item Ask Revision Varient API is --------> %d", iFail);fflush(stdout);		
			
            int n_lines,n_arcmod = 0;
	        tag_t* tarcmod = NULL;			
			if(tPlatform != NULLTAG)
			{
				//ITK_CALL(BOM_line_ask_child_lines(tPlatform, &n_arcmod, &tarcmod));
				//printf("\n Return Value From BOM Line Ask Child Line API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(BOM_window_hide_unconfigured(bom_window));
				printf("\n Return Value From BOM Window Hide Configured API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(BOM_window_show_variants(bom_window));
				printf("\n Return Value From BOM Window Show Varients API is --------> %d", iFail);fflush(stdout);
				//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config));
				//if(BOM_variant_config_apply (bom_variant_config));
                //if(BOM_variant_rule_apply(primary1));				
				ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
				printf("\n Return Value From BOM Window Apply Varient Configuration API is --------> %d", iFail);fflush(stdout);
               //if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list));
				ITK_CALL(BOM_window_hide_variants(bom_window));
                ITK_CALL(BOM_line_ask_child_lines(tPlatform, &n_arcmod, &tarcmod));
				printf("\n BOM Line Ask Child Lines (Architecture_Module) --------> %d\n",n_arcmod);fflush(stdout);
				int blqu = 0;
				tag_t Childobject4 = NULLTAG;
				tag_t Childobject3 = NULLTAG;
				//int p4 = 0;
				tag_t objTypeTagDi = NULLTAG;
				//tag_t Childobject2 = NULLTAG;
				//char type_name2[TCTYPE_name_size_c+1];
				char* top_child_item_id = NULL;
	            char* top_child_item_revision_id = NULL;
				char* top_child_Quantity = NULL;
	            //char* child_bl_formula = NULL; 
				int n_module = 0;
				tag_t* tmodule = NULLTAG;
                ITK_CALL( BOM_line_look_up_attribute ("bl_quantity",&blqu));
                if (n_arcmod >0)
				{
					int p1 = 0;
					for(p1=0; p1 < n_arcmod; p1++)
					{
						if(Childobject4) Childobject4 = NULLTAG;
						Childobject4=tarcmod[p1];
						//ITK_CALL(BOM_line_unpack(Childobject4));
                        ITK_CALL(BOM_line_ask_child_lines(Childobject4, &n_module, &tmodule));
						printf("\n BOM Line Ask Child Lines (Module) --------> %d\n",n_module);fflush(stdout);
						int n_submodule = 0;
				        tag_t* tsubmodule = NULLTAG;
                        if(n_module >0)
						{
							int p4 = 0;
							for (p4=0; p4 < n_module; p4++)
							{
								if(Childobject3) Childobject3 = NULLTAG;
								Childobject3=tmodule[p4];

								ITK_CALL(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
								printf("\n Return Value From Object Type API is --------> %d", iFail);fflush(stdout);
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_item_item_id", &top_child_item_id ));
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &top_child_item_revision_id));
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_quantity", &top_child_Quantity));
						        printf("\n########## M O D U L E    D E T A I L S #############");fflush(stdout);		
								printf("\nUnique Module ID: %s", top_child_item_id);fflush(stdout);
			                    printf("\nUnique Module Revision ID: %s", top_child_item_revision_id);fflush(stdout);
								printf("\nUnique Module Quantity: %s", top_child_Quantity);fflush(stdout);
								printf("\nUnique Revision Rule: %s", RevisionRule);fflush(stdout);
								printf("\n########## M O D U L E    D E T A I L S #############");fflush(stdout);
								tag_t tchild_item = NULLTAG;
								ITK_CALL(ITEM_find_item(top_child_item_id, &tchild_item));
								printf("\n Return Value From Item Find Item API is --------> %d", iFail);fflush(stdout);
								tag_t Childrev = NULLTAG;
								//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
								ITK_CALL(ITEM_find_revision(tchild_item, top_child_item_revision_id, &Childrev));
								printf("\n Return Value From Item Find Revision API is --------> %d", iFail);fflush(stdout);
								if(Childrev != NULLTAG)
								{
									printf("\n!!!!!!!!! T E S T I N G    O K !!!!!!!!!!");fflush(stdout);
									bom_sub_module(Childrev,RevisionRule,top_child_Quantity,PMReport,USReport);
								}
                            }
							//bom_sub_child(lines4, n_lines4);
						}
						if(tmodule)
						{
							MEM_free(tmodule);
						}
					}
			    }
				if(tarcmod)
				{
					MEM_free(tarcmod);
				}
				ITK_CALL(BOM_close_window(bom_window));
			    printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
            }
		}
		else
		{
			printf("\n No BOM Window Found \n");fflush(stdout);
		}
					
	}

	return ITK_ok;	
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	//time_t	temptime;
	//char GenDate[20];
	//char RptDate[20];
	//struct tm *timeptr;
	//int ch;
	//int ch1;
	char *RptFile1= (char *) malloc(400*sizeof(char));
	char *RptFile2= (char *) malloc(400*sizeof(char));
	char *RptFile= (char *) malloc(400*sizeof(char));
	char *MstrRptFile= (char *) malloc(400*sizeof(char));
	char *UnsortFinalRptFile= (char *) malloc(400*sizeof(char));
	char *SortFinalRptFile= (char *) malloc(400*sizeof(char));
	char *PreFinalRptFile= (char *) malloc(400*sizeof(char));
	char *FinalRptFile= (char *) malloc(400*sizeof(char));
	FILE *fpus_file = NULL;
	FILE *fpOutput_file = NULL;
	FILE *fpInput_file = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char* Platform = NULL;
	//char* SVRList = NULL;
	char* SVR = NULL;
	char* RevisionRule = NULL;
	char* SVRNoStr = NULL;
	char* VCList = NULL;
	char* VCNo = NULL;
	char* VCRevSeq = NULL;
	char* plantname = NULL;
	char* EmailID = NULL;
	char* SVRShellCommandLine = NULL;
	SVRShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	//char* responseString1 = NULL;
	//responseString1=(char *)MEM_alloc(200);
	
	/* printf("\n Generating Curernt Time Stamp");fflush(stdout);
	temptime = time(NULL);
	tc_strcpy(GenDate,"");
	timeptr = (struct tm *)localtime(&temptime);
	ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M_%S",timeptr);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n Curernt Time Stamp Generated");fflush(stdout); */
	
	printf("\n Generating New Time Stamp");fflush(stdout);
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n New Time Stamp Generated");fflush(stdout);
	
	printf("\n Generating New Report Time Stamp");fflush(stdout);
	char RptDate[100] = "";
	strftime(RptDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Report Time --------> %s", RptDate);fflush(stdout);
	printf("\n New Report Time Stamp Generated");fflush(stdout);
	
	/* printf("\n Generating Report Time Stamp");fflush(stdout);
	tc_strcpy(RptDate,"");
	ch1 = strftime(RptDate,sizeof(RptDate)-1,"%d-%b-%Y-%H:%M:%S",timeptr);
	printf("\n Report Time --------> %s", RptDate);fflush(stdout);
	printf("\n Report Time Stamp Generated");fflush(stdout); */
	
	printf("\n Generating UnSorted Solved BOM Report File Name");fflush(stdout);
	tc_strcpy(RptFile1,"/tmp/");
	tc_strcat(RptFile1,"UnSorted_Solved_BOM_Rpt_File");
	//tc_strcpy(RptFile1,"/tmp/");
	//tc_strcat(RptFile1,"UnSorted_Solved_BOM_Rpt_File");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,GenDate);
	tc_strcat(RptFile1,".csv");
	printf("\n UnSorted Solved BOM Report File Name --------> %s", RptFile1);fflush(stdout);
	printf("\n UnSorted Solved BOM Report File Name Generated");fflush(stdout);
	
	printf("\n Generating Sorted Solved BOM Report File Name");fflush(stdout);
	tc_strcpy(RptFile2,"/tmp/");
	tc_strcat(RptFile2,"Sorted_Solved_BOM_Rpt_File");
	//tc_strcpy(RptFile2,"/tmp/");
	//tc_strcat(RptFile2,"Sorted_Solved_BOM_Rpt_File");
	tc_strcat(RptFile2,"_");
	tc_strcat(RptFile2,GenDate);
	tc_strcat(RptFile2,".csv");
	printf("\n Sorted Solved BOM Report File Name --------> %s", RptFile2);fflush(stdout);
	printf("\n Sorted Solved BOM Report File Name Generated");fflush(stdout);
	
	
    printf("\n Generating Solved BOM Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"/tmp/");
	tc_strcat(RptFile,"Solved_BOM_Rpt_File");
	//tc_strcpy(RptFile,"/tmp/");
	//tc_strcat(RptFile,"Solved_BOM_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Solved BOM Report File Name --------> %s", RptFile);fflush(stdout);
	printf("\n Solved BOM Report File Name Generated");fflush(stdout);
	
	printf("\n Generating Stdalone VC BOM Report File Name");fflush(stdout);
	tc_strcpy(MstrRptFile,"/tmp/");
	tc_strcat(MstrRptFile,"Stdalone_VC_BOM_Rpt_File");
	//tc_strcpy(MstrRptFile,"/tmp/");
	//tc_strcat(MstrRptFile,"Stdalone_VC_BOM_Rpt_File");
	tc_strcat(MstrRptFile,"_");
	tc_strcat(MstrRptFile,GenDate);
	tc_strcat(MstrRptFile,".csv");
	printf("\n Stdalone VC BOM Report File Name --------> %s", MstrRptFile);fflush(stdout);
	printf("\n Stdalone VC BOM Report File Name Generated");fflush(stdout);
	
	printf("\n Generating Unsorted Final Report File Name");fflush(stdout);
	tc_strcpy(UnsortFinalRptFile,"/tmp/");
	tc_strcat(UnsortFinalRptFile,"Unsorted_StdVC_VS_Solved_BOM_Rpt");
	//tc_strcpy(UnsortFinalRptFile,"/tmp/");
	//tc_strcat(UnsortFinalRptFile,"Unsorted_StdVC_VS_Solved_BOM_Rpt");
	tc_strcat(UnsortFinalRptFile,"_");
	tc_strcat(UnsortFinalRptFile,GenDate);
	tc_strcat(UnsortFinalRptFile,".csv");
	printf("\n Unsorted Final Report File Name --------> %s", UnsortFinalRptFile);fflush(stdout);
	printf("\n Unsorted Final Report File Name Generated");fflush(stdout);
	
	printf("\n Generating Sorted Final Report File Name");fflush(stdout);
	tc_strcpy(SortFinalRptFile,"/tmp/");
	tc_strcat(SortFinalRptFile,"Sorted_StdVC_VS_Solved_BOM_Rpt");
	//tc_strcpy(SortFinalRptFile,"/tmp/");
	//tc_strcat(SortFinalRptFile,"Sorted_StdVC_VS_Solved_BOM_Rpt");
	tc_strcat(SortFinalRptFile,"_");
	tc_strcat(SortFinalRptFile,GenDate);
	tc_strcat(SortFinalRptFile,".csv");
	printf("\n Final Report File Name --------> %s", SortFinalRptFile);fflush(stdout);
	printf("\n Final Report File Name Generated");fflush(stdout); 
	
	printf("\n Generating PreFinal Report File Name");fflush(stdout);
	tc_strcpy(PreFinalRptFile,"/tmp/");
	tc_strcat(PreFinalRptFile,"PreFinal_Sorted_StdVC_VS_Solved_BOM_Rpt");
	//tc_strcpy(PreFinalRptFile,"/tmp/");
	//tc_strcat(PreFinalRptFile,"PreFinal_Sorted_StdVC_VS_Solved_BOM_Rpt");
	tc_strcat(PreFinalRptFile,"_");
	tc_strcat(PreFinalRptFile,GenDate);
	tc_strcat(PreFinalRptFile,".csv");
	printf("\n PreFinal Report File Name --------> %s", PreFinalRptFile);fflush(stdout);
	printf("\n PreFinal Report File Name Generated");fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 9)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			Platform = ITK_ask_cli_argument("-plat=");
			SVR = ITK_ask_cli_argument("-svr=");
	        RevisionRule = ITK_ask_cli_argument("-rrule=");
			VCList = ITK_ask_cli_argument("-vc=");
			EmailID = ITK_ask_cli_argument("-email=");
			printf("\nUsername --------> %s", cUSERID);fflush(stdout);
			printf("\nPassword --------> %s", cPASS);fflush(stdout);
			printf("\nGroup --------> %s", cGroup);fflush(stdout);
			printf("\nPlatform --------> %s", Platform);fflush(stdout);
			printf("\nSVR List --------> %s", SVR);fflush(stdout);
			printf("\nRevision Rule --------> %s", RevisionRule);fflush(stdout);
			printf("\nVC List --------> %s", VCList);fflush(stdout);
			printf("\nUser Email ID --------> %s", EmailID);fflush(stdout);
			VCNo = strtok(VCList, "/");
			VCRevSeq = strtok(NULL,"/");
			printf("\nVC No --------> %s", VCNo);fflush(stdout);
			printf("\nVC Rev & Seq --------> %s", VCRevSeq);fflush(stdout);
			printf("\nVC List --------> %s", VCList);fflush(stdout);
			//exit(0);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&cUSERID, &tuser);
				printf("\nLogged in Username --------> %s", cUSERID);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			if( tc_strlen(stripBlanks(Platform)) == 0 || tc_strlen(stripBlanks(SVR)) == 0 || tc_strlen(stripBlanks(RevisionRule)) == 0 || tc_strlen(stripBlanks(VCList)) == 0)
	        {
		        print_requirement();
		        return iFail;
	        }
			
			printf("\n Generating Final Report File Name");fflush(stdout);
			tc_strcpy(FinalRptFile,"/tmp/");
	        tc_strcat(FinalRptFile,Platform);
	        /* tc_strcpy(FinalRptFile,"/tmp/");
			tc_strcat(FinalRptFile,Platform);
			tc_strcat(FinalRptFile,"_");
	        tc_strcat(FinalRptFile,SVR);
	        tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,VCList);
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,"SolvedSVR_And_StandaloneVC_Comparision_Report");
			tc_strcat(FinalRptFile,"_");
	        tc_strcat(FinalRptFile,GenDate);
	        tc_strcat(FinalRptFile,".csv"); */
		    tc_strcat(FinalRptFile,"_");
		    tc_strcat(FinalRptFile,SVR);
	        tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,VCList);
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,"SolvedSVR_And_StandaloneVC_Comparision_Report");
			tc_strcat(FinalRptFile,"_");
	        tc_strcat(FinalRptFile,GenDate);
	        tc_strcat(FinalRptFile,".csv");
	        printf("\n Final Report File Name --------> %s", FinalRptFile);fflush(stdout);
	        printf("\n Final Report File Name Generated");fflush(stdout);
			
		    
			fpus_file = fopen(UnsortFinalRptFile, "w");
			if(fpus_file == NULL)
	        {
				printf("\n Unable to Create Unsorted Report File on Server --------> %s",UnsortFinalRptFile);fflush(stdout);
				return iFail;
	        }
            
			fpOutput_file = fopen(RptFile1, "w"); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Solved BOM Report File on Server --------> %s",RptFile1);fflush(stdout);
				return iFail;
	        }
			else
	        {
		        printf("\n Solved BOM Report File Opened Successfully");fflush(stdout);
				printf("\n Function1: BOM solving after applying SVR Start");fflush(stdout);
			    Platform_SVR(Platform,SVR,RevisionRule,fpOutput_file,fpus_file);
			    printf("\n Function1: BOM solving after applying SVR End");fflush(stdout);
			    fclose(fpOutput_file);
			    printf("\n Solved BOM Report File Closed Successfully");fflush(stdout);
	        }
			
			
			
			fpInput_file = fopen(MstrRptFile, "w"); 
	        if(fpInput_file == NULL)
	        {
				printf("\n Unable to Create Stdalone VC BOM Report File on Server --------> %s",MstrRptFile);fflush(stdout);
				return iFail;
	        }
			else
	        {
		        printf("\n Stdalone VC BOM Report File Opened Successfully");fflush(stdout);
				printf("\n Function2: Standalone VC BOM solve Start");fflush(stdout);
			    Platform_VC(VCNo,VCRevSeq,RevisionRule,fpInput_file,fpus_file);
			    printf("\n Function2: Standalone VC BOM solve End");fflush(stdout);
			    fclose(fpInput_file);
			    printf("\n Stdalone VC BOM Report File Closed Successfully");fflush(stdout);
	        }
            fclose(fpus_file);
           
		   //Replace space with specific character rpl for Revision Rule 
            char rpl = '-'; 
			int alk = 0;
            for(alk = 0; alk < strlen(RevisionRule); alk++)
			{  
               if(RevisionRule[alk] == ' ')  
               RevisionRule[alk] = rpl;
            }
            printf("\n Final Revision Rule After Replace --------> %s",RevisionRule);fflush(stdout); 

            //Replace space with specific character rpl for Platform
            char newrpl = '_'; 
			int nbk = 0;
            for(nbk = 0; nbk < strlen(Platform); nbk++)
			{  
               if(Platform[nbk] == ' ')  
               Platform[nbk] = newrpl;
            }
            printf("\n Final Revision Rule After Replace --------> %s",Platform);fflush(stdout);

            printf("\n Vehicle Revision Sequence Token Start...");fflush(stdout);
			printf("\n Vehicle Revision & Sequence Before Tok --------> %s", VCRevSeq);fflush(stdout);
            char* VehRev = NULL;
			char* VehSeq = NULL;
            VehRev = strtok(VCRevSeq, ";");
			VehSeq = strtok(NULL,";");
			printf("\n Vehicle Revision --------> %s", VehRev);fflush(stdout);
			printf("\n Vehicle Sequence --------> %s", VehSeq);fflush(stdout); 
            printf("\n Vehicle Revision Sequence Token End...");fflush(stdout);			
			
			printf("\n Shell Calling STARTED...");fflush(stdout);
			//tc_strcpy(SVRShellCommandLine,"/user/uaprodtrl/Sourav/tm_stdvc_svr_bom_report/Execution_Shell.sh");
			//tc_strcpy(SVRShellCommandLine,"/user/omfprod/sourav/tm_stdvc_svr_bom_report/Execution_Shell.sh");
			//tc_strcpy(SVRShellCommandLine,"/user/cvprod/sourav/SVRVCTESTRPT/Execution_Shell.sh");
			//tc_strcpy(SVRShellCommandLine,"/user/omfprod/sourav/TestReport/Execution_Shell.sh");
			//tc_strcpy(SVRShellCommandLine,"/user/cvprod/shells/SVRVSVCRPT/Execution_Shell.sh");
			//tc_strcpy(SVRShellCommandLine,"/user/omfprod/sourav/TESTSTDVSVC/Execution_Shell.sh");
			tc_strcpy(SVRShellCommandLine,"/user/cvprod/sourav/TESTSTDVSVC/Execution_Shell.sh");
			tc_strcat(SVRShellCommandLine," ");
			tc_strcat(SVRShellCommandLine,SVR);
			tc_strcat(SVRShellCommandLine," ");
			tc_strcat(SVRShellCommandLine,RevisionRule);
			tc_strcat(SVRShellCommandLine," ");
			tc_strcat(SVRShellCommandLine,Platform);
			tc_strcat(SVRShellCommandLine," ");
			tc_strcat(SVRShellCommandLine,VCList);
			tc_strcat(SVRShellCommandLine," ");
			tc_strcat(SVRShellCommandLine,RptDate);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,EmailID);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,RptFile1);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,RptFile2);
	        tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,RptFile);
	        tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,MstrRptFile);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,UnsortFinalRptFile);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,SortFinalRptFile);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,PreFinalRptFile);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,FinalRptFile);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,VehRev);
			tc_strcat(SVRShellCommandLine," ");
	        tc_strcat(SVRShellCommandLine,VehSeq);
	        printf("\n CommandLine: -------> %s",SVRShellCommandLine);fflush(stdout);
	        system(SVRShellCommandLine); 
			printf("\n Shell Called Ended...");
			
			
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}