/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Query Design Revision & Sequence & Return It's Attached with DML in Working State or Not As a Response via Web-Service 
*  File Name    :   tm_V6PartRevise.c
*  Created on   :   Jan 06th, 2024
*  Usage        :   tm_V6PartRevise
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     06/01/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* ERC_DML_Part_LC_Details(char* DmlNumber)
{
	tag_t dml_task_rel = NULLTAG;
	int	task_count = 0;
	tag_t *task_tag	= NULL;
    tag_t dml_tag = NULLTAG;
	tag_t rev_tag = NULLTAG;
    tag_t RevTypTag	= NULLTAG;
	char* RevTyp = NULL;
	char* item_type = NULL;
	int	status_count = 0;
	tag_t* relStatus_list = NULLTAG;
	char* latest_rev_Rel_Status = NULL;
	char* latest_rev_Rel_StatusDup = NULL;
	char *Funresult = (char *) malloc(400*sizeof(char));
			
	ITK_CALL(ITEM_find_item(DmlNumber, &dml_tag));
	if (dml_tag != NULLTAG)
	{
		printf("\n !!!!!! DML Tag Found !!!!!!\n");fflush(stdout);
	}
	ITK_CALL(ITEM_ask_type2(dml_tag, &item_type));
	printf("\n DML Item_Types: [%s] \n",item_type);fflush(stdout);
	//Find the DML-Revision tag.
	//ITK_CALL(ITEM_find_revision(dml_tag,"NR",&dml_rev_tag)) ;
	ITK_CALL(ITEM_ask_latest_rev(dml_tag,&rev_tag)) ;
	if(rev_tag != NULLTAG)
	{
		printf("\n !!!!!! DML Revision Tag Found !!!!!!");fflush(stdout);
	}
	if(TCTYPE_ask_object_type(rev_tag, &RevTypTag));
	if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\n Revision Type: [%s]\n", RevTyp);fflush(stdout);
	if(tc_strcmp(RevTyp,"ChangeRequestRevision")==0)
	{
		WSOM_ask_release_status_list(rev_tag, &status_count, &relStatus_list);
		printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
		if(status_count>0)
		{
			int m = 0;
			for(m = 0; m<status_count; m++)
			{		  
				AOM_ask_value_string(relStatus_list[m],"object_name",&latest_rev_Rel_StatusDup);
				printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
                tc_strcpy(Funresult,latest_rev_Rel_StatusDup);				
			}
		}
		else
		{
			printf("\n Sorry!! No Release Status Found..!!");fflush(stdout);
			tc_strcpy(Funresult,"T5_LcsErcRlzd");
		}
	}
	else
	{
		printf("\n Sorry!! RevType is Not ChangeRequestRevision..!!");fflush(stdout);
		tc_strcpy(Funresult,"T5_LcsErcRlzd");
	}
	
	return Funresult;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tQryobj = NULLTAG;
	int n_entries = 2;
	int n_Qryobj_found = 0;
	tag_t* tQryobj_results = NULLTAG;
	char *Input_line_str = NULL;
	char *Input_line_strDup = NULL;
	char* resultstring = NULL;
	resultstring=(char *)MEM_alloc(200);
	char* responsestring = NULL;
	responsestring=(char *)MEM_alloc(200);
	char *Part_No_Str = NULL;
	char *RevSeq_Str = NULL;
	char *Rev_Str = NULL;
	char *Seq_Str = NULL;
	char *Part_No_StrDup = NULL;
	char *Rev_StrDup = NULL;
	char *Seq_StrDup = NULL;
	tag_t tQryDesRev = NULL;
	char *To_date_strDup = NULL;
	char *Rq_domain_strDup = NULL;
	int i = 0;
	char *Rev_Seq_strDup = (char *) malloc(400*sizeof(char));
	char *SrcPart_No = NULL;
	char *SrcRevSeq = NULL;
	char *SrcProjCode = NULL;
	char *SrcDesGroup = NULL;
	int	n_reffound = 0;
	int *n_level;
	tag_t *referencers = NULLTAG;
	char **relations =  NULL;
	int j = 0;
	int k = 0;
	tag_t tsk_dml_rel_type = NULLTAG;
	int dmlcnt = 0;
	tag_t *DMLRev =	NULLTAG;
	char *DMLNo = NULL;
	char *DMLType = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	Input_line_str = ITK_ask_cli_argument("-IPL=");
	
	trimwhitespace(Input_line_str);
	if(Input_line_str!=NULL)tc_strdup(Input_line_str,&Input_line_strDup);
	printf(" [1]: Input Line(Input_line_str): [%s]\n",Input_line_strDup);
	Part_No_Str=strtok(Input_line_strDup,"^");
	RevSeq_Str=strtok(NULL,"^");
	printf("\n Part_Number String: [%s]", Part_No_Str);fflush(stdout);
	printf("\n Part_Rev_Seq String: [%s]", RevSeq_Str);fflush(stdout);
	Rev_Str=strtok(RevSeq_Str,".");
	Seq_Str=strtok(NULL,".");
	if((tc_strlen(Part_No_Str)>0) && (tc_strlen(Rev_Str)>0) && (tc_strlen(Rev_Str)>0))
	{
		tc_strdup(Part_No_Str,&Part_No_StrDup);
		tc_strdup(Rev_Str,&Rev_StrDup);
		tc_strdup(Seq_Str,&Seq_StrDup);
	}
	else
	{
		tc_strdup("",&Part_No_StrDup);
		tc_strdup("",&Rev_StrDup);
		tc_strdup("",&Seq_StrDup);
		printf("\n Part Rev-Seq Value is NULL \n");fflush(stdout);
	}
	trimwhitespace(Part_No_StrDup);
	trimwhitespace(Rev_StrDup);
	trimwhitespace(Seq_StrDup);
	printf("\n Part_No Value After Dup & Trim: [%s]\n", Part_No_StrDup);fflush(stdout);
	printf("\n Revision Value After Dup & Trim: [%s]\n", Rev_StrDup);fflush(stdout);
	printf("\n Sequence Value After Dup & Trim: [%s]\n", Seq_StrDup);fflush(stdout);
	
	tc_strcpy(Rev_Seq_strDup,Rev_StrDup);
	tc_strcat(Rev_Seq_strDup,";");
	tc_strcat(Rev_Seq_strDup,Seq_StrDup);
	printf(" Final: Rev-Seq Value(Rev_Seq_strDup): [%s]\n",Rev_Seq_strDup);
	
	printf("\n Control Object Check STARTED...\n");fflush(stdout);
	tag_t tCtrlobj = NULLTAG;
	tag_t* tPathctrlobj_results = NULLTAG;
	int n_pathentries = 4;
	int n_path_ctrlobj_found = 0;
	char *JarCallPath = NULL;
	char *JarPath = NULL;
	ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
	if(tCtrlobj!=NULLTAG)
	{
		printf("\n Control Object Query Found Successfully...!!\n");
		char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
		char *cPathValues[4]  = {"V6Revise","V6RevisePath","V6ReviseCntObj","0"};
		ITK_CALL(QRY_execute(tCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tPathctrlobj_results));
		printf("\n No of Control Object Found: [%d]\n",n_path_ctrlobj_found);fflush(stdout);
		if(n_path_ctrlobj_found>0)
		{
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tQryobj));
			if(tQryobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {Rev_Seq_strDup,Part_No_StrDup};
				ITK_CALL(QRY_execute(tQryobj, n_entries, cEntries, cValues, &n_Qryobj_found, &tQryobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found --------> %d\n",n_Qryobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				
				if(n_Qryobj_found > 0)
				{
					printf(" Design Revision Found..!!\n");fflush(stdout);
					for(i = 0; i < n_Qryobj_found; i++)
					{
						tQryDesRev = tQryobj_results[i];
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_id",&SrcPart_No));
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_revision_id",&SrcRevSeq));
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"t5_ProjectCode",&SrcProjCode));
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"t5_DesignGrp",&SrcDesGroup));
						printf("Searched Part Details: ----> Part_No: [%s], Part_RevSeq: [%s], Project_Code: [%s], Design_Group: [%s]\n",SrcPart_No,SrcRevSeq,SrcProjCode,SrcDesGroup);fflush(stdout);
											
						ITK_CALL(WSOM_where_referenced(tQryDesRev,1,&n_reffound,&n_level,&referencers,&relations));
						printf("\n -----------------------------------------------\n");fflush(stdout);
						printf("\n No of Reference Found: [%d]\n",n_reffound);fflush(stdout);
						printf("\n -----------------------------------------------\n\n");fflush(stdout);
						if(n_reffound>0)
						{
							for(j = 0; j < n_reffound; j++)
							{
								ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
								ITK_CALL(GRM_list_primary_objects_only(referencers[j],tsk_dml_rel_type,&dmlcnt,&DMLRev));
								printf("No of Object Found: [%d]\n",dmlcnt);fflush(stdout);
								if(dmlcnt>0)
								{
									for(k = 0; k <dmlcnt; k++)
									{
										ITK_CALL(AOM_ask_value_string(DMLRev[k],"object_type",&DMLType));
										printf("Object_Type: [%s]\n",DMLType);fflush(stdout);
										if(tc_strcmp(DMLType,"ChangeRequestRevision")==0)
										{
											printf("!!!!!! ERC DML Found !!!!!!\n");fflush(stdout);
											ITK_CALL(AOM_ask_value_string(DMLRev[k],"item_id",&DMLNo));
											printf("DML No is:------> [%s]\n",DMLNo);fflush(stdout);
											printf("Function: ERC DML Part LC Details Calling Start\n");fflush(stdout);
											resultstring = ERC_DML_Part_LC_Details(DMLNo);
											printf("Function: ERC DML Part LC Details Calling End\n");fflush(stdout);
											printf("ResultString Before Trim: [%s]\n",resultstring);fflush(stdout);
											trimwhitespace(resultstring);
											printf("ResultString After Trim: [%s]\n",resultstring);fflush(stdout);
											if(tc_strcmp(resultstring,"In Designer Working") == 0)
											{
												printf("\n !!!!!! DML LC State[Working] Found, So Jump..!!!!!!\n");fflush(stdout);
												tc_strcpy(responsestring,"TRUE");
												goto jump;			   
											}
											else
											{
												printf("ERC DML LC State Not Working, So Continue..!!\n\n");fflush(stdout);
												continue;
											}
										}
										else
										{
											printf("ERC DML Not Found, So Continue..!!\n\n");fflush(stdout);
										}
									}
								}
								else
								{
									printf("DML Count Zero[0] Continue..!!\n\n");fflush(stdout);
								}
							}									
						}
						else
						{
							printf("\n Design Revision Not Attached with Any Task..!!");fflush(stdout);
							tc_strcpy(responsestring,"FALSE");
						}
					}
				}
				else
				{
					printf("\n Design Revision Not Found..!!\n");fflush(stdout);
					tc_strcpy(responsestring,"FLASE");
				}
			}
			else
			{
				printf("\n DesignRevision Sequence Tag is NULL..!!\n");fflush(stdout);
				tc_strcpy(responsestring,"FALSE");
			}
		}
		else
		{
			printf("\n Control Object[V6Revise] Not Found..!!\n");fflush(stdout);
			tc_strcpy(responsestring,"FALSE");
		}
	}
	else
	{
		printf("\n Control Object Tag is NULL..!!\n");fflush(stdout);
		tc_strcpy(responsestring,"FALSE");
	}	
	
	jump:
	   printf("\n !!!!!! DML LC State[Working] Found, In Jump Block..!!!!!!\n");
	   
	if(tc_strlen(responsestring)>0)
	{
		printf("\nResponse Already Received, So Skip..!!\n");fflush(stdout);
	}
	else
	{
		printf("\nResponse Not Received[Attached All DML Already Released], So Copy..!!\n");fflush(stdout);
		tc_strcpy(responsestring,"FLASE");
	}
	printf("\n############################################\n");fflush(stdout);
	printf("\n Part Number: -----> <%s> \n",Part_No_StrDup);fflush(stdout);
    printf("\n Part Revision & Sequence: -----> <%s> \n",Rev_Seq_strDup);fflush(stdout);
	printf("\n Response: ------> <%s> \n",responsestring);fflush(stdout);
	printf("\n############################################\n");fflush(stdout);
    if (tQryobj_results)
	{
	  MEM_free(tQryobj_results);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_V6PartRevise.c
* // ./linkitk -o tm_V6PartRevise tm_V6PartRevise.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_PartReviseV6/tm_V6PartRevise .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_PartReviseV6/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_PartReviseV6/usage.txt .
* // ./tm_V6PartRevise -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -IPL="5158F1C0445013^NR.1^"
* // ./tm_V6PartRevise -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -IPL="5158F1C0445013^NR.1^"
*
***************************************************************************/