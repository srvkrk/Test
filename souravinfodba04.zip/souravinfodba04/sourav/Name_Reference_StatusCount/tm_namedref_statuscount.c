/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Count Named Reference File in Attached Dataset  
*  File Name    :   tm_namedref_statuscount.c
*  Created on   :   Jan 29th, 2024
*  Usage        :  ./tm_namedref_statuscount -u=<USER_ID> -pf=<PASSWORD_FILE> -g=<GROUP>
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     29/01/2024                Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_str= NULL;
	char *item_revseq_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t titem = NULLTAG;
	char* cItem_revseq = NULL;
	char* file_name_str = NULL;
	char *RptFile= (char *) malloc(400*sizeof(char));
	char *ds_no_str = NULL;
	char *ds_no_strDup = NULL;
	char *ds_type_str = NULL;
	char *ds_type_strDup = NULL;
	tag_t tRefRelationType = NULLTAG;
	tag_t tRendRelationType = NULLTAG;
	tag_t* tSecObjectList = NULLTAG;
	int iSec_ObjCount = 0;
	char* SecObjType = NULL;
	int i, j, k, m, n = 0;
	char* SecObjString = NULL;
	int no_ref = 0;
	tag_t* tnamed_ref = NULLTAG;
	char *namedref_no_str = NULL;
	char *namedref_no_strDup = NULL;
	char *namedref_type_str = NULL;
	char *namedref_type_strDup = NULL;
	char* NameRef = NULL;
	tag_t dataset = NULLTAG;
	AE_reference_type_t RefType;
	char* RefName = NULL;
	tag_t RefObject = NULLTAG;
	char *BfrOrginal_Name = NULL;
	char Buffer[MAX_LINE_LENGTH];
	FILE *fpOutput_file = NULL;
	FILE *fpPart_List = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"NamedRef_Details_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ N A M E D - R E F E R E N C E   D E T A I L S   R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
    fprintf(fpOutput_file,"PART_NO, REV_SEQ, DATASET_TYPE, DATASET_NO, NAMED_REF_FILENAME\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_revseq_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_revseq_str!=NULL)tc_strdup(item_revseq_str,&item_revseq_strDup);
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_revseq_strDup!=NULL)trimwhitespace(item_revseq_strDup);
			
			printf(" [1]: Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf(" [2]: Part RevSeq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
	
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
			if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"B;2","2196G1A0154005"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					for (i = 0; i < n_itemobj_found; i++)
					{
						ITK_CALL(GRM_find_relation_type("IMAN_reference", &tRefRelationType));
						ITK_CALL(GRM_find_relation_type("IMAN_Rendering", &tRendRelationType));
						
						printf("\n Checking Dataset in IMAN_reference Relation Start..!!\n");fflush(stdout);
						ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRefRelationType, &iSec_ObjCount, &tSecObjectList));
						printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
						if(iSec_ObjCount > 0)
						{
							for (j = 0; j < iSec_ObjCount; j++)
							{
								dataset = tSecObjectList[j];
								ITK_CALL(AOM_ask_value_string(dataset, "object_type", &SecObjType));
								printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
								ITK_CALL(AOM_ask_value_string(dataset, "object_string", &SecObjString));
								printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
								if((tc_strcmp(SecObjType,"PDF")==0) || (tc_strcmp(SecObjType,"DirectModel")==0))
								{
									printf("\n Dataset Type Matched, Checking Named Reference File Available Status..!!\n");fflush(stdout);
									ITK_CALL(AE_ask_dataset_named_refs(dataset, &no_ref, &tnamed_ref));
									printf("\n Dataset Present With Named Reference, So, Printing Named Reference File_Name..!!\n");fflush(stdout);
									if(no_ref > 0)
									{
										printf("\n Dataset Present With Named Reference File..!!\n");fflush(stdout);
										for (k = 0; k < no_ref; k++)
										{
											ITK_CALL(AE_find_dataset_named_ref2(dataset,0,&RefName,&RefType,&RefObject));
											ITK_CALL(IMF_ask_original_file_name2(RefObject,&BfrOrginal_Name));
											printf("Orginal File Name: [%s]\n",BfrOrginal_Name);fflush(stdout);
											fprintf(fpOutput_file,"%s,%s,%s,%s,%s\n",item_id_strDup,item_revseq_strDup,SecObjType,SecObjString,BfrOrginal_Name);fflush(fpOutput_file);
										}
									}
									else
									{
										printf("\n Dataset Present With Empty Named Reference File..!!\n");fflush(stdout);
										fprintf(fpOutput_file,"%s,%s,%s,%s,%s\n",item_id_strDup,item_revseq_strDup,SecObjType,SecObjString,"Not_Present");fflush(fpOutput_file);
									}
								}
								else
								{
									printf("\n Dataset Type Not Matched For PDF & JT[DirectModel] in IMAN_reference Relation..!!\n");fflush(stdout);
								}
							}
						}
						else
						{
							printf("\n Dataset Not Present For PDF in IMAN_reference Relation..!!\n");fflush(stdout);
						}
						printf("\n Checking Dataset in IMAN_reference Relation End..!!\n");fflush(stdout);
						
						printf("\n Checking Dataset in IMAN_Rendering Relation Start..!!\n");fflush(stdout);
						ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRendRelationType, &iSec_ObjCount, &tSecObjectList));
						printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
						if(iSec_ObjCount > 0)
						{
							for (m = 0; m < iSec_ObjCount; m++)
							{
								dataset = tSecObjectList[m];
								ITK_CALL(AOM_ask_value_string(dataset, "object_type", &SecObjType));
								printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
								ITK_CALL(AOM_ask_value_string(dataset, "object_string", &SecObjString));
								printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
								if((tc_strcmp(SecObjType,"PDF")==0) || (tc_strcmp(SecObjType,"DirectModel")==0))
								{
									printf("\n Dataset Type Matched, Checking Named Reference File Available Status..!!\n");fflush(stdout);
									ITK_CALL(AE_ask_dataset_named_refs(dataset, &no_ref, &tnamed_ref));
									if(no_ref > 0)
									{
										printf("\n Dataset Present With Named Reference File..!!\n");fflush(stdout);
										for (n = 0; n < no_ref; n++)
										{
											ITK_CALL(AE_find_dataset_named_ref2(dataset,0,&RefName,&RefType,&RefObject));
											ITK_CALL(IMF_ask_original_file_name2(RefObject,&BfrOrginal_Name));
											printf("Before Set Orginal File Name: [%s]\n",BfrOrginal_Name);fflush(stdout);
										    fprintf(fpOutput_file,"%s,%s,%s,%s,%s\n",item_id_strDup,item_revseq_strDup,SecObjType,SecObjString,BfrOrginal_Name);fflush(fpOutput_file);
										}
									}
									else
									{
										printf("\n Dataset Present With Empty Named Reference File..!!\n");fflush(stdout);
										fprintf(fpOutput_file,"%s,%s,%s,%s,%s\n",item_id_strDup,item_revseq_strDup,SecObjType,SecObjString,"Not_Present");fflush(fpOutput_file);
									}
								}
								else
								{
									printf("\n Dataset Type Not Matched For PDF & JT[DirectModel] in IMAN_Rendering Relation..!!\n");fflush(stdout);
								}	
							}
						}
					    else
						{
						   printf("\n Dataset Type Not Matched For PDF & JT[DirectModel] in IMAN_reference Relation..!!\n");fflush(stdout);
						}
						printf("\n Checking Dataset in IMAN_Rendering Relation End..!!\n");fflush(stdout);
					}			
				}
				else
				{
					printf("\n No of Revision Found Zero[0]..!!");fflush(stdout);
				}
			}
			else
			{
				printf("\n DesignRevision Sequence Query Tag NULL..!!");fflush(stdout);
			}
		}
	}
	else
	{
		printf("\n Input_File NULL..!!");fflush(stdout);
	}
	if(titemobj_results)
	{
		MEM_free(titemobj_results);
	}
	if(tSecObjectList)
	{
		MEM_free(tSecObjectList);
	}
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
	fclose(fpPart_List);
	fclose(fpOutput_file);           
	printf("\n All Details Written Successfully on the Output File....\n");fflush(stdout);
	
	printf("\n Report File Attach To Users Home Folder Start..!!\n");fflush(stdout);
	char *Filename = NULL;
	char *FileLoc = NULL;
	char *dataSetName = NULL;
	IMF_file_t	fileDescriptor;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	tag_t tUser = NULLTAG;
	tag_t tHomeFolder = NULLTAG;
	
    dataSetName = (char *) MEM_alloc( 70 * sizeof(char) );
	tc_strcpy(dataSetName,"NAMEDREF-STATUS-COUNT-RPT-");
	tc_strcat(dataSetName,GenDate);
	printf(" Dataset Name: [%s]\n", dataSetName);fflush(stdout);
	
	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(Filename,RptFile);
	printf(" File Name: [%s]\n", Filename);fflush(stdout);

	tc_strcpy(FileLoc,"/user/cvprod/sourav/NamedRef_StatusCount/");
	tc_strcat(FileLoc,Filename);
	printf(" File Location: [%s]\n", FileLoc);fflush(stdout);

	ITK_CALL(AE_find_datasettype2("MSExcel",&datasettype));
	ITK_CALL(AE_find_tool2("MSExcel", &tool));
	ITK_CALL(AE_create_dataset_with_id(datasettype,dataSetName,"",NULL,NULL,&Newdataset));
	ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
	ITK_CALL(AE_set_dataset_format2(Newdataset,"BINARY_REF"));
	ITK_CALL(AOM_save(Newdataset));
    //ITK_CALL(AE_save_myself(Newdataset));	
	ITK_CALL(IMF_fmsfile_import(FileLoc,Filename,SS_BINARY,&filetag,&fileDescriptor));
	if(filetag == NULLTAG)
	{
		printf(" File Tag Not Found..!!\n");fflush(stdout);
	}
	ITK_CALL(AOM_refresh(Newdataset,TRUE));
	ITK_CALL(AE_add_dataset_named_ref2(Newdataset, "excel", AE_PART_OF, filetag));
	ITK_CALL(AOM_save(Newdataset));
	//ITK_CALL(AE_save_myself(Newdataset));
	ITK_CALL(AOM_refresh(Newdataset,FALSE));
	
	ITK_CALL(SA_find_user2("souravk.ttl",&tUser));
	ITK_CALL(SA_ask_user_home_folder(tUser,&tHomeFolder));
	ITK_CALL(AOM_lock(tHomeFolder));
	ITK_CALL(FL_insert(tHomeFolder,Newdataset,999));
    ITK_CALL(AOM_save(tHomeFolder));
	ITK_CALL(AOM_unlock(tHomeFolder));
	//ITK_CALL(AOM_refresh(tHomeFolder,1));
	printf("\n Report File Attach To Users Home Folder End..!!\n");fflush(stdout);
    	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_namedref_statuscount.c
* // ./linkitk -o tm_namedref_statuscount tm_namedref_statuscount.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_StatusCount/tm_namedref_statuscount .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_StatusCount/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_StatusCount/usage.txt .
* // ./tm_namedref_statuscount -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_namedref_statuscount -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/