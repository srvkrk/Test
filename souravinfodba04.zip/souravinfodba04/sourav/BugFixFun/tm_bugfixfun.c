/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Bug Fix
*  Description  :   Bug Fix
*  File Name    :   tm_bugfixfun.c
*  Created on   :   July 23rd, 2024
*  Usage        :   tm_bugfixfun
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     01/08/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* remove_white_spaces(char* InpStr)
{
    char *OutStr = (char *) malloc(500*sizeof(char));
    char str[1000];
    strcpy(str, InpStr);
    int i, j = 0;
    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] != ' ')
        {
            str[j] = str[i];
            j++;
        }
    }
    str[j] = '\0';
    printf("#-----------------------------#\n");
    printf("[Function - remove_white_spaces] String After Space Remove: [%s]\n", str);
    printf("#-----------------------------#\n");
    strcpy(OutStr,str);
    return OutStr;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* InpDMLProjCode = NULL;
	char* DMLDesGrp = NULL;
	char* InpDMLDesGrp = NULL;
	tag_t tCtrlobj = NULLTAG;
	tag_t* tctrlobj_results = NULLTAG;
	int n_entries = 4;
	int n_ctrlobj_found = 0;
	char* EnvType = NULL;
	char* EnvTypeDup = NULL;
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	InpDMLProjCode = ITK_ask_cli_argument("-pc=");
	DMLDesGrp = ITK_ask_cli_argument("-dg=");
	printf("\n Input DML Project Code: ------> <%s> \n",InpDMLProjCode);fflush(stdout);
	printf("\n Input DML Design Group: ------> <%s> \n",DMLDesGrp);fflush(stdout);
	trimwhitespace(InpDMLProjCode);
	InpDMLDesGrp = remove_white_spaces(DMLDesGrp);
	printf("\n Input DML Project Code After Trim --------> [%s]\n", InpDMLProjCode);fflush(stdout);
	printf("\n Input DML Design Group After Trim --------> [%s]\n", InpDMLDesGrp);fflush(stdout);
	
	ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
	if(tCtrlobj!=NULLTAG)
	{
		printf("#--------------------------------------------------------#\n");
		char DesignGroup[1000];
		tc_strcpy(DesignGroup, InpDMLDesGrp);
		char* tok;
		tok = tc_strtok(DesignGroup, ",");
		while(tok != NULL) 
		{
			printf("\n Each Element: [%s]\n", tok);
			char *cEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
			char *cValues[4]  = {InpDMLProjCode,tok,"V6PartCreChkInOutVld","0"};
			ITK_CALL(QRY_execute(tCtrlobj, n_entries, cEntries, cValues, &n_ctrlobj_found, &tctrlobj_results));
			printf("\n No of Control Object Found --------> [%d]\n",n_ctrlobj_found);fflush(stdout);
			if(n_ctrlobj_found>0)
			{
				printf("\n Control Object Found Against Input DML Project Code & Design Group\n");fflush(stdout);
				ITK_CALL(AOM_ask_value_string(tctrlobj_results[0], "t5_Userinfo1", &EnvType));
				printf("\n Environment Type: --------> [%s]\n",EnvType);fflush(stdout);
				if(EnvType!=NULL)tc_strdup(EnvType,&EnvTypeDup);
				printf("\n Environment Type Dup: --------> [%s]\n",EnvTypeDup);fflush(stdout);
				break;
			}
			else
			{
				printf("\n Control Object Not Found..!!\n");fflush(stdout);
				if(tc_strstr(tok,",")!=NULL)
				{
					printf("\n Comma Present in String..!!\n"); fflush(stdout);
					tok = strtok(NULL, ",");
				}
				else
				{
					printf("\n Comma Not Present in String..!!\n"); fflush(stdout);
					break;
				}
			}
		}
	}
	else
	{
	  printf("\n Control Object Tag not Found..!!\n");fflush(stdout);	
	}
	printf("#--------------------------------------------------------#\n");
	printf("\n Original Project Code: [%s]\n",InpDMLProjCode);fflush(stdout);
	printf("\n Original Design Group: [%s]\n",InpDMLDesGrp);fflush(stdout);
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_bugfixfun.c
* // ./linkitk -o tm_bugfixfun tm_bugfixfun.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BugFixFun/tm_bugfixfun .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BugFixFun/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BugFixFun/usage.txt .
* // ./tm_bugfixfun -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -pc="5129" -dg="00"
* // ./tm_bugfixfun -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -pc="5129" -dg="00"
* // ./tm_bugfixfun -u=infodba -p=infodba123 -g=dba -pc="5129" -dg="00"
*
***************************************************************************/