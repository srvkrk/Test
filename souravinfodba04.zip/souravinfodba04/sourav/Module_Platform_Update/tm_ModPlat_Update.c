/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Module & Update It's Platform According To Control Object (SYSCD - PartPlatform) Value in All Revision 
*  File Name    :   tm_ModPlat_Update.c
*  Created on   :   March 28th, 2024
*  Usage        :   tm_ModPlat_Update
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     28/03/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_prjcdup = (char *) malloc(20*sizeof(char));
	char *ProjCode = NULL;
	char *ProjCodeDup = NULL;
	FILE *fpPart_List = NULL;
	tag_t tCtrlobj = NULLTAG;
	tag_t* tctrlobj_results = NULLTAG;
	int c_entries = 2;
	int n_ctrlobj_found = 0;
	tag_t PropName_AttrID = NULLTAG;
	char *item_propvalue_str = NULL;
	char *item_propvalue_strDup = NULL;
	int i = 0;
	char Buffer[MAX_LINE_LENGTH];

    printf("\n ~~~~~~~~ M O D U L E - P L A T F O R M   U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	fpPart_List = fopen("PartList.txt","r");
	
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);	
            printf(" [1]: Input Part No(item_id_strDup): [%s]\n",item_id_strDup);
            
            ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
			if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {"*",item_id_strDup};
				//char *cValues[2]  = {"A;2","51780353R"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Design Revision & Sequence Found..!!\n");fflush(stdout);
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ProjectCode",&ProjCode));
						if(tc_strlen(ProjCode)>0)
						{
							tc_strdup(ProjCode,&ProjCodeDup);
						}
						else
						{
							printf("\n Project Code Value is NULL..!!");fflush(stdout);
						}
						
						tc_strcpy(item_prjcdup,"*");
			            tc_strcat(item_prjcdup,ProjCodeDup);
			            tc_strcat(item_prjcdup,"*");
			            printf(" Final: Part_Project_Code Value(item_prjcdup): [%s]\n",item_prjcdup);
						
						if((item_id_strDup != NULL) && (ProjCodeDup != NULL))
						{
							ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
							if(tCtrlobj!=NULLTAG)
							{
								printf("\n Control Objects... Query Found Successfully..!!\n");
								char *pEntries[2]  = {"SYSCD","Information-2"};
								char *pValues[2]  = {"PartPlatform",item_prjcdup};
								ITK_CALL(QRY_execute(tCtrlobj, c_entries, pEntries, pValues, &n_ctrlobj_found, &tctrlobj_results));
								printf("\n No of Control Object Found: [%d]\n",n_ctrlobj_found);fflush(stdout);
								if(n_ctrlobj_found>0)
								{
									printf("\n Control Object Found Against Input Project Code..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(tctrlobj_results[0],"t5_SubSyscd",&item_propvalue_str));
									if(tc_strlen(item_propvalue_str)>0)
									{
										tc_strdup(item_propvalue_str,&item_propvalue_strDup);
									}
									else
									{
										printf("\n Platform(t5_SubSyscd) Value is NULL..!!");fflush(stdout);
									}
									trimwhitespace(item_propvalue_strDup);
									printf(" Final: Part_Rev_Seq Value(item_propvalue_strDup): [%s]\n",item_propvalue_strDup);
									if(tc_strcmp(item_propvalue_strDup," ") !=0)
									{
										printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);  
										ITK_CALL(AOM_refresh(titemobj_results[i], POM_modify_lock));
										printf("\n Lock..!!\n");
										ITK_CALL(POM_attr_id_of_attr("t5_Platform", "Design_0_Revision_alt", &PropName_AttrID));
										printf("\n Property Name Tag Found..!!\n");
										ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], PropName_AttrID, item_propvalue_strDup));
										printf("\n Set Property Value..!!\n");
										ITK_CALL(POM_save_instances(1, &titemobj_results[i], true));
										printf("\n Save...!!\n");
										ITK_CALL(AOM_refresh(titemobj_results[i], POM_no_lock));
										printf("\n Unlock..!!\n");
										printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
									}
									else
									{
										printf("\n Property Value NULL..!!");
									}			
								}
								else
								{
									printf("\n Please Create Control Object For Input Project Code: [%s] (SYSCD - PartPlatform)!!",ProjCodeDup);fflush(stdout);
								}
							}
							else 
							{
							   printf("\n Control Objects... Query Tag is NULL..!!\n");fflush(stdout);
							}
						}
						else 
						{
							printf("\n Input_Part_No or Project Code is NULL..!!\n");fflush(stdout);
						}
	                }
				}
				else
				{
					printf("\n Searched Design Revision[Any] Not Found..!!");fflush(stdout);
				}
			}
			else
			{
				printf("\n Design Revision Tag is NULL..!!");fflush(stdout);
			}			
		}	
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));
    printf("\n ~~~~~~~~ M O D U L E - P L A T F O R M   U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ModPlat_Update.c
* // ./linkitk -o tm_ModPlat_Update tm_ModPlat_Update.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Module_Platform_Update/tm_ModPlat_Update .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Module_Platform_Update/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Module_Platform_Update/usage.txt .
* // ./tm_ModPlat_Update -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_ModPlat_Update -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/