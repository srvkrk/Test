/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   BOM
*  Description  :   Multi Line BOM Report
*  File Name    :   tm_bom_multi_report.c
*  Created on   :   April 1st, 2023
*  Usage        :   tm_bom_multi_report
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     01/04/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	FILE* fpPart_List = NULL;
	char* Part_Id_Str = NULL;
	int iRev_Count = 0;
	tag_t* tRevList = NULLTAG;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[300]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	int no_ref = 0;
	tag_t tBOMLine = NULLTAG;
	int j =0;
	time_t	temptime;
	char GenDate[20];
	struct tm *timeptr;
	int ch;
	char* RptFile= (char *) malloc(400*sizeof(char));
	FILE* fpOutput_file = NULL;
	char* SysFile= (char *) malloc(400*sizeof(char));
	FILE* fpSyslog_file = NULL;
	tag_t* tBOM_Children = NULLTAG;
	int iNumber_Child = 0;
	tag_t tWindow = NULLTAG;
	char* cLevel = NULL;
	char* cRev_Name = NULL;
	char* cItem_Id = NULL;
	char* cRevision = NULL;
	char* cParent = NULL;
	char* cOwn_Group = NULL;
	char* cOwn_User = NULL;
	char* cQuantity = NULL;
	char* cFind_No = NULL;
	char* cPacked = NULL;
	char* cDRAR = NULL;
	char* cPart_Type = NULL; 

	int bom_sub_child(tag_t* tBOM_Children, int iNumber_Child)
	{
		char* cLevel = NULL;
		char* cRev_Name = NULL;
		char* cItem_Id = NULL;
		char* cRevision = NULL;
		char* cParent = NULL;
		char* cOwn_Group = NULL;
		char* cOwn_User = NULL;
		char* cQuantity = NULL;
		char* cFind_No = NULL;
		char* cPacked = NULL;
		char* cDRAR = NULL;
		char* cPart_Type = NULL; 
		int j =0;
		int iFail = ITK_ok;
		int iAttribute = 0;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		for(j = 0; j <= iNumber_Child; j++)
		{
			ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_level_starting_0", &cLevel));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_rev_object_name", &cRev_Name));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_item_item_id", &cItem_Id));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_rev_item_revision_id", &cRevision));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_formatted_parent_name", &cParent));
		    ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_rev_owning_group", &cOwn_Group));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_rev_owning_user", &cOwn_User));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_quantity", &cQuantity));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_sequence_no", &cFind_No));
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nLevel: %s", cLevel);
			printf("\nRevision Name: %s", cRev_Name);
			printf("\nItem ID: %s", cItem_Id);
			printf("\nRevision ID: %s", cRevision);
			printf("\nParent: %s", cParent);
			printf("\nOwning Group: %s", cOwn_Group);
			printf("\nOwning User: %s", cOwn_User);
			printf("\nQuantity: %s", cQuantity);
			printf("\nFind No: %s", cFind_No);
			printf("\n-------------------------------------------------------------------------");
			fprintf(fpOutput_file,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s",cLevel,cRev_Name,cItem_Id,cRevision,cParent,cOwn_Group,cOwn_User,cQuantity,cFind_No);fflush(fpOutput_file);
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found --------> %d\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				bom_sub_child(tSubChild,iNumber_SubChild);
			}
		}
		return iFail;

	}
	
	printf("\n Generating Curernt Time Stamp");fflush(stdout);
	temptime = time(NULL);
	tc_strcpy(GenDate,"");
	timeptr = (struct tm *)localtime(&temptime);
	ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);

    printf("\n Generating Syslog File Name");fflush(stdout);
	tc_strcpy(SysFile,"TM_Multi_Level_BOM");
	tc_strcat(SysFile,"_");
	tc_strcat(SysFile,GenDate);
	tc_strcat(SysFile,".syslog");
	printf("\n Syslog File Name --------> %s", SysFile);fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"TM_Multi_Level_BOM");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	fpSyslog_file = fopen(SysFile, "w");
    if(fpSyslog_file == NULL)
	{
		printf("\n Unable to Create Syslog File on Server --------> %s",fpSyslog_file);fflush(stdout);
		return iFail;
	}
	fprintf(fpSyslog_file,"\n **************** M U L T I  L I N E   B O M   R E P O R T ******************");fflush(stdout);
	TC_write_syslog("\n **************** M U L T I   L I N E   B O M   R E P O R T ******************");fflush(stdout);
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	fprintf(fpSyslog_file,"\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	TC_write_syslog("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 1)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			fprintf(fpSyslog_file,"\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			TC_write_syslog("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			ITK_CALL(ITK_auto_login());
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				fprintf(fpSyslog_file,"\n Teamcenter Login Success...");fflush(stdout);
			    TC_write_syslog("\n Teamcenter Login Success...");fflush(stdout);
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
				fprintf(fpSyslog_file,"\n Logged in Username --------> %s", username);fflush(stdout);
			    TC_write_syslog("\n Logged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
				fprintf(fpSyslog_file,"\n Teamcenter Login Error --------> %s", cError);fflush(stdout);
			    TC_write_syslog("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			fpPart_List = fopen("PartList.txt","r");
			fpOutput_file = fopen(RptFile, "w");
			fprintf(fpOutput_file,"\n *******************************************************************************");fflush(stdout);
			fprintf(fpOutput_file,"\n **************** M U L T I   L E V E L   B O M   R E P O R T ******************");fflush(stdout);
			fprintf(fpOutput_file,"\n *******************************************************************************");fflush(stdout);
            fprintf(fpOutput_file,"\n\n\n Level, Revision Name, Item ID, Revision, Parent, Owning Group, Owning User, Quantity, Find No");fflush(fpOutput_file);  
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Output File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			if(fpPart_List != NULL)
		    {	
			    printf("\n Part List is Not Null Moving Forward...");fflush(stdout);
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					Part_Id_Str=strtok(temp,",");
					printf("\n Part No --------> %s", Part_Id_Str);fflush(stdout);

                    ITK_CALL(ITEM_find_item(Part_Id_Str, &tItemobj));
			        printf("\n Return Value From Item Find API is --------> %d", iFail);fflush(stdout);

                    if(tItemobj!=NULLTAG)
			        {
					   printf("\n Item Found Successfully...");fflush(stdout);
					   ITK_CALL(ITEM_list_all_revs(tItemobj, &iRev_Count, &tRevList));
					   printf("\n Return Value From Item List All Revision API is --------> %d", iFail);fflush(stdout);
					   printf("\n -----------------------------------------------\n");fflush(stdout);
					   printf("\n No of Item Revision Found --------> %d\n",iRev_Count);fflush(stdout);
					   printf("\n -----------------------------------------------\n");fflush(stdout);
					   if(iRev_Count>0)
					    {
							for (i = 0; i < iRev_Count; i++)
		                    {
								ITK_CALL(BOM_create_window( &tWindow));
								printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
								ITK_CALL(BOM_set_window_top_line( tWindow, tItemobj, tRevList[i], NULLTAG, &tBOMLine));
								printf("\n Return Value From BOM Set Window API is --------> %d", iFail);fflush(stdout);
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_level_starting_0", &cLevel));
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_rev_object_name", &cRev_Name));
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_item_item_id", &cItem_Id));
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_rev_item_revision_id", &cRevision));
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_formatted_parent_name", &cParent));
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_rev_owning_group", &cOwn_Group));
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_rev_owning_user", &cOwn_User));
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_quantity", &cQuantity));
								ITK_CALL(AOM_UIF_ask_value(tBOMLine, "bl_sequence_no", &cFind_No));
								printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
								printf("\nLevel: %s", cLevel);
								printf("\nRevision Name: %s", cRev_Name);
								printf("\nItem ID: %s", cItem_Id);
								printf("\nRevision ID: %s", cRevision);
								printf("\nParent: %s", cParent);
								printf("\nOwning Group: %s", cOwn_Group);
								printf("\nOwning User: %s", cOwn_User);
								printf("\nQuantity: %s", cQuantity);
								printf("\nFind No: %s", cFind_No);
								printf("\n-------------------------------------------------------------------------");
								fprintf(fpOutput_file,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s",cLevel,cRev_Name,cItem_Id,cRevision,cParent,cOwn_Group,cOwn_User,cQuantity,cFind_No);fflush(fpOutput_file);
								ITK_CALL(BOM_line_ask_all_child_lines(tBOMLine, &iNumber_Child, &tBOM_Children));
								printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
								printf("\n No of Children Found --------> %d\n",iNumber_Child);fflush(stdout);
								if(iNumber_Child>0)
					            {
									bom_sub_child(tBOM_Children, iNumber_Child);
								}
		                    }
                            if (tRevList)
						    {
							   MEM_free(tRevList);
						    }
							if (tBOM_Children)
						    {
							   MEM_free(tBOM_Children);
						    }
                            ITK_CALL(BOM_close_window(tWindow));
							printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
						}
						else
						{
							printf("\n No Item Revision Found...");fflush(stdout);
						}
			        }					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n All Item Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout); 
				fclose(fpOutput_file) ;           
				printf("\n First Level BOM Written Successfully on the Output File....\n");fflush(stdout); 
				printf("\n Output File Closed Now\n");fflush(stdout); 
			}
			else 
			{
				printf("\n Part List is Null....");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if(tItemobj != NULLTAG)
			{

				tc_strcpy(env_subject,"SUCCESS: MAIL FROM CVPROD DATASET REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    Please Check Attached Report");
				tc_strcat(env_body,"\n                    Total Dataset Count: ");
				tc_strcat(env_body," 2278\n\n\n");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			else
			{
				tc_strcpy(env_subject,"FAILED: MAIL FROM CVPROD DATASET REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    There is an Issue in Dataset report Creation ");
				tc_strcat(env_body,"\n\n                  Please Check Log & Support user");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			
			printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);
			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
	fclose(fpSyslog_file) ;           
	printf("\n Syslog File Closed Successfully\n");fflush(stdout);	
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}


