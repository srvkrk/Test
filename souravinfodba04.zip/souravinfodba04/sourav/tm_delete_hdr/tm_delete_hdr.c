/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   STN
*  Description  :   Query STN Header & Delete All TC Object Attached with it From Bottom To Top
*  File Name    :   tm_delete_hdr.c
*  Created on   :   March 28th, 2023
*  Usage        :   tm_delete_hdr
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     28/03/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	FILE* fpPart_List = NULL;
	char* STN_Hdr_Str = NULL;
	int n_entries = 1;
	int n_itemobj_found = 0;
	char* STNName = NULL;
	char* DSType = NULL;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	tag_t* titemobj_results = NULLTAG;
	char temp[10000];
	int no_ref = 0;
	tag_t* tnamed_ref = NULLTAG;
	char* NameRefType = NULL;
	char* NameRef = NULL;
	int j =0;
	
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 1)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			ITK_CALL(ITK_auto_login());
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			fpPart_List = fopen("HeaderList.txt","r");
			if(fpPart_List != NULL)
		    {	
			    printf("\n Header List is Not Null Moving Forward...");fflush(stdout);
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					STN_Hdr_Str=strtok(temp,",");
					printf("\n STN Header No --------> %s", STN_Hdr_Str);fflush(stdout);

                    ITK_CALL(QRY_find2("Item ID",&tItemobj));
			        printf("\n Return Value From Item ID Query API is --------> %d", iFail);fflush(stdout);

                    if(tItemobj!=NULLTAG)
			        {
					   printf("\n Item ID Query Found Successfully...");fflush(stdout);
					   char *cEntries[1]  = {"Item ID"};
					   char *cValues[1]  = {STN_Hdr_Str};
					   ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
					   printf("\n Return Value From Item ID Query Execute API is --------> %d", iFail);fflush(stdout);
					   printf("\n -----------------------------------------------\n");fflush(stdout);
					   printf("\n No of STN Header Found --------> %d\n",n_itemobj_found);fflush(stdout);
					   printf("\n -----------------------------------------------\n");fflush(stdout);
					   if(n_itemobj_found>0)
					    {
							for (i = 0; i < n_itemobj_found; i++)
		                    {
								ITK_CALL(AOM_ask_value_string( titemobj_results[i], "object_string", &STNName));
								printf("\n STN Name --------> %s", STNName);fflush(stdout);
								ITK_CALL(AE_ask_dataset_named_refs(titemobj_results[i], &no_ref, &tnamed_ref));
								if(no_ref>0)
					            {
									for (j = 0; j < no_ref; j++)
									{
										ITK_CALL(AOM_ask_value_string( tnamed_ref[j], "object_type", &NameRefType));
										ITK_CALL(AOM_ask_value_string( tnamed_ref[j], "original_file_name", &NameRef));
										ITK_CALL(AOM_refresh(titemobj_results[i], 1));
										printf("\n Return Value From Dataset Check-Out API is --------> %d", iFail);fflush(stdout);
										printf("\n Dataset Checked-Out Successfully");fflush(stdout);
										ITK_CALL(AE_remove_dataset_named_ref2(titemobj_results[i], "excel"));
										printf("\n Return Value From Remove Name Reference API is --------> %d", iFail);fflush(stdout);
										printf("\n Name Reference Removed Successfully");fflush(stdout);
										ITK_CALL(AOM_save(titemobj_results[i]));
										printf("\n Return Value From Dataset Save API is --------> %d", iFail);fflush(stdout);
										printf("\n Dataset Saved Successfully");fflush(stdout);
										ITK_CALL(AOM_refresh(titemobj_results[i], 0));
										printf("\n Return Value From Dataset Check-In API is --------> %d", iFail);fflush(stdout);
										printf("\n Dataset Checked-in Successfully");fflush(stdout);
									}
								}
		                    }

						}
						else
						{
							printf("\n After Query Execution No Dataset Found...");fflush(stdout);
						}
						if (titemobj_results)
						{
							MEM_free(titemobj_results);
						}
						if (tnamed_ref)
						{
							MEM_free(tnamed_ref);
						}
			        }					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n All Dataset Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout); 
			}
			else 
			{
				printf("\n Dataset List is Null....");fflush(stdout);
			}
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}


