/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create Module Revision Object After Reading Data From Input File 
*  File Name    :   tm_modulecreate.c
*  Created on   :   Jun 12th, 2024
*  Usage        :   tm_modulecreate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/06/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>

#define MAX_LINE_LEN 10240
#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int report_error(char *file, int line, char *call, int status,
    logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        const int
            *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
        if (n_errors > 0)
        {
            ECHO("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            ECHO("\n%s\n", error_message_string);
        }

        ECHO("error %d at line %d in %s\n", status, line, file);
        ECHO("%s\n", call);
        if (exit_on_error)
        {
            ECHO("%s", "Exiting program!\n");
            exit (status);
        }
    }
    return status;
}



/*
#define ITKCALL( argument )                                             \
{                                                                       \
    int retcode = argument;                                             \
    if ( retcode != ITK_ok ) {                                          \
        char* s;                                                        \
        printf( " "#argument "\n" );                                    \
        printf( "  returns [%d]\n", retcode );                          \
        EMH_ask_error_text (retcode, &s);                               \
        printf( "  Teamcenter ERROR: [%s]\n", s);           \
        printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
        if (s != 0) MEM_free (s);                                       \
    }                                                                   \
}*/


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}




/*******************************************START OF UTILITY FUNCTIONS**************************************************/

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}
void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}

///CODE START HERE
int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		//printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		//printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;	
}

int getItemRevObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_sendESOMailRep: getItemRevObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



int getGeneralObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_sendESOMailRep: getGeneralObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



typedef struct PartModel_
{
 int level;
 tag_t childItemRev;
 tag_t childBomLine;
} *PartModel; 

void setAddPartModel(int *count,PartModel **objlist,PartModel obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartModel *)malloc((*count ) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartModel *)realloc((*objlist),(*count) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}





void setFindTagInSet(tag_t *objlist,tag_t obj,int count,int *found)
{
	int k=0;
	*found=-1;
	for(k=0;k<count;k++)
	{		
		if(objlist[k]==obj)
		{
			*found=k;
			break;
		}
	}
}



char *t5TrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

void remove_multi_new_line(char* string)
{
  size_t length = strlen(string);
  while((length>0) && (string[length-1] == '\n'))
  {
      --length;
      string[length] ='\0';
  }
}


void  t5GetCurrentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}


//declaration of date structure

struct date{
	int dd,mm,yy;
	};
//function to get yesterday's (previous) date
void getYesterdayDate(struct date *d){
	if(d->dd==1){
		if(d->mm==4||d->mm==6||d->mm==9||d->mm==11){
			d->dd=31;
			d->mm--;
		}
		else if(d->mm==3){
			if((d->yy%4)==0 && ((d->yy%100)!=0 || (d->yy%400)==0)) d->dd=29;
			else d->dd=28;
			d->mm--;
		}
		else if(d->mm==1){
			d->dd=31;
			d->yy--;
			d->mm=12;
		}
		else if(d->mm==2){
			d->dd=31;
			d->mm--;
		}
		else{
			d->dd=30;
			d->mm--;
		}
	}
	else{
		d->dd--;
	}
}


void t5GetPrevDate(char cprevAccessDate[30])
{
	int day, month, year, nd, nm, ny;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	
	struct date dt;

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	
	dt.dd = day;
	dt.mm = month;
	dt.yy = year;
	
	printf( "Given date is %d:%d:%d\n", day, month, year );
   
	getYesterdayDate(&dt);
	nd = dt.dd;
	nm = dt.mm;
	ny = dt.yy;
	
    printf( "Prev  days date is %d:%d:%d\n", nd, nm, ny );
	t5GetCurrentMonth(nm,cMonth);
	//printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cprevAccessDate,strDay);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,cMonth);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,strYear);
	tc_strcat(cprevAccessDate," ");
	tc_strcat(cprevAccessDate,"00:00");
	//printf("\n cprevAccessDate:%s\n",cprevAccessDate);
}

void t5GetPrevDateTo(char cprevAccessDate[30])
{
	int day, month, year, nd, nm, ny;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	
	struct date dt;

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	
	dt.dd = day;
	dt.mm = month;
	dt.yy = year;
	
	printf( "Given date is %d:%d:%d\n", day, month, year );
   
	getYesterdayDate(&dt);
	nd = dt.dd;
	nm = dt.mm;
	ny = dt.yy;
	
    printf( "Prev  days To date is %d:%d:%d\n", nd, nm, ny );
	t5GetCurrentMonth(nm,cMonth);
	//printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cprevAccessDate,strDay);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,cMonth);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,strYear);
	tc_strcat(cprevAccessDate," ");
	tc_strcat(cprevAccessDate,"23:59");
	//printf("\n cprevAccessDate:%s\n",cprevAccessDate);
}


void t5GetCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n t5GetCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);

	fflush(stdout);
}

int getTCObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	//printf("\n\n partNumber ===> [%s]\n",partNumber);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	//printf("\n getLatestPart: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}


int getItemRevObj(char *partNumber, char* revId, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	//printf("\n\n partNumber ===> [%s]\n",partNumber);fflush(stdout);
	//printf("\n\n revId ===> [%s]\n",revId);fflush(stdout);
	
	qry_entries[0] = "Item ID";
	
	qry_values[0] = partNumber;
	
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 1, qry_entries, qry_values, &count, &itemObjs));
	//printf("\n getItemRevObj: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		//*tcPart = itemObjs[count-1];
		int k=0;
		char* revS = NULL;		
		for(k=0;k<count;k++)
		{
			CALLAPI(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			//printf("\n getItemRevObj: revS==>%s", revS);fflush(stdout);
			//printf("\n getItemRevObj: revS length==>%d", strlen(revS));fflush(stdout);
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revId)==0)
			{
				*tcPart = itemObjs[k];
				break;
			}			
		}
	}
	
	return ifail;
}


int getPartObjFromRevSeq(char* partnumber, char* rev, char* seq, tag_t *partObj)
{
	int ifail = ITK_ok;
	
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;
	char* revStr = NULL;
	int seqInt = 0;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Item ID";
	qry_entries[1] = "Type";
	//qry_entries[2] = "Sequence Id";
	
	qry_values[0] = partnumber;
	revStr = (char *) MEM_alloc( 10 * sizeof(char) );
	//tc_strcpy(revStr,"");
	tc_strcpy(revStr,rev);
	tc_strcat(revStr,";");
	tc_strcat(revStr,seq);
	printf("\nSAN:getPartObjFromRevSeq: revStr=========>%s\n",revStr);fflush(stdout);
	printf("\nSAN:getPartObjFromRevSeq: revStr==length=======>%d\n",strlen(revStr));fflush(stdout);
	qry_values[1] = "Design Revision";
	
	//trimLeading(revStr);
	char* revStr1 = NULL;
	char* revStr2 = NULL;
	revStr1 = ltrimString(revStr);
	revStr2 = rtrimString(revStr1);
	
	
		
	printf("\nSAN:getPartObjFromRevSeq: After trim revStr2=========>%s\n",revStr2);fflush(stdout);
	printf("\nSAN:getPartObjFromRevSeq: After trim revStr2==length=======>%d\n",strlen(revStr2));fflush(stdout);	
	
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\n getPartObjFromRevSeq: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		int k=0;
		char* revS = NULL;
		for(k=0;k<count;k++)
		{
			CALLAPI(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			printf("\n getPartObjFromRevSeq: revS==>%s", revS);fflush(stdout);
			printf("\n getPartObjFromRevSeq: revS length==>%d", strlen(revS));fflush(stdout);
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revStr2)==0)
			{
				*partObj = itemObjs[k];
				break;
			}
			
		}
	}
	
	if(revStr!=NULL) MEM_free(revStr);
	return ifail;	

}


/*******************************************END OF UTILITY FUNCTIONS**************************************************/




int getAllItemRevObject(char *partNumber, char *object_type, int *cnt, tag_t **tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	//printf("\n SAN:getAllItemRevObject: getItemRevObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		int i=0;
		for(i=0;i<count;i++)
		{
			t5AddTagObjToSet(cnt,tcPart,itemObj[i]);
		}
		

	}
	
	return ifail;
}

int Create_occurance_effectivity(tag_t primaryObj, char* objectId, char* objectrevId, char* arcPlatform, char* EffDateStr)
{
	int		ifail			= ITK_ok;
	int		iy				= 0;
	int		iz				= 0;
	int		bvr_count		= 0;
	int		n_occs			= 0;
	int		Item_count		= 0;
	int		effcnt			= 0;	

	tag_t	*bvrs;
	tag_t   *occsal;
	tag_t	ChildItem		= NULLTAG;
	tag_t	*rev_list		= NULLTAG;
	tag_t	bvr				= NULLTAG;
	tag_t	bvrchild		= NULLTAG;
	tag_t	*Effobbj		= NULLTAG;
	tag_t	EffecTag		= NULLTAG;

	char	*dataset_name1	= NULL;
	char	*t5Des_Rev		= NULL;

	date_t	date_end		= NULLDATE;
	
	date_t dcreation_date;
	char* ccreation_date	= NULL;
	char* end_date			= NULL;
	ccreation_date = malloc(30 * sizeof (char *) );
	end_date = malloc(30 * sizeof (char *) );

	char* Effecsta			 = NULL;
	char* EffecEnd			 = NULL;

	char EffecRange[200];
	char EffecName[200];
	
	int i_ChildCount		 = 0;
	int iChldPrts			 = 0;
	int uidType				 = 0;
	int Uidlatest            = 0;
	tag_t  t_BomLineWindow	 = NULLTAG;
	tag_t  t_Rule			 = NULLTAG;
	tag_t  t_TopLine		 = NULLTAG;
	tag_t  *t_PartChildren	 = NULLTAG;
	tag_t  t_Childobject	 = NULLTAG;
	char   *Child_SeqId		 = NULL;
	char   *ChildUID		 = NULL;
	char   *child_Uid   	 = NULL;
	
	date_t start_date;
	char * startDate;
	startDate = malloc(30 * sizeof (char *) );
	
	char* toDt = NULL;
	char* toDt1 = NULL;
	char* toDt2 = NULL;
	char* toDate = NULL;
	
	
	
	//ifail = ITK_string_to_date("31-Dec-2099 00:00", &date_end);
	
	//Get current date
	char cCurrentAccessDate[20]={0};
	char cPrevAccessDate[20]={0};
	char* fromDt = NULL;
	char* fromDt1 = NULL;
	char* tempStr = NULL;
	
	t5GetCurrentDateTime(cCurrentAccessDate);
	
	printf("\n Inide Create_occurance_effectivity.....\n");fflush(stdout);
	//printf("\n Eff:Current date  is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
	
	//t5GetPrevDate(cPrevAccessDate);
	
	 
	//fromDt= subString(EffDateStr,0,11);
	
	if(EffDateStr == NULL)
	{
		//printf("\n No effectivity of source module...Exiting...\n");fflush(stdout);
		return ifail;
	}
	else 
	{
		if(tc_strcmp(EffDateStr,"")==0)
		{
			//printf("\n11111 No effectivity of source module...Exiting...\n");fflush(stdout);
			return ifail;
		}
	}
		
	
	tempStr = strdup(EffDateStr);
	
	char* tempStr1 = NULL;
	char* tempStr2 = NULL;
	
	//printf("\n tempStr =====> %s\n",tempStr);fflush(stdout);
	
	ITK_CALL(STRNG_replace_str(tempStr," to ",";",&tempStr1));
	//printf("\n tempStr1-------> %s\n",tempStr1);fflush(stdout);
	
	ITK_CALL(STRNG_replace_str(tempStr1," (NONE)","",&tempStr2));

	
	if(tempStr2 == NULL)
	{
		//printf("\n tempStr2 is null No effectivity of source module...Exiting...\n");fflush(stdout);
		return ifail;
	}
	else 
	{
		if(tc_strcmp(tempStr2,"")==0)
		{
			//printf("\n2222 tempStr2 is blank No effectivity of source module...Exiting...\n");fflush(stdout);
			return ifail;
		}
	}
	
	
	fromDt1 = strtok(tempStr2,";");
	toDt1 = strtok(NULL,";");	
	
	fromDt = rtrimString(fromDt1);
	
	
	
	tc_strcpy(cPrevAccessDate,"");
	tc_strcat(cPrevAccessDate,fromDt);
	
	toDt2 = ltrimString(toDt1);
	
	toDate = subString(toDt2,0,17);
	
	printf("San.... fromDt[%s].... toDate[%s]\n",fromDt,toDate);fflush(stdout);
	
	//printf("\n Eff:Altroz split date  is..:[%s]\n",cPrevAccessDate);fflush(stdout);
	
	//printf("\n Eff:Yesterday date  is..:[%s]\n",cPrevAccessDate);fflush(stdout);
	
	ifail = ITK_string_to_date(toDate, &date_end);
	
	//if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &start_date )))
	if(ITK_ok != (ifail = ITK_string_to_date(cPrevAccessDate, &start_date )))
	{
		return ifail;
	}	

	ifail = ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs);
	//printf("\nXXX: CM_MR_SetOccEff bvr count is...%d",bvr_count);fflush(stdout);
	if (bvr_count)
	{

		int occCnt = 0;
		tag_t* occList = NULLTAG;
		int occNtFndCnt = 0;
		tag_t* occNtFndList = NULLTAG;		
		int effIdCnt = 0;
		char** effIdLst = NULL;
		int effIdCnt1 = 0;
		char** effIdLst1 = NULL;
		int effIdCnt2 = 0;
		char** effIdLst2 = NULL;
		bvr = bvrs[0];
		ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
		//printf("\n CM_MR_SetOccEff n_occs count is...%d",n_occs);fflush(stdout);
		for (iy = 0; iy<n_occs; iy++)
		{
			ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

			if (ChildItem)
			{
				ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

				
				//
				Item_count = 0;
				rev_list = NULLTAG;
				getAllItemRevObject(dataset_name1,"Design Revision",&Item_count, &rev_list);
				//printf("\nSAN: Item_count==> %d\n",Item_count);fflush(stdout);
				if(Item_count ==0)
				{
					ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
				}
				//printf("\nSAN: Item_count==> %d\n",Item_count);fflush(stdout);
				//getAllItemRevObject(char *partNumber, char *object_type, int *cnt, tag_t **tcPart)
				
				if(Item_count > 0)
				{
					for (iz = 0; iz<Item_count; iz++)
					{
						ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
						//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
						//printf("\nSAN:tst:dataset_name1[%s]==> objectId[%s], t5Des_Rev[%s] ==> objectrevId[%s]\n",dataset_name1,objectId,t5Des_Rev,objectrevId);fflush(stdout);
						if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
						{
							//printf("\nSAN:Added....\n");fflush(stdout);
							t5AddTagObjToSet(&occCnt,&occList,occsal[iy]);
						}
						

					}
				}
			}
		}
		
		printf("\nOccurance Count==============>%d\n",occCnt);fflush(stdout);
		
		if(occCnt==1)
		{
			for (iy = 0; iy<n_occs; iy++)
			{
				ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					//ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					Item_count = 0;
					rev_list = NULLTAG;
					getAllItemRevObject(dataset_name1,"Design Revision",&Item_count, &rev_list);
					if(Item_count ==0)
					{
						ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					}
					//printf("\nSAN: Item_count==> %d\n",Item_count);fflush(stdout);					

					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							

							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
							  tc_strcpy(EffecName,"");
							  tc_strcat(EffecName,dataset_name1);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,t5Des_Rev);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,arcPlatform);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,"1");

							 // printf("\n CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);

							  ifail = AOM_ask_value_date(rev_list[iz],"creation_date",&dcreation_date);
							  ITK_date_to_string(dcreation_date, &ccreation_date);
							  ITK_date_to_string(date_end, &end_date);
							  //printf("\n\t CM_MR_SetOccEff creation_date is  >>>>>>>>>> [ %s ]",ccreation_date); fflush(stdout);
							  //printf("\n\t CM_MR_SetOccEff end_date is  >>>>>>>>>> [ %s ]",end_date); fflush(stdout);
							  
								ITK_date_to_string(start_date, &startDate);

								//Effecsta=subString(ccreation_date,0,11);
								//Effecsta=subString(startDate,0,11);
								Effecsta = startDate;
								EffecEnd=subString(end_date,0,11);

								tc_strcpy(EffecRange,"");

								tc_strcat(EffecRange,Effecsta);
								tc_strcat(EffecRange," to ");
								tc_strcat(EffecRange,EffecEnd);

								//printf("\n CM_MR_SetOccEff Date range is = [ %s ]",EffecRange);fflush(stdout);

								ifail =  AOM_lock( bvr );

								ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

								//printf("\n CM_MR_SetOccEff effcnt count is...%d",effcnt);fflush(stdout);
								
								
								
								if (effcnt == 0)
								{
									ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

									if (EffecTag)
									{
										//printf("\n CM_MR_SetOccEff setting effe 2...%d",effcnt);fflush(stdout);

										ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

										ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,EffecRange,FALSE);

										ifail = AOM_save(EffecTag);
										ifail = AOM_refresh(EffecTag, 0);

										//ifail = AOM_refresh(bvr, 1);
										ifail = AOM_save(bvr);
										ifail = AOM_unlock( bvr );

									}
								}
							}
						}
					}
				}
			}
						
		}
		
		
		
		//for multi occurance case
		if(occCnt>1)
		{
			
			int k=0;
			for(k=0;k<occCnt;k++)
			{
				tag_t occTag = NULLTAG;
				occTag = occList[k];
				ifail = PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild );
				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					//ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list
					Item_count = 0;
					rev_list = NULLTAG;
					getAllItemRevObject(dataset_name1,"Design Revision",&Item_count, &rev_list);
					if(Item_count ==0)
					{
						ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					}
					//printf("\nSAN: Item_count==> %d\n",Item_count);fflush(stdout);					
					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
								
								// int effcnt = 0;
								// tag_t Effobbj = NULLTAG;
					
								char str1[20];
								sprintf(str1, "%d", k+1);
								tc_strcpy(EffecName,"");
								tc_strcat(EffecName,dataset_name1);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,t5Des_Rev);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,arcPlatform);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,str1);								  

								//printf("\nSAN: adding to the set..EffecName... [ %s ]\n",EffecName);fflush(stdout);
								t5AddStrToSet(&effIdCnt, &effIdLst,EffecName);
								

								
								ifail = PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj);
								
								if(effcnt ==0)
								{
									//printf("\nSAN: adding to the set. not found .EffecName... [ %s ]\n",EffecName);fflush(stdout);
									t5AddStrToSet(&effIdCnt1, &effIdLst1,EffecName);
									t5AddTagObjToSet(&occNtFndCnt,&occNtFndList,occTag);
								}
								
								if(effcnt>0)
								{
									char* effId = NULL;
									tag_t effObj = NULLTAG;
									int flag =0;
									effObj= Effobbj[0];
									ifail = PS_occ_eff_ask_id(bvr,occTag,effObj, &effId);
									//printf("\nSAN111111: effId==> %s\n",effId);fflush(stdout);
									
									if(effId==NULL )
									{
										flag++;
									}
									else if(tc_strcmp(effId,"")==0)
									{
										flag++;
									}
									//printf("\nSAN2222: flag==> %d\n",flag);fflush(stdout);
									
									if(flag==0)									
									{
										//printf("\nSAN: adding to the set effIdLst2 ..effId... [ %s ]\n",effId);fflush(stdout);
										t5AddStrToSet(&effIdCnt2, &effIdLst2,effId);
									}
									if(flag>=1)
									{
										//printf("\nSAN: Removed effectivity\n",effId);fflush(stdout);
										ifail= PS_occ_eff_remove_eff(bvr,occTag,effObj);
									}
								}

								
								
							}
						}
					}
							
				}
				
								
				
			}

		}
		
		//printf("\nSAN: ====> effIdCnt==> %d\n",effIdCnt);fflush(stdout);
		//printf("\nSAN: ====> effIdCnt1==> %d\n",effIdCnt1);fflush(stdout);
		//printf("\nSAN: ====> effIdCnt2==> %d\n",effIdCnt2);fflush(stdout);
		//printf("\nSAN: ====> occNtFndCnt==> %d\n",occNtFndCnt);fflush(stdout);
		//for multi occurance case
		
		if(occNtFndCnt>0)
		{
			int jk=0;
			for(jk=0;jk<occNtFndCnt;jk++)
			{
				tag_t occTag = NULLTAG;
				occTag = occNtFndList[jk];
				ifail = PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild );
				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n XXX: CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					//ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					Item_count = 0;
					rev_list = NULLTAG;
					getAllItemRevObject(dataset_name1,"Design Revision",&Item_count, &rev_list);
					if(Item_count ==0)
					{
						ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					}
					//printf("\nSAN: Item_count==> %d\n",Item_count);fflush(stdout);					
					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\tXXXX: CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
								
								int ij=0;
								for(ij=0;ij<occCnt;ij++)
								{
									int found =0;
									char str1[20];
									sprintf(str1, "%d", ij+1);
									tc_strcpy(EffecName,"");
									tc_strcat(EffecName,dataset_name1);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,t5Des_Rev);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,arcPlatform);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,str1);								
								  

									//printf("\n XXXX: yyyyyy CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);
									
									t5FindStrInSet(effIdLst2,effIdCnt2,EffecName,&found);
									//printf("\nFound==>%d\n",found);fflush(stdout);
									
									if(found==0)
									{
										ifail = AOM_ask_value_date(rev_list[iz],"creation_date",&dcreation_date);
										ITK_date_to_string(dcreation_date, &ccreation_date);
										ITK_date_to_string(date_end, &end_date);
										//printf("\n\t XXX:CM_MR_SetOccEff creation_date is  >>>>>>>>>> [ %s ]",ccreation_date); fflush(stdout);
										//printf("\n\t XXX: CM_MR_SetOccEff end_date is  >>>>>>>>>> [ %s ]",end_date); fflush(stdout);
										
										ITK_date_to_string(start_date, &startDate);

										//Effecsta=subString(ccreation_date,0,11);
										//Effecsta=subString(startDate,0,11);
										Effecsta = startDate;
										EffecEnd=subString(end_date,0,11);

										tc_strcpy(EffecRange,"");

										tc_strcat(EffecRange,Effecsta);
										tc_strcat(EffecRange," to ");
										tc_strcat(EffecRange,EffecEnd);

										//printf("\n XXX:CM_MR_SetOccEff Date range is = [ %s ]",EffecRange);fflush(stdout);

										ifail =  AOM_lock( bvr );

										ifail = PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj);

										//printf("\n CM_MR_SetOccEff effcnt count is...%d",effcnt);fflush(stdout);
										

										
										if (effcnt == 0)
										{
										
											ifail = PS_occ_eff_create(bvr,occTag,&EffecTag);

											if (EffecTag)
											{
												//printf("\n CM_MR_SetOccEff setting effe 2...%d",effcnt);fflush(stdout);

												ifail = PS_occ_eff_set_id(bvr,occTag,EffecTag,EffecName);

												ifail = PS_occ_eff_set_date_range(bvr,occTag,EffecTag,EffecRange,FALSE);

												ifail = AOM_save(EffecTag);
												ifail = AOM_refresh(EffecTag, 0);
												ifail = AOM_save(bvr);
												ifail = AOM_unlock( bvr );

											}
											t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName);
										}
										
										break;
										
									}
									
								}
							}
						}
					}						
				}					
			}
		}
				
	}

	return ifail;
}





int addChildToParent(tag_t archModuleRevTag, tag_t child_line, int* childIdCnt, char*** childIdList)
{
	int ifail = ITK_ok;

	int childId = 0;
	int childRevSeq = 0;
	char* child_id = NULL;
	char* child_rev_seq = NULL;
	char child_partNum[100];
	
	int effecId = 0;
	char* effec_id = NULL;
	char* occ_effec = NULL;
	int occEffec = 0;
	int vfFormId = 0;
	char* variant_formula = NULL;
	int findNoId = 0;
	char* find_no = NULL;
	char *sCustomTotalVF= NULL;	
	if (sCustomTotalVF != NULL) { sCustomTotalVF=NULL; }
	sCustomTotalVF=malloc(9000 * sizeof(char));
	
	char *sCustomANDVF= NULL;
	char *sCustomORVF= NULL;

	
	CALLAPI(BOM_line_look_up_attribute("bl_item_item_id",&childId));
	CALLAPI(BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq));
	CALLAPI(BOM_line_ask_attribute_string(child_line,childId,&child_id));
	CALLAPI(BOM_line_ask_attribute_string(child_line,childRevSeq,&child_rev_seq));
	
	printf("\n child_id[%s] child_rev_seq[%s]",child_id,child_rev_seq);fflush(stdout);
	
	tc_strcpy(child_partNum,"");
	tc_strcat(child_partNum,child_id);
	tc_strcat(child_partNum,"_");
	tc_strcat(child_partNum,child_rev_seq);
	
	printf("\n child_partNum[%s]",child_partNum);fflush(stdout);
	

	
	CALLAPI(BOM_line_look_up_attribute("bl_has_date_effectivity",&effecId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,effecId,&effec_id));
	
	printf("\n Effectivity ID[%s]",effec_id);fflush(stdout);
	
	CALLAPI(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
	CALLAPI(BOM_line_ask_attribute_string(child_line,occEffec,&occ_effec));
	
	printf("\n Effectivity[%s]",occ_effec);fflush(stdout);
	
	CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,vfFormId,&variant_formula));
	
	printf("\n variant_formula[%s]",variant_formula);fflush(stdout);
	
	tc_strcpy(sCustomTotalVF,"");
	tc_strcat(sCustomTotalVF,variant_formula);
	printf("\n VFSubStr1 =>%s\n ",sCustomTotalVF);fflush(stdout);
	
	ITK_CALL(STRNG_replace_str(sCustomTotalVF,"AND ([Teamcenter]","& ([Teamcenter]",&sCustomANDVF));
	printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

	ITK_CALL(STRNG_replace_str(sCustomANDVF,"AND [Teamcenter]","& [Teamcenter]",&sCustomANDVF));
	printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

	ITK_CALL(STRNG_replace_str(sCustomANDVF," OR "," | ",&sCustomORVF));
	printf("\n Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);	
	

	//bl_item_object_type
	
	
	//bl_sequence_no
	
	CALLAPI(BOM_line_look_up_attribute("bl_sequence_no",&findNoId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,findNoId,&find_no));
	
	printf("\n find_no[%s]",find_no);fflush(stdout);
	
	//Get Child Item Rev

	tag_t archModuleItemTag = NULLTAG;
	tag_t bv = NULLTAG;
	tag_t bvr = NULLTAG;	
	tag_t childModuleRevTag = NULLTAG;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t* bvs = NULLTAG;
	int bv_count = 0;
	
	int objTypeId = 0;
	char* bl_object_Type = NULL;
	
	CALLAPI(BOM_line_look_up_attribute("bl_item_object_type",&objTypeId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,objTypeId,&bl_object_Type));
	
	printf("\n bl_object_Type==>%s\n",bl_object_Type);fflush(stdout);
	

	CALLAPI(getItemRevObj(child_id,child_rev_seq,&childModuleRevTag));
	
	
	
	
	

	if(childModuleRevTag == NULLTAG)
	{
		printf("\n Child Module Rev[%s/%s] not found in PLM. Exiting the program....\n",child_id,child_rev_seq);fflush(stdout);
		return ifail;
	}
	
	printf("\nFound Architecture Module Rev Tag ....\n");fflush(stdout);
	CALLAPI(ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag));
	

	CALLAPI(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));
	
	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		ifail = PS_create_bom_view(NULLTAG,"","",archModuleItemTag,&bv);
		ifail = AOM_save( bv );
		ifail = AOM_save( archModuleItemTag );
		ifail = AOM_unlock( archModuleItemTag );
		if(bv != NULLTAG) 
		{
			printf("\nCreatd BOM View ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View ...\n");fflush(stdout);
		}
	}
	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);			
	
	if(bvr_count)
	{
		//int n_occs = 0;
		//tag_t* occs = NULLTAG;
		//int i = 0;
		
		bvr = bvrs[0];
		MEM_free(bvrs);
		
		/*
		ifail = AOM_lock( bvr );
		ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occs );
		
		for (i = 0; i<n_occs; i++)
		{
			ifail = PS_delete_occurrence( bvr, occs[i] );
		}
		ifail = AOM_save( bvr );
		ifail = AOM_unlock( bvr );
		MEM_free(occs);
		*/
		
	}
	else
	{
		ifail = PS_create_bvr( bv, "", "", false, archModuleRevTag, &bvr );
		
		ifail = AOM_save( bvr );
		ifail = AOM_save( archModuleRevTag );
		ifail = AOM_unlock( archModuleRevTag );
		if(bvr != NULLTAG) 
		{
			printf("\nCreatd BOM View Revision ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View Revision...\n");fflush(stdout);
		}
	}
	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}				
						

					
	if(bvr != NULLTAG)
	{

		tag_t* occs1 = NULLTAG;
		
		tag_t occTag = NULLTAG;
		
		if  (PS_create_occurrences( bvr, childModuleRevTag, NULLTAG,1, &occs1 ));
		
		if(occs1[0] != NULLTAG)
		{
			printf("\nOccurrence created....\n");fflush(stdout);
			occTag = occs1[0];
					
		}
	
		ifail = AOM_save(bvr);
		ifail = AOM_refresh(bvr,1);
		ifail = AOM_unlock( bvr );

		if(occs1[0] != NULLTAG)
		{
			char* arcPlatform = NULL;
			printf("\n1111...Occurrence created....\n");fflush(stdout);
			occTag = occs1[0];
			
			//Create Occurence effectivity.
			
			CALLAPI(AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform));
			printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
			
			//Get Child line of Dest Arch Node
			tag_t window = NULLTAG;
			tag_t rule = NULLTAG;
			tag_t top_line = NULLTAG;
			tag_t* child_lines = NULLTAG;
			int nChld = 0;
			//void t5AddStrToSet(int *count,char ***strset,char* str)
			//int childIdCnt = 0;
			//char** childIdList = NULL:
			
			CALLAPI(BOM_create_window (&window));
			CALLAPI(CFM_find( "Latest Working", &rule ));
			CALLAPI(BOM_set_window_config_rule( window, rule ));
			CALLAPI(BOM_set_window_pack_all (window, false));
			CALLAPI(BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line));
	
			if(top_line != NULLTAG)
			{
				int ij = 0;
				int uidType = 0;
				char * ChildUID = NULL;
				int chldFound = 0;
				
				int Uidlatest = 0;
				char* childSAPID = NULL;
				
				char* child_item_id = NULL;
				char* child_item_rev_id = NULL;
				
				int fndidlatest = 0;
				
				
				
				CALLAPI(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
				printf("\nNo of child objects of dest Arc Mod Rev are : %d",nChld);fflush(stdout);
				
				for(ij=0;ij<nChld;ij++)
				{
					 
					if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
					if(BOM_line_ask_attribute_string(child_lines[ij], uidType, &ChildUID));
					printf("\n [%d] ChildUID ======>>> %s \n",ij +1, ChildUID);fflush(stdout);
					
					t5FindStrInSet(*childIdList,*childIdCnt,ChildUID,&chldFound);
					printf("\nChild found in the set==>%d\n",chldFound);fflush(stdout);
					if(chldFound == 0)
					{
						//Set the attributes
						//SAP ID
						if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
						if(BOM_line_ask_attribute_string(child_lines[ij], Uidlatest, &childSAPID));
						if(childSAPID==NULL)
						{
							if(BOM_line_set_attribute_string(child_lines[ij], Uidlatest,ChildUID));
						}
						else if(tc_strcmp(childSAPID,"")==0)
						{
							if(BOM_line_set_attribute_string(child_lines[ij], Uidlatest,ChildUID));
						}
						
						//Find Number
						if(BOM_line_set_attribute_string(child_lines[ij],findNoId,find_no));
						
					

						
						//Create Occ Effectivity
						CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childId,&child_item_id));
						CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childRevSeq,&child_item_rev_id));
						printf("\nSAN: creating occ effectivity of %s;%s\n",child_item_id,child_item_rev_id);fflush(stdout);
						Create_occurance_effectivity(archModuleRevTag,child_item_id,child_item_rev_id,arcPlatform,occ_effec);
						
						//Variant Formula
						if(BOM_line_set_attribute_string(child_lines[ij],vfFormId,sCustomORVF));
						printf("\nSetting VF for child [%s] as %s\n",child_partNum,sCustomORVF);fflush(stdout);
						
						if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
						if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"False"));
						
						t5AddStrToSet(childIdCnt, childIdList,ChildUID);
						
					}
					
				}
				
			
				
				
				
				
			}
			
			CALLAPI(BOM_save_window(window));
			CALLAPI(BOM_close_window(window));
			
			
			
			
			
		}		
		
	
	}		
	
	
	return ifail;
}



int updateVFofDestModule(tag_t archModuleRevTag, tag_t child_line)
{
	int ifail = ITK_ok;

	int childId = 0;
	int childRevSeq = 0;
	char* child_id = NULL;
	char* child_rev_seq = NULL;
	char child_partNum[100];
	
	//int effecId = 0;
	//char* effec_id = NULL;
	//char* occ_effec = NULL;
	//int occEffec = 0;
	int vfFormId = 0;
	char* variant_formula = NULL;
	//int findNoId = 0;
	//char* find_no = NULL;
	char *sCustomTotalVF= NULL;	
	if (sCustomTotalVF != NULL) { sCustomTotalVF=NULL; }
	sCustomTotalVF=malloc(9000 * sizeof(char));
	
	char *sCustomANDVF= NULL;
	char *sCustomORVF= NULL;

	
	CALLAPI(BOM_line_look_up_attribute("bl_item_item_id",&childId));
	CALLAPI(BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq));
	CALLAPI(BOM_line_ask_attribute_string(child_line,childId,&child_id));
	CALLAPI(BOM_line_ask_attribute_string(child_line,childRevSeq,&child_rev_seq));
	
	//printf("\nSAN:updateVF: child_id[%s] child_rev_seq[%s]",child_id,child_rev_seq);fflush(stdout);
	
	tc_strcpy(child_partNum,"");
	tc_strcat(child_partNum,child_id);
	tc_strcat(child_partNum,"_");
	tc_strcat(child_partNum,child_rev_seq);
	
	
	CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,vfFormId,&variant_formula));
	
	//printf("\nSAN:updateVF: variant_formula[%s]",variant_formula);fflush(stdout);
	
	tc_strcpy(sCustomTotalVF,"");
	tc_strcat(sCustomTotalVF,variant_formula);
	//printf("\nSAN:updateVF: VFSubStr1 =>%s\n ",sCustomTotalVF);fflush(stdout);
	
	ITK_CALL(STRNG_replace_str(sCustomTotalVF,"AND ([Teamcenter]","& ([Teamcenter]",&sCustomANDVF));
	//printf("\nSAN:updateVF: sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

	ITK_CALL(STRNG_replace_str(sCustomANDVF,"AND [Teamcenter]","& [Teamcenter]",&sCustomANDVF));
	//printf("\nSAN:updateVF: sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

	ITK_CALL(STRNG_replace_str(sCustomANDVF," OR "," | ",&sCustomORVF));
	//printf("\nSAN:updateVF: Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);
	
	//Sanjoy
	ITK_CALL(STRNG_replace_str(sCustomORVF,"'SEAT MOVEMENT ? DRIVER SEAT'","'SEAT MOVEMENT – DRIVER SEAT'",&sCustomORVF));
	ITK_CALL(STRNG_replace_str(sCustomORVF,"?","–",&sCustomORVF));	
	
	//ITK_CALL(STRNG_replace_str(sCustomORVF," ? ","-",&sCustomORVF));
	//printf("\nSAN:updateVF: 111...Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);
	//bl_item_object_type
	
	

	
	//Get Child Item Rev

	
	tag_t childModuleRevTag = NULLTAG;

	int objTypeId = 0;
	char* bl_object_Type = NULL;
	
	CALLAPI(BOM_line_look_up_attribute("bl_item_object_type",&objTypeId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,objTypeId,&bl_object_Type));
	
	//printf("\nSAN:updateVF: bl_object_Type==>%s\n",bl_object_Type);fflush(stdout);
	

	CALLAPI(getItemRevObj(child_id,child_rev_seq,&childModuleRevTag));
	
	
	
	
	

	if(childModuleRevTag == NULLTAG)
	{
		printf("\nSAN:updateVF: Child Module Rev[%s/%s] not found in PLM. Exiting the program....\n",child_id,child_rev_seq);fflush(stdout);
		return ifail;
	}

					


		char* arcPlatform = NULL;


		
		CALLAPI(AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform));
		//printf("\nSAN:updateVF:SAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
		
		//Get Child line of Dest Arch Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;
		tag_t* child_lines = NULLTAG;
		int nChld = 0;
		//void t5AddStrToSet(int *count,char ***strset,char* str)
		//int childIdCnt = 0;
		//char** childIdList = NULL:
		
		CALLAPI(BOM_create_window (&window));
		CALLAPI(CFM_find( "Latest Working", &rule ));
		CALLAPI(BOM_set_window_config_rule( window, rule ));
		CALLAPI(BOM_set_window_pack_all (window, false));
		CALLAPI(BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line));

		if(top_line != NULLTAG)
		{
			int ij = 0;
			int uidType = 0;
			char * ChildUID = NULL;
			int chldFound = 0;
			

			
			int fndidlatest = 0;
			char* vformulaDest = NULL;
			
			char* child_id1 = NULL;
			char* child_rev_seq1 = NULL;
			char child_partNum1[100];
			
			tag_t dest_Child_Line = NULLTAG;
			
			
			CALLAPI(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
			printf("\nSAN:updateVF:No of child objects of dest Arc Mod Rev are : %d",nChld);fflush(stdout);
			
			for(ij=0;ij<nChld;ij++)
			{
				
				CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childId,&child_id1));
				CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childRevSeq,&child_rev_seq1));
				
				//printf("\nSAN:updateVF: child_id1[%s] child_rev_seq1[%s]",child_id1,child_rev_seq1);fflush(stdout);
				
				tc_strcpy(child_partNum1,"");
				tc_strcat(child_partNum1,child_id1);
				tc_strcat(child_partNum1,"_");
				tc_strcat(child_partNum1,child_rev_seq1);
				
				//printf("\nSAN:updateVF: child_partNum1[%s]",child_partNum1);fflush(stdout);				
				 
				if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(BOM_line_ask_attribute_string(child_lines[ij], uidType, &ChildUID));
				//printf("\nSAN:updateVF: [%d] ChildUID ======>>> %s \n",ij +1, ChildUID);fflush(stdout);
				
				if(BOM_line_ask_attribute_string(child_lines[ij], vfFormId, &vformulaDest));
				//printf("\nSAN:updateVF: [%d] vformulaDest ======>>> %s \n",ij +1, vformulaDest);fflush(stdout);
				
				//t5FindStrInSet(*childIdList,*childIdCnt,ChildUID,&chldFound);
				//printf("\nSAN:updateVF:Child found in the set==>%d\n",chldFound);fflush(stdout);
				
				if(tc_strcmp(child_partNum, child_partNum1)==0)
				{
					
					
					
					if(vformulaDest!=NULL)
					{
						if(tc_strcmp(vformulaDest,"")== 0)
						{
						
							dest_Child_Line = child_lines[ij];
							break;
							
						}						
					}
					else
					{
						dest_Child_Line = child_lines[ij];
						break;						
						
					}					
					


							
				}

			}
			/*if(tc_strcmp(child_partNum1,"5442B4Z0160004_NR;1")==0)
			{
				ITK_CALL(STRNG_replace_str(sCustomORVF," & [Teamcenter]'ARMREST TYPE FOR 2ND ROW SEAT' = 'ARMREST WITH CUP HOLDER'","",&sCustomORVF));
				printf("\nSAN:updateVF: 111...Final Variant Formula 5442B4Z0160004_NR;1 is-------> %s\n",sCustomORVF);fflush(stdout);				
			}*/
			if(dest_Child_Line != NULLTAG)
			{
				//printf("\nSAN:updateVF: Dest Child line have blank VF.. need to update ......\n");
				if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
				if(BOM_line_set_attribute_string(dest_Child_Line, fndidlatest,"True"));
				
				if(BOM_line_set_attribute_string(dest_Child_Line,vfFormId,sCustomORVF));
				printf("\nSAN:updateVF:Setting VF for dest child [%s] as %s\n",child_partNum,sCustomORVF);fflush(stdout);
				
				//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
				if(BOM_line_set_attribute_string(dest_Child_Line, fndidlatest,"False"));				
				
			}
			
			
			
			
		}
		
		CALLAPI(BOM_save_window(window));
		CALLAPI(BOM_close_window(window));
		

	

		
	
			
	
	
	return ifail;
}



int addModuleAndUpdateVF(tag_t archModuleRevTag, int childLineCnt, tag_t* childLineList)
{
	int ifail = ITK_ok;
	char* arcPlatform = NULL;
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	int bv_count = 0;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t bv = NULLTAG;
	tag_t bvr = NULLTAG;	

	

	
	
	printf("\nSAN:Inside addModuleAndUpdateVF.......\n");fflush(stdout);
	
	//printf("\nSAN:childLineCnt ====> %d",childLineCnt);fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform));
	printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);

	CALLAPI(ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag));

	CALLAPI(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));

	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		ifail = PS_create_bom_view(NULLTAG,"","",archModuleItemTag,&bv);
		ifail = AOM_save( bv );
		ifail = AOM_save( archModuleItemTag );
		ifail = AOM_unlock( archModuleItemTag );
		if(bv != NULLTAG) 
		{
			printf("\nCreatd BOM View ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View ...\n");fflush(stdout);
		}
	}	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);
	
	if(bvr_count)
	{

		bvr = bvrs[0];
		MEM_free(bvrs);
	}
	else
	{
		ifail = PS_create_bvr( bv, "", "", false, archModuleRevTag, &bvr );
		
		ifail = AOM_save( bvr );
		ifail = AOM_save( archModuleRevTag );
		ifail = AOM_unlock( archModuleRevTag );
		if(bvr != NULLTAG) 
		{
			printf("\nCreatd BOM View Revision ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View Revision...\n");fflush(stdout);
		}
	}

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}
	
	if(bvr != NULLTAG)
	{
		//Get Child line of Dest Arch Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;


		
		CALLAPI(BOM_create_window (&window));
		CALLAPI(CFM_find( "Latest Working", &rule ));
		CALLAPI(BOM_set_window_config_rule( window, rule ));
		CALLAPI(BOM_set_window_pack_all (window, false));
		CALLAPI(BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line));
		
		if(top_line != NULLTAG)
		{
			int i=0;


			
			for(i=0; i< childLineCnt ; i++)
			{
				
				int childId = 0;
				int childRevSeq = 0;
				tag_t src_child_line = NULLTAG;
				char* child_id = NULL;
				char* child_rev_seq = NULL;
				tag_t childModuleRevTag = NULLTAG;
				//tag_t childModuleItem = NULLTAG;
				tag_t child_line = NULLTAG;				
				int vfFormId = 0;
				char*variant_formula = NULL;
				char *sCustomTotalVF= NULL;	
				if (sCustomTotalVF != NULL) { sCustomTotalVF=NULL; }
				sCustomTotalVF=malloc(9000 * sizeof(char));
				
				char *sCustomANDVF= NULL;
				char *sCustomORVF= NULL;
				int uidType = 0;
				char* ChildUID = NULL;
				
				int Uidlatest = 0;
				char* childSAPID = NULL;
				
				int findNoId = 0;
				char* find_no = NULL;
				
				int occEffec = 0;
				char* occ_effec = NULL;
				int fndidlatest = 0;
				
				
				src_child_line = childLineList[i];

				CALLAPI(BOM_line_look_up_attribute("bl_item_item_id",&childId));
				CALLAPI(BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq));
				CALLAPI(BOM_line_ask_attribute_string(src_child_line,childId,&child_id));
				CALLAPI(BOM_line_ask_attribute_string(src_child_line,childRevSeq,&child_rev_seq));

				//printf("\n child_id[%s] child_rev_seq[%s]",child_id,child_rev_seq);fflush(stdout);
				
				//Get the child item rev tag
				CALLAPI(getItemRevObj(child_id,child_rev_seq,&childModuleRevTag));
				
		
				if(childModuleRevTag == NULLTAG)
				{
					printf("\n Child Module Rev[%s/%s] not found in PLM. Ignoring this part....\n",child_id,child_rev_seq);fflush(stdout);
					continue;
				}
				
				//CALLAPI(ITEM_ask_item_of_rev(childModuleRevTag, &childModuleItem));
				
				//Add line item to Dest Arch Node
				CALLAPI(BOM_line_add(top_line, NULLTAG, childModuleRevTag, NULLTAG, &child_line));
				
				if(child_line == NULLTAG)
				{
					printf("\nSAN:Exception...Error!!!! not added child part [%s;%s]\n",child_id,child_rev_seq);fflush(stdout);
					continue;
				}
				
				//Set SAP ID
				if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(BOM_line_ask_attribute_string(child_line, uidType, &ChildUID));
				//printf("\n [%d] ChildUID ======>>> %s \n",i +1, ChildUID);fflush(stdout);

				if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
				if(BOM_line_ask_attribute_string(child_line, Uidlatest, &childSAPID));
				if(childSAPID==NULL)
				{
					if(BOM_line_set_attribute_string(child_line, Uidlatest,ChildUID));
				}
				else if(tc_strcmp(childSAPID,"")==0)
				{
					if(BOM_line_set_attribute_string(child_line, Uidlatest,ChildUID));
				}


				//Find Number
				CALLAPI(BOM_line_look_up_attribute("bl_sequence_no",&findNoId));
				CALLAPI(BOM_line_ask_attribute_string(src_child_line,findNoId,&find_no));
				//printf("\n Setting Find no [%s] ....\n",find_no);fflush(stdout);
				if(BOM_line_set_attribute_string(child_line,findNoId,find_no));
				
				
				
				//Variant formula string manipulation..
				
				CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));
				CALLAPI(BOM_line_ask_attribute_string(src_child_line,vfFormId,&variant_formula));

				//printf("\n variant_formula[%s]",variant_formula);fflush(stdout);				

				tc_strcpy(sCustomTotalVF,"");
				tc_strcat(sCustomTotalVF,variant_formula);
				//printf("\n VFSubStr1 =>%s\n ",sCustomTotalVF);fflush(stdout);

				ITK_CALL(STRNG_replace_str(sCustomTotalVF,"AND ([Teamcenter]","& ([Teamcenter]",&sCustomANDVF));
				//printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

				ITK_CALL(STRNG_replace_str(sCustomANDVF,"AND [Teamcenter]","& [Teamcenter]",&sCustomANDVF));
				//printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

				ITK_CALL(STRNG_replace_str(sCustomANDVF," OR "," | ",&sCustomORVF));
				//printf("\n Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);
				
				//change_sanjoy1
				//ITK_CALL(STRNG_replace_str(sCustomORVF,"'SEAT MOVEMENT ? DRIVER SEAT'","'SEAT MOVEMENT - DRIVER SEAT'",&sCustomORVF));
				ITK_CALL(STRNG_replace_str(sCustomORVF,"'SEAT MOVEMENT ? DRIVER SEAT'","'SEAT MOVEMENT – DRIVER SEAT'",&sCustomORVF));
				ITK_CALL(STRNG_replace_str(sCustomORVF,"?","–",&sCustomORVF));

				printf("\nSAN:1111...Setting VF for child [%s;%s] as %s\n",child_id,child_rev_seq,sCustomORVF);fflush(stdout);
				if(BOM_line_set_attribute_string(child_line,vfFormId,sCustomORVF));
				

				if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
				if(BOM_line_set_attribute_string(child_line, fndidlatest,"True"));					
				
				//Create Occurence effectivity
				CALLAPI(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
				CALLAPI(BOM_line_ask_attribute_string(src_child_line,occEffec,&occ_effec));

				//printf("\n Effectivity[%s]",occ_effec);fflush(stdout);				
				
				Create_occurance_effectivity(archModuleRevTag,child_id,child_rev_seq,arcPlatform,occ_effec);
				
				
		
				
			}
		}
		
		CALLAPI(BOM_save_window(window));
		CALLAPI(BOM_close_window(window));		
	}
	
	//Update VF formula if missed.
	
	int ii =0;
	for(ii=0; ii< childLineCnt ; ii++)
	{
		CALLAPI(updateVFofDestModule(archModuleRevTag,childLineList[ii]));
	}
		
	
	
	
	return ifail;
}


typedef struct ArchNodeDet_
{
	char archNodeID[50];
	char** moduleIDList;
	char** moduleAddList;
	int moduleCnt;
	char** vformulaStrList;
	int vformulaStrCnt;
}ArchNodeDet;

void setAddArchNodeDet(int *count,ArchNodeDet **objlist,ArchNodeDet obj )
{

	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (ArchNodeDet *)malloc((*count ) * sizeof(ArchNodeDet ));
	}
	else
	{
		(*objlist) = (ArchNodeDet *)realloc((*objlist),(*count) * sizeof(ArchNodeDet ));
	}

	(*objlist)[*count-1] = obj;
}

void t5FindArchNodeInArchNodeSet(ArchNodeDet *archnode_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(archnode_list[k].archNodeID,str)==0)
		{
			*found=1;
			break;
		}

	}
}


int Create_occurance_effectivity_generic(tag_t primaryObj, char* objectId, char* objectrevId, char* arcPlatform)
{
	int		ifail			= ITK_ok;
	int		iy				= 0;
	int		iz				= 0;
	int		bvr_count		= 0;
	int		n_occs			= 0;
	int		Item_count		= 0;
	int		effcnt			= 0;	

	tag_t	*bvrs;
	tag_t   *occsal;
	tag_t	ChildItem		= NULLTAG;
	tag_t	*rev_list		= NULLTAG;
	tag_t	bvr				= NULLTAG;
	tag_t	bvrchild		= NULLTAG;
	tag_t	*Effobbj		= NULLTAG;
	tag_t	EffecTag		= NULLTAG;

	char	*dataset_name1	= NULL;
	char	*t5Des_Rev		= NULL;

	date_t	date_end		= NULLDATE;
	
	date_t dcreation_date;
	char* ccreation_date	= NULL;
	char* end_date			= NULL;
	ccreation_date = malloc(30 * sizeof (char *) );
	end_date = malloc(30 * sizeof (char *) );

	char* Effecsta			 = NULL;
	char* EffecEnd			 = NULL;

	char EffecRange[200];
	char EffecName[200];
	
	int i_ChildCount		 = 0;
	int iChldPrts			 = 0;
	int uidType				 = 0;
	int Uidlatest            = 0;
	tag_t  t_BomLineWindow	 = NULLTAG;
	tag_t  t_Rule			 = NULLTAG;
	tag_t  t_TopLine		 = NULLTAG;
	tag_t  *t_PartChildren	 = NULLTAG;
	tag_t  t_Childobject	 = NULLTAG;
	char   *Child_SeqId		 = NULL;
	char   *ChildUID		 = NULL;
	char   *child_Uid   	 = NULL;
	
	date_t start_date;
	char * startDate;
	startDate = malloc(30 * sizeof (char *) );

	ifail = ITK_string_to_date("31-Dec-2099 00:00", &date_end);
	
	//Get current date
	char cCurrentAccessDate[20]={0};
	char cPrevAccessDate[20]={0};
	
	t5GetCurrentDateTime(cCurrentAccessDate);
	

	printf("\n Eff:Current date  is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
	
	t5GetPrevDate(cPrevAccessDate);
	
	printf("\n Eff:Yesterday date  is..:[%s]\n",cPrevAccessDate);fflush(stdout);
	
	//if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &start_date )))
	if(ITK_ok != (ifail = ITK_string_to_date(cPrevAccessDate, &start_date )))
	{
		return ifail;
	}	

	ifail = ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs);
	printf("\nXXX: CM_MR_SetOccEff bvr count is...%d",bvr_count);fflush(stdout);
	if (bvr_count)
	{

		int occCnt = 0;
		tag_t* occList = NULLTAG;
		int occNtFndCnt = 0;
		tag_t* occNtFndList = NULLTAG;		
		int effIdCnt = 0;
		char** effIdLst = NULL;
		int effIdCnt1 = 0;
		char** effIdLst1 = NULL;
		int effIdCnt2 = 0;
		char** effIdLst2 = NULL;
		bvr = bvrs[0];
		ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
		printf("\n CM_MR_SetOccEff n_occs count is...%d",n_occs);fflush(stdout);
		for (iy = 0; iy<n_occs; iy++)
		{
			ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

			if (ChildItem)
			{
				ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

				
				ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);

				if(Item_count > 0)
				{
					for (iz = 0; iz<Item_count; iz++)
					{
						ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
						//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
						
						if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
						{
							t5AddTagObjToSet(&occCnt,&occList,occsal[iy]);
						}
						

					}
				}
			}
		}
		
		printf("\nOccurance Count==============>%d\n",occCnt);fflush(stdout);
		
		if(occCnt==1)
		{
			for (iy = 0; iy<n_occs; iy++)
			{
				ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);

					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							

							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
							  tc_strcpy(EffecName,"");
							  tc_strcat(EffecName,dataset_name1);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,t5Des_Rev);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,arcPlatform);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,"1");

							 // printf("\n CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);

							  ifail = AOM_ask_value_date(rev_list[iz],"creation_date",&dcreation_date);
							  ITK_date_to_string(dcreation_date, &ccreation_date);
							  ITK_date_to_string(date_end, &end_date);
							  //printf("\n\t CM_MR_SetOccEff creation_date is  >>>>>>>>>> [ %s ]",ccreation_date); fflush(stdout);
							  //printf("\n\t CM_MR_SetOccEff end_date is  >>>>>>>>>> [ %s ]",end_date); fflush(stdout);
							  
								ITK_date_to_string(start_date, &startDate);

								//Effecsta=subString(ccreation_date,0,11);
								//Effecsta=subString(startDate,0,11);
								Effecsta = startDate;
								EffecEnd=subString(end_date,0,11);

								tc_strcpy(EffecRange,"");

								tc_strcat(EffecRange,Effecsta);
								tc_strcat(EffecRange," to ");
								tc_strcat(EffecRange,EffecEnd);

								//printf("\n CM_MR_SetOccEff Date range is = [ %s ]",EffecRange);fflush(stdout);

								ifail =  AOM_lock( bvr );

								ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

								//printf("\n CM_MR_SetOccEff effcnt count is...%d",effcnt);fflush(stdout);
								
								
								
								if (effcnt == 0)
								{
									ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

									if (EffecTag)
									{
										//printf("\n CM_MR_SetOccEff setting effe 2...%d",effcnt);fflush(stdout);

										ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

										ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,EffecRange,FALSE);

										ifail = AOM_save(EffecTag);
										ifail = AOM_refresh(EffecTag, 0);

										//ifail = AOM_refresh(bvr, 1);
										ifail = AOM_save(bvr);
										ifail = AOM_unlock( bvr );

									}
								}
							}
						}
					}
				}
			}
						
		}
		
		
		
		//for multi occurance case
		if(occCnt>1)
		{
			
			int k=0;
			for(k=0;k<occCnt;k++)
			{
				tag_t occTag = NULLTAG;
				occTag = occList[k];
				ifail = PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild );
				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
								
								// int effcnt = 0;
								// tag_t Effobbj = NULLTAG;
					
								char str1[20];
								sprintf(str1, "%d", k+1);
								tc_strcpy(EffecName,"");
								tc_strcat(EffecName,dataset_name1);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,t5Des_Rev);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,arcPlatform);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,str1);								  

								//printf("\nSAN: adding to the set..EffecName... [ %s ]\n",EffecName);fflush(stdout);
								t5AddStrToSet(&effIdCnt, &effIdLst,EffecName);
								

								
								ifail = PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj);
								
								if(effcnt ==0)
								{
									//printf("\nSAN: adding to the set. not found .EffecName... [ %s ]\n",EffecName);fflush(stdout);
									t5AddStrToSet(&effIdCnt1, &effIdLst1,EffecName);
									t5AddTagObjToSet(&occNtFndCnt,&occNtFndList,occTag);
								}
								
								if(effcnt>0)
								{
									char* effId = NULL;
									tag_t effObj = NULLTAG;
									int flag =0;
									effObj= Effobbj[0];
									ifail = PS_occ_eff_ask_id(bvr,occTag,effObj, &effId);
									//printf("\nSAN111111: effId==> %s\n",effId);fflush(stdout);
									
									if(effId==NULL )
									{
										flag++;
									}
									else if(tc_strcmp(effId,"")==0)
									{
										flag++;
									}
									//printf("\nSAN2222: flag==> %d\n",flag);fflush(stdout);
									
									if(flag==0)									
									{
										//printf("\nSAN: adding to the set effIdLst2 ..effId... [ %s ]\n",effId);fflush(stdout);
										t5AddStrToSet(&effIdCnt2, &effIdLst2,effId);
									}
									if(flag>=1)
									{
										//printf("\nSAN: Removed effectivity\n",effId);fflush(stdout);
										ifail= PS_occ_eff_remove_eff(bvr,occTag,effObj);
									}
								}

								
								
							}
						}
					}
							
				}
				
								
				
			}

		}
		
		//printf("\nSAN: ====> effIdCnt==> %d\n",effIdCnt);fflush(stdout);
		//printf("\nSAN: ====> effIdCnt1==> %d\n",effIdCnt1);fflush(stdout);
		//printf("\nSAN: ====> effIdCnt2==> %d\n",effIdCnt2);fflush(stdout);
		//printf("\nSAN: ====> occNtFndCnt==> %d\n",occNtFndCnt);fflush(stdout);
		//for multi occurance case
		
		if(occNtFndCnt>0)
		{
			int jk=0;
			for(jk=0;jk<occNtFndCnt;jk++)
			{
				tag_t occTag = NULLTAG;
				occTag = occNtFndList[jk];
				ifail = PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild );
				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n XXX: CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\tXXXX: CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
								
								int ij=0;
								for(ij=0;ij<occCnt;ij++)
								{
									int found =0;
									char str1[20];
									sprintf(str1, "%d", ij+1);
									tc_strcpy(EffecName,"");
									tc_strcat(EffecName,dataset_name1);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,t5Des_Rev);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,arcPlatform);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,str1);								
								  

									//printf("\n XXXX: yyyyyy CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);
									
									t5FindStrInSet(effIdLst2,effIdCnt2,EffecName,&found);
									//printf("\nFound==>%d\n",found);fflush(stdout);
									
									if(found==0)
									{
										ifail = AOM_ask_value_date(rev_list[iz],"creation_date",&dcreation_date);
										ITK_date_to_string(dcreation_date, &ccreation_date);
										ITK_date_to_string(date_end, &end_date);
										//printf("\n\t XXX:CM_MR_SetOccEff creation_date is  >>>>>>>>>> [ %s ]",ccreation_date); fflush(stdout);
										//printf("\n\t XXX: CM_MR_SetOccEff end_date is  >>>>>>>>>> [ %s ]",end_date); fflush(stdout);
										
										ITK_date_to_string(start_date, &startDate);

										//Effecsta=subString(ccreation_date,0,11);
										//Effecsta=subString(startDate,0,11);
										Effecsta = startDate;
										EffecEnd=subString(end_date,0,11);

										tc_strcpy(EffecRange,"");

										tc_strcat(EffecRange,Effecsta);
										tc_strcat(EffecRange," to ");
										tc_strcat(EffecRange,EffecEnd);

										//printf("\n XXX:CM_MR_SetOccEff Date range is = [ %s ]",EffecRange);fflush(stdout);

										ifail =  AOM_lock( bvr );

										ifail = PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj);

										//printf("\n CM_MR_SetOccEff effcnt count is...%d",effcnt);fflush(stdout);
										

										
										if (effcnt == 0)
										{
										
											ifail = PS_occ_eff_create(bvr,occTag,&EffecTag);

											if (EffecTag)
											{
												//printf("\n CM_MR_SetOccEff setting effe 2...%d",effcnt);fflush(stdout);

												ifail = PS_occ_eff_set_id(bvr,occTag,EffecTag,EffecName);

												ifail = PS_occ_eff_set_date_range(bvr,occTag,EffecTag,EffecRange,FALSE);

												ifail = AOM_save(EffecTag);
												ifail = AOM_refresh(EffecTag, 0);
												ifail = AOM_save(bvr);
												ifail = AOM_unlock( bvr );

											}
											t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName);
										}
										
										break;
										
									}
									
								}
							}
						}
					}						
				}					
			}
		}
				
	}

	return ifail;
}


int relateModuleToArchNode1(tag_t archModuleRevTag, int childLineCnt, tag_t* childLineList)
{
	int ifail = ITK_ok;
	char* arcPlatform = NULL;
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	int bv_count = 0;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t bv = NULLTAG;
	tag_t bvr = NULLTAG;	

	

	
	
	printf("\nSAN:Inside addModuleAndUpdateVF.......\n");fflush(stdout);
	
	//printf("\nSAN:childLineCnt ====> %d",childLineCnt);fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform));
	printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);

	CALLAPI(ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag));

	CALLAPI(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));

	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		ifail = PS_create_bom_view(NULLTAG,"","",archModuleItemTag,&bv);
		ifail = AOM_save( bv );
		ifail = AOM_save( archModuleItemTag );
		ifail = AOM_unlock( archModuleItemTag );
		if(bv != NULLTAG) 
		{
			printf("\nCreatd BOM View ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View ...\n");fflush(stdout);
		}
	}	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);
	
	if(bvr_count)
	{

		bvr = bvrs[0];
		MEM_free(bvrs);
	}
	else
	{
		ifail = PS_create_bvr( bv, "", "", false, archModuleRevTag, &bvr );
		
		ifail = AOM_save( bvr );
		ifail = AOM_save( archModuleRevTag );
		ifail = AOM_unlock( archModuleRevTag );
		if(bvr != NULLTAG) 
		{
			printf("\nCreatd BOM View Revision ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View Revision...\n");fflush(stdout);
		}
	}

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}
	
	if(bvr != NULLTAG)
	{
		//Get Child line of Dest Arch Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;


		
		CALLAPI(BOM_create_window (&window));
		CALLAPI(CFM_find( "Latest Working", &rule ));
		CALLAPI(BOM_set_window_config_rule( window, rule ));
		CALLAPI(BOM_set_window_pack_all (window, false));
		CALLAPI(BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line));
		
		if(top_line != NULLTAG)
		{
			int i=0;


			
			for(i=0; i< childLineCnt ; i++)
			{
				
				int childId = 0;
				int childRevSeq = 0;
				char* child_id = NULL;
				char* child_rev_seq = NULL;
				tag_t childModuleRevTag = NULLTAG;
				//tag_t childModuleItem = NULLTAG;
				tag_t child_line = NULLTAG;				


				int uidType = 0;
				char* ChildUID = NULL;
				
				int Uidlatest = 0;
				char* childSAPID = NULL;
				
				int findNoId = 0;
				char* find_no = NULL;
				
				int occEffec = 0;
				char* occ_effec = NULL;
				int fndidlatest = 0;
				
				
				childModuleRevTag = childLineList[i];


				//CALLAPI(ITEM_ask_item_of_rev(childModuleRevTag, &childModuleItem));
				
				//Add line item to Dest Arch Node
				CALLAPI(BOM_line_add(top_line, NULLTAG, childModuleRevTag, NULLTAG, &child_line));
				
				ifail = BOM_line_look_up_attribute("bl_item_item_id",&childId);
				ifail = BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq);
				ifail = BOM_line_ask_attribute_string(child_line,childId,&child_id);
				ifail = BOM_line_ask_attribute_string(child_line,childRevSeq,&child_rev_seq);
				
				if(child_line == NULLTAG)
				{
					printf("\nSAN:Exception...Error!!!! not added child part [%s;%s]\n",child_id,child_rev_seq);fflush(stdout);
					continue;
				}
				else
				{
					printf("\nSAN:Added child part [%s;%s]\n",child_id,child_rev_seq);fflush(stdout);
				}


				
				//Set SAP ID
				if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(BOM_line_ask_attribute_string(child_line, uidType, &ChildUID));
				//printf("\n [%d] ChildUID ======>>> %s \n",i +1, ChildUID);fflush(stdout);

				if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
				if(BOM_line_ask_attribute_string(child_line, Uidlatest, &childSAPID));
				if(childSAPID==NULL)
				{
					if(BOM_line_set_attribute_string(child_line, Uidlatest,ChildUID));
				}
				else if(tc_strcmp(childSAPID,"")==0)
				{
					if(BOM_line_set_attribute_string(child_line, Uidlatest,ChildUID));
				}




				
				
				//Create Occurence effectivity
				CALLAPI(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
				CALLAPI(BOM_line_ask_attribute_string(child_line,occEffec,&occ_effec));

				//printf("\n Effectivity[%s]",occ_effec);fflush(stdout);	
				
				ifail = Create_occurance_effectivity_generic(archModuleRevTag, child_id, child_rev_seq,arcPlatform);
				//Create_occurance_effectivity(archModuleRevTag,child_id,child_rev_seq,arcPlatform,occ_effec);
				
				
		
				
			}
		}
		
		CALLAPI(BOM_save_window(window));
		CALLAPI(BOM_close_window(window));		
	}
	
	//Update VF formula if missed.
	
	int ii =0;
	for(ii=0; ii< childLineCnt ; ii++)
	{
		CALLAPI(updateVFofDestModule(archModuleRevTag,childLineList[ii]));
	}
		
	
	
	
	return ifail;
}



int relateModuleToArchNode_old(tag_t archModuleRevTag, int childLineCnt, tag_t* childLineList)
{
	int ifail = ITK_ok;
	
	printf("\n To do - to be implemented....\n");fflush(stdout);
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	tag_t bv = NULLTAG;
	int bv_count = 0;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t bvr = NULLTAG;
	
	ifail = ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag);
	
	ifail = ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs );
	
	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		ifail = PS_create_bom_view(NULLTAG,"","",archModuleItemTag,&bv);
		ifail = AOM_save( bv );
		ifail = AOM_save( archModuleItemTag );
		ifail = AOM_unlock( archModuleItemTag );
		if(bv != NULLTAG) 
		{
			printf("\nCreatd BOM View ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View ...\n");fflush(stdout);
		}		
	}
	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);
	
	if(bvr_count)
	{	
		bvr = bvrs[0];
		MEM_free(bvrs);		
	}
	else
	{
		ifail = PS_create_bvr( bv, "", "", false, archModuleRevTag, &bvr );
		
		ifail = AOM_save( bvr );
		ifail = AOM_save( archModuleRevTag );
		ifail = AOM_unlock( archModuleRevTag );
		if(bvr != NULLTAG) 
		{
			printf("\nCreatd BOM View Revision ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View Revision...\n");fflush(stdout);
		}
	}
	
	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}
	
	if(bvr != NULLTAG)
	{
		int i=0;
		tag_t* occTags = NULLTAG;		
		tag_t occTag = NULLTAG;
		char* seq_no  = NULL;		
		
		for(i=0;i<childLineCnt;i++)
		{
			ifail = PS_create_occurrences( bvr, childLineList[i], NULLTAG,1, &occTags );
		
			if(occTags[0] != NULLTAG)
			{
				printf("\nOccurrence created....\n");fflush(stdout);
				occTag = occTags[0];

				ifail = USER_ask_new_default_sequence_number(bvr, childLineList[i],&seq_no);
				ifail = PS_set_seq_no(bvr,occTag,seq_no);
			}			
			
		}
	
		ifail = AOM_save(bvr);
		ifail = AOM_refresh(bvr,1);
		ifail = AOM_unlock( bvr );
		
		//Create Occurence Effectivity,find no, VF etc...
		
		char* arcPlatform = NULL;
		
		ifail = AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform);
		printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
		
		//Get Child line of Architecture Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;
		tag_t* child_lines = NULLTAG;
		int nChld = 0;
		
		ifail = BOM_create_window (&window);
		ifail = CFM_find( "Latest Working", &rule );
		ifail = BOM_set_window_config_rule( window, rule );
		ifail = BOM_set_window_pack_all (window, false);
		ifail = BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line);
		
		if(top_line != NULLTAG)
		{
			int j =0;
			int childId = 0;
			int childRevSeq = 0;
			char* child_id = 0;
			char* child_rev_seq = 0;
			int occuid = 0;
			char* ChildUID = NULL;
			int uidsap = 0;
			char* ChildSAPUID = NULL;
			
			ifail = BOM_line_ask_child_lines (top_line, &nChld, &child_lines);
			printf("\nNo of child objects of Arch Module Rev are : %d",nChld);fflush(stdout);
			
			ifail = BOM_line_look_up_attribute("bl_item_item_id",&childId);
		    ifail = BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq);
			ifail = BOM_line_look_up_attribute ("bl_occurrence_uid",&occuid);
			ifail = BOM_line_look_up_attribute("bl_occ_t5_uidsap",&uidsap);
			
			for(j=0;j<nChld;j++)
			{
				
				ifail = BOM_line_ask_attribute_string(child_lines[j],childId,&child_id);
				ifail = BOM_line_ask_attribute_string(child_lines[j],childRevSeq,&child_rev_seq);
				ifail = BOM_line_ask_attribute_string(child_lines[j], occuid, &ChildUID);
				ifail = BOM_line_ask_attribute_string(child_lines[j], uidsap, &ChildSAPUID);
				
				//Set SAP_UID
				if(ChildSAPUID==NULL)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}
				else if(tc_strcmp(ChildSAPUID,"")==0)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}				

				//Create Occurence Effectivity
				ifail = Create_occurance_effectivity_generic(archModuleRevTag, child_id, child_rev_seq,arcPlatform);
				
									
				
			}
			
			
			
						
		}
		
		ifail = BOM_close_window(window);
		
	}
	
	
	
	return ifail;
}



int relateModuleToArchNode(tag_t archModuleRevTag, int childLineCnt, tag_t* childLineList)
{
	int ifail = ITK_ok;
	
	printf("\n To do - to be implemented....\n");fflush(stdout);
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	tag_t bv = NULLTAG;
	int bv_count = 0;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t bvr = NULLTAG;
	
	ifail = ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag);
	
	ifail = ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs );
	
	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		ifail = PS_create_bom_view(NULLTAG,"","",archModuleItemTag,&bv);
		ifail = AOM_save( bv );
		ifail = AOM_save( archModuleItemTag );
		ifail = AOM_unlock( archModuleItemTag );
		if(bv != NULLTAG) 
		{
			printf("\nCreatd BOM View ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View ...\n");fflush(stdout);
		}		
	}
	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);
	
	if(bvr_count)
	{	
		bvr = bvrs[0];
		MEM_free(bvrs);		
	}
	else
	{
		ifail = PS_create_bvr( bv, "", "", false, archModuleRevTag, &bvr );
		
		ifail = AOM_save( bvr );
		ifail = AOM_save( archModuleRevTag );
		ifail = AOM_unlock( archModuleRevTag );
		if(bvr != NULLTAG) 
		{
			printf("\nCreatd BOM View Revision ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View Revision...\n");fflush(stdout);
		}
	}
	
	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}
	
	if(bvr != NULLTAG)
	{
		
		/*************Check if the part already exist in the structure***********************/
		
		/**************End if the part already in structure ********************/
		
		
		int i=0;
		tag_t* occTags = NULLTAG;		
		tag_t occTag = NULLTAG;
		char* seq_no  = NULL;		
		
		for(i=0;i<childLineCnt;i++)
		{
			ifail = PS_create_occurrences( bvr, childLineList[i], NULLTAG,1, &occTags );
		
			if(occTags[0] != NULLTAG)
			{
				printf("\nOccurrence created....\n");fflush(stdout);
				occTag = occTags[0];

				ifail = USER_ask_new_default_sequence_number(bvr, childLineList[i],&seq_no);
				ifail = PS_set_seq_no(bvr,occTag,seq_no);
			}			
			
		}
	
		ifail = AOM_save(bvr);
		ifail = AOM_refresh(bvr,1);
		ifail = AOM_unlock( bvr );
		
		//Create Occurence Effectivity,find no, VF etc...
		
		char* arcPlatform = NULL;
		
		ifail = AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform);
		printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
		
		//Get Child line of Architecture Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;
		tag_t* child_lines = NULLTAG;
		int nChld = 0;
		
		ifail = BOM_create_window (&window);
		ifail = CFM_find( "Latest Working", &rule );
		ifail = BOM_set_window_config_rule( window, rule );
		ifail = BOM_set_window_pack_all (window, false);
		ifail = BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line);
		
		if(top_line != NULLTAG)
		{
			int j =0;
			int childId = 0;
			int childRevSeq = 0;
			char* child_id = 0;
			char* child_rev_seq = 0;
			int occuid = 0;
			char* ChildUID = NULL;
			int uidsap = 0;
			char* ChildSAPUID = NULL;
			
			ifail = BOM_line_ask_child_lines (top_line, &nChld, &child_lines);
			printf("\nNo of child objects of Arch Module Rev are : %d",nChld);fflush(stdout);
			
			ifail = BOM_line_look_up_attribute("bl_item_item_id",&childId);
		    ifail = BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq);
			ifail = BOM_line_look_up_attribute ("bl_occurrence_uid",&occuid);
			ifail = BOM_line_look_up_attribute("bl_occ_t5_uidsap",&uidsap);
			
			for(j=0;j<nChld;j++)
			{
				
				ifail = BOM_line_ask_attribute_string(child_lines[j],childId,&child_id);
				ifail = BOM_line_ask_attribute_string(child_lines[j],childRevSeq,&child_rev_seq);
				ifail = BOM_line_ask_attribute_string(child_lines[j], occuid, &ChildUID);
				ifail = BOM_line_ask_attribute_string(child_lines[j], uidsap, &ChildSAPUID);
				
				//Set SAP_UID
				if(ChildSAPUID==NULL)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}
				else if(tc_strcmp(ChildSAPUID,"")==0)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}				

				//Create Occurence Effectivity
				ifail = Create_occurance_effectivity_generic(archModuleRevTag, child_id, child_rev_seq,arcPlatform);
				
									
				
			}
			
			
			
						
		}
		
		ifail = BOM_close_window(window);
		
	}
	
	
	
	return ifail;
}

int getScaledValue(char *inpStr, char **outStr)
{
	int ifail = ITK_ok;
	
	char* tMatrixStr = (char*)MEM_alloc(100*sizeof(char));
	char* tMatrixStrDup = NULL;//(char*)MEM_alloc(100*sizeof(char));
	
	char* tmat1 = (char*)MEM_alloc(50*sizeof(char));
	*outStr = (char*)MEM_alloc(300*sizeof(char));
	char* tok1 = NULL;
	char* tok2 = NULL;
	int len1 = 0;
	
	tc_strcpy(tMatrixStr,inpStr);
	
	//printf("\n tMatrixStr:[%s]\n",tMatrixStr);fflush(stdout);
	
	tc_strdup(tMatrixStr, &tMatrixStrDup);
	
	
	len1 = tc_strlen(tMatrixStr);
	//printf("\n Length of the input T Matrix value : [%d]\n", len1);fflush(stdout);
	
	/*If first character is .*/
	int flag1 = 0;
	char ch = '\0';
	ch = tMatrixStr[0];
	
	if(ch == '.')
	{
		flag1++;
	}
	
	/* Get the tokens */
	tok1 = tc_strtok(tMatrixStr,".");
	tok2 = tc_strtok(NULL,".");
	//printf("\n tok1[%s], tok2[%s]\n",tok1,tok2);fflush(stdout);
	
	

	//printf("\n flag1 ==> %d\n", flag1);fflush(stdout);
	if(flag1 > 0)
	{
		tc_strcpy(tmat1,"0.000");
		tc_strcpy(*outStr,tmat1);
		tc_strcat(*outStr,tok2);
		
		//printf("\n outStr : [%s]\n",*outStr);fflush(stdout);
		
		if(tMatrixStr!=NULL) MEM_free(tMatrixStr);
		if(tMatrixStrDup!=NULL)free(tMatrixStrDup);
		if(tMatrixStr!=NULL)MEM_free(tmat1);
		return ifail;
	}
	
	/*If first character is -.*/
	int flag2 = 0;
	char ch1 = '\0';
	
	//printf("\n 111Length of the input T Matrix value : [%d]\n", tc_strlen(tMatrixStrDup));fflush(stdout);
	if(tc_strlen(tMatrixStrDup) >=2)
	{
		ch  = tMatrixStrDup[0];
		ch1 = tMatrixStrDup[1];
		
		if(ch == '-' && ch1 =='.')
		{
			flag2 ++;
		}
		
	}
	
	//printf("\n flag2 ==> %d\n", flag2);fflush(stdout);
	if(flag2 > 0)
	{
		tc_strcpy(tmat1,"-0.000");
		tc_strcpy(*outStr,tmat1);
		tc_strcat(*outStr,tok2);
		
		//printf("\n outStr : [%s]\n",*outStr);fflush(stdout);
		
		if(tMatrixStr!=NULL) MEM_free(tMatrixStr);
		if(tMatrixStrDup!=NULL)free(tMatrixStrDup);
		if(tMatrixStr!=NULL)MEM_free(tmat1);
		return ifail;
	}
	
	
	/********************Other Logic **************************/
	
	int flag = 0;
	int len = 0;
	int k = 0;
	int j = 0;
	int cnt = 0;
	char * tok1Dup = NULL;
	
	//tok1Dup = (char*)MEM_alloc(50*sizeof(char));
	tc_strdup(tok1,&tok1Dup);
	
	if(tok1[0] == '-')
	{
		//printf("\n -ve number \n");fflush(stdout);
		flag++;
			
	}
	
	//printf("\ntok1Dup ==. [%s]\n",tok1Dup);fflush(stdout);
	
	//replace the -ve from tok1
	if(flag > 0 )
	{
		int len1 = 0;
		len1 = tc_strlen(tok1Dup);
		
		ifail = STRNG_replace_str(tok1Dup,"-","",&tok1);
		//printf("\n tok1 ==> [%s]",tok1);fflush(stdout);
	}
	
	len = tc_strlen(tok1);
	//printf("\nLength of first token: [%d]\n",len);fflush(stdout);
	
	if(len > 3)
	{
		k = len;
	}
	else if(len ==3)
	{
		k = len + 1;
	}
	else if(len == 2)
	{
		k = len + 2;
	}
	else if(len == 1)
	{
		k = len + 3;
	}
	
	
	
	//printf("\n Initial k ==> [%d]\n",k);fflush(stdout);
	
	//76543
	for(j=len-1;j>=0;j--)
	{

		if(len > 3)
		{
			if(cnt==3)
			{
				*(tmat1 + k)= '.';
				j++;
			}
			else
			{
				*(tmat1 + k) = tok1[j];
			}
			k--;
			cnt++;
		}
		else
		{

			*(tmat1 + k ) = tok1[j];
			k--;
		}
	
	
	}
	

	if(len == 3)
	{
		*(tmat1 + k) = '.';
		*(tmat1 + k - 1) = '0';
		*(tmat1 + len + 2)='\0';
	}
	else if(len == 2)
	{
		*(tmat1 + k) = '0';
		*(tmat1 + k - 1) = '.';
		*(tmat1 + k - 2) = '0';
		*(tmat1 + len + 3)='\0';					
	}
	else if(len == 1)
	{
		*(tmat1 + k) = '0';
		*(tmat1 + k - 1) = '0';
		*(tmat1 + k - 2) = '.';
		*(tmat1 + k - 3) = '0';
		*(tmat1 + len + 4)='\0';			
	}
	
	//printf("\ntmat1[%s]\n",tmat1);fflush(stdout);
	if(flag == 0)
	{		
		tc_strcpy(*outStr,tmat1);
		tc_strcat(*outStr,tok2);
	}
	else
	{
		tc_strcpy(*outStr,"-");
		tc_strcat(*outStr,tmat1);
		tc_strcat(*outStr,tok2);
	}

		
	//printf("\n outStr : [%s]\n",*outStr);fflush(stdout);
		
	if(tok1Dup!=NULL) free(tok1Dup);
	if(tMatrixStrDup!=NULL) free(tMatrixStrDup);
	if(tMatrixStr!=NULL)MEM_free(tMatrixStr);	
	if(tmat1!=NULL)MEM_free(tmat1);
	
	return ifail;

}



int relateModuleAndUpdateTMatrixToArchNode(tag_t archModuleRevTag, int childLineCnt, tag_t* childLineList, int childModuleTmatrixCnt, char** childModuleTmatrixList , char* deleteFlag)
{
	int ifail = ITK_ok;
	
	printf("\n Start - relateModuleAndUpdateTMatrixToArchNode....\n");fflush(stdout);
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	tag_t bv = NULLTAG;
	int bv_count = 0;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t bvr = NULLTAG;
	
	ifail = ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag);
	
	ifail = ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs );
	
	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		ifail = PS_create_bom_view(NULLTAG,"","",archModuleItemTag,&bv);
		ifail = AOM_save( bv );
		ifail = AOM_save( archModuleItemTag );
		ifail = AOM_unlock( archModuleItemTag );
		if(bv != NULLTAG) 
		{
			printf("\nCreatd BOM View ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View ...\n");fflush(stdout);
		}		
	}
	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);
	
	if(bvr_count)
	{	

		bvr = bvrs[0];
		MEM_free(bvrs);	
		
		//delete prev occurences.
		if(tc_strcmp(deleteFlag,"YES")==0)
		{
			int ii = 0;
			tag_t* occs = NULLTAG;
			int n_occs = 0;
			ifail = AOM_lock( bvr );
			ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occs );
			
			for (ii = 0; ii<n_occs; ii++)
			{
				ifail = PS_delete_occurrence( bvr, occs[ii] );
			}
			ifail = AOM_save( bvr );
			ifail = AOM_unlock( bvr );
			MEM_free(occs);
		}

				
	}
	else
	{
		ifail = PS_create_bvr( bv, "", "", false, archModuleRevTag, &bvr );
		
		ifail = AOM_save( bvr );
		ifail = AOM_save( archModuleRevTag );
		ifail = AOM_unlock( archModuleRevTag );
		if(bvr != NULLTAG) 
		{
			printf("\nCreatd BOM View Revision ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View Revision...\n");fflush(stdout);
		}
	}
	
	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}
	
	if(bvr != NULLTAG)
	{
		
		/*************Check if the part already exist in the structure***********************/
		
		/**************End if the part already in structure ********************/
		
		
		int i=0;
		tag_t* occTags = NULLTAG;		
		tag_t occTag = NULLTAG;
		char* seq_no  = NULL;		
		int seqNo = 0;
		for(i=0;i<childLineCnt;i++)
		{
			ifail = PS_create_occurrences( bvr, childLineList[i], NULLTAG,1, &occTags );
		
			if(occTags[0] != NULLTAG)
			{
				printf("\nOccurrence created....\n");fflush(stdout);
				occTag = occTags[0];
				if(i==0)
				{
					ifail = USER_ask_new_default_sequence_number(bvr, childLineList[i],&seq_no);
					ifail = PS_set_seq_no(bvr,occTag,seq_no);
					seqNo = atoi(seq_no);
				}
				else
				{
									
					seqNo = seqNo + 10;
					char * seqTmp = NULL;
					seqTmp = (char*)MEM_alloc(30*sizeof(char));
					
					sprintf(seqTmp,"%d",seqNo);
					ifail = PS_set_seq_no(bvr,occTag,seqTmp);
					
					MEM_free(seqTmp);
					
				}
				
				
				
				
				//Set T-matrix
				printf("\n Setting T-Matrix [%s]\n",childModuleTmatrixList[i]);fflush(stdout);
				
				
				char* transcpy = NULL;
				char* tempmat1 = NULL;
				double mat[4][4];
				char *tempmat=NULL;				
				int imat = 0;
				int jmat = 0;
				
				transcpy = (char *) MEM_alloc(tc_strlen(childModuleTmatrixList[i])*sizeof(char) + 100);
				tc_strcpy(transcpy,childModuleTmatrixList[i]);
				printf("\nUpdTMatrix: trans before stamp=======> :: %s\n",transcpy); fflush(stdout);
				tempmat1=tc_strtok(transcpy," ");
					
					
				for(imat=0;imat<4;imat++)
				{
					for(jmat=0;jmat<4;jmat++)
					{
						if(imat==0 && jmat==0)
						{
							//printf("\n inside if"); fflush(stdout);
							mat[imat][jmat]=strtod(tempmat1,NULL);
						}else
						{
							//printf("\n inside else"); fflush(stdout);
							tempmat=tc_strtok(NULL," ");
							mat[imat][jmat]=strtod(tempmat,NULL);
						}
					}
				}


				for(imat=0;imat<4;imat++)
				{
					for(jmat=0;jmat<4;jmat++)
					{
						printf("%10lf,",mat[imat][jmat]);
					}
					printf("\n");
				}
				
				ifail = PS_set_plmxml_transform(bvr, occTag, *mat);
				
				printf("\nT-Matrix set\n");fflush(stdout);
				
				//Get quantity and set quantity if not set
				double qty = 0.00;
				ifail = PS_ask_occurrence_qty(bvr, occTag,&qty);
				printf("\nThe quantity for the newly created occurence===> %lf\n",qty);fflush(stdout);
				if(qty > 0)
				{
					printf("\nAlready there is quantity. No need to set the quantity for the newly created occurence...\n");fflush(stdout);
				}
				else
				{
					ifail = PS_set_occurrence_qty(bvr,occTag,1);
					printf("\nSetting the quantity for the newly created occurence...\n");fflush(stdout);
				}
				
				
				
				
			}			
			
		}
	
		ifail = AOM_save(bvr);
		ifail = AOM_refresh(bvr,1);
		ifail = AOM_unlock( bvr );
		
		//Create Occurence Effectivity,find no, VF etc...
		
		char* arcPlatform = NULL;
		
		ifail = AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform);
		printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
		
		//Get Child line of Architecture Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;
		tag_t* child_lines = NULLTAG;
		int nChld = 0;
		
		ifail = BOM_create_window (&window);
		ifail = CFM_find( "Latest Working", &rule );
		ifail = BOM_set_window_config_rule( window, rule );
		ifail = BOM_set_window_pack_all (window, false);
		ifail = BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line);
		
		if(top_line != NULLTAG)
		{
			int j =0;
			int childId = 0;
			int childRevSeq = 0;
			char* child_id = 0;
			char* child_rev_seq = 0;
			int occuid = 0;
			char* ChildUID = NULL;
			int uidsap = 0;
			char* ChildSAPUID = NULL;
			
			ifail = BOM_line_ask_child_lines (top_line, &nChld, &child_lines);
			printf("\nNo of child objects of Arch Module Rev are : %d",nChld);fflush(stdout);
			
			ifail = BOM_line_look_up_attribute("bl_item_item_id",&childId);
		    ifail = BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq);
			ifail = BOM_line_look_up_attribute ("bl_occurrence_uid",&occuid);
			ifail = BOM_line_look_up_attribute("bl_occ_t5_uidsap",&uidsap);
			
			for(j=0;j<nChld;j++)
			{
				
				ifail = BOM_line_ask_attribute_string(child_lines[j],childId,&child_id);
				ifail = BOM_line_ask_attribute_string(child_lines[j],childRevSeq,&child_rev_seq);
				ifail = BOM_line_ask_attribute_string(child_lines[j], occuid, &ChildUID);
				ifail = BOM_line_ask_attribute_string(child_lines[j], uidsap, &ChildSAPUID);
				
				//Set SAP_UID
				if(ChildSAPUID==NULL)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}
				else if(tc_strcmp(ChildSAPUID,"")==0)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}				

				//Create Occurence Effectivity
				ifail = Create_occurance_effectivity_generic(archModuleRevTag, child_id, child_rev_seq,arcPlatform);
				
									
				
			}
			
			
			
						
		}
		
		ifail = BOM_close_window(window);
		
	}
	
	
	
	return ifail;
}


int updateVariantFormula(tag_t archModuleRevTag,tag_t childTag, tag_t occTag, char* childModuleVF)
{
	int ifail = ITK_ok;
	char* arcPlatform = NULL;
	char* uidChildStr = NULL;
	
	ifail = AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform);
	printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
	
	ITK__convert_tag_to_uid(occTag,&uidChildStr);
	printf("\n uidChildStr : [%s]",uidChildStr);
	
	//Get Child line of Architecture Node
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t* child_lines = NULLTAG;
	int nChld = 0;
	

	
	ifail = BOM_create_window (&window);
	ifail = CFM_find( "Latest Working", &rule );
	ifail = BOM_set_window_config_rule( window, rule );
	ifail = BOM_set_window_pack_all (window, false);
	ifail = BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line);
	
	if(top_line != NULLTAG)
	{
		int j =0;
		int childId = 0;
		int childRevSeq = 0;
		char* child_id = 0;
		char* child_rev_seq = 0;
		int occuid = 0;
		char* ChildUID = NULL;
		int uidsap = 0;
		char* ChildSAPUID = NULL;
		int vfFormId = 0;
		
		ifail = BOM_line_ask_child_lines (top_line, &nChld, &child_lines);
		printf("\nNo of child objects of Arch Module Rev are : %d",nChld);fflush(stdout);
		
		ifail = BOM_line_look_up_attribute("bl_item_item_id",&childId);
		ifail = BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq);
		ifail = BOM_line_look_up_attribute ("bl_occurrence_uid",&occuid);
		ifail = BOM_line_look_up_attribute("bl_occ_t5_uidsap",&uidsap);
		
		CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));
		
		for(j=0;j<nChld;j++)
		{
			char* uidocc = NULL;
			
			ifail = BOM_line_ask_attribute_string(child_lines[j],childId,&child_id);
			ifail = BOM_line_ask_attribute_string(child_lines[j],childRevSeq,&child_rev_seq);
			ifail = BOM_line_ask_attribute_string(child_lines[j], occuid, &ChildUID);
			ifail = BOM_line_ask_attribute_string(child_lines[j], uidsap, &ChildSAPUID);
			
			//ITK__convert_tag_to_uid(child_lines[j],&uidocc);
			
			
			//Create Occurence Effectivity
			

			printf("\n ChildUID : [%s]",ChildUID);
			
			if(tc_strcmp(ChildUID,uidChildStr)==0)
			{
				//ifail = Create_occurance_effectivity_generic(archModuleRevTag, child_id, child_rev_seq,arcPlatform);
				char *sCustomTotalVF= NULL;	
				if (sCustomTotalVF != NULL) { sCustomTotalVF=NULL; }
				sCustomTotalVF=malloc(9000 * sizeof(char));
				
				char *sCustomANDVF= NULL;
				char *sCustomORVF= NULL;
				char* sCustomORVF1 = NULL;
				
				tc_strcpy(sCustomTotalVF,"");
				tc_strcat(sCustomTotalVF,childModuleVF);
				printf("\n VFSubStr1 =>%s\n ",sCustomTotalVF);fflush(stdout);
				
				ITK_CALL(STRNG_replace_str(sCustomTotalVF,"AND ([Teamcenter]","& ([Teamcenter]",&sCustomANDVF));
				printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

				ITK_CALL(STRNG_replace_str(sCustomANDVF,"AND [Teamcenter]","& [Teamcenter]",&sCustomANDVF));
				printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

				ITK_CALL(STRNG_replace_str(sCustomANDVF," OR "," | ",&sCustomORVF1));
				printf("\n SAN....sCustomANDVF1-------> %s\n",sCustomORVF1);fflush(stdout);
				
				ITK_CALL(STRNG_replace_str(sCustomORVF1,"?","-",&sCustomORVF));
				
				printf("\n Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);	

				if(BOM_line_set_attribute_string(child_lines[j],vfFormId,sCustomORVF));
				printf("\nSetting VF for child  as %s\n",sCustomORVF);fflush(stdout);
				
				
				free(sCustomTotalVF);
				

				
				
			}
			
								
			
		}
		
		
		
					
	}
	ifail = BOM_save_window(window);
	ifail = BOM_close_window(window);	
	
	return ifail;
	
}


//Main Function 
int relateModuleAndUpdateVFToArchNode(tag_t archModuleRevTag, int childLineCnt, tag_t* childLineList, int childModuleVFCnt, char** childModuleVFList, char* deleteFlag)
{
	int ifail = ITK_ok;
	
	printf("\n Start - relateModuleAndUpdateVFToArchNode....\n");fflush(stdout);
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	tag_t bv = NULLTAG;
	int bv_count = 0;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t bvr = NULLTAG;
	
	ifail = ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag);
	
	ifail = ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs );
	
	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		ifail = PS_create_bom_view(NULLTAG,"","",archModuleItemTag,&bv);
		ifail = AOM_save( bv );
		ifail = AOM_save( archModuleItemTag );
		ifail = AOM_unlock( archModuleItemTag );
		if(bv != NULLTAG) 
		{
			printf("\nCreatd BOM View ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View ...\n");fflush(stdout);
		}		
	}
	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);
	
	if(bvr_count)
	{	

		bvr = bvrs[0];
		MEM_free(bvrs);	
		
		//delete prev occurences.
		if(tc_strcmp(deleteFlag,"YES")==0)
		{
			int ii = 0;
			tag_t* occs = NULLTAG;
			int n_occs = 0;
			ifail = AOM_lock( bvr );
			ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occs );
			
			for (ii = 0; ii<n_occs; ii++)
			{
				ifail = PS_delete_occurrence( bvr, occs[ii] );
			}
			ifail = AOM_save( bvr );
			ifail = AOM_unlock( bvr );
			MEM_free(occs);
		}

				
	}
	else
	{
		ifail = PS_create_bvr( bv, "", "", false, archModuleRevTag, &bvr );
		
		ifail = AOM_save( bvr );
		ifail = AOM_save( archModuleRevTag );
		ifail = AOM_unlock( archModuleRevTag );
		if(bvr != NULLTAG) 
		{
			printf("\nCreatd BOM View Revision ...\n");fflush(stdout);
		}
		else
		{
			printf("\n NULL BOM View Revision...\n");fflush(stdout);
		}
	}
	
	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}
	
	if(bvr != NULLTAG)
	{
		
		/*************Check if the part already exist in the structure***********************/
		
		/**************End if the part already in structure ********************/
		
		
		int i=0;
		tag_t* occTags = NULLTAG;		
		tag_t occTag = NULLTAG;
		char* seq_no  = NULL;		
		int seqNo = 0;
		char** uidList = NULL;
		int uidCnt = 0;
		char** vfList = NULL;
		int vfCnt = 0;
		for(i=0;i<childLineCnt;i++)
		{
			ifail = PS_create_occurrences( bvr, childLineList[i], NULLTAG,1, &occTags );
		
			if(occTags[0] != NULLTAG)
			{
				printf("\nOccurrence created....\n");fflush(stdout);
				occTag = occTags[0];
				if(i==0)
				{
					ifail = USER_ask_new_default_sequence_number(bvr, childLineList[i],&seq_no);
					ifail = PS_set_seq_no(bvr,occTag,seq_no);
					seqNo = atoi(seq_no);
				}
				else
				{
									
					seqNo = seqNo + 10;
					char * seqTmp = NULL;
					seqTmp = (char*)MEM_alloc(30*sizeof(char));
					
					sprintf(seqTmp,"%d",seqNo);
					ifail = PS_set_seq_no(bvr,occTag,seqTmp);
					
					MEM_free(seqTmp);
					
				}
				
				
				
				
				//Set T-matrix

				
				//Get quantity and set quantity if not set
				double qty = 0.00;
				ifail = PS_ask_occurrence_qty(bvr, occTag,&qty);
				printf("\nThe quantity for the newly created occurence===> %lf\n",qty);fflush(stdout);
				if(qty > 0)
				{
					printf("\nAlready there is quantity. No need to set the quantity for the newly created occurence...\n");fflush(stdout);
				}
				else
				{
					ifail = PS_set_occurrence_qty(bvr,occTag,1);
					printf("\nSetting the quantity for the newly created occurence...\n");fflush(stdout);
				}
				
				
				
				
			}
			ifail = AOM_save(bvr);
			ifail = AOM_refresh(bvr,1);
			ifail = AOM_unlock( bvr );
			
			//Update VF
			char* uidChildStr = NULL;
			ITK__convert_tag_to_uid(occTags[0],&uidChildStr);
			printf("\n uidChildStr : [%s]",uidChildStr);
			
			t5AddStrToSet(&uidCnt, &uidList,uidChildStr);
			t5AddStrToSet(&vfCnt, &vfList,childModuleVFList[i]);
			
			
			
			
		}
	
		ifail = AOM_save(bvr);
		ifail = AOM_refresh(bvr,1);
		ifail = AOM_unlock( bvr );
		
		printf("\n uidCnt:[%d], vfCnt:[%d]\n",uidCnt,vfCnt);fflush(stdout);
		
		//Create Occurence Effectivity,find no, VF etc...
		
		char* arcPlatform = NULL;
		
		ifail = AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform);
		printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
		
		//Get Child line of Architecture Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;
		tag_t* child_lines = NULLTAG;
		int nChld = 0;
		
		ifail = BOM_create_window (&window);
		ifail = CFM_find( "Latest Working", &rule );
		ifail = BOM_set_window_config_rule( window, rule );
		ifail = BOM_set_window_pack_all (window, false);
		ifail = BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line);
		
		if(top_line != NULLTAG)
		{
			int j =0;
			int childId = 0;
			int childRevSeq = 0;
			char* child_id = 0;
			char* child_rev_seq = 0;
			int occuid = 0;
			char* ChildUID = NULL;
			int uidsap = 0;
			char* ChildSAPUID = NULL;
			int vfFormId = 0;
			
			ifail = BOM_line_ask_child_lines (top_line, &nChld, &child_lines);
			printf("\nNo of child objects of Arch Module Rev are : %d",nChld);fflush(stdout);
			
			ifail = BOM_line_look_up_attribute("bl_item_item_id",&childId);
		    ifail = BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq);
			ifail = BOM_line_look_up_attribute ("bl_occurrence_uid",&occuid);
			ifail = BOM_line_look_up_attribute("bl_occ_t5_uidsap",&uidsap);
			
			for(j=0;j<nChld;j++)
			{
				
				ifail = BOM_line_ask_attribute_string(child_lines[j],childId,&child_id);
				ifail = BOM_line_ask_attribute_string(child_lines[j],childRevSeq,&child_rev_seq);
				ifail = BOM_line_ask_attribute_string(child_lines[j], occuid, &ChildUID);
				ifail = BOM_line_ask_attribute_string(child_lines[j], uidsap, &ChildSAPUID);
				CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));
				
				//Set SAP_UID
				if(ChildSAPUID==NULL)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}
				else if(tc_strcmp(ChildSAPUID,"")==0)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}				

				//Create Occurence Effectivity
				ifail = Create_occurance_effectivity_generic(archModuleRevTag, child_id, child_rev_seq,arcPlatform);
				
				
			}
			
			
			for(j=0;j<nChld;j++)
			{
				
				ifail = BOM_line_ask_attribute_string(child_lines[j],childId,&child_id);
				ifail = BOM_line_ask_attribute_string(child_lines[j],childRevSeq,&child_rev_seq);
				ifail = BOM_line_ask_attribute_string(child_lines[j], occuid, &ChildUID);
				ifail = BOM_line_ask_attribute_string(child_lines[j], uidsap, &ChildSAPUID);
				CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));
				
				//Set SAP_UID
				if(ChildSAPUID==NULL)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}
				else if(tc_strcmp(ChildSAPUID,"")==0)
				{
					ifail = BOM_line_set_attribute_string(child_lines[j], uidsap,ChildUID);
				}				

				//Create Occurence Effectivity
				//ifail = Create_occurance_effectivity_generic(archModuleRevTag, child_id, child_rev_seq,arcPlatform);
				
				
				
				//Update VF
				int k =0;
				
				for(k=0;k<uidCnt;k++)
				{
					
					if(tc_strcmp(ChildUID,uidList[k])==0)
					{
						//ifail = Create_occurance_effectivity_generic(archModuleRevTag, child_id, child_rev_seq,arcPlatform);
						char* childModuleVF = NULL;
						char *sCustomTotalVF= NULL;	
						if (sCustomTotalVF != NULL) { sCustomTotalVF=NULL; }
						sCustomTotalVF=malloc(9000 * sizeof(char));
						
						char *sCustomANDVF= NULL;
						char *sCustomORVF= NULL;
						char* sCustomORVF1 = NULL;
						
						childModuleVF = vfList[k];
						tc_strcpy(sCustomTotalVF,"");
						tc_strcat(sCustomTotalVF,childModuleVF);
						printf("\n VFSubStr1 =>%s\n ",sCustomTotalVF);fflush(stdout);
						
						ITK_CALL(STRNG_replace_str(sCustomTotalVF,"AND ([Teamcenter]","& ([Teamcenter]",&sCustomANDVF));
						//printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

						ITK_CALL(STRNG_replace_str(sCustomANDVF,"AND [Teamcenter]","& [Teamcenter]",&sCustomANDVF));
						//printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

						ITK_CALL(STRNG_replace_str(sCustomANDVF," OR "," | ",&sCustomORVF1));
						//printf("\n SAN....sCustomANDVF1-------> %s\n",sCustomORVF1);fflush(stdout);
						
						ITK_CALL(STRNG_replace_str(sCustomORVF1,"?","-",&sCustomORVF));
						
						//printf("\n Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);	

						if(BOM_line_set_attribute_string(child_lines[j],vfFormId,sCustomORVF));
						printf("\nSetting VF for child[%s,%s]  as [%s]\n",child_id,ChildUID,sCustomORVF);fflush(stdout);
						
						
						free(sCustomTotalVF);
						

						
						
					}
				
					ifail = BOM_save_window(window);					
					
				}
				
				
				
			}			
			
			
			
			ifail = BOM_save_window(window);			
		}
		
		ifail = BOM_close_window(window);
		
	}
	
	
	
	return ifail;
}

/********************Report LOgic functions ***************************/


typedef struct SubModuleLibDet_
{
	char moduleAddr[50];
	char desc[300];
	char agrregate[300];
	char agrregateGrp[300];
	
	char** moduleNoList;
	int moduleNoListCnt;
	
	char** moduleRevList;
	//int moduleRevListCnt;
		
	char** moduleSeqList;
	//int moduleSeqListCnt;
	
	char** drStatList;
	//int drStatListCnt;
	
	char** prodlineList;
	char** platformList;
	char** projectcodeList;
	
	char** descList;
	
}SubModuleLibDet;

void setAddSubModuleLibDet(int *count,SubModuleLibDet **objlist,SubModuleLibDet obj )
{

	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (SubModuleLibDet *)malloc((*count ) * sizeof(SubModuleLibDet ));
	}
	else
	{
		(*objlist) = (SubModuleLibDet *)realloc((*objlist),(*count) * sizeof(SubModuleLibDet ));
	}

	(*objlist)[*count-1] = obj;
}

void t5FindSubModuleLibInSubModuleLibSet(SubModuleLibDet *subModuleLibList,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(subModuleLibList[k].moduleAddr,str)==0)
		{
			*found=1;
			break;
		}

	}
}


int getSubModuleLibRevTag(char *moduleAddr, tag_t *moduleLibRevTag)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Name";
	qry_entries[1] = "ID";
	
	qry_values[0] = moduleAddr;
	qry_values[1] = moduleAddr;
		
	CALLAPI(QRY_find("SubModuleLibrary...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	//printf("\nMCC:getSubModuleLibRevTag: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*moduleLibRevTag = itemObj[count-1];
	}
	
	return ifail;
}

int createSubModuleLibTag(SubModuleLibDet subModuleLibData, tag_t* SubModuleLibRevTag)
{
	int ifail = ITK_ok;
	tag_t SubModuleLibRevType = NULLTAG;
	tag_t SubModuleLibRevCreInput = NULLTAG;
	
	printf("\nMCC:Creation of Submodule Lib starts....\n");fflush(stdout);
	
	ifail = TCTYPE_find_type("T5_SubmodulelibRevision", NULL, &SubModuleLibRevType);
	
	if(SubModuleLibRevType != NULLTAG)
	{
		tag_t SubModuleLibType = NULLTAG;
		ifail = TCTYPE_construct_create_input(SubModuleLibRevType, &SubModuleLibRevCreInput);
		
		if(SubModuleLibRevCreInput != NULLTAG)
		{
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "item_revision_id", "A;1");
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "sequence_id", "1"); 
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "object_desc", subModuleLibData.desc);
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "t5_submoduledesc", subModuleLibData.desc);
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "t5_aggrgrp", subModuleLibData.agrregateGrp);
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "t5_aggr", subModuleLibData.agrregate);
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "t5_ModuleAddrSL", subModuleLibData.moduleAddr);
			
			ifail = TCTYPE_find_type("T5_Submodulelib", NULL, &SubModuleLibType);    
			if(SubModuleLibType != NULLTAG)
			{
				tag_t SubModuleLibCreInput  = NULLTAG;
				tag_t SubModuleTag = NULLTAG;
				ifail = TCTYPE_construct_create_input(SubModuleLibType, &SubModuleLibCreInput);
				
				ifail = AOM_set_value_string(SubModuleLibCreInput, "object_name", subModuleLibData.moduleAddr);
				ifail = AOM_set_value_string(SubModuleLibCreInput, "item_id", subModuleLibData.moduleAddr);
				
				ifail = TCTYPE_create_object(SubModuleLibCreInput, &SubModuleTag);
				
				if(SubModuleTag != NULLTAG)
				{
					tag_t latestSubModuleRevTag = NULLTAG;
					
					printf("\nMCC: SubModule Lib Created successfully. **** \n\n \n ");fflush(stdout);
					
					if(AOM_save(SubModuleTag));
					if(AOM_unlock(SubModuleTag));		
					if(AOM_refresh(SubModuleTag,1));
					
					
					ifail = ITEM_ask_latest_rev(SubModuleTag, &latestSubModuleRevTag);
					
					if(latestSubModuleRevTag != NULLTAG)
					{
						ifail = AOM_lock(latestSubModuleRevTag);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "item_revision_id", "A;1");
						ifail = AOM_set_value_string(latestSubModuleRevTag, "sequence_id", "1"); 
						ifail = AOM_set_value_string(latestSubModuleRevTag, "object_desc", subModuleLibData.desc);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "t5_submoduledesc", subModuleLibData.desc);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "t5_aggrgrp", subModuleLibData.agrregateGrp);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "t5_aggr", subModuleLibData.agrregate);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "t5_ModuleAddrSL", subModuleLibData.moduleAddr);											
						
						ifail = AOM_save(latestSubModuleRevTag);
						ifail = AOM_unlock(latestSubModuleRevTag);
						ifail = AOM_refresh(latestSubModuleRevTag,1);
						
						
						//Create- Update the Table properties.
						
						//subModuleLibData.moduleNoListCnt
						
						int num_rows_to_insert = 0;
						tag_t* table_rows_tag = NULLTAG;
						int property_index = 0;
						
						char** moduleNoList = NULL;
						char** moduleRevList = NULL;
						char** moduleSeqList = NULL;
						char** drStatList = NULL;
                        char** prodlineList = NULL;
                        char** platformList = NULL;
                        char** projectcodeList = NULL;
                        char** descList = NULL;						
						
						
						num_rows_to_insert = subModuleLibData.moduleNoListCnt;
						moduleNoList = subModuleLibData.moduleNoList;
						moduleRevList = subModuleLibData.moduleRevList;
						moduleSeqList = subModuleLibData.moduleSeqList;
						drStatList = subModuleLibData.drStatList;
						prodlineList = subModuleLibData.prodlineList;
						platformList = subModuleLibData.platformList;
						projectcodeList = subModuleLibData.projectcodeList;
						descList = subModuleLibData.descList;
						
						printf("\nMCC:num_rows_to_insert ===>[%d]\n",num_rows_to_insert);fflush(stdout);
						
						ifail = AOM_insert_table_rows(latestSubModuleRevTag,"t5_Submoduledetail",0,num_rows_to_insert,&table_rows_tag );
						printf("MCC:ifail is %d\n",ifail);
						
						for ( property_index = 0 ; property_index < num_rows_to_insert; property_index++ )
						{
							printf("\nMCC:ModuleNo[%d]==> [%s/%s;%s], DR Status:[%s]\n",property_index,moduleNoList[property_index],moduleRevList[property_index],moduleSeqList[property_index],drStatList[property_index]);fflush(stdout);
							
							if(table_rows_tag [ property_index ] != NULLTAG)
							{
								char* srnNo = (char*)MEM_alloc(30*sizeof(char*));
								sprintf(srnNo,"%d",property_index + 1);
								
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_srno", srnNo);
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_submoduleno", moduleNoList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_desc", descList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_rev", moduleRevList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_seq", moduleSeqList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_productline", prodlineList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_Platform", platformList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_projectcode", projectcodeList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_drarstatus", drStatList[property_index] );
								
								MEM_free(srnNo);
								
								ifail = AOM_save_with_extensions(table_rows_tag[property_index]);
							}
						}
						
						
					}
						
				}
			}
			
			
			
			
		}

		
		
		
	}
	
	printf("\nMCC:Creation of Submodule Lib finishes....\n");fflush(stdout);
	return ITK_ok;
}


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );	
	printf("\nMCC:*********** Start Of Main function ************* \n");fflush(stdout);	
	
	if(ITK_auto_login() == ITK_ok)	
	{

		char *filepath = ITK_ask_cli_argument("-f=");
		FILE * fp = NULL;
				
		ITK_set_journalling( TRUE );
		printf("\nMCC:Login successfull.\n");fflush(stdout);		
		printf("\nMCC:Input Parameters:Input File:[%s]\n",filepath);fflush(stdout);
		
		char* sno = NULL;
		char* moduleNo = NULL;
		char* moduleAddr = NULL;
		char* moduleRev = NULL;
		char* moduleSeq = NULL;
		char* drStat = NULL;	
		char* desc = NULL;
		char* agrregate = NULL;
		char* agrregateGrp = NULL;
		char* prodline = NULL;
		char* platform = NULL;
		char* projectcode = NULL;
		

		char** moduleNoList = NULL;
		int moduleNoListCnt = 0;
		
		char** moduleAddrList = NULL;
		int moduleAddrListCnt = 0;
		
		char** moduleRevList = NULL;
		int moduleRevListCnt = 0;
		
		char** moduleSeqList = NULL;
		int moduleSeqListCnt = 0;
		
		char** drStatList = NULL;
		int drStatListCnt = 0;
		
		char** descList = NULL;
		int descListCnt = 0;
		
		char** agrregateList = NULL;
		int agrregateListCnt = 0;
		
		char** agrregateGrpList = NULL;
		int agrregateGrpListCnt = 0;
		
		char** prodlineList = NULL;
		int prodlineListCnt = 0;
		
		char** platformList = NULL;
		int platformListCnt = 0;
		
		char** projectcodeList = NULL;
		int projectcodeListCnt = 0;

		fp = fopen(filepath, "r");
		

		if(fp==NULL)
		{
			printf("\nMCC:Could not open the file %s. Kindly check.\n",filepath);fflush(stdout);
		}
		else
		{
			int k =0;
			char buffer[MAX_LINE_LEN] ="";
			
			
			while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
			{
				sno = strtok(buffer,",");
				moduleNo = strtok(NULL,",");
				desc = strtok(NULL,",");
				moduleRev = strtok(NULL,",");
				moduleSeq = strtok(NULL,",");
				prodline = strtok(NULL,",");
				platform = strtok(NULL,",");
				projectcode = strtok(NULL,",");
				drStat =strtok(NULL,",");
				moduleAddr = strtok(NULL,",");
				agrregate = strtok(NULL,",");
				agrregateGrp = strtok(NULL,",");
				
								
				printf("\nMCC:[%d] SNo[%s], Module No[%s/%s;%s],Module Addresss:[%s], DR Status[%s], Description[%s], Aggregate[%s], Aggregate Group[%s], Product Line[%s], Platform[%s], Project Code[%s]", k++, sno, moduleNo, moduleRev,moduleSeq,moduleAddr,drStat,desc,agrregate,agrregateGrp,prodline,platform,projectcode);fflush(stdout);
				
				
				t5AddStrToSet(&moduleNoListCnt, &moduleNoList,moduleNo);
				t5AddStrToSet(&descListCnt, &descList,desc);
				t5AddStrToSet(&moduleRevListCnt, &moduleRevList,moduleRev);
				t5AddStrToSet(&moduleSeqListCnt, &moduleSeqList,moduleSeq);
				t5AddStrToSet(&prodlineListCnt, &prodlineList,prodline);
				t5AddStrToSet(&platformListCnt, &platformList,platform);
				t5AddStrToSet(&projectcodeListCnt, &projectcodeList,projectcode);
				t5AddStrToSet(&drStatListCnt, &drStatList,drStat);
				t5AddStrToSet(&moduleAddrListCnt, &moduleAddrList,moduleAddr);
				t5AddStrToSet(&agrregateListCnt, &agrregateList,agrregate);
				t5AddStrToSet(&agrregateGrpListCnt, &agrregateGrpList,agrregateGrp);
				
				
				
				
			}
		}
		
		
		
		

		if(fp) fclose(fp);
		
		
		printf("\nMCC:moduleNoListCnt[%d], agrregateListCnt[%d], agrregateGrpListCnt[%d]",moduleNoListCnt,agrregateListCnt,agrregateGrpListCnt);fflush(stdout);
		
		
		int i=0;
		int j =0;
		
		SubModuleLibDet * subModuleLibDetList;
		int subModuleLibDetListCnt =0;
		
		
		char** moduleADDList = NULL;
		int moduleADDListCnt = 0;
		int found = 0;
		
		
		for(i=0;i<moduleAddrListCnt;i++)
		{
			char* moduleAdd = NULL;
			
			char** moduleNo1List = NULL;
			int moduleNo1ListCnt = 0;
			
			char** moduleRev1List = NULL;
			int moduleRev1ListCnt = 0;
			
			char** moduleSeq1List = NULL;
			int moduleSeq1ListCnt = 0;
			
			char** drStat1List = NULL;
			int drStat1ListCnt = 0;	

            char** prodline1List = NULL;
			int prodline1ListCnt = 0;

            char** platform1List = NULL;
			int platform1ListCnt = 0;

            char** projectcode1List = NULL;
			int projectcode1ListCnt = 0;

            char** desc1List = NULL;
			int desc1ListCnt = 0;			
			
			moduleAdd = moduleAddrList[i];
			
			t5FindStrInSet(moduleADDList,moduleADDListCnt,moduleAdd,&found);
			
			if(found ==0)
			{
				SubModuleLibDet subMdlDet;
				
				for(j=0;j<moduleAddrListCnt;j++)
				{
					if(tc_strcmp(moduleAdd,moduleAddrList[j])==0)
					{
						t5AddStrToSet(&moduleNo1ListCnt, &moduleNo1List,moduleNoList[j]);
						t5AddStrToSet(&moduleRev1ListCnt, &moduleRev1List,moduleRevList[j]);
						t5AddStrToSet(&moduleSeq1ListCnt, &moduleSeq1List,moduleSeqList[j]);
						t5AddStrToSet(&drStat1ListCnt, &drStat1List,drStatList[j]);
						t5AddStrToSet(&prodline1ListCnt, &prodline1List,prodlineList[j]);
						t5AddStrToSet(&platform1ListCnt, &platform1List,platformList[j]);
						t5AddStrToSet(&projectcode1ListCnt, &projectcode1List,projectcodeList[j]);
						t5AddStrToSet(&desc1ListCnt, &desc1List,descList[j]);

					}
				}
			
				tc_strcpy(subMdlDet.moduleAddr,moduleAdd);
				tc_strcpy(subMdlDet.desc,descList[i]);
				tc_strcpy(subMdlDet.agrregate,agrregateList[i]);
				tc_strcpy(subMdlDet.agrregateGrp,agrregateGrpList[i]);
				
				subMdlDet.moduleNoList = moduleNo1List;
				subMdlDet.moduleNoListCnt = moduleNo1ListCnt;
				subMdlDet.moduleRevList = moduleRev1List;
				subMdlDet.moduleSeqList = moduleSeq1List;
				subMdlDet.drStatList = drStat1List;
				subMdlDet.prodlineList = prodline1List;
				subMdlDet.platformList = platform1List;
				subMdlDet.projectcodeList = projectcode1List;
				subMdlDet.descList = desc1List;
				
				
				
				
				setAddSubModuleLibDet(&subModuleLibDetListCnt, &subModuleLibDetList,subMdlDet);
			
			
			}
			
			t5AddStrToSet(&moduleADDListCnt, &moduleADDList,moduleAdd);
			
			
		}
		printf("\nMCC:subModuleLibDetListCnt ==> [%d]\n", subModuleLibDetListCnt);fflush(stdout);
		
		
		/* Logic to create the data in TCUA */
		
		int m = 0;
		
		
		for(m =0; m< subModuleLibDetListCnt; m++)
		{
			SubModuleLibDet subModuleLibData;
			char* moduleAddrStr = NULL;
			tag_t SubModuleLibRevTag = NULLTAG;
			subModuleLibData = subModuleLibDetList[m];
			
			moduleAddrStr = subModuleLibData.moduleAddr;
			
			//Check whether this already exists in PLM DB
			
			ifail = getSubModuleLibRevTag(moduleAddrStr, &SubModuleLibRevTag);
			
			if(SubModuleLibRevTag != NULLTAG)
			{
				printf("\nMCC:Already exists SubmoduleTag[%s] - Only update with new data\n",moduleAddrStr);fflush(stdout);
			}
			else
			{
				printf("\nMCC:Create a new SubModuleLib Object[%s].\n",moduleAddrStr);fflush(stdout);
				
				ifail = createSubModuleLibTag(subModuleLibData, &SubModuleLibRevTag);
			}
			
		}
			
		
	}
	

	
	
	printf("\nMCC:*********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_moduleaddresstablecreate.c
* // ./linkitk -o tm_moduleaddresstablecreate tm_moduleaddresstablecreate.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressTableCreate/tm_moduleaddresstablecreate .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressTableCreate/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressTableCreate/Input.csv .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressTableCreate/usage.txt .
* // ./tm_moduleaddresstablecreate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_moduleaddresstablecreate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/