/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   This EXE is used for different date time findings 
*  File Name    :   tm_dttime.c
*  Created on   :   Sept 19th, 2024
*  Usage        :   tm_dttime
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     19/09/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tc/tc.h>
#include <time.h>
#include <string.h>

void tostring(char [], int);
char* TC_MonthName(int monno)
{
	char *monname = NULL;
	switch(monno) 
	{
        case 1 : 
                tc_strdup("Jan",&monname);				
				break;
        case 2 : 
				tc_strdup("Feb",&monname);
          		break;
        case 3 : 
				tc_strdup("Mar",&monname);
				break;
        case 4 : 
                tc_strdup("Apr",&monname);				
				break;
        case 5 : 
				tc_strdup("May",&monname);
				break;
        case 6 : 
				tc_strdup("Jun",&monname);
				break;
        case 7 : 
				tc_strdup("Jul",&monname);
				break;
        case 8 : 
				tc_strdup("Aug",&monname);
				break;
        case 9 : 
                tc_strdup("Sep",&monname);				
				break;
        case 10 : 
				tc_strdup("Oct",&monname);
				break;
        case 11 : 
                tc_strdup("Nov",&monname);				
				break;
        case 12 : 
				tc_strdup("Dec",&monname);
				break;
        default : printf("Input Number is Wrong..!!\n");
    }
	
   return monname;
}

char* TC_LeapYrChk(int yrno)
{
   char *leapstatus = NULL;
    if((yrno%4==0) && ((yrno%400==0) || (yrno%100!=0)))  
    {  
        tc_strdup("yes",&leapstatus);
    } 
	else 
	{  
        tc_strdup("no",&leapstatus); 
    }  
   return leapstatus;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of Date-Time Main Function ************* \n");fflush(stdout);					
    char *did_str = NULL;
    char *mid_str = NULL;
    char *yid_str = NULL;
    
    char GenDate[100] = "";
	char GenYr[100] = "";
	char FullYr[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d-%m-%Y",&when);
	printf("\nCurrent TimeStamp: [%s]\n", GenDate);fflush(stdout);
	strftime(GenYr,100,"%y",&when);
	printf("\nCurrent TimeStamp(Only Year): [%s]\n", GenYr);fflush(stdout);
	strftime(FullYr,100,"%Y",&when);
	printf("\nCurrent TimeStamp(Full Year): [%s]\n", FullYr);fflush(stdout);
	did_str=strtok(GenDate,"-");
	mid_str=strtok(NULL,"-");
	yid_str=strtok(NULL,"-");
	printf("\nDAY: [%s]", did_str);fflush(stdout);
	printf("\nMONTH[STRING]: [%s]", mid_str);fflush(stdout);
	printf("\nYEAR: [%s]", yid_str);fflush(stdout);
	int val;
	val = atoi(mid_str);
	printf("\nMONTH[INT]: [%d]\n", val);fflush(stdout);
	int yrval;
	yrval = atoi(GenYr);
	printf("\nYEAR[INT]: [%d]\n", yrval);fflush(stdout);
	int fullyrval;
	fullyrval = atoi(FullYr);
	printf("\nFULL YEAR[INT]: [%d]\n", fullyrval);fflush(stdout);
	int preyrval;
	preyrval = fullyrval - 1;
	printf("\nPRE YEAR[INT]: [%d]\n", preyrval);fflush(stdout);
	int i = 0;
	int change = 0;
	char *MonStatus = NULL;
	char *colhead = (char *) malloc(20*sizeof(char));
	char *sdate = (char *) malloc(20*sizeof(char));
	char *edate = (char *) malloc(20*sizeof(char));
	char newyrvalstr[10];
	char *YrStatus = NULL;
	char preyrvalstr[10];
	for(i = 0; i <= 11; i++)
	{
	    if(val<1)
		{
		   val = 12;
		   MonStatus = TC_MonthName(val);
		   val = val -1;
		   tc_strcpy(colhead,MonStatus);
		   change = change + 1;
		}
		else
		{
			MonStatus = TC_MonthName(val);
			val = val -1;
		}
		
		if(change == 0)
		{
			tc_strcpy(colhead,MonStatus);
	        tc_strcat(colhead,"-");
	        tc_strcat(colhead,GenYr);
			YrStatus = TC_LeapYrChk(fullyrval);
			if(tc_strcmp(MonStatus,"Jan")==0)
			{
				//tc_strcpy(sdate,"01-01-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-01-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if((tc_strcmp(YrStatus,"yes")==0) && (tc_strcmp(MonStatus,"Feb")==0))
			{
				//tc_strcpy(sdate,"01-02-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"29-02-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if((tc_strcmp(YrStatus,"no")==0) && (tc_strcmp(MonStatus,"Feb")==0))
			{
				//tc_strcpy(sdate,"01-02-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"28-02-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Mar")==0)
			{
				//tc_strcpy(sdate,"01-03-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-03-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Apr")==0)
			{
				//tc_strcpy(sdate,"01-04-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-04-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"May")==0)
			{
				//tc_strcpy(sdate,"01-05-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-05-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Jun")==0)
			{
				//tc_strcpy(sdate,"01-06-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-06-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Jul")==0)
			{
				//tc_strcpy(sdate,"01-07-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-07-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Aug")==0)
			{
				//tc_strcpy(sdate,"01-08-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-08-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Sep")==0)
			{
				//tc_strcpy(sdate,"01-09-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-09-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Oct")==0)
			{
				//tc_strcpy(sdate,"01-10-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-10-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Nov")==0)
			{
				//tc_strcpy(sdate,"01-11-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-11-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Dec")==0)
			{
				//tc_strcpy(sdate,"01-12-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-12-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else
			{
				printf("\n !!..Not Matched..!!");fflush(stdout);
			}
		}
		else
		{
			int newyrval = 0;
			newyrval = yrval - 1;
			tostring(newyrvalstr, newyrval);
			tc_strcpy(colhead,MonStatus);
	        tc_strcat(colhead,"-");
	        tc_strcat(colhead,newyrvalstr);
			YrStatus = TC_LeapYrChk(fullyrval-1);
			tostring(preyrvalstr, preyrval);
			if(tc_strcmp(MonStatus,"Jan")==0)
			{
				//tc_strcpy(sdate,"01-01-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-01-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if((tc_strcmp(YrStatus,"yes")==0) && (tc_strcmp(MonStatus,"Feb")==0))
			{
				//tc_strcpy(sdate,"01-02-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"29-02-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if((tc_strcmp(YrStatus,"no")==0) && (tc_strcmp(MonStatus,"Feb")==0))
			{
				//tc_strcpy(sdate,"01-02-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"28-02-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Mar")==0)
			{
				//tc_strcpy(sdate,"01-03-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-03-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Apr")==0)
			{
				//tc_strcpy(sdate,"01-04-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-04-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"May")==0)
			{
				//tc_strcpy(sdate,"01-05-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-05-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Jun")==0)
			{
				//tc_strcpy(sdate,"01-06-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-06-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Jul")==0)
			{
				//tc_strcpy(sdate,"01-07-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-07-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Aug")==0)
			{
				//tc_strcpy(sdate,"01-08-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-08-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Sep")==0)
			{
				//tc_strcpy(sdate,"01-09-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-09-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Oct")==0)
			{
				//tc_strcpy(sdate,"01-10-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-10-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Nov")==0)
			{
				//tc_strcpy(sdate,"01-11-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-11-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Dec")==0)
			{
				//tc_strcpy(sdate,"01-12-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-01-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-12-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else
			{
				printf("\n !!..Not Matched..!!");fflush(stdout);
			}
		}
		
		
		printf("\nMonth Name: [%s] | Column Heading: [%s] | Start Date: [%s] | End Date: [%s]", MonStatus,colhead,sdate,edate);fflush(stdout);
	}

	printf("\n*********** End Of Date-Time Main Function ************* \n");fflush(stdout);	
	return ifail;
}

/***************************************************************************
*
* // ./compile tm_dttime.c
* // ./linkitk -o tm_dttime tm_dttime.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DATETEST/tm_dttime .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DATETEST/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DATETEST/SendEmail.sh .
* // ./tm_dttime -u=infodba -p=loader123 -g=dba
*
***************************************************************************/