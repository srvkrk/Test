/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   POM
*  Description  :   Generate TCUA Data Dump For BOM Completeness 
*  File Name    :   tm_BOMComp.c
*  Created on   :   Feb 1st, 2024
*  Usage        :   tm_BOMComp
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     01/02/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ValidateString (char *B)
{
    int i;
    for (i = 0; B[i] != '\0'; i++)
    {
        if (!(B[i] >= 65 && B[i] <= 90) && !(B[i] >= 97 && B[i] <= 122) && !(B[i] >= 44 && B[i] <= 57) && !(B[i] >31 && B[i] <= 32))
        {
            return 0;
        }
    }
       return 1;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile1 = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	FILE *fpOutput_file1 = NULL;
	char *Part_No = NULL;
	char *Part_RevSeq = NULL;
	char *Part_RevSeqDup = NULL;
	char *Part_Rev = NULL;
	char *Part_Seq = NULL;
	char *Part_Type = NULL;
	char *Part_TypeDup = NULL;
	char *Input_File = (char *) malloc(400*sizeof(char));
	int z=0;
	tag_t iteamrev2 = NULLTAG;
	double Part_Weight;
	char *Env_Dim = NULL;
	char *Env_DimDup = NULL;
	char *Mat_Clas = NULL;
	char *Mat_ClasDup = NULL;
	char *Spare_Ctr = NULL;
	char *Spare_CtrDup = NULL;
	char *Mat_Drw = NULL;
	char *Mat_DrwDup = NULL;
	tag_t PartMasterTag	= NULLTAG;
	char *MstrUnitTag = NULL;
	char *MstrUnitTagDup = NULL;
	char *MstrUnitVal = NULL;
	char *MstrUnitValDup = NULL;
	char *RevUnitVal = NULL;
	char *RevUnitValDup = NULL;
	


    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char *start_limit = NULL;
	char *end_limit = NULL;
	start_limit = ITK_ask_cli_argument("-s=");
	end_limit = ITK_ask_cli_argument("-e=");
	trimwhitespace(start_limit);
	trimwhitespace(end_limit);
	printf(" [1]: Input Starting(start_limit): [%s]\n",start_limit);fflush(stdout);
	printf(" [2]: Input Ending(end_limit): [%s]\n",end_limit);fflush(stdout);
	
	int strtl = 0;
	int endl = 0;
	if (start_limit != NULL)
	{
		strtl = atoi(start_limit);
	}
	if (end_limit != NULL)
	{
		endl = atoi(end_limit);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile1,"TCUA_BOMComp_");
	tc_strcat(RptFile1,"From");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,start_limit);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,"To");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,end_limit);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,GenDate);
	tc_strcat(RptFile1,".csv");
	printf("\n CSV Report File Name: [%s]", RptFile1);fflush(stdout);
	printf("\n CSV Report File Generated..!!");fflush(stdout);
	
	fpOutput_file1 = fopen(RptFile1, "w");
	fprintf(fpOutput_file1,"PART_NO, PART_REV, PART_SEQ, ENV_DIM, WEIGHT, MAT_CLASS, PART_CAT, PART_TYPE, MAT_DRW, MSTR_UOM_TAG, MSTR_UOM, REV_UOM\n");fflush(fpOutput_file1); 
	int objtyplen = 1;
	int rlztyplen = 3;
	//int ownUsrlen = 1;
	const char* object_type_data[]={"Design Revision"};
	const char* fnd_lat_ERCRlz_lst=NULL;
	//const char* select_attrs[]={"item_id","item_revision_id","creation_date","last_mod_date","puid"};
	const char* select_attrs[]={"puid","item_revision_id"};
	const char *select_attrs_Item[] = { "item_id" };
	//const char* release_status_data[]={"T5_LcsErcRlzd"};
	const char* release_status_data[]={"T5_LcsWorking","T5_LcsReview","T5_LcsErcRlzd"};
	//const char* owning_user_data[]={"loader"};
	int  rows = 0, columns = 0;
	void ***report;
	char *pQry = "fnd_lat_ERCRlz_lst";
	ITK_CALL(POM_enquiry_create(pQry));
	ITK_CALL(POM_enquiry_add_select_attrs (pQry,"ItemRevision",1,select_attrs));
	ITK_CALL(POM_enquiry_add_select_attrs(pQry, "Item", 1,select_attrs_Item));
 
	ITK_CALL(POM_enquiry_set_string_value (pQry,"object_type_expr",objtyplen,object_type_data,POM_enquiry_bind_value));
	ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_object_type_in","ItemRevision","object_type",POM_enquiry_in,"object_type_expr"));
 
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr2","ItemRevision", "release_status_list", POM_enquiry_equal, "ReleaseStatus", "puid"));
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr3","ItemRevision", "owning_user", POM_enquiry_equal, "User", "puid"));
 
	ITK_CALL(POM_enquiry_set_string_value (pQry,"release_stat_expr",rlztyplen,release_status_data,POM_enquiry_bind_value));
	ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_rlz_stat_in","ReleaseStatus","name",POM_enquiry_in,"release_stat_expr"));
 
	//ITK_CALL(POM_enquiry_set_string_value (pQry,"own_user_expr",ownUsrlen,owning_user_data,POM_enquiry_bind_value));
	//ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_own_user_in","User","user_id",POM_enquiry_in,"own_user_expr"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr","join_expr1", POM_enquiry_and, "join_expr2"));
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr1","combine_expr",POM_enquiry_and,"expr_object_type_in"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr2","combine_expr1",POM_enquiry_and,"join_expr3"));
	//ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr3","combine_expr2",POM_enquiry_and,"expr_own_user_in"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"expr_AND_expression","combine_expr2",POM_enquiry_and,"expr_rlz_stat_in"));
	ITK_CALL(POM_enquiry_set_where_expr (pQry,"expr_AND_expression"));
 
	ITK_CALL(POM_enquiry_add_order_attr (pQry, "Item", "item_id", POM_enquiry_asc_order));
 
	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_execute(pQry, &rows, &columns, &report));
	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_delete(pQry));
	printf(" \n Number of Rows [%d] and Number of Coloumns [%d]\n",rows,columns);fflush(stdout);
	//exit(0);
	if (endl > rows)
	{
		endl = rows;
	}
	if(rows > 0 && strtl < rows)
	{
		for(z=strtl;z < endl; z++)
		{
			//iteamrev2 = titemobj_results[z];
			iteamrev2 = *(tag_t*)(report[z][0]);
			ITK_CALL(AOM_ask_value_string(iteamrev2,"item_id",&Part_No));
			if(Part_No!=NULL)
			{
				ITK_CALL(AOM_ask_value_string(iteamrev2,"item_revision_id",&Part_RevSeq));
				if(tc_strlen(Part_RevSeq)>0)
				{
					tc_strdup(Part_RevSeq,&Part_RevSeqDup);
				}
				Part_Rev=strtok(Part_RevSeqDup,";");
				Part_Seq=strtok(NULL,";");
				
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_EnvelopeDimensions",&Env_Dim));
				if(Env_Dim!=NULL)
				{
					trimwhitespace(Env_Dim);
					STRNG_replace_str(Env_Dim,","," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,";"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"\n"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"'"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"`"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"~"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"@"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"#"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"$"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"|"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"!"," ",&Env_Dim);
					tc_strdup(Env_Dim,&Env_DimDup);
				}
				else
				{
					tc_strdup("--",&Env_DimDup);
					printf("\n Envelope Dimension Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_double(iteamrev2,"t5_Weight",&Part_Weight));
			    ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_MatlClass",&Mat_Clas));
				if(Mat_Clas!=NULL)
				{
					trimwhitespace(Mat_Clas);
					STRNG_replace_str(Mat_Clas,","," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,";"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"\n"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"'"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"`"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"~"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"@"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"#"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"$"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"|"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"!"," ",&Mat_Clas);
					tc_strdup(Mat_Clas,&Mat_ClasDup);
				}
				else
				{
					tc_strdup("--",&Mat_ClasDup);
					printf("\n Material Class Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_SpareCriteria",&Spare_Ctr));
				if(Spare_Ctr!=NULL)
				{
					trimwhitespace(Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,","," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,";"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"\n"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"'"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"`"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"~"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"@"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"#"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"$"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"|"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"!"," ",&Spare_Ctr);
					tc_strdup(Spare_Ctr,&Spare_CtrDup);
				}
				else
				{
					tc_strdup("--",&Spare_CtrDup);
					printf("\n Spare Criteria Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PartType",&Part_Type));
				if(Part_Type!=NULL)
				{
					tc_strdup(Part_Type,&Part_TypeDup);
				}
				else
				{
					tc_strdup("--",&Part_TypeDup);
					printf("\n Part Type Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_Material",&Mat_Drw));
				if(Mat_Drw!=NULL)
				{
					trimwhitespace(Mat_Drw);
					STRNG_replace_str(Mat_Drw,","," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,";"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"\n"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"'"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"`"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"~"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"@"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"#"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"$"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"|"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"!"," ",&Mat_Drw);
					tc_strdup(Mat_Drw,&Mat_DrwDup);
				}
				else
				{
					tc_strdup("--",&Mat_DrwDup);
					printf("\n Material in Drawing Value is NULL..!!\n");fflush(stdout);
				}
				
				ITK_CALL(ITEM_find_item(Part_No,&PartMasterTag));
				if(PartMasterTag != NULLTAG)
				{
					ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&MstrUnitTag));
				}
				if(MstrUnitTag!=NULL)
				{
					tc_strdup(MstrUnitTag,&MstrUnitTagDup);
				}
				else
				{
					tc_strdup("--",&MstrUnitTagDup);
					printf("\n Master Unit of Measure Tag[uom_tag] is NULL..!!\n");fflush(stdout);
				}
				
				ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"t5_uom",&MstrUnitVal));
				if(MstrUnitVal!=NULL)
				{
					tc_strdup(MstrUnitVal,&MstrUnitValDup);
				}
				else
				{
					tc_strdup("--",&MstrUnitValDup);
					printf("\n Master Unit of Measure Value[t5_uom] is NULL..!!\n");fflush(stdout);
				}
				
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_uom",&RevUnitVal));
				if(RevUnitVal!=NULL)
				{
					tc_strdup(RevUnitVal,&RevUnitValDup);
				}
				else
				{
					tc_strdup("--",&RevUnitValDup);
					printf("\n Revision Unit of Measure Value[t5_uom] is NULL..!!\n");fflush(stdout);
				}

				printf(" Part Details Start...!!\n");fflush(stdout);
				printf("[1] Part_No: [%s]\n",Part_No);fflush(stdout);
				printf("[2] Part_Rev: [%s]\n",Part_Rev);fflush(stdout);
				printf("[3] Part_Seq: [%s]\n",Part_Seq);fflush(stdout);
				printf("[4] Envelope_Dimension: [%s]\n",Env_DimDup);fflush(stdout);
				printf("[5] Weight: [%.3f]\n",Part_Weight);fflush(stdout);
				printf("[6] Material_Class: [%.3f]\n",Mat_ClasDup);fflush(stdout);
				printf("[7] Spare_Criteria: [%s]\n",Spare_CtrDup);fflush(stdout);
				printf("[8] Part_Type: [%s]\n",Part_TypeDup);fflush(stdout);
				printf("[9] Material_Drawing: [%s]\n",Mat_DrwDup);fflush(stdout);
				printf("[10] Master_UOM_Tag: [%s]\n",MstrUnitTagDup);fflush(stdout);
				printf("[11] Master_UOM_Value: [%s]\n",MstrUnitValDup);fflush(stdout);
				printf("[12] Revision_UOM_Value: [%s]\n",RevUnitValDup);fflush(stdout);
				printf(" Part Details End...!!\n");fflush(stdout);
		
				fprintf(fpOutput_file1,"%s,%s,%s,%s,%.3f,%s,%s,%s,%s,%s,%s,%s\n",Part_No,Part_Rev,Part_Seq,Env_DimDup,Part_Weight,Mat_ClasDup,Spare_CtrDup,Part_TypeDup,Mat_DrwDup,MstrUnitTagDup,MstrUnitValDup,RevUnitValDup);fflush(fpOutput_file1);
				
            }
            else
            {
				printf("\n Part Number is NULL..!!");fflush(stdout);
			}				
		}
	}
	fprintf(fpOutput_file1,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file1);
	fclose(fpOutput_file1);
	printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_BOMComp.c
* // ./linkitk -o tm_BOMComp tm_BOMComp.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BOMCompleteness/tm_BOMComp .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BOMCompleteness/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BOMCompleteness/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BOMCompleteness/SendEmail.sh .
* // ./tm_BOMComp -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -s=0 -e=100000
* // ./tm_BOMComp -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -s=0 -e=100000
*
***************************************************************************/