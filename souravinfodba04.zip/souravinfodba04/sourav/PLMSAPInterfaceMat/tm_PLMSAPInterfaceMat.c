/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP Interface
*  Description  :   User Services For Material loading in SAP 
*  File Name    :   tm_PLMSAPInterfaceMat.c
*  Created on   :   08th Aug, 2024
*  Usage        :   tm_PLMSAPInterfaceMat
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  
***************************************************************************/
				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tccore/iman_msg.h>

#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 401)
#define T5_WorkFlowHandlerErr1 (EMH_USER_error_base + 402)
#define T5_WorkFlowHandlerErr2 (EMH_USER_error_base + 403)
#define T5_WorkFlowHandlerESOErr (EMH_USER_error_base + 701)
#define T5_WorkFlowHandlerAnxErr (EMH_USER_error_base + 702)
#define MAX_LINE_LEN 1024
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_err 910001


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}



int tm_PLMSAPInterfaceServMat(void *retValue)
{
	printf("\n: Service: Start ---- tm_PLMSAPInterfaceServMat..!!\n");fflush(stdout);
	
	const char	*prog_name 	="tm_PLMSAPInterfaceServMat";
	
	int ifail = ITK_ok;
	int iFail = 0;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	
	char* DMLNo = NULL;
	char* PlantCode = NULL;
	char* ReqType = NULL;
	char* TrnsType = NULL;
	char* UserEmail = NULL;

	USERARG_get_string_argument(&DMLNo);
	USERARG_get_string_argument(&PlantCode);
	USERARG_get_string_argument(&ReqType);
	USERARG_get_string_argument(&TrnsType);
	USERARG_get_string_argument(&UserEmail);

	printf("\nDML No: [%s]",DMLNo);fflush(stdout);
	printf("\nPlant Code: [%s]",PlantCode);fflush(stdout);
	printf("\nRequest Type: [%s]",ReqType);fflush(stdout);
	printf("\nTransfer Type: [%s]",TrnsType);fflush(stdout);
	printf("\nUser Email:[%s]",UserEmail);fflush(stdout);
	
	
	//Implement your system command logic.
	tag_t tCtrlobj = NULLTAG;
	int n_entries = 4;
	int n_ctrlobj_found = 0;
	tag_t* tctrlobj_results = NULLTAG;
	char *t5user_inf1 = NULL;
	char *t5user_inf2 = NULL;
	char *t5user_inf3 = NULL;
	
	QRY_find2("Control Objects...",&tCtrlobj);
	printf("\n Return Value From Control Object Query API is --------> %d", iFail);fflush(stdout);
	if(tCtrlobj!=NULLTAG)
	{
	    printf("\n Control Object Query Found Successfully...");
	    char *cEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
	    char *cValues[4]  = {"PLMSAPInterface","PLMSAPIntFaceMAT","PLMSAPIntXFR","0"};
		QRY_execute(tCtrlobj, n_entries, cEntries, cValues, &n_ctrlobj_found, &tctrlobj_results);
	    printf("\n Return Value From Control Object Query Execute API is --------> %d", iFail);fflush(stdout);
		printf("\n No of Control Object Found --------> %d\n",n_ctrlobj_found);fflush(stdout);
	    if(n_ctrlobj_found>0)
	    {
				
			AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo1", &t5user_inf1);
			printf("\n User Information1 Value --------> %s\n",t5user_inf1);fflush(stdout);

			AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo2", &t5user_inf2);
			printf("\n User Information2 Value --------> %s\n",t5user_inf2);fflush(stdout);

            AOM_ask_value_string( tctrlobj_results[0], "t5_Userinfo3", &t5user_inf3);
			printf("\n User Information3 Value --------> %s\n",t5user_inf3);fflush(stdout);

		}
		else
		{
			printf("\n Sorry! No Control Object Found...\n");fflush(stdout);
		}
        if (tctrlobj_results)
	    {
			MEM_free(tctrlobj_results);
		}
	}
    char* SVRShellCommandLine = NULL;
	SVRShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
    printf("\n Shell Calling STARTED...");fflush(stdout);
	//tc_strcpy(SVRShellCommandLine,"/user/uaprodtrl/Sourav/tm_stdvc_svr_bom_report/Execution_Shell.sh");
	tc_strcpy(SVRShellCommandLine,t5user_inf1);
	tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,DMLNo);
    tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,PlantCode);
    tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,ReqType);
    tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,TrnsType);
    tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,UserEmail);
	printf("\n CommandLine: -------> [%s]",SVRShellCommandLine);fflush(stdout);
	system(SVRShellCommandLine);
	printf("\n Shell Called Ended..."); 	
	
	//printf("After returning Value\n");fflush(stdout);	
	printf("\n Service:End ---- tm_PLMSAPInterfaceServMat..!!\n");fflush(stdout);
	return ifail;	
	
}





extern int tm_PLMSAPInterfaceFuncMat(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int n_args = 5;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_STRING_TYPE;//DML number
	input_arg_type[1]=USERARG_STRING_TYPE;//Plant Code
	input_arg_type[2]=USERARG_STRING_TYPE;//Req Type
	input_arg_type[3]=USERARG_STRING_TYPE;//Transfer Type
	input_arg_type[4]=USERARG_STRING_TYPE;//UserEmail
	ret_value_type = USERARG_VOID_TYPE;
 	
	
	printf("\n Before registing ...tm_PLMSAPInterfaceServMat\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_PLMSAPInterfaceServMat",(USER_function_t)tm_PLMSAPInterfaceServMat,n_args,input_arg_type,ret_value_type);
	printf("\n After registing ...tm_PLMSAPInterfaceServMat\n");fflush(stdout);
	
		
	
	
	return ifail;
}

extern int tm_PLMSAPInterfaceMat_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	
   //Define Rule/Action handler here

	
    return ifail;
}


extern DLLAPI int tm_PLMSAPInterfaceMat_register_callbacks ()
{	
    int ifail    = ITK_ok;
	//printf("\tm_PLMSAPInterfaceMat_register_callbacks:Before registoring....");  
    ifail=CUSTOM_register_exit ( "tm_PLMSAPInterfaceMat", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_PLMSAPInterfaceMat_register_method);
	//printf("\tm_PLMSAPInterfaceMat_register_callbacks: After registoring....");
	
	//printf("\n Started- Registering user service function tm_PLMSAPInterfaceFuncMat...");
	ifail=CUSTOM_register_exit ( "tm_PLMSAPInterfaceMat", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_PLMSAPInterfaceFuncMat);//user service not use
	//printf("\n Completed- Registering user service function tm_PLMSAPInterfaceFuncMat...");
	
  return ( ITK_ok );
}

