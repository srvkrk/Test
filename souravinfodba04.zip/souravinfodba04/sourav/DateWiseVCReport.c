/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2023  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: ModuleInfoReport.c
* Description	: This Utility Mainly Used For AutoLogin in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tc/folder.h>

#define MAX_LINE_LEN 10024
#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
FILE *Report = NULL;
int ctr=0;

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

static int report_error(char *file, int line, char *call, int status,
    logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        const int
            *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
        if (n_errors > 0)
        {
            ECHO("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            ECHO("\n%s\n", error_message_string);
        }

        ECHO("error %d at line %d in %s\n", status, line, file);
        ECHO("%s\n", call);
        if (exit_on_error)
        {
            ECHO("%s", "Exiting program!\n");
            exit (status);
        }
    }
    return status;
}


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

// Function to check if a character is printable
int isPrintable(char ch) {
    return ch >= 32 && ch <= 126;
}

// Function to remove non-ASCII, non-printable, and special characters from string
void removeNonAsciiChars(char *str) {
    int i = 0;
    char ch;
    while ((ch = str[i]) != '\0') {
        if (!isPrintable(ch))
        {
            str[i] = ' ';
        }
        i++;
    }
}



int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y_%H_%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%m_%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}


void tm_find_Prev_Official_Rev(char	*req_item,tag_t t_currentRevision, tag_t* t_previousRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		ii					=	0;
	int		n_tags_found		=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);

	if(Item_count > 0)
	{
		RevFlag		=	0;
		PreRevFlag	=	0;

		for(ii=Item_count-1;ii>=0;ii--)
		{
			RevOnly		=	NULL;
			PreRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				RevOnly		= strtok( Part_Rev_copy, ";" );
				PreRevOnly	= strtok( Part_rev_Id, ";" );
				printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				if(tc_strcmp(RevOnly,PreRevOnly)!=0)
				{
					PreRevFlag = 1;

				}
				if(PreRevFlag == 1)
				{
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_prev_rev_Id));
					printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
					*t_previousRevision	=	rev_list[ii];
					break;
				}
			}
		}
		if(PreRevFlag == 0)
		{
			*t_previousRevision	=	t_currentRevision;
		}
	}
}


void tm_find_DR4_Rev(tag_t t_currentRevision, tag_t* t_first_DR4_Revision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		iii					=	0;
	int		n_tags_found		=	0;

	
	
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;
	char	*DR_Part_value	=	NULL;
	char	*Part_DR_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	master		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	
	
	ITKCALL(AOM_ask_value_string(t_currentRevision,"t5_PartStatus",&DR_Part_value));
	printf("\n DR_Part_value %s\n",DR_Part_value);fflush(stdout);
	
	ITEM_ask_item_of_rev(t_currentRevision, &master);
	
	ITKCALL(ITEM_list_all_revs (master, &Item_count, &rev_list));
	
	if(Item_count > 0)
	{
		for(iii=0;iii<Item_count;iii++)
		{
			
			AOM_ask_value_string(rev_list[iii],"t5_PartStatus",&Part_DR_Id);
			
			if(tc_strcmp(Part_DR_Id,"DR4")==0)
			{
				RevFlag = 1;
				
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			
		
		if(RevFlag == 1)
		{
			AOM_ask_value_string(rev_list[iii],"item_revision_id",&Part_prev_rev_Id);
			printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
			*t_first_DR4_Revision	=	rev_list[iii];
			break;
		}
		}
		
	}
}


int getClsValueFrmICSTag( tag_t  IcsClsTag , char *clsKeyAtrrId,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   Ptype_name[TCTYPE_name_size_c+1];
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,Ptype_name));
	//printf("\n getClsValueFrmICSTag IcsClsTag  Ptype_name :: %s\n", Ptype_name); fflush(stdout);

	
	//Create Relation between Intent and Vehicle.
	int partRevCnt=0;
                tag_t* partRevTagObjs = NULLTAG;
                tag_t partRevTag = NULLTAG;
	if(IcsClsTag!=NULLTAG)
	{
		char * 	theClassId =NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
			char keyPrefix[10];
			tc_strcpy(keyPrefix,"-");
			tc_strcat(keyPrefix,clsKeyAtrrId);
			printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char * 	key_lov_name;
			int  	options;
			int i;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites ;
			theICOTag=IcsClsTag;
			//CALLAPI(ICS_ask_attribute_value(theICOTag,"8066",&AttrKeyValue))
			if(ICS_ask_attribute_value(IcsClsTag,clsKeyAtrrId,&AttrKeyValue))
			
			printf("\n AttrKeyValue=%s key_lov_id=%s",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
 				for(i=0;i<n_lov_entries;i++)								
				{
					printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
					
					if(tc_strcasecmp(AttrKeyValue,lov_keys[i])==0)
					{
						printf("\n Mascot lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
						
						if(lov_values[i])
						{
							tc_strdup(lov_values[i],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						break;
					}
					
					
					
				} 
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}						
			printf("\n RetAttrVal=%s ",RetAttrVal); fflush(stdout);
			

	return ITK_ok;

}


int ITK_user_main(int argc, char* argv[])
{
    char* cError = NULL;
	char*  F_date = ITK_ask_cli_argument("-F=");
	char*  T_date = ITK_ask_cli_argument("-T=");
	
	char*   From_date = NULL;
	char*   To_date = NULL;
	int ifail = ITK_ok;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	if(ITK_auto_login() == ITK_ok)	
	{
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Data[100] = "";

	//	Report=fopen("/user/cvprod/suryansh/DateWiseVehicleReport/VCDateWiseReport.xml","w");
		Report=fopen("/tmp/VCDateWiseReport.xml","w");
		if (Report == NULL)
		{
			printf("ERROR: XML Cannot open File\n");
			return -1;
		}
		else
		{
			printf("XML File opened successfully.\n");
		}

		strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
		write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		write2xml(Report,"\n<PLMXML date=\"");
		write2xml(Report,Data);
		write2xml(Report,"\" >\n");

		tag_t itemrev = NULLTAG;
		int  rows = 0, i = 0;
		tag_t* itemobj_results = NULLTAG;
		int FieldCount = 2;
		tag_t ItemObjs = NULLTAG;
		tag_t TagClassId = NULLTAG;
		char *ObjClassName=NULL;
		tag_t GCI_relation_tag = NULLTAG;
		tag_t Vc_spec_relation_type = NULLTAG;
		
		//char *FieldList[2]  = {"Part Type","Type"};
		char **FieldVaule = (char **) MEM_alloc(50 * sizeof(char *));
		
		From_date = (char *) MEM_alloc(100);
		To_date = (char *) MEM_alloc(100);
		
		
		
		tc_strcpy(From_date,"");
		tc_strcpy(From_date,F_date);
		tc_strcat(From_date," 00:00");
		
		
		tc_strcpy(To_date,"");
		tc_strcpy(To_date,T_date);
		tc_strcat(To_date," 23:59");
		printf("\n\n\n\n\nFrom date [%s] \n To Date [%s]",From_date,To_date);fflush(stdout);
		
		
		char    	*FieldList[4]	= {"ID","Name","date_released_after","date_released_before"};	
		//char		**qryvalue= (char **) MEM_alloc(500 * sizeof(char *));
		ITK_CALL(QRY_find("ERCDMLReleased",&ItemObjs));
		
		
	
		if (ItemObjs)
		{
			printf("\nFound Query_for_Report\n");fflush(stdout);
		}
		else
		{
			printf("\n-----------Not Found Query_for_Module_Info_Report\n");fflush(stdout);
		}

		//FieldVaule[0] = "M";
		//FieldVaule[1] = "Design Revision";
		printf("Before Query Execute"); fflush(stdout);
		//if (QRY_execute(ItemObjs, FieldCount, FieldList, FieldVaule, &rows, &itemobj_results) != ITK_ok) PrintErrorStack();
		
		FieldVaule[0]="*";
		FieldVaule[1]="T5_LcsErcRlzd"; //ERC Released
		FieldVaule[2]=From_date;
		FieldVaule[3]=To_date;
		ITK_CALL(QRY_execute(ItemObjs,4, FieldList, FieldVaule, &rows, &itemobj_results));
		if (rows != 0)
		{
			printf("\n Total DML : %d",rows); fflush(stdout);
			for(i=0;i<rows;i++)
			{
				printf("\n entering into loop of i");
				itemrev=itemobj_results[i];
				
			if(POM_class_of_instance(itemrev,&TagClassId));
			if(POM_name_of_class(TagClassId,&ObjClassName));
			if (tc_strcmp(ObjClassName,"ChangeRequestRevision")==0)
			{
				
				char*  DML_Release_Type =NULL;
				char*  DML_DR_Status =NULL;
				char*  DML_no =NULL;
				char*  DML_synopsis =NULL;
				char*  DML_reasoncode =NULL;
				char*  DML_Owner =NULL;
				char*	dmlRelDate	=NULL;
				char*	dmlProj	=NULL;
				char*	dmlLC	=NULL;
				char*	DML_from_to	=NULL;
				char*	proj_des=NULL;
				char*	ERC_BusiUt=NULL;
				char*	Plant=NULL;
				int p,cnt = 0;
				tag_t *Dml_tasks= NULLTAG;
				tag_t DMLToTaskReln = NULLTAG;
				tag_t project = NULLTAG;
			//	char*	dml_type_dup					= NULL;
				char*	first_DR4_rev=	NULL;
				char*	first_DR4_rev_f=	NULL;
				char*	first_DR4_rev_f1=	NULL;
				char*	prev_rev_DR_status=	NULL;
				char*	prev_rev_DR_status_f=	NULL;
				char*	prev_rev_DR_status_f1=	NULL;
				char*	prev_rev_DR_status_dup=	NULL;
				char*	prev_rev_DR_status_dup_f=	NULL;
				char*	prev_rev_DR_status_dup_f1=	NULL;
				char*	first_DR4_rev_dup=	NULL;
				char*	first_DR4_rev_dup_f=	NULL;
				char*	first_DR4_rev_dup_f1=	NULL;
				
				prev_rev_DR_status_dup_f=(char *)MEM_alloc(500);
				first_DR4_rev_dup_f=(char *)MEM_alloc(500);
				
				prev_rev_DR_status_dup_f1 = (char *) MEM_alloc(500);
				first_DR4_rev_dup_f1 = (char *) MEM_alloc(500);

				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_rlstype",&DML_Release_Type));
	
				//if((tc_strcmp(DML_Release_Type,"Veh")==0) || (tc_strcmp(DML_Release_Type,"XO")==0) || (tc_strcmp(DML_Release_Type,"CP")==0) || (tc_strcmp(DML_Release_Type,"VCMDU")==0))
				if((tc_strcmp(DML_Release_Type,"Vehicle Release")==0) || (tc_strcmp(DML_Release_Type,"Gate Maturation")==0))
				{
	
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_cDRstatus",&DML_DR_Status));
				ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&DML_no));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"object_name",&DML_synopsis));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_reason",&DML_reasoncode));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"date_released",&dmlRelDate));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_cprojectcode",&dmlProj));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"release_status_list",&dmlLC));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_PlntToPlnt",&DML_from_to));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_user",&DML_Owner));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_ERCBusiUt",&ERC_BusiUt));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_TargetPlant",&Plant));
				
				
				printf("\n\t DML_Release_Type is :%s",DML_Release_Type);fflush(stdout);
				printf("\n\t DML_DR_Status is :%s",DML_DR_Status);fflush(stdout);
				printf("\n\t DML_no is :%s",DML_no);fflush(stdout);
				printf("\n\t DML_synopsis is :%s",DML_synopsis);fflush(stdout);
				printf("\n\t DML_reasoncode is :%s",DML_reasoncode);fflush(stdout);
				printf("\n\t DML_Release_date is :%s",dmlRelDate);fflush(stdout);
				printf("\n\t DML_Project is :%s",dmlProj);fflush(stdout);
				printf("\n\t DML_lifecycle_state is :%s",dmlLC);fflush(stdout);
				printf("\n\t DML_from_to is :%s",DML_from_to);fflush(stdout);
				printf("\n\t DML_Owner is :%s",DML_Owner);fflush(stdout);
				printf("\n\t Business Unit is :%s",ERC_BusiUt);fflush(stdout);
				printf("\n\t Plant is :%s",Plant);fflush(stdout);
				
	
				ITK_CALL(PROJ_find(dmlProj,&project));
				ITK_CALL(AOM_UIF_ask_value(project,"project_desc",&proj_des));
				printf("\n\t Project Description :%s",proj_des);fflush(stdout);
				
				GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskReln);
				GRM_find_relation_type("T5_GCI_relation", &GCI_relation_tag);
				GRM_find_relation_type("T5_VCSpec",&Vc_spec_relation_type);
				
				GRM_list_secondary_objects_only(itemrev,DMLToTaskReln,&cnt,&Dml_tasks);
				printf("\n Now cnt: %d\n",cnt);fflush(stdout);
				
				
			if (cnt>0)
			{
			for (p=0;p<cnt;p++)
			{
				int k,partcnt,change_partcnt,r =0;
				tag_t *PartsTag= NULLTAG;
				tag_t *change_PartsTag= NULLTAG;
				tag_t PartTag= NULLTAG;
				tag_t change_AssyTag= NULLTAG;
				char*	object_type	=NULL;
			//	char*	Prt_object_type =NULL;
				
				AOM_ask_value_string(Dml_tasks[p],"object_type",&object_type);
				printf("\n object_type is :%s\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
						
			if(tc_strcmp(DML_Release_Type,"Gate Maturation")==0)
			{
				AOM_ask_value_tags(Dml_tasks[p],"CMReferences",&change_partcnt,&change_PartsTag);
				printf("\n Now change_partcnt:%d\n",change_partcnt);fflush(stdout);
				if(change_partcnt> 0)
				{
					for(r=0;r<change_partcnt;r++)
					{
						char*  item_id_f =NULL;
						char*  item_id_f1 =NULL;
						char*  parttype =NULL;
						char*  parttype_f =NULL;
						char*  item_revision_id_f =NULL;
						char*  item_revision_id_f1 =NULL;
						char*  DR_status_f =NULL;
						char*  DR_status_f_Dup =NULL;
						char*  DR_status_f1 =NULL;
						char*  desc_f =NULL;
						char*  desc_f1 =NULL;
						char*  color_ind_f =NULL;
						char*  color_ind_f1 =NULL;
						char*  platform_f =NULL;
						char*  platform_f_Dup =NULL;
						char*  platform_f1 =NULL;
						char*  platform_f1_Dup =NULL;
						char*  rolledupwt_f =NULL;
						char*  rolledupwt_f1 =NULL;
						char*  t5_BOMCompl_f =NULL;
						char*  t5_BOMCompl_f1 =NULL;
						char*  DR_status_f1_Dup =NULL;
						
						tag_t prevoffRev_tag_f= NULLTAG;
						tag_t prevoffRev_tag_f1= NULLTAG;
						tag_t DR4Rev_tag_f= NULLTAG;
						tag_t DR4Rev_tag_f1= NULLTAG;
						tag_t master_f= NULLTAG;
						tag_t master_f1= NULLTAG;
						tag_t ClsObj_f= NULLTAG;
						tag_t ClsObj_f1= NULLTAG;
						tag_t *ClsObjTag_f = NULLTAG;
						tag_t *ClsObjTag_f1 = NULLTAG;
						tag_t iteamrev2 = NULLTAG;
						
						int DVLOcnt_f = 0;
						int vcspec_count_f = 0;
						int DVLOcnt_f1 = 0;
						int vcspec_count_f1 = 0;
						int cnt_f = 0;
						int cnt_f1 = 0;
						tag_t *DVLOtags_f= NULLTAG;
						tag_t *Vc_specObjects_f1= NULLTAG;
						tag_t *Vc_specObjects_f= NULLTAG;
						tag_t *DVLOtags_f1= NULLTAG;
						
						char*	DVLO_Name_f =NULL;
						char*	DVLO_Name_f1 =NULL;
						char*	DVLO_Name_dup_f =NULL;
						char*	DVLO_Name_dup_f1 =NULL;
						int		demerit_score_f =0;
						int		demerit_score_f1 =0;
						int 	demerit_score_rating_f	=0;
						int 	demerit_score_rating_f1	=0;
						double	geometry_conf_index_f	;
						double	geometry_conf_index_f1	;
						tag_t 	DVLOtag_f	=NULLTAG;
						tag_t 	DVLOtag_f1	=NULLTAG;
						char* demerit_score_s_f;
						char* demerit_score_s_f1;
						char* demerit_score_s_dup_f =NULL;
						char* demerit_score_s_dup_f1 =NULL;
						char* demerit_score_rating_s_f;
						char* demerit_score_rating_s_f1;
						char* demerit_score_rating_s_dup_f =NULL;
						char* demerit_score_rating_s_dup_f1 =NULL;
						char* geometry_conf_index_s_f;
						char* geometry_conf_index_s_f1;
						char* geometry_conf_index_s_dup_f =NULL;
						char* geometry_conf_index_s_dup_f1 =NULL;
						int ri,rii,ti,tii =0;
						demerit_score_s_f=(char *)MEM_alloc(100);
						demerit_score_s_f1=(char *)MEM_alloc(100);
						demerit_score_s_dup_f=(char *)MEM_alloc(100);
						demerit_score_s_dup_f1=(char *)MEM_alloc(100);
						demerit_score_rating_s_f=(char *)MEM_alloc(100);
						demerit_score_rating_s_f1=(char *)MEM_alloc(100);
						demerit_score_rating_s_dup_f=(char *)MEM_alloc(100);
						demerit_score_rating_s_dup_f1=(char *)MEM_alloc(100);
						geometry_conf_index_s_f=(char *)MEM_alloc(100);
						geometry_conf_index_s_f1=(char *)MEM_alloc(100);
						geometry_conf_index_s_dup_f=(char *)MEM_alloc(100);
						geometry_conf_index_s_dup_f1=(char *)MEM_alloc(100);
						DVLO_Name_dup_f=(char *)MEM_alloc(100);
						DVLO_Name_dup_f1=(char *)MEM_alloc(100);
						char  *Prt_object_type =NULL;
						char *getESOAttrVal_id_f1 = NULL;
						char *getESOAttrVal_id_f = NULL;
						char *getESOAttrVal_f1= NULL;
						char *getESOAttrVal_f= NULL;
						char *getProduct_line_id_f1= NULL;
						char *getProduct_line_id_f= NULL;
						char *getProduct_line_f1= NULL;
						char *getProduct_line_f= NULL;
						char *getEmsNorms_id_f1= NULL;
						char *getEmsNorms_id_f= NULL;
						char *getEmsNorms_f1= NULL;
						char *getEmsNorms_f= NULL;
						char *getVehicle_class_id_f1= NULL;
						char *getVehicle_class_id_f= NULL;
						char *getVehicle_class_f1= NULL;
						char *getVehicle_class_f= NULL;
						char *vcspec_item_id_f1= NULL;
						char *vcspec_item_id_f= NULL;
						char *vcclass_f1= NULL;
						char *vcclass_f= NULL;

						change_AssyTag=change_PartsTag[r];
						AOM_ask_value_string(change_AssyTag,"object_type",&Prt_object_type);
						printf("\n for CM refrences object_type is :%s \n",Prt_object_type);fflush(stdout);
					if(tc_strcmp(Prt_object_type,"Folder")==0)
					{
							char* FldrName =NULL;
							AOM_ask_value_string(change_AssyTag,"object_name",&FldrName);
							printf("\n for FldrName is:: %s \n", FldrName);fflush(stdout);
							if(tc_strcmp(FldrName,"Parts For Gate Maturation")==0)
							{
								printf("\n Inside folder found \n");fflush(stdout);
								int FlderSize=0;
								if(FL_ask_size(change_AssyTag,&FlderSize));
								printf("\n FlderSize is:   %d \n",FlderSize);fflush(stdout);
								int FlderObjCount=0;
								tag_t* FolderObj_tag=NULL;
								if(FL_ask_references(change_AssyTag,FL_fsc_by_date_modified,&FlderObjCount,&FolderObj_tag));
								printf("\n  FlderObjCount is..:   %d \n",FlderObjCount);fflush(stdout);
								if(FlderObjCount>0)
								{
									int fld=0;
									for (fld=0;fld<FlderObjCount;fld++)
									{
										iteamrev2 = FolderObj_tag[fld];
										
										ITK_CALL(AOM_ask_value_string(iteamrev2, "t5_PartType", &parttype_f)) ;
										printf ( "\nPart type_f : [%s]", parttype_f );fflush(stdout);
									if((tc_strcmp(parttype_f,"V")==0) || (tc_strcmp(parttype_f,"VCCR")==0) || (tc_strcmp(parttype_f,"VC")==0))
									{
										AOM_ask_value_string(iteamrev2,"item_id",&item_id_f);
										AOM_ask_value_string(iteamrev2,"item_revision_id",&item_revision_id_f);
										AOM_ask_value_string(iteamrev2,"t5_PartStatus",&DR_status_f);
										
										if(tc_strlen(DR_status_f)>0)
										{
											tc_strdup(DR_status_f,&DR_status_f_Dup);
										}
										
										else
										{
											tc_strdup("NA",&DR_status_f_Dup);
											printf("\n DR ST is  NULL..!!");fflush(stdout);
										}
										
										AOM_ask_value_string(iteamrev2,"t5_ColourInd",&color_ind_f);
										AOM_ask_value_string(iteamrev2,"object_desc",&desc_f);
										AOM_ask_value_string(iteamrev2,"t5_Platform",&platform_f);
										AOM_ask_value_string(iteamrev2,"t5_RolledupWt",&rolledupwt_f);
										AOM_ask_value_string(iteamrev2,"t5_BOMCmpl",&t5_BOMCompl_f);
										
										printf("\n item_id  is :%s\n",item_id_f);	fflush(stdout);
										printf("\n Revision_id  is :%s\n",item_revision_id_f);fflush(stdout);
										printf("\n DR_status is :%s\n",DR_status_f);fflush(stdout);
										printf("\n color_ind :%s\n",color_ind_f);fflush(stdout);
										printf("\n object_desc :%s\n",desc_f);fflush(stdout);
										printf("\n Platform is :%s\n",platform_f);fflush(stdout);
										printf("\n Rolled_UP_weight is :%s\n",rolledupwt_f);fflush(stdout);
										printf("\n BOM_Completeness is :%s\n",t5_BOMCompl_f);fflush(stdout);
										
										if(tc_strlen(platform_f)>0)
										{
											tc_strdup(platform_f,&platform_f_Dup);
										}
										
										else
										{
											tc_strdup("NA",&platform_f_Dup);
											printf("\n platform_f_Dup is  NULL..!!");fflush(stdout);
										}
										
								if (Vc_spec_relation_type!=NULLTAG)
								{
									GRM_list_secondary_objects_only(iteamrev2, Vc_spec_relation_type, &vcspec_count_f, &Vc_specObjects_f);
									printf("\n tech spec_f count is %d",vcspec_count_f);fflush(stdout);
										if(vcspec_count_f>0)
										{
											for(tii=0;tii<vcspec_count_f;tii++)
											{
											//	Vc_specObject = Vc_specObjects[t];
												AOM_ask_value_string(Vc_specObjects_f[tii],"item_id",&vcspec_item_id_f);
												printf("\nvcspec_item_id_f item is.......%s",vcspec_item_id_f);fflush(stdout);
												
												AOM_ask_value_string(Vc_specObjects_f[tii],"t5_VCClassName",&vcclass_f);
												printf("\nvcclass_f is.......%s",vcclass_f);fflush(stdout);
												
											if(tc_strlen(vcclass_f)>0)
											{
											//	tc_strdup(vcclass,&platform_Dup);
												
												getESOAttrVal_id_f=(char *) MEM_alloc(400);
												getProduct_line_id_f=(char *) MEM_alloc(400);
												getEmsNorms_id_f=(char *) MEM_alloc(400);
												getVehicle_class_id_f=(char *) MEM_alloc(400);

												if(tc_strcmp(vcclass_f,"MCV")==0)
												{
													printf("\n Entering for MCV_f \n ");fflush(stdout);
													tc_strcpy(getESOAttrVal_id_f,"5103");
													tc_strcpy(getProduct_line_id_f,"6240");
													tc_strcpy(getEmsNorms_id_f,"5036");
													tc_strcpy(getVehicle_class_id_f,"5052");
													
													printf("\n getESOAttrVal_id_f MCV[%s] !!",getESOAttrVal_id_f); fflush(stdout);
													printf("\n getProduct_line_id_f MCV[%s] !!",getProduct_line_id_f); fflush(stdout);
													printf("\n getEmsNorms_id_f MCV[%s] !!",getEmsNorms_id_f); fflush(stdout);
													printf("\n getVehicle_class_id_f MCV[%s] !!",getVehicle_class_id_f); fflush(stdout);
												}
												else if(tc_strcmp(vcclass_f,"HCV")==0)
												{
													printf("\n Entering for HCV_f \n ");fflush(stdout);
													tc_strcpy(getESOAttrVal_id_f,"6103");
													tc_strcpy(getProduct_line_id_f,"6240");
													tc_strcpy(getEmsNorms_id_f,"6036");
													tc_strcpy(getVehicle_class_id_f,"6052");
													
													printf("\n getESOAttrVal_id_f[%s] HCV !!",getESOAttrVal_id_f); fflush(stdout);
													printf("\n getProduct_line_id_f[%s] HCV !!",getProduct_line_id_f); fflush(stdout);
													printf("\n getEmsNorms_id_f[%s] HCV !!",getEmsNorms_id_f); fflush(stdout);
													printf("\n getVehicle_class_id_f[%s] HCV !!",getVehicle_class_id_f); fflush(stdout);
													
												}
												
												else if(tc_strcmp(vcclass_f,"LCV")==0)
												{
													printf("\n Entering for LCV_f \n ");fflush(stdout);
													tc_strcpy(getESOAttrVal_id_f,"4103");
													tc_strcpy(getProduct_line_id_f,"6240");
													tc_strcpy(getEmsNorms_id_f,"4036");
													tc_strcpy(getVehicle_class_id_f,"4222");
													
													printf("\n getESOAttrVal_id_f[%s] LCV !!",getESOAttrVal_id_f); fflush(stdout);
													printf("\n getProduct_line_id_f[%s] LCV !!",getProduct_line_id_f); fflush(stdout);
													printf("\n getEmsNorms_id_f[%s] LCV !!",getEmsNorms_id_f); fflush(stdout);
													printf("\n getVehicle_class_id_f[%s] LCV !!",getVehicle_class_id_f); fflush(stdout);
													
												}
												else if(tc_strcmp(vcclass_f,"LMV")==0)
												{
													printf("\n Entering for LMV_f \n ");fflush(stdout);
													tc_strcpy(getESOAttrVal_id_f,"2103");
													tc_strcpy(getProduct_line_id_f,"6240");
													tc_strcpy(getEmsNorms_id_f,"2036");
													tc_strcpy(getVehicle_class_id_f,"2222");
													
													printf("\n getESOAttrVal_id_f[%s] LMV !!",getESOAttrVal_id_f); fflush(stdout);
													printf("\n getProduct_line_id_f[%s] LMV !!",getProduct_line_id_f); fflush(stdout);
													printf("\n getEmsNorms_id_f[%s] LMV !!",getEmsNorms_id_f); fflush(stdout);
													printf("\n getVehicle_class_id_f[%s] LMV !!",getVehicle_class_id_f); fflush(stdout);
													
												}
												else if(tc_strcmp(vcclass_f,"BUS")==0)
												{
													printf("\n Entering for BUS_f \n ");fflush(stdout);
													tc_strcpy(getESOAttrVal_id_f,"7103");
													tc_strcpy(getProduct_line_id_f,"6240");
													tc_strcpy(getEmsNorms_id_f,"7036");
													tc_strcpy(getVehicle_class_id_f,"7222");
													
													printf("\n getESOAttrVal_id_f[%s] BUS !!",getESOAttrVal_id_f); fflush(stdout);
													printf("\n getProduct_line_id_f[%s] BUS !!",getProduct_line_id_f); fflush(stdout);
													printf("\n getEmsNorms_id_f[%s] BUS !!",getEmsNorms_id_f); fflush(stdout);
													printf("\n getVehicle_class_id_f[%s] BUS !!",getVehicle_class_id_f); fflush(stdout);
													
												}
											/*	else if(tc_strstr(vcclass_f,"MUV")!= NULL)
												{
													printf("\n Entering for MUV \n ");
													tc_strcpy(getESOAttrVal_id,"4103");
													tc_strcpy(getProduct_line_id,"6240");
													tc_strcpy(getEmsNorms_id,"4036");
													tc_strcpy(getVehicle_class_id,"4052");
													
													printf("\n getESOAttrVal_id[%s] MUV !!",getESOAttrVal_id); fflush(stdout);
													printf("\n getProduct_line_id[%s] MUV !!",getProduct_line_id); fflush(stdout);
													printf("\n getEmsNorms_id[%s] MUV !!",getEmsNorms_id); fflush(stdout);
													printf("\n getVehicle_class_id[%s] MUV !!",getVehicle_class_id); fflush(stdout);
													
												}*/
												else if(tc_strcmp(vcclass_f,"UV_VAN")==0)
												{
													printf("\n Entering for UV_VAN_f \n ");fflush(stdout);
													tc_strcpy(getESOAttrVal_id_f,"10103");
													tc_strcpy(getProduct_line_id_f,"6240");
													tc_strcpy(getEmsNorms_id_f,"10036");
													tc_strcpy(getVehicle_class_id_f,"10222");
													
													printf("\n getESOAttrVal_id_f[%s] UV_VAN !!",getESOAttrVal_id_f); fflush(stdout);
													printf("\n getProduct_line_id_f[%s] UV_VAN !!",getProduct_line_id_f); fflush(stdout);
													printf("\n getEmsNorms_id_f[%s] UV_VAN !!",getEmsNorms_id_f); fflush(stdout);
													printf("\n getVehicle_class_id_f[%s] UV_VAN !!",getVehicle_class_id_f); fflush(stdout);
													
												}
												else if(tc_strcmp(vcclass_f,"ICV")==0)
												{
													printf("\n Entering for ICV_f \n ");fflush(stdout);
													tc_strcpy(getESOAttrVal_id_f,"3103");
													tc_strcpy(getProduct_line_id_f,"6240");
													tc_strcpy(getEmsNorms_id_f,"3036");
													tc_strcpy(getVehicle_class_id_f,"3222");
													
													printf("\n getESOAttrVal_id_f[%s] ICV !!",getESOAttrVal_id_f); fflush(stdout);
													printf("\n getProduct_line_id_f[%s] ICV !!",getProduct_line_id_f); fflush(stdout);
													printf("\n getEmsNorms_id_f[%s] ICV !!",getEmsNorms_id_f); fflush(stdout);
													printf("\n getVehicle_class_id_f[%s] ICV !!",getVehicle_class_id_f); fflush(stdout);
													
												}
												else{
													printf("\n Vc class is not mactching with mentioned value");fflush(stdout);
												}
												
												
											}
											else
											{
											tc_strdup("NA",&vcclass_f);
											printf("\n Vehicle class is  NULL..in f!!");fflush(stdout);
											}
												
											}
											ITEM_ask_item_of_rev(iteamrev2, &master_f);
											if(master_f !=NULLTAG)
											{
											ITK_CALL(AOM_ask_value_tags(master_f,"IMAN_classification",&cnt_f,&ClsObjTag_f));
											printf("\n classified object count_f[%d]",cnt_f); fflush(stdout);
											if(cnt_f>0)
											{
												getESOAttrVal_f=(char *)MEM_alloc(500);
												getProduct_line_f=(char *)MEM_alloc(500);
												getEmsNorms_f=(char *)MEM_alloc(500);
												getVehicle_class_f=(char *)MEM_alloc(500);

											ClsObj_f=*ClsObjTag_f;
											ITK_CALL(getClsValueFrmICSTag(ClsObj_f ,getESOAttrVal_id_f,&getESOAttrVal_f));
											ITK_CALL(getClsValueFrmICSTag(ClsObj_f ,getProduct_line_id_f,&getProduct_line_f));
											ITK_CALL(getClsValueFrmICSTag(ClsObj_f ,getEmsNorms_id_f,&getEmsNorms_f));
											ITK_CALL(getClsValueFrmICSTag(ClsObj_f ,getVehicle_class_id_f,&getVehicle_class_f));
											
											printf("\n getESOAttrVal_f[%s] !!",getESOAttrVal_f); fflush(stdout);
											printf("\n getProduct_line_f[%s] !!",getProduct_line_f); fflush(stdout);
											printf("\n getEmsNorms_f[%s] !!",getEmsNorms_f); fflush(stdout);
											printf("\n getVehicle_class_f[%s] !!",getVehicle_class_f); fflush(stdout);
											
											}
											else{
												printf("\n There is no classification vehicle in_f");fflush(stdout);
											}
											}
											
										}
										else
										{
											printf("\n There is no TechSpec attached with vehicle_f");fflush(stdout);
										}

								}	
										
								
								if(GCI_relation_tag!=NULLTAG)
								{
								GRM_list_secondary_objects_only(iteamrev2,GCI_relation_tag,&DVLOcnt_f,&DVLOtags_f);	
								printf("\n entering into DVLO relation under folder\n");
								if(DVLOcnt_f > 0)
								{

									for(ri=0;ri<DVLOcnt_f;ri++)
									{

										DVLOtag_f=DVLOtags_f[ri];
										AOM_ask_value_string(DVLOtag_f,"t5_DVLO_Name1",&DVLO_Name_f);
										AOM_ask_value_int(DVLOtag_f,"t5_demerit_score_v1",&demerit_score_f);
										AOM_ask_value_int(DVLOtag_f,"t5_demerit_score_rating_S1",&demerit_score_rating_f);
										AOM_ask_value_double(DVLOtag_f,"t5_geometry_conf_index_a1",&geometry_conf_index_f);
										
										printf("\n DVLO_Name[%s]",DVLO_Name_f); fflush(stdout);
										printf("\n demerit_score[%d]",demerit_score_f); fflush(stdout);
										printf("\n demerit_score_rating[%d]",demerit_score_rating_f); fflush(stdout);
										printf("\n geometry_conf_index count[%lf]",geometry_conf_index_f); fflush(stdout);
										
										sprintf(demerit_score_s_f,"%d",demerit_score_f);
										sprintf(demerit_score_rating_s_f,"%d",demerit_score_rating_f);
										sprintf(geometry_conf_index_s_f,"%lf",geometry_conf_index_f);
										
										tc_strcpy(DVLO_Name_dup_f,DVLO_Name_f);
										tc_strcpy(demerit_score_s_dup_f,demerit_score_s_f);
										tc_strcpy(demerit_score_rating_s_dup_f,demerit_score_rating_s_f);
										tc_strcpy(geometry_conf_index_s_dup_f,geometry_conf_index_s_f);
										
										printf("\n DVLO_Name_dup_f[%s]",DVLO_Name_dup_f); fflush(stdout);
										printf("\n demerit_score_s_dup_f[%s]",demerit_score_s_dup_f); fflush(stdout);
										printf("\n demerit_score_rating_s_dup_f[%s]",demerit_score_rating_s_dup_f); fflush(stdout);
										printf("\n geometry_conf_index_s_dup_f[%s]",geometry_conf_index_s_dup_f); fflush(stdout);
										
									}
								}
								else
								{
									tc_strcpy(DVLO_Name_dup_f,"NA");
									tc_strcpy(demerit_score_s_dup_f,"NA");
									tc_strcpy(demerit_score_rating_s_dup_f,"NA");
									tc_strcpy(geometry_conf_index_s_dup_f,"NA");
									
									printf("\n DVLO_Name_dup_f[%s]",DVLO_Name_dup_f); fflush(stdout);
									printf("\n demerit_score_s_dup_f[%s]",demerit_score_s_dup_f); fflush(stdout);
									printf("\n demerit_score_rating_s_dup_f[%s]",demerit_score_rating_s_dup_f); fflush(stdout);
									printf("\n geometry_conf_index_s_dup_f[%s]",geometry_conf_index_s_dup_f); fflush(stdout);
									
								}
								}
								
								
								tm_find_Prev_Official_Rev(item_id_f,iteamrev2,&prevoffRev_tag_f);
								if(prevoffRev_tag_f!=NULLTAG)
								{
								//	char	*prev_rev_DR_status=	NULL;

								printf("\nPrevious official Revision found \n");fflush(stdout);
								
								AOM_ask_value_string(prevoffRev_tag_f,"t5_PartStatus",&prev_rev_DR_status_f);
								printf("\n previous_revision_DR_status_f is  :%s\n",prev_rev_DR_status_f);fflush(stdout);
								
								tc_strcpy(prev_rev_DR_status_dup_f,prev_rev_DR_status_f);
								printf("\n prev_rev_DR_status_dup_f is  :%s\n",prev_rev_DR_status_dup_f);fflush(stdout);
								}
								
								else{
									
									printf("\n under else of previous_revision_DR_status is\n");fflush(stdout);
									tc_strcpy(prev_rev_DR_status_dup_f,"NA");
									printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status_dup_f);fflush(stdout);
								}
								
								tm_find_DR4_Rev(iteamrev2,&DR4Rev_tag_f);
										
								if(DR4Rev_tag_f!=NULLTAG)
								{
								//	char	*first_DR4_rev=	NULL;
									AOM_ask_value_string(DR4Rev_tag_f,"item_revision_id",&first_DR4_rev_f);
								//	printf("\n 11111111111first_rev_DR_id  :%s\n",first_DR4_rev);fflush(stdout);
									
									tc_strcpy(first_DR4_rev_dup_f,first_DR4_rev_f);
									printf("\n 2222222222first_DR4_rev_dup  :%s\n",first_DR4_rev_dup_f);fflush(stdout);
								}
								else{
									
									printf("\n under else of first DR4 revsiion");fflush(stdout);
									tc_strcpy(first_DR4_rev_dup_f,"NA");
									printf("\n first_DR4_rev_dup_f  :%s\n",first_DR4_rev_dup_f);fflush(stdout);
								}
								
						//	char *slNo=(char *) MEM_alloc(200);
						//	sprintf(slNo,"%d",(i+1));

							write2xml(Report,"<DesignRevision>\n");
						//	write2xml(Report,"<field key =\"slNo\">");
						//	write2xml(Report,slNo);
						//	write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"item_id\">");
							write2xml(Report,item_id_f);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"item_revision_id\">"); write2xml(Report,item_revision_id_f); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DR_status\">"); if(DR_status_f_Dup != NULL) write2xml(Report,DR_status_f_Dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"prev_rev_DR_status_dup\">"); if(prev_rev_DR_status_dup_f != NULL) write2xml(Report,prev_rev_DR_status_dup_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"first_DR4_rev_dup\">"); if(first_DR4_rev_dup_f != NULL) write2xml(Report,first_DR4_rev_dup_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"color_ind\">"); if(color_ind_f != NULL) write2xml(Report,color_ind_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"desc\">"); if(desc_f != NULL) write2xml(Report,desc_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"platform_Dup\">"); if(platform_f_Dup != NULL) write2xml(Report,platform_f_Dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"rolledupwt\">"); if(rolledupwt_f != NULL) write2xml(Report,rolledupwt_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DVLO_Name_dup\">"); if(DVLO_Name_dup_f != NULL) write2xml(Report,DVLO_Name_dup_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Plant\">"); if(Plant != NULL) write2xml(Report,Plant); else write2xml(Report,""); write2xml(Report,"</field>\n");
							
							write2xml(Report,"<field key =\"t5_BOMCompl\">"); if(t5_BOMCompl_f != NULL) write2xml(Report,t5_BOMCompl_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_Release_Type\">"); if(DML_Release_Type != NULL) write2xml(Report,DML_Release_Type); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_DR_Status\">"); if(DML_DR_Status != NULL) write2xml(Report,DML_DR_Status); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_no\">"); if(DML_no != NULL) write2xml(Report,DML_no); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_synopsis\">"); if(DML_synopsis != NULL) write2xml(Report,DML_synopsis); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_reasoncode\">"); if(DML_reasoncode != NULL) write2xml(Report,DML_reasoncode); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"dmlRelDate\">"); if(dmlRelDate != NULL) write2xml(Report,dmlRelDate); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"dmlLC\">"); if(dmlLC != NULL) write2xml(Report,dmlLC); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_from_to\">"); if(DML_from_to != NULL) write2xml(Report,DML_from_to); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"dmlProj\">"); if(dmlProj != NULL) write2xml(Report,dmlProj); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"proj_des\">"); if(proj_des != NULL) write2xml(Report,proj_des); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_Owner\">"); if(DML_Owner != NULL) write2xml(Report,DML_Owner); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"ERC_BusiUt\">"); if(ERC_BusiUt != NULL) write2xml(Report,ERC_BusiUt); else write2xml(Report,""); write2xml(Report,"</field>\n");
							
							write2xml(Report,"<field key =\"demerit_score_s_dup\">"); if(demerit_score_s_dup_f != NULL) write2xml(Report,demerit_score_s_dup_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"demerit_score_rating_s_dup\">"); if(demerit_score_rating_s_dup_f != NULL) write2xml(Report,demerit_score_rating_s_dup_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"geometry_conf_index_s_dup\">"); if(geometry_conf_index_s_dup_f != NULL) write2xml(Report,geometry_conf_index_s_dup_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"getESOAttrVal\">"); if(getESOAttrVal_f != NULL) write2xml(Report,getESOAttrVal_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"getProduct_line\">"); if(getProduct_line_f != NULL) write2xml(Report,getProduct_line_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"getEmsNorms\">"); if(getEmsNorms_f != NULL) write2xml(Report,getEmsNorms_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"getVehicle_class\">"); if(getVehicle_class_f != NULL) write2xml(Report,getVehicle_class_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
		
							write2xml(Report,"</DesignRevision>\n");
						}			
						}
						}
						}
					}
					else{
							ITK_CALL(AOM_ask_value_string(change_AssyTag, "t5_PartType", &parttype)) ;
							printf("\nPart type : [%s]", parttype );fflush(stdout);
							if((tc_strcmp(parttype,"V")==0) || (tc_strcmp(parttype,"VCCR")==0) || (tc_strcmp(parttype,"VC")==0))
							{
							
							AOM_ask_value_string(change_AssyTag,"item_id",&item_id_f1);
							AOM_ask_value_string(change_AssyTag,"item_revision_id",&item_revision_id_f1);
							AOM_ask_value_string(change_AssyTag,"t5_PartStatus",&DR_status_f1);

							if(tc_strlen(DR_status_f1)>0)
							{
								tc_strdup(DR_status_f1,&DR_status_f1_Dup);
							}
							
							else
							{
								tc_strdup("NA",&DR_status_f1_Dup);
								printf("\n DR ST is  NULL..!!");fflush(stdout);
							}
							AOM_ask_value_string(change_AssyTag,"t5_ColourInd",&color_ind_f1);
							AOM_ask_value_string(change_AssyTag,"object_desc",&desc_f1);
							AOM_ask_value_string(change_AssyTag,"t5_Platform",&platform_f1);
							AOM_ask_value_string(change_AssyTag,"t5_RolledupWt",&rolledupwt_f1);
							AOM_ask_value_string(change_AssyTag,"t5_BOMCmpl",&t5_BOMCompl_f1);
							
							printf("\n item_id_f1  is :%s\n",item_id_f1);fflush(stdout);
							printf("\n item_revision_id_f1  is :%s\n",item_revision_id_f1);fflush(stdout);
							printf("\n DR_status_f1 is :%s\n",DR_status_f1);fflush(stdout);
							printf("\n color_ind_f1 :%s\n",color_ind_f1);fflush(stdout);
							printf("\n desc_f1 :%s\n",desc_f1);fflush(stdout);
							printf("\n platform_f1 is :%s\n",platform_f1);fflush(stdout);
							printf("\n rolledupwt_f1 is :%s\n",rolledupwt_f1);fflush(stdout);
							printf("\n t5_BOMCompl_f1 is :%s\n",t5_BOMCompl_f1);fflush(stdout);
							
							if(tc_strlen(platform_f1)>0)
							{
								tc_strdup(platform_f1,&platform_f1_Dup);
							}
							
							else
							{
								tc_strdup("NA",&platform_f1_Dup);
								printf("\n platform_f1_Dup is  NULL..!!");fflush(stdout);
							}
						
					if (Vc_spec_relation_type!=NULLTAG)
					{
						GRM_list_secondary_objects_only(change_AssyTag, Vc_spec_relation_type, &vcspec_count_f1, &Vc_specObjects_f1);
						printf("\n tech spec_f1 count is %d",vcspec_count_f1);fflush(stdout);
					if(vcspec_count_f1>0)
					{
						for(ti=0;ti<vcspec_count_f1;ti++)
						{
						//	Vc_specObject = Vc_specObjects[t];
							AOM_ask_value_string(Vc_specObjects_f1[ti],"item_id",&vcspec_item_id_f1);
							printf("\nvcspec_item_id_f1 item is.......%s",vcspec_item_id_f1);fflush(stdout);
							
							AOM_ask_value_string(Vc_specObjects_f1[ti],"t5_VCClassName",&vcclass_f1);
							printf("\nvcclass_f1 is.......%s",vcclass_f1);fflush(stdout);
							
						if(tc_strlen(vcclass_f1)>0)
						{
						//	tc_strdup(vcclass,&platform_Dup);
							
							getESOAttrVal_id_f1=(char *) MEM_alloc(400);
							getProduct_line_id_f1=(char *) MEM_alloc(400);
							getEmsNorms_id_f1=(char *) MEM_alloc(400);
							getVehicle_class_id_f1=(char *) MEM_alloc(400);

							if(tc_strcmp(vcclass_f1,"MCV")==0)
							{
								printf("\n Entering for MCV_f1 \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id_f1,"5103");
								tc_strcpy(getProduct_line_id_f1,"6240");
								tc_strcpy(getEmsNorms_id_f1,"5036");
								tc_strcpy(getVehicle_class_id_f1,"5052");
								
								printf("\n getESOAttrVal_id_f1 MCV[%s] !!",getESOAttrVal_id_f1); fflush(stdout);
								printf("\n getProduct_line_id_f1 MCV[%s] !!",getProduct_line_id_f1); fflush(stdout);
								printf("\n getEmsNorms_id_f1 MCV[%s] !!",getEmsNorms_id_f1); fflush(stdout);
								printf("\n getVehicle_class_id_f1 MCV[%s] !!",getVehicle_class_id_f1); fflush(stdout);
							}
							else if(tc_strcmp(vcclass_f1,"HCV")==0)
							{
								printf("\n Entering for HCV_f1 \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id_f1,"6103");
								tc_strcpy(getProduct_line_id_f1,"6240");
								tc_strcpy(getEmsNorms_id_f1,"6036");
								tc_strcpy(getVehicle_class_id_f1,"6052");
								
								printf("\n getESOAttrVal_id_f1[%s] HCV !!",getESOAttrVal_id_f1); fflush(stdout);
								printf("\n getProduct_line_id_f1[%s] HCV !!",getProduct_line_id_f1); fflush(stdout);
								printf("\n getEmsNorms_id_f1[%s] HCV !!",getEmsNorms_id_f1); fflush(stdout);
								printf("\n getVehicle_class_id_f1[%s] HCV !!",getVehicle_class_id_f1); fflush(stdout);
								
							}
							
							else if(tc_strcmp(vcclass_f1,"LCV")==0)
							{
								printf("\n Entering for LCV_f1 \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id_f1,"4103");
								tc_strcpy(getProduct_line_id_f1,"6240");
								tc_strcpy(getEmsNorms_id_f1,"4036");
								tc_strcpy(getVehicle_class_id_f1,"4222");
								
								printf("\n getESOAttrVal_id_f1[%s] LCV !!",getESOAttrVal_id_f1); fflush(stdout);
								printf("\n getProduct_line_id_f1[%s] LCV !!",getProduct_line_id_f1); fflush(stdout);
								printf("\n getEmsNorms_id_f1[%s] LCV !!",getEmsNorms_id_f1); fflush(stdout);
								printf("\n getVehicle_class_id_f1[%s] LCV !!",getVehicle_class_id_f1); fflush(stdout);
								
							}
							else if(tc_strcmp(vcclass_f1,"LMV")==0)
							{
								printf("\n Entering for LMV_f1 \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id_f1,"2103");
								tc_strcpy(getProduct_line_id_f1,"6240");
								tc_strcpy(getEmsNorms_id_f1,"2036");
								tc_strcpy(getVehicle_class_id_f1,"2222");
								
								printf("\n getESOAttrVal_id_f1[%s] LMV !!",getESOAttrVal_id_f1); fflush(stdout);
								printf("\n getProduct_line_id_f1[%s] LMV !!",getProduct_line_id_f1); fflush(stdout);
								printf("\n getEmsNorms_id_f1[%s] LMV !!",getEmsNorms_id_f1); fflush(stdout);
								printf("\n getVehicle_class_id_f1[%s] LMV !!",getVehicle_class_id_f1); fflush(stdout);
								
							}
							else if(tc_strcmp(vcclass_f1,"BUS")==0)
							{
								printf("\n Entering for BUS_f1 \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id_f1,"7103");
								tc_strcpy(getProduct_line_id_f1,"6240");
								tc_strcpy(getEmsNorms_id_f1,"7036");
								tc_strcpy(getVehicle_class_id_f1,"7222");
								
								printf("\n getESOAttrVal_id_f1[%s] BUS !!",getESOAttrVal_id_f1); fflush(stdout);
								printf("\n getProduct_line_id_f1[%s] BUS !!",getProduct_line_id_f1); fflush(stdout);
								printf("\n getEmsNorms_id_f1[%s] BUS !!",getEmsNorms_id_f1); fflush(stdout);
								printf("\n getVehicle_class_id_f1[%s] BUS !!",getVehicle_class_id_f1); fflush(stdout);
								
							}
						/*	else if(tc_strstr(vcclass_f1,"MUV")!= NULL)
							{
								printf("\n Entering for MUV \n ");
								tc_strcpy(getESOAttrVal_id,"4103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"4036");
								tc_strcpy(getVehicle_class_id,"4052");
								
								printf("\n getESOAttrVal_id[%s] MUV !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id[%s] MUV !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id[%s] MUV !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id[%s] MUV !!",getVehicle_class_id); fflush(stdout);
								
							}*/
							else if(tc_strcmp(vcclass_f1,"UV_VAN")==0)
							{
								printf("\n Entering for UV_VAN_f1 \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id_f1,"10103");
								tc_strcpy(getProduct_line_id_f1,"6240");
								tc_strcpy(getEmsNorms_id_f1,"10036");
								tc_strcpy(getVehicle_class_id_f1,"10222");
								
								printf("\n getESOAttrVal_id_f1[%s] UV_VAN !!",getESOAttrVal_id_f1); fflush(stdout);
								printf("\n getProduct_line_id_f1[%s] UV_VAN !!",getProduct_line_id_f1); fflush(stdout);
								printf("\n getEmsNorms_id_f1[%s] UV_VAN !!",getEmsNorms_id_f1); fflush(stdout);
								printf("\n getVehicle_class_id_f1[%s] UV_VAN !!",getVehicle_class_id_f1); fflush(stdout);
								
							}
							else if(tc_strcmp(vcclass_f1,"ICV")==0)
							{
								printf("\n Entering for ICV_f1 \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id_f1,"3103");
								tc_strcpy(getProduct_line_id_f1,"6240");
								tc_strcpy(getEmsNorms_id_f1,"3036");
								tc_strcpy(getVehicle_class_id_f1,"3222");
								
								printf("\n getESOAttrVal_id_f1[%s] ICV !!",getESOAttrVal_id_f1); fflush(stdout);
								printf("\n getProduct_line_id_f1[%s] ICV !!",getProduct_line_id_f1); fflush(stdout);
								printf("\n getEmsNorms_id_f1[%s] ICV !!",getEmsNorms_id_f1); fflush(stdout);
								printf("\n getVehicle_class_id_f1[%s] ICV !!",getVehicle_class_id_f1); fflush(stdout);
								
							}
							else{
								printf("\n Vc class is not mactching with mentioned value");fflush(stdout);
							}
							
							
						}
						else
						{
						tc_strdup("NA",&vcclass_f1);
						printf("\n Vehicle class is  NULL..in f1!!");fflush(stdout);
						}
							
						}
						ITEM_ask_item_of_rev(change_AssyTag, &master_f1);
						if(master_f1 !=NULLTAG)
						{
						ITK_CALL(AOM_ask_value_tags(master_f1,"IMAN_classification",&cnt_f1,&ClsObjTag_f1));
						printf("\n classified object count_f1[%d]",cnt_f1); fflush(stdout);
						if(cnt_f1>0)
						{
							getESOAttrVal_f1=(char *)MEM_alloc(500);
							getProduct_line_f1=(char *)MEM_alloc(500);
							getEmsNorms_f1=(char *)MEM_alloc(500);
							getVehicle_class_f1=(char *)MEM_alloc(500);

						ClsObj_f1=*ClsObjTag_f1;
						ITK_CALL(getClsValueFrmICSTag(ClsObj_f1 ,getESOAttrVal_id_f1,&getESOAttrVal_f1));
						ITK_CALL(getClsValueFrmICSTag(ClsObj_f1 ,getProduct_line_id_f1,&getProduct_line_f1));
						ITK_CALL(getClsValueFrmICSTag(ClsObj_f1 ,getEmsNorms_id_f1,&getEmsNorms_f1));
						ITK_CALL(getClsValueFrmICSTag(ClsObj_f1 ,getVehicle_class_id_f1,&getVehicle_class_f1));
						
						printf("\n getESOAttrVal_f1[%s] !!",getESOAttrVal_f1); fflush(stdout);
						printf("\n getProduct_line_f1[%s] !!",getProduct_line_f1); fflush(stdout);
						printf("\n getEmsNorms_f1[%s] !!",getEmsNorms_f1); fflush(stdout);
						printf("\n getVehicle_class_f1[%s] !!",getVehicle_class_f1); fflush(stdout);
						
						}
						else{
							printf("\n There is no classification vehicle in f1");fflush(stdout);
						}
						}
						
					}
					else
					{
						printf("\n There is no TechSpec attached with vehicle f1");fflush(stdout);
					}
					
					}
					/*
					ITEM_ask_item_of_rev(change_AssyTag, &master_f1);
					if(master_f1 !=NULLTAG)
					{
					ITK_CALL(AOM_ask_value_tags(master_f1,"IMAN_classification",&cnt_f1,&ClsObjTag_f1));
					printf("\n classified object count_f1[%d]",cnt_f1); fflush(stdout);
					if(cnt_f1>0)
					{
						getESOAttrVal_f1=(char *)MEM_alloc(500);
						getProduct_line_f1=(char *)MEM_alloc(500);
						getEmsNorms_f1=(char *)MEM_alloc(500);
						getVehicle_class_f1=(char *)MEM_alloc(500);

					ClsObj_f1=*ClsObjTag_f1;
					ITK_CALL(getClsValueFrmICSTag(ClsObj_f1 ,getESOAttrVal_id_f1,&getESOAttrVal_f1));
					ITK_CALL(getClsValueFrmICSTag(ClsObj_f1 ,getProduct_line_id_f1,&getProduct_line_f1));
					ITK_CALL(getClsValueFrmICSTag(ClsObj_f1 ,getEmsNorms_id_f1,&getEmsNorms_f1));
					ITK_CALL(getClsValueFrmICSTag(ClsObj_f1 ,getVehicle_class_id_f1,&getVehicle_class_f1));
					
					printf("\n getESOAttrVal_f1[%s] !!",getESOAttrVal_f1); fflush(stdout);
					printf("\n getProduct_line_f1[%s] !!",getProduct_line_f1); fflush(stdout);
					printf("\n getEmsNorms_f1[%s] !!",getEmsNorms_f1); fflush(stdout);
					printf("\n getVehicle_class_f1[%s] !!",getVehicle_class_f1); fflush(stdout);
					
					}
					else{
						printf("\n There is no Tech spec attached with vehicle in f1");
					}
					}*/
					
						if(GCI_relation_tag!=NULLTAG)
						{
							GRM_list_secondary_objects_only(change_AssyTag,GCI_relation_tag,&DVLOcnt_f1,&DVLOtags_f1);	
							printf("\n entering into DVLO relation\n");fflush(stdout);
							if(DVLOcnt_f1 > 0)
							{

								for(rii=0;rii<DVLOcnt_f1;rii++)
								{

									DVLOtag_f1=DVLOtags_f1[rii];
									AOM_ask_value_string(DVLOtag_f1,"t5_DVLO_Name1",&DVLO_Name_f1);
									AOM_ask_value_int(DVLOtag_f1,"t5_demerit_score_v1",&demerit_score_f1);
									AOM_ask_value_int(DVLOtag_f1,"t5_demerit_score_rating_S1",&demerit_score_rating_f1);
									AOM_ask_value_double(DVLOtag_f1,"t5_geometry_conf_index_a1",&geometry_conf_index_f1);
									
									printf("\n DVLO_Name_f1[%s]",DVLO_Name_f1); fflush(stdout);
									printf("\n demerit_score_f1[%d]",demerit_score_f1); fflush(stdout);
									printf("\n demerit_score_rating_f1[%d]",demerit_score_rating_f1); fflush(stdout);
									printf("\n geometry_conf_index_f1 [%lf]",geometry_conf_index_f1); fflush(stdout);
									
									sprintf(demerit_score_s_f1,"%d",demerit_score_f1);
									sprintf(demerit_score_rating_s_f1,"%d",demerit_score_rating_f1);
									sprintf(geometry_conf_index_s_f1,"%lf",geometry_conf_index_f1);
									
									tc_strcpy(DVLO_Name_dup_f1,DVLO_Name_f1);
									tc_strcpy(demerit_score_s_dup_f1,demerit_score_s_f1);
									tc_strcpy(demerit_score_rating_s_dup_f1,demerit_score_rating_s_f1);
									tc_strcpy(geometry_conf_index_s_dup_f1,geometry_conf_index_s_f1);
									
									printf("\n DVLO_Name_dup_f1[%s]",DVLO_Name_dup_f1); fflush(stdout);
									printf("\n demerit_score_s_dup_f1[%s]",demerit_score_s_dup_f1); fflush(stdout);
									printf("\n demerit_score_rating_s_dup_f1[%s]",demerit_score_rating_s_dup_f1); fflush(stdout);
									printf("\n geometry_conf_index_s_dup_f1[%s]",geometry_conf_index_s_dup_f1); fflush(stdout);
									
								}
							}
							else
							{
								tc_strcpy(DVLO_Name_dup_f1,"NA");
								tc_strcpy(demerit_score_s_dup_f1,"NA");
								tc_strcpy(demerit_score_rating_s_dup_f1,"NA");
								tc_strcpy(geometry_conf_index_s_dup_f1,"NA");
								
								printf("\n DVLO_Name_dup_f1[%s]",DVLO_Name_dup_f1); fflush(stdout);
								printf("\n demerit_score_s_dup_f1[%s]",demerit_score_s_dup_f1); fflush(stdout);
								printf("\n demerit_score_rating_s_dup_f1[%s]",demerit_score_rating_s_dup_f1); fflush(stdout);
								printf("\n geometry_conf_index_s_dup_f1[%s]",geometry_conf_index_s_dup_f1); fflush(stdout);
								
							}
							}
							printf("\n enetring into tm_find_Prev_Official_Rev function\n");fflush(stdout);
							
							tm_find_Prev_Official_Rev(item_id_f1,change_AssyTag,&prevoffRev_tag_f1);
							if(prevoffRev_tag_f1!=NULLTAG)
							{
							//	char	*prev_rev_DR_status=	NULL;

							printf("\nPrevious official Revision found \n");fflush(stdout);
							
							AOM_ask_value_string(prevoffRev_tag_f1,"t5_PartStatus",&prev_rev_DR_status_f1);
							printf("\n previous_revision_DR_status_f1 is  :%s\n",prev_rev_DR_status_f1);fflush(stdout);
							
							tc_strcpy(prev_rev_DR_status_dup_f1,prev_rev_DR_status_f1);
							printf("\n prev_rev_DR_status_dup_f1 is  :%s\n",prev_rev_DR_status_dup_f1);fflush(stdout);
							}
							
							else{
								
								printf("\n under else of previous_revision_DR_status is\n");
								tc_strcpy(prev_rev_DR_status_dup_f1,"NA");
								printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status_dup_f1);fflush(stdout);
							}
							
							printf("\n enetring into tm_find_DR4_Rev function\n");fflush(stdout);
							tm_find_DR4_Rev(change_AssyTag,&DR4Rev_tag_f1);
									
							if(DR4Rev_tag_f1!=NULLTAG)
							{
							//	char	*first_DR4_rev=	NULL;
								AOM_ask_value_string(DR4Rev_tag_f1,"item_revision_id",&first_DR4_rev_f1);
							//	printf("\n 11111111111first_rev_DR_id  :%s\n",first_DR4_rev);fflush(stdout);
								
								tc_strcpy(first_DR4_rev_dup_f1,first_DR4_rev_f1);
								printf("\n 2222222222first_DR4_rev_dup_f1  :%s\n",first_DR4_rev_dup_f1);fflush(stdout);
							}
							else{
								
								printf("\n under else of first DR4 revsiion");
								tc_strcpy(first_DR4_rev_dup_f1,"NA");
								printf("\n first_DR4_rev_dup_f1  :%s\n",first_DR4_rev_dup_f1);fflush(stdout);
							}
						//	char *slNo_f=(char *) MEM_alloc(200);
						//	sprintf(slNo_f,"%d",(i+1));

							write2xml(Report,"<DesignRevision>\n");
						//	write2xml(Report,"<field key =\"slNo\">");
						//	write2xml(Report,slNo_f);
						//	write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"item_id\">");
							write2xml(Report,item_id_f1);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"item_revision_id\">"); write2xml(Report,item_revision_id_f1); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DR_status\">"); if(DR_status_f1_Dup != NULL) write2xml(Report,DR_status_f1_Dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"prev_rev_DR_status_dup\">"); if(prev_rev_DR_status_dup_f1 != NULL) write2xml(Report,prev_rev_DR_status_dup_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"first_DR4_rev_dup\">"); if(first_DR4_rev_dup_f1 != NULL) write2xml(Report,first_DR4_rev_dup_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"color_ind\">"); if(color_ind_f1 != NULL) write2xml(Report,color_ind_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"desc\">"); if(desc_f1 != NULL) write2xml(Report,desc_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"platform_Dup\">"); if(platform_f1_Dup != NULL) write2xml(Report,platform_f1_Dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"rolledupwt\">"); if(rolledupwt_f1 != NULL) write2xml(Report,rolledupwt_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DVLO_Name_dup\">"); if(DVLO_Name_dup_f1 != NULL) write2xml(Report,DVLO_Name_dup_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Plant\">"); if(Plant != NULL) write2xml(Report,Plant); else write2xml(Report,""); write2xml(Report,"</field>\n");
							
							write2xml(Report,"<field key =\"t5_BOMCompl\">"); if(t5_BOMCompl_f1 != NULL) write2xml(Report,t5_BOMCompl_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_Release_Type\">"); if(DML_Release_Type != NULL) write2xml(Report,DML_Release_Type); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_DR_Status\">"); if(DML_DR_Status != NULL) write2xml(Report,DML_DR_Status); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_no\">"); if(DML_no != NULL) write2xml(Report,DML_no); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_synopsis\">"); if(DML_synopsis != NULL) write2xml(Report,DML_synopsis); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_reasoncode\">"); if(DML_reasoncode != NULL) write2xml(Report,DML_reasoncode); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"dmlRelDate\">"); if(dmlRelDate != NULL) write2xml(Report,dmlRelDate); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"dmlLC\">"); if(dmlLC != NULL) write2xml(Report,dmlLC); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_from_to\">"); if(DML_from_to != NULL) write2xml(Report,DML_from_to); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"dmlProj\">"); if(dmlProj != NULL) write2xml(Report,dmlProj); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"proj_des\">"); if(proj_des != NULL) write2xml(Report,proj_des); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML_Owner\">"); if(DML_Owner != NULL) write2xml(Report,DML_Owner); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"ERC_BusiUt\">"); if(ERC_BusiUt != NULL) write2xml(Report,ERC_BusiUt); else write2xml(Report,""); write2xml(Report,"</field>\n");
							
							write2xml(Report,"<field key =\"demerit_score_s_dup\">"); if(demerit_score_s_dup_f1 != NULL) write2xml(Report,demerit_score_s_dup_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"demerit_score_rating_s_dup\">"); if(demerit_score_rating_s_dup_f1 != NULL) write2xml(Report,demerit_score_rating_s_dup_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"geometry_conf_index_s_dup\">"); if(geometry_conf_index_s_dup_f1 != NULL) write2xml(Report,geometry_conf_index_s_dup_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"getESOAttrVal\">"); if(getESOAttrVal_f1 != NULL) write2xml(Report,getESOAttrVal_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"getProduct_line\">"); if(getProduct_line_f1 != NULL) write2xml(Report,getProduct_line_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"getEmsNorms\">"); if(getEmsNorms_f1 != NULL) write2xml(Report,getEmsNorms_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"getVehicle_class\">"); if(getVehicle_class_f1 != NULL) write2xml(Report,getVehicle_class_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							
							write2xml(Report,"</DesignRevision>\n");
					}
					else
					{
						printf("\n VC not found in change refrence\n");fflush(stdout);
					}
					}
					}
				}
			}
			else if(tc_strcmp(DML_Release_Type,"Vehicle Release")==0)				
		//	if(tc_strcmp(DML_Release_Type,"Vehicle Release")==0)				
			{
						
			AOM_ask_value_tags(Dml_tasks[p],"CMHasSolutionItem",&partcnt,&PartsTag);
			printf("\n Now partcnt:%d\n",partcnt);fflush(stdout);
			if (partcnt>0)
			{
				for(k=0;k<partcnt;k++)
				{
					PartTag=PartsTag[k];
					
					char*  item_id =NULL;
					char*  item_revision_id =NULL;
					char*  DR_status =NULL;
					char*  desc =NULL;
					char*  color_ind =NULL;
					char*  platform =NULL;
					char*  platform_Dup =NULL;
					char*  rolledupwt =NULL;
					char*  t5_BOMCompl =NULL;
					tag_t prevoffRev_tag= NULLTAG;
					tag_t DR4Rev_tag= NULLTAG;
					tag_t master= NULLTAG;
					tag_t ClsObj= NULLTAG;
					tag_t *ClsObjTag = NULLTAG;
					
					int DVLOcnt = 0;
					int t = 0;
					tag_t *DVLOtags= NULLTAG;
					int 		vcspec_count	=	0;
					tag_t	*Vc_specObjects		= NULLTAG;
					char*	vcspec_item_id=NULL;
					char*	vcclass=NULL;
					
					char*	DVLO_Name =NULL;
					char*	DVLO_Name_dup =NULL;
					int		demerit_score =0;
					int 	demerit_score_rating	=0;
					double	geometry_conf_index	;
					tag_t 	DVLOtag	=NULLTAG;
					char* demerit_score_s;
					char* demerit_score_s_dup =NULL;
					char* demerit_score_rating_s;
					char* demerit_score_rating_s_dup =NULL;
					char* geometry_conf_index_s;
					char* geometry_conf_index_s_dup =NULL;
					int ii =0;
					demerit_score_s=(char *)MEM_alloc(100);
					demerit_score_s_dup=(char *)MEM_alloc(100);
					demerit_score_rating_s=(char *)MEM_alloc(100);
					demerit_score_rating_s_dup=(char *)MEM_alloc(100);
					geometry_conf_index_s=(char *)MEM_alloc(100);
					geometry_conf_index_s_dup=(char *)MEM_alloc(100);
					DVLO_Name_dup=(char *)MEM_alloc(100);
					prev_rev_DR_status_dup =(char *)MEM_alloc(500);
					first_DR4_rev_dup =(char *)MEM_alloc(500);
					
					
					
					char *getESOAttrVal_id = NULL;
					char *getESOAttrVal= NULL;
					char *getProduct_line_id= NULL;
					char *getProduct_line= NULL;
					char *getEmsNorms_id= NULL;
					char *getEmsNorms= NULL;
					char *getVehicle_class_id= NULL;
					char *getVehicle_class= NULL;


					AOM_ask_value_string(PartTag,"item_id",&item_id);
					AOM_ask_value_string(PartTag,"item_revision_id",&item_revision_id);
					AOM_ask_value_string(PartTag,"t5_PartStatus",&DR_status);
					AOM_ask_value_string(PartTag,"t5_ColourInd",&color_ind);
					AOM_ask_value_string(PartTag,"object_desc",&desc);
					AOM_ask_value_string(PartTag,"t5_Platform",&platform);
					AOM_ask_value_string(PartTag,"t5_Platform",&platform_Dup);
					AOM_ask_value_string(PartTag,"t5_RolledupWt",&rolledupwt);
					AOM_ask_value_string(PartTag,"t5_BOMCmpl",&t5_BOMCompl);
					printf("\n item_id  is :%s\n",item_id);	fflush(stdout);
					printf("\n Revision_id  is :%s\n",item_revision_id);fflush(stdout);
					printf("\n DR_status is :%s\n",DR_status);fflush(stdout);
					printf("\n color_ind :%s\n",color_ind);fflush(stdout);
					printf("\n object_desc :%s\n",desc);fflush(stdout);
					printf("\n Platform is :%s\n",platform);fflush(stdout);
					printf("\n platform_Dup is :%s\n",platform_Dup);fflush(stdout);
					printf("\n Rolled_UP_weight is :%s\n",rolledupwt);fflush(stdout);
					printf("\n BOM_Completeness is :%s\n",t5_BOMCompl);fflush(stdout);
					
					
					if (Vc_spec_relation_type!=NULLTAG)
					{
						GRM_list_secondary_objects_only(PartTag, Vc_spec_relation_type, &vcspec_count, &Vc_specObjects);
						printf("\n tech spec count is %d",vcspec_count);fflush(stdout);
					if(vcspec_count>0)
					{
						for(t=0;t<vcspec_count;t++)
						{
						//	Vc_specObject = Vc_specObjects[t];
							AOM_ask_value_string(Vc_specObjects[t],"item_id",&vcspec_item_id);
							printf("\nvcspec_item_id item is.......%s",vcspec_item_id);fflush(stdout);
							
							AOM_ask_value_string(Vc_specObjects[t],"t5_VCClassName",&vcclass);
							printf("\nvcclass is.......%s",vcclass);fflush(stdout);
							
						if(tc_strlen(vcclass)>0)
						{
						//	tc_strdup(vcclass,&platform_Dup);
							
							getESOAttrVal_id=(char *) MEM_alloc(400);
							getProduct_line_id=(char *) MEM_alloc(400);
							getEmsNorms_id=(char *) MEM_alloc(400);
							getVehicle_class_id=(char *) MEM_alloc(400);

							if(tc_strcmp(vcclass,"MCV")==0)
							{
								printf("\n Entering for MCV \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id,"5103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"5036");
								tc_strcpy(getVehicle_class_id,"5052");
								
								printf("\n getESOAttrVal_id MCV[%s] !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id MCV[%s] !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id MCV[%s] !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id MCV[%s] !!",getVehicle_class_id); fflush(stdout);
							}
							else if(tc_strcmp(vcclass,"HCV")==0)
							{
								printf("\n Entering for HCV \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id,"6103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"6036");
								tc_strcpy(getVehicle_class_id,"6052");
								
								printf("\n getESOAttrVal_id[%s] HCV !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id[%s] HCV !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id[%s] HCV !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id[%s] HCV !!",getVehicle_class_id); fflush(stdout);
								
							}
							
							else if(tc_strcmp(vcclass,"LCV")==0)
							{
								printf("\n Entering for LCV \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id,"4103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"4036");
								tc_strcpy(getVehicle_class_id,"4222");
								
								printf("\n getESOAttrVal_id[%s] LCV !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id[%s] LCV !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id[%s] LCV !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id[%s] LCV !!",getVehicle_class_id); fflush(stdout);
								
							}
							else if(tc_strcmp(vcclass,"LMV")==0)
							{
								printf("\n Entering for LMV \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id,"2103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"2036");
								tc_strcpy(getVehicle_class_id,"2222");
								
								printf("\n getESOAttrVal_id[%s] LMV !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id[%s] LMV !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id[%s] LMV !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id[%s] LMV !!",getVehicle_class_id); fflush(stdout);
								
							}
							else if(tc_strcmp(vcclass,"BUS")==0)
							{
								printf("\n Entering for BUS \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id,"7103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"7036");
								tc_strcpy(getVehicle_class_id,"7222");
								
								printf("\n getESOAttrVal_id[%s] BUS !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id[%s] BUS !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id[%s] BUS !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id[%s] BUS !!",getVehicle_class_id); fflush(stdout);
								
							}
						/*	else if(tc_strstr(vcclass,"MUV")!= NULL)
							{
								printf("\n Entering for MUV \n ");
								tc_strcpy(getESOAttrVal_id,"4103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"4036");
								tc_strcpy(getVehicle_class_id,"4052");
								
								printf("\n getESOAttrVal_id[%s] MUV !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id[%s] MUV !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id[%s] MUV !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id[%s] MUV !!",getVehicle_class_id); fflush(stdout);
								
							}*/
							else if(tc_strcmp(vcclass,"UV_VAN")==0)
							{
								printf("\n Entering for UV_VAN \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id,"10103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"10036");
								tc_strcpy(getVehicle_class_id,"10222");
								
								printf("\n getESOAttrVal_id[%s] UV_VAN !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id[%s] UV_VAN !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id[%s] UV_VAN !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id[%s] UV_VAN !!",getVehicle_class_id); fflush(stdout);
								
							}
							else if(tc_strcmp(vcclass,"ICV")==0)
							{
								printf("\n Entering for ICV \n ");fflush(stdout);
								tc_strcpy(getESOAttrVal_id,"3103");
								tc_strcpy(getProduct_line_id,"6240");
								tc_strcpy(getEmsNorms_id,"3036");
								tc_strcpy(getVehicle_class_id,"3222");
								
								printf("\n getESOAttrVal_id[%s] ICV !!",getESOAttrVal_id); fflush(stdout);
								printf("\n getProduct_line_id[%s] ICV !!",getProduct_line_id); fflush(stdout);
								printf("\n getEmsNorms_id[%s] ICV !!",getEmsNorms_id); fflush(stdout);
								printf("\n getVehicle_class_id[%s] ICV !!",getVehicle_class_id); fflush(stdout);
								
							}
							else{
								printf("\n Vc class is not mactching with mentioned value");fflush(stdout);
							}
							
							
						}
						else
						{
						tc_strdup("NA",&vcclass);
						printf("\n Vehicle class is  NULL..!!");fflush(stdout);
						}
							
						}
						
						ITEM_ask_item_of_rev(PartTag, &master);
						if(master !=NULLTAG)
						{
						ITK_CALL(AOM_ask_value_tags(master,"IMAN_classification",&cnt,&ClsObjTag));
						printf("\n classified object count[%d]",cnt); fflush(stdout);
						if(cnt>0)
						{
							getESOAttrVal=(char *)MEM_alloc(500);
							getProduct_line=(char *)MEM_alloc(500);
							getEmsNorms=(char *)MEM_alloc(500);
							getVehicle_class=(char *)MEM_alloc(500);

						ClsObj=*ClsObjTag;
						ITK_CALL(getClsValueFrmICSTag(ClsObj ,getESOAttrVal_id,&getESOAttrVal));
						ITK_CALL(getClsValueFrmICSTag(ClsObj ,getProduct_line_id,&getProduct_line));
						ITK_CALL(getClsValueFrmICSTag(ClsObj ,getEmsNorms_id,&getEmsNorms));
						ITK_CALL(getClsValueFrmICSTag(ClsObj ,getVehicle_class_id,&getVehicle_class));
						
						printf("\n getESOAttrVal[%s] !!",getESOAttrVal); fflush(stdout);
						printf("\n getProduct_line[%s] !!",getProduct_line); fflush(stdout);
						printf("\n getEmsNorms[%s] !!",getEmsNorms); fflush(stdout);
						printf("\n getVehicle_class[%s] !!",getVehicle_class); fflush(stdout);
						
						}
						else{
							printf("\n There is no classification value");fflush(stdout);
						}
						}	
					}
					else
						{
							printf("\n There is no tech spec attached with vehicle\n");fflush(stdout);
						}
					}
					
					/*
					ITEM_ask_item_of_rev(PartTag, &master);
					if(master !=NULLTAG)
					{
					ITK_CALL(AOM_ask_value_tags(master,"IMAN_classification",&cnt,&ClsObjTag));
					printf("\n classified object count[%d]",cnt); fflush(stdout);
					if(cnt>0)
					{
						getESOAttrVal=(char *)MEM_alloc(500);
						getProduct_line=(char *)MEM_alloc(500);
						getEmsNorms=(char *)MEM_alloc(500);
						getVehicle_class=(char *)MEM_alloc(500);

					ClsObj=*ClsObjTag;
					ITK_CALL(getClsValueFrmICSTag(ClsObj ,getESOAttrVal_id,&getESOAttrVal));
					ITK_CALL(getClsValueFrmICSTag(ClsObj ,getProduct_line_id,&getProduct_line));
					ITK_CALL(getClsValueFrmICSTag(ClsObj ,getEmsNorms_id,&getEmsNorms));
					ITK_CALL(getClsValueFrmICSTag(ClsObj ,getVehicle_class_id,&getVehicle_class));
					
					printf("\n getESOAttrVal[%s] !!",getESOAttrVal); fflush(stdout);
					printf("\n getProduct_line[%s] !!",getProduct_line); fflush(stdout);
					printf("\n getEmsNorms[%s] !!",getEmsNorms); fflush(stdout);
					printf("\n getVehicle_class[%s] !!",getVehicle_class); fflush(stdout);
					
					}
					else{
						printf("\n There is no classification value");fflush(stdout);
					}
					}*/

					
				if(GCI_relation_tag !=NULLTAG)
				{
					
					GRM_list_secondary_objects_only(PartTag,GCI_relation_tag,&DVLOcnt,&DVLOtags);
					
					if(DVLOcnt > 0)
					{
						
						
						for(ii=0;ii<DVLOcnt;ii++)
						{
							
							
							DVLOtag=DVLOtags[ii];
							AOM_ask_value_string(DVLOtag,"t5_DVLO_Name1",&DVLO_Name);
							AOM_ask_value_int(DVLOtag,"t5_demerit_score_v1",&demerit_score);
							AOM_ask_value_int(DVLOtag,"t5_demerit_score_rating_S1",&demerit_score_rating);
							AOM_ask_value_double(DVLOtag,"t5_geometry_conf_index_a1",&geometry_conf_index);
							
							printf("\n DVLO_Name[%s]",DVLO_Name); fflush(stdout);
							printf("\n demerit_score[%d]",demerit_score); fflush(stdout);
							printf("\n demerit_score_rating[%d]",demerit_score_rating); fflush(stdout);
							printf("\n geometry_conf_index count[%lf]",geometry_conf_index); fflush(stdout);
							
							sprintf(demerit_score_s,"%d",demerit_score);
							sprintf(demerit_score_rating_s,"%d",demerit_score_rating);
							sprintf(geometry_conf_index_s,"%f",geometry_conf_index);
							
							tc_strcpy(DVLO_Name_dup,DVLO_Name);
							tc_strcpy(demerit_score_s_dup,demerit_score_s);
							tc_strcpy(demerit_score_rating_s_dup,demerit_score_rating_s);
							tc_strcpy(geometry_conf_index_s_dup,geometry_conf_index_s);
							
							printf("\n DVLO_Name_dup[%s]",DVLO_Name_dup); fflush(stdout);
							printf("\n demerit_score_s_dup[%s]",demerit_score_s_dup); fflush(stdout);
							printf("\n demerit_score_rating_s_dup[%s]",demerit_score_rating_s_dup); fflush(stdout);
							printf("\n geometry_conf_index_s_dup[%s]",geometry_conf_index_s_dup); fflush(stdout);
							
						}
					}
					else
					{
						tc_strcpy(DVLO_Name_dup,"NA");
						tc_strcpy(demerit_score_s_dup,"NA");
						tc_strcpy(demerit_score_rating_s_dup,"NA");
						tc_strcpy(geometry_conf_index_s_dup,"NA");
						
						printf("\n DVLO_Name_dup[%s]",DVLO_Name_dup); fflush(stdout);
						printf("\n demerit_score_s_dup[%s]",demerit_score_s_dup); fflush(stdout);
						printf("\n demerit_score_rating_s_dup[%s]",demerit_score_rating_s_dup); fflush(stdout);
						printf("\n geometry_conf_index_s_dup[%s]",geometry_conf_index_s_dup); fflush(stdout);
						
					}
					}

					
					
					tm_find_Prev_Official_Rev(item_id,PartTag,&prevoffRev_tag);
					if(prevoffRev_tag!=NULLTAG)
					{
					//	char	*prev_rev_DR_status=	NULL;

					printf("\nPrevious official Revision found \n");fflush(stdout);
					
					AOM_ask_value_string(prevoffRev_tag,"t5_PartStatus",&prev_rev_DR_status);
					printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status);fflush(stdout);
					
					tc_strcpy(prev_rev_DR_status_dup,prev_rev_DR_status);
					printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status_dup);fflush(stdout);
					}
					
					else{
						
						printf("\n under else of previous_revision_DR_status is\n");fflush(stdout);
						tc_strcpy(prev_rev_DR_status_dup,"NA");
						printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status_dup);fflush(stdout);
					}
					
					
					
					tm_find_DR4_Rev(PartTag,&DR4Rev_tag);
					
					if(DR4Rev_tag!=NULLTAG)
					{
					//	char	*first_DR4_rev=	NULL;
						AOM_ask_value_string(DR4Rev_tag,"item_revision_id",&first_DR4_rev);
					//	printf("\n 11111111111first_rev_DR_id  :%s\n",first_DR4_rev);fflush(stdout);
						
						tc_strcpy(first_DR4_rev_dup,first_DR4_rev);
						printf("\n 2222222222first_DR4_rev_dup  :%s\n",first_DR4_rev_dup);fflush(stdout);
					}
					else{
						
						printf("\n under else of first DR4 revsiion");fflush(stdout);
						tc_strcpy(first_DR4_rev_dup,"NA");
						printf("\n first_DR4_rev_dup  :%s\n",first_DR4_rev_dup);fflush(stdout);
					}
					
					
				//	}
					
				/*
	
					STRNG_replace_str(DR_status,"\\n"," ",&DR_status);
					STRNG_replace_str(color_ind,"\\n"," ",&color_ind);
					STRNG_replace_str(desc,"\\n"," ",&desc);
					STRNG_replace_str(platform_Dup,"\\n"," ",&platform_Dup);
					STRNG_replace_str(rolledupwt,"\\n"," ",&rolledupwt);
					STRNG_replace_str(t5_BOMCompl,"\\n"," ",&t5_BOMCompl);
					STRNG_replace_str(DML_Release_Type,"\\n"," ",&DML_Release_Type);
					STRNG_replace_str(DML_DR_Status,"\\n"," ",&DML_DR_Status);
					STRNG_replace_str(prev_rev_DR_status_dup,"\\n"," ",&prev_rev_DR_status_dup);
					STRNG_replace_str(first_DR4_rev_dup,"\\n"," ",&first_DR4_rev_dup);
					STRNG_replace_str(DML_no,"\\n"," ",&DML_no);
					STRNG_replace_str(DML_synopsis,"\\n"," ",&DML_synopsis);
					STRNG_replace_str(DML_reasoncode,"\\n"," ",&DML_reasoncode);
					STRNG_replace_str(dmlRelDate,"\\n"," ",&dmlRelDate);
					STRNG_replace_str(dmlProj,"\\n"," ",&dmlProj);
					STRNG_replace_str(proj_des,"\\n"," ",&proj_des);
					STRNG_replace_str(dmlLC,"\\n"," ",&dmlLC);
					STRNG_replace_str(Plant,"\\n"," ",&Plant);
					STRNG_replace_str(DML_from_to,"\\n"," ",&DML_from_to);
					STRNG_replace_str(DML_Owner,"\\n"," ",&DML_Owner);
					STRNG_replace_str(DVLO_Name_dup,"\\n"," ",&DVLO_Name_dup);
					STRNG_replace_str(demerit_score_s_dup,"\\n"," ",&demerit_score_s_dup);
					STRNG_replace_str(demerit_score_rating_s_dup,"\\n"," ",&demerit_score_rating_s_dup);
					STRNG_replace_str(geometry_conf_index_s_dup,"\\n"," ",&geometry_conf_index_s_dup);
					STRNG_replace_str(getESOAttrVal,"\\n"," ",&getESOAttrVal);
					STRNG_replace_str(getProduct_line,"\\n"," ",&getProduct_line);
					STRNG_replace_str(getEmsNorms,"\\n"," ",&getEmsNorms);
					STRNG_replace_str(getVehicle_class,"\\n"," ",&getVehicle_class);
				
					
					
					
					STRNG_replace_str(DR_status,"<","(",&DR_status);
					STRNG_replace_str(prev_rev_DR_status_dup,"<","(",&prev_rev_DR_status_dup);
					STRNG_replace_str(first_DR4_rev_dup,"<","(",&first_DR4_rev_dup);
					STRNG_replace_str(color_ind,"<","(",&color_ind);
					STRNG_replace_str(desc,"<","(",&desc);
					STRNG_replace_str(platform_Dup,"<","(",&platform_Dup);
					STRNG_replace_str(rolledupwt,"<","(",&rolledupwt);
					STRNG_replace_str(t5_BOMCompl,"<","(",&t5_BOMCompl);
					STRNG_replace_str(DML_Release_Type,"<","(",&DML_Release_Type);
					STRNG_replace_str(DML_DR_Status,"<","(",&DML_DR_Status);
					STRNG_replace_str(DML_no,"<","(",&DML_no);
					STRNG_replace_str(DML_synopsis,"<","(",&DML_synopsis);
					STRNG_replace_str(DML_reasoncode,"<","(",&DML_reasoncode);
					STRNG_replace_str(dmlRelDate,"<","(",&dmlRelDate);
					STRNG_replace_str(dmlProj,"<","(",&dmlProj);
					STRNG_replace_str(proj_des,"<","(",&proj_des);
					STRNG_replace_str(dmlLC,"<","(",&dmlLC);
					STRNG_replace_str(Plant,"<","(",&Plant);
					STRNG_replace_str(DML_from_to,"<","(",&DML_from_to);
					STRNG_replace_str(DML_Owner,"<","(",&DML_Owner);
					STRNG_replace_str(ERC_BusiUt,"<","(",&ERC_BusiUt);
					STRNG_replace_str(DVLO_Name_dup,"<","(",&DVLO_Name_dup);
					STRNG_replace_str(demerit_score_s_dup,"<","(",&demerit_score_s_dup);
					STRNG_replace_str(demerit_score_rating_s_dup,"<","(",&demerit_score_rating_s_dup);
					STRNG_replace_str(geometry_conf_index_s_dup,"<","(",&geometry_conf_index_s_dup);
					STRNG_replace_str(getESOAttrVal,"<","(",&getESOAttrVal);
					STRNG_replace_str(getProduct_line,"<","(",&getProduct_line);
					STRNG_replace_str(getEmsNorms,"<","(",&getEmsNorms);
					STRNG_replace_str(getVehicle_class,"<","(",&getVehicle_class);
					
					
					STRNG_replace_str(DR_status,">",")",&DR_status);
					STRNG_replace_str(prev_rev_DR_status_dup,">",")",&prev_rev_DR_status_dup);
					STRNG_replace_str(first_DR4_rev_dup,">",")",&first_DR4_rev_dup);
					STRNG_replace_str(color_ind,">",")",&color_ind);
					STRNG_replace_str(desc,">",")",&desc);
					STRNG_replace_str(platform_Dup,">",")",&platform_Dup);
					STRNG_replace_str(rolledupwt,">",")",&rolledupwt);
					STRNG_replace_str(t5_BOMCompl,">",")",&t5_BOMCompl);
					STRNG_replace_str(DML_Release_Type,">",")",&DML_Release_Type);
					STRNG_replace_str(DML_DR_Status,">",")",&DML_DR_Status);
					STRNG_replace_str(DML_no,">",")",&DML_no);
					STRNG_replace_str(DML_synopsis,">",")",&DML_synopsis);
					STRNG_replace_str(DML_reasoncode,">",")",&DML_reasoncode);
					STRNG_replace_str(dmlRelDate,">",")",&dmlRelDate);
					STRNG_replace_str(dmlProj,">",")",&dmlProj);
					STRNG_replace_str(proj_des,">",")",&proj_des);
					STRNG_replace_str(dmlLC,">",")",&dmlLC);
					STRNG_replace_str(Plant,">",")",&Plant);
					STRNG_replace_str(DML_from_to,">",")",&DML_from_to);
					STRNG_replace_str(DML_Owner,">",")",&DML_Owner);
					STRNG_replace_str(ERC_BusiUt,">",")",&ERC_BusiUt);
					STRNG_replace_str(DVLO_Name_dup,">",")",&DVLO_Name_dup);
					STRNG_replace_str(demerit_score_s_dup,">",")",&demerit_score_s_dup);
					STRNG_replace_str(demerit_score_rating_s_dup,">",")",&demerit_score_rating_s_dup);
					STRNG_replace_str(geometry_conf_index_s_dup,">",")",&geometry_conf_index_s_dup);
					STRNG_replace_str(getESOAttrVal,">",")",&getESOAttrVal);
					STRNG_replace_str(getProduct_line,">",")",&getProduct_line);
					STRNG_replace_str(getEmsNorms,">",")",&getEmsNorms);
					STRNG_replace_str(getVehicle_class,">",")",&getVehicle_class);
					
					removeNonAsciiChars(DR_status);
					removeNonAsciiChars(prev_rev_DR_status_dup);
					removeNonAsciiChars(first_DR4_rev_dup);
					removeNonAsciiChars(color_ind);
					removeNonAsciiChars(desc);
					removeNonAsciiChars(platform_Dup);
					removeNonAsciiChars(rolledupwt);
					removeNonAsciiChars(t5_BOMCompl);
					removeNonAsciiChars(DML_Release_Type);
					removeNonAsciiChars(DML_DR_Status);
					removeNonAsciiChars(DML_no);
					removeNonAsciiChars(DML_synopsis);
					removeNonAsciiChars(DML_reasoncode);
					removeNonAsciiChars(dmlRelDate);
					removeNonAsciiChars(dmlProj);
					removeNonAsciiChars(proj_des);
					removeNonAsciiChars(dmlLC);
					removeNonAsciiChars(DML_from_to);
					removeNonAsciiChars(DML_Owner);
					removeNonAsciiChars(ERC_BusiUt);
					removeNonAsciiChars(DVLO_Name_dup);
					removeNonAsciiChars(Plant);
					removeNonAsciiChars(getESOAttrVal);
					removeNonAsciiChars(getProduct_line);
					removeNonAsciiChars(getEmsNorms);
					removeNonAsciiChars(getVehicle_class);
				*/
					
					//char *t5_DR_status = NULL;
					//char *t5_color_ind = NULL;
					char *t5_desc = NULL;
					char *t5_platform = NULL;
					char *t5_DML_DR_Status = NULL;
					char *t5_DML_synopsis = NULL;
					char *t5_DML_reasoncode = NULL;
				//	char *t5_dml_type_dup = NULL;
					char *t5_dmlProj = NULL;
					char *t5_rolledupwt = NULL;
					char *t5_DML_from_to = NULL;
					char *t5_BOMCompl_val = NULL;
					char *t5_proj_des = NULL;
					char *t5_prev_rev_DR_status = NULL;
					char *t5_first_DR4_rev = NULL;
					
					//if(DR_status != NULL) STRNG_replace_str(DR_status,"&","&amp;",&t5_DR_status);
					//if(color_ind != NULL) STRNG_replace_str(color_ind,"&","&amp;",&t5_color_ind);
					if(desc != NULL) STRNG_replace_str(desc,"&","&amp;",&t5_desc);
				//	if(platform != NULL) STRNG_replace_str(platform,"&","&amp;",&t5_platform);
					if(rolledupwt != NULL) STRNG_replace_str(rolledupwt,"&","&amp;",&t5_rolledupwt);
					if(DML_DR_Status != NULL) STRNG_replace_str(DML_DR_Status,"&","&amp;",&t5_DML_DR_Status);
				//	if(prev_rev_DR_status != NULL) STRNG_replace_str(prev_rev_DR_status,"&","&amp;",&t5_prev_rev_DR_status);
				//	if(first_DR4_rev != NULL) STRNG_replace_str(first_DR4_rev,"&","&amp;",&t5_first_DR4_rev);
					if(DML_synopsis != NULL) STRNG_replace_str(DML_synopsis,"&","&amp;",&t5_DML_synopsis);
					if(DML_reasoncode != NULL) STRNG_replace_str(DML_reasoncode,"&","&amp;",&t5_DML_reasoncode);
				//	if(dml_type_dup != NULL) STRNG_replace_str(dml_type_dup,"&","&amp;",&t5_dml_type_dup);
					if(dmlProj != NULL) STRNG_replace_str(dmlProj,"&","&amp;",&t5_dmlProj);
					if(DML_from_to != NULL) STRNG_replace_str(DML_from_to,"&","&amp;",&t5_DML_from_to);
					if(t5_BOMCompl != NULL) STRNG_replace_str(t5_BOMCompl,"&","&amp;",&t5_BOMCompl_val);
					if(proj_des != NULL) STRNG_replace_str(proj_des,"&","&amp;",&t5_proj_des);
					
					
					
				//	char *slNo=(char *) MEM_alloc(200);
				//	sprintf(slNo,"%d",(i+1));

					write2xml(Report,"<DesignRevision>\n");
				//	write2xml(Report,"<field key =\"slNo\">");
				//	write2xml(Report,slNo);
				//	write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"item_id\">");
					write2xml(Report,item_id);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"item_revision_id\">"); write2xml(Report,item_revision_id); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DR_status\">"); if(DR_status != NULL) write2xml(Report,DR_status); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"prev_rev_DR_status_dup\">"); if(prev_rev_DR_status_dup != NULL) write2xml(Report,prev_rev_DR_status_dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"first_DR4_rev_dup\">"); if(first_DR4_rev_dup != NULL) write2xml(Report,first_DR4_rev_dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"color_ind\">"); if(color_ind != NULL) write2xml(Report,color_ind); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"desc\">"); if(t5_desc != NULL) write2xml(Report,t5_desc); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"platform_Dup\">"); if(platform_Dup != NULL) write2xml(Report,platform_Dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"rolledupwt\">"); if(t5_rolledupwt != NULL) write2xml(Report,t5_rolledupwt); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DVLO_Name_dup\">"); if(DVLO_Name_dup != NULL) write2xml(Report,DVLO_Name_dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Plant\">"); if(Plant != NULL) write2xml(Report,Plant); else write2xml(Report,""); write2xml(Report,"</field>\n");
					
					write2xml(Report,"<field key =\"t5_BOMCompl\">"); if(t5_BOMCompl_val != NULL) write2xml(Report,t5_BOMCompl_val); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DML_Release_Type\">"); if(DML_Release_Type != NULL) write2xml(Report,DML_Release_Type); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DML_DR_Status\">"); if(t5_DML_DR_Status != NULL) write2xml(Report,t5_DML_DR_Status); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DML_no\">"); if(DML_no != NULL) write2xml(Report,DML_no); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DML_synopsis\">"); if(t5_DML_synopsis != NULL) write2xml(Report,t5_DML_synopsis); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DML_reasoncode\">"); if(t5_DML_reasoncode != NULL) write2xml(Report,t5_DML_reasoncode); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"dmlRelDate\">"); if(dmlRelDate != NULL) write2xml(Report,dmlRelDate); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"dmlLC\">"); if(dmlLC != NULL) write2xml(Report,dmlLC); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DML_from_to\">"); if(t5_DML_from_to != NULL) write2xml(Report,t5_DML_from_to); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"dmlProj\">"); if(t5_dmlProj != NULL) write2xml(Report,t5_dmlProj); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"proj_des\">"); if(t5_proj_des != NULL) write2xml(Report,t5_proj_des); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DML_Owner\">"); if(DML_Owner != NULL) write2xml(Report,DML_Owner); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"ERC_BusiUt\">"); if(ERC_BusiUt != NULL) write2xml(Report,ERC_BusiUt); else write2xml(Report,""); write2xml(Report,"</field>\n");
					
					write2xml(Report,"<field key =\"demerit_score_s_dup\">"); if(demerit_score_s_dup != NULL) write2xml(Report,demerit_score_s_dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"demerit_score_rating_s_dup\">"); if(demerit_score_rating_s_dup != NULL) write2xml(Report,demerit_score_rating_s_dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"geometry_conf_index_s_dup\">"); if(geometry_conf_index_s_dup != NULL) write2xml(Report,geometry_conf_index_s_dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"getESOAttrVal\">"); if(getESOAttrVal != NULL) write2xml(Report,getESOAttrVal); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"getProduct_line\">"); if(getProduct_line != NULL) write2xml(Report,getProduct_line); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"getEmsNorms\">"); if(getEmsNorms != NULL) write2xml(Report,getEmsNorms); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"getVehicle_class\">"); if(getVehicle_class != NULL) write2xml(Report,getVehicle_class); else write2xml(Report,""); write2xml(Report,"</field>\n");
					
					write2xml(Report,"</DesignRevision>\n");

			//	}
			//	}
			//	}
			//	}
			}
			}
							//	}
						}
					}
				}
				
			}
				printf("\n out of the DML \n");
			}
				
			}
		}
		write2xml(Report,"</PLMXML>\n");
		fclose(Report);
		
		printf("\n report is generted\n");

		ifail = ITK_exit_module(TRUE);
		if (ifail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(ifail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
	}
	return ITK_ok;
}


