/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Module & Check It's Two Properties Value (Module Name & Keyword Description)  
*  File Name    :   tm_module_info_update.c
*  Created on   :   Sep 14th, 2023
*  Usage        :   tm_module_info_update
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     14/09/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}														\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	FILE* fpPart_List = NULL;
	char* PNo_Str = NULL;
	char* PNo_StrDup = NULL;
	char* DesGrp_Str = NULL;
	char* DesGrp_StrDup = NULL;
	char* Agg_Str = NULL;
	char* Agg_StrDup = NULL;
	char* AggGrp_Str = NULL;
	char* AggGrp_StrDup = NULL;
	char* Mod_Str = NULL;
	char* Mod_StrDup = NULL;
	char* ModGrp_Str = NULL;
	char* ModGrp_StrDup = NULL;
	char* ModAdd_Str = NULL;
	char* ModAdd_StrDup = NULL;
	char* ModName_Str = NULL;
    char* ModName_StrDup = NULL;
	char* Module_No = NULL;
	char* Module_NoDup = NULL;
	
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[300]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	int no_ref = 0;
	int j =0;
	char *RptFile= (char *) malloc(400*sizeof(char));
	//char *status= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t DesGrp_AttrID = NULLTAG;
	tag_t Agg_AttrID = NULLTAG;
	tag_t AggGrp_AttrID = NULLTAG;
	tag_t Mod_AttrID = NULLTAG;
	tag_t ModGrp_AttrID = NULLTAG;
	tag_t ModAddress_AttrID = NULLTAG;
	tag_t ModName_AttrID = NULLTAG;
	char *message;
	char *loggedInUser = NULL;
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n New Time Stamp Generated");fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"Module_Property_Info_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
			
			fpPart_List = fopen("PartList.txt","r");
			if(fpPart_List != NULL)
		    {	
			    printf("\n Part List is Not Null Moving Forward...");fflush(stdout);
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					PNo_Str=strtok(temp,"^");
					DesGrp_Str=strtok(NULL,"^");
					Agg_Str=strtok(NULL,"^");
					AggGrp_Str=strtok(NULL,"^");
					Mod_Str=strtok(NULL,"^");
					ModGrp_Str=strtok(NULL,"^");
					ModAdd_Str=strtok(NULL,"^");
					ModName_Str=strtok(NULL,"^");
					
					printf("\n Part Number String: [%s]", PNo_Str);fflush(stdout);
                    printf("\n Design Group String: [%s]", DesGrp_Str);fflush(stdout);	
                    printf("\n Aggregate: [%s]", Agg_Str);fflush(stdout);	
                    printf("\n Aggregate Group: [%s]", AggGrp_Str);fflush(stdout);	
                    printf("\n Module: [%s]", Mod_Str);fflush(stdout);
                    printf("\n Module Group: [%s]", ModGrp_Str);fflush(stdout);	
                    printf("\n Module Address: [%s]", ModAdd_Str);fflush(stdout);
                    printf("\n Module Name: [%s]", ModName_Str);fflush(stdout);					
					if(PNo_Str!=NULL)tc_strdup(PNo_Str,&PNo_StrDup);	
					if(PNo_StrDup!=NULL)trimwhitespace(PNo_StrDup);
					if(DesGrp_Str!=NULL)tc_strdup(DesGrp_Str,&DesGrp_StrDup);	
					if(DesGrp_StrDup!=NULL)trimwhitespace(DesGrp_StrDup);
					if(Agg_Str!=NULL)tc_strdup(Agg_Str,&Agg_StrDup);	
					if(Agg_StrDup!=NULL)trimwhitespace(Agg_StrDup);
					if(Agg_Str!=NULL)tc_strdup(AggGrp_Str,&AggGrp_StrDup);	
					if(AggGrp_StrDup!=NULL)trimwhitespace(AggGrp_StrDup);
					if(Mod_Str!=NULL)tc_strdup(Mod_Str,&Mod_StrDup);	
					if(Mod_StrDup!=NULL)trimwhitespace(Mod_StrDup);
					if(ModGrp_Str!=NULL)tc_strdup(ModGrp_Str,&ModGrp_StrDup);	
					if(ModGrp_StrDup!=NULL)trimwhitespace(ModGrp_StrDup);
					if(ModAdd_Str!=NULL)tc_strdup(ModAdd_Str,&ModAdd_StrDup);	
					if(ModAdd_StrDup!=NULL)trimwhitespace(ModAdd_StrDup);
					if(ModName_Str!=NULL)tc_strdup(ModName_Str,&ModName_StrDup);	
					if(ModName_StrDup!=NULL)trimwhitespace(ModName_StrDup);
					
					printf("\n Part Number Value After Dup & Trim: [%s]", PNo_StrDup);fflush(stdout);
					printf("\n Design Group Value After Dup & Trim: [%s]", DesGrp_StrDup);fflush(stdout);
					printf("\n Aggregate Value After Dup & Trim: [%s]", Agg_StrDup);fflush(stdout);
					printf("\n Aggregate Group Value After Dup & Trim: [%s]", AggGrp_StrDup);fflush(stdout);
					printf("\n Module Value After Dup & Trim: [%s]", Mod_StrDup);fflush(stdout);
					printf("\n Module Group Value After Dup & Trim: [%s]", ModGrp_StrDup);fflush(stdout);
					printf("\n Module Address Value After Dup & Trim: [%s]", ModAdd_StrDup);fflush(stdout);
					printf("\n Module Name Value After Dup & Trim: [%s]", ModName_StrDup);fflush(stdout);
				
					ITK_CALL(QRY_find2("Design Revision",&tItemobj));
                    if(tItemobj != NULLTAG)
			        {
							printf("\n Design Revision Found Successfully...");fflush(stdout);
					        char *cEntries[1]  = {"ID"};
							char *cValues[1]  = {PNo_StrDup};
							//char *cValues[1]  = {"5545D2B1172002"};
					        ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
					        printf("\n -----------------------------------------------\n");fflush(stdout);
					        printf("\n No of Revision Found --------> %d\n",n_itemobj_found);fflush(stdout);
					        printf("\n -----------------------------------------------\n");fflush(stdout);
							for (i = 0; i < n_itemobj_found; i++)
		                    {
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "item_id", &Module_No));
								if(Module_No!=NULL)tc_strdup(Module_No,&Module_NoDup);
								if(Module_NoDup!=NULL)trimwhitespace(Module_NoDup);
								if(Module_NoDup!=NULL)
								{
								   printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 
								   ITK_CALL(AOM_refresh(titemobj_results[i], POM_modify_lock));
								   printf("\n Lock..!!");
								   ITK_CALL(POM_attr_id_of_attr("t5_DesignGrp", "Design_0_Revision_alt", &DesGrp_AttrID));
								   printf("\n Design Group Tag Found..!!");
								   ITK_CALL(POM_attr_id_of_attr("t5_Aggregate", "Design_0_Revision_alt", &Agg_AttrID));
								   printf("\n Aggregate Tag Found..!!");
								   ITK_CALL(POM_attr_id_of_attr("t5_AggregateGroup", "Design_0_Revision_alt", &AggGrp_AttrID));
								   printf("\n Aggregate Group Tag Found..!!");
								   ITK_CALL(POM_attr_id_of_attr("t5_Module", "Design_0_Revision_alt", &Mod_AttrID));
								   printf("\n Module Tag Found..!!");
								   ITK_CALL(POM_attr_id_of_attr("t5_Module_Group", "Design_0_Revision_alt", &ModGrp_AttrID));
								   printf("\n Module Group Found..!!");
								   ITK_CALL(POM_attr_id_of_attr("t5_ModuleAddress", "Design_0_Revision_alt", &ModAddress_AttrID));
								   printf("\n Module Address Tag Found..!!");
								   ITK_CALL(POM_attr_id_of_attr("t5_ModuleName", "Design_0_Revision_alt", &ModName_AttrID));
								   printf("\n Module Address Tag Found..!!");
								   ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], DesGrp_AttrID, DesGrp_StrDup));
								   printf("\n Set Design Group Value..!!");
								   ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], Agg_AttrID, Agg_StrDup));
								   printf("\n Set Aggregate Value..!!");
								   ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], AggGrp_AttrID, AggGrp_StrDup));
								   printf("\n Set Aggregate Group Value..!!");
								   ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], Mod_AttrID, Mod_StrDup));
								   printf("\n Set Module Value..!!");
								   ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], ModGrp_AttrID, ModGrp_StrDup));
								   printf("\n Set Module Group Value..!!");
								   ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], ModAddress_AttrID, ModAdd_StrDup));
								   printf("\n Set Module Address Value..!!");
								   ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], ModName_AttrID, ModName_StrDup));
								   printf("\n Set Module Name Value..!!");
								   ITK_CALL(POM_save_instances(1, &titemobj_results[i], true));
								   printf("\n Save...!!\n");
								   ITK_CALL(AOM_refresh(titemobj_results[i], POM_no_lock));
								   printf("\n Unlock..!!");
								   printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
								} 
								
		                    }
			        }
					else
					{
						printf("\n After Query Execution No Item Found...");fflush(stdout);
					}
					if (titemobj_results)
					{
						MEM_free(titemobj_results);
					}					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n Part No Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout);           
				printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout);
			}
			else 
			{
				printf("\n Part List is Null....");fflush(stdout);
			}
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
			
	return 0;
}