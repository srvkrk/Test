/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Latest Released Design Revision After Reading Data From Input File .
*  File Name    :   tm_Datasethunttcua.c
*  Created on   :   Aug 28th, 2024
*  Usage        :   tm_Datasethunttcua
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     28/08/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
																            \
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
    FILE *fpOutput_file = NULL;
	char* SubModAddr_Str = NULL;
	char* InpPart_Str = NULL;
	char* InpRev_Str = NULL;
	char* InpSeq_Str = NULL;
	char* SubModAddr_StrDup = NULL;
	char* InpPart_StrDup = NULL;
	char* InpRev_StrDup = NULL;
	char* InpSeq_StrDup = NULL;
	char* LibPartNo = NULL;
	char* LibPartRev = NULL;
	char* LibPartSeq = NULL;
	char* LibPartNoDup = NULL;
	char* LibPartRevDup = NULL;
	char* LibPartSeqDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tdesrev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	
	//tag_t IMANSpecType = NULLTAG;
	//tag_t IMANRefType = NULLTAG;
	tag_t IMANRenType = NULLTAG;
	tag_t* IMANRenAttach = NULLTAG;
	int IMANRenCnt = 0;
	int i = 0;
	int j = 0;
	tag_t dataset = NULLTAG;
	AE_reference_type_t RefType;
	char* RefName = NULL;
	tag_t SecObjTypeTag = NULLTAG;
	char SecObjTypeName[TCTYPE_name_size_c+1];
	int ReferenceCount = 0;
	int k = 0;
	tag_t RefObject = NULLTAG;
	char* Orginal_Name = NULL;
	char* Orginal_NameDup = NULL;
	char* object_type = NULL;
	char* Data_Name  = NULL;
	char* ItemIDChk = NULL;
	char* New_Name= (char *) malloc(400*sizeof(char));
	char* SecObjName = NULL;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	char *item_parttype_str = NULL;
	char *item_parttype_strDup = NULL;
	char *item_desgrp_str = NULL;
	char *item_desgrp_strDup = NULL;
	char *item_model_str = NULL;
	char *item_model_strDup = NULL;
	char *Owner = NULL;
	char *OwnerDup = NULL;
	char* inpparttype_str = NULL;
	char* inpparttype_strDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
    inpparttype_str = ITK_ask_cli_argument("-type=");
    trimwhitespace(inpparttype_str);
    if(inpparttype_str!=NULL)tc_strdup(inpparttype_str,&inpparttype_strDup);
    printf(" [1]: Input Part Type(inpparttype_strDup): [%s]\n",inpparttype_strDup);

	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
    tc_strcpy(RptFile,"TCUA_Dataset_Hunt");
    tc_strcat(RptFile,"_");
    tc_strcat(RptFile,GenDate);
    tc_strcat(RptFile,".csv");
    printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
    printf("\n CSV Report File Generated..!!");fflush(stdout);

	fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"PART_NO, REVISION, SEQUENCE, DESCRIPTION, PART_TYPE, DESIGN_GROUP, MODEL_INDICATOR, JT_FILE_STATUS, JT_FILE_NAME, OWNER)\n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
		printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
			return 0;
	}

	ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("Query[Latest Released Design Revision for ERC] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Item ID","Part Type"};
		char *cValues[2]  = {"*",inpparttype_strDup};
		//char *cValues[2]  = {"*","M"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Latest Released Design Revision for ERC] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Objects[Latest Released Design Revision for ERC] Exist So Continue..!!\n");fflush(stdout);
			//ITK_CALL(GRM_find_relation_type("IMAN_specification",&IMANSpecType));
		    //ITK_CALL(GRM_find_relation_type("IMAN_reference",&IMANRefType));
	        ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&IMANRenType));
			for (i = 0; i < n_itemobj_found; i++)
			//for (i = 0; i < 10; i++)
		    {
				tdesrev = titemobj_results[i];
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
                if(tc_strlen(item_id_str)>0)
                {
                    tc_strdup(item_id_str,&item_id_strDup);
                    trimwhitespace(item_id_strDup);
                }
                else
                {
                    tc_strdup("--",&item_id_strDup);
                    printf("\n Part Number Value is NULL..!!");fflush(stdout);
                }
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&Newitem_revseq_str));
                if(tc_strlen(Newitem_revseq_str)>0)
                {
                    tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
                    trimwhitespace(Newitem_revseq_strDup);
                    item_rev_str=strtok(Newitem_revseq_strDup,";");
                    item_seq_str=strtok(NULL,";");
                    if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
                    if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
                    trimwhitespace(item_rev_strDup);
                    trimwhitespace(item_seq_strDup);
                }
                else
                {
                    tc_strdup("--",&item_rev_strDup);
					tc_strdup("--",&item_seq_strDup);
                    printf("\n [New]Part Revision Sequence Value is NULL..!!");fflush(stdout);
                }
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"object_desc",&cItem_Desc));
				printf("\n Item Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
				if(tc_strlen(cItem_Desc)>0)
				{
						tc_strdup(cItem_Desc,&cItem_DescDup);
				}
				else
				{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL..!!");fflush(stdout);
				}
				trimwhitespace(cItem_DescDup);
				printf("\n Item Description Value After Dup & Trim: --------> <%s>", cItem_DescDup);fflush(stdout);
				STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
				printf("\n Item Description Final Value: --------> [%s]\n", cItem_DescDup);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartType",&item_parttype_str));
                if(tc_strlen(item_parttype_str)>0)
                {
                    tc_strdup(item_parttype_str,&item_parttype_strDup);
                    trimwhitespace(item_parttype_strDup);
                }
                else
                {
                    tc_strdup("--",&item_parttype_strDup);
                    printf("\n Part Type Value is NULL..!!");fflush(stdout);
                }
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_DesignGrp",&item_desgrp_str));
                if(tc_strlen(item_desgrp_str)>0)
                {
                    tc_strdup(item_desgrp_str,&item_desgrp_strDup);
                    trimwhitespace(item_desgrp_strDup);
                }
                else
                {
                    tc_strdup("--",&item_desgrp_strDup);
                    printf("\n Part Design Group Value is NULL..!!");fflush(stdout);
                }
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ModelIndicator",&item_model_str));
                if(tc_strlen(item_model_str)>0)
                {
                    tc_strdup(item_model_str,&item_model_strDup);
                    trimwhitespace(item_model_strDup);
                }
                else
                {
                    tc_strdup("--",&item_model_strDup);
                    printf("\n Part Model Indicator Value is NULL..!!");fflush(stdout);
                }
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"owning_user",&Owner));
			    if(tc_strlen(Owner)>0)
				{
					tc_strdup(Owner,&OwnerDup);
					trimwhitespace(OwnerDup);
					printf("\n Owning_User Value After Dup & Trim: --------> <%s>", OwnerDup);fflush(stdout);
					STRNG_replace_str(OwnerDup,","," ",&OwnerDup);
					STRNG_replace_str(OwnerDup,";"," ",&OwnerDup);
					STRNG_replace_str(OwnerDup,"\n"," ",&OwnerDup);
					STRNG_replace_str(OwnerDup,"'"," ",&OwnerDup);
					printf("\n Owning_User Final Value: --------> [%s]\n", OwnerDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&OwnerDup);
					printf("\n Owning_User Value is NULL..!!");fflush(stdout);
				}
				printf(" @@@@@@@@@@@@ IMAN RENDERING START @@@@@@@@@@@@\n");fflush(stdout);
				if(IMANRenType != NULLTAG)
	            {
					ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i],IMANRenType,&IMANRenCnt,&IMANRenAttach));
					printf("Dataset Object Count[IMAN_Rendering]: [%d]\n",IMANRenCnt);fflush(stdout);
					if(IMANRenCnt > 0)
					{
						for (j = 0; j < IMANRenCnt; j++)
						{
							//dataset = IMANRenAttach[j];
							//ITK_CALL(WSOM_ask_object_id_string(dataset,&SecObjName));
							//printf("SecObjName: [%s]\n",SecObjName);fflush(stdout);
							//ITK_CALL(AOM_ask_value_string(dataset,"object_type",&object_type));
							//printf("Object Type: [%s]\n",object_type);fflush(stdout);
							//ITK_CALL(AE_find_dataset_named_ref2(dataset,j,&RefName,&RefType,&RefObject));
							ITK_CALL(WSOM_ask_object_id_string(IMANRenAttach[j],&SecObjName));
							printf("SecObjName: [%s]\n",SecObjName);fflush(stdout);
							ITK_CALL(AOM_ask_value_string(IMANRenAttach[j],"object_type",&object_type));
							printf("Object Type: [%s]\n",object_type);fflush(stdout);
							ITK_CALL(AE_find_dataset_named_ref2(IMANRenAttach[j],0,&RefName,&RefType,&RefObject));
						    ITK_CALL(IMF_ask_original_file_name2(RefObject,&Orginal_Name));
                            printf("Before Set Orginal File Name: [%s]\n",Orginal_Name);fflush(stdout);
							if(tc_strlen(Orginal_Name)>0)
				            {
								tc_strdup(Orginal_Name,&Orginal_NameDup);
							}
							if(tc_strcmp(object_type,"DirectModel")==0)
							{
								if(tc_strlen(Orginal_Name)>0)
								{
								  fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,cItem_DescDup,item_parttype_strDup,item_desgrp_strDup,item_model_strDup,"Named_Ref_Present",Orginal_NameDup,OwnerDup);fflush(fpOutput_file);
								}
								else
								{
								  fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,cItem_DescDup,item_parttype_strDup,item_desgrp_strDup,item_model_strDup,"Named_Ref_Missing","--",OwnerDup);fflush(fpOutput_file);
								}
							}
							else
							{
							  printf("\n [object_type] is not [DirectModel]..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
					  fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,cItem_DescDup,item_parttype_strDup,item_desgrp_strDup,item_model_strDup,"Compare_Required","--",OwnerDup);fflush(fpOutput_file);
					}
				}
				else
				{
					printf("\n Relation Tag[IMAN_Rendering] Not Found..!!\n");fflush(stdout);
				}
			}						
		}
		else
		{
		   printf("\n Objects[Latest Released Design Revision for ERC] Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[Latest Released Design Revision for ERC] Tag Not Found..!!");fflush(stdout);
	}
	if(titemobj_results)
	{
	   MEM_free(titemobj_results);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_Datasethunttcua.c
* // ./linkitk -o tm_Datasethunttcua tm_Datasethunttcua.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DatasetHuntTCUA/tm_Datasethunttcua .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DatasetHuntTCUA/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DatasetHuntTCUA/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DatasetHuntTCUA/usage.txt .
* // ./tm_Datasethunttcua -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -type="M"
* // ./tm_Datasethunttcua -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -type="M"
*
***************************************************************************/