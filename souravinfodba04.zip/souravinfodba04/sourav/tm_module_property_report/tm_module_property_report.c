/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Module & Check It's Two Properties Value (Module Name & Keyword Description)  
*  File Name    :   tm_module_property_report.c
*  Created on   :   Sep 01st, 2023
*  Usage        :   tm_module_property_report
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     01/09/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	FILE* fpPart_List = NULL;
	char* PNo_Str = NULL;
	char* Module_No = NULL;
	char* Module_RevSeq = NULL;
	char* Module_KeywordDes = NULL;
	char* Module_Name = NULL;
	char* PNo_StrDup = NULL;
	char* Module_NoDup = NULL;
	char* Module_RevSeqDup = NULL;
	char* Module_KeywordDesDup = NULL;
	char* Module_NameDup = NULL;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[300]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	int no_ref = 0;
	int j =0;
	char *RptFile= (char *) malloc(400*sizeof(char));
	char *status= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char* cMAdd = NULL;
	char *ModAddress = (char *) malloc(400*sizeof(char));
	tag_t ModName_AttrID = NULLTAG;
	tag_t ModAddress_AttrID = NULLTAG;
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n New Time Stamp Generated");fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"Module_Property_Info_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 4)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			printf("\n Username --------> %s", cUSERID);fflush(stdout);
			printf("\n Password --------> %s", cPASS);fflush(stdout);
			printf("\n Group --------> %s", cGroup);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\n Return Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\n Teamcenter Login Success...");
				POM_get_user(&username, &tuser);
				printf("\n Logged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\n Teamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			fpPart_List = fopen("PartList.txt","r");
			fpOutput_file = fopen(RptFile, "w");
			fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ M O D U L E   P R O P E R T Y   U P D A T E ~~~~~~~~~~~~~~~");fflush(fpOutput_file);
            fprintf(fpOutput_file,"\n Module_No, Rev_Seq, Keyword_Description, Module_Name, Status");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Log File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			if(fpPart_List != NULL)
		    {	
			    printf("\n Part List is Not Null Moving Forward...");fflush(stdout);
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					PNo_Str=strtok(temp,"^");
					
					printf("\n Input Part Number String --------> %s", PNo_Str);fflush(stdout);			
					if(PNo_Str!=NULL)tc_strdup(PNo_Str,&PNo_StrDup);	
					if(PNo_StrDup!=NULL)trimwhitespace(PNo_StrDup);
					
					printf("\n Input Part Number Value After Dup & Trim --------> [%s]", PNo_StrDup);fflush(stdout);
				
					ITK_CALL(QRY_find2("Design Revision",&tItemobj));
			        printf("\n Return Value From Design Revision Query API is --------> %d", iFail);fflush(stdout);
                    if(tItemobj != NULLTAG)
			        {
							printf("\n Design Revision Found Successfully...");fflush(stdout);
					        char *cEntries[1]  = {"ID"};
							char *cValues[1]  = {PNo_StrDup};
							//char *cValues[1]  = {"5545D2B1172002"};
					        ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
					        printf("\n Return Value From DesignRevision Sequence Query Execute API is --------> %d", iFail);fflush(stdout);
					        printf("\n -----------------------------------------------\n");fflush(stdout);
					        printf("\n No of Revision Found --------> %d\n",n_itemobj_found);fflush(stdout);
					        printf("\n -----------------------------------------------\n");fflush(stdout);
							for (i = 0; i < n_itemobj_found; i++)
		                    {
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "item_id", &Module_No));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "item_revision_id", &Module_RevSeq));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_CategoryName", &Module_KeywordDes));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_ModuleName", &Module_Name));
								
								printf("\n Module Number: --------> [%s]", Module_No);fflush(stdout);
								printf("\n Module Rev_Seq: --------> [%s]", Module_RevSeq);fflush(stdout);
								printf("\n Module Keyword Description Before Dup & Trim & Replace: --------> [%s]", Module_KeywordDes);fflush(stdout);
								printf("\n Module Name Before Dup & Trim & Replace: --------> [%s]", Module_Name);fflush(stdout);
								
								if(Module_No!=NULL)tc_strdup(Module_No,&Module_NoDup);
                                if(Module_RevSeq!=NULL)tc_strdup(Module_RevSeq,&Module_RevSeqDup);
								if(Module_KeywordDes!=NULL)tc_strdup(Module_KeywordDes,&Module_KeywordDesDup);
								if(Module_Name!=NULL)tc_strdup(Module_Name,&Module_NameDup);
									
					            if(Module_NoDup!=NULL)trimwhitespace(Module_NoDup);
								if(Module_RevSeqDup!=NULL)trimwhitespace(Module_RevSeqDup);
								if(Module_KeywordDesDup!=NULL)trimwhitespace(Module_KeywordDesDup);
								if(Module_NameDup!=NULL)trimwhitespace(Module_NameDup);
								
								if(tc_strcmp(Module_KeywordDesDup,Module_NameDup)==0)
								{
									tc_strcpy(status,"OK");
								}
								else
								{
									tc_strcpy(status,"Not OK");
								}
								
		                        STRNG_replace_str(Module_KeywordDesDup,","," ",&Module_KeywordDesDup);
		                        STRNG_replace_str(Module_KeywordDesDup,";"," ",&Module_KeywordDesDup);
		                        STRNG_replace_str(Module_KeywordDesDup,"\n"," ",&Module_KeywordDesDup);
		                        STRNG_replace_str(Module_KeywordDesDup,"'"," ",&Module_KeywordDesDup);
								
								STRNG_replace_str(Module_NameDup,","," ",&Module_NameDup);
		                        STRNG_replace_str(Module_NameDup,";"," ",&Module_NameDup);
		                        STRNG_replace_str(Module_NameDup,"\n"," ",&Module_NameDup);
		                        STRNG_replace_str(Module_NameDup,"'"," ",&Module_NameDup);
								
		                        printf("\n Module Keyword Description After Dup & Trim & Replace: --------> [%s]", Module_KeywordDesDup);fflush(stdout);
								printf("\n Module Name After Dup & Trim & Replace: --------> [%s]", Module_NameDup);fflush(stdout);
								
								
								printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);
								printf("\n Module Number: --------> [%s]", Module_NoDup);fflush(stdout);
                                printf("\n Module Rev_Seq: --------> [%s]", Module_RevSeqDup);fflush(stdout);
								printf("\n Module Keyword Description: --------> [%s]", Module_KeywordDesDup);fflush(stdout);
								printf("\n Module Name: --------> [%s]", Module_NameDup);fflush(stdout);
								printf("\n Status: --------> [%s]", status);fflush(stdout); 
								printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);
								fprintf(fpOutput_file,"\n %s,%s,%s,%s,%s",Module_NoDup,Module_RevSeqDup,Module_KeywordDesDup,Module_NameDup,status);fflush(fpOutput_file);
		                    }
			        }
					else
					{
						printf("\n After Query Execution No Item Found...");fflush(stdout);
					}
					if (titemobj_results)
					{
						MEM_free(titemobj_results);
					}					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n Part No Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout); 
				fclose(fpOutput_file) ;           
				printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
				printf("\n Output File Closed Now\n");fflush(stdout); 
			}
			else 
			{
				printf("\n Part List is Null....");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if(tItemobj!=NULLTAG)
			{

				tc_strcpy(env_subject,"SUCCESS: MAIL FROM CVPROD MODULE INFO REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    Please Check Attached Report");
				tc_strcat(env_body,RptFile);
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			else
			{
				tc_strcpy(env_subject,"FAILED: MAIL FROM CVPROD MODULE INFO REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    There is an Issue in MODULE INFO Report Creation ");
				tc_strcat(env_body,"\n\n                  Please Check Log & Support user");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			
			printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);
			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}