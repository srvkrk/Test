/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Part & Update Part Property(Material Class, Part Category, Owner Design Dept, Denis Project Part? etc) 
*  File Name    :   tm_Part_Property_Update.c
*  Created on   :   Aug 07th, 2023
*  Usage        :   tm_Part_Property_Update
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     07/08/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	FILE* fpPart_List = NULL;
	char* PNo_Str = NULL;
	char* RevSeq_Str = NULL;
	char* MatClass_Str = NULL;
	char* PartCat_Str = NULL;
	char* DesDept_Str = NULL;
	char* DenPart_Str = NULL;
	char* StdPart_Str = NULL;
	char* SurfArea_Str = NULL;
	char* Vol_Str = NULL;
	char* PNo_StrDup = NULL;
	char* RevSeq_StrDup = NULL;
	char* MatClass_StrDup = NULL;
	char* PartCat_StrDup = NULL;
	char* DesDept_StrDup = NULL;
	char* DenPart_StrDup = NULL;
	char* StdPart_StrDup = NULL;
	char* SurfArea_StrDup = NULL;
	char* Vol_StrDup = NULL;
	char* OldPart = NULL;
	char* OldRevSeq = NULL;
	char* OldMatClass = NULL;
	char* OldPartCat = NULL;
	char* OldDesDept = NULL;
	logical OldDenPart = false;
	logical OldSpareInd = false;
	char* OldSrfArea = NULL;
	char* OldVol = NULL;
	char* NewPart = NULL;
	char* NewRevSeq = NULL;
	char* NewMatClass = NULL;
	char* NewPartCat = NULL;
	char* NewDesDept = NULL;
	logical NewDenPart = false;
	logical NewSpareInd = false;
	char* NewSrfArea = NULL;
	char* NewVol = NULL;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[300]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	int no_ref = 0;
	int j =0;
	char *RptFile= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n New Time Stamp Generated");fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"PartProperty_Update_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 4)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			printf("\n Username --------> %s", cUSERID);fflush(stdout);
			printf("\n Password --------> %s", cPASS);fflush(stdout);
			printf("\n Group --------> %s", cGroup);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\n Return Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\n Teamcenter Login Success...");
				POM_get_user(&username, &tuser);
				printf("\n Logged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\n Teamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			fpPart_List = fopen("PartList.txt","r");
			fpOutput_file = fopen(RptFile, "w");
			fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ P A R T   P R O P E R T Y   U P D A T E ~~~~~~~~~~~~~~~");fflush(fpOutput_file);
            fprintf(fpOutput_file,"\n TC_Part, Rev_Seq, TCE_MatClass, TCUA_MatClass, TCE_PartCategory, TCUA_PartCategory, TCE_DesDept, TCUA_DesDept, TCE_StdPart, TCUA_StdPart, TCE_SurfaceArea, TCUA_SurfaceArea, TCE_Volume, TCUA_Volume, Status");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Log File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			if(fpPart_List != NULL)
		    {	
			    printf("\n Part List is Not Null Moving Forward...");fflush(stdout);
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					PNo_Str=strtok(temp,"^");
					RevSeq_Str=strtok(NULL,"^");
					MatClass_Str=strtok(NULL,"^");
					PartCat_Str=strtok(NULL,"^");
					DesDept_Str=strtok(NULL,"^");
					DenPart_Str=strtok(NULL,"^");
					StdPart_Str=strtok(NULL,"^");
					SurfArea_Str=strtok(NULL,"^");
					Vol_Str=strtok(NULL,"^");
					printf("\n Input Part Number String --------> %s", PNo_Str);fflush(stdout);
					printf("\n Input Revision & Sequence String --------> %s", RevSeq_Str);fflush(stdout);
					printf("\n Input Material Class String --------> %s", MatClass_Str);fflush(stdout);
					printf("\n Input Part category String --------> %s", PartCat_Str);fflush(stdout);
					printf("\n Input Owner Design Department String --------> %s", DesDept_Str);fflush(stdout);
					printf("\n Input Denis Project Part? String --------> %s", DenPart_Str);fflush(stdout);
					printf("\n Input Standard Part? String --------> %s", StdPart_Str);fflush(stdout);
					printf("\n Input Surface Area String --------> %s", SurfArea_Str);fflush(stdout);
					printf("\n Input Volume String --------> %s\n", Vol_Str);fflush(stdout);
					
					if(PNo_Str!=NULL)tc_strdup(PNo_Str,&PNo_StrDup);
					if(RevSeq_Str!=NULL)tc_strdup(RevSeq_Str,&RevSeq_StrDup);
					if(MatClass_Str!=NULL)tc_strdup(MatClass_Str,&MatClass_StrDup);
					if(PartCat_Str!=NULL)tc_strdup(PartCat_Str,&PartCat_StrDup);
					if(DesDept_Str!=NULL)tc_strdup(DesDept_Str,&DesDept_StrDup);
					if(DenPart_Str!=NULL)tc_strdup(DenPart_Str,&DenPart_StrDup);
					if(StdPart_Str!=NULL)tc_strdup(StdPart_Str,&StdPart_StrDup);
					if(SurfArea_Str!=NULL)tc_strdup(SurfArea_Str,&SurfArea_StrDup);
					if(Vol_Str!=NULL)tc_strdup(Vol_Str,&Vol_StrDup);
					
					if(PNo_StrDup!=NULL)trimwhitespace(PNo_StrDup);
					if(RevSeq_StrDup!=NULL)trimwhitespace(RevSeq_StrDup);
					if(MatClass_StrDup!=NULL)trimwhitespace(MatClass_StrDup);
					if(PartCat_StrDup!=NULL)trimwhitespace(PartCat_StrDup);
					if(DesDept_StrDup!=NULL)trimwhitespace(DesDept_StrDup);
					if(DenPart_StrDup!=NULL)trimwhitespace(DenPart_StrDup);
					if(StdPart_StrDup!=NULL)trimwhitespace(StdPart_StrDup);
					if(SurfArea_StrDup!=NULL)trimwhitespace(SurfArea_StrDup);
					if(Vol_StrDup!=NULL)trimwhitespace(Vol_StrDup);
					
					printf("\n Input Part Number Value After Dup & Trim --------> [%s]", PNo_StrDup);fflush(stdout);
					printf("\n Input Revision & Sequence Value After Dup & Trim --------> [%s]", RevSeq_StrDup);fflush(stdout);
					printf("\n Input Material Class After Dup & Trim --------> [%s]", MatClass_StrDup);fflush(stdout);
					printf("\n Input Part Category After Dup & Trim --------> [%s]", PartCat_StrDup);fflush(stdout);
					printf("\n Input Owner design Department After Dup & Trim --------> [%s]", DesDept_StrDup);fflush(stdout);
					printf("\n Input Denis Project Part? After Dup & Trim --------> [%s]", DenPart_StrDup);fflush(stdout);
					printf("\n Input Standard Part? After Dup & Trim --------> [%s]", StdPart_StrDup);fflush(stdout);
					printf("\n Input Surface Area After Dup & Trim --------> [%s]", SurfArea_StrDup);fflush(stdout);
					printf("\n Input Volume After Dup & Trim --------> [%s]\n", Vol_StrDup);fflush(stdout);
					ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
			        printf("\n Return Value From DesignRevision Sequence Query API is --------> %d", iFail);fflush(stdout);
                    if(tItemobj != NULLTAG)
			        {
							printf("\n DesignRevision Sequence Found Successfully...");fflush(stdout);
					        char *cEntries[2]  = {"Revision","ID"};
							char *cValues[2]  = {RevSeq_StrDup,PNo_StrDup};
							//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
					        ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
					        printf("\n Return Value From DesignRevision Sequence Query Execute API is --------> %d", iFail);fflush(stdout);
					        printf("\n -----------------------------------------------\n");fflush(stdout);
					        printf("\n No of Revision Found --------> %d\n",n_itemobj_found);fflush(stdout);
					        printf("\n -----------------------------------------------\n");fflush(stdout);
							for (i = 0; i < n_itemobj_found; i++)
		                    {
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "item_id", &OldPart));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "item_revision_id", &OldRevSeq));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_MatlClass", &OldMatClass));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_SpareCriteria", &OldPartCat));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_DsgnDept", &OldDesDept));
								ITK_CALL(AOM_ask_value_logical(titemobj_results[i], "t5_DenisPart", &OldDenPart));
								ITK_CALL(AOM_ask_value_logical(titemobj_results[i], "t5_StdPartIndicator", &OldSpareInd));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_SurfaceArea", &OldSrfArea));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_Volume", &OldVol));
								
								printf("\n TC_Part: --------> [%s]", OldPart);fflush(stdout);
								printf("\n Rev_Seq: --------> [%s]", OldRevSeq);fflush(stdout);
								printf("\n Old Part Material Class: --------> [%s]", OldMatClass);fflush(stdout);
								printf("\n Old Part Category: --------> [%s]", OldPartCat);fflush(stdout);
								printf("\n Old Part Owner Design Dept: --------> [%s]", OldDesDept);fflush(stdout);
								printf("\n Old Denis Project Part?: --------> [%d]", OldDenPart);fflush(stdout);
								printf("\n Old Standard Part?: --------> [%d]", OldSpareInd);fflush(stdout);
								printf("\n Old Surface Area in SqMtr: --------> [%s]", OldSrfArea);fflush(stdout);
								printf("\n Old Volume in CuMtr: --------> [%s]", OldVol);fflush(stdout);
								ITK_CALL(AOM_lock(titemobj_results[i]));
								printf("\n Return Value From Checkout API is --------> %d", iFail);fflush(stdout);
								if(tc_strcmp(MatClass_StrDup," ")!=0)
								{
								   printf("\n Material Class UPDATING");fflush(stdout);
								   ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_MatlClass",MatClass_StrDup));
								   printf("\n Return Value From Material Class Set Value API is --------> %d", iFail);fflush(stdout);
								}
								if(tc_strcmp(PartCat_StrDup," ")!=0)
								{
								   printf("\n Part Category UPDATING");fflush(stdout);
								   ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_SpareCriteria",PartCat_StrDup));
								   printf("\n Return Value From Part Category Set Value API is --------> %d", iFail);fflush(stdout);
								}
								if(tc_strcmp(DesDept_StrDup," ")!=0)
								{
								   printf("\n Owner Design Department UPDATING");fflush(stdout);
								   ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_DsgnDept",DesDept_StrDup));
								   printf("\n Return Value From Owner Design Department Set Value API is --------> %d", iFail);fflush(stdout);
								}
								if(tc_strcmp(DenPart_StrDup," ")!=0)
								{
									printf("\n Denis Project Part? UPDATING\n");fflush(stdout);
									if(tc_strcmp(DenPart_StrDup,"-")==0)
									{
										ITK_CALL(AOM_set_value_logical(titemobj_results[i],"t5_DenisPart",false));
										printf("\n Return Value From Denis Project Part? Set Value API is --------> %d", iFail);fflush(stdout);
									}
									else if(tc_strcmp(DenPart_StrDup,"+")==0)
									{
										ITK_CALL(AOM_set_value_logical(titemobj_results[i],"t5_DenisPart",true));
										printf("\n Return Value From Denis Project Part? Set Value API is --------> %d", iFail);fflush(stdout);
									}
									else
									{
										printf("\n Sorry!! Incorerct Value For Denis Project Part?");fflush(stdout);
									}
								}
								if(tc_strcmp(StdPart_StrDup," ")!=0)
								{
									printf("\n Standard Part? UPDATING");fflush(stdout);
									if(tc_strcmp(StdPart_StrDup,"-")==0)
									{
										ITK_CALL(AOM_set_value_logical(titemobj_results[i],"t5_StdPartIndicator",false));
										printf("\n Return Value From Standard Part? Set Value API is --------> %d", iFail);fflush(stdout);
									}
									else if(tc_strcmp(StdPart_StrDup,"+")==0)
									{
										ITK_CALL(AOM_set_value_logical(titemobj_results[i],"t5_StdPartIndicator",true));
										printf("\n Return Value From Standard Part? Set Value API is --------> %d", iFail);fflush(stdout);
									}
									else
									{
										printf("\n Sorry!! Incorerct Value For Standard Part?");fflush(stdout);
									}
								}
								if(tc_strcmp(SurfArea_StrDup," ")!=0)
								{
								   printf("\n Surface Area in SqMtr UPDATING");fflush(stdout);
								   ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_SurfaceArea",SurfArea_StrDup));
								   printf("\n Return Value From Surface Area in SqMtr Set Value API is --------> %d", iFail);fflush(stdout);
								}
								if(tc_strcmp(Vol_StrDup," ")!=0)
								{
								   printf("\n Volume in CuMtr UPDATING");fflush(stdout);
								   ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_Volume",Vol_StrDup));
								   printf("\n Return Value From Volume in CuMtr Set Value API is --------> %d", iFail);fflush(stdout);
								}
								ITK_CALL(AOM_save(titemobj_results[i]));
								printf("\n Return Value From Save Value API is --------> %d", iFail);fflush(stdout);
	                            ITK_CALL(AOM_unlock(titemobj_results[i]));
								printf("\n Return Value From Checkin API is --------> %d", iFail);fflush(stdout);
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "item_id", &NewPart));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "item_revision_id", &NewRevSeq));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_MatlClass", &NewMatClass));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_SpareCriteria", &NewPartCat));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_DsgnDept", &NewDesDept));
								ITK_CALL(AOM_ask_value_logical(titemobj_results[i], "t5_DenisPart", &NewDenPart));
								ITK_CALL(AOM_ask_value_logical(titemobj_results[i], "t5_StdPartIndicator", &NewSpareInd));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_SurfaceArea", &NewSrfArea));
								ITK_CALL(AOM_ask_value_string(titemobj_results[i], "t5_Volume", &NewVol));
								const char* upDenPart = (NewDenPart == 0) ? "-" : "+";
                                const char* upStdPart = (NewSpareInd == 0) ? "-" : "+";
								printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);
								printf("\n TC_Part --------> %s", NewPart);fflush(stdout);
                                printf("\n Rev_Seq --------> %s", NewRevSeq);fflush(stdout);
								printf("\n Updated Material Class --------> %s", NewMatClass);fflush(stdout);
								printf("\n Updated Part Category --------> %s", NewPartCat);fflush(stdout);
								printf("\n Updated Design Department --------> %s", NewDesDept);fflush(stdout);
								printf("\n Updated Denis Project Part? --------> %s", upDenPart);fflush(stdout);
								printf("\n Updated Standard Part? --------> %s", upStdPart);fflush(stdout);
								printf("\n Updated Surface Area --------> %s", NewSrfArea);fflush(stdout);
								printf("\n Updated Volume --------> %s", NewVol);fflush(stdout);
								printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);
								fprintf(fpOutput_file,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",PNo_StrDup,RevSeq_StrDup,MatClass_StrDup,NewMatClass,PartCat_StrDup,NewPartCat,DesDept_StrDup,NewDesDept,DenPart_StrDup,upDenPart,StdPart_StrDup,upStdPart,SurfArea_StrDup,NewSrfArea,Vol_StrDup,NewVol,"UPDATED");fflush(fpOutput_file);
		                    }
			        }
					else
					{
						printf("\n After Query Execution No Item Found...");fflush(stdout);
					}
					if (titemobj_results)
					{
						MEM_free(titemobj_results);
					}					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n Part No Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout); 
				fclose(fpOutput_file) ;           
				printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
				printf("\n Output File Closed Now\n");fflush(stdout); 
			}
			else 
			{
				printf("\n Part List is Null....");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if(tItemobj!=NULLTAG)
			{

				tc_strcpy(env_subject,"SUCCESS: MAIL FROM CVPROD PART PROPERTY UPDATE REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    Please Check Attached Report");
				tc_strcat(env_body,RptFile);
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			else
			{
				tc_strcpy(env_subject,"FAILED: MAIL FROM CVPROD PART PROPERTY UPDATE REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    There is an Issue in Part Type Update Report Creation ");
				tc_strcat(env_body,"\n\n                  Please Check Log & Support user");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			
			printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);
			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}