/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Find Latest Item in TCUA Using POM Enquiry Based on Project Code & Design Group
*  File Name    :   tm_find_latest_item.c
*  Created on   :   June 28th, 2023
*  Usage        :   tm_find_latest_item
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     28/06/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#include <pom/enq/enq.h>
#define ITK_err 910001


int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf);
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
    int i;
    char *retStringf;
    //printf("\n count found %s ",mainStringf);fflush(stdout);
    retStringf = (char*) MEM_alloc(200);
    for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
    *(retStringf+i) = '\0';
    //printf("\n return string found %s ",retStringf);fflush(stdout);
    return retStringf;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)  
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[300]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	//int j =0;
	time_t	temptime;
	char GenDate[20];
	struct tm *timeptr;
	int ch;
	char* RptFile= (char *) malloc(400*sizeof(char));
	FILE* fpOutput_file = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char* cPCode = NULL;
	char* cDGrp = NULL;
	char* responseString = NULL;
	responseString =(char *)MEM_alloc(200);
	
	
	printf("\n Generating Curernt Time Stamp");fflush(stdout);
	temptime = time(NULL);
	tc_strcpy(GenDate,"");
	timeptr = (struct tm *)localtime(&temptime);
	ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"TM_Part_No_Generation");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 6)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			cPCode = ITK_ask_cli_argument("-pc=");
			cDGrp = ITK_ask_cli_argument("-dg=");
			printf("\nUsername --------> %s", cUSERID);fflush(stdout);
			printf("\nPassword --------> %s", cPASS);fflush(stdout);
			printf("\nGroup --------> %s", cGroup);fflush(stdout);
			printf("\nProject Code --------> %s", cPCode);fflush(stdout);
			printf("\nDesign Group --------> %s", cDGrp);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");fflush(stdout);
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			

			fpOutput_file = fopen(RptFile, "w");
			fprintf(fpOutput_file,"\n *******************************************************************************");fflush(stdout);
			fprintf(fpOutput_file,"\n **************** P A R T   N O   G E N E R A T I O N   R E P O R T ******************");fflush(stdout);
			fprintf(fpOutput_file,"\n *******************************************************************************");fflush(stdout);
            fprintf(fpOutput_file,"\n\n\n Part_No");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Output File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			printf("\n Input Project Code: -------> %s", cPCode);fflush(stdout);
			printf("\n Input Design Group: -------> %s", cDGrp);fflush(stdout);
			if((cPCode != NULL) && (tc_strcmp(cPCode,"")!=0) && (cDGrp != NULL) && (tc_strcmp(cDGrp,"")!=0))
			{
				//const char * select_attrs[]={"puid"};
				const char *PCode[]={cPCode};
				const char *DGrp[]={cDGrp};
				//const char *select_attrs[] = { "puid","item_revision_id" };
				//const char *select_attrs_Item[] = { "item_id" };
				//const char* object_type_data[]={"Design Revision","T5_ClrPartRevision","T5_CkdDmyRevision","T5_DummyPartRevision","T5_DuraFitPartRevision","T5_EE_PartRevision","T5_RawPartRevision"};
				int rows1 = 0;
				int cols1 = 0;
				void ***report1;
				//char *QryCmd = "Test123";
				
				int objtyplen = 1;
		int rlztyplen = 1;
		int ownUsrlen = 1;
		const char* object_type_data[]={"2121"};
		const char* object_type_data1[]={"69"};
		const char* fnd_lat_ERCRlz_lst=NULL;
		//const char* select_attrs[]={"item_id","item_revision_id","creation_date","last_mod_date","puid"};
		//const char* select_attrs[]={"puid","item_revision_id"};
		//const char *select_attrs_Item[] = { "item_id" };
		const char* release_status_data[]={"T5_LcsErcRlzd"};
		const char* owning_user_data[]={"loader"};
		int  rows = 0, columns = 0, i = 0;
		void ***report;
		char *pQry = "fnd_lat_ERCRlz_lst";
		const char* object_data[]={"Design Revision","T5_ClrPartRevision","T5_CkdDmyRevision","T5_DummyPartRevision","T5_DuraFitPartRevision","T5_EE_PartRevision","T5_RawPartRevision"};
		int objlen = 7;
		tag_t objtag1 = NULLTAG;
		
		
		
		
char *pQry1 = "QueryItemRevASC";
const char *partnumber[]={"543869100184"};
const char *objecttype[]={"Design Revision"};
char *pClass = "ItemRevision";
const char *select_attrs_ItemRev[] = { "puid", "creation_date" };
const char *select_attrs_Item[] = { "item_id" };

ITK_CALL(POM_enquiry_create(pQry1));
ITK_CALL(POM_enquiry_add_select_attrs(pQry1, "ItemRevision", 1,select_attrs_ItemRev));
ITK_CALL(POM_enquiry_set_string_value (pQry1,"partnumber_expr",1,partnumber,POM_enquiry_bind_value));
ITK_CALL(POM_enquiry_set_attr_expr (pQry1,"expr_part","Item","item_id",POM_enquiry_equal,"partnumber_expr"));
ITK_CALL(POM_enquiry_set_string_value (pQry1,"objecttype_expr",1,objecttype,POM_enquiry_bind_value));
ITK_CALL(POM_enquiry_set_attr_expr (pQry1,"expr_objecttype","ItemRevision","object_type",POM_enquiry_equal,"objecttype_expr"));
ITK_CALL(POM_enquiry_set_join_expr(pQry1, "join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
ITK_CALL(POM_enquiry_set_expr(pQry1, "combine_expr1","expr_part", POM_enquiry_and, "expr_objecttype"));
ITK_CALL(POM_enquiry_set_expr(pQry1, "combine_expr_2","combine_expr1", POM_enquiry_and, "join_expr1"));
ITK_CALL(POM_enquiry_set_where_expr(pQry1, "combine_expr2"));
ITK_CALL(POM_enquiry_add_order_attr(pQry1, "ItemRevision", "creation_date", POM_enquiry_asc_order));
POM_enquiry_execute(pQry1, &rows, &columns, &report);
ITK_CALL(POM_enquiry_delete(pQry1)); 
printf("\n Before For Loop Number of Rows:----> [%d]",rows);fflush(stdout);
printf("\n Before For Loop Number of Columns:----> [%d]",columns);fflush(stdout);
		
		             
					/* const char *select_attrs_ItemRev[] = { "puid", "item_revision_id" };
					const char *select_attrs_Item[] = { "item_id" };	
					const char *PrtType_val1={"V"};
					char *QryCmd1 = "fnd_lat";
					//const char *activeSeq_val1={"0"};
					//const char *value_list[] = { "ERC Review", "ERC Working","Rejected","Obsolete","Pending" };
					
					ITK_CALL(POM_enquiry_add_select_attrs(QryCmd1, "Design Revision", 1, select_attrs_ItemRev));
	                //ITK_CALL(POM_enquiry_add_select_attrs(QryCmd1, "Item", 1,select_attrs_Item));
					ITK_CALL(POM_enquiry_set_string_value(QryCmd1, "value", 1, &PrtType_val1,POM_enquiry_bind_value));
					//ITK_CALL(POM_enquiry_set_join_expr(QryCmd1, "expression_join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
					ITK_CALL(POM_enquiry_set_attr_expr (QryCmd1, "expression_partType", "Design Revision", "t5_PartType", POM_enquiry_equal, "value"));
	                //ITK_CALL(POM_enquiry_set_expr (QryCmd1,"expression","expression_join_expr1",POM_enquiry_and,"expression_partType"));
					ITK_CALL(POM_enquiry_set_where_expr ( QryCmd1, "expression" ));
	                ITK_CALL(POM_enquiry_add_order_attr(QryCmd1, "Item", "item_id", POM_enquiry_asc_order));
                    ITK_CALL(POM_enquiry_add_order_attr(QryCmd1, "ItemRevision", "item_revision_id", POM_enquiry_asc_order));
					POM_enquiry_execute(QryCmd1, &rows, &columns, &report);
	                ITK_CALL(POM_enquiry_delete(QryCmd1)); 
					printf("\n Before For Loop Number of Rows:----> [%d]",rows);fflush(stdout);
				    printf("\n Before For Loop Number of Columns:----> [%d]",columns);fflush(stdout); */
		
		            
					/* const char* select_attrs[]={"item_revision_id"};
		            int n_rows = 0, n_cols = 0;
					char* FinalItemId= (char *) malloc(10*sizeof(char));
					tc_strcpy(FinalItemId,"54720525R");
                    tc_strcat(FinalItemId,"*");
                    printf("\n FinalItemId=%s",FinalItemId);
                    const char *str_list[15]={FinalItemId};
                    printf("\nstr_list[0]=%s",str_list[0]);
					tag_t objtag1 = NULLTAG;
	                char *latest_item = NULL;
				    //char *latest_itemDup = NULL;
		
		            printf("POM Enquiry Excustion Started....");fflush(stdout);
		            ITK_CALL(POM_enquiry_create ("find_TechSpec_by_type"));
                    ITK_CALL(POM_enquiry_add_select_attrs ("find_TechSpec_by_type","Item", 1, select_attrs));
                    ITK_CALL(POM_enquiry_set_string_value ("find_TechSpec_by_type","attrval",1,str_list,POM_enquiry_bind_value));
                    ITK_CALL(POM_enquiry_set_attr_expr ("find_TechSpec_by_type","expr1", "Item","item_id",POM_enquiry_like, "attrval"));
                    ITK_CALL(POM_enquiry_set_where_expr ("find_TechSpec_by_type","expr1"));
                    ITK_CALL(POM_enquiry_add_order_attr( "find_TechSpec_by_type", "Item", "item_id", POM_enquiry_desc_order ));
                    ITK_CALL(POM_enquiry_execute("find_TechSpec_by_type", &n_rows, &n_cols, &report));
                    ITK_CALL(POM_enquiry_delete("find_TechSpec_by_type")); 
					printf("POM Enquiry Excustion Ended....");fflush(stdout);
                    printf("\nB4 cal FinalItemId=%s row=%d col=%d report=%s",FinalItemId,n_rows,n_cols,report);
					exit(0);	
					if (n_rows != 0)
					{
						int cnt = 0;
					   for (cnt =0; cnt<n_rows; cnt++)
					   {	   
							objtag1 = *(tag_t*)(report[cnt][0]);
							
							ITK_CALL(AOM_ask_value_string(objtag1,"item_id",&latest_item));
							//printf("\n Number of Rows:----> [%d]",n_rows);fflush(stdout);
							//printf("\n Number of Columns:----> [%d]",n_cols);fflush(stdout);
							printf("\n Latest Item No:----> [%s]",latest_item);fflush(stdout);
							
					   }
					} */
		
		
		/* ITK_CALL(POM_enquiry_create(pQry));
		ITK_CALL(POM_enquiry_add_select_attrs (pQry,"ItemRevision",1,select_attrs));
		//ITK_CALL(POM_enquiry_add_select_attrs(pQry, "Item", 1,select_attrs_Item));

		ITK_CALL(POM_enquiry_set_string_value (pQry,"object_type_expr",objtyplen,object_type_data,POM_enquiry_bind_value));
		ITK_CALL(POM_enquiry_set_attr_expr (pQry,"join_expr2","ItemRevision","t5_ProjectCode",POM_enquiry_in,"object_type_expr"));

        ITK_CALL(POM_enquiry_set_string_value (pQry,"object_type_expr2",objlen,object_data,POM_enquiry_bind_value));
		ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_object_type_in","ItemRevision","object_type",POM_enquiry_in,"object_type_expr2"));


        ITK_CALL(POM_enquiry_set_string_value (pQry,"object_type_expr1",objtyplen,object_type_data1,POM_enquiry_bind_value));
		ITK_CALL(POM_enquiry_set_attr_expr (pQry,"join_expr3","ItemRevision","t5_DesignGrp",POM_enquiry_in,"object_type_expr1"));
        
		ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr1","join_expr2", POM_enquiry_and, "join_expr3"));
		
		ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr2","combine_expr1", POM_enquiry_and, "expr_object_type_in"));
		
		//ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));

		//ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr","join_expr1", POM_enquiry_and, "combine_expr1"));
		//ITK_CALL(POM_enquiry_set_where_expr (pQry,"combine_expr"));
		
		ITK_CALL(POM_enquiry_set_where_expr (pQry,"combine_expr2"));

		ITK_CALL(POM_enquiry_add_order_attr (pQry, "ItemRevision", "creation_date", POM_enquiry_desc_order));

		printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
		ITK_CALL(POM_enquiry_execute(pQry, &rows, &columns, &report));
		printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
		ITK_CALL(POM_enquiry_delete(pQry));
		printf(" \n number of rows %d and coloumn %d\n",rows,columns);fflush(stdout); */
				
				/* ITK_CALL(POM_enquiry_create(QryCmd));
				printf("\n Return Value From POM_enquiry_create --------> %d", iFail);fflush(stdout);
				ITK_CALL(POM_enquiry_add_select_attrs(QryCmd, "ItemRevision", 1, select_attrs));
				printf("\n Return Value From POM_enquiry_add_select_attrs --------> %d", iFail);fflush(stdout);
				ITK_CALL(POM_enquiry_set_string_value(QryCmd, "Project_Code", 1, PCode, POM_enquiry_bind_value));
				printf("\n Return Value From POM_enquiry_set_string_value --------> %d", iFail);fflush(stdout);
				ITK_CALL(POM_enquiry_set_string_value(QryCmd, "Design_Grp", 1, DGrp, POM_enquiry_bind_value));
				printf("\n Return Value From POM_enquiry_set_string_value --------> %d", iFail);fflush(stdout);
				ITK_CALL(POM_enquiry_set_attr_expr(QryCmd, "expression_pcode", "ItemRevision", "t5_ProjectCode", POM_enquiry_equal, "Project_Code"));
				printf("\n Return Value From POM_enquiry_set_attr_expr --------> %d", iFail);fflush(stdout);
				ITK_CALL(POM_enquiry_set_attr_expr(QryCmd, "expression_dgroup", "ItemRevision", "t5_DesignGrp", POM_enquiry_equal, "Design_Grp"));
				printf("\n Return Value From POM_enquiry_set_attr_expr --------> %d", iFail);fflush(stdout);
				ITK_CALL(POM_enquiry_set_expr(QryCmd, "expression", "expression_pcode", POM_enquiry_and, "expression_dgroup"));
				printf("\n Return Value From POM_enquiry_set_expr --------> %d", iFail);fflush(stdout);
				ITK_CALL(POM_enquiry_set_where_expr(QryCmd, "expression"));
				printf("\n Return Value From POM_enquiry_set_where_expr --------> %d", iFail);fflush(stdout); 
	            ITK_CALL(POM_enquiry_add_order_attr(QryCmd, "ItemRevision", "puid", POM_enquiry_desc_order));
				printf("\n Return Value From POM_enquiry_add_order_attr --------> %d", iFail);fflush(stdout);
				ITK_CALL(POM_enquiry_execute(QryCmd, &rows1, &cols1, &report1));
				printf("\n Return Value From POM_enquiry_execute --------> %d", iFail);fflush(stdout);
	            ITK_CALL(POM_enquiry_delete(QryCmd));
                printf("\n Return Value From POM_enquiry_delete --------> %d", iFail);fflush(stdout); */				
				
	            //tag_t objtag1 = NULLTAG;
	            char *latest_item = NULL;
				char *latest_itemDup = NULL;
				printf("\n Before For Loop Number of Rows:----> [%d]",rows1);fflush(stdout);
				printf("\n Before For Loop Number of Columns:----> [%d]",cols1);fflush(stdout);
				if (rows1 != 0)
				{
					int cnt = 0;
				   for (cnt =0; cnt<rows1; cnt++)
				   {	   
						objtag1 = *(tag_t*)(report1[cnt][0]);
						
						ITK_CALL(AOM_ask_value_string(objtag1,"item_id",&latest_item));
						printf("\n Number of Rows:----> [%d]",rows1);fflush(stdout);
						printf("\n Number of Columns:----> [%d]",cols1);fflush(stdout);
						printf("\n Latest Item No:----> [%s]",latest_item);fflush(stdout);
						
				   }
				}
				
				if(tc_strlen(latest_item)>0)
				{
					tc_strdup(latest_item, &latest_itemDup);
					printf("\n Latest Item Value After Dup --------> %s\n", latest_itemDup);fflush(stdout);
				}
				else
				{
					tc_strdup("", &latest_itemDup);
					printf("\n Latest Item Value is NULL \n");fflush(stdout);
				}
				trimwhitespace(latest_itemDup);
				printf("\n Latest Item Value After Trim --------> %s\n", latest_itemDup);fflush(stdout);
				char *PreSrNo = NULL;
				char *SrNo = NULL;
				int InSrNo = 0;
				PreSrNo = subString(latest_itemDup,0,8);
				SrNo = subString(latest_itemDup,8,4);
				printf("\n Pre Serial No --------> %s\n", PreSrNo);fflush(stdout);
				printf("\n Serial No --------> %s\n", SrNo);fflush(stdout);
				InSrNo = atoi(SrNo);
				InSrNo = InSrNo + 1;
				printf("\n Next Serial No --------> %s\n", InSrNo);fflush(stdout);
				char result[100] = {0};
				sprintf(result, "%d", InSrNo);
                printf("\n Incremented Serial No --------> %s\n", result);
				tc_strcat(PreSrNo,result);
				tc_strcpy(responseString,PreSrNo);
				printf("\n Final Part No --------> %s\n", responseString);
				printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
				printf("\n Response String:Part Number -----> <%s> \n",responseString);fflush(stdout);
				printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
			    printf("\nData Print Start on Report File...");fflush(stdout);
				fprintf(fpOutput_file,"\n %s",responseString);fflush(fpOutput_file);
				printf("\nData Print End on Report File...");fflush(stdout);
			}
			else
			{
				printf("\nSorry! Entered Project Code or Design Group is NULL");fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
	        fclose(fpOutput_file) ;           
	        printf("\n Report File Closed Successfully\n");fflush(stdout);
			
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if(responseString != NULL)
			{

				tc_strcpy(env_subject,"SUCCESS: MAIL FROM UAPROD PART NO GENERATION REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    Part No Generated Successfully");
				tc_strcat(env_body,"\n\n                    Part Number");
		        tc_strcat(env_body,": ");
		        tc_strcat(env_body,responseString);
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			else
			{
				tc_strcpy(env_subject,"FAILED: MAIL FROM UAPROD PART NO GENERATION REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    There is an Issue in Part No Generation");
				tc_strcat(env_body,"\n\n                    Please Check Log & Support user");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			
			printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);
			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"rajeshbasak.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}