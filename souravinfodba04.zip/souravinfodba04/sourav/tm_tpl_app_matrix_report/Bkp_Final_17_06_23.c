/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   BOM
*  Description  :   Expand Vehicles First Level Child 
*  File Name    :   tm_tpl_app_matrix.c
*  Created on   :   June 10th, 2023
*  Usage        :   tm_tpl_app_matrix
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     13/06/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -plat=<Platform Name> (Required)\n"
		" -svr=<SVR> (Required)\n"
		" -rrule=<Revision Rule> (Required)\n"
        );	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport)
{
		char* cLevel = NULL;
		char* cRev_Name = NULL;
		char* cItem_Id = NULL;
		char* cRevision = NULL;
		//char* cParent = NULL;
		char* cOwn_Group = NULL;
		char* cOwn_User = NULL;
		char* cQuantity = NULL;
		//char* cFind_No = NULL;
		char* cPacked = NULL;
		char* cDRAR = NULL;
		char* cPart_Type = NULL; 
		int j =0;
		int iFail = ITK_ok;
		int iAttribute = 0;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		//FILE *fpOutput_file = NULL;
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_level_starting_0", &cLevel));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_object_name", &cRev_Name));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cRevision));
			//ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_formatted_parent_name", &cParent));
		    ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_owning_group", &cOwn_Group));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_owning_user", &cOwn_User));
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			//ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_sequence_no", &cFind_No));
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nLevel: %s", cLevel);
			printf("\nRevision Name: %s", cRev_Name);
			printf("\nItem ID: %s", cItem_Id);
			printf("\nRevision ID: %s", cRevision);
			//printf("\nParent: %s", cParent);
			printf("\nOwning Group: %s", cOwn_Group);
			printf("\nOwning User: %s", cOwn_User);
			printf("\nQuantity: %s", cQuantity);
			//printf("\nFind No: %s", cFind_No);
			printf("\n-------------------------------------------------------------------------");
			fprintf(FP_OutputReport,"\n %s,%s,%s,%s,%s,%s",cLevel,cItem_Id,cRevision,cOwn_Group,cOwn_User,cQuantity);fflush(FP_OutputReport);
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found --------> %d\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			}
		}
		return iFail;
}

int bom_sub_module(tag_t tSub_Children, char* Sub_Child_rrule, char* top_child_qty, FILE* FReport)
{
	
	tag_t Sub_Child_bom_window = NULLTAG;
	tag_t subrule = NULLTAG;
	//int subrulefound = 0;
	//tag_t* subclosurerule = NULL;
	//tag_t sub_close_tag = NULLTAG;
	//char** subrulename = NULL;
    //char** subrulevalue = NULL;
	tag_t tSub_Child = NULLTAG;
	char* cSubLevel = NULL;
	char* cSubRev_Name = NULL;
	char* cSubItem_Id = NULL;
	char* cSubRevision = NULL;
	//char* cSubParent = NULL;
	char* cSubOwn_Group = NULL;
	char* cSubOwn_User = NULL;
	//char* cSubQuantity = NULL;
	//char* cSubFind_No = NULL;
	int iFail = ITK_ok;
	int iSubNumber_Child = 0;
	tag_t* tBOM_Children = NULLTAG;
	
	char* cSubSubLevel = NULL;
	char* cSubSubItem_Id = NULL;
	char* cSubSubRevision = NULL;
	char* cSubSubParent = NULL;
	char* cSubSubQuantity = NULL;
			
	ITK_CALL(BOM_create_window(&Sub_Child_bom_window));
	printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
    //ITK_CALL(CFM_find("ERC release and above", &rule))
	ITK_CALL(CFM_find(Sub_Child_rrule, &subrule));
	printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
    ITK_CALL(BOM_set_window_config_rule(Sub_Child_bom_window, subrule));
	printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
	/* ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
	printf("\n No of Rule Found --------> %d\n",subrulefound);fflush(stdout);
	if (subrulefound > 0)
	{
		sub_close_tag = subclosurerule[0];
	}
	ITK_CALL(BOM_window_set_closure_rule(Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
	printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout); */
	ITK_CALL(BOM_set_window_pack_all(Sub_Child_bom_window, TRUE));
	printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
	ITK_CALL(BOM_set_window_top_line(Sub_Child_bom_window, NULLTAG, tSub_Children, NULLTAG, &tSub_Child));
	printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
	if(tSub_Child != NULLTAG)
    {
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_level_starting_0", &cSubLevel));
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_rev_object_name", &cSubRev_Name));
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_item_item_id", &cSubItem_Id));
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_rev_item_revision_id", &cSubRevision));
		//ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_formatted_parent_name", &cSubParent));
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_rev_owning_group", &cSubOwn_Group));
		ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_rev_owning_user", &cSubOwn_User));
		//ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_quantity", &cSubQuantity));
		//ITK_CALL(AOM_UIF_ask_value(tSub_Child, "bl_sequence_no", &cSubFind_No));
		printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
		printf("\nLevel: %s", cSubLevel);
		printf("\nRevision Name: %s", cSubRev_Name);
		printf("\nItem ID: %s", cSubItem_Id);
		printf("\nRevision ID: %s", cSubRevision);
		//printf("\nParent: %s", cSubParent);
		printf("\nOwning Group: %s", cSubOwn_Group);
		printf("\nOwning User: %s", cSubOwn_User);
		printf("\nQuantity: %s", top_child_qty);
		//printf("\nFind No: %s", cSubFind_No);
		printf("\n-------------------------------------------------------------------------");
		fprintf(FReport,"\n %s,%s,%s,%s,%s,%s",cSubLevel,cSubItem_Id,cSubRevision,cSubOwn_Group,cSubOwn_User,top_child_qty);fflush(FReport);
		ITK_CALL(BOM_line_ask_all_child_lines(tSub_Child, &iSubNumber_Child, &tBOM_Children));
		printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
		printf("\n No of Children Found --------> %d\n",iSubNumber_Child);fflush(stdout);
		if(iSubNumber_Child>0)
		{
			//bom_sub_child(tBOM_Children, iSubNumber_Child);
			printf("\n!!!!!!!!! N O   O F   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
			bom_sub_child(tBOM_Children, iSubNumber_Child, FReport);
			/* int j = 0;
			for(j = 0; j < iSubNumber_Child; j++)
		    {
				ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_level_starting_0", &cSubSubLevel));
				ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_item_item_id", &cSubSubItem_Id));
				ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_rev_item_revision_id", &cSubSubRevision));
				ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_formatted_parent_name", &cSubSubParent));
				ITK_CALL(AOM_UIF_ask_value(tBOM_Children[j], "bl_quantity", &cSubSubQuantity));
				printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
				printf("\nLevel: %s", cSubSubLevel);
				printf("\nItem ID: %s", cSubSubItem_Id);
				printf("\nRevision ID: %s", cSubSubRevision);
				printf("\nParent: %s", cSubSubParent);
				printf("\nQuantity: %s", cSubSubQuantity);
				printf("\n-------------------------------------------------------------------------");
			}
			if(tBOM_Children)
	        {
		       MEM_free(tBOM_Children);
	        } */
		}
    }
	ITK_CALL(BOM_close_window(Sub_Child_bom_window));
	printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
	return iFail;
}	

int Platform_SVR(char* Platform,char* SVR,char* RevisionRule,FILE* PMReport)
{
	FILE 	*InputFile;
	
	//int ifail = ITK_ok;
	int iFail = 0;
	tag_t  objTypeTagDi1=NULLTAG;		
    tag_t  plat = NULLTAG;
	tag_t  rev  = NULLTAG;
	tag_t RevTypTag	= NULLTAG;
	char* RevTyp = NULL;
	tag_t VariqueryTag = NULLTAG;
	
    ITK_CALL(ITEM_find_item(Platform, &plat));
	printf("\nReturn Value From PlatForm Find API --------> %d", iFail);fflush(stdout);	
	ITK_CALL(ITEM_ask_latest_rev(plat, &rev));
    printf("\nReturn Value From PlatForm Latest Rev API --------> %d", iFail);fflush(stdout);	
	ITK_CALL(TCTYPE_ask_object_type(rev, &RevTypTag));
	printf("\nReturn Value From PlatForm Object Type API --------> %d", iFail);fflush(stdout);
	ITK_CALL(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\nReturn Value From PlatForm Name API --------> %d", iFail);fflush(stdout);
	printf("\nPlatform Revision Type: [%s]\n", RevTyp);fflush(stdout);

	ITK_CALL(QRY_find2("VariantRule", &VariqueryTag));
	printf("\nReturn Value From Varient Rule Query API is --------> %d", iFail);fflush(stdout);

	if(VariqueryTag!=NULLTAG)
	{
	   printf("\nVarient Rule Query Found Successfully...");fflush(stdout);
	}
	else
	{
	   printf("\n Varient Rule Query Not Found");fflush(stdout);
	}
    char** valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
	valuesNonColSvr[0] = SVR ;
	//valuesNonColSvr[0] = "54644625000R_A";
	int n_entriesV = 1;
	char *qry_entries3[1] = {"Name"};
	//char *qry_values3[1] = {"*"};
	int resultCountVNCol = 0;
	tag_t* outputVNCol_tags = NULLTAG;
	
    ITK_CALL(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
	printf("\n Return Value From Varient Query Execute API is --------> %d", iFail);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
    printf("\n No of Result Found --------> %d\n",resultCountVNCol);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
    
	tag_t  VarientRuletag = NULLTAG;
	if (resultCountVNCol > 0)
	{
		VarientRuletag = outputVNCol_tags[0];
	}
	else
	{
		printf("\n NonColour-SVR-VarientRule Not Present:  [%s]\n", SVR); fflush(stdout);
		exit(0);
	}
    char* objecttype = NULL;
	ITK_CALL(AOM_ask_value_string(VarientRuletag,"object_type",&objecttype));
	printf("\n Varient Rule Object Type:  [%s]\n",objecttype);fflush(stdout);
    tag_t bom_view = NULLTAG;
	
	if(tc_strcmp(RevTyp,"T5_PlatformRevision") == 0)
	{

		if(rev != NULLTAG)
		{
			tag_t view_type = NULLTAG;
			ITK_CALL(PS_find_view_type("view", &view_type));
			printf("\n Return Value From View Type Find API is --------> %d", iFail);fflush(stdout);
            if(view_type != NULLTAG)
			{
				tag_t item = NULLTAG;
				int n_bom_views = 0;
				tag_t* bom_views = NULL;
				ITK_CALL(ITEM_ask_item_of_rev(rev, &item));
				printf("\n Return Value From Item of Rev API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(ITEM_list_bom_views(item, &n_bom_views, &bom_views));
				printf("\n Return Value From List BOM View API is --------> %d", iFail);fflush(stdout);
                bom_view = bom_views[0];
			}
			else
			{
				printf("\n View Type Tag Not Found \n");fflush(stdout);
			}
		}


		if(bom_view != NULLTAG)
		{
			tag_t bom_window = NULLTAG;
			tag_t rule = NULLTAG;
			int rulefound = 0;
			tag_t* closurerule = NULL;
			tag_t close_tag = NULLTAG;
			char** rulename = NULL;
            char** rulevalue = NULL;
			tag_t tPlatform = NULLTAG;
			tag_t bom_variant_rule = NULLTAG;
			tag_t objTypeTag = NULLTAG;
			char type_name[TCTYPE_name_size_c+1];
			tag_t e_block = NULLTAG;
			
			ITK_CALL(BOM_create_window(&bom_window));
			printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
			//ITK_CALL(CFM_find("ERC release and above", &rule))
			ITK_CALL(CFM_find(RevisionRule, &rule));
			printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_config_rule(bom_window, rule));
			printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
			ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule));
			printf("\n No of Rule Found --------> %d\n",rulefound);fflush(stdout);
			if (rulefound > 0)
			{
				close_tag = closurerule[0];
			}
			ITK_CALL(BOM_window_set_closure_rule(bom_window,close_tag,0,rulename,rulevalue));
			printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_pack_all(bom_window, FALSE));
			printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
			ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, rev, NULLTAG, &tPlatform));
			printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
			ITK_CALL( BOM_window_ask_variant_rule(bom_window, &bom_variant_rule));
			printf("\n Return Value From BOM Window Ask Varient Rule API is --------> %d", iFail);fflush(stdout);
            ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
			printf("\n Return Value From BOM Varient Rule Object Type Tag API is --------> %d", iFail);fflush(stdout);
		    ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
            printf("\nBOM Varient Rule Type Name: [%s]\n", type_name);fflush(stdout);			

			//ITK_CALL(ITEM_ask_rev_variants(rev, &e_block));
			//printf("\n Return Value From Item Ask Revision Varient API is --------> %d", iFail);fflush(stdout);		
			
            int n_lines,n_arcmod = 0;
	        tag_t* tarcmod = NULL;			
			if(tPlatform != NULLTAG)
			{
				//ITK_CALL(BOM_line_ask_child_lines(tPlatform, &n_arcmod, &tarcmod));
				//printf("\n Return Value From BOM Line Ask Child Line API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(BOM_window_hide_unconfigured(bom_window));
				printf("\n Return Value From BOM Window Hide Configured API is --------> %d", iFail);fflush(stdout);
				ITK_CALL(BOM_window_show_variants(bom_window));
				printf("\n Return Value From BOM Window Show Varients API is --------> %d", iFail);fflush(stdout);
				//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config));
				//if(BOM_variant_config_apply (bom_variant_config));
                //if(BOM_variant_rule_apply(primary1));				
				ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
				printf("\n Return Value From BOM Window Apply Varient Configuration API is --------> %d", iFail);fflush(stdout);
               //if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list));
				ITK_CALL(BOM_window_hide_variants(bom_window));
                ITK_CALL(BOM_line_ask_child_lines(tPlatform, &n_arcmod, &tarcmod));
				printf("\n BOM Line Ask Child Lines (Architecture_Module) --------> %d\n",n_arcmod);fflush(stdout);
				int blqu = 0;
				tag_t Childobject4 = NULLTAG;
				tag_t Childobject3 = NULLTAG;
				//int p4 = 0;
				tag_t objTypeTagDi = NULLTAG;
				//tag_t Childobject2 = NULLTAG;
				//char type_name2[TCTYPE_name_size_c+1];
				char* top_child_item_id = NULL;
	            char* top_child_item_revision_id = NULL;
				char* top_child_Quantity = NULL;
	            //char* child_bl_formula = NULL; 
				int n_module = 0;
				tag_t* tmodule = NULLTAG;
                ITK_CALL( BOM_line_look_up_attribute ("bl_quantity",&blqu));
                if (n_arcmod >0)
				{
					int p1 = 0;
					for(p1=0; p1 < n_arcmod; p1++)
					{
						if(Childobject4) Childobject4 = NULLTAG;
						Childobject4=tarcmod[p1];
						//ITK_CALL(BOM_line_unpack(Childobject4));
                        ITK_CALL(BOM_line_ask_child_lines(Childobject4, &n_module, &tmodule));
						printf("\n BOM Line Ask Child Lines (Module) --------> %d\n",n_module);fflush(stdout);
						int n_submodule = 0;
				        tag_t* tsubmodule = NULLTAG;
                        if(n_module >0)
						{
							int p4 = 0;
							for (p4=0; p4 < n_module; p4++)
							{
								if(Childobject3) Childobject3 = NULLTAG;
								Childobject3=tmodule[p4];

								ITK_CALL(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
								printf("\n Return Value From Object Type API is --------> %d", iFail);fflush(stdout);
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_item_item_id", &top_child_item_id ));
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &top_child_item_revision_id));
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_quantity", &top_child_Quantity));
						        printf("\n########## M O D U L E    D E T A I L S #############");fflush(stdout);		
								printf("\nUnique Module ID: %s", top_child_item_id);fflush(stdout);
			                    printf("\nUnique Module Revision ID: %s", top_child_item_revision_id);fflush(stdout);
								printf("\nUnique Module Quantity: %s", top_child_Quantity);fflush(stdout);
								printf("\nUnique Revision Rule: %s", RevisionRule);fflush(stdout);
								printf("\n########## M O D U L E    D E T A I L S #############");fflush(stdout);
								tag_t tchild_item = NULLTAG;
								ITK_CALL(ITEM_find_item(top_child_item_id, &tchild_item));
								printf("\n Return Value From Item Find Item API is --------> %d", iFail);fflush(stdout);
								tag_t Childrev = NULLTAG;
								//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
								ITK_CALL(ITEM_find_revision(tchild_item, top_child_item_revision_id, &Childrev));
								printf("\n Return Value From Item Find Revision API is --------> %d", iFail);fflush(stdout);
								if(Childrev != NULLTAG)
								{
									printf("\n!!!!!!!!! T E S T I N G    O K !!!!!!!!!!");fflush(stdout);
									bom_sub_module(Childrev,RevisionRule,top_child_Quantity,PMReport);
								}
								//exit(0); 
								//bom_sub_child(tmodule, n_module);
								
										
								//int n_submodule = 0;
				                //tag_t* tsubmodule = NULLTAG;
								//int p5 = 0;
								//char* cLeveltest = NULL;  
								//char* cRev_Nametest = NULL; 
								//char* cItem_Idtest = NULL; 
								/* ITK_CALL(BOM_line_unpack(Childobject3));
								printf("\n Return Value From BOM Line Unpack API is --------> %d", iFail);fflush(stdout);
								ITK_CALL(BOM_line_ask_all_child_lines(Childobject3, &n_submodule, &tsubmodule));
								printf("\n BOM Line Ask Child Lines (Sub_Module) --------> %d\n",n_submodule);fflush(stdout);
								exit(0); */
								/* if(n_submodule > 0)
								{
									for (p5=0; p5 < n_submodule; p5++)
							        {
								       if(Childobject2) Childobject2 = NULLTAG;
								       Childobject2=tsubmodule[p5];
									   ITK_CALL(AOM_UIF_ask_value(Childobject2, "bl_level_starting_0", &cLeveltest));
			                           ITK_CALL(AOM_UIF_ask_value(Childobject2, "bl_rev_object_name", &cRev_Nametest));
			                           ITK_CALL(AOM_UIF_ask_value(Childobject2, "bl_item_item_id", &cItem_Idtest));
									   printf("\n ################# T E S T   R E S U L T    S U B - M O D U L E ###############");
									   printf("\nLevel Test: %s", cLeveltest);
									   printf("\nRevision Name Test: %s", cRev_Nametest);
			                           printf("\nItem ID Test: %s", cItem_Idtest);
									   printf("\n ################# T E S T   R E S U L T    S U B - M O D U L E ###############");
									   //bom_sub_child(Childobject2, n_submodule);
									}
								}  */
								
								
								
								/* ITK_CALL(TCTYPE_ask_name(objTypeTagDi,type_name2));	  
								printf("\nObject Type Name2: [%s]\n", type_name2);fflush(stdout);
								
								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_item_item_id", &child_item_id ));
								printf("\nChild Item ID: [%s]\n", child_item_id);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &child_item_revision_id));
								printf("\nChild Item Revision ID: [%s]\n", child_item_revision_id);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(Childobject3, "bl_formula", &child_bl_formula));
								printf("\nBOM Line Formula: [%s]\n", child_bl_formula);fflush(stdout); */
                            }
							//bom_sub_child(lines4, n_lines4);
						}
						if(tmodule)
						{
							MEM_free(tmodule);
						}
					}
			    }
				if(tarcmod)
				{
					MEM_free(tarcmod);
				}
				ITK_CALL(BOM_close_window(bom_window));
			    printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
            }
		}
		else
		{
			printf("\n No BOM Window Found \n");fflush(stdout);
		}
					
	}

	return ITK_ok;	
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	time_t	temptime;
	char GenDate[20];
	struct tm *timeptr;
	int ch;
	char *RptFile= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char* Platform = NULL;
	char* SVR = NULL;
	char* RevisionRule = NULL;
	
	printf("\n Generating Curernt Time Stamp");fflush(stdout);
	temptime = time(NULL);
	tc_strcpy(GenDate,"");
	timeptr = (struct tm *)localtime(&temptime);
	ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"TPL_App_Matrix_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 7)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			Platform = ITK_ask_cli_argument("-plat=");
			SVR = ITK_ask_cli_argument("-svr=");
	        RevisionRule = ITK_ask_cli_argument("-rrule=");
			printf("\nUsername --------> %s", cUSERID);fflush(stdout);
			printf("\nPassword --------> %s", cPASS);fflush(stdout);
			printf("\nGroup --------> %s", cGroup);fflush(stdout);
			printf("\nPlatform --------> %s", Platform);fflush(stdout);
			printf("\nSVR --------> %s", SVR);fflush(stdout);
			printf("\nRevision Rule --------> %s", RevisionRule);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&cUSERID, &tuser);
				printf("\nLogged in Username --------> %s", cUSERID);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			if( tc_strlen(stripBlanks(Platform)) == 0 || tc_strlen(stripBlanks(SVR)) == 0 || tc_strlen(stripBlanks(RevisionRule)) == 0 )
	        {
		        print_requirement();
		        return iFail;
	        } 
			
			fpOutput_file = fopen(RptFile, "w");
			fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ S V R   R E P O R T ~~~~~~~~~~~~~~~");fflush(fpOutput_file);
            fprintf(fpOutput_file,"\n Level, Item_ID, Rev_Seq, Own_Group, Own_User, Qty");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Log File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			else
	        {
		        printf("\n Output File Opened Successfully");fflush(stdout);
	        }
			//ITK_CALL(Platform_SVR(Platform,SVR,RevisionRule,fpOutput_file));
			Platform_SVR(Platform,SVR,RevisionRule,fpOutput_file);
			fclose(fpOutput_file) ;           
			printf("\n All SVR Details Written Successfully on the Output File....\n");fflush(stdout); 
			printf("\n Output File Closed Now\n");fflush(stdout);
			
			
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}