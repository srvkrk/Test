/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   MCC Vehicle Link Report Calling Exe  
*  File Name    :   tm_mccrpt.c
*  Created on   :   July 05h, 2024
*  Usage        :   tm_mccrpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     05/07/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tc/tc.h>


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of MCC Dashboard Main Function ************* \n");fflush(stdout);
	
	char* sysCmnd = NULL;
	//char* PrtStr = ITK_ask_cli_argument( "-PartList=");
	//char* UsrStr = ITK_ask_cli_argument( "-User=");
	//char* EmlStr = ITK_ask_cli_argument( "-Email=");
	sysCmnd=(char *) MEM_alloc(400);
	tc_strcpy(sysCmnd,"/user/infodba04/sourav/MCCRPT/MCC_VEH_LINK_RPT/CallingShell.sh");
	//tc_strcat(sysCmnd,PrtStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,UsrStr);
	//tc_strcat(sysCmnd," ");
	//tc_strcat(sysCmnd,EmlStr);
	
	printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
	system(sysCmnd);
	//MEM_free(sysCmnd);
						

	printf("\n*********** End Of MCC Dashboard Main Function ************* \n");fflush(stdout);	
	return ifail;
}

/***************************************************************************
*
* // ./compile tm_mccrpt.c
* // ./linkitk -o tm_mccrpt tm_mccrpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MCCRPT/tm_mccrpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MCCRPT/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MCCRPT/SendEmail.sh .
*
***************************************************************************/
