
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2023.Tata Technologies  ALL RIGHTS RESERVED 
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_V6PrtCreCheckInOutValidation.c
*
* Description		: > This contains custom user service and handler. Implemented Custom ITK functions for V6 Prjoject validation in Teamcenterlogic
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 06/07/2023   	Rajesh Raman Basak			    Validation for V6 projects in Teamcenter

* -----------------------------------------------------------------------------
*
*****************************************************************************/				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tccore/iman_msg.h>

#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 401)
#define T5_WorkFlowHandlerErr1 (EMH_USER_error_base + 402)
#define T5_WorkFlowHandlerErr2 (EMH_USER_error_base + 403)
#define T5_WorkFlowHandlerESOErr (EMH_USER_error_base + 701)
#define T5_WorkFlowHandlerAnxErr (EMH_USER_error_base + 702)
#define MAX_LINE_LEN 1024
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_V6UAValErr 910011


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text(stat,&err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}




	int tm_V6ValidationFunc(tag_t objTag)
	{
			
			char *projcode=NULL;
			char *desgrp=NULL;
			char		*V6ErrMsg				= NULL;
			tag_t objTypeTag;
			char *type_name=NULL;
			printf("\n inside V6 checkin_validation tm_V6ValidationFunc \n");fflush(stdout);
			
			
			tag_t sessionUserTag = NULLTAG;
			char* sessionUserName = NULL;
			char* userid = NULL;
			tag_t current_role_tag = NULLTAG;
			char* rolename = NULL;
			
			tag_t groupTag = NULLTAG;
			char* groupname = NULL;
			
			
			tag_t   cntrlObjTag		=	NULLTAG;
				
			char    *QryCntrlEntry[4]	=	{"SYSCD","SUBSYSCD","Name","Delete Indicator"};
			char    **QryCntrlValues    =  (char **) MEM_alloc(10 * sizeof(char *));
			int     MOd_entry				=	4;
			int		V6ValdCntrlObjCnt			=	0;
			tag_t   *V6CntrlObj_tags    =	NULLTAG;		
			
			POM_get_user(&sessionUserName,&sessionUserTag);
			SA_ask_user_identifier2	(sessionUserTag,&userid);		
			SA_ask_current_role(&current_role_tag);			
			SA_ask_role_name2(current_role_tag, &rolename);
			printf ("\ntm_V6ValidationFunc Logged in user:%s %s\n",userid,sessionUserName);fflush(stdout);	

			POM_ask_group(&groupname, &groupTag);
			
						
			printf("\ntm_V6ValidationFunc Role Name: %s\nGroup Name: %s\n",rolename,groupname);fflush(stdout);
			
		if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"infodba")!=0 && tc_strcmp(groupname,"PLM_Support_Group")!=0)
		{
			if((tc_strstr(rolename,"Designer") != NULL) || (tc_strstr(rolename,"Manager") != NULL))
			{
				printf("\ninside the the Designer or Manager[%s] login condition\n",userid);fflush(stdout);
				ITK_CALL(TCTYPE_ask_object_type(objTag,&objTypeTag));
				ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name));
				printf("\ninput object's type_name:%s\n",type_name);fflush(stdout);
			
				if(strcmp(type_name,"Design Revision")==0 ||strcmp(type_name,"ItemRevision")==0)
				{

					printf("\ninside the Design Revision condition:%s\n",type_name);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode));
					ITK_CALL(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&desgrp));
					printf("\nprojcode=%s desgrp=%s\n",projcode,desgrp);fflush(stdout);
					//if(QRY_find("Control Objects...", &cntrlObjTag));
					if(QRY_find2("Control Objects...", &cntrlObjTag));
					if (cntrlObjTag)
					{
						if(tc_strlen(desgrp)>0 && tc_strlen(projcode)>0)
						{
							printf("\n going to Query ControlObjects to check V6 project live validation Check-In in uaprod/cvprod \n");fflush(stdout);
							QryCntrlValues[0] = desgrp;
							QryCntrlValues[1] = projcode;
							QryCntrlValues[2] =	 "V6PartCreChkInOutVld";
							QryCntrlValues[3] =	 "0";
							if(QRY_execute(cntrlObjTag, MOd_entry, QryCntrlEntry, QryCntrlValues, &V6ValdCntrlObjCnt, &V6CntrlObj_tags));
							printf(" \n Mod Checkin:V6ValdCntrlObjCnt:[%d]",V6ValdCntrlObjCnt); fflush(stdout);
							if(V6ValdCntrlObjCnt>0)
							{
								printf("\n Found control object for V6 project and design grp to stop Part Create/Check-In/out in uaprod/cvprod \n");fflush(stdout);
								
											
										//if(tc_strlen(V6ErrMsg) > 0)
										//{
											//printf("\n inside error pop up condition V6ErrMsg=%s \n",V6ErrMsg);fflush(stdout);
											//EMH_clear_errors();
											//ITK_CALL(EMH_store_error_s1(EMH_severity_error,ITK_V6UAValErr,V6ErrMsg));
											//printf("\n after call error pop up of func tm_V6ValidationFunc \n");fflush(stdout);
											return ITK_V6UAValErr;
											
										//}
								//return ITK_ok;
							}
						}
					}
					else
					{
						printf("\n Not Found V6ValdCntrlObjCnt ControlObjects for Check-In/Out , so skipping V6 check \n");fflush(stdout);
						return ITK_ok;
					}

					
				}
				else
				{
					printf("\n No Design Revision class so skip this V6 check \n");fflush(stdout);
					return ITK_ok;
				}
			}
		}
		printf("\n End of func tm_V6ValidationFunc \n");fflush(stdout);
			
	}

extern DLLAPI int V6PrtCreCheckInOutValidMethod(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;

	//char	type_name[TCTYPE_name_size_c+1];
	char	*type_name=NULL;
	char *V6ErrMsg=NULL;


	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	//POM_get_user(&username,&user_tag);
	printf("\n inside V6PrtCreCheckInOutValidMethod PreAction objTypeTag [%s]\n",type_name);fflush(stdout);


	if(strcmp(type_name,"Design Revision")==0 ||strcmp(type_name,"ItemRevision")==0)
	{
		
			printf ("\n inside V6PrtCreCheckInOutValidMethod:for design revision object\n");fflush(stdout);	

			printf("\n b4 call func tm_V6ValidationFunc\n");fflush(stdout);
			int retVal = tm_V6ValidationFunc(objTag);
			printf("\n after call tm_V6ValidationFunc Return value : %d\n",retVal);fflush(stdout);
			if(retVal==ITK_V6UAValErr)
			{
				if(V6ErrMsg)MEM_free(V6ErrMsg);
				V6ErrMsg	=(char* )malloc( 500 * sizeof (char));
				char *proj=NULL;
				char *designgrp=NULL;
				ITK_CALL(AOM_ask_value_string(objTag,"t5_ProjectCode",&proj));
				ITK_CALL(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&designgrp));
				printf("\ninside Preaction V6PrtCreCheckInOutValidMethod projcode=%s desgrp=%s\n",proj,designgrp);fflush(stdout);
				
				tc_strcpy(V6ErrMsg, "Project[");
				tc_strcat(V6ErrMsg, proj);
				tc_strcat(V6ErrMsg, "]");
				tc_strcat(V6ErrMsg, " and Design Group [");
				tc_strcat(V6ErrMsg, designgrp);
				tc_strcat(V6ErrMsg, "]");
				tc_strcat(V6ErrMsg, " live for CATIA V6 environment, Part Create/Check-In/Check-Out not allowed here ");
											
				printf("\n V6ErrMsg=%s \n",V6ErrMsg);fflush(stdout);
				printf("\n inside call error pop up of func tm_V6ValidationFunc in preaction\n");fflush(stdout);
				EMH_clear_errors();
				ITK_CALL(EMH_store_error_s1(EMH_severity_error,ITK_V6UAValErr,V6ErrMsg));
				printf("\n after call error pop up of func tm_V6ValidationFunc in preaction\n \n");fflush(stdout);
				return ITK_V6UAValErr;
			}

	}
	else
	{
			printf("\n object type is not Design Revision ,therefore skipping V6PrtCreCheckInOutValidMethod \n");fflush(stdout);
			 		
	}
		printf("\n End V6PrtCreCheckInOutValidMethod PreAction ofunction\n");fflush(stdout);
	return ITK_ok;
}

/* int ITK_CALL(int IFail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
} */

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

void trimLeading(char * str)
{
    int index, i, j;
    index = 0;
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }
    if(index != 0)
    {
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; 
    }
}

char* remove_white_spaces(char* InpStr)
{
    char *OutStr = (char *) malloc(500*sizeof(char));
    char str[1000];
    strcpy(str, InpStr);
    int i, j = 0;
    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] != ' ')
        {
            str[j] = str[i];
            j++;
        }
    }
    str[j] = '\0';
    printf("#-----------------------------#\n");
    printf("[Function - remove_white_spaces] String After Space Remove: [%s]\n", str);
    printf("#-----------------------------#\n");
    strcpy(OutStr,str);
    return OutStr;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_PartRevSeqFormat(char* PartRS)
{
	char *FRevSeq = (char *) malloc(400*sizeof(char));
	char* Rev_Str = NULL;
	char* Seq_Str = NULL;
	char* Rev_StrDup = NULL;
	char* Seq_StrDup = NULL;
	
	if(tc_strlen(PartRS)>0)
	{
		
		Rev_Str=strtok(PartRS,";");
		Seq_Str=strtok(NULL,";");
		printf("\n Revision String --------> %s", Rev_Str);fflush(stdout);
		printf("\n Sequence String --------> %s", Seq_Str);fflush(stdout);
		if((tc_strcmp(Rev_Str,NULL)!=0) && (tc_strcmp(Seq_Str,NULL)!=0))
		{	
			tc_strdup(Rev_Str,&Rev_StrDup);
			tc_strdup(Seq_Str,&Seq_StrDup);
		}
		else
		{
			tc_strdup("",&Rev_StrDup);
			tc_strdup("",&Seq_StrDup);
			printf("\n [NULL]Part Rev-Seq Value is NULL \n");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("",&Rev_StrDup);
		tc_strdup("",&Seq_StrDup);
		printf("\n Part Rev-Seq Value is NULL \n");fflush(stdout);
	}
	trimwhitespace(Rev_StrDup);
	trimwhitespace(Seq_StrDup);
	printf("\n Revision Value After Dup & Trim --------> %s\n", Rev_StrDup);fflush(stdout);
	printf("\n Sequence Value After Dup & Trim --------> %s\n", Seq_StrDup);fflush(stdout);
	tc_strcpy(FRevSeq,Rev_StrDup);
	tc_strcat(FRevSeq,".");
	tc_strcat(FRevSeq,Seq_StrDup);
	printf("\n Final Revision & Sequence Value --------> %s", FRevSeq);fflush(stdout);
	return FRevSeq;
}

int Part_Release_Status(char* PSrch,char* PRevSeqSrch,FILE* RelStatRpt)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	int iFail = 0;
	tag_t tQryobj = NULLTAG;
	int n_entries = 1;
	int n_Qryobj_found = 0;
	tag_t* tQryobj_results = NULLTAG;
	char* responseString1 = NULL;
	responseString1=(char *)MEM_alloc(200);
	char* responseString2 = NULL;
	responseString2=(char *)MEM_alloc(200);
	char* responseString3 = NULL;
	responseString3=(char *)MEM_alloc(200);
	char* responseString4 = NULL;
	responseString4=(char *)MEM_alloc(200);
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value After Trim --------> %s\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision and Sequence Value After Trim --------> %s\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tQryobj));
	printf("\n Return Value From Dataset Name Query API is --------> %d", iFail);fflush(stdout);
    if(tQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		//char *cEntries[2]  = {"Revision","ID"};
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {PSrch};
		ITK_CALL(QRY_execute(tQryobj, n_entries, cEntries, cValues, &n_Qryobj_found, &tQryobj_results));
		printf("\n Return Value From DesignRevision Sequence Query Execute API is --------> %d", iFail);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found --------> %d\n",n_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < n_Qryobj_found; m++)
			{
				DesRev_tag = tQryobj_results[m];
				ITK_CALL(AOM_ask_value_string(tQryobj_results[m],"item_revision_id",&Item_revseq));
				printf("\n Printing Rev & Seq: [%s]\n",Item_revseq);fflush(stdout);
				if(tc_strcmp(Item_revseq,PRevSeqSrch)==0)
				{
					tag_t rev_tags_found = NULLTAG;
					tag_t item_t = NULLTAG;
					size_t len;
					int	status_count = 0;
					tag_t* relStatus_list = NULLTAG;
					char* latest_rev_Rel_Status = NULL;
					char* latest_rev_Rel_StatusDup = NULL;
					char* latest_rev_Part_Type = NULL;
					char* PrtShellCommandLine = NULL;
					PrtShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
					char* dt_rlzd =	NULL;
					char* dt_rlzdDup = NULL;
					
					//item_t = tQryobj_results[0];
					//ITEM_ask_latest_rev(item_t, &rev_tags_found);
					rev_tags_found = tQryobj_results[m];
					if(rev_tags_found != NULLTAG)
					{	
						WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list);
						printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
						if(status_count>0)
						{
							int k = 0;
							for(k = 0; k<status_count; k++)
							{
									  
								AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_StatusDup);
								printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
										
								if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsReview") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsWrkg") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0))
								{
									  
									ITK_CALL(AOM_UIF_ask_value(relStatus_list[k],"date_released",&dt_rlzd));
									printf(" \n Release Status Dtae Released String: ------> <%s>\n",dt_rlzd);fflush(stdout);
									if(tc_strlen(dt_rlzd)>0)
									{
										tc_strdup(dt_rlzd,&dt_rlzdDup);
										tc_strdup(latest_rev_Rel_StatusDup,&latest_rev_Rel_Status);
										printf("\n Date Released Value --------> %s\n", dt_rlzdDup);fflush(stdout);
										printf("\n Latest_Rev_Rel_Status Value --------> %s\n", latest_rev_Rel_Status);fflush(stdout);
									}
									else
									{
										tc_strdup("",&dt_rlzdDup);
										tc_strdup("",&latest_rev_Rel_Status);
										printf("\n Date Released Value is NULL \n");fflush(stdout);
										printf("\n Latest Rev Released Status Value is NULL \n");fflush(stdout);
									}
									trimLeading(dt_rlzdDup);
									trimLeading(latest_rev_Rel_Status);
									printf("\n Date Released Value After Trim --------> %s\n", dt_rlzdDup);fflush(stdout);
									printf("\n Latest Rev Released Status Value After Trim --------> %s\n", latest_rev_Rel_Status);fflush(stdout);
										   
								}
								else
								{
									continue;
								}
									  
							}
							
							printf("\n############################################\n");fflush(stdout);
							printf("\n Part Number: -----> <%s> \n",PSrch);fflush(stdout);
							printf("\n Part Revision & Sequence: -----> <%s> \n",PRevSeqSrch);fflush(stdout);
							printf("\n Latest ERC Date Released Value: ------> <%s> \n",dt_rlzdDup);fflush(stdout);
							printf("\n Latest Rev ERC Status Value: ------> <%s> \n",latest_rev_Rel_Status);fflush(stdout);
							printf("\n############################################\n");fflush(stdout);
							
							AOM_ask_value_string(rev_tags_found,"t5_PartType",&latest_rev_Part_Type);
							printf("\n Latest_Rev_Part_Type: ------> <%s> \n",latest_rev_Part_Type);fflush(stdout);
							
							tc_strcpy(responseString1,PSrch);
							printf("\n Part Revision & Sequence Format :Function Calling Start");fflush(stdout);
							responseString2 = TC_PartRevSeqFormat(PRevSeqSrch);
							printf("\n Part Revision & Sequence Format :Function Calling End");fflush(stdout);
									
							if(tc_strlen(latest_rev_Rel_Status)>0)
							{
								if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsWrkg")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcWrkg")==0))
								{
									tc_strcpy(responseString3,"IN_WORK");
								}
								else if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsReview")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcReview")==0))
								{
									tc_strcpy(responseString3,"FROZEN");
								}
								else if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsRlzd")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcRlzd")==0))
								{
									tc_strcpy(responseString3,"RELEASED");
								}
								else
								{
									tc_strcpy(responseString3,"NULL");
								}
							}
							else
							{
								tc_strcpy(responseString3,"NULL");
							}
							
							if(tc_strlen(latest_rev_Part_Type)>0)
							{
								/* if(tc_strcmp(latest_rev_Part_Type,"A")==0)
								{
									tc_strcpy(responseString4,"PhysicalProduct");
								}
								else if(tc_strcmp(latest_rev_Part_Type,"C")==0)
								{
									tc_strcpy(responseString4,"PhysicalProduct");
								}
								else
								{
									tc_strcpy(responseString4,"Drawing");
								} */
								tc_strcpy(responseString4,"PhysicalProduct");
							}
							else
							{
								tc_strcpy(responseString4,"NULL");
							}
									
							printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
							printf("\n Response String1:Part Number -----> <%s> \n",responseString1);fflush(stdout);
							printf("\n Response String2:Part Revision & Sequence -----> <%s> \n",responseString2);fflush(stdout);
							printf("\n Response String3:Release Status -----> <%s> \n",responseString3);fflush(stdout);
							printf("\n Response String4:Part Type -----> <%s> \n",responseString4);fflush(stdout);
							printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
								
							printf("\nData Print Start on Report File...");fflush(stdout);
							fprintf(RelStatRpt,"%s,%s,%s,%s\n",responseString1,responseString2,responseString3,responseString4);fflush(RelStatRpt);
							printf("\nData Print End on Report File...");fflush(stdout);
						}
						else
						{
							printf("\nSorry! ERC Release Status Not Found on Selected Revision...");fflush(stdout);
						}
					}
					else
					{
						printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
					}
				}
			}
		}
		else
		{
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
			printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	if (tQryobj_results)
    {
		MEM_free(tQryobj_results);
	}
	
    return iFail;	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* ChildReport)
{
	
		char* cSubItem_Id = NULL;
		char* cSubItem_IdDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cRevision = NULL;
		char* cRevisionDup  = NULL;
		int j =0;
		int iFail = ITK_ok;
		//int iAttribute = 0;
		//int iNumber_SubChild = 0;
		//tag_t tChild = NULLTAG;
		//tag_t* tSubChild = NULLTAG;
		//char* cItemDes = NULL;
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cSubItem_Id));
			if(tc_strlen(cSubItem_Id)>0)
		    {
			   tc_strdup(cSubItem_Id,&cSubItem_IdDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cSubItem_IdDup);
			   printf("\n Part No Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cSubItem_IdDup);
		    printf("\n Part No Value After Dup & Trim --------> %s", cSubItem_IdDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cRevision));
			if(tc_strlen(cRevision)>0)
		    {
			   tc_strdup(cRevision,&cRevisionDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cRevisionDup);
			   printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cRevisionDup);
		    printf("\n Part Rev & Seq Value After Dup --------> %s", cRevisionDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
		    {
			   tc_strdup(cPartType,&cPartTypeDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cPartTypeDup);
			   printf("\n Part Type Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cPartTypeDup);
		    printf("\n Part Type Value After Dup & Trim --------> %s", cPartTypeDup);fflush(stdout);
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nID: %s", cSubItem_IdDup);
			printf("\nRev & Seq: %s", cRevisionDup);
			printf("\nType: %s", cPartTypeDup);
			printf("\n-------------------------------------------------------------------------");
			if(tc_strlen(cSubItem_IdDup)>0)
		    {
				//fprintf(ChildReport,"%s,%s,\n",cSubItem_IdDup,cRevisionDup);fflush(ChildReport);
				printf("\n Function: Child Part Release Status & Part Type Print Start");fflush(stdout);
			    Part_Release_Status(cSubItem_IdDup,cRevisionDup,ChildReport);
			    printf("\n Function: Child Part Release Status & Part Type Print End");fflush(stdout);
			}
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found --------> %d\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			} */
		}
	return iFail;
}

int ERC_DML_Part_Child(char* TCPart,char* TCPartRS,FILE* TCReport)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	//int subrulefound = 0;
	//tag_t* subclosurerule = NULL;
	//tag_t sub_close_tag = NULLTAG;
	//char** subrulename = NULL;
    //char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_IdDup = NULL;
	char* ctopSubRevision = NULL;
	char* ctopSubRevisionDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(TCPart, &top_item));
	printf("\n Return Value From Item Find Item API is --------> %d", iFail);fflush(stdout);
	tag_t topchildrev = NULLTAG;
	ITK_CALL(ITEM_find_revision(top_item, TCPartRS, &topchildrev));
	printf("\n Return Value From Item Find Revision API is --------> %d", iFail);fflush(stdout);
	if(topchildrev != NULLTAG)
    {
			
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
		printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
		/* ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n No of Rule Found --------> %d\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout); */
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			if(tc_strlen(ctopSubItem_Id)>0)
			{
				tc_strdup(ctopSubItem_Id,&ctopSubItem_IdDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubItem_IdDup);
				printf("\n Part Number Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubItem_IdDup);
			printf("\n Part Number Value After Dup & Trim --------> %s", ctopSubItem_IdDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubRevision));
			if(tc_strlen(ctopSubRevision)>0)
			{
				tc_strdup(ctopSubRevision,&ctopSubRevisionDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubRevisionDup);
				printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubRevisionDup);
			printf("\n Part Rev & Seq Value After Dup & Trim --------> %s", ctopSubRevisionDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim --------> %s", ctopSubPartTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nItem ID: %s", ctopSubItem_IdDup);
			printf("\nItem Rev & Seq: %s", ctopSubRevisionDup);
			printf("\nItem Part Type: %s", ctopSubPartTypeDup);
			printf("\n-------------------------------------------------------------------------");
			//fprintf(TCReport,"%s,%s,%s\n",ctopSubItem_IdDup,ctopSubRevisionDup,ctopSubPartTypeDup);fflush(TCReport);
			printf("\n Function: TC Part Release Status & Part Type Print Start");fflush(stdout);
			Part_Release_Status(ctopSubItem_IdDup,ctopSubRevisionDup,TCReport);
			printf("\n Function: TC Part Release Status & Part Type Print End");fflush(stdout);	
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
			printf("\n No of Children Found --------> %d\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! N O   O F   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, TCReport);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
	}
	return iFail;	
}

int ERC_DML_Part_transfer(char* DmlNumber,FILE* FReport)
{
	
	int iFail = 0;
	tag_t dml_task_rel = NULLTAG;
	int	task_count = 0;
	tag_t *task_tag	= NULL;
    tag_t dml_tag = NULLTAG;
	tag_t rev_tag = NULLTAG;
    tag_t RevTypTag	= NULLTAG;
	char* RevTyp = NULL;
	char* item_type = NULL;
	ITK_CALL(ITEM_find_item(DmlNumber, &dml_tag));
	if (dml_tag != NULLTAG)
	{
		printf("\n !!!!!! DML Tag Found !!!!!!");fflush(stdout);
	}
	ITK_CALL(ITEM_ask_type2(dml_tag, &item_type));
	printf("\n DML Item_Types: [%s] \n",item_type);fflush(stdout);
	// Find the DML-Revision tag.
	//ITK_CALL(ITEM_find_revision(dml_tag,"NR",&dml_rev_tag)) ;
	ITK_CALL(ITEM_ask_latest_rev(dml_tag,&rev_tag)) ;
	if(rev_tag != NULLTAG)
	{
		printf("\n !!!!!! DML Revision Tag Found !!!!!!");fflush(stdout);
	}
	if(TCTYPE_ask_object_type(rev_tag, &RevTypTag));
	if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\n Revision Type: [%s]\n", RevTyp);fflush(stdout);
	if(tc_strcmp(RevTyp,"ChangeRequestRevision")==0)
	{
		ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &dml_task_rel));
		ITK_CALL(GRM_list_secondary_objects_only(rev_tag, dml_task_rel, &task_count, &task_tag));
		printf("\n !!!!!! Secondary Objects Only !!!!!!");fflush(stdout);
		printf("\n Total Task Found: [%d]",task_count);fflush(stdout);
		int i = 0;
		char *task_id = NULL;
		tag_t task_part_rel = NULLTAG;
		int	part_count = 0;
		tag_t* part_tag	= NULL;
		int j = 0;
		int n_tags_found = 0;
		tag_t* tags_found = NULLTAG;
		tag_t item_t = NULLTAG;
		tag_t rev_tags_found = NULLTAG;
		int	status_count = 0;
		tag_t*	relStatus_list = NULLTAG;
		char* latest_rev_Rel_Status = NULL;
		char* latest_rev_Rel_StatusDup = NULL;
		char* latest_rev_Part_Type = NULL;
		char* PrtShellCommandLine = NULL;
		PrtShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
		char* dt_rlzd =	NULL;
		char* dt_rlzdDup = NULL;
		char* part_Rev = NULL;
		char* cItemID = NULL;
		if(task_count > 0)
		{
			for(i=0;i<task_count;i++)
			{
				
				printf("\n Inside Task: ---> [%d]", i);fflush(stdout);
				ITK_CALL(AOM_UIF_ask_value(task_tag[i], "item_id", &task_id));
				printf("\nTask ID: [%s]", task_id);fflush(stdout);
				if(tc_strstr(task_id,"APL") == NULL)
			    {
				
					printf("\n !!!!!! Task To Part !!!!!!");fflush(stdout);
					ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &task_part_rel));
					ITK_CALL(GRM_list_secondary_objects_only(task_tag[i], task_part_rel, &part_count, &part_tag));
					printf("\n >>>>>> Total Part Found: [%d] <<<<<<", part_count);fflush(stdout);
					if(part_count > 0)
					{	
						for(j=0;j<part_count;j++)
						{
							
							ITK_CALL(AOM_UIF_ask_value(part_tag[j], "item_id", &cItemID));
							ITK_CALL(AOM_UIF_ask_value(part_tag[j], "item_revision_id", &part_Rev));
							printf("\n Part Number: [%s]", cItemID);fflush(stdout);
							printf("\n Part Revision & Sequence: [%s]", part_Rev);fflush(stdout);
							rev_tags_found = part_tag[j];
							if((cItemID != NULL) && (tc_strcmp(cItemID,"")!=0))
							{
								printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
								printf("\n First String:Part Number -----> <%s> \n",cItemID);fflush(stdout);
								printf("\n Second String:Part Revision & Sequence -----> <%s> \n",part_Rev);fflush(stdout);
								printf("\n Third String:Task Number -----> <%s> \n",task_id);fflush(stdout);
								printf("\n Fourth String:DML Number -----> <%s> \n",DmlNumber);fflush(stdout);
								printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
								
								printf("\n Function: First Level Child Details Find Start");fflush(stdout);
			                    ERC_DML_Part_Child(cItemID,part_Rev,FReport);
			                    printf("\n Function: First Level Child Details Find End");fflush(stdout);						
							}
							else
							{
								printf("\n Sorry!! Item ID is NULL");fflush(stdout);
							}						
						}
					}
					else
					{
						printf("\n Sorry!! No Parts Found");fflush(stdout);
					}
				}
				else
				{
					printf("\n SKIP: As APL Task Found");fflush(stdout);
				}
			}
	    }
		else
		{
			printf("\n Sorry!! No Tasks Found");fflush(stdout);
		}
	}
	else
	{
		printf("\n Sorry!! RevType is Not ChangeRequestRevision");fflush(stdout);
	}
	
	return ITK_ok;	
}


int tm_V6PartTransfer( EPM_action_message_t msg )
{
	printf("\n ~~~~~~~~~~~~~~ Action Handler[tm_V6PartTransfer] Start ~~~~~~~~~~~~~~\n");fflush(stdout);
	tag_t tMainCtrlobj = NULLTAG;
	tag_t* tmainctrlobj_results = NULLTAG;
	int n_mainentries = 4;
	int n_mainctrlobj_found = 0;
	ITK_CALL(QRY_find2("Control Objects...",&tMainCtrlobj));
	char *cMainEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
	char *cMainValues[4]  = {"V6XFRSYS","V6XFRSBSYS","V6XFRLIVE","0"};
	ITK_CALL(QRY_execute(tMainCtrlobj, n_mainentries, cMainEntries, cMainValues, &n_mainctrlobj_found, &tmainctrlobj_results));
	printf("\n No of Control Object Found --------> [%d]\n",n_mainctrlobj_found);fflush(stdout);
	if(n_mainctrlobj_found>0)
	{
		printf("\n Action Handler[tm_V6PartTransfer] Control Object Live..!!");fflush(stdout);
		tag_t rootTask = NULLTAG;
		char*  parent_name = NULL;
		char*  CurrentTask = NULL;
		tag_t user_tag = NULLTAG;
		char* username = NULL;
		char* DmlNo = NULL;
		int	noAttachment = 0;
		tag_t *attachments = NULLTAG;
		char* object_type = NULL;
		int n_ctrlobj_found = 0;
		char* EnvType = NULL;
		char* EnvTypeDup = NULL;
		char* DMLDesGrp = NULL;
		
		POM_get_user(&username,&user_tag);
		printf("\nUsername:  [%s]\n",username);fflush(stdout);
		ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

		ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\nCurrentTask:  [%s]\n",CurrentTask);

		ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:   [%s]\n",parent_name);fflush(stdout);
		
		//ITK_CALL(AOM_ask_value_string(rootTask,"item_id",&DmlNo));
		//printf("\nDML No:   [%s]\n",DmlNo);fflush(stdout);
		
		ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		printf("\nTarget Attachment:   [%d]\n",noAttachment);fflush(stdout);
			
		ITK_CALL(AOM_ask_value_string(attachments[0],"object_type",&object_type));
		printf("\nObject Type:    [%s]\n",object_type);fflush(stdout);
		
		if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
		{

			printf("\n !!!!!! ERC DML Found !!!!!! ");fflush(stdout);
			ITK_CALL(AOM_ask_value_string(attachments[0],"current_id",&DmlNo));
			printf("\n DML No is:------> [%s]\n",DmlNo);fflush(stdout);
			
			int iFail = 0;
			int i = 0;
			char* cError = NULL;
			//char* username = NULL;
			//tag_t tuser = NULLTAG;
			char *FinalRptFile= (char *) malloc(400*sizeof(char));
			FILE *fpOutput_file = NULL;
			//char* cUSERID = NULL;
			//char* cPASS = NULL;
			//char* cGroup = NULL;
			char* ShellCommandLine = NULL;
			ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
			//tag_t tUserAgen;
			//char* useragency = NULL;
			//tag_t user_tag = NULLTAG;
			char* InpDMLProjCode = NULL;
			char* InpDMLDesGrp = NULL;
			//tag_t CurrentRoleTag = NULLTAG;
			//char* roleName = NULL;
			//char *PlantName = NULL;
			char* FinalDesGrp = NULL;
			FinalDesGrp = (char *) MEM_alloc(100*sizeof(char ));
			char* EnvType = NULL;
			char* EnvTypeDup = NULL;
			
			printf("\n Generating New Time Stamp");fflush(stdout);
			char GenDate[100] = "";
			time_t 	now;
			struct 	tm when;
			time(&now);
			when = *localtime(&now);
			strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
			printf("\n Current Time --------> %s", GenDate);fflush(stdout);
			printf("\n New Time Stamp Generated");fflush(stdout);
			
			printf("\n Generating New Report Time Stamp");fflush(stdout);
			char RptDate[100] = "";
			strftime(RptDate,100,"%d_%b_%Y_%H_%M_%S",&when);
			printf("\n Report Time --------> %s", RptDate);fflush(stdout);
			printf("\n New Report Time Stamp Generated");fflush(stdout);
			
			printf("\n Generating Report File Name");fflush(stdout);
			tc_strcpy(FinalRptFile,"/tmp/");
			tc_strcat(FinalRptFile,DmlNo);
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,"CATIAV6_Part_Tranfer_Report");
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,GenDate);
			tc_strcat(FinalRptFile,".txt");
			printf("\n Report File Name --------> %s", FinalRptFile);fflush(stdout);
			printf("\n Report File Name Generated");fflush(stdout);
					
			fpOutput_file = fopen(FinalRptFile, "w"); 
			if(fpOutput_file == NULL)
			{
				printf("\n Unable to Create Report File on Server --------> %s",FinalRptFile);fflush(stdout);
				return iFail;
			}
			else
			{
				printf("\n Report File Opened Successfully");fflush(stdout);
				tag_t Inpdmltag = NULLTAG;
				tag_t Inprevtag = NULLTAG;
				tag_t InpRevTypTag	= NULLTAG;
				char* InpRevTyp = NULL;
				char* Inpitemtype = NULL;
				
				ITK_CALL(ITEM_find_item(DmlNo, &Inpdmltag));
				if (Inpdmltag != NULLTAG)
				{
					printf("\n !!!!!! Input DML Tag Found !!!!!!");fflush(stdout);
				}
				ITK_CALL(ITEM_ask_type2(Inpdmltag, &Inpitemtype));
				printf("\n Input DML Item_Types: [%s] \n",Inpitemtype);fflush(stdout);
				// Find the DML-Revision tag.
				//ITK_CALL(ITEM_find_revision(Inpdmltag,"NR",&dml_rev_tag)) ;
				ITK_CALL(ITEM_ask_latest_rev(Inpdmltag,&Inprevtag)) ;
				if(Inprevtag != NULLTAG)
				{
					printf("\n !!!!!! Input DML Revision Tag Found !!!!!!");fflush(stdout);
				}
				AOM_ask_value_string(Inprevtag,"t5_cprojectcode",&InpDMLProjCode);
				printf("\n Input DML Project Code: ------> <%s> \n",InpDMLProjCode);fflush(stdout);
				AOM_UIF_ask_value(Inprevtag,"t5_crdesigngroup",&DMLDesGrp);
				 //ITK_CALL(AOM_ask_displayable_values(Inprevtag,"t5_crdesigngroup",&DMLDesGrp));
				printf("\n Input DML Design Group: ------> <%s> \n",DMLDesGrp);fflush(stdout);
				trimwhitespace(InpDMLProjCode);
				InpDMLDesGrp = remove_white_spaces(DMLDesGrp);
				printf("\n Input DML Project Code After Trim --------> [%s]\n", InpDMLProjCode);fflush(stdout);
				printf("\n Input DML Design Group After Trim --------> [%s]\n", InpDMLDesGrp);fflush(stdout);
				printf("\n New Logic For Design Group Implemented..!!");fflush(stdout);
				if(TCTYPE_ask_object_type(Inprevtag, &InpRevTypTag));
				if(TCTYPE_ask_name2(InpRevTypTag,&InpRevTyp));
				printf("\n Revision Type: [%s]\n", InpRevTyp);fflush(stdout);
				if(tc_strcmp(InpRevTyp,"ChangeRequestRevision")==0)
				{
					tag_t tCtrlobj = NULLTAG;
					tag_t* tctrlobj_results = NULLTAG;
					int n_entries = 4;
					ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
					printf("\n Return Value From Control Object Query API is --------> %d", iFail);fflush(stdout);
					if(tCtrlobj!=NULLTAG)
					{
						printf("\n Control Object Query Found Successfully..!!");
						printf("#--------------------------------------------------------#\n");
						char DesignGroup[1000];
						tc_strcpy(DesignGroup, InpDMLDesGrp);
						char* tok;
						tok = tc_strtok(DesignGroup, ",");
						while(tok != NULL) 
						{
							printf("\n Each Element: [%s]\n", tok);
							char *cEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
							char *cValues[4]  = {InpDMLProjCode,tok,"V6PartCreChkInOutVld","0"};
							ITK_CALL(QRY_execute(tCtrlobj, n_entries, cEntries, cValues, &n_ctrlobj_found, &tctrlobj_results));
							printf("\n No of Control Object Found --------> [%d]\n",n_ctrlobj_found);fflush(stdout);
							if(n_ctrlobj_found>0)
							{
								printf("\n Control Object Found Against Input DML Project Code & Design Group\n");fflush(stdout);
								ITK_CALL(AOM_ask_value_string(tctrlobj_results[0], "t5_Userinfo1", &EnvType));
								printf("\n Environment Type: --------> [%s]\n",EnvType);fflush(stdout);
								if(EnvType!=NULL)tc_strdup(EnvType,&EnvTypeDup);
								printf("\n Environment Type Dup: --------> [%s]\n",EnvTypeDup);fflush(stdout);
								break;
							}
							else
							{
								printf("\n Control Object Not Found..!!\n");fflush(stdout);
								if(tc_strstr(tok,",")!=NULL)
								{
									printf("\n Comma Present in String..!!\n"); fflush(stdout);
									tok = strtok(NULL, ",");
								}
								else
								{
									printf("\n Comma Not Present in String..!!\n"); fflush(stdout);
									break;
								}
							}
						}
						printf("\n Original String: [%s]\n",InpDMLDesGrp);
						printf("#--------------------------------------------------------#\n");
						printf("\n No of Control Object Found(Outside) --------> [%d]\n",n_ctrlobj_found);fflush(stdout);
						if(n_ctrlobj_found>0)
						{
							printf("\n Function: ERC DML Part Transfer Start");fflush(stdout);
							ERC_DML_Part_transfer(DmlNo,fpOutput_file);
							printf("\n Function: ERC DML Part Transfer End");fflush(stdout);
						}
						else
						{
							printf("\n Sorry! No Control Object Found Against Input DML Project Code & Design Group");fflush(stdout);
						}
					}
					else
					{
						printf("\n Sorry! Control Objects... Query Tag Not Found");fflush(stdout);
					}					
				}
				else
				{
					printf("\n Sorry! Input DML is Not ERC DML");fflush(stdout);
				}
			}
			fclose(fpOutput_file);
			printf("\n Report File Closed Successfully");fflush(stdout);
			
			printf("\n Shell Calling STARTED...");fflush(stdout);
			tag_t tJarPathCtrlobj = NULLTAG;
			tag_t* tJarPathctrlobj_results = NULLTAG;
			int n_pathentries = 4;
			int n_path_ctrlobj_found = 0;
			char *JarCallPath = NULL;
			char *JarPath = NULL;
			ITK_CALL(QRY_find2("Control Objects...",&tJarPathCtrlobj));
			printf("\n Return Value From Control Object Query API is --------> %d", iFail);fflush(stdout);
			printf("\n Environment Type Dup Next: --------> [%s]\n",EnvTypeDup);fflush(stdout);
			if((tJarPathCtrlobj!=NULLTAG) && (n_ctrlobj_found>0))
			{
				printf("\n Control Object Query Found Successfully & Project Code & Design Group Matched...!!");
				if(tc_strcmp(EnvTypeDup,"AVINYA")==0)
				{
					printf("\n Control Object Check Start AVINYA Project..!!");
					char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
					char *cPathValues[4]  = {"V6TransferAVN","V6TransferPathAVN","V6TransferCntObjAVN","0"};
					ITK_CALL(QRY_execute(tJarPathCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tJarPathctrlobj_results));
					printf("\n Return Value From Control Object Query Execute API is --------> [%d]", iFail);fflush(stdout);
					printf("\n No of Control Object Found[AVINYA] --------> %d\n",n_path_ctrlobj_found);fflush(stdout);
					if(n_path_ctrlobj_found>0)
					{
						ITK_CALL(AOM_ask_value_string(tJarPathctrlobj_results[0], "t5_Userinfo1", &JarCallPath));
						printf("\n JAR Calling Path[AVINYA]: --------> [%s]\n",JarCallPath);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(tJarPathctrlobj_results[0], "t5_Userinfo2", &JarPath));
						printf("\n JAR Path[AVINYA]: --------> [%s]\n",JarPath);fflush(stdout);
						printf("\n Jar Calling Path Control Object Found For AVINYA");fflush(stdout);
						printf("\n JAR CALL: Start[AVINYA]");fflush(stdout);
						//tc_strcpy(ShellCommandLine,"/user/uaprodtrl/Sourav/tm_dml_part_transfer/Execution_Shell.sh");
						//tc_strcpy(ShellCommandLine,"/user/omfprod/sourav/tm_dml_part_transfer/Execution_Shell.sh");
						tc_strcpy(ShellCommandLine,JarCallPath);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,DmlNo);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,RptDate);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,FinalRptFile);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,InpDMLProjCode);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,InpDMLDesGrp);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,JarPath);
						printf("\n CommandLine: -------> [%s]",ShellCommandLine);fflush(stdout);
						system(ShellCommandLine);
						printf("\n JAR CALL: End[AVINYA]");fflush(stdout);
					}
					else
					{
						printf("\n Sorry! No Jar Calling Path Control Object Found & Project Code & Design Group Not Matched[AVINYA]");fflush(stdout);
					}
					printf("\n Control Object Check End AVINYA Project..!!");
				}
				else
				{
					printf("\n Control Object Check Start Normal Project..!!");
					char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
					char *cPathValues[4]  = {"V6Transfer","V6TransferPath","V6TransferCntObj","0"};
					ITK_CALL(QRY_execute(tJarPathCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tJarPathctrlobj_results));
					printf("\n Return Value From Control Object Query Execute API is --------> %d", iFail);fflush(stdout);
					printf("\n No of Control Object Found --------> %d\n",n_path_ctrlobj_found);fflush(stdout);
					if(n_path_ctrlobj_found>0)
					{
						ITK_CALL(AOM_ask_value_string(tJarPathctrlobj_results[0], "t5_Userinfo1", &JarCallPath));
						printf("\n JAR Calling Path: --------> [%s]\n",JarCallPath);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(tJarPathctrlobj_results[0], "t5_Userinfo2", &JarPath));
						printf("\n JAR Path: --------> [%s]\n",JarPath);fflush(stdout);
						printf("\n Jar Calling Path Control Object Found");fflush(stdout);
						printf("\n JAR CALL: Start");fflush(stdout);
						//tc_strcpy(ShellCommandLine,"/user/uaprodtrl/Sourav/tm_dml_part_transfer/Execution_Shell.sh");
						//tc_strcpy(ShellCommandLine,"/user/omfprod/sourav/tm_dml_part_transfer/Execution_Shell.sh");
						tc_strcpy(ShellCommandLine,JarCallPath);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,DmlNo);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,RptDate);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,FinalRptFile);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,InpDMLProjCode);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,InpDMLDesGrp);
						tc_strcat(ShellCommandLine," ");
						tc_strcat(ShellCommandLine,JarPath);
						printf("\n CommandLine: -------> %s",ShellCommandLine);fflush(stdout);
						system(ShellCommandLine);
						printf("\n JAR CALL: End");fflush(stdout);
					}
					else
					{
						printf("\n Sorry! No Jar Calling Path Control Object Found & Project Code & Design Group Not Matched");fflush(stdout);
					}
					printf("\n Control Object Check End Normal Project..!!");
				}
			}
			else
			{
				printf("\n Sorry! Control Objects... Query Tag Not Found");fflush(stdout);
			}			
			printf("\n Shell Called Ended...");
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		}
		else
		{
			printf("\n Sorry! Object_Type is Not ChangeRequestRevision i.e Not ERC DML");fflush(stdout);
		}
	}
	else
	{
		printf("\n Sorry! Action Handler[tm_V6PartTransfer] Control Object Not Live..!!");fflush(stdout);
	}
	printf("\n ~~~~~~~~~~~~~~ Action Handler[tm_V6PartTransfer] End ~~~~~~~~~~~~~~\n");fflush(stdout);
	
	return ITK_ok;
}






extern int tm_V6PrtCreCheckInOutValidation_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
  
    //METHOD_id_t method;
    METHOD_id_t method1;
    METHOD_id_t  V6PrtCreCheckInOutValMethod;
  
     //Removed From IMAN_save_msg
    /* if( METHOD_find_method("Design Revision", IMAN_save_msg, &method) !=ITK_ok);

    if (method.id != NULLTAG)
	{
		printf("\n V6PrtCreCheckInOutValMethod is found for IMAN_save_msg on Design Revision \n");fflush(stdout);
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) V6PrtCreCheckInOutValidMethod, NULL)!=ITK_ok);
   
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");fflush(stdout);
	} */
	  
		if ( METHOD_find_method(RES_Type, RES_checkin_msg, &method1) !=ITK_ok);

		if (method1.id != NULLTAG)
		{
			if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) V6PrtCreCheckInOutValidMethod, NULL)!=ITK_ok);

			TC_write_syslog("\n inside V6PrtCreCheckInOutValMethod check-in validation \n");
		}
		else
		{
			printf(" method1 not found for checkin part for V6PrtCreCheckInOutValMethod  \n");fflush(stdout);
		}
    
        
	  
	  
	  if(METHOD_find_method(RES_Type, RES_checkout_msg,&V6PrtCreCheckInOutValMethod) !=ITK_ok);
	  
		if (V6PrtCreCheckInOutValMethod.id != NULLTAG)
		{
			TC_write_syslog("\nInside V6PrtCreCheckInOutValMethod for check out\n");	
			if( METHOD_add_action(V6PrtCreCheckInOutValMethod, METHOD_pre_action_type, (METHOD_function_t) V6PrtCreCheckInOutValidMethod, NULL)!=ITK_ok);
		}
  
  
  /*End - rrb V6PrtCreCheckInOutValidMethods    */ 

   //DML PART TRANSFER START TO CATIA V6 FROM TCUA 
    METHOD_id_t  method2;  
    if( ITK_ok == EPM_register_action_handler("tm_V6PartTransfer", "", tm_V6PartTransfer))
    {
		TC_write_syslog("\t\n Registered Action Handler V6PartTransfermethod\n");
    }
	else
    {
		printf("\t FAILED to register Action Handler V6PartTransfermethod\n");fflush(stdout);
    }	 
   //DML PART TRANSFER END TO CATIA V6 FROM TCUA
	
    return ifail;
}





extern DLLAPI int tm_V6PrtCreCheckInOutValidation_register_callbacks ()
{	
    int ifail    = ITK_ok;
	TC_write_syslog("\ntm_V6PrtCreCheckInOutValidation_register_callbacks:Before registering....");  
    ifail=CUSTOM_register_exit ( "tm_V6PrtCreCheckInOutValidation", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_V6PrtCreCheckInOutValidation_register_method);
	TC_write_syslog("\nttm_V6PrtCreCheckInOutValidation_register_callbacks: After registering....");
	
	
  return ( ITK_ok );
}