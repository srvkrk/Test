/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create MCC Main Dashboard After Reading Data From Input File 
*  File Name    :   tm_mccmaindashboard.c
*  Created on   :   Sept 13th, 2024
*  Usage        :   tm_mccmaindashboard
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     13/09/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int TC_CVDS2(FILE* CVRpt2)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int k = 0;
	tag_t tsubmodlib_rev = NULLTAG;
	char *SubModAddr_Str = NULL;
	char *SubModAddr_StrDup = NULL;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	char *LbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fplb_file = NULL;
	char *MstrLbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fmstrplb_file = NULL;
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Submodule Library Report File Name..!!");fflush(stdout);
	tc_strcpy(LbRptFile,"/tmp/");
	tc_strcat(LbRptFile,"SubModDetails");
	tc_strcat(LbRptFile,"_");
	tc_strcat(LbRptFile,GenDate);
	tc_strcat(LbRptFile,".txt");
	printf("\n Submodule Library Report File Name: [%s]", LbRptFile);fflush(stdout);
	printf("\n Submodule Library Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating Master Submodule Library Report File Name..!!");fflush(stdout);
	tc_strcpy(MstrLbRptFile,"/tmp/");
	tc_strcat(MstrLbRptFile,"MasterSubModDetails");
	tc_strcat(MstrLbRptFile,"_");
	tc_strcat(MstrLbRptFile,GenDate);
	tc_strcat(MstrLbRptFile,".txt");
	printf("\n Master Submodule Library Report File Name: [%s]", MstrLbRptFile);fflush(stdout);
	printf("\n Master Submodule Library Report File Generated..!!");fflush(stdout);
	fplb_file = fopen(LbRptFile, "w");
	//fmstrplb_file = fopen(MstrLbRptFile, "w");
	
	printf("\n Submodule Library Report Report File Generated..!!");fflush(stdout);
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\nSubModule Address Revision Found..!!\n");fflush(stdout);
			for(k = 0; k < n_itemobj_found; k++)
			{
				tsubmodlib_rev = titemobj_results[k];
				ITK_CALL(AOM_ask_value_string(tsubmodlib_rev,"item_id",&SubModAddr_Str));
				trimwhitespace(SubModAddr_Str);
				if(SubModAddr_Str!=NULL)tc_strdup(SubModAddr_Str,&SubModAddr_StrDup);
				ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
				printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SubModAddr_StrDup);fflush(stdout);
				if(n_valid_rows>0)
				{
					int iValCnt=0;
					for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
					{
						char* Tbl_SubModNo = NULL;
						char* Tbl_SubModNodup = NULL;
						char* Tbl_SubModProd = NULL;
						char* Tbl_SubModProddup = NULL;
						printf("\n [Start] Printing of Table Row: [%d]\n",iValCnt);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
						trimwhitespace(Tbl_SubModNo);
						trimwhitespace(Tbl_SubModProd);
						if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
						if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
						if(tc_strlen(Tbl_SubModNodup)>0)
						{
						  fprintf(fplb_file,"%s^%s^\n",Tbl_SubModNodup,Tbl_SubModProddup);fflush(fplb_file);
						}  
						printf("\n [End] Printing of Table Row: [%d]",iValCnt);fflush(stdout);
					}
				}
				else
				{
					printf("\n No Table Row Found Zero For Input SubModule Address: [%s]\n", SubModAddr_StrDup);fflush(stdout);
				}
			}				
		}
		else
		{
		   printf("\n SubModule Address Revision Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
	}
	fclose(fplb_file);
	
	/* char* RptShellCommandLine = NULL;
	RptShellCommandLine = (char *) MEM_alloc(100*sizeof(char ));
	printf("\n File Short Shell Call Started...");fflush(stdout);
	tc_strcpy(RptShellCommandLine,"/user/cvprod/sourav/MCCMAINDASHBOARD/FileShort.sh");
	tc_strcat(RptShellCommandLine," ");
	tc_strcat(RptShellCommandLine,LbRptFile);
	tc_strcat(RptShellCommandLine," ");
	tc_strcat(RptShellCommandLine,MstrLbRptFile);
	printf("\n CommandLine: -------> [%s]",RptShellCommandLine);fflush(stdout);
	system(RptShellCommandLine); 
    printf("\n File Short Shell Call Ended..."); */
	
	char command[512];
	printf("\n File Short Shell Call Started...");fflush(stdout);
	sprintf(command,"/user/cvprod/sourav/MCCMAINDASHBOARD/FileShort.sh %s %s",LbRptFile,MstrLbRptFile);
	system(command);
	printf("\n File Short Shell Call Ended...");


	char *item_id_str = NULL;
	char *item_plat_str = NULL;
	char *item_id_strDup = NULL;
	char *item_plat_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer1[MAX_LINE_LENGTH];
	int i = 0;
	int hcvcount = 0;
	int ilmcvcount = 0;
	int scvcount = 0;
	int passcount = 0;
	int cvcount = 0;
	fpPart_List = fopen(MstrLbRptFile,"r");
	
	if(fpPart_List == NULL)
	{
	    printf("\n Unable to Open Input File \n");fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
	    while(fgets(Buffer1,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer1,"^");
			item_plat_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_plat_str!=NULL)tc_strdup(item_plat_str,&item_plat_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_plat_strDup!=NULL)trimwhitespace(item_plat_strDup);
			
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Platform(item_plat_strDup): [%s]\n",item_plat_strDup);
			
			if(tc_strstr(item_plat_strDup,"HCV")!=NULL)
			{
				hcvcount = hcvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"ILMCV")!=NULL)
			{
				ilmcvcount = ilmcvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"SCV")!=NULL)
			{
				scvcount = scvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"BUS")!=NULL)
			{
				passcount = passcount + 1;
			}
			else
			{
				printf("\n!!...Platform Not Matched..!!\n");fflush(stdout);
			}
		}
		cvcount = hcvcount + ilmcvcount + scvcount + passcount;
		char hcvcountstr[10];
		char ilmcvcountstr[10];
		char scvcountstr[10];
		char passcountstr[10];
		char cvcountstr[10];
		tostring(hcvcountstr, hcvcount);
		tostring(ilmcvcountstr, ilmcvcount);
		tostring(scvcountstr, scvcount);
		tostring(passcountstr, passcount);
		tostring(cvcountstr, cvcount);

		write2xml(CVRpt2,"<DataSheet2>\n");
		write2xml(CVRpt2,"<Details2>"); write2xml(CVRpt2,"Total Submodules(SM)"); write2xml(CVRpt2,"</Details2>\n");
		write2xml(CVRpt2,"<DS2HCV>"); write2xml(CVRpt2,"HCV"); write2xml(CVRpt2,"</DS2HCV>\n");
		write2xml(CVRpt2,"<DS2HCVData>"); write2xml(CVRpt2,hcvcountstr); write2xml(CVRpt2,"</DS2HCVData>\n");
		write2xml(CVRpt2,"<DS2ILMCV>"); write2xml(CVRpt2,"ILMCV"); write2xml(CVRpt2,"</DS2ILMCV>\n");
		write2xml(CVRpt2,"<DS2ILMCVData>"); write2xml(CVRpt2,ilmcvcountstr); write2xml(CVRpt2,"</DS2ILMCVData>\n");
		write2xml(CVRpt2,"<DS2SCV>"); write2xml(CVRpt2,"SCV"); write2xml(CVRpt2,"</DS2SCV>\n");
		write2xml(CVRpt2,"<DS2SCVData>"); write2xml(CVRpt2,scvcountstr); write2xml(CVRpt2,"</DS2SCVData>\n");
		write2xml(CVRpt2,"<DS2PASS>"); write2xml(CVRpt2,"PASS(BUS)"); write2xml(CVRpt2,"</DS2PASS>\n");
		write2xml(CVRpt2,"<DS2PASSData>"); write2xml(CVRpt2,passcountstr); write2xml(CVRpt2,"</DS2PASSData>\n");
		write2xml(CVRpt2,"<DS2CV>"); write2xml(CVRpt2,"CV"); write2xml(CVRpt2,"</DS2CV>\n");
		write2xml(CVRpt2,"<DS2CVData>"); write2xml(CVRpt2,cvcountstr); write2xml(CVRpt2,"</DS2CVData>\n");
		write2xml(CVRpt2,"</DataSheet2>\n");
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	
	return iFail;
}

int TC_CVDS1(FILE* CVRpt1)
{
	int iFail = ITK_ok;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_plat_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *item_plat_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	int i = 0;
	int hcvcount = 0;
	int ilmcvcount = 0;
	int scvcount = 0;
	int passcount = 0;
	int cvcount = 0;
	fpPart_List = fopen("/user/cvprod/sourav/MCCMAINDASHBOARD/PartList.txt","r");
	
	if(fpPart_List == NULL)
	{
	    printf("\n Unable to Open Input File \n");fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
	    while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			item_plat_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			if(item_plat_str!=NULL)tc_strdup(item_plat_str,&item_plat_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_rev_strDup!=NULL)trimwhitespace(item_rev_strDup);
			if(item_seq_strDup!=NULL)trimwhitespace(item_seq_strDup);
			if(item_plat_strDup!=NULL)trimwhitespace(item_plat_strDup);
			
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			printf("\n Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
			printf("\n Part Platform(item_plat_strDup): [%s]\n",item_plat_strDup);
			
			if(tc_strstr(item_plat_strDup,"HCV")!=NULL)
			{
				hcvcount = hcvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"ILMCV")!=NULL)
			{
				ilmcvcount = ilmcvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"SCV")!=NULL)
			{
				scvcount = scvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"BUS")!=NULL)
			{
				passcount = passcount + 1;
			}
			else
			{
				printf("\n!!...Platform Not Matched..!!\n");fflush(stdout);
			}
		}
		cvcount = hcvcount + ilmcvcount + scvcount + passcount;
		char hcvcountstr[10];
		char ilmcvcountstr[10];
		char scvcountstr[10];
		char passcountstr[10];
		char cvcountstr[10];
		tostring(hcvcountstr, hcvcount);
		tostring(ilmcvcountstr, ilmcvcount);
		tostring(scvcountstr, scvcount);
		tostring(passcountstr, passcount);
		tostring(cvcountstr, cvcount);

		write2xml(CVRpt1,"<DataSheet1>\n");
		write2xml(CVRpt1,"<Details1>"); write2xml(CVRpt1,"Total Vehicle(s) Applicable, All Live VCs"); write2xml(CVRpt1,"</Details1>\n");
		write2xml(CVRpt1,"<DS1HCV>"); write2xml(CVRpt1,"HCV"); write2xml(CVRpt1,"</DS1HCV>\n");
		write2xml(CVRpt1,"<DS1HCVData>"); write2xml(CVRpt1,hcvcountstr); write2xml(CVRpt1,"</DS1HCVData>\n");
		write2xml(CVRpt1,"<DS1ILMCV>"); write2xml(CVRpt1,"ILMCV"); write2xml(CVRpt1,"</DS1ILMCV>\n");
		write2xml(CVRpt1,"<DS1ILMCVData>"); write2xml(CVRpt1,ilmcvcountstr); write2xml(CVRpt1,"</DS1ILMCVData>\n");
		write2xml(CVRpt1,"<DS1SCV>"); write2xml(CVRpt1,"SCV"); write2xml(CVRpt1,"</DS1SCV>\n");
		write2xml(CVRpt1,"<DS1SCVData>"); write2xml(CVRpt1,scvcountstr); write2xml(CVRpt1,"</DS1SCVData>\n");
		write2xml(CVRpt1,"<DS1PASS>"); write2xml(CVRpt1,"PASS(BUS)"); write2xml(CVRpt1,"</DS1PASS>\n");
		write2xml(CVRpt1,"<DS1PASSData>"); write2xml(CVRpt1,passcountstr); write2xml(CVRpt1,"</DS1PASSData>\n");
		write2xml(CVRpt1,"<DS1CV>"); write2xml(CVRpt1,"CV"); write2xml(CVRpt1,"</DS1CV>\n");
		write2xml(CVRpt1,"<DS1CVData>"); write2xml(CVRpt1,cvcountstr); write2xml(CVRpt1,"</DS1CVData>\n");
		write2xml(CVRpt1,"</DataSheet1>\n");
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	char *PreVCompFile = (char *) malloc(100*sizeof(char));
	printf("\n Generating XML Report File Name..!!");fflush(stdout);
	tc_strcpy(PreVCompFile,"/tmp/");
	tc_strcat(PreVCompFile,"MCCMainDashboardReport");
	tc_strcat(PreVCompFile,"_");
	tc_strcat(PreVCompFile,GenDate);
	tc_strcat(PreVCompFile,".xml");
	//Report = fopen("/tmp/MCCMainDashboardReport.xml","w");
	printf("\n Pre MCC Main Dashboard Report File Name: [%s]", PreVCompFile);fflush(stdout);
	
	Report = fopen(PreVCompFile,"w");
	if(Report == NULL)
	{
		printf("ERROR: Unable To Open XML File..!!\n");
	}
	else
	{
		printf("XML File Opened Successfully..!!\n");
	}
	write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	write2xml(Report,"<MCCMainDashboardRpt>\n");
	printf(" Input_File Not Null..!!\n");fflush(stdout);
	printf("\n >>>>>>>>>>111111111111111111111111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function1: TCUA-CV Data Sheet1 Print Start");fflush(stdout);
	TC_CVDS1(Report);
	printf("\n Function1: TCUA-CV Data Sheet1 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>111111111111111111111111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222222222222222222222222222222222222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function2: TCUA-CV Data Sheet2 Print Start");fflush(stdout);
	TC_CVDS2(Report);
	printf("\n Function2: TCUA-CV Data Sheet2 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222222222222222222222222222222222222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>333333333333333333333333333333333333333333333333333333333333333333333333<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function3: TCUA-CV Data Sheet3 Print Start");fflush(stdout);
	TC_CVDS3(Report);
	printf("\n Function3: TCUA-CV Data Sheet3 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>333333333333333333333333333333333333333333333333333333333333333333333333<<<<<<<<<<<\n");fflush(stdout);
	write2xml(Report,"</MCCMainDashboardRpt>\n");
	fclose(Report);		
	printf("\n All Details Written Successfully on the XML File....\n");fflush(stdout);
		
	printf("Current File To Original File Move Start..!!\n");fflush(stdout);
	char* ShellCommandLine = NULL;
	ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	tc_strcpy(ShellCommandLine,"/user/cvprod/sourav/MCCMAINDASHBOARD/RemoveProcessFiles.sh");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,PreVCompFile);
	system(ShellCommandLine);
	printf("Current File To Original File Move End..!!\n");fflush(stdout);

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mccmaindashboard.c
* // ./linkitk -o tm_mccmaindashboard tm_mccmaindashboard.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MCCMAINDASHBOARD/tm_mccmaindashboard .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MCCMAINDASHBOARD/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MCCMAINDASHBOARD/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MCCMAINDASHBOARD/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/MCCMAINDASHBOARD/SendEmail.sh .
* // ./tm_mccmaindashboard -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mccmaindashboard -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mccmaindashboard -u=infodba -p=loader123 -g=dba
*
***************************************************************************/