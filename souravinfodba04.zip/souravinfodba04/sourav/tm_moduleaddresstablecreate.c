/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create Module Revision Object After Reading Data From Input File 
*  File Name    :   tm_modulecreate.c
*  Created on   :   Jun 12th, 2024
*  Usage        :   tm_modulecreate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/06/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define ITK_errStore 91900002
#define MAX_LINE_LEN 10240

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

/*
#define ITKCALL( argument )                                             \
{                                                                       \
    int retcode = argument;                                             \
    if ( retcode != ITK_ok ) {                                          \
        char* s;                                                        \
        printf( " "#argument "\n" );                                    \
        printf( "  returns [%d]\n", retcode );                          \
        EMH_ask_error_text (retcode, &s);                               \
        printf( "  Teamcenter ERROR: [%s]\n", s);           \
        printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
        if (s != 0) MEM_free (s);                                       \
    }                                                                   \
}*/


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}




/*******************************************START OF UTILITY FUNCTIONS**************************************************/

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}
void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}



int getItemRevObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_sendESOMailRep: getItemRevObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}

int getGeneralObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_sendESOMailRep: getGeneralObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



typedef struct PartModel_
{
 int level;
 tag_t childItemRev;
 tag_t childBomLine;
} *PartModel; 

void setAddPartModel(int *count,PartModel **objlist,PartModel obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartModel *)malloc((*count ) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartModel *)realloc((*objlist),(*count) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}





void setFindTagInSet(tag_t *objlist,tag_t obj,int count,int *found)
{
	int k=0;
	*found=-1;
	for(k=0;k<count;k++)
	{		
		if(objlist[k]==obj)
		{
			*found=k;
			break;
		}
	}
}



char *t5TrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

void remove_multi_new_line(char* string)
{
  size_t length = strlen(string);
  while((length>0) && (string[length-1] == '\n'))
  {
      --length;
      string[length] ='\0';
  }
}

int getTCObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	//printf("\n\n partNumber ===> [%s]\n",partNumber);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	//printf("\n getLatestPart: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}


int getItemRevObj(char *partNumber, char* revId, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	//printf("\n\n partNumber ===> [%s]\n",partNumber);fflush(stdout);
	//printf("\n\n revId ===> [%s]\n",revId);fflush(stdout);
	
	qry_entries[0] = "Item ID";
	
	qry_values[0] = partNumber;
	
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 1, qry_entries, qry_values, &count, &itemObjs));
	//printf("\n getItemRevObj: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		//*tcPart = itemObjs[count-1];
		int k=0;
		char* revS = NULL;		
		for(k=0;k<count;k++)
		{
			CALLAPI(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			//printf("\n getItemRevObj: revS==>%s", revS);fflush(stdout);
			//printf("\n getItemRevObj: revS length==>%d", strlen(revS));fflush(stdout);
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revId)==0)
			{
				*tcPart = itemObjs[k];
				break;
			}			
		}
	}
	
	return ifail;
}


int getPartObjFromRevSeq(char* partnumber, char* rev, char* seq, tag_t *partObj)
{
	int ifail = ITK_ok;
	
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;
	char* revStr = NULL;
	int seqInt = 0;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Item ID";
	qry_entries[1] = "Type";
	//qry_entries[2] = "Sequence Id";
	
	qry_values[0] = partnumber;
	revStr = (char *) MEM_alloc( 10 * sizeof(char) );
	//tc_strcpy(revStr,"");
	tc_strcpy(revStr,rev);
	tc_strcat(revStr,";");
	tc_strcat(revStr,seq);
	printf("\nSAN:getPartObjFromRevSeq: revStr=========>%s\n",revStr);fflush(stdout);
	printf("\nSAN:getPartObjFromRevSeq: revStr==length=======>%d\n",strlen(revStr));fflush(stdout);
	qry_values[1] = "Design Revision";
	
	//trimLeading(revStr);
	char* revStr1 = NULL;
	char* revStr2 = NULL;
	revStr1 = ltrimString(revStr);
	revStr2 = rtrimString(revStr1);
	
	
		
	printf("\nSAN:getPartObjFromRevSeq: After trim revStr2=========>%s\n",revStr2);fflush(stdout);
	printf("\nSAN:getPartObjFromRevSeq: After trim revStr2==length=======>%d\n",strlen(revStr2));fflush(stdout);	
	
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\n getPartObjFromRevSeq: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		int k=0;
		char* revS = NULL;
		for(k=0;k<count;k++)
		{
			CALLAPI(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			printf("\n getPartObjFromRevSeq: revS==>%s", revS);fflush(stdout);
			printf("\n getPartObjFromRevSeq: revS length==>%d", strlen(revS));fflush(stdout);
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revStr2)==0)
			{
				*partObj = itemObjs[k];
				break;
			}
			
		}
	}
	
	if(revStr!=NULL) MEM_free(revStr);
	return ifail;	

}


/*******************************************END OF UTILITY FUNCTIONS**************************************************/




int getAllItemRevObject(char *partNumber, char *object_type, int *cnt, tag_t **tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	//printf("\n SAN:getAllItemRevObject: getItemRevObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		int i=0;
		for(i=0;i<count;i++)
		{
			t5AddTagObjToSet(cnt,tcPart,itemObj[i]);
		}
		

	}
	
	return ifail;
}

typedef struct SubModuleLibDet_
{
	char moduleAddr[50];
	char desc[300];
	char agrregate[300];
	char agrregateGrp[300];
	
	char** moduleNoList;
	int moduleNoListCnt;
	
	char** moduleRevList;
	//int moduleRevListCnt;
		
	char** moduleSeqList;
	//int moduleSeqListCnt;
	
	char** drStatList;
	//int drStatListCnt;
	
	char** prodlineList;
	char** platformList;
	char** projectcodeList;
	
	char** descList;
	
}SubModuleLibDet;

void setAddSubModuleLibDet(int *count,SubModuleLibDet **objlist,SubModuleLibDet obj )
{

	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (SubModuleLibDet *)malloc((*count ) * sizeof(SubModuleLibDet ));
	}
	else
	{
		(*objlist) = (SubModuleLibDet *)realloc((*objlist),(*count) * sizeof(SubModuleLibDet ));
	}

	(*objlist)[*count-1] = obj;
}

void t5FindSubModuleLibInSubModuleLibSet(SubModuleLibDet *subModuleLibList,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(subModuleLibList[k].moduleAddr,str)==0)
		{
			*found=1;
			break;
		}

	}
}


int getSubModuleLibRevTag(char *moduleAddr, tag_t *moduleLibRevTag)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Name";
	qry_entries[1] = "ID";
	
	qry_values[0] = moduleAddr;
	qry_values[1] = moduleAddr;
		
	CALLAPI(QRY_find2("SubModuleLibrary...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	//printf("\nMCC:getSubModuleLibRevTag: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*moduleLibRevTag = itemObj[count-1];
	}
	
	return ifail;
}

int createSubModuleLibTag(SubModuleLibDet subModuleLibData, tag_t* SubModuleLibRevTag)
{
	int ifail = ITK_ok;
	tag_t SubModuleLibRevType = NULLTAG;
	tag_t SubModuleLibRevCreInput = NULLTAG;
	
	printf("\nMCC:Creation of Submodule Lib starts....\n");fflush(stdout);
	
	ifail = TCTYPE_find_type("T5_SubmodulelibRevision", NULL, &SubModuleLibRevType);
	
	if(SubModuleLibRevType != NULLTAG)
	{
		tag_t SubModuleLibType = NULLTAG;
		ifail = TCTYPE_construct_create_input(SubModuleLibRevType, &SubModuleLibRevCreInput);
		
		if(SubModuleLibRevCreInput != NULLTAG)
		{
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "item_revision_id", "A;1");
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "sequence_id", "1"); 
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "object_desc", subModuleLibData.desc);
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "t5_submoduledesc", subModuleLibData.desc);
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "t5_aggrgrp", subModuleLibData.agrregateGrp);
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "t5_aggr", subModuleLibData.agrregate);
			ifail = AOM_set_value_string(SubModuleLibRevCreInput, "t5_ModuleAddrSL", subModuleLibData.moduleAddr);
			
			ifail = TCTYPE_find_type("T5_Submodulelib", NULL, &SubModuleLibType);    
			if(SubModuleLibType != NULLTAG)
			{
				tag_t SubModuleLibCreInput  = NULLTAG;
				tag_t SubModuleTag = NULLTAG;
				ifail = TCTYPE_construct_create_input(SubModuleLibType, &SubModuleLibCreInput);
				
				ifail = AOM_set_value_string(SubModuleLibCreInput, "object_name", subModuleLibData.moduleAddr);
				ifail = AOM_set_value_string(SubModuleLibCreInput, "item_id", subModuleLibData.moduleAddr);
				
				ifail = TCTYPE_create_object(SubModuleLibCreInput, &SubModuleTag);
				
				if(SubModuleTag != NULLTAG)
				{
					tag_t latestSubModuleRevTag = NULLTAG;
					
					printf("\nMCC: SubModule Lib Created successfully. **** \n\n \n ");fflush(stdout);
					
					if(AOM_save_with_extensions(SubModuleTag));
					if(AOM_unlock(SubModuleTag));		
					if(AOM_refresh(SubModuleTag,1));
					
					
					ifail = ITEM_ask_latest_rev(SubModuleTag, &latestSubModuleRevTag);
					
					if(latestSubModuleRevTag != NULLTAG)
					{
						ifail = AOM_lock(latestSubModuleRevTag);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "item_revision_id", "A;1");
						ifail = AOM_set_value_string(latestSubModuleRevTag, "sequence_id", "1"); 
						ifail = AOM_set_value_string(latestSubModuleRevTag, "object_desc", subModuleLibData.desc);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "t5_submoduledesc", subModuleLibData.desc);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "t5_aggrgrp", subModuleLibData.agrregateGrp);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "t5_aggr", subModuleLibData.agrregate);
						ifail = AOM_set_value_string(latestSubModuleRevTag, "t5_ModuleAddrSL", subModuleLibData.moduleAddr);											
						
						ifail = AOM_save_with_extensions(latestSubModuleRevTag);
						ifail = AOM_unlock(latestSubModuleRevTag);
						ifail = AOM_refresh(latestSubModuleRevTag,1);
						
						
						//Create- Update the Table properties.
						
						//subModuleLibData.moduleNoListCnt
						
						int num_rows_to_insert = 0;
						tag_t* table_rows_tag = NULLTAG;
						int property_index = 0;
						
						char** moduleNoList = NULL;
						char** moduleRevList = NULL;
						char** moduleSeqList = NULL;
						char** drStatList = NULL;
                        char** prodlineList = NULL;
                        char** platformList = NULL;
                        char** projectcodeList = NULL;
                        char** descList = NULL;						
						
						
						num_rows_to_insert = subModuleLibData.moduleNoListCnt;
						moduleNoList = subModuleLibData.moduleNoList;
						moduleRevList = subModuleLibData.moduleRevList;
						moduleSeqList = subModuleLibData.moduleSeqList;
						drStatList = subModuleLibData.drStatList;
						prodlineList = subModuleLibData.prodlineList;
						platformList = subModuleLibData.platformList;
						projectcodeList = subModuleLibData.projectcodeList;
						descList = subModuleLibData.descList;
						
						printf("\nMCC:num_rows_to_insert ===>[%d]\n",num_rows_to_insert);fflush(stdout);
						
						ifail = AOM_insert_table_rows(latestSubModuleRevTag,"t5_Submoduledetail",0,num_rows_to_insert,&table_rows_tag );
						printf("MCC:ifail is %d\n",ifail);
						
						for ( property_index = 0 ; property_index < num_rows_to_insert; property_index++ )
						{
							printf("\nMCC:ModuleNo[%d]==> [%s/%s;%s], DR Status:[%s]\n",property_index,moduleNoList[property_index],moduleRevList[property_index],moduleSeqList[property_index],drStatList[property_index]);fflush(stdout);
							
							if(table_rows_tag [ property_index ] != NULLTAG)
							{
								char* srnNo = (char*)MEM_alloc(30*sizeof(char*));
								sprintf(srnNo,"%d",property_index + 1);
								
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_srno", srnNo);
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_submoduleno", moduleNoList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_desc", descList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_rev", moduleRevList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_seq", moduleSeqList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_productline", prodlineList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_Platform", platformList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_projectcode", projectcodeList[property_index] );
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_drarstatus", drStatList[property_index] );
								
								MEM_free(srnNo);
								
								ifail = AOM_save_with_extensions(table_rows_tag[property_index]);
							}
						}
						
						
					}
						
				}
			}
			
			
			
			
		}

		
		
		
	}
	
	printf("\nMCC:Creation of Submodule Lib finishes....\n");fflush(stdout);
	return ITK_ok;
}


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );	
	printf("\nMCC:*********** Start Of Main function ************* \n");fflush(stdout);	
	
	if(ITK_auto_login() == ITK_ok)	
	{

		char *filepath = ITK_ask_cli_argument("-f=");
		FILE * fp = NULL;
				
		ITK_set_journalling( TRUE );
		printf("\nMCC:Login successfull.\n");fflush(stdout);		
		printf("\nMCC:Input Parameters:Input File:[%s]\n",filepath);fflush(stdout);
		
		char* sno = NULL;
		char* moduleNo = NULL;
		char* moduleAddr = NULL;
		char* moduleRev = NULL;
		char* moduleSeq = NULL;
		char* drStat = NULL;	
		char* desc = NULL;
		char* agrregate = NULL;
		char* agrregateGrp = NULL;
		char* prodline = NULL;
		char* platform = NULL;
		char* projectcode = NULL;
		

		char** moduleNoList = NULL;
		int moduleNoListCnt = 0;
		
		char** moduleAddrList = NULL;
		int moduleAddrListCnt = 0;
		
		char** moduleRevList = NULL;
		int moduleRevListCnt = 0;
		
		char** moduleSeqList = NULL;
		int moduleSeqListCnt = 0;
		
		char** drStatList = NULL;
		int drStatListCnt = 0;
		
		char** descList = NULL;
		int descListCnt = 0;
		
		char** agrregateList = NULL;
		int agrregateListCnt = 0;
		
		char** agrregateGrpList = NULL;
		int agrregateGrpListCnt = 0;
		
		char** prodlineList = NULL;
		int prodlineListCnt = 0;
		
		char** platformList = NULL;
		int platformListCnt = 0;
		
		char** projectcodeList = NULL;
		int projectcodeListCnt = 0;

		fp = fopen(filepath, "r");
		

		if(fp==NULL)
		{
			printf("\nMCC:Could not open the file %s. Kindly check.\n",filepath);fflush(stdout);
		}
		else
		{
			int k =0;
			char buffer[MAX_LINE_LEN] ="";
			
			
			while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
			{
				sno = strtok(buffer,",");
				moduleNo = strtok(NULL,",");
				desc = strtok(NULL,",");
				moduleRev = strtok(NULL,",");
				moduleSeq = strtok(NULL,",");
				prodline = strtok(NULL,",");
				platform = strtok(NULL,",");
				projectcode = strtok(NULL,",");
				drStat =strtok(NULL,",");
				moduleAddr = strtok(NULL,",");
				agrregate = strtok(NULL,",");
				agrregateGrp = strtok(NULL,",");
				
								
				printf("\nMCC:[%d] SNo[%s], Module No[%s/%s;%s],Module Addresss:[%s], DR Status[%s], Description[%s], Aggregate[%s], Aggregate Group[%s], Product Line[%s], Platform[%s], Project Code[%s]", k++, sno, moduleNo, moduleRev,moduleSeq,moduleAddr,drStat,desc,agrregate,agrregateGrp,prodline,platform,projectcode);fflush(stdout);
				
				
				t5AddStrToSet(&moduleNoListCnt, &moduleNoList,moduleNo);
				t5AddStrToSet(&descListCnt, &descList,desc);
				t5AddStrToSet(&moduleRevListCnt, &moduleRevList,moduleRev);
				t5AddStrToSet(&moduleSeqListCnt, &moduleSeqList,moduleSeq);
				t5AddStrToSet(&prodlineListCnt, &prodlineList,prodline);
				t5AddStrToSet(&platformListCnt, &platformList,platform);
				t5AddStrToSet(&projectcodeListCnt, &projectcodeList,projectcode);
				t5AddStrToSet(&drStatListCnt, &drStatList,drStat);
				t5AddStrToSet(&moduleAddrListCnt, &moduleAddrList,moduleAddr);
				t5AddStrToSet(&agrregateListCnt, &agrregateList,agrregate);
				t5AddStrToSet(&agrregateGrpListCnt, &agrregateGrpList,agrregateGrp);
				
				
				
				
			}
		}
		
		
		
		

		if(fp) fclose(fp);
		
		
		printf("\nMCC:moduleNoListCnt[%d], agrregateListCnt[%d], agrregateGrpListCnt[%d]",moduleNoListCnt,agrregateListCnt,agrregateGrpListCnt);fflush(stdout);
		
		
		int i=0;
		int j =0;
		
		SubModuleLibDet * subModuleLibDetList;
		int subModuleLibDetListCnt =0;
		
		
		char** moduleADDList = NULL;
		int moduleADDListCnt = 0;
		int found = 0;
		
		
		for(i=0;i<moduleAddrListCnt;i++)
		{
			char* moduleAdd = NULL;
			
			char** moduleNo1List = NULL;
			int moduleNo1ListCnt = 0;
			
			char** moduleRev1List = NULL;
			int moduleRev1ListCnt = 0;
			
			char** moduleSeq1List = NULL;
			int moduleSeq1ListCnt = 0;
			
			char** drStat1List = NULL;
			int drStat1ListCnt = 0;	

            char** prodline1List = NULL;
			int prodline1ListCnt = 0;

            char** platform1List = NULL;
			int platform1ListCnt = 0;

            char** projectcode1List = NULL;
			int projectcode1ListCnt = 0;

            char** desc1List = NULL;
			int desc1ListCnt = 0;			
			
			moduleAdd = moduleAddrList[i];
			
			t5FindStrInSet(moduleADDList,moduleADDListCnt,moduleAdd,&found);
			
			if(found ==0)
			{
				SubModuleLibDet subMdlDet;
				
				for(j=0;j<moduleAddrListCnt;j++)
				{
					if(tc_strcmp(moduleAdd,moduleAddrList[j])==0)
					{
						t5AddStrToSet(&moduleNo1ListCnt, &moduleNo1List,moduleNoList[j]);
						t5AddStrToSet(&moduleRev1ListCnt, &moduleRev1List,moduleRevList[j]);
						t5AddStrToSet(&moduleSeq1ListCnt, &moduleSeq1List,moduleSeqList[j]);
						t5AddStrToSet(&drStat1ListCnt, &drStat1List,drStatList[j]);
						t5AddStrToSet(&prodline1ListCnt, &prodline1List,prodlineList[j]);
						t5AddStrToSet(&platform1ListCnt, &platform1List,platformList[j]);
						t5AddStrToSet(&projectcode1ListCnt, &projectcode1List,projectcodeList[j]);
						t5AddStrToSet(&desc1ListCnt, &desc1List,descList[j]);

					}
				}
			
				tc_strcpy(subMdlDet.moduleAddr,moduleAdd);
				tc_strcpy(subMdlDet.desc,descList[i]);
				tc_strcpy(subMdlDet.agrregate,agrregateList[i]);
				tc_strcpy(subMdlDet.agrregateGrp,agrregateGrpList[i]);
				
				subMdlDet.moduleNoList = moduleNo1List;
				subMdlDet.moduleNoListCnt = moduleNo1ListCnt;
				subMdlDet.moduleRevList = moduleRev1List;
				subMdlDet.moduleSeqList = moduleSeq1List;
				subMdlDet.drStatList = drStat1List;
				subMdlDet.prodlineList = prodline1List;
				subMdlDet.platformList = platform1List;
				subMdlDet.projectcodeList = projectcode1List;
				subMdlDet.descList = desc1List;
				
				
				
				
				setAddSubModuleLibDet(&subModuleLibDetListCnt, &subModuleLibDetList,subMdlDet);
			
			
			}
			
			t5AddStrToSet(&moduleADDListCnt, &moduleADDList,moduleAdd);
			
			
		}
		printf("\nMCC:subModuleLibDetListCnt ==> [%d]\n", subModuleLibDetListCnt);fflush(stdout);
		
		
		/* Logic to create the data in TCUA */
		
		int m = 0;
		
		
		for(m =0; m< subModuleLibDetListCnt; m++)
		{
			SubModuleLibDet subModuleLibData;
			char* moduleAddrStr = NULL;
			tag_t SubModuleLibRevTag = NULLTAG;
			subModuleLibData = subModuleLibDetList[m];
			
			moduleAddrStr = subModuleLibData.moduleAddr;
			
			//Check whether this already exists in PLM DB
			
			ifail = getSubModuleLibRevTag(moduleAddrStr, &SubModuleLibRevTag);
			
			if(SubModuleLibRevTag != NULLTAG)
			{
				printf("\nMCC:Already exists SubmoduleTag[%s] - Only update with new data\n",moduleAddrStr);fflush(stdout);
			}
			else
			{
				printf("\nMCC:Create a new SubModuleLib Object[%s].\n",moduleAddrStr);fflush(stdout);
				
				ifail = createSubModuleLibTag(subModuleLibData, &SubModuleLibRevTag);
			}
			
		}
			
		
	}
	

	
	
	printf("\nMCC:*********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_moduleaddresstablecreate.c
* // ./linkitk -o tm_moduleaddresstablecreate tm_moduleaddresstablecreate.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressTableCreate/tm_moduleaddresstablecreate .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressTableCreate/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressTableCreate/Input.csv .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressTableCreate/usage.txt .
* // ./tm_moduleaddresstablecreate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_moduleaddresstablecreate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/
