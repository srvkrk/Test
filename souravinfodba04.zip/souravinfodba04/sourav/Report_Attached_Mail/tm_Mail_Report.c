/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Generate Report & Send it To User's Email As An Attachment  
*  File Name    :   tm_Mail_Report.c
*  Created on   :   Sep 09th, 2023
*  Usage        :   tm_Mail_Report
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     09/09/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *Part_item_id = NULL;
	char *item_id_str = NULL;
	FILE *fpPart_List = NULL;
         		
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char *RptFile= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current TimeStamp: [%s]", GenDate);fflush(stdout);

	tc_strcpy(RptFile,"Sample_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");
	
	fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ S A M P L E   R E P O R T ~~~~~~~~~~~~~~~");fflush(fpOutput_file);
    fprintf(fpOutput_file,"\n Part_No");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File [%s] on Server",RptFile);fflush(stdout);
	}

	if(fpPart_List != NULL)
	{
		printf("\n Part_List Not Null\n");fflush(stdout);
		Part_item_id=(char *) MEM_alloc(100);

		while(fgets(Part_item_id,100,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Part_item_id,"^");
			printf("\n Part Details(item_id_str): [%s]\n",item_id_str);
			fprintf(fpOutput_file,"\n %s",item_id_str);fflush(fpOutput_file);

		}
	}
	else 
	{
		printf("\n Part_List is NULL\n");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	int sysreturn = -1;
	char*  sMail = NULL;
	char*  sMBody = NULL;
	sMBody = (char *) MEM_alloc(1500 * sizeof(char ));

    tc_strcpy(sMBody,"Dear All, \n\n ");
	tc_strcat(sMBody,"\n\n                    Please Check Attached Report");
    tc_strcat(sMBody,"\n\n\n Regards,\n PLM Team \n\n\n");
	tc_strcat(sMBody," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
    sMail = (char *) MEM_alloc(2000 * sizeof(char ) + strlen(sMBody) * sizeof(char));;
	tc_strcpy(sMail,"echo \"");
	tc_strcat(sMail,sMBody);
	if(sMBody) MEM_free(sMBody);
    tc_strcat(sMail,"\" ");								
	tc_strcat(sMail," | nail  -s \"SUCCESS: REPORT");
	tc_strcat(sMail,"\"");
	tc_strcat(sMail," -a ");
	tc_strcat(sMail,RptFile);
	tc_strcat(sMail," ");
	tc_strcat(sMail," -c \" souravk.ttl@tatamotors.com\"");
	tc_strcat(sMail," ");	
	tc_strcat(sMail," -r \" cvprod@vzmailserver.tmindia.tatamotors.com\"");
	tc_strcat(sMail," ");
	tc_strcat(sMail,"souravk.ttl@tatamotors.com");
	printf("\nCommand is: [%s]\n",sMail); fflush(stdout);
		
	if(sMail) MEM_free(sMail);
	if(sysreturn!=0)
	{
		printf("\n System: Call Failed For Sending Report\n");fflush(stdout);
	}
	sysreturn = -1;		
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);

	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
}


/***************************************************************************
*
* // ./compile tm_Mail_Report.c
* // ./linkitk -o tm_Mail_Report tm_Mail_Report.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Report_Attached_Mail/tm_Mail_Report .
* // tm_Mail_Report -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_Mail_Report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_Mail_Report -u=loader -p=loader123 -g=dba
*
***************************************************************************/