/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Part & Print its Properties on Reports  
*  File Name    :   tm_PartDetailsRpt.c
*  Created on   :   March 12th, 2024
*  Usage        :   tm_PartDetailsRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/03/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	char* cPType = NULL;
	char* cPTypeDup = NULL;
	char* cDesGrp = NULL;
	char* cDesGrpDup = NULL;
	char* cPartCat = NULL;
	char* cPartCatDup = NULL;
	char* cPartWt = NULL;
	char* cPartWtDup = NULL;
	char* cEnvDim = NULL;
	char* cEnvDimDup = NULL;
	tag_t tSpecfRelationType = NULLTAG;
	tag_t tRefRelationType = NULLTAG;
	tag_t tRendRelationType = NULLTAG;
	int iSpecSec_ObjCount = 0;
	tag_t* tSpecSecObjectList = NULLTAG;
	int iRefSec_ObjCount = 0;
	tag_t* tRefSecObjectList = NULLTAG;
	int iRendSec_ObjCount = 0;
	tag_t* tRendSecObjectList = NULLTAG;
	char *item_spec = (char *) malloc(10*sizeof(char));
	char *item_ref = (char *) malloc(10*sizeof(char));
	char *item_rend = (char *) malloc(10*sizeof(char));tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	char *item_revseq_strDup = (char *) malloc(10*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t DesRev_tag = NULLTAG;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Part_Details_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");
	
    fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~  P A R T   D E T A I L S   R E P O R T  ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
    fprintf(fpOutput_file,"PART_NO, REV, SEQ, PART_TYPE, DESIGN_GROUP, PART_CATEGORY, WEIGHT, ENV_DIMENSION, IMAN_specification, IMAN_reference, IMAN_Rendering\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			
			item_id_str=strtok(Buffer,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_rev_strDup!=NULL)trimwhitespace(item_rev_strDup);
			if(item_seq_strDup!=NULL)trimwhitespace(item_seq_strDup);
			
			tc_strcpy(item_revseq_strDup,item_rev_strDup);
			tc_strcat(item_revseq_strDup,";");
			tc_strcat(item_revseq_strDup,item_seq_strDup);
			
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			printf("\n Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
			printf("\n Part Rev&Seq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						DesRev_tag = titemobj_results[i];
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_PartType",&cPType));
						if(tc_strlen(cPType)>0)
						{
							tc_strdup(cPType,&cPTypeDup);
							trimwhitespace(cPTypeDup);
							printf("\n Part_Type Value After Dup & Trim: --------> <%s>", cPTypeDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&cPTypeDup);
							printf("\n Part_Type Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_DesignGrp",&cDesGrp));
						if(tc_strlen(cDesGrp)>0)
						{
							tc_strdup(cDesGrp,&cDesGrpDup);
							trimwhitespace(cDesGrpDup);
							printf("\n Design_Group Value After Dup & Trim: --------> <%s>", cDesGrpDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&cDesGrpDup);
							printf("\n Design_Group Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_SpareCriteria",&cPartCat));
						if(tc_strlen(cPartCat)>0)
						{
							tc_strdup(cPartCat,&cPartCatDup);
							trimwhitespace(cPartCatDup);
							printf("\n Part_Category Value After Dup & Trim: --------> <%s>", cPartCatDup);fflush(stdout);
							STRNG_replace_str(cPartCatDup,","," ",&cPartCatDup);
							STRNG_replace_str(cPartCatDup,";"," ",&cPartCatDup);
							STRNG_replace_str(cPartCatDup,"\n"," ",&cPartCatDup);
							STRNG_replace_str(cPartCatDup,"'"," ",&cPartCatDup);
							printf("\n Part_Category Final Value: --------> [%s]\n", cPartCatDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&cPartCatDup);
							printf("\n Part_Category Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_Weight",&cPartWt));
						if(tc_strlen(cPartWt)>0)
						{
							tc_strdup(cPartWt,&cPartWtDup);
							trimwhitespace(cPartWtDup);
							printf("\n Part_Weight Value After Dup & Trim: --------> <%s>", cPartWtDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&cPartWtDup);
							printf("\n Part_Weight Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_EnvelopeDimensions",&cEnvDim));
						if(tc_strlen(cEnvDim)>0)
						{
							tc_strdup(cEnvDim,&cEnvDimDup);
							trimwhitespace(cEnvDimDup);
							printf("\n Envelope_Dimensions Value After Dup & Trim: --------> <%s>", cEnvDimDup);fflush(stdout);
							STRNG_replace_str(cEnvDimDup,","," ",&cEnvDimDup);
							STRNG_replace_str(cEnvDimDup,";"," ",&cEnvDimDup);
							STRNG_replace_str(cEnvDimDup,"\n"," ",&cEnvDimDup);
							STRNG_replace_str(cEnvDimDup,"'"," ",&cEnvDimDup);
							printf("\n Envelope_Dimensions Final Value: --------> [%s]\n", cEnvDimDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&cEnvDimDup);
							printf("\n Envelope_Dimensions Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(GRM_find_relation_type("IMAN_specification", &tSpecfRelationType));
				        ITK_CALL(GRM_find_relation_type("IMAN_reference", &tRefRelationType));
				        ITK_CALL(GRM_find_relation_type("IMAN_Rendering", &tRendRelationType));
						
						ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tSpecfRelationType, &iSpecSec_ObjCount, &tSpecSecObjectList));
					    printf("\n Secondary Object_Count[IMAN_specification]: [%d]\n",iSpecSec_ObjCount);fflush(stdout);
						if(iSpecSec_ObjCount > 0)
						{
							tc_strcpy(item_spec,"PRESENT");
						}
						else
						{
							tc_strcpy(item_spec,"--");
						}
						printf("\n 3D CAD Status on IMAN_specification Relation: --------> <%s>", item_spec);fflush(stdout);
						
						ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRefRelationType, &iRefSec_ObjCount, &tRefSecObjectList));
					    printf("\n Secondary Object_Count[IMAN_reference]: [%d]\n",iRefSec_ObjCount);fflush(stdout);
						if(iRefSec_ObjCount > 0)
						{
							tc_strcpy(item_ref,"PRESENT");
						}
						else
						{
							tc_strcpy(item_ref,"--");
						}
						printf("\n 3D CAD Status on IMAN_reference Relation: --------> <%s>", item_ref);fflush(stdout);
						
						ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRendRelationType, &iRendSec_ObjCount, &tRendSecObjectList));
					    printf("\n Secondary Object_Count[IMAN_Rendering]: [%d]\n",iRendSec_ObjCount);fflush(stdout);
						if(iRendSec_ObjCount > 0)
						{
							tc_strcpy(item_rend,"PRESENT");
						}
						else
						{
							tc_strcpy(item_rend,"--");
						}
						printf("\n 3D CAD Status on IMAN_Rendering Relation: --------> <%s>", item_rend);fflush(stdout);
						
						printf(" Part Details Start...!!\n");fflush(stdout);
						printf("[1] Part_No: [%s]\n",item_id_strDup);fflush(stdout);
						printf("[2] Revision: [%s]\n",item_rev_strDup);fflush(stdout);
						printf("[3] Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
						printf("[4] Part_Type: [%s]\n",cPTypeDup);fflush(stdout);
						printf("[5] Design_Group: [%s]\n",cDesGrpDup);fflush(stdout);
						printf("[6] Part_Category: [%s]\n",cPartCatDup);fflush(stdout);
						printf("[7] Weight: [%s]\n",cPartWtDup);fflush(stdout);
						printf("[8] Envelope_Dimensions: [%s]\n",cEnvDimDup);fflush(stdout);
						printf("[9] CAD[IMAN_specification]: [%s]\n",item_spec);fflush(stdout);
						printf("[10] CAD[IMAN_reference]: [%s]\n",item_ref);fflush(stdout);
						printf("[11] CAD[IMAN_Rendering]: [%s]\n",item_rend);fflush(stdout);
						printf(" SubModule Details End...!!\n");fflush(stdout);
						
						fprintf(fpOutput_file,"'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,cPTypeDup,cDesGrpDup,cPartCatDup,cPartWtDup,cEnvDimDup,item_spec,item_ref,item_rend);fflush(fpOutput_file);
					}
				}
				else
                {
					fprintf(fpOutput_file,"'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,"Not_Found","Not_Found","Not_Found","Not_Found","Not_Found","Not_Found","Not_Found","Not_Found");fflush(fpOutput_file);
					printf(" DesignRevision Not Found..!!\n");fflush(stdout);
				}
			}
			else
            {
				printf(" DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
		    }
			if(titemobj_results)
			{
				MEM_free(titemobj_results);
			}
		}
		fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
		fclose(fpOutput_file) ;           
		printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PartDetailsRpt.c
* // ./linkitk -o tm_PartDetailsRpt tm_PartDetailsRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Details_Report/tm_PartDetailsRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Details_Report/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Details_Report/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Details_Report/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Details_Report/SendEmail.sh .
* // ./tm_PartDetailsRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_PartDetailsRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/