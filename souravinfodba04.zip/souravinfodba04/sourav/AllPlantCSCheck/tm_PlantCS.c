/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   POM
*  Description  :   Generate TCUA Data Dump For All Plant CS
*  File Name    :   tm_PlantCS.c
*  Created on   :   Feb 15th, 2024
*  Usage        :   tm_PlantCS
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     15/02/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ValidateString (char *B)
{
    int i;
    for (i = 0; B[i] != '\0'; i++)
    {
        if (!(B[i] >= 65 && B[i] <= 90) && !(B[i] >= 97 && B[i] <= 122) && !(B[i] >= 44 && B[i] <= 57) && !(B[i] >31 && B[i] <= 32))
        {
            return 0;
        }
    }
       return 1;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile1 = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	FILE *fpOutput_file1 = NULL;
	char *Part_No = NULL;
	char *Part_RevSeq = NULL;
	char *Part_RevSeqDup = NULL;
	char *Part_Rev = NULL;
	char *Part_Seq = NULL;
	char *Input_File = (char *) malloc(400*sizeof(char));
	int z=0;
	tag_t iteamrev2 = NULLTAG;
	char *JSRCS = NULL;
	char *JSRCSDup = NULL;
	char *LKNCS = NULL;
	char *LKNCSDup = NULL;
	char *DWDCS = NULL;
	char *DWDCSDup = NULL;
	char *SNDCS = NULL;
	char *SNDCSDup = NULL;
	char *PUNCS = NULL;
	char *PUNCSDup = NULL;
	char *PNRCS = NULL;
	char *PNRCSDup = NULL;
	char *PPCBUCS = NULL;
	char *PPCBUCSDup = NULL;
	char *PUVCS = NULL;
	char *PUVCSDup = NULL;
	char *CARCS = NULL;
	char *CARCSDup = NULL;
	char *AHDCS = NULL;
	char *AHDCSDup = NULL;
	char *RJVCS = NULL;
	char *RJVCSDup = NULL;
	char *SGRCS = NULL;
	char *SGRCSDup = NULL;
	


    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char *start_limit = NULL;
	char *end_limit = NULL;
	start_limit = ITK_ask_cli_argument("-s=");
	end_limit = ITK_ask_cli_argument("-e=");
	trimwhitespace(start_limit);
	trimwhitespace(end_limit);
	printf(" [1]: Input Starting(start_limit): [%s]\n",start_limit);fflush(stdout);
	printf(" [2]: Input Ending(end_limit): [%s]\n",end_limit);fflush(stdout);
	
	int strtl = 0;
	int endl = 0;
	if (start_limit != NULL)
	{
		strtl = atoi(start_limit);
	}
	if (end_limit != NULL)
	{
		endl = atoi(end_limit);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile1,"TCUA_PlantCS_");
	tc_strcat(RptFile1,"From");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,start_limit);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,"To");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,end_limit);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,GenDate);
	tc_strcat(RptFile1,".csv");
	printf("\n CSV Report File Name: [%s]", RptFile1);fflush(stdout);
	printf("\n CSV Report File Generated..!!");fflush(stdout);
	
	fpOutput_file1 = fopen(RptFile1, "w");
	fprintf(fpOutput_file1,"PART_NO, PART_REV, PART_SEQ, JSR_CS, LKN_CS, DWD_CS, SND_CS, PUN_CS, PNR_CS, PUNPCBU_CS, PUNUV_CS, CAR_CS, AHD_CS, RJV_CS, SGR_CS\n");fflush(fpOutput_file1); 
	int objtyplen = 1;
	int rlztyplen = 3;
	//int ownUsrlen = 1;
	const char* object_type_data[]={"Design Revision"};
	const char* fnd_lat_ERCRlz_lst=NULL;
	//const char* select_attrs[]={"item_id","item_revision_id","creation_date","last_mod_date","puid"};
	const char* select_attrs[]={"puid","item_revision_id"};
	const char *select_attrs_Item[] = { "item_id" };
	//const char* release_status_data[]={"T5_LcsErcRlzd"};
	const char* release_status_data[]={"T5_LcsWorking","T5_LcsReview","T5_LcsErcRlzd"};
	//const char* owning_user_data[]={"loader"};
	int  rows = 0, columns = 0;
	void ***report;
	char *pQry = "fnd_lat_ERCRlz_lst";
	ITK_CALL(POM_enquiry_create(pQry));
	ITK_CALL(POM_enquiry_add_select_attrs (pQry,"ItemRevision",1,select_attrs));
	ITK_CALL(POM_enquiry_add_select_attrs(pQry, "Item", 1,select_attrs_Item));
 
	ITK_CALL(POM_enquiry_set_string_value (pQry,"object_type_expr",objtyplen,object_type_data,POM_enquiry_bind_value));
	ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_object_type_in","ItemRevision","object_type",POM_enquiry_in,"object_type_expr"));
 
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr2","ItemRevision", "release_status_list", POM_enquiry_equal, "ReleaseStatus", "puid"));
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr3","ItemRevision", "owning_user", POM_enquiry_equal, "User", "puid"));
 
	ITK_CALL(POM_enquiry_set_string_value (pQry,"release_stat_expr",rlztyplen,release_status_data,POM_enquiry_bind_value));
	ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_rlz_stat_in","ReleaseStatus","name",POM_enquiry_in,"release_stat_expr"));
 
	//ITK_CALL(POM_enquiry_set_string_value (pQry,"own_user_expr",ownUsrlen,owning_user_data,POM_enquiry_bind_value));
	//ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_own_user_in","User","user_id",POM_enquiry_in,"own_user_expr"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr","join_expr1", POM_enquiry_and, "join_expr2"));
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr1","combine_expr",POM_enquiry_and,"expr_object_type_in"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr2","combine_expr1",POM_enquiry_and,"join_expr3"));
	//ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr3","combine_expr2",POM_enquiry_and,"expr_own_user_in"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"expr_AND_expression","combine_expr2",POM_enquiry_and,"expr_rlz_stat_in"));
	ITK_CALL(POM_enquiry_set_where_expr (pQry,"expr_AND_expression"));
 
	ITK_CALL(POM_enquiry_add_order_attr (pQry, "Item", "item_id", POM_enquiry_asc_order));
 
	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_execute(pQry, &rows, &columns, &report));
	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_delete(pQry));
	printf(" \n Number of Rows [%d] and Number of Coloumns [%d]\n",rows,columns);fflush(stdout);
	//exit(0);
	if (endl > rows)
	{
		endl = rows;
	}
	if(rows > 0 && strtl < rows)
	{
		for(z=strtl;z < endl; z++)
		{
			//iteamrev2 = titemobj_results[z];
			iteamrev2 = *(tag_t*)(report[z][0]);
			ITK_CALL(AOM_ask_value_string(iteamrev2,"item_id",&Part_No));
			if(Part_No!=NULL)
			{
				ITK_CALL(AOM_ask_value_string(iteamrev2,"item_revision_id",&Part_RevSeq));
				if(tc_strlen(Part_RevSeq)>0)
				{
					tc_strdup(Part_RevSeq,&Part_RevSeqDup);
				}
				Part_Rev=strtok(Part_RevSeqDup,";");
				Part_Seq=strtok(NULL,";");
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_JsrMakeBuyIndicator",&JSRCS));
				if(JSRCS!=NULL)
				{
					trimwhitespace(JSRCS);
					STRNG_replace_str(JSRCS,","," ",&JSRCS);
					STRNG_replace_str(JSRCS,";"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"\n"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"'"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"`"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"~"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"@"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"#"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"$"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"|"," ",&JSRCS);
					STRNG_replace_str(JSRCS,"!"," ",&JSRCS);
					tc_strdup(JSRCS,&JSRCSDup);
				}
				else
				{
					tc_strdup("--",&JSRCSDup);
					printf("\n JSR CS Value is NULL..!!\n");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_LkoMakeBuyIndicator",&LKNCS));
				if(LKNCS!=NULL)
				{
					trimwhitespace(LKNCS);
					STRNG_replace_str(LKNCS,","," ",&LKNCS);
					STRNG_replace_str(LKNCS,";"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"\n"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"'"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"`"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"~"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"@"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"#"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"$"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"|"," ",&LKNCS);
					STRNG_replace_str(LKNCS,"!"," ",&LKNCS);
					tc_strdup(LKNCS,&LKNCSDup);
				}
				else
				{
					tc_strdup("--",&LKNCSDup);
					printf("\n LKN CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_DwdMakeBuyIndicator",&DWDCS));
				if(DWDCS!=NULL)
				{
					trimwhitespace(DWDCS);
					STRNG_replace_str(DWDCS,","," ",&DWDCS);
					STRNG_replace_str(DWDCS,";"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"\n"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"'"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"`"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"~"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"@"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"#"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"$"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"|"," ",&DWDCS);
					STRNG_replace_str(DWDCS,"!"," ",&DWDCS);
					tc_strdup(DWDCS,&DWDCSDup);
				}
				else
				{
					tc_strdup("--",&DWDCSDup);
					printf("\n DWD CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_SndMakeBuyIndicator",&SNDCS));
				if(SNDCS!=NULL)
				{
					trimwhitespace(SNDCS);
					STRNG_replace_str(SNDCS,","," ",&SNDCS);
					STRNG_replace_str(SNDCS,";"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"\n"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"'"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"`"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"~"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"@"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"#"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"$"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"|"," ",&SNDCS);
					STRNG_replace_str(SNDCS,"!"," ",&SNDCS);
					tc_strdup(SNDCS,&SNDCSDup);
				}
				else
				{
					tc_strdup("--",&SNDCSDup);
					printf("\n SND CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PunMakeBuyIndicator",&PUNCS));
				if(PUNCS!=NULL)
				{
					trimwhitespace(PUNCS);
					STRNG_replace_str(PUNCS,","," ",&PUNCS);
					STRNG_replace_str(PUNCS,";"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"\n"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"'"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"`"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"~"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"@"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"#"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"$"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"|"," ",&PUNCS);
					STRNG_replace_str(PUNCS,"!"," ",&PUNCS);
					tc_strdup(PUNCS,&PUNCSDup);
				}
				else
				{
					tc_strdup("--",&PUNCSDup);
					printf("\n PUN CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PnrMakeBuyIndicator",&PNRCS));
				if(PNRCS!=NULL)
				{
					trimwhitespace(PNRCS);
					STRNG_replace_str(PNRCS,","," ",&PNRCS);
					STRNG_replace_str(PNRCS,";"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"\n"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"'"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"`"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"~"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"@"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"#"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"$"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"|"," ",&PNRCS);
					STRNG_replace_str(PNRCS,"!"," ",&PNRCS);
					tc_strdup(PNRCS,&PNRCSDup);
				}
				else
				{
					tc_strdup("--",&PNRCSDup);
					printf("\n PNR CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PunPCBUMakeBuyIndicator",&PPCBUCS));
				if(PPCBUCS!=NULL)
				{
					trimwhitespace(PPCBUCS);
					STRNG_replace_str(PPCBUCS,","," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,";"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"\n"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"'"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"`"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"~"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"@"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"#"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"$"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"|"," ",&PPCBUCS);
					STRNG_replace_str(PPCBUCS,"!"," ",&PPCBUCS);
					tc_strdup(PPCBUCS,&PPCBUCSDup);
				}
				else
				{
					tc_strdup("--",&PPCBUCSDup);
					printf("\n PPCB CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PunUVMakeBuyIndicator",&PUVCS));
				if(PUVCS!=NULL)
				{
					trimwhitespace(PUVCS);
					STRNG_replace_str(PUVCS,","," ",&PUVCS);
					STRNG_replace_str(PUVCS,";"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"\n"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"'"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"`"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"~"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"@"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"#"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"$"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"|"," ",&PUVCS);
					STRNG_replace_str(PUVCS,"!"," ",&PUVCS);
					tc_strdup(PUVCS,&PUVCSDup);
				}
				else
				{
					tc_strdup("--",&PUVCSDup);
					printf("\n PUV CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_CarMakeBuyIndicator",&CARCS));
				if(CARCS!=NULL)
				{
					trimwhitespace(CARCS);
					STRNG_replace_str(CARCS,","," ",&CARCS);
					STRNG_replace_str(CARCS,";"," ",&CARCS);
					STRNG_replace_str(CARCS,"\n"," ",&CARCS);
					STRNG_replace_str(CARCS,"'"," ",&CARCS);
					STRNG_replace_str(CARCS,"`"," ",&CARCS);
					STRNG_replace_str(CARCS,"~"," ",&CARCS);
					STRNG_replace_str(CARCS,"@"," ",&CARCS);
					STRNG_replace_str(CARCS,"#"," ",&CARCS);
					STRNG_replace_str(CARCS,"$"," ",&CARCS);
					STRNG_replace_str(CARCS,"|"," ",&CARCS);
					STRNG_replace_str(CARCS,"!"," ",&CARCS);
					tc_strdup(CARCS,&CARCSDup);
				}
				else
				{
					tc_strdup("--",&CARCSDup);
					printf("\n CAR CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_AhdMakeBuyIndicator",&AHDCS));
				if(AHDCS!=NULL)
				{
					trimwhitespace(AHDCS);
					STRNG_replace_str(AHDCS,","," ",&AHDCS);
					STRNG_replace_str(AHDCS,";"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"\n"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"'"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"`"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"~"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"@"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"#"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"$"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"|"," ",&AHDCS);
					STRNG_replace_str(AHDCS,"!"," ",&AHDCS);
					tc_strdup(AHDCS,&AHDCSDup);
				}
				else
				{
					tc_strdup("--",&AHDCSDup);
					printf("\n AHD CS Value is NULL..!!\n");fflush(stdout);
				}
			    ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_RjvMakebuyInd",&RJVCS));
				if(RJVCS!=NULL)
				{
					trimwhitespace(RJVCS);
					STRNG_replace_str(RJVCS,","," ",&RJVCS);
					STRNG_replace_str(RJVCS,";"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"\n"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"'"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"`"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"~"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"@"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"#"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"$"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"|"," ",&RJVCS);
					STRNG_replace_str(RJVCS,"!"," ",&RJVCS);
					tc_strdup(RJVCS,&RJVCSDup);
				}
				else
				{
					tc_strdup("--",&RJVCSDup);
					printf("\n RJV CS Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_SgrMakeBuyIndicator",&SGRCS));
				if(SGRCS!=NULL)
				{
					trimwhitespace(SGRCS);
					STRNG_replace_str(SGRCS,","," ",&SGRCS);
					STRNG_replace_str(SGRCS,";"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"\n"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"'"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"`"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"~"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"@"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"#"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"$"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"|"," ",&SGRCS);
					STRNG_replace_str(SGRCS,"!"," ",&SGRCS);
					tc_strdup(SGRCS,&SGRCSDup);
				}
				else
				{
					tc_strdup("--",&SGRCSDup);
					printf("\n SGR CS Value is NULL..!!\n");fflush(stdout);
				}
				
				printf(" Part Details Start...!!\n");fflush(stdout);
				printf("[1] Part_No: [%s]\n",Part_No);fflush(stdout);
				printf("[2] Part_Rev: [%s]\n",Part_Rev);fflush(stdout);
				printf("[3] Part_Seq: [%s]\n",Part_Seq);fflush(stdout);
				printf("[4] JSR CS: [%s]\n",JSRCSDup);fflush(stdout);
				printf("[5] LKN CS: [%s]\n",LKNCSDup);fflush(stdout);
				printf("[6] DWD CS: [%s]\n",DWDCSDup);fflush(stdout);
				printf("[7] SND CS: [%s]\n",SNDCSDup);fflush(stdout);
				printf("[8] PUN CS: [%s]\n",PUNCSDup);fflush(stdout);
				printf("[9] PNR CS: [%s]\n",PNRCSDup);fflush(stdout);
				printf("[10] PPCBU CS: [%s]\n",PPCBUCSDup);fflush(stdout);
				printf("[11] PUV CS: [%s]\n",PUVCSDup);fflush(stdout);
				printf("[12] CAR CS: [%s]\n",CARCSDup);fflush(stdout);
				printf("[13] AHD CS: [%s]\n",AHDCSDup);fflush(stdout);
				printf("[14] RJV CS: [%s]\n",RJVCSDup);fflush(stdout);
				printf("[15] SGR CS: [%s]\n",SGRCSDup);fflush(stdout);
				printf(" Part Details End...!!\n");fflush(stdout);
		
				fprintf(fpOutput_file1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",Part_No,Part_Rev,Part_Seq,JSRCSDup,LKNCSDup,DWDCSDup,SNDCSDup,PUNCSDup,PNRCSDup,PPCBUCSDup,PUVCSDup,CARCSDup,AHDCSDup,RJVCSDup,SGRCSDup);fflush(fpOutput_file1);
				
            }
            else
            {
				printf("\n Part Number is NULL..!!");fflush(stdout);
			}				
		}
	}
	fprintf(fpOutput_file1,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file1);
	fclose(fpOutput_file1);
	printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PlantCS.c
* // ./linkitk -o tm_PlantCS tm_PlantCS.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AllPlantCSCheck/tm_PlantCS .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AllPlantCSCheck/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AllPlantCSCheck/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AllPlantCSCheck/SendEmail.sh .
* // ./tm_PlantCS -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -s=0 -e=100000
* // ./tm_PlantCS -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -s=0 -e=100000
*
***************************************************************************/