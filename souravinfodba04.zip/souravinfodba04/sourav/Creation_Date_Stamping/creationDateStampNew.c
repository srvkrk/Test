/*************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*
* Modification History :
* S.No      Date			CR No      Modified By				Modification Notes
*  1     14-Jan-2019			  			         Creation Date Stamping on Master and Revision.
**************************************************************************************************************/

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tc/tc_startup.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <fclasses/tc_date.h>
#include <ae/dataset.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>
#include <ae/dataset.h>
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


int update_release_date(tag_t, date_t);
int update_creation_date(tag_t, date_t);

char* MonthAbbreviation (char* MonthNo)
{
	char *ResponseMonth = (char *) malloc(400*sizeof(char));
	printf("\n Input Month No in String: --------> [%s]\n", MonthNo);fflush(stdout);
	int monno = atoi(MonthNo);
	printf("\n Input Month No in Integer: --------> [%d]\n", monno);fflush(stdout);
	switch(monno)
   {
	case 1:
	       tc_strcpy(ResponseMonth,"Jan");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 2:
	       tc_strcpy(ResponseMonth,"Feb");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 3:
	       tc_strcpy(ResponseMonth,"Mar");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 4:
	       tc_strcpy(ResponseMonth,"Apr");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 5:
	       tc_strcpy(ResponseMonth,"May");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 6:
	       tc_strcpy(ResponseMonth,"Jun");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 7:
	       tc_strcpy(ResponseMonth,"Jul");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 8:
	       tc_strcpy(ResponseMonth,"Aug");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 9:
	       tc_strcpy(ResponseMonth,"Sep");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 10:
	       tc_strcpy(ResponseMonth,"Oct");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 11:
	       tc_strcpy(ResponseMonth,"Nov");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 12:
	       tc_strcpy(ResponseMonth,"Dec");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	default:
	       printf("Invalid Number");
	       break;
      }
	  
	  return ResponseMonth;
}

char* DateFormatConstruct (char* InputDt)
{
	char* FormatDtRlzd = (char *) malloc(400*sizeof(char));
	char* RespMonth = NULL;
	char* InpYear = NULL;
	char* InpMonth = NULL;
	char* InpRemainDay = NULL;
	char* InpSeperate = NULL;
	char* InpHour = NULL;
	char* InpMin = NULL;
	char* InpSec = NULL;
	char* InpRemainMinHour = NULL;
	char* InpDay = NULL;
	
	InpYear=strtok(InputDt,"/");
	InpMonth=strtok(NULL,"/");
	InpRemainDay=strtok(NULL,"/");
	printf("\n Input Year: [%s]\n", InpYear);fflush(stdout);
	printf("\n Input Month: [%s]\n", InpMonth);fflush(stdout);
	printf("\n Input Remain Day: [%s]\n", InpRemainDay);fflush(stdout);
												
	InpDay=strtok(InpRemainDay,"-");
	InpRemainMinHour=strtok(NULL,"-");
	printf("\n Input Day: [%s]\n", InpDay);fflush(stdout);
	printf("\n Input Remain Minute & Hour: [%s]\n", InpRemainMinHour);fflush(stdout);
												
	InpHour=strtok(InpRemainMinHour,":");
	InpMin=strtok(NULL,":");
	InpSec=strtok(NULL,":");
												
	printf("\n Input Hour: [%s]\n", InpHour);fflush(stdout);
	printf("\n Input Minute: [%s]\n", InpMin);fflush(stdout);
	printf("\n Input Second: [%s]\n", InpSec);fflush(stdout);
												
	RespMonth = MonthAbbreviation(InpMonth);
	printf("\n Input Month Abbreviated Form: [%s]\n", RespMonth);fflush(stdout);
												
	tc_strcpy(FormatDtRlzd,InpDay);
	tc_strcat(FormatDtRlzd,"-");
	tc_strcat(FormatDtRlzd,RespMonth);
	tc_strcat(FormatDtRlzd,"-");
    tc_strcat(FormatDtRlzd,InpYear);
	tc_strcat(FormatDtRlzd," ");
    tc_strcat(FormatDtRlzd,InpHour);
    tc_strcat(FormatDtRlzd,":");
    tc_strcat(FormatDtRlzd,InpMin);
    printf("\n Formatted Date Released: [%s]\n", FormatDtRlzd);fflush(stdout);
	  
	return FormatDtRlzd;
}

int ITK_user_main (int argc, char *argv[])
{
    int				ifail						= 0;
    int				sec_count					= 0;
    int				sec_rev_count				= 0;
	
	char			inputline[1000];
	char			*inputfile					= NULL;
	char			*date						= NULL;
	char			*itemId						= NULL;
	char			*revId						= NULL;
	char			*seqId						= NULL;
	char			*VaultStr					= NULL;
	char			*CreDateStr				    = NULL;
	char			*lastUpdateStr				= NULL;

	tag_t			itemTag						= NULLTAG;
	tag_t			revTag						= NULLTAG;
	tag_t			relation_master				= NULLTAG;
	tag_t			relation_rev				= NULLTAG;
	tag_t			*sec_tag					= NULL;
	tag_t			*sec_form					= NULL;
    char			*creation_date				= NULL;

	date_t			date_created;
	date_t			date_rlzd;
	FILE			*file_p						= NULL;
	
	char* Part_No = NULL;
	char* Part_RevSeq = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char* FormatCreateDate = NULL;
	char* FormatLastUpdDate = NULL;
	tag_t attr_id=NULLTAG;
	tag_t Stat_tag = NULLTAG;

	inputfile = ITK_ask_cli_argument("-i=");
	date = ITK_ask_cli_argument("-date=");
    
    ifail = ITK_auto_login( );
	ifail = ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	printf("\nLogin to Teamcenter...!!");fflush(stdout);
    ifail = ITK_set_journalling(TRUE);
	
	printf("\nLOGIN SUCCESSFUlL");fflush(stdout);
	
	file_p = fopen(inputfile,"r");
	printf("\n Input_File Name: [%s]\n",inputfile);fflush(stdout);

	if(file_p != NULL)
	{		
		printf("\n Part List is Not Null Moving Forward..!!\n");fflush(stdout);
		while(fgets(inputline, 1000, file_p) != NULL)
		{
			fputs(inputline,stdout);
			
			//282972208201^D;1^Release Vault^2006/03/26-09:37:25:305^2021/07/05-07:16:36:574
			
			itemId = tc_strtok(inputline,"^");
			printf("\n----| Item id: [%s]",itemId);fflush(stdout);

			revId = tc_strtok(NULL,"^");
			printf("\n----| Rev-Seq id: [%s]",revId);fflush(stdout);			
			
			VaultStr = tc_strtok(NULL,"^");
			printf("\n----| Vault is: [%s]",VaultStr);fflush(stdout);
			
			CreDateStr = tc_strtok(NULL,"^");
			printf("\n----| Creation Date is: [%s]",CreDateStr);fflush(stdout);
			
			lastUpdateStr = tc_strtok(NULL,"^");
			printf("\n----| Last Update is: [%s]",lastUpdateStr);fflush(stdout);
			
			FormatCreateDate = DateFormatConstruct(CreDateStr);
			FormatLastUpdDate = DateFormatConstruct(lastUpdateStr);
			printf("\n Formatted Date (CreDateStr): [%s]\n", FormatCreateDate);fflush(stdout);
			printf("\n Formatted Date (lastUpdateStr): [%s]\n", FormatLastUpdDate);fflush(stdout);
			
			ITK_CALL(ITK_string_to_date(FormatCreateDate,&date_created));
			ITK_CALL(ITK_string_to_date(FormatLastUpdDate,&date_rlzd));

			ifail = ITEM_find_item(itemId, &itemTag);
			if(itemTag != NULLTAG)
			{
				printf("\n Part Found is: [%s]", itemId);fflush(stdout);
				ifail = update_creation_date(itemTag, date_created);
				printf("\n [1]: Input Part No(itemId): [%s]\n",itemId);fflush(stdout);
	            printf("\n [2]: Input Part Rev-Seq(revId): [%s]\n",revId);fflush(stdout);
				
				ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
				if(tItemobj != NULLTAG)
				{
					printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
					char *cEntries[2]  = {"Revision","ID"};
					char *cValues[2]  = {revId,itemId};
					//char *cValues[2]  = {"A;2","51780353R"};
					ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
					printf("\n -----------------------------------------------\n");fflush(stdout);
					printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
					printf("\n -----------------------------------------------\n");fflush(stdout);
					if(n_itemobj_found > 0)
					{
						revTag = titemobj_results[0];
						int  status_count = 0;
						tag_t* relStatus_list = NULLTAG;
						char* latest_rev_Rel_Status = NULL;
						char* latest_rev_Rel_StatusDup = NULL;
						char* Aldt_rlzd = NULL;
						printf(" Design Revision & Sequence Found..!!\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_string(titemobj_results[0],"item_id",&Part_No));
						printf(" Found Part-No: [%s]\n",Part_No);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(titemobj_results[0],"current_revision_id",&Part_RevSeq));
						printf(" Found Part-Rev-Seq: [%s]\n",Part_RevSeq);fflush(stdout);
						printf("\n Function[update_creation_date] Call Start..!!");fflush(stdout);
						ifail = update_creation_date(revTag, date_created);
						printf("\n Function[update_creation_date] Call End..!!");fflush(stdout);
						if(tc_strcmp(VaultStr,"Release Vault") == 0)
						{
							WSOM_ask_release_status_list(revTag, &status_count, &relStatus_list);
							printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
							if(status_count>0)
							{
								int k = 0;
								for(k = 0; k<status_count; k++)
								{
									AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_StatusDup);
									printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
                                    if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0))
									{
										ITK_CALL(AOM_UIF_ask_value(relStatus_list[k],"date_released",&Aldt_rlzd));
										printf(" \n Release Status Date Released String: ------> <%s>\n",Aldt_rlzd);fflush(stdout);
										Stat_tag = relStatus_list[k];
										printf("\n Function[update_release_date - Release Vault] Call Start..!!");fflush(stdout);
										ifail = update_release_date(Stat_tag, date_rlzd);
							            printf("\n Function[update_release_date - Release Vault] Call End..!!");fflush(stdout);
										//goto CLEANUP;
										break;
									}
									else
									{
										continue;
									}
								}
                            }
							else
							{
								printf("\nSorry! ERC Release Status Not Found on Selected Revision...");fflush(stdout);
							}
						}
						else
						{
							WSOM_ask_release_status_list(revTag, &status_count, &relStatus_list);
							printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
							if(status_count>0)
							{
								int k = 0;
								for(k = 0; k<status_count; k++)
								{
									AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_StatusDup);
									printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
                                    if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsReview") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcReview") == 0))
									{
										ITK_CALL(AOM_UIF_ask_value(relStatus_list[k],"date_released",&Aldt_rlzd));
										printf(" \n Release Status Date Released String: ------> <%s>\n",Aldt_rlzd);fflush(stdout);
										Stat_tag = relStatus_list[k];
										printf("\n Function[update_release_date - WIP/CE Vault] Call Start..!!");fflush(stdout);
							            ifail = update_release_date(Stat_tag, date_created);
							            printf("\n Function[update_release_date - WIP/CE Vault] Call End..!!");fflush(stdout);
										break;
									}
									else
									{
										continue;
									}
								}
                            }
						}
					}
					else
					{
						printf("\n Design Revision Not Found..!!");fflush(stdout);
					}
				}
				else
				{
					printf("\n DesignRevision Sequence Query Tag Not Found..!!");fflush(stdout);
				}
			}
			else
			{
				printf("\n Item-Master Not Found For Item-ID:[%s] Item-RevSeq:[%s] Vault:[%s] Creation-Date:[%s]\n",itemId,revId,VaultStr,CreDateStr);
				printf("\n Continuing For Next Item..!!\n");
			}
			printf("\n");
		}
	}
	
	
    CLEANUP:
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	ITK_CALL(ITK_exit_module(TRUE));	
	return ifail;
}

int update_release_date(tag_t obj_tag, date_t date_rel)
{
	printf("\n Function(update_release_date) Start..!!\n");
	int	ifail = ITK_ok;
	tag_t attr_id1=NULLTAG;
	
	printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 	
	ITK_CALL(AOM_refresh(obj_tag, POM_modify_lock));
	printf("\n Lock..!!\n");fflush(stdout);
	ITK_CALL(POM_attr_id_of_attr("date_released", "ReleaseStatus", &attr_id1));
	printf("\n Attr_Id:  [%d]",attr_id1);fflush(stdout);  
	printf("\n Property Name Tag Found..!!\n");fflush(stdout); 
	ITK_CALL(POM_set_attr_date(1, &obj_tag, attr_id1, date_rel));
	printf("\n Set Property Value..!!\n");fflush(stdout);  
	ITK_CALL(POM_save_instances(1, &obj_tag, true));
	printf("\n Save...!!\n");fflush(stdout);
	ITK_CALL(AOM_refresh(obj_tag, POM_no_lock));
	printf("\n Unlock..!!\n");fflush(stdout);												
	printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
	
	if(ifail == ITK_ok)
	{
		printf("\n Date Release Updated.....!!");fflush(stdout);
	}
    printf("\n Function(update_release_date) End..!!\n");

	return ifail;
}

int update_creation_date(tag_t obj_tag, date_t date_created)
{
	printf("\n Function[update_creation_date] Start..!!");fflush(stdout);
	int	ifail = ITK_ok;
	tag_t attr_id1=NULLTAG;
	
	printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);  
	ITK_CALL(AOM_refresh(obj_tag, POM_modify_lock));
	printf("\n Lock..!!\n");fflush(stdout);  
	POM_set_creation_date(obj_tag, date_created);
	printf("\n Set Property Value..!!\n");fflush(stdout);  
	ITK_CALL(POM_save_instances(1, &obj_tag, true));
	printf("\n Save...!!\n");fflush(stdout);  
	ITK_CALL(AOM_refresh(obj_tag, POM_no_lock));
    printf("\n Unlock..!!\n");fflush(stdout);
	printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
	
	if(ifail == ITK_ok)
	{
		printf("\n CreationDate Updated.....!!");fflush(stdout);
	}
    printf("\n Function[update_creation_date] End..!!");fflush(stdout);

	return ifail;
}


/***************************************************************************
*
* // ./compile creationDateStampNew.c
* // ./linkitk -o creationDateStampNew creationDateStampNew.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Creation_Date_Stamping/creationDateStampNew .
*
***************************************************************************/