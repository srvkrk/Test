/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Read Module Property Details From File & Update it. 
*  File Name    :   tm_moduleinfoupload.c
*  Created on   :   Sept 26nd, 2023
*  Usage        :   tm_moduleinfoupload
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     26/09/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int Module_Info_Update(char* ModNum,char* ModRev,char* ModSeq,char* ModPType,char* ModPlatform,char* ModAggrGrp,char* ModAggr,char* ModGrp,char* ModSubModule,char* ModSubModuleAdd,char* ModSubModuleDesGrp,char* ModProject,char* ModDesGrp,char* ModName,char* Module)
{
	
	int iFail = 0;
	tag_t tQryobj = NULLTAG;
	int n_entries = 2;
	int n_Qryobj_found = 0;
	tag_t* tQryobj_results = NULLTAG;
	char* RevSeqString = NULL;
	RevSeqString=(char *)MEM_alloc(200);
	tc_strcpy(RevSeqString,ModRev);
	tc_strcat(RevSeqString,";");
	tc_strcat(RevSeqString,ModSeq);
	printf(" Module Rev-Seq[After Concat]:  [%s]\n", RevSeqString);fflush(stdout);
	
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tQryobj));
    if(tQryobj!=NULLTAG)
	{
		printf(" DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","ID"};
		char *cValues[2]  = {RevSeqString,ModNum};
		ITK_CALL(QRY_execute(tQryobj, n_entries, cEntries, cValues, &n_Qryobj_found, &tQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);		
		if(n_Qryobj_found > 0)
		{
			tag_t rev_tags_found = NULLTAG;
	        char* ModuleRevisionSequence = NULL;
	        char* ModuleNumber = NULL;
	        char* Module_Rev = NULL;
	        char* Module_Seq = NULL;
			
			rev_tags_found = tQryobj_results[0];
			if(rev_tags_found != NULLTAG)
			{	
		
		        ITK_CALL(AOM_ask_value_string(rev_tags_found,"item_revision_id",&ModuleRevisionSequence));
				ITK_CALL(AOM_ask_value_string(rev_tags_found,"item_id",&ModuleNumber));
                Module_Rev = tc_strtok(ModuleRevisionSequence,";");
				Module_Seq = tc_strtok(NULL,";");
				printf(" Found Module_No: [%s]\n",ModuleNumber);fflush(stdout);
				printf(" Found Module_Rev: [%s]\n",Module_Rev);fflush(stdout);
				printf(" Found Module_Seq: [%s]\n",Module_Seq);fflush(stdout);
				
				if(tc_strcmp(ModNum,ModuleNumber)==0 && tc_strcmp(ModRev,Module_Rev)==0 && tc_strcmp(ModSeq,Module_Seq)==0)
				{
					printf(" ########### U P D A T I O N    S T A R T ###########\n");fflush(stdout);
					ITK_CALL(AOM_refresh(rev_tags_found,POM_modify_lock));
					if(ModProject!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_ProjectCode",ModProject));  //Project_Code
					if(ModDesGrp!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_DesignGrp",ModDesGrp)); //Design_Group 
					if(ModPType!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_PartType",ModPType)); //Part_Type
					if(ModAggr!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_Aggregate",ModAggr)); //Aggregate
				    if(ModAggrGrp!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_AggregateGroup",ModAggrGrp)); //Aggregate_Group 
					if(Module!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_Module",Module)); //Module
					if(ModGrp!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_Module_Group",ModGrp)); //Module_Group 
					if(ModSubModuleAdd!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_ModuleAddress",ModSubModuleAdd)); //Module_Address 
					if(ModName!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_ModuleName",ModName)); //Module_Name 
					if(ModName!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_CategoryName ",ModName)); //Keyword_Description  
					if(ModPlatform!=NULL)ITK_CALL(AOM_set_value_string(rev_tags_found,"t5_Platform",ModPlatform)); //Platform
				    ITK_CALL(AOM_save(rev_tags_found));
				    ITK_CALL(AOM_refresh(rev_tags_found,POM_no_lock));
					printf(" ########### U P D A T I O N    E N D ###########\n");fflush(stdout);
				}
				else
			    {
			       printf(" Module Number & Rev & Seq Not Matched..!!\n");fflush(stdout);
			    }							
			}
			else
			{
			    printf(" Revision Tag Not Found..!!\n");fflush(stdout);
			}
		}
		else
		{
			printf(" Module Query Result Not Found..!!\n");fflush(stdout);
		}
		
	}
	else
	{
		printf(" DesignRevision Sequence Query Tag Not Found..!!");fflush(stdout);
	}
	if (tQryobj_results)
    {
		MEM_free(tQryobj_results);
	}
	
    return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
    char *Filename			= NULL;
	char *FileLoc			= NULL;
	char *dataSetName 		= NULL;
	IMF_file_t	fileDescriptor;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	tag_t tUser = NULLTAG;
	tag_t tHomeFolder = NULLTAG;
	
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char* Module_Number = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d-%b-%Y-%H-%M-%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
    fpPart_List = fopen("ModuleInfoDownloadRpt.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			Module_Number=strtok(Buffer,"~");
			Module_Revision=strtok(NULL,"~");
			Module_Seqence=strtok(NULL,"~");
			Module_PartType=strtok(NULL,"~");
			Module_Plateform=strtok(NULL,"~");
			Module_AggregateGroup=strtok(NULL,"~");
			Module_Aggregates=strtok(NULL,"~");
			Module_ModuleName=strtok(NULL,"~");
			Module_SubModule=strtok(NULL,"~");
			Module_SubModuleAdress=strtok(NULL,"~");
			Module_SubModuleDesignGrp=strtok(NULL,"~");
			Module_ProjectCode=strtok(NULL,"~");
			Module_DesignGrp=strtok(NULL,"~");
			
			if(Module_Number!=NULL)tc_strdup(Module_Number,&Module_NumberDup);
			if(Module_Revision!=NULL)tc_strdup(Module_Revision,&Module_RevisionDup);
			if(Module_Seqence!=NULL)tc_strdup(Module_Seqence,&Module_SeqenceDup);
			if(Module_PartType!=NULL)tc_strdup(Module_PartType,&Module_PartTypeDup);
			if(Module_Plateform!=NULL)tc_strdup(Module_Plateform,&Module_PlateformDup);
			if(Module_AggregateGroup!=NULL)tc_strdup(Module_AggregateGroup,&Module_AggregateGroupDup);
			if(Module_Aggregates!=NULL)tc_strdup(Module_Aggregates,&Module_AggregatesDup);
			if(Module_ModuleName!=NULL)tc_strdup(Module_ModuleName,&Module_ModuleNameDup);
			if(Module_SubModule!=NULL)tc_strdup(Module_SubModule,&Module_SubModuleDup);
			if(Module_SubModuleAdress!=NULL)tc_strdup(Module_SubModuleAdress,&Module_SubModuleAdressDup);
			if(Module_SubModuleDesignGrp!=NULL)tc_strdup(Module_SubModuleDesignGrp,&Module_SubModuleDesignGrpDup);
			if(Module_ProjectCode!=NULL)tc_strdup(Module_ProjectCode,&Module_ProjectCodeDup);
			if(Module_DesignGrp!=NULL)tc_strdup(Module_DesignGrp,&Module_DesignGrpDup);
			
			printf(" Module_Number(Module_NumberDup): [%s]\n",Module_NumberDup);
			printf(" Revision(Module_RevisionDup): [%s]\n",Module_RevisionDup);
			printf(" Sequence(Module_SeqenceDup): [%s]\n",Module_SeqenceDup);
			printf(" Part_Type(Module_PartTypeDup): [%s]\n",Module_PartTypeDup);
			printf(" Platform(Module_PlateformDup): [%s]\n",Module_PlateformDup);
			printf(" Aggregate_Group(Module_AggregateGroupDup): [%s]\n",Module_AggregateGroupDup);
			printf(" Aggregates(Module_AggregatesDup): [%s]\n",Module_AggregatesDup);
			printf(" Module_Name(Module_ModuleNameDup): [%s]\n",Module_ModuleNameDup);
			printf(" SubModule(Module_SubModuleDup): [%s]\n",Module_SubModuleDup);
			printf(" SubModuleAddress(Module_SubModuleAdressDup): [%s]\n",Module_SubModuleAdressDup);
			printf(" SubModuleDesignGroup(Module_SubModuleDesignGrpDup): [%s]\n",Module_SubModuleDesignGrpDup);
			printf(" Project_Code(Module_ProjectCodeDup): [%s]\n",Module_ProjectCodeDup);
			printf(" Design_Group(Module_DesignGrpDup): [%s]\n",Module_DesignGrpDup);
			
			char *Module = NULL;
			char *Module_Name = NULL;
			Module = (char *)MEM_alloc(50);
			tc_strcpy(Module,Module_SubModuleDup);

			Module_Name = subString(Module_SubModuleDup,3,(tc_strlen(Module_SubModuleDup)-1));
			//Module_Name = tc_strtok(Module_SubModuleDup,"-");
			//Module_Name = tc_strtok(NULL,"-");
			printf(" Module_Name: [%s]",Module_Name);fflush(stdout);
			printf(" Module: [%s]",Module);fflush(stdout);
			
			printf("\n Function: Module Info Update Start");fflush(stdout);
			Module_Info_Update(Module_NumberDup,Module_RevisionDup,Module_SeqenceDup,Module_PartTypeDup,Module_PlateformDup,Module_AggregateGroupDup,Module_AggregatesDup,Module_ModuleNameDup,Module_SubModuleDup,Module_SubModuleAdressDup,Module_SubModuleDesignGrpDup,Module_ProjectCodeDup,Module_DesignGrpDup,Module_Name,Module);
			printf("\n Function: Module Info Update End");fflush(stdout);
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_moduleinfoupload.c
* // ./linkitk -o tm_moduleinfoupload tm_moduleinfoupload.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Create_Dataset_Home_Folder/tm_moduleinfoupload .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Create_Dataset_Home_Folder/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Create_Dataset_Home_Folder/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Create_Dataset_Home_Folder/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Create_Dataset_Home_Folder/SendEmail.sh .
* // tm_moduleinfoupload -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_moduleinfoupload -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_moduleinfoupload -u=loader -p=loader123 -g=dba
*
***************************************************************************/