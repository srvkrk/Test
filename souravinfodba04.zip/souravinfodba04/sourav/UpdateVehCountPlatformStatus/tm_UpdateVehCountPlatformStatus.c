/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Update SubModule Vehicle Count and Platform Status After Reading Data From Input File 
*  File Name    :   tm_UpdateVehCountPlatformStatus.c
*  Created on   :   July 18th, 2024
*  Usage        :   tm_UpdateVehCountPlatformStatus
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     18/07/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* SubModAddr_Str = NULL;
	char* SubModNo_Str = NULL;
	char* SubModRev_Str = NULL;
	char* SubModSeq_Str = NULL;
	char* SubModProdline_Str = NULL;
	/* char* SubModDesc_Str = NULL;
	char* SubModProdline_Str = NULL;
	char* SubModPlat_Str = NULL;
	char* SubModProjcode_Str = NULL;
	char* SubModdrar_Str = NULL; */
	char* SubModVehLinkStatus_Str = NULL;
	char* SubModVCountinf1_Str = NULL;
	char* SubModPlatinf2_Str = NULL;
	char* SubModAddr_StrDup = NULL;
	char* SubModNo_StrDup = NULL;
	char* SubModRev_StrDup = NULL;
	char* SubModSeq_StrDup = NULL;
	char* SubModProdline_StrDup = NULL;
	/* char* SubModDesc_StrDup = NULL;
	char* SubModProdline_StrDup = NULL;
	char* SubModPlat_StrDup = NULL;
	char* SubModProjcode_StrDup = NULL;
	char* SubModdrar_StrDup = NULL; */
	char* SubModVehLinkStatus_StrDup = NULL;
	char* SubModVCountinf1_StrDup = NULL;	
	char* SubModPlatinf2_StrDup = NULL;
	
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	tag_t ttablerow_rev = NULLTAG;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("InputList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{			
	
			SubModAddr_Str=strtok(Buffer,"^");
			SubModNo_Str=strtok(NULL,"^");
			SubModRev_Str=strtok(NULL,"^");
			SubModSeq_Str=strtok(NULL,"^");
			/* SubModDesc_Str=strtok(NULL,"^");
			SubModProdline_Str=strtok(NULL,"^");
			SubModPlat_Str=strtok(NULL,"^");
			SubModProjcode_Str=strtok(NULL,"^");
			SubModdrar_Str=strtok(NULL,"^"); */
			SubModVehLinkStatus_Str=strtok(NULL,"^");
			SubModVCountinf1_Str=strtok(NULL,"^");
			SubModPlatinf2_Str=strtok(NULL,"^");
			SubModProdline_Str=strtok(NULL,"^");
			
            if(SubModAddr_Str!=NULL)tc_strdup(SubModAddr_Str,&SubModAddr_StrDup);
            if(SubModNo_Str!=NULL)tc_strdup(SubModNo_Str,&SubModNo_StrDup);
            if(SubModRev_Str!=NULL)tc_strdup(SubModRev_Str,&SubModRev_StrDup);
            if(SubModSeq_Str!=NULL)tc_strdup(SubModSeq_Str,&SubModSeq_StrDup);
			/* if(SubModDesc_Str!=NULL)tc_strdup(SubModDesc_Str,&SubModDesc_StrDup);
            if(SubModProdline_Str!=NULL)tc_strdup(SubModProdline_Str,&SubModProdline_StrDup);
			if(SubModPlat_Str!=NULL)tc_strdup(SubModPlat_Str,&SubModPlat_StrDup);
			if(SubModProjcode_Str!=NULL)tc_strdup(SubModProjcode_Str,&SubModProjcode_StrDup);
			if(SubModdrar_Str!=NULL)tc_strdup(SubModdrar_Str,&SubModdrar_StrDup); */
			if(SubModVehLinkStatus_Str!=NULL)tc_strdup(SubModVehLinkStatus_Str,&SubModVehLinkStatus_StrDup);
			if(SubModVCountinf1_Str!=NULL)tc_strdup(SubModVCountinf1_Str,&SubModVCountinf1_StrDup);
			if(SubModPlatinf2_Str!=NULL)tc_strdup(SubModPlatinf2_Str,&SubModPlatinf2_StrDup);
			if(SubModProdline_Str!=NULL)tc_strdup(SubModProdline_Str,&SubModProdline_StrDup);
			
			if(SubModAddr_StrDup!=NULL)trimwhitespace(SubModAddr_StrDup);
			if(SubModNo_StrDup!=NULL)trimwhitespace(SubModNo_StrDup);
			if(SubModRev_StrDup!=NULL)trimwhitespace(SubModRev_StrDup);
			if(SubModSeq_StrDup!=NULL)trimwhitespace(SubModSeq_StrDup);
			/* if(SubModDesc_StrDup!=NULL)trimwhitespace(SubModDesc_StrDup);
			if(SubModProjcode_StrDup!=NULL)trimwhitespace(SubModProjcode_StrDup);
			if(SubModdrar_StrDup!=NULL)trimwhitespace(SubModdrar_StrDup); */
			
			printf(" Address(SubModAddr_StrDup): [%s]\n",SubModAddr_StrDup);
			printf(" No(SubModNo_StrDup): [%s]\n",SubModNo_StrDup);
			printf(" Rev(SubModRev_StrDup): [%s]\n",SubModRev_StrDup);
			printf(" Seq(SubModSeq_StrDup): [%s]\n",SubModSeq_StrDup);
			/* printf(" Description(SubModDesc_StrDup): [%s]\n",SubModDesc_StrDup);
			printf(" Product Line(SubModProdline_StrDup): [%s]\n",SubModProdline_StrDup);
			printf(" Platform(SubModPlat_StrDup): [%s]\n",SubModPlat_StrDup);
			printf(" Project_Code(SubModProjcode_StrDup): [%s]\n",SubModProjcode_StrDup);
			printf(" AR/DR(SubModdrar_StrDup): [%s]\n",SubModdrar_StrDup); */
			printf(" Vehicle-Link Status(SubModVehLinkStatus_StrDup): [%s]\n",SubModVehLinkStatus_StrDup);
			printf(" Vehicle-Link Count(SubModVCountinf1_StrDup): [%s]\n",SubModVCountinf1_StrDup);
			printf(" Vehicle-Map Platform(SubModPlatinf2_StrDup): [%s]\n",SubModPlatinf2_StrDup);
			printf(" Product Line(SubModProdline_StrDup): [%s]\n",SubModProdline_StrDup);

			ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"ID"};
				char *cValues[1]  = {SubModAddr_StrDup};
				//char *cValues[1]  = {"A1A01"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
				    printf(" SubModule Address revision Exist So Continue For Table Data Updation..!!\n");fflush(stdout);
				    tsubmodlib_rev = titemobj_results[0];
					ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
					printf("\n No of Table Row [%d]  For SubModule Address  [%s]\n", n_valid_rows, SubModAddr_StrDup);fflush(stdout);
					if(n_valid_rows>0)
					{
						for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
						{
							ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
							ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
							ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
							printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
							printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
							printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
							if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
							//if((tc_strcmp(SubModNo_StrDup,Tbl_SubModNo)==0) && (tc_strcmp(SubModRev_StrDup,Tbl_SubModRev)==0) && (tc_strcmp(SubModSeq_StrDup,Tbl_SubModSeq)==0))
							if(tc_strcmp(SubModNo_StrDup,Tbl_SubModNo)==0)
							{
								printf("\n Input SubModule No And Table SubModule No Matched So Update..!!\n");fflush(stdout);
								printf("\n Update Start..!!\n");fflush(stdout);
								ttablerow_rev = valid_rowsTag[iValCnt];
								ITK_CALL(AOM_lock(ttablerow_rev));
								/* ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_rev",SubModRev_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_seq",SubModSeq_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_desc",SubModDesc_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_productline",SubModProdline_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_Platform",SubModPlat_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_projectcode",SubModProjcode_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",SubModdrar_StrDup)); */
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_productline",SubModProdline_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_VehLink",SubModVehLinkStatus_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_info1",SubModVCountinf1_StrDup));
								ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_info2",SubModPlatinf2_StrDup));
								ITK_CALL(AOM_save_with_extensions(valid_rowsTag[iValCnt]));
								ITK_CALL(AOM_save(ttablerow_rev));
								ITK_CALL(AOM_unlock(ttablerow_rev));
								printf("\n Update End..!!\n");fflush(stdout);
							}
							else
							{
							    printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
					    printf("\n No Table Row Found For Input SubModule Address: [%s], SubModAddr_StrDup\n");fflush(stdout);
					}    
				}
                else
                {
				   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
				}					
			}
		    else
			{
				printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
			}
			if(titemobj_results)
			{
			   MEM_free(titemobj_results);
			} 
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_UpdateVehCountPlatformStatus.c
* // ./linkitk -o tm_UpdateVehCountPlatformStatus tm_UpdateVehCountPlatformStatus.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdateVehCountPlatformStatus/tm_UpdateVehCountPlatformStatus .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdateVehCountPlatformStatus/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdateVehCountPlatformStatus/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdateVehCountPlatformStatus/usage.txt .
* // ./tm_UpdateVehCountPlatformStatus -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_UpdateVehCountPlatformStatus -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/