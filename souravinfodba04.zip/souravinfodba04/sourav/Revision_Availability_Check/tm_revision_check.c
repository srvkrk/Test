/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Check Design Revision's Availability  
*  File Name    :   tm_revision_check.c
*  Created on   :   Oct 04th, 2023
*  Usage        :   tm_revision_check
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     04/10/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t titem = NULLTAG;
	tag_t tlatestitem_rev = NULLTAG;
	char* ResponseString = NULL;
	ResponseString =(char *)MEM_alloc(200);
	char* cItem_revseq = NULL;
	char* TCUA_Item_Rev = NULL;
	char* TCUA_Item_Seq = NULL;
	char buffer1[1024];
	char* MasterComRev = NULL;
	char* MasterComValue = NULL;
	char* TCUA_RevMaster_value = NULL;
	TCUA_RevMaster_value =(char *)MEM_alloc(200);
	char* TCE_RevMaster_value = NULL;
	TCE_RevMaster_value =(char *)MEM_alloc(200);
	int TCUA_IntRevMaster_value;
	int TCE_IntRevMaster_value;
	FILE *fpOutput_file = NULL;
	char* file_name_str = NULL;
	char *RptFile= (char *) malloc(400*sizeof(char));
	const char *cEntries[1];
	const char *cValues[1];
	char* condition_str = NULL;
	char* condition_strDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	item_id_str = ITK_ask_cli_argument("-id=");
	item_rev_str = ITK_ask_cli_argument("-rev=");
	condition_str = ITK_ask_cli_argument("-con=");
	file_name_str = ITK_ask_cli_argument("-fname=");
	
	printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,file_name_str);
	printf("\n Output File Name: [%s]\n", RptFile);fflush(stdout);
	fpOutput_file = fopen(RptFile, "w");
	
	trimwhitespace(item_id_str);
	trimwhitespace(item_rev_str);
	trimwhitespace(condition_str);
	if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
	if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
	if(condition_str!=NULL)tc_strdup(condition_str,&condition_strDup);
	printf(" [1]: Input Part No(item_id_strDup): [%s]\n",item_id_strDup);
	printf(" [2]: Input Part RevSeq(item_rev_strDup): [%s]\n",item_rev_strDup);
	printf(" [3]: Input Condition(condition_strDup): [%s]\n",condition_strDup);
	printf(" [4]: Input File Name(file_name_str): [%s]\n",file_name_str);

    if(tc_strcmp(condition_strDup,"REVISE") == 0)
	{
		printf(" ######## CONDITION START: REVISE ########\n");fflush(stdout);
		if((tc_strlen(item_id_strDup)>0) && (tc_strlen(item_rev_strDup)>0))
		{
			printf(" Part_No Not Null..!!\n");fflush(stdout);
			cEntries[0] ="item_id";
			cValues[0] = item_id_strDup;
			ITEM_find_items_by_key_attributes(1, cEntries, cValues, &n_itemobj_found, &titemobj_results);
			if(n_itemobj_found > 0)
			{
				titem = titemobj_results[0];
				if(titem != NULLTAG )
				{
					ITK_CALL(ITEM_ask_latest_rev(titem,&tlatestitem_rev));
					ITK_CALL(AOM_ask_value_string(tlatestitem_rev,"item_revision_id",&cItem_revseq));
					printf("LATEST_ITEM_REVISION_SEQUENCE_VALUE(cItem_revseq): [%s]\n", cItem_revseq);fflush(stdout);
					TCUA_Item_Rev = tc_strtok(cItem_revseq,";");
					TCUA_Item_Seq = tc_strtok(NULL,";");
					FILE* fpinp = fopen("/user/cvprod/sourav/Revision_Availability_Check/Master_RevCompare_File.txt", "r");
					if (!fpinp)
					{
						printf("Can't Open Master_RevCompare_File\n");fflush(stdout);
						return 0;
					}
					else
					{
						while (fgets(buffer1,1024, fpinp))
						{
							MasterComRev = strtok(buffer1,"^");
							MasterComValue = strtok(NULL,"^");
							if(tc_strcmp(TCUA_Item_Rev,MasterComRev) == 0)
							{
								tc_strcpy(TCUA_RevMaster_value,MasterComValue);
							}
							if(tc_strcmp(item_rev_strDup,MasterComRev) == 0)
							{
								tc_strcpy(TCE_RevMaster_value,MasterComValue);
							}
						}
						TCUA_IntRevMaster_value = atoi(TCUA_RevMaster_value);
						TCE_IntRevMaster_value = atoi(TCE_RevMaster_value);
						printf("##########################################\n");
						printf("TCUA_REVISION_VALUE(TCUA_IntRevMaster_value): [%d]\n", TCUA_IntRevMaster_value);fflush(stdout);
						printf("TCE_REVISION_VALUE(TCE_IntRevMaster_value): [%d]\n", TCE_IntRevMaster_value);fflush(stdout);
						printf("##########################################");
						if(TCE_IntRevMaster_value == TCUA_IntRevMaster_value)
						{
							tc_strcpy(ResponseString,"SAME");
							tc_strcat(ResponseString,"^");
						}
						if(TCE_IntRevMaster_value < TCUA_IntRevMaster_value)
						{
							tc_strcpy(ResponseString,"TCELOWER");
							tc_strcat(ResponseString,"^");
						}
						if(TCE_IntRevMaster_value > TCUA_IntRevMaster_value)
						{
							tc_strcpy(ResponseString,"TCEHIGHER");
							tc_strcat(ResponseString,"^");
						}
					}
				}
				else
				{
					printf("\n Item Tag is NULL..!!");fflush(stdout);
					tc_strcpy(ResponseString,"NOREVFOUND");
					tc_strcat(ResponseString,"^");
				}
			}
			else
			{
				printf("\n Mentioned Item Not Found in CVPROD..!!");fflush(stdout);
				tc_strcpy(ResponseString,"NOREVFOUND");
				tc_strcat(ResponseString,"^");
			}
            printf("\n #########################################\n");fflush(stdout);
			printf("\n RESPONSESTRING(ResponseString): [%s]\n",ResponseString);fflush(stdout);
			printf("\n #########################################\n");fflush(stdout);
			fprintf(fpOutput_file,"%s",ResponseString);fflush(fpOutput_file);				
			if (titemobj_results)
			{
			   MEM_free(titemobj_results);
			}
			fclose(fpOutput_file) ;           
			printf("\n Output File Closed..!!\n");fflush(stdout); 		
		}
		else 
		{
			printf("\n Input_Part_No or Input_Part_RevSeq is NULL..!!\n");fflush(stdout);
		}
		printf(" ######## CONDITION END: REVISE ########\n");fflush(stdout);
	}
	
	if(tc_strcmp(condition_strDup,"CREATE") == 0)
	{
		printf(" ######## CONDITION START: CREATE ########\n");fflush(stdout);
		if((tc_strlen(item_id_strDup)>0) && (tc_strlen(item_rev_strDup)>0))
		{
			cEntries[0] ="item_id";
			cValues[0] = item_id_strDup;
			ITEM_find_items_by_key_attributes(1, cEntries, cValues, &n_itemobj_found, &titemobj_results);
			if(n_itemobj_found > 0)
			{
				titem = titemobj_results[0];
				if(titem != NULLTAG )
				{
					ITK_CALL(ITEM_ask_latest_rev(titem,&tlatestitem_rev));
					ITK_CALL(AOM_ask_value_string(tlatestitem_rev,"item_revision_id",&cItem_revseq));
					printf("LATEST_ITEM_REVISION_SEQUENCE_VALUE(cItem_revseq): [%s]\n", cItem_revseq);fflush(stdout);
					TCUA_Item_Rev = tc_strtok(cItem_revseq,";");
					TCUA_Item_Seq = tc_strtok(NULL,";");
					tc_strcpy(ResponseString,"ITEMPRESENT");
					tc_strcat(ResponseString,"^");
				}
				else
				{
					printf("\n Item Tag is NULL..!!");fflush(stdout);
					tc_strcpy(ResponseString,"ITEMNOTPRESENT");
					tc_strcat(ResponseString,"^");
				}
			}
			else
			{
				printf("\n Mentioned Item Not Found in CVPROD..!!");fflush(stdout);
				tc_strcpy(ResponseString,"ITEMNOTPRESENT");
				tc_strcat(ResponseString,"^");
			}
			printf("\n #########################################\n");fflush(stdout);
			printf("\n RESPONSESTRING(ResponseString): [%s]\n",ResponseString);fflush(stdout);
			printf("\n #########################################\n");fflush(stdout);
			fprintf(fpOutput_file,"%s",ResponseString);fflush(fpOutput_file);
			if (titemobj_results)
			{
			   MEM_free(titemobj_results);
			}
			fclose(fpOutput_file) ;           
			printf("\n Output File Closed..!!\n");fflush(stdout);
		}
		else 
		{
			printf("\n Input_Part_No or Input_Part_RevSeq is NULL..!!\n");fflush(stdout);
		}
		printf(" ######## CONDITION END: CREATE ########\n");fflush(stdout);
	}
	
	if(tc_strcmp(condition_strDup,"QUERY") == 0)
	{
		printf(" ######## CONDITION START: QUERY ########\n");fflush(stdout);
		if((tc_strlen(item_id_strDup)>0))
		{
			cEntries[0] ="item_id";
			cValues[0] = item_id_strDup;
			ITEM_find_items_by_key_attributes(1, cEntries, cValues, &n_itemobj_found, &titemobj_results);
			if(n_itemobj_found > 0)
			{
				titem = titemobj_results[0];
				if(titem != NULLTAG )
				{
					ITK_CALL(ITEM_ask_latest_rev(titem,&tlatestitem_rev));
					ITK_CALL(AOM_ask_value_string(tlatestitem_rev,"item_revision_id",&cItem_revseq));
					printf("LATEST_ITEM_REVISION_SEQUENCE_VALUE(cItem_revseq): [%s]\n", cItem_revseq);fflush(stdout);
					TCUA_Item_Rev = tc_strtok(cItem_revseq,";");
					TCUA_Item_Seq = tc_strtok(NULL,";");
					tc_strcpy(ResponseString,item_id_strDup);
					tc_strcat(ResponseString,"^");
					tc_strcat(ResponseString,TCUA_Item_Rev);
					tc_strcat(ResponseString,"^");
					tc_strcat(ResponseString,TCUA_Item_Seq);
					tc_strcat(ResponseString,"^");
				}
				else
				{
					printf("\n Item Tag is NULL..!!");fflush(stdout);
					tc_strcpy(ResponseString,"ITEMNOTFOUND");
					tc_strcat(ResponseString,"^");
					tc_strcat(ResponseString,"REVNOTFOUND");
					tc_strcat(ResponseString,"^");
					tc_strcat(ResponseString,"SEQNOTFOUND");
					tc_strcat(ResponseString,"^");
				}
			}
			else
			{
				printf("\n Mentioned Item Not Found in CVPROD..!!");fflush(stdout);
				tc_strcpy(ResponseString,"ITEMNOTFOUND");
				tc_strcat(ResponseString,"^");
				tc_strcat(ResponseString,"REVNOTFOUND");
				tc_strcat(ResponseString,"^");
				tc_strcat(ResponseString,"SEQNOTFOUND");
				tc_strcat(ResponseString,"^");
			}
			printf("\n #########################################\n");fflush(stdout);
			printf("\n RESPONSESTRING(ResponseString): [%s]\n",ResponseString);fflush(stdout);
			printf("\n #########################################\n");fflush(stdout);
			fprintf(fpOutput_file,"%s",ResponseString);fflush(fpOutput_file);
			if (titemobj_results)
			{
			   MEM_free(titemobj_results);
			}
			fclose(fpOutput_file) ;           
			printf("\n Output File Closed..!!\n");fflush(stdout);
		}
		else 
		{
			printf("\n Input_Part_No or Input_Part_RevSeq is NULL..!!\n");fflush(stdout);
		}
		printf(" ######## CONDITION END: QUERY ########\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_revision_check.c
* // ./linkitk -o tm_revision_check tm_revision_check.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Revision_Availability_Check/tm_revision_check .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Revision_Availability_Check/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Revision_Availability_Check/usage.txt .
* // .tm_revision_check -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // .tm_revision_check -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // .tm_revision_check -u=loader -p=loader123 -g=dba
*
***************************************************************************/