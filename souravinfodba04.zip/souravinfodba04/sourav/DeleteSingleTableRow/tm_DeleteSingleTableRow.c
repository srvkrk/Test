/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   SubModule Library Revision
*  Description  :   Delete SubModule Table Single Row Data After Reading SubModule Address, SubModule No, SubModule Revision & Sequence From Input File.
*  File Name    :   tm_DeleteSingleTableRow.c
*  Created on   :   Aug 26th, 2024
*  Usage        :   tm_DeleteSingleTableRow
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     26/08/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* SubModAddr_Str = NULL;
	char* InpPart_Str = NULL;
	char* InpRev_Str = NULL;
	char* InpSeq_Str = NULL;
	char* SubModAddr_StrDup = NULL;
	char* InpPart_StrDup = NULL;
	char* InpRev_StrDup = NULL;
	char* InpSeq_StrDup = NULL;
	char* LibPartNo = NULL;
	char* LibPartRev = NULL;
	char* LibPartSeq = NULL;
	char* LibPartNoDup = NULL;
	char* LibPartRevDup = NULL;
	char* LibPartSeqDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("InputList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{	
			SubModAddr_Str=strtok(Buffer,"^");
			InpPart_Str=strtok(NULL,"^");
			InpRev_Str=strtok(NULL,"^");
			InpSeq_Str=strtok(NULL,"^");
			
            if(SubModAddr_Str!=NULL)tc_strdup(SubModAddr_Str,&SubModAddr_StrDup);
            if(InpPart_Str!=NULL)tc_strdup(InpPart_Str,&InpPart_StrDup);
            if(InpRev_Str!=NULL)tc_strdup(InpRev_Str,&InpRev_StrDup);
            if(InpSeq_Str!=NULL)tc_strdup(InpSeq_Str,&InpSeq_StrDup);			
			if(SubModAddr_StrDup!=NULL)trimwhitespace(SubModAddr_StrDup);
			if(InpPart_StrDup!=NULL)trimwhitespace(InpPart_StrDup);
			if(InpRev_StrDup!=NULL)trimwhitespace(InpRev_StrDup);
			if(InpSeq_StrDup!=NULL)trimwhitespace(InpSeq_StrDup);
			printf(" Address(SubModAddr_StrDup): [%s]\n",SubModAddr_StrDup);
			printf(" Part_No(InpPart_StrDup): [%s]\n",InpPart_StrDup);
			printf(" Revision(InpRev_StrDup): [%s]\n",InpRev_StrDup);
			printf(" Sequence(InpSeq_StrDup): [%s]\n",InpSeq_StrDup);

			ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"ID"};
				char *cValues[1]  = {SubModAddr_StrDup};
				//char *cValues[1]  = {"A1A01"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
				    printf(" SubModule Address revision Exist So Continue For Table Data Updation..!!\n");fflush(stdout);
				    tsubmodlib_rev = titemobj_results[0];
					ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
					printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SubModAddr_StrDup);fflush(stdout);
					if(n_valid_rows>0)
					{
						int iValCnt=0;
						for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
						{
							ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &LibPartNo));
						    ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &LibPartRev));
						    ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &LibPartSeq));
							if(LibPartNo!=NULL)tc_strdup(LibPartNo,&LibPartNoDup);
							if(LibPartRev!=NULL)tc_strdup(LibPartRev,&LibPartRevDup);
							if(LibPartSeq!=NULL)tc_strdup(LibPartSeq,&LibPartSeqDup);
			                if(LibPartNoDup!=NULL)trimwhitespace(LibPartNoDup);
							if(LibPartRevDup!=NULL)trimwhitespace(LibPartRevDup);
							if(LibPartSeqDup!=NULL)trimwhitespace(LibPartSeqDup);
						    printf("\n Library Part_No: [%s]\n",LibPartNoDup);fflush(stdout);
							printf("\n Library Part_Rev: [%s]\n",LibPartRevDup);fflush(stdout);
							printf("\n Library Part_No: [%s]\n",LibPartSeqDup);fflush(stdout);
							
							int delete_from_row_index = iValCnt;
							int num_rows_to_delete  = 1;
							if((tc_strcmp(InpPart_StrDup,LibPartNoDup)==0) && (tc_strcmp(InpRev_StrDup,LibPartRevDup)==0) && (tc_strcmp(InpSeq_StrDup,LibPartSeqDup)==0))
						    {
								printf("\n [Start] Deletion of Table Row: [%d]\n",iValCnt);fflush(stdout);
								ITK_CALL(AOM_lock(tsubmodlib_rev));
								ITK_CALL(AOM_delete_table_rows(tsubmodlib_rev,"t5_Submoduledetail", delete_from_row_index,num_rows_to_delete));
								ITK_CALL(AOM_unlock(tsubmodlib_rev));
								ITK_CALL(AOM_refresh(tsubmodlib_rev, FALSE));
								printf("\n [End] Deletion of Table Row: [%d]",iValCnt);fflush(stdout);
							}
						}
					}
					else
					{
					    printf("\n No Table Row Found For Input SubModule Address: [%s]\n", SubModAddr_StrDup);fflush(stdout);
					}    
				}
                else
                {
				   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
				}					
			}
		    else
			{
				printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
			}
			if(titemobj_results)
			{
			   MEM_free(titemobj_results);
			} 
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_DeleteSingleTableRow.c
* // ./linkitk -o tm_DeleteSingleTableRow tm_DeleteSingleTableRow.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DeleteSingleTableRow/tm_DeleteSingleTableRow .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DeleteSingleTableRow/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DeleteSingleTableRow/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DeleteSingleTableRow/usage.txt .
* // ./tm_DeleteSingleTableRow -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_DeleteSingleTableRow -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/