/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Query Start Part & Print It's Information
*  File Name    :   tm_startpart_lst.c
*  Created on   :   March 10th, 2023
*  Usage        :   tm_startpart_lst
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     13/03/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	char* cError = NULL;
	char* username = NULL;
	FILE *fpPart_List = NULL;
	char * Part_Id_Str = NULL;
	int n_entries = 1;
	int n_itemobj_found = 0;
	char *ItemID = NULL;
	char *ItemDesc = NULL;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	tag_t* titemobj_results = NULLTAG;
	char temp[10000];
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 1)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			ITK_CALL(ITK_auto_login());
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			fpPart_List = fopen("PartList.txt","r");
			if(fpPart_List != NULL)
		    {	
			    printf("\n Part List is Not Null Moving Forward...");
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					Part_Id_Str=strtok(temp,",");
					printf("\n Start Part No --------> %s", Part_Id_Str);fflush(stdout);

                    ITK_CALL(QRY_find2("Item ID",&tItemobj));
			        printf("\n Return Value From Item ID Query API is --------> %d", iFail);fflush(stdout);

                    if(tItemobj!=NULLTAG)
			        {
					   printf("\n Item ID Query Found Successfully...");
					   char *cEntries[1]  = {"Item ID"};
					   char *cValues[1]  = {Part_Id_Str};
					   ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
					   printf("\n Return Value From Item ID Query Execute API is --------> %d", iFail);fflush(stdout);
					   printf("\n No of Item Found --------> %d\n",n_itemobj_found);fflush(stdout);
					   if(n_itemobj_found>0)
					    {
							
						    ITK_CALL(AOM_ask_value_string( titemobj_results[0], "item_id", &ItemID));
							ITK_CALL(AOM_ask_value_string( titemobj_results[0], "object_desc", &ItemDesc));
							printf("\n Item ID --------> %s,Item Description --------> %s,Present Status --------> YES\n",ItemID,ItemDesc);fflush(stdout);

						}
						else
						{
							printf("\n Item ID --------> %s,Present Status --------> NO\n",Part_Id_Str);fflush(stdout);
						}
						if (titemobj_results)
						{
							MEM_free(titemobj_results);
						}
			        }					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n Data Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout); 
			}
			else 
			{
				printf("\n Input Part List is Null....");fflush(stdout);
			}
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}


