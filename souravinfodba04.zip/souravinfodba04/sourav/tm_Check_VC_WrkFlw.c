/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   tm_Check_VC_WrkFlw.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar			VC_Handler
* 2.	   19.4.22		-			Prasad				Uploaded Data from Bhaskar Folder to DV
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_Check_VC_WrkFlw(EPM_rule_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int no_attach			= 0;
	int count				= 0;
	int taskcount			= 0;
	int flagVehicle = 0, flagCCVC = 0;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  Taskrelation_type	= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *taskObject		= NULLTAG;
	tag_t   DMLObject		= NULLTAG;

	char   *objecttype		=NULL;
	char   *objectId		=NULL;
	char   *objectRevID		=NULL;
	char   *objectdesc		=NULL;
	char   *objectrelstatus	=NULL;
	char   *objectDRstatus	=NULL;
	char   *DMLDRstauts		=NULL;
	char   *value			=NULL;
	char   *Ct5parttype		=NULL;

	char *username;
	tag_t user_tag=NULLTAG;
	char *userid;

	char   ObjTyp[TCTYPE_name_size_c+1];

	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_Check_VC_WrkFlw--*********** ::start here:: **********");fflush(stdout);

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_Check_VC_WrkFlw--No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\ntm_Check_VC_WrkFlw--******* INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n tm_Check_VC_WrkFlw--********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if(GRM_find_relation_type("T5_DMLTaskRelation",&Taskrelation_type));
				if(Taskrelation_type != NULLTAG)
				{
					if(GRM_list_primary_objects_only(taskAttachments[i],Taskrelation_type,&taskcount,&taskObject)!=ITK_ok)PrintErrorStack();
					printf("\n tm_Check_VC_WrkFlw--DML Count :>>>>  %d\n",taskcount);fflush(stdout);
					if(taskcount >0)
					{
						DMLObject=taskObject[0];
						if(AOM_ask_value_string(DMLObject,"t5_rlstype",&value));
						printf("\n tm_Check_VC_WrkFlw-->>>>>ERC DML release type:: t5_rlstype ::  %s\n",value);fflush(stdout);

						if(AOM_ask_value_string(DMLObject,"t5_cDRstatus",&DMLDRstauts));
						printf("\n tm_Check_VC_WrkFlw-->>>>>ERC DML :: DMLDRstauts ::  %s\n",DMLDRstauts);fflush(stdout);
						
						if(tc_strcmp(value,"Veh")==0)
						{
							if(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation));
							if(DmlItemsRelation != NULLTAG)
							{
								printf("\n\t tm_Check_VC_WrkFlw--DmlItemsRelation relation found......");fflush(stdout);
								if(GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject));
								printf("\n\t tm_Check_VC_WrkFlw--count is : %d",count);
								
								if(count >0)
								{
									flagVehicle=0;
									flagCCVC=0;

									for(k=0;k<count;k++)
									{
										if(AOM_ask_value_string(SecObject[k],"t5_PartType",&Ct5parttype));
										printf("\n tm_Check_VC_WrkFlw--[%d]th Object and Object Part type :: [%s]",count,Ct5parttype);fflush(stdout);
										if(tc_strcmp(Ct5parttype,"CCVC")==0)
										{
											flagCCVC=1;
											printf("\n\t tm_Check_VC_WrkFlw--Found Object under Solution folder is of type CCV");fflush(stdout);
										}
									}
									printf("\n\t tm_Check_VC_WrkFlw--flagCCVC==> [%d] ",flagCCVC);fflush(stdout);
									
									if (flagCCVC == 0)
									{
										printf("\n\t tm_Check_VC_WrkFlw--Inside loop flagCCVC==0 ");fflush(stdout);
										int		p				=0;
										int		VPL_count		=0;
										tag_t	trelation_type	=NULLTAG;
										tag_t	*AvailObjects	=NULLTAG;
										int flagWarningVPL = 0;
										int flagErrorVPL = 0;
										if(GRM_find_relation_type("T5_HasVPL",&trelation_type));
										
										for(j=0;j<count;j++)
										{
											if(AOM_ask_value_string(SecObject[j],"object_type",&objecttype));
											if(AOM_ask_value_string(SecObject[j],"item_id",&objectId));
											if(AOM_ask_value_string(SecObject[j],"item_revision_id",&objectRevID));
											if(AOM_ask_value_string(SecObject[j],"object_desc",&objectdesc));
											if(AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus));
											if(AOM_ask_value_string(SecObject[j],"t5_PartStatus",&objectDRstatus));

											printf("\n tm_Check_VC_WrkFlw--SecObject objecttype = [%s] ",objecttype);fflush(stdout);
											printf("\n tm_Check_VC_WrkFlw--SecObject objectId=[%s] objectRevID: [%s] objectDRstatus= [%s] objectrelstatus: [%s]",objectId,objectRevID,objectDRstatus,objectrelstatus);fflush(stdout);
											printf("\n tm_Check_VC_WrkFlw--SecObject objectdesc= [%s] ",objectdesc);fflush(stdout);

											POM_get_user(&username,&user_tag);
											SA_ask_user_identifier2	(user_tag,&userid)	;
											printf (" tm_Check_VC_WrkFlw--Logged in user:%s %s\n",userid,username);fflush(stdout);
											
											if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"su_mdm")!=0 && tc_strcmp(userid,"infodba")!=0)
											{
												printf ("\n tm_Check_VC_WrkFlw--tc_strlen(objectId): [%d] \n",tc_strlen(objectId));fflush(stdout);
												
												if(tc_strlen(objectId)>0)
												{
													if(tc_strlen(objectId)==9)
													{
														flagVehicle=1;

														if ((tc_strstr(objectrelstatus,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(objectrelstatus,"ERC Released")!= NULL))
														{
															printf("\n **************VC is Released NOT Allowed to Signoff ***********.\n");fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,VC_WrkFlw_error,"Solution Item having Released VC/Vehicle which is not allowed, remove Released VC/Vehicle and Proceed",objectId);//to be added in header file	
															decision = EPM_nogo;
															return decision;
														}
														else
														{
															//if((tc_strlen(objectdesc)>0) && (tc_strlen(objectDRstatus)>0))
															if((tc_strlen(objectdesc)>0) && (tc_strcmp(objectDRstatus,DMLDRstauts)==0))
															{
																printf("\n tm_Check_VC_WrkFlw--***Mandatory attributes are Present***");fflush(stdout);
															}
															else
															{
																printf("\n tm_Check_VC_WrkFlw--**************VC/Vehicle is NOT Released ***********.\n");fflush(stdout);
																EMH_clear_errors();
																EMH_store_error_s2(EMH_severity_error,VC_error,"Please check mandatory attributes {Desc} is filled and VC/Vehicle DR-Status should be equal to DML DR Status, correct mandatory attributes and signoff",objectId);//to be added in header file	
																decision = EPM_nogo;
																return decision;																	
															}
														}
														/*HAS VPL VALIDATION ADDED WHILE TASK SIGN OFF ACTION*/
														tag_t	DmlReasonqryTag							=	NULLTAG;
														tag_t   *DMLReasonValidationCntrlObjectTag		=	NULLTAG;
														int     DMLReasonValidation_rsltCount			=	0;
														char    *DMLReasonValidation_qry_entry[1]  = {"SYSCD"};
														char   **DMLReasonValidation_qry_values     =  (char **) MEM_alloc(100 * sizeof(char *));
														char   *Userinfo5 =NULL;
														char   *Userinfo5Dup =NULL;
														if(QRY_find("Control Objects...", &DmlReasonqryTag));

														if(DmlReasonqryTag)
														{
															printf("\n DmlReasonqryTag:Found Query ControlObjects \n");fflush(stdout);
														}
														else
														{
															printf("\n DmlReasonqryTag:Not Found Query ControlObjects \n");fflush(stdout);
														}
														if(DmlReasonqryTag!=NULLTAG)
														{
															DMLReasonValidation_qry_values[0] = "DMLReasonSignOffValidation";
															if(QRY_execute(DmlReasonqryTag, 1, DMLReasonValidation_qry_entry, DMLReasonValidation_qry_values, &DMLReasonValidation_rsltCount, &DMLReasonValidationCntrlObjectTag));
															printf("\n DMLReasonValidation_rsltCount :%d:", DMLReasonValidation_rsltCount); fflush(stdout);

														}
														GRM_list_secondary_objects_only(SecObject[j], trelation_type, &VPL_count, &AvailObjects);
														printf("VPL count is %d",VPL_count);
														if(DMLReasonValidation_rsltCount >0)
														{
															if(AOM_ask_value_string(DMLReasonValidationCntrlObjectTag[0],"t5_Userinfo5",&Userinfo5));
															tc_strdup(Userinfo5,&Userinfo5Dup);
															printf("\n Userinfo5 :[%s]:", Userinfo5Dup); fflush(stdout);
															if(tc_strstr(Userinfo5Dup,"VPL")!=NULL)
															{
																flagErrorVPL = 0;
																if(VPL_count==0)
																{
																	flagWarningVPL++;
																}
																
															}
														}

														/*HAS VPL VALIDATION ADDED WHILE TASK SIGN OFF ACTION*/
													}
												}
											}
										} //end of for loop==count

										if (flagVehicle==0)
										{
											printf("\n tm_Check_VC_WrkFlw--**************VC/Vehicle NOT Present ***********.\n");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,VC_Not_error,"VC/Vehicle is not present in solution item Please add Applicable VC/Vehicle and Signoff",objectId);//to be added in header file	
											decision = EPM_nogo;
											return decision;
										}
										if(flagWarningVPL>0)
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_warning,ITK_err, "VPL Part Master is not attached to Vehicle Revision");
											decision = EPM_go;
											return decision;
										}
										if(flagErrorVPL>0)
										{
											EMH_clear_errors();
											EMH_store_error_s3(EMH_severity_error,ITK_err, "Sign Off is not Allowed, Because: ","Has VPL Relation not found"," Please attach Design master of VPL part in Design Revision Has VPL folder!!!!");
											decision = EPM_nogo;
											return decision;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	printf("\n tm_Check_VC_WrkFlw--Completed...\n");fflush(stdout);
	
	return decision;
}
