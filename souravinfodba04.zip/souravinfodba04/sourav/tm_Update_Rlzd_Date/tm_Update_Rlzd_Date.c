/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Module & Check It's Two Properties Value (Module Name & Keyword Description)  
*  File Name    :   tm_module_property_report.c
*  Created on   :   Sep 01st, 2023
*  Usage        :   tm_module_property_report
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     01/09/2023                 Sourav Karak
***************************************************************************/

#include <stdio.h>
#include <tc/tc.h>
#include <string.h>
#include <stdlib.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <itk/mem.h>
#include <stdlib.h>
#include <tccore/grm.h>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/tctype.h>
#include <tccore/imantype.h>
#include <tccore/workspaceobject.h>
#include <tccore/custom.h>
#include <tccore/imantype.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

void get_PreviousDate(char Effect_Frm_Dt[100],char ReturnPrevDt[30]) //function to get next date of the passed(parameter/argument) date.
{ 
	printf("\n In get_PreviousDate function: Given date is : %s",Effect_Frm_Dt);
	int x =0;
	char DayTmp[10];
	char MothTmp[10];
	char YearTmp[10];
	int year;
	int month;
	int day;
	char *dd = (char *)malloc(100);
	char *mm = (char *)malloc(100);
	char *yy = (char *)malloc(100);
	char Day[10];
	char Year[10];
	char *token = NULL;
	//logical date_is_valid_l;
	//date_t NextDate;

    token = strtok(Effect_Frm_Dt, "-"); // Splitting string

	while (token != NULL) 
    { 
        if(x==0)
		{
			strcpy(DayTmp,token);
			day = atoi(DayTmp);        // Converting string to int
		}
		if(x==1)
		{
			strcpy(MothTmp,token);
			 month = atoi(MothTmp);
		}
		if(x==2)
		{
			strcpy(YearTmp,token);
			year = atoi(YearTmp);      // Converting string to int
		}
		token = strtok(NULL, "-");
		x++;
    } 
	printf("\n Given date as string after splitting(DD-MM-YY) = %s-%s-%s \n",DayTmp,MothTmp,YearTmp ); // Print splitted date as string	

	if (strcmp(MothTmp,"Jan")==0)
	{month = 1;}
	else if (strcmp(MothTmp,"Feb")==0)
	{month = 2;}
	else if (strcmp(MothTmp,"Mar")==0)
	{month = 3;}
	else if (strcmp(MothTmp,"Apr")==0)
	{month = 4;}
	else if (strcmp(MothTmp,"May")==0)
	{month = 5;}
	else if (strcmp(MothTmp,"Jun")==0)
	{month = 6;}
	else if (strcmp(MothTmp,"Jul")==0)
	{month = 7;}
	else if (strcmp(MothTmp,"Aug")==0)
	{month = 8;}
	else if (strcmp(MothTmp,"Sep")==0)
	{month = 9;}
	else if (strcmp(MothTmp,"Oct")==0)
	{month = 10;}
	else if (strcmp(MothTmp,"Nov")==0)
	{month = 11;}
	else if (strcmp(MothTmp,"Dec")==0)
	{month = 12;}
	printf("\n Given date as int after splitting (day-month-year) = %d-%d-%d \n",day,month,year ); // Print splitted date as int

    day = day -1;

	//Day logic, based on that month and year
	if (day ==0 )
	 {
		if (month==1)
		{
			month=12;
			year = year -1;
		}
		else
		{
			month=month-1;
		}

		if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12 )
		{
			day = 31;
		}
		else if (month == 2 )
		{
			if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))  // Leap year checking, if yes, Feb will have 29 days.
			{
				day = 29;
			}
			else
			{
				day = 28;
			}
		}
		else
		{
			day = 30;
		}
	}   
    
	printf("\n Previous Date as int(day-month-year) = %d-%d-%d \n",day,month,year ); // Print Previous date in int	
	
	char	*ddmm	=	NULL;
	ddmm	=	(char*) malloc(5);
	sprintf(ddmm, "%d", day);
	sprintf(Year, "%d", year);
	if ( day<10)
	{
		printf("\nDay less than 10");fflush(stdout);
		strcpy(Day,"0");
		strcat(Day,ddmm);
	}
	else
	{
		strcpy(Day,ddmm);
	}
	printf("\nDay......... : %s",Day);fflush(stdout);
	//itoa(year,Year,10);
	strcpy(dd,Day);
    //strcpy(mm,itoa(month));
	strcpy(yy,Year);

	if (month == 1)
	{strcpy (mm, "Jan");}
	else if (month == 2)
	{strcpy (mm, "Feb");}
	else if (month == 3)
	{strcpy (mm, "Mar");}
	else if (month == 4)
	{strcpy (mm, "Apr");}
	else if (month == 5)
	{strcpy (mm, "May");}
	else if (month == 6)
	{strcpy (mm, "Jun");}
	else if (month == 7)
	{strcpy (mm, "Jul");}
	else if (month == 8)
	{strcpy (mm, "Aug");}
	else if (month == 9)
	{strcpy (mm, "Sep");}
	else if (month == 10)
	{strcpy (mm, "Oct");}
	else if (month == 11)
	{strcpy (mm, "Nov");}
	else if (month == 12)
	{strcpy (mm, "Dec");}

    printf("\n Previous Date as string (dd-mm-yy) = %s-%s-%s \n",dd,mm,yy); // Print Previous date in string
	int size = strlen(dd) + strlen(mm) + strlen(yy) + 1;
	char *PrevDate_String = malloc(size);
	strcpy (PrevDate_String, dd);
    strcat (PrevDate_String, "-");
	strcat (PrevDate_String, mm);
	strcat (PrevDate_String, "-");
	strcat (PrevDate_String, yy);
	//strcat (PrevDate_String, " ");
	//strcat (PrevDate_String, "00:00");

	printf("\n Previous date is(PrevDate_String) : %s \n",PrevDate_String);

	strcpy (ReturnPrevDt, PrevDate_String);
	
}

int ITK_user_main(int argc,char* argv[]) // Main Function
{
	char *message;
	char *loggedInUser = NULL;
	char *Part_item_id = NULL;
	char *item_id_str = NULL;
	char *PartNo = NULL;
	char *PartRev = NULL;
	char *RlzStatusName = NULL;

	tag_t Part_tag = NULLTAG;
	tag_t *Rev_list = NULLTAG;
	tag_t PartRev_tag = NULLTAG;
	tag_t *Stat_list = NULLTAG;
	tag_t Stat_tag = NULLTAG;

	int Rev_count = 0;
	int Stat_Cnt = 0;

	FILE *fpPart_List = NULL;	

	FILE *fpNoChangeReqd = NULL;
    fpNoChangeReqd = fopen("Status_No_ChangeReq_Update.csv","w");
	FILE *fpChangeReqd = NULL;
    fpChangeReqd = fopen("Status_ChangeReq_Update.csv","w");
         		
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	   //Auto-Logging in to TC
    status = ITK_auto_login ();
	
    if (status != ITK_ok ) 
	{
              EMH_ask_error_text(status, &message);
              printf(" Error with ITK_auto_login : \"%d\", \"%s\"\n", status, message);
              MEM_free(message);
              return status;
    }
	else
	{
			printf(" Auto login Successfully\n");fflush(stdout);
			POM_get_user_id(&loggedInUser);
			printf(" Logged in User is : %s\n",loggedInUser);fflush(stdout);
	}

	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf("\n Part_List != NULL\n");fflush(stdout);
		Part_item_id=(char *) MEM_alloc(100);

		while(fgets(Part_item_id,100,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Part_item_id,"^");
			printf("\n Part_item_id (item_id_str) = %s \n",item_id_str);

			Part_tag = NULLTAG;
			ITK_CALL(ITEM_find_item(item_id_str,&Part_tag));

			AOM_ask_value_string(Part_tag,"item_id",&PartNo);
			printf(" \n Part Number = %s\n",PartNo);fflush(stdout);
					
			if (Part_tag != NULLTAG)
			{
				int i = 0;
				int j = 0;
				ITK_CALL(ITEM_list_all_revs(Part_tag,&Rev_count,&Rev_list));
				printf(" \n Rev_count = %d\n",Rev_count);fflush(stdout);

				for(i=0;i<Rev_count;i++)
				{
					PartRev_tag = Rev_list[i];

					AOM_ask_value_string(PartRev_tag,"item_revision_id",&PartRev);
			        printf(" \n Part Revision = %s/%s\n",PartNo,PartRev);fflush(stdout);

					ITK_CALL(WSOM_ask_release_status_list(PartRev_tag,&Stat_Cnt,&Stat_list));

					for(j=0;j<Stat_Cnt;j++)
					{
						Stat_tag = Stat_list[j];
						AOM_ask_name(Stat_tag, &RlzStatusName);
						printf("\n Part`s Release status is : %s\n",RlzStatusName);fflush(stdout);

						if ((tc_strcmp(RlzStatusName,"T5_LcsRlzd")==0) || (tc_strcmp(RlzStatusName,"T5_LcsErcRlzd")==0))
						{
							int Length = 0;
							char *Effect_dt	= NULL;
							char *Effect_dt_tmp	= (char *)malloc(100);
							char *Dt_Rlzd	=	NULL;
							char *Dt_Rlzd_tmp	=	NULL;
							char *Effect_Frm_Dt	=	NULL;
							char *Req_Dt_Rlzd = (char *)malloc(100);
							tag_t RlzStat_AttrID = NULLTAG;
							date_t Req_Dt_Rlzd_tag ;

							printf("\n APLC Released status found on part..... \n");fflush(stdout);
							ITK_CALL(AOM_ask_value_string(Stat_tag,"effectivity_text",&Effect_dt));
							printf(" \n Release status Effect_dt = %s\n",Effect_dt);fflush(stdout);
							
							Length = tc_strlen(Effect_dt);
							printf(" \n Effect_dt Length  = %d\n",Length);fflush(stdout);

							if (tc_strlen(Effect_dt)>17)
							{
								tc_strcpy(Effect_dt_tmp,Effect_dt);

								ITK_CALL(AOM_UIF_ask_value(Stat_tag,"date_released",&Dt_Rlzd));
								printf(" \n Release status Dt_Rlzd = %s\n",Dt_Rlzd);fflush(stdout);

								Dt_Rlzd_tmp = strtok(Dt_Rlzd," ");
								printf(" \n Dt_Rlzd_tmp = %s\n",Dt_Rlzd_tmp);fflush(stdout);

								Effect_Frm_Dt = strtok(Effect_dt_tmp," ");
								printf(" \n Effect_Frm_Dt = %s\n",Effect_Frm_Dt);fflush(stdout);
								
								get_PreviousDate(Effect_Frm_Dt,Req_Dt_Rlzd);
								printf(" \n Req_Dt_Rlzd = %s\n",Req_Dt_Rlzd);fflush(stdout);

								if (tc_strcmp(Dt_Rlzd_tmp,Req_Dt_Rlzd)==0)
								{
									printf(" \n No correction is required as Actual and Required date_released matches. \n");fflush(stdout);
								}
								else
								{
									printf(" \n Correction is required as Actual and Required date_released do not matches. \n");fflush(stdout);
									fprintf(fpChangeReqd,"%s/%s,%s,%s,%s,%s\n",PartNo,PartRev,RlzStatusName,Effect_dt,Dt_Rlzd_tmp,Req_Dt_Rlzd);fflush(fpChangeReqd);
									
									//date_released update code start
									strcat (Req_Dt_Rlzd, " ");
									strcat (Req_Dt_Rlzd, "00:00");
									printf(" \n Required Released Date = %s\n",Req_Dt_Rlzd);fflush(stdout);
									exit(0);
									ITK_CALL(ITK_string_to_date(Req_Dt_Rlzd,&Req_Dt_Rlzd_tag));

									ITK_CALL(AOM_lock(Stat_tag));
									ITK_CALL (POM_attr_id_of_attr("date_released", "ReleaseStatus", &RlzStat_AttrID));
									ITK_CALL (POM_set_attr_date(1, &Stat_tag, RlzStat_AttrID, Req_Dt_Rlzd_tag));
									ITK_CALL (AOM_save(Stat_tag));
									ITK_CALL(AOM_refresh(Stat_tag,0));
									ITK_CALL(AOM_unlock(Stat_tag));
									//date_released update code end
								}	
							}
						}
					}
				}
			}
		}
	}
	else 
	{
		printf("\n Part_List = NULL\n");fflush(stdout);
	}
		
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}




// compile -DIPLIB=none Update_Rlz_Dt.c
// linkitk -o Update_Rlz_Dt Update_Rlz_Dt.o
// Update_Rlz_Dt -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba > Update_Log.log &
// Update_Rlz_Dt -u=infodba -p=infodba -g=dba
// scp tcuaadev@172.22.97.90:/user/tcuaadev/devgroups/sagar/Update_Rlz_Dt/Update_Rlz_Dt .
// Update_Rlz_Dt -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba