/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query _WE Part & Update Part Type From Component To Dummy 
*  File Name    :   tm_we_parttype_update.c
*  Created on   :   June 10th, 2023
*  Usage        :   tm_we_parttype_update
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     10/06/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

/* void trimLeading(char * str)
{
    int index, i, j;
    index = 0;
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }
    if(index != 0)
    {
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; 
    }
} */

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)  // All spaces?
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	FILE* fpPart_List = NULL;
	char* PNo_Str = NULL;
	char* RevSeq_Str = NULL;
	char* PNo_StrDup = NULL;
	char* RevSeq_StrDup = NULL;
	char* Part_Id = NULL;
	char* Rev_Seq = NULL;
	char* PartType = NULL;
	char* PartTypeDup = NULL;
	char* NewPartType = NULL;
	char* NewPartTypeDup = NULL;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[300]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	int no_ref = 0;
	int j =0;
	time_t	temptime;
	char GenDate[20];
	struct tm *timeptr;
	int ch;
	char *RptFile= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	
	printf("\n Generating Curernt Time Stamp");fflush(stdout);
	temptime = time(NULL);
	tc_strcpy(GenDate,"");
	timeptr = (struct tm *)localtime(&temptime);
	ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"WEPartType_Update_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 1)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			ITK_CALL(ITK_auto_login());
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			fpPart_List = fopen("PartList.txt","r");
			fpOutput_file = fopen(RptFile, "w");
			fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ P A R T   T Y P E   U P D A T E   O F   W E   P A R T S ~~~~~~~~~~~~~~~");fflush(fpOutput_file);
            fprintf(fpOutput_file,"\n TC_Part, Rev_Seq, Prev_Part_Type, New_Part_Type");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Log File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			if(fpPart_List != NULL)
		    {	
			    printf("\n Part List is Not Null Moving Forward...");fflush(stdout);
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					PNo_Str=strtok(temp,"^");
					RevSeq_Str=strtok(NULL,"^");
					printf("\n Part Number String --------> %s", PNo_Str);fflush(stdout);
					printf("\n Revision & Sequence String --------> %s", RevSeq_Str);fflush(stdout);
					if(tc_strlen(PNo_Str)>0)
					{
						tc_strdup(PNo_Str,&PNo_StrDup);
						tc_strdup(RevSeq_Str,&RevSeq_StrDup);
					}
					else
					{
						tc_strdup("",&PNo_StrDup);
						tc_strdup("",&RevSeq_StrDup);
						printf("\n Part Number & Rev-Seq Value is NULL \n");fflush(stdout);
					}
					trimwhitespace(PNo_StrDup);
					trimwhitespace(RevSeq_StrDup);
					printf("\n Part Number Value After Dup & Trim --------> %s\n", PNo_StrDup);fflush(stdout);
					printf("\n Revision & Sequence Value After Dup & Trim --------> %s\n", RevSeq_StrDup);fflush(stdout);
					ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
			        printf("\n Return Value From ItemRev Query API is --------> %d", iFail);fflush(stdout);
                    if(tItemobj != NULLTAG)
			        {
							printf("\n ItemRev Query Found Successfully...");fflush(stdout);
					        char *cEntries[2]  = {"Revision","ID"};
							char *cValues[2]  = {RevSeq_StrDup,PNo_StrDup};
							//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
					        ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
					        printf("\n Return Value From ItemRev Query Execute API is --------> %d", iFail);fflush(stdout);
					        printf("\n -----------------------------------------------\n");fflush(stdout);
					        printf("\n No of Part Found --------> %d\n",n_itemobj_found);fflush(stdout);
					        printf("\n -----------------------------------------------\n");fflush(stdout);
							for (i = 0; i < n_itemobj_found; i++)
		                    {
								ITK_CALL(AOM_ask_value_string( titemobj_results[i], "item_id", &Part_Id));
								ITK_CALL(AOM_ask_value_string( titemobj_results[i], "item_revision_id", &Rev_Seq));
								ITK_CALL(AOM_ask_value_string( titemobj_results[i], "t5_PartType", &PartType));
								printf("\n Item Revision & Sequence String--------> %s", Rev_Seq);fflush(stdout);
								printf("\n Item Part Type String--------> %s", PartType);fflush(stdout);
								if(tc_strlen(PartType)>0)
								{
								   tc_strdup(PartType,&PartTypeDup);
								   printf("\n Existing Part Type Value After Dup --------> %s\n", PartTypeDup);fflush(stdout);
								}
								else
								{
								   tc_strdup("",&PartTypeDup);
								   printf("\n Existing Part Type Value is NULL \n");fflush(stdout);
								}
								trimwhitespace(PartTypeDup);
								printf("\n Existing Part Type Value After Trim --------> %s\n", PartTypeDup);fflush(stdout);
								if(strstr(PartTypeDup,"C") != NULL)
								{
								    if(strcmp(PartTypeDup,"C") == 0)
									{
										ITK_CALL(AOM_lock(titemobj_results[i]));
										printf("\n Return Value From Checkout API is --------> %d", iFail);fflush(stdout);
										ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_PartType","D"));
										printf("\n Return Value From Set Value API is --------> %d", iFail);fflush(stdout);
										ITK_CALL(AOM_save(titemobj_results[i]));
										printf("\n Return Value From Save Value API is --------> %d", iFail);fflush(stdout);
	                                    ITK_CALL(AOM_unlock(titemobj_results[i]));
										printf("\n Return Value From Checkin API is --------> %d", iFail);fflush(stdout);
										printf("\n UPDATED: Dummy");fflush(stdout);
										ITK_CALL(AOM_ask_value_string( titemobj_results[i], "t5_PartType", &NewPartType));
										printf("\n New Part Type Value --------> %s\n", NewPartType);fflush(stdout);
										if(tc_strlen(NewPartType)>0)
										{
										   tc_strdup(NewPartType,&NewPartTypeDup);
										}
										else
										{
										   tc_strdup("",&NewPartTypeDup);
										   printf("\n New Part Type Value is NULL \n");fflush(stdout);
										}
										trimwhitespace(NewPartTypeDup);
										printf("\n New Part Type Value After Dup --------> %s\n", NewPartTypeDup);fflush(stdout);
										printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);
								        printf("\n TC_Part --------> %s", Part_Id);fflush(stdout);
                                        printf("\n Rev_Seq --------> %s", Rev_Seq);fflush(stdout);
								        printf("\n Prev_Part_Type --------> %s", PartTypeDup);fflush(stdout);
								        printf("\n New_Part_Type --------> %s", NewPartTypeDup);fflush(stdout);
								        printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);
								        fprintf(fpOutput_file,"\n %s,%s,%s,%s,%s",Part_Id,Rev_Seq,PartTypeDup,NewPartTypeDup);fflush(fpOutput_file);
									}
									else
									{
										printf("\n NOT UPDATED");fflush(stdout);
									}
								}
								else
								{
									printf("\n NOT UPDATED");fflush(stdout);
									continue;
								}
		                    }
			        }
					else
					{
						printf("\n After Query Execution No Item Found...");fflush(stdout);
					}
					if (titemobj_results)
					{
						MEM_free(titemobj_results);
					}					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n Part No Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout); 
				fclose(fpOutput_file) ;           
				printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
				printf("\n Output File Closed Now\n");fflush(stdout); 
			}
			else 
			{
				printf("\n Part List is Null....");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if(tItemobj!=NULLTAG)
			{

				tc_strcpy(env_subject,"SUCCESS: MAIL FROM CVPROD PARTTYPE UPDATE REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    Please Check Attached Report");
				tc_strcat(env_body,RptFile);
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			else
			{
				tc_strcpy(env_subject,"FAILED: MAIL FROM CVPROD PARTTYPE UPDATE REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    There is an Issue in Part Type Update Report Creation ");
				tc_strcat(env_body,"\n\n                  Please Check Log & Support user");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			
			printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);
			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}