/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Query SubModule & Check Whether It's Linked with Vehicle or Not (WhereUsed) 
*  File Name    :   tm_SubModuleVehLink.c
*  Created on   :   July 2nd, 2024
*  Usage        :   tm_SubModuleVehLink
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     02/07/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_VehLinkStatus(char* PNSrch,char* PNRevSeqSrch)
{
	
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char* ResponseVehlinkStat = NULL;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	tag_t rev_tags_found = NULLTAG;
	tag_t tParentDesRev = NULLTAG;
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
            int	status_count = 0;
	        tag_t* relStatus_list = NULLTAG;
            char* latest_rev_Rel_Status = NULL;
	        char* latest_rev_Rel_StatusDup = NULL;			
	        rev_tags_found = tpLCQryobj_results[0];
			
			ITK_CALL(PS_where_used_all(rev_tags_found, 1, &n_parents, &levels, &parents));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Attachment Found: [%d]\n",n_parents);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_parents > 0)
			{
				int z = 0;
				printf(" Parent Attachment Found..!!\n");fflush(stdout);
				for(z = 0; z < n_parents; z++)
				{ 
				   tParentDesRev = parents[z];
				   char *Parent_ID = NULL;
				   char *Parent_IDDup = NULL;
				   char *Parent_RevSeq = NULL;
				   char *Parent_RevSeqDup = NULL;
				   char *Parent_PartType = NULL;
				   char *Parent_PartTypeDup = NULL;
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_id",&Parent_ID));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_revision_id",&Parent_RevSeq));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_PartType",&Parent_PartType));
				   
				   printf("\n Parent Part_No: [%s]",Parent_ID);fflush(stdout);
				   printf("\n Parent Rev&Seq No: [%s]",Parent_RevSeq);fflush(stdout);
				   printf("\n Parent Part Type: [%s]",Parent_PartType);fflush(stdout);
				   
				   if(Parent_ID!=NULL)tc_strdup(Parent_ID,&Parent_IDDup);
				   if(Parent_RevSeq!=NULL)tc_strdup(Parent_RevSeq,&Parent_RevSeqDup);
				   if(Parent_PartType!=NULL)tc_strdup(Parent_PartType,&Parent_PartTypeDup);
				    if(tc_strlen(Parent_PartTypeDup)>0)
				    {
					    if((tc_strcmp(Parent_PartTypeDup,"V") == 0) || (tc_strcmp(Parent_PartTypeDup,"VC") == 0))
					    {
						    WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list);
							printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
							if(status_count>0)
							{
								int g = 0;
								for(g = 0; g<status_count; g++)
								{			  
									AOM_ask_value_string(relStatus_list[g],"object_name",&latest_rev_Rel_StatusDup);
									printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
									if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"ERC Released") == 0))
									{ 
									   tc_strdup("Yes",&ResponseVehlinkStat);
									   goto jump;				   
									}
									else
									{
									   continue;
									}			  
								}
							}
							else
							{
								tc_strdup("No",&ResponseVehlinkStat);
								printf("\nRelease Status Not Found on Quiried Design Revision..!!");fflush(stdout);
							}
					    }
				    }   
				}
			}
			else
			{
				tc_strdup("No",&ResponseVehlinkStat);
				printf("Parent Count Zero[0] Continue..!!\n");fflush(stdout);
			}	
		}
		else
		{
			tc_strdup("No",&ResponseVehlinkStat);
			printf("\nEntered Revision Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\nDesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	jump:
		printf("\n !!!!!! Vehicle/VC LC State[ERC Released] Found, In Jump Block..!!!!!!\n");
	
	if(tc_strlen(ResponseVehlinkStat)>0)
	{
		printf("\n Vehicle Link Status Already Received..!!\n");fflush(stdout);
    }
    else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\n As ResponseVehlinkStat value was empty so status[No] added..!!\n");fflush(stdout);
	}
	
	return ResponseVehlinkStat;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(200*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
	tag_t AggrGrpRev_tag = NULLTAG;
	tag_t AggrGrpToAggrRel = NULLTAG;
	int sec_countaggr = 0;
	tag_t* sec_aggrobjects = NULLTAG;
	tag_t AggrRev_tag = NULLTAG;
	tag_t AggrToModRel = NULLTAG;
	int sec_countmod = 0;
	tag_t* sec_modobjects = NULLTAG;
	tag_t ModRev_tag = NULLTAG;
	tag_t ModToSubModRel = NULLTAG;
	int sec_countsubmod = 0;
	tag_t* sec_submodobjects = NULLTAG;
	tag_t SubModRev_tag = NULLTAG;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
	int iValCnt = 0;
	tag_t ttablerow_rev = NULLTAG;
	char *Tbl_SubModRevSeq = NULL;
	Tbl_SubModRevSeq = (char *) malloc(20*sizeof(char));

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"SubModule_Vehicle_Link_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	 
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"PART_NO, PART_REV, PART_SEQ, DESCRIPTION, PRODUCT_LINE, PLATFORM, PROJECT_CODE, AR/DR_STATUS, VEHICLE_LINK_STATUS\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	printf("\n Finding Query[SubModuleLibraryAggrGrp]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("SubModuleLibraryAggrGrp",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query SubModuleLibraryAggrGrp Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total SubModule Library Aggregate Group Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
			{
				char* aggrgrp_no = NULL;
	            char* aggrgrp_nodup = NULL;
				char* aggrgrp_name = NULL;
				char* aggrgrp_namedup = NULL;
				char* aggrgrp_desc = NULL;
				char* aggrgrp_descdup = NULL;
	
				AggrGrpRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"item_id",&aggrgrp_no));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_name",&aggrgrp_name));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_desc",&aggrgrp_desc));
				trimwhitespace(aggrgrp_no);
				trimwhitespace(aggrgrp_name);
				trimwhitespace(aggrgrp_desc);
				if(aggrgrp_no!=NULL)tc_strdup(aggrgrp_no,&aggrgrp_nodup);
				if(aggrgrp_name!=NULL)tc_strdup(aggrgrp_name,&aggrgrp_namedup);
				if(aggrgrp_desc!=NULL)tc_strdup(aggrgrp_desc,&aggrgrp_descdup);
				printf("\n Aggregate Group No(aggrgrp_nodup): [%s]\n", aggrgrp_nodup);
				printf("\n Aggregate Group Name(aggrgrp_namedup): [%s]\n", aggrgrp_namedup);
				printf("\n Aggregate Group Description(aggrgrp_descdup): [%s]\n", aggrgrp_descdup);
				
				ITK_CALL(GRM_find_relation_type("T5_Submdlbagrpagrrel",&AggrGrpToAggrRel));
				if(AggrGrpToAggrRel!=NULLTAG)
				{									
				    printf("\n Sudo Folder Aggregate Details(T5_Submdlbagrpagrrel) Relation Found..!!\n");fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(AggrGrpRev_tag, AggrGrpToAggrRel, &sec_countaggr, &sec_aggrobjects));
				    printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
					if(sec_countaggr > 0)
					{
						for(j = 0; j < sec_countaggr; j++)
			            {
							char* aggr_no = NULL;
	                        char* aggr_nodup = NULL;
							char* aggr_name = NULL;
							char* aggr_namedup = NULL;
							char* aggr_desc = NULL;
							char* aggr_descdup = NULL;
							
						    AggrRev_tag = sec_aggrobjects[j];
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"item_id",&aggr_no));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_name",&aggr_name));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_desc",&aggr_desc));
							trimwhitespace(aggr_no);
							trimwhitespace(aggr_name);
							trimwhitespace(aggr_desc);
							if(aggr_no!=NULL)tc_strdup(aggr_no,&aggr_nodup);
							if(aggr_name!=NULL)tc_strdup(aggr_name,&aggr_namedup);
							if(aggr_desc!=NULL)tc_strdup(aggr_desc,&aggr_descdup);
						    printf("\n Aggregate No(aggr_nodup): [%s]\n", aggr_nodup);
							printf("\n Aggregate Name(aggr_namedup): [%s]\n", aggr_namedup);
							printf("\n Aggregate Description(aggr_descdup): [%s]\n", aggr_descdup);
							
							ITK_CALL(GRM_find_relation_type("T5_Submdlbagrmodrel",&AggrToModRel));
							if(AggrToModRel!=NULLTAG)
							{									
								printf("\n Sudo Folder Module Details(T5_Submdlbagrmodrel) Relation Found..!!\n");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AggrRev_tag, AggrToModRel, &sec_countmod, &sec_modobjects));
								printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countmod);
								if(sec_countmod > 0)
								{
									for(k = 0; k < sec_countmod; k++)
									{
										char* mod_no = NULL;
	                                    char* mod_nodup = NULL;
										char* mod_name = NULL;
										char* mod_namedup = NULL;
										char* mod_desc = NULL;
										char* mod_descdup = NULL;
										
										ModRev_tag = sec_modobjects[k];
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"item_id",&mod_no));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_name",&mod_name));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_desc",&mod_desc));
										trimwhitespace(mod_no);
										trimwhitespace(mod_name);
										trimwhitespace(mod_desc);
										if(mod_no!=NULL)tc_strdup(mod_no,&mod_nodup);
										if(mod_name!=NULL)tc_strdup(mod_name,&mod_namedup);
										if(mod_desc!=NULL)tc_strdup(mod_desc,&mod_descdup);
										printf("\n Module No(mod_nodup): [%s]\n", mod_nodup);
										printf("\n Module Name(mod_name): [%s]\n", mod_namedup);
										printf("\n Module Description(mod_desc): [%s]\n", mod_descdup);
										
                                        ITK_CALL(GRM_find_relation_type("T5_Submdlbmodsubrel",&ModToSubModRel));
										if(ModToSubModRel!=NULLTAG)
										{									
											printf("\n Sudo Folder SubModule Details(T5_Submdlbmodsubrel) Relation Found..!!\n");fflush(stdout);
											ITK_CALL(GRM_list_secondary_objects_only(ModRev_tag, ModToSubModRel, &sec_countsubmod, &sec_submodobjects));
											printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countsubmod);
											if(sec_countsubmod > 0)
											{
												for(l = 0; l < sec_countsubmod; l++)
												{
													char* submod_no = NULL;
	                                                char* submod_nodup = NULL;
													char* submod_name = NULL;
													char* submod_namedup = NULL;
													char* submod_desc = NULL;
													char* submod_descdup = NULL;
													char* submod_address = NULL;
													char* submod_addressdup = NULL;
	
													SubModRev_tag = sec_submodobjects[l];
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"item_id",&submod_no));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_name",&submod_name));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_desc",&submod_desc));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"t5_ModuleAddrSL",&submod_address));
													trimwhitespace(submod_no);
													trimwhitespace(submod_name);
													trimwhitespace(submod_desc);
													trimwhitespace(submod_address);
													if(submod_no!=NULL)tc_strdup(submod_no,&submod_nodup);
													if(submod_name!=NULL)tc_strdup(submod_name,&submod_namedup);
													if(submod_desc!=NULL)tc_strdup(submod_desc,&submod_descdup);
													if(submod_address!=NULL)tc_strdup(submod_address,&submod_addressdup);
													printf("\n SubModule No(submod_nodup): [%s]\n", submod_nodup);
													printf("\n SubModule Name(submod_namedup): [%s]\n", submod_namedup);
													printf("\n SubModule Description(submod_descdup): [%s]\n", submod_descdup);
													printf("\n Module Address(submod_addressdup): [%s]\n", submod_addressdup);
													
													ITK_CALL(AOM_ask_table_rows(SubModRev_tag,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
													printf("\n No of Table Row: [%d]  For SubModule:  [%s]\n", n_valid_rows, submod_nodup);fflush(stdout);
													if(n_valid_rows>0)
													{
														for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
														{
															char* Tbl_SubModNo = NULL;
															char* Tbl_SubModNodup = NULL;
															char* Tbl_SubModRev = NULL;
															char* Tbl_SubModRevdup = NULL;
															char* Tbl_SubModSeq = NULL;
															char* Tbl_SubModSeqdup = NULL;
															char* Tbl_SubModDesc = NULL;
															char* Tbl_SubModDescdup = NULL;
															char* Tbl_SubModProd = NULL;
															char* Tbl_SubModProddup = NULL;
															char* Tbl_SubModPlat = NULL;
															char* Tbl_SubModPlatdup = NULL;
															char* Tbl_SubModProj = NULL;
	                                                        char* Tbl_SubModProjdup = NULL;
															char* Tbl_SubModDRAR = NULL;
	                                                        char* Tbl_SubModDRARdup = NULL;
															char* Veh_LinkStatus = NULL;
															
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));	
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_rev",&Tbl_SubModRev));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_seq",&Tbl_SubModSeq));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_desc",&Tbl_SubModDesc));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_Platform",&Tbl_SubModPlat));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_projectcode",&Tbl_SubModProj));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",&Tbl_SubModDRAR));
															
															trimwhitespace(Tbl_SubModNo);
															trimwhitespace(Tbl_SubModRev);
															trimwhitespace(Tbl_SubModSeq);
															trimwhitespace(Tbl_SubModDesc);
				                                            printf("\n SubModule Description Value Before Dup & Trim: --------> <%s>", Tbl_SubModDesc);fflush(stdout);
															STRNG_replace_str(Tbl_SubModDesc,","," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,";"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"\n"," ",&Tbl_SubModDesc);
															trimwhitespace(Tbl_SubModProd);
															trimwhitespace(Tbl_SubModPlat);
															trimwhitespace(Tbl_SubModProj);
															trimwhitespace(Tbl_SubModDRAR);
													        if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
															if(Tbl_SubModRev!=NULL)tc_strdup(Tbl_SubModRev,&Tbl_SubModRevdup);
															if(Tbl_SubModSeq!=NULL)tc_strdup(Tbl_SubModSeq,&Tbl_SubModSeqdup);
															if(Tbl_SubModDesc!=NULL)tc_strdup(Tbl_SubModDesc,&Tbl_SubModDescdup);
															if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
															if(Tbl_SubModPlat!=NULL)tc_strdup(Tbl_SubModPlat,&Tbl_SubModPlatdup);
															if(Tbl_SubModProj!=NULL)tc_strdup(Tbl_SubModProj,&Tbl_SubModProjdup);
															if(Tbl_SubModDRAR!=NULL)tc_strdup(Tbl_SubModDRAR,&Tbl_SubModDRARdup);
													        printf("\n Table SubModule No(Tbl_SubModNodup): [%s]\n", Tbl_SubModNodup);
															printf("\n Table SubModule Rev(Tbl_SubModRevdup): [%s]",Tbl_SubModRevdup);fflush(stdout);
															printf("\n Table SubModule Seq(Tbl_SubModSeqdup): [%s]",Tbl_SubModSeqdup);fflush(stdout);
															printf("\n Table SubModule Description(Tbl_SubModDescdup): [%s]",Tbl_SubModDescdup);fflush(stdout);
															printf("\n Table SubModule Peoductline(Tbl_SubModProddup): [%s]",Tbl_SubModProddup);fflush(stdout);
															printf("\n Table SubModule Platform(Tbl_SubModPlatdup): [%s]",Tbl_SubModPlatdup);fflush(stdout);
															printf("\n Table SubModule Project Code(Tbl_SubModProjdup): [%s]",Tbl_SubModProjdup);fflush(stdout);
															printf("\n Table SubModule DR/AR(Tbl_SubModDRARdup): [%s]",Tbl_SubModDRARdup);fflush(stdout);
															
															
															printf("\n Function1: Vehicle Link Status Find Start..!!\n");fflush(stdout);
															tc_strcpy(Tbl_SubModRevSeq,Tbl_SubModRevdup);
															tc_strcat(Tbl_SubModRevSeq,"*");
															tc_strcat(Tbl_SubModRevSeq,Tbl_SubModSeqdup);
															printf("SubModule RevSeq: [%s] \n", Tbl_SubModRevSeq);fflush(stdout);
															Veh_LinkStatus = TC_VehLinkStatus(Tbl_SubModNodup,Tbl_SubModRevSeq);
															printf("\n Part Attached with Vehicle[Vehicle Link Status]: [%s]", Veh_LinkStatus);fflush(stdout);
															printf("\n Function1: Vehicle Link Status Find End..!!\n");fflush(stdout);
															
															fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s\n",Tbl_SubModNodup,Tbl_SubModRevdup,Tbl_SubModSeqdup,Tbl_SubModDescdup,Tbl_SubModProddup,Tbl_SubModPlatdup,Tbl_SubModProjdup,Tbl_SubModDRARdup,Veh_LinkStatus);fflush(fpOutput_file);
															
														}
													}
													else
													{
														printf("\n No Table Row Found For Input SubModule: [%s], submod_nodup\n");fflush(stdout);
													} 
												}
											}
											else
											{
												printf("\n SubModule Not Found For Module: [%s]\n", mod_nodup);fflush(stdout);
											}
										}
										else
										{
											printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
										}										
									}
								}
								else
								{
									printf("\n Module Not Found For Aggregate: [%s]\n", aggr_nodup);fflush(stdout);
								}
							}
							else
							{
								printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Aggregate Not Found For Aggregate Group: [%s]\n", aggrgrp_nodup);fflush(stdout);
					}
				}
				else
				{
					printf("\n Aggregate Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
				}
			}			
		}
		else
        {
			printf(" Aggregate Group Found Zero[0] on SubModuleLibraryAggrGrp..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" SubModule Aggregate Group Tag Not Found..!!\n");fflush(stdout);
    }
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
	CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_SubModuleVehLink.c
* // ./linkitk -o tm_SubModuleVehLink tm_SubModuleVehLink.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/SubModuleLinkVehicle/tm_SubModuleVehLink .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/SubModuleLinkVehicle/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/SubModuleLinkVehicle/usage.txt .
* // ./tm_SubModuleVehLink -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_SubModuleVehLink -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_SubModuleVehLink -u=infodba -p=infodba123 -g=dba
*
***************************************************************************/