/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Part & Print Duplicate Dataset Attached with it Where Object Type - CMI2CacheCgr 
*  File Name    :   tm_duplicate_cgr.c
*  Created on   :   April 06th, 2023
*  Usage        :   tm_duplicate_cgr
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     06/04/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

void trimLeading(char * str)
{
    int index, i, j;
    index = 0;
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }
    if(index != 0)
    {
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; 
    }
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	FILE* fpPart_List = NULL;
	char* Part_Id_Str = NULL;
	int n_itemobj_found = 0;
	char* Rev_Id = NULL;
	char* Rev_Seq = NULL;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[300]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	int no_ref = 0;
	int j =0;
	time_t	temptime;
	char GenDate[20];
	struct tm *timeptr;
	int ch;
	char *RptFile= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	int nitem_revision = 0;
	tag_t* tRev_list = NULLTAG;
	tag_t tRelationType = NULLTAG;
	tag_t* tSecObjectList = NULLTAG;
	int iSec_ObjCount = 0;
	char* SecObjType = NULL;
	char* SecObjString = NULL;
	char* DesString= (char *) malloc(400*sizeof(char));
	char* DesStringDup = NULL;
	
	printf("\n Generating Curernt Time Stamp");fflush(stdout);
	temptime = time(NULL);
	tc_strcpy(GenDate,"");
	timeptr = (struct tm *)localtime(&temptime);
	ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"CacheCgr_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 1)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			ITK_CALL(ITK_auto_login());
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			fpPart_List = fopen("PartList.txt","r");
			fpOutput_file = fopen(RptFile, "w");
            fprintf(fpOutput_file,"\n TC Part, Revision, Type");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Log File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			if(fpPart_List != NULL)
		    {	
			    printf("\n Part List is Not Null Moving Forward...");fflush(stdout);
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					Part_Id_Str=strtok(temp,",");
					printf("\n Part No --------> %s", Part_Id_Str);fflush(stdout);
					ITK_CALL(ITEM_find_item(Part_Id_Str, &tItemobj));
		            printf("\n Return Value From Item Found API is : %d", iFail);
					printf("\n Item Found Successfully...");fflush(stdout);
                    if(tItemobj!=NULLTAG)
			        {
							ITK_CALL(ITEM_list_all_revs(tItemobj, &nitem_revision, &tRev_list));
							printf("\n Return Value From Item Revision Found API is --------> %d", iFail);fflush(stdout);
							printf("\n No of Item Revision Found --------> %d\n",nitem_revision);fflush(stdout);
							for (i = 0; i < nitem_revision; i++)
		                    {
								ITK_CALL(AOM_ask_value_string( tRev_list[i], "item_id", &Rev_Id));
								ITK_CALL(AOM_ask_value_string( tRev_list[i], "item_revision_id", &Rev_Seq));
								printf("\n Item Revision ID --------> %s", Rev_Id);fflush(stdout);
								printf("\n Item Revision & Sequence --------> %s", Rev_Seq);fflush(stdout);
								tc_strcpy(DesString," ");
	                            tc_strcat(DesString,Rev_Id);
	                            tc_strcat(DesString,".");
	                            tc_strcat(DesString,"cgr");
                    
								if(tc_strlen(DesString)>0)
								{
								   tc_strdup(DesString,&DesStringDup);
								   printf("\n Desired Concatinated Value --------> %s\n", DesStringDup);fflush(stdout);
								}
								else
								{
								   tc_strdup("",&DesStringDup);
								   printf("\n Desired Concatinated Value is NULL \n");fflush(stdout);
								}
								trimLeading(DesStringDup);
								printf("\n Desired Concatinated Value After Trim --------> %s\n", DesStringDup);fflush(stdout);
								ITK_CALL(GRM_find_relation_type("IMAN_specification", &tRelationType));
		                        printf("\n Return Value From Relation Type Tag API is : %d", iFail);fflush(stdout);
		                        ITK_CALL(GRM_list_secondary_objects_only(tRev_list[i], tRelationType, &iSec_ObjCount, &tSecObjectList));
		                        printf("\n Return Value From List of Secondary Objects Tag API is : %d", iFail);fflush(stdout);
		                        printf("\n No of Secondary Objects Attached with Item Revision --------> %d\n",iSec_ObjCount);fflush(stdout);
								if(iSec_ObjCount>0)
					            {
									for (j = 0; j < iSec_ObjCount; j++)
									{
										ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_type", &SecObjType));
										printf("\n Return Value From Object Type API is : %d", iFail);fflush(stdout);
										printf("\n Secondary Object Original Type --------> %s", SecObjType);fflush(stdout);
										ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_string", &SecObjString));
										printf("\n Secondary Object Original Value --------> %s", SecObjString);fflush(stdout);
										printf("\n Desired Concatinated Value --------> %s", DesStringDup);fflush(stdout);
										if(tc_strcmp(SecObjType,"CMI2CacheCgr") == 0 && tc_strcmp(SecObjString,DesStringDup) == 0)
										{
											printf("\n Dataset Type Matched So Printing on Report");fflush(stdout);
											printf("\n TC Part ---> %s,Revision ---> %s,Type ---> %s\n",Rev_Id,Rev_Seq,SecObjType);fflush(stdout);
								            fprintf(fpOutput_file,"\n %s,%s,%s",Rev_Id,Rev_Seq,SecObjType);fflush(fpOutput_file);
										}
										else
										{
											printf("\n Comparision Not Happen...\n");fflush(stdout);
										}
									}
								}
							    
		                    }
			        }
					else
					{
						printf("\n After Query Execution No Item Found...");fflush(stdout);
						continue;
					}
					if (tRev_list)
					{
						MEM_free(tRev_list);
					}
					if (tSecObjectList)
					{
						MEM_free(tSecObjectList);
					}					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n All Part Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout); 
				fclose(fpOutput_file) ;           
				printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
				printf("\n Output File Closed Now\n");fflush(stdout); 
			}
			else 
			{
				printf("\n Part Listt is Null....");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if(tItemobj!=NULLTAG)
			{

				tc_strcpy(env_subject,"SUCCESS: MAIL FROM CVPROD DATASET REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    Please Check Attached Report");
				tc_strcat(env_body,"\n                    Total Dataset Count: ");
				tc_strcat(env_body," 2278\n\n\n");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			else
			{
				tc_strcpy(env_subject,"FAILED: MAIL FROM CVPROD DATASET REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    There is an Issue in Dataset report Creation ");
				tc_strcat(env_body,"\n\n                  Please Check Log & Support user");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			
			printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);
			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}


