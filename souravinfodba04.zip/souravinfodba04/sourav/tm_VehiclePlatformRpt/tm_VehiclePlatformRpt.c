/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Vehicle & Print its Properties on Reports  
*  File Name    :   tm_VehiclePlatformRpt.c
*  Created on   :   Nov 8th, 2023
*  Usage        :   tm_VehiclePlatformRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     08/11/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	FILE *fpPart_List = NULL;
	int i = 0;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t DesRev_tag = NULLTAG;
	char *veh_no_str = NULL;
	char *veh_no_strDup = NULL;
	char *veh_revseq_str = NULL;
	char *veh_revseq_strDup = NULL;
	char *ProjCode = NULL;
	char *ProjCodeDup = NULL;
	char *DesGrp = NULL;
	char *DesGrpDup = NULL;
	char *ExstPlatform = NULL;
	char *ExstPlatformDup = NULL;
	char *ReqdPlatform = (char *) malloc(400*sizeof(char));
	char *ReqdPlatformDup = NULL;
	char *resstatus = (char *) malloc(400*sizeof(char));
	char *Input_File = (char *) malloc(400*sizeof(char));
	char *item_prjcdup = (char *) malloc(400*sizeof(char));
	tag_t tCtrlobj = NULLTAG;
    tag_t* tctrlobj_results = NULLTAG;
	int c_entries = 2;
	int n_ctrlobj_found = 0;
	tag_t PropName_AttrID = NULLTAG;
	char *item_propvalue_str = NULL;
	char *item_propvalue_strDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"SubModule_Details_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");
	
    fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ V E H I C L E   D E T A I L S   R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
    fprintf(fpOutput_file,"VEH_NO, REV_SEQ, PROJECT_CODE, DESIGN_GROUP, EXISTING_PLATFORM, REQUIRED_PLATFORM, STATUS, UPDATED_INPUT_FILE\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			veh_no_str=strtok(Buffer,"^");
			veh_revseq_str=strtok(NULL,"^");
			
			if(veh_no_str!=NULL)tc_strdup(veh_no_str,&veh_no_strDup);
			if(veh_revseq_str!=NULL)tc_strdup(veh_revseq_str,&veh_revseq_strDup);
			
			if(veh_no_strDup!=NULL)trimwhitespace(veh_no_strDup);
			if(veh_revseq_strDup!=NULL)trimwhitespace(veh_revseq_strDup);
			
			printf("\n Vehicle No(veh_no_strDup): [%s]\n",veh_no_strDup);
			printf("\n Vehicle Rev_Seq(veh_revseq_strDup): [%s]\n",veh_revseq_strDup);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {veh_revseq_strDup,veh_no_strDup};
				//char *cValues[2]  = {"A;2","51780353R"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						DesRev_tag = titemobj_results[i];
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ProjectCode",&ProjCode));
						if(tc_strlen(ProjCode)>0)
						{
							tc_strdup(ProjCode,&ProjCodeDup);
						}
						else
						{
							tc_strdup("--",&ProjCodeDup);
							printf("\n Project Code Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_DesignGrp",&DesGrp));
						if(tc_strlen(DesGrp)>0)
						{
							tc_strdup(DesGrp,&DesGrpDup);
						}
						else
						{
							tc_strdup("--",&DesGrpDup);
							printf("\n Design Group Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Platform",&ExstPlatform));
						if(tc_strlen(ExstPlatform)>0)
						{
							tc_strdup(ExstPlatform,&ExstPlatformDup);
						}
						else
						{
							tc_strdup("--",&ExstPlatformDup);
							printf("\n Existing Platform Value is NULL..!!");fflush(stdout);
						}
						
						if(tc_strlen(ProjCodeDup)>0)
						{
							
							tc_strcpy(item_prjcdup,"*");
	                        tc_strcat(item_prjcdup,ProjCodeDup);
	                        tc_strcat(item_prjcdup,"*");
	                        printf(" Final: Part_Project_Code Value(item_prjcdup): [%s]\n",item_prjcdup);
							ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
							if(tCtrlobj!=NULLTAG)
							{
								printf("\n Control Objects... Query Found Successfully..!!\n");
								char *pEntries[2]  = {"SYSCD","Information-2"};
								char *pValues[2]  = {"PartPlatform",item_prjcdup};
								ITK_CALL(QRY_execute(tCtrlobj, c_entries, pEntries, pValues, &n_ctrlobj_found, &tctrlobj_results));
								printf("\n No of Control Object Found: [%d]\n",n_ctrlobj_found);fflush(stdout);
								if(n_ctrlobj_found>0)
								{
									printf("\n Control Object Found Against Input Project Code..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(tctrlobj_results[0],"t5_SubSyscd",&ReqdPlatform));
									if(tc_strlen(ReqdPlatform)>0)
									{
										tc_strdup(ReqdPlatform,&ReqdPlatformDup);
									}
									else
									{
										printf("\n Platform(t5_SubSyscd) Value is NULL..!!");fflush(stdout);
										tc_strdup("--",&ReqdPlatformDup);
							            printf("\n Required Platform Value is NULL..!!");fflush(stdout);
									}
								}
								else
								{
									tc_strdup("Ctrl_Obj_Not_Present",&ReqdPlatformDup);
							        printf("\n Required Control Object Not Present..!!");fflush(stdout);
								}
							}
							else
							{
								tc_strdup("Ctrl_Obj_Not_Present",&ReqdPlatformDup);
								printf("\n Required Control Object Not Present..!!");fflush(stdout);
							}
						}
						else
						{
							tc_strdup("--",&ReqdPlatformDup);
							printf("\n Project Code Value is NULL..!!");fflush(stdout);
						}
						if(tc_strcmp(ExstPlatformDup,ReqdPlatformDup) == 0)
						{
							tc_strcpy(resstatus,"OK");
						}
						else
						{
							tc_strcpy(resstatus,"Not_OK");
						}
						if(tc_strcmp(resstatus,"Not_OK") == 0)
						{
							tc_strcpy(Input_File,veh_no_strDup);
							tc_strcat(Input_File,"^");
							tc_strcat(Input_File,veh_revseq_strDup);
							tc_strcat(Input_File,"^");
							tc_strcat(Input_File,"t5_Platform");
							tc_strcat(Input_File,"^");
							tc_strcat(Input_File,ReqdPlatformDup);
							tc_strcat(Input_File,"^");
						}
						else
						{
							tc_strcpy(Input_File,"OK");
						}
						printf(" Vehicle Details Start...!!\n");fflush(stdout);
						printf("[1] Vehicle_No: [%s]\n",veh_no_strDup);fflush(stdout);
						printf("[2] Vehicle_Rev&Seq: [%s]\n",veh_revseq_strDup);fflush(stdout);
						printf("[3] Project_Code: [%s]\n",ProjCodeDup);fflush(stdout);
						printf("[4] Design_Group: [%s]\n",DesGrpDup);fflush(stdout);
						printf("[5] Existing_Platform: [%s]\n",ExstPlatformDup);fflush(stdout);
						printf("[6] Required_Platform: [%s]\n",ReqdPlatformDup);fflush(stdout);
						printf("[7] Status: [%s]\n",resstatus);fflush(stdout);
						printf("[8] Input_File: [%s]\n",Input_File);fflush(stdout);
						printf(" Vehicle Details End...!!\n");fflush(stdout);
						
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s\n",veh_no_strDup,veh_revseq_strDup,ProjCodeDup,DesGrpDup,ExstPlatformDup,ReqdPlatformDup,resstatus,Input_File);fflush(fpOutput_file);
					}
				}
				else
                {
					printf(" DesignRevision Not Found..!!\n");fflush(stdout);
				}
			}
			else
            {
				printf(" DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
		    }
			if(titemobj_results)
			{
				MEM_free(titemobj_results);
			}
		}
		fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
		fclose(fpOutput_file) ;           
		printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_VehiclePlatformRpt.c
* // ./linkitk -o tm_VehiclePlatformRpt tm_VehiclePlatformRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehiclePlatformRpt/tm_VehiclePlatformRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehiclePlatformRpt/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehiclePlatformRpt/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehiclePlatformRpt/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_VehiclePlatformRpt/SendEmail.sh .
* // ./tm_VehiclePlatformRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_VehiclePlatformRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/