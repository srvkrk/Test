/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   
*  Description  :   String API Testing Code 
*  File Name    :   tm_stringapi.c
*  Created on   :   Aug 1st, 2023
*  Usage        :   tm_stringapi
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     01/08/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int TC_PartSrch(char* PNSrch)
{
	int iFail = 0;
	tag_t* tItem_results = NULLTAG;
	trimwhitespace(PNSrch);
	printf("\n Searched Part Number Value After Trim --------> %s\n", PNSrch);fflush(stdout);
	tag_t tPartobj = NULLTAG;
	ITK_CALL(QRY_find2("Item ID",&tPartobj));
	printf("\n Return Value From ItemRev Query API is --------> %d", iFail);fflush(stdout);
    if(tPartobj != NULLTAG)
	{
		printf("\n ItemID Query Found Successfully...");fflush(stdout);
		int n_entrie = 1;
		char *cQry_entry[1] = {"Item ID"};
		char *cQry_values[1] = {PNSrch};
		//char *cQry_values[1] = {"5137D1D0270001_WE"};
	    int nItem_found = 0;
	    ITK_CALL(QRY_execute(tPartobj, n_entrie, cQry_entry, cQry_values, &nItem_found, &tItem_results));
		printf("\n Return Value From ItemRev Query Execute API is --------> %d", iFail);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Part Found --------> %d\n",nItem_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nItem_found > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		printf("\n Sorry!! Query Tag Not Found...");fflush(stdout);
	}
	if (tItem_results)
    {
		MEM_free(tItem_results);
	}			
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -pno=<Part Number 10 Digit> (Required)\n"
        );	
}	

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char* PartNumberTen = NULL;
	char* PartNumberTenDup = NULL;
	char* DesStr = NULL;
	DesStr = (char *) MEM_alloc(20*sizeof(char ));
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 4)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			printf("\nUsername --------> %s", cUSERID);fflush(stdout);
			printf("\nPassword --------> %s", cPASS);fflush(stdout);
			printf("\nGroup --------> %s", cGroup);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&cUSERID, &tuser);
				printf("\nLogged in Username --------> %s", cUSERID);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			printf("\n!!!!!!!!! S T R I N G   A P I   T E S T I N G   S T A R T !!!!!!!!!!!");fflush(stdout);
			tc_strcpy(DesStr,"TEAMCENTER");
			printf("\nDestination String --------> [%s]", DesStr);fflush(stdout);
			if(tc_strlen(PartNumberTen)< 1)
	        {
		        print_requirement();
		        return iFail;
	        }
			
			
			if(tc_strlen(PartNumberTen)>0)
		    {
			   tc_strdup(PartNumberTen,&PartNumberTenDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&PartNumberTenDup);
			   printf("\n Part No Value is NULL");fflush(stdout);
		    }
            trimwhitespace(PartNumberTenDup);
			tc_strcpy(PartNo,PartNumberTenDup);
	        tc_strcat(PartNo,"*");
			printf("\n Final Part Number After Trim Concat & Dup --------> %s", PartNo);fflush(stdout);
			tag_t tItemobj = NULLTAG;			
			ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
			printf("\n Return Value From Item Revision Query API is --------> %d", iFail);fflush(stdout);
			if(tItemobj!=NULLTAG)
			{
			    printf("\n Item Revision... Query Found Successfully");fflush(stdout);
				int n_entries = 2;
				char *cEntries[2] = {"Item ID","Type"};
                char *cValues[2] = {PartNo,"Design Revision"};
				int num_to_sort = 1;
				//char *keys[1] = {"object_name"};
				char *keys[1] = {"creation_date"};
				int orders[1] = {2};
				int n_itemobj_found = 0;
				tag_t* titemobj_results = NULLTAG;
				
				ITK_CALL(QRY_execute_with_sort(tItemobj, n_entries, cEntries, cValues, num_to_sort, keys, orders, &n_itemobj_found, &titemobj_results));
                printf("\n Return Value From Query Execute with Sort API is --------> %d", iFail);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n Total Parts Found --------> %d\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				char* DescPartNo = NULL;
				char* cFstNo = NULL;
				char* cSrNo = NULL;
                if(n_itemobj_found>0)
				{
					ITK_CALL(AOM_ask_value_string(titemobj_results[0], "item_id", &DescPartNo));
					printf("\n DESC Order Part No[First] --------> %s", DescPartNo);fflush(stdout);
					cFstNo=subString(DescPartNo,0,9);
					printf("\n First Ten Digit After Substring --------> %s", cFstNo);fflush(stdout);
					cSrNo=subString(DescPartNo,9,3);
					printf("\n Last Two Digit After Substring --------> %s", cSrNo);fflush(stdout);
					int cStart,counter = 0;
					cStart = atoi(cSrNo);
					char* PartNoSrch = NULL;
	                PartNoSrch = (char *) MEM_alloc(20*sizeof(char ));
					tc_strcpy(PartNoSrch,cFstNo);
					printf("\n Part No Value Without Last Two Digit --------> %s", PartNoSrch);fflush(stdout);
					char* vsr = NULL;
					vsr = (char *) MEM_alloc(20*sizeof(char ));
					char* FinalPartNoSrch = NULL;
	                FinalPartNoSrch = (char *) MEM_alloc(20*sizeof(char ));
					int RStatus = 0; 
					for(counter=(cStart+1);counter<=999;counter++)
		            {
						if(counter<10)
						{
							printf("\n Before sprintf Less Than Ten");fflush(stdout);
							sprintf(vsr,"%d",counter);
							tc_strcpy(FinalPartNoSrch,PartNoSrch);
							tc_strcat(FinalPartNoSrch,"00");
							tc_strcat(FinalPartNoSrch,vsr);
                            printf("\n After sprintf Less Than Ten");fflush(stdout);							
						}
						else if((counter>9) && (counter<100))
						{
							printf("\n Before sprintf Less Than Ten");fflush(stdout);
							sprintf(vsr,"%d",counter);
							tc_strcpy(FinalPartNoSrch,PartNoSrch);
							tc_strcat(FinalPartNoSrch,"0");
							tc_strcat(FinalPartNoSrch,vsr);
                            printf("\n After sprintf Less Than Ten");fflush(stdout);							
						}
						else
						{
						  printf("\n Before sprintf Greater Than Ten");fflush(stdout);
						  sprintf(vsr,"%d",counter);
						  tc_strcpy(FinalPartNoSrch,PartNoSrch);
						  tc_strcat(FinalPartNoSrch,vsr);
						  printf("\n After sprintf Greater Than Ten");fflush(stdout);
						}
						printf("\n Final Part No Value For Searching --------> %s", FinalPartNoSrch);fflush(stdout);
						printf("\n Part Search Function Call Start");fflush(stdout);
						RStatus = TC_PartSrch(FinalPartNoSrch);
						printf("\n Part Search Function Call End");fflush(stdout);
						if(RStatus == 1)
						{
							printf("\n Part No Already Exist So Continue...");fflush(stdout);
							continue;
						}
						if(RStatus == 0)
						{
							printf("\n Final Part No Received So Break...");fflush(stdout);
							break;
						}
					}
					printf("\n R E S P O N S E     S T R I N G");fflush(stdout);
					printf("\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");fflush(stdout);
					printf("\n Generated Part No --------> [%s]", FinalPartNoSrch);fflush(stdout);
					printf("\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");fflush(stdout);
				}
				else
	            {
		            printf("\n Sorry! No Item Found in Query with Sort\n");fflush(stdout);
	            }
			}
			else
	        {
		        printf("\n Sorry! Item Revision Query Tag Not Found\n");fflush(stdout);
	        }
			
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}