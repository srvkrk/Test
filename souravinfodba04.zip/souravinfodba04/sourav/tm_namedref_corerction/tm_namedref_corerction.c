/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Name Reference Correction For CATIA - Dataset
*  File Name    :   tm_namedref_corerction.c
*  Created on   :   July 21st, 2023
*  Usage        :   tm_namedref_corerction
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     21/07/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}
		return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	int j = 0;
	char* cError = NULL;
	char* username = NULL;
	FILE* fpPart_List = NULL;
	char* DS_Id_Str = NULL;
	char* PartNo = NULL;
	char* Rev = NULL;
	char* Seq = NULL;
	int n_entries = 1;
	int n_itemobj_found = 0;
	char* Itemid = NULL;
	char* RevSeqid = NULL;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;
	tag_t* titemobj_results = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[900]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	char* RptString= (char *) MEM_alloc(400*sizeof(char));
	char* RptStringDup = NULL;
	tag_t trel_type = NULLTAG;
	int n_attchs = 0;
	tag_t* tsec_obj_list = NULLTAG;
	char* csecobj_type = NULL;
	char* csecobj_id_string = NULL;
	tag_t tnewrel_type = NULLTAG;
	tag_t tfindnew_rel = NULLTAG;
	tag_t trevds_relation = NULLTAG;
	char* RptFile= (char *) MEM_alloc(400*sizeof(char));
	FILE* fpOutput_file = NULL;
	
	printf("\n Generating New Time Stamp");fflush(stdout);
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n New Time Stamp Generated");fflush(stdout);
	
	printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"Not_Matched_Dataset_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 1)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			ITK_CALL(ITK_auto_login());
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Auto-Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			fpPart_List = fopen("DatasetList.txt","r");
			fpOutput_file = fopen(RptFile, "w");
            fprintf(fpOutput_file,"\n Dataset Name, Status");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Log File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			if(fpPart_List != NULL)
		    {	
			    printf("\n Dataset List is Not Null Moving Forward...");fflush(stdout);
				while(fgets(temp, 10000, fpPart_List)!= NULL)
				{
					DS_Id_Str=strtok(temp,",");
					printf("\n Dataset No --------> %s", DS_Id_Str);fflush(stdout);
					PartNo=strtok(DS_Id_Str, "_" );
                    Rev=strtok(NULL,"_");
                    Seq=strtok(NULL,"_");
					printf("\n Part No --------> %s", PartNo);fflush(stdout);
					printf("\n Revision --------> %s", Rev);fflush(stdout);
					printf("\n Sequence --------> %s", Seq);fflush(stdout);
					
					tc_strcpy(RptString," ");
	                tc_strcat(RptString,Rev);
	                tc_strcat(RptString,";");
	                tc_strcat(RptString,Seq);
                    
					if(tc_strlen(RptString)>0)
					{
					   tc_strdup(RptString,&RptStringDup);
					   printf("\n Concatinated Rev & Seq String Dup Value --------> %s\n", RptStringDup);
					}
					else
					{
					   tc_strdup("",&RptStringDup);
					   printf("\n Concatinated Rev & Seq String Dup Value is NULL \n");
					}
					printf("\n Final Concatinated Rev & Seq String --------> %s", RptString);fflush(stdout);

                    ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
			        printf("\n Return Value From Item Revision Query API is --------> %d", iFail);fflush(stdout);

                    if(tItemobj!=NULLTAG)
			        {
					   printf("\n Item Revision Query Found Successfully...");fflush(stdout);
					   char *cEntries[1]  = {"Item ID"};
					   char *cValues[1]  = {PartNo};
					   ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
					   printf("\n Return Value From Item Revision Query Execute API is --------> %d", iFail);fflush(stdout);
					   printf("\n -----------------------------------------------\n");fflush(stdout);
					   printf("\n No of Item Revision Found --------> %d\n",n_itemobj_found);fflush(stdout);
					   printf("\n -----------------------------------------------\n");fflush(stdout);
					   ITK_CALL(GRM_find_relation_type("IMAN_specification", &trel_type));
					   printf("\n Return Value From Existing Relation Type Find API is --------> %d", iFail);fflush(stdout);
					   ITK_CALL(GRM_find_relation_type("IMAN_reference",&tnewrel_type));
					   printf("\n Return Value From Target Relation Type Find API is --------> %d", iFail);fflush(stdout);
					   if(n_itemobj_found>0)
					    {
							for (i = 0; i < n_itemobj_found; i++)
		                    {
								ITK_CALL(AOM_ask_value_string( titemobj_results[i], "item_id", &Itemid));
								ITK_CALL(AOM_ask_value_string( titemobj_results[i], "item_revision_id", &RevSeqid));
								printf("\n Current Item ID --------> %s,Current Revision & Sequence --------> %s, Report String --------> %s", Itemid, RevSeqid, RptStringDup);fflush(stdout);
								if(tc_strstr(RptStringDup,RevSeqid) != NULL)
					            {
									printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \n");fflush(stdout);
									printf("\n Matched Item ID --------> %s, Matched Item Revision & Sequence --------> %s \n", Itemid, RevSeqid);fflush(stdout);
									printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");fflush(stdout);
									if(trel_type != NULLTAG)
					                {

                                       ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], trel_type, &n_attchs, &tsec_obj_list));
									   printf("\n Return Value From Secondary Object List API is --------> %d", iFail);fflush(stdout);
						               printf("\n Total No of Secondary Object Attaches --------> %d\n", n_attchs);fflush(stdout);
									   if(n_attchs>0)
						                {
										    for (j = 0; j < n_attchs; j++)
		                                    {
											    ITK_CALL(WSOM_ask_object_id_string(tsec_obj_list[j], &csecobj_id_string));
											    ITK_CALL(WSOM_ask_object_type2(tsec_obj_list[j], &csecobj_type));
											    printf("\n Secondary Object ID --------> %s,Secondary Object Type --------> %s\n", csecobj_id_string, csecobj_type);fflush(stdout);
											    if((tc_strcmp(csecobj_type,"MSExcel") == 0) && (tc_strstr(csecobj_id_string, DS_Id_Str) != NULL))
					                            {
													printf("\n ~~~~~~~~~~~ YES TC PART & DS NAME MATCHES WITH REL IMAN_SPECIFICATION ~~~~~~~~~~~~\n");fflush(stdout);
													ITK_CALL(GRM_find_relation(titemobj_results[i], tsec_obj_list[j], trel_type ,&tfindnew_rel));
													printf("\n Return Value From Find Relation API is --------> %d", iFail);fflush(stdout);
													ITK_CALL(GRM_delete_relation(tfindnew_rel));
													printf("\n Return Value From Delete Relation Tag API is --------> %d", iFail);fflush(stdout);
													ITK_CALL(AOM_save(tfindnew_rel));
													printf("\n Return Value From Relation Save API is --------> %d", iFail);fflush(stdout);
													if(tnewrel_type != NULLTAG)
													{
														ITK_CALL(GRM_create_relation(titemobj_results[i], tsec_obj_list[j], tnewrel_type,  NULLTAG, &trevds_relation));
														printf("\n Return Value From Create Relation Tag API is --------> %d", iFail);fflush(stdout);
														ITK_CALL(GRM_save_relation(trevds_relation));
														printf("\n Return Value From Save Relation Tag API is --------> %d", iFail);fflush(stdout);
													}
											    }
										    }
									    }

									}
									
								}
		                    }

						}
						else
						{
							printf("\n After Query Execution No Dataset Found...");fflush(stdout);
						}
						if (titemobj_results)
						{
							MEM_free(titemobj_results);
						}
						if (csecobj_id_string)
						{
							MEM_free(csecobj_id_string);
						}
						if (csecobj_type)
						{
							MEM_free(csecobj_type);
						}
						if (tsec_obj_list)
						{
							MEM_free(tsec_obj_list);
						}
			        }					
	
				} 

				fclose(fpPart_List) ;           
				printf("\n All Dataset Read Successfully From The File....\n");fflush(stdout); 
				printf("\n Input File Closed Now\n");fflush(stdout); 
			}
			else 
			{
				printf("\n Dataset List is Null....");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if(n_itemobj_found > 0)
			{

				tc_strcpy(env_subject,"SUCCESS: MAIL FROM CVPROD DATASET REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    Please Check Attached Report");
				tc_strcat(env_body,"\n                    Total Dataset Count: ");
				tc_strcat(env_body," 2278\n\n\n");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			else
			{
				tc_strcpy(env_subject,"FAILED: MAIL FROM CVPROD DATASET REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    There is an Issue in Dataset report Creation ");
				tc_strcat(env_body,"\n\n                  Please Check Log & Support user");
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			
			printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);
			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}


