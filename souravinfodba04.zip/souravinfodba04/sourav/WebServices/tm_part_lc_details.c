/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   ITEM
*  Description  :   Part Property Details
*  File Name    :   tm_part_lc_details.c
*  Created on   :   May 24th, 2023
*  Usage        :   tm_part_lc_details
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     24/05/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is: ----> %s", cError);
		  exit(0);
		}

		return iFail;
}

void trimLeading(char * str)
{
    int index, i, j;
    index = 0;
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }
    if(index != 0)
    {
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; 
    }
}

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	//FILE* fpPart_List = NULL;
	//char* Part_Id_Str = NULL;
	//int iRev_Count = 0;
	//tag_t* tRevList = NULLTAG;
	tag_t tuser = NULLTAG;
	//tag_t tItemobj = NULLTAG;
	char temp[10000];
	char env_subject[300] = {'\0'};
    char env_body[300]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	//int no_ref = 0;
	//tag_t tBOMLine = NULLTAG;
	int j =0;
	time_t	temptime;
	char GenDate[20];
	struct tm *timeptr;
	int ch;
	char* RptFile= (char *) malloc(400*sizeof(char));
	FILE* fpOutput_file = NULL;
	//char* SysFile= (char *) malloc(400*sizeof(char));
	//FILE* fpSyslog_file = NULL;
	/* char* cLevel = NULL;
	char* cRev_Name = NULL;
	char* cItem_Id = NULL;
	char* cRevision = NULL;
	char* cParent = NULL;
	char* cOwn_Group = NULL;
	char* cOwn_User = NULL;
	char* cQuantity = NULL;
	char* cFind_No = NULL;
	char* cPacked = NULL;
	char* cDRAR = NULL;
	char* cPart_Type = NULL;
	tag_t* tBOM_Children = NULLTAG;
	int iNumber_Child = 0;
	tag_t tWindow = NULLTAG; */
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char* cItemID = NULL;
	char* ShellObject = NULL;
	char* responseString1 = NULL;
	responseString1=(char *)MEM_alloc(200);
	char* responseString2 = NULL;
	responseString2=(char *)MEM_alloc(200);
	char* responseString3 = NULL;
	responseString3=(char *)MEM_alloc(200);
	int n_tags_found = 0;
    int n_entries = 1;
	tag_t* tags_found = NULLTAG;
	tag_t rev_tags_found = NULLTAG;
	tag_t item_t = NULLTAG;
	size_t len;
	int	status_count = 0;
	tag_t*	relStatus_list = NULLTAG;
	char* latest_rev_Rel_Status = NULL;
	char* latest_rev_Rel_StatusDup = NULL;
	char* latest_rev_Part_Type = NULL;
	char* PrtShellCommandLine = NULL;
	PrtShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	char* dt_rlzd	=	NULL;
	char* dt_rlzdDup = NULL;
	
	
	printf("\n Generating Curernt Time Stamp");fflush(stdout);
	temptime = time(NULL);
	tc_strcpy(GenDate,"");
	timeptr = (struct tm *)localtime(&temptime);
	ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);

    printf("\n Generating Report File Name");fflush(stdout);
	tc_strcpy(RptFile,"TM_Part_LC_Details");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 5)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			cItemID = ITK_ask_cli_argument("-item=");
			printf("\nUsername --------> %s", cUSERID);fflush(stdout);
			printf("\nPassword --------> %s", cPASS);fflush(stdout);
			printf("\nGroup --------> %s", cGroup);fflush(stdout);
			printf("\nPartNo --------> %s", cItemID);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			//ITK_CALL(ITK_auto_login());
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");fflush(stdout);
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			
			//fpPart_List = fopen("PartList.txt","r");
			fpOutput_file = fopen(RptFile, "w");
			fprintf(fpOutput_file,"\n *******************************************************************************");fflush(stdout);
			fprintf(fpOutput_file,"\n **************** P A R T   P R O P E R T Y   D E T A I L S   R E P O R T ******************");fflush(stdout);
			fprintf(fpOutput_file,"\n *******************************************************************************");fflush(stdout);
            fprintf(fpOutput_file,"\n\n\n Part_No, LC_State, Part_Type, DateTime");fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Output File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			printf("\n Input Part Number: -------> %s", cItemID);fflush(stdout);
			if((cItemID != NULL) && (tc_strcmp(cItemID,"")!=0))
			{
				const char *attrs[1];
				const char *values[1];
				attrs[0] ="item_id";
				values[0] = (char *)cItemID;
				printf("\n Values[0]: -----> <%s> \n",values[0] );fflush(stdout);

				iFail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
				printf("\n No of Tag Found: -----> <%d> \n",n_tags_found );fflush(stdout);

				if(n_tags_found > 0)
				{
					item_t = tags_found[0];
					ITEM_ask_latest_rev(item_t, &rev_tags_found);
					if(rev_tags_found != NULLTAG)
					{	
						WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list);
						printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
						if(status_count>0)
						{
							int k = 0;
							for(k = 0; k<status_count; k++)
					        {
							  
							    AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_StatusDup);
							    printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
								
								if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsReview") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsWrkg") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0))
								{
							  
							        ITK_CALL(AOM_UIF_ask_value(relStatus_list[k],"date_released",&dt_rlzd));
							        printf(" \n Release Status Dtae Released String: ------> <%s>\n",dt_rlzd);fflush(stdout);
									if(tc_strlen(dt_rlzd)>0)
								    {
									   tc_strdup(dt_rlzd,&dt_rlzdDup);
									   tc_strdup(latest_rev_Rel_StatusDup,&latest_rev_Rel_Status);
									   printf("\n Date Released Value --------> %s\n", dt_rlzdDup);fflush(stdout);
									   printf("\n Latest_Rev_Rel_Status Value --------> %s\n", latest_rev_Rel_Status);fflush(stdout);
								    }
								    else
								    {
								       tc_strdup("",&dt_rlzdDup);
									   tc_strdup("",&latest_rev_Rel_Status);
								       printf("\n Date Released Value is NULL \n");fflush(stdout);
									   printf("\n Latest Rev Released Status Value is NULL \n");fflush(stdout);
								    }
								    trimLeading(dt_rlzdDup);
									trimLeading(latest_rev_Rel_Status);
								    printf("\n Date Released Value After Trim --------> %s\n", dt_rlzdDup);fflush(stdout);
									printf("\n Latest Rev Released Status Value After Trim --------> %s\n", latest_rev_Rel_Status);fflush(stdout);
								   
								    //AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_Status);
							        //printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_Status);fflush(stdout);
								}
								else
								{
									continue;
								}
							  
							}
                            
							printf("\n############################################\n");fflush(stdout);
							printf("\n Part Number: -----> <%s> \n",cItemID);fflush(stdout);
							printf("\n Latest ERC Date Released Value: ------> <%s> \n",dt_rlzdDup);fflush(stdout);
							printf("\n Latest Rev ERC Status Value: ------> <%s> \n",latest_rev_Rel_Status);fflush(stdout);
							printf("\n############################################\n");fflush(stdout);
							
							AOM_ask_value_string(rev_tags_found,"t5_PartType",&latest_rev_Part_Type);
							printf("\n Latest_Rev_Part_Type: ------> <%s> \n",latest_rev_Part_Type);fflush(stdout);
						
							tc_strcpy(responseString1,cItemID);
							
							if(tc_strlen(latest_rev_Rel_Status)>0)
							{
								if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsWrkg")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcWrkg")==0))
								{
								   tc_strcpy(responseString2,"IN_WORK");
								}
								else if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsReview")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcReview")==0))
								{
								   tc_strcpy(responseString2,"FROZEN");
								}
								else if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsRlzd")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcRlzd")==0))
								{
								   tc_strcpy(responseString2,"RELEASED");
								}
								else
								{
								   tc_strcpy(responseString2,"NULL");
								}
							}
							else
							{
								tc_strcpy(responseString2,"NULL");
							}
							

							
							if(tc_strlen(latest_rev_Part_Type)>0)
							{
								/* if(tc_strcmp(latest_rev_Part_Type,"A")==0)
								{
								   tc_strcpy(responseString3,"PhysicalProduct");
								}
								else if(tc_strcmp(latest_rev_Part_Type,"C")==0)
								{
								   tc_strcpy(responseString3,"PhysicalProduct");
								}
								else
								{
								   tc_strcpy(responseString3,"Drawing");
								} */
								tc_strcpy(responseString3,"PhysicalProduct");
							}
							else
							{
								tc_strcpy(responseString3,"NULL");
							}
							
							
							printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
							printf("\n Response String1:Part Number -----> <%s> \n",responseString1);fflush(stdout);
							printf("\n Response String2:Release Status -----> <%s> \n",responseString2);fflush(stdout);
							printf("\n Response String3:Part Type -----> <%s> \n",responseString3);fflush(stdout);
							printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
					        
							printf("\nData Print Start on Report File...");fflush(stdout);
							fprintf(fpOutput_file,"\n %s,%s,%s,%s",responseString1,responseString2,responseString3,GenDate);fflush(fpOutput_file);
							printf("\nData Print End on Report File...");fflush(stdout);
						}
						else
						{
						    printf("\nSorry! ERC Release Status Not Found on Latest Revision...");fflush(stdout);
						}
					}
					else
					{
						printf("\nSorry! Latest Revision Not Found...");fflush(stdout);
					}
				}
				else
				{
					printf("\nSorry! Entered Part Not Found in UAPROD...");fflush(stdout);
				}
			}
			else
			{
				printf("\nSorry! Input Part Number is Blank...");fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			if (relStatus_list)
			{
				MEM_free(relStatus_list);
			}
			if (tags_found)
			{
				MEM_free(tags_found);
			}
	        fclose(fpOutput_file) ;           
	        printf("\n Report File Closed Successfully\n");fflush(stdout);
			
			printf("\n Shell Calling STARTED...");fflush(stdout);
			//tc_strcpy(PrtShellCommandLine,"/user/tcuaadev/devgroups/sourav/JAR_Calling.sh");
			tc_strcpy(PrtShellCommandLine,"/user/testcmi/sourav/WebServices/JAR_Calling.sh");
			//tc_strcpy(PrtShellCommandLine,"/user/uaprodtrl/Sourav/tm_webservices/JAR_Calling.sh");
	        tc_strcat(PrtShellCommandLine," ");
	        tc_strcat(PrtShellCommandLine,responseString1);
	        tc_strcat(PrtShellCommandLine," ");
	        tc_strcat(PrtShellCommandLine,responseString2);
	        tc_strcat(PrtShellCommandLine," ");
	        tc_strcat(PrtShellCommandLine,responseString3);
	        printf("\n CommandLine: -------> %s",PrtShellCommandLine);fflush(stdout);
	        system(PrtShellCommandLine);
			printf("\n Shell Called Ended...");
			
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if(cItemID != NULL)
			{

				tc_strcpy(env_subject,"SUCCESS: MAIL FROM UAPROD PART DETAILS REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    Part Details Exe Called Successfully");
				tc_strcat(env_body,"\n\n                    Part Number");
		        tc_strcat(env_body,": ");
		        tc_strcat(env_body,responseString1);
				tc_strcat(env_body,"\n\n                    Lifecycle State");
		        tc_strcat(env_body,": ");
		        tc_strcat(env_body,responseString2);
				tc_strcat(env_body,"\n\n                    Part Type");
		        tc_strcat(env_body,": ");
		        tc_strcat(env_body,responseString3);
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			else
			{
				tc_strcpy(env_subject,"FAILED: MAIL FROM UAPROD PART DETAILS REPORT");
				tc_strcpy(env_body,"Dear All, \n\n ");
				tc_strcat(env_body,"\n\n                    There is an Issue in Part Details Exe Calling");
				tc_strcat(env_body,"\n\n                    Please Check Log & Support user");
				tc_strcat(env_body,"\n\n                    Part Number");
		        tc_strcat(env_body,": ");
		        tc_strcat(env_body,responseString1);
				tc_strcat(env_body,"\n\n                    Lifecycle State");
		        tc_strcat(env_body,": ");
		        tc_strcat(env_body,responseString2);
				tc_strcat(env_body,"\n\n                    Part Type");
		        tc_strcat(env_body,": ");
		        tc_strcat(env_body,responseString3);
				tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
				tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
			}
			
			printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);
			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"sandipb.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"ajinkyau.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"rajeshbasak.ttl@tatamotors.com"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"souravk.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}


