/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Part & Update Part Property(Part Type, Env Dimension, Weight, Material Class, Part Category, Material Drwing) 
*  File Name    :   tm_BOMCompUp.c
*  Created on   :   March 18th, 2024
*  Usage        :   tm_BOMCompUp
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     18/03/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc, char* argv[])
{
	char *message;
	char *loggedInUser = NULL;
	int i = 0;
	FILE* fpPart_List = NULL;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char* PNo_Str = NULL;
	char* PNo_StrDup = NULL;
	char* RevSeq_Str = NULL;
	char* RevSeq_StrDup = NULL;
	char* PartType_Str = NULL;
	char* PartType_StrDup = NULL;
	char* EnvDim_Str = NULL;
	char* EnvDim_StrDup = NULL;
	char* Wght_Str = NULL;
	char* Wght_StrDup = NULL;
	char* MatClass_Str = NULL;
	char* MatClass_StrDup = NULL;
	char* PartCat_Str = NULL;
	char* PartCat_StrDup = NULL;
	char* MatDrw_Str = NULL;
	char* MatDrw_StrDup = NULL;
	double dweight=0;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	tag_t DesRev_tag = NULLTAG;
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	//fpPart_List = fopen("/user/cvprod/sourav/BOMCompCV/PartList.txt","r");
	fpPart_List = fopen("/user/uaprodtrl/Sourav/BOMCompPV/PartList.txt","r");
	
	if(fpPart_List != NULL)
	{
		printf("\n Input_File Not Null..!!");fflush(stdout);
		printf("\n BOMCompleteness Attribute Details Update Start..!!\n");fflush(stdout); 
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			PNo_Str=strtok(Buffer,"^");
			RevSeq_Str=strtok(NULL,"^");
			PartType_Str=strtok(NULL,"^");
			EnvDim_Str=strtok(NULL,"^");
			Wght_Str=strtok(NULL,"^");
			MatClass_Str=strtok(NULL,"^");
			PartCat_Str=strtok(NULL,"^");
			MatDrw_Str=strtok(NULL,"^");
			
			if(PNo_Str!=NULL)tc_strdup(PNo_Str,&PNo_StrDup);
			if(RevSeq_Str!=NULL)tc_strdup(RevSeq_Str,&RevSeq_StrDup);
			if(PartType_Str!=NULL)tc_strdup(PartType_Str,&PartType_StrDup);
			if(EnvDim_Str!=NULL)tc_strdup(EnvDim_Str,&EnvDim_StrDup);
			if(Wght_Str!=NULL)tc_strdup(Wght_Str,&Wght_StrDup);
			if(MatClass_Str!=NULL)tc_strdup(MatClass_Str,&MatClass_StrDup);
			if(PartCat_Str!=NULL)tc_strdup(PartCat_Str,&PartCat_StrDup);
			if(MatDrw_Str!=NULL)tc_strdup(MatDrw_Str,&MatDrw_StrDup);		
			
			if(PNo_StrDup!=NULL)trimwhitespace(PNo_StrDup);
			if(RevSeq_StrDup!=NULL)trimwhitespace(RevSeq_StrDup);
			if(PartType_StrDup!=NULL)trimwhitespace(PartType_StrDup);
			if(EnvDim_StrDup!=NULL)trimwhitespace(EnvDim_StrDup);
			if(Wght_StrDup!=NULL)trimwhitespace(Wght_StrDup);
			if(MatClass_StrDup!=NULL)trimwhitespace(MatClass_StrDup);
			if(PartCat_StrDup!=NULL)trimwhitespace(PartCat_StrDup);
			if(MatDrw_StrDup!=NULL)trimwhitespace(MatDrw_StrDup);
			
			printf("\n Part Number(PNo_StrDup): [%s]", PNo_StrDup);fflush(stdout);
			printf("\n Part Revision & Sequence(RevSeq_StrDup): [%s]", RevSeq_StrDup);fflush(stdout);
			printf("\n Part Type(PartType_StrDup): [%s]", PartType_StrDup);fflush(stdout);
			printf("\n Envelope Dimension(EnvDim_StrDup): [%s]", EnvDim_StrDup);fflush(stdout);
			printf("\n Weight(Wght_StrDup): [%s]", Wght_StrDup);fflush(stdout);
			printf("\n Material Class(MatClass_StrDup): [%s]", MatClass_StrDup);fflush(stdout);
			printf("\n Part Category(PartCat_StrDup): [%s]", PartCat_StrDup);fflush(stdout);
			printf("\n Material in Drawing(MatDrw_StrDup): [%s]", MatDrw_StrDup);fflush(stdout);
			
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully...");fflush(stdout);
			    char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {RevSeq_StrDup,PNo_StrDup};
				//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						DesRev_tag = titemobj_results[i];
						ITK_CALL(AOM_lock(titemobj_results[i]));
						if(tc_strcmp(PartType_StrDup," ")!=0)
						{
							printf("\n Part Type Update Start..!!\n");fflush(stdout);
							ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_PartType",PartType_StrDup));
							printf("\n Part Type Update End..!!\n");fflush(stdout);
						}
						if(tc_strcmp(EnvDim_StrDup," ")!=0)
						{
							STRNG_replace_str(EnvDim_StrDup,"?"," ",&EnvDim_StrDup);
							STRNG_replace_str(EnvDim_StrDup,"\n"," ",&EnvDim_StrDup);
							printf("\n Envelope Dimension Update Start..!!\n");fflush(stdout);
							ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_EnvelopeDimensions",EnvDim_StrDup));
							printf("\n Envelope Dimension Update End..!!\n");fflush(stdout);
						}
						dweight=atof(Wght_StrDup);
						if(tc_strcmp(Wght_StrDup," ")!=0)
						{
							printf("\n Weight Update Start..!!\n");fflush(stdout);
							ITK_CALL(AOM_set_value_double(titemobj_results[i],"t5_Weight",dweight));
							printf("\n Weight Update End..!!\n");fflush(stdout);
						}
						if(tc_strcmp(MatClass_StrDup," ")!=0)
						{
							STRNG_replace_str(MatClass_StrDup,"?"," ",&MatClass_StrDup);
							STRNG_replace_str(MatClass_StrDup,"\n"," ",&MatClass_StrDup);
						    printf("\n Material Class Update Start..!!\n");fflush(stdout);
							ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_MatlClass",MatClass_StrDup));
						    printf("\n Material Class Update End..!!\n");fflush(stdout);
						}
						if(tc_strcmp(PartCat_StrDup," ")!=0)
						{
							STRNG_replace_str(PartCat_StrDup,"?"," ",&PartCat_StrDup);
							STRNG_replace_str(PartCat_StrDup,"\n"," ",&PartCat_StrDup);
							printf("\n Part Category Update Start..!!\n");fflush(stdout);
						    ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_SpareCriteria",PartCat_StrDup));
						    printf("\n Part Category Update End..!!\n");fflush(stdout);
						}
						if(tc_strcmp(MatDrw_StrDup," ")!=0)
						{
							STRNG_replace_str(MatDrw_StrDup,"?"," ",&MatDrw_StrDup);
							STRNG_replace_str(MatDrw_StrDup,"\n"," ",&MatDrw_StrDup);
							printf("\n Material Drawing Update Start..!!\n");fflush(stdout);
						    ITK_CALL(AOM_set_value_string(titemobj_results[i],"t5_Material",MatDrw_StrDup));
						    printf("\n Material Drawing Update End..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_save(titemobj_results[i]));
						ITK_CALL(AOM_unlock(titemobj_results[i]));
						ITK_CALL(AOM_refresh(titemobj_results[i],1));
					}
				}
				else
                {
					printf(" DesignRevision Not Found Continue..!!\n");fflush(stdout);
				}
			}
			else
            {
				printf(" DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
		    }
		}
        fclose(fpPart_List) ;           
		printf("\n Input File Closed....\n");fflush(stdout); 		
		printf("\n BOMCompleteness Attribute Details Update End..!!\n");fflush(stdout); 
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}

/***************************************************************************
*
* // ./compile tm_BOMCompUp.c
* // ./linkitk -o tm_BOMCompUp tm_BOMCompUp.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BOMCompletenessUpload/tm_BOMCompUp .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BOMCompletenessUpload/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BOMCompletenessUpload/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/BOMCompletenessUpload/usage.txt .
* // ./tm_BOMCompUp -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_BOMCompUp -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=ERC_Designers_Group
*
***************************************************************************/