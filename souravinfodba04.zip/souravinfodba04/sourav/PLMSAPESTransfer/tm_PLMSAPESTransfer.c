/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP EstimateSheet
*  Description  :   Query PSD Final Released EstimateSheet Revision & Transfer To SAP
*  File Name    :   tm_PLMSAPESTransfer.c
*  Created on   :   Apr 27th, 2024
*  Usage        :   tm_PLMSAPESTransfer
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     27/04/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *ESNo = NULL;
	char *ESNoNew = NULL;
	char *ESNoDup = NULL;
	char *PlantName = NULL;
	char *PlantNameDup = NULL;
	char *ESStatus = NULL;
	char *ESStatusDup = NULL;
	char *RptFile = (char *) malloc(30*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t PropName_AttrID = NULLTAG;
	char *ESStatusValueDup = (char *) malloc(50*sizeof(char));

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%Y%m%d_%H%M",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	printf("\n Generating Transfer Status Value..!!");fflush(stdout);
	tc_strcpy(ESStatusValueDup,GenDate);
	tc_strcat(ESStatusValueDup,"_HRS_SAP_JOB");
	printf("\n Transfer Status Value: [%s]", ESStatusValueDup);fflush(stdout);
	printf("\n Transfer Status Value Generated..!!");fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"ESList.lst");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);

	
	fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	ITK_CALL(QRY_find2("Estimate_Sheet_PLMSAP",&tItemobj));
    if(tItemobj != NULLTAG)
    {
		printf("\n Query [Estimate_Sheet_PLMSAP] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"Release_Status"};
		char *cValues[1]  = {"T5_PSDFinalReleased"};
		//char *cValues[1]  = {"T5_PSDFinalReleased"};
	    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of PSD Final Released EstimateSheet Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" PSD Final Released EstimateSheet Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&ESNo));
				if(tc_strlen(ESNo)>0)
				{
					tc_strdup(ESNo,&ESNoNew);
					ESNoDup=strtok(ESNoNew,"-");
				}
				else
				{
					printf("\n Estimate Sheet No is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PEPlantName",&PlantName));
				if(tc_strlen(PlantName)>0)
				{
					tc_strdup(PlantName,&PlantNameDup);
				}
				else
				{
					printf("\n Plant Name is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Design_Number",&ESStatus));
				if(tc_strlen(ESStatus)<1)
				{
					tc_strdup(ESStatus,&ESStatusDup);
				}
				else
				{
					printf("\n Estimate Sheet Already Transferred..!!");fflush(stdout);
				}
				printf("\n Estimate Sheet No(ESNoDup): [%s]\n",ESNoDup);fflush(stdout);
				printf("\n Plant Name(PlantNameDup): [%s]\n",PlantNameDup);fflush(stdout);
				printf("\n Transfer Status(ESStatusDup): [%s]\n",ESStatusDup);fflush(stdout);
				if((tc_strlen(ESNoDup) > 0) && (tc_strcmp(PlantNameDup,"CVBU JSR") == 0) && (tc_strlen(ESStatusDup) < 1))
				{
				   fprintf(fpOutput_file,"%s\n",ESNoDup);fflush(fpOutput_file);
				   printf("\n ~~~~~~~~ S T A T U S   U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);
				   if(tc_strcmp(ESStatusValueDup," ") !=0)
				    {  
						ITK_CALL(AOM_refresh(titemobj_results[i], POM_modify_lock));
						printf("\n Lock..!!\n");
						ITK_CALL(POM_attr_id_of_attr("t5_Design_Number", "DocumentRevision", &PropName_AttrID));
						printf("\n Property Name Tag Found..!!\n");
						ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], PropName_AttrID, ESStatusValueDup));
						printf("\n Set Property Value..!!\n");
						ITK_CALL(POM_save_instances(1, &titemobj_results[i], true));
						printf("\n Save...!!\n");
						ITK_CALL(AOM_refresh(titemobj_results[i], POM_no_lock));
						printf("\n Unlock..!!\n");
				    }
				    else
					{
						printf("\n Property Value NULL..!!");
					}
					printf("\n ~~~~~~~~ S T A T U S   U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
				}
				else
				{
					printf("\n Either ES No is Blank or PlantName is Not CVBU JSR or Transfer Status is Not NULL..!!");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n PSD Final Released Estimate Sheet Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\n Query Tag[Estimate_Sheet_PLMSAP] is NULL..!!");fflush(stdout);
	}
	
    if (titemobj_results)
	{
	  MEM_free(titemobj_results);
	}
	fclose(fpOutput_file); 		
    printf("\n All Estimate Sheet Written Successfully on the Output File....\n");fflush(stdout); 
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PLMSAPESTransfer.c
* // ./linkitk -o tm_PLMSAPESTransfer tm_PLMSAPESTransfer.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PLMSAPESTransfer/tm_PLMSAPESTransfer .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PLMSAPESTransfer/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PLMSAPESTransfer/usage.txt .
* // ./tm_PLMSAPESTransfer -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_PLMSAPESTransfer -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/