/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create Aggregate Revision Object After Reading Data From Input File 
*  File Name    :   tm_aggrcreate.c
*  Created on   :   Jun 12th, 2024
*  Usage        :   tm_aggrcreate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/06/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int toint(char str[])
{
    int len = strlen(str);
    int i, num = 0;
 
    for (i = 0; i < len; i++)
    {
        num = num + ((str[len - (i + 1)] - '0') * pow(10, i));
    }
 
   return num;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* Aggrgrp_Str = NULL;
	char* Aggrgrp_StrDup = NULL;
	char* Aggr_Str = NULL;
	char* Aggr_StrDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tObjCreate_Input = NULLTAG;
	tag_t tObj_Type = NULLTAG;
	tag_t new_object = NULLTAG;
	tag_t taggrgrp_rev = NULLTAG;
	tag_t tAggrqryobj = NULLTAG;
	int n_aggrentries = 1;
	int n_aggritemobj_found = 0;
	tag_t* taggritemobj_results = NULLTAG;
	tag_t taggr_rev = NULLTAG;
	tag_t relation_type;
	tag_t relation_found = NULLTAG;
	tag_t relation_new = NULLTAG;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("InputList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			Aggrgrp_Str=strtok(Buffer,"^");
			Aggr_Str=strtok(NULL,"^");
			
			if(Aggrgrp_Str!=NULL)tc_strdup(Aggrgrp_Str,&Aggrgrp_StrDup);
            if(Aggr_Str!=NULL)tc_strdup(Aggr_Str,&Aggr_StrDup);			
			if(Aggrgrp_StrDup!=NULL)trimwhitespace(Aggrgrp_StrDup);
			if(Aggr_StrDup!=NULL)trimwhitespace(Aggr_StrDup);
			
			printf(" Aggregate Group(Aggrgrp_StrDup): [%s]\n",Aggrgrp_StrDup);
			printf(" Aggregate (Aggr_StrDup): [%s]\n",Aggr_StrDup);

			ITK_CALL(QRY_find2("SubModuleLibraryAggrGrp",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("Query[SubModuleLibraryAggrGrp] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"ID"};
				char *cValues[1]  = {Aggrgrp_StrDup};
				//char *cValues[1]  = {"POWERTRAIN"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[SubModuleLibraryAggrGrp] Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
				    printf(" [SubModuleLibraryAggrGrp] Revision Exist So Continue For Aggregate Revision Creation..!!\n");fflush(stdout);
				    taggrgrp_rev = titemobj_results[0];
				    printf("\n ~~~~~~~~ C R E A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 
				    ITK_CALL(TCTYPE_find_type("T5_Submdlbagr", NULL, &tObj_Type));
					ITK_CALL(TCTYPE_construct_create_input(tObj_Type, &tObjCreate_Input));
					if(tObjCreate_Input != NULLTAG)
					{
						printf(" Input Tag Not NULL..!!\n");fflush(stdout);
						ITK_CALL(AOM_set_value_string(tObjCreate_Input,"object_name",Aggr_StrDup));
						ITK_CALL(AOM_set_value_string(tObjCreate_Input,"object_desc",Aggr_StrDup));
						ITK_CALL(AOM_set_value_string(tObjCreate_Input,"item_id",Aggr_StrDup));
						ITK_CALL(TCTYPE_create_object(tObjCreate_Input, &new_object));
						if(new_object != NULLTAG) 
						{
							printf(" Objects[SubModuleLibraryAggr] Revision Created..!! \n");fflush(stdout);
						}
						else
						{
							printf(" Objects[SubModuleLibraryAggr] Revision Not Created..!! \n");fflush(stdout);
						}
						ITK_CALL(AOM_save(new_object));
						printf("\n Save...!!\n");
						ITK_CALL(AOM_unlock(new_object));
						printf("\n Unlock..!!\n");
						ITK_CALL(QRY_find2("SubModuleLibraryAggr",&tAggrqryobj));
						if(tAggrqryobj != NULLTAG)
						{
							printf("Query[SubModuleLibraryAggr] Found Successfully..!!\n");fflush(stdout);
							char *cAggrEntries[1]  = {"ID"};
							char *cAggrValues[1]  = {Aggr_StrDup};
							//char *cAggrValues[1]  = {"POWERTRAIN"};
							ITK_CALL(QRY_execute(tAggrqryobj, n_aggrentries, cAggrEntries, cAggrValues, &n_aggritemobj_found, &taggritemobj_results));
							printf("\n -----------------------------------------------\n");fflush(stdout);
							printf("\n No of Objects[SubModuleLibraryAggr] Found: [%d]\n",n_aggritemobj_found);fflush(stdout);
							printf("\n -----------------------------------------------\n");fflush(stdout);
                            if(n_aggritemobj_found > 0)
				            {
								taggr_rev = taggritemobj_results[0];
								ITK_CALL(GRM_find_relation_type("T5_Submdlbagrpagrrel", &relation_type));
								ITK_CALL(GRM_find_relation(taggrgrp_rev, taggr_rev, relation_type ,&relation_found));
								if(relation_found)
								{
									printf("\n Relation Already Exist with Same Aggregate Group and Aggregate Revision \n");fflush(stdout);
								}
								else
								{
									ITK_CALL(GRM_create_relation(taggrgrp_rev, taggr_rev, relation_type, NULLTAG, &relation_new));
									ITK_CALL(GRM_save_relation(relation_new));
									printf("\n Aggregate Revision Created and Attached with Aggregate Group Revision");fflush(stdout);
								}
							}
                            else
                            {
								printf(" Aggregate Revision Not Found..!!\n");fflush(stdout);
							}								
						}
						else
						{
						  printf(" Query Tag [SubModuleLibraryAggr] NULL..!!\n");fflush(stdout);
						}
							
					}
					else
					{
						printf(" Object Create Input Tag NULL..!!\n");fflush(stdout);
					}
					printf("\n ~~~~~~~~ C R E A T I O N   E N D ~~~~~~~~\n");fflush(stdout); 
				}
                else
                {
				   printf(" Aggregate Group Not Found..!!");fflush(stdout);
				}					
			}
		    else
			{
				printf(" Query[SubModuleLibraryAggrGrp] Tag Not Found..!!");fflush(stdout);
			}
			if(titemobj_results)
			{
			   MEM_free(titemobj_results);
			} 
            if(taggritemobj_results)
			{
			   MEM_free(taggritemobj_results);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_aggrcreate.c
* // ./linkitk -o tm_aggrcreate tm_aggrcreate.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AGGRCreate/tm_aggrcreate .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AGGRCreate/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AGGRCreate/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AGGRCreate/usage.txt .
* // ./tm_aggrcreate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_aggrcreate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/