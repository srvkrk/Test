/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Part Applicability Matrix Reports  
*  File Name    :   tm_PartApplicability_Rpt.c
*  Created on   :   Mar 12th, 2024
*  Usage        :   tm_PartApplicability_Rpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/03/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#include <ics/ics2.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSeqSrch)
{
	
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char *Item_revseq = NULL;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[n];
				if(LC_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpLCQryobj_results[n],"release_status_list",&sRelStatus);
					printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						tc_strdup("--",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
					printf("\n Item Release Status After Dup & Trim: [%s]", sRelStatusDup);fflush(stdout);
					STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
					printf("\n Item Release Status Final Value: [%s]", sRelStatusDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&sRelStatusDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&sRelStatusDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&sRelStatusDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_FileReport, FILE* FP_OutputReport)
{
	    char* cItem_Level = NULL;
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cItem_LCDetails = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* cItem_Desc = NULL;
		char* cQuantity = NULL;
		char* cQuantityDup = NULL;
		char* cDesGrp = NULL;
		char* cDesGrpDup = NULL;
		char* cSpInd = NULL;
		char* cSpIndDup = NULL;
		char* cRevSeq = NULL;
		int cLevel = 0;
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			
			//ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j],"bl_level_starting_0",&cItem_Level));
			//trimwhitespace(cItem_Level);
			//printf("\n Part Level Value After Trim: [%s]\n", cItem_Level);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_int(tBOM_Sub_Children[j], "bl_level_starting_0", &cLevel));
			printf("\n Part Level: [%d]\n", cLevel);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cRevSeq));
			trimwhitespace(cRevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cRevSeq);fflush(stdout);
			
			cItem_Desc = TC_PartDesc(cItem_Id,cItem_RevSeq);
			printf("\n Part Description Value: [%s]", cItem_Desc);fflush(stdout);
			
			cItem_LCDetails = TC_PartLCDetails(cItem_Id,cItem_RevSeq);
			printf("\n Part LC Status Value After Dup & Trim: [%s]", cItem_LCDetails);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartStatus", &cArDrStatus));
			if(tc_strlen(cArDrStatus)>0)
			{
				tc_strdup(cArDrStatus,&cArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&cArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(cArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", cArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_DesignGrp", &cDesGrp));
			if(tc_strlen(cDesGrp)>0)
			{
				tc_strdup(cDesGrp,&cDesGrpDup);
			}
			else
			{
				tc_strdup("--",&cDesGrpDup);
				printf("\n Part Design Group Value is NULL");fflush(stdout);
			}
			trimwhitespace(cDesGrpDup);
			printf("\n Part Design Group Value After Dup & Trim: [%s]\n", cDesGrpDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("--",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_SpareInd", &cSpInd));
			if(tc_strlen(cSpInd)>0)
			{
				tc_strdup(cSpInd,&cSpIndDup);
			}
			else
			{
				tc_strdup("--",&cSpIndDup);
				printf("\n Part Spare Indicator Value is NULL");fflush(stdout);
			}
			trimwhitespace(cSpIndDup);
			printf("\n Part Spare Indicator Value After Dup & Trim: [%s]\n", cSpIndDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			if(tc_strlen(cQuantity)>0)
			{
				tc_strdup(cQuantity,&cQuantityDup);
			}
			else
			{
				tc_strdup("--",&cQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(cQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", cQuantityDup);fflush(stdout);
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level: [%d]", cLevel);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Part Revision: [%s]", cItem_Rev);
			printf("\nChild_Level Part Sequence: [%s]", cItem_Seq);
			printf("\nChild_Level Part Description: [%s]", cItem_Desc);
			printf("\nChild_Level Part AR/DR Status: [%s]", cArDrStatusDup);
			printf("\nChild_Level Part Design Group: [%s]", cDesGrpDup);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\nChild_Level Part Spare Indicator: [%s]", cSpIndDup);
			printf("\nChild_Level Part LC Details: [%s]", cItem_LCDetails);
			printf("\nChild_Level Part Quantity: [%s]", cQuantityDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if(tc_strcmp(cPartTypeDup,"Module")==0 || tc_strcmp(cPartTypeDup,"CAD Module")==0)
				{
				   fprintf(FP_FileReport,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",cItem_Id,cItem_Rev,cItem_Seq,cItem_Desc,cArDrStatusDup,cDesGrpDup,cPartTypeDup,cSpIndDup,cItem_LCDetails,cQuantityDup);fflush(FP_FileReport);
				   fprintf(FP_OutputReport,"%s,%s,%s\n",cItem_Id,cRevSeq,cQuantityDup);fflush(FP_OutputReport);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if((iNumber_SubChild > 0) && (cLevel<6))
			{
				bom_sub_child(tSubChild,iNumber_SubChild,FP_FileReport,FP_OutputReport);
			}
		}
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRS,FILE* PrMstRpt,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopModAggr = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubItem_Desc = NULL;
	char* ctopSubQuantity = NULL;
	char* ctopSubQuantityDup = NULL;
	char* ctopSubItem_LCDetails = NULL;
	char* ctopSubDesGrp = NULL;
	char* ctopSubDesGrpDup =  NULL;
	char* ctopSubSpInd = NULL;
	char* ctopSubSpIndDup = NULL;
	char* ctopSubRevSeq = NULL;
	int ctopLevel = 0;
	
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {
			
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		//ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		ITK_CALL(CFM_find("Latest Working", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);
		
        /* //Closure_Rule was Hashed As APL ALL Plant Part Required		
		ITK_CALL(PIE_find_closure_rules("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		//Closure_Rule was Hashed As APL ALL Plant Part Required */
		
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_ask_value_int(t_top_Sub_Child, "bl_level_starting_0", &ctopLevel));
			printf("\n Part Level: [%d]\n", ctopLevel);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubRevSeq));
			trimwhitespace(ctopSubRevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubRevSeq);fflush(stdout);
			
			ctopSubItem_Desc = TC_PartDesc(ctopSubItem_Id,ctopSubItem_RevSeq);
			printf("\n Part Description Value: [%s]", ctopSubItem_Desc);fflush(stdout);
			
			ctopSubItem_LCDetails = TC_PartLCDetails(ctopSubItem_Id,ctopSubItem_RevSeq);
			printf("\n Part LC Status Value After Dup & Trim: [%s]", ctopSubItem_LCDetails);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartStatus", &ctopSubArDrStatus));
			if(tc_strlen(ctopSubArDrStatus)>0)
			{
				tc_strdup(ctopSubArDrStatus,&ctopSubArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&ctopSubArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", ctopSubArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_DesignGrp", &ctopSubDesGrp));
			if(tc_strlen(ctopSubDesGrp)>0)
			{
				tc_strdup(ctopSubDesGrp,&ctopSubDesGrpDup);
			}
			else
			{
				tc_strdup("--",&ctopSubDesGrpDup);
				printf("\n Part Design Group Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubDesGrpDup);
			printf("\n Part Design Group Value After Dup & Trim: [%s]\n", ctopSubDesGrpDup);fflush(stdout);
			
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_SpareInd", &ctopSubSpInd));
			if(tc_strlen(ctopSubSpInd)>0)
			{
				tc_strdup(ctopSubSpInd,&ctopSubSpIndDup);
			}
			else
			{
				tc_strdup("--",&ctopSubSpIndDup);
				printf("\n Part Spare Indicator Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubSpIndDup);
			printf("\n Part Spare Indicator Value After Dup & Trim: [%s]\n", ctopSubSpIndDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_quantity", &ctopSubQuantity));
			if(tc_strlen(ctopSubQuantity)>0)
			{
				tc_strdup(ctopSubQuantity,&ctopSubQuantityDup);
			}
			else
			{
				tc_strdup("--",&ctopSubQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", ctopSubQuantityDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level: [%d]", ctopLevel);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Description: [%s]", ctopSubItem_Desc);
			printf("\nTop_Level AR/DR: [%s]", ctopSubArDrStatusDup);
			printf("\nTop_Level Design Group: [%s]", ctopSubDesGrpDup);
			printf("\nTop_Level Part Type: [%s]", ctopSubPartTypeDup);
			printf("\nTop_Level Spare Indicator: [%s]", ctopSubSpIndDup);
			printf("\nTop_Level LC State: [%s]", ctopSubItem_LCDetails);
			printf("\nTop_Level QTY: [%s]", ctopSubQuantityDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if(tc_strcmp(ctopSubPartTypeDup,"Module")==0 || tc_strcmp(ctopSubPartTypeDup,"CAD Module")==0)
				{
				   fprintf(PrMstRpt,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubItem_Desc,ctopSubArDrStatusDup,ctopSubDesGrpDup,ctopSubPartTypeDup,ctopSubSpIndDup,ctopSubItem_LCDetails,ctopSubQuantityDup);fflush(PrMstRpt);
				   fprintf(VehRpt,"%s,%s,%s\n",ctopSubItem_Id,ctopSubRevSeq,ctopSubQuantityDup);fflush(VehRpt);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if((itopSubNumber_Child>0) && (ctopLevel<6))
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, PrMstRpt, VehRpt);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *PrMstRptFile= (char *) malloc(100*sizeof(char));
	char *MstrRptFile = (char *) malloc(100*sizeof(char));
	char *FinalRptFile = (char *) malloc(100*sizeof(char));
	char *InpRptFile = (char *) malloc(100*sizeof(char));
	FILE *fpPreMstrop_file = NULL;
	FILE *fpInput_file = NULL;
	char *item_revseq_strDup = NULL;
	char *item_revseq_strdup = (char *) malloc(20*sizeof(char));
	tag_t DesRev_tag = NULLTAG;
	char* user_id_str = NULL;
	char* user_id_strDup = NULL;
	char* email_id_str = NULL;
	char* email_id_strDup = NULL;
    char* responseString1 = NULL;
	responseString1=(char *)MEM_alloc(200);
	char* SVRShellCommandLine = NULL;
	SVRShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	char* ItemNo = NULL;
	char* ItemRev = NULL;
	char* ItemSeq = NULL;
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	
	cUSERID = ITK_ask_cli_argument("-u=");
	cPASS = ITK_ask_cli_argument("-p=");
	cGroup = ITK_ask_cli_argument("-g=");
	item_id_str = ITK_ask_cli_argument("-PartList=");
	user_id_str = ITK_ask_cli_argument("-User=");
	email_id_str = ITK_ask_cli_argument("-Email=");
	
	trimwhitespace(item_id_str);
	trimwhitespace(user_id_str);
	trimwhitespace(email_id_str);
	if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
	if(user_id_str!=NULL)tc_strdup(user_id_str,&user_id_strDup);
	if(email_id_str!=NULL)tc_strdup(email_id_str,&email_id_strDup);
	printf(" [1]: UserID(cUSERID): [%s]\n",cUSERID);
	printf(" [2]: Password(cPASS): [%s]\n",cPASS);
	printf(" [3]: Group(cGroup): [%s]\n",cGroup);
	printf(" [4]: Input Part List(item_id_strDup): [%s]\n",item_id_strDup);
	printf(" [5]: Input User ID(user_id_strDup): [%s]\n",user_id_strDup);
	printf(" [6]: Input User Email(email_id_strDup): [%s]\n",email_id_strDup);
	status = ITK_init_module(cUSERID, cPASS, cGroup);
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating New Report Time Stamp");fflush(stdout);
	char RptDate[100] = "";
	strftime(RptDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Report Time: [%s]", RptDate);fflush(stdout);
	printf("\n New Report Time Stamp Generated");fflush(stdout);
	
	printf("\n Generating Pre Master Report File Name..!!");fflush(stdout);
	//tc_strcpy(PrMstRptFile,"Pre_Master_Part_App_Matrix");
	tc_strcpy(PrMstRptFile,"/tmp/");
	tc_strcat(PrMstRptFile,"PreMaster_Part_App_Matrix_Rpt");
	tc_strcat(PrMstRptFile,"_");
	tc_strcat(PrMstRptFile,GenDate);
	tc_strcat(PrMstRptFile,".csv");
	printf("\n Pre Master Report File Name: [%s]", PrMstRptFile);fflush(stdout);
	printf("\n Pre Master Report File Name Generated..!!");fflush(stdout);
	
	printf("\n Generating Master Report File Name..!!");fflush(stdout);
	//tc_strcpy(MstrRptFile,"Master_Part_App_Matrix");
	tc_strcpy(MstrRptFile,"/tmp/");
	tc_strcat(MstrRptFile,"Master_Part_App_Matrix_Rpt");
	tc_strcat(MstrRptFile,"_");
	tc_strcat(MstrRptFile,GenDate);
	tc_strcat(MstrRptFile,".csv");
	printf("\n Master Report File Name: [%s]", MstrRptFile);fflush(stdout);
	printf("\n Master Report File Name Generated..!!");fflush(stdout);
	
	printf("\n Generating Final Report File Name..!!");fflush(stdout);
	//tc_strcpy(FinalRptFile,"Part_App_Matrix_Rpt");
	tc_strcpy(FinalRptFile,"/tmp/");
	tc_strcat(FinalRptFile,"Part_App_Matrix_Rpt");
	tc_strcat(FinalRptFile,"_");
	tc_strcat(FinalRptFile,GenDate);
	tc_strcat(FinalRptFile,".csv");
	printf("\n Final Report File Name: [%s]", FinalRptFile);fflush(stdout);
	printf("\n Final Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating Input Report File Name..!!");fflush(stdout);
	//tc_strcpy(InpRptFile,"InputList");
	tc_strcpy(InpRptFile,"/tmp/");
	tc_strcat(InpRptFile,"App_InputPartList");
	tc_strcat(InpRptFile,"_");
	tc_strcat(InpRptFile,GenDate);
	tc_strcat(InpRptFile,".csv");
	printf("\n Input Report File Name: [%s]", InpRptFile);fflush(stdout);
	printf("\n Input Report File Name Generated..!!");fflush(stdout);
	
	printf("\n Copying PartList in Response String1");fflush(stdout);
	if(tc_strlen(item_id_strDup)>0)
	{
		tc_strcpy(responseString1,item_id_strDup);
	}
	else
	{
		tc_strcpy(responseString1,"");
		printf("\n Response String1 Value is NULL");fflush(stdout);
	}
	printf("\n Input PartList: [%s]", item_id_strDup);fflush(stdout);
	printf("\n Response String1: %s", responseString1);fflush(stdout);
	printf("\n PartList Copied in Response String1");fflush(stdout);
	
	fpPreMstrop_file = fopen(PrMstRptFile, "w");
	if(fpPreMstrop_file == NULL)
	{
	    printf("\n Unable to Create [Pre_Master_Part_App_Matrix] File: [%s]",PrMstRptFile);fflush(stdout);
		return 0;
	}
	else
	{
		printf("\n [Pre_Master_Part_App_Matrix] File Opened Successfully..!!");fflush(stdout);
	}
	
	fpInput_file = fopen(InpRptFile, "w"); 
	if(fpInput_file == NULL)
	{
	    printf("\n Unable to Create [App_InputPartList] File: [%s]",InpRptFile);fflush(stdout);
		return 0;
	}
	else
	{
		printf("\n [App_InputPartList] File Opened Successfully..!!");fflush(stdout);
	}
	
	char token_list[20][20];
	char* token = strtok(item_id_strDup, ",");
	int num_tokens = 0;
	while(token != NULL) 
	{
		strcpy(token_list[num_tokens], token); 
		num_tokens++;
		token = strtok(NULL, ",");
	}					
	printf("\n No of Tokens: [%d]",num_tokens);fflush(stdout);
	int c=0;
    for (c=0; c < num_tokens; c++) 
    {
		char* InpLine = (char *) malloc(20*sizeof(char));
		tc_strcpy(InpLine,token_list[c]);
		printf("\n Input_Line:  [%s]",InpLine);fflush(stdout);
		fprintf(fpInput_file,"%s\n",InpLine);fflush(fpInput_file);
		char *InpPartRptFile= (char *) malloc(100*sizeof(char));
	    FILE *fppart_output_file = NULL;
	    printf("\n Generating Each Part Report File Name..!!");fflush(stdout);
		trimwhitespace(InpLine);
		printf("\n Input_Line After Trim WhiteSpace:  [%s]",InpLine);fflush(stdout);
	    //tc_strcpy(InpPartRptFile,InpLine);
	    tc_strcpy(InpPartRptFile,"/tmp/");
	    tc_strcat(InpPartRptFile,InpLine);
	    tc_strcat(InpPartRptFile,".csv");
	    printf("\n Input_Part Report File: [%s]", InpPartRptFile);fflush(stdout);
		fppart_output_file = fopen(InpPartRptFile, "w");
		if(fppart_output_file == NULL)
	    {
		    printf("\n Unable to Create Input Part Report File: [%s]",InpPartRptFile);fflush(stdout);
		    return 0;
	    }
		else
	    {
		    printf("\n Input Part Report File Opened Successfully..!!");fflush(stdout);
	    }
		
		ItemNo=strtok(InpLine,"_");
	    ItemRev=strtok(NULL,"_");
		ItemSeq=strtok(NULL,"_");
		
		printf("Item No: [%s] \n", ItemNo);fflush(stdout);
        printf("Item Rev: [%s] \n", ItemRev);fflush(stdout);
        printf("Item Seq: [%s] \n", ItemSeq);fflush(stdout);
			
	    tc_strcpy(item_revseq_strdup,ItemRev);
	    tc_strcat(item_revseq_strdup,";");
	    tc_strcat(item_revseq_strdup,ItemSeq);
	    printf("Item RevSeq: [%s] \n", item_revseq_strdup);fflush(stdout);
		
		printf("\n Function1: Vehicle Child Details Find Start");fflush(stdout);
		TC_VehChild_Details(ItemNo,item_revseq_strdup,fpPreMstrop_file,fppart_output_file);
	    printf("\n Function1: Vehicle Child Details Find End\n");fflush(stdout);
					
		fclose(fppart_output_file);
		printf("\n Input Part File Closed Successfully..!!");fflush(stdout);
	}
	fclose(fpInput_file);
	printf("\n Input File Closed..!!\n");fflush(stdout);
    fclose(fpPreMstrop_file);           
	printf("\n All Part Details Written Successfully on [Pre_Master_Part_App_Matrix]File..!!\n");fflush(stdout);
	
	
	printf("\n Shell Calling Started..!!");fflush(stdout);
	//tc_strcpy(SVRShellCommandLine,"/user/cvprod/sourav/Part_Applicability_Matrix_Report/Execution_Shell.sh");
	//tc_strcpy(SVRShellCommandLine,"/user/uaprodtrl/Sourav/Part_Applicability_Matrix_Report/Execution_Shell.sh");
	tc_strcpy(SVRShellCommandLine,"/user/cvprod/sourav/ReportBuilderPartAppRpt/Execution_Shell.sh");
	tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,responseString1);
	tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,PrMstRptFile);
	tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,MstrRptFile);
	tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,FinalRptFile);
    tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,email_id_strDup);
	tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,InpRptFile);
    //tc_strcat(SVRShellCommandLine," ");
	//tc_strcat(SVRShellCommandLine,item_id_strDup);
	tc_strcat(SVRShellCommandLine," ");
	tc_strcat(SVRShellCommandLine,RptDate);
	printf("\n CommandLine: [%s]",SVRShellCommandLine);fflush(stdout);
	system(SVRShellCommandLine);
	printf("\n Shell Called Ended..!!");
	

    printf("\n Report File Attach To Users Home Folder Start..!!\n");fflush(stdout);
	char *Filename = NULL;
	char *FileLoc = NULL;
	char *dataSetName = NULL;
	IMF_file_t	fileDescriptor;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	tag_t tUser = NULLTAG;
	tag_t tHomeFolder = NULLTAG;
	
    dataSetName = (char *) MEM_alloc( 70 * sizeof(char) );
	tc_strcpy(dataSetName,"PART-APPLICABILITY-RPT-");
	tc_strcat(dataSetName,GenDate);
	printf(" Dataset Name: [%s]\n", dataSetName);fflush(stdout);
	
	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(Filename,FinalRptFile);
	printf(" File Name: [%s]\n", Filename);fflush(stdout);

	//tc_strcpy(FileLoc,"/tmp/");
	//tc_strcat(FileLoc,Filename);
	tc_strcpy(FileLoc,Filename);
	printf(" File Location: [%s]\n", FileLoc);fflush(stdout);

	ITK_CALL(AE_find_datasettype2("MSExcel",&datasettype));
	ITK_CALL(AE_find_tool2("MSExcel", &tool));
	ITK_CALL(AE_create_dataset_with_id(datasettype,dataSetName,"",NULL,NULL,&Newdataset));
	ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
	ITK_CALL(AE_set_dataset_format2(Newdataset,"BINARY_REF"));
	ITK_CALL(AOM_save(Newdataset));	
	ITK_CALL(IMF_fmsfile_import(FileLoc,Filename,SS_BINARY,&filetag,&fileDescriptor));
	if(filetag == NULLTAG)
	{
		printf(" File Tag Not Found..!!\n");fflush(stdout);
	}
	ITK_CALL(AOM_refresh(Newdataset,TRUE));
	ITK_CALL(AE_add_dataset_named_ref2(Newdataset, "excel", AE_PART_OF, filetag));
	ITK_CALL(AOM_save(Newdataset));
	ITK_CALL(AOM_refresh(Newdataset,FALSE));
	
	ITK_CALL(SA_find_user2(user_id_strDup,&tUser));
	ITK_CALL(SA_ask_user_home_folder(tUser,&tHomeFolder));
	ITK_CALL(AOM_lock(tHomeFolder));
	ITK_CALL(FL_insert(tHomeFolder,Newdataset,999));
    ITK_CALL(AOM_save(tHomeFolder));
	ITK_CALL(AOM_unlock(tHomeFolder));
	printf("\n Report File Attach To Users Home Folder End..!!\n");fflush(stdout);
		
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PartApplicability_Rpt.c
* // ./linkitk -o tm_PartApplicability_Rpt tm_PartApplicability_Rpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Applicability_Report/tm_PartApplicability_Rpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Applicability_Report/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Applicability_Report/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Applicability_Report/SendEmail.sh .
* // ./tm_PartApplicability_Rpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -PartList="51273863R_A_1,21960158R_H_2" -User="souravk.ttl" -Email="souravk.ttl@tatamotors.com"
* // ./tm_PartApplicability_Rpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -PartList="51273863R_A_1,21960158R_H_2" -User="souravk.ttl" -Email="souravk.ttl@tatamotors.com"
*
***************************************************************************/