/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Modularity Dashboard Report
*  File Name    :   tm_ModDashboardRpt.c
*  Created on   :   Apr 04th, 2024
*  Usage        :   tm_ModDashboardRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     04/04/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *MstrSubDet_str = NULL;
	char *MstrSubDet_strDup = NULL;
	FILE *fpMstr_List = NULL;
	char Buffer1[1024];
	FILE *fpGen_List = NULL;
	char Buffer2[1024];
	char *RptFile = (char *) malloc(100*sizeof(char));
	FILE *fpOutput_file = NULL;
	char *GenSubDet_str = NULL;
	char *GenSubDet_strDup = NULL;
	char *SrNo_str = NULL;
	char *SrNo_strDup = NULL;
	char *Platform_str = NULL;
	char *Platform_strDup = NULL;
	char *Module_str = NULL;
	char *Module_strDup = NULL;
	char *DesGrp_str = NULL;
	char *DesGrp_strDup = NULL;
	char *ModAdd_str = NULL;
    char *ModAdd_strDup = NULL;
	char *ModNum_str = NULL;
	char *ModNum_strDup = NULL;
	char *PUNCS_str = NULL;
	char *PUNCS_strDup = NULL;
	char *JSRCS_str = NULL;
	char *JSRCS_strDup = NULL;
	char *LKOCS_str = NULL;
	char *LKOCS_strDup = NULL;
	char *DWDCS_str = NULL;
	char *DWDCS_strDup = NULL;
	char *SubModDesc_str = NULL;
	char *SubModDesc_strDup = NULL;
	char *GenSubVar_str = NULL;
	char *GenSubVar_strDup = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Dashboard Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Modularity_Dashboard_Rpt");\
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"SR_NO, PLATFORM, MODULE, DESIGN_GROUP, SUBMODULE_ADDRESS, SUBMODULE_NUMBER, PUN_CS, JSR_CS, LKN_CS, DWD_CS, SUBMODULE_DESCRIPTION, VARIETY\n");fflush(fpOutput_file);
	 
	fpMstr_List = fopen("Modularity.txt","r");
	if(fpMstr_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer1,1024,fpMstr_List)!=NULL)
		{	
			SrNo_str=strtok(Buffer1,"^");
			Platform_str=strtok(NULL,"^");
			Module_str=strtok(NULL,"^");
			DesGrp_str=strtok(NULL,"^");
			ModAdd_str=strtok(NULL,"^");
			ModNum_str=strtok(NULL,"^");
			PUNCS_str=strtok(NULL,"^");
			JSRCS_str=strtok(NULL,"^");
			LKOCS_str=strtok(NULL,"^");
			DWDCS_str=strtok(NULL,"^");
			SubModDesc_str=strtok(NULL,"^");
			if(SrNo_str!=NULL)tc_strdup(SrNo_str,&SrNo_strDup);
			if(Platform_str!=NULL)tc_strdup(Platform_str,&Platform_strDup);
			if(Module_str!=NULL)tc_strdup(Module_str,&Module_strDup);
			if(DesGrp_str!=NULL)tc_strdup(DesGrp_str,&DesGrp_strDup);
			if(ModAdd_str!=NULL)tc_strdup(ModAdd_str,&ModAdd_strDup);
			if(ModNum_str!=NULL)tc_strdup(ModNum_str,&ModNum_strDup);
			if(PUNCS_str!=NULL)tc_strdup(PUNCS_str,&PUNCS_strDup);
			if(JSRCS_str!=NULL)tc_strdup(JSRCS_str,&JSRCS_strDup);
			if(LKOCS_str!=NULL)tc_strdup(LKOCS_str,&LKOCS_strDup);
			if(DWDCS_str!=NULL)tc_strdup(DWDCS_str,&DWDCS_strDup);
			if(SubModDesc_str!=NULL)tc_strdup(SubModDesc_str,&SubModDesc_strDup);
			
			if(SrNo_strDup!=NULL)trimwhitespace(SrNo_strDup);
            if(Platform_strDup!=NULL)trimwhitespace(Platform_strDup);	
            if(Module_strDup!=NULL)trimwhitespace(Module_strDup);
            if(DesGrp_strDup!=NULL)trimwhitespace(DesGrp_strDup);
            if(ModAdd_strDup!=NULL)trimwhitespace(ModAdd_strDup);
			if(ModNum_strDup!=NULL)trimwhitespace(ModNum_strDup);
			if(PUNCS_strDup!=NULL)trimwhitespace(PUNCS_strDup);
			if(JSRCS_strDup!=NULL)trimwhitespace(JSRCS_strDup);
			if(LKOCS_strDup!=NULL)trimwhitespace(LKOCS_strDup);
			if(DWDCS_strDup!=NULL)trimwhitespace(DWDCS_strDup);
			if(SubModDesc_strDup!=NULL)trimwhitespace(SubModDesc_strDup);
			
            printf(" [1]: Serial No(SrNo_strDup): [%s]\n",SrNo_strDup);
			printf(" [2]: Platform(Platform_strDup): [%s]\n",Platform_strDup);
			printf(" [3]: Module(Module_strDup): [%s]\n",Module_strDup);
			printf(" [3]: Design Group(DesGrp_strDup): [%s]\n",DesGrp_strDup);
			printf(" [4]: SubModule Address(ModAdd_strDup): [%s]\n",ModAdd_strDup);
			printf(" [5]: SubModule Number(ModAdd_strDup): [%s]\n",ModNum_strDup);
			printf(" [6]: PUNE CS(PUNCS_strDup): [%s]\n",PUNCS_strDup);
			printf(" [7]: JSR CS(JSRCS_strDup): [%s]\n",JSRCS_strDup);
			printf(" [8]: LKO CS(LKOCS_strDup): [%s]\n",LKOCS_strDup);
			printf(" [9]: DWD CS(DWDCS_strDup): [%s]\n",DWDCS_strDup);
			printf(" [10]: SubModule Description(SubModDesc_strDup): [%s]\n",SubModDesc_strDup);
			
			if(tc_strlen(SubModDesc_strDup)>0)
			{
				fpGen_List = fopen("VarietyCountRpt.txt","r");
				if(fpGen_List != NULL)
	            {
					printf(" VarietyCount Report File Not Null..!!\n");fflush(stdout);
					while(fgets(Buffer2,1024,fpGen_List)!=NULL)
					{
						GenSubDet_str=strtok(Buffer2,"^");
						GenSubVar_str=strtok(NULL,"^");
						if(GenSubDet_str!=NULL)tc_strdup(GenSubDet_str,&GenSubDet_strDup);
						if(GenSubVar_str!=NULL)tc_strdup(GenSubVar_str,&GenSubVar_strDup);
						if(GenSubDet_strDup!=NULL)trimwhitespace(GenSubDet_strDup);
						if(GenSubVar_strDup!=NULL)trimwhitespace(GenSubVar_strDup);
						printf(" [1]: Generated_SubMod_Details(GenSubDet_strDup): [%s]\n",GenSubDet_strDup);
						printf(" [2]: Generated_SubMod_Variety(GenSubVar_strDup): [%s]\n",GenSubVar_strDup);
						if(tc_strlen(GenSubDet_strDup)>0)
						{
							if(tc_strcmp(SubModDesc_strDup,GenSubDet_strDup) == 0)
						    {
								fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",SrNo_strDup,Platform_strDup,Module_strDup,DesGrp_strDup,ModAdd_strDup,ModNum_strDup,PUNCS_strDup,JSRCS_strDup,LKOCS_strDup,DWDCS_strDup,SubModDesc_strDup,GenSubVar_strDup);fflush(fpOutput_file);	
							}
							else
							{
								printf(" SubModule Details Not Matched..!!\n");fflush(stdout);
							}
						}
						else
						{
							printf(" Generated SubModule Details NULL..!!\n");fflush(stdout);
						}
					}
                    fclose(fpGen_List);
	                printf("\n Generated_File CLosed");fflush(stdout);				
				}
				else 
				{
					printf("\n Generated_File is NULL..!!\n");fflush(stdout);
				}
			}
            else
			{
				printf(" Master SubModule Details NULL..!!\n");fflush(stdout);
			}
		}
		fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
        fclose(fpMstr_List);
		printf("\n Master_Input_File Closed..!!");fflush(stdout);
        fclose(fpOutput_file);
        printf("\n Output_File Closed..!!");fflush(stdout);		
	}
	else 
	{
		printf("\n Master_Input_File is NULL..!!\n");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ModDashboardRpt.c
* // ./linkitk -o tm_ModDashboardRpt tm_ModDashboardRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModularityDashboardReport/tm_ModDashboardRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModularityDashboardReport/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModularityDashboardReport/usage.txt .
* // ./tm_ModDashboardRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_ModDashboardRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/