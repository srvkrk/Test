/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Import Named Reference File To An Empty Dataset  
*  File Name    :   tm_DatasetImport.c
*  Created on   :   Dec 31st, 2023
*  Usage        :   ./tm_DatasetImport -u=<USER_ID> -pf=<PASSWORD_FILE> -g=<GROUP> -prt=<PART_NO> -rev=<PART_REV> -seq=<PART_SEQ> -name=<DATASET_DISPLAY_NAME> -fname=<DATASET_FILE_NAME>
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     31/12/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_disname_str = NULL;
	char *item_fname_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *item_disname_strDup = NULL;
	char *item_fname_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t titem = NULLTAG;
	char* cItem_revseq = NULL;
	char* file_name_str = NULL;
	char *RptFile= (char *) malloc(400*sizeof(char));
	const char *cEntries[1];
	const char *cValues[1];
	char *item_revseq_str= (char *) malloc(400*sizeof(char));
	char *item_revseq_strDup = NULL;
	char *ds_no_str = NULL;
	char *ds_no_strDup = NULL;
	char *ds_type_str = NULL;
	char *ds_type_strDup = NULL;
	char* dstyperesponsestring = NULL;
	dstyperesponsestring=(char *)MEM_alloc(200);
	tag_t tSpecfRelationType = NULLTAG;
	tag_t tRefRelationType = NULLTAG;
	tag_t tRendRelationType = NULLTAG;
	tag_t* tSecObjectList = NULLTAG;
	int iSec_ObjCount = 0;
	char* SecObjType = NULL;
	int i, j, k = 0;
	char* SecObjString = NULL;
	int no_ref = 0;
	tag_t* tnamed_ref = NULLTAG;
	char *namedref_no_str = NULL;
	char *namedref_no_strDup = NULL;
	char *namedref_type_str = NULL;
	char *namedref_type_strDup = NULL;
	char imp_path[90000]= {'\0'};
	tag_t item_tag = NULLTAG;
	int	ref_count = 0;
	tag_t datasettype = NULLTAG;
	tag_t Newdataset = NULLTAG;
	tag_t tool = NULLTAG;
	tag_t filetag = NULLTAG;
	char **ref_list;
	IMF_file_t fileDescriptor;
	AE_reference_type_t	tagRefType = 1;
	//char *fullPath = NULL;
	tag_t relation_type = NULLTAG;
	tag_t Fndrelation = NULLTAG;
	tag_t relation = NULLTAG;
	tag_t* nameRefObject = NULL;
	//char *JTFileDesc = NULL;
	//char *itemId12 = NULL;
	int nameRef_cnt = 0;
	
	tag_t cmidrwdatasettype = NULLTAG;
	tag_t cmidrwNewdataset = NULLTAG;
	tag_t cmidrwtool = NULLTAG;
	int cmidrwnameRef_cnt = 0;
	tag_t* cmidrwnameRefObject = NULL;
	int cmidrwref_count = 0;
	char **cmidrwref_list;
	tag_t cmidrwfiletag = NULLTAG;
	IMF_file_t cmidrwfileDescriptor;
	tag_t cmidrwrelation_type = NULLTAG;
	tag_t cmidrwFndrelation = NULLTAG;
	tag_t cmidrwrelation = NULLTAG;
	
	tag_t cmiprtdatasettype = NULLTAG;
	tag_t cmiprtNewdataset = NULLTAG;
	tag_t cmiprttool = NULLTAG;
	int cmiprtnameRef_cnt = 0;
	tag_t* cmiprtnameRefObject = NULL;
	int cmiprtref_count = 0;
	char **cmiprtref_list;
	tag_t cmiprtfiletag = NULLTAG;
	IMF_file_t cmiprtfileDescriptor;
	tag_t cmiprtrelation_type = NULLTAG;
	tag_t cmiprtFndrelation = NULLTAG;
	tag_t cmiprtrelation = NULLTAG;
	
	tag_t cmipdfdatasettype = NULLTAG;
	tag_t cmipdfNewdataset = NULLTAG;
	tag_t cmipdftool = NULLTAG;
	int cmipdfnameRef_cnt = 0;
	tag_t* cmipdfnameRefObject = NULL;
	int cmipdfref_count = 0;
	char **cmipdfref_list;
	tag_t cmipdffiletag = NULLTAG;
	IMF_file_t cmipdffileDescriptor;
	tag_t cmipdfrelation_type = NULLTAG;
	tag_t cmipdfFndrelation = NULLTAG;
	tag_t cmipdfrelation = NULLTAG;
	
	tag_t cmiproddatasettype = NULLTAG;
	tag_t cmiprodNewdataset = NULLTAG;
	tag_t cmiprodtool = NULLTAG;
	int cmiprodnameRef_cnt = 0;
	tag_t* cmiprodnameRefObject = NULL;
	int cmiprodref_count = 0;
	char **cmiprodref_list;
	tag_t cmiprodfiletag = NULLTAG;
	IMF_file_t cmiprodfileDescriptor;
	tag_t cmiprodrelation_type = NULLTAG;
	tag_t cmiprodFndrelation = NULLTAG;
	tag_t cmiprodrelation = NULLTAG;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	item_id_str = ITK_ask_cli_argument("-prt=");
	item_rev_str = ITK_ask_cli_argument("-rev=");
	item_seq_str = ITK_ask_cli_argument("-seq=");
	item_disname_str = ITK_ask_cli_argument("-name=");
	item_fname_str = ITK_ask_cli_argument("-fname=");
	
	trimwhitespace(item_id_str);
	trimwhitespace(item_rev_str);
	trimwhitespace(item_seq_str);
	trimwhitespace(item_disname_str);
	trimwhitespace(item_fname_str);
	if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
	if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
	if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
	if(item_disname_str!=NULL)tc_strdup(item_disname_str,&item_disname_strDup);
	if(item_fname_str!=NULL)tc_strdup(item_fname_str,&item_fname_strDup);
	printf(" [1]: Input Part No(item_id_strDup): [%s]\n",item_id_strDup);
	printf(" [2]: Input Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
	printf(" [3]: Input Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
	printf(" [4]: Input File Display Name(item_disname_strDup): [%s]\n",item_disname_strDup);
	printf(" [5]: Input File Name(item_fname_strDup): [%s]\n",item_fname_strDup);
	
	tc_strcpy(item_revseq_str,item_rev_strDup);
	tc_strcat(item_revseq_str,";");
	tc_strcat(item_revseq_str,item_seq_strDup);
	if(item_revseq_str!=NULL)tc_strdup(item_revseq_str,&item_revseq_strDup);
	printf(" Item Rev & Seq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
	
	ds_no_str=strtok(item_disname_strDup,".");
	ds_type_str=strtok(NULL,".");
	if(ds_no_str!=NULL)tc_strdup(ds_no_str,&ds_no_strDup);
	if(ds_type_str!=NULL)tc_strdup(ds_type_str,&ds_type_strDup);
	printf(" Dataset No(ds_type_strDup): [%s]\n",ds_no_strDup);
	printf(" Dataset Type(ds_type_strDup): [%s]\n",ds_type_strDup);
	
	namedref_no_str=strtok(item_fname_strDup,".");
	namedref_type_str=strtok(NULL,".");
	if(namedref_no_str!=NULL)tc_strdup(namedref_no_str,&namedref_no_strDup);
	if(namedref_type_str!=NULL)tc_strdup(namedref_type_str,&namedref_type_strDup);
	printf(" Named Reference No(namedref_no_strDup): [%s]\n",namedref_no_strDup);
	printf(" Named Reference Type(namedref_type_strDup): [%s]\n",namedref_type_strDup);
	
	printf("\n Generating Physical File Import Location");fflush(stdout);
    tc_strcpy(imp_path," ");
	//tc_strcpy(imp_path,"/user/cvprod/sourav/DATASETIMPORT/");
	tc_strcpy(imp_path,"/user/cvprod/sourav/DSCREATEIMPORT/");
    //tc_strcat(imp_path,item_fname_strDup);
	tc_strcat(imp_path,namedref_no_strDup);
	tc_strcat(imp_path,".");
	tc_strcat(imp_path,namedref_type_strDup);
	printf("\n Physical File Name with Location:  [%s]", imp_path);fflush(stdout);
	printf("\n Physical File Name & Location Generated..!!");fflush(stdout);
	
	if(tc_strlen(ds_type_strDup)>0)
	{
		if(tc_strcmp(ds_type_strDup,"CATDrawing")==0)
		{
			tc_strcpy(dstyperesponsestring,"CMI2Drawing");
		}
		else if(tc_strcmp(ds_type_strDup,"CATPart")==0)
		{
			tc_strcpy(dstyperesponsestring,"CMI2Part");
		}
		else if(tc_strcmp(ds_type_strDup,"CATProduct")==0)
		{
			tc_strcpy(dstyperesponsestring,"CMI2Product");
		}
		else if(tc_strcmp(ds_type_strDup,"pdf")==0)
		{
			tc_strcpy(dstyperesponsestring,"PDF");
		}
		else if(tc_strcmp(ds_type_strDup,"jt")==0)
		{
			tc_strcpy(dstyperesponsestring,"DirectModel");
		}
		else
		{
		    tc_strcpy(dstyperesponsestring,"NA");
		}
	}
	else
	{
		tc_strcpy(dstyperesponsestring,"NA");
	}
	printf(" Dataset Type Response String(dstyperesponsestring): [%s]\n",dstyperesponsestring);
	
	ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","ID"};
		char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
		//char *cValues[2]  = {"B;2","2196G1A0154005"};
	    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for (i = 0; i < n_itemobj_found; i++)
		    {
				item_tag = titemobj_results[i];
				ITK_CALL(GRM_find_relation_type("IMAN_specification", &tSpecfRelationType));
				ITK_CALL(GRM_find_relation_type("IMAN_reference", &tRefRelationType));
				ITK_CALL(GRM_find_relation_type("IMAN_Rendering", &tRendRelationType));
				if(tc_strcmp(dstyperesponsestring,"CMI2Drawing")==0)
				{
					int CMI2DrawingCreateFlag = 0;
					ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tSpecfRelationType, &iSec_ObjCount, &tSecObjectList));
					printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
					if(iSec_ObjCount > 0)
					{
						for (j = 0; j < iSec_ObjCount; j++)
					    {
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_type", &SecObjType));
							printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_string", &SecObjString));
							printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
							if((tc_strcmp(dstyperesponsestring,SecObjType)==0) && (tc_strcmp(ds_no_strDup,SecObjString)==0))
							{
								printf("\n Dataset Type & Dataset No Matched, Checking Named Reference File Available or Not..!!\n");fflush(stdout);
								ITK_CALL(AE_ask_dataset_named_refs(tSecObjectList[j], &no_ref, &tnamed_ref));
								if(no_ref < 1)
					            {
									printf("\n Dataset Present With Blank Named Reference, So Import Named Reference..!!\n");fflush(stdout);
									ITK_CALL(AOM_refresh(tSecObjectList[j], 1));
								    printf("\n Dataset Checked-Out Successfully..!!");fflush(stdout);
								    //ITK_CALL(AE_import_named_ref(tSecObjectList[j],"CATDrawing",imp_path,ds_no_strDup,SS_BINARY));
									ITK_CALL(AE_import_named_ref(tSecObjectList[j],"CATDrawing",imp_path,NULL,SS_BINARY));
				                    printf("\n Named Reference Imported Successfully..!!");fflush(stdout);
				                    ITK_CALL(AE_save_myself(tSecObjectList[j]));
				                    printf("\n Named Reference Saved Successfully..!!");fflush(stdout);
								    ITK_CALL(AOM_refresh(tSecObjectList[j], 0));
								    printf("\n Dataset Checked-In Successfully..!!");fflush(stdout);
								}
								else
								{
									printf("\n Dataset Present With Named Reference, So Skip..!!\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Dataset Type & Dataset Name Not Matched For CMI2Drawing in IMAN_specification Relation..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Dataset Not Present For CMI2Drawing in IMAN_specification Relation..!!\n");fflush(stdout);
						if((tc_strcmp(item_id_strDup,ds_no_strDup)==0) && (CMI2DrawingCreateFlag = 0))
						{
							printf("\n Dataset Not Present For CMI2Drawing in IMAN_specification Relation & TC Part No & Dataset ID is same So, Create Dataset & Import Named-Reference Start..!!\n");fflush(stdout);
							ITK_CALL(AE_find_datasettype("CMI2Drawing", &cmidrwdatasettype));
							ITK_CALL(AE_create_dataset_with_id(cmidrwdatasettype,item_id_strDup,"",NULL,NULL,&cmidrwNewdataset));
							ITK_CALL(AE_set_dataset_format(cmidrwNewdataset, "BINARY_REF"));
							ITK_CALL(AE_set_dataset_tool(cmidrwNewdataset,cmidrwtool));
							ITK_CALL(AE_ask_dataset_named_refs(cmidrwNewdataset,&cmidrwnameRef_cnt,&cmidrwnameRefObject));
							printf("\n\t @@@@CMI2Drawing Named-Reference Count(cmidrwnameRef_cnt): [%d]\n",cmidrwnameRef_cnt);fflush(stdout);
							if(cmidrwnameRef_cnt == 0)
							{
								ITK_CALL(AE_ask_datasettype_refs(cmidrwdatasettype,&cmidrwref_count,&cmidrwref_list));
								ITK_CALL(IMF_import_file(imp_path,NULL,SS_BINARY,&cmidrwfiletag,&cmidrwfileDescriptor));
								ITK_CALL(AOM_save(cmidrwfiletag));
								ITK_CALL(AE_add_dataset_named_ref(cmidrwNewdataset,cmidrwref_list[0],tagRefType,cmidrwfiletag));
								ITK_CALL(AE_set_dataset_tool(cmidrwNewdataset,cmidrwtool));
								ITK_CALL(AOM_save(cmidrwNewdataset));
							}
							ITK_CALL(GRM_find_relation_type("IMAN_specification",&cmidrwrelation_type));
							ITK_CALL(GRM_find_relation(item_tag,cmidrwNewdataset,cmidrwrelation_type,&cmidrwFndrelation));
							if(cmidrwFndrelation)
							{
								printf("\n\t Relation Already Exist..!!\n" );fflush(stdout);
							}
							else
							{
							  ITK_CALL(GRM_create_relation(item_tag,cmidrwNewdataset,cmidrwrelation_type,NULLTAG,&cmidrwrelation));
							  ITK_CALL(GRM_save_relation(cmidrwrelation));
							}
							CMI2DrawingCreateFlag = CMI2DrawingCreateFlag + 1;
						}
					}
					ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRefRelationType, &iSec_ObjCount, &tSecObjectList));
					printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
					if(iSec_ObjCount > 0)
					{
						for (k = 0; k < iSec_ObjCount; k++)
						{
							ITK_CALL(AOM_ask_value_string( tSecObjectList[k], "object_type", &SecObjType));
							printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
							ITK_CALL(AOM_ask_value_string( tSecObjectList[k], "object_string", &SecObjString));
							printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
							if((tc_strcmp(dstyperesponsestring,SecObjType)==0) && (tc_strcmp(ds_no_strDup,SecObjString)==0))
							{
								printf("\n Dataset Type & Dataset No Matched, Checking Named Reference File Available or Not..!!\n");fflush(stdout);
								ITK_CALL(AE_ask_dataset_named_refs(tSecObjectList[k], &no_ref, &tnamed_ref));
								if(no_ref < 1)
								{
									printf("\n Dataset Present With Blank Named Reference, So Import Named Reference..!!\n");fflush(stdout);
									ITK_CALL(AOM_refresh(tSecObjectList[k], 1));
								    printf("\n Dataset Checked-Out Successfully..!!");fflush(stdout);
								    //ITK_CALL(AE_import_named_ref(tSecObjectList[k],"CATDrawing",imp_path,ds_no_strDup,SS_BINARY));
									ITK_CALL(AE_import_named_ref(tSecObjectList[k],"CATDrawing",imp_path,NULL,SS_BINARY));
				                    printf("\n Named Reference Imported Successfully..!!");fflush(stdout);
				                    ITK_CALL(AE_save_myself(tSecObjectList[k]));
				                    printf("\n Named Reference Saved Successfully..!!");fflush(stdout);
								    ITK_CALL(AOM_refresh(tSecObjectList[k], 0));
								    printf("\n Dataset Checked-In Successfully..!!");fflush(stdout);
									
								}
								else
								{
									printf("\n Dataset Present With Named Reference, So Skip..!!\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Dataset Type & Dataset Name Not Matched For CMI2Drawing in IMAN_reference Relation..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Dataset Not Present For CMI2Drawing in IMAN_reference Relation..!!\n");fflush(stdout);
						if((tc_strcmp(item_id_strDup,ds_no_strDup)!=0) && (CMI2DrawingCreateFlag = 0))
						{
							printf("\n Dataset Not Present For CMI2Drawing in IMAN_reference Relation & TC Part No & Dataset ID is same So, Create Dataset & Import Named-Reference Start..!!\n");fflush(stdout);
							ITK_CALL(AE_find_datasettype("CMI2Drawing", &cmidrwdatasettype));
							ITK_CALL(AE_create_dataset_with_id(cmidrwdatasettype,item_id_strDup,"",NULL,NULL,&cmidrwNewdataset));
							ITK_CALL(AE_set_dataset_format(cmidrwNewdataset, "BINARY_REF"));
							ITK_CALL(AE_set_dataset_tool(cmidrwNewdataset,cmidrwtool));
							ITK_CALL(AE_ask_dataset_named_refs(cmidrwNewdataset,&cmidrwnameRef_cnt,&cmidrwnameRefObject));
							printf("\n\t @@@@CMI2Drawing Named-Reference Count(cmidrwnameRef_cnt): [%d]\n",cmidrwnameRef_cnt);fflush(stdout);
							if(cmidrwnameRef_cnt == 0)
							{
								ITK_CALL(AE_ask_datasettype_refs(cmidrwdatasettype,&cmidrwref_count,&cmidrwref_list));
								ITK_CALL(IMF_import_file(imp_path,NULL,SS_BINARY,&cmidrwfiletag,&cmidrwfileDescriptor));
								ITK_CALL(AOM_save(cmidrwfiletag));
								ITK_CALL(AE_add_dataset_named_ref(cmidrwNewdataset,cmidrwref_list[0],tagRefType,cmidrwfiletag));
								ITK_CALL(AE_set_dataset_tool(cmidrwNewdataset,cmidrwtool));
								ITK_CALL(AOM_save(cmidrwNewdataset));
							}
							ITK_CALL(GRM_find_relation_type("IMAN_reference",&cmidrwrelation_type));
							ITK_CALL(GRM_find_relation(item_tag,cmidrwNewdataset,cmidrwrelation_type,&cmidrwFndrelation));
							if(cmidrwFndrelation)
							{
								printf("\n\t Relation Already Exist..!!\n" );fflush(stdout);
							}
							else
							{
							  ITK_CALL(GRM_create_relation(item_tag,cmidrwNewdataset,cmidrwrelation_type,NULLTAG,&cmidrwrelation));
							  ITK_CALL(GRM_save_relation(cmidrwrelation));
							}
							CMI2DrawingCreateFlag = CMI2DrawingCreateFlag + 1;
						}
					}
				}
				if(tc_strcmp(dstyperesponsestring,"CMI2Part")==0)
				{
					int CMI2PartCreateFlag = 0;
					ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tSpecfRelationType, &iSec_ObjCount, &tSecObjectList));
					printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
					if(iSec_ObjCount > 0)
					{
						for (j = 0; j < iSec_ObjCount; j++)
					    {
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_type", &SecObjType));
							printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_string", &SecObjString));
							printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
							if((tc_strcmp(dstyperesponsestring,SecObjType)==0) && (tc_strcmp(ds_no_strDup,SecObjString)==0))
							{
								printf("\n Dataset Type & Dataset No Matched, Checking Named Reference File Available or Not..!!\n");fflush(stdout);
								ITK_CALL(AE_ask_dataset_named_refs(tSecObjectList[j], &no_ref, &tnamed_ref));
								if(no_ref < 1)
					            {
									printf("\n Dataset Present With Blank Named Reference, So Import Named Reference..!!\n");fflush(stdout);
									ITK_CALL(AOM_refresh(tSecObjectList[j], 1));
								    printf("\n Dataset Checked-Out Successfully..!!");fflush(stdout);
								    //ITK_CALL(AE_import_named_ref(tSecObjectList[j],"CATPart",imp_path,ds_no_strDup,SS_BINARY));
									ITK_CALL(AE_import_named_ref(tSecObjectList[j],"CATPart",imp_path,NULL,SS_BINARY));
				                    printf("\n Named Reference Imported Successfully..!!");fflush(stdout);
				                    ITK_CALL(AE_save_myself(tSecObjectList[j]));
				                    printf("\n Named Reference Saved Successfully..!!");fflush(stdout);
								    ITK_CALL(AOM_refresh(tSecObjectList[j], 0));
								    printf("\n Dataset Checked-In Successfully..!!");fflush(stdout);
								}
								else
								{
									printf("\n Dataset Present With Named Reference, So Skip..!!\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Dataset Type & Dataset Name Not Matched For CMI2Part in IMAN_specification Relation..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Dataset Not Present For CMI2Part in IMAN_specification Relation..!!\n");fflush(stdout);
						if((tc_strcmp(item_id_strDup,ds_no_strDup)==0) && (CMI2PartCreateFlag = 0))
						{
							printf("\n Dataset Not Present For CMI2Part in IMAN_specification Relation & TC Part No & Dataset ID is same So, Create Dataset & Import Named-Reference Start..!!\n");fflush(stdout);
							ITK_CALL(AE_find_datasettype("CMI2Part", &cmiprtdatasettype));
							ITK_CALL(AE_create_dataset_with_id(cmiprtdatasettype,item_id_strDup,"",NULL,NULL,&cmiprtNewdataset));
							ITK_CALL(AE_set_dataset_format(cmiprtNewdataset, "BINARY_REF"));
							ITK_CALL(AE_set_dataset_tool(cmiprtNewdataset,cmiprttool));
							ITK_CALL(AE_ask_dataset_named_refs(cmiprtNewdataset,&cmiprtnameRef_cnt,&cmiprtnameRefObject));
							printf("\n\t @@@@CMI2Part Named-Reference Count(cmiprtnameRef_cnt): [%d]\n",cmiprtnameRef_cnt);fflush(stdout);
							if(cmiprtnameRef_cnt == 0)
							{
								ITK_CALL(AE_ask_datasettype_refs(cmiprtdatasettype,&cmiprtref_count,&cmiprtref_list));
								ITK_CALL(IMF_import_file(imp_path,NULL,SS_BINARY,&cmiprtfiletag,&cmiprtfileDescriptor));
								ITK_CALL(AOM_save(cmiprtfiletag));
								ITK_CALL(AE_add_dataset_named_ref(cmiprtNewdataset,cmiprtref_list[0],tagRefType,cmiprtfiletag));
								ITK_CALL(AE_set_dataset_tool(cmiprtNewdataset,cmiprttool));
								ITK_CALL(AOM_save(cmiprtNewdataset));
							}
							ITK_CALL(GRM_find_relation_type("IMAN_specification",&cmiprtrelation_type));
							ITK_CALL(GRM_find_relation(item_tag,cmiprtNewdataset,cmiprtrelation_type,&cmiprtFndrelation));
							if(cmiprtFndrelation)
							{
								printf("\n\t Relation Already Exist..!!\n" );fflush(stdout);
							}
							else
							{
							  ITK_CALL(GRM_create_relation(item_tag,cmiprtNewdataset,cmiprtrelation_type,NULLTAG,&cmiprtrelation));
							  ITK_CALL(GRM_save_relation(cmiprtrelation));
							}
							CMI2PartCreateFlag = CMI2PartCreateFlag + 1;
						}
					}
				}
				if(tc_strcmp(dstyperesponsestring,"DirectModel")==0)
				{
					int JTCreateFlag = 0;
					ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRendRelationType, &iSec_ObjCount, &tSecObjectList));
					printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
					if(iSec_ObjCount > 0)
					{
						printf("\n Dataset Already Present For JT in IMAN_Rendering Relation..!!\n");fflush(stdout);
						for (j = 0; j < iSec_ObjCount; j++)
					    {
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_type", &SecObjType));
							printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_string", &SecObjString));
							printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
							if((tc_strcmp(dstyperesponsestring,SecObjType)==0) && (tc_strcmp(ds_no_strDup,SecObjString)==0))
							{
								printf("\n Dataset Type & Dataset No Matched, Checking Named Reference File Available or Not..!!\n");fflush(stdout);
								ITK_CALL(AE_ask_dataset_named_refs(tSecObjectList[j], &no_ref, &tnamed_ref));
								if(no_ref < 1)
					            {
									printf("\n Dataset Present With Blank Named Reference, So Import Named Reference..!!\n");fflush(stdout);
									ITK_CALL(AOM_refresh(tSecObjectList[j], 1));
								    printf("\n Dataset Checked-Out Successfully..!!");fflush(stdout);
								    //ITK_CALL(AE_import_named_ref(tSecObjectList[j],"JTPART",imp_path,ds_no_strDup,SS_BINARY));
									ITK_CALL(AE_import_named_ref(tSecObjectList[j],"JTPART",imp_path,NULL,SS_BINARY));
				                    printf("\n Named Reference Imported Successfully..!!");fflush(stdout);
				                    ITK_CALL(AE_save_myself(tSecObjectList[j]));
				                    printf("\n Named Reference Saved Successfully..!!");fflush(stdout);
								    ITK_CALL(AOM_refresh(tSecObjectList[j], 0));
								    printf("\n Dataset Checked-In Successfully..!!");fflush(stdout);
								}
								else
								{
									printf("\n Dataset Present With Named Reference, So Skip..!!\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Dataset Type & Dataset Name Not Matched For JT in IMAN_Rendering Relation..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Dataset Not Present For JT in IMAN_Rendering Relation..So, Create & Import Named-Reference Start..!!\n");fflush(stdout);
						if((tc_strcmp(item_id_strDup,ds_no_strDup)==0) && (JTCreateFlag = 0))
						{
							ITK_CALL(AE_find_datasettype("DirectModel", &datasettype));
							ITK_CALL(AE_create_dataset_with_id(datasettype,item_id_strDup,"",NULL,NULL,&Newdataset));
							ITK_CALL(AE_set_dataset_format(Newdataset, "BINARY_REF"));
							ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
							ITK_CALL(AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt,&nameRefObject));
							printf("\n\t @@@@JT Named-Reference Count(nameRef_cnt): [%d]\n",nameRef_cnt);fflush(stdout);
							if (nameRef_cnt == 0)
							{
								ITK_CALL(AE_ask_datasettype_refs(datasettype,&ref_count,&ref_list));
								ITK_CALL(IMF_import_file(imp_path,NULL,SS_BINARY,&filetag,&fileDescriptor));
								ITK_CALL(AOM_save(filetag));
								ITK_CALL(AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag));
								ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
								ITK_CALL(AOM_save(Newdataset));
							}
							ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&relation_type));
							ITK_CALL(GRM_find_relation(item_tag,Newdataset,relation_type,&Fndrelation));
							if(Fndrelation)
							{
								printf("\n\t Relation Already Exist..!!\n" );fflush(stdout);
							}
							else
							{
							  ITK_CALL(GRM_create_relation(item_tag,Newdataset,relation_type,NULLTAG,&relation));
							  ITK_CALL(GRM_save_relation(relation));
							}
							JTCreateFlag = JTCreateFlag + 1;
						}
					}
				}
				if(tc_strcmp(dstyperesponsestring,"PDF")==0)
				{
					int PDFCreateFlag = 0;
					ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRefRelationType, &iSec_ObjCount, &tSecObjectList));
					printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
					if(iSec_ObjCount > 0)
					{
						for (j = 0; j < iSec_ObjCount; j++)
					    {
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_type", &SecObjType));
							printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_string", &SecObjString));
							printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
							if((tc_strcmp(dstyperesponsestring,SecObjType)==0) && (tc_strcmp(ds_no_strDup,SecObjString)==0))
							{
								printf("\n Dataset Type & Dataset No Matched, Checking Named Reference File Available or Not..!!\n");fflush(stdout);
								ITK_CALL(AE_ask_dataset_named_refs(tSecObjectList[j], &no_ref, &tnamed_ref));
								if(no_ref < 1)
					            {
									printf("\n Dataset Present With Blank Named Reference, So Import Named Reference..!!\n");fflush(stdout);
									ITK_CALL(AOM_refresh(tSecObjectList[j], 1));
								    printf("\n Dataset Checked-Out Successfully..!!");fflush(stdout);
								    //ITK_CALL(AE_import_named_ref(tSecObjectList[j],"PDF_Reference",imp_path,ds_no_strDup,SS_BINARY));
									ITK_CALL(AE_import_named_ref(tSecObjectList[j],"PDF_Reference",imp_path,NULL,SS_BINARY));
				                    printf("\n Named Reference Imported Successfully..!!");fflush(stdout);
				                    ITK_CALL(AE_save_myself(tSecObjectList[j]));
				                    printf("\n Named Reference Saved Successfully..!!");fflush(stdout);
								    ITK_CALL(AOM_refresh(tSecObjectList[j], 0));
								    printf("\n Dataset Checked-In Successfully..!!");fflush(stdout);
								}
								else
								{
									printf("\n Dataset Present With Named Reference, So Skip..!!\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Dataset Type & Dataset Name Not Matched For PDF in IMAN_reference Relation..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Dataset Not Present For PDF in IMAN_reference Relation..!!\n");fflush(stdout);
						if((tc_strcmp(item_id_strDup,ds_no_strDup)!=0) && (PDFCreateFlag = 0))
						{
							printf("\n Dataset Not Present For PDF in IMAN_reference Relation & TC Part No & Dataset ID is not same So, Create Dataset & Import Named-Reference Start..!!\n");fflush(stdout);
							ITK_CALL(AE_find_datasettype("PDF", &cmipdfdatasettype));
							ITK_CALL(AE_create_dataset_with_id(cmipdfdatasettype,item_id_strDup,"",NULL,NULL,&cmipdfNewdataset));
							ITK_CALL(AE_set_dataset_format(cmipdfNewdataset, "BINARY_REF"));
							ITK_CALL(AE_set_dataset_tool(cmipdfNewdataset,cmipdftool));
							ITK_CALL(AE_ask_dataset_named_refs(cmipdfNewdataset,&cmipdfnameRef_cnt,&cmipdfnameRefObject));
							printf("\n\t @@@@PDF Named-Reference Count(cmipdfnameRef_cnt): [%d]\n",cmipdfnameRef_cnt);fflush(stdout);
							if(cmipdfnameRef_cnt == 0)
							{
								ITK_CALL(AE_ask_datasettype_refs(cmipdfdatasettype,&cmipdfref_count,&cmipdfref_list));
								ITK_CALL(IMF_import_file(imp_path,NULL,SS_BINARY,&cmipdffiletag,&cmipdffileDescriptor));
								ITK_CALL(AOM_save(cmipdffiletag));
								ITK_CALL(AE_add_dataset_named_ref(cmipdfNewdataset,cmipdfref_list[0],tagRefType,cmipdffiletag));
								ITK_CALL(AE_set_dataset_tool(cmipdfNewdataset,cmipdftool));
								ITK_CALL(AOM_save(cmipdfNewdataset));
							}
							ITK_CALL(GRM_find_relation_type("IMAN_reference",&cmipdfrelation_type));
							ITK_CALL(GRM_find_relation(item_tag,cmipdfNewdataset,cmipdfrelation_type,&cmipdfFndrelation));
							if(cmipdfFndrelation)
							{
								printf("\n\t Relation Already Exist..!!\n" );fflush(stdout);
							}
							else
							{
							  ITK_CALL(GRM_create_relation(item_tag,cmipdfNewdataset,cmipdfrelation_type,NULLTAG,&cmipdfrelation));
							  ITK_CALL(GRM_save_relation(cmipdfrelation));
							}
							PDFCreateFlag = PDFCreateFlag + 1;
						}
					}
					ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRendRelationType, &iSec_ObjCount, &tSecObjectList));
					printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
					if(iSec_ObjCount > 0)
					{
						for (k = 0; k < iSec_ObjCount; k++)
						{
							ITK_CALL(AOM_ask_value_string( tSecObjectList[k], "object_type", &SecObjType));
							printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
							ITK_CALL(AOM_ask_value_string( tSecObjectList[k], "object_string", &SecObjString));
							printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
							if((tc_strcmp(dstyperesponsestring,SecObjType)==0) && (tc_strcmp(ds_no_strDup,SecObjString)==0))
							{
								printf("\n Dataset Type & Dataset No Matched, Checking Named Reference File Available or Not..!!\n");fflush(stdout);
								ITK_CALL(AE_ask_dataset_named_refs(tSecObjectList[k], &no_ref, &tnamed_ref));
								if(no_ref < 1)
								{
									printf("\n Dataset Present With Blank Named Reference, So Import Named Reference..!!\n");fflush(stdout);
									ITK_CALL(AOM_refresh(tSecObjectList[k], 1));
								    printf("\n Dataset Checked-Out Successfully..!!");fflush(stdout);
								    //ITK_CALL(AE_import_named_ref(tSecObjectList[k],"PDF_Reference",imp_path,ds_no_strDup,SS_BINARY));
									ITK_CALL(AE_import_named_ref(tSecObjectList[k],"PDF_Reference",imp_path,NULL,SS_BINARY));
				                    printf("\n Named Reference Imported Successfully..!!");fflush(stdout);
				                    ITK_CALL(AE_save_myself(tSecObjectList[k]));
				                    printf("\n Named Reference Saved Successfully..!!");fflush(stdout);
								    ITK_CALL(AOM_refresh(tSecObjectList[k], 0));
								    printf("\n Dataset Checked-In Successfully..!!");fflush(stdout);
									
								}
								else
								{
									printf("\n Dataset Present With Named Reference, So Skip..!!\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Dataset Type & Dataset Name Not Matched For PDF in IMAN_Rendering Relation..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Dataset Not Present For For PDF in IMAN_Rendering Relation..!!\n");fflush(stdout);
						if((tc_strcmp(item_id_strDup,ds_no_strDup)==0) && (PDFCreateFlag = 0))
						{
							printf("\n Dataset Not Present For PDF in IMAN_Rendering Relation & TC Part No & Dataset ID is same So, Create Dataset & Import Named-Reference Start..!!\n");fflush(stdout);
							ITK_CALL(AE_find_datasettype("PDF", &cmipdfdatasettype));
							ITK_CALL(AE_create_dataset_with_id(cmipdfdatasettype,item_id_strDup,"",NULL,NULL,&cmipdfNewdataset));
							ITK_CALL(AE_set_dataset_format(cmipdfNewdataset, "BINARY_REF"));
							ITK_CALL(AE_set_dataset_tool(cmipdfNewdataset,cmipdftool));
							ITK_CALL(AE_ask_dataset_named_refs(cmipdfNewdataset,&cmipdfnameRef_cnt,&cmipdfnameRefObject));
							printf("\n\t @@@@PDF Named-Reference Count(cmipdfnameRef_cnt): [%d]\n",cmipdfnameRef_cnt);fflush(stdout);
							if(cmipdfnameRef_cnt == 0)
							{
								ITK_CALL(AE_ask_datasettype_refs(cmipdfdatasettype,&cmipdfref_count,&cmipdfref_list));
								ITK_CALL(IMF_import_file(imp_path,NULL,SS_BINARY,&cmipdffiletag,&cmipdffileDescriptor));
								ITK_CALL(AOM_save(cmipdffiletag));
								ITK_CALL(AE_add_dataset_named_ref(cmipdfNewdataset,cmipdfref_list[0],tagRefType,cmipdffiletag));
								ITK_CALL(AE_set_dataset_tool(cmipdfNewdataset,cmipdftool));
								ITK_CALL(AOM_save(cmipdfNewdataset));
							}
							ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&cmipdfrelation_type));
							ITK_CALL(GRM_find_relation(item_tag,cmipdfNewdataset,cmipdfrelation_type,&cmipdfFndrelation));
							if(cmipdfFndrelation)
							{
								printf("\n\t Relation Already Exist..!!\n" );fflush(stdout);
							}
							else
							{
							  ITK_CALL(GRM_create_relation(item_tag,cmipdfNewdataset,cmipdfrelation_type,NULLTAG,&cmipdfrelation));
							  ITK_CALL(GRM_save_relation(cmipdfrelation));
							}
							PDFCreateFlag = PDFCreateFlag + 1;
						}
					}
				}
				if(tc_strcmp(dstyperesponsestring,"CMI2Product")==0)
				{
					int CMI2ProdCreateFlag = 0;
					ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tSpecfRelationType, &iSec_ObjCount, &tSecObjectList));
					printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
					if(iSec_ObjCount > 0)
					{
						for (j = 0; j < iSec_ObjCount; j++)
					    {
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_type", &SecObjType));
							printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
							ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_string", &SecObjString));
							printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
							if((tc_strcmp(dstyperesponsestring,SecObjType)==0) && (tc_strcmp(ds_no_strDup,SecObjString)==0))
							{
								printf("\n Dataset Type & Dataset No Matched, Checking Named Reference File Available or Not..!!\n");fflush(stdout);
								ITK_CALL(AE_ask_dataset_named_refs(tSecObjectList[j], &no_ref, &tnamed_ref));
								if(no_ref < 1)
					            {
									printf("\n Dataset Present With Blank Named Reference, So Import Named Reference..!!\n");fflush(stdout);
									ITK_CALL(AOM_refresh(tSecObjectList[j], 1));
								    printf("\n Dataset Checked-Out Successfully..!!");fflush(stdout);
								    //ITK_CALL(AE_import_named_ref(tSecObjectList[j],"CATProduct",imp_path,ds_no_strDup,SS_BINARY));
									ITK_CALL(AE_import_named_ref(tSecObjectList[j],"CATProduct",imp_path,NULL,SS_BINARY));
				                    printf("\n Named Reference Imported Successfully..!!");fflush(stdout);
				                    ITK_CALL(AE_save_myself(tSecObjectList[j]));
				                    printf("\n Named Reference Saved Successfully..!!");fflush(stdout);
								    ITK_CALL(AOM_refresh(tSecObjectList[j], 0));
								    printf("\n Dataset Checked-In Successfully..!!");fflush(stdout);
								}
								else
								{
									printf("\n Dataset Present With Named Reference, So Skip..!!\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Dataset Type & Dataset Name Not Matched For CMI2Product in IMAN_specification Relation..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Dataset Not Present For CMI2Product in IMAN_specification Relation..!!\n");fflush(stdout);
						if((tc_strcmp(item_id_strDup,ds_no_strDup)==0) && (CMI2ProdCreateFlag = 0))
						{
							printf("\n Dataset Not Present For CMI2Product in IMAN_specification Relation & TC Part No & Dataset ID is same So, Create Dataset & Import Named-Reference Start..!!\n");fflush(stdout);
							ITK_CALL(AE_find_datasettype("CMI2Product", &cmiproddatasettype));
							ITK_CALL(AE_create_dataset_with_id(cmiproddatasettype,item_id_strDup,"",NULL,NULL,&cmiprodNewdataset));
							ITK_CALL(AE_set_dataset_format(cmiprodNewdataset, "BINARY_REF"));
							ITK_CALL(AE_set_dataset_tool(cmiprodNewdataset,cmiprodtool));
							ITK_CALL(AE_ask_dataset_named_refs(cmiprodNewdataset,&cmiprodnameRef_cnt,&cmiprodnameRefObject));
							printf("\n\t @@@@CMI2Product Named-Reference Count(cmiprodnameRef_cnt): [%d]\n",cmiprodnameRef_cnt);fflush(stdout);
							if(cmiprodnameRef_cnt == 0)
							{
								ITK_CALL(AE_ask_datasettype_refs(cmiproddatasettype,&cmiprodref_count,&cmiprodref_list));
								ITK_CALL(IMF_import_file(imp_path,NULL,SS_BINARY,&cmiprodfiletag,&cmiprodfileDescriptor));
								ITK_CALL(AOM_save(cmiprodfiletag));
								ITK_CALL(AE_add_dataset_named_ref(cmiprodNewdataset,cmiprodref_list[0],tagRefType,cmiprodfiletag));
								ITK_CALL(AE_set_dataset_tool(cmiprodNewdataset,cmiprodtool));
								ITK_CALL(AOM_save(cmiprodNewdataset));
							}
							ITK_CALL(GRM_find_relation_type("IMAN_specification",&cmiprodrelation_type));
							ITK_CALL(GRM_find_relation(item_tag,cmiprodNewdataset,cmiprodrelation_type,&cmiprodFndrelation));
							if(cmiprodFndrelation)
							{
								printf("\n\t Relation Already Exist..!!\n" );fflush(stdout);
							}
							else
							{
							  ITK_CALL(GRM_create_relation(item_tag,cmiprodNewdataset,cmiprodrelation_type,NULLTAG,&cmiprodrelation));
							  ITK_CALL(GRM_save_relation(cmiprodrelation));
							}
							CMI2ProdCreateFlag = CMI2ProdCreateFlag + 1;
						}	
					}
				}
				
			}
		}
		else
		{
			printf("\n No of Revision Found Zero[0]..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\n DesignRevision Sequence Query Tag NULL..!!");fflush(stdout);
	}
	if(titemobj_results)
	{
		MEM_free(titemobj_results);
	}
	if(tSecObjectList)
	{
		MEM_free(tSecObjectList);
	}
    	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_DatasetImport.c
* // ./linkitk -o tm_DatasetImport tm_DatasetImport.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DatasetImport/tm_DatasetImport .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DatasetImport/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DatasetImport/usage.txt .
* // ./tm_DatasetImport -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -prt=<PART_NO> -rev=<PART_REV> -seq=<PART_SEQ> -name=<DATASET_DISPLAY_NAME> -fname=<DATASET_FILE_NAME>
* // ./tm_DatasetImport -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -prt=<PART_NO> -rev=<PART_REV> -seq=<PART_SEQ> -name=<DATASET_DISPLAY_NAME> -fname=<DATASET_FILE_NAME>
*
***************************************************************************/