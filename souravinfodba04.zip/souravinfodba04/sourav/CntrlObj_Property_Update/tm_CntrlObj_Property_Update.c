/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Update Control Object's Property  
*  File Name    :   tm_CntrlObj_Property_Update.c
*  Created on   :   Nov 06th, 2023
*  Usage        :   tm_CntrlObj_Property_Update
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     06/11/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *Part_item_id = NULL;
	char *syscd_str = NULL;
	char *subsyscd_str = NULL;
	char *name_str = NULL;
	char *delind_str = NULL;
	char *newval_str = NULL;
	char *syscd_strDup = NULL;
	char *subsyscd_strDup = NULL;
	char *name_strDup = NULL;
	char *delind_strDup = NULL;
	char *newval_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 4;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t PropName_AttrID = NULLTAG;
	int i = 0;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			syscd_str=strtok(Buffer,"^");
			subsyscd_str=strtok(NULL,"^");
			name_str=strtok(NULL,"^");
			delind_str=strtok(NULL,"^");
			newval_str=strtok(NULL,"^");
			
			if(syscd_str!=NULL)tc_strdup(syscd_str,&syscd_strDup);
			if(subsyscd_str!=NULL)tc_strdup(subsyscd_str,&subsyscd_strDup);
			if(name_str!=NULL)tc_strdup(name_str,&name_strDup);
			if(delind_str!=NULL)tc_strdup(delind_str,&delind_strDup);
			if(newval_str!=NULL)tc_strdup(newval_str,&newval_strDup);
			
			if(syscd_strDup!=NULL)trimwhitespace(syscd_strDup);
			if(subsyscd_strDup!=NULL)trimwhitespace(subsyscd_strDup);
			if(name_strDup!=NULL)trimwhitespace(name_strDup);
			if(delind_strDup!=NULL)trimwhitespace(delind_strDup);
			if(newval_strDup!=NULL)trimwhitespace(newval_strDup);
			
			printf(" SYSCD(syscd_strDup): [%s]\n",syscd_strDup);
			printf(" SUBSYSCD(subsyscd_strDup): [%s]\n",subsyscd_strDup);
			printf(" Name(name_strDup): [%s]\n",name_strDup);
			printf(" Delete Indicator(delind_strDup): [%s]\n",delind_strDup);
			printf(" New Value(newval_strDup): [%s]\n",newval_strDup);
			ITK_CALL(QRY_find2("Control Objects...",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n Control Objects... Found Successfully..!!\n");fflush(stdout);
				char *cEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
				char *cValues[4]  = {syscd_strDup,subsyscd_strDup,name_strDup,delind_strDup};
				//char *cValues[4]  = {"5476","61","V6TransferCntObj","0"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					for (i = 0; i < n_itemobj_found; i++)
					{		
						printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);  
						ITK_CALL(AOM_refresh(titemobj_results[i], POM_modify_lock));
						printf("\n Lock..!!\n");
						ITK_CALL(POM_attr_id_of_attr("object_name", "T5_ControlObject", &PropName_AttrID));
						printf("\n Property Name Tag Found..!!\n");
						ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], PropName_AttrID, newval_strDup));
						printf("\n Set Property Value..!!\n");
						ITK_CALL(POM_save_instances(1, &titemobj_results[i], true));
						printf("\n Save...!!\n");
						ITK_CALL(AOM_refresh(titemobj_results[i], POM_no_lock));
						printf("\n Unlock..!!\n");
						printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);						
					}
				}
				else
				{
					printf("\n Control Objects Not Found..!!");
				}
			}
		    else
			{
				printf("\n After Query Execution No Control Objects... Query Found..!!");fflush(stdout);
			}
			if (titemobj_results)
			{
				MEM_free(titemobj_results);
			}		

		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_CntrlObj_Property_Update.c
* // ./linkitk -o tm_CntrlObj_Property_Update tm_CntrlObj_Property_Update.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/CntrlObj_Property_Update/tm_CntrlObj_Property_Update .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/CntrlObj_Property_Update/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/CntrlObj_Property_Update/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/CntrlObj_Property_Update/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/CntrlObj_Property_Update/SendEmail.sh .
* // ./tm_CntrlObj_Property_Update -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_CntrlObj_Property_Update -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_CntrlObj_Property_Update -u=loader -p=loader123 -g=dba
*
***************************************************************************/