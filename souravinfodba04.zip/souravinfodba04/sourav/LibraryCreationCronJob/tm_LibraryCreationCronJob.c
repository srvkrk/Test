/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   MCC
*  Description  :   Library Creation Cron Job
*  File Name    :   tm_LibraryCreationCronJob.c
*  Created on   :   Nov 25th, 2024
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     25/11/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#include <ics/ics2.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_ModuleAddrStatus(char* InpModAddr)
{
	
	trimwhitespace(InpModAddr);
	char* ResModAdd = NULL;
	char* Info1 = NULL;
	char* Info2 = NULL;
	char* Info3 = NULL;
	char* Info4 = NULL;
	char* Info5 = NULL;
	char* Info6 = NULL;
	char* Info7 = NULL;
	char* Info8 = NULL;
	char* Info9 = NULL;
	char* Info10 = NULL;
	char* Fundesresponse = NULL;
	Fundesresponse = (char *) malloc(2000*sizeof(char ));
	printf("\n Control Object Check Started..!!\n");fflush(stdout);
	tag_t tCtrlobj = NULLTAG;
	tag_t* tPathctrlobj_results = NULLTAG;
	int n_pathentries = 4;
	int n_path_ctrlobj_found = 0;
	ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
	printf("\n Control Object Query Tag Found Successfully...!!\n");
	char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
	char *cPathValues[4]  = {"MCCInvalidAdd","MCCInvalidAddSub","MCCInvalidAddCntObj","0"};
	ITK_CALL(QRY_execute(tCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tPathctrlobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Control Object Found: [%d]\n",n_path_ctrlobj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_path_ctrlobj_found > 0)
	{
		printf("\n Control Object Found..!!\n");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo1", &Info1));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo2", &Info2));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo3", &Info3));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo4", &Info4));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo5", &Info5));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo6", &Info6));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo7", &Info7));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo8", &Info8));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo9", &Info9));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_userinfo10", &Info10));
		tc_strcpy(Fundesresponse,Info1);
		tc_strcat(Fundesresponse,Info2);
		tc_strcat(Fundesresponse,Info3);
		tc_strcat(Fundesresponse,Info4);
		tc_strcat(Fundesresponse,Info5);
		tc_strcat(Fundesresponse,Info6);
		tc_strcat(Fundesresponse,Info7);
		tc_strcat(Fundesresponse,Info8);
		tc_strcat(Fundesresponse,Info9);
		tc_strcat(Fundesresponse,Info10);
		printf("\n Concatinated Module_Address: --------> [%s]\n",Fundesresponse);fflush(stdout);
		if(tc_strstr(Fundesresponse,InpModAddr) != NULL)
		{
			tc_strdup("INVALID",&ResModAdd);
		}
		else
		{
			tc_strdup("VALID",&ResModAdd);
		}
	}
	else
	{
		tc_strdup("VALID",&ResModAdd);
		printf("\nControl Object Not Found So, Taking As Valid Case...");fflush(stdout);
	}
	
	return ResModAdd;	
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

int TC_ECUPartRlzd_DML_Details(FILE* ECURptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tECUItemobj  = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tecuitemobj_results = NULLTAG;
	int n_ecuentries = 5;
	int n_ecuitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf(" Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tECUItemobj));
    if(tECUItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cecuEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cecuValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"EP"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","EP"};
		ITK_CALL(QRY_execute(tECUItemobj, n_ecuentries, cecuEntries, cecuValues, &n_ecuitemobj_found, &tecuitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(ECU Part Release): [%d]\n",n_ecuitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_ecuitemobj_found > 0)
		{
			printf(" Release Type(ECU Part Release) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_ecuitemobj_found; i++)
			{
				ErcDMLTag = tecuitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"EP")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [Vehicle Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_string(revTag,"t5_AggregateGroup",&item_aggrp_str));
								if(tc_strlen(item_aggrp_str)>0)
								{
									tc_strdup(item_aggrp_str,&item_aggrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggrp_strDup);
									printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Aggregate",&item_aggr_str));
								if(tc_strlen(item_aggr_str)>0)
								{
									tc_strdup(item_aggr_str,&item_aggr_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggr_strDup);
									printf("\n Aggregate Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module_Group",&item_modgrp_str));
								if(tc_strlen(item_modgrp_str)>0)
								{
									tc_strdup(item_modgrp_str,&item_modgrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_modgrp_strDup);
									printf("\n Module Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module",&item_mod_str));
								if(tc_strlen(item_mod_str)>0)
								{
									tc_strdup(item_mod_str,&item_mod_strDup);
								}
								else
								{
									tc_strdup(" ",&item_mod_strDup);
									printf("\n Module Value is NULL..!!");fflush(stdout);
								}
								item_modaddr_str = subString(item_id_strDup, 4, 5);
								trimwhitespace(item_modaddr_str);
								printf("\n Part Module Address Value: [%s]", item_modaddr_str);fflush(stdout);
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Part_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Part_Desc,&Part_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&item_plat_str));
									if(tc_strlen(item_plat_str)>0)
									{
										tc_strdup(item_plat_str,&item_plat_strDup);
									}
									else
									{
										tc_strdup(" ",&item_plat_strDup);
										printf("\n Platform Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_ProjectCode",&item_pcode_str));
									if(tc_strlen(item_pcode_str)>0)
									{
										tc_strdup(item_pcode_str,&item_pcode_strDup);
									}
									else
									{
										tc_strdup(" ",&item_pcode_strDup);
										printf("\n Project_Code Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									if(tc_strlen(item_drar_str)>0)
									{
										tc_strdup(item_drar_str,&item_drar_strDup);
									}
									else
									{
										tc_strdup(" ",&item_drar_strDup);
										printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
									}

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Aggregate_Group: [%s]\n",item_aggrp_strDup);fflush(stdout);
									printf("\n  Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
									printf("\n  Module_Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
									printf("\n  Module: [%s]\n",item_mod_strDup);fflush(stdout);
									printf("\n  Module_Address: [%s]\n",item_modaddr_str);fflush(stdout);
									printf("\n  Part Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Part Description: [%s]\n",Part_DescDup);fflush(stdout);
									printf("\n  Part Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Part Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part Platform: [%s]\n",item_plat_strDup);fflush(stdout);
									printf("\n  Part Project_Code: [%s]\n",item_pcode_strDup);fflush(stdout);
									printf("\n  Part DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
									Module_Address_Status = TC_ModuleAddrStatus(item_modaddr_str);
									tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
									
									if((tc_strcmp(item_ptype_strDup,"EM")==0) && (tc_strcmp(item_typeDup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
									{
										fprintf(ECURptFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",DmlNo,item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup);fflush(ECURptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not Vehicle Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--Vehicle Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int TC_ModuleSpareKitRlzd_DML_Details(FILE* ModSpKitRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tMSPKItemobj  = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tmspkitemobj_results = NULLTAG;
	int n_mspkentries = 5;
	int n_mspkitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf(" Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tMSPKItemobj));
    if(tMSPKItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cmspkEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cmspkValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"TSKR"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","TSKR"};
		ITK_CALL(QRY_execute(tMSPKItemobj, n_mspkentries, cmspkEntries, cmspkValues, &n_mspkitemobj_found, &tmspkitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(Module with Spare Kit Release): [%d]\n",n_mspkitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_mspkitemobj_found > 0)
		{
			printf(" Release Type(Module with Spare Kit Release) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_mspkitemobj_found; i++)
			{
				ErcDMLTag = tmspkitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"TSKR")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [Vehicle Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_string(revTag,"t5_AggregateGroup",&item_aggrp_str));
								if(tc_strlen(item_aggrp_str)>0)
								{
									tc_strdup(item_aggrp_str,&item_aggrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggrp_strDup);
									printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Aggregate",&item_aggr_str));
								if(tc_strlen(item_aggr_str)>0)
								{
									tc_strdup(item_aggr_str,&item_aggr_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggr_strDup);
									printf("\n Aggregate Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module_Group",&item_modgrp_str));
								if(tc_strlen(item_modgrp_str)>0)
								{
									tc_strdup(item_modgrp_str,&item_modgrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_modgrp_strDup);
									printf("\n Module Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module",&item_mod_str));
								if(tc_strlen(item_mod_str)>0)
								{
									tc_strdup(item_mod_str,&item_mod_strDup);
								}
								else
								{
									tc_strdup(" ",&item_mod_strDup);
									printf("\n Module Value is NULL..!!");fflush(stdout);
								}
								item_modaddr_str = subString(item_id_strDup, 4, 5);
								trimwhitespace(item_modaddr_str);
								printf("\n Part Module Address Value: [%s]", item_modaddr_str);fflush(stdout);
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Part_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Part_Desc,&Part_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&item_plat_str));
									if(tc_strlen(item_plat_str)>0)
									{
										tc_strdup(item_plat_str,&item_plat_strDup);
									}
									else
									{
										tc_strdup(" ",&item_plat_strDup);
										printf("\n Platform Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_ProjectCode",&item_pcode_str));
									if(tc_strlen(item_pcode_str)>0)
									{
										tc_strdup(item_pcode_str,&item_pcode_strDup);
									}
									else
									{
										tc_strdup(" ",&item_pcode_strDup);
										printf("\n Project_Code Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									if(tc_strlen(item_drar_str)>0)
									{
										tc_strdup(item_drar_str,&item_drar_strDup);
									}
									else
									{
										tc_strdup(" ",&item_drar_strDup);
										printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
									}

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Aggregate_Group: [%s]\n",item_aggrp_strDup);fflush(stdout);
									printf("\n  Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
									printf("\n  Module_Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
									printf("\n  Module: [%s]\n",item_mod_strDup);fflush(stdout);
									printf("\n  Module_Address: [%s]\n",item_modaddr_str);fflush(stdout);
									printf("\n  Part Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Part Description: [%s]\n",Part_DescDup);fflush(stdout);
									printf("\n  Part Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Part Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part Platform: [%s]\n",item_plat_strDup);fflush(stdout);
									printf("\n  Part Project_Code: [%s]\n",item_pcode_strDup);fflush(stdout);
									printf("\n  Part DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
									Module_Address_Status = TC_ModuleAddrStatus(item_modaddr_str);
									tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
									
									if((tc_strcmp(item_ptype_strDup,"M")==0) && (tc_strcmp(item_typeDup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
									{
										fprintf(ModSpKitRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",DmlNo,item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup);fflush(ModSpKitRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not Vehicle Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--Vehicle Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int TC_ModuleRlzd_DML_Details(FILE* VehDMLRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tVItemobj     = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tvitemobj_results = NULLTAG;
	int n_ventries = 5;
	int n_vitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////  P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf(" Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tVItemobj));
    if(tVItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cvEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cvValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"MR"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","MR"};
		ITK_CALL(QRY_execute(tVItemobj, n_ventries, cvEntries, cvValues, &n_vitemobj_found, &tvitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(Module Released): [%d]\n",n_vitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_vitemobj_found > 0)
		{
			printf(" Release Type(Module Released) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_vitemobj_found; i++)
			{
				ErcDMLTag = tvitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"MR")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [Vehicle Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_string(revTag,"t5_AggregateGroup",&item_aggrp_str));
								if(tc_strlen(item_aggrp_str)>0)
								{
									tc_strdup(item_aggrp_str,&item_aggrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggrp_strDup);
									printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Aggregate",&item_aggr_str));
								if(tc_strlen(item_aggr_str)>0)
								{
									tc_strdup(item_aggr_str,&item_aggr_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggr_strDup);
									printf("\n Aggregate Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module_Group",&item_modgrp_str));
								if(tc_strlen(item_modgrp_str)>0)
								{
									tc_strdup(item_modgrp_str,&item_modgrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_modgrp_strDup);
									printf("\n Module Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module",&item_mod_str));
								if(tc_strlen(item_mod_str)>0)
								{
									tc_strdup(item_mod_str,&item_mod_strDup);
								}
								else
								{
									tc_strdup(" ",&item_mod_strDup);
									printf("\n Module Value is NULL..!!");fflush(stdout);
								}
								item_modaddr_str = subString(item_id_strDup, 4, 5);
								trimwhitespace(item_modaddr_str);
								printf("\n Part Module Address Value: [%s]", item_modaddr_str);fflush(stdout);
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Part_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Part_Desc,&Part_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&item_plat_str));
									if(tc_strlen(item_plat_str)>0)
									{
										tc_strdup(item_plat_str,&item_plat_strDup);
									}
									else
									{
										tc_strdup(" ",&item_plat_strDup);
										printf("\n Platform Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_ProjectCode",&item_pcode_str));
									if(tc_strlen(item_pcode_str)>0)
									{
										tc_strdup(item_pcode_str,&item_pcode_strDup);
									}
									else
									{
										tc_strdup(" ",&item_pcode_strDup);
										printf("\n Project_Code Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									if(tc_strlen(item_drar_str)>0)
									{
										tc_strdup(item_drar_str,&item_drar_strDup);
									}
									else
									{
										tc_strdup(" ",&item_drar_strDup);
										printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
									}

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Aggregate_Group: [%s]\n",item_aggrp_strDup);fflush(stdout);
									printf("\n  Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
									printf("\n  Module_Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
									printf("\n  Module: [%s]\n",item_mod_strDup);fflush(stdout);
									printf("\n  Module_Address: [%s]\n",item_modaddr_str);fflush(stdout);
									printf("\n  Part Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Part Description: [%s]\n",Part_DescDup);fflush(stdout);
									printf("\n  Part Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Part Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part Platform: [%s]\n",item_plat_strDup);fflush(stdout);
									printf("\n  Part Project_Code: [%s]\n",item_pcode_strDup);fflush(stdout);
									printf("\n  Part DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
									Module_Address_Status = TC_ModuleAddrStatus(item_modaddr_str);
									tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
									
									if((tc_strcmp(item_ptype_strDup,"M")==0) && (tc_strcmp(item_typeDup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
									{
										fprintf(VehDMLRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",DmlNo,item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup);fflush(VehDMLRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not Vehicle Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--Vehicle Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int TC_GMRlzd_DML_Details(FILE* GMDMLRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tGMItemobj    = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tgmitemobj_results = NULLTAG;
	int n_gmentries = 5;
	int n_gmitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf(" Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tGMItemobj));
    if(tGMItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cgmEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cgmValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"TODR"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","TODR"};
		ITK_CALL(QRY_execute(tGMItemobj, n_gmentries, cgmEntries, cgmValues, &n_gmitemobj_found, &tgmitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(GM Released): [%d]\n",n_gmitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_gmitemobj_found > 0)
		{
			printf(" Release Type(GM Released) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_gmitemobj_found; i++)
			{
				ErcDMLTag = tgmitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"TODR")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [GM Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMReferences",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_string(revTag,"t5_AggregateGroup",&item_aggrp_str));
								if(tc_strlen(item_aggrp_str)>0)
								{
									tc_strdup(item_aggrp_str,&item_aggrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggrp_strDup);
									printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Aggregate",&item_aggr_str));
								if(tc_strlen(item_aggr_str)>0)
								{
									tc_strdup(item_aggr_str,&item_aggr_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggr_strDup);
									printf("\n Aggregate Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module_Group",&item_modgrp_str));
								if(tc_strlen(item_modgrp_str)>0)
								{
									tc_strdup(item_modgrp_str,&item_modgrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_modgrp_strDup);
									printf("\n Module Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module",&item_mod_str));
								if(tc_strlen(item_mod_str)>0)
								{
									tc_strdup(item_mod_str,&item_mod_strDup);
								}
								else
								{
									tc_strdup(" ",&item_mod_strDup);
									printf("\n Module Value is NULL..!!");fflush(stdout);
								}
								
								item_modaddr_str = subString(item_id_strDup, 4, 5);
								trimwhitespace(item_modaddr_str);
								printf("\n Part Module Address Value: [%s]", item_modaddr_str);fflush(stdout);
								
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Part_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Part_Desc,&Part_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&item_plat_str));
									if(tc_strlen(item_plat_str)>0)
									{
										tc_strdup(item_plat_str,&item_plat_strDup);
									}
									else
									{
										tc_strdup(" ",&item_plat_strDup);
										printf("\n Platform Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_ProjectCode",&item_pcode_str));
									if(tc_strlen(item_pcode_str)>0)
									{
										tc_strdup(item_pcode_str,&item_pcode_strDup);
									}
									else
									{
										tc_strdup(" ",&item_pcode_strDup);
										printf("\n Project_Code Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									if(tc_strlen(item_drar_str)>0)
									{
										tc_strdup(item_drar_str,&item_drar_strDup);
									}
									else
									{
										tc_strdup(" ",&item_drar_strDup);
										printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
									}

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Aggregate_Group: [%s]\n",item_aggrp_strDup);fflush(stdout);
									printf("\n  Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
									printf("\n  Module_Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
									printf("\n  Module: [%s]\n",item_mod_strDup);fflush(stdout);
									printf("\n  Module_Address: [%s]\n",item_modaddr_str);fflush(stdout);
									printf("\n  Part Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Part Description: [%s]\n",Part_DescDup);fflush(stdout);
									printf("\n  Part Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Part Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part Platform: [%s]\n",item_plat_strDup);fflush(stdout);
									printf("\n  Part Project_Code: [%s]\n",item_pcode_strDup);fflush(stdout);
									printf("\n  Part DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
									Module_Address_Status = TC_ModuleAddrStatus(item_modaddr_str);
									tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
									
									if((tc_strcmp(item_ptype_strDup,"M")==0) && (tc_strcmp(item_typeDup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
									{
										fprintf(GMDMLRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",DmlNo,item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup);fflush(GMDMLRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not GM Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--GM Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	int ifail = ITK_ok;
	char *RptFile = (char *) malloc(100*sizeof(char));
	FILE *fpOutput_file = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}

	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"LibCreation_CronJob_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	printf("\n tm_LibraryCreationCronJob--Started \n");fflush(stdout);
	printf("\n Function1: DML Release Type - Module Release(MR) Details Find Start");fflush(stdout);
	TC_ModuleRlzd_DML_Details(fpOutput_file);
	printf("\n Function1: DML Release Type - Module Release(MR) Details Find End\n");fflush(stdout);
	printf("\n Function2: DML Release Type - Gate Maturation(TODR) Details Find Start");fflush(stdout);
	TC_GMRlzd_DML_Details(fpOutput_file);
	printf("\n Function2: DML Release Type - Gate Maturation(TODR) Details Find End\n");fflush(stdout);
	printf("\n Function3: DML Release Type - Module with Spare Kit Release(TSKR) Details Find Start");fflush(stdout);
	TC_ModuleSpareKitRlzd_DML_Details(fpOutput_file);
	printf("\n Function3: DML Release Type - Module with Spare Kit Release(TSKR) Details Find End\n");fflush(stdout);
	printf("\n Function4: DML Release Type - ECU Part Release(EP) Details Find Start");fflush(stdout);
	TC_ECUPartRlzd_DML_Details(fpOutput_file);
	printf("\n Function4: DML Release Type - ECU Part Release(EP) Details Find End\n");fflush(stdout);
    fclose(fpOutput_file);
	printf("\n tm_LibraryCreationCronJob--Completed \n");fflush(stdout);	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_LibraryCreationCronJob.c
* // ./linkitk -o tm_LibraryCreationCronJob tm_LibraryCreationCronJob.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LibraryCreationCronJob/tm_LibraryCreationCronJob .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LibraryCreationCronJob/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LibraryCreationCronJob/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LibraryCreationCronJob/SendEmail.sh .
* // ./tm_LibraryCreationCronJob -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_LibraryCreationCronJob -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/