/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Part & If Checked-Out Then Check-In  
*  File Name    :   tm_Part_Checkin.c
*  Created on   :   Nov 29th, 2023
*  Usage        :   tm_Part_Checkin
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     29/11/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int getPartObjFromRevSeq(char* partnumber, char* rev, tag_t *partObj)
{
	int ifail = ITK_ok;
	
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;
	char* revStr = NULL;
	int seqInt = 0;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Item ID";
	qry_entries[1] = "Type";
	//qry_entries[2] = "Sequence Id";
	
	qry_values[0] = partnumber;
	revStr = (char *) MEM_alloc( 10 * sizeof(char) );
	//tc_strcpy(revStr,"");
	tc_strcpy(revStr,rev);
	//tc_strcat(revStr,";");
	//tc_strcat(revStr,seq);
	
	qry_values[1] = "Design Revision";
	
	//trimLeading(revStr);
	char* revStr1 = NULL;
	char* revStr2 = NULL;
	revStr1 = trimwhitespace(revStr);
	revStr2 = trimwhitespace(revStr1);
	
	ITK_CALL(QRY_find2("Item Revision...", &query));
	if(query != NULLTAG)
	{
		printf("\n Item Revision... Found Successfully..!!\n");fflush(stdout);
	}
	ITK_CALL(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\n No of Revision Found: [%d]", count);fflush(stdout);

	if(count>0)
	{
		int k=0;
		char* revS = NULL;
		for(k=0;k<count;k++)
		{
			ITK_CALL(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revStr2)==0)
			{
				*partObj = itemObjs[k];
				break;
			}
			
		}
	}
	
	if(revStr!=NULL) MEM_free(revStr);
	return ifail;	

}

int tmCheckinPart(char* partNo, char* rev)
{
	int ifail = ITK_ok;
	tag_t partTag = NULLTAG;
	ITK_CALL(getPartObjFromRevSeq(partNo,rev,&partTag));
	if(partTag!=NULLTAG)
	{
		logical chkOut = FALSE;
		char* partname = NULL;
		ITK_CALL(AOM_ask_value_string(partTag,"object_string",&partname));
		printf("\n Part_No: [%s]\n",partname);fflush(stdout);
		RES_is_checked_out(partTag,&chkOut);
		if(chkOut)
		{
			RES_checkin(partTag);
			
		}
		else
		{
			printf("\nPart-[%s], Rev-[%s], Seq-[%s] is Already Checked-In..!!\n",partNo,rev);fflush(stdout);
		}
	}
	else
	{
		printf("\nPart-[%s], Rev-[%s], Seq-[%s] Not Found..!!\n",partNo,rev);fflush(stdout);
	}
	
	return ifail;
} 

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *Part_item_id = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	int ifail = ITK_ok;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_rev_str=strtok(NULL,"^");
			//item_seq_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			//if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_rev_strDup!=NULL)trimwhitespace(item_rev_strDup);
			//if(item_seq_strDup!=NULL)trimwhitespace(item_seq_strDup);
			
			printf(" Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf(" Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			//printf(" Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
			printf("\n ~~~~~~~~ F U N C T I O N - C A L L  S T A R T ~~~~~~~~\n");fflush(stdout); 
			ifail = tmCheckinPart(item_id_strDup,item_rev_strDup);
			printf("\n ~~~~~~~~ F U N C T I O N - C A L L  E N D ~~~~~~~~\n");fflush(stdout);
        }
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_Part_Checkin.c
* // ./linkitk -o tm_Part_Checkin tm_Part_Checkin.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Part_Checkin/tm_Part_Checkin .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Part_Checkin/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Part_Checkin/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Part_Checkin/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_Part_Checkin/SendEmail.sh .
* // tm_Part_Checkin -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_Part_Checkin -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_Part_Checkin -u=loader -p=loader123 -g=dba
*
***************************************************************************/