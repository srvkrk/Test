<?xml version="1.0" encoding="UTF-8"?>
<!--
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<!-- $Id: PlannerWiseDMLRpt.xsl,v 1.1 2018/06/25 12:45:57 smm914024 Exp root $ -->
<xsl:stylesheet version="1.1" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" exclude-result-prefixes="fo">
  <xsl:output method="xml" version="1.0" omit-xml-declaration="no" indent="yes"/>
  <xsl:param name="versionParam" select="'1.0'"/> 
  <!-- ========================= -->
  <!-- root element: projectteam -->
  <!-- ========================= -->
  <xsl:template match="PlannerWiseAPlRpdData">
    <fo:root xmlns:fo="http://www.w3.org/1999/XSL/Format">
      <fo:layout-master-set>
       <fo:simple-page-master master-name="simpleA4" page-height="21cm" page-width="29.7cm" margin-top="1cm" margin-bottom="1cm" margin-left="1cm" margin-right="1cm">
          <fo:region-body/>
        </fo:simple-page-master>
      </fo:layout-master-set>
      <fo:page-sequence master-reference="simpleA4">
        <fo:flow flow-name="xsl-region-body">
          <fo:block font-size="14pt" font-weight="bold" space-after="5mm" text-align="center" color = "#87cefa" text-decoration="underline">Planner Wise DML Report
          </fo:block>
		  <fo:block font-size="8pt" space-after="5mm">Planner : <xsl:value-of select="Planner"/>
          </fo:block>
          <fo:block font-size="8pt" space-after="5mm">From Date :  <xsl:value-of select="FromDate"/> 
          </fo:block>
		  <fo:block font-size="8pt" space-after="5mm">To Date : <xsl:value-of select="ToDate"/>
          </fo:block>
  	
		 <fo:block font-size="4pt">
       <fo:table keep-with-previous.within-page="always" page-break-inside="avoid" table-layout="fixed" border-width="0pt" border-style="solid">
       	<fo:table-column column-width="1%"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="10%"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="2%"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="8%"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="3%"/>
		  
          <fo:table-body>
              <fo:table-row>
			      <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          SR.
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          DML NO.
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          DESCRIPTION
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          ERC REL DATE
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				           APL REL DATE
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				           STDSI REL DATE
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          TASK NO.
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				         PART NUMBER
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          REV
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          PART DESC
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          DRAWING MODIFICATION DETAILS
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          ADD INDENT
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          AMATL INDENT
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				         EPA No.
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="0pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          DR STATUS
				        </fo:block>							
			      </fo:table-cell>
				 
			   </fo:table-row>   
            <xsl:apply-templates select="rptrow1"/>
          </fo:table-body>            
       </fo:table>
     	</fo:block>     	
        </fo:flow>
      </fo:page-sequence>
    </fo:root>
  </xsl:template>

  <!-- ========================= -->
  <!-- child element: member     -->
  <!-- ========================= -->
  <xsl:template match="PlannerWiseAPlRpdData/rptrow1">
    <fo:table-row>

      <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="SrNo"/>
        </fo:block>
      </fo:table-cell>
       <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="DmlNum"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="DmlNumDes"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="ERCRlzDate"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="APLRlzDate"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="StdRlzDate"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="TaskNum"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
         <xsl:value-of select="Pnum"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="Prev"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="PDesc"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="PDModDet"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
         <xsl:value-of select="AddInd"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="AmaInd"/>
        </fo:block>
      </fo:table-cell>
	   <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="Epanum"/>
        </fo:block>
      </fo:table-cell>
	  <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="DmlDRStatus"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	
  </xsl:template>  
</xsl:stylesheet>
