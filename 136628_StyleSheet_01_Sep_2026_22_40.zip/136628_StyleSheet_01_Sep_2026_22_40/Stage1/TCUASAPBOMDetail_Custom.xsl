<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
					<Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Report Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="PLMXML/@date"/>
                            </Data>
                        </Cell>      
                        <Cell ss:StyleID="s22" ss:MergeAcross='3'>
                            <Data ss:Type='String'>TCUA-BOM Detail report</Data>
                        </Cell>
                    </Row>
					<Row></Row>
					<Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part Number</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="PLMXML/@designrevName"/>
                            </Data>
                        </Cell>  
						<Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part Rev Seq</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="PLMXML/@PrtRevSeq"/>
                            </Data>
                        </Cell> 						
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Plant</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="PLMXML/@iSapPlant"/>
                            </Data>
                        </Cell>  
                    </Row>
					<Row></Row>
					
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>S.NO</Data>
                        </Cell>
						 <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Level</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part No</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Description</Data>
                        </Cell> 
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Revision Level</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Data in SAP status (Yes/No)</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DML No</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Task No</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part Type</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part DR Status</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Qty</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>CS</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>LCS</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Project Code</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Design Group</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateDesignRevPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateDesignRevPartsList">
        <xsl:for-each select="PLMXML/DesignRevision">
			<Row>
               
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='slNo']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='Level']"/></Data>
				</Cell>
			     <Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='ChildRevName']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='description']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='Revision_ID']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='bomValue']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='finalDMLName']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='finalTaskName']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='ChildPartType']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='ChildPartDRStatus']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String' ><xsl:value-of select="field[@key='ChildPrtQty']"/></Data>
				</Cell> 
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String' ><xsl:value-of select="field[@key='make_buy_ind']"/></Data>
				</Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='ChildRelStatus']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='ChildPrjCode']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='ChildDesignGrp']"/></Data>
                </Cell>
               
			</Row>
        </xsl:for-each>
    </xsl:template>
    
</xsl:stylesheet>