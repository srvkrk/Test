<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
           xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
           xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
           xmlns="urn:schemas-microsoft-com:office:spreadsheet"
           xmlns:o="urn:schemas-microsoft-com:office:office"
           xmlns:x="urn:schemas-microsoft-com:office:excel"
           xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
           xmlns:html="http://www.w3.org/TR/REC-html40" >



  <xsl:output method="xml" version="1.0" indent="yes" />

  <xsl:strip-space elements="*"/>


  <xsl:template match="/">
  
  <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
    <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
      xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:x="urn:schemas-microsoft-com:office:excel"
      xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
      xmlns:html="http://www.w3.org/TR/REC-html40">

      <Styles>
        <Style ss:ID="s22">
          <Interior ss:Color="#FBFFDE" ss:Pattern="Solid"/>
		  <Font ss:Bold="1" ss:FontName="Calibri" x:Family="Swiss" ss:Size="9" ss:Color="#000000" />
		 <Borders>
		  <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#000000"/>
		  <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#000000"/>
		  <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#000000"/>
		  <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#000000"/>
		 </Borders>		  
        </Style>
        <Style ss:ID="s23">
          <Font ss:Color="#FF0000"/>
        </Style>
        <!-- fix me: may be use different color -->
        <Style ss:ID="s24">
          <Font ss:Color="#FF0000"/>
        </Style>
		
		<Style ss:ID="Default" ss:Name="Normal">
		 <Font ss:Bold="0" ss:FontName="Calibri" x:Family="Swiss" ss:Size="10" ss:Color="#000000" />
		 <Borders />
		 <Alignment ss:Horizontal="Left" ss:Vertical="Top" ss:WrapText="0" />
		 <Interior ss:Color="#FFFFFF" ss:Pattern="Solid" />
		 <NumberFormat ss:Format="General" />
		</Style>
		
		<Style ss:ID="Default2">
		 <Font ss:Bold="0" ss:FontName="Calibri" x:Family="Swiss" ss:Size="9" ss:Color="#000000" />
		 <Borders>
		  <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#000000"/>
		  <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#000000"/>
		  <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#000000"/>
		  <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#000000"/>
		 </Borders>
		 <Alignment ss:Horizontal="Left" ss:Vertical="Top" ss:WrapText="0" />
		 <Interior ss:Color="#FFFFFF" ss:Pattern="Solid" />
		 <NumberFormat ss:Format="General" />
		</Style>
		
		<Style ss:ID="LHead" ss:Parent="Default2">
		 <Font ss:Bold="1" ss:FontName="Calibri" x:Family="Swiss" ss:Size="12" ss:Color="#FFFFFF" />
		 <Interior ss:Color="#0083BE" ss:Pattern="Solid" />
		</Style>
		
		<Style ss:ID="RHead" ss:Parent="Default2">
		 <Font ss:Bold="1" ss:FontName="Calibri" x:Family="Swiss" ss:Size="9" ss:Color="#FFFFFF" />
		 <Alignment ss:Horizontal="Right" ss:Vertical="Top" ss:WrapText="0" />
		 <Interior ss:Color="#0083BE" ss:Pattern="Solid" />
		</Style>
		
		<Style ss:ID="Num" ss:Parent="Default2">
		 <Alignment ss:Horizontal="Right" ss:Vertical="Top" />
		 <NumberFormat ss:Format="_(* #,##0.00_);_(* \(#,##0.00\);_(* &quot;-&quot;??_);_(@_)" />
		</Style>
		
		<Style ss:ID="Date" ss:Parent="Default2">
		 <NumberFormat ss:Format="dd\-mmm\-yyyy" />
		</Style>
		
		<Style ss:ID="NumBold" ss:Parent="Num">
		 <Font ss:Bold="1" ss:FontName="Calibri" x:Family="Swiss" ss:Size="9" ss:Color="#000000" />
		</Style>
		
		<Style ss:ID="DefBold" ss:Parent="Default2">
		 <Font ss:Bold="1" ss:FontName="Calibri" x:Family="Swiss" ss:Size="9" ss:Color="#000000" />
		</Style>
		
      </Styles>

      <Worksheet ss:Name="Sheet1">

        <Table ss:StyleID="Default2">
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
		  <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
		  <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
		  <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
          <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>

          <Row>
            <Cell ss:StyleID="LHead">
              <Data ss:Type="String">
                FDJ Status Report
              </Data>
            </Cell>
          </Row>
		  <Row>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                FROM Date
              </Data>
            </Cell>
			<Cell>
				<Data ss:Type="String">
				  <xsl:value-of  select="PLMXML/@FromDate"/>
				</Data>
			  </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                TO Date
              </Data>
            </Cell>
			<Cell>
				<Data ss:Type="String">
				  <xsl:value-of  select="PLMXML/@ToDate"/>
				</Data>
			  </Cell>			  
          </Row>
          <Row>
		   <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Sr No
              </Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML No
              </Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Business Unit
              </Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Description
              </Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Project Code
              </Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Project Description
              </Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Release Status
              </Data>
            </Cell>
			
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Release Type
              </Data>
            </Cell>
			
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML DR Status
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Release Date
              </Data>
            </Cell>				
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Creator
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Creation Date
              </Data>
            </Cell>
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Owner
              </Data>
            </Cell>
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Design Group
              </Data>
            </Cell>
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Vertical
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML WBS No
              </Data>
            </Cell>
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                DML Reason
              </Data>
            </Cell>
			
			
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part No
              </Data>
            </Cell>	

			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part Revision
              </Data>
            </Cell>	
			
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part DR Status
              </Data>
            </Cell>	

			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part Description
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part Owner Design Unit
              </Data>
            </Cell>	
			
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part Owner
              </Data>
            </Cell>			
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part LC Status
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part Project
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part Design Group
              </Data>
            </Cell>
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part Type
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Part Modification Description
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Coated Indication
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Colour Indicator
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                Drawing Indicator
              </Data>
            </Cell>		

			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                FDJ Number
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                FDJ Status
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                FDJ Gr No.
              </Data>
            </Cell>		
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                FDJ Gr Date
              </Data>
            </Cell>	
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                FDJ Remark
              </Data>
            </Cell>		
			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                FDJ Creator
              </Data>
            </Cell>		

			<Cell ss:StyleID="s22">
              <Data ss:Type="String">
                FDJ Creation Date
              </Data>
            </Cell>				
          </Row>
		<xsl:apply-templates select="//DMLDetails"/>
        </Table>
        <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
          <Selected/>
          <ProtectObjects>False</ProtectObjects>
          <ProtectScenarios>False</ProtectScenarios>
        </WorksheetOptions>
      </Worksheet>
    </Workbook>

  </xsl:template>

  <xsl:template match="DMLDetails">
    <xsl:for-each select="PartDetails">
      <Row>
			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../SrNo"/>
				</Data>
			  </Cell>				
			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLNo"/>
				</Data>
			  </Cell>
			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLBusUnit"/>
				</Data>
			  </Cell>
			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLSynopsis"/>
				</Data>
			  </Cell>
			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLProjCode"/>
				</Data>
			  </Cell>
			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLProjDesc"/>
				</Data>
			  </Cell>
			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLRelStat"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLRelType"/>
				</Data>
			  </Cell>
			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLDRStat"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLReleaseDate"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLCreator"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLCreationDate"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLOwner"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLDesgGrp"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLVertical"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLWbsNo"/>
				</Data>
			  </Cell>

			  <Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="../DMLReason"/>
				</Data>
			  </Cell>
			  
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartNo"/>
				</Data>
			</Cell>	
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartRev"/>
				</Data>
			</Cell>					
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartDRStatus"/>
				</Data>
			</Cell>

			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartDesc"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartOwnerDesUnit"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartOwner"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartLCStatus"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartProject"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartDesgGrp"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartType"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartModDesc"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartCoatedInd"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartColorInd"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="PartDrwInd"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="FDJNum"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="FDJStatus"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="FdjGrNo"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="FdjGrDateNo"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="FdjRemark"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="FdjCreator"/>
				</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				<xsl:value-of select="FdjCreationDate"/>
				</Data>
			</Cell>
			</Row>
    </xsl:for-each>
  </xsl:template>


</xsl:stylesheet>
