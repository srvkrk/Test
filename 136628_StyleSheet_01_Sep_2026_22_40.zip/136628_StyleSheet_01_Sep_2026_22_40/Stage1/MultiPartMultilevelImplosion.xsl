<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="50"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="300" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Row>  
                        <Cell ss:StyleID="s22" ss:MergeAcross='10'>
                            <Data ss:Type='String'>Multi_Part_Multilevel_Implosion</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="PLMXML/@date"/>
                            </Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row>
					
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Level</Data>
                        </Cell>
						 <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Assembly_NO</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Rev/Seq</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>OwnerName</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>LifeCycleState</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Description</Data>
                        </Cell>
						 <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>UnitOfMeasureS</Data>
                        </Cell>
						 <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>JsrMakeBuyIndicator</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>PunMakeBuyIndicator</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>SndMakeBuyIndicator</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>LkoMakeBuyIndicator</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DwdMakeBuyIndicator</Data>
                        </Cell>
						 <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>PartType</Data>
                        </Cell>
						 <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Component_Part</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateDesignRevPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateDesignRevPartsList">
        <xsl:for-each select="PLMXML/DesignRevision">
			<Row>

			
			
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='Count']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='Part_ID']"/></Data>
				</Cell>
			     <Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='rev_seq']"/></Data>
				</Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='OwnerName']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='LcsState']"/></Data>
				</Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Description']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='UnitOfMeasureS']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='JsrMakeBuyIndicator']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='PunMakeBuyIndicator']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='SndMakeBuyIndicator']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='LkoMakeBuyIndicator']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='DwdMakeBuyIndicator']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='PartType']"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='PartentItem']"/></Data>
                </Cell>
				
			</Row>
        </xsl:for-each>
    </xsl:template>
    
</xsl:stylesheet>