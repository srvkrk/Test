<?xml version="1.0" encoding="UTF-8"?>
<!--
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<!-- $Id: APLDMLBetweenDatesReport.xsl,v 1.1 2018/06/25 12:48:00 smm914024 Exp root $ -->
<xsl:stylesheet version="1.1" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" exclude-result-prefixes="fo">
  <xsl:output method="xml" version="1.0" omit-xml-declaration="no" indent="yes"/>
  <xsl:param name="versionParam" select="'1.0'"/> 
  <!-- ========================= -->
  <!-- root element: projectteam -->
  <!-- ========================= -->
  <xsl:template match="APLDMLBetweenDateReport">
    <fo:root xmlns:fo="http://www.w3.org/1999/XSL/Format">
      <fo:layout-master-set>
        <fo:simple-page-master master-name="simpleA4" page-height="auto" page-width="80cm" margin-top="2cm" margin-bottom="2cm" margin-left="2cm" margin-right="2cm">
          <fo:region-body/>
        </fo:simple-page-master>
      </fo:layout-master-set>
      <fo:page-sequence master-reference="simpleA4">
        <fo:flow flow-name="xsl-region-body">
          <fo:block font-size="14pt" font-weight="bold" space-after="5mm" color = "black" text-decoration="underline">APL DML Released Between Dates for APL
          </fo:block>
          <fo:block font-size="12pt" space-after="5mm">Report Fired Date :  <xsl:value-of select="ReportFiredDate"/> 
          </fo:block>
		  <fo:block font-size="12pt" space-after="5mm">From Date : <xsl:value-of select="fromDate"/>
          </fo:block>
		  <fo:block font-size="12pt" space-after="5mm">To Date: <xsl:value-of select="ToDate"/>
          </fo:block>    
		<fo:block font-size="10pt">
       <fo:table table-layout="fixed" width="100%" border-collapse="separate">
       	<fo:table-column column-width="3cm"/>
          <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="5%"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
		  <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
          <fo:table-body>
            <fo:table-row>
			      <fo:table-cell border="1pt solid black" background-color = "#0099ff" >
				        <fo:block font-size="12pt" color = "black">
				          Serial No
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
				          Project Code 
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
				          Design Group
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
				          DML Number
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
				          DR Status
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
				          DCR Status
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
				          DML Description
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
				          Reason Decription
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 Designer
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 Part Number
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 Revision
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 Sequence
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 Part Description
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 ERC Release Date
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 APL Planner
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						Reviewer
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						APL Release Date
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 STD Planner
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 STD Release Date
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 Lifecycle State
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 EPA Number
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 EPA Status
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 EPA Finalized Date
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 Remarks
				        </fo:block>			      
			      </fo:table-cell>
				  <fo:table-cell border="1pt solid black" background-color = "#0099ff">
				        <fo:block font-size="12pt"  color = "black">
						 MBPA Number
				        </fo:block>			      
			      </fo:table-cell>
			   </fo:table-row> 
			    <xsl:apply-templates select="Header_Column"/>
          </fo:table-body>            
       </fo:table>
     	</fo:block>
        </fo:flow>
      </fo:page-sequence>
	  </fo:root>
     </xsl:template>
    
 

  <!-- ========================= -->
  <!-- child element: member     -->
  <!-- ========================= -->
  <xsl:template match="APLDMLBetweenDateReport/Header_Column">
  <!--<xsl:template match="APLDMLBetweenDateReport">-->
    <fo:table-row>
	 <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="SrNo"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Project_Code"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Design_Group"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="DML_Number"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="DR_Status"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="DCR_Status"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="DML_Description"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Reason_Description"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Designer"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Part_Number"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Revision"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Sequence"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Part_Description"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="ERC_Released_Date"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="APL_Planner"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Reviewer"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="APL_released_Date"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="STD_PLanner"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="STD_Release_Date"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="LifecycleState"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="EPA_Number"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="EPA_Status"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="EPA_finalized_Date"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="Remarks"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="0.5pt solid black">
        <fo:block text-align="center" space-after="5mm">
          <xsl:value-of select="MBPA_Number"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	</xsl:template>
	</xsl:stylesheet>
