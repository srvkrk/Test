<?xml version="1.0" encoding="UTF-8"?>
<!--
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<!-- $Id: APLSummaryRpt.xsl,v 1.1 2018/06/25 12:42:28 smm914024 Exp root $ -->
<xsl:stylesheet version="1.1" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" exclude-result-prefixes="fo">
  <xsl:output method="xml" version="1.0" omit-xml-declaration="no" indent="yes"/>
  <xsl:param name="versionParam" select="'1.0'"/> 
  <!-- ========================= -->
  <!-- root element: projectteam -->
  <!-- ========================= -->
  <xsl:template match="AplRptData">
    <fo:root xmlns:fo="http://www.w3.org/1999/XSL/Format">
      <fo:layout-master-set>
        <fo:simple-page-master master-name="simpleA4" page-height="29.7cm" page-width="21cm" margin-top="2cm" margin-bottom="2cm" margin-left="2cm" margin-right="2cm">
          <fo:region-body/>
        </fo:simple-page-master>
      </fo:layout-master-set>
      <fo:page-sequence master-reference="simpleA4">
        <fo:flow flow-name="xsl-region-body">
          <fo:block font-size="14pt" font-weight="bold" space-after="5mm" text-align="center" color = "#87cefa" text-decoration="underline">APL SUMMARY REPORT
          </fo:block>
          <fo:block font-size="12pt" space-after="5mm">From Date :  <xsl:value-of select="FromDate"/> 
          </fo:block>
		  <fo:block font-size="12pt" space-after="5mm">To Date : <xsl:value-of select="ToDate"/>
          </fo:block>
		  <fo:block font-size="12pt" space-after="5mm">Planner : <xsl:value-of select="Planner"/>
          </fo:block>
          <fo:block font-size="10pt">
       <fo:table table-layout="fixed" width="100%" border-collapse="separate">
       	<fo:table-column column-width="9cm"/>
          <fo:table-column column-width="9cm"/>
          <fo:table-body>
            <fo:table-row>
			      <fo:table-cell number-columns-spanned="2" border="0pt solid black">
				        <fo:block font-size="12pt" background-color = "#87cefa" color = "black">
				          TOTAL DML RELEASE
				        </fo:block>			      
			      </fo:table-cell>
			   </fo:table-row> 
			    <xsl:apply-templates select="cd"/>
			   
          </fo:table-body>            
       </fo:table>
     	</fo:block>
       <fo:block font-size="10pt">
       <fo:table table-layout="fixed" width="100%" border-collapse="separate">
       	<fo:table-column column-width="9cm"/>
          <fo:table-column column-width="9cm"/>
          <fo:table-body>
              <fo:table-row>
			      <fo:table-cell number-columns-spanned="2" border="0pt solid black">
				        <fo:block font-size="12pt" background-color = "#87cefa" color = "black">
				          APL INTERNAL ACTIONS
				        </fo:block>			      
			      </fo:table-cell>
			   </fo:table-row>   
             <xsl:apply-templates select="ef"/>
			
          </fo:table-body>            
       </fo:table>
     	</fo:block>     	
		 <fo:block font-size="10pt">
       <fo:table table-layout="fixed" width="100%" border-collapse="separate">
       	<fo:table-column column-width="9cm"/>
          <fo:table-column column-width="9cm"/>
          <fo:table-body>
              <fo:table-row>
			      <fo:table-cell number-columns-spanned="2" border="0pt solid black">
				        <fo:block font-size="12pt" background-color = "#87cefa" color = "black">
				          ADD INDENT ACTIONS
				        </fo:block>			      
			      </fo:table-cell>
			   </fo:table-row>   
            <xsl:apply-templates select="gh"/>
          </fo:table-body>            
       </fo:table>
     	</fo:block>     	
        </fo:flow>
      </fo:page-sequence>
    </fo:root>
  </xsl:template>

  <!-- ========================= -->
  <!-- child element: member     -->
  <!-- ========================= -->
  <xsl:template match="AplRptData/cd">
    <fo:table-row>

      <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          Total DML Released by ERC(A) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left" space-after="5mm">
          <xsl:value-of select="dmlRelByERC"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	<fo:table-row>

      <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          DML released within 15 Days (B) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left" space-after="5mm">
          <xsl:value-of select="dmlrelwithinlimit"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	<fo:table-row>	
      <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          DML released exceed 15 Days in last 45 Days (List1) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left" space-after="5mm">
          <xsl:value-of select="dmlrelafterlimit"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	<fo:table-row>	
      <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
          DML Pending after 15 days (C) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left" space-after="5mm">
          <xsl:value-of select="dmlpndgafterlimit"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	<fo:table-row>	
      <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
         DML Pending exceed 15 days :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left" space-after="5mm">
          <xsl:value-of select="dmlpndgabovelimit"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	<fo:table-row>	
      <fo:table-cell border="0pt solid black">
        <fo:block space-after="5mm">
         Efficency (B * 100 / (A-C)) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left" space-after="5mm">
          <xsl:value-of select="effA"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>	
  </xsl:template>
  
  <xsl:template match="AplRptData/ef">

    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
         DML Internal actions decided (D) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="DMLInternalActDec"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
          DML Internal actions to be decided (List4) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="DMLInternalActtobeDec"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
		    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
          DML Internal actions Completed (E) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="DMLInternalActComlted"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
			    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
         DML Internal action Decided but not completed (List5) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="DMLInternalActDecBtNComlted"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	
			    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
        Decided Efficency (D * 100 / (A-C)) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="DecEff"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
		    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
        Completed Efficency (E * 100 / (A-C)) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="CompEff"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
  </xsl:template>  
  
  
  <xsl:template match="AplRptData/gh">

    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
         Total ADD Indent Released by APL (F) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="ADDIRAPL"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
          Indent action to be decided :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="IndActDec"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	
			    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
         Indent Not required (G) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="IndNtReq"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
	
			    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
       Indent Applicable but not released :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="IndAppBtNtRel"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
		    <fo:table-row>
      <fo:table-cell border="0pt solid black">
        <fo:block>
        Efficiency ((F+G) * 100 / (A-C)) :
        </fo:block>
      </fo:table-cell>
      <fo:table-cell border="0pt solid black">
        <fo:block text-align="left">
          <xsl:value-of select="Effiency"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
	
  </xsl:template>  
</xsl:stylesheet>
