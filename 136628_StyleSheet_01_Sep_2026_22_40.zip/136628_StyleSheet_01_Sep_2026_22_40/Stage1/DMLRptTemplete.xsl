<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.1" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
				xmlns:java="http://xml.apache.org/xslt/java" 
				xmlns:part="http://www.w3.org"
				xmlns:fo="http://www.w3.org/1999/XSL/Format" exclude-result-prefixes="java fo">
				
				
  <xsl:output method="xml" version="1.0"  encoding="UTF-8" omit-xml-declaration="no" indent="yes"/>
  <xsl:param name="versionParam" select="'1.0'"/> 
  
  <xsl:variable name="fo:layout-master-set">
		<fo:layout-master-set>
			<fo:simple-page-master master-name="page-master-0-even" margin-left="0.492in" margin-right="0.492in" page-height="11.693in" page-width="8.268in" margin-top="0.492in" margin-bottom="0.492in">
				<fo:region-body margin-top="0.51in" margin-bottom="0.51in" column-count="1" column-gap="0.50in"/>
				<fo:region-before region-name="even-page-header" overflow="hidden" extent="0.51in"/>
				<fo:region-after region-name="even-page-footer" overflow="hidden" extent="0.51in"/>
			</fo:simple-page-master>
			<fo:simple-page-master master-name="page-master-0-odd" margin-left="0.492in" margin-right="0.492in" page-height="11.693in" page-width="8.268in" margin-top="0.492in" margin-bottom="0.492in">
				<fo:region-body margin-top="0.51in" margin-bottom="0.51in" column-count="1" column-gap="0.50in"/>
				<fo:region-before region-name="odd-page-header" overflow="hidden" extent="0.51in"/>
				<fo:region-after region-name="odd-page-footer" overflow="hidden" extent="0.51in"/>
			</fo:simple-page-master>
			<fo:page-sequence-master master-name="page-master-0">
				<fo:repeatable-page-master-alternatives>
					<fo:conditional-page-master-reference master-reference="page-master-0-even" odd-or-even="even"/>
					<fo:conditional-page-master-reference master-reference="page-master-0-odd" odd-or-even="odd"/>
				</fo:repeatable-page-master-alternatives>
			</fo:page-sequence-master>
		</fo:layout-master-set>
	</xsl:variable>
	
	<xsl:template match="report">
		<fo:root>
			<xsl:copy-of select="$fo:layout-master-set"/>
			<fo:page-sequence force-page-count="no-force" master-reference="page-master-0" initial-page-number="auto" format="1">
				<fo:static-content flow-name="odd-page-header">
					<fo:block-container overflow="hidden" display-align="before">
						<fo:block>	<fo:table width="100%" table-layout="fixed" border-spacing="2pt">
									<fo:table-column column-width="10.400in"/>
								
									<fo:table-body start-indent="0pt">
										
											<fo:table-row>	<fo:table-cell font-size="10pt" padding="0" display-align="center">
															<fo:block text-align="left">
																<fo:inline>	<xsl:text>DML Print Report: [</xsl:text><xsl:value-of select="java:format(java:java.text.SimpleDateFormat.new('yyyy-MM-dd HH:mm:ss.SSS'), java:java.util.Date.new())" /> <xsl:text> ]</xsl:text></fo:inline>
															</fo:block>
															</fo:table-cell>
											</fo:table-row>
											<fo:table-row>	<fo:table-cell padding="0" display-align="center">
															<fo:block text-align="left">
															<fo:block text-align="center">
																<fo:leader leader-pattern="rule" rule-thickness="1" leader-length="100%" color="black"/>
															</fo:block>
															</fo:block>
															</fo:table-cell>
											</fo:table-row>
										
									</fo:table-body>
									</fo:table>
						</fo:block>
					</fo:block-container>
				</fo:static-content>
				
				<fo:static-content flow-name="even-page-header">
					<fo:block-container overflow="hidden" display-align="before">
						<fo:block>	<fo:table width="100%" table-layout="fixed" border-spacing="2pt">
									<fo:table-column column-width="10.400in"/>
									
									<fo:table-body start-indent="0pt">
									
										<fo:table-row>	<fo:table-cell font-size="10pt" padding="0" display-align="center">
														<fo:block text-align="left">
															<fo:inline>	<xsl:text>DML Print Report : [</xsl:text><xsl:value-of select="java:format(java:java.text.SimpleDateFormat.new('yyyy-MM-dd HH:mm:ss.SSS'), java:java.util.Date.new())" /> <xsl:text> ]</xsl:text></fo:inline>
														</fo:block>
														</fo:table-cell>
										</fo:table-row>
										<fo:table-row> <fo:table-cell padding="0" display-align="center">
														<fo:block text-align="left">
															<fo:block text-align="center">
																<fo:leader leader-pattern="rule" rule-thickness="1" leader-length="100%" color="black"/>
															</fo:block>
														</fo:block>
														</fo:table-cell>
										</fo:table-row>
									
									</fo:table-body>
									</fo:table>
						</fo:block>
					</fo:block-container>
				</fo:static-content>
				
				<fo:static-content flow-name="odd-page-footer">
					<fo:block-container height="0.51in" overflow="hidden" display-align="after">
						<fo:block>	<fo:table width="100%" table-layout="fixed" border-spacing="2pt">
									<fo:table-column column-width="90%"/>
									<fo:table-column column-width="10%"/>
									
									<fo:table-body start-indent="0pt">
									
										<fo:table-row> 	<fo:table-cell number-columns-spanned="2" padding="0" display-align="center">
															<fo:block text-align="left">
															<fo:block text-align="center">
																<fo:leader leader-pattern="rule" rule-thickness="1" leader-length="100%" color="black"/>
															</fo:block>
															</fo:block>
														</fo:table-cell>
										</fo:table-row>
										<fo:table-row>
														<fo:table-cell font-size="10pt" padding="0" display-align="center">
															<fo:block text-align="left">
															<fo:inline font-weight="bold">
																<xsl:text>Document:</xsl:text>
															</fo:inline>
															</fo:block>
														</fo:table-cell>
														<fo:table-cell font-size="10pt" padding="0" display-align="center">
															<fo:block text-align="right">
															<fo:inline font-weight="bold">
																<xsl:text>Page: </xsl:text> </fo:inline> <fo:page-number font-weight="bold"/>
															</fo:block>
														</fo:table-cell>
										</fo:table-row>
									
									</fo:table-body>
									</fo:table>
						</fo:block>
					</fo:block-container>
				</fo:static-content>
				
				<fo:static-content flow-name="even-page-footer">
					<fo:block-container height="0.51in" overflow="hidden" display-align="after">
						<fo:block>	<fo:table width="100%" table-layout="fixed" border-spacing="2pt">
									<fo:table-column column-width="90%"/>
									<fo:table-column column-width="10%"/>
									
									<fo:table-body start-indent="0pt">
									
										<fo:table-row>	<fo:table-cell number-columns-spanned="2" padding="0" display-align="center">
															<fo:block text-align="left">
															<fo:block text-align="center">
																<fo:leader leader-pattern="rule" rule-thickness="1" leader-length="100%" color="black"/>
															</fo:block>
															</fo:block>
														</fo:table-cell>
										</fo:table-row>
										<fo:table-row>
														<fo:table-cell font-size="10pt" padding="0" display-align="center">
															<fo:block text-align="left">
															<fo:inline font-weight="bold">	<xsl:text>Document: DML Print Report[Moni]</xsl:text>	</fo:inline>
															</fo:block>
														</fo:table-cell>
														<fo:table-cell font-size="10pt" padding="0" display-align="center">
															<fo:block text-align="right">
															<fo:inline font-weight="bold">	<xsl:text>Page: </xsl:text>	</fo:inline> <fo:page-number font-weight="bold"/>
															</fo:block>
														</fo:table-cell>
										</fo:table-row>
									
									</fo:table-body>
									</fo:table>
						</fo:block>
					</fo:block-container>
				</fo:static-content>
				
				
				<fo:flow flow-name="xsl-region-body">
					<fo:block>
					<!-- Start Report Header-->
					
						<fo:block  text-align="Center" font-family="Tahoma" font-size="small" margin-right="100% - 100%" space-before="0" space-after="0" margin="0pt">
						<fo:table >
							<fo:table-column column-width="40%"/>
							<fo:table-column column-width="50%"/>
							<fo:table-column column-width="10%"/>
							<fo:table-body >
								
									<fo:table-row>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="left">
												<fo:inline>	<fo:external-graphic src="url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAAkCAYAAACKRBSIAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuMTCtCgrAAAAFHUlEQVRoQ+3XPatcVRQG4PwHf4iVhZ2gYGNn5y9QG5uACEYshNgEsbBQwUIFBTGoScQPRBKMSAIJUQKaCEEiSgJBuaKEIIz32bnvdc25ewbtdrEPvHPOedf3WnvvmTm0Wq0mBkeXnBgLXXJiLHTJibHQJSfGQpecGAtdcmIsdMmJsdAlJ8ZCl5wYC11yYix0yYmx0CUnxkKXnBgLXXJiLHTJibHQPn6+ubO69uvvW0EnRrf+uH1AHtnOX3cOyHq4+duf+zbbZJtQ43j+rzJY1queTbIlosfvUncZq+erVxtum077ePTFz1b3Hv5gdd/TH3ZB9thLXzZDBR195/ya/kPPnVqdv3KjyT+9eH31wLMn1+yXYHv0+KWmf/mnWwdkT7xypsm2QZx7nnyv6b/xxQ+71L+yt05fbTy8e/rKvkwT6T7ywict1v3PfNRw+M1zqwtX7+ZPFr81J9zDz3/cdK7d2Gn5qzM+4Njxi63JdDRaHWz51GO+Hn/17H4s0De9paeP7kfePrc28PZBScAHj5xqiVTgyNI4TgWsOpy/fPK7Jj9z6XpLig2+6kVXssdOfNv03elWHXKNIN8EQ9IY/p56/eyavnrw5HVIcuSbvjxBY+mqiQ9+T3z9YxsmP3x4xpFZpJqYofDx1eVfGse3uwGBODg9Mxjx2Vnk2b3i6pc8+RHHPTlD+xCMcyuqDsozjixDkPCyqYo0REXaGVYZG1zVUzQe3v/mWlstVR7wn522CclDgeJnJ8tBY/B1SOQ4/utA5SAfNlk44KjSZCu7Hj/yxml05enHf4YZ+1x2GR09ZSuPukB2r+ZrifbBIeToSbM848gUI5GsUvIMNO9WgSv6jp0MlI7GS4b89p2/26A0krz6CeqWX0JDFafBYrz2+fe79N0Fx9YQ5e+OJ6dH33uFpmoehJNnmqzu8Im3V+uan+xUsaq9Z0hOclSbHqhB3XQtqDr4YO2FwnJIe0btsrXTVI6tiOh6V4AB7F7NnyFkSO5JLlcGDnYdeI4/Q9691nIMNESBCmfnrNcIPvHy1iAx6Vv56un5dLywUVu4TUPi3zCXRxIYdmJa3OzVnQWgLj3a89cuccRmp2b+u8ddsG1ImqsRdg9nguMkkh0lWA2wbUj0ljJFShKXwfHTgwWSeAalwQagGVbyckjZSb1j9P/spCxMNuGC7BQLKPbe9UFc/tVkgMsLZ4DpbY25FmTbkDjJLuIkx0Y9stzz3RXZchAZUhIC8hwflVdUrxmQHeML2aDo1pwVmSGJWQdRdzvQkXv9Tto0pHpkVT+eLWJ5i+U99tHJr04+HHWu9MPFRv3LmO0j2DYkK6E23NHHBhSYxmre3krZOKRscTybsroOOZfDg2MKv4Q4icUfH/LAkStS/opWg7iaRgdnuGw1TDzgJ/43DQkvhnrYtvi7PwjURjc/CmA5JDET30AMyqLmA/RUHXLZOiROOQL/DVIgXtEgyfwfgEyfjXt+URlS5dNwRw8u/hSIhwywxlJA5EEWRBrLh+Ky8+TtXdHR4UeuGiw+uWfNXO5YNmz1oDYM7Fw2WYDxw3dyFT/2scuA6eufd896Y4fLSe36FhvYfwhMswJnSJVbNk2wnnwT7175OnDwczkyDVk2Ccjqn0I67PaOj8axpVM5zVv6l2fkARu2dKp9wIZt/PDJd9WJfY+zk/ituUCtKVh7mRgTXXJiLHTJibHQJSfGQpecGAtdcmIsdMmJsdAlJ8ZCl5wYCatD/wAIX1LFMOXRnwAAAABJRU5ErkJggg==)"/>	</fo:inline>
												
												
												</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="Center">
													<fo:inline font-weight="bold"><xsl:text>DML PRINT REPORT</xsl:text></fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="right">
													<fo:inline>	<fo:external-graphic src="url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAAkCAYAAAAZ4GNvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuMTCtCgrAAAAC5UlEQVRYR9WYvWpWQRCGc11egDfgBXgB3oCNnZYWFnZiKVZ2Wgo2liktgigiRBEhSEBFkPV7lm8+5rx59+cksTgLD0lmZ2bfs7uzZ0+OSimbxRovw+nZn/L87Vm5/+Jruf34U7lx76QJ/fjhT5zmmsUa1/Dy+MdQ7AjiyaO5R1jjDG/enZdbDz9aMZeFfOTVsVpY4wiW3A1+XZD//Nff3VB+/MAae/xv4QFbafQA1tji0atviwHuPP1cZ+nJ6+91zx5/+FnJMfThy89sD1/i6CMP+XJ+bDlGsUYHpwKDsCf3J8SinXz5fRCfH4DfEaK2gDht5GccxuudRtboYAkZLM9Sr2DvPjvdhV0Uj119A/Ll1SSmt3Ws0bH2ZMGfOBWvW2PEzQfva5zDGh0ucQ9EEndV8UCcwxodLmkPips4Fc92UN8RxDms0bF2xuKNqeKxq28PjkziHNboWDvo/hS5IB67+vbg/kOcwxpbrCnaiAnxsRJAEaq/I4q+hTW2YNZmBo5ihRDPXg/bzBZknFi9FtbYY+YBslAnflS0M8LBGkfw1uvNXr4ZOvFhc5B35lIG1jgLIt1dPg8ehZ7F068xiOahwmcGa1wLS8y5ToHp0RZbJIsH/IC4mS3isMbrhNlE+NpZncEat4I1bgVr3ArWuBWskWNrhvDn/qF9uUC1r0X4j/IFiz8CPYNbhL974+bvT+1rEf7uDhVfZpnFH4EGtsC3d9uMl5Xrc+DLi8/1gX7PLkQHLBGwfJoAW/Tjy5KqTxAvpjX5et+4+qJbiE7URkJNsGuHfmYi9+n20Suty7cXXdvafIdfhNpG4vX/OOxz3a/ukpbJ4uMqEZBP7075uyDEKrWNxOvMcEfRrZELbSReH5w+zcc23bWaL8QqtfXEa6HGkurSQxRaT7wW6j5fLfpsh8inooPaeuK1UHMxadHpfxIyIb4RU1srXxacqa0lvje7oKvC9sLeEt/JV1srn4reEOXoH3eUZEaNVy11AAAAAElFTkSuQmCC)"/></fo:inline>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
							</fo:table-body>
						</fo:table>
							
						</fo:block>
						<fo:block text-align="left" font-family="Tahoma" font-size="small" margin-right="100% - 100%" space-before="0" space-after="0" margin="0pt">
							
						</fo:block>
						<fo:block>
							<fo:leader leader-pattern="space"/>
						</fo:block>
						
					<!-- End Report Header-->	
					<!-- Start EPA Details-->
						
						<fo:table border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-top-color="black" border-top-style="solid" border-top-width="thin" font-family="Tahoma" font-size="x-small"  width="100%" border="solid 0.1mm black" >
							<fo:table-column column-width="18%"/>
							<fo:table-column column-width="16%"/>
							<fo:table-column column-width="13%"/>
							<fo:table-column column-width="12%"/>
							<fo:table-column column-width="13%"/>
							<fo:table-column column-width="28%"/>
							
							<fo:table-body >
								
									<fo:table-row>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>DML No</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlno"/></fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Department</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlDept"/></fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Release Type</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlRelType"/></fo:inline>
												</fo:block>
											</fo:table-cell>
									</fo:table-row>
									<fo:table-row>
											<fo:table-cell   padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Design Group</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell   padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlDsgGrp"/></fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell   padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Project code</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell   padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlProj"/></fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell   padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline  font-weight="bold">	<xsl:text>Reason</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell   padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlReason"/></fo:inline>
												</fo:block>
											</fo:table-cell>
									</fo:table-row>
									<fo:table-row>
											<fo:table-cell   padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Creator</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="left">
														<fo:inline><xsl:value-of select="dmldetail/dmlCre"/></fo:inline>
													</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>DML DR-Status</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
													<fo:block text-align="left">
														<fo:inline><xsl:value-of select="dmldetail/dmlDRStat"/></fo:inline>
													</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>ERC Reviewer</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell  padding="2pt" display-align="center">
													<fo:block text-align="left">
														<fo:inline><xsl:value-of select="dmldetail/dmlERCRev"/></fo:inline>
													</fo:block>
											</fo:table-cell>
									</fo:table-row>
									<fo:table-row>
											<fo:table-cell  border="solid 0.1mm black" padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Synopsis</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell number-columns-spanned="5" border="solid 0.1mm black" padding="2pt" display-align="center">
													<fo:block text-align="left">
														<fo:inline><xsl:value-of select="dmldetail/dmlDesc"/></fo:inline>
													</fo:block>
											</fo:table-cell>
									</fo:table-row>
									<fo:table-row>
										<fo:table-cell border="solid 0.1mm black" padding="2pt" display-align="center">
											<fo:block text-align="left">
												<fo:inline font-weight="bold">	<xsl:text>Reason Description</xsl:text>	</fo:inline>
											</fo:block>
										</fo:table-cell>
										<fo:table-cell number-columns-spanned="5" border="solid 0.1mm black" padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlReasondesc"/></fo:inline>
												</fo:block>
										</fo:table-cell>
									</fo:table-row>
									<fo:table-row>
										<fo:table-cell border="solid 0.1mm black" padding="2pt" display-align="center">
											<fo:block text-align="left">
												<fo:inline font-weight="bold">	<xsl:text>Release Notes</xsl:text>	</fo:inline>
											</fo:block>
										</fo:table-cell>
										<fo:table-cell number-columns-spanned="5" border="solid 0.1mm black" padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlRelNote"/></fo:inline>
												</fo:block>
										</fo:table-cell>
									</fo:table-row>
									<fo:table-row>
										<fo:table-cell border="solid 0.1mm black" padding="2pt" display-align="center">
											<fo:block text-align="left">
												<fo:inline font-weight="bold">	<xsl:text>Other Design Groups Affected</xsl:text>	</fo:inline>
											</fo:block>
										</fo:table-cell>
										<fo:table-cell number-columns-spanned="5" border="solid 0.1mm black" padding="2pt" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="dmldetail/dmlOthDsgGrpAff"/></fo:inline>
												</fo:block>
										</fo:table-cell>
									</fo:table-row>
								
							</fo:table-body>
						</fo:table>
						
						<!--Start table DML Details-->
						
						
						<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
							<fo:table-column column-width="18%"/>
							<fo:table-column column-width="28%"/>
							<fo:table-column column-width="18%"/>
							<fo:table-column column-width="18%"/>
							<fo:table-column column-width="18%"/>
								
								<fo:table-header start-indent="0pt">
									
										<fo:table-row>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>DML No</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Life Cycle State</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>ERC Rel Date</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>APL Rel Date</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>STD Rel Date</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
									
								</fo:table-header>
								
								<fo:table-body>
									<!--<xsl:apply-templates select="//DMLDetails"/>-->
									 <xsl:for-each select="tasksdetail/taskdetail">
										<fo:table-row>
											  <!--<xsl:if test="function = 'lead'" >
												<xsl:attribute name="font-weight">bold</xsl:attribute>
											  </xsl:if>-->
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center" >
												<fo:block>
												  <xsl:value-of select="taskno"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="taskLCS"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="taskercreldate"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="taskaplreldate"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="taskstdreldate"/>
												</fo:block>
											  </fo:table-cell>
											  
										</fo:table-row>
									</xsl:for-each>
								</fo:table-body>
						</fo:table>
						<!--End Table DML Details-->
						
						
						
						<!--<fo:block>
							<fo:leader leader-pattern="space"/>
						</fo:block>-->
						
						<!--Start Table Parts Details-->
						<xsl:variable name="BaseTask" select="task/DsgGrpBaseDetails" />
						<xsl:variable name="TaskDsgs" select="$BaseTask/tasksDsgs" />
						<xsl:variable name="Draws" select="$BaseTask/draws" />
						<xsl:variable name="PartAddMods" select="$BaseTask/partAddMods" />
						<xsl:variable name="StrucChg" select="$BaseTask/strucChgs" />
						<xsl:variable name="AffVC" select="$BaseTask/affVC" />
						
						<xsl:for-each select="$BaseTask">
						<xsl:variable name="cur-task-id" select="./@id"/>
						<xsl:variable name="cur-tasksDsgs-av" select="./tasksDsgs/@AV" />
						<xsl:variable name="cur-partAddMods-av" select="./partAddMods/@AV" />
						<xsl:variable name="cur-draws-av" select="./draws/@AV" />
						<xsl:variable name="cur-strucChg-av" select="./strucChgs/@AV" />
						<xsl:variable name="cur-affVC-av" select="./affVC/@AV" />
						
						<fo:block>
							<fo:leader leader-pattern="space"/>
						</fo:block>
						<fo:block font-family="Tahoma" font-size="x-small" margin-right="100% - 100%" margin="0pt">
							<fo:inline font-size="9pt">	<xsl:text>AFFECTED  DESIGN  GROUPS</xsl:text>	</fo:inline>
							
						</fo:block>
						<fo:leader leader-pattern="rule" leader-length="100%" rule-style="Solid" rule-thickness="1.5pt"/>					
						<xsl:choose>
						<xsl:when test='$cur-tasksDsgs-av="true"'>
							<xsl:variable name="DsgDetails" select="$TaskDsgs/tasksDsgdetails" />
						<!--Task Detail-->
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="6%"/>
								<fo:table-column column-width="18%"/>
								<fo:table-column column-width="28%"/>
								<fo:table-column column-width="16%"/>
								<fo:table-column column-width="16%"/>
								<fo:table-column column-width="16%"/>
								
								<fo:table-header start-indent="0pt">
									
										<fo:table-row>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>DesGrp</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Task Id</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Synopsis</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>ERC Analyst</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>APL Planner</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>STDS1 Planner</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
									
								</fo:table-header>
								
								<fo:table-body>
									
								<xsl:for-each select="$DsgDetails">
								<xsl:variable name="cur-DsgDetails" select="."/>
									   
									<xsl:if test="$cur-DsgDetails/DsgGrpid=$cur-task-id" >
										<fo:table-row>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-DsgDetails/desgrp"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DsgDetails/taskid"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DsgDetails/taskdesc"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DsgDetails/ERCAna"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DsgDetails/APLAna"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DsgDetails/STDAna"/>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
									</xsl:if>	
								</xsl:for-each>
								</fo:table-body>
								
							</fo:table>
							<!--</xsl:if>-->
						</xsl:when>	
						<xsl:otherwise> 
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="100%"/>
								<fo:table-body>
									<fo:table-row>
										<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
											<fo:block>
											<xsl:text>DATA NOT AVAILABLE</xsl:text>
											</fo:block>
										</fo:table-cell>
									</fo:table-row>
								</fo:table-body>
							</fo:table>
						</xsl:otherwise> 
						</xsl:choose> 							
						
							<fo:block>
								<fo:leader leader-pattern="space"/>
							</fo:block>
							<fo:block font-family="Tahoma" font-size="x-small" margin-right="100% - 100%" margin="0pt">
								<fo:inline font-size="9pt">	<xsl:text>PARTS ADDED / MODIFIED</xsl:text>	</fo:inline>
							</fo:block>
						<!--</xsl:for-each>	-->
						<xsl:choose>
						<xsl:when test='$cur-partAddMods-av="true"'>
							<xsl:variable name="PartAddMod" select="$PartAddMods/partAddMod" />
						
							
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="14%"/>
								<fo:table-column column-width="24%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="10%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="7%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="6%"/>
								
								<fo:table-header start-indent="0pt">
									
										<fo:table-row>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Srl</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>PartNo</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Description</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Rv/Sq</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>IA</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>CS</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>SI</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>CI</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>EPA Task</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>ES</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>RS-DI(PR)</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>RI</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Checked By</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>DR Status</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>LC State</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
									
								</fo:table-header>
								
									<fo:table-body>
										
										 <xsl:for-each select="$PartAddMod">
											<xsl:variable name="cur-PartAddMod" select="."/>
									   
											<xsl:if test="$cur-PartAddMod/PartAddModid=$cur-task-id" >
											<fo:table-row>
												 
												 
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/srl"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/assy"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center" >
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/desc"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/revseq"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/IA"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/CS"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/SI"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center" >
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/CI"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/EPATask"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/ES"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="$cur-PartAddMod/true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/RSFAP"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/RI"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center" >
													<fo:block>
													  <xsl:value-of select="CheckedBy"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/PartStat"/>
													</fo:block>
												  </fo:table-cell>
												  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
													<fo:block>
													  <xsl:value-of select="$cur-PartAddMod/LCS"/>
													</fo:block>
												  </fo:table-cell>
												  
												  
												  
											</fo:table-row>
											</xsl:if>
										</xsl:for-each>
									</fo:table-body>
							</fo:table>
						</xsl:when>
						<xsl:otherwise> 
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="100%"/>
								<fo:table-body>
									<fo:table-row>
										<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
											<fo:block>
											<xsl:text>DATA NOT AVAILABLE</xsl:text>
											</fo:block>
										</fo:table-cell>
									</fo:table-row>
								</fo:table-body>
							</fo:table>
						</xsl:otherwise> 
						</xsl:choose> 	
						<!--</xsl:for-each>-->
						
							<fo:block>
							<fo:leader leader-pattern="space"/>
							</fo:block>
							<fo:block font-family="Tahoma" font-size="x-small" margin-right="100% - 100%" margin="0pt">
								<fo:inline font-size="9pt"  font-weight="bold">	<xsl:text>DRAWINGS ADDED / MODIFIED</xsl:text>	</fo:inline>
							</fo:block>
						<xsl:choose>
						<xsl:when test='$cur-draws-av="true"'>
							<xsl:variable name="DrawInd" select="$Draws/drawInd" />
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="14%"/>
								<fo:table-column column-width="24%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="40%"/>
								<fo:table-column column-width="15%"/>
								
								<fo:table-header start-indent="0pt">
									
										<fo:table-row>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Srl</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Drawing No</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Description</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Rv/Sq</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>Modification Description</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>LifeCycleState</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
									
								</fo:table-header>
								
								<fo:table-body>
									
									<xsl:for-each select="$DrawInd">
									<xsl:variable name="cur-DrawInd" select="."/>
									    <xsl:if test="$cur-DrawInd/drawIndid=$cur-task-id" >
												<!--<xsl:attribute name="font-weight">bold</xsl:attribute>-->
										<fo:table-row>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DrawInd/srl"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DrawInd/assy"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DrawInd/desc"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-DrawInd/revseq"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-DrawInd/modDesc"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-DrawInd/lcStat"/>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
										</xsl:if> 
									</xsl:for-each>
								</fo:table-body>
								
							</fo:table>
						</xsl:when>
						<xsl:otherwise> 
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="100%"/>
								<fo:table-body>
									<fo:table-row>
										<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
											<fo:block>
											<xsl:text>DATA NOT AVAILABLE</xsl:text>
											</fo:block>
										</fo:table-cell>
									</fo:table-row>
								</fo:table-body>
							</fo:table>
						</xsl:otherwise> 
						</xsl:choose> 	
						
						
						
							<fo:block>
								<fo:leader leader-pattern="space"/>
							</fo:block>
							<fo:block font-family="Tahoma" font-size="x-small" margin-right="100% - 100%" margin="0pt">
								<fo:inline font-size="9pt">	<xsl:text>STRUCTURE CHANGES</xsl:text>	</fo:inline>
							</fo:block>
						<xsl:choose>
						<xsl:when test='$cur-strucChg-av="true"'>
						<xsl:variable name="StrucChgPrtDtl" select="$StrucChg/partdetail" />	
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="2%"/>
								<fo:table-column column-width="12%"/>
								<fo:table-column column-width="18%"/>
								<fo:table-column column-width="4%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="2%"/>
								<fo:table-column column-width="2%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="18%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="2%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="12%"/>
								<fo:table-column column-width="10%"/>
								
								
								<fo:table-header start-indent="0pt">
									
										<fo:table-row>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Srl</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>PartNo</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Description</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Rv/Sq</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>CS</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>CI</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>QT</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>QR</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>SI</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>EPA</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>ES</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>RI</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>IPTV</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>IC</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>Replace Part</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>LCS</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											
										</fo:table-row>
								</fo:table-header>
								<fo:table-body>
								
									<xsl:for-each select="$StrucChgPrtDtl">
									<xsl:variable name="cur-StrucChgPrtDtl" select="."/>
										   
									<xsl:if test="$cur-StrucChgPrtDtl/partdetailid=$cur-task-id" >
										<fo:table-row>
											<fo:table-cell hyphenate="true"  border="solid 0.1mm black" display-align="center">
												<fo:block>
												
												  <xsl:choose>
													<xsl:when test="$cur-StrucChgPrtDtl/srl='A'">
													<fo:inline color="#0CEC35"><xsl:value-of select="$cur-StrucChgPrtDtl/srl"/></fo:inline>
												  </xsl:when>
												  <xsl:when test="$cur-StrucChgPrtDtl/srl='D'">
													<fo:inline color="#FF5733"><xsl:value-of select="$cur-StrucChgPrtDtl/srl"/></fo:inline>
												  </xsl:when>
												  <xsl:when test="$cur-StrucChgPrtDtl/srl='C'">
													<fo:inline color="#008FFF"><xsl:value-of select="$cur-StrucChgPrtDtl/srl"/></fo:inline>
												  </xsl:when>
												  <xsl:otherwise>
													<fo:inline color="#050505"><xsl:value-of select="$cur-StrucChgPrtDtl/srl"/></fo:inline>
												  </xsl:otherwise>
												  </xsl:choose>
												
												
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black"  display-align="center">
												<fo:block>
												<xsl:value-of select="$cur-StrucChgPrtDtl/childPart"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center" >
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childDesc"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true"  border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childRevision"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black"  display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childCS"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true"  border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childCI"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childQty"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childQRI"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childSI"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childEPA"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childES"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childRI"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childIPTV"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childIC"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childREPLACE"/>
												</fo:block>
											  </fo:table-cell>
											  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block>
												  <xsl:value-of select="$cur-StrucChgPrtDtl/childRelstatus"/>
												</fo:block>
											  </fo:table-cell>
											
										</fo:table-row>
									</xsl:if>
									</xsl:for-each>
								</fo:table-body>
							</fo:table>
						</xsl:when>
						<xsl:otherwise> 
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="100%"/>
								<fo:table-body>
									<fo:table-row>
										<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
											<fo:block>
											<xsl:text>DATA NOT AVAILABLE</xsl:text>
											</fo:block>
										</fo:table-cell>
									</fo:table-row>
								</fo:table-body>
							</fo:table>
						</xsl:otherwise> 
						</xsl:choose> 
						
							<fo:block>
								<fo:leader leader-pattern="space"/>
							</fo:block>
							<fo:block font-family="Tahoma" font-size="x-small" margin-right="100% - 100%" margin="0pt">
								<fo:inline font-size="9pt">	<xsl:text>AFFECTED VCs</xsl:text>	</fo:inline>
							</fo:block>
						<xsl:choose>
						<xsl:when test='$cur-affVC-av="true"'>
						<xsl:variable name="AffVC-vcs" select="$AffVC/vcs" />
						</xsl:when>
						<xsl:otherwise> 
							<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="100%"/>
								<fo:table-body>
									<fo:table-row>
										<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
											<fo:block>
											<xsl:text>DATA NOT AVAILABLE</xsl:text>
											</fo:block>
										</fo:table-cell>
									</fo:table-row>
								</fo:table-body>
							</fo:table>
						</xsl:otherwise>
						</xsl:choose>
						</xsl:for-each>	
						
						
						<fo:block>
								<fo:leader leader-pattern="space"/>
							</fo:block>
							<fo:block font-family="Tahoma" font-size="x-small" margin-right="100% - 100%" margin="0pt">
								<fo:inline font-size="9pt">	<xsl:text>RECORD  SUMMARY  FOR  DML</xsl:text>	</fo:inline>
							</fo:block>
						<fo:leader leader-pattern="rule" leader-length="100%" rule-style="Solid" rule-thickness="1.5pt"/>
						
						<xsl:variable name="AffGrp" select="task/DsgGrpBaseDetails" />
						<xsl:variable name="ResultPart" select="$BaseTask/tasksDsgs" />
						<xsl:variable name="AddAssy" select="$BaseTask/draws" />
						<xsl:variable name="DelAssy" select="$BaseTask/partAddMods" />
						<xsl:variable name="QtyChg" select="$BaseTask/strucChgs" />
						
						
						<fo:table  font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%"  >
							<fo:table-column column-width="60%"/>
							<fo:table-column column-width="35%"/>
							<fo:table-column column-width="5%"/>
							<fo:table-body>
								<fo:table-row>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										<xsl:text font-weight="bold">No of affected groups</xsl:text>
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block text-align="left">
										<fo:inline><xsl:value-of select="result/TotalAffectGrp"/></fo:inline>
										</fo:block>
									</fo:table-cell>
								</fo:table-row>
								<fo:table-row>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										<xsl:text font-weight="bold">No of Resultant Parts</xsl:text>
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										
										<fo:block text-align="left">
										<fo:inline><xsl:value-of select="result/TotalParts"/></fo:inline>
										</fo:block>
										
									</fo:table-cell>
								</fo:table-row>
								<fo:table-row>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										<xsl:text font-weight="bold">No of Parts Added in Assy</xsl:text>
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										
										<fo:block text-align="left">
										<fo:inline><xsl:value-of select="result/TotalAdd"/></fo:inline>
										</fo:block>
										
									</fo:table-cell>
								</fo:table-row>
								<fo:table-row>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										<xsl:text font-weight="bold">No of Parts Deleted from Assy</xsl:text>
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										
										<fo:block text-align="left">
										<fo:inline><xsl:value-of select="result/TotalDel"/></fo:inline>
										</fo:block>
										
									</fo:table-cell>
								</fo:table-row>
								<fo:table-row>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										<fo:block>
										<xsl:text font-weight="bold">No of Parts Qty Changed from assy</xsl:text>
										</fo:block>
									</fo:table-cell>
									<fo:table-cell hyphenate="true"  display-align="center">
										
										<fo:block text-align="left">
										<fo:inline><xsl:value-of select="result/TotalChng"/></fo:inline>
										</fo:block>
										
									</fo:table-cell>
								</fo:table-row>
								
							</fo:table-body>
						</fo:table>
						<fo:leader leader-pattern="rule" leader-length="100%" rule-style="double" rule-thickness="1.5pt"/>
						<fo:block>
								<fo:leader leader-pattern="space"/>
							</fo:block>
							<fo:block font-family="Tahoma" font-size="x-small" margin-right="100% - 100%" margin="0pt">
								<fo:inline font-size="9pt" font-weight="bold">	<xsl:text>AUTO SOR DETAILS</xsl:text>	</fo:inline>
							</fo:block>
							
						<fo:table border-bottom-color="black" border-bottom-style="solid" border-bottom-width="thin" border-color="black" border-left-color="black" border-left-style="solid" border-left-width="thin" border-right-color="black" border-right-style="solid" border-right-width="thin" border-style="solid" border-top-color="black" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" >
								<fo:table-column column-width="8%"/>
								<fo:table-column column-width="12%"/>
								<fo:table-column column-width="12%"/>
								<fo:table-column column-width="8%"/>
								<fo:table-column column-width="8%"/>
								<fo:table-column column-width="8%"/>
								<fo:table-column column-width="10%"/>
								<fo:table-column column-width="10%"/>
								<fo:table-column column-width="8%"/>
								<fo:table-column column-width="8%"/>
								<fo:table-column column-width="8%"/>
								
								<fo:table-header start-indent="0pt">
									
										<fo:table-row>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Group</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>TaskID</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>Part</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline font-weight="bold">	<xsl:text>SOR</xsl:text> </fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>PPPM</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>Project</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>Commodity</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>Process type</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>SOR Category</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>PPPM Project</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline font-weight="bold"> <xsl:text>Prod Status</xsl:text>	</fo:inline>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
									
								</fo:table-header>
								
								<fo:table-body>	
								<fo:table-row>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="SOR/grp"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="SOR/taskId"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="SOR/part"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline><xsl:value-of select="SOR/SOR"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline><xsl:value-of select="SOR/PPPM"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline><xsl:value-of select="SOR/Proj"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline><xsl:value-of select="SOR/Commod"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline><xsl:value-of select="SOR/ProcessType"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline><xsl:value-of select="SOR/SORCat"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline><xsl:value-of select="SOR/PPPMProj"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left"> 
													<fo:inline><xsl:value-of select="SOR/Prodstat"/>	</fo:inline>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
								</fo:table-body>
							</fo:table>
			<fo:leader leader-pattern="rule" leader-length="100%" rule-style="double" rule-thickness="1.5pt"/>
						<fo:block>
								<fo:leader leader-pattern="space"/>
							</fo:block>
							<fo:block font-family="Tahoma" font-size="x-small" margin-right="100% - 100%" margin="0pt">
								<fo:inline font-size="9pt"  font-weight="bold">	<xsl:text>END OF REPORT</xsl:text>	</fo:inline>
							</fo:block>	
<fo:leader leader-pattern="rule" leader-length="100%" rule-style="Solid" rule-thickness="1.5pt"/>							
	<!--					<fo:table border-bottom-color="#57c0ff" border-color="#57c0ff" border-style="solid" border-top-color="#57c0ff" border-top-style="solid" border-top-width="thin" border-width="thin" font-family="Tahoma" font-size="x-small" text-align="left" table-layout="fixed" width="100%" border="solid 0.1mm black" border-spacing="2pt">
								<fo:table-column column-width="20%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="10%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="5%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="15%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="3%"/>
								<fo:table-column column-width="5%"/>
								<fo:table-column column-width="15%"/>
								
								<fo:table-header start-indent="0pt">
									
										<fo:table-row>
											<fo:table-cell border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>Valid Part No/ Description/ Drg No</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>R</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>CS</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>PO</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>Xn</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>QI</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>CI</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>Colour</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>Q</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>SLoc</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>IA</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>Invalid Part</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>R</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>Qt</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>Shop</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center">
												<fo:block text-align="left">
													<fo:inline>
														<xsl:text>Remark</xsl:text>
													</fo:inline>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
										
										
									
								</fo:table-header>
								
								<fo:table-body>
								<xsl:variable name="part:tablerows">
									<xsl:for-each select="epa/epapart/partdetail">
										<fo:table-row>
											<fo:table-cell  border="solid 0.1mm black" display-align="center">
	<xsl:if test="part/parent = '1'" >
        <xsl:attribute name="start-indent">20pt</xsl:attribute>
      </xsl:if>
												<fo:block hyphenate="true" language="en" text-align="left">
													<xsl:value-of select="part/partno"/>
												</fo:block>
												<fo:block hyphenate="true" language="en" text-align="left">
													<xsl:value-of select="part/desc"/>
												</fo:block>
												<fo:block hyphenate="true" language="en" text-align="left">
													<xsl:value-of select="part/drwno"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="rev"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="cs"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="po"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="xn"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="qi"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="ci"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black" display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="clr"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="qt"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="sloc"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="ia"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="invpart"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="irev"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="iqt"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell border="solid 0.1mm black"  display-align="center" hyphenate="true">
												<fo:block text-align="left">
													<xsl:value-of select="shop"/>
												</fo:block>
											</fo:table-cell>
											<fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
												<fo:block text-align="left">
													<xsl:value-of select="rem"/>
												</fo:block>
											</fo:table-cell>
										</fo:table-row>
									</xsl:for-each>	
									</xsl:variable>
									<xsl:choose>
										<xsl:when test="string($part:tablerows)">
											<xsl:copy-of select="$part:tablerows"/>
										</xsl:when>
										<xsl:otherwise>
											<fo:table-row>
												<fo:table-cell>
													<fo:block/>
												</fo:table-cell>
											</fo:table-row>
										</xsl:otherwise>
									</xsl:choose>
								</fo:table-body>
								
						</fo:table>		-->
						<!--End Table Parts Details-->
						
					</fo:block>
				</fo:flow>
				
			</fo:page-sequence>
		</fo:root>
	</xsl:template>
	
	 <!-- ========================= -->
  <!-- child element: member     -->
  <!-- ========================= -->
  <xsl:template match="DMLDetails" >
    <fo:table-row>
      <!--<xsl:if test="function = 'lead'" >
        <xsl:attribute name="font-weight">bold</xsl:attribute>
      </xsl:if>-->
      <fo:table-cell hyphenate="true"  >
        <fo:block>
          <xsl:value-of select="dmlno"/>
        </fo:block>
      </fo:table-cell>
      <fo:table-cell hyphenate="true" >
        <fo:block>
          <xsl:value-of select="dmldesc"/>
        </fo:block>
      </fo:table-cell>
      <fo:table-cell hyphenate="true">
        <fo:block>
          <xsl:value-of select="dmlcategory"/>
        </fo:block>
      </fo:table-cell>
	  <fo:table-cell hyphenate="true">
        <fo:block>
          <xsl:value-of select="dmldr"/>
        </fo:block>
      </fo:table-cell>
	  <fo:table-cell hyphenate="true">
        <fo:block>
          <xsl:value-of select="dmlercreldate"/>
        </fo:block>
      </fo:table-cell>
	  <fo:table-cell hyphenate="true">
        <fo:block>
          <xsl:value-of select="dmlaplreldate"/>
        </fo:block>
      </fo:table-cell>
	  <fo:table-cell hyphenate="true">
        <fo:block>
          <xsl:value-of select="dmlstdreldate"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
  </xsl:template>
  
  
  <xsl:templete name="dsgdetails" match="/task/DsgGrpBaseDetails">
	<xsl:for-each select="tasksDsgdetails">
	<fo:table-row>
		  <!--<xsl:if test="function = 'lead'" >
			<xsl:attribute name="font-weight">bold</xsl:attribute>
		  </xsl:if>-->
		  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center" >
			<fo:block>
			  <xsl:value-of select="desgrp"/>
			</fo:block>
		  </fo:table-cell>
		  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
			<fo:block>
			  <xsl:value-of select="taskid"/>
			</fo:block>
		  </fo:table-cell>
		  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
			<fo:block>
			  <xsl:value-of select="taskdesc"/>
			</fo:block>
		  </fo:table-cell>
		  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
			<fo:block>
			  <xsl:value-of select="ERCAna"/>
			</fo:block>
		  </fo:table-cell>
		  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
			<fo:block>
			  <xsl:value-of select="APLAna"/>
			</fo:block>
		  </fo:table-cell>
		  <fo:table-cell hyphenate="true" border="solid 0.1mm black" display-align="center">
			<fo:block>
			  <xsl:value-of select="STDAna"/>
			</fo:block>
		  </fo:table-cell>
		  
	</fo:table-row>
	</xsl:for-each>
  </xsl:templete>
	
</xsl:stylesheet>