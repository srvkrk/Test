<?xml version="1.0" encoding="UTF-8"?>
<!--
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<!-- $Id: APLStatusRpt.xsl,v 1.1 2018/07/27 05:19:27 pks06049 Exp root $ -->
<xsl:stylesheet version="1.1" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" exclude-result-prefixes="fo">
  <xsl:output method="xml" version="1.0" omit-xml-declaration="no" indent="yes"/>
  <xsl:param name="versionParam" select="'1.0'"/> 
  <!-- ========================= -->
  <!-- root element: projectteam -->
  <!-- ========================= -->
  <xsl:template match="APLStatusRptData">
    <fo:root xmlns:fo="http://www.w3.org/1999/XSL/Format">
      <fo:layout-master-set>
       <fo:simple-page-master master-name="simpleA4" page-height="21cm" page-width="29.7cm" margin-top="1cm" margin-bottom="1cm" margin-left="1cm" margin-right="1cm">
          <fo:region-body/>
        </fo:simple-page-master>
      </fo:layout-master-set>
      <fo:page-sequence master-reference="simpleA4">
        <fo:flow flow-name="xsl-region-body">
          <fo:block font-size="14pt" font-weight="bold" space-after="5mm" text-align="center" color = "#87cefa" text-decoration="underline">DML STATUS REPORT  
          </fo:block>
		  <fo:block font-size="8pt" space-after="5mm">PROJECT CODE : : <xsl:value-of select="PrjCode"/>
          </fo:block>
          <fo:block font-size="8pt" space-after="5mm">From Date :  <xsl:value-of select="FromDate"/> 
          </fo:block>
		  <fo:block font-size="8pt" space-after="5mm">To Date : <xsl:value-of select="ToDate"/>
          </fo:block>
		   <fo:block font-size="8pt" space-after="5mm">DML Type : <xsl:value-of select="dType"/>
          </fo:block>
  	
		 <fo:block font-size="4pt">
       <fo:table keep-with-previous.within-page="always" page-break-inside="avoid" table-layout="fixed" border-width="1pt" border-style="solid">
		<fo:table-column column-width="2%"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="2%"/>
          <fo:table-column column-width="3%"/>
		  <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
		   <fo:table-column column-width="auto"/>
          <fo:table-column column-width="auto"/>
		  <fo:table-column column-width="auto"/>
		  
          <fo:table-body>
              <fo:table-row>
			      <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          SR.
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          DML No.
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          DG.
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          PROJ
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				           APL PLANNER
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				           STDSI PLANNER
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          ERC REL DATE
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          APL STATUS
				        </fo:block>							
			      </fo:table-cell>
				  
				   <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          Indent Txt Attached
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          APL REVIWER
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          STDSI REVIWER
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          INDENT REVIEWER
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          INDENT CREATION DATE 
				        </fo:block>							
			      </fo:table-cell>
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          INDENT APPROVAL DATE
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				         INDENT STATUS
				        </fo:block>							
			      </fo:table-cell>
				  
				  <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				         INDENT COMMENTS
				        </fo:block>							
			      </fo:table-cell>
				  
				   <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          APL RLZ DATE 
				        </fo:block>							
			      </fo:table-cell>
				  
				   <fo:table-cell number-columns-spanned="1" border="1pt solid black">
				        <fo:block font-size="4pt" font-weight="bold" color = "black">
				          DML DESCRIPTION
				        </fo:block>							
			      </fo:table-cell>
				 
			   </fo:table-row>   
            <xsl:apply-templates select="ASrptrow1"/>
          </fo:table-body>            
       </fo:table>
     	</fo:block>     	
        </fo:flow>
      </fo:page-sequence>
    </fo:root>
  </xsl:template>

  <!-- ========================= -->
  <!-- child element: member     -->
  <!-- ========================= -->
  <xsl:template match="APLStatusRptData/ASrptrow1">
  
    <fo:table-row>

      <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="SrNo"/>
        </fo:block>
      </fo:table-cell>
	  
       <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="DmlNum"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="TskDgGrp"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="DmlPrjcode"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="AplPlanner"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="StdPlanner"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="ERCRlzDate"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
         <xsl:value-of select="TskLcStat"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="IndtxtAtt"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="AplRev"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="StdRev"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
         <xsl:value-of select="IndRev"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="IndCreDate"/>
        </fo:block>
      </fo:table-cell>
	  
	  	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="IndAppDate"/>
        </fo:block>
      </fo:table-cell>
	  
	  	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="IndStatus"/>
        </fo:block>
      </fo:table-cell>
	  
	  	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
          <xsl:value-of select="IndComment"/>
        </fo:block>
      </fo:table-cell>
	  
	   <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="APLRlzDate"/>
        </fo:block>
      </fo:table-cell>
	  
	  <fo:table-cell border="1pt solid black">
        <fo:block space-after="5mm">
           <xsl:value-of select="Dmldesc"/>
        </fo:block>
      </fo:table-cell>
	  
    </fo:table-row>
	
	
  </xsl:template>  
</xsl:stylesheet>
