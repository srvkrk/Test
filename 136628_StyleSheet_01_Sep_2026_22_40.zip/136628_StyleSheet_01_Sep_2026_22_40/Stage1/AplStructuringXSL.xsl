<?xml version="1.0" encoding="UTF-8"?>
<!--
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<!-- $Id: AplStructuringXSL.xsl,v 1.1 2018/06/25 12:44:42 smm914024 Exp root $ -->
<xsl:stylesheet version="1.1" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" exclude-result-prefixes="fo">
  <xsl:output method="xml" version="1.0" omit-xml-declaration="no" indent="yes"/>
  <xsl:param name="versionParam" select="'1.0'"/> 
  <!-- ========================= -->
  <!-- root element: projectteam -->
  <!-- ========================= -->
  <xsl:template match="APLREPORT">
    <fo:root xmlns:fo="http://www.w3.org/1999/XSL/Format">
      <fo:layout-master-set>
        <fo:simple-page-master master-name="simpleA4" page-height="29.7cm" page-width="21cm" margin-top="1cm" margin-bottom="1cm" margin-left="1cm" margin-right="1cm">
          <fo:region-body/>
        </fo:simple-page-master>
      </fo:layout-master-set>
      <fo:page-sequence master-reference="simpleA4">

        <fo:flow flow-name="xsl-region-body">
          <fo:block font-size="10pt" font-weight="bold"  text-decoration="underline" space-after="5mm">
          APL Structure Report
          </fo:block>
        <!-- 
          <fo:block font-size="16pt" font-weight="bold" space-after="5mm">Project: <xsl:value-of select="projectname"/>
          </fo:block>
          
          <fo:block font-size="12pt" space-after="5mm">Version <xsl:value-of select="$versionParam"/>
          </fo:block>
          -->
          <fo:block font-size="5pt">
            <fo:table keep-with-previous.within-page="always" page-break-inside="avoid" table-layout="fixed" border-width="0.5pt" border-style="solid">
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="2%"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="6%"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="8%"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/> 
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>  
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="8%"/> 
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="8%"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>
              <fo:table-column border-width="0.5pt" border-style="solid" column-width="auto"/>                                          
              <fo:table-header>
  				<fo:table-row border-width="0.5pt" border-style="solid" background-color = "#87cefa" font-size="4pt">
    				<fo:table-cell>
      				<fo:block font-weight="bold">Level</fo:block>
    				</fo:table-cell>
   					 <fo:table-cell>
      				<fo:block font-weight="bold">PART NUMBER</fo:block>
   					 </fo:table-cell>
   					 <fo:table-cell>
      				<fo:block font-weight="bold">DESCRIPTION</fo:block>
   					 </fo:table-cell>   
 					<fo:table-cell >
				        <fo:block font-weight="bold">Rev/Seq</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">DI</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">UQ</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">QTY</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">CS</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">IA</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">LOC</fo:block>			      
			      </fo:table-cell>				      			                 
			      <fo:table-cell >
				        <fo:block font-weight="bold">Count</fo:block>			      
			      </fo:table-cell>
			      <fo:table-cell >
				        <fo:block font-weight="bold">OP/CS</fo:block>			      
			      </fo:table-cell>	
   					 <fo:table-cell>
      				<fo:block font-weight="bold">OWNER NAME</fo:block>
   					 </fo:table-cell>
   					 <fo:table-cell>
      				<fo:block font-weight="bold">Part Type</fo:block>
   					 </fo:table-cell>   
 					<fo:table-cell >
				        <fo:block font-weight="bold">Coated Indicator</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">SPI</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">COMP CODE</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">KEYWORD DESCRIPTION</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">Blank Width</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">Blank Thickness</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">Blank Length</fo:block>			      
			      </fo:table-cell>				      			                 
			      <fo:table-cell >
				        <fo:block font-weight="bold">Components /Blank</fo:block>			      
			      </fo:table-cell>
			      <fo:table-cell >
				        <fo:block font-weight="bold">Blank Weight</fo:block>			      
			      </fo:table-cell>	
			      <fo:table-cell >
				        <fo:block font-weight="bold">Usage</fo:block>			      
			      </fo:table-cell>			       			         					 					 
  				</fo:table-row>
				</fo:table-header>
              <fo:table-body >
                <xsl:apply-templates select="PART"/>
              </fo:table-body>
            </fo:table>
          </fo:block>
        </fo:flow>
        
      </fo:page-sequence>
    </fo:root>
  </xsl:template>
  <!-- ========================= -->
  <!-- child element: member     -->
  <!-- ========================= -->
  <xsl:template match="PART">
    <fo:table-row border-width="0.5pt" border-style="solid" font-size="3pt">
    <!-- 
      <xsl:if test="function = 'lead'">
        <xsl:attribute name="font-weight">bold</xsl:attribute>
      </xsl:if>
      -->
      <fo:table-cell >
        <fo:block>
          <xsl:value-of select="LEVEL"/>
        </fo:block>
      </fo:table-cell>
      <fo:table-cell>
        <fo:block>
          <xsl:value-of select="ITEMID"/>
        </fo:block>
      </fo:table-cell>
      <fo:table-cell>
        <fo:block>
          <xsl:value-of select="ITEMDESC"/>
        </fo:block>
      </fo:table-cell>
       <fo:table-cell>
		<fo:block>
          <xsl:value-of select="REV"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="DI"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="UQ"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="QTY"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="CS"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="IA"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="LOC"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="SELN"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="OPCS"/>
        </fo:block>
        </fo:table-cell>  
      <fo:table-cell>
		<fo:block>
          <xsl:value-of select="OWNERNAME"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="PARTTYPE"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="COATEDID"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="SPI"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="COMPCODE"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="KEYWORDDESC"/>
        </fo:block>	
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="BLWIDTH"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="BLTHICKNESS"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>	
		<fo:block>
          <xsl:value-of select="BLLENGTH"/>
        </fo:block>
        </fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="COMPBLANKS"/>
        </fo:block>			
		</fo:table-cell>
        <fo:table-cell>
		<fo:block>
          <xsl:value-of select="BLWEIGHT"/>
        </fo:block>			
		</fo:table-cell>
		 <fo:table-cell>
		<fo:block>
          <xsl:value-of select="USAGE"/>
        </fo:block>			
		</fo:table-cell>            
    </fo:table-row>
  </xsl:template>
</xsl:stylesheet>
