<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
                xmlns:crf="http://ExternalFunction.setFile">


	 <xsl:output method="html" indent="yes"/>
			
	 
	 
	 
	<xsl:template match="/">
				
	 
					<html>
						<head>
							<style>
							h2 {text-align: center;}
							
							.myDiv {
							  border: 5px outset red;
							  background-color: lightblue;    
							  text-align: center;
							}
							<!--
							h3 {text-align: center;}
							h4 {text-align: center;}
							h5 {text-align: center;}-->
							
							
							</style>
							</head>
							<body>
							   
							<h2>Report Generated Successfully!!</h2>
							
							<div class="myDiv">
							<h3>Report File Name : <xsl:value-of select = "/Report/FileName"/></h3>
							<h4>File is mailed to User Email ID :<xsl:value-of select = "/Report/Mail"/></h4>
							<h5> Please check your eMail attachment.</h5>
							</div>
							 <script type="text/javascript">
							 
							 <![CDATA[
							var close = document.getElementsByClassName("closebtn");
							var i;

							for (i = 0; i < close.length; i++) {
							  close[i].onclick = function(){
								var div = this.parentElement;
								div.style.opacity = "0";
								setTimeout(function(){ div.style.display = "none"; }, 600);
							  }
							}
							]]>
							</script>

							</body>
					</html>	
	</xsl:template>
</xsl:stylesheet>
	 