<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>

    <xsl:key name="UserDt" match="plm:User" use="@id"/>
    <xsl:key name="ReleaseStatusList" match="plm:ReleaseStatus" use="@id"/>
    <xsl:key name="OrganisationList" match="plm:Organisation" use="@id"/>
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="30"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="110" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="110" AutoFitWidth="1"/>
                    
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Report Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:call-template name="sortReportDate"><xsl:with-param name="inRepDate" select="plm:PLMXML/@date"></xsl:with-param></xsl:call-template></Data>
                        </Cell>      
                        <Cell ss:StyleID="s22" ss:MergeAcross='3'>
                            <Data ss:Type='String'>MODULE INFO REPORT</Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Sr. No.</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part Number</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Revision/Sequence</Data>
                        </Cell> 
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Design Group</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Description</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>AddOn Description</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Owning User</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Creator</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Creation Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Lastupdate Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Organization ID</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>LCState</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DR Status</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Project</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Platform</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Aggregate Group</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Aggregates</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module Address</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module Group</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module Name</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module Type</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part Type</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Drawing Ind</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Pune Make/Buy</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>JSR Make/Buy</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>LKO Make/Buy</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>PNR Make/Buy</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>AHD Make/Buy</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>CAR Make/Buy</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>PunPCBU Make/Buy</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Dharwad Make/Buy</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateDesignRevPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateDesignRevPartsList">
        <xsl:for-each select="/plm:PLMXML/plm:DesignRevision">
            <xsl:variable name="CretorRef" select="plm:UserData/plm:UserValue[@title='owning_user']/@dataRef"/>
            <xsl:variable name="CreUserNode" select="key('UserDt',substring-after($CretorRef,'#'))"/>
            <xsl:variable name="releaseStatus" select="@releaseStatusRefs" />
            <xsl:variable name="OwningGroupRef" select="plm:UserData/plm:UserValue[@title='owning_group']/@dataRef"/>
            <xsl:variable name="OwningGroupNode" select="key('OrganisationList',substring-after($OwningGroupRef,'#'))"/>
			<Row>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='Number'><xsl:number value="position()" format="01"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data>
				</Cell>
			     <Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='item_revision_id']/@value"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_DesignGrp']/@value"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='current_desc']/@value"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_SimVal']/@value"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="$CreUserNode/@userId"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_VerCreator']/@value"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String' ><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="plm:UserData/plm:UserValue[@title='creation_date']/@value"></xsl:with-param></xsl:call-template></Data>
				</Cell> 
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String' ><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="plm:UserData/plm:UserValue[@title='last_mod_date']/@value"></xsl:with-param></xsl:call-template></Data>
				</Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'>
                    <xsl:choose>
                        <xsl:when test="$CreUserNode/@userId = 'loader'">ERC</xsl:when>
                        <xsl:when test="$CreUserNode/@userId = 'aplloader'">APL</xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="$OwningGroupNode/@name"/>
                        </xsl:otherwise>
                    </xsl:choose>
                    </Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'>
                        <xsl:call-template name="split">
                            <xsl:with-param name="input" select="$releaseStatus"></xsl:with-param>
                        </xsl:call-template>
                    </Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_PartStatus']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_ProjectCode']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_Platform']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_AggregateGroup']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_Aggregate']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_Module']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_ModuleAddress']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_Module_Group']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_ModuleName']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_ModuleType']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_PartType']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_DrawingInd']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_PunMakeBuyIndicator']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_JsrMakeBuyIndicator']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_LkoMakeBuyIndicator']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_PnrMakeBuyIndicator']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_AhdMakeBuyIndicator']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_CarMakeBuyIndicator']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_PunPCBUMakeBuyIndicator']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_DwdMakeBuyIndicator']/@value"/></Data>
                </Cell>
			</Row>
        </xsl:for-each>
    </xsl:template>
    
    <xsl:template name="replaceText">
        <xsl:param name="actualString" />
        <xsl:param name="findString" />
        <xsl:param name="replaceString" />
        <xsl:choose>
            <xsl:when test="contains($actualString, $findString)">
                <xsl:value-of select="substring-before($actualString, $findString)" />
                <xsl:value-of select="$replaceString" disable-output-escaping="yes" />
                <xsl:call-template name="replaceText">
                    <xsl:with-param name="actualString" select="substring-after($actualString, $findString)" />
                    <xsl:with-param name="findString" select="$findString" />
                    <xsl:with-param name="replaceString" select="$replaceString" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$actualString" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="split">
      <xsl:param name="input"/>
      <xsl:param name="delimiter" select="' '"/>
      <xsl:choose>
        <xsl:when test="contains($input, $delimiter)">
          <xsl:variable name="token" select="substring-before($input, $delimiter)"/>
          <!-- <xsl:value-of select="$token"/>
          <xsl:text> </xsl:text> -->
          <xsl:call-template name="split">
            <xsl:with-param name="input" select="substring-after($input, $delimiter)"/>
            <xsl:with-param name="delimiter" select="$delimiter"/>
          </xsl:call-template>
        </xsl:when>
        <xsl:otherwise>
            <xsl:variable name="ReleaseStatusNode" select="key('ReleaseStatusList',substring-after($input,'#'))"/>
            <!-- <xsl:value-of select="$input"/> -->
            <!-- <xsl:value-of select="$ReleaseStatusNode/@name"/> -->
            <xsl:choose>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LCS_CAEReleased'">CAE Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LCS_CAEReview'">CAE Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LCS_CAEWorking'">CAE Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsCoCReview'">In CoC Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsDesignerWorking'">In Designer Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsManagerReview'">In Manager Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_APLFinalReleased'">APL Final Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_APLPre-Released'">APL Pre- Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_ESAPLWorking'">APL Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_PSDFinalReleased'">PSD Final Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_PSDWorking'">PSD Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLWrkg_1'">APL Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplRew'">APL Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsDsnRelz'">PE Designer Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsDsnWrkg'">PE Designer Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsEstApp'">Cost Approved</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsEstimated'">Cost Estimate</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPECancel'">Indent Canceled</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPEClsRlzd'">PE Closure Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPEClsWrk'">PE Closure Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPEDrop'">Indent Dropped</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPERlzd_1'">PE Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPERlzd'">Indent Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPETxPLM_1'">Transferred to PLM</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPETxPLM'">Transferred to PLM</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPEWrkg_1'">PE Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPEWrkg'">Indent Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPLMRlzd'">APL Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsPlnWrkg'">Planner Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsWorking_1'">ERC Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAuthorzd'">Authorized</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsTOAbort'">Modfn Required</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsTOCQRvw'">CQ Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsTOChncl'">TryOut Cancel</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsTOMaFRv'">TryOut Manufacturing Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsTOSTDAM'">Approved Mail</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsTOSTDRvw'">TryOut STD Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsTOVDRvw'">TryOut VD Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsTOVQTSRv'">TryOut VQA &amp; TS Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_STDSIReleased'">STDSI Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_STDSIWorking'">STDSI Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_TOApproved Mail'">Approved</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_TOCcfAuthoring'">Authoring</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_TOLcsAgncWrkg'">Feedback from Agencies</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_TOLcsApproved'">Approved</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_TOLcsRejected'">Rejected</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_TOLcsWorking'">ERC Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLWrkg'">APLC Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLaWrkg'">APLA Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLdWrkg'">APLD Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLjWrkg'">APLJ Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLlWrkg'">APLL Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLpWrkg'">APLP Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLuWrkg'">APLU Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAPLvWrkg'">APLV Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplReview'">APLC Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplRlzd'">APLC Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplaReview'">APLA Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplaRlzd'">APLA Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsApldReview'">APLD Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsApldRlzd'">APLD Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsApljReview'">APLJ Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsApljRlzd'">APLJ Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsApllReview'">APLL Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsApllRlzd'">APLL Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplpReview'">APLP Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplpRlzd'">APLP Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsApluReview'">APLU Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsApluRlzd'">APLU Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplvReview'">APLV Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsAplvRlzd'">APLV Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsErcRlzd'">ERC Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsReview'">ERC Review</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDARResc'">STDSIA Re-Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDDRResc'">STDSID Re-Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDJRResc'">STDSIJ Re-Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDPRResc'">STDSIP Re-Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDRResc'">STDSIC Re-Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDURResc'">STDSIU Re-Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDVRResc'">STDSIV Re-Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDWrkg'">STDSIC Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDaWrkg'">STDSIA Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDdWrkg'">STDSID Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDjWrkg'">STDSIJ Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDlRResc'">STDSIL Re-Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDlWrkg'">STDSIL Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDpWrkg'">STDSIP Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDuWrkg'">STDSIU Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsSTDvWrkg'">STDSIV Working</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdRestructured'">STDSIC Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdRlzd'">STDSIC Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdaRestructured'">STDSIA Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdaRlzd'">STDSIA Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStddRestructured'">STDSID Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStddRlzd'">STDSID Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdjRestructured'">STDSIJ Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdjRlzd'">STDSIJ Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdlRestructured'">STDSIL Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdlRlzd'">STDSIL Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdpRestructured'">STDSIP Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdpRlzd'">STDSIP Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStduRestructured'">STDSIU Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStduRlzd'">STDSIU Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdvRestructured'">STDSIV Restructured</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsStdvRlzd'">STDSIV Released</xsl:when>
                <xsl:when test="$ReleaseStatusNode/@name = 'T5_LcsWorking'">ERC Working</xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$ReleaseStatusNode/@name"/>
                </xsl:otherwise>
            </xsl:choose>

        </xsl:otherwise>
      </xsl:choose>
    </xsl:template>
    
    <xsl:template name="sortDate">
        <xsl:param name="inDate" />
        <xsl:if test="string-length($inDate)&gt;1">
            <xsl:variable name="datebit1" select="substring-before($inDate,'T')"/>
            <xsl:variable name="datebit2" select="substring-after($datebit1,'-')"/>
            <xsl:variable name="yearbit" select="substring-before($datebit1,'-')"/>
            <xsl:variable name="monthbit" select="substring-before($datebit2,'-')"/>
            <xsl:variable name="daybit" select="substring-after($datebit2,'-')"/>
            <xsl:variable name="timebit1" select="substring-after($inDate,'T')"/>
            <xsl:variable name="timebit2" select="substring-after($timebit1,':')"/>
            <xsl:variable name="hourbit" select="substring-before($timebit1,':')"/>
            <xsl:variable name="minbit" select="substring-before($timebit2,':')"/>
            <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit,'  ')"/>
        </xsl:if>
    </xsl:template>
    
    <xsl:template name="sortReportDate">
        <xsl:param name="inRepDate"/>
        <!--<xsl:variable name="inRepDate" select="plm:PLMXML/@date"/>-->
        <xsl:variable name="datebit1" select="substring-after($inRepDate,'-')"/>
        <xsl:variable name="yearbit" select="substring-before($inRepDate,'-')"/>
        <xsl:variable name="monthbit" select="substring-before($datebit1,'-')"/>
        <xsl:variable name="daybit" select="substring-after($datebit1,'-')"/>
        <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit)"/>
    </xsl:template>
    
</xsl:stylesheet>