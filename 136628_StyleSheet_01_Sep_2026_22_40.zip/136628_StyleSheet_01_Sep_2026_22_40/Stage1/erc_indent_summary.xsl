<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:key name="ercIndentRev" match="plm:ProductRevision[@subType='T5_ERCIndRevision']" use="@id"/>
    <!-- <xsl:key name="ercNonPlmParts" match="plm:TableRow[@tablePropertyName='t5_NonPLMParts']" use="@id"/> -->
    <xsl:key name="designRev" match="plm:DesignRevision" use="@id"/>
    <xsl:key name="clrRev" match="plm:ProductRevision[@subType='T5_ClrPartRevision']" use="@id"/>
    
    <xsl:param name="indentRootId" select="substring-after(/plm:PLMXML/plm:Header/@traverseRootRefs,'#')"></xsl:param>
    <xsl:param name="indentNode" select="key('ercIndentRev',$indentRootId)"></xsl:param>
    
    <xsl:key name="UserDt" match="plm:User" use="@id"/>
    <xsl:key name="PersonDt" match="plm:Person" use="@id"/>
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>        
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s27" ss:Name="PropertyNameCellCenter">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="30"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="150"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/><!--Column 5-->
                    <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="110" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/><!--Column 10-->
                    <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
                    
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s21" ss:MergeAcross='3'>
                            <Data ss:Type='String'>TATA MOTORS PUNE</Data>
                        </Cell>                        
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>                       
                        <Cell ss:StyleID="s21" ss:MergeAcross='3'>
                            <Data ss:Type='String'>Engineering Research Center</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>       
                        <Cell ss:StyleID="s22" ss:MergeAcross='3'>
                            <Data ss:Type='String'>MANUFACTURING INDENT</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Report Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:call-template name="sortReportDate"><xsl:with-param name="inRepDate" select="plm:PLMXML/@date"></xsl:with-param></xsl:call-template></Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell></Cell>
                        <!--<Cell>
                            <Data ss:Type='String'>Indent Name:</Data>
                        </Cell>
                        <Cell>
                            <Data ss:Type='String'><xsl:value-of select="$indentNode/@name"/></Data>
                        </Cell>-->
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Indent Ref. No</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5RefNo']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>   
                        <Cell></Cell> 
                        <!--<Cell></Cell>--> 
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Indenting Agency</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5ERIndSec']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                               <Data ss:Type='String' >Project Code</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5PrjCode']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell> 
                        <!--<Cell></Cell>-->
                        <Cell ss:StyleID="s26">
                                <Data ss:Type='String'>Last Modified Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="$indentNode/plm:UserData/plm:UserValue[@title='last_mod_date']/@value"></xsl:with-param></xsl:call-template><!--<xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='last_mod_date']/@value"/>--></Data>
                        </Cell>
                    </Row>
                    
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String' >WBS</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5WBS']/@value"/></Data>
                        </Cell>
                        
                    </Row>
                    
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String' >WBS Desc</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5IndWbsDes']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell> 
                        <!--<Cell></Cell>-->
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Proto Indent Category</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5PrtIndCat']/@value"/></Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle/VC No.</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5IndVehno']/@value"/></Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:MergeAcross='1' ss:StyleID="s26">
                            <Data ss:Type='String'>HEAD OF PROTOTYPE PLANNING</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:MergeAcross='5' ss:StyleID="s26">
                            <Data ss:Type='String'>Kindly arrange to Manufacture (develop item as per following drawing for the project under reference)</Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Sr. No.</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part Number</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Revision/Sequence</Data>
                        </Cell> 
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Description of Item</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Qty/Set</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>No. of Sets Req.</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part Category</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>I.R. Reqd.</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>TRSO</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Supplier Name</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>TKO</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DR Status</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Remark</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateIndentPartsList"></xsl:call-template>
                    <xsl:call-template name="generateNonPLMPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell></Cell>
                        <Cell 
                            ss:StyleID="s24" ss:MergeAcross='1'>
                            <Data ss:Type='String'>These items are required for the purpose of :</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5ERCIndPurpose']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>                        
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'>Remark</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5ERCIndRemark']/@value"/></Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s27" ss:MergeAcross='6'>
                            <Data ss:Type='String'>Contact Person</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Sr. No.</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>User ID</Data>
                        </Cell>
                        <Cell ss:StyleID="s26" ss:MergeAcross='1'>
                            <Data ss:Type='String'>User Name</Data>
                        </Cell>
                        <Cell ss:StyleID="s26" ss:MergeAcross='1'>
                            <Data ss:Type='String'>Email-ID</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Role</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateParticipantsList"></xsl:call-template>
                    <Row></Row>
                    
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>

    <xsl:template name="generateParticipantsList">
        <xsl:variable name="CretorRef" select="$indentNode/plm:UserData/plm:UserValue[@title='owning_user']/@dataRef"/>
        <xsl:variable name="CreUserNode" select="key('UserDt',substring-after($CretorRef,'#'))"/>
        <xsl:variable name="CrePersonRef" select="$CreUserNode/@personRef"/>
        <xsl:variable name="CrePersonNode" select="key('PersonDt',substring-after($CrePersonRef,'#'))"/>
        <Row>
            <Cell></Cell>
            <Cell ss:StyleID="s24">
                <Data ss:Type='Number'>01</Data>
            </Cell>
            <Cell ss:StyleID="s24">
                <Data ss:Type='String'><xsl:value-of select="$CreUserNode/@userId"/></Data>
            </Cell>
            <Cell ss:StyleID="s24" ss:MergeAcross='1'>
                <Data ss:Type='String'><xsl:value-of select="$CrePersonNode/@lastName"/></Data>
            </Cell>
            <Cell ss:StyleID="s24" ss:MergeAcross='1'>
                <Data ss:Type='String'><xsl:value-of select="$CrePersonNode/plm:UserData/plm:UserValue[@title='PA9']/@value"/></Data>
            </Cell>
            <Cell ss:StyleID="s24">
                <Data ss:Type='String'>Indent Creator</Data>
            </Cell>
        </Row>

        <xsl:for-each select="/plm:PLMXML/plm:Participant">
            <xsl:variable name="participantType" select="@userDefinedType"/>
            <xsl:variable name="AssgnUsr" select="plm:UserData/plm:UserValue[@title='fnd0AssigneeUser']/@dataRef"/>
            <xsl:variable name="UserNode" select="key('UserDt',substring-after($AssgnUsr,'#'))"/>
            <xsl:choose>
              <xsl:when test="$participantType = 'T5_IndMngrReviw'">
                <Row>
                    <Cell></Cell>
                    <Cell ss:StyleID="s24">
                        <Data ss:Type='Number'>02</Data>
                    </Cell>
                    <Cell ss:StyleID="s24">
                        <Data ss:Type='String'><xsl:value-of select="$UserNode/@userId"/></Data>
                    </Cell>
                    <Cell ss:StyleID="s24" ss:MergeAcross='1'>
                        <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='object_string']/@value"/></Data>
                    </Cell>
                    <Cell ss:StyleID="s24" ss:MergeAcross='1'>
                        <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='fnd0AssigneeEmail']/@value"/></Data>
                    </Cell>
                    <Cell ss:StyleID="s24">
                        <Data ss:Type='String'>Head Of Section</Data>
                    </Cell>
                </Row>
              </xsl:when>
              <xsl:when test="$participantType = 'T5_IndChfEng'">
                <Row>
                    <Cell></Cell>
                    <Cell ss:StyleID="s24">
                        <Data ss:Type='Number'>03</Data>
                    </Cell>
                    <Cell ss:StyleID="s24">
                        <Data ss:Type='String'><xsl:value-of select="$UserNode/@userId"/></Data>
                    </Cell>
                    <Cell ss:StyleID="s24" ss:MergeAcross='1'>
                        <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='object_string']/@value"/></Data>
                    </Cell>
                    <Cell ss:StyleID="s24" ss:MergeAcross='1'>
                        <Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='fnd0AssigneeEmail']/@value"/></Data>
                    </Cell>
                    <Cell ss:StyleID="s24">
                        <Data ss:Type='String'>Chief Engineer</Data>
                    </Cell>
                </Row>
              </xsl:when>
            </xsl:choose>
        </xsl:for-each>
    </xsl:template>

    <xsl:template name="generateNonPLMPartsList">
        <xsl:for-each select="//plm:TableRow[@tablePropertyName='t5_NonPLMParts']">
            <Row>
                <Cell></Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='Number'><xsl:number value="position()" format="01"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartNo']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartRev']/@value"/>;<xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartSeq']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartDesc']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartQtySet']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartSetReq']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartCat']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'>--</Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartTrso']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartVendor']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartTKO']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'>--</Data>
                </Cell> 
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="plm:TableColumn[@title='t5_NonPLMIndPartRem']/@value"/></Data>
                </Cell>
            </Row>
        </xsl:for-each>
    </xsl:template>
    
    <xsl:template name="generateIndentPartsList">
        <xsl:for-each select="/plm:PLMXML/plm:GeneralRelation">
            <xsl:variable name="indentPartRef" select="substring-after(@relatedRefs,' ')"/>
            <xsl:variable name="DesignPartNode" select="key('designRev',substring-after($indentPartRef,'#'))"/>
			<xsl:if test="$DesignPartNode/plm:UserData/plm:UserValue[@title='item_id']/@value != ''">
				<Row>
					<Cell></Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='Number'><xsl:number value="position()" format="01"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="$DesignPartNode/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="$DesignPartNode/plm:UserData/plm:UserValue[@title='item_revision_id']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="$DesignPartNode/plm:UserData/plm:UserValue[@title='current_desc']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_ERCIndQtySet']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_ERCIndReqdSet']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_PartIndCategory']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5ERIndIR']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_TRSOStatus']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_SupplierName']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_TkoStatus']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5PartStatus']/@value"/></Data>
					</Cell> 
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5ERCIndRemark']/@value"/></Data>
					</Cell>
				</Row>
			</xsl:if>
            <xsl:variable name="ColourPartNode" select="key('clrRev',substring-after($indentPartRef,'#'))"/>
			<xsl:if test="$ColourPartNode/plm:UserData/plm:UserValue[@title='item_id']/@value != ''">
				<Row>
					<Cell></Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='Number'><xsl:number value="position()" format="01"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="$ColourPartNode/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="$ColourPartNode/plm:UserData/plm:UserValue[@title='item_revision_id']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="$ColourPartNode/plm:UserData/plm:UserValue[@title='current_desc']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_ERCIndQtySet']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_ERCIndReqdSet']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_PartIndCategory']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5ERIndIR']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_TRSOStatus']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_SupplierName']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5_TkoStatus']/@value"/></Data>
					</Cell>
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5PartStatus']/@value"/></Data>
					</Cell> 
					<Cell ss:StyleID="s24">
						<Data ss:Type='String'><xsl:value-of select="plm:UserData/plm:UserValue[@title='t5ERCIndRemark']/@value"/></Data>
					</Cell>
				</Row>
			</xsl:if>
        </xsl:for-each>
    </xsl:template>
    
    <xsl:template name="replaceText">
        <xsl:param name="actualString" />
        <xsl:param name="findString" />
        <xsl:param name="replaceString" />
        <xsl:choose>
            <xsl:when test="contains($actualString, $findString)">
                <xsl:value-of select="substring-before($actualString, $findString)" />
                <xsl:value-of select="$replaceString" disable-output-escaping="yes" />
                <xsl:call-template name="replaceText">
                    <xsl:with-param name="actualString" select="substring-after($actualString, $findString)" />
                    <xsl:with-param name="findString" select="$findString" />
                    <xsl:with-param name="replaceString" select="$replaceString" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$actualString" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    
    <xsl:template name="sortDate">
        <xsl:param name="inDate" />
        <xsl:if test="string-length($inDate)&gt;1">
            <xsl:variable name="datebit1" select="substring-before($inDate,'T')"/>
            <xsl:variable name="datebit2" select="substring-after($datebit1,'-')"/>
            <xsl:variable name="yearbit" select="substring-before($datebit1,'-')"/>
            <xsl:variable name="monthbit" select="substring-before($datebit2,'-')"/>
            <xsl:variable name="daybit" select="substring-after($datebit2,'-')"/>
            <xsl:variable name="timebit1" select="substring-after($inDate,'T')"/>
            <xsl:variable name="timebit2" select="substring-after($timebit1,':')"/>
            <xsl:variable name="hourbit" select="substring-before($timebit1,':')"/>
            <xsl:variable name="minbit" select="substring-before($timebit2,':')"/>
            <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit,'  ')"/>
        </xsl:if>
    </xsl:template>
    
    <xsl:template name="sortReportDate">
        <xsl:param name="inRepDate"/>
        <!--<xsl:variable name="inRepDate" select="plm:PLMXML/@date"/>-->
        <xsl:variable name="datebit1" select="substring-after($inRepDate,'-')"/>
        <xsl:variable name="yearbit" select="substring-before($inRepDate,'-')"/>
        <xsl:variable name="monthbit" select="substring-before($datebit1,'-')"/>
        <xsl:variable name="daybit" select="substring-after($datebit1,'-')"/>
        <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit)"/>
    </xsl:template>
    
</xsl:stylesheet>