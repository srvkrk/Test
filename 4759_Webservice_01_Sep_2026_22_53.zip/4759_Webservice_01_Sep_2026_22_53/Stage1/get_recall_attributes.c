#include "soapH.h"
#include "get_recall_attributes.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <time.h>
#include <tccore/tctype.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128
//#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		//printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			//printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}                                  
extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;
int ns__GetRecallAttributes(struct soap* soap,char *Item, char* Rev, char* Seq,char **Response)
{
        int ifail =0;
		int i,j = 0;
		char*			responseString			= NULL;

		*Response = (char *) malloc( (5000) * sizeof(char));

		tag_t query_tag         = NULLTAG;
		tag_t *Rev1Tag           = NULLTAG;
		tag_t ItemTag		    = NULLTAG;
		//tag_t ItemTag		    = NULLTAG;


		char *part_no           = NULL;
		char *Revision          = NULL;
		char *sequence          = NULL;
		char *object_desc       = NULL;
		char *t5_DocRemarks     = NULL;
		char *t5_TrackTrace     = NULL;
		char *t5_CTECTS         = NULL;
		char *t5_SheetSize      = NULL;
		char *Object_string     = NULL;
        char *entries[2]        = {"Item ID","Revision"};
		//tag_t *list_of_WSO_tags_SP=NULLTAG;
		//int number_found_SP = 0;

		int n_items             = 0;
		int value_entries       = 2;
		//char **values           = NULL;
		//WSO_search_criteria_t  	criteria_SP;

		//char *Rev1               =NULL;


		Revision =(char *) MEM_alloc(50);
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
        freopen("/tmp/tcuadml.txt", "a", stdout);

		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		ITK_CALL(ITK_auto_login( ));
		ITK_CALL(ITK_set_journalling( TRUE ));

		//printf("\n part_no : [%s]\n",Item);fflush(stdout);
		//printf("\n revision: [%s]\n",Rev);fflush(stdout);
		//printf("\n sequence : [%s]\n",Seq);fflush(stdout);

		tc_strcpy(Revision,Rev);
		tc_strcat(Revision,"*");
		tc_strcat(Revision,Seq);

		//printf("\nRevision : [%s]", Revision );fflush(stdout);

        //values = (char **) MEM_alloc(10 * sizeof(char *));
		char **values =(char **) MEM_alloc(sizeof(char)* 100);

		//ifail = ITEM_find_item (Item ,&ItemTag);
		//ifail = ITEM_find_revision (ItemTag ,


		//WSOM_clear_search_criteria(&criteria_SP);
		//
		//strcpy(criteria_SP.item_id ,Item);
		//strcpy(criteria_SP.item_revision_id,Revision);
	    //ifail	= WSOM_search(criteria_SP, &number_found_SP, &list_of_WSO_tags_SP);
		ITK_CALL(QRY_find("Item Revision...",&query_tag));

				if (query_tag)
				{
					//printf("\nFound Query : Item Revision...\n"); fflush(stdout);
					//fprintf(fp1,"\nFound Query : Item Rev1ision...\n"); fflush(stdout);
					
		            values[0] = (char *)MEM_alloc( strlen( Item ) + 1);
		            tc_strcpy(values[0], Item  );
					
					values[1] = (char *)MEM_alloc( strlen( Revision ) + 1);
		            tc_strcpy(values[1], Revision );


                    //printf("\n execute Query : Item Revision...\n"); fflush(stdout);
                    //fprintf(fp1,"\n execute Query : Item Rev1ision...\n"); fflush(stdout);

					ITK_CALL(QRY_execute(query_tag, value_entries, entries, values, &n_items, &Rev1Tag));

                    //printf("\nItem Revision Found : [%d]\n",n_items); fflush(stdout);
                    //fprintf(fp1,"\nItem Rev1ision Found : [%d]\n",n_items); fflush(stdout);

				
			            if(n_items>0)
			            {
			            	responseString=(char *)MEM_alloc(5000);
			            	//responseString1=(char *)MEM_alloc(200);
			            	//responseString2=(char *)MEM_alloc(200);
			            	//responseString3=(char *)MEM_alloc(200);
			            	//responseString4=(char *)MEM_alloc(200);
			            	//responseString5=(char *)MEM_alloc(200);
			            	
			            
                            ItemTag = Rev1Tag[0];
			            	ifail = AOM_UIF_ask_value(ItemTag,"object_string",&Object_string); //Part Number Rev1ision , sequence
			            	//printf("\nPart Number Rev1ision , sequence : [%s]\n",Object_string); fflush(stdout);
			            	//tc_strcpy(responseString,Object_string);
			            	//tc_strcat(responseString,Object_string);
			            
			            	ifail = AOM_UIF_ask_value(ItemTag,"object_desc",&object_desc); //Description
			            	//printf("\n Description : [%s]\n",object_desc); fflush(stdout);
			                //tc_strcpy(responseString1,object_desc);
			            	//tc_strcat(responseString1,object_desc);
			            
			            	ifail = AOM_UIF_ask_value(ItemTag,"t5_DocRemarks",&t5_DocRemarks);//Modification Description
			            	//printf("\n Modification Description : [%s]\n",t5_DocRemarks); fflush(stdout);
			            	//tc_strcpy(responseString2,t5_DocRemarks); 
			            	//tc_strcat(responseString2,t5_DocRemarks);
			            
			            
			            	ifail = AOM_UIF_ask_value(ItemTag,"t5_TrackTrace",&t5_TrackTrace);//Track & Trace
			            	//printf("\nTrack & Trace : [%s]\n",t5_TrackTrace); fflush(stdout);
			            	//tc_strcpy(responseString3,t5_TrackTrace); 
			            	//tc_strcat(responseString3,t5_TrackTrace);
			            
			            	ifail = AOM_UIF_ask_value(ItemTag,"t5_CTECTS",&t5_CTECTS); //Critical to Emission Critical to Safety
			            	//printf("\n Critical to Emission Critical to Safety : [%s]\n",t5_CTECTS); fflush(stdout);
			            	//tc_strcpy(responseString4,t5_CTECTS); 
			            	//tc_strcat(responseString4,t5_CTECTS);
			            
			            	ifail = AOM_UIF_ask_value(ItemTag,"t5_SheetSize",&t5_SheetSize); // Drawing Sheet Size and Sheet orientation
			            	//printf("\nDrawing Sheet Size : [%s]\n",t5_SheetSize); fflush(stdout);
			            	//tc_strcpy(responseString5,t5_SheetSize); 
			            	//tc_strcat(responseString5,t5_SheetSize);
	                       // printf("*********************************************************************************"); fflush(stdout);
			            


                            tc_strcpy(responseString,"PartNo:");
                            tc_strcat(responseString,Item);
                            tc_strcat(responseString,",");
                            tc_strcat(responseString,Rev);
                            tc_strcat(responseString,",");
                            tc_strcat(responseString,Seq);
							tc_strcat(responseString,"~");
							tc_strcat(responseString,"Description:");
							tc_strcat(responseString,object_desc);
							tc_strcat(responseString,"~");
							tc_strcat(responseString,"Modification_description:");
							tc_strcat(responseString,t5_DocRemarks);
							tc_strcat(responseString,"~");
							tc_strcat(responseString,"Track_Trace:");
							tc_strcat(responseString,t5_TrackTrace);
							tc_strcat(responseString,"~");
							tc_strcat(responseString,"Critical_to_Emission_Critical_to_Safety:");
							tc_strcat(responseString,t5_CTECTS);
							tc_strcat(responseString,"~");
							tc_strcat(responseString,"Drawing_Sheet_Size_and_Sheet_orientation:");
							tc_strcat(responseString,t5_SheetSize);
							tc_strcat(responseString,"~");

							//printf("\n Output: %s ",responseString);fflush(stdout);


                            tc_strcpy(*Response,responseString);
			            
			            
			            	//aString_test-> __size =1;
			            	//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
			            	//for(i=0;i<1;i++)
			            	//{
			            
                                //aString_test->__ptrItem[1].PartNo = malloc(3000 * sizeof(char *) );
			            		//strcpy(aString_test->__ptrItem[1].PartNo,responseString); // PartNo
			            
			            		//aString_test->__ptrItem[i].Description = malloc(30 * sizeof(char *) );
			            		//strcpy(aString_test->__ptrItem[i].Description,responseString1); // Description
			            		//
			            		//aString_test->__ptrItem[i].Modification_description = malloc(30 * sizeof(char *) );
			            		//strcpy(aString_test->__ptrItem[i].Modification_description,responseString2); // Modification_description
			            		//
			            		//
			            		//aString_test->__ptrItem[i].TrackTrace = malloc(200 * sizeof(char *) );
			            		//strcpy(aString_test->__ptrItem[i].TrackTrace,responseString3); // TrackTrace
			            		//
			            		//aString_test->__ptrItem[i].CTECTS = malloc(30 * sizeof(char *) );
			            		//strcpy(aString_test->__ptrItem[i].CTECTS,responseString4); // CTECTS
			            		//
			            		//aString_test->__ptrItem[i].SheetSize = malloc(30 * sizeof(char *) );
			            		//strcpy(aString_test->__ptrItem[i].SheetSize,responseString5); // SheetSize
			            
			            
			            	//}
			            }
						else 
					    {
							tc_strcpy(*Response,"***********Part Not Found**************");

					    }
		}///
		//}
		//fflush(stdout);
		//dup2(fd, fileno(stdout));
		//close(fd);
		//clearerr(stdout);
		//fsetpos(stdout, &pos);

		fflush(stdout);
        dup2(fd, fileno(stdout));
        close(fd);
        clearerr(stdout);
        fsetpos(stdout, &pos);

		return SOAP_OK;
}