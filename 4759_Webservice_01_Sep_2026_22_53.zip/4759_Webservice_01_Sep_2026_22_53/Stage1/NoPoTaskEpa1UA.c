#define _CLMAIN_DEFNS
#include <cl.h>
#include <ft.h>
#include <malloc.h>
#include <mserv.h>
#include <msgapc.h>
#include <msglcm.h>
#include <msgomf.h>
#include <msgtel.h>
#include <nls.h>
#include <oi.h>
#include <pdmc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <sc.h>
#include <semaphore.h>
#include <serv.h>
#include <status.h>
#include <stdlib.h>
#include <string.h>
#include <tel.h>
#include <ui.h>
#include <usc.h>
#include "soapH.h"
#include "NoPoTaskEpa1UA.nsmap"

string		  ProjectCodedup           = NULL;
SetOfObjects outputObjSet = NULL;
int  TotalCount = 0;
int  GolbalVcFlag = 0;
int  GolbalFlag = 0;
//SetOfStrings	uniqueListSS	=	NULL;




char* subString(char* mainStringf,  int fromCharf,  int toCharf)
{
        int substr1;
        char *retStringf;
        retStringf =  (char*) malloc(toCharf + 1);
        for(substr1 = 0; substr1 < toCharf; substr1++ )
                *(retStringf + substr1) =  *(mainStringf + substr1 + fromCharf);
        *(retStringf + substr1) =  '\0';
        return retStringf;
}
;



int main(int argc, char *argv[])
{
	t5MethodInitWMD("NoPoTaskEpa1.c");
	dstat = clInitMB2 (argc,&argv,NULL);
	return soap_serve(soap_new()); /* call the request dispatcher */

}
;

/******* new function by sarin to sort objects in ascending order **********/
status t5SortBOMObjsByDate
(
				SetOfObjects     *itemObjs,
				SetOfObjects     *relObjs,
				integer*                               mfail
)
{
                status                                    dstat                      = OKAY;
                char                                       *mod_name      = "t5SortBOMObjsByDate";
                SetOfObjects    tmpItemObjs    = NULL;
                SetOfObjects    tmpRelObjs     = NULL;
                ObjectPtr                            relObj                   = NULL;
                ObjectPtr                            itemObj                               = NULL;
                ObjectPtr                            relTObj                 = NULL;
                ObjectPtr                            itemTObj             = NULL;
                integer                                 count                    = 0;
                integer                                 cmpCount           = 0;
                ObjectPtr                            tmpRelObj          = 0;
                string                                     curCreDate                         = NULL;
                string                                     tmpcurCreDate = NULL;
                string                                     cmpCreDate                       = NULL;
                string                                     tmpcmpCreDate              = NULL;
                *mfail                   = USC_OKAY;

                /* processing */
                for(count=0; count<setSize(*relObjs); count++)
                {
                                itemObj = setGet(*itemObjs, count);
                                relObj = setGet(*relObjs, count);

                                /* initalizing sorted object set */
                                if(count == 0)
                                {
                                                if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
                                                if(dstat = ulyCopyObjectToSet(relObj, &tmpRelObjs)) goto CLEANUP;
                                                continue;
                                }

                                if(dstat = objCopy(&relTObj, relObj)) goto CLEANUP;
                                if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;

                                /* get mainSerial */
                               // if(dstat = objGetAttribute(relObj, CreationDateAttr, &curCreDate)) goto CLEANUP;
                                if(dstat = objGetAttribute(relObj, DateCreatedAttr, &curCreDate)) goto CLEANUP;
                                tmpcurCreDate = nlsStrDup(curCreDate);
								//printf("\ntmpcurCreDate : %s",tmpcurCreDate);fflush(stdout);

                                /* compare mainSerial with the new set of objects */
                                for(cmpCount=0; cmpCount<setSize(tmpRelObjs); cmpCount++)
                                {
                                                tmpRelObj = setGet(tmpRelObjs, cmpCount);

                                                //if(dstat = objGetAttribute(tmpRelObj, CreationDateAttr, &cmpCreDate)) goto CLEANUP;
                                                if(dstat = objGetAttribute(tmpRelObj, DateCreatedAttr, &cmpCreDate)) goto CLEANUP;
                                                tmpcmpCreDate = nlsStrDup(cmpCreDate);

                                                if(nlsStrCmp(tmpcurCreDate,tmpcmpCreDate) <= 0)
                                                {
                                                                low_set_insrt(tmpRelObjs, cmpCount, relTObj);
                                                                low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
                                                                break;
                                                }
                                }
                                if(cmpCount == setSize(tmpRelObjs))
                                {
                                                low_set_insrt(tmpRelObjs, cmpCount, relTObj);
                                                low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
                                }
                }

                /* free memory and assign to new set sorted objects */
                objDisposeAll(*itemObjs); *itemObjs = NULL;
                objDisposeAll(*relObjs); *relObjs = NULL;

                *itemObjs = tmpItemObjs;
                *relObjs = tmpRelObjs;

CLEANUP:

EXIT:
                if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
                return( dstat );
}


int ns__getDMLPODetailsData(struct soap* soap,char *TaskName,struct ns__CharArray3 *aString_test3)
{
			SetOfStrings  dbScp		=   NULL;
			string		  docobjst	=	NULL;
			SetOfObjects  taskObjs    = NULL;
			SetOfObjects  DataItemSO  = NULL ;
			SetOfObjects		noPOs	= NULL;
			SetOfObjects		setParts	= NULL;
			SetOfObjects		setParts1	= NULL;
			ObjectPtr taskObj = NULL;
			ObjectPtr NoPoObj = NULL;
			ObjectPtr setPart = NULL;
			ObjectPtr setPart1= NULL;
				int			  ii		=   0;
				int			  i		=   0;
				int			  d		=   0;
				int			  n		=   0;
				int			  iPOCnt		=   0;
				int			  YrInt	=	0;
			SqlPtr  Sql_ptr  = NULL;
			
			string		  prtNum						= NULL;
			string		  chldPrtNum					= NULL;
			string		  chldPrtNumD					= NULL;
			string		  chldPrtNum1					= NULL;
			string		  chldPrtNum2					= NULL;
			string		  chldPrtNum3					= NULL;
			string		  chldPrtDesc					= NULL;
			string		  HomoDup						= NULL;
			string		  Homo							= NULL;
			string		  CreDateDup					= NULL;
			string		  CreDate						= NULL;
			string		  YrStr							= NULL;
			string	      YrStrDup						= NULL;
			//string		  Partobj						= NULL;
			string		  PartDetailsStr                = NULL;
			string		  Rev							= NULL;
			string		  RevDup						= NULL;
			string		  Seq							= NULL;
			string		  SeqDup						= NULL;
			//string		  Desc							= NULL;
			//string		  DescDup						= NULL;



			
			
//			string		  jtFlpName		                = NULL;
//			string		  jtFlpNameDup					= NULL;


			status dstat = OKAY;
			int mfail =USC_OKAY;
			int     cnt			=	0;
			//int     prtcnt		=	0;
			int d1 = 0;
			int d2 = 0;
			int j = 0;
			int revcnt = 0;
			
			
			//int		retStatus	=	0;


			//const char* txtargv[10];
			char		buff[90240];
			
			


				int DataItem ;
            	ObjectPtr NewDataItemObjP=NULL;
            	ObjectPtr VisFileObjP=NULL;
            	ObjectPtr proprtrevObjP=NULL;
                string fullPathattr = NULL;
                string fullPathattr1 = NULL;
                string fullPathattrDup = NULL;
                string fullPathattrDup1 = NULL;
                string Temp1 = NULL;
                string StrTmpPrtDatStr = NULL;
                string HostNam = NULL;
                string HostNamDup = NULL;
                string CS = NULL;
                string CSDup = NULL;
                string MatS = NULL;
                string MatSDup = NULL;
                string chldPrtDescDup = NULL;
              
	            SetOfStrings	attchdDmlSet1    = NULL;
				SetOfStrings	PartListSS	=	NULL;
				
				SetOfStrings	t5ChkPartExit		=	NULL;
				SetOfStrings	t5ChkPartRExit		=	NULL;//Changes
				SetOfStrings	uniqueListSS		=	NULL;
				SetOfStrings	LifeCycValSet		=	NULL;

				
				//uniqueListSS        =set_create_str(20000);
				
				char * line = NULL;
				size_t len = 0;// size_t is the unsigned integer type of the result of sizeof
				ssize_t read;// This data type is used to represent the sizes of blocks that can be read or written in a single operation

	//UA Variable
	string			StrFullPathShell	=	NULL;

	string			inputfile			=	NULL;
	const char		*txtargv[3];
	int				SysReturn			=	0;
	string			sysdate				=	NULL;
    
	        FILE	*TskToDmlUA;
			FILE	*fp1;

			string		    FileNameDup			=	NULL;
			string			TodayDate			=	NULL;
			
			FileNameDup		=	nlsStrAlloc(500);

			TodayDate=sysGetCTime();
			low_strrpl(TodayDate,' ','_');
			low_strrpl(TodayDate,':','_');

			nlsStrCpy(FileNameDup,"/plmuv_logs/omfprod/logs/");
			nlsStrCat(FileNameDup,"NOPO_");
			nlsStrCat(FileNameDup,TodayDate);
			nlsStrCat(FileNameDup,".log");

			TskToDmlUA = fopen(FileNameDup , "a+") ;
			if(FileNameDup==NULL)
			{
				goto EXIT;
			}



	//UA Variable ends

	//char* mod_name="ns__getVcDetailsData";
	//printf("\nHELLOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");fflush(stdout);
	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/logNoPOUAEPA1.txt", "w", stdout);

	if (dstat = clInitialize2 (TRUE)) goto CLEANUP;
	/*if (dstat = clLogin2("hps08540","Nexon@123",&stat)) goto CLEANUP;
	if (stat != OKAY)
	{
		//printf("\nInvalid User Name or Password !!!!!!!!!!!!\n");
		goto EXIT;
	}*/

	//if (dstat = clLogin2 ("Loader","123loader",&mfail))goto CLEANUP;
	//if (dstat = clLogin2 ("hps08540","Nexon@123",&mfail))goto CLEANUP;
	//if (mfail!=OKAY)
	//{
	//	//printf("\nLogin Failed \n"); fflush(stdout);
	//	goto EXIT;
	//}

	attchdDmlSet1	=	setCreate(1);
	t5ChkPartExit	=	setCreate(1);
	t5ChkPartRExit	=	setCreate(1);
	PartListSS      =	set_create_str(20000);
	LifeCycValSet	= setCreate(2);
	//low_set_add_str_unique(LifeCycValSet,"LcsAplRlzd");
	low_set_add_str_unique(LifeCycValSet,"LcsSTDWrkg");
	low_set_add_str_unique(LifeCycValSet,"LcsSTDRlzd");
   if(dstat = GetDatabaseScope(PdmSessnClass,&dbScp,&mfail))  goto EXIT;
   for (ii=0;ii<setSize(dbScp) ; ii++)
	{
							docobjst=low_set_get(dbScp,ii);
	}
	low_set_add_str_unique(dbScp, "supprod");
	low_set_add_str_unique(dbScp, "suhprod");

	if ((nlsStrStr(TaskName,"APLJ")!=NULL) ||  (nlsStrStr(TaskName,"STDJ")!=NULL))
	{
		low_set_add_str_unique(dbScp, "sujprod");//DB Added
	}

	if( (nlsStrStr(TaskName,"STDL")!=NULL)|| (nlsStrStr(TaskName,"APLL")!=NULL))
	{
		low_set_add_str_unique(dbScp, "sulprod");//DB to be Added
	}

	if(dstat = SetDatabaseScope(PdmSessnClass,dbScp,&mfail)) goto EXIT;
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
	}

	if(!nlsIsStrNull(TaskName))
    {
	if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
	if(dstat = oiSqlWhereEQ(Sql_ptr,WbsIDAttr,TaskName)) goto EXIT;
	if(dstat = QueryDbObject("CmTaskIt",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&taskObjs,&mfail)) goto EXIT;
	if (mfail) goto CLEANUP;
	if(Sql_ptr) oiSqlDispose(Sql_ptr);Sql_ptr = NULL;
	//printf("\n taskObjs:: =%d\n",setSize(taskObjs));fflush(stdout);
	if(setSize(taskObjs)<=0)
	{
		taskObjs=NULL;
		if(Sql_ptr) oiSqlDispose(Sql_ptr); Sql_ptr = NULL;
		if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
		if(dstat = oiSqlWhereEQ(Sql_ptr,WbsIDAttr,TaskName)) goto EXIT;
		if(dstat = QueryDbObject("t5StdDml",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&taskObjs,&mfail)) goto EXIT;
		if (mfail) goto CLEANUP;
		if(Sql_ptr) oiSqlDispose(Sql_ptr);Sql_ptr = NULL;
		//printf("\n taskObjs EPA:: =%d\n",setSize(taskObjs));fflush(stdout);
	}
    if(setSize(taskObjs)>0)
	{
		taskObj = setGet(taskObjs,0);
		if(dstat=ExpandObject5(AttachClass,taskObj,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,&mfail))  goto EXIT;
		//if setSize(DataItemSO) > 0
		//if less then 0, then give output -,-,-
		//printf("\nsetSize(DataItemSO) %d", setSize(DataItemSO));fflush(stdout);
		if (setSize(DataItemSO) > 0)
		{
			for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
			{
				fullPathattr	=	NULL;
				fullPathattrDup	=	NULL;
				VisFileObjP		=	NULL;
				proprtrevObjP	=	NULL;
				NewDataItemObjP	=	setGet(DataItemSO,DataItem);
				if(dstat=objCopy(&VisFileObjP,NewDataItemObjP));
				if(dstat=GetInfoItem(VisFileObjP,&proprtrevObjP,&mfail));
				if(dstat=objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
				fullPathattrDup	=	nlsStrDup(fullPathattr);
				//printf("\nfullPathattrDup1 %s", fullPathattrDup);fflush(stdout);
				if(nlsStrStr(fullPathattrDup,"PO_REPORT"))
				{
					cnt ++;
					 if(dstat = ulyAddObjectToSet(proprtrevObjP,&noPOs)) goto CLEANUP;
				}
				//printf("\nelse setSize(noPOs) %d", setSize(noPOs));fflush(stdout);
			}
		}
		else
		{
				//printf("\nelse setSize(DataItemSO) %d", setSize(DataItemSO));fflush(stdout);
				d=setSize(t5ChkPartExit);
				aString_test3 ->__size = d;
				aString_test3 ->__ptrVcDetails = malloc( (aString_test3 ->__size + 1) * sizeof(*aString_test3 ->__ptrVcDetails) );
				
				if(!nlsIsStrNull(PartDetailsStr)) nlsStrFree(PartDetailsStr);
				PartDetailsStr	=	NULL;
				PartDetailsStr	=	nlsStrAlloc(500);
				nlsStrCpy(PartDetailsStr,"-1");
				
				//printf("\nPartDetailsStr %s", PartDetailsStr);fflush(stdout);
				aString_test3->__ptrVcDetails[0].PartDetails = malloc(20 * sizeof(char *) );
				nlsStrCpy(aString_test3->__ptrVcDetails[0].PartDetails,PartDetailsStr);
				nlsStrCpy(aString_test3->__ptrVcDetails[1].PartDetails,PartDetailsStr);
				//nlsStrCpy(aString_test3->__ptrVcDetails[0].PartDetails,"-");
				//printf("PartDetailsStr: %s", PartDetailsStr);
		}
		//if setSize(noPOs) > 0
		//if less then 0, then give output -,-,-

		if(dstat=t5SortBOMObjsByDate(&noPOs,&noPOs,&mfail));

		
		if (setSize(noPOs)>0)
		{
			// printf("\n TESTING111\n");fflush(stdout);
			n =setSize(noPOs);
			//printf("\n nnnnnnnnn %d\n",n);fflush(stdout);
			NoPoObj=setGet(noPOs,n-1);
			fullPathattrDup1 = NULL;
			fullPathattr1 = NULL;
			HostNam = NULL;
			HostNamDup = NULL;
			
			if(dstat=objGetAttribute(NoPoObj,HostNameAttr,&HostNam)) ;
			HostNamDup=nlsStrDup(HostNam);

			

			if(dstat=objGetAttribute(NoPoObj,FullPathAttr,&fullPathattr1)) ;
			fullPathattrDup1=nlsStrDup(fullPathattr1);
			//printf("\nfullPathattrDup1 : %s",fullPathattrDup1);fflush(stdout);

			

			if(nlsStrCmp(HostNamDup,"plmpuvfs"))
			{
			
			sprintf(buff,"	scp -r \"%s\":\"%s\" \"%s\"",HostNamDup,fullPathattrDup1,fullPathattrDup1);
			
			system(buff);

              
			}
			
			

			FILE *file = fopen ( fullPathattrDup1, "r" );


			if ( file != NULL )
			{
				iPOCnt=0;
				while ((read = getline(&line, &len, file)) != -1) 
				{
					
					nlsStrTrimTrailWhiteSpace(line);
					if (nlsStrCmp(line,"PO is not available in SAP for Below Parts")==0)
					{
						iPOCnt=1;
						continue;
					}
					else if(nlsStrCmp(line,"Stock is not available or less than 2 digit in SAP for Below Parts")==0)
					{			
						break;
					}
					//else if(nlsStrCmp(line,"Revision Level PO mismatch in SAP for Below Parts(Softcheck)")==0)
					else if(nlsStrCmp(line,"Revision Level PO mismatch in SAP for Below Parts")==0)
					{		
						iPOCnt=2;
						continue;
					}
					else if (nlsStrCmp(line,"MRP Controller is DMY/ZZZ/XXX/not available in SAP for Below Parts")==0)
					{
						break;
					}
					//else if (nlsStrCmp(line,"Revision Level PO mismatch in SAP for Below Parts(Softcheck)")==0)
					//{
						//break;
					//}
					else
					{
						if (iPOCnt==1)
						{
							low_set_add_str_unique(t5ChkPartExit,line);
						}
						else if (iPOCnt==2)
						{
							low_set_add_str_unique(t5ChkPartRExit,line);
						}
						
					}
				}

				

				if (setSize(uniqueListSS)==0||uniqueListSS==NULL)
				{
					uniqueListSS = setCreate(1);
				}


				if ((setSize(t5ChkPartExit) > 0) || (setSize(t5ChkPartRExit) > 0))
				{
			
				d1=setSize(t5ChkPartExit);
				d2=setSize(t5ChkPartRExit);
				d=d1+d2;

				aString_test3 ->__size = d;
				aString_test3 ->__ptrVcDetails = malloc( (aString_test3 ->__size + 1) * sizeof(*aString_test3 ->__ptrVcDetails) );
				}


//				d1=setSize(t5ChkPartExit);
//				d2=setSize(t5ChkPartRExit);
//				aString_test3 ->__size = d;
//				aString_test3 ->__ptrVcDetails = malloc( (aString_test3 ->__size + 1) * sizeof(*aString_test3 ->__ptrVcDetails) );
				if(setSize(t5ChkPartExit) > 0)
				{
				for(i=0;i<setSize(t5ChkPartExit);i++)
				{



					Temp1	    =	nlsStrAlloc(500);
					Temp1		=	setGetStr(t5ChkPartExit,i);
				
						StrTmpPrtDatStr = NULL;
						chldPrtNum		= NULL;
						chldPrtNumD		= NULL;
						chldPrtNum1		= NULL; 
						chldPrtNum3		= NULL; 
						prtNum		=  NULL;
						Rev		=  NULL;
						Seq		=  NULL;
						CS		=  NULL;
						MatS		=  NULL;
						chldPrtDesc		=  NULL;

						chldPrtNum3	    =	nlsStrAlloc(50);
						chldPrtNum1	    =	nlsStrAlloc(50);
						StrTmpPrtDatStr	=	nlsStrAlloc(1500);
						nlsStrCpy(StrTmpPrtDatStr,Temp1);
									
						prtNum		=	strtok(Temp1,"\t");
						chldPrtNum	=	strtok(NULL,"\t");
						Rev	=	strtok(NULL,"\t");
						Seq	=	strtok(NULL,"\t");
						CS	=	strtok(NULL,"\t");
						MatS	=	strtok(NULL,"\t");
						chldPrtDesc	=	strtok(NULL,"\t");

						low_strrpl(chldPrtDesc,'\n',' ');
						low_strrpl(chldPrtDesc,',',' ');
						low_strrpl(chldPrtDesc,'&',' ');
           
						nlsStrCpy(chldPrtNum3,chldPrtNum);
						
						
									
						if(nlsStrStr(chldPrtNum3,"/"))
						{
							chldPrtNum2 =strtok(chldPrtNum3,"/");
							chldPrtNum1	=	strtok(NULL,"/");
										//printf("chldPrtNum: %s", chldPrtNum1);
						}
						else
						{
							nlsStrCpy(chldPrtNum1,chldPrtNum);
						}

						chldPrtNum		= NULL;
						RevDup		= NULL;
						SeqDup		= NULL; 
						CSDup		= NULL; 
						MatSDup		=  NULL;
						chldPrtDescDup		=  NULL;

						//chldPrtNumD	=	nlsStrDup(chldPrtNum1);
						if(!nlsIsStrNull(chldPrtNum1)) chldPrtNumD =  nlsStrDup( chldPrtNum1);
						if(!nlsIsStrNull(Rev)) RevDup =  nlsStrDup( Rev);
						if(!nlsIsStrNull(Seq)) SeqDup =  nlsStrDup( Seq);
						if(!nlsIsStrNull(CS)) CSDup =  nlsStrDup( CS);
						if(!nlsIsStrNull(MatS)) MatSDup =  nlsStrDup( MatS);
						if(!nlsIsStrNull(chldPrtDesc)) chldPrtDescDup =  nlsStrDup( chldPrtDesc);
				        //printf("\n StrTmpPrtDatStr fetched 123:: =%s,%s,%s,%s,%s,%s\n",chldPrtNumD,RevDup,SeqDup,CSDup,MatSDup,chldPrtDescDup);fflush(stdout);

						
						//printf("chldPrtNum11112222222: %s", chldPrtNum);
						if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
						if(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,chldPrtNum1)) goto EXIT;
						if(dstat=(oiSqlWhereAND(Sql_ptr))) goto EXIT;
						if(dstat = oiSqlWhereEQ(Sql_ptr,LifeCycleStateAttr,"LcsSTDRlzd")) goto EXIT;
						if(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr)) goto EXIT;
						if(dstat = QueryDbObject(PartClass,Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&setParts,&mfail)) goto EXIT;
						if (mfail) goto CLEANUP;
						if(Sql_ptr) oiSqlDispose(Sql_ptr);Sql_ptr = NULL;
						//printf("\nNo of Part Found : %d",setSize(setParts));fflush(stdout);
						Homo=NULL;
						HomoDup=NULL;
						if(setSize(setParts)>0)
						{
							setPart = setGet(setParts,0);	  

							if(dstat = objGetAttribute(setPart,t5HomologationReqdAttr,&Homo)) goto EXIT;
							if(!nlsIsStrNull(Homo)) HomoDup =  nlsStrDup( Homo);

									//printf("t5HomologationReqdAttr: %s", HomoDup);


						}

						 if(!nlsIsStrNull(PartDetailsStr)) nlsStrFree(PartDetailsStr);
						PartDetailsStr=NULL;
						PartDetailsStr=nlsStrAlloc(500);

						
						//printf("\nchldPrtNum3: %s", chldPrtNumD);
						if(!nlsIsStrNull(chldPrtNumD))
						{
							
							nlsStrCpy(PartDetailsStr,chldPrtNumD);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCpy(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						//printf("\nchldRev: %s", RevDup);
						if(!nlsIsStrNull(RevDup))
						{
							nlsStrCat(PartDetailsStr,RevDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						//printf("\nchldSeq: %s", SeqDup);
						if(!nlsIsStrNull(SeqDup))
						{
							nlsStrCat(PartDetailsStr,SeqDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}

						

//						if(!nlsIsStrNull(MatSDup))
//						{
//							nlsStrCat(PartDetailsStr,MatSDup);
//							nlsStrCat(PartDetailsStr,",");
//						}
//						else
//						{
//							nlsStrCat(PartDetailsStr," ");
//							nlsStrCat(PartDetailsStr,",");
//						}

						if(!nlsIsStrNull(chldPrtDescDup))
						{
							nlsStrCat(PartDetailsStr,chldPrtDescDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr,",");
						}
								
						if(!nlsIsStrNull(HomoDup))
						{
							nlsStrCat(PartDetailsStr,HomoDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr,"N");
							nlsStrCat(PartDetailsStr,",");
						}

						if(!nlsIsStrNull(CSDup))
						{
							nlsStrCat(PartDetailsStr,CSDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}

						nlsStrCat(PartDetailsStr,"NOPO");
						nlsStrCat(PartDetailsStr,",");

                       // printf("\nPartDetailsStr: %s, I : %d", PartDetailsStr,i);

						if(!nlsIsStrNull(PartDetailsStr)) aString_test3->__ptrVcDetails[i].PartDetails = malloc(100 * sizeof(char *) );
						if(!nlsIsStrNull(PartDetailsStr)) nlsStrCpy(aString_test3->__ptrVcDetails[i].PartDetails,PartDetailsStr);

						//if(!nlsIsStrNull(PartDetailsStr)) aString_test3->__ptrVcDetails[i].PartDetails = malloc(20 * sizeof(char *) );
						//if(!nlsIsStrNull(PartDetailsStr)) nlsStrCpy(aString_test3->__ptrVcDetails[i].PartDetails,PartDetailsStr);


				
				}


	
				//if(file)
				//fclose(file);

			} 
			if (setSize(t5ChkPartRExit) > 0)
				{
				for(j=0;j<setSize(t5ChkPartRExit);j++)
				{


					revcnt=i+j;
					Temp1	    =	nlsStrAlloc(500);
					Temp1		=	setGetStr(t5ChkPartRExit,j);
				
						StrTmpPrtDatStr = NULL;
						chldPrtNum		= NULL;
						chldPrtNumD		= NULL;
						chldPrtNum1		= NULL; 
						chldPrtNum3		= NULL; 
						prtNum		=  NULL;
						Rev		=  NULL;
						Seq		=  NULL;
						CS		=  NULL;
						MatS		=  NULL;
						chldPrtDesc		=  NULL;

						chldPrtNum3	    =	nlsStrAlloc(50);
						chldPrtNum1	    =	nlsStrAlloc(50);
						StrTmpPrtDatStr	=	nlsStrAlloc(1500);
						nlsStrCpy(StrTmpPrtDatStr,Temp1);
									
						prtNum		=	strtok(Temp1,"\t");
						chldPrtNum	=	strtok(NULL,"\t");
						Rev	=	strtok(NULL,"\t");
						Seq	=	strtok(NULL,"\t");
						CS	=	strtok(NULL,"\t");
						MatS	=	strtok(NULL,"\t");
						chldPrtDesc	=	strtok(NULL,"\t");

						low_strrpl(chldPrtDesc,'\n',' ');
						low_strrpl(chldPrtDesc,',',' ');
						low_strrpl(chldPrtDesc,'&',' ');
           
						nlsStrCpy(chldPrtNum3,chldPrtNum);
						
						
									
						if(nlsStrStr(chldPrtNum3,"/"))
						{
							chldPrtNum2 =strtok(chldPrtNum3,"/");
							chldPrtNum1	=	strtok(NULL,"/");
										//printf("chldPrtNum: %s", chldPrtNum1);
						}
						else
						{
							nlsStrCpy(chldPrtNum1,chldPrtNum);
						}

						chldPrtNum		= NULL;
						RevDup		= NULL;
						SeqDup		= NULL; 
						CSDup		= NULL; 
						MatSDup		=  NULL;
						chldPrtDescDup		=  NULL;

						//chldPrtNumD	=	nlsStrDup(chldPrtNum1);
						if(!nlsIsStrNull(chldPrtNum1)) chldPrtNumD =  nlsStrDup( chldPrtNum1);
						if(!nlsIsStrNull(Rev)) RevDup =  nlsStrDup( Rev);
						if(!nlsIsStrNull(Seq)) SeqDup =  nlsStrDup( Seq);
						if(!nlsIsStrNull(CS)) CSDup =  nlsStrDup( CS);
						if(!nlsIsStrNull(MatS)) MatSDup =  nlsStrDup( MatS);
						if(!nlsIsStrNull(chldPrtDesc)) chldPrtDescDup =  nlsStrDup( chldPrtDesc);
				       // printf("\n StrTmpPrtDatStr fetched 123:: =%s,%s,%s,%s,%s,%s\n",chldPrtNumD,RevDup,SeqDup,CSDup,MatSDup,chldPrtDescDup);fflush(stdout);

						
						//printf("chldPrtNum11112222222: %s", chldPrtNum);
						if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
						if(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,chldPrtNum1)) goto EXIT;
						if(dstat=(oiSqlWhereAND(Sql_ptr))) goto EXIT;
						if(dstat = oiSqlWhereEQ(Sql_ptr,LifeCycleStateAttr,"LcsSTDRlzd")) goto EXIT;
						if(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr)) goto EXIT;
						if(dstat = QueryDbObject(PartClass,Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&setParts,&mfail)) goto EXIT;
						if (mfail) goto CLEANUP;
						if(Sql_ptr) oiSqlDispose(Sql_ptr);Sql_ptr = NULL;
						//printf("\nNo of Part Found : %d",setSize(setParts));fflush(stdout);
						Homo=NULL;
						HomoDup=NULL;
						if(setSize(setParts)>0)
						{
							setPart = setGet(setParts,0);	  

							if(dstat = objGetAttribute(setPart,t5HomologationReqdAttr,&Homo)) goto EXIT;
							if(!nlsIsStrNull(Homo)) HomoDup =  nlsStrDup( Homo);

									//printf("t5HomologationReqdAttr: %s", HomoDup);
						}

						//Vishal TZ 3.91 - Taken same part,rev,seq which is being sent in VCMS
						if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
						if(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,chldPrtNum1)) goto EXIT;
						if(dstat=(oiSqlWhereAND(Sql_ptr))) goto EXIT;
						if(dstat = oiSqlWhereEQ(Sql_ptr,RevisionAttr,Rev)) goto EXIT;
						if(dstat=(oiSqlWhereAND(Sql_ptr))) goto EXIT;
						if(dstat = oiSqlWhereEQ(Sql_ptr,SequenceAttr,Seq)) goto EXIT;
						if(dstat = QueryDbObject(PartClass,Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&setParts1,&mfail)) goto EXIT;
						if (mfail) goto CLEANUP;
						if(Sql_ptr) oiSqlDispose(Sql_ptr);Sql_ptr = NULL;
						
						CreDate=NULL;
						CreDateDup=NULL;
						setPart1=NULL;
						if(setSize(setParts1)>0)
						{
							setPart1 = setGet(setParts1,0);	
							
							if(dstat = objGetAttribute(setPart1,CreationDateAttr,&CreDate)) goto EXIT; 
							if(!nlsIsStrNull(CreDate)) CreDateDup =  nlsStrDup(CreDate);

							//printf("\nTemp ... CreDateDup: %s", CreDateDup);

							if(nlsStrLen(CreDateDup) >= 10)
							{
								YrInt	=	0;
								YrStr	=	NULL;
								YrStrDup=	NULL;

								YrStr = subString(CreDateDup, 0, 4);
								if(!nlsIsStrNull(YrStr)) YrStrDup =  nlsStrDup(YrStr);
								
								YrInt = atoi(YrStrDup);
								//printf("\nTemp ... YrInt: %d", YrInt);
							}
						}

						 if(!nlsIsStrNull(PartDetailsStr)) nlsStrFree(PartDetailsStr);
						PartDetailsStr=NULL;
						PartDetailsStr=nlsStrAlloc(500);

						
						//printf("\nchldPrtNum3: %s", chldPrtNumD);
						if(!nlsIsStrNull(chldPrtNumD))
						{
							
							nlsStrCpy(PartDetailsStr,chldPrtNumD);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCpy(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						//printf("\nchldRev: %s", RevDup);
						if(!nlsIsStrNull(RevDup))
						{
							nlsStrCat(PartDetailsStr,RevDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						//printf("\nchldSeq: %s", SeqDup);
						if(!nlsIsStrNull(SeqDup))
						{
							nlsStrCat(PartDetailsStr,SeqDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}

						

//						(!nlsIsStrNull(MatSDup))
//						{
//							nlsStrCat(PartDetailsStr,MatSDup);
//							nlsStrCat(PartDetailsStr,",");
//						}
//						else
//						{
//							nlsStrCat(PartDetailsStr," ");
//							nlsStrCat(PartDetailsStr,",");
//						}

						if(!nlsIsStrNull(chldPrtDescDup))
						{
							nlsStrCat(PartDetailsStr,chldPrtDescDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr,",");
						}
								
						if(!nlsIsStrNull(HomoDup))
						{
							nlsStrCat(PartDetailsStr,HomoDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr,",");
						}

						if(!nlsIsStrNull(CSDup))
						{
							nlsStrCat(PartDetailsStr,CSDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						
						if(YrInt>=2019)  //Vishal TZ 3.91
						{

							nlsStrCat(PartDetailsStr,"NOBYPSFORREVPO");
						}
						else
						{
							nlsStrCat(PartDetailsStr,"REVPOMISMATCH");
						}
						nlsStrCat(PartDetailsStr,",");

                       // printf("\nPartDetailsStr: %s, I : %d", PartDetailsStr,i);

						if(!nlsIsStrNull(PartDetailsStr)) aString_test3->__ptrVcDetails[revcnt].PartDetails = malloc(100 * sizeof(char *) );
						if(!nlsIsStrNull(PartDetailsStr)) nlsStrCpy(aString_test3->__ptrVcDetails[revcnt].PartDetails,PartDetailsStr);

						//if(!nlsIsStrNull(PartDetailsStr)) aString_test3->__ptrVcDetails[i].PartDetails = malloc(20 * sizeof(char *) );
						//if(!nlsIsStrNull(PartDetailsStr)) nlsStrCpy(aString_test3->__ptrVcDetails[i].PartDetails,PartDetailsStr);


				
				}


	
				if(file)
				fclose(file);

			
			}
			
			}
		}
	}
	else if(nlsStrStr(TaskName,"APLC")!=NULL || nlsStrStr(TaskName,"STDC")!=NULL || nlsStrStr(TaskName,"APLA")!=NULL || nlsStrStr(TaskName,"STDA")!=NULL)
	{
//			FILE	*TskToDmlUA;
//			FILE	*fp1;
//
//			string		    FileNameDup			=	NULL;
//			string			TodayDate			=	NULL;
//			
//			FileNameDup		=	nlsStrAlloc(500);
//
//			TodayDate=sysGetCTime();
//			low_strrpl(TodayDate,' ','_');
//			low_strrpl(TodayDate,':','_');
//
//			nlsStrCpy(FileNameDup,"/plmuv_logs/omfprod/logs/");
//			nlsStrCat(FileNameDup,"NOPO_");
//			nlsStrCat(FileNameDup,TodayDate);
//			nlsStrCat(FileNameDup,".log");
//
//			TskToDmlUA = fopen(FileNameDup , "a+") ;
//			if(FileNameDup==NULL)
//			{
//				goto EXIT;
//			}
			
//			fprintf(TskToDmlUA,"\n******** TCUA WEB SERVICE CALLED FOR BOM PART CHECK***********");
//			fprintf(TskToDmlUA,"\n TASK NUMBER	:	[%s]\n",TaskName);

			fprintf(TskToDmlUA,"\n Task not found in TCE, check in TCUA UA");

			StrFullPathShell = nlsStrAlloc(200);//"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass"
			nlsStrCpy(StrFullPathShell,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/NoPoTaskEpa.sh");
			
			txtargv[0] = StrFullPathShell;
			txtargv[1] = TaskName;
			txtargv[2] = NULL;

			for (cnt = 0;cnt < 1; cnt++ )
			{
				fprintf(TskToDmlUA,"txtargv[%d] : [%s]\n", cnt, txtargv[cnt]); fflush(TskToDmlUA);
			}

			fprintf(TskToDmlUA,"\nStrFullPathShell : [%s]\n", StrFullPathShell); fflush(TskToDmlUA);

			SysReturn = sysExecute(StrFullPathShell, txtargv);
			if(SysReturn == 0)
			{
				fprintf(TskToDmlUA,"\n Execution Done Successfully ...\n");  fflush(TskToDmlUA);
			}
			else
			{
				fprintf(TskToDmlUA,"\n Execution Done Fail, Pl check Env variable and calling shell..\n");  fflush(TskToDmlUA);
			}

			sysdate		=	sysGetDate();
			low_strrpl(sysdate,'-','_');
			//low_strrpl(sysdate,' ','_');
			fprintf(TskToDmlUA,"\n sysdate : %s\n",sysdate);  fflush(TskToDmlUA);

			inputfile	=	nlsStrAlloc(nlsStrLen("/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/")+100);
			nlsStrCpy(inputfile,"");
			nlsStrCat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass");
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,sysdate);
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,TaskName);
			nlsStrCat(inputfile,"_NOPO");
			nlsStrCat(inputfile,".txt");
			fprintf(TskToDmlUA,"\nFilename : %s\n",inputfile);fflush(TskToDmlUA);

			fp1=fopen(inputfile,"r");
			if(fp1!=NULL)
			{
				char	*line	= NULL;
				size_t	len		= 0;
				ssize_t read;
				int		iFln	=	0;
				string			getLinef		=	NULL;

				while ((read = getline(&line, &len, fp1)) != -1) 
				{
				   // printf("Retrieved line of length %zu :\n", read);
					fprintf(TskToDmlUA,"%s\n", line);fflush(TskToDmlUA);
					low_set_add_str_unique(attchdDmlSet1,line);
				}
				iPOCnt	=	0;
				for (iFln=0;iFln<setSize(attchdDmlSet1) ;iFln++ )
				{
					getLinef	=	NULL;
					getLinef	=	setGet(attchdDmlSet1,iFln);
					nlsStrTrimTrailWhiteSpace(getLinef);
					fprintf(TskToDmlUA,"%s", getLinef);fflush(TskToDmlUA);
					if (nlsStrCmp(getLinef,"PO is not available in SAP for Below Parts")==0)
					{
						iPOCnt=1;
						continue;
					}
					else if(nlsStrCmp(getLinef,"Stock is not available or less than 2 digit in SAP for Below Parts")==0)
					{			
						break;
					}
					//else if(nlsStrCmp(line,"Revision Level PO mismatch in SAP for Below Parts(Softcheck)")==0)
					else if(nlsStrCmp(getLinef,"Revision Level PO mismatch in SAP for Below Parts")==0)
					{		
						iPOCnt=2;
						continue;
					}
					else if (nlsStrCmp(getLinef,"MRP Controller is DMY/ZZZ/XXX/not available in SAP for Below Parts")==0)
					{
						break;
					}
					//else if (nlsStrCmp(line,"Revision Level PO mismatch in SAP for Below Parts(Softcheck)")==0)
					//{
					//break;
					//}
					else
					{
						if (iPOCnt==1)
						{
							low_set_add_str_unique(t5ChkPartExit,getLinef);
						}
						else if (iPOCnt==2)
						{
							low_set_add_str_unique(t5ChkPartRExit,getLinef);
						}

					}
				}

				if ((setSize(t5ChkPartExit) > 0) || (setSize(t5ChkPartRExit) > 0))
				{

					d1=setSize(t5ChkPartExit);
					d2=setSize(t5ChkPartRExit);
					d=d1+d2;

					aString_test3 ->__size = d;
					aString_test3 ->__ptrVcDetails = malloc( (aString_test3 ->__size + 1) * sizeof(*aString_test3 ->__ptrVcDetails) );
				}

				if(setSize(t5ChkPartExit) > 0)
				{
					for(i=0;i<setSize(t5ChkPartExit);i++)
					{
						Temp1	    =	nlsStrAlloc(500);
						Temp1		=	setGetStr(t5ChkPartExit,i);

						StrTmpPrtDatStr = NULL;
						chldPrtNum		= NULL;
						chldPrtNumD		= NULL;
						chldPrtNum1		= NULL; 
						chldPrtNum3		= NULL; 
						prtNum		=  NULL;
						Rev		=  NULL;
						Seq		=  NULL;
						CS		=  NULL;
						MatS		=  NULL;
						chldPrtDesc		=  NULL;

						chldPrtNum3	    =	nlsStrAlloc(50);
						chldPrtNum1	    =	nlsStrAlloc(50);
						StrTmpPrtDatStr	=	nlsStrAlloc(1500);
						nlsStrCpy(StrTmpPrtDatStr,Temp1);
								
						prtNum		=	strtok(Temp1,"\t");
						chldPrtNum	=	strtok(NULL,"\t");
						Rev	=	strtok(NULL,"\t");
						Seq	=	strtok(NULL,"\t");
						CS	=	strtok(NULL,"\t");
						MatS	=	strtok(NULL,"\t");
						chldPrtDesc	=	strtok(NULL,"\t");
						Homo	=	strtok(NULL,"\t");

						low_strrpl(chldPrtDesc,'\n',' ');
						low_strrpl(chldPrtDesc,',',' ');
						low_strrpl(chldPrtDesc,'&',' ');

						nlsStrCpy(chldPrtNum3,chldPrtNum);
								
						if(nlsStrStr(chldPrtNum3,"/"))
						{
							chldPrtNum2 =strtok(chldPrtNum3,"/");
							chldPrtNum1	=	strtok(NULL,"/");
							//printf("chldPrtNum: %s", chldPrtNum1);
						}
						else
						{
							nlsStrCpy(chldPrtNum1,chldPrtNum);
						}

						chldPrtNum		= NULL;
						RevDup		= NULL;
						SeqDup		= NULL; 
						CSDup		= NULL; 
						MatSDup		=  NULL;
						chldPrtDescDup		=  NULL;

						//chldPrtNumD	=	nlsStrDup(chldPrtNum1);
						if(!nlsIsStrNull(chldPrtNum1)) chldPrtNumD =  nlsStrDup( chldPrtNum1);
						if(!nlsIsStrNull(Rev)) RevDup =  nlsStrDup( Rev);
						if(!nlsIsStrNull(Seq)) SeqDup =  nlsStrDup( Seq);
						if(!nlsIsStrNull(CS)) CSDup =  nlsStrDup( CS);
						if(!nlsIsStrNull(MatS)) MatSDup =  nlsStrDup( MatS);
						if(!nlsIsStrNull(chldPrtDesc)) chldPrtDescDup =  nlsStrDup( chldPrtDesc);
						if(!nlsIsStrNull(Homo)) HomoDup =  nlsStrDup( Homo);
						fprintf(TskToDmlUA,"\n StrTmpPrtDatStr fetched 123:: =%s,%s,%s,%s,%s,%s\n",chldPrtNumD,RevDup,SeqDup,CSDup,MatSDup,chldPrtDescDup);fflush(TskToDmlUA);
						if(!nlsIsStrNull(PartDetailsStr)) nlsStrFree(PartDetailsStr);
						PartDetailsStr=NULL;
						PartDetailsStr=nlsStrAlloc(500);


						//printf("\nchldPrtNum3: %s", chldPrtNumD);
						if(!nlsIsStrNull(chldPrtNumD))
						{

							nlsStrCpy(PartDetailsStr,chldPrtNumD);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCpy(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						//printf("\nchldRev: %s", RevDup);
						if(!nlsIsStrNull(RevDup))
						{
							nlsStrCat(PartDetailsStr,RevDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						//printf("\nchldSeq: %s", SeqDup);
						if(!nlsIsStrNull(SeqDup))
						{
							nlsStrCat(PartDetailsStr,SeqDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}

						if(!nlsIsStrNull(chldPrtDescDup))
						{
							nlsStrCat(PartDetailsStr,chldPrtDescDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr,",");
						}
							
						if(!nlsIsStrNull(HomoDup))
						{
							nlsStrCat(PartDetailsStr,HomoDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr,"N");
							nlsStrCat(PartDetailsStr,",");
						}

						if(!nlsIsStrNull(CSDup))
						{
							nlsStrCat(PartDetailsStr,CSDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}

							nlsStrCat(PartDetailsStr,"NOPO");
							nlsStrCat(PartDetailsStr,",");

						// printf("\nPartDetailsStr: %s, I : %d", PartDetailsStr,i);
						if(!nlsIsStrNull(PartDetailsStr)) aString_test3->__ptrVcDetails[i].PartDetails = malloc(100 * sizeof(char *) );
						if(!nlsIsStrNull(PartDetailsStr)) nlsStrCpy(aString_test3->__ptrVcDetails[i].PartDetails,PartDetailsStr);

						//if(!nlsIsStrNull(PartDetailsStr)) aString_test3->__ptrVcDetails[i].PartDetails = malloc(20 * sizeof(char *) );
						//if(!nlsIsStrNull(PartDetailsStr)) nlsStrCpy(aString_test3->__ptrVcDetails[i].PartDetails,PartDetailsStr);

					}

					//if(file)
					//fclose(file);

				} 

			}
			else
			{
				d=setSize(t5ChkPartExit);
				aString_test3 ->__size = d;
				aString_test3 ->__ptrVcDetails = malloc( (aString_test3 ->__size + 1) * sizeof(*aString_test3 ->__ptrVcDetails) );

				if(!nlsIsStrNull(PartDetailsStr)) nlsStrFree(PartDetailsStr);
				PartDetailsStr	=	NULL;
				PartDetailsStr	=	nlsStrAlloc(500);
				nlsStrCpy(PartDetailsStr,"-1");

				//printf("\nPartDetailsStr %s", PartDetailsStr);fflush(stdout);
				aString_test3->__ptrVcDetails[0].PartDetails = malloc(20 * sizeof(char *) );
				nlsStrCpy(aString_test3->__ptrVcDetails[0].PartDetails,PartDetailsStr);
				nlsStrCpy(aString_test3->__ptrVcDetails[1].PartDetails,PartDetailsStr);
			}
		}
		else
		{
			fprintf(TskToDmlUA,"\n Task not found in TCE, check in TCUA CV");

			StrFullPathShell = nlsStrAlloc(200);//"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass"
			nlsStrCpy(StrFullPathShell,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/NoPoTaskEpa_CV.sh");
			
			txtargv[0] = StrFullPathShell;
			txtargv[1] = TaskName;
			txtargv[2] = NULL;

			for (cnt = 0;cnt < 1; cnt++ )
			{
				fprintf(TskToDmlUA,"txtargv[%d] : [%s]\n", cnt, txtargv[cnt]); fflush(TskToDmlUA);
			}

			fprintf(TskToDmlUA,"\nStrFullPathShell : [%s]\n", StrFullPathShell); fflush(TskToDmlUA);

			SysReturn = sysExecute(StrFullPathShell, txtargv);
			if(SysReturn == 0)
			{
				fprintf(TskToDmlUA,"\n Execution Done Successfully ...\n");  fflush(TskToDmlUA);
			}
			else
			{
				fprintf(TskToDmlUA,"\n Execution Done Fail, Pl check Env variable and calling shell..\n");  fflush(TskToDmlUA);
			}

			sysdate		=	sysGetDate();
			low_strrpl(sysdate,'-','_');
			//low_strrpl(sysdate,' ','_');
			fprintf(TskToDmlUA,"\n sysdate : %s\n",sysdate);  fflush(TskToDmlUA);

			inputfile	=	nlsStrAlloc(nlsStrLen("/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/")+100);
			nlsStrCpy(inputfile,"");
			nlsStrCat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass");
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,sysdate);
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,TaskName);
			nlsStrCat(inputfile,"_NOPO");
			nlsStrCat(inputfile,".txt");
			fprintf(TskToDmlUA,"\nFilename : %s\n",inputfile);fflush(TskToDmlUA);

			fp1=fopen(inputfile,"r");
			if(fp1!=NULL)
			{
				char	*line	= NULL;
				size_t	len		= 0;
				ssize_t read;
				int		iFln	=	0;
				string			getLinef		=	NULL;

				while ((read = getline(&line, &len, fp1)) != -1) 
				{
				   // printf("Retrieved line of length %zu :\n", read);
					fprintf(TskToDmlUA,"%s\n", line);fflush(TskToDmlUA);
					low_set_add_str_unique(attchdDmlSet1,line);
				}
				iPOCnt	=	0;
				for (iFln=0;iFln<setSize(attchdDmlSet1) ;iFln++ )
				{
					getLinef	=	NULL;
					getLinef	=	setGet(attchdDmlSet1,iFln);
					nlsStrTrimTrailWhiteSpace(getLinef);
					fprintf(TskToDmlUA,"%s", getLinef);fflush(TskToDmlUA);
					if (nlsStrCmp(getLinef,"PO is not available in SAP for Below Parts")==0)
					{
						iPOCnt=1;
						continue;
					}
					else if(nlsStrCmp(getLinef,"Stock is not available or less than 2 digit in SAP for Below Parts")==0)
					{			
						break;
					}
					//else if(nlsStrCmp(line,"Revision Level PO mismatch in SAP for Below Parts(Softcheck)")==0)
					else if(nlsStrCmp(getLinef,"Revision Level PO mismatch in SAP for Below Parts")==0)
					{		
						iPOCnt=2;
						continue;
					}
					else if (nlsStrCmp(getLinef,"MRP Controller is DMY/ZZZ/XXX/not available in SAP for Below Parts")==0)
					{
						break;
					}
					//else if (nlsStrCmp(line,"Revision Level PO mismatch in SAP for Below Parts(Softcheck)")==0)
					//{
					//break;
					//}
					else
					{
						if (iPOCnt==1)
						{
							low_set_add_str_unique(t5ChkPartExit,getLinef);
						}
						else if (iPOCnt==2)
						{
							low_set_add_str_unique(t5ChkPartRExit,getLinef);
						}

					}
				}

				if ((setSize(t5ChkPartExit) > 0) || (setSize(t5ChkPartRExit) > 0))
				{

					d1=setSize(t5ChkPartExit);
					d2=setSize(t5ChkPartRExit);
					d=d1+d2;

					aString_test3 ->__size = d;
					aString_test3 ->__ptrVcDetails = malloc( (aString_test3 ->__size + 1) * sizeof(*aString_test3 ->__ptrVcDetails) );
				}

				if(setSize(t5ChkPartExit) > 0)
				{
					for(i=0;i<setSize(t5ChkPartExit);i++)
					{
						Temp1	    =	nlsStrAlloc(500);
						Temp1		=	setGetStr(t5ChkPartExit,i);

						StrTmpPrtDatStr = NULL;
						chldPrtNum		= NULL;
						chldPrtNumD		= NULL;
						chldPrtNum1		= NULL; 
						chldPrtNum3		= NULL; 
						prtNum		=  NULL;
						Rev		=  NULL;
						Seq		=  NULL;
						CS		=  NULL;
						MatS		=  NULL;
						chldPrtDesc		=  NULL;

						chldPrtNum3	    =	nlsStrAlloc(50);
						chldPrtNum1	    =	nlsStrAlloc(50);
						StrTmpPrtDatStr	=	nlsStrAlloc(1500);
						nlsStrCpy(StrTmpPrtDatStr,Temp1);
								
						prtNum		=	strtok(Temp1,"\t");
						chldPrtNum	=	strtok(NULL,"\t");
						Rev	=	strtok(NULL,"\t");
						Seq	=	strtok(NULL,"\t");
						CS	=	strtok(NULL,"\t");
						MatS	=	strtok(NULL,"\t");
						chldPrtDesc	=	strtok(NULL,"\t");
						Homo	=	strtok(NULL,"\t");

						low_strrpl(chldPrtDesc,'\n',' ');
						low_strrpl(chldPrtDesc,',',' ');
						low_strrpl(chldPrtDesc,'&',' ');

						nlsStrCpy(chldPrtNum3,chldPrtNum);
								
						if(nlsStrStr(chldPrtNum3,"/"))
						{
							chldPrtNum2 =strtok(chldPrtNum3,"/");
							chldPrtNum1	=	strtok(NULL,"/");
							//printf("chldPrtNum: %s", chldPrtNum1);
						}
						else
						{
							nlsStrCpy(chldPrtNum1,chldPrtNum);
						}

						chldPrtNum		= NULL;
						RevDup		= NULL;
						SeqDup		= NULL; 
						CSDup		= NULL; 
						MatSDup		=  NULL;
						chldPrtDescDup		=  NULL;

						//chldPrtNumD	=	nlsStrDup(chldPrtNum1);
						if(!nlsIsStrNull(chldPrtNum1)) chldPrtNumD =  nlsStrDup( chldPrtNum1);
						if(!nlsIsStrNull(Rev)) RevDup =  nlsStrDup( Rev);
						if(!nlsIsStrNull(Seq)) SeqDup =  nlsStrDup( Seq);
						if(!nlsIsStrNull(CS)) CSDup =  nlsStrDup( CS);
						if(!nlsIsStrNull(MatS)) MatSDup =  nlsStrDup( MatS);
						if(!nlsIsStrNull(chldPrtDesc)) chldPrtDescDup =  nlsStrDup( chldPrtDesc);
						if(!nlsIsStrNull(Homo)) HomoDup =  nlsStrDup( Homo);
						fprintf(TskToDmlUA,"\n StrTmpPrtDatStr fetched 123:: =%s,%s,%s,%s,%s,%s\n",chldPrtNumD,RevDup,SeqDup,CSDup,MatSDup,chldPrtDescDup);fflush(TskToDmlUA);
						if(!nlsIsStrNull(PartDetailsStr)) nlsStrFree(PartDetailsStr);
						PartDetailsStr=NULL;
						PartDetailsStr=nlsStrAlloc(500);


						//printf("\nchldPrtNum3: %s", chldPrtNumD);
						if(!nlsIsStrNull(chldPrtNumD))
						{

							nlsStrCpy(PartDetailsStr,chldPrtNumD);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCpy(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						//printf("\nchldRev: %s", RevDup);
						if(!nlsIsStrNull(RevDup))
						{
							nlsStrCat(PartDetailsStr,RevDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}
						//printf("\nchldSeq: %s", SeqDup);
						if(!nlsIsStrNull(SeqDup))
						{
							nlsStrCat(PartDetailsStr,SeqDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}

						if(!nlsIsStrNull(chldPrtDescDup))
						{
							nlsStrCat(PartDetailsStr,chldPrtDescDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr,",");
						}
							
						if(!nlsIsStrNull(HomoDup))
						{
							nlsStrCat(PartDetailsStr,HomoDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr,"N");
							nlsStrCat(PartDetailsStr,",");
						}

						if(!nlsIsStrNull(CSDup))
						{
							nlsStrCat(PartDetailsStr,CSDup);
							nlsStrCat(PartDetailsStr,",");
						}
						else
						{
							nlsStrCat(PartDetailsStr," ");
							nlsStrCat(PartDetailsStr,",");
						}

							nlsStrCat(PartDetailsStr,"NOPO");
							nlsStrCat(PartDetailsStr,",");

						// printf("\nPartDetailsStr: %s, I : %d", PartDetailsStr,i);
						if(!nlsIsStrNull(PartDetailsStr)) aString_test3->__ptrVcDetails[i].PartDetails = malloc(100 * sizeof(char *) );
						if(!nlsIsStrNull(PartDetailsStr)) nlsStrCpy(aString_test3->__ptrVcDetails[i].PartDetails,PartDetailsStr);

						//if(!nlsIsStrNull(PartDetailsStr)) aString_test3->__ptrVcDetails[i].PartDetails = malloc(20 * sizeof(char *) );
						//if(!nlsIsStrNull(PartDetailsStr)) nlsStrCpy(aString_test3->__ptrVcDetails[i].PartDetails,PartDetailsStr);

					}

					//if(file)
					//fclose(file);

				} 

			}
			else
			{
				d=setSize(t5ChkPartExit);
				aString_test3 ->__size = d;
				aString_test3 ->__ptrVcDetails = malloc( (aString_test3 ->__size + 1) * sizeof(*aString_test3 ->__ptrVcDetails) );

				if(!nlsIsStrNull(PartDetailsStr)) nlsStrFree(PartDetailsStr);
				PartDetailsStr	=	NULL;
				PartDetailsStr	=	nlsStrAlloc(500);
				nlsStrCpy(PartDetailsStr,"-1");

				//printf("\nPartDetailsStr %s", PartDetailsStr);fflush(stdout);
				aString_test3->__ptrVcDetails[0].PartDetails = malloc(20 * sizeof(char *) );
				nlsStrCpy(aString_test3->__ptrVcDetails[0].PartDetails,PartDetailsStr);
				nlsStrCpy(aString_test3->__ptrVcDetails[1].PartDetails,PartDetailsStr);
			}
        
		}
}
    

	

	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

return SOAP_OK;

 CLEANUP :
	 fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
		return SOAP_OK;
EXIT:
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
return SOAP_OK;
}


