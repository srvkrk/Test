/*********************************************************************
 *
 * FILE
 * childparts.c
 * Author: Priti Jadhav
 * DESCRIPTION
 * Web Service to send group child parts list from PLM to Mint
 *********************************************************************/
#define _CLMAIN_DEFNS
#include <cfg.h>
#include <cl.h>
#include <ft.h>
#include <malloc.h>
#include <meta.h>
#include <mserv.h>
#include <msg.h>
#include <msgapc.h>
#include <msglcm.h>
#include <msgomf.h>
#include <msgtel.h>
#include <Mtimsg.h>
#include <Mtimsgh.h>
#include <mutproto.h>
#include <nls.h>
#include <pdmc.h>
#include <pdmitem.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <sc.h>
#include <serv.h>
#include <status.h>
#include <stdlib.h>
#include <string.h>
#include <sys.h>
#include <tel.h>
#include <ui.h>
#include <usc.h>
#include <oi.h>
#include <stdio.h>
#include <ZZ_sqlerr.h>
#include <AZ_ato.h>
//#include <msgomfU.h>
#include <smmth.h>
#include <oidero.h>

#include "soapH.h"
#include "GroupChildRelUA.nsmap"

int intExclZeroQty=0;
int intFrznVewChk=0;
string strView=NULL;

char* subString_1
(
  char* mainStringf ,
  int fromCharf     ,
  int toCharf
)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

SetOfObjects getColorSchemePartObjAct_1(string clrscm)
{
	MODNAME ("getColorSchemePartObjAct_1");
	status	dstat = OKAY ;
	int  mfail;
	SetOfObjects sColScheme	= NULL;
	/*ObjectPtr ColScmObj = NULL;*/
	SqlPtr sqlPtr = NULL ;

	if(sqlPtr)
		oiSqlDispose(sqlPtr);

	t5CheckDstat(oiSqlCreateSelect(&sqlPtr)) ;
	t5CheckDstat(oiSqlWhereEQ(sqlPtr, "Nomenclature",clrscm));
	t5CheckDstat(oiSqlWhereAND(sqlPtr));
	t5CheckDstat(oiSqlWhereEQ(sqlPtr,"Superseded","-"));
	t5CheckDstat(oiSqlWhereAND(sqlPtr));
	t5CheckDstat(oiSqlWhereLike(sqlPtr, "OwnerName","%Release Vault"));
	t5CheckDstat(QueryWhere("t5ClSchm",sqlPtr,&sColScheme,&mfail));
	//ColScmObj = setGet(sColScheme,0);

/*CLEANUP:*/
EXIT:
	return sColScheme;
}

status t5GenPrevRevForColPrtA(ObjectPtr *colourPart,boolean *isColLcsMch,SetOfStrings *LcsSet,string viewName,string IsBomExWView,integer *mfail)
{
	status		dstat			= OKAY;

	ObjectPtr	opprvOffRev		= NULL;
	ObjectPtr	getInfoDialog		= NULL;
	string		revision		= NULL;
	string		ColLcsSt		= NULL;
	string		ColLcsStDup		= NULL;
	string		LcsVal			= NULL;
	string		LcsValDup		= NULL;
	string		FroView			= NULL;
	SetOfStrings	FrozList		= NULL;

	int lcsCt,t=0;

	char* mod_name="t5GenPrevRevForColPrtA";
	FrozList     = setCreate(6);
	//printf("\n Inside GetPrevOfficialRev Function Call \n");fflush(stdout);

	t5CheckMfail(GetPrevOfficialRev(*colourPart,&opprvOffRev,mfail));
	if(opprvOffRev)
	{
		//printf("\n Inside Previous Officail revision found \n");fflush(stdout);

		if (ColLcsSt) ColLcsSt=NULL;
		if (dstat = objGetAttribute(opprvOffRev,LifeCycleStateAttr,&ColLcsSt)) goto EXIT;
		if(!nlsIsStrNull(ColLcsSt)) ColLcsStDup = nlsStrDup(ColLcsSt);
		//printf("\n ColLcsStDup: %s \n",ColLcsStDup);fflush(stdout);


		for(lcsCt=0;lcsCt<setSize(*LcsSet);lcsCt++)
		{
			LcsVal=low_set_get_str(*LcsSet,lcsCt);
			if(!nlsIsStrNull(LcsVal)) LcsValDup = nlsStrDup(LcsVal);

			//printf("\n LcsValDup: %s \n",LcsValDup);fflush(stdout);
			if(nlsStrCmp(LcsValDup,ColLcsStDup)==0)
			{
				//printf("\n Match:::::LcsValDup: %s %s \n",LcsValDup,ColLcsStDup);fflush(stdout);

				if(nlsStrCmp(IsBomExWView,"+")==0)
				{
				//printf("\n Indise BOM Exp with view \n");fflush(stdout);
				t5CheckMfail(GetInfoItem(opprvOffRev,&getInfoDialog,mfail));

				if(dstat = objListGetList(getInfoDialog,FrozenViewListAttr,&FrozList)) goto EXIT;
				if(setSize(FrozList)>0)
				{
					for(t=0; t< setSize(FrozList);t++)
					{
						FroView=low_set_get_str(FrozList,t);
						if(nlsStrCmp(FroView,viewName)==0)
						{
						*isColLcsMch=TRUE;
						*colourPart=opprvOffRev;
						break;
						}
					}
				}
				}
				else
				{

				*isColLcsMch=TRUE;
				*colourPart=opprvOffRev;
				break;
				}
			}
		}


		t5CheckDstat(objGetAttribute(opprvOffRev,RevisionAttr,&revision));
		//printf("\n revision is :%s \n",revision);fflush(stdout);
		if((*isColLcsMch==FALSE) && (nlsStrStr(revision,"NR")==NULL))
		{
			//printf("\n Inside Part not Assign to any view \n");fflush(stdout);
			*colourPart=opprvOffRev;
			t5CheckMfail(t5GenPrevRevForColPrtA(colourPart,isColLcsMch,LcsSet,viewName,IsBomExWView,mfail));

		}
	}
	//printf("\n Return Object in EXIT Of t5GenPrevRevForColPrt** \n");fflush(stdout);
	//objDump(*colourPart);

	CLEANUP :

	//printf("\n Inside Gentpl CLEANUP t5GenPrevRevForColPrt \n");fflush(stdout);
	t5PrintCleanUpModName;

	EXIT :
	t5CheckDstatAndReturn;
}

status t5ActShowUsesCLPartMsgA(FILE *checkIndLogFile1,ObjectPtr ColourPart,ObjectPtr genContextObj,SetOfObjects *SetOfChildObj,SetOfObjects *SetOfChildRelObj,integer* mfail)
{
	//char* subString(char*,int,int);
	status			dstat		= OKAY;
   	char			*mod_name 	= "t5ActShowUsesCLPartMsgA";
	string			projectcode			= NULL;
	string			VehClass			= NULL;
	string			PartCatCode			= NULL;
	string			ColSrl				= NULL;
	string			assyCompCode		= NULL;
	string			assyColSrl			= NULL;
	string			subColSrl			= NULL;
	string			colourID			= NULL;
	string			colourIDDup			= NULL;
	string			comCode				= NULL;
	string			comCodeDup			= NULL;
	string			vcCS				= NULL;
	string			vcCSDup				= NULL;
	string			SchemeName			= NULL;
	string			Inputpart			= NULL;
	string			AssyPartNo			= NULL;
	string			SchmPrtNo			= NULL;
	string			SchRev				= NULL;
	string			SchSeq				= NULL;
	string			SchemeDesc			= NULL;
	string			SchName				= NULL;
	string			ColorSrl			= NULL;
	string			IntSchmInd			= NULL;
	string			IntSchmIndDup		= NULL;
	string			Iscoated			= NULL;
	string			IscoatedDup			= NULL;
	string			colourInd			= NULL;
	string			colourIndDup		= NULL;
	string			CoatedType			= NULL;
	string			CoatedTypeDup		= NULL;
	string			IscoatedSchm		= NULL;
	string			IscoatedSchmDup		= NULL;
	string			ccolourInd			= NULL;
	string			ccolourIndDup		= NULL;
	string			PartType			= NULL;
	string			PartTypeDup			= NULL;
	string			Coated				= NULL;
	SetOfObjects	ProjectSet			= NULL;
	SetOfObjects	soSchmObj			= NULL;
	SetOfObjects	ColSchmSet			= NULL;
	SetOfObjects	nonColourParts		= NULL;
	SetOfObjects	t5ItmRevs			= NULL;
	SetOfObjects	t5ItmRevRels		= NULL;
	SetOfObjects	childObjSO			= NULL;
	SetOfObjects	childRelObjSO		= NULL;
	SetOfObjects	t5ItmMstr			= NULL;
	SetOfObjects	t5ItmMstrRel		= NULL;
	SetOfObjects	colourParts			= NULL;
	SetOfObjects	LatPartObjs			= NULL;
	SetOfObjects	soClMas				= NULL;
	SET_PTR			ColourPartSet		= NULL;
	SET_PTR			ColourPartSet1		= NULL;
	SET_PTR			ColourRelPartSet	= NULL;
	SET_PTR			ColourRelPartSet1	= NULL;
	SetOfStrings	ssCs				= NULL;
	ObjectPtr		nonColourPart		= NULL;
	ObjectPtr		genContextObjTmp	= NULL;
	ObjectPtr		CtxtObjTmp			= NULL;
	ObjectPtr		t5ItmRev			= NULL;
	ObjectPtr		childObj			= NULL;
	ObjectPtr		childRelObj			= NULL;
	ObjectPtr		itemRevObj			= NULL;
	ObjectPtr		colourPart			= NULL;
	ObjectPtr		ClMasObj			= NULL;
	ObjectPtr		SchmObj				= NULL;
	ObjectPtr		tmpSchmObj			= NULL;
	ObjectPtr		LatPartObj			= NULL;
	string			VehClassDup			= NULL;
	string			ColourInd			= NULL;
	string			Colid				= NULL;
	string			VColourInd			= NULL;
	string			EffectiveDate		= NULL;
	string			SchemeRev			= NULL;
	string			SchemeSeq			= NULL;
	string			tmpVehClass			= NULL;
	string			Veh_value			= NULL;
	string			VehTypeList			= NULL;
	NVSET			textInserts			= NULL;
	SetOfStrings	distinctVehClass	= NULL;
	SqlPtr			a_sql				= NULL;
	SqlPtr			Sql					= NULL;
	SqlPtr			sql1				= NULL;
	boolean			AssyHasFlag			= FALSE;
	boolean			ans					= FALSE;
	string			partType			= NULL;

	string			VCObid				= NULL;
	string			LeftSchm			= NULL;
	string			SchmName			= NULL;
	SqlPtr			sql					= NULL;
	SqlPtr			Sql_ptr				= NULL;
	SetOfObjects	SchmRelSet			= NULL;
	ObjectPtr		SchmRelObj			= NULL;
	ObjectPtr		SchmObjE			= NULL;
	SetOfObjects	TasksOfCLParts		= NULL;
	SetOfObjects	tmpColSchmSet		= NULL;
	SetOfObjects	soControls			= NULL;
	SetOfObjects	coatedParts			= NULL;
	SetOfObjects	coatedPartsRel		= NULL;
	SetOfObjects	CoatedPartObjs		= NULL;
	SetOfObjects	soExpObj			= NULL;
	SetOfObjects	relObjSet			= NULL;
	SetOfObjects	soCntrlObj			= NULL;
	SetOfObjects	child98ObjSO		= NULL;
	SetOfObjects	child98RelObjSO		= NULL;
	SetOfObjects  	ControlSet			= NULL;
	SetOfObjects  	MasterOrgSet		= NULL;
	SetOfObjects  	HasControlSet		= NULL;
	SetOfStrings	uniqueClrScm		= NULL;
	SetOfObjects	setColScheme		= NULL;
	ObjectPtr		MasterOrgObj		= NULL;
	ObjectPtr		HasControlObj		= NULL;
	SetOfStrings	SetOfVC				= NULL;
	SetOfObjects	AssyHasDmlSet       = NULL;
	SetOfObjects	AssyHasDmlRelSet	= NULL;
	ObjectPtr		TaskObj				= NULL;
	ObjectPtr		child98Obj			= NULL;
	ObjectPtr		child98RelObj		= NULL;
	string			TaskNo				= NULL;
	string			TaskNoDup			= NULL;
	string			tmpTaskNo			= NULL;
	string			scheme1				= NULL;
	string			scheme2				= NULL;
	string			scheme3				= NULL;
	string			scheme4				= NULL;
	string			scheme5				= NULL;
	string			IscoatedPartNo		= NULL;
	string			viewName			= NULL;
	string			AssyOrgId			= NULL;
	string			NcPartNumber		= NULL;
	string			NcPartNumberDup		= NULL;
	string			ColourSchDup		= NULL;
	string			ColourSch			= NULL;
	string			DisplayDescDup		= NULL;
	string			DisplayDesc			= NULL;
	string			clrscm				= NULL;
	string          ttRev				= NULL;
	string          ttSeq				= NULL;
	string          LcsVal				= NULL;
	string          LcsSel				= NULL;
	string          ColLcsSt			= NULL;
	string          ColLcsStDup			= NULL;
	string          revision			= NULL;
	string          revisionDup			= NULL;
	string          LcsValDup			= NULL;
	string          SupVal				= NULL;
	string          IsAsRlsOptDup		= NULL;
	string          IsLatestOptDup		= NULL;
	string          NonColttRev			= NULL;
	string          ViewFor98Grp		= NULL;
	string          ViewFor98GrpDup		= NULL;
	string			SchmCompCodeCategoryDup= NULL;
	string			SchmCompCodeCategory  = NULL;
	string			SchemePlatformDup  	= NULL;
	string			SchemePlatform  	= NULL;
	string			SchemeCreatorDup  	= NULL;
	string			SchemeCreator  		= NULL;


	SET_PTR			LcsSet				= NULL;
	boolean			isColLcsMch			= FALSE;


	SetOfObjects	setofDML			= NULL;
	SetOfObjects	soResult			= NULL;
	SetOfStrings	LifeCycValSet		= NULL;

	string			tasknam				= NULL;
	string			TaskDesignGrp		= NULL;
	string			TaskDesignGrpDup	= NULL;
	ObjectPtr		DMLObj				= NULL;
	ObjectPtr		sessionctxt			= NULL;
	ObjectPtr		soResultPart		= NULL;
	string			DmlType				= NULL;

	string			ColourIndDup		= NULL;
	string			ttRevDup			= NULL;
	string			ttSeqDup			= NULL;
	string			CoatedDup			= NULL;
	string			ColidDup			= NULL;
	string			InputpartDup		= NULL;
	string			projectcodeDup		= NULL;
	string			assyCompCodeDup		= NULL;
	string			assyColSrlDup		= NULL;
	string			EffectiveDateDup	= NULL;

	char			colourScheme[300];
	char			assyHasClSch[300];
	int				ii,jj,kk,TabSize2,ip= 0;

	int				TabSize=0,p=0,strLen=0,i=0,k=0,c=0,t=0,q=0,cnt=0,SchIndex,LCSSize,lcsCt=0;
	int				CheckResult1=0;
	*mfail = USC_OKAY;

	colourIDDup	=low_getspace(100);
	comCodeDup	=low_getspace(100);
	PartCatCode	=low_getspace(100);
	tmpVehClass	=low_getspace(100);
	Veh_value	=low_getspace(100);
	VehTypeList	=low_getspace(100);
	SchemeDesc	=low_getspace(500);
	SchName		=low_getspace(40);
	SchRev		=low_getspace(2);
	SchSeq		=low_getspace(2);
	subColSrl	=low_getspace(100);
	ColorSrl	=low_getspace(100);
	distinctVehClass=setCreate(100);
	TaskNoDup=nlsStrAlloc(50);

	LifeCycValSet = setCreate(2);
	  low_set_add_str_unique(LifeCycValSet,"LcsErcRlzd");
	  low_set_add_str_unique(LifeCycValSet,"LcsAPLWrkg");
	  low_set_add_str_unique(LifeCycValSet,"LcsAplRlzd");
	  low_set_add_str_unique(LifeCycValSet,"LcsSTDWrkg");
	  low_set_add_str_unique(LifeCycValSet,"LcsSTDRlzd");

	//strDbScope = low_set_create_str(2);
		//low_set_add_str_unique(strDbScope,"supprod");
		//low_set_add_str_unique(strDbScope,"sujprod");
		//low_set_add_str_unique(strDbScope,"suhprod");
		//low_set_add_str_unique(strDbScope,"sulprod");
		//if(dstat = smSetSessionDbScope(strDbScope)) goto CLEANUP;

	if(setSize(*SetOfChildObj)>0||*SetOfChildObj!=NULL)
	{
		t5FreeSetOfStrings(*SetOfChildObj);
	}
	if(setSize(*SetOfChildRelObj)>0||*SetOfChildRelObj!=NULL)
	{
		t5FreeSetOfStrings(*SetOfChildRelObj);
	}
	*SetOfChildObj =setCreate(1);
	*SetOfChildRelObj =setCreate(1);



	//objCopy(&CopyColourPartLop,ColourPart);
	if(dstat=objGetAttribute(ColourPart,t5ColourIndAttr,&ColourIndDup)) goto EXIT;
	ColourInd = nlsStrDup(ColourIndDup);
	if (dstat = objGetAttribute(ColourPart,RevisionAttr,&ttRevDup)) goto EXIT;
	ttRev = nlsStrDup(ttRevDup);
	if (dstat = objGetAttribute(ColourPart,SequenceAttr,&ttSeqDup)) goto EXIT;
	ttSeq = nlsStrDup(ttSeqDup);
	if(dstat=objGetAttribute(ColourPart,t5CoatedAttr,&CoatedDup)) goto EXIT;
	Coated = nlsStrDup(CoatedDup);
	if(dstat=objGetAttribute(ColourPart,t5ColourIDAttr,&ColidDup)) goto EXIT;
	Colid = nlsStrDup(ColidDup);
	if (dstat = objGetAttribute(ColourPart,PartNumberAttr,&InputpartDup)) goto EXIT;
	Inputpart = nlsStrDup(InputpartDup);
	fprintf(checkIndLogFile1,"\n Inside t5ShowUsesColourPart Function for inputs ::: Partnumber[%s] [%s] [%s] :::Colour Ind[%s] :::Coated Ind[%s]   \n",Inputpart,ttRev,ttSeq,ColourInd,Coated);

	if(nlsStrCmp(ColourInd,"C") && nlsStrCmp(Coated,"C") )
	{

	///*
	//*.TXT t5ColourIndNotFoundErr011/12/2013
	//*.Colour or Coated Indicator of the Part should be "C" for Uses Coated Colour Parts .
	//*/

	//t5CheckDstat(uiShowText("t5ColourIndNotFoundErr0", NULL, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
	//*mfail = NOT_OKAY;
	//goto CLEANUP;

	fprintf(checkIndLogFile1,"\nNot Colour/Coated Part\n");fflush(checkIndLogFile1);
	}
	t5CheckDstat(objGetAttribute(ColourPart,SupersededAttr,&SupVal)) ;

		if(!nlsStrCmp(SupVal,"-"))
		{
			//if(dstat = ConstructDialog("UsPColX",NULL,NULL,&extraStr,&extraObj,mfail,&dialogObj1)) goto EXIT;
			//if(*mfail) goto EXIT;
			//tx1Okstatus=1;
			//if(dstat = InteractWithUser(dialogObj1,NULL,NULL,&extraStr,&extraObj,mfail)) goto EXIT;
			//if(*mfail || tx1Okstatus==0)
			//{
			//	printf(" mfail in UsPColX");fflush(stdout);
			//	goto CLEANUP;
			//}

			//if (IsAsRlsOpt) IsAsRlsOpt=NULL;
			//if(dstat =objGetAttribute(dialogObj1,t5AsRlsOptAttr,&IsAsRlsOpt)) goto EXIT;
			//if(!nlsIsStrNull(IsAsRlsOpt)) IsAsRlsOptDup = nlsStrDup(IsAsRlsOpt);

			//if (IsLatestOpt) IsLatestOpt=NULL;
			//if(dstat =objGetAttribute(dialogObj1,t5LatestOptAttr,&IsLatestOpt)) goto EXIT;
			//if(!nlsIsStrNull(IsLatestOpt)) IsLatestOptDup = nlsStrDup(IsLatestOpt);
			IsAsRlsOptDup = nlsStrDup("+");
			IsLatestOptDup = nlsStrDup("-");
			if(nlsStrCmp(IsAsRlsOptDup,"+")==0 && nlsStrCmp(IsLatestOptDup,"+")==0)
			{
			//printf("Inside both options are selected::: Hence error display=== %s %s ",IsLatestOptDup,IsAsRlsOptDup);fflush(stdout);

	//		/*
	//		*.TXT t5AllOptionSelErr01
	//		*.Pls select any one option.
	//		*/

	//		if( dstat = uiShowText("t5AllOptionSelErr01", NULL, UI_ATTENTION_TEXT , dstat, WHERE) );
	//		goto EXIT;
	//		*mfail = NOT_OKAY;
	//		goto CLEANUP;

			}

		}

	if(EffectiveDate) EffectiveDate=NULL;
	if(EffectiveDateDup) EffectiveDateDup=NULL;

	t5CheckDstat(objGetObject(genContextObj,ConfigCtxtBlobAttr,&sessionctxt));

	t5CheckDstat(objGetAttribute(sessionctxt,EffectiveDateAttr,&EffectiveDateDup));
	//printf("\n EffectiveDateDup :%s \n",EffectiveDateDup); fflush(stdout);

	if (dstat = objGetAttribute(ColourPart,ProjectNameAttr,&projectcodeDup)) goto EXIT;
	projectcode = nlsStrDup(projectcodeDup);
	if (dstat = objGetAttribute(ColourPart,t5PrtCatCodeAttr,&assyCompCodeDup)) goto EXIT;
	assyCompCode = nlsStrDup(assyCompCodeDup);
	if (dstat = objGetAttribute(ColourPart,t5ColourIDAttr,&assyColSrlDup)) goto EXIT;
	assyColSrl = nlsStrDup(assyColSrlDup);
	fprintf(checkIndLogFile1,"\n Colour/Coated Part Project code:%s\n",projectcode);fflush(checkIndLogFile1);
	fprintf(checkIndLogFile1,"\n Colour/Coated t5PrtCatCode code:%s\n",assyCompCodeDup);fflush(checkIndLogFile1);
	fprintf(checkIndLogFile1,"\n Colour/Coated t5ColourID code:%s\n",assyColSrlDup);fflush(checkIndLogFile1);

	if(!nlsIsStrNull(EffectiveDateDup))
	{
		if((dstat = oiSqlCreateSelect(&Sql)) ||
		(dstat = oiSqlWhereBegParen(Sql)) ||
		(dstat = oiSqlWhereEQ(Sql,PartNumberAttr,Inputpart)) ||
		(dstat = oiSqlWhereAND(Sql)) ||
		(dstat = oiSqlWhereEQ(Sql, RevisionAttr,ttRev)) ||
		(dstat = oiSqlWhereAND(Sql)) ||
		(dstat = oiSqlWhereEQ(Sql, SequenceAttr,ttSeq)) ||
		(dstat = oiSqlWhereEndParen(Sql)) ||
		(dstat = QueryDbObject(PartClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &LatPartObjs, mfail))) goto CLEANUP;

	}
	else
	{
		if((dstat = oiSqlCreateSelect(&Sql)) ||
		(dstat = oiSqlWhereBegParen(Sql)) ||
		(dstat = oiSqlWhereEQ(Sql,PartNumberAttr,Inputpart)) ||
		(dstat = oiSqlWhereAND(Sql)) ||
		(dstat = oiSqlWhereEQ(Sql, SupersededAttr,"-")) ||
		(dstat = oiSqlWhereEndParen(Sql)) ||
		(dstat = QueryDbObject(PartClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &LatPartObjs, mfail))) goto CLEANUP;
	}

	if (setSize(LatPartObjs)>0)
	{
		//printf("\n  t5ShowUsesColourPart::Latest colour part found [Query Superseded]\n");fflush(stdout);
		LatPartObj=setGet(LatPartObjs,0);
	}
	else
	{
	//	printf("\n  t5ShowUsesColourPart::Latest colour part not found [Query Superseded]\n");fflush(stdout);
		goto CLEANUP;
	}

	if(!nlsStrCmp(ColourInd,"C"))
	{
		if(nlsIsStrNull(Colid))
		{

//		/*
//		*.TXT t5CompCodeNotFoundErr0
//		*.Colour ID of selected Colour Part should not be NULL .
//		*/
//
//		t5CheckDstat(uiShowText("t5CompCodeNotFoundErr0", NULL, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
//		*mfail = NOT_OKAY;
//		goto CLEANUP;

	//	printf("\nColour ID is Null\n");fflush(stdout);
		}
	}

	if(EffectiveDate) EffectiveDate=NULL;
	if(EffectiveDateDup) EffectiveDateDup=NULL;
	if(Sql_ptr)	oiSqlDispose(Sql_ptr);	Sql_ptr = NULL;
	t5CheckDstat(oiSqlCreateSelect(&Sql_ptr));
	t5CheckDstat(oiSqlWhereBegParen(Sql_ptr));
	t5CheckDstat(oiSqlWhereEQ(Sql_ptr,t5SyscdAttr,"UsesP"));
	t5CheckDstat(oiSqlWhereEndParen(Sql_ptr));
	t5CheckDstat(QueryDbObject(t5CntrolClass,Sql_ptr,-1,FALSE,SC_SCOPE_OF_SESSION,&soCntrlObj,mfail));
	if(Sql_ptr) oiSqlDispose(Sql_ptr); Sql_ptr = NULL;
	//objDump(genContextObj);
//	t5CheckDstat(objSetAttribute(CtxtObjTmp,CfgItemIdAttr,"GlobalCtxt"));
	//t5CheckDstat(objGetAttribute(genContextObj, NavigateViewNameAttr, &viewName));
	t5CheckDstat(objGetObject(genContextObj,ConfigCtxtBlobAttr,&sessionctxt));
	t5CheckDstat(objGetAttribute(sessionctxt, NavigateViewNameAttr, &viewName));
	//printf("\n viewName :%s \n",viewName); fflush(stdout);
	if(dstat = objNameValueSize(sessionctxt, LCStateListAttr,&LCSSize)) goto EXIT;
	fprintf(checkIndLogFile1,"\n set size of LC State :%d \n",LCSSize); fflush(checkIndLogFile1);
	LcsSet = low_set_create_str(8);
	for(i=0;i<LCSSize;i++)
	{
			if(LcsVal) LcsVal=NULL;
			if(LcsSel) LcsSel=NULL;
			if(dstat = objNameValueGet_byi(sessionctxt,LCStateListAttr,i,&LcsVal,&LcsSel)) goto EXIT;

			if(nlsStrCmp(LcsSel,"+")== 0)
			{
					//printf("\n LcsVal and LcsSel [%s]  [%s]",LcsVal,LcsSel);
				low_set_add_str(LcsSet,LcsVal);
			}
	 }
	// printf("\n Total State Selected Is [%d] ",setSize(LcsSet));
	 if(setSize(LcsSet)==0)
	 {
		low_set_add_str(LcsSet,"LcsAplRlzd");
		low_set_add_str(LcsSet,"LcsErcRlzd");
		low_set_add_str(LcsSet,"LcsReview");
		low_set_add_str(LcsSet,"LcsWorking");
		low_set_add_str(LcsSet,"LcsAPLWrkg");
		low_set_add_str(LcsSet,"LcsSTDRlzd");
		low_set_add_str(LcsSet,"LcsSTDWrkg");
	 }
	// printf("\n Set Size of LC state Object:%d \n",setSize(LcsSet)); fflush(stdout);
//	t5CheckDstat(objSetObject(genContextObjTmp,ConfigCtxtBlobAttr,CtxtObjTmp));
//	t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContextObjTmp,"PscLastRev",mfail));
	t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,ColourPart,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));

	t5CheckDstat(objGetAttribute(sessionctxt,EffectiveDateAttr,&EffectiveDateDup));
	//printf("\n EffectiveDateDup :%s \n",EffectiveDateDup); fflush(stdout);

	if(!nlsIsStrNull(EffectiveDateDup))
	{
		EffectiveDate = nlsStrDup(EffectiveDateDup);
		//printf("\n t5ShowUsesColourPart::EffectiveDate is [%s] ",EffectiveDate);fflush(stdout);
	}
	else
	{
		if(setSize(relObjSet)>0)
		{
			//Commened for Latest REv as Per GENTPL Report. TZ 3.55

			//t5CheckDstat(objGetAttribute (setGet(relObjSet,0),DateEffectiveFromAttr,&EffectiveDate));
			//printf("\n t5ShowUsesColourPart::Inside RevEff Object Found for Colour Part [%s]:: and EffectiveDate is [%s] ",Inputpart,EffectiveDate);fflush(stdout);

		}
	}
	//printf("\n t5ShowUsesColourPart:: for Colour Part Inputpart[%s]] ",Inputpart);fflush(stdout);

	t5CheckMfail(ExpandObject5("t5ClInfo",LatPartObj,"t5ColPrtforAsm",SC_SCOPE_OF_SESSION,&nonColourParts,mfail)) ;
	//printf("\n t5ShowUsesColourPart::Has Non Colour Part found: [%d] \n ",setSize(nonColourParts));fflush(stdout);
	if (setSize(nonColourParts)>0)
	{
			//objDumpAll(nonColourParts);
			//printf("\n t5ShowUsesColourPart::Inside Has Non Colour Part found \n ");fflush(stdout);
			 MasterOrgSet=setCreate(10);

			if(nlsStrCmp(viewName,"APL")==0 || nlsStrCmp(viewName,"STD")==0 )
			{
				for(k=0;k<setSize(nonColourParts) ;k++)
				{
				 nonColourPart=setGet(nonColourParts,k);
				if (dstat = objGetAttribute(nonColourPart,OrganizationIDAttr,&AssyOrgId)) goto EXIT;
				//printf("\n Input View Name [%s]:::and AssyOrgId [%s] \n",viewName,AssyOrgId);fflush(stdout);
				if (!nlsStrCmp(AssyOrgId,"APLPUNE"))
				{
					low_set_add(MasterOrgSet,nonColourPart);
					break;

				}

				}
				//printf("\n setSize(MasterOrgSet) after APL org check:%d\n",setSize(MasterOrgSet) ); fflush(stdout);
				if (setSize(MasterOrgSet)<=0)
				{
					  low_set_add(MasterOrgSet,setGet(nonColourParts,0));
				}
			}
			if(nlsStrCmp(viewName,"APL1")==0 || nlsStrCmp(viewName,"STD1")==0 )
			{
				for(k=0;k<setSize(nonColourParts) ;k++)
				{
				 nonColourPart=setGet(nonColourParts,k);
				if (dstat = objGetAttribute(nonColourPart,OrganizationIDAttr,&AssyOrgId)) goto EXIT;
				//printf("\n AssyOrgId :%s\n",AssyOrgId);fflush(stdout);
				if (!nlsStrCmp(AssyOrgId,"APLAHD"))
				{
					low_set_add(MasterOrgSet,nonColourPart);
					break;

				}

				}
				//printf("\n setSize(MasterOrgSet) after APL org check:%d\n",setSize(MasterOrgSet) ); fflush(stdout);
				if (setSize(MasterOrgSet)<=0)
				{
					  low_set_add(MasterOrgSet,setGet(nonColourParts,0));
				}
			}
			if(nlsStrCmp(viewName,"ERC")==0)
			{
				 low_set_add(MasterOrgSet,setGet(nonColourParts,0));
			}

			//printf("\n setSize(MasterOrgSet) before taking Rev:%d\n",setSize(MasterOrgSet) ); fflush(stdout);
			if (setSize(MasterOrgSet)>0)
			{

			MasterOrgObj=low_set_get(MasterOrgSet,0);

			t5CheckMfail(IntSetUpContext(objClass(MasterOrgObj),MasterOrgObj,&genContextObjTmp,mfail)) ;
			t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContextObjTmp,&CtxtObjTmp,mfail));
			t5CheckDstat(objSetAttribute(CtxtObjTmp,CfgItemIdAttr,"GlobalCtxt"));

			//Check options as released and latest here


			if(!nlsStrCmp(SupVal,"-"))
			{
				//printf("\n SupVal is False \n"); fflush(stdout);
				if(!nlsIsStrNull(EffectiveDate) && nlsStrCmp(IsAsRlsOptDup,"+")==0)
				{
					t5CheckDstat(SetEffectivityPref(CtxtObjTmp,true,"GlobalCtxt",EffectiveDate,NULL,mfail));
					//t5CheckDstat(objSetAttribute(CtxtObjTmp,EffectiveDateAttr,EffectiveDate));
				}
				if(nlsStrCmp(IsLatestOptDup,"+")==0)
				{
					t5CheckDstat(SetEffectivityPref(CtxtObjTmp,true,"GlobalCtxt",NULL,NULL,mfail));
					//t5CheckDstat(objSetAttribute(CtxtObjTmp,EffectiveDateAttr,""));
				}
				if(nlsIsStrNull(EffectiveDate))
				{
					t5CheckDstat(SetEffectivityPref(CtxtObjTmp,true,"GlobalCtxt",NULL,NULL,mfail));
					//t5CheckDstat(objSetAttribute(CtxtObjTmp,EffectiveDateAttr,""));
				}
			}
			else
			{
				//printf("\n SupVal is True \n"); fflush(stdout);
				if(!nlsIsStrNull(EffectiveDate))
				{
					t5CheckDstat(SetEffectivityPref(CtxtObjTmp,true,"GlobalCtxt",EffectiveDate,NULL,mfail));
					//t5CheckDstat(objSetAttribute(CtxtObjTmp,EffectiveDateAttr,EffectiveDate));
				}
				if(nlsIsStrNull(EffectiveDate))
				{
					t5CheckDstat(SetEffectivityPref(CtxtObjTmp,true,"GlobalCtxt",NULL,NULL,mfail));
					//t5CheckDstat(objSetAttribute(CtxtObjTmp,EffectiveDateAttr,""));
				}
			}

			t5CheckDstat(objSetObject(genContextObjTmp,ConfigCtxtBlobAttr,CtxtObjTmp));
			t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContextObjTmp,"PscLastRev",mfail));

			//objDump(MasterOrgObj);
			//objDump(genContextObjTmp);
			t5CheckMfail(ExpandRelationWithCtxt(ItemRevClass,
						MasterOrgObj,
						"StrucBIRevsOfItemMstr",
						 genContextObj,
						 SC_SCOPE_OF_SESSION,
						 NULL,
						 &t5ItmRevs,
						&t5ItmRevRels,
						mfail))  ;

			fprintf(checkIndLogFile1,"\n SetSize t5ItmRevs: %d \n ",setSize(t5ItmRevs));fflush(checkIndLogFile1);
			if (setSize(t5ItmRevs)==0)
			{
				//printf("\n No ItemRev found Hence EXIT.....\n");fflush(stdout);
	//			/*
	//			*.TXT t5ItemRevErr01
	//			*.Related Non -Colour Revision not found as per Context.Pls enter proper Context. !!!
	//			*/

	//			t5CheckDstat(uiShowText("t5ItemRevErr01", NULL, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
	//			*mfail = NOT_OKAY;
	//			goto CLEANUP;
			}
			else
			{
				t5ItmRev=setGet(t5ItmRevs,0);
				if (dstat = objGetAttribute(t5ItmRev,PartNumberAttr,&AssyPartNo)) goto EXIT;
				if (dstat = objGetAttribute(t5ItmRev,RevisionAttr,&NonColttRev)) goto EXIT;
				if (dstat = objGetAttribute(t5ItmRev,SequenceAttr,&ttSeq)) goto EXIT;

				fprintf(checkIndLogFile1,"\n After Expanding with Effective Date::PartNumber::[%s][%s][%s]\n",AssyPartNo,NonColttRev,ttSeq);fflush(checkIndLogFile1);

				if(VColourInd)  VColourInd=NULL;

				if(dstat=objGetAttribute(t5ItmRev,t5ColourIndAttr,&VColourInd)) goto EXIT;

			  if(Sql_ptr) oiSqlDispose(Sql_ptr);
			  if(dstat = oiSqlCreateSelect(&Sql_ptr));
			  if(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,AssyPartNo));
			  if(dstat = oiSqlWhereAND(Sql_ptr)) goto EXIT;
			  if(dstat = oiSqlWhereIN(Sql_ptr,LifeCycleStateAttr,LifeCycValSet,mfail));
			  if(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr));
			  if(dstat = oiSqlPrint(Sql_ptr));
			  if(dstat = QueryDbObject(PartClass,Sql_ptr,-1,TRUE,SC_SCOPE_OF_SESSION,&soResult,mfail));

			 fprintf(checkIndLogFile1,"\n setSize(soResult) : %d \n",setSize(soResult)); fflush(checkIndLogFile1);
				if(nlsStrCmp(VColourInd,"N")==0 && !nlsStrCmp(ColourInd,"C"))
				{
					//printf("\n Basic Part Colour Ind is N but colour part is there\n");fflush(stdout);
	//			/*
	//			*.TXT t5ColourIndErr0
	//			*.colour indicator of basic part is N.You can't go for Uses Colour-Coated Parts.
	//			*/
	//
	//			t5CheckDstat(uiShowText("t5ColourIndErr0", NULL, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
	//			*mfail = NOT_OKAY;
	//			goto CLEANUP;
				}
			}
		}
	}else
	{
		//Added by bharat on colour...
		if(dstat=objCopy(&t5ItmRev,LatPartObj)) goto EXIT;
		fprintf(checkIndLogFile1,"\n NonColour Not Found so going to do uses Part \n"); fflush(checkIndLogFile1);

	}

	if(!nlsStrCmp(Coated,"C") && !nlsStrCmp(ColourInd,"N") )
	{
		 ColourPartSet1=setCreate(200);
		 ColourRelPartSet1=setCreate(200);

		fprintf(checkIndLogFile1,"\n setSize(soResult) : %d \n",setSize(soResult)); fflush(checkIndLogFile1);

		if(setSize(soResult)>0)
		{
			for(ip=0;ip<setSize(soResult);ip++)
			{
				soResultPart=setGet(soResult,ip);
				//soResultPart=setGet(soResult,0);//Test

		t5FreeSetOfObjects(childObjSO);
		t5CheckMfail(ExpandRelationWithCtxt(AsRevRevClass,
						soResultPart,
						"PartsInAssembly",
						 genContextObj,
						 SC_SCOPE_OF_SESSION,
						 NULL,
						 &childObjSO,
						&childRelObjSO,
						mfail))  ;
		//t5CheckMfail(ExpandObject2(AsRevRevClass,t5ItmRev,"PartsInAssembly",SC_SCOPE_OF_SESSION,&childObjSO,&childRelObjSO,mfail)) ;
		fprintf(checkIndLogFile1,"\n  No of Uses Parts found : %d \n ",setSize(childObjSO));fflush(checkIndLogFile1);

		if(setSize(childObjSO)>0)
		{
			for(i=0;i<setSize(childObjSO);i++)
			{

				childObj=setGet(childObjSO,i);
				childRelObj=setGet(childRelObjSO,i);
				if (Iscoated)   Iscoated=NULL;
				if (colourInd)   colourInd=NULL;
				if (dstat = objGetAttribute(childObj,t5CoatedAttr,&Iscoated)) goto EXIT;
				if(!nlsIsStrNull(Iscoated)) IscoatedDup = nlsStrDup(Iscoated);
				if (dstat = objGetAttribute(childObj,t5ColourIndAttr,&colourInd)) goto EXIT;
				if(!nlsIsStrNull(colourInd)) colourIndDup = nlsStrDup(colourInd);
				//printf("\n Iscoated :%s and colourInd:%s \n",Iscoated,colourInd); fflush(stdout);
				if(!nlsStrCmp(colourIndDup,"N") && !nlsStrCmp(IscoatedDup,"Y"))
				{
				//if (dstat = ExpandRelationWithCtxt(ItemRevClass,childObj,"ItemMstrForStrucBIRev",genContextObj,SC_SCOPE_OF_SESSION,NULL,&t5ItmMstr,&t5ItmMstrRel,mfail)) goto CLEANUP;
				//printf("\nsetSize(t5ItmMstr):%d",setSize(t5ItmMstr));fflush(stdout);
				t5CheckMfail(ExpandObject2(ItemRevClass,childObj,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&t5ItmMstr,&t5ItmMstrRel,mfail)) ;
				fprintf(checkIndLogFile1,"\n SetSize t5ItmMstr: %d \n ",setSize(t5ItmMstr));fflush(checkIndLogFile1);

				itemRevObj=setGet(t5ItmMstr,0);
				fprintf(checkIndLogFile1,"\n itemrev obj \n"); fflush(checkIndLogFile1);
				t5CheckMfail(ExpandObject2(t5ClInfoClass,itemRevObj,"t5AsmhasColPrt",SC_SCOPE_OF_SESSION,&coatedParts,&coatedPartsRel,mfail)) ;
				fprintf(checkIndLogFile1,"\n SetSize coatedParts: %d \n ",setSize(coatedParts));fflush(checkIndLogFile1);
				if (setSize(coatedParts)>0)
				{
					if (dstat = objGetAttribute(low_set_get(coatedParts,0),PartNumberAttr,&IscoatedPartNo)) goto EXIT;
					//printf("\n IscoatedPartNo :%s\n",IscoatedPartNo); fflush(stdout);
					if((dstat = oiSqlCreateSelect(&Sql)) ||
					(dstat = oiSqlWhereBegParen(Sql)) ||
					(dstat = oiSqlWhereEQ(Sql,PartNumberAttr,IscoatedPartNo)) ||
					(dstat = oiSqlWhereAND(Sql)) ||
					(dstat = oiSqlWhereEQ(Sql, SupersededAttr,"-")) ||
					(dstat = oiSqlWhereEndParen(Sql)) ||
					(dstat = QueryDbObject(PartClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &CoatedPartObjs, mfail))) goto CLEANUP;
					//printf("\n setSize(CoatedPartObjs) :%d\n",setSize(CoatedPartObjs)); fflush(stdout);
					if (setSize(CoatedPartObjs)>0)
					{
						low_set_add(ColourPartSet1,low_set_get(CoatedPartObjs,0));
						low_set_add(ColourRelPartSet1,childRelObj);
					}

				}
				else
				{
					//printf("\n else no coated found last\n");
					low_set_add(ColourPartSet1,childObj);
					low_set_add(ColourRelPartSet1,childRelObj);
				}

				}
				if(!nlsStrCmp(colourIndDup,"N") && !nlsStrCmp(IscoatedDup,"N"))
				{
					//printf("\n else last\n");
					low_set_add(ColourPartSet1,childObj);
					low_set_add(ColourRelPartSet1,childRelObj);

				}
				if(!nlsStrCmp(colourIndDup,"Y"))
				{
					//printf("\n else colourind Y\n");
					low_set_add(ColourPartSet1,childObj);
					low_set_add(ColourRelPartSet1,childRelObj);

				}
			}
			if(setSize(ColourPartSet1)>0&&setSize(ColourRelPartSet1)>0)
			{
				//printf("\n setSize(ColourPartSet1):%d\n",setSize(ColourPartSet1)); fflush(stdout);
				//Need to Return Set Of Object.............................

////				t5CheckDstat(uiActivateBrowserWindow());
////				t5CheckMfail(GenerateBrowser(PartClass,BrwRelRghtValue,NULL,NULL,mfail));
////				t5CheckMfail(ShowListInBrowser(PartClass,PDO_BROWSER_ADD_TO,ColourPartSet1,ColourRelPartSet1,NULL,NULL,mfail));
////				t5CheckMfail(uiSetWindowTitle ("Uses Colour-Coated Part"));
////				t5CheckDstat(uiSetBrowserView("BrwListView"));
//
//				t5CheckDstat(uiActivateBrowserWindow());
//							for (i=0;i<setSize(ColourPartSet1) ;i++ )
//				{
//						if(dstat = RefreshObject2(setGet(ColourPartSet1,i),TRUE,mfail)) goto EXIT;
//						if(dstat = RefreshItObj(setGet(ColourPartSet1,i),TRUE,TRUE,&bln,&Obj,mfail)) goto EXIT;
//				}
//				for (i=0;i<setSize(ColourRelPartSet1) ;i++ )
//				{
//						if(dstat = RefreshObject2(setGet(ColourRelPartSet1,i),TRUE,mfail)) goto EXIT;
//						if(dstat = RefreshItObj(setGet(ColourRelPartSet1,i),TRUE,TRUE,&bln,&Obj,mfail)) goto EXIT;
//				}
//				t5CheckMfail(GenerateBrowser(PartClass,BrwNewWinValue,NULL,NULL,mfail));
//
//				uiGetWindowObject(&winObj);
//				SetColTableOnBrw("d5ColStr",winObj,NULL,NULL,mfail);
//
//				uiSetListViewColumns(winObj);
//
//				t5CheckMfail(ShowListInBrowser(PartClass,PDO_BROWSER_ADD_TO,ColourPartSet1,ColourRelPartSet1,NULL,NULL,mfail));
//				t5CheckMfail(uiSetWindowTitle ("Uses Colour-Coated Part"));
//				t5CheckDstat(uiSetBrowserView("BrwListView"));
//
//
//				t5CheckDstat(uiActivateBrowserWindow());
				low_set_cpy(*SetOfChildObj,ColourPartSet1);
				low_set_cpy(*SetOfChildRelObj,ColourRelPartSet1);

			}
			else
			{
				//printf("\nStructure not found as per Context setting.\n");
//			/*
//			*.TXT t5ColourStrErr0
//			*.Structure not found as per Context setting. Pls enter proper context.
//			*/
//
//			t5CheckDstat(uiShowText("t5ColourStrErr0", NULL, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
//			*mfail = NOT_OKAY;
//			goto CLEANUP;
			}

	       }
		   else
		   {
			   //printf("\nStructure not found as per Context setting.\n");
//			/*
//			*.TXT t5ColourStrErrC1
//			*.Structure not found as per input Part/Context setting. Pls enter proper Assembly/context.
//			*/
//
//			t5CheckDstat(uiShowText("t5ColourStrErrC1", NULL, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
//			*mfail = NOT_OKAY;
//			goto CLEANUP;
		   }
	}
	}
}
/****************Query for Master *************************/

if(!nlsStrCmp(ColourInd,"C"))
{
	if(sql1)	oiSqlDispose(sql1);	sql1 = NULL;
	if(soClMas)
	{

		soClMas = NULL;
	}
	if((dstat = oiSqlCreateSelect(&sql1)) ||
	(dstat = oiSqlWhereBegParen(sql1)) ||
	(dstat = oiSqlWhereEQ(sql1,t5Category_CodeAttr,assyCompCode)) ||
	(dstat = oiSqlWhereEndParen(sql1)) ||
	(dstat = QueryDbObject(t5CatCdClass, sql1, 0, TRUE, SC_SCOPE_OF_SESSION, &soClMas, mfail))) goto CLEANUP;
	fprintf(checkIndLogFile1,"\n **Colour t5CatCdClass  Query Set Size:%d\n",setSize(soClMas));fflush(checkIndLogFile1);

	if(setSize(soClMas)>0)
	{
		if(ClMasObj) ClMasObj=NULL;
		ClMasObj=setGet(soClMas,0);

		if (dstat = objGetAttribute(ClMasObj,t5InternalSchmAttr,&IntSchmInd)) goto EXIT;
		if(!nlsIsStrNull(IntSchmInd)) IntSchmIndDup = nlsStrDup(IntSchmInd);

			fprintf(checkIndLogFile1,"\n **IntSchmIndDup don't come null :%s \n",IntSchmIndDup );fflush(checkIndLogFile1);

	}

	/*******************************************************************************************************/
	//if(t5ItmRev)
	//printf("\n Beforeeeeeeeeee   \n");fflush(stdout);
	//objDump(t5ItmRev);
	if(t5ItmRev)
	t5CheckDstat(objGetAttribute(t5ItmRev,PartTypeAttr,&partType)) ;
	fprintf(checkIndLogFile1,"\n After   \n");fflush(checkIndLogFile1);


	if(nlsStrCmp(partType,"VC")==0)
	{
			fprintf(checkIndLogFile1,"\n Inside uses colour part being used for VC   \n");fflush(checkIndLogFile1);
			t5CheckDstat(objGetAttribute(t5ItmRev,OBIDAttr,&VCObid)) ;

			fprintf(checkIndLogFile1,"\n VC has OBID :%s\n",VCObid);fflush(checkIndLogFile1);
			if(sql)	oiSqlDispose(sql);	sql = NULL;
			if(SchmRelSet)
			{
				objDisposeAll(SchmRelSet);
				SchmRelSet = NULL;
			}

			if (dstat = oiSqlCreateSelect(&sql) |
					oiSqlWhereBegParen(sql) |
							oiSqlWhereEQ(sql,RightAttr,VCObid) |
					oiSqlWhereAND(sql) |
					oiSqlWhereEQ(sql,t5ColVCAttr,Inputpart) |
						oiSqlWhereEndParen(sql))
			if(*mfail)
				goto CLEANUP;
				if (dstat = QueryDbObject(t5ClCfgIClass,sql,1,TRUE,SC_SCOPE_OF_SESSION,&SchmRelSet,mfail))   ;
				if(*mfail)
				goto CLEANUP;


			fprintf(checkIndLogFile1,"\n No of Colour Scheme found setSize[SchmRelSet] :%d\n",setSize(SchmRelSet));fflush(checkIndLogFile1);
			if(setSize(SchmRelSet))
			{
				SchmRelObj = setGet(SchmRelSet,0);
				t5CheckDstat(objGetAttribute(SchmRelObj ,LeftAttr,&LeftSchm)) ;

				fprintf(checkIndLogFile1,"\n LeftSchm :%s \n",LeftSchm);fflush(checkIndLogFile1);

				if (dstat = oiSqlCreateSelect(&sql) |
						oiSqlWhereBegParen(sql) |
						oiSqlWhereEQ(sql,OBIDAttr,LeftSchm) |
						oiSqlWhereEndParen(sql))
				if(*mfail)
				goto CLEANUP;
				if (dstat = QueryDbObject(t5ClSchmClass,sql,1,TRUE,SC_SCOPE_OF_SESSION,&ColSchmSet,mfail))   ;
				if(*mfail)
				goto CLEANUP;

				SchmObjE = setGet(ColSchmSet,0);

				if (dstat = objGetAttribute(SchmObjE,NomenclatureAttr,&SchmName)) goto EXIT;
			}

			if(!nlsIsStrNull(EffectiveDate) && setSize(soCntrlObj)>0)
			{
				fprintf(checkIndLogFile1,"\n Inside EffectiveDate option being used  \n");fflush(checkIndLogFile1);
				if(ColSchmSet) ColSchmSet=NULL;
				if (dstat = oiSqlCreateSelect(&sql) |
						oiSqlWhereBegParen(sql) |
						oiSqlWhereLE(sql,PlannedEffDateAttr,EffectiveDate)|
						oiSqlWhereAND(sql)|
						oiSqlWhereEQ(sql,NomenclatureAttr,SchmName) |
						oiSqlWhereAND(sql) |
					//    oiSqlWhereEQ(sql, OwnerNameAttr,"Release Vault") |
					   oiSqlWhereLike(sql, OwnerNameAttr,"%Release Vault") |
						oiSqlWhereEndParen(sql))
				if(*mfail)
				goto CLEANUP;
				if (dstat = QueryDbObject(t5ClSchmClass,sql,0,TRUE,SC_SCOPE_OF_SESSION,&ColSchmSet,mfail))   ;
				if(*mfail)
				goto CLEANUP;

				if (setSize(ColSchmSet) <1)
				{

//				if (dstat = dlow_nvs_set(&textInserts,"EffectiveD",EffectiveDate)) goto EXIT;
//				t5CheckDstat(uiShowText("SchemeNotFoundE", textInserts, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
//				*mfail = NOT_OKAY;
//				goto CLEANUP;
				}

			}
			else
			{
				//printf("\n Inside EffectiveDate option not being used  \n");fflush(stdout);
				if(ColSchmSet) ColSchmSet=NULL;

				if(!nlsIsStrNull(SchmName))
				{
					if (dstat = oiSqlCreateSelect(&sql) |
							oiSqlWhereBegParen(sql) |
							oiSqlWhereEQ(sql,NomenclatureAttr,SchmName) |
							oiSqlWhereAND(sql) |
						  //  oiSqlWhereEQ(sql, OwnerNameAttr,"Release Vault") |
							oiSqlWhereLike(sql, OwnerNameAttr,"%Release Vault") |
							oiSqlWhereEndParen(sql))
					if(*mfail)
					goto CLEANUP;
					if (dstat = QueryDbObject(t5ClSchmClass,sql,0,TRUE,SC_SCOPE_OF_SESSION,&ColSchmSet,mfail))   ;
					if(*mfail)
					goto CLEANUP;
				}
			}


	}
	else
	{

		if(dstat =  ExpandObject5( CmRsltsClass,ColourPart,"BusItemIsResultOfCMPrdPln",SC_SCOPE_OF_SESSION,&TasksOfCLParts,mfail));
		fprintf(checkIndLogFile1,"\n Tasks found for Colour Part:%d\n",setSize(TasksOfCLParts));fflush(checkIndLogFile1);
		if(setSize(TasksOfCLParts)>0)
		{
			for(i=0;i<setSize(TasksOfCLParts);i++)
			{
				TaskObj=low_set_get(TasksOfCLParts,i);
				if(TaskNo) TaskNo=NULL;

				if (dstat = objGetAttribute(TaskObj,WbsIDAttr,&TaskNo)) goto EXIT;
				if ((nlsStrStr(TaskNo,"APLPUNE")==NULL || nlsStrStr(TaskNo,"APL")==NULL) && (nlsStrStr(TaskNo,"APL1")==NULL
				|| nlsStrStr(TaskNo,"APLSGR")==NULL ))
				{
					if(!nlsIsStrNull(TaskNo)) nlsStrCpy(TaskNoDup,TaskNo);
					if(tmpTaskNo) tmpTaskNo=NULL;
					tmpTaskNo=subString_1(TaskNoDup,0,10);
					fprintf(checkIndLogFile1,"\n **going to query Control Object for DML:%s\n",tmpTaskNo);fflush(checkIndLogFile1);


				//	 CheckResult1= CheckIfCMorCL (TaskObj,&mfail);


				//printf("\n ********Inside CheckIfCMorCL");fflush(stdout);

				t5CheckDstat(objGetAttribute(TaskObj,WbsIDAttr,&tasknam));
				//printf("\nTask name: %s\n",tasknam);fflush(stdout);

				if (dstat = objGetAttribute(TaskObj,t5DesignGroupAttr,&TaskDesignGrp)) goto EXIT;
				if(TaskDesignGrp) TaskDesignGrpDup=nlsStrDup(TaskDesignGrp);

				if(!nlsStrCmp(TaskDesignGrpDup,"CL") )
				{
					CheckResult1= 1;
				}
				else
				{
					  t5CheckMfail(ExpandObject5(CmPlRvRvClass,TaskObj,"CMPlanRollsUpInTo",SC_SCOPE_OF_SESSION,&setofDML,mfail));
					  	fprintf(checkIndLogFile1,"\nDML object found:%d\n",setSize(setofDML));fflush(checkIndLogFile1);
					  DMLObj = low_set_get(setofDML,0);

					t5CheckDstat(objGetAttribute(DMLObj,t5DmlTypeAttr,&DmlType));

					// chk CL n APL in task name
					if(!nlsStrCmp(DmlType,"CM") )
					{
						//printf("\n CM type DML\n");fflush(stdout);
						CheckResult1= 1;
					}
					else
					{
						CheckResult1= 0;
					}
				}


					fprintf(checkIndLogFile1,"\n *After CheckIfCMorCL function CheckResult1 :%d\n",CheckResult1);fflush(checkIndLogFile1);

					if(CheckResult1==1)
					{

						//your code will come in this loop for      testing 282929100123

						//printf("\n*********Inside CM or CL type DML\n");fflush(stdout);

						if(dstat = objGetAttribute(ColourPart,"t5NcPartNo",&NcPartNumber))goto CLEANUP;
							if(!nlsIsStrNull(NcPartNumber))
							{
								NcPartNumberDup = nlsStrDup(NcPartNumber);
								//printf("\n #NC Part no: %s\n",NcPartNumberDup);
							}

						if(sql1) sql1=NULL;
						if(HasControlSet) HasControlSet=NULL;

						if((dstat = oiSqlCreateSelect(&sql1)) ||
						(dstat = oiSqlWhereBegParen(sql1)) ||
						(dstat = oiSqlWhereEQ(sql1,t5VCDmlNoAttr,tmpTaskNo)) ||
						(dstat = oiSqlWhereAND(sql1))||
						(dstat = oiSqlWhereEQ(sql1,t5NonColorAssyAttr,NcPartNumberDup))||
						(dstat = oiSqlWhereEndParen(sql1)) ||
						(dstat = QueryDbObject(t5ClCtTClass, sql1, 0, TRUE, SC_SCOPE_OF_SESSION, &HasControlSet, mfail))) goto CLEANUP;
					//	printf("\n **Control Object Found by Query for  post mod dml :%d\n",setSize(HasControlSet));fflush(stdout);

			//swapnil code
								if(setSize(HasControlSet)==0)
							{
								//printf("\n Partno and DML combination not found in control object hence continueing");fflush(stdout);
							//	objColScheme=NULL;
								//goto CLEANUP;
							}
							else
							{
								//printf("\nFound");fflush(stdout);
								//printf("\nHasControlSet ObjectSize: %d\n",setSize(HasControlSet));fflush(stdout);
								HasControlObj = setGet(HasControlSet,0);
								if(dstat = ExpandObject2("t5CtColR",HasControlObj,"t5AssyHasClDml",SC_SCOPE_OF_SESSION,&AssyHasDmlSet,&AssyHasDmlRelSet,mfail)) goto CLEANUP ;
								if(setSize(AssyHasDmlSet)==0)
								{
									fprintf(checkIndLogFile1,"\nAssyHasDmlSet has size 0\n");fflush(checkIndLogFile1);
									goto CLEANUP;
								}
								else
								{
									//printf("\nAssyHasDmlSet ObjectSize: %d\n",setSize(AssyHasDmlSet));fflush(stdout);
								}
								if(setSize(AssyHasDmlRelSet)==0)
								{
									//printf("\nAssyHasDmlRelSet has size 0\n");fflush(stdout);
									goto CLEANUP;
								}
								else
								{
									//printf("\nAssyHasDmlRelSet ObjectSize: %d",setSize(AssyHasDmlRelSet));fflush(stdout);
								}
								for(jj=0 ;jj<setSize(AssyHasDmlRelSet);jj++)
								{
									t5FreeSetOfStrings(uniqueClrScm);
									uniqueClrScm =	low_set_create_str(100);
									if(dstat =objGetTableSize(setGet(AssyHasDmlRelSet,jj),"t5ColSchemesFt",&TabSize2)) goto EXIT;
									for(ii = 0; ii<TabSize2; ii++)
									{
										if(dstat=objGetTableAttribute (setGet(AssyHasDmlRelSet,jj),"t5ColSchemesFt", ii,"t5ColSchmRlsTAttr",&ColourSch)) goto EXIT;
										if(!nlsIsStrNull(ColourSch))
										{
											nlsStrTrimTrailWhiteSpace(ColourSch);
											ColourSchDup = nlsStrDup(ColourSch);
											low_set_add_str_unique(uniqueClrScm,ColourSchDup);
										}
									}
									//printf("\nNumber of Schemes:%d for Clr of NCPartno:%s\n",setSize(uniqueClrScm),NcPartNumberDup);fflush(stdout);
									if( dstat = objGetAttribute(setGet(AssyHasDmlSet,jj),"DisplayedDesc",&DisplayDesc)) goto CLEANUP;
									if(!nlsIsStrNull(DisplayDesc))
									{
										DisplayDescDup = nlsStrDup(DisplayDesc);
										//printf("\n:DmlNo:%s\n",DisplayDescDup);fflush(stdout);
									}
									for(ii=0;ii<setSize(uniqueClrScm);ii++)
									{
										clrscm = low_set_get_str(uniqueClrScm,ii);
										//printf("\n%d %s\n",ii,clrscm);fflush(stdout);
										//sColScheme = getColorSchemeObj(clrscm);
										setColScheme = (SetOfObjects)getColorSchemePartObjAct_1(clrscm);
										//printf("\n Before for loop setSize(setColScheme) :%d\n",setSize(setColScheme));
										for(kk=0;kk<setSize(setColScheme);kk++)
										{
											// add logic of matching colourID if needed

											t5CheckDstat(ulyAddObjectToSet(low_set_get(setColScheme,kk),&soSchmObj));     //ii
										}
									}
									//printf("\n After for loop setSize(soSchmObj) :%d\n",setSize(soSchmObj));
								}
					}

				//	}


					}
					else
					{

						//printf("\n***********Inside CP type DML\n");fflush(stdout);

					if(sql1) sql1=NULL;
					if(soControls) soControls=NULL;
					if((dstat = oiSqlCreateSelect(&sql1)) ||
					(dstat = oiSqlWhereBegParen(sql1)) ||
					(dstat = oiSqlWhereEQ(sql1,t5VCDmlNoAttr,tmpTaskNo)) ||
					(dstat = oiSqlWhereEndParen(sql1)) ||
					(dstat = QueryDbObject(t5ColCtlClass, sql1, 0, TRUE, SC_SCOPE_OF_SESSION, &soControls, mfail))) goto CLEANUP;
					//printf("\n **Control Object Found by Queryyyyyyyy:%d\n",setSize(soControls));fflush(stdout);
					SetOfVC  = setCreate(5);
					if (setSize(soControls)>0)
					{

					t5CheckDstat(objGetAttribute(setGet(soControls,0),t5SchmNomenclature1Attr,&scheme1));

					if(!nlsIsStrNull(scheme1)) low_set_add_str(SetOfVC,scheme1);

					t5CheckDstat(objGetAttribute(setGet(soControls,0),t5SchmNomenclature2Attr,&scheme2));

					if(!nlsIsStrNull(scheme2)) low_set_add_str(SetOfVC,scheme2);

					t5CheckDstat(objGetAttribute(setGet(soControls,0),t5SchmNomenclature3Attr,&scheme3));

					if(!nlsIsStrNull(scheme3)) low_set_add_str(SetOfVC,scheme3);

					t5CheckDstat(objGetAttribute(setGet(soControls,0),t5SchmNomenclature4Attr,&scheme4));

					if(!nlsIsStrNull(scheme4))  low_set_add_str(SetOfVC,scheme4);

					t5CheckDstat(objGetAttribute(setGet(soControls,0),t5SchmNomenclature5Attr,&scheme5));
					if(!nlsIsStrNull(scheme5)) low_set_add_str(SetOfVC,scheme5);
					}


					//printf("\n No of Colour Schemes found for DML==%s :%d\n",tmpTaskNo,setSize(SetOfVC));fflush(stdout);

					if (setSize(SetOfVC)>0)
					{
					for(cnt=0;cnt<setSize(SetOfVC);cnt++)
					{

						//printf("\n %d.going to Query scheme for :%s  \n",cnt,setGet(SetOfVC,cnt));fflush(stdout);

						if(!nlsIsStrNull(EffectiveDate) && setSize(soCntrlObj)>0)
						{
							//printf("\n Inside EffectiveDate option being used  \n");fflush(stdout);
							if(ColSchmSet) ColSchmSet=NULL;
							if (dstat = oiSqlCreateSelect(&sql) |
									oiSqlWhereBegParen(sql) |
									oiSqlWhereLE(sql,PlannedRelDateAttr,EffectiveDate)|
									oiSqlWhereAND(sql)|
									oiSqlWhereEQ(sql,NomenclatureAttr,setGet(SetOfVC,cnt)) |
									oiSqlWhereAND(sql) |
								//    oiSqlWhereEQ(sql, OwnerNameAttr,"Release Vault") |
								oiSqlWhereLike(sql, OwnerNameAttr,"%Release Vault") |
									oiSqlWhereEndParen(sql))
							if(*mfail)
							goto CLEANUP;
							if (dstat = QueryDbObject(t5ClSchmClass,sql,0,TRUE,SC_SCOPE_OF_SESSION,&tmpColSchmSet,mfail))   ;
							if(*mfail)
							goto CLEANUP;

						}
						else
						{
							//printf("\n Inside EffectiveDate option not being used  \n");fflush(stdout);
							if(ColSchmSet) ColSchmSet=NULL;
							if (dstat = oiSqlCreateSelect(&sql) |
									oiSqlWhereBegParen(sql) |
									oiSqlWhereEQ(sql,NomenclatureAttr,setGet(SetOfVC,cnt)) |
									oiSqlWhereAND(sql) |
								//    oiSqlWhereEQ(sql, OwnerNameAttr,"Release Vault") |
								oiSqlWhereLike(sql, OwnerNameAttr,"%Release Vault") |
									oiSqlWhereEndParen(sql))
							if(*mfail)
							goto CLEANUP;
							if (dstat = QueryDbObject(t5ClSchmClass,sql,0,TRUE,SC_SCOPE_OF_SESSION,&tmpColSchmSet,mfail))   ;
							if(*mfail)
							goto CLEANUP;


						}
						//printf("\n %d: Scheme found through Control Object for scheme ===%s:%d  \n",cnt,setGet(SetOfVC,cnt),setSize(tmpColSchmSet));fflush(stdout);

						if(setSize(tmpColSchmSet)>0)
						{

							for(t=0;t<setSize(tmpColSchmSet);t++)
							{
							t5CheckDstat(ulyAddObjectToSet(low_set_get(tmpColSchmSet,t),&soSchmObj));

							}
							low_set_empty(tmpColSchmSet);
							//printf("\n %d:Scheme Added====:%d  \n",i,setSize(soSchmObj));fflush(stdout);
						}

					}
					}

					} //else CP

					if (setSize(soSchmObj)>0)
					{
						//printf("\n Total Scheme found through Control Object :%d  \n",setSize(soSchmObj));fflush(stdout);
						for(t=0;t<setSize(soSchmObj);t++)
						{

							//objDump(SchmObj);
							if(dstat =objGetTableSize(low_set_get(soSchmObj,t),t5SchFullTabAttr,&TabSize)) goto EXIT;
							//printf("\n TabSize is %d", TabSize);fflush(stdout);
							if (dstat = objGetAttribute(low_set_get(soSchmObj,t),NomenclatureAttr,&SchemeName)) goto EXIT;
							//printf("\n %d. Filtering the Schemes %s for %s amd %s  : and %s \n",t,SchemeName,assyCompCode,assyColSrl,AssyPartNo);fflush(stdout);

							for (p=0;p<TabSize;p++)
							{
								//printf("\nTABSIZE %d;", TabSize);

								if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5PrtCatCodeAttr,&PartCatCode)) goto EXIT;
								if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5ClSrlAttr,&ColSrl)) goto EXIT;
								if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5SchmPrtCAttr,&SchmPrtNo)) goto EXIT;

								if((!nlsIsStrNull(PartCatCode))&&(!nlsIsStrNull(ColSrl)))
								{

								strLen=strlen(ColSrl);
								subColSrl=subString_1(ColSrl,3,strLen);
								nlsStrTrimTrailWhiteSpace(subColSrl);
								//printf("\n Checking in Full table: PartCatCode  ColSrl & Scheme Part No: %s ,%s ,%s \n",PartCatCode,subColSrl,SchmPrtNo);fflush(stdout);

								}

								if (nlsStrCmp(IntSchmIndDup,"T")==0)
								{
								if(!nlsIsStrNull(SchmPrtNo))
								{
									nlsStrTrimTrailWhiteSpace(SchmPrtNo);

									if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 && nlsStrStr(SchmPrtNo,AssyPartNo)!=NULL)
									{
										//printf("\n A. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
										//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
										//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
										//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
										t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
										break;
									}
								}
								else
								{
									if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
									{
										//printf("\n B. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
										//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
										//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
										//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
										t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
										break;
									}

								}
								}
								else
								{
									if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
									{
										//printf("\n C. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
										//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
										//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
										//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
										t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
										break;
									}
								}
							}


						}

					}


				} //task attached

			}
		}
	}
	/*******************************************************************************************************/


	//printf("\n Scheme Found Through DML Route after checkresult if and else  [%d] ",setSize(ColSchmSet));fflush(stdout);
	if (setSize(ColSchmSet) <1)
	{
		//printf("\n Scheme Found Through DML Route [%d]: Going Through VEH CLASS ",setSize(ColSchmSet));fflush(stdout);
		//if (dstat = objGetAttribute(ColourPart,ProjectNameAttr,&projectcode)) goto EXIT;
		//printf("\n Colour/Coated Part Project code:%s\n",projectcode);fflush(stdout);
		//printf("\n Project Code:%s ",projectcode);fflush(stdout);

		if ((dstat = oiSqlCreateSelect(&a_sql)) ||
		(dstat = oiSqlWhereEQ(a_sql,ProjectNameAttr,projectcode)) ||
		(dstat = QueryWhere(t0NPProjClass,a_sql,&ProjectSet,mfail)) )	goto EXIT;
		if (*mfail) goto CLEANUP;
		//printf("\n No of Projects Found:%d \n",setSize(ProjectSet));
		if(VehClass) VehClass=NULL;
		if (dstat = objGetAttribute(low_set_get(ProjectSet,0),t5VehicleClassAttr,&VehClass)) goto EXIT;
		//printf("\n VehClass found for project %s:  %s \n",projectcode,VehClass);fflush(stdout);
		if(!nlsIsStrNull(VehClass))
		{
			VehClassDup = nlsStrDup(VehClass);
		}
		else
		{

			//printf("\n Veh Class of Project:%s\n",projectcode);
//					/*
//					*.TXT t5VehClassNotFound
//					*.Veh Class of Project #projcode# is NULL .
//					*/
//					if (dstat = dlow_nvs_set(&textInserts,"projcode",projectcode)) goto EXIT;
//					t5CheckDstat(uiShowText("t5VehClassNotFound", textInserts, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
//					*mfail = NOT_OKAY;
//					goto CLEANUP;
		}

		//printf("\n EffectiveDate === %s \n",EffectiveDate);fflush(stdout);
		if(!nlsIsStrNull(EffectiveDate) && setSize(soCntrlObj)>0)
		{
			//printf("\n Inside EffectiveDate option being used  \n");fflush(stdout);
			if(nlsStrCmp(Coated,"C")==0)
			{
				if((dstat = oiSqlCreateSelect(&Sql)) ||
				(dstat = oiSqlWhereBegParen(Sql)) ||
				(dstat = oiSqlWhereLE(Sql,PlannedEffDateAttr,EffectiveDate))||
				(dstat = oiSqlWhereAND(Sql))||
				(dstat = oiSqlWhereEQ(Sql,t5VehClassAttr,VehClassDup)) ||
				(dstat = oiSqlWhereAND(Sql)) ||
				(dstat = oiSqlWhereEQ(Sql, t5CoatedAttr,"Y")) ||
				(dstat = oiSqlWhereAND(Sql)) ||
				//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
				(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
				(dstat = oiSqlWhereEndParen(Sql)) ||
				(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
				//printf("\n A.Total Scheme found for Veh class==%s :::: Coated Ind== Y :::: with EffectiveDate date ==%s ::: is== %d\n",VehClassDup,EffectiveDate,setSize(soSchmObj));fflush(stdout);

			}
			else
			{
				if((dstat = oiSqlCreateSelect(&Sql)) ||
				(dstat = oiSqlWhereBegParen(Sql)) ||
				(dstat = oiSqlWhereLE(Sql,PlannedEffDateAttr,EffectiveDate))||
				(dstat = oiSqlWhereAND(Sql))||
				(dstat = oiSqlWhereEQ(Sql,t5VehClassAttr,VehClassDup)) ||
				(dstat = oiSqlWhereAND(Sql)) ||
				//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
				(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
				(dstat = oiSqlWhereEndParen(Sql)) ||
				(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
				//printf("\n B.Total Scheme found for Veh class==%s :::: Coated Ind== N :::: with EffectiveDate date ==%s ::: is== %d\n",VehClassDup,EffectiveDate,setSize(soSchmObj));fflush(stdout);
			}
		}
		else
		{
			//printf("\n Inside EffectiveDate option not being used  \n");fflush(stdout);
			if(nlsStrCmp(Coated,"C")==0)
			{
				if((dstat = oiSqlCreateSelect(&Sql)) ||
				(dstat = oiSqlWhereBegParen(Sql)) ||
				(dstat = oiSqlWhereEQ(Sql,t5VehClassAttr,VehClassDup)) ||
				(dstat = oiSqlWhereAND(Sql)) ||
				(dstat = oiSqlWhereEQ(Sql, t5CoatedAttr,"Y")) ||
				(dstat = oiSqlWhereAND(Sql)) ||
				//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
				(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
				(dstat = oiSqlWhereEndParen(Sql)) ||
				(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
				//printf("\n C.Total Scheme found for Veh class==%s :::: Coated Ind== Y :::: is== %d\n",VehClassDup,setSize(soSchmObj));fflush(stdout);
			}
			else
			{
				if((dstat = oiSqlCreateSelect(&Sql)) ||
				(dstat = oiSqlWhereBegParen(Sql)) ||
				(dstat = oiSqlWhereEQ(Sql,t5VehClassAttr,VehClassDup)) ||
				(dstat = oiSqlWhereAND(Sql)) ||
				//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
				(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
				(dstat = oiSqlWhereEndParen(Sql)) ||
				(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
				//printf("\n D.Total Scheme found for Veh class==%s :::: Coated Ind== N :::: is== %d\n",VehClassDup,setSize(soSchmObj));fflush(stdout);
			}
		}



		if (setSize(soSchmObj)<1)
		{
//		/*.TXT SchemeHelp01
//		*.There is no Scheme found for Veh Class #VehClass#.
//		*.Would you like to check with Scheme of other Veh Class?
//		*/

			if(!nlsStrCmp(VehClassDup,"PRD"))
			{
				//printf("\n Inside for vehicle class PRD \n");fflush(stdout);
				if(!nlsIsStrNull(EffectiveDate) && setSize(soCntrlObj)>0)
					{
						//printf("\n Inside EffectiveDate option being used  \n");fflush(stdout);
						if(nlsStrCmp(Coated,"C")==0)
						{
							if((dstat = oiSqlCreateSelect(&Sql)) ||
							(dstat = oiSqlWhereBegParen(Sql)) ||
							(dstat = oiSqlWhereLE(Sql,PlannedEffDateAttr,EffectiveDate))||
							(dstat = oiSqlWhereAND(Sql)) ||
							(dstat = oiSqlWhereEQ(Sql, t5CoatedAttr,"Y")) ||
							(dstat = oiSqlWhereAND(Sql)) ||
						//	(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
							(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
							(dstat = oiSqlWhereEndParen(Sql)) ||
							(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
							//printf("\n A.Total Scheme found  :::: Coated Ind== Y :::: with EffectiveDate date ==%s ::: is== %d\n",EffectiveDate,setSize(soSchmObj));fflush(stdout);

						}
						else
						{
							if((dstat = oiSqlCreateSelect(&Sql)) ||
							(dstat = oiSqlWhereBegParen(Sql)) ||
							(dstat = oiSqlWhereLE(Sql,PlannedEffDateAttr,EffectiveDate))||
							(dstat = oiSqlWhereAND(Sql)) ||
						//	(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
							(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
							(dstat = oiSqlWhereEndParen(Sql)) ||
							(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
							//printf("\n B.Total Scheme found:: Coated Ind== N :::: with EffectiveDate date ==%s ::: is== %d\n",EffectiveDate,setSize(soSchmObj));fflush(stdout);
						}
					}
					else
					{
						//printf("\n Inside EffectiveDate option not being used  \n");fflush(stdout);
						if(nlsStrCmp(Coated,"C")==0)
						{
							if((dstat = oiSqlCreateSelect(&Sql)) ||
							(dstat = oiSqlWhereBegParen(Sql)) ||
							(dstat = oiSqlWhereEQ(Sql, t5CoatedAttr,"Y")) ||
							(dstat = oiSqlWhereAND(Sql)) ||
						//	(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
							(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
							(dstat = oiSqlWhereEndParen(Sql)) ||
							(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
							//printf("\n C.Total Scheme found f:: Coated Ind== Y :::: is== %d\n",setSize(soSchmObj));fflush(stdout);
						}
						else
						{
							if((dstat = oiSqlCreateSelect(&Sql)) ||
							(dstat = oiSqlWhereBegParen(Sql)) ||
							//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
							(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
							(dstat = oiSqlWhereEndParen(Sql)) ||
							(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
							//printf("\n D.Total Scheme found  :::: Coated Ind== N :::: is== %d\n",setSize(soSchmObj));fflush(stdout);
						}
					}

			}
			else
			{
				if(!nlsStrCmp(VehClassDup,"PRD"))
				{
					//printf("\n Inside for vehicle class PRD \n");fflush(stdout);
						if(!nlsIsStrNull(EffectiveDate) && setSize(soCntrlObj)>0)
						{
							//printf("\n Inside EffectiveDate option being used  \n");fflush(stdout);
							if(nlsStrCmp(Coated,"C")==0)
							{
								if((dstat = oiSqlCreateSelect(&Sql)) ||
								(dstat = oiSqlWhereBegParen(Sql)) ||
								(dstat = oiSqlWhereLE(Sql,PlannedEffDateAttr,EffectiveDate))||
								(dstat = oiSqlWhereAND(Sql)) ||
								(dstat = oiSqlWhereEQ(Sql, t5CoatedAttr,"Y")) ||
								(dstat = oiSqlWhereAND(Sql)) ||
								//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
								(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
								(dstat = oiSqlWhereEndParen(Sql)) ||
								(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
								//printf("\n A.Total Scheme found  :::: Coated Ind== Y :::: with EffectiveDate date ==%s ::: is== %d\n",EffectiveDate,setSize(soSchmObj));fflush(stdout);

							}
							else
							{
								if((dstat = oiSqlCreateSelect(&Sql)) ||
								(dstat = oiSqlWhereBegParen(Sql)) ||
								(dstat = oiSqlWhereLE(Sql,PlannedEffDateAttr,EffectiveDate))||
								(dstat = oiSqlWhereAND(Sql)) ||
								//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
								(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
								(dstat = oiSqlWhereEndParen(Sql)) ||
								(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
								//printf("\n B.Total Scheme found for :::: Coated Ind== N :::: with EffectiveDate date ==%s ::: is== %d\n",EffectiveDate,setSize(soSchmObj));fflush(stdout);
							}
						}
						else
						{
							//printf("\n Inside EffectiveDate option not being used  \n");fflush(stdout);
							if(nlsStrCmp(Coated,"C")==0)
							{
								if((dstat = oiSqlCreateSelect(&Sql)) ||
								(dstat = oiSqlWhereBegParen(Sql)) ||
								(dstat = oiSqlWhereEQ(Sql, t5CoatedAttr,"Y")) ||
								(dstat = oiSqlWhereAND(Sql)) ||
								//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
								(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
								(dstat = oiSqlWhereEndParen(Sql)) ||
								(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
								//printf("\n C.Total Scheme found f :::: Coated Ind== Y :::: is== %d\n",setSize(soSchmObj));fflush(stdout);
							}
							else
							{
								if((dstat = oiSqlCreateSelect(&Sql)) ||
								(dstat = oiSqlWhereBegParen(Sql)) ||
								//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
								(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
								(dstat = oiSqlWhereEndParen(Sql)) ||
								(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
								//printf("\n D.Total Scheme found for  :::: Coated Ind== N :::: is== %d\n",setSize(soSchmObj));fflush(stdout);
							}
						}

				}
				else
				{
					/*if (dstat = dlow_nvs_set(&textInserts,"VehClass",VehClassDup)) goto EXIT;
					if(dstat = uiShowConfirm("SchemeHelp01", textInserts, UI_MODAL_QUESTION, &ans)) goto EXIT;
					if(!ans)
					{
						//printf("\n Inside No Option selected  \n");fflush(stdout);
						*mfail=NOT_OKAY;
						goto EXIT;
					}
					else Hemal Commented */
					{
						//printf("\n Inside Query with other Veh Class:: showing Veh Class  \n");fflush(stdout);
						low_set_add_str_unique(distinctVehClass,"BUS");
						low_set_add_str_unique(distinctVehClass,"CAR");
						low_set_add_str_unique(distinctVehClass,"HCV");
						low_set_add_str_unique(distinctVehClass,"LCV");
						low_set_add_str_unique(distinctVehClass,"LMV");

						low_set_add_str_unique(distinctVehClass,"MCV");
						low_set_add_str_unique(distinctVehClass,"PRD");
						low_set_add_str_unique(distinctVehClass,"UV_VAN");
						low_set_add_str_unique(distinctVehClass,"SEMI VEHICLE");

//						if(dstat = ConstructDialog("ShwVLSX",NULL,NULL,&extraStr,&extraObj,mfail,&dialogObj2)) goto EXIT;
//						if(*mfail) goto EXIT;
//
//
//						for (t=0; t<setSize(distinctVehClass); t++ )
//						{
//							printf("\n ****distinct Veh Class found %d \n",setSize(distinctVehClass));
//							tmpVehClass=low_set_get(distinctVehClass,t);
//							printf("\n Veh Class...%s",tmpVehClass);
//							if(!nlsIsStrNull(tmpVehClass))
//							{
//
//							if(dstat=objNameValueSet(dialogObj2,t5ShwVehClassListAttr,tmpVehClass,"-")) goto EXIT;
//
//							}
//
//						}
//
//						if(dstat = InteractWithUser(dialogObj2,NULL,NULL,&extraStr,&extraObj,mfail)) goto EXIT;
						//printf("\n After InteractWithUser.... .... \n");fflush(stdout);
//
//						if(dstat = objNameValueSize(dialogObj2, t5ShwVehClassListAttr,&VehListSize)) goto EXIT;
//						if(dstat = objCopy(&orgObj1,dialogObj2)) goto EXIT;


						for(i=0;i<setSize(distinctVehClass);i++)
						{
							if(VehTypeList) VehTypeList=NULL;
							//if(Veh_value) Veh_value=NULL;
							//if(dstat = objNameValueGet_byi(orgObj1,t5ShwVehClassListAttr,i,&VehTypeList,&Veh_value)) goto EXIT;

							//if(nlsStrCmp(Veh_value,"+")== 0)
							//{
								//printf("\n Veh Class Selected ...%s %s",VehTypeList,Veh_value);
								VehTypeList=setGetStr(distinctVehClass,i);
								//printf("\n Inside second loop of Query Scheme for Veh Class === %s \n",VehTypeList);fflush(stdout);
								if(!nlsIsStrNull(EffectiveDate) && setSize(soCntrlObj)>0)
								{
									//printf("\n Inside EffectiveDate option being used  \n");fflush(stdout);
									if(nlsStrCmp(Coated,"C")==0)
									{
										if((dstat = oiSqlCreateSelect(&Sql)) ||
										(dstat = oiSqlWhereBegParen(Sql)) ||
										(dstat = oiSqlWhereLE(Sql,PlannedEffDateAttr,EffectiveDate))||
										(dstat = oiSqlWhereAND(Sql))||
										(dstat = oiSqlWhereEQ(Sql,t5VehClassAttr,VehTypeList)) ||
										(dstat = oiSqlWhereAND(Sql)) ||
										(dstat = oiSqlWhereEQ(Sql, t5CoatedAttr,"Y")) ||
										(dstat = oiSqlWhereAND(Sql)) ||
									//	(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
										(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
										(dstat = oiSqlWhereEndParen(Sql)) ||
										(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
										//printf("\n A.Total Scheme found for Veh class==%s :::: Coated Ind== Y :::: with EffectiveDate date ==%s ::: is== %d\n",VehTypeList,EffectiveDate,setSize(soSchmObj));fflush(stdout);

									}
									else
									{
										if((dstat = oiSqlCreateSelect(&Sql)) ||
										(dstat = oiSqlWhereBegParen(Sql)) ||
										(dstat = oiSqlWhereLE(Sql,PlannedEffDateAttr,EffectiveDate))||
										(dstat = oiSqlWhereAND(Sql))||
										(dstat = oiSqlWhereEQ(Sql,t5VehClassAttr,VehTypeList)) ||
										(dstat = oiSqlWhereAND(Sql)) ||
										//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
										(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
										(dstat = oiSqlWhereEndParen(Sql)) ||
										(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
										//printf("\n B.Total Scheme found for Veh class==%s :::: Coated Ind== N :::: with EffectiveDate date ==%s ::: is== %d\n",VehTypeList,EffectiveDate,setSize(soSchmObj));fflush(stdout);
									}
								}
								else
								{
									//printf("\n Inside EffectiveDate option not being used  \n");fflush(stdout);
									if(nlsStrCmp(Coated,"C")==0)
									{
										if((dstat = oiSqlCreateSelect(&Sql)) ||
										(dstat = oiSqlWhereBegParen(Sql)) ||
										(dstat = oiSqlWhereEQ(Sql,t5VehClassAttr,VehTypeList)) ||
										(dstat = oiSqlWhereAND(Sql)) ||
										(dstat = oiSqlWhereEQ(Sql, t5CoatedAttr,"Y")) ||
										(dstat = oiSqlWhereAND(Sql)) ||
										//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
										(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
										(dstat = oiSqlWhereEndParen(Sql)) ||
										(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
										//printf("\n C.Total Scheme found for Veh class==%s :::: Coated Ind== Y :::: is== %d\n",VehTypeList,setSize(soSchmObj));fflush(stdout);
									}
									else
									{
										if((dstat = oiSqlCreateSelect(&Sql)) ||
										(dstat = oiSqlWhereBegParen(Sql)) ||
										(dstat = oiSqlWhereEQ(Sql,t5VehClassAttr,VehTypeList)) ||
										(dstat = oiSqlWhereAND(Sql)) ||
										//(dstat = oiSqlWhereEQ(Sql, OwnerNameAttr,"Release Vault")) ||
										(dstat = oiSqlWhereLike(Sql, OwnerNameAttr,"%Release Vault")) ||
										(dstat = oiSqlWhereEndParen(Sql)) ||
										(dstat = QueryDbObject(t5ClSchmClass, Sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soSchmObj, mfail))) goto CLEANUP;
										//printf("\n D.Total Scheme found for Veh class==%s :::: Coated Ind== N :::: is== %d\n",VehTypeList,setSize(soSchmObj));fflush(stdout);
									}
								}


							//}
						}

					}
				}
			}
		}
		/*************************************************************/

		if(sql)	oiSqlDispose(sql);	sql = NULL;
					if(ControlSet)
				{
					objDisposeAll(ControlSet);
					ControlSet = NULL;
				}

				if((dstat = oiSqlCreateSelect(&sql)) ||
					(dstat = oiSqlWhereBegParen(sql)) ||
					(dstat = oiSqlWhereEQ(sql,t5SyscdAttr,"OLDEXT")) ||
					(dstat = oiSqlWhereEndParen(sql)) ||
					(dstat = QueryDbObject(t5CntrolClass, sql, 1, TRUE, SC_SCOPE_OF_SESSION, &ControlSet, mfail))) goto CLEANUP;
			//printf("\n setSize(ControlSet):%d\n",setSize(ControlSet));fflush(stdout);


		//printf("\n IntSchmIndDup %s   \n",IntSchmIndDup);fflush(stdout);
		for(t=0;t<setSize(soSchmObj);t++)
		{

			//objDump(SchmObj);
			if(dstat =objGetTableSize(low_set_get(soSchmObj,t),t5SchFullTabAttr,&TabSize)) goto EXIT;
			//printf("\n TabSize is %d", TabSize);fflush(stdout);
			if (dstat = objGetAttribute(low_set_get(soSchmObj,t),NomenclatureAttr,&SchemeName)) goto EXIT;
			if (dstat = objGetAttribute(low_set_get(soSchmObj,t),t5SchmCompPlatFormAttr,&SchmCompCodeCategory)) goto EXIT;
			if(SchmCompCodeCategory) SchmCompCodeCategoryDup=nlsStrDup(SchmCompCodeCategory);
			if (dstat = objGetAttribute(low_set_get(soSchmObj,t),CreatorAttr,&SchemeCreator)) goto EXIT;
			if(SchemeCreator) SchemeCreatorDup=nlsStrDup(SchemeCreator);
			if (dstat = objGetAttribute(low_set_get(soSchmObj,t),t5SchmPlantAttr,&SchemePlatform)) goto EXIT;
			if(SchemePlatform) SchemePlatformDup=nlsStrDup(SchemePlatform);
			//printf("\n %d. Filtering the Schemes %s for %s amd %s  : and %s and SchemeCreatorDup in uses col coated :%s \n",t,SchemeName,assyCompCode,assyColSrl,AssyPartNo,SchemeCreatorDup);fflush(stdout);


			for (p=0;p<TabSize;p++)
			{

				if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5PrtCatCodeAttr,&PartCatCode)) goto EXIT;
				if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5ClSrlAttr,&ColSrl)) goto EXIT;
				if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5SchmPrtCAttr,&SchmPrtNo)) goto EXIT;


				if((!nlsIsStrNull(PartCatCode))&&(!nlsIsStrNull(ColSrl)))
				{

				strLen=strlen(ColSrl);
				subColSrl=subString_1(ColSrl,3,strLen);
				nlsStrTrimTrailWhiteSpace(subColSrl);
				//printf("\n Checking in Full table: PartCatCode  ColSrl & Scheme Part No: %s ,%s ,%s \n",PartCatCode,subColSrl,SchmPrtNo);fflush(stdout);

				}

				if(setSize(ControlSet)>0)
				{
					if(!nlsStrCmp(SchmCompCodeCategoryDup,"Exterior"))
					{
						if((!nlsStrCmp(SchemePlatformDup,"OLD_INDICA") || !nlsStrCmp(SchemePlatformDup,"OLD_INDIGO")) &&! nlsStrCmp(SchemeCreatorDup,"Loader"))
						{
								if(!nlsIsStrNull(SchmPrtNo))
							{
								nlsStrTrimTrailWhiteSpace(SchmPrtNo);

								if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 && nlsStrStr(SchmPrtNo,AssyPartNo)!=NULL)
								{
									//printf("\n A. Inside Fields Match in Scheme for Scheme only for exterior schemes in uses col coated %s \n",SchemeName);fflush(stdout);
									//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
									//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
									//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
									t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
									break;
								}
							}
						}
							else
							{
								//printf("\n  Inside Fields for  exterior in control object creator not loader  \n"); fflush(stdout);
								if (nlsStrCmp(IntSchmIndDup,"T")==0)
								{
									if(!nlsIsStrNull(SchmPrtNo))
									{
										//printf("\n  Inside Fields for non exterior and  T   \n"); fflush(stdout);
										nlsStrTrimTrailWhiteSpace(SchmPrtNo);

										if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 && nlsStrStr(SchmPrtNo,AssyPartNo)!=NULL)
										{
											//printf("\n A. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
											//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
											//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
											//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
											t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
											break;
										}
									}
									else
									{
										if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
										{
											//printf("\n B. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
											//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
											//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
											//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
											t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
											break;
										}

									}
								}
								else
								{
								//printf("\n  Inside Fields for non exterior and body colour  \n"); fflush(stdout);
								if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
								{
									//printf("\n C. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
									//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
									//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
									//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
									t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
									break;
								}
							}
						}
					}
					else
					{

					if (nlsStrCmp(IntSchmIndDup,"T")==0)
					{
					if(!nlsIsStrNull(SchmPrtNo))
					{
						//printf("\n  Inside Fields for non exterior and  T   \n"); fflush(stdout);
						nlsStrTrimTrailWhiteSpace(SchmPrtNo);
						//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
						//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
					//	printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
						if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 && nlsStrStr(SchmPrtNo,AssyPartNo)!=NULL)
						{
						//	printf("\n A. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
							//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
							//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
							//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
							t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
							break;
						}
					}
					else
					{
						if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
						{
							//printf("\n B. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
							//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
							//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
							//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
							t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
							break;
						}

					}
					}
					else
					{
					//printf("\n  Inside Fields for non exterior and body colour  \n"); fflush(stdout);
					if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
					{
						//printf("\n C. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
						//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
						//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
						//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
						t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
						break;
					}
					}
				}
			}
			else
			{
					if (nlsStrCmp(IntSchmIndDup,"T")==0)
					{
					if(!nlsIsStrNull(SchmPrtNo))
					{
						nlsStrTrimTrailWhiteSpace(SchmPrtNo);

						if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 && nlsStrStr(SchmPrtNo,AssyPartNo)!=NULL)
						{
							//printf("\n A. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
							//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
							//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
							//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
							t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
							break;
						}
					}
					else
					{
						if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
						{
							//printf("\n B. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
							//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
							//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
							//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
							t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
							break;
						}

					}
					}
					else
					{
					if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
					{
						//printf("\n C. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
						//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
						//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
						//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
						t5CheckDstat(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet));
						break;
					}
					}
			}


		}
		}
	}
//L1:;
//printf("\n  Total Scheme Found for assyCompCode : %s assyColSrl: %s projectcode %s PartNumber: %s ::::: %d \n",assyCompCode,assyColSrl,projectcode,AssyPartNo,setSize(ColSchmSet));fflush(stdout);

if (setSize(ColSchmSet) <1)
{
///*
//*.TXT t5NoSchemeFoundErr
//*.No Scheme found for Colour Part #CLPART# .
//*/
//
//if (dstat = dlow_nvs_set(&textInserts,"CLPART",Inputpart)) goto EXIT;
//t5CheckDstat(uiShowText("t5NoSchemeFoundErr", textInserts, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
//goto CLEANUP;
//printf("\n No Scheme found for Colour Part:%s\n",Inputpart);fflush(stdout);
}

if (setSize(ColSchmSet) >0)
{

	//printf("\n Total scheme selected by user : %d\n",setSize(ColSchmSet));fflush(stdout);
	////t5CheckMfail(t5SortBOMObjsByDate(&ColSchmSet,&ColSchmSet,mfail));
	//printf("\n After shorting by Date: %d\n",setSize(ColSchmSet));fflush(stdout);
	for(t=0;t<setSize(ColSchmSet);t++)
	{
	if (dstat = objGetAttribute(low_set_get(ColSchmSet,t),NomenclatureAttr,&SchemeName)) goto EXIT;
	if (dstat = objGetAttribute(low_set_get(ColSchmSet,t),RevisionAttr,&SchemeRev)) goto EXIT;
	if (dstat = objGetAttribute(low_set_get(ColSchmSet,t),SequenceAttr,&SchemeSeq)) goto EXIT;
	//printf("\n %d===== : %s %s %s\n",t,SchemeName,SchemeRev,SchemeSeq);fflush(stdout);

	}
	SchIndex=setSize(ColSchmSet);
	SchIndex=SchIndex-1;

	SchmObj=low_set_get(ColSchmSet,SchIndex);

		if(dstat = objCopy(&tmpSchmObj,SchmObj)) goto EXIT;
		if(dstat =objGetTableSize(tmpSchmObj,t5SchFullTabAttr,&TabSize)) goto EXIT;
		if (IscoatedSchm)   IscoatedSchm=NULL;
		if (dstat = objGetAttribute(SchmObj,t5CoatedAttr,&IscoatedSchm)) goto EXIT;
		if(!nlsIsStrNull(IscoatedSchm)) IscoatedSchmDup = nlsStrDup(IscoatedSchm);

		//printf("\n Is coated Schm : %s \n",IscoatedSchmDup);fflush(stdout);


		ssCs = low_set_create_str(TabSize);
		for (q=0;q<TabSize;q++)
		{
			if(dstat = objGetTableAttribute(tmpSchmObj,t5SchFullTabAttr,q,t5PrtCatCodeAttr,&PartCatCode)) goto EXIT;
			if(dstat = objGetTableAttribute(tmpSchmObj,t5SchFullTabAttr,q,t5ClSrlAttr,&ColorSrl)) goto EXIT;
			//printf("\n PartCatCode & ColorSrl : %s ,%s \n",PartCatCode,ColorSrl);fflush(stdout);

			if((!nlsIsStrNull(PartCatCode))&&(!nlsIsStrNull(ColorSrl)))
			{

				strLen=nlsStrLen(ColorSrl);
				subColSrl=subString_1(ColorSrl,3,strLen);
				nlsStrTrimTrailWhiteSpace(subColSrl);
				//printf("\n PartCatCode & subColSrl : %s ,%s \n",PartCatCode,subColSrl);fflush(stdout);

				nlsStrCpy(colourScheme,PartCatCode);
				nlsStrCat(colourScheme,"_") ;
				nlsStrCat(colourScheme,subColSrl) ;
				//printf("\n colourScheme :%s \n",colourScheme);fflush(stdout);
				low_set_add_str(ssCs,colourScheme);

			}

		}
		//printf("\n Size[ssCs] :%d \n",setSize(ssCs));fflush(stdout);

		 ColourPartSet=setCreate(100);
		 ColourRelPartSet=setCreate(100);

//		t5CheckMfail(IntSetUpContext(objClass(t5ItmRev),t5ItmRev,&genContextObjOP,mfail));
//		t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass, genContextObjOP, &contextObjOP, mfail));
//		t5CheckMfail(objSetAttribute(contextObjOP,CfgItemIdAttr,"GlobalCtxt"));
//		//t5CheckDstat(objSetAttribute(contextObjOP,EffectiveDateAttr,""));
////		t5CheckDstat(objNameValueSet(contextObjOP,LCStateListAttr,"LcsAplRlzd","+"));
////		t5CheckDstat(objNameValueSet(contextObjOP,LCStateListAttr,"LcsErcRlzd","+"));
////		t5CheckDstat(objNameValueSet(contextObjOP,LCStateListAttr,"LcsReview","-"));
////		t5CheckDstat(objNameValueSet(contextObjOP,LCStateListAttr,"LcsWorking","-"));
////		t5CheckDstat(objNameValueSet(contextObjOP,LCStateListAttr,"LcsAPLWrkg","+"));
////		t5CheckDstat(objNameValueSet(contextObjOP,LCStateListAttr,"LcsSTDRlzd","+"));
////		t5CheckDstat(objNameValueSet(contextObjOP,LCStateListAttr,"LcsSTDWrkg","+"));
//		t5CheckDstat(objSetObject(genContextObjOP,ConfigCtxtBlobAttr,contextObjOP));
//		t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContextObjOP,"PscLastRev",mfail));

		//t5CheckDstat(objGetAttribute(contextObjOP, NavigateViewNameAttr, &ViewFor98Grp));
		t5CheckDstat(objGetObject(genContextObj,ConfigCtxtBlobAttr,&sessionctxt));
		t5CheckDstat(objGetAttribute(sessionctxt, NavigateViewNameAttr, &ViewFor98Grp));
		//printf("\n ViewFor98Grp :%s \n",ViewFor98Grp); fflush(stdout);
		//t5CheckDstat(objGetAttribute(genContextObj, NavigateViewNameAttr, &ViewFor98Grp));

		if(ViewFor98Grp) ViewFor98GrpDup=nlsStrDup(ViewFor98Grp);
		//printf("\nBefore config dump\n\n");fflush(stdout);
		//objDump(genContextObj);
		//printf("\nAfter config dump\n\n");fflush(stdout);
		//objDump(t5ItmRev);
		//printf("\nAfter t5ItmRev dump\n\n");fflush(stdout);
		t5FreeSetOfObjects(childRelObjSO);
		t5FreeSetOfObjects(childObjSO);
//		t5CheckMfail(ExpandRelationWithCtxt("AsRevRev",
//					t5ItmRev,
//					"PartsInAssembly",
//					 genContextObjOP,
//					 SC_SCOPE_OF_SESSION,
//					 NULL,
//					 &childObjSO,
//					&childRelObjSO,
//					mfail))  ;

		fprintf(checkIndLogFile1,"\n setSize(soResult) : %d \n",setSize(soResult)); fflush(checkIndLogFile1);

		if(setSize(soResult)>0)
		{
			for(ip=0;ip<setSize(soResult);ip++)
			{
				soResultPart=setGet(soResult,ip);
				//soResultPart=setGet(soResult,0);//Test
//		if(t5ItmRev)
//		{
			t5CheckMfail(ExpandRelationWithCtxt("AsRevRev",
						soResultPart,
						"PartsInAssembly",
						 genContextObj,
						 SC_SCOPE_OF_SESSION,
						 NULL,
						 &childObjSO,
						&childRelObjSO,
						mfail))  ;
		//}


		//printf("\n  No of Uses Parts found : %d \n ",setSize(childObjSO));fflush(stdout);

		fprintf(checkIndLogFile1,"\n setSize(childObjSO) : %d \n",setSize(childObjSO)); fflush(checkIndLogFile1);
		if(setSize(childObjSO)>0)
		{
			for(i=0;i<setSize(childObjSO);i++)
			{

			//printf("\n Inside childObjSO found i is :%d\n ",i);fflush(stdout);
			childObj=setGet(childObjSO,i);
			childRelObj=setGet(childRelObjSO,i);
			//
			//objDump(childObj);
			//printf("\n dump for qty \n"); fflush(stdout);
			if (Iscoated)   Iscoated=NULL;
			if (colourInd)   colourInd=NULL;
			if (PartType)   PartType=NULL;
			if (dstat = objGetAttribute(childObj,t5CoatedAttr,&Iscoated)) goto EXIT;
			if(!nlsIsStrNull(Iscoated)) IscoatedDup = nlsStrDup(Iscoated);

			if (dstat = objGetAttribute(childObj,t5ColourIndAttr,&colourInd)) goto EXIT;
			if(!nlsIsStrNull(colourInd)) colourIndDup = nlsStrDup(colourInd);
			if (dstat = objGetAttribute(childObj,PartTypeAttr,&PartType)) goto EXIT;
			if(!nlsIsStrNull(PartType)) PartTypeDup = nlsStrDup(PartType);

			if (dstat = objGetAttribute(childObj,t5PrtCatCodeAttr,&comCode)) goto EXIT;
			if(!nlsIsStrNull(comCode)) comCodeDup = nlsStrDup(comCode);

			//if (dstat = ExpandRelationWithCtxt(ItemRevClass,childObj,"ItemMstrForStrucBIRev",genContextObj,SC_SCOPE_OF_SESSION,NULL,&t5ItmMstr,&t5ItmMstrRel,mfail)) goto CLEANUP;
				//printf("\n  ::setSize(t5ItmMstr) : %d\n",setSize(t5ItmMstr)); fflush(stdout);

			t5CheckMfail(ExpandObject2(ItemRevClass,childObj,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&t5ItmMstr,&t5ItmMstrRel,mfail)) ;
			//printf("\n SetSize t5ItmMstr: %d \n ",setSize(t5ItmMstr));fflush(stdout);

			if(setSize(t5ItmMstr)>0)
			{

			itemRevObj=setGet(t5ItmMstr,0);

			t5CheckMfail(ExpandObject5("t5ClInfo",itemRevObj,"t5AsmhasColPrt",SC_SCOPE_OF_SESSION,&colourParts,mfail)) ;
			fprintf(checkIndLogFile1,"\n SetSize colourParts: %d \n ",setSize(colourParts));fflush(checkIndLogFile1);
			if (setSize(colourParts)>0)
			{
				AssyHasFlag=FALSE;
				for(k=0;k<setSize(colourParts);k++)
				{
					//printf("\n Inside colourParts found k is :%d\n ",k);fflush(stdout);
					colourPart=low_set_get(colourParts,k);
					if (dstat = objGetAttribute(colourPart,t5ColourIDAttr,&colourID)) goto EXIT;
					if(!nlsIsStrNull(colourID)) colourIDDup = nlsStrDup(colourID);

					if(nlsStrCmp(colourIndDup,"Y")==0)
					{

					//printf("\n comCode & colourID : %s ,%s \n",comCodeDup,colourIDDup);fflush(stdout);
					nlsStrCpy(assyHasClSch,comCodeDup);
					nlsStrCat(assyHasClSch,"_") ;
					nlsStrCat(assyHasClSch,colourIDDup) ;
					//printf("\n assyHasClSch :%s \n",assyHasClSch);fflush(stdout);
					for(c=0;c<setSize(ssCs);c++)
					{
						//printf("\n Inside Inner loop (VCHasClSch) Group\n");fflush(stdout);
						vcCS=low_set_get_str(ssCs,c);
						if(!nlsIsStrNull(vcCS)) vcCSDup = nlsStrDup(vcCS);
						//printf("\n vcCSDup Group: %s \n",vcCSDup);fflush(stdout);
						if(nlsStrCmp(vcCSDup,assyHasClSch)==0)
						{


							if (ColLcsSt) ColLcsSt=NULL;
							if (dstat = objGetAttribute(colourPart,LifeCycleStateAttr,&ColLcsSt)) goto EXIT;
							if(!nlsIsStrNull(ColLcsSt)) ColLcsStDup = nlsStrDup(ColLcsSt);
							//printf("\n ColLcsStDup: %s \n",ColLcsStDup);fflush(stdout);

							if (revision) revision=NULL;
							if (dstat = objGetAttribute(colourPart,RevisionAttr,&revision)) goto EXIT;
							if(!nlsIsStrNull(revision)) revisionDup = nlsStrDup(revision);

							isColLcsMch=FALSE;
							for(lcsCt=0;lcsCt<setSize(LcsSet);lcsCt++)
							{
								LcsVal=low_set_get_str(LcsSet,lcsCt);
								if(!nlsIsStrNull(LcsVal)) LcsValDup = nlsStrDup(LcsVal);

								//printf("\n LcsValDup: %s \n",LcsValDup);fflush(stdout);
								if(nlsStrCmp(LcsValDup,ColLcsStDup)==0)
								{

								isColLcsMch=TRUE;
								break;

								}
							}
							if((isColLcsMch==FALSE) && (nlsStrStr(revisionDup,"NR")==NULL))
							{
								//printf("\n Before Calling t5GenPrevRevForColPrt Function \n");fflush(stdout);
								t5CheckMfail(t5GenPrevRevForColPrtA(&colourPart,&isColLcsMch,&LcsSet,viewName,"-",mfail));
							}

							if(isColLcsMch==TRUE)
							{
							//printf("\n Comp Code & Colour ID match: %s %s\n",vcCSDup,assyHasClSch);fflush(stdout);

							if(nlsStrCmp(PartTypeDup,"V")==0 || nlsStrCmp(PartTypeDup,"VC")==0)
							{
							AssyHasFlag=TRUE;
							low_set_add(ColourPartSet,colourPart);
							low_set_add(ColourRelPartSet,childRelObj);
							break;
							}
							else
							{
							if(nlsStrCmp(IscoatedSchmDup,"Y")==0)
							{
								if(nlsStrCmp(colourIndDup,"Y")==0 && nlsStrCmp(IscoatedDup,"Y")==0)
								{
									if (CoatedType)   CoatedType=NULL;
									if (dstat = objGetAttribute(colourPart,t5CoatedAttr,&CoatedType)) goto EXIT;
									if(!nlsIsStrNull(CoatedType)) CoatedTypeDup = nlsStrDup(CoatedType);

									if (dstat = objGetAttribute(colourPart,t5ColourIndAttr,&ccolourInd)) goto EXIT;
									if(!nlsIsStrNull(ccolourInd)) ccolourIndDup = nlsStrDup(ccolourInd);

									//printf("\n Colour YES Coated YES: %s %s",ccolourIndDup,CoatedTypeDup);
									if(nlsStrCmp(CoatedTypeDup,"C")==0 && nlsStrCmp(ccolourIndDup,"C")==0 )
									{
										low_set_add(ColourPartSet,colourPart);
										low_set_add(ColourRelPartSet,childRelObj);
										//printf("\n After Adding  Colour  Coated Part SetSize ColourPartSet: %d \n ",setSize(ColourPartSet));fflush(stdout);
										AssyHasFlag=TRUE;
										break;
									}
								}
								if(nlsStrCmp(colourIndDup,"Y")==0 && nlsStrCmp(IscoatedDup,"N")==0)
								{
									if (CoatedType)   CoatedType=NULL;
									if (dstat = objGetAttribute(colourPart,t5CoatedAttr,&CoatedType)) goto EXIT;
									if(!nlsIsStrNull(CoatedType)) CoatedTypeDup = nlsStrDup(CoatedType);

									if (dstat = objGetAttribute(colourPart,t5ColourIndAttr,&ccolourInd)) goto EXIT;
									if(!nlsIsStrNull(ccolourInd)) ccolourIndDup = nlsStrDup(ccolourInd);

									//printf("\n Colour YES Coated YES: %s %s",ccolourIndDup,CoatedTypeDup);
									if(nlsStrCmp(CoatedTypeDup,"N")==0 && nlsStrCmp(ccolourIndDup,"C")==0 )
									{
										low_set_add(ColourPartSet,colourPart);
										low_set_add(ColourRelPartSet,childRelObj);
										//printf("\n After Finding  Colour  Coated Part SetSize ColourPartSet: %d \n ",setSize(ColourPartSet));fflush(stdout);

										AssyHasFlag=TRUE;
										break;
									}
								}

							}
							else
							{
									if (CoatedType)   CoatedType=NULL;
									if (dstat = objGetAttribute(colourPart,t5CoatedAttr,&CoatedType)) goto EXIT;
									if(!nlsIsStrNull(CoatedType)) CoatedTypeDup = nlsStrDup(CoatedType);

									if (dstat = objGetAttribute(colourPart,t5ColourIndAttr,&ccolourInd)) goto EXIT;
									if(!nlsIsStrNull(ccolourInd)) ccolourIndDup = nlsStrDup(ccolourInd);

									//printf("\n Colour YES Coated NO: %s %s",ccolourIndDup,CoatedTypeDup);
									if(nlsStrCmp(CoatedTypeDup,"N")==0 && nlsStrCmp(ccolourIndDup,"C")==0 )
									{
									low_set_add(ColourPartSet,colourPart);
									low_set_add(ColourRelPartSet,childRelObj);
									//printf("\n After Adding  colour Part SetSize ColourPartSet: %d \n ",setSize(ColourPartSet));fflush(stdout);
									AssyHasFlag=TRUE;
									break;
									}
							}
							}
						}
						}
					}
					}
					else
					{
					if(nlsStrCmp(IscoatedSchmDup,"Y")==0)
					{
					if((nlsStrCmp(colourIndDup,"N")==0 && nlsStrCmp(IscoatedDup,"Y")==0))
					{
						if (CoatedType)   CoatedType=NULL;
						if (dstat = objGetAttribute(colourPart,t5CoatedAttr,&CoatedType)) goto EXIT;
						if(!nlsIsStrNull(CoatedType)) CoatedTypeDup = nlsStrDup(CoatedType);
						//printf("\n Colour NO Coated YES: %s",CoatedTypeDup);
						if(nlsStrCmp(CoatedTypeDup,"C")==0)
						{
							low_set_add(ColourPartSet,colourPart);
							low_set_add(ColourRelPartSet,childRelObj);
							//printf("\n After Adding  Coated Part SetSize ColourPartSet: %d \n ",setSize(ColourPartSet));fflush(stdout);
							AssyHasFlag=TRUE;

						}
					}
					}
					}

					if(AssyHasFlag==TRUE)
					break;

				}
			}
			}
			if((AssyHasFlag !=TRUE)||(setSize(colourParts)<1))
			{
				low_set_add(ColourPartSet,childObj);
				low_set_add(ColourRelPartSet,childRelObj);
				//printf("\n After Adding  Basic Parts SetSize ColourPartSet: %d \n ",setSize(ColourPartSet));fflush(stdout);
			}


			}
		}
}
}

		// Activation of the current window is required before generating new browser
		if(setSize(ColourPartSet)>0)
		{

		//printf("\n assyCompCode :%s and ViewFor98GrpDup :%s\n",assyCompCode,ViewFor98GrpDup); fflush(stdout);
		if (!nlsStrCmp(assyCompCode,"VEHICLE") || !nlsStrCmp(assyCompCode,"BODY_SHELL"))
		{
				if( !nlsStrCmp(ViewFor98GrpDup,"APL") ||!nlsStrCmp(ViewFor98GrpDup,"APL1") ||
				   !nlsStrCmp(ViewFor98GrpDup,"STD") || !nlsStrCmp(ViewFor98GrpDup,"STD1"))
				 {
					t5FreeSetOfObjects(child98ObjSO);
					t5FreeSetOfObjects(child98RelObjSO);

					t5CheckMfail(ExpandRelationWithCtxt("AsRevRev",
						ColourPart,
						"PartsInAssembly",
						 genContextObj,
						 SC_SCOPE_OF_SESSION,
						 NULL,
						 &child98ObjSO,
						&child98RelObjSO,
						mfail))  ;
						//printf("\n setSize(child98ObjSO) :%d\n",setSize(child98ObjSO)); fflush(stdout);
						if (setSize(child98ObjSO)>0)
						{
							for (p=0;p<setSize(child98ObjSO) ;p++ )
							{
								child98Obj=low_set_get(child98ObjSO,p);
								child98RelObj=low_set_get(child98RelObjSO,p);

								low_set_add(ColourPartSet,child98Obj);
								low_set_add(ColourRelPartSet,child98RelObj);
							}
						}
				}


		}

		if (dstat = objGetAttribute(SchmObj,NomenclatureAttr,&SchName)) goto EXIT;
		if (dstat = objGetAttribute(SchmObj,RevisionAttr,&SchRev)) goto EXIT;
		if (dstat = objGetAttribute(SchmObj,SequenceAttr,&SchSeq)) goto EXIT;
		if (dstat = objGetAttribute(SchmObj,t5ClSrlAttr,&ColorSrl)) goto EXIT;
		if (dstat = objGetAttribute(SchmObj,t5ClSchmDescAttr,&SchemeDesc)) goto EXIT;
		if (dstat = objGetAttribute(SchmObj,t5ColourIDAttr,&colourIDDup)) goto EXIT;

		//printf("\n Colour Scheme :%s ColorSrl: %s Rev :%s & Seq : %s \n",SchName,ColorSrl,SchRev,SchSeq);fflush(stdout);
		//printf("\n setSize(ColourPartSet) :%d and setSize(ColourRelPartSet): %d\n",setSize(ColourPartSet),setSize(ColourRelPartSet));fflush(stdout);
		if(setSize(ColourPartSet)>0&&setSize(ColourRelPartSet))
		{
			low_set_cpy(*SetOfChildObj,ColourPartSet);
			low_set_cpy(*SetOfChildRelObj,ColourRelPartSet);
		}
//		nlsStrCpy(schemeName,"Uses Colour Part For ");
//		nlsStrCat(schemeName,Inputpart);
//		nlsStrCat(schemeName," With ");
//		nlsStrCat(schemeName,SchName);
//		nlsStrCat(schemeName, ",");
//		nlsStrCat(schemeName, SchRev);
//		nlsStrCat(schemeName, ",");
//		nlsStrCat(schemeName,ColorSrl);
//		nlsStrCat(schemeName, "-");
//		nlsStrCat(schemeName,colourIDDup);
//		nlsStrCat(schemeName, " ");
//		nlsStrCat(schemeName, "For ");
//		nlsStrCat(schemeName,NonColttRev);
//		nlsStrCat(schemeName, "  ");
//		nlsStrCat(schemeName, "Revision Of Non Colour");
////		nlsStrCat(schemeName, "   ");
////		nlsStrCat(schemeName, SchemeDesc);
//		printf("\n schemeName : %s \n",schemeName);fflush(stdout);
////		t5CheckDstat(uiActivateBrowserWindow());
////		t5CheckMfail(GenerateBrowser(PartClass,BrwRelRghtValue,NULL,NULL,mfail));
////		printf("\n after GenerateBrowser : %s \n",schemeName);fflush(stdout);
////		t5CheckMfail(ShowListInBrowser(PartClass,PDO_BROWSER_ADD_TO,ColourPartSet,ColourRelPartSet,NULL,NULL,mfail));
////		printf("\n after ShowListInBrowser : %s \n",schemeName);fflush(stdout);
////		t5CheckMfail(uiSetWindowTitle (schemeName));
////		t5CheckDstat(uiSetBrowserView("BrwListView"));
////		// Activating the browser window after adding set
////		t5CheckDstat(uiActivateBrowserWindow());
//
//		t5CheckDstat(uiActivateBrowserWindow());
//			for (i=0;i<setSize(ColourPartSet) ;i++ )
//		{
//				if(dstat = RefreshObject2(setGet(ColourPartSet,i),TRUE,mfail)) goto EXIT;
//				if(dstat = RefreshItObj(setGet(ColourPartSet,i),TRUE,TRUE,&bln,&Obj,mfail)) goto EXIT;
//		}
//		for (i=0;i<setSize(ColourRelPartSet) ;i++ )
//		{
//				if(dstat = RefreshObject2(setGet(ColourRelPartSet,i),TRUE,mfail)) goto EXIT;
//				if(dstat = RefreshItObj(setGet(ColourRelPartSet,i),TRUE,TRUE,&bln,&Obj,mfail)) goto EXIT;
//		}
//		t5CheckMfail(GenerateBrowser(PartClass,BrwNewWinValue,NULL,NULL,mfail));
//		uiGetWindowObject(&winObj);
//		SetColTableOnBrw("d5ColStr",winObj,NULL,NULL,mfail);
//
//		uiSetListViewColumns(winObj);
//
//		t5CheckMfail(ShowListInBrowser(PartClass,PDO_BROWSER_ADD_TO,ColourPartSet,ColourRelPartSet,NULL,NULL,mfail));
//		t5CheckMfail(uiSetWindowTitle (schemeName));
//		t5CheckDstat(uiSetBrowserView("BrwListView"));
//
//
//
//		t5CheckDstat(uiActivateBrowserWindow());

		}
		else
		{
			/*
//			*.TXT t5ColourStrErr1
//			*.Structure not found as per Context setting. Pls enter proper context.
//			*/

//			t5CheckDstat(uiShowText("t5ColourStrErr1", NULL, UI_ATTENTION_TEXT, dstat, WHERE) ) ;
//			*mfail = NOT_OKAY;
//			goto CLEANUP;

			//printf("\n In Else Structure not found as per Context setting. Pls enter proper context\n");
		}




}

}


CLEANUP: //printf("\n In cleanup t5ShowUsesColourPart\n");
	t5PrintCleanUpModName;
EXIT:
//printf("\n I'm here at EXIT code.for t5ShowUsesColourPart function...\n ");fflush(stdout);
	t5CheckDstatAndReturn;
}

status t5SortBOMObjs2
	(
		SetOfObjects	*itemObjs,
		SetOfObjects	*relObjs,
		integer*		mfail
	)
{
	status			dstat		= OKAY;
   	char			*mod_name 	= "t5SortBOMObjs2";
	SetOfObjects    tmpItemObjs    = NULL;
	SetOfObjects    tmpRelObjs     = NULL;
   	ObjectPtr		relObj		= NULL;
   	ObjectPtr		itemObj		= NULL;
   	ObjectPtr		relTObj		= NULL;
   	ObjectPtr		itemTObj	= NULL;
	integer			count		= 0;
	integer			cmpCount	= 0;
	ObjectPtr		tmpRelObj	= 0;
	string			curMainSerial		= NULL;
	string			tmpCurMainSerial	= NULL;
	integer			curIMainSerial		= 0;
	string			cmpMainSerial		= NULL;
	string			tmpCmpMainSerial	= NULL;
	integer			cmpIMainSerial		= 0;

   					*mfail 		= USC_OKAY;

	/* processing */

//	printf("\n No of Object for444444444444");fflush(stdout);
	for(count=0; count<setSize(*relObjs); count++)
	{
		itemObj = setGet(*itemObjs, count);
		relObj = setGet(*relObjs, count);

		/* initalizing sorted object set */
		if(count == 0)
		{
			if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(relObj, &tmpRelObjs)) goto CLEANUP;
			continue;
		}

		if(dstat = objCopy(&relTObj, relObj)) goto CLEANUP;
		if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;

		/* get mainSerial */
		if(dstat = objGetAttribute(relObj, "t5MainSerial", &curMainSerial)) goto CLEANUP;
		tmpCurMainSerial = nlsStrDup(curMainSerial);
		curIMainSerial = atoi(tmpCurMainSerial);
		nlsStrFree(tmpCurMainSerial); tmpCurMainSerial = NULL;

		/* compare mainSerial with the new set of objects */
		for(cmpCount=0; cmpCount<setSize(tmpRelObjs); cmpCount++)
		{
			tmpRelObj = setGet(tmpRelObjs, cmpCount);

			if(dstat = objGetAttribute(tmpRelObj, "t5MainSerial", &cmpMainSerial)) goto CLEANUP;
			tmpCmpMainSerial = nlsStrDup(cmpMainSerial);
			cmpIMainSerial = atoi(tmpCmpMainSerial);
			nlsStrFree(tmpCmpMainSerial); tmpCmpMainSerial = NULL;

			//printf("\ncalling ExpSetForUses curIMainSerial =[%d] and cmpIMainSerial =[%d]\n",curIMainSerial,cmpIMainSerial);fflush(stdout);

			if(curIMainSerial <= cmpIMainSerial)
			{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
				break;
			}
		}
		if(cmpCount == setSize(tmpRelObjs))
		{
			low_set_insrt(tmpRelObjs, cmpCount, relTObj);
			low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
		}
	}

	/* free memory and assign to new set sorted objects */
	//objDisposeAll(*itemObjs); *itemObjs = NULL;
	//objDisposeAll(*relObjs); *relObjs = NULL;

	t5FreeSetOfObjects (*itemObjs);
	t5FreeSetOfObjects (*relObjs);

	*itemObjs = tmpItemObjs;
	*relObjs = tmpRelObjs;

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
   	return( dstat );
}

status t5GetViewBasedExpl1
	(
		FILE           *checkIndLogFile1,
		ObjectPtr		partObj,
		integer			reqLevel,
		int				BPSFlg,
		ObjectPtr       contextObj,
		SetOfObjects	*childObjs,
		SetOfObjects	*childRelObjs,
		//SetOfStrings	*levels,
		integer*		level,
		SetOfStrings	SetOfPrtNum,
		integer*		mfail
	)
{
	status			dstat		= OKAY;
   	char			*mod_name 	= "t5GetViewBasedExpl1";
	SetOfObjects    itemObjs    = NULL;
	SetOfObjects    relObjs     = NULL;
	SetOfObjects  itemObjSet  = NULL;
	SetOfStrings	FrozList	= NULL;
   	ObjectPtr		relObj		= NULL;
   	ObjectPtr		itemObj		= NULL;
	ObjectPtr		getInfoDialog = NULL;
   	integer			cnt			  = 0;
	int				t			  = 0;

	string			strQtyDup	  = NULL;
	string			strQty		  = NULL;
	string			FroView		  = NULL;
	string			strRev		  = NULL;
	string			strPartNo	  = NULL;
	string			prtNamDup	  = NULL;
	string			prtNam		  = NULL;
	string			ColourInd	  = NULL;
	string			ColourIndDup  = NULL;
	string			CoatedInd	  = NULL;
	string			CoatedIndDup  = NULL;


	boolean			IsFound		  = FALSE;

	*mfail 		= USC_OKAY;




	if( *level >= reqLevel )
		   return (dstat);

	/*Add Part To Set*/
	itemObjSet = NULL;
    itemObjSet = setCreate(1);
	if(dstat = ulyCopyObjectToSet(partObj, &itemObjSet)) goto CLEANUP;
	if (*mfail)
	goto CLEANUP;

	ColourInd	 = NULL;
	ColourIndDup = NULL;
	CoatedInd	 = NULL;
	CoatedIndDup = NULL;

	//printf("\n************Colour ***************[%d] and [%d]",*level,reqLevel);fflush(stdout);

	if (dstat = objGetAttribute(setGet(itemObjSet, 0),t5ColourIndAttr,&ColourInd)) goto EXIT;
	if(!nlsIsStrNull(ColourInd))
	{
		ColourIndDup = nlsStrDup(ColourInd);
	}
	if (dstat = objGetAttribute(setGet(itemObjSet, 0),t5CoatedAttr,&CoatedInd)) goto EXIT;
	if(!nlsIsStrNull(CoatedInd))
	{
		CoatedIndDup = nlsStrDup(CoatedInd);
	}


	fprintf(checkIndLogFile1,"\nBPSFlg:%d",BPSFlg);
	fprintf(checkIndLogFile1,"\n  ColourIndDup : %s, CoatedIndDup : %s \n",ColourIndDup,CoatedIndDup);

	if((nlsStrCmp(ColourIndDup,"C")==0&&nlsStrCmp(CoatedIndDup,"C")==0)||(nlsStrCmp(ColourIndDup,"C")==0&&nlsStrCmp(CoatedIndDup,"N")==0) || (BPSFlg==1))
	{
		if( dstat = t5ActShowUsesCLPartMsgA(checkIndLogFile1,setGet(itemObjSet, 0),contextObj,&itemObjs,&relObjs,mfail))goto EXIT;// Hemal Comm
		if(*mfail)
		goto CLEANUP;

	}else
	{
		if (dstat = ExpSetForUses(AsRevRevClass,itemObjSet,"PartsInAssembly",NULL,contextObj,SC_SCOPE_OF_SESSION,&itemObjs,&relObjs,mfail))goto CLEANUP;
	}
    if(setSize(itemObjs)>0)
	{	//Sort the objects as per main serial.
		t5CheckMfail(t5SortBOMObjs2(&itemObjs, &relObjs, mfail));
	}
	// printf("\nsize of itemObjs after ExpSetForUses:%d\n",setSize(itemObjs));fflush(stdout);


    if (*mfail)
		goto CLEANUP;

	/* Get the objects from set and do recusive call */
	*level = *level + 1;
	for( cnt=0; cnt<setSize(itemObjs); cnt++)
	{

		prtNamDup = NULL;
		prtNam    = NULL;
		itemObj    = NULL;
		relObj    = NULL;

		itemObj = setGet(itemObjs, cnt);
		relObj = setGet(relObjs, cnt);

		if (dstat = objGetAttribute(itemObj,PartNumberAttr,&prtNamDup)) goto EXIT;
		if(!nlsIsStrNull(prtNamDup))prtNam = nlsStrDup(prtNamDup);

		//printf("\nValue of prtNam===============>:%s\n",prtNam);fflush(stdout);

		if(intFrznVewChk==1) /*Frozen view check selected*/
		{
			t5CheckMfail(GetInfoItem(itemObj,&getInfoDialog,mfail));
			if(dstat = objListGetList(getInfoDialog,FrozenViewListAttr,&FrozList)) goto EXIT;
			if(setSize(FrozList)>0)
			{
				for(t=0; t< setSize(FrozList);t++)
				{
					FroView=low_set_get_str(FrozList,t);
					if(nlsStrCmp(FroView,strView)==0)
					{
						if(!nlsIsStrNull(prtNam))
						{
							low_set_add_str_unique(SetOfPrtNum,prtNam);
						}
						if(dstat = ulyCopyObjectToSet(itemObj, childObjs)) goto CLEANUP;
						if(dstat = ulyCopyObjectToSet(relObj, childRelObjs)) goto CLEANUP;
						IsFound=TRUE;
						break;
					}

				}
			}
			t5CheckDstat(objGetAttribute(itemObj,RevisionAttr,&strRev));
			if((IsFound==FALSE) && (nlsStrStr(strRev,"NR")==NULL))
			{
				t5CheckMfail(t5GenPrevRevForViewExp(&itemObj,strView,&IsFound,mfail));
				if(IsFound==TRUE) /*Is frozen for the selected view*/
				{
					if(!nlsIsStrNull(prtNam))
					{
						low_set_add_str_unique(SetOfPrtNum,prtNam);
					}
					if(dstat = ulyCopyObjectToSet(itemObj, childObjs)) goto CLEANUP;
					if(dstat = ulyCopyObjectToSet(relObj, childRelObjs)) goto CLEANUP;
				}
				else
				{
					t5CheckDstat(objGetAttribute(itemObj,PartNumberAttr,&strPartNo));
					//printf("\nt5GetViewBasedExpl1:Partno = [%s] no revision is frozen for view [%s]",strPartNo,strView);
					fflush(stdout);
					continue;
				}
			}
		}
		else /*Frozen view check not selected;directly copy the objects to set*/
		{
			if(!nlsIsStrNull(prtNam))
			{
				low_set_add_str_unique(SetOfPrtNum,prtNam);
			}
			if(dstat = ulyCopyObjectToSet(itemObj, childObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(relObj, childRelObjs)) goto CLEANUP;
		}

		if(dstat = objGetAttribute(relObj, QuantityAttr, &strQty)) goto CLEANUP;
		if(!nlsIsStrNull(strQty))
			strQtyDup=nlsStrDup(strQty);
		else
			strQtyDup=nlsStrDup("0");
		if(intExclZeroQty==1)
		{
			if(nlsStrCmp(strQtyDup,"0")==0)
			{
				//printf("t5GetViewBasedExpl : Assy has 0 qty, hence wont be expand further");fflush(stdout);
				continue;
			}
		}
		/* recursive call */
		if( dstat = t5GetViewBasedExpl1(checkIndLogFile1,itemObj, reqLevel,BPSFlg, contextObj, childObjs, childRelObjs,level,SetOfPrtNum, mfail))

			goto CLEANUP;
		if(*mfail)
			goto CLEANUP;


	}
	*level = *level - 1;

CLEANUP:
	if(itemObjs)  objDisposeAll(itemObjs); itemObjs = NULL;
	if(relObjs)	  objDisposeAll(relObjs); relObjs = NULL;

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}

status t5GetMultiLvlViewBasedExpl1
(
		FILE           *checkIndLogFile1,
		ObjectPtr		partObj,
		integer			reqLevel,
		int				BPSFlg,
		ObjectPtr       contextObj,
		SetOfObjects*	childObjs,
		SetOfObjects*	childRelObjs,
		//SetOfStrings*	levels,
		SetOfStrings    SetOfPrtNum,
		integer*		mfail
)
{
	status			dstat		= OKAY;
   	char			*mod_name 	= "t5GetMultiLvlViewBasedExpl1";
	integer			level		= 0;
 //  	NVSET			textInserts	= NULL;
					*mfail 		= USC_OKAY;
	//printf("\n No of Object for111 ");fflush(stdout);
	/* call to a function to track level */
	//if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg1", textInserts, UI_DIALOG_TEXT , dstat, WHERE) )goto CLEANUP;
	//printf("\n No of Object for 2222222222");fflush(stdout);
	fprintf(checkIndLogFile1,"\n  t5GetViewBasedExpl1 :  \n");

	if( dstat = t5GetViewBasedExpl1(checkIndLogFile1,partObj, reqLevel,BPSFlg, contextObj, childObjs, childRelObjs, &level,SetOfPrtNum, mfail))
	//if( dstat = t5GetViewBasedExpl1(partObj, reqLevel, contextObj,&level,SetOfPrtNum, mfail))
		goto CLEANUP;
	if(*mfail)
		goto CLEANUP;

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}

int main(int argc, char *argv[])
{
	//int	 stat  =	OKAY;
	t5MethodInitWMD("GroupChildRelUA.c");
	dstat = clInitMB2 (argc,&argv,NULL);
	return soap_serve(soap_new()); /* call the request dispatcher */

}
;

int ns__getGrpChildlistsDataUA(struct soap* soap,char *Grp_prt,char* Plant,struct ns__CharArray1 *aString_test)
{
	//char* mod_name	= "main:GroupChildRel.c";
		//int i=0;
		int j=0;
		int k=0,ip=0;
		int	d=0;
		int chcnt=0;
		int prtptr=0;

		int BPSFlg = 0;

		SetOfObjects    soResult		= NULL;
		SetOfObjects    soResult1		= NULL;

		SetOfObjects    tmpItemObjs		= NULL;
		//SetOfObjects    ChildObjs		= NULL;
		//SetOfObjects    ChildRelObjs	= NULL;
		SetOfObjects	multiLevchldObjs= NULL;
		SetOfObjects	MultichildRelObjs= NULL;
		SetOfObjects	multiLevchldObjs1= NULL;
		SetOfObjects	MultichildRelObjs1= NULL;
		SetOfObjects	nonColourParts	= NULL;
		SetOfObjects	UsrObjSet		= NULL;//Hemal

		SetOfStrings	SetOfPrtNum		= NULL;
		SetOfStrings	SetOfPrtNum1	= NULL;

		SetOfStrings	strDbScope		= NULL;
		SetOfStrings	StrUnqPrtList	= NULL;
		SetOfStrings	LifeCycValSet	= NULL;

		SqlPtr          Sql_ptr			= NULL;

		//ObjectPtr       ChildObjPtr	    = NULL;
		ObjectPtr		GenContxtObjP	= NULL ;
		ObjectPtr		ContxtObjP1		= NULL ;
		ObjectPtr		multiLevChldPtr	= NULL;
		ObjectPtr		Grp_part_ptr	= NULL;
		ObjectPtr		tmpItemObjPtr	= NULL;
		ObjectPtr		NCPartP			= NULL;
		ObjectPtr		multiLevChldPtr1= NULL;

		string		    FileNameDup		= NULL;

		FILE           *checkIndLogFile1;

		string			InputPrt		= NULL;
		string			InputPrtDup		= NULL;
		string			ChildPart		= NULL;
		string			ChildPartDup	= NULL;
		string			StrTmpPrt		= NULL;
		string			OrgName			= NULL;
		string			OrgNameDup		= NULL;
		string			AssyPNo			= NULL;

		string			ColourIndDup	= NULL;
		string			ColourInd		= NULL;
		string			CoatedIndDup	= NULL;
		string			CoatedInd		= NULL;

		string			CreatorName		= NULL;//Hemal
		string			CreatorNameDup	= NULL;//Hemal
		string			ConfigIDStr		= NULL;//Hemal
		string			usrLocation		= NULL;//Hemal
		string			usrLocationDup	= NULL;//Hemal
		
		//UA Variable
		string			InpPrtProj		=	NULL;
		string			InpPrtProjDup	=	NULL;

		SqlPtr			Sql_ptr_UA		=	NULL;
		
		ObjectPtr		Grp_prt_UA		=	NULL;

		SetOfObjects	soTCUACntrl		=	NULL;

		//UA VARIABLE
		string			StrFullPathShell	=	NULL;
		string			inputfile			=	NULL;
		string			sysdate				=	NULL;
		const char		*txtargv[3];
		int				cnt					=	0;
		int				SysReturn			=	0;
		char			fileRead[500];
		FILE           *fp1;
		//UA VARIABLE
		//UA Variable Ends

		status			dstat			= OKAY;
		//int *mfail =USC_OKAY;
		int mfail =USC_OKAY;
		//char* mod_name="main:GroupChildRel.c";
		//char* mod_name="ns__ConnectionTest";
		
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("logUA.txt", "w", stdout);

		if (dstat = clInitialize2 (TRUE)) goto CLEANUP;
		//if (dstat = clLogin2 ("Loader","123loader",&mfail))goto CLEANUP;
		//if (dstat = clLogin2 ("hps08540","Nexon@123",&mfail))goto CLEANUP;
		//if (mfail!=OKAY)
		//{
			//printf("\nLogin Failed \n"); fflush(stdout);
		//	goto EXIT;
		//}	

		FileNameDup=nlsStrAlloc(50);


	//nlsStrCpy(FileNameDup1,"/plmuv_logs/omfprod/logs/ChildPartWebServicesLog/");
	//nlsStrCpy(FileNameDup,"/tmp/");
	nlsStrCpy(FileNameDup,"/plmuv_logs/omfprod/logs/");
	nlsStrCat(FileNameDup,"GroupPartUA");
	nlsStrCat(FileNameDup,"_");
	nlsStrCat(FileNameDup,Grp_prt);
	nlsStrCat(FileNameDup,".log");

	checkIndLogFile1 = fopen(FileNameDup , "w") ;
	if(checkIndLogFile1==NULL)
	{
		goto EXIT;
	}
		strDbScope = low_set_create_str(2);
		low_set_add_str_unique(strDbScope,"supprod");
		low_set_add_str_unique(strDbScope,"sujprod");
		low_set_add_str_unique(strDbScope,"suhprod");
		low_set_add_str_unique(strDbScope,"sulprod");
		if(dstat = smSetSessionDbScope(strDbScope)) goto CLEANUP;
	  fprintf(checkIndLogFile1,"\n********HELO***********");

	  LifeCycValSet = setCreate(2);
	  low_set_add_str_unique(LifeCycValSet,"LcsErcRlzd");
	  low_set_add_str_unique(LifeCycValSet,"LcsAPLWrkg");
	  low_set_add_str_unique(LifeCycValSet,"LcsAplRlzd");
	  low_set_add_str_unique(LifeCycValSet,"LcsSTDWrkg");
	  low_set_add_str_unique(LifeCycValSet,"LcsSTDRlzd");


	  if(Sql_ptr) oiSqlDispose(Sql_ptr);Sql_ptr=NULL;
	  if(dstat = oiSqlCreateSelect(&Sql_ptr));
	  if(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,Grp_prt));
	  if(dstat = oiSqlWhereAND(Sql_ptr)) goto EXIT;
	  if(dstat = oiSqlWhereIN(Sql_ptr,LifeCycleStateAttr,LifeCycValSet,&mfail));
	  // if(dstat = oiSqlWhereEQ(Sql_ptr,LifeCycleStateAttr,"LcsSTDRlzd"));
//	  if(dstat = oiSqlWhereBegParen(Sql_ptr)) goto EXIT;
//	  if(dstat = oiSqlWhereLike(Sql_ptr,OwnerNameAttr,"Release%"));
//	  if(dstat = oiSqlWhereOR(Sql_ptr)) goto EXIT;
//	  if(dstat = oiSqlWhereLike(Sql_ptr,OwnerNameAttr,"Obsolete%"));
//	  if(dstat = oiSqlWhereEndParen(Sql_ptr)) goto EXIT;
	  if(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr));
	  if(dstat = oiSqlPrint(Sql_ptr));
	  if(dstat = QueryDbObject(PartClass,Sql_ptr,-1,TRUE,SC_SCOPE_OF_SESSION,&soResult,&mfail));

	  fprintf(checkIndLogFile1,"\n*********Number of parts is::::: %d\n",setSize(soResult));

	// check if the project code of the part
	//if it is UA project code then go to TCUAPROJ label
	if (soResult>0)
	{
		Grp_prt_UA	=	setGet(soResult,0);
		
		if(dstat=objGetAttribute(Grp_prt_UA,ProjectNameAttr,&InpPrtProj)) goto EXIT;
		if(!nlsIsStrNull(InpPrtProj)) InpPrtProjDup = nlsStrDup(InpPrtProj);
		fprintf(checkIndLogFile1,"\nInpPrtProjDup:%s",InpPrtProjDup);
		
		//Query the TCUA_PRJ control object for project code
		if(Sql_ptr_UA) oiSqlDispose(Sql_ptr_UA);Sql_ptr_UA=NULL;
		if(dstat = oiSqlCreateSelect(&Sql_ptr_UA));
		if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SyscdAttr,"TCUA_PRJ"));//t5SubSyscdAttr
		if(dstat = oiSqlWhereAND(Sql_ptr_UA)) goto EXIT;
		if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SubSyscdAttr,InpPrtProjDup));
		if(dstat = oiSqlWhereAND(Sql_ptr_UA)) goto EXIT;
		if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5DelIndAttr,"-"));
		if(dstat = oiSqlDescOrder(Sql_ptr_UA,CreationDateAttr));
		if(dstat = oiSqlPrint(Sql_ptr_UA));
		if(dstat = QueryDbObject(t5CntrolClass,Sql_ptr_UA,-1,TRUE,SC_SCOPE_OF_SESSION,&soTCUACntrl,&mfail));
		
		fprintf(checkIndLogFile1,"\nNo of UA Control object found :%d",setSize(soTCUACntrl));
		if (setSize(soTCUACntrl)>0)
		{
			fprintf(checkIndLogFile1,"\nTCUA PROJECT PART, going to query part in TCUA");
			goto TCUAPROJ;
		}
	}
	//End UA Proj condition
	  if(setSize(soResult)>0)
	  {
		  for(prtptr=0;prtptr<setSize(soResult);prtptr++)
		  {

				Grp_part_ptr=setGet(soResult,prtptr);
				//Grp_part_ptr=setGet(soResult,0);//test
				//objDump(Grp_part_ptr);
				InputPrtDup	=	NULL;
				InputPrt	=	NULL;
				if(dstat=objGetAttribute(Grp_part_ptr,PartNumberAttr,&InputPrt)) goto EXIT;
				if(!nlsIsStrNull(InputPrt)) InputPrtDup = nlsStrDup(InputPrt);
				fprintf(checkIndLogFile1,"\nInputPrt:%s",InputPrtDup);
				fprintf(checkIndLogFile1,"\n  InputPrtDup : %s  \n",InputPrtDup);

				OrgNameDup	=	NULL;
				OrgName		=	NULL;
				if(dstat=objGetAttribute(Grp_part_ptr,OrganizationIDAttr,&OrgName)) goto EXIT;
				if(!nlsIsStrNull(OrgName)) OrgNameDup = nlsStrDup(OrgName);
				fprintf(checkIndLogFile1,"\nOrgNameDup:%s",OrgNameDup);

				//Added By Hemal Start
				CreatorName		=	NULL;
				CreatorNameDup	=	NULL;
				if(dstat=objGetAttribute(Grp_part_ptr,CreatorAttr,&CreatorName)) goto EXIT;
				if(!nlsIsStrNull(CreatorName)) CreatorNameDup = nlsStrDup(CreatorName);
				fprintf(checkIndLogFile1,"\nCreatorNameDup:%s",CreatorNameDup);
				//Added By Hemal End

				if((!nlsIsStrNull(OrgNameDup)) && (nlsStrStr(OrgNameDup,"APL")))
				{
				//Added By Hemal Start
				if(Sql_ptr) oiSqlDispose(Sql_ptr);Sql_ptr=NULL;
				if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
				if(dstat = oiSqlWhereEQ(Sql_ptr,ParticipantAttr, CreatorNameDup)) goto EXIT;
				if(dstat = QueryDbObject(UsrClass, Sql_ptr, 1, TRUE, SC_SCOPE_OF_SESSION, &UsrObjSet, &mfail)) goto EXIT;
				if (mfail) goto CLEANUP;

					if(setSize(UsrObjSet)>0)
					{
						usrLocationDup	=	NULL;
						usrLocation		=	NULL;
						if(dstat =objGetAttribute(setGet(UsrObjSet,0),t5UsrLocationAttr,&usrLocationDup));
						if(!nlsIsStrNull(usrLocationDup))
						usrLocation = nlsStrDup(usrLocationDup);
						fprintf(checkIndLogFile1,"\nusrLocation is:: %s",usrLocation);
						ConfigIDStr			=	NULL;
						ConfigIDStr			=	nlsStrAlloc(20);

						//if (nlsStrCmp(usrLocation,"PCVBU")==0 || nlsStrCmp(usrLocation,"PPCBU")==0 || nlsStrCmp(usrLocation,"PUNE")==0 ||  nlsStrCmp(usrLocation,"CARPLT")==0 ||  nlsStrCmp(usrLocation,"AHD")==0)
						if (nlsStrCmp(OrgNameDup,"APLPUN")==0 || nlsStrCmp(OrgNameDup,"APLAHD")==0 )
						{
							fprintf(checkIndLogFile1,"\nGlobalCtxt is set ");
							nlsStrCpy(ConfigIDStr,"GlobalCtxt");
						}
						else if (nlsStrCmp(OrgNameDup,"APLJSR")==0)
						{
							fprintf(checkIndLogFile1,"\nJsrCtxt is set ");
							nlsStrCpy(ConfigIDStr,"JsrCtxt");
						}
						else if (nlsStrCmp(OrgNameDup,"APLLKO")==0)
						{
							nlsStrCpy(ConfigIDStr,"LkoCtxt");
						}
						//else if (nlsStrCmp(OrgNameDup,"APLDWD")==0)
						//{
						//	nlsStrCpy(ConfigIDStr,"DWDCtxt");
						//}
						else if (nlsStrCmp(OrgNameDup,"JDL")==0)
						{
							nlsStrCpy(ConfigIDStr,"JdlCtxt");
						}
						else if (nlsStrCmp(OrgNameDup,"APLPNR")==0)
						{
							nlsStrCpy(ConfigIDStr,"PNRCtxt");
						}
						else
						{
							fprintf(checkIndLogFile1,"\nNo loaction found, set GlobalCtxt is set ");
							nlsStrCpy(ConfigIDStr,"GlobalCtxt");
						}
						fprintf(checkIndLogFile1,"\nConfigIDStr is:: %s",ConfigIDStr);
					}



					//Added By Hemal End

					if(dstat = SetUpContext(objClass(Grp_part_ptr),Grp_part_ptr,&GenContxtObjP,&mfail))goto CLEANUP;
					if(dstat = GetCfgCtxtObjFromCtxt(DSesScc2Class,GenContxtObjP,&ContxtObjP1,&mfail))goto CLEANUP;
					//if(dstat = objSetAttribute(ContxtObjP1,CfgItemIdAttr,"GlobalCtxt"))goto CLEANUP;
					if(dstat = objSetAttribute(ContxtObjP1,CfgItemIdAttr,ConfigIDStr))goto CLEANUP;
					if(dstat = objSetAttribute(ContxtObjP1,ExpandOnRevisionAttr, "PscLastRev"))goto CLEANUP;
					//if (nlsStrCmp(usrLocation,"AHD")==0)
					if (nlsStrCmp(OrgNameDup,"APLAHD")==0)
					{
					if(dstat = SetNavigateViewPref(ContxtObjP1,TRUE,"EAS","APL1",&mfail))goto CLEANUP;
					}
					else
					{
					if(dstat = SetNavigateViewPref(ContxtObjP1,TRUE,"EAS","APL",&mfail))goto CLEANUP;
					}
					if(dstat = objSetAttribute(ContxtObjP1,PsmExpIncludeZeroQtyAttr,"+"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsAplRlzd","+"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsErcRlzd","-"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsReview","-"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsWorking","-"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsAPLWrkg","-"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsSTDRlzd","+"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsSTDWrkg","+"))goto CLEANUP;
					if(dstat = objSetObject(GenContxtObjP,"ConfigCtxtBlob",ContxtObjP1)) goto CLEANUP;
					if(dstat = SetExpOnRevInCtxt(DSesGnCClass,GenContxtObjP,"PscLastRev",&mfail)) goto CLEANUP;
				}
				else
				{
					if(dstat = SetUpContext(objClass(Grp_part_ptr),Grp_part_ptr,&GenContxtObjP,&mfail))goto CLEANUP;
					if(dstat = GetCfgCtxtObjFromCtxt(DSesScc2Class,GenContxtObjP,&ContxtObjP1,&mfail))goto CLEANUP;
					if(dstat = objSetAttribute(ContxtObjP1,CfgItemIdAttr,"GlobalCtxt"))goto CLEANUP;
					if(dstat = objSetAttribute(ContxtObjP1,ExpandOnRevisionAttr, "PscLastRev"))goto CLEANUP;
					if(dstat = SetNavigateViewPref(ContxtObjP1,TRUE,"EAS","ERC",&mfail))goto CLEANUP;
					if(dstat = objSetAttribute(ContxtObjP1,PsmExpIncludeZeroQtyAttr,"+"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsAplRlzd","+"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsErcRlzd","+"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsReview","-"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsWorking","-"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsAPLWrkg","+"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsSTDRlzd","+"))goto CLEANUP;
					if(dstat = objNameValueSet(ContxtObjP1,"LCStateList","LcsSTDWrkg","+"))goto CLEANUP;
					if(dstat = objSetObject(GenContxtObjP,"ConfigCtxtBlob",ContxtObjP1)) goto CLEANUP;
					if(dstat = SetExpOnRevInCtxt(DSesGnCClass,GenContxtObjP,"PscLastRev",&mfail)) goto CLEANUP;
				}

				if( dstat = t5GetMultiLvlViewBasedExpl1(checkIndLogFile1,Grp_part_ptr, 99,BPSFlg, GenContxtObjP,&multiLevchldObjs,&MultichildRelObjs,SetOfPrtNum, &mfail))goto CLEANUP;

				if(setSize(multiLevchldObjs)>0)
				{
					for(j=0;j<setSize(multiLevchldObjs);j++)
					{
						multiLevChldPtr= low_set_get(multiLevchldObjs,j);
						if(!nlsIsStrNull(ChildPart)) ChildPart=NULL;
						if(dstat = objGetAttribute(multiLevChldPtr,"PartNumber",&ChildPart)) goto CLEANUP;
						if(dstat = ulyAddObjectToSet (multiLevChldPtr, &tmpItemObjs)) goto CLEANUP;
					}
				}

			}
	  }
	  else
		{
			TCUAPROJ :
				//printf("\nCheck part in TCUA");fflush(stdout);
				fprintf(checkIndLogFile1,"\n GROUP PART not found in TCE, check in TCUA");
				StrFullPathShell = nlsStrAlloc(200);//"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass"
				nlsStrCpy(StrFullPathShell,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GRP_CHILD/UAGroupChild.sh");

				txtargv[0] = StrFullPathShell;
				txtargv[1] = Grp_prt;
				txtargv[2] = Plant;
				txtargv[3] = NULL;

				for (cnt = 0;cnt < 3; cnt++ )
				{
					fprintf(checkIndLogFile1,"txtargv[%d] : [%s]", cnt, txtargv[cnt]); fflush(checkIndLogFile1);
				}

				fprintf(checkIndLogFile1,"\nStrFullPathShell : [%s]", StrFullPathShell); fflush(checkIndLogFile1);

				SysReturn = sysExecute(StrFullPathShell, txtargv);
				if(SysReturn == 0)
				{
					fprintf(checkIndLogFile1,"\n Execution Done Successfully ...");  fflush(checkIndLogFile1);
				}
				else
				{
					fprintf(checkIndLogFile1,"\n Execution Done Fail, Pl check Env variable and calling shell..\n");  fflush(checkIndLogFile1);
				}

				sysdate		=	sysGetDate();
				low_strrpl(sysdate,'-','_');
				//low_strrpl(sysdate,' ','_');
				fprintf(checkIndLogFile1,"\n sysdate : %s",sysdate);  fflush(checkIndLogFile1);
				inputfile	=	nlsStrAlloc(nlsStrLen("/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/")+100);
				nlsStrCpy(inputfile,"");
				nlsStrCat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GRP_CHILD");
				nlsStrCat(inputfile,"/");
				nlsStrCat(inputfile,sysdate);
				nlsStrCat(inputfile,"/");
				nlsStrCat(inputfile,Grp_prt);
				nlsStrCat(inputfile,"_GrpChild");
				nlsStrCat(inputfile,".txt");
				fprintf(checkIndLogFile1,"\nFilename : %s",inputfile);fflush(checkIndLogFile1);

				fp1=fopen(inputfile,"r");

				if(fp1!=NULL)
				{

					if(StrUnqPrtList != NULL)
					{
						setEmpty(StrUnqPrtList); StrUnqPrtList = NULL;
					}
					StrUnqPrtList = setCreate(1);

					char	*line	= NULL;
					size_t	len		= 0;
					ssize_t read;
					int		iFln	=	0;
					string			getLinef		=	NULL;

					while ((read = getline(&line, &len, fp1)) != -1) 
					{
					   // printf("Retrieved line of length %zu :\n", read);
						fprintf(checkIndLogFile1,"%s\n", line);fflush(checkIndLogFile1);
						low_trimwb(line);//Added to remove space
						low_set_add_str_unique(StrUnqPrtList,line);
					}

					fprintf(checkIndLogFile1,"\nsetSize(StrUnqPrtList):%d",setSize(StrUnqPrtList));
					
					d=setSize(StrUnqPrtList);
					aString_test->__size = d;
					aString_test->__ptrPrt = malloc( (aString_test->__size + 100000) * sizeof(*aString_test->__ptrPrt) );

					for(chcnt = 0; chcnt < setSize(StrUnqPrtList); chcnt++)
					{
						if(StrTmpPrt != NULL)
						{
							nlsStrFree(StrTmpPrt); StrTmpPrt = NULL;
						}
						StrTmpPrt = nlsStrDup("-");

						StrTmpPrt = setGetStr(StrUnqPrtList, chcnt);
						low_trimwb(StrTmpPrt);
						fprintf(checkIndLogFile1,"\nStrTmpPrt:%s,",StrTmpPrt);
						aString_test->__ptrPrt[chcnt].prt_no = malloc(30 * sizeof(char *) );
						nlsStrCpy(aString_test->__ptrPrt[chcnt].prt_no,StrTmpPrt);
					}

					fflush(stdout);
					dup2(fd, fileno(stdout));
					close(fd);
					clearerr(stdout);
					fsetpos(stdout, &pos);

					return SOAP_OK;

				}
		}

	

		if(StrUnqPrtList != NULL)
		{
			setEmpty(StrUnqPrtList); StrUnqPrtList = NULL;
		}
		StrUnqPrtList = setCreate(1);


		if(setSize(tmpItemObjs)>0)
		  {
			for(k=0;k<setSize(tmpItemObjs);k++)
			{
				tmpItemObjPtr=low_set_get(tmpItemObjs,k);
				if(!nlsIsStrNull(ChildPart)) ChildPart=NULL;
				if(!nlsIsStrNull(ChildPartDup)) ChildPartDup=NULL;
				if(dstat = objGetAttribute(tmpItemObjPtr,"PartNumber",&ChildPart)) goto CLEANUP;
				if(!nlsIsStrNull(ChildPart))
				{
					ChildPartDup = nlsStrDup(ChildPart);
					fprintf(checkIndLogFile1,"\nChildPart:%s",ChildPartDup);
					low_set_add_str_unique(StrUnqPrtList, ChildPartDup);

				}

			}
		  }
		  fprintf(checkIndLogFile1,"\nsetSize(StrUnqPrtList):%d",setSize(StrUnqPrtList));

		d=setSize(StrUnqPrtList);
		aString_test->__size = d;
		aString_test->__ptrPrt = malloc( (aString_test->__size + 100000) * sizeof(*aString_test->__ptrPrt) );


		for(chcnt = 0; chcnt < setSize(StrUnqPrtList); chcnt++)
		{
			if(StrTmpPrt != NULL)
			{
				nlsStrFree(StrTmpPrt); StrTmpPrt = NULL;
			}
			StrTmpPrt = nlsStrDup("-");

			StrTmpPrt = setGetStr(StrUnqPrtList, chcnt);
			fprintf(checkIndLogFile1,"\nStrTmpPrt:%s,",StrTmpPrt);
			aString_test->__ptrPrt[chcnt].prt_no = malloc(30 * sizeof(char *) );
			nlsStrCpy(aString_test->__ptrPrt[chcnt].prt_no,StrTmpPrt);
		}

	//}



	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

return SOAP_OK;

 CLEANUP :
		fprintf(checkIndLogFile1,"\n  Inside CLEANUP:\n");
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
 return SOAP_OK;
EXIT:
	fprintf(checkIndLogFile1,"\n  Inside EXIT \n");
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
   return SOAP_OK;
}