//Sample Web service client
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include "soapH.h"
#include "pronextSOAP.nsmap"


char* Create_Rfi_SOR_ProNext_Frm_WS(char *RfiSor_number,char *RfiSor_desc,char *RevisionR,char *PPPM_Pcode,char *BunitR,char *Design_group,char *GPart_Name,char *Cat,char *Sor_creater,char *Sor_lifrcycle,char *Owner,char *Sor_Vcreater,char *Sor_CDate)

{
	char *val;
	struct _ns1__plm_USCOREto_USCOREpronext_USCORErfi_USCOREsor *stringArg = malloc(sizeof *stringArg);
	//struct _ns1__plm_USCOREto_USCOREpronext_USCOREsorResponse *stringArg1 = malloc(sizeof *stringArg1);
	struct _ns1__plm_USCOREto_USCOREpronext_USCORErfi_USCOREsorResponse *Response;//result
	printf("\n In Create_Rfi_SOR_ProNext_Frm_WS function1---RfiSor_number :%s",RfiSor_number); fflush(stdout);
	
	stringArg->rfi_USCOREsor_USCOREno = RfiSor_number;
	stringArg->rfi_USCOREsor_USCOREdesc = RfiSor_desc;
	stringArg->revision = RevisionR;
	stringArg->pppm_USCOREproject_USCOREcode = PPPM_Pcode;
	stringArg->business_USCOREunit  = BunitR;
	stringArg->tpl = Design_group;
	stringArg->generic_USCOREpart_USCOREname  = GPart_Name;
	stringArg->category  = Cat;
	stringArg->plm_USCOREowner = Sor_creater;
	stringArg->life_USCOREcycle = Sor_lifrcycle;
	stringArg->owner = Owner;
	stringArg->created_USCOREby  = Sor_Vcreater;
	stringArg->created_USCOREdt  = Sor_CDate;
	
	//printf("\n stringArg->part_USCOREnumber :%s",stringArg->part_USCOREnumber); fflush(stdout);

	//SOAP STARTS HERE
	struct soap *	soap = soap_new();
	soap_init1(soap, SOAP_IO_KEEPALIVE); 

	if ((soap_call___ns1__plm_USCOREto_USCOREpronext_USCORErfi_USCOREsor(soap, NULL, NULL,stringArg,Response)) == SOAP_OK) 
	{
		printf("\nstringArg->rfi_USCOREsor_USCOREno :%s",stringArg->rfi_USCOREsor_USCOREno ); fflush(stdout);
		printf("\nstringArg->rfi_USCOREsor_USCOREdesc :%s",stringArg->rfi_USCOREsor_USCOREdesc); fflush(stdout);
		printf("\nstringArg->revision :%s",stringArg->revision); fflush(stdout);
		printf("\nstringArg->pppm_USCOREproject_USCOREcode :%s",stringArg->pppm_USCOREproject_USCOREcode); fflush(stdout);
		printf("\nstringArg->business_USCOREunit :%s",stringArg->business_USCOREunit); fflush(stdout);
		printf("\nstringArg->tpl :%s",stringArg->tpl); fflush(stdout);
		printf("\nstringArg->generic_USCOREpart_USCOREname :%s",stringArg->generic_USCOREpart_USCOREname); fflush(stdout);
		printf("\nstringArg->category :%s",stringArg->category); fflush(stdout);
		printf("\nstringArg->plm_USCOREowner :%s",stringArg->plm_USCOREowner); fflush(stdout);
		printf("\nstringArg->life_USCOREcycle :%s",stringArg->life_USCOREcycle); fflush(stdout);
		printf("\nstringArg->owner :%s",stringArg->owner); fflush(stdout);
		printf("\nstringArg->created_USCOREby :%s",stringArg->created_USCOREby); fflush(stdout);
		printf("\nstringArg->created_USCOREdt :%s",stringArg->created_USCOREdt); fflush(stdout);
		printf("\nResponse: %s \n\n ",Response->result); fflush(stdout);
	}
	else // an error occurred
	{
		printf("\nSOAP_NOT_OK \n");fflush(stdout);
		soap_print_fault(soap, stderr); // display the SOAP fault on the stderr stream
	}

	soap_end(soap);
	soap_free(soap);

	printf("\nFinished\n");

	return 0;
}
