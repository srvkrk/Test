//#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;


int ITK_user_main(int argc,char* argv[])
{
	int		status					=	0;
	int		n_tags_found			=	0;
	int		n_attchs_PO				=	0;
	int		referencenumberfound	=	0;
	int		ireffnd					=	0;

	char	*Tasknumber			=	NULL;
	char	*FilePath			=	NULL;
	char	*FileName			=	NULL;
	tag_t	objTypeTag		=	NULLTAG;
	char	*type_eff		=	NULL;
	char   *ret_id,*ret_rev;

	tag_t	*tags_found			=	NULLTAG;
	tag_t	itemcldclass		=	NULLTAG;
	
	//GRM_relation_t	*rellist_PO;
	tag_t	*rellist_PO;
	tag_t	relationstr		=	NULLTAG;
	Tasknumber	= ITK_ask_cli_argument("-i=");
	//PlantName	= ITK_ask_cli_argument("-pl=");
	FilePath	= ITK_ask_cli_argument("-fp=");

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_auto_login( ));

	printf("\nTask Number : %s",Tasknumber);fflush(stdout);

	if (tc_strlen(Tasknumber)>=10)
	{
		const char *qry_entries[2];
		const char *qry_values[2];

		qry_entries[0] ="item_id";
		qry_entries[1] ="object_type";
		qry_values[0] = Tasknumber;
		if (tc_strlen(Tasknumber)==10)
		{
			//EPA
			qry_values[1] = "T5_EPA";
		}
		else
		{	
			if (tc_strstr(Tasknumber,"STD")!=NULL)
			{
				qry_values[1] = "T5_SMDMLTask";
			}
			else
			{
				qry_values[1] = "T5_APLTask";
			}
		}
		printf("\nqry_values[0] : %s , qry_values[1] : %s",qry_values[0],qry_values[1]);fflush(stdout);
		
		
		ITK_CALL(ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &tags_found));
		printf("\n\nITEM_find_items_by_key_attributes Item_id count in DB is : %d\n",n_tags_found);fflush(stdout);

		if (n_tags_found > 0)
		{
			itemcldclass = tags_found[0];

			tag_t  	item_rev_cld_tag_orig	=	NULLTAG;
			ITK_CALL(ITEM_ask_latest_rev(itemcldclass,&item_rev_cld_tag_orig));
			if (item_rev_cld_tag_orig!=NULLTAG)
			{
			
				
				ITK_CALL(TCTYPE_ask_object_type(item_rev_cld_tag_orig,&objTypeTag));
				ITK_CALL (TCTYPE_ask_name2(objTypeTag,&type_eff));
				printf("\nTaskType : %s",type_eff);fflush(stdout);

				tag_t  reln_type_Reference =NULLTAG;
				//ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&reln_type_Reference));
				ITK_CALL(GRM_find_relation_type("IMAN_reference",&reln_type_Reference));
				//ITKCALL(AOM_ask_value_tags(item_rev_cld_tag_orig,"IMAN_reference",&n_attchs_PO,&rellist_PO));

				//ITK_CALL(GRM_list_secondary_objects(item_rev_cld_tag_orig,reln_type_Reference,&n_attchs_PO,&rellist_PO));
				ITK_CALL(GRM_list_secondary_objects_only(item_rev_cld_tag_orig,reln_type_Reference,&n_attchs_PO,&rellist_PO));
				
				printf("\n Total PO..............%d",n_attchs_PO);fflush(stdout);

				FileName	=	(char*)malloc(tc_strlen(FilePath)+tc_strlen(Tasknumber)+20);
				tc_strcpy(FileName,FilePath);
				tc_strcat(FileName,Tasknumber);
				tc_strcat(FileName,"_NOPO");
				tc_strcat(FileName,".txt");
				printf("\nFilename : %s",FileName);fflush(stdout);

				if (n_attchs_PO>0)
				{
					int	i	=	0;
					for (i= 0; i < n_attchs_PO; i++)
					{
						tag_t	objTypeTag		=	NULLTAG;
						tag_t	secondary		=	NULLTAG;
						char	*type_name		=	NULL;
						//secondary	=	rellist_PO[i].secondary;
						//relationstr	=	rellist_PO[i].the_relation;
						secondary	=	rellist_PO[i];
						//secondary	=	rellist_PO[n_attchs_PO-1];
						//secondary	=	rellist_PO[0];
						ITK_CALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
						ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name));
						printf("\n Type Name:%s ..............",type_name);fflush(stdout);
						
						//objTypeTag	=	NULLTAG;
						//type_name	=	NULL;
						//ITK_CALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
						//ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name));
						//printf("\n Type Name:%s ..............",type_name);fflush(stdout);

						if(secondary!=NULLTAG)
						{
						}
						else
						{
							printf("\nsecondary is NULLTAG");fflush(stdout);
						}
						ITK_CALL(AE_ask_dataset_id_rev(secondary,&ret_id,&ret_rev));

						printf("\nret_id=%s\n",referencenumberfound);

						ITK_CALL(AE_ask_dataset_ref_count(secondary,&referencenumberfound));
						printf("\nreferencenumberfound =%d\n",referencenumberfound);
						
						int	j	=	0;
						for(j=0;j<referencenumberfound;j++)
						{
							printf("\n--------inside referencenumberfound---------------------\n");
							char*   refname;
							AE_reference_type_t     reftype;
							tag_t	refobject	=	NULLTAG;
							ITK_CALL(AE_find_dataset_named_ref2(secondary,j,&refname,&reftype,&refobject));
							printf("\n ---name ref type ----- :%s\n",refname);
							
							if (refobject!=NULLTAG)
							{
								ireffnd++;
							}
							else
							{
								ireffnd	=	0;
							}
							char*   orig_name;
							ITK_CALL( IMF_ask_original_file_name2(refobject,&orig_name));
							
//							FileName	=	(char*)malloc(tc_strlen(FilePath)+tc_strlen(Tasknumber)+20);
//							tc_strcpy(FileName,FilePath);
//							tc_strcat(FileName,Tasknumber);
//							tc_strcat(FileName,"_NOPO");
//							tc_strcat(FileName,".txt");
//							printf("\nFilename : %s",FileName);fflush(stdout);

							printf("\n orig_name is :%s \n",orig_name);
							char   pathnamePdf[SS_MAXPATHLEN + 1];
							//sprintf(pathnamePdf,"%s/%s",FilePath,orig_name );
							sprintf(pathnamePdf,"%s",FileName );
							IMF_export_file(refobject,pathnamePdf); //commented for testing
							
							//Text
//							printf("\nRef name : %s, original file name : %s",refname,Tasknumber);fflush(stdout);
//							if (tc_strcmp(refname,"Text")==0 && tc_strstr(orig_name,Tasknumber)!=NULL)
//							{
//								printf("PO Report found...!!!\n");fflush(stdout);
//
//								IMF_file_t 	file_descriptor	 =	NULLTAG;
//								ITK_CALL(IMF_ask_file_descriptor(refobject,&file_descriptor));
//
//								int 	ss_file_access_mode	 =	SS_RDONLY ;
//
//								char	*text_line	=	NULL;
//								ITK_CALL(IMF_open_file(file_descriptor,ss_file_access_mode ));
//								int	flread	=	0;
//								do
//								{
//									text_line	=	NULL;
//									flread	=	(IMF_read_file_line2(file_descriptor,&text_line));
//									
//									if (tc_strstr(text_line,"PO is not available in SAP for Below Parts")!=NULL)
//									{
//										
//										printf("%s",text_line);fflush(stdout);		
//										printf("Fl read : %d\n",flread);fflush(stdout);
//									}
//								}
//								while (flread!=1104);
								

//								flread	=	0;
//								text_line	=	NULL;
//								flread	=	(IMF_read_file_line2(file_descriptor,&text_line));
//								printf("\n%s",text_line);fflush(stdout);
//								printf("\nFl read : %d",flread);fflush(stdout);
//
//								flread	=	0;
//								text_line	=	NULL;
//								flread	=	(IMF_read_file_line2(file_descriptor,&text_line));
//								printf("\n%s",text_line);fflush(stdout);
//								printf("\nFl read : %d",flread);fflush(stdout);
//
//								flread	=	0;
//								text_line	=	NULL;
//								flread	=	(IMF_read_file_line2(file_descriptor,&text_line));
//								printf("\n%s",text_line);fflush(stdout);
//								printf("\nFl read : %d",flread);fflush(stdout);
//
//								flread	=	0;
//								text_line	=	NULL;
//								flread	=	(IMF_read_file_line2(file_descriptor,&text_line));
//								printf("\n%s",text_line);fflush(stdout);
//								printf("\nFl read : %d",flread);fflush(stdout);
//
//								flread	=	0;
//								text_line	=	NULL;
//								flread	=	(IMF_read_file_line2(file_descriptor,&text_line));
//								printf("\n%s",text_line);fflush(stdout);
//								printf("\nFl read : %d",flread);fflush(stdout);
//
//								flread	=	0;
//								text_line	=	NULL;
//								flread	=	(IMF_read_file_line2(file_descriptor,&text_line));
//								printf("\n%s",text_line);fflush(stdout);
//								printf("\nFl read : %d",flread);fflush(stdout);

//							}
						}
						if(ireffnd>0)
						{
							break;
						}
					}
				}
			}
			else
			{
				printf("\n NULLTAG found");fflush(stdout);
				FILE	*DML_EPA			=	NULL;
				DML_EPA=fopen(FileName,"w");
				fflush(DML_EPA);
				fprintf(DML_EPA,"-1");fflush(DML_EPA);
			}

		}
		else
		{
			printf("\nTASK or EPA not found...!!!");fflush(stdout);
		}
	}

}