//gsoap ns service name:				 PartDataExpansionNew
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:PartDataExpansionNew
//gsoap ns service location:			 http://172.22.99.106:9080/cgi/PartDataExpansionNew.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:PartDataExpansionNew
//gsoap ns service method-documentation: Module name web service


int ns__PartDataExpansionNew(char *userId,char *password,char *prtNumber,char *prtRevisionId,char *prtSequence,char* hostname1,char **Response);
