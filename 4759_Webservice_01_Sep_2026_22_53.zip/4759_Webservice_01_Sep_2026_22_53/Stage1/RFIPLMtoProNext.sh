rm -f RFIPLMtoProNext.a soapC.o soapClient.o stdsoap2.o RFIPLMtoProNext.o
./wsdl2h -c -o RFIPLMtoProNext.h http://172.22.97.50:8080/pFirst_SOA/cgi/service.cgi?action=pronext1
./soapcpp2  -1 -e -c -C RFIPLMtoProNext.h
cp /user/testcmi/Dev/devgroups/shrivardhan/ProNxtWebQA/stdsoap2.h .
cp /user/testcmi/Dev/devgroups/shrivardhan/ProNxtWebQA/stdsoap2.c .
cc -c -fPIC soapC.c
cc -c -fPIC soapClient.c
cc -c -fPIC stdsoap2.c
cc -c -fPIC RFIPLMtoProNext.c
ar -cr RFIPLMtoProNext.a soapC.o soapClient.o stdsoap2.o RFIPLMtoProNext.o

