//gsoap ns service name:				 GrpChildRelWS
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:GrpChildRelWS  
//gsoap ns service location:			 http://172.22.99.106:9080/cgi/GrpChildRelWS.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:GrpChildRelWS 
//gsoap ns service method-documentation: Tests the Simple Web service

struct ns__plmPrtDet
{   
   char *prt_no;
   //char *Response;
   
}
;
struct ns__CharArray1 
{
   struct ns__plmPrtDet *__ptrPrt;
   int __size;
}
; 

//int ns__getGrpChildRelWS(char *Grp_prt,char *Plant, struct ns__CharArray1 *aString_test);
int ns__getGrpChildRelWS(char *Grp_prt,char *Plant, char *Release_status, struct ns__CharArray1 *aString_test);
