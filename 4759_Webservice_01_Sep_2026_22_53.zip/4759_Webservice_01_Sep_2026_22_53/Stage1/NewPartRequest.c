//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================
#include "soapH.h"
#include "NewPartRequest.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   // ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
	//fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;



int ns__getItemData(struct soap* soap,char *NPR_no,struct ns__CharArray1 *aString_test)
{
        int ifail =0;
		int i,j = 0;
		int n_tags_found = 0;
		int num = 0;
		int d = 0;
		int row = 7;

		tag_t *tags_found = NULLTAG;
		tag_t item_t = NULLTAG;
		tag_t itemRev_t = NULLTAG;

		char*	tml_part_no		= NULL;
		

		
		char*			responseString1			= NULL;
		

		
		//const char* u = NULL;
		//const char* p = NULL;
		//const char* g = NULL;

		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/NewPartRequest.txt", "w", stdout);
		//CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//u = ITK_ask_cli_argument( "-u=ercjsup");
		//p = ITK_ask_cli_argument( "-p=Tcua_tst@789");
		//g = ITK_ask_cli_argument( "-g=dba");
		//if (ITK_init_module(u,p,g) == ITK_ok )
		//{


		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		



		printf("\n Input .. %s",NPR_no);fflush(stdout);
		if((NPR_no !=NULL) && (tc_strcmp(NPR_no,"")!=0))
		{
			const char *attrs[2];
			const char *values[2];
			attrs[0] ="item_id";
			attrs[1] ="object_type";
			values[0] = (char *)NPR_no;
			values[1] = "New Part Request";
			printf("\n values[0] <%s> \n",values[0] );fflush(stdout);

			ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);

			printf("\n Tag Found <%d> \n",n_tags_found );fflush(stdout);
			if(n_tags_found>0)
			{
				responseString1=(char *)MEM_alloc(100);
				

				item_t = tags_found[0];
				ITEM_ask_latest_rev(item_t,&itemRev_t);
				//itemRev_t = tags_found[0];
				AOM_ask_value_string(item_t,"t5_NwTmlPtNo",&tml_part_no);
				printf("\n PartNumber <%s> \n",tml_part_no);fflush(stdout);
				tc_strcpy(responseString1,"PartNumber:");
				tc_strcat(responseString1,tml_part_no);

				aString_test-> __size =1;
				aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
				for(i=0;i<1;i++)
				{
					aString_test->__ptrItem[i].TM_PART_NO = malloc(30 * sizeof(char *));
					strcpy(aString_test->__ptrItem[i].TM_PART_NO,responseString1); // TML PART NUMBER					
				}
			}
		}///
		//}
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

		return SOAP_OK;
}

