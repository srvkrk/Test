#define _CLMAIN_DEFNS
#define _CLMAIN_DEFNS
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include "soapH.h"
#include "CheckPartInGrpIDInTCE.nsmap"


int main(int argc, char *argv[])
{
	t5MethodInitWMD("CheckPartInGrpIDInTCE");
	t5CheckDstat(clInitMB2 (argc,&argv,NULL)); 
	EXIT:
	return soap_serve(soap_new()); /* call the request dispatcher */
}
//int ns__CheckPartInGrpIDInTCE(struct soap* soap,char* Item_id_par,char* GroupID,char **Response)
//{
//	char* mod_name="ns__getNoPOPartsDetailsData";
//
//	char *ResponseString;
//	char *NewGrpId;
//	FILE *fp = NULL ;
//
//	//if (dstat = clInitialize2 (TRUE)) goto CLEANUP;
//
//	ResponseString = (char *) malloc( (50) * sizeof(char));
//	NewGrpId = (char *) malloc( (45) * sizeof(char));
//
//	//*Response = (char *) malloc( (50) * sizeof(char));
//
//	fp = fopen("CheckPartInGrpIDInTCE.txt","a");
//
//	fprintf(fp,"\n Login Success....");fflush(fp);
//
//	fprintf(fp, "\nConencting to CheckPartInGrpID [%s] [%s]",Item_id_par,GroupID);fflush(fp);
//
//	strcpy(ResponseString,"Group");
//	strcat(ResponseString,"ID Present");
//
//
//	//strcpy(*Response,ResponseString);
//	Response=&ResponseString;
//	
//	return SOAP_OK;
//
//CLEANUP :
//	return SOAP_OK;
//EXIT:
//	if (fp)
//	{
//		fclose(fp);
//	}
//	return SOAP_OK;
//}

int ns__CheckPartInGrpIDInTCE(struct soap* soap,char* Item_id_par,char* GroupID,char **Response)
{
	char* mod_name="ns__CheckPartInGrpIDInTCE";

	//int stat = OKAY;

	SetOfObjects    partObjSO              =   NULL;
	SqlPtr          sqlDIQry                 =   NULL;
	SET_PTR		OwnerSet			= NULL;

	//int d =0;
	int i,ii =0;
	//printf("hiiiiiiiiii "); 
	string   uname   = NULL;
	string   pass   = NULL;
	string   responseString = NULL;
	string   MakeBuyStr = NULL;
	string   StoreLocStr = NULL;
	string viewName = NULL;
	string sLCSStat = NULL;
	string sLCSStatDup = NULL;

	SetOfStrings dbScp				= NULL;
	SetOfStrings docobjst			= NULL;
	SetOfStrings outputStringSet	= NULL;
	SetOfObjects	soPrt			= NULL;
	ObjectPtr	ParentObjP			= NULL;
	string		ParentGroupIdDupS	= NULL;
	string		ParentGroupIdS		= NULL;
	string		rightObjPartNum		= NULL;
	string		rightObjPartNumDup	= NULL;
	string		SupersNameS			= NULL;
	string		SupersNameDupS		= NULL;
	string		ParentObjOrgidDup	= NULL;
	string		ParentObjOrgid		= NULL;
	string		sDispLifeCycle		= NULL;
	int			UsedInGrIDFlag		= 0;
	SetOfObjects	soPrtRel		= NULL;
	ObjectPtr		ContextObjPNew	= NULL;
	ObjectPtr		GenContextObjPNew	= NULL;
	//FILE *ptr = NULL;
	ObjectPtr mypartPtr = NULL;
	status dstat = OKAY;
	int mfail =USC_OKAY;


	FILE *fp = NULL ;

	SET_PTR LcsSet =  NULL;

	
	uname = nlsStrAlloc(10);
	pass = nlsStrAlloc(10);
	viewName = nlsStrAlloc(5);

	outputStringSet = setStrCreate(1);

	LcsSet = low_set_create_str(8);

	//char *inputProjectName;
	

	//nlsStrCpy(uname,"Loader");
	//nlsStrCpy(pass,"123loader");

	//if (dstat = clTestNetwork ()) goto CLEANUP;
	//printf("\n[%s] [%s]\n",uname,pass);fflush(stdout);
	/*	Initialize the command line session.	*/
	if (dstat = clInitialize2 (TRUE)) goto CLEANUP;
	//printf("hiiiiiiiiii "); 
	//system("serverlogin > cd.txt");

	*Response = (char *) malloc( (50) * sizeof(char));

	//ptr = freopen("TR.txt", "w", stdout);

	//fp = fopen("CheckPartInGrpIDInTCE.txt","a");

	//fprintf(fp,"\n Login Success....");fflush(fp);


	//fprintf(fp, "\nConencting to CheckPartInGrpID");fflush(fp);

	nlsStrCpy(viewName,"ERC");

	//////////////////////////DB SCOPE///////////
	t5CheckDstat(GetDatabaseScope("PdmSessn",&dbScp,&mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			//printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}
	set_add_str_unique(dbScp, "supprod");
	set_add_str_unique(dbScp, "suhprod");
	//set_add_str_unique(dbScp, "sujprod");
	//set_add_str_unique(dbScp, "sulprod");
	t5CheckDstat(SetDatabaseScope("PdmSessn",dbScp,&mfail));
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,&mfail));
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
				docobjst=low_set_get(dbScp,ii);
			//printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}

	MakeBuyStr = nlsStrAlloc(500);
	StoreLocStr = nlsStrAlloc(500);
	OwnerSet = low_set_create_str(8);

	if (dstat = oiSqlCreateSelect(&sqlDIQry)) goto EXIT;
	if (dstat = oiSqlWhereEQ(sqlDIQry,PartNumberAttr,Item_id_par)) goto EXIT;
	if (dstat = oiSqlWhereAND(sqlDIQry)) goto EXIT;
	if (dstat = oiSqlWhereEQ(sqlDIQry,SupersededAttr,"-")) goto EXIT;
	if (dstat = QueryWhere(PartClass,sqlDIQry,&partObjSO,&mfail)) goto EXIT;


	//printf("\nTOTAL SET SIZE = %d\n",setSize(partObjSO));fflush(stdout);

    /* Initializing structure array  */
	//responseString=nlsStrAlloc(2000);

	//TR LC state not equal to submitted/ close
	// objct Signoff histroy claimed /unclaimed 

	//fprintf(fp, "\n partObjSO size: %d",setSize(partObjSO));fflush(fp);

	if(setSize(partObjSO)>0)
	{
		//printf("\nIn If loop...\n");fflush(stdout);
 
		responseString=nlsStrAlloc(100);
		sDispLifeCycle=nlsStrAlloc(50);
		
		//fprintf(fp, "\n Inside if condition");fflush(fp);

		for (i=0;i<setSize(partObjSO) ;i++ )
	    {
			mypartPtr=low_set_get(partObjSO,i);

			if(dstat=objGetAttribute(mypartPtr, LifeCycleStateAttr, &sLCSStat))goto EXIT;
			if(!nlsIsStrNull(sLCSStat))
			{
				sLCSStatDup = nlsStrDup (sLCSStat);
			}
			
			//fprintf(fp, "\n expanding object now %s",sLCSStatDup);fflush(fp);

			if(SetUpContext(objClass(mypartPtr),mypartPtr,&GenContextObjPNew,&mfail));
			/* Get the configuration context object from the general context. */
			if(GetCfgCtxtObjFromCtxt(DSesGnCClass,GenContextObjPNew,&ContextObjPNew,&mfail));
			/* Set the option as "Latest Revision with State" in the context object */
			t5CheckDstat(objSetAttribute(ContextObjPNew,ExpandOnRevisionAttr, "PscLastRev"));
			t5CheckDstat(objSetAttribute(ContextObjPNew,"NavigateViewBitPos","0"));
			t5CheckDstat(objSetAttribute(ContextObjPNew,"CfgItemId","GlobalCtxt"));
			t5CheckDstat(objSetAttribute(ContextObjPNew,NavigateViewNetworkAttr,"EAS"));
			t5CheckDstat(objSetAttribute(ContextObjPNew,NavigateViewNameAttr,"ERC"));
			t5CheckDstat(objSetAttribute(ContextObjPNew,PsmExpIncludeZeroQtyAttr,"+"));
			t5CheckDstat(objSetObject(GenContextObjPNew,ConfigCtxtBlobAttr, ContextObjPNew));

			if (dstat = ExpandRelationWithCtxt(AsRevRevClass,mypartPtr,"AssembliesWherePartIsUsed",GenContextObjPNew,SC_SCOPE_OF_SESSION,NULL,&soPrt,&soPrtRel,&mfail))goto EXIT;
			
			//fprintf(fp, "\n expantion done: %d",setSize(soPrt));//207354601606 G218281
			fflush(fp);
			if(setSize(soPrt)>0)
				{
					for(ii=0;ii<setSize(soPrt);ii++)
					{
						ParentObjP=setGet(soPrt,ii);

						if (dstat = objGetAttribute(ParentObjP,ClassAttr,&ParentGroupIdDupS)) goto EXIT;
						if(ParentGroupIdDupS) ParentGroupIdS=nlsStrDup(ParentGroupIdDupS);

						if (dstat = objGetAttribute(ParentObjP,PartNumberAttr,&rightObjPartNumDup)) goto EXIT;
						if(rightObjPartNumDup) rightObjPartNum=nlsStrDup(rightObjPartNumDup);

						//printf("\nRight object partnumber-->%s\n",rightObjPartNum);fflush(stdout);

						if (dstat = objGetAttribute(ParentObjP,SupersededAttr,&SupersNameDupS)) goto EXIT;
						if(SupersNameDupS) SupersNameS=nlsStrDup(SupersNameDupS);
						//printf("\nsuperseded value for all group ids is newly-->%s\n",SupersNameS);fflush(stdout);

						if (dstat = objGetAttribute(ParentObjP,OrganizationIDAttr,&ParentObjOrgidDup)) goto EXIT;
						if(ParentObjOrgidDup) ParentObjOrgid=nlsStrDup(ParentObjOrgidDup);
						//printf("\nParentObjOrgidDup of parent part-->%s\n",ParentObjOrgid);fflush(stdout);
						
						//fprintf(fp, "\n Got properties");fflush(fp);

						if(nlsStrCmp(ParentGroupIdS,"t5GrpID")==0)
							{
								if(nlsStrCmp(ParentObjOrgid,"ERC")==0)
								{
									if((nlsStrCmp(SupersNameS,"-")==0) && (nlsStrCmp(rightObjPartNum,GroupID)!=0))
									{
										UsedInGrIDFlag=1;
										break;
									}
								}
							}
							else
							{
								continue;
							}
					}
				}
				if(UsedInGrIDFlag==1)
				{

					nlsStrCpy(responseString,"");
					//fprintf(ptr,"RqNoDup: %s",RqNoDup);					
					nlsStrCat(responseString,rightObjPartNum);
					//fprintf(ptr,"responseString: %s",responseString);
					//aString_test4->__ptr[i] = (char *) malloc( (1500) * sizeof(char));

					strcpy(*Response, responseString);
					//fprintf(fp, "\nResponse1:%s",*Response);fflush(fp);

				}
				else
				{
					//d=1;	aString_test4->__size = d;
					//aString_test4->__ptr = malloc( (aString_test4->__size + 1) * sizeof(*aString_test4->__ptr) );

					//responseString=nlsStrAlloc(10);
					nlsStrCpy(responseString,"NA");
					//aString_test4->__ptr[0] = (char *) malloc( (10) * sizeof(char));
					nlsStrCpy(*Response, responseString);
					//fprintf(fp, "\nResponse1:%s",*Response);fflush(fp);
				}
	    }
	}
	else 
	{
		//printf("\nIn else loop...\n");fflush(stdout);

		//d=1;	aString_test4->__size = d;
		//aString_test4->__ptr = malloc( (aString_test4->__size + 1) * sizeof(*aString_test4->__ptr) );

		responseString=nlsStrAlloc(10);
		nlsStrCpy(responseString,"NA");
		//aString_test4->__ptr[0] = (char *) malloc( (10) * sizeof(char));
		nlsStrCpy(*Response, responseString);
		//fprintf(fp, "\nResponse1:%s",*Response);fflush(fp);
	}

	return SOAP_OK;

 CLEANUP :
	    //printf("INSIDE CLEANUP");
		return SOAP_OK;
EXIT:
//	if (fp)
//	{
//		fclose(fp);
//	}
		return SOAP_OK;
}
