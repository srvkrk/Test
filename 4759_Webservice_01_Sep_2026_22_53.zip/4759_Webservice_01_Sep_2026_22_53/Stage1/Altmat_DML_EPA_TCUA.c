/********************************************************************************************************************************************************************
File Name	:	Altmat_DML_EPA_TCUA.c
Purpose		:	Query the  partand DML, find Relation between Part and DML task
				
Date		:	27-feb-2023
Modification:	27-Feb-2023	: created code for first time.Nana Keskar
********************************************************************************************************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <pie/pie.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100


static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;


int ITK_user_main(int argc,char* argv[])
{
	FILE	*GRP_CHILD;
	int		status				=	0;
	int		cntrev				=	0;
	int		iChildItemTag		=	0;
	int		iLength				=	0;
	int		igchild				=	0;
	int		i					=	0;
	int		ichk				=	0;
	int		ifnd				=	0;

	char*	cGroupPart			=	NULL;
	char*	FilePath			=	NULL;
	char*	cFilename			=	NULL;
	char*	cFirstChar			=	NULL;

	//Group Part attributes starts
	char*	cGrpPrtNum			=	NULL;
	char*	cGrpPrtRev			=	NULL;
	char*	cgchildnum			=	NULL;
	char*	Response			=	NULL;
	char*	cDMLno				=	NULL;
	char*	tempErr				=	NULL;
	char*	TasksPrtNo				=	NULL;
	//Group Part attributes ends

	tag_t	t_GrpPrt			=	NULLTAG;
	tag_t	t_GrpPrtRev			=	NULLTAG;
	tag_t	t_gchildtag			=	NULLTAG;
	tag_t	t_gchildtag_bvr		=	NULLTAG;

	tag_t*	t_GrpPrtRevs		=	NULLTAG;
	tag_t	CDMLtags		=	NULLTAG;
	tag_t*	DMLTasksTagg		=	NULLTAG;
	tag_t*	PartTasksTagg		=	NULLTAG;
	tag_t	CDMLtagRev		=	NULLTAG;
	tag_t	CDMLtag		=	NULLTAG;
	tag_t	dml_task_rel_type		=	NULLTAG;
	tag_t	DMLTaskTagg		=	NULLTAG;
	tag_t	Part_task_rel_type		=	NULLTAG;
	tag_t	PartTaskTagg		=	NULLTAG;
	
	int	StructCntBdyShProdPlan	= 0;

	char	**SetChildRelErr	=	NULL;
	int		icount				=	0;
	int		count_DMLtasks				=	0;
	int		t				=	0;
	int		count_Parttasks				=	0;
	int		prtfoundflg,p		=	0;

	cGroupPart	= ITK_ask_cli_argument("-i=");
	cDMLno	= ITK_ask_cli_argument("-d=");
	FilePath	= ITK_ask_cli_argument("-fp=");

	ITK_CALL(ITK_initialize_text_services(ITK_BATCH_TEXT_MODE));
	ITK_CALL(ITK_set_journalling(TRUE));
	ITK_CALL(ITK_auto_login());

	printf("Group Part : %s, DML No is %s, File Path : %s",cGroupPart,cDMLno,FilePath);fflush(stdout);

	
	cFilename	=	(char*)malloc(tc_strlen(FilePath)+tc_strlen(cGroupPart)+20);
	tc_strcpy(cFilename,FilePath);
	tc_strcat(cFilename,cGroupPart);
	tc_strcat(cFilename,"_Altmat_UA.txt");

	printf("\nFile Name : %s",cFilename);fflush(stdout);
		printf("\nFile Name : %s",cFilename);fflush(stdout);

			GRP_CHILD	=	fopen(cFilename,"w+");

	if (cGroupPart!=NULL)
	{
		printf("\nGroup part is not NULL");fflush(stdout);
		//cFirstChar	=	subString(cGroupPart,0,1);
		//printf("\nFirst character : %s",cFirstChar);fflush(stdout);

		
		
			ITKCALL (ITEM_find_item(cGroupPart, &t_GrpPrt));
			if (t_GrpPrt!=NULLTAG)
			{
				ITKCALL (ITEM_ask_latest_rev(t_GrpPrt, &t_GrpPrtRev));

				ITKCALL(ITEM_list_all_revs (t_GrpPrt, &cntrev, &t_GrpPrtRevs));

				if (t_GrpPrtRev!=NULLTAG)
				{
					ITKCALL(AOM_ask_value_string(t_GrpPrtRev,"item_id",&cGrpPrtNum));
					printf("\n\n\t\t cGrpPrtNum  is :%s",cGrpPrtNum);	fflush(stdout);

					AOM_UIF_ask_value(t_GrpPrtRev,"item_revision_id",&cGrpPrtRev);
					printf("\n\n\t cGrpPrtRev--->%s",cGrpPrtRev);

                       ITKCALL (ITEM_find_item(cDMLno, &CDMLtag));
					if (CDMLtag!=NULLTAG)
					{
						//CDMLtag=CDMLtags[0];
                    ITKCALL (ITEM_ask_latest_rev(CDMLtag, &CDMLtagRev));
					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&dml_task_rel_type));
					ITKCALL(GRM_list_secondary_objects_only(CDMLtagRev,dml_task_rel_type,&count_DMLtasks,&DMLTasksTagg));
					if (count_DMLtasks>0)
					{

                     for (t=0; t<count_DMLtasks;t++ )
                     {
						 DMLTaskTagg=DMLTasksTagg[t];

					ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&Part_task_rel_type));
					ITKCALL(GRM_list_secondary_objects_only(DMLTaskTagg,Part_task_rel_type,&count_Parttasks,&PartTasksTagg));
					if (count_Parttasks>0)
					{
						for (p=0;p<count_Parttasks; p++)
						{
							PartTaskTagg=PartTasksTagg[p];

						ITKCALL(AOM_ask_value_string(PartTaskTagg,"item_id",&TasksPrtNo));
					             printf("\n\n\t\t TasksPrtNo  is :%s",TasksPrtNo);	fflush(stdout);


								 if (tc_strcmp(cGrpPrtNum,TasksPrtNo)==0)
								 {
									 Response="1,";
									 fprintf(GRP_CHILD,"%s",Response);fflush(GRP_CHILD);
											//fprintf(GRP_CHILD,"%s",tempErr);fflush(GRP_CHILD);
											prtfoundflg=1;
											break;                              
								 }

						}
					}

if (prtfoundflg==1)
{
	break; 
}
					

                     }
					if (prtfoundflg==1)
					 {
						printf("\n\n\t\t Part %s and DML %s Relation found",TasksPrtNo,cDMLno);	fflush(stdout);
						
					 }
					 else
						{
						 		 Response="0,";
							fprintf(GRP_CHILD,"%s",Response);fflush(GRP_CHILD);					 
					 
					  }
					}

					   
					   
					   }

  			}
				else
				{
					printf("\nLatest rev tag is nulltag");fflush(stdout);
				}
			}
			else
			{
				printf("t_GrpPrt is NULLTAG");fflush(stdout);
			}
					
	}
	else
	{
		printf("\nGroup part is NULL");fflush(stdout);
	}

	//GRP_CHILD	=	fopen(cFilename,"w");

	ITK_CALL(POM_logout(false));
	return ITK_ok;
}