#include "soapH.h"								/* get the gSOAP-generated definitions */
#include "tm_SAPartCreate.nsmap"		 /* get the gSOAP-generated namespace bindings */

 #define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
//#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <fclasses/tc_string.h>
//#include <epm/cr_effectivity.h>
#include <tc/folder.h>



#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define Debug TRUE
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}

// int X;
// int status;
// #define ITK_CALL 	 \
// status=X; 	 \
// if (status != ITK_ok)  	 \
// {	 \
// int	 index = 0;	 \
// int	 n_ifails = 0;	 \
// const int*	 severities = 0;	 \
// const int*	 ifails = 0;	 \
// const char**	texts = NULL;	 \
// \
// EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
// printf("%3d error with #X\n", n_ifails);	 \
// for( index=0; index<n_ifails; index++)	 \
// {	 \
// printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
// }	 \
// return status;	 \
// }	 \
// ;

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

FILE	*SAPartCreateLog;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

//this function will return output as by reversing a string as per input
void revstr(char *str1)
{
    int i, len, temp;
    len = tc_strlen(str1);
    for (i = 0; i < len/2; i++)
    {
        temp = str1[i];
        str1[i] = str1[len - i - 1];
        str1[len - i - 1] = temp;
    }
}
//This function will increase by one digit as per given input part number. for example i/p: 54426010M10011   o/p:- 54426010M10012
void GetNextPartNumberCount(char *ltst_Part,int t)
{
	if(ltst_Part[t]=='0')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='1')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='2')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='3')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='4')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='5')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='6')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='7')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='8')
	{
		ltst_Part[t]=ltst_Part[t]+1;
	}
	else if(ltst_Part[t]=='9')
	{
		ltst_Part[t]=48;
		t++;
		GetNextPartNumberCount(ltst_Part,t);
	}
}

//this function will create Part in TCUA as per user requested/input.
//void t5CreatePart(char *ipPartNum)
//{
//	int				n_strings			=	1;
//	int				l_strings			=	500;
//	int				index				=	0;
//
//	char	**display_value;
//	char	*tempStringt	=	NULL;
//
//	tag_t	t_dsgtyp	=	NULLTAG;
//	tag_t	t_dsgrevtyp	=	NULLTAG;
//	tag_t	t_dsgcre	=	NULLTAG;
//	tag_t	t_dsgrevcre	=	NULLTAG;
//	tag_t	t_dsgtag = NULLTAG;
//	char *project_code=NULL;
//	char *designGroup=NULL;
//	char *temp=NULL;
//	int max_char_size = 80;
//
//	project_code = (char *)MEM_alloc(max_char_size * sizeof(char));
//	designGroup = (char *)MEM_alloc(max_char_size * sizeof(char));
//	temp = (char *)MEM_alloc(max_char_size * sizeof(char));
//
//	tc_strcpy(temp,ipPartNum);
//
//	project_code = subString(temp,0,4);
//	designGroup = subString(temp,4,2);
//
//	display_value = (char**)malloc( n_strings * sizeof *display_value );
//	for( index=0; index<n_strings; index++ )
//	{
//		display_value[index] = (char*)malloc( l_strings + 1 );
//	}
//	printf("\nInside tm_create_design : %s",ipPartNum);fflush(stdout);
//
//	ITK_CALL(TCTYPE_find_type("Design",NULL,&t_dsgtyp));
//	if (t_dsgtyp!=NULLTAG)
//	{
//		printf("\nnonclr t_dsgtyp is not null tag");fflush(stdout);
//	}
//	ITK_CALL(TCTYPE_construct_create_input(t_dsgtyp,&t_dsgcre));
//
//	ITK_CALL(TCTYPE_find_type("Design Revision",NULL,&t_dsgrevtyp));
//	ITK_CALL(TCTYPE_construct_create_input(t_dsgrevtyp,&t_dsgrevcre));
//
//	tc_strcpy(display_value[0],ipPartNum);
//	ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"item_id",1,(const char**)display_value));
//	ITK_CALL( AOM_tag_to_string(t_dsgrevcre, &tempStringt));
//	tc_strcpy(display_value[0],tempStringt);
//	ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"revision",1,(const char**)display_value));
//	tc_strcpy( display_value[0], "NR;1");
//	ITK_CALL( TCTYPE_set_create_display_value( t_dsgrevcre, "item_revision_id", 1,(const char**)display_value));
//	tc_strcpy( display_value[0], project_code);
//	ITK_CALL( TCTYPE_set_create_display_value( t_dsgrevcre, "t5_ProjectCode", 1,(const char**)display_value));
//	tc_strcpy( display_value[0], "SA");
//	ITK_CALL( TCTYPE_set_create_display_value( t_dsgrevcre, "t5_PartType", 1,(const char**)display_value));
//	tc_strcpy( display_value[0], designGroup);
//	ITK_CALL( TCTYPE_set_create_display_value( t_dsgrevcre, "t5_DesignGrp", 1,(const char**)display_value));
//
//	ITK_CALL( TCTYPE_create_object( t_dsgcre, &t_dsgtag) );
//	ITK_CALL(AOM_save(t_dsgtag));
//
//}

//this function will check given part is available in TCUA or not.
//int CheckPartIsExistInPlm(char *Part)
//{
//	int status;
//	int X;
//	const char *qry_entries[1];
//	const char *qry_values[1];
//
//	int n_tags_found=0;
//	tag_t*		itemclass	= NULLTAG;
//	tag_t		item		= NULLTAG;
//
//	qry_entries[0] ="item_id";
//	qry_values[0] = Part;
//	ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
//	if(n_tags_found>0)
//	{
//		return 1;
//	}
//	else
//	{
//		return 0;
//	}
//}

//this function will check wether the user requested part is available in TCUA, if available Next part number will generate, if not available it will create new part with 0001 and return.
char *GetNextPartNumber(char *InputPart)
{

	int status;
	int X;
	int counter,z =0;
	int ifail = 0;

	int max_char_size = 80;
	int		n_entries	=	1;
	char *counterString=NULL;
	char *initialStringNumber=NULL;
	int    	num_to_sort =	1;
	char 	*Part_Name = NULL;
	char 	*Part = NULL;

	char 	*InputPartDup = NULL;
	int  	orders[1]  	=	{2};
	int		n_found		=	0;
	tag_t   *results	=	NULLTAG;
	tag_t   partTag = NULLTAG;
	tag_t	queryPart	=	NULLTAG;


	initialStringNumber = (char *)MEM_alloc(max_char_size * sizeof(char));
	counterString = (char *)MEM_alloc(max_char_size * sizeof(char));
	InputPartDup = (char *)MEM_alloc(max_char_size * sizeof(char));
	Part_Name = (char *)MEM_alloc(max_char_size * sizeof(char));
	Part = (char *)MEM_alloc(max_char_size * sizeof(char));

	tc_strcpy(InputPartDup,InputPart);

	tc_strcat(InputPartDup,"*");

	char 	*keys[1] 	= 	{"creation_date"};
	char 	*qry_part_entries[2]= {"Item ID","t5_PartType"};
	char 	*qry_part_values[2]={InputPartDup,"SA"};

	ifail = ITK_init_module("am927460.ttl","TATAMotors@123","PLM_Support_Group");

	if(ifail==1)
	{
		printf("\n Login successful\n");fflush(stdout);
	}
	else
	{
		printf("\n Login Failed\n");fflush(stdout);
	}
	ITK_set_journalling( TRUE );

	ITK_CALL(QRY_find2("Item Revision...", &queryPart));
	ITK_CALL(QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results));
	if(tc_strlen(InputPart)==10)
	{
		if(n_found>0)
		{
			partTag = results[0];
			AOM_ask_value_string(partTag, "item_id", &Part_Name);
			printf("\n Part_Name : %s\n",Part_Name);fflush(stdout);

			revstr(Part_Name);
			GetNextPartNumberCount(Part_Name,0);
			revstr(Part_Name);
			printf("if condition Part Number is %s\n",Part_Name);
			tc_strcpy(Part,Part_Name);
			//t5CreatePart(Part);
		}
		else
		{
			tc_strcat(Part_Name,InputPart);
			tc_strcat(Part_Name,"0001");
			printf("else condition Part Number is %s\n",Part_Name);
			tc_strcpy(Part,Part_Name);
			//t5CreatePart(Part);
		}
	}
	else
	{
		printf("Invalid Input\n");
	}
	return Part_Name;
}

//This Webservice function taking 10 digit partnumber as input, and returning 14digit part number as output.
int ns__SANumberingPartCreate(struct soap* soap, char *PartNumber,char **Response)
{

	//FILE     *inputfile    =NULL;
	int status =0;
	int X;
	int d =2;
	int i,j,k=0;
	int ifail  =  0;
	int stop=0;
	int y,z=0;
	int check=0;
	char *InputPart =NULL;
	char *temp =NULL;

	char *optupt_part=NULL;
	char *initialStringNumberdup=NULL;

	int max_char_size = 80;
	char *ExeLogFile =	NULL;

	// ITK_initialize_text_services( ITK_BATCH_TEXT_MODE);
	// ITK_auto_login();

	ExeLogFile = (char	*)MEM_alloc(100);
	tc_strcpy(ExeLogFile,"");
	tc_strcpy(ExeLogFile,"/tmp/");
	tc_strcat(ExeLogFile,PartNumber);
	//tc_strcat(ExeLogFile,"_");
	//tc_strcat(ExeLogFile,Plant);
	tc_strcat(ExeLogFile,"_SAPartCreate.log");
	SAPartCreateLog = fopen(ExeLogFile,"w");
	
	fprintf(SAPartCreateLog,"\n Part Execution Log file is :: %s\n",ExeLogFile);fflush(SAPartCreateLog);

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));

	ifail = ITK_init_module("am927460.ttl","TATAMotors@123","PLM_Support_Group");

	if(ifail==1)
	{
		fprintf(SAPartCreateLog,"\n Login successful\n");fflush(SAPartCreateLog);
	}
	else
	{
		fprintf(SAPartCreateLog,"\n Login Failed\n");fflush(SAPartCreateLog);
	}
	ITK_set_journalling( TRUE );


	InputPart = (char *)MEM_alloc(max_char_size * sizeof(char));
	initialStringNumberdup = (char *)MEM_alloc(max_char_size * sizeof(char));
	optupt_part = (char *)MEM_alloc(max_char_size * sizeof(char));
	temp = (char *)MEM_alloc(max_char_size * sizeof(char));
	InputPart = (char *)MEM_alloc(max_char_size * sizeof(char));

	//inputfile=fopen("/user/tcuaadev/devgroups/Srikanth_Beerapor/WebService_TCUA_SA_Numbering/SATracker.txt","w+");
	//fprintf(inputfile,"user Input part %s\n",PartNumber);//54426010S1
	//fprintf(inputfile,"check value is %d\n",check);

	optupt_part=GetNextPartNumber(PartNumber);
	//fprintf(inputfile,"after generating part string is %s\n",optupt_part);
	//check = CheckPartIsExistInPlm(optupt_part);
	//fprintf(inputfile,"check value is %d\n",check);

	if(tc_strlen(optupt_part)==14)
	{
		*Response = (char *) malloc( (50) * sizeof(char));
		tc_strcpy(*Response,optupt_part);
	}
	else
	{
		*Response = (char *) malloc((50) * sizeof(char));
		tc_strcpy(*Response,"-1");
	}
	//fclose(inputfile);
	fclose(SAPartCreateLog);
	fflush(stdout);

	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;
};
extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new()); /* call the request dispatcher */

};
