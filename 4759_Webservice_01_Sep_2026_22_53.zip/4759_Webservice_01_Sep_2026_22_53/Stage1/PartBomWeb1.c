#define _CLMAIN_DEFNS
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include "soapH.h"
#include "PartBomWeb1.nsmap"

struct Prt_Bom
{
	char	Level[5];
	char	PrtObid[30];
	char	PartNumber[30];
	char	PartRev[5];
	char	PartSeq[5];
	char	PartWeight[20];
	char	PartSurfArea[50];
	char	PartVolume[10];
	char	PartCS[5];
	char	PartMaterial[50];
	char	PartDesc[500];
	char	PartProjCode[10];
	char	PartProjDesc[500];
	char	PEnvDia[500];
	char	PThickness[300];
	char	PParttype[300];
	
}get_Prt_List_Rev;


status t5GetCntxtObjForPrtBom(FILE *fp,ObjectPtr thisObj,string VewNameS, string ContextIDS,string ContextOptS,ObjectPtr *genContextObj,integer*  mfail)
{
	
	ObjectPtr		genCntxtObj				= NULL;
	ObjectPtr		contextObj				= NULL;
	string			VewNameSDup				= NULL;
	string			ContextIDSDup				= NULL;
	string			ContextOptSDup				= NULL;
	string			viewName				= NULL;
	string			viewNamedup				= NULL;
	string			confg_class				= NULL;



	t5MethodInit("t5GetCntxtObjForPrtBom");
  /*---------------------------------------------------------------------------------------------------------------------------------------------------------*/

   fprintf(fp,"\n Inside t5GetCntxtObjForPrtBom.\n");fflush(fp);

	if(VewNameS) VewNameSDup = strdup(VewNameS);
	if(ContextOptS) ContextOptSDup = strdup(ContextOptS);
	if (ContextIDS) ContextIDSDup = strdup(ContextIDS);

   //Setting Context
	// Building up of the Generalized Expand Context Object

	t5CheckMfail(IntSetUpContext(objClass(thisObj),thisObj,&genCntxtObj,mfail)) ;
	t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genCntxtObj,&contextObj,mfail));

	t5CheckDstat(objGetAttribute(contextObj, NavigateViewNameAttr, &viewName));
	if(viewName) viewNamedup = strdup(viewName);
     fprintf(fp,"\nBefore setting View is =%s\n",viewNamedup);fflush(fp);

	t5CheckDstat(objGetClass(contextObj, &confg_class)) ;
	t5CheckDstat(objSetAttribute(contextObj,CfgItemIdAttr,ContextIDSDup));

		if (dstat = objSetAttribute(contextObj,ExpandOnRevisionAttr,"PscLastRev"));
		if (dstat = objSetAttribute(contextObj,PsmExpIncludeZeroQtyAttr,"+"));

    	if(nlsStrCmp(VewNameSDup,"ERC")==0)
	{   
		fprintf(fp,"\n*****************ERC Context Applied***********************\n");fflush(fp);
		if(dstat=SetNavigateViewPref(contextObj,TRUE,"EAS","ERC",mfail)) goto EXIT;
		if (*mfail) goto CLEANUP;
	}
	else if(nlsStrCmp(VewNameSDup,"APL")==0)
	{
		fprintf(fp,"\n*****************APL Context Applied***********************\n");fflush(fp);
		if(dstat=SetNavigateViewPref(contextObj,TRUE,"EAS","APL",mfail)) goto EXIT;
		if (*mfail) goto CLEANUP;
	}
	else
	//if(nlsStrCmp(VewNameSDup,"APL1")==0)
	{
		fprintf(fp,"\n*****************AHD APL1Context Applied***********************\n");fflush(fp);
		if(dstat=SetNavigateViewPref(contextObj,TRUE,"EAS","APL1",mfail)) goto EXIT;
		if (*mfail) goto CLEANUP;
	}

	if (dstat = objSetAttribute(contextObj,PsmExpDisableCfgCtxAttr,"-")) goto CLEANUP;

	t5CheckDstat(objGetAttribute(contextObj, NavigateViewNameAttr, &viewName));
	if(viewName) viewNamedup = strdup(viewName);
 	fprintf(fp,"\nAfter setting View is =%s\n\n",viewNamedup);fflush(fp);


	if(nlsStrCmp(ContextOptSDup,"Option1")==0)
	{   
		fprintf(fp,"\n*****************ERC Lifecycle Applied***********************\n");fflush(fp);
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsAplRlzd","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsErcRlzd","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsReview","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsWorking","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsAPLWrkg","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsSTDRlzd","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsSTDWrkg","+"));
		t5CheckDstat(objSetObject(genCntxtObj,ConfigCtxtBlobAttr,contextObj));
		t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genCntxtObj,"PscLastRev",mfail));

	}
	if(nlsStrCmp(ContextOptSDup,"Option2")==0)
	{
		fprintf(fp,"\n*****************APL Lifecycle Applied***********************\n");fflush(fp);
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsAplRlzd","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsErcRlzd","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsReview","-"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsWorking","-"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsAPLWrkg","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsSTDRlzd","+"));
		t5CheckDstat(objNameValueSet(contextObj,LCStateListAttr,"LcsSTDWrkg","+"));
		t5CheckDstat(objSetObject(genCntxtObj,ConfigCtxtBlobAttr,contextObj));
		t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genCntxtObj,"PscLastRev",mfail));
	}


      /*----------------------------------------------------------------------------------------------------------------------------------*/


	//if(dstat =  IntSetUpContext(objClass(thisObj),thisObj,&genCntxtObj,mfail));
//	if (dstat = GetCfgCtxtObjFromCtxt(DSesScc2Class, genCntxtObj, &contextObj, mfail));
	
//	if (dstat = objSetAttribute(contextObj,CfgItemIdAttr,"GlobalCtxt"))  goto CLEANUP;
//	if (dstat = objSetAttribute(contextObj,ExpandOnRevisionAttr,"PscLastRev"));
//	if (dstat = objSetAttribute(contextObj,PsmExpIncludeZeroQtyAttr,"+"));

//	if (dstat = SetNavigateViewPref(contextObj,TRUE,"EAS","ERC",mfail));
//	if (dstat = objSetAttribute(contextObj,PsmExpDisableCfgCtxAttr,"-")) goto CLEANUP;

/*	if (dstat = objNameValueSet(contextObj,LCStateListAttr,"LcsAplRlzd","+")) goto CLEANUP ;
	if (dstat = objNameValueSet(contextObj,LCStateListAttr,"LcsSTDRlzd","+")) goto CLEANUP ;
	if (dstat = objNameValueSet(contextObj,LCStateListAttr,"LcsSTDWrkg","+")) goto CLEANUP ;
	if (dstat = objNameValueSet(contextObj,LCStateListAttr,"LcsErcRlzd","+")) goto CLEANUP ;
	if (dstat = objNameValueSet(contextObj,LCStateListAttr,"LcsReview","+")) goto CLEANUP ;
	if (dstat = objNameValueSet(contextObj,LCStateListAttr,"LcsWorking","-")) goto CLEANUP ;
	if (dstat = objNameValueSet(contextObj,LCStateListAttr,"LcsAPLWrkg","+")) goto CLEANUP ;
	if (dstat = objSetObject(genCntxtObj, ConfigCtxtBlobAttr, contextObj));*/

	if(genCntxtObj!=NULL)
	{
		if (dstat = objCopy(genContextObj,genCntxtObj)) goto CLEANUP;
	}

	CLEANUP :
		t5PrintCleanUpModName;
	EXIT :
		t5CheckDstatAndReturn;
}

void removeSpecialChars(char* str) 
{
    int len = strlen(str);
    //char* result = new char[len + 1];
	len = len + 1;
    char * result = malloc(len* sizeof(char*)+5);
	int j = 0,i=0;
    for(i = 0; i < len; i++) 
	{
        if((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z') || (str[i] >= '0' && str[i] <= '9')) 
		{
            result[j++] = str[i];
        }
    }
    result[j] = '\0';
    strcpy(str, result);
    //delete[] result;
	
}

status t5BOMExpInVLERC
(
		FILE			*fp,
		struct Prt_Bom prtLst[],
		ObjectPtr		partObj,
		ObjectPtr		genCntxtObj,
		integer			reqLevel,
		integer*		level,
		//SetOfObjects*	SetOfPrtNum,
		SetOfObjects*	SetOfPrtRel,
		int*			StrctInt,
		integer*		mfail
)
{
	status				dstat				= OKAY;
   	char				*mod_name 			= "t5BOMExpInVLERC";

   	//integer				cnt				= 0;
	string			pObid			=	NULL;
	string			pObidDup		=	NULL;
	string			PartNum			=	NULL;
	string			PartNumDup		=	NULL;
	string			Revision		=	NULL;
	string			RevisionDup		=	NULL;
	string			Sequence		=	NULL;
	string			SequenceDup		=	NULL;
	string			Weight			=	NULL;
	string			WeightDup		=	NULL;
	string			SurArea			=	NULL;
	string			SurAreaDup		=	NULL;
	string			Volume			=	NULL;
	string			VolumeDup		=	NULL;
	string			pCS				=	NULL;
	string			pCSDup			=	NULL;
	string			Material		=	NULL;
	string			MaterialDup		=	NULL;
	string			pDesc			=	NULL;
	string			pDescDup		=	NULL;
	string			pProjCode		=	NULL;
	string			pProjCodeDup	=	NULL;
	string			pProjDesc		=	NULL;
	string			pProjDescDup	=	NULL;
	string			sTempLevel		=	NULL;
	string			pEnvDia			=	NULL;
	string			pEnvDiaDup		=	NULL;

	string			pThickness		=	NULL;
	string			pThicknessDup	=	NULL;
	string			pParttype		=	NULL;
	string			pParttypeDup	=	NULL;

	ObjectPtr			ChldrelObj		=	NULL;
   	ObjectPtr			ChldObj			=	NULL;
   	ObjectPtr			Proj			=	NULL;

	SetOfObjects		ChldObjs		=	NULL;
	SetOfObjects		ChldrelObjs		=	NULL;
	SetOfObjects		soProj			=	NULL;
	//SetOfObjects		itemObjSet		= NULL;
	//SetOfStrings		ForF30PrtSet	= NULL;

	int		i			=0;

	SqlPtr			a_sql				=	NULL;
	//int		found		=0;

	*mfail 		= USC_OKAY;
	//printf("\ncalling t5GetViewBasedExplAPL\n");fflush(stdout);

	ChldObjs		=	NULL;
	ChldrelObjs		=	NULL;
	
	fprintf(fp,"\n Inside t5BOMExpInVERC.\n");fflush(fp);
	if (setSize(*SetOfPrtRel)<=0)
	{
		*SetOfPrtRel	=	setCreate(1);
	}

	if( *level >= reqLevel )
		   return (dstat);
	
	sTempLevel	= nlsStrAlloc(5);
	sprintf(sTempLevel, "%d", *level);
	if(dstat=objGetAttribute(partObj,OBIDAttr,&pObid)) goto EXIT;
	if(!nlsIsStrNull(pObid))
	{
		pObidDup=nlsStrDup(pObid);
	}
	else
	{
		pObidDup	=	NULL;
		pObidDup	=	nlsStrAlloc(5);
		nlsStrCpy(pObidDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,PartNumberAttr,&PartNum)) goto EXIT;
	if(!nlsIsStrNull(PartNum))
	{
		PartNumDup=nlsStrDup(PartNum);
		fprintf(fp,"\n******PartNumDup******* : %s \n", PartNumDup);fflush(fp);

	}
	else
	{
		PartNumDup	=	NULL;
		PartNumDup	=	nlsStrAlloc(5);
		nlsStrCpy(PartNumDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,RevisionAttr,&Revision)) goto EXIT;
	if(!nlsIsStrNull(Revision))
	{
		RevisionDup=nlsStrDup(Revision);
	}
	else
	{
		RevisionDup	=	NULL;
		RevisionDup	=	nlsStrAlloc(5);
		nlsStrCpy(RevisionDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,SequenceAttr,&Sequence)) goto EXIT;
	if(!nlsIsStrNull(Sequence))
	{
		SequenceDup=nlsStrDup(Sequence);
	}
	else
	{
		SequenceDup	=	NULL;
		SequenceDup	=	nlsStrAlloc(5);
		nlsStrCpy(SequenceDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,t5WeightAttr,&Weight)) goto EXIT;
	if(!nlsIsStrNull(Weight))
	{
		WeightDup=nlsStrDup(Weight);
	}
	else
	{
		WeightDup	=	NULL;
		WeightDup	=	nlsStrAlloc(5);
		nlsStrCpy(WeightDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,t5SurfaceAreaAttr,&SurArea)) goto EXIT;
	if(!nlsIsStrNull(SurArea))
	{
		SurAreaDup=nlsStrDup(SurArea);
	}
	else
	{
		SurAreaDup	=	NULL;
		SurAreaDup	=	nlsStrAlloc(5);
		nlsStrCpy(SurAreaDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,t5VolumeAttr,&Volume)) goto EXIT;
	if(!nlsIsStrNull(Volume))
	{
		VolumeDup=nlsStrDup(Volume);
	}
	else
	{
		VolumeDup	=	NULL;
		VolumeDup	=	nlsStrAlloc(5);
		nlsStrCpy(VolumeDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,t5MaterialAttr,&Material)) goto EXIT;
	if(!nlsIsStrNull(Material))
	{
        //removeSpecialChars(Material);
		MaterialDup=nlsStrDup(Material);
	}
	else
	{
		MaterialDup	=	NULL;
		MaterialDup	=	nlsStrAlloc(5);
		nlsStrCpy(MaterialDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,NomenclatureAttr,&pDesc)) goto EXIT;
	if(!nlsIsStrNull(pDesc))
	{
		pDescDup=nlsStrDup(pDesc);
	}
	else
	{
		pDescDup	=	NULL;
		pDescDup	=	nlsStrAlloc(5);
		nlsStrCpy(pDescDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,t5PunMakeBuyIndicatorAttr,&pCS)) goto EXIT;
	if(!nlsIsStrNull(pCS))
	{
		pCSDup=nlsStrDup(pCS);
	}
	else
	{
		pCSDup	=	NULL;
		pCSDup	=	nlsStrAlloc(5);
		nlsStrCpy(pCSDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,ProjectNameAttr,&pProjCode)) goto EXIT;
	if(!nlsIsStrNull(pProjCode))
	{
		pProjCodeDup=nlsStrDup(pProjCode);
	}
	else
	{
		pProjCodeDup	=	NULL;
		pProjCodeDup	=	nlsStrAlloc(5);
		nlsStrCpy(pProjCodeDup,"NA");
	}
	//pEnvDia t5EnvelopeDimensions
	if(dstat=objGetAttribute(partObj,t5EnvelopeDimensionsAttr,&pEnvDia)) goto EXIT;
	if(!nlsIsStrNull(pEnvDia))
	{
		pEnvDiaDup=nlsStrDup(pEnvDia);
	}
	else
	{
		pEnvDiaDup	=	NULL;
		pEnvDiaDup	=	nlsStrAlloc(5);
		nlsStrCpy(pEnvDiaDup,"NA");
	}

	if(dstat=objGetAttribute(partObj,t5MThicknessAttr,&pThickness)) goto EXIT;
	if(!nlsIsStrNull(pThickness))
	{
		pThicknessDup=nlsStrDup(pThickness);
	}
	else
	{
		pThicknessDup	=	NULL;
		pThicknessDup	=	nlsStrAlloc(5);
		nlsStrCpy(pThicknessDup,"0");
	}
	//Parttype(PartType)
	if(dstat=objGetAttribute(partObj,PartTypeAttr,&pParttype)) goto EXIT;
	if(!nlsIsStrNull(pParttype))
	{
		pParttypeDup=nlsStrDup(pParttype);
	}
	else
	{
		pParttypeDup	=	NULL;
		pParttypeDup	=	nlsStrAlloc(5);
		nlsStrCpy(pParttypeDup,"NA");
	}
	
	if(!nlsIsStrNull(pProjCode))
	{
		//Query the project and fetch the desription

		if(a_sql)	oiSqlDispose(a_sql); a_sql = NULL;
		if (dstat = oiSqlCreateSelect(&a_sql))	goto CLEANUP;
		if (dstat = oiSqlWhereEQValue(a_sql, ProjectNameAttr,  pProjCode))	goto CLEANUP;
		if (dstat = QueryDbObject(t0NPProjClass,  a_sql,  -1,  FALSE,  SC_SCOPE_OF_SESSION,  &soProj,  mfail)) goto CLEANUP;
		if(a_sql) oiSqlDispose(a_sql); a_sql = NULL;

		printf("\nNo of Project found : %d", setSize(soProj));fflush(stdout);

		if (setSize(soProj)>0)
		{
			Proj	=	setGet(soProj,0);

			if (dstat = objGetAttribute (Proj,ProjectDescAttr,&pProjDesc)) goto EXIT;
			if(!nlsIsStrNull(pProjDesc))
				pProjDescDup	=	nlsStrDup(pProjDesc);
			else
			{
				pProjDescDup	=	NULL;
				pProjDescDup	=	nlsStrAlloc(5);
				nlsStrCpy(pProjDescDup,"-");
			}
		}
	}
	else
	{
		pProjDescDup	=	NULL;
		pProjDescDup	=	nlsStrAlloc(5);
		nlsStrCpy(pProjDescDup,"NA");
	}



	*StrctInt	=	*StrctInt+1;
	nlsStrCpy(prtLst[*StrctInt].Level,sTempLevel);
	nlsStrCpy(prtLst[*StrctInt].PrtObid,pObidDup);
	nlsStrCpy(prtLst[*StrctInt].PartNumber,PartNumDup);
	nlsStrCpy(prtLst[*StrctInt].PartRev,RevisionDup);
	nlsStrCpy(prtLst[*StrctInt].PartSeq,SequenceDup);
	nlsStrCpy(prtLst[*StrctInt].PartWeight,WeightDup);
	nlsStrCpy(prtLst[*StrctInt].PartSurfArea,SurAreaDup);
	nlsStrCpy(prtLst[*StrctInt].PartVolume,VolumeDup);
	nlsStrCpy(prtLst[*StrctInt].PartCS,pCSDup);
	nlsStrCpy(prtLst[*StrctInt].PartMaterial,MaterialDup);
	nlsStrCpy(prtLst[*StrctInt].PartDesc,pDescDup);
	nlsStrCpy(prtLst[*StrctInt].PartProjCode,pProjCodeDup);
	nlsStrCpy(prtLst[*StrctInt].PartProjDesc,pProjDescDup);
	nlsStrCpy(prtLst[*StrctInt].PEnvDia,pEnvDiaDup);
	nlsStrCpy(prtLst[*StrctInt].PThickness,pThicknessDup);
	nlsStrCpy(prtLst[*StrctInt].PParttype,pParttypeDup);

	fprintf(fp,"\n After setting up Context.\n");fflush(fp);

	if (dstat = ExpandRelationWithCtxt("AsRevRev",
				   partObj,
				   "PartsInAssembly",
				    genCntxtObj,
				    SC_SCOPE_OF_SESSION,
				    NULL,
				    &ChldObjs,
				    &ChldrelObjs,
				    mfail))
				goto EXIT;
	if (*mfail)    goto CLEANUP;

	fprintf(fp,"\nNo of child found : %d\n",setSize(ChldObjs));fflush(fp);

	if (setSize(ChldObjs) > 0)
	{
		*level		=	*level+1;
		for(i	=	0;	i	<	setSize(ChldObjs); i++)
		{
			ChldObj		=	setGet(ChldObjs,i);
			ChldrelObj	=	setGet(ChldrelObjs,i);

			fprintf(fp,"\nCopy Child : %d\n",i);fflush(fp);
			
			if(dstat=ulyCopyObjectToSet(ChldrelObj,SetOfPrtRel))goto EXIT;
			
			fprintf(fp,"\nAfter Copy Child : %d\n",i);fflush(fp);
			if( dstat = t5BOMExpInVLERC(fp,prtLst,ChldObj,genCntxtObj,reqLevel,level,SetOfPrtRel,StrctInt,mfail))goto CLEANUP;
		}
		*level		=	*level		-	1;
	}
	

CLEANUP:
	if(ChldObjs)  objDisposeAll(ChldObjs); ChldObjs = NULL;
	if(ChldrelObjs)	  objDisposeAll(ChldrelObjs); ChldrelObjs = NULL;

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );

}

char* subString_1 (
char* mainStringf ,
int fromCharf ,
int toCharf
)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
	*(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


int main(int argc, char *argv[])
{
	t5MethodInitWMD("PartBomWeb1.c");
	dstat = clInitMB2 (argc,&argv,NULL);

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;



int ns__getBOMLDetails(struct soap* soap,char *partnumber,char	*revision, char	*ISequence, char*ER_EW,char	*Plant, struct ns__CharArray4Test *aString_test)
{
	FILE           *bomdtls;
	string		    FileNameDup			=	NULL;

	struct			Prt_Bom			getList[3000];
	int				StrctInt			=	0;
		int				stat			= 0;
		int PlntFlag = 0;
		int CVPROJ = 0;
		FILE* fp1 = NULL;
		char fileRead[2000];

	string			relObid			=	NULL;
	string			relObidDup		=	NULL;
	string			leftObid		=	NULL;
	string			leftObidDup		=	NULL;
	string			rightObid		=	NULL;
	string			rightObidDup	=	NULL;
	string			Qty				=	NULL;
	string			QtyDup			=	NULL;
	string strSet = NULL;
	string strSet1 = NULL;

	string			PartRev			=	NULL;
	string			RevDup			=	NULL;
	string			Sequence			=	NULL;
	string			RevSeq			=	NULL;
	string			OrgName			=	NULL;
	string			OrgNm			=	NULL;
	string			PartNumbers			=	NULL;
	string			PartNum			=	NULL;
	string			ViewSet			=	NULL;
	string			contextid			=	NULL;
	string			PartProjectcode				=	NULL;
	string			StrFullPathShell	=	NULL;
	string          inputfile = NULL;

	string item_levelCV = NULL;
	string partNumberCV = NULL;
	string partRevNumberCV = NULL;
	string ModItem_SeqCV =NULL;
	string WeightCV = NULL;
	string SurfaceAreaCV = NULL;
	string VolumeCV = NULL;
	string PartCSCV = NULL;
	string MaterialCV = NULL;
	string DescriptionCV = NULL;
	string PartProjCodeCV = NULL;
	string PartProjCode1CV = NULL;
	string EnvelopeDimensionsCV = NULL;
	string ThicknesCV=NULL;
	string PartTypeCV=NULL;
	string quantityCV=NULL;

	string PartInfoStr = NULL;
	PartInfoStr = nlsStrAlloc(1000);

	const char		*txtargv[5];

	ObjectPtr		PartObj				=	NULL;
	ObjectPtr		genCntxtObj			=	NULL;
	ObjectPtr		relObj				=	NULL;

	SetOfStrings	strDbScope			=	NULL;
	SetOfStrings	LifeCycValSet		=	NULL;
	SetOfStrings	LifeCycValSetEW		=	NULL;

	SetOfObjects	soPartObjs			=	NULL;
	SetOfObjects	SetOfPrt			=	NULL;
	SetOfObjects	SetOfPrtRel			=	NULL;
	SetOfObjects    soTCUACntrl		=   NULL;
	SetOfStrings partBomData = NULL;
	partBomData = setStrCreate(1);
	SetOfStrings partBomData1 = NULL;
	partBomData1 = setStrCreate(1);

	SetOfStrings partBomSET = NULL;
	partBomSET = setStrCreate(1);
	
	SqlPtr          QrySqlPtr			=   NULL;
	SqlPtr          Sql_ptr_UA		 =   NULL;
	integer	level		=	0;
	int	iPB				=	0;
	int	iPR				=	0;
	int	iPdt			=	0;
	int	length			=	0;
	int	cnt				=	0;
	int	cntr			=	0;
	int	SysReturn		=	0;
	
	status dstat		=	OKAY;
	int mfail			=	USC_OKAY;
	
	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("log1.txt", "w", stdout);
    


	if (dstat = clInitialize2 (TRUE)) goto CLEANUP;
	if (dstat =clLogin2 ("super user","abc123",&stat))goto CLEANUP;
	FileNameDup		=	nlsStrAlloc(500);
	SetOfPrt		=	setCreate(1);

     //nlsStrCpy(FileNameDup,"/plmuv_logs/omfprod/logs/");
	//nlsStrCpy(FileNameDup,"/plmpv16/bulkdata/omf9dev/devgroups/Hemal/PartBomWeb2/");

	///////
	char WebServiceFiredDate[26] = {'\0'};
    time_t now;
	struct tm* now_tm;
	time(&now);
    now_tm = localtime(&now);
    strftime (WebServiceFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
    ///////
	nlsStrCpy(FileNameDup,"/proj/PLMLoading/UAFiles/CasCaveTCELog/");
	nlsStrCat(FileNameDup,partnumber);
	nlsStrCat(FileNameDup,"_");
	nlsStrCat(FileNameDup,WebServiceFiredDate);
	nlsStrCat(FileNameDup,"_PartBomWeb2");
	nlsStrCat(FileNameDup,".log");
	bomdtls = fopen(FileNameDup , "a+") ;
	if(FileNameDup==NULL)
	{
		goto EXIT;
	}

	strDbScope = low_set_create_str(2);
	low_set_add_str_unique(strDbScope,"supprod");
	low_set_add_str_unique(strDbScope,"suhprod");
	low_set_add_str_unique(strDbScope,"sulprod");
	low_set_add_str_unique(strDbScope,"sujprod");
	low_set_add_str_unique(strDbScope,"admpprod");



	if(dstat = smSetSessionDbScope(strDbScope)) goto CLEANUP;
	fprintf(bomdtls,"\n********WEB SERVICE CALLED FOR BOM PART CHECK***********");fflush(bomdtls);
	
	LifeCycValSet		= setCreate(7);
	//low_set_add_str_unique(LifeCycValSet,"LcsReview"); //commented as per Tushar Dhumal Sir requirement CR number : CR/CVBU PUNE/APL/18/0083
	low_set_add_str_unique(LifeCycValSet,"LcsErcRlzd");
	low_set_add_str_unique(LifeCycValSet,"LcsAPLWrkg");
	low_set_add_str_unique(LifeCycValSet,"LcsAplRlzd");
	low_set_add_str_unique(LifeCycValSet,"LcsSTDWrkg");
	low_set_add_str_unique(LifeCycValSet,"LcsSTDRlzd");


	LifeCycValSetEW		= setCreate(7);
	low_set_add_str_unique(LifeCycValSetEW,"LcsReview"); 
	low_set_add_str_unique(LifeCycValSetEW,"LcsWorking"); 
	
	fprintf(bomdtls,"\nPart Number : %s, Revision : %s ",partnumber,revision);fflush(bomdtls);
	fprintf(bomdtls,"\nPart Sequence : %s, Lifecycle states_EW : %s ",ISequence,ER_EW);fflush(bomdtls);
	fprintf(bomdtls,"\nPart BOM Plant : %s ",Plant);fflush(bomdtls);
	if(!nlsIsStrNull(Plant))
	{
		PlntFlag=0;
		fprintf(bomdtls,"\nPart BOM Plant input not null : %s ",Plant);fflush(bomdtls);
		if(nlsStrCmp(Plant,"PNR")==0)
		{
			PlntFlag=1;
		}
		else if(nlsStrCmp(Plant,"JSR")==0)
		{
			PlntFlag=1;
		}
		else if (nlsStrCmp(Plant,"DWD")==0)
		{
			PlntFlag=1;
		}
		else if(nlsStrCmp(Plant,"LKO")==0)
		{
			PlntFlag=1;
		}
		else if(nlsStrCmp(Plant,"AHD")==0)
		{
			PlntFlag=1;
		}
		else if(nlsStrCmp(Plant,"PUN")==0)
		{
			PlntFlag=1;
		}
		else
		{
			PlntFlag=0;
		}
	}


		if(nlsStrCmp(ER_EW,"EW")==0)
		{
		if (  (!nlsIsStrNull (partnumber)) && (!nlsIsStrNull (revision)) && ( !nlsIsStrNull (ISequence))  )
		{
		fprintf(bomdtls,"\n ***INSIDE  _EW  check Query*** -------------------------");fflush(bomdtls);
		if(QrySqlPtr)	oiSqlDispose(QrySqlPtr); QrySqlPtr = NULL;
		if(dstat = oiSqlCreateSelect(&QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,PartNumberAttr,partnumber))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,RevisionAttr,revision))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,SequenceAttr,ISequence))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereIN(QrySqlPtr,LifeCycleStateAttr,LifeCycValSetEW,&mfail))goto CLEANUP;
		if(dstat = oiSqlDescOrder(QrySqlPtr,CreationDateAttr))goto CLEANUP;
		if(dstat = oiSqlPrint(QrySqlPtr))goto CLEANUP;//Query Master
		if(dstat = QueryDbObject(PartClass,QrySqlPtr,-1,TRUE,SC_SCOPE_OF_SESSION,&soPartObjs,&mfail))goto CLEANUP;
		}
		else if (  (!nlsIsStrNull (partnumber)) && (!nlsIsStrNull (revision)) )
		{
		fprintf(bomdtls,"\n ***INSIDE  _EW  2check Query*** -------------------------");fflush(bomdtls);
		if(QrySqlPtr)	oiSqlDispose(QrySqlPtr); QrySqlPtr = NULL;
		if(dstat = oiSqlCreateSelect(&QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,PartNumberAttr,partnumber))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,RevisionAttr,revision))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereIN(QrySqlPtr,LifeCycleStateAttr,LifeCycValSetEW,&mfail))goto CLEANUP;
		if(dstat = oiSqlDescOrder(QrySqlPtr,CreationDateAttr))goto CLEANUP;
		if(dstat = oiSqlPrint(QrySqlPtr))goto CLEANUP;//Query Master
		if(dstat = QueryDbObject(PartClass,QrySqlPtr,-1,TRUE,SC_SCOPE_OF_SESSION,&soPartObjs,&mfail))goto CLEANUP;
		}
		else if ( (nlsStrCmp(revision,"-")==0) &&  (!nlsIsStrNull (partnumber)) )
		{
			fprintf(bomdtls,"\n INSIDE  EW- if revision is blankQuery ");fflush(bomdtls);
			PartProjectcode=subString_1(partnumber,0,4);
	        fprintf(bomdtls,"\n*Project code of Part is %s***",PartProjectcode);fflush(bomdtls);

	    	if(Sql_ptr_UA) oiSqlDispose(Sql_ptr_UA);
	    	if(dstat = oiSqlCreateSelect(&Sql_ptr_UA));
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SyscdAttr,"CVPROJ"));//t5SubSyscdAttr
	    	if(dstat = oiSqlWhereAND(Sql_ptr_UA)) goto EXIT;
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SubSyscdAttr,PartProjectcode));
	    	if(dstat = oiSqlDescOrder(Sql_ptr_UA,CreationDateAttr));
	    	if(dstat = QueryDbObject(t5CntrolClass,Sql_ptr_UA,-1,TRUE,SC_SCOPE_OF_SESSION,&soTCUACntrl,&mfail));
	    
	    	fprintf(bomdtls,"\n*TCUA Project code control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
			if(setSize(soTCUACntrl)>0)
			{
				CVPROJ=1;
				fprintf(bomdtls,"\n*TCUA Project code As control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
				fprintf(bomdtls,"\n*TCUA Project code CVPROJ  %d***",CVPROJ);fflush(bomdtls);
			}
			else
			{
	            fprintf(bomdtls,"\n INSIDE  - - revision Query ");fflush(bomdtls);
	            if(QrySqlPtr)	oiSqlDispose(QrySqlPtr); QrySqlPtr = NULL;
	            if(dstat = oiSqlCreateSelect(&QrySqlPtr)) goto CLEANUP;
	            if(dstat = oiSqlWhereEQ(QrySqlPtr,PartNumberAttr,partnumber))goto CLEANUP;
	            if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
	            if(dstat = oiSqlWhereIN(QrySqlPtr,LifeCycleStateAttr,LifeCycValSetEW,&mfail))goto CLEANUP;
	            if(dstat = oiSqlDescOrder(QrySqlPtr,CreationDateAttr))goto CLEANUP;
	            if(dstat = oiSqlPrint(QrySqlPtr))goto CLEANUP; //Query Master
	            if(dstat = QueryDbObject(PartClass,QrySqlPtr,-1,TRUE,SC_SCOPE_OF_SESSION,&soPartObjs,&mfail))goto CLEANUP;
			}
		}
      	else  /* if (  (!nlsIsStrNull (partnumber)) && (!nlsIsStrNull (revision))  )*/
		{

			//check project code is lived in TCUA , if TCUA project live return latest erc released bom as plant as rev blank
			fprintf(bomdtls,"\n INSIDE  - if revision is blankQuery ");fflush(bomdtls);
			PartProjectcode=subString_1(partnumber,0,4);
	        fprintf(bomdtls,"\n*Project code of Part is %s***",PartProjectcode);fflush(bomdtls);

	    	if(Sql_ptr_UA) oiSqlDispose(Sql_ptr_UA);
	    	if(dstat = oiSqlCreateSelect(&Sql_ptr_UA));
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SyscdAttr,"CVPROJ"));//t5SubSyscdAttr
	    	if(dstat = oiSqlWhereAND(Sql_ptr_UA)) goto EXIT;
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SubSyscdAttr,PartProjectcode));
	    	if(dstat = oiSqlDescOrder(Sql_ptr_UA,CreationDateAttr));
	    	if(dstat = QueryDbObject(t5CntrolClass,Sql_ptr_UA,-1,TRUE,SC_SCOPE_OF_SESSION,&soTCUACntrl,&mfail));
	    
	    	fprintf(bomdtls,"\n*TCUA Project code control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
			if(setSize(soTCUACntrl)>0)
			{
				CVPROJ=1;
				fprintf(bomdtls,"\n*TCUA Project code As control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
				fprintf(bomdtls,"\n*TCUA Project code CVPROJ  %d***",CVPROJ);fflush(bomdtls);
			}
		}
	}
	else
	{
      if (  (!nlsIsStrNull (partnumber)) && (!nlsIsStrNull (revision)) && ( !nlsIsStrNull (ISequence))  )
		{
		fprintf(bomdtls,"\n ***INSIDE  ER_  check Query*** ");fflush(bomdtls);
		if(QrySqlPtr)	oiSqlDispose(QrySqlPtr); QrySqlPtr = NULL;
		if(dstat = oiSqlCreateSelect(&QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,PartNumberAttr,partnumber))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,RevisionAttr,revision))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,SequenceAttr,ISequence))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereIN(QrySqlPtr,LifeCycleStateAttr,LifeCycValSet,&mfail))goto CLEANUP;
		if(dstat = oiSqlDescOrder(QrySqlPtr,CreationDateAttr))goto CLEANUP;
		if(dstat = oiSqlPrint(QrySqlPtr))goto CLEANUP;//Query Master
		if(dstat = QueryDbObject(PartClass,QrySqlPtr,-1,TRUE,SC_SCOPE_OF_SESSION,&soPartObjs,&mfail))goto CLEANUP;
		}
		else if (  (!nlsIsStrNull (partnumber)) && (!nlsIsStrNull (revision)))
		{
		fprintf(bomdtls,"\n ***INSIDE  ER_  2check Query*** ");fflush(bomdtls);
		if(QrySqlPtr)	oiSqlDispose(QrySqlPtr); QrySqlPtr = NULL;
		if(dstat = oiSqlCreateSelect(&QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,PartNumberAttr,partnumber))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(QrySqlPtr,RevisionAttr,revision))goto CLEANUP;
		if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
		if(dstat = oiSqlWhereIN(QrySqlPtr,LifeCycleStateAttr,LifeCycValSet,&mfail))goto CLEANUP;
		if(dstat = oiSqlDescOrder(QrySqlPtr,CreationDateAttr))goto CLEANUP;
		if(dstat = oiSqlPrint(QrySqlPtr))goto CLEANUP;//Query Master
		if(dstat = QueryDbObject(PartClass,QrySqlPtr,-1,TRUE,SC_SCOPE_OF_SESSION,&soPartObjs,&mfail))goto CLEANUP;
		}
		else if ( (nlsStrCmp(revision,"-")==0) &&  (!nlsIsStrNull (partnumber)) )
		{
			fprintf(bomdtls,"\n INSIDE  ER- if revision is blankQuery ");fflush(bomdtls);
			PartProjectcode=subString_1(partnumber,0,4);
	        fprintf(bomdtls,"\n*Project code of Part is %s***",PartProjectcode);fflush(bomdtls);

	    	if(Sql_ptr_UA) oiSqlDispose(Sql_ptr_UA);
	    	if(dstat = oiSqlCreateSelect(&Sql_ptr_UA));
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SyscdAttr,"CVPROJ"));//t5SubSyscdAttr
	    	if(dstat = oiSqlWhereAND(Sql_ptr_UA)) goto EXIT;
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SubSyscdAttr,PartProjectcode));
	    	if(dstat = oiSqlDescOrder(Sql_ptr_UA,CreationDateAttr));
	    	if(dstat = QueryDbObject(t5CntrolClass,Sql_ptr_UA,-1,TRUE,SC_SCOPE_OF_SESSION,&soTCUACntrl,&mfail));
	    
	    	fprintf(bomdtls,"\n*TCUA Project code control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
			if(setSize(soTCUACntrl)>0)
			{
				CVPROJ=1;
				fprintf(bomdtls,"\n*TCUA Project code As control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
				fprintf(bomdtls,"\n*TCUA Project code CVPROJ  %d***",CVPROJ);fflush(bomdtls);
			}
			else
			{
	            fprintf(bomdtls,"\n INSIDE  - - revision Query ");fflush(bomdtls);
	            if(QrySqlPtr)	oiSqlDispose(QrySqlPtr); QrySqlPtr = NULL;
	            if(dstat = oiSqlCreateSelect(&QrySqlPtr)) goto CLEANUP;
	            if(dstat = oiSqlWhereEQ(QrySqlPtr,PartNumberAttr,partnumber))goto CLEANUP;
	            if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
	            if(dstat = oiSqlWhereIN(QrySqlPtr,LifeCycleStateAttr,LifeCycValSet,&mfail))goto CLEANUP;
	            if(dstat = oiSqlDescOrder(QrySqlPtr,CreationDateAttr))goto CLEANUP;
	            if(dstat = oiSqlPrint(QrySqlPtr))goto CLEANUP; //Query Master
	            if(dstat = QueryDbObject(PartClass,QrySqlPtr,-1,TRUE,SC_SCOPE_OF_SESSION,&soPartObjs,&mfail))goto CLEANUP;
			}
		}
      	else  /* if (  (!nlsIsStrNull (partnumber)) && (!nlsIsStrNull (revision))  )*/
		{

			//check project code is lived in TCUA , if TCUA project live return latest erc released bom as plant as rev blank
			fprintf(bomdtls,"\n INSIDE  - else is blankQuery ");fflush(bomdtls);
			PartProjectcode=subString_1(partnumber,0,4);
	        fprintf(bomdtls,"\n*Project code of Part is %s***",PartProjectcode);fflush(bomdtls);

	    	if(Sql_ptr_UA) oiSqlDispose(Sql_ptr_UA);
	    	if(dstat = oiSqlCreateSelect(&Sql_ptr_UA));
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SyscdAttr,"CVPROJ"));//t5SubSyscdAttr
	        if(dstat = oiSqlWhereAND(Sql_ptr_UA)) goto EXIT;
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SubSyscdAttr,PartProjectcode));
	    	if(dstat = oiSqlDescOrder(Sql_ptr_UA,CreationDateAttr));
	    	if(dstat = QueryDbObject(t5CntrolClass,Sql_ptr_UA,-1,TRUE,SC_SCOPE_OF_SESSION,&soTCUACntrl,&mfail));
	    
	    	fprintf(bomdtls,"\n*TCUA Project code control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
			if(setSize(soTCUACntrl)>0)
			{
				CVPROJ=1;
				fprintf(bomdtls,"\n*TCUA Project code As control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
				fprintf(bomdtls,"\n*TCUA Project code CVPROJ  %d***",CVPROJ);fflush(bomdtls);
			}
			else
			{
			//if TCE than below code to be 

	    	fprintf(bomdtls,"\n INSIDE in TCE else Query ");fflush(bomdtls);
	    	if(QrySqlPtr)	oiSqlDispose(QrySqlPtr); QrySqlPtr = NULL;
	    	if(dstat = oiSqlCreateSelect(&QrySqlPtr)) goto CLEANUP;
	    	if(dstat = oiSqlWhereEQ(QrySqlPtr,PartNumberAttr,partnumber))goto CLEANUP;
	    	if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
	    	if(dstat = oiSqlWhereEQ(QrySqlPtr,RevisionAttr,revision))goto CLEANUP;
	    	if(dstat = oiSqlWhereAND(QrySqlPtr)) goto CLEANUP;
	    	if(dstat = oiSqlWhereIN(QrySqlPtr,LifeCycleStateAttr,LifeCycValSet,&mfail))goto CLEANUP;
	    	if(dstat = oiSqlDescOrder(QrySqlPtr,CreationDateAttr))goto CLEANUP;
	    	if(dstat = oiSqlPrint(QrySqlPtr))goto CLEANUP;//Query Master
	    	if(dstat = QueryDbObject(PartClass,QrySqlPtr,-1,TRUE,SC_SCOPE_OF_SESSION,&soPartObjs,&mfail))goto CLEANUP;
			}
		}


	}
	fprintf(bomdtls,"\nSet Size of soPartObjs Object Set***:%d \n", setSize(soPartObjs));fflush(bomdtls);
    if (setSize(soTCUACntrl)==0)
	 {
			PartProjectcode=subString_1(partnumber,0,4);
	        fprintf(bomdtls,"\n*Project code of Part is %s***",PartProjectcode);fflush(bomdtls);

	    	if(Sql_ptr_UA) oiSqlDispose(Sql_ptr_UA);
	    	if(dstat = oiSqlCreateSelect(&Sql_ptr_UA));
	    	if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SyscdAttr,"CVPRD-LOCK"));//t5SubSyscdAttr
	    	//if(dstat = oiSqlWhereAND(Sql_ptr_UA)) goto EXIT;
	    	//if(dstat = oiSqlWhereEQ(Sql_ptr_UA,t5SubSyscdAttr,PartProjectcode));
	    	if(dstat = oiSqlDescOrder(Sql_ptr_UA,CreationDateAttr));
	    	if(dstat = QueryDbObject(t5CntrolClass,Sql_ptr_UA,-1,TRUE,SC_SCOPE_OF_SESSION,&soTCUACntrl,&mfail));
	    
	    	fprintf(bomdtls,"\n*TCUA Project code control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
			if(setSize(soTCUACntrl)>0)
			{
				CVPROJ=1;
				fprintf(bomdtls,"\n*TCUA Project code As control object setSize(soTCUACntrl) is  %d***",setSize(soTCUACntrl));fflush(bomdtls);
				fprintf(bomdtls,"\n*TCUA Project code CVPROJ  %d***",CVPROJ);fflush(bomdtls);
			}
	   
     } 
     
	if(setSize(soPartObjs)>0)
	{
		PartObj	=	setGet(soPartObjs,0);

		if(dstat = objGetAttribute(PartObj, PartNumberAttr, &PartNumbers));
		if(!nlsIsStrNull(PartNumbers)) PartNum=nlsStrDup(PartNumbers);
		fprintf(bomdtls,"\n Part Number Found is= %s ",PartNum);fflush(bomdtls);

		if (dstat = objGetAttribute(PartObj, RevisionAttr, &PartRev)) goto CLEANUP;
		if(!nlsIsStrNull(PartRev)) RevDup=nlsStrDup(PartRev);
		fprintf(bomdtls,"\n PartRev Number Found is= %s ",RevDup);fflush(bomdtls);

	    if(dstat=objGetAttribute(PartObj,SequenceAttr,&Sequence)) goto CLEANUP;
		if(!nlsIsStrNull(Sequence)) RevSeq=nlsStrDup(Sequence);
	    fprintf(bomdtls,"\n Sequence Number Found is= %s ",RevSeq);fflush(bomdtls);

		if(dstat=objGetAttribute(PartObj,OrganizationIDAttr,&OrgName)) goto CLEANUP;
		if(!nlsIsStrNull(OrgName)) OrgNm=nlsStrDup(OrgName);
	    fprintf(bomdtls,"\n OrgID Name Found = %s ",OrgNm);fflush(bomdtls);
         
        nlsStrCpy(ViewSet,"");
		ViewSet = nlsStrAlloc(5);

        nlsStrCpy(contextid,"");
		contextid = nlsStrAlloc(20);


		if((nlsStrStr(OrgNm,"APL")!=NULL)&&(PlntFlag==0))
		{
           fprintf(bomdtls,"\nInside APL Content Get");fflush(bomdtls);	
			if (nlsStrCmp("APLAHD",OrgNm)==0 )		{	nlsStrCat(ViewSet,"APL1");			nlsStrCat(contextid,"GlobalCtxt");	}
	else if (nlsStrCmp("APLDWD",OrgNm)==0 )	{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"DWDCtxt");	}
	else if (nlsStrCmp("APLJSR",OrgNm)==0 )		{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"JsrCtxt");		}
	else if (nlsStrCmp("APLLKO",OrgNm)==0 )		{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"LkoCtxt");		}
	else if (nlsStrCmp("APLPNR",OrgNm)==0 )		{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"PNRCtxt");		}
	else																			{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"GlobalCtxt");	}
		}
		else if((nlsStrStr(OrgNm,"APL")!=NULL)&&(PlntFlag==1))
		{
			fprintf(bomdtls,"\nInside APL Content Get on Plant basis");fflush(bomdtls);	
			if (nlsStrStr("AHD",Plant)!=NULL )		{	nlsStrCat(ViewSet,"APL1");			nlsStrCat(contextid,"GlobalCtxt");	}
	else if (nlsStrStr("DWD",Plant)!=NULL )	{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"DWDCtxt");	}
	else if (nlsStrStr("JSR",Plant)!=NULL )		{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"JsrCtxt");		}
	else if (nlsStrStr("LKO",Plant)!=NULL )		{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"LkoCtxt");		}
	else if (nlsStrStr("PNR",Plant)!=NULL )		{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"PNRCtxt");		}
	else																			{	nlsStrCat(ViewSet,"APL");			nlsStrCat(contextid,"GlobalCtxt");	}
		
		}
		else 
		{
        fprintf(bomdtls,"\nInside ERC Exp");fflush(bomdtls);	
		nlsStrCat(ViewSet,"ERC");           nlsStrCat(contextid,"GlobalCtxt");
	} 
         
		fprintf(bomdtls,"\nView Set & Context is :[%s] & [%s] ", ViewSet,contextid);fflush(bomdtls);	      
       fprintf(bomdtls,"\n  Confiduration Context Provided for BOM Expansion is== [%s]\n",contextid);fflush(bomdtls);
	   
	   if(nlsStrStr(ViewSet,"APL")!=NULL)
	  {
        fprintf(bomdtls,"\nInside APL BOM Expansion\n");fflush(bomdtls);	
       	if(dstat = t5GetCntxtObjForPrtBom(bomdtls,PartObj,ViewSet,contextid,"Option2", &genCntxtObj, &mfail))goto CLEANUP;
	  }else
	 {
		 fprintf(bomdtls,"\nInside ERC BOM Expansion\n");fflush(bomdtls);	
		if(dstat = t5GetCntxtObjForPrtBom(bomdtls,PartObj,ViewSet,contextid,"Option1", &genCntxtObj, &mfail))goto CLEANUP;	
	  }

         
	//	if(dstat = t5GetCntxtObjForPrtBom(PartObj,"ERC", "GlobalCtxt","Option1", &genCntxtObj, &mfail))goto CLEANUP;
		
		if(dstat = ulyCopyObjectToSet(PartObj,&SetOfPrt)) goto CLEANUP;

		if(dstat = t5BOMExpInVLERC(bomdtls,getList,PartObj,genCntxtObj,99,&level,&SetOfPrtRel,&StrctInt,&mfail))goto CLEANUP;

		fprintf(bomdtls,"\nSet Size of SetOfPrt Object Set:%d \n", StrctInt);fflush(bomdtls);
		fprintf(bomdtls,"\nSet Size of SetOfPrtRel Object Set:%d \n", setSize(SetOfPrtRel));fflush(bomdtls);

		 aString_test->__sizeClt = 1;
		 aString_test->__plmPartDetailClt	= malloc((aString_test ->__sizeClt + 1) * sizeof(*aString_test ->__plmPartDetailClt) );

		 aString_test->__plmPartDetailClt[0].PartClient = malloc(20* sizeof(char*)+5);
		 strcpy(aString_test->__plmPartDetailClt[0].PartClient,"TCE");

		if (StrctInt>0)
		{
			iPB	=	StrctInt;
			fprintf(bomdtls,"\niPB:%d \n", iPB);fflush(bomdtls);
			aString_test->__size = iPB;
			aString_test->__plmPartDetail	=	 malloc((aString_test ->__size + 600) * sizeof(*aString_test ->__plmPartDetail) );

			for (iPdt=0;iPdt<StrctInt ;iPdt++ )
			{
				cnt		=	iPdt+1;
				length	=	0;
				length	=	nlsStrLen(getList[cnt].Level);

				aString_test->__plmPartDetail[iPdt].PLevel = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].Level)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].PLevel,getList[cnt].Level);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].PLevel,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PrtObid);

				aString_test->__plmPartDetail[iPdt].PrtObid = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PrtObid)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].PrtObid,getList[cnt].PrtObid);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].PrtObid,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartNumber);

				aString_test->__plmPartDetail[iPdt].PartNum = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartNumber)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].PartNum,getList[cnt].PartNumber);
					fprintf(bomdtls,"\n####PartNum#### : %s \n", aString_test->__plmPartDetail[iPdt].PartNum);fflush(bomdtls);

				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].PartNum,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartRev);

				aString_test->__plmPartDetail[iPdt].Revision = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartRev)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Revision,getList[cnt].PartRev);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Revision,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartSeq);

				aString_test->__plmPartDetail[iPdt].Sequence = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartSeq))
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Sequence,getList[cnt].PartSeq);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Sequence,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartWeight);

				aString_test->__plmPartDetail[iPdt].Weight = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartWeight)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Weight,getList[cnt].PartWeight);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Weight,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartSurfArea);

				aString_test->__plmPartDetail[iPdt].SurArea = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartSurfArea)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].SurArea,getList[cnt].PartSurfArea);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].SurArea,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartVolume);

				aString_test->__plmPartDetail[iPdt].Volume = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartVolume)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Volume,getList[cnt].PartVolume);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Volume,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartMaterial);

				aString_test->__plmPartDetail[iPdt].Material = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartMaterial)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Material,getList[cnt].PartMaterial);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Material,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartDesc);

				aString_test->__plmPartDetail[iPdt].Descrpt = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartDesc)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Descrpt,getList[cnt].PartDesc);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Descrpt,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartCS);

				aString_test->__plmPartDetail[iPdt].CS = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartCS)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].CS,getList[cnt].PartCS);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].CS,"NA");
				}

				//Project
				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartProjCode);

				aString_test->__plmPartDetail[iPdt].ProjCode = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartProjCode)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].ProjCode,getList[cnt].PartProjCode);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].ProjCode,"NA");
				}

				//Project Desc
				length	=	0;
				length	=	nlsStrLen(getList[cnt].PartProjDesc);

				aString_test->__plmPartDetail[iPdt].ProjDesc = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PartProjDesc)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].ProjDesc,getList[cnt].PartProjDesc);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].ProjDesc,"NA");
				}

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PEnvDia);
				aString_test->__plmPartDetail[iPdt].PEnvDia = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PEnvDia)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].PEnvDia,getList[cnt].PEnvDia);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].PEnvDia,"NA");
				}
				fprintf(bomdtls,"\nPEnvDia : %s",getList[cnt].PEnvDia );fflush(bomdtls);
				
				//Thickness

				length	=	0;
				length	=	nlsStrLen(getList[cnt].PThickness);
				aString_test->__plmPartDetail[iPdt].Thickness = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PThickness)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Thickness,getList[cnt].PThickness);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Thickness,"0");
				}
				fprintf(bomdtls,"\nPThickness : %s",getList[cnt].PThickness );fflush(bomdtls);

				//Parttype
				length	=	0;
				length	=	nlsStrLen(getList[cnt].PParttype);
				aString_test->__plmPartDetail[iPdt].Parttype = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(getList[cnt].PParttype)) 
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Parttype,getList[cnt].PParttype);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[iPdt].Parttype,"NA");
				}
				fprintf(bomdtls,"\nPParttype : %s",getList[cnt].PParttype );fflush(bomdtls);
			}
		}
		if (setSize(SetOfPrtRel)>0)
		{
			iPR	=	setSize(SetOfPrtRel);
			fprintf(bomdtls,"\niPR:%d \n", iPR);fflush(bomdtls);
			aString_test->__sizeT = iPR;
			aString_test->__plmRelDetails	=	 malloc((aString_test ->__sizeT + 60000) * sizeof(*aString_test ->__plmRelDetails) );
			
			for (iPdt=0;iPdt<setSize(SetOfPrtRel) ;iPdt++ )
			{
				relObid			=	NULL;
				relObidDup		=	NULL;
				leftObid		=	NULL;
				leftObidDup		=	NULL;
				rightObid		=	NULL;
				rightObidDup	=	NULL;
				Qty				=	NULL;
				QtyDup			=	NULL;//DisplayQuantityAttr
				rightObidDup	=	NULL;
				relObj			=	NULL;
				
				if(dstat= objGetObject(setGet(SetOfPrtRel,iPdt),AssocRelationObjAttr,&relObj))goto EXIT;

				if(dstat=objGetAttribute(relObj,OBIDAttr,&relObid)) goto EXIT;
				if(!nlsIsStrNull(relObid))relObidDup=nlsStrDup(relObid);
				fprintf(bomdtls,"\nrelObidDup:%s \n", relObidDup);fflush(bomdtls);

				length	=	0;
				length	=	nlsStrLen(relObidDup);

				aString_test->__plmRelDetails[iPdt].rel_Obid = malloc((length* sizeof(char*))+5);

				if(!nlsIsStrNull(relObidDup)) 
				{
					nlsStrCpy(aString_test->__plmRelDetails[iPdt].rel_Obid,relObidDup);
				}
				else
				{
					nlsStrCpy(aString_test->__plmRelDetails[iPdt].rel_Obid,"NA");
				}

				if(dstat=objGetAttribute(setGet(SetOfPrtRel,iPdt),LeftAttr,&leftObid)) goto EXIT;
				if(!nlsIsStrNull(leftObid))leftObidDup=nlsStrDup(leftObid);
				fprintf(bomdtls,"\nleftObidDup:%s \n", leftObidDup);fflush(bomdtls);

				length	=	0;
				length	=	nlsStrLen(leftObidDup);

				aString_test->__plmRelDetails[iPdt].ParentObid = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(leftObidDup)) 
				{
					nlsStrCpy(aString_test->__plmRelDetails[iPdt].ParentObid,leftObidDup);
					fprintf(bomdtls,"\n******PartNum******* : %s \n", aString_test->__plmRelDetails[iPdt].ParentObid);fflush(bomdtls);
				}
				else
				{
					nlsStrCpy(aString_test->__plmRelDetails[iPdt].ParentObid,"NA");
				}

				if(dstat=objGetAttribute(setGet(SetOfPrtRel,iPdt),RightAttr,&rightObid)) goto EXIT;
				if(!nlsIsStrNull(rightObid))rightObidDup=nlsStrDup(rightObid);
				fprintf(bomdtls,"\nrightObidDup:%s \n", rightObidDup);fflush(bomdtls);

				length	=	0;
				length	=	nlsStrLen(rightObidDup);

				aString_test->__plmRelDetails[iPdt].ChildObid = malloc(length* sizeof(char*)+5);

				if(!nlsIsStrNull(rightObidDup)) 
				{
					nlsStrCpy(aString_test->__plmRelDetails[iPdt].ChildObid,rightObidDup);
					fprintf(bomdtls,"\n!!!!!!!!!PartNum!!!!!!!! : %s \n", aString_test->__plmRelDetails[iPdt].ChildObid);fflush(bomdtls);
				}
				else
				{
					nlsStrCpy(aString_test->__plmRelDetails[iPdt].ChildObid,"NA");
				}

				if(dstat=objGetAttribute(relObj,DisplayQuantityAttr,&QtyDup)) goto EXIT;
				if(!nlsIsStrNull(QtyDup))Qty=nlsStrDup(QtyDup);
				fprintf(bomdtls,"\nQtyDup:%s \n", Qty);fflush(bomdtls);
				
				aString_test->__plmRelDetails[iPdt].c_Qty = malloc(length* sizeof(char*)+5);
				if(!nlsIsStrNull(Qty)) 
				{
					nlsStrCpy(aString_test->__plmRelDetails[iPdt].c_Qty,Qty);
				}
				else
				{
					nlsStrCpy(aString_test->__plmRelDetails[iPdt].c_Qty,"NA");
				}

			}
		}
	}
	else if((setSize(soPartObjs)==0)&&(CVPROJ==1))
	{
		//check that part rev in TCUA
		fprintf(bomdtls,"\n* as CVPROJ is %d***",CVPROJ);fflush(bomdtls);
		fprintf(bomdtls,"\n PART not found in TCE, checking in TCUA");fflush(bomdtls);
		StrFullPathShell = nlsStrAlloc(400);//"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass"
		nlsStrCpy(StrFullPathShell,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/PartBomDetailsFrmTcua_CV/PartBomDetailsFrmTcua_CV.sh");
				
			txtargv[0] = StrFullPathShell;
			txtargv[1] = partnumber;
			if((nlsStrCmp(revision,"-")==0)||(nlsStrCmp(revision,"")==0))
		    {
				txtargv[2] ="TBD";
			}
			else
		    { 
			    txtargv[2] = revision;
			}
			if((nlsStrCmp(ISequence,"-")==0)||(nlsStrCmp(ISequence,"")==0))
		    {
				txtargv[3] = "TBD";
			}
			else
		    {
			    txtargv[3] = ISequence;
		    }
			txtargv[4] = ER_EW;
			if((nlsStrCmp(Plant,"-")==0)||(nlsStrCmp(Plant,"")==0))
		    {
				txtargv[5] = "TBD";
			}
			else
		    {
			   txtargv[5] = Plant;	
		    }
				

			for (cntr = 0;cntr < 6; cntr++ )
			{
				fprintf(bomdtls,"\n txtargv[%d] : [%s]", cntr, txtargv[cntr]); fflush(bomdtls);
			}

			fprintf(bomdtls,"\n StrFullPathShell : [%s]", StrFullPathShell); fflush(bomdtls);

			SysReturn = sysExecute(StrFullPathShell, txtargv);
			if(SysReturn == 0)
			{
				fprintf(bomdtls,"\n Execution Done Successfully ...");  fflush(bomdtls);
			}
			else
			{
				fprintf(bomdtls,"\n Execution Done Fail, Pl check Env variable and calling shell..\n"); fflush(bomdtls);
			}
	     int PartExistInTCUAFlag=0;


			//////////// reading tcua output file in tce web service...
			inputfile = nlsStrAlloc(2000);
			nlsStrCpy(inputfile,"");	
			nlsStrCpy(inputfile,"/plmuv_logs/omfprod/logs/PFIRST_TCE_TCUA_PART/");
			nlsStrCat(inputfile,partnumber);
			nlsStrCat(inputfile,"_TCUACV_PARTBOMDETAIL.txt");
			fprintf(bomdtls,"\n FIleNameSDup: [%s]\n",inputfile);  fflush(bomdtls);
			///plmuv_logs/omfprod/logs/PFIRST_TCE_TCUA_PART/517531200102_TCUACV_PARTBOMDETAIL.txt

			fp1=fopen(inputfile,"r");
			if(fp1!=NULL)  //Querying Part in CVPROD
			{
				while (fgets(fileRead,1000,fp1)!=NULL )
				{
					low_trimwb(fileRead);

					fprintf(bomdtls,"\n fileRead: [%s] ",fileRead);fflush(bomdtls);

					if (nlsStrStr(fileRead,"#*#")==NULL)
					{
						continue;
					}  

					PartExistInTCUAFlag=1;

					item_levelCV=NULL;	        //1
			        partNumberCV=NULL;			    //2
			        partRevNumberCV=NULL;			//3
			        ModItem_SeqCV=NULL;		        //4
			        WeightCV=NULL;	                //5
			        SurfaceAreaCV=NULL;	            //6
			        VolumeCV=NULL;		            //7
			        PartCSCV=NULL;		            //8
			        MaterialCV=NULL;                //9
			        DescriptionCV=NULL;             //10
			        PartProjCodeCV=NULL;            //11
			        PartProjCode1CV=NULL;          //12
			        EnvelopeDimensionsCV=NULL;      //13
			        ThicknesCV=NULL;                //14
			        PartTypeCV=NULL;                //15
			        quantityCV=NULL;                //16

					item_levelCV=strtok(fileRead,"#*#");	     //1
					partNumberCV=strtok(NULL,"#*#");			 //2
					partRevNumberCV=strtok(NULL,"#*#");		 //3
					ModItem_SeqCV=strtok(NULL,"#*#");		     //4
					WeightCV=strtok(NULL,"#*#");	             //5
					SurfaceAreaCV=strtok(NULL,"#*#");	         //6
					VolumeCV=strtok(NULL,"#*#");	             //7
					PartCSCV=strtok(NULL,"#*#");		         //8
					MaterialCV=strtok(NULL,"#*#");             //9
					DescriptionCV=strtok(NULL,"#*#");          //10
					PartProjCodeCV=strtok(NULL,"#*#");         //11
					PartProjCode1CV=strtok(NULL,"#*#");        //12
					EnvelopeDimensionsCV=strtok(NULL,"#*#");   //13
					ThicknesCV=strtok(NULL,"#*#");             //14
					PartTypeCV=strtok(NULL,"#*#");             //15
					quantityCV=strtok(NULL,"#*#");             //16
	

					fprintf(bomdtls,"\n item_levelCV: [%s]",item_levelCV); fflush(bomdtls);                //1
					fprintf(bomdtls," partNumberCV: [%s]",partNumberCV); fflush(bomdtls);                  //2
					fprintf(bomdtls," partRevNumberCV: [%s]",partRevNumberCV); fflush(bomdtls);            //3
					fprintf(bomdtls," ModItem_SeqCV: [%s]",ModItem_SeqCV); fflush(bomdtls);                //4
					fprintf(bomdtls," WeightCV: [%s]",WeightCV); fflush(bomdtls);                          //5
					fprintf(bomdtls," SurfaceAreaCV: [%s]",SurfaceAreaCV); fflush(bomdtls);                //6
					fprintf(bomdtls," VolumeCV: [%s]",VolumeCV); fflush(bomdtls);                          //7
					fprintf(bomdtls," PartCSCV: [%s] ",PartCSCV); fflush(bomdtls);                         //8
					fprintf(bomdtls," MaterialCV: [%s] ",MaterialCV); fflush(bomdtls);                     //9
					fprintf(bomdtls," DescriptionCV: [%s] ",DescriptionCV); fflush(bomdtls);               //10
					fprintf(bomdtls," PartProjCodeCV: [%s] ",PartProjCodeCV); fflush(bomdtls);             //11
					fprintf(bomdtls," PartProjCode1CV: [%s] ",PartProjCode1CV); fflush(bomdtls);           //12
					fprintf(bomdtls," EnvelopeDimensionsCV: [%s] ",EnvelopeDimensionsCV); fflush(bomdtls); //13
					fprintf(bomdtls," ThicknesCV: [%s] ",ThicknesCV); fflush(bomdtls);                     //14
					fprintf(bomdtls," PartTypeCV: [%s] ",PartTypeCV); fflush(bomdtls);                     //15
					fprintf(bomdtls," quantityCV: [%s] ",quantityCV); fflush(bomdtls);                     //16


					PartInfoStr=nlsStrAlloc(1000);
					nlsStrCpy(PartInfoStr,"");
					nlsStrCpy(PartInfoStr,item_levelCV);          //1
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,partNumberCV);          //2
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,partRevNumberCV);       //3
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,ModItem_SeqCV);         //4
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,WeightCV);              //5
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,SurfaceAreaCV);         //6
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,VolumeCV);              //7
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,PartCSCV);              //8
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,MaterialCV);            //9
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,DescriptionCV);         //10
					nlsStrCat(PartInfoStr,"#^#"); 
					nlsStrCat(PartInfoStr,PartProjCodeCV);        //11
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,PartProjCode1CV);       //12
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,EnvelopeDimensionsCV);  //13
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,ThicknesCV);            //14
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,PartTypeCV);            //15
					nlsStrCat(PartInfoStr,"#^#");
					nlsStrCat(PartInfoStr,quantityCV);            //16
					nlsStrCat(PartInfoStr,"#^#");

					//if(low_set_find_str(partBomSET,partNumberCV) < 0)
					//{
						fprintf(bomdtls,"\n  not Present in set hence adding  [%s]",PartInfoStr); fflush(bomdtls);
						low_set_insrt_str(partBomData,0,PartInfoStr);
						low_set_insrt_str(partBomData1,0,PartInfoStr);
						low_set_insrt_str(partBomSET,0,partNumberCV);
					//}
				}
			}
			fprintf(bomdtls,"\n PartExistInTCUAFlag: %d  CVpartBom size partBomData : %d ,  partBomData1 : %d \n",PartExistInTCUAFlag,setSize(partBomData),setSize(partBomData1)); fflush(bomdtls);

           aString_test->__sizeClt = 1;
		   aString_test->__plmPartDetailClt	= malloc((aString_test ->__sizeClt + 1) * sizeof(*aString_test ->__plmPartDetailClt) );

		   aString_test->__plmPartDetailClt[0].PartClient = malloc(20* sizeof(char*)+5);
		   strcpy(aString_test->__plmPartDetailClt[0].PartClient,"TCUA_CV");

         if(setSize(partBomData)>0) 	//Set of Part in TCE or TCUA
		 {
			int jk=0;
			//int va=0;
			//va=setSize(partBomData)-1;
			fprintf(bomdtls,"\n setSize(partBomData)   [%d]",setSize(partBomData)); fflush(bomdtls);
			aString_test->__size  = setSize(partBomData);
			aString_test->__plmPartDetail = malloc((aString_test ->__size + 600) * sizeof(*aString_test ->__plmPartDetail) );
			
			for(jk=0; jk<setSize(partBomData); jk++)
			{

				strSet = NULL;
				item_levelCV=NULL;	        //1
				partNumberCV=NULL;			    //2
				partRevNumberCV=NULL;			//3
				ModItem_SeqCV=NULL;		        //4
				WeightCV=NULL;	                //5
				SurfaceAreaCV=NULL;	            //6
				VolumeCV=NULL;		            //7
				PartCSCV=NULL;		            //8
				MaterialCV=NULL;                //9
				DescriptionCV=NULL;             //10
				PartProjCodeCV=NULL;            //11
				PartProjCode1CV=NULL;          //12
				EnvelopeDimensionsCV=NULL;      //13
				ThicknesCV=NULL;                //14
				PartTypeCV=NULL;                //15
				quantityCV=NULL;                //16
				strSet=low_set_get(partBomData,jk);

				fprintf(bomdtls,"\n jk: [%d]  strSet: %s",jk,strSet); fflush(bomdtls);

				item_levelCV=strtok(strSet,"#^#");	        //1
				partNumberCV=strtok(NULL,"#^#");			    //2
				partRevNumberCV=strtok(NULL,"#^#");			//3
				ModItem_SeqCV=strtok(NULL,"#^#");		        //4
				WeightCV=strtok(NULL,"#^#");	                //5
				SurfaceAreaCV=strtok(NULL,"#^#");	            //6
				VolumeCV=strtok(NULL,"#^#");		            //7
				PartCSCV=strtok(NULL,"#^#");		            //8
				MaterialCV=strtok(NULL,"#^#");                //9
				DescriptionCV=strtok(NULL,"#^#");             //10
				PartProjCodeCV=strtok(NULL,"#^#");            //11
				PartProjCode1CV=strtok(NULL,"#^#");           //12
				EnvelopeDimensionsCV=strtok(NULL,"#^#");      //13
				ThicknesCV=strtok(NULL,"#^#");                //14
				PartTypeCV=strtok(NULL,"#^#");                //15
				quantityCV=strtok(NULL,"#^#");                //16
				

				if(nlsIsStrNull(item_levelCV)){	nlsStrCpy(item_levelCV,"NA");}
				if(nlsIsStrNull(partNumberCV)){nlsStrCpy(partNumberCV,"NA");}
				if(nlsIsStrNull(partRevNumberCV)){nlsStrCpy(partRevNumberCV,"NA");}
				if(nlsIsStrNull(ModItem_SeqCV)){nlsStrCpy(ModItem_SeqCV,"NA");}
				if(nlsIsStrNull(WeightCV)){nlsStrCpy(WeightCV,"NA");}
                if(nlsIsStrNull(SurfaceAreaCV)){nlsStrCpy(SurfaceAreaCV,"NA");}
				if(nlsIsStrNull(VolumeCV)){	nlsStrCpy(VolumeCV,"NA");}
                if(nlsIsStrNull(PartCSCV)){	nlsStrCpy(PartCSCV,"NA");}
				if(nlsIsStrNull(MaterialCV)){nlsStrCpy(MaterialCV,"NA");}
                if(nlsIsStrNull(DescriptionCV)){nlsStrCpy(DescriptionCV,"NA");}
                if(nlsIsStrNull(PartProjCodeCV)){nlsStrCpy(PartProjCodeCV,"NA");}
                if(nlsIsStrNull(PartProjCode1CV)){nlsStrCpy(PartProjCode1CV,"NA");}
                if(nlsIsStrNull(EnvelopeDimensionsCV)){nlsStrCpy(EnvelopeDimensionsCV,"NA");}
                if(nlsIsStrNull(ThicknesCV)){nlsStrCpy(ThicknesCV,"NA");}
                if(nlsIsStrNull(PartTypeCV)){nlsStrCpy(PartTypeCV,"NA");}
                if(nlsIsStrNull(quantityCV)){nlsStrCpy(quantityCV,"NA");}


				length	=	500;
				//length	=	nlsStrLen(item_levelCV);
				aString_test->__plmPartDetail[jk].PLevel = malloc(length* sizeof(char*)+5);
				aString_test->__plmPartDetail[jk].PrtObid = malloc(length* sizeof(char*)+5);
				//length	=	nlsStrLen(partNumberCV);
				aString_test->__plmPartDetail[jk].PartNum = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(partRevNumberCV);
				aString_test->__plmPartDetail[jk].Revision = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(ModItem_SeqCV);
				aString_test->__plmPartDetail[jk].Sequence = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(WeightCV);
				aString_test->__plmPartDetail[jk].Weight = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(SurfaceAreaCV);
				aString_test->__plmPartDetail[jk].SurArea = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(VolumeCV);
				aString_test->__plmPartDetail[jk].Volume = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(PartCSCV);
				aString_test->__plmPartDetail[jk].Material = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(MaterialCV);
				aString_test->__plmPartDetail[jk].Descrpt = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(DescriptionCV);
				aString_test->__plmPartDetail[jk].CS = malloc(length * sizeof(char *));
				
				//length	=	nlsStrLen(PartProjCodeCV);
				aString_test->__plmPartDetail[jk].ProjCode = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(PartProjCode1CV);
				aString_test->__plmPartDetail[jk].ProjDesc = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(EnvelopeDimensionsCV);
				aString_test->__plmPartDetail[jk].PEnvDia = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(ThicknesCV);
				aString_test->__plmPartDetail[jk].Thickness = malloc(length * sizeof(char *) );
				
				//length	=	nlsStrLen(PartTypeCV);
				aString_test->__plmPartDetail[jk].Parttype = malloc(length * sizeof(char *) );
				

			/*  nlsStrCpy(aString_test->__plmPartDetail[jk].PLevel,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].PartNum,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].Revision,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].Sequence,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].Weight,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].SurArea,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].Volume,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].Material,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].Descrpt,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].CS,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].ProjCode,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].ProjDesc,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].PEnvDia,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].Thickness,"");
				nlsStrCpy(aString_test->__plmPartDetail[jk].Parttype,"");  */
				

				if(!nlsIsStrNull(item_levelCV))
				{
				 fprintf(bomdtls,"\ninside levelCV : %s\n",item_levelCV); fflush(bomdtls); //1
				 nlsStrCpy(aString_test->__plmPartDetail[jk].PLevel,item_levelCV);
				}
				else
				{
					fprintf(bomdtls,"inside else levelCV : %s\n",item_levelCV); fflush(bomdtls); //1
					nlsStrCpy(aString_test->__plmPartDetail[jk].PLevel,"NA");
				}
				nlsStrCpy(aString_test->__plmPartDetail[jk].PrtObid,"NA");
				if(!nlsIsStrNull(partNumberCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].PartNum,partNumberCV);
				fprintf(bomdtls,"\n@@@@@@ PartNum @@@@@@@ : %s \n", aString_test->__plmPartDetail[jk].PartNum);fflush(bomdtls);
				}
				else
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].PartNum,"NA");
				}
				if(!nlsIsStrNull(partRevNumberCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].Revision,partRevNumberCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].Revision,"NA");
				}
				if(!nlsIsStrNull(ModItem_SeqCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].Sequence,ModItem_SeqCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].Sequence,"NA");
				}
				if(!nlsIsStrNull(WeightCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].Weight,WeightCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].Weight,"NA");
				}
				if(!nlsIsStrNull(SurfaceAreaCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].SurArea,SurfaceAreaCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].SurArea,"NA");
				}
				if(!nlsIsStrNull(VolumeCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].Volume,VolumeCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].Volume,"NA");
				}
				if(!nlsIsStrNull(PartCSCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].CS,PartCSCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].CS,"NA");
				}
				if(!nlsIsStrNull(MaterialCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].Material,MaterialCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].Material,"NA");
				}
				if(!nlsIsStrNull(DescriptionCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].Descrpt,DescriptionCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].Descrpt,"NA");
				}
				if(!nlsIsStrNull(PartProjCodeCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].ProjCode,PartProjCodeCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].ProjCode,"NA");
				}
				if(!nlsIsStrNull(PartProjCode1CV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].ProjDesc,PartProjCode1CV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].ProjDesc,"NA");
				}
				if(!nlsIsStrNull(EnvelopeDimensionsCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].PEnvDia,EnvelopeDimensionsCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].PEnvDia,"NA");
				}
				if(!nlsIsStrNull(ThicknesCV))
				{
				nlsStrCpy(aString_test->__plmPartDetail[jk].Thickness,ThicknesCV);
				}
				else
				{
					nlsStrCpy(aString_test->__plmPartDetail[jk].Thickness,"NA");
				}
				if(!nlsIsStrNull(PartTypeCV))
				{
					fprintf(bomdtls,"\ninside PartTypeCV : %s",PartTypeCV); fflush(bomdtls); //1
				nlsStrCpy(aString_test->__plmPartDetail[jk].Parttype,PartTypeCV);
				}
				else
				{
					fprintf(bomdtls,"\ninside PartTypeCV : %s",PartTypeCV); fflush(bomdtls); //1
					nlsStrCpy(aString_test->__plmPartDetail[jk].Parttype,"NA");
				}

				
				fprintf(bomdtls,"\nitem_levelCV : %s\n",item_levelCV); fflush(bomdtls); //1
				fprintf(bomdtls,"partNumberCV : %s\n",partNumberCV); fflush(bomdtls); //2
				fprintf(bomdtls,"partRevNumberCV : %s\n",partRevNumberCV); fflush(bomdtls); //3
				fprintf(bomdtls,"ModItem_SeqCV : %s\n",ModItem_SeqCV); fflush(bomdtls); //4
				fprintf(bomdtls,"WeightCV : %s\n",WeightCV); fflush(bomdtls); //5
				fprintf(bomdtls,"SurfaceAreaCV : %s\n",SurfaceAreaCV); fflush(bomdtls); //6
				fprintf(bomdtls,"VolumeCV : %s\n",VolumeCV); fflush(bomdtls); //7
				fprintf(bomdtls,"PartCSCV : %s\n",PartCSCV); fflush(bomdtls); //8
				fprintf(bomdtls,"MaterialCV : %s\n",MaterialCV); fflush(bomdtls); //9
				fprintf(bomdtls,"DescriptionCV : %s\n",DescriptionCV); fflush(bomdtls); //10
				fprintf(bomdtls,"PartProjCodeCV : %s\n",PartProjCodeCV); fflush(bomdtls); //11
				fprintf(bomdtls,"PartProjCode1CV : %s\n",PartProjCode1CV); fflush(bomdtls); //12
				fprintf(bomdtls,"EnvelopeDimensionsCV : %s\n",EnvelopeDimensionsCV); fflush(bomdtls); //13
				fprintf(bomdtls,"ThicknesCV : %s\n",ThicknesCV); fflush(bomdtls); //14
				fprintf(bomdtls,"PartTypeCV : %s\n",PartTypeCV); fflush(bomdtls); //15
				fprintf(bomdtls,"quantityCV : %s\n",quantityCV); fflush(bomdtls); //16

				
			}
		

		 if(setSize(partBomData1)>0) 	//Set of Part in TCE or TCUA
		 {
			int jp=0;
			int vp=0;
			vp=(setSize(partBomData1)-1);
			fprintf(bomdtls,"\n vp   [%d]",vp); fflush(bomdtls);
			aString_test->__sizeT = setSize(partBomData1);	
			aString_test->__plmRelDetails	=	 malloc((aString_test ->__sizeT + 60000) * sizeof(*aString_test ->__plmRelDetails) );

			for(jp=0; jp<(setSize(partBomData1)-1); jp++)
			{	
				strSet1 = NULL;
				item_levelCV=NULL;	        //1
				partNumberCV=NULL;			    //2
				partRevNumberCV=NULL;			//3
				ModItem_SeqCV=NULL;		        //4
				WeightCV=NULL;	                //5
				SurfaceAreaCV=NULL;	            //6
				VolumeCV=NULL;		            //7
				PartCSCV=NULL;		            //8
				MaterialCV=NULL;                //9
				DescriptionCV=NULL;             //10
				PartProjCodeCV=NULL;            //11
				PartProjCode1CV=NULL;          //12
				EnvelopeDimensionsCV=NULL;      //13
				ThicknesCV=NULL;                //14
				PartTypeCV=NULL;                //15
				quantityCV=NULL;                //16

				strSet1=low_set_get(partBomData1,jp);

				fprintf(bomdtls,"\n jp: [%d]  strSet1: %s",jp,strSet1); fflush(bomdtls);

				item_levelCV=strtok(strSet1,"#^#");	        //1
				partNumberCV=strtok(NULL,"#^#");			    //2
				partRevNumberCV=strtok(NULL,"#^#");			//3
				ModItem_SeqCV=strtok(NULL,"#^#");		        //4
				WeightCV=strtok(NULL,"#^#");	                //5
				SurfaceAreaCV=strtok(NULL,"#^#");	            //6
				VolumeCV=strtok(NULL,"#^#");		            //7
				PartCSCV=strtok(NULL,"#^#");		            //8
				MaterialCV=strtok(NULL,"#^#");                //9
				DescriptionCV=strtok(NULL,"#^#");             //10
				PartProjCodeCV=strtok(NULL,"#^#");            //11
				PartProjCode1CV=strtok(NULL,"#^#");           //12
				EnvelopeDimensionsCV=strtok(NULL,"#^#");      //13
				ThicknesCV=strtok(NULL,"#^#");                //14
				PartTypeCV=strtok(NULL,"#^#");                //15
				quantityCV=strtok(NULL,"#^#");                //16

				if(nlsIsStrNull(item_levelCV)){	nlsStrCpy(item_levelCV,"NA");}
				if(nlsIsStrNull(partNumberCV)){nlsStrCpy(partNumberCV,"NA");}
				if(nlsIsStrNull(partRevNumberCV)){nlsStrCpy(partRevNumberCV,"NA");}
				if(nlsIsStrNull(ModItem_SeqCV)){nlsStrCpy(ModItem_SeqCV,"NA");}
				if(nlsIsStrNull(WeightCV)){nlsStrCpy(WeightCV,"NA");}
                if(nlsIsStrNull(SurfaceAreaCV)){nlsStrCpy(SurfaceAreaCV,"NA");}
				if(nlsIsStrNull(VolumeCV)){	nlsStrCpy(VolumeCV,"NA");}
                if(nlsIsStrNull(PartCSCV)){	nlsStrCpy(PartCSCV,"NA");}
				if(nlsIsStrNull(MaterialCV)){nlsStrCpy(MaterialCV,"NA");}
                if(nlsIsStrNull(DescriptionCV)){nlsStrCpy(DescriptionCV,"NA");}
                if(nlsIsStrNull(PartProjCodeCV)){nlsStrCpy(PartProjCodeCV,"NA");}
                if(nlsIsStrNull(PartProjCode1CV)){nlsStrCpy(PartProjCode1CV,"NA");}
                if(nlsIsStrNull(EnvelopeDimensionsCV)){nlsStrCpy(EnvelopeDimensionsCV,"NA");}
                if(nlsIsStrNull(ThicknesCV)){nlsStrCpy(ThicknesCV,"NA");}
                if(nlsIsStrNull(PartTypeCV)){nlsStrCpy(PartTypeCV,"NA");}
                if(nlsIsStrNull(quantityCV)){nlsStrCpy(quantityCV,"NA");}
				
				length	=	1000;
				//length	=	nlsStrLen(partNumberCV);
				aString_test->__plmRelDetails[jp].rel_Obid = malloc((length* sizeof(char*))+5);
				aString_test->__plmRelDetails[jp].ParentObid = malloc(length* sizeof(char*)+5);
				aString_test->__plmRelDetails[jp].ChildObid = malloc(length* sizeof(char*)+5);
				//length	=	nlsStrLen(quantityCV);
				aString_test->__plmRelDetails[jp].c_Qty = malloc(length * sizeof(char *) );

				/*nlsStrCpy(aString_test->__plmPartDetail[jp].PLevel,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].PartNum,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].Revision,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].Sequence,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].Weight,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].SurArea,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].Volume,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].Material,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].Descrpt,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].CS,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].ProjCode,"");
				nlsStrCpy(aString_test->__plmPartDetail[jp].ProjDesc,""); 
				nlsStrCpy(aString_test->__plmRelDetails[jp].rel_Obid,"");
				nlsStrCpy(aString_test->__plmRelDetails[jp].ParentObid,"");
				nlsStrCpy(aString_test->__plmRelDetails[jp].ChildObid,"");
				nlsStrCpy(aString_test->__plmRelDetails[jp].c_Qty,"");  */


				nlsStrCpy(aString_test->__plmRelDetails[jp].rel_Obid,"NA");
				nlsStrCpy(aString_test->__plmRelDetails[jp].ParentObid,"NA");
				nlsStrCpy(aString_test->__plmRelDetails[jp].ChildObid,partNumberCV);

				if(!nlsIsStrNull(quantityCV))
				{
					fprintf(bomdtls,"\ninside quantityCV : %s",quantityCV); fflush(bomdtls); //1
				nlsStrCpy(aString_test->__plmRelDetails[jp].c_Qty,quantityCV);
				}
				else
				{
					fprintf(bomdtls,"inside else quantityCV : %s\n\n",quantityCV); fflush(bomdtls); //1
					nlsStrCpy(aString_test->__plmRelDetails[jp].c_Qty,"NA");
				}

				fprintf(bomdtls,"\nitem_levelCV : %s\n",item_levelCV); fflush(bomdtls); //1
				fprintf(bomdtls,"partNumberCV : %s\n",partNumberCV); fflush(bomdtls); //2
				fprintf(bomdtls,"partRevNumberCV : %s\n",partRevNumberCV); fflush(bomdtls); //3
				fprintf(bomdtls,"ModItem_SeqCV : %s\n",ModItem_SeqCV); fflush(bomdtls); //4
				fprintf(bomdtls,"WeightCV : %s\n",WeightCV); fflush(bomdtls); //5
				fprintf(bomdtls,"SurfaceAreaCV : %s\n",SurfaceAreaCV); fflush(bomdtls); //6
				fprintf(bomdtls,"VolumeCV : %s\n",VolumeCV); fflush(bomdtls); //7
				fprintf(bomdtls,"PartCSCV : %s\n",PartCSCV); fflush(bomdtls); //8
				fprintf(bomdtls,"MaterialCV : %s\n",MaterialCV); fflush(bomdtls); //9
				fprintf(bomdtls,"DescriptionCV : %s\n",DescriptionCV); fflush(bomdtls); //10
				fprintf(bomdtls,"PartProjCodeCV : %s\n",PartProjCodeCV); fflush(bomdtls); //11
				fprintf(bomdtls,"PartProjCode1CV : %s\n",PartProjCode1CV); fflush(bomdtls); //12
				fprintf(bomdtls,"EnvelopeDimensionsCV : %s\n",EnvelopeDimensionsCV); fflush(bomdtls); //13
				fprintf(bomdtls,"ThicknesCV : %s\n",ThicknesCV); fflush(bomdtls); //14
				fprintf(bomdtls,"PartTypeCV : %s\n",PartTypeCV); fflush(bomdtls); //15
				fprintf(bomdtls,"quantityCV : %s\n",quantityCV); fflush(bomdtls); //16

				
			}
		} 
	  }
	}
	else
	{
		fprintf(bomdtls,"\nNo ERC Released and above part found %s,%s",partnumber,revision);fflush(bomdtls);
	}

	fprintf(bomdtls,"\n*************************************End OF Program**************************************************************\n\n");fflush(bomdtls);
	if(bomdtls != NULL)
		{
			fclose(bomdtls);
			bomdtls=NULL;
		}

	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
	return SOAP_OK;
 
CLEANUP :
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);
		return SOAP_OK;
EXIT:
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
	return SOAP_OK;
}