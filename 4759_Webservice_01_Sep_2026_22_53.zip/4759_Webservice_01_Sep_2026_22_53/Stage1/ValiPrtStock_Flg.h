//gsoap ns service name:			ValiPrtStock_Flg
//gsoap ns service style:			rpc
//gsoap ns service namespace:		urn:ValiPrtStock_Flg  
//gsoap ns service location:			http://172.22.97.8:9010/cgi/ValiPrtStock_Flg.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:		urn:ValiPrtStock_Flg
//gsoap ns service method-documentation: Tests the Simple Web service
int ns__getValiPrtStock(char *partnumber, char *sapplant,char* pvflg, char **Response);