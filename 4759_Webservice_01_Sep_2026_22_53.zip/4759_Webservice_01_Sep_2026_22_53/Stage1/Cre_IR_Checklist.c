#include <soapH.h> /* get the gSOAP-generated definitions */
#include <Cre_IR_Checklist.nsmap> /* get the gSOAP-generated namespace bindings */
#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>



#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

char* subString (char* mainStringf ,int fromCharf,int toCharf);

char* subString
(
	char* mainStringf ,
	int fromCharf     ,
	int toCharf
)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


//char* subResult (char* mainStringf);
//char* subResult
//(
//	char* assignment ,
//	int fromCharf     ,
//	int toCharf
//)
//{
//	int i;
//	char *retStringf;
//	retStringf = (char*) malloc(toCharf+1);
//	for(i=0; i < toCharf; i++ )
//              *(retStringf+i) = *(mainStringf+i+fromCharf);
//	*(retStringf+i) = '\0';
//	return retStringf;
//}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    //printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	//printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		//printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		//printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
	{
	char *error_msg_string;

	EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	//printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	//printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}

extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new()); /* call the request dispatcher */
} 
;


//TR_RqDomain
//TR_RqProjCode
//TR_RqProjDes
//TR_BU
//TR_WBS
//TR_WbsDesc
//TR_TestSubGrp
//TR_RqAggregate
//TR_RqProgram
//TR_RqDesStatus
//TR_CtrDrwNo
//TR_TstReqRef
//TR_RqRefDVP
//TR_RqReqDep
//TR_RqVehStage
//TR_RqSupplier
//TR_RqInvType
//TR_DescComp
//TR_RqTestDetails
//TR_RqBGHistory
//TR_RqChkMetRep
//TR_RqMetRepNo
//TR_RqChkQaRep
//TR_RqQaRepNo
//TR_RqChkPartyRep
//TR_RqPartyRepNo
//TR_SamplPeriGvn
//TR_RqSmplNo
//TR_RqGIN   /home/people/uaprod/apache-tomcat-6.0.29/webapps/ROOT/WEB-INF/cgi
/* 
int ns__Cre_TR_RMDV(struct soap* soap, char *TR_No, char *TR_RqDomain, char *TR_RqProjCode, char *TR_RqProjDes,char *TR_BU, char *TR_WBS,char *TR_WbsDesc,char* TR_TestSubGrp,char *TR_RqAggregate,char *TR_RqProgram, 
	char *TR_RqDesStatus,char *TR_TstReqRef, char *TR_RqRefDVP,char *TR_RqReqDep,char *TR_RqVehStage,char *TR_RqSupplier, char *TR_RqInvType,char *TR_DescComp, char *TR_RqTestDetails,char *TR_RqBGHistory,char *TR_RqChkMetRep,
	char* TR_RqMetRepNo,char *TR_RqChkQaRep, char *TR_RqQaRepNo, char *TR_RqChkPartyRep, char *TR_RqPartyRepNo, char *TR_SamplPeriGvn, char *TR_RqSmplNo, char *TR_RqGIN, char *Part_Number,char *Owner,char *TestEngineer, char **responseT) */

//int ns__Cre_TR_RMDV(struct soap* soap, char *TR_No, char *TR_RqDomain, char *TR_RqProjCode, char *TR_RqProjDes,char *TR_BU, char *TR_WBS,char *TR_WbsDesc,char* TR_TestSubGrp,char *TR_RqAggregate,char *TR_RqProgram)


int ns__Cre_IR_Checklist(struct soap* soap, char *module_no,char *DesignRuleID, char *status, char *Remark, char **responseT)
{
	int ifail =0;


	//char *logFile;




	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/logIRChecklist.txt", "w", stdout);

	ifail =ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	//ifail =ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering") ;
	ifail =ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering") ;
	ifail =ITK_auto_login( );
	ifail =ITK_set_journalling( TRUE ); 

	//logFile = (char *) malloc(sizeof (char) * 50 );
	//strcpy(logFile,"/tmp/");
	//strcat(logFile,module_no);
	//strcat(logFile,"_RMDV.log");
	//freopen(logFile, "w", stdout);
	FILE *RepFP=NULL;
	char *InpFile;
	InpFile = (char *) malloc(sizeof (char) * 500 );
	//strcpy(InpFile,"/user/sks08539/TDM/TR_RMDV/");

  
    strcpy(InpFile,"/user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/");

/*	if (tc_strstr(status,"5442") || tc_strstr(status,"5445")|| tc_strstr(status,"5457")|| tc_strstr(status,"5447")|| tc_strstr(status,"5464")|| tc_strstr(status,"5465")|| tc_strstr(status,"5467")|| tc_strstr(status,"5123")|| tc_strstr(status,"5458")|| tc_strstr(status,"5466")|| tc_strstr(status,"5468"))
	{
		strcpy(InpFile,"/proj/PLMLoading/UAFiles/TR_RMDV/TCUA/");
	}
	else
	{
		strcpy(InpFile,"/proj/PLMLoading/UAFiles/TR_RMDV/TCE/");
	}

	*/
	
	//strcpy(InpFile,"/tmp/");
	strcat(InpFile,module_no);
	strcat(InpFile,"_Input.txt");
	RepFP=fopen(InpFile, "w");

 

	*responseT = malloc(sizeof (char) * 500 );
	

	//tc_strcpy(*responseT,"NULL");
	if(module_no)
	{
		//printf("\n TR_TestSubGrp is manadatory attribute %s \n",TR_TestSubGrp);fflush(stdout);
	}
	else
	{
		//printf("\n Testing Sub group is manadatory attribute.");fflush(stdout);
		strcpy(*responseT,"module is manadatory attribute");
		return SOAP_OK; 
	}
	
	if (RepFP)
	{
	//	fprintf(RepFP,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^",module_no,DesignRuleID,status,Remark,TR_BU,TR_WBS,TR_WbsDesc,TR_TestSubGrp,TR_RqAggregate,TR_RqProgram,TR_RqDesStatus,TR_TstReqRef,TR_RqRefDVP,TR_RqReqDep,TR_RqVehStage,TR_RqSupplier,TR_RqInvType,TR_DescComp,TR_RqTestDetails,TR_RqBGHistory,TR_RqChkMetRep,TR_RqMetRepNo,TR_RqChkQaRep,TR_RqQaRepNo,TR_RqChkPartyRep,TR_RqPartyRepNo,TR_SamplPeriGvn,TR_RqSmplNo,TR_RqGIN,Part_Number,Owner,TestEngineer);
		fprintf(RepFP,"%s,%s,%s,%s,",module_no,DesignRuleID,status,Remark);
	}

          	
	//printf("\n********************************************************************************************\n");fflush(stdout);
	
	if (RepFP)
	{
		fclose(RepFP);
		
	}
	//printf("\n 1complete 1\n");fflush(stdout);
	dup2(fd, fileno(stdout));
	
	close(fd);
	
	clearerr(stdout);
	
	fsetpos(stdout, &pos);
	
	strcpy(*responseT,"Success");

	ITK_exit_module(true);
	
	return SOAP_OK;

}
;


//DesignRuleID
//status
//Remark
//TR_BU
//TR_WBS
//TR_WbsDesc
//TR_TestSubGrp
//TR_RqAggregate
//TR_RqProgram
//TR_RqDesStatus
//TR_CtrDrwNo
//TR_TstReqRef
//TR_RqRefDVP
//TR_RqReqDep
//TR_RqVehStage
//TR_RqSupplier
//TR_RqInvType
//TR_DescComp
//TR_RqTestDetails
//TR_RqBGHistory
//TR_RqChkMetRep
//TR_RqMetRepNo
//TR_RqChkQaRep
//TR_RqQaRepNo
//TR_RqChkPartyRep
//TR_RqPartyRepNo
//TR_SamplPeriGvn
//TR_RqSmplNo
//TR_RqGIN


//scp -r testcmi@172.22.97.28:/user/testcmi/Saurabh/WS_RMDV/Cre_TR_RMDV.cgi .