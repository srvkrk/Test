#include "soapH.h"
#include "Pdcastatus.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
logical StatusFound = false;
static date_t TML_token_to_date( char *str );
static void MM_check_status(int count, tag_t *status_list, tag_t * revstatus);
static void MM_ReleaseRevision(tag_t rev,tag_t *released_rev,logical updatable);
static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   // ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
	//fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;

static void MM_ReleaseRevision(tag_t rev,tag_t *released_rev,logical updatable)
{
	int   hits						= 0,
		count						= 0,
		ifail						= 0;

	char *status_name				= NULL;

	tag_t list						= NULLTAG,
		set_effec					= NULLTAG,
		revstatus					= NULLTAG,
		release_status			= NULLTAG;

	tag_t  *status_list				= NULL;
	date_t ReleasedDate = NULLDATE;

	char         *stamp             = NULL;
	char         *itemId             = NULL;

	char  name[WSO_name_size_c+1]    = {'\0'};

	time_t now;

	char ReleasedDate_str[12] = {'\0'};

	struct tm* now_tm;

	StatusFound = false;

	printf("\n Inside MM_ReleaseRevision \n");fflush(stdout);

	ifail=CR_find_status_type("T5_LcsErcRlzd",&list );
	//printf("\n find status list hits:%d\n",list);

	ifail=CR_create_release_status( "T5_LcsErcRlzd",&release_status);


	ifail=WSOM_ask_release_status_list(rev ,&count,&status_list);

	printf("\n Inside MM_ReleaseRevision::count-->[%d]\n",count);fflush(stdout);
	//Check this status is alreasy present in ItemRevision
	MM_check_status(count,status_list,&revstatus);



	//if Status is not present ,it will add status under ItemRevision
	if ( !StatusFound )
	{
       if(updatable)
	{

		tag_t	releaseStatusListId = NULLTAG;
		tag_t	releaseDateId	= NULLTAG;
		//char *ReleasedDate_str="2014/10/11";// Get the Current Date

		time(&now);

		now_tm = localtime(&now);



		strftime (ReleasedDate_str, 12, "%Y/%m/%d", now_tm);
		printf("\n MM_ReleaseRevision::Time out is [%s]",ReleasedDate_str);fflush(stdout);


		ReleasedDate =	TML_token_to_date(ReleasedDate_str);
		printf("\n Before Call DatePlusDays");fflush(stdout);
		//DatePlusDays( &ReleasedDate, 1 ) ;
		printf("\n After Call DatePlusDays");fflush(stdout);

		ifail = AOM_set_value_date(release_status, "date_released", ReleasedDate);

         printf("\n find status list hits fail=%d ",ifail);fflush(stdout);

		/* Load the workspace object for modification */
		ifail = AOM_refresh(rev, POM_modify_lock);

		AOM_ask_value_string(rev,"item_id",&itemId);
		printf("\n 1 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);


		/* Get the id of attribute WorkspaceObject.release_status_list */
		ifail = POM_attr_id_of_attr("release_status_list", "WorkspaceObject", &releaseStatusListId);
		printf("\n 2 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);

		ifail = POM_attr_id_of_attr("date_released", "WorkspaceObject", &releaseDateId);
         printf("\n 2find status list hits fail=%d ",ifail);fflush(stdout);
		printf("\n 3 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);


		/* Update the workspace object attached status list */
		ifail = POM_set_attr_tags(1, &rev, releaseStatusListId, 0, 1, &release_status);
		printf("\n 4 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
         printf("\n 3 find status list hits fail=%d ",ifail);fflush(stdout);

		ifail = POM_set_attr_date(1, &rev, releaseDateId, ReleasedDate);
		printf("\n 5 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
         printf("\n 4find status list hits fail=%d ",ifail);fflush(stdout);




		/* Save the newly create release status */
		ifail = POM_save_instances(1, &release_status, true);
		printf("\n 6 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
         printf("\n 5find status list hits fail=%d ",ifail);fflush(stdout);


			/* Unlock the newly created release status instance */
			ifail = POM_refresh_instances_any_class(1, &release_status, POM_no_lock);
         printf("\n 6find status list hits fail=%d ",ifail);fflush(stdout);
			printf("\n 7 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);


			/* Save the workspace object */
			ifail = POM_save_instances(1, &rev, false);
         printf("\n 7find status list hits fail=%d ",ifail);fflush(stdout);
			printf("\n 8 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);


			/* Unlock the object */
			ifail = AOM_refresh(rev, POM_no_lock);
			printf("\n 10 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
         printf("\n 8 find status list hits fail=%d ",ifail);fflush(stdout);


			ifail=WSOM_ask_release_status_list(rev ,&count,&status_list);
			printf("\n 11 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);

			MM_check_status(count,status_list,&revstatus);
			printf("\n 12 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
			ifail = AOM_refresh(rev, 0);
			printf("\n 13 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
	}//END for updatable
     }// END FOR Status
	printf("\n 14 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
	*released_rev=revstatus;
	//*released_rev=release_status;
	printf("\n 15 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
}
static void MM_check_status(int count, tag_t *status_list, tag_t * revstatus)
{
	int   NStatus					 = 0;
	int   ifail						 = 0;
	char  name[WSO_name_size_c+1]    = {'\0'};
	//logical  StatusFound = false;

	printf("\n Inside MM_check_status::count==>[%d] \n",count);fflush(stdout);
	if(count>0)
	{
		for(NStatus=0;NStatus<count;NStatus++)
		{
			ifail=CR_ask_release_status_type(status_list[NStatus],name);
			printf("\n Inside MM_check_status==>[%s] \n",name);fflush(stdout);

			if(tc_strcmp(name,"T5_LcsErcRlzd")==0)
			{
				StatusFound = true;
				*revstatus=status_list[NStatus];
				break;
			}
		}
	}

}
static date_t TML_token_to_date(char *str )
{
	date_t   date		  = NULLDATE;

	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */

	int ifail=0;

	//printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

	//printf("\n Debugging ==> 000899999 \n");fflush(stdout);

	if(tc_strlen(str)>0)
	{
		printf("\n Debugging ==> 0008999 \n");fflush(stdout);
		sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		month--;

		date.month = month;
		date.day   = day;
		date.year  = year;
		date.hour  = hour;
		date.minute= minute;
		date.second= second;
		printf("\n Debugging ==> 0008 \n");fflush(stdout);

	}
	return date;
}
int ns__getStatusPDCA(struct soap* soap,char *Dml_Num,char *Status,char **Response)
{
	int ifail =0;
	int n_tags_found = 0;
	int n_pdcattchs = 0;

	tag_t *tags_found = NULLTAG;
	tag_t item_t = NULLTAG;
	tag_t itemRev_t = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t *pdca_objects = NULLTAG;
	tag_t Pdcaob	 = NULLTAG;
	tag_t pdcastatus = NULLTAG;

	char*	LatRev_ObjectType	= NULL;
	char*	dmlNo				= NULL;

	*Response = (char *) malloc( (100) * sizeof(char));

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/PdcaStatus.txt", "w", stdout);

	CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	CALLAPI(ITK_auto_login( ));
	CALLAPI(ITK_set_journalling( TRUE ));

	printf("\n Input .. %s",Dml_Num);fflush(stdout);
	if((Dml_Num !=NULL) && (tc_strcmp(Dml_Num,"")!=0))
	{
		const char *attrs[1];
		const char *values[1];
		attrs[0] ="item_id";
		//attrs[1] ="object_type";
		values[0] = (char *)Dml_Num;
		//values[1] = "ERC DML";
		printf("\n values[0] <%s> \n",values[0] );fflush(stdout);

		ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);

		printf("\n Tag Found <%d> \n",n_tags_found );fflush(stdout);
		if(n_tags_found>0)
		{
			item_t = tags_found[0];
			ITEM_ask_latest_rev(item_t,&itemRev_t);
			AOM_UIF_ask_value(itemRev_t,"object_type",&LatRev_ObjectType);
			printf("\n Object Type of Latest Revision is :%s",LatRev_ObjectType);fflush(stdout);
			if(tc_strcasecmp(LatRev_ObjectType,"ERC DML Revision")==0)
			{
				AOM_ask_value_string(itemRev_t,"item_id",&dmlNo);
				printf("\n DML No is : [%s]\n", dmlNo); fflush(stdout);

				CALLAPI(GRM_find_relation_type("T5_DmlHasPdca",&relation_type));
				if (relation_type!=NULLTAG)
				{
					CALLAPI(GRM_list_secondary_objects_only(itemRev_t,relation_type,&n_pdcattchs,&pdca_objects));
					printf("\n n_pdcattchs is : [%d]\n", n_pdcattchs); fflush(stdout);
					if(n_pdcattchs>0)
					{
						Pdcaob = pdca_objects[0];
						if(tc_strcmp(Status,"Completed")==0)
						{
							tc_strcpy(*Response,"Update");
							// Add Status
							MM_ReleaseRevision(Pdcaob,&pdcastatus,true);
						}
						else
						{
							tc_strcpy(*Response,"Fail");
						}
					}
					else
					{
						tc_strcpy(*Response,"Object not found");
					}					
				}
			}
		}
	}
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;

}
