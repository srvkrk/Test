//gsoap ns service name:				 replace_named_referance
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:replace_named_referance
//gsoap ns service location:			 http://172.22.97.12:9080/cgi/replace_named_referance.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:replace_named_referance
//gsoap ns service method-documentation: Tests the Simple Web service

int ns__ReplaceNamedReference(char *Part_no, char* Revision, char* sequence ,char* path,char **Response);