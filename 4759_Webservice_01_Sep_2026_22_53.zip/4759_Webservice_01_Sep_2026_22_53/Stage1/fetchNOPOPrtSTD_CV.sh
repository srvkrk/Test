. /user/cvprod/.bash_profile
cd /proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/
WorkingPath=/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/NoPoTaskEpa
echo "Working Path :"$WorkingPath
echo "Task Number : "$1
echo "File Path : "$2
${WorkingPath} -u=aplloader -pf=/user/cvprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=$1 -fp=$2
