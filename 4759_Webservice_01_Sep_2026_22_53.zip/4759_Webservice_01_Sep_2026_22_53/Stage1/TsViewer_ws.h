//gsoap ns service name:				 TsViewer_ws
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:TsViewer_ws
//gsoap ns service location:			 https://172.22.97.28:9081/cgi/TsViewer_ws.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:TsViewer_ws
//gsoap ns service method-documentation: Module name web service

struct ns__plmTMLSTDDetail
{
	char	*item_id;
	char	*object_desc;
	char	*t5_DVolNo;
	char	*t5_TSMod_Date;
	char	*t5_TSAinNo;
	char	*t5_IssueNo;
	char	*t5_TSRemark;
};
struct ns__CharArray4Test 
{
	int __size;
	struct ns__plmTMLSTDDetail *__plmTMLSTDDetail;
}; 
int ns__TsViewer_ws(char *tml_std_number, struct ns__CharArray4Test *aString_test);
int ns__TsViewer_ws_criteria(int criteria,char *volume_no,char *tml_std_number,char *ts_keyword1,char *ts_keyword2,char *ts_keyword3,char *ts_description,char *mod_after_date,char *mod_before_date, struct ns__CharArray4Test *aString_test);
int ns__TsViewer_pdf_download_ws(char *tml_std_number, char **aString_download_response);


/*
T5_TMLStdRevision	T5_TMLStd	
t5_DocCreateDate

T5_TMLStdRevision

item_id
object_desc
t5_DVolNo
t5_TSMod_Date
t5_TSAinNo
t5_IssueNo
t5_TSRemark
*/
