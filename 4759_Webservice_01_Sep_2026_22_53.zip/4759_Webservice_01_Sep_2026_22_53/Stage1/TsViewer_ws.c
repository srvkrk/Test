#include "TsViewer_ws.nsmap"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
//#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <ae/dataset.h>
#include <sa/tcfile.h>
#include "stdsoap2.h"
#include "soapH.h"

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
        if (return_code != ITK_ok)
        {
                int                             index = 0;
                int                             n_ifails = 0;
                const int*              severities = 0;
                const int*              ifails = 0;
                const char**    texts = NULL;

                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
                printf("%3d error(s) ", n_ifails);
                for( index=0; index<n_ifails; index++)
                {
                        printf("ERROR: %d\tERROR MSG: %s ", ifails[index], texts[index]);
                        TC_write_syslog("ERROR: %d\tERROR MSG: %s ", ifails[index], texts[index]);
                        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n ", function, file, line);
                        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d ", function, file, line);
                }
                EMH_clear_errors();

        }
        return return_code;
}

extern int ITK_user_main(int argc, char *argv[])
{
  struct soap *soap = soap_new();
  soap->accept_timeout = 24*60*60;
  soap->send_timeout = soap->recv_timeout = 5;
  soap->transfer_timeout = 10;
  soap_ssl_init();
  if (soap_ssl_server_context(soap,
    SOAP_SSL_NO_AUTHENTICATION,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
  ))
  {
    soap_print_fault(soap, stderr);
    exit(EXIT_FAILURE);
  }
  soap_serve(soap) ;
  soap_print_fault(soap, stderr);
  soap_destroy(soap);
  soap_end(soap);
  soap_free(soap);
  return 0;
}

/*
T5_TMLStdRevision       T5_TMLStd
t5_DocCreateDate

T5_TMLStdRevision

item_id
object_desc
t5_DVolNo
t5_TSMod_Date
t5_TSAinNo
t5_IssueNo
t5_TSRemark
*/
int tm_check_info_control_object(char* syscd, char* subsyscd, char* info1, char* info2)
{
        int n_found = 0;
        int n_entries = 2;
        char* qry_entries[2] = { "SYSCD", "SUBSYSCD" };
        char* qry_values[2] = { syscd, subsyscd };
        tag_t query = NULLTAG;
        tag_t* cntr_objects = NULL;

        char* l_info1 = NULL;
        char* l_info2 = NULL;

        ITK_CALL(QRY_find2("ControlObjQry", &query));
        ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
        printf("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);
        TC_write_syslog("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);

        if (n_found > 0)
        {
                ITK_CALL(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo1", &l_info1));
                tc_strcpy(info1, l_info1);
                ITK_CALL(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo2", &l_info2));
                tc_strcpy(info2, l_info2);

                TC_write_syslog("\ninfo1 : [%s] info2 : [%s]", info1, info2); fflush(stdout);
                printf("\ninfo1 : [%s] info2 : [%s]", info1, info2); fflush(stdout);
        }

        return n_found;
}
int ns__TsViewer_pdf_download_ws(struct soap* soap,char *tml_std_number, char **aString_download_response)
{
        int nOne = 2;
        int nCount = 0;
        tag_t *nTags = NULLTAG;
        char *qry_entries[2] = { "Type", "Item ID" } ;
        char *qry_values[2] =  { "T5_TMLStdRevision", tml_std_number } ;
        tag_t latest_tml_std_rev = NULLTAG;
        tag_t dataset_relation_type = NULLTAG;
        char *item_id = NULL;
        int dataset_cnt = 0;
        tag_t* DatasetList = NULLTAG;
        int i = 0;
        int iRelCntr = 0;
        tag_t Query = NULLTAG;
        tag_t PDF_Tag = NULLTAG;
        char *datasettype_PDF_type = NULL;
        int referencenumberfound = 0;
        int ref_c = 0;
        //char path_name[SS_MAXPATHLEN];
        //char orig_name[IMF_filename_size_c + 1];
        AE_reference_type_t reftype;
        //char refname[AE_reference_size_c + 1];
        char *orig_name = NULL;
        char *refname = NULL;
        char *path_name = NULL;
        tag_t refobject = NULLTAG;
        char *file_path = NULL;
        char *path1 = NULL;
        char *path2 = NULL;
        int n_found_qSOR_pdf_path = 0;
        fpos_t pos;
        fgetpos(stdout, &pos);
        int fd = dup(fileno(stdout));

        freopen("/tmp/tml_std_download.txt", "w", stdout);
        ITK_CALL ( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) ) ;
        //ITK_CALL ( ITK_auto_login ( ) ) ;
        ITK_CALL (ITK_init_module("ak924461.ttl", "Ilovemyindia@2027", "PLM_Support_Group"));
    ITK_CALL ( ITK_set_journalling ( TRUE ) ) ;

        path1 = (char*)MEM_alloc(200 * sizeof(char));
        path2 = (char*)MEM_alloc(200 * sizeof(char));
        file_path = (char*)MEM_alloc(500 * sizeof(char));
        n_found_qSOR_pdf_path = tm_check_info_control_object("TSVIEWER_PDF_PATH", "PATH", path1, path2);
        if (n_found_qSOR_pdf_path > 0)
        {

                printf("\nLatest TML STD uery for : [%s]", tml_std_number); fflush(stdout);
                TC_write_syslog("\nLatest TML STD uery for : [%s]", tml_std_number); fflush(stdout);
                ITK_CALL ( QRY_find2 ( "Latest Item Revision...", &Query ) );

                *aString_download_response = (char *) MEM_alloc ( (200) * sizeof(char));
                if ( Query )
                {
                        ITK_CALL ( QRY_execute ( Query, nOne, qry_entries, qry_values, &nCount, &nTags ) );
                        printf("\nTML STD tag cnt : [%d]", nCount); fflush(stdout);
                        TC_write_syslog("\nTML STD tag cnt : [%d]", nCount);
                        if ( nCount > 0 )
                        {
                                for ( i = 0 ; i < nCount ; i++ )
                                {
                                        latest_tml_std_rev = nTags[0];
                                        ITK_CALL ( AOM_ask_value_string(latest_tml_std_rev,"item_id",&item_id) );
                                        ITK_CALL ( GRM_find_relation_type ( "IMAN_specification", &dataset_relation_type ) );
                                        ITK_CALL ( GRM_list_secondary_objects_only ( latest_tml_std_rev, dataset_relation_type, &dataset_cnt, &DatasetList ) ) ;
                                        printf("\ndataset_cnt IMAN_specification : [%d]", dataset_cnt); fflush(stdout);
                                        TC_write_syslog("\ndataset_cnt IMAN_specification : [%d]", dataset_cnt);
                                        if ( dataset_cnt <= 0)
                                        {
                                                ITK_CALL ( GRM_find_relation_type ( "IMAN_Rendering", &dataset_relation_type ) );
                                                ITK_CALL ( GRM_list_secondary_objects_only ( latest_tml_std_rev, dataset_relation_type, &dataset_cnt, &DatasetList ) ) ;
                                                printf("\ndataset_cnt IMAN_Rendering : [%d]", dataset_cnt); fflush(stdout);
                                                TC_write_syslog("\ndataset_cnt IMAN_Rendering : [%d]", dataset_cnt);
                                        }
                                        if ( dataset_cnt > 0)
                                        {

                                                for ( iRelCntr = 0 ; iRelCntr < dataset_cnt; iRelCntr++ )
                                                {
                                                        PDF_Tag = DatasetList[iRelCntr];
                                                        ITK_CALL ( AOM_UIF_ask_value (PDF_Tag,"object_type",&datasettype_PDF_type) );
                                                        printf("\ndatasettype_PDF_type : [%s]",datasettype_PDF_type);
                                                        TC_write_syslog("\ndatasettype_PDF_type : [%s]",datasettype_PDF_type);
                                                        ITK_CALL ( AE_ask_dataset_ref_count(PDF_Tag,&referencenumberfound) );
                                                        if ( referencenumberfound > 0 )
                                                        {
                                                                for (ref_c = 0; ref_c < referencenumberfound ; ref_c++)
                                                                {
                                                                        ITK_CALL ( AE_find_dataset_named_ref2(PDF_Tag,ref_c,&refname,&reftype,&refobject) );
                                                                        printf("\nrefname  : [%s]\n",refname); fflush(stdout);
                                                                        TC_write_syslog("\nrefname  : [%s]\n",refname); fflush(stdout);
                                                                        ITK_CALL ( IMF_ask_original_file_name2(refobject,&orig_name));
                                                                        printf("\norig_name  : [%s]\n",orig_name); fflush(stdout);
                                                                        TC_write_syslog("\norig_name  : [%s]\n",orig_name); fflush(stdout);
                                                                        ITK_CALL ( IMF_ask_file_pathname2(refobject,SS_UNIX_MACHINE,&path_name));
                                                                        printf("\npath_name  : [%s]\n",path_name); fflush(stdout);
                                                                        TC_write_syslog("\npath_name  : [%s]\n",path_name); fflush(stdout);
                                                                        sprintf(file_path,"%s/%s",path1,orig_name);
                                                                        //sprintf(file_path,"/tmp/%s",orig_name);
                                                                        printf("\nfile_path : [%s]\n",file_path); fflush(stdout);
                                                                        TC_write_syslog("\nfile_path : [%s]\n",file_path); fflush(stdout);
                                                                        ITK_CALL ( IMF_export_file (refobject,file_path));

                                                                        sprintf(*aString_download_response,"File Downloaded at : [%s]",file_path);
                                                                        printf("\nSuccess : [%s]",*aString_download_response);
                                                                }
                                                        }
                                                        else
                                                        {
                                                                sprintf(*aString_download_response,"PDF references Object not found");
                                                                printf("\nError 1 : [%s]",*aString_download_response);
                                                                TC_write_syslog("\nError 1 : [%s]",*aString_download_response);
                                                        }
                                                }
                                        }
                                        else
                                        {
                                                sprintf(*aString_download_response,"PDF Object not found in IMAN_specification relation");
                                                printf("\nError 2 : [%s]",*aString_download_response);fflush(stdout);
                                                TC_write_syslog("\nError 2 : [%s]",*aString_download_response);
                                        }
                                }
                        }
                        else
                        {
                                sprintf(*aString_download_response,"TML STD objects not Found");
                                printf("\nError 3 : [%s]",*aString_download_response);fflush(stdout);
                                TC_write_syslog("\nError 3 : [%s]",*aString_download_response);
                        }
                }
                else
                {
                        sprintf(*aString_download_response,"TML STD Query not Found in Query Builder");
                        printf("\nError 4 : [%s]",*aString_download_response);fflush(stdout);
                        TC_write_syslog("\nError 4 : [%s]",*aString_download_response);
                }

        }
        else
        {
                sprintf(*aString_download_response,"TSViewer default PDF download path not found control object Name : [TSVIEWER_PDF_PATH]");
                printf("\nError 5 : [%s]",*aString_download_response);fflush(stdout);
                TC_write_syslog ( "\nTSViewer default PDF download path not found control object Name : [TSVIEWER_PDF_PATH]" ) ;
                return 0;
        }

        ITK_exit_module(true);
        dup2(fd, fileno(stdout));
        close(fd);
        clearerr(stdout);
        fsetpos(stdout, &pos);
        return SOAP_OK;
}
/*
"   &quot;
'   &apos;
<   &lt;
>   &gt;
&   &amp;

*/
int ns__TsViewer_ws_criteria(struct soap* soap,int criteria,char *volume_no,char *tml_std_number,char *ts_keyword1,char *ts_keyword2,char *ts_keyword3,char *ts_description,char *mod_after_date,char *mod_before_date, struct ns__CharArray4Test *aString_test)
{

        int nOne = 2;
        int nSix = 6;
        int nThree = 3;
        int nCount = 0;
        tag_t *nTags = NULLTAG;

        int length = 0;
        int i = 0;
        tag_t Query = NULLTAG;
        tag_t Query1 = NULLTAG;
        tag_t Query2 = NULLTAG;
        int d = 0 ;
        char *item_id = NULL;
        char *object_desc = NULL;
        char *t5_DVolNo = NULL;
        date_t d_t5_TSMod_Date;
        char *t5_TSMod_Date = NULL;
        char *t5_TSAinNo = NULL;
        char *t5_IssueNo = NULL;
        char *t5_TSRemark = NULL;
		char *ts_description_str = NULL;
		char *ts_keyword_str = NULL;

        fpos_t pos;
        fgetpos(stdout, &pos);
        int fd = dup(fileno(stdout));
        printf ( "\nMain function" ) ; fflush(stdout);
        TC_write_syslog ( "\nMain function" ) ; fflush(stdout);

        freopen("/tmp/tml_std_criteria_test.txt", "w", stdout);

        ITK_CALL ( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) ) ;
        //ITK_CALL ( ITK_auto_login ( ) ) ;
        ITK_CALL (ITK_init_module("ak924461.ttl", "Ilovemyindia@2027", "PLM_Support_Group"));
		ITK_CALL ( ITK_set_journalling ( TRUE ) ) ;
        printf ( "\nafter Login" ) ; fflush(stdout);
        TC_write_syslog ( "\nafter Login" ) ; fflush(stdout);

		// ----Search 0
        printf ("\nbefore volume_no	: [%s]",volume_no); fflush ( stdout ) ;
        TC_write_syslog("\nbefore volume_no	: [%s]",volume_no); fflush ( stdout ) ;

        char *qry_entries_0[2] = { "Volume No", "Delete Indicator" } ;
        int  n_entries_0 = 2;
        char **qry_values_0 = NULL;
        qry_values_0  = (char **) MEM_alloc(n_entries_0 * sizeof(char *));

        qry_values_0[0] = (char *)MEM_alloc( tc_strlen( volume_no ) + 1);
        tc_strcpy(qry_values_0[0], volume_no );

        qry_values_0[1] = (char *)MEM_alloc( 100);
        tc_strcpy(qry_values_0[1], "Valid Standard for All" );

        printf ( "\nqry_values_0[0] : [%s]", qry_values_0[0]) ; fflush ( stdout ) ;
        TC_write_syslog ( "\nqry_values_0[0] : [%s]", qry_values_0[0]) ; fflush ( stdout ) ;

		
		// ----Search 2
        char *qry_entries_2[3] = { "Modified after", "Modified before", "Delete Indicator" } ;
        //char *qry_values_2[2] =  { mod_after_date,mod_before_date } ;
        int  n_entries_2 = 3;
        char **qry_values_2 = NULL;
        qry_values_2  = (char **) MEM_alloc(n_entries_2 * sizeof(char *));

        qry_values_2[0] = (char *)MEM_alloc( tc_strlen( mod_after_date ) + 1);
        tc_strcpy(qry_values_2[0], mod_after_date );

        qry_values_2[1] = (char *)MEM_alloc( tc_strlen( mod_before_date ) + 1);
        tc_strcpy(qry_values_2[1], mod_before_date );

        qry_values_2[2] = (char *)MEM_alloc( 100);
        tc_strcpy(qry_values_2[2], "Valid Standard for All" );

        printf ( "\nqry_values_2[0] : [%s]", qry_values_2[0]) ; fflush ( stdout ) ;
        printf ( "\nqry_values_2[1] : [%s]", qry_values_2[1]) ; fflush ( stdout ) ;
        printf ( "\nqry_values_2[2] : [%s]", qry_values_2[2]) ; fflush ( stdout ) ;
        char *keys[] = { "object_name","item_revision_id" };
        
		//char *keys[] = { "object_name","t5_TSMod_Date" };
        //char *keys[] = { "item_id" };
        //char *keys[] = { "t5_TSMod_Date" };

        //int orders[2] = { 2,2 };//desc order          //Commented by RRR on 22.07.2025
        int orders[1] = { 1 };//Ascending order			//Added by RRR on 22.07.2025

        int num_to_sort = 1;    //no of sort criterial param count

        //system("touch /tmp/a.sh;chmod 777 /tmp/a.sh;/tmp/a.sh");
        //system("/tmp/a.sh");
        printf ("\ncriteria        : [%d]",criteria);fflush(stdout);
        TC_write_syslog ("\ncriteria        : [%d]",criteria);

        ITK_CALL ( QRY_find2 ( "Latest TMLSTD Revision TSViewer", &Query ) ); //Query by Volume
        //ITK_CALL ( QRY_find2 ( "Latest TMLSTD Revision TSViewer1", &Query1 ) ); //Query by Description
        //ITK_CALL ( QRY_find2 ( "Latest TMLSTD Revision TSViewer5", &Query1 ) ); //Query by Description
        ITK_CALL ( QRY_find2 ( "Latest TMLSTD Revision TSViewer9", &Query1 ) ); //Query by Description
        ITK_CALL ( QRY_find2 ( "Latest TMLSTD Revision TSViewer2", &Query2 ) ); //Query by Modificatin Date

        if (criteria == 0 && Query)
        {
                printf ("\nvolume_no       : [%s]",volume_no);fflush(stdout);
                TC_write_syslog ("\nvolume_no       : [%s]",volume_no);
                //ITK_CALL ( QRY_execute ( Query, nOne, qry_entries_0, qry_values_0, &nCount, &nTags ) );
                ITK_CALL ( QRY_execute_with_sort(Query, nOne, qry_entries_0, qry_values_0, num_to_sort, keys, orders, &nCount, &nTags));
        }
        else if ( criteria == 1 && Query1)
        {
                printf ("\ntml_std_number  : [%s]",tml_std_number);fflush(stdout);
                printf ("\nts_description  : [%s]",ts_description);fflush(stdout);
                printf ("\nts_description_str  : [%s]",ts_description_str);fflush(stdout);

                printf ("\nts_keyword1     : [%s]",ts_keyword1);fflush(stdout);
                printf ("\nts_keyword2     : [%s]",ts_keyword2);fflush(stdout);
                printf ("\nts_keyword3     : [%s]",ts_keyword3);fflush(stdout);

                TC_write_syslog ("\ntml_std_number  : [%s]",tml_std_number);
                TC_write_syslog ("\nts_description  : [%s]",ts_description);
                TC_write_syslog ("\nts_description_str  : [%s]",ts_description_str);

                TC_write_syslog ("\nts_keyword1     : [%s]",ts_keyword1);
                TC_write_syslog ("\nts_keyword2     : [%s]",ts_keyword2);
                TC_write_syslog ("\nts_keyword3     : [%s]",ts_keyword3);

				if (tml_std_number && tc_strcmp(tml_std_number, "*") == 0) tml_std_number = NULL;
				if (ts_description && tc_strcmp(ts_description, "*") == 0) ts_description = NULL;
				if (ts_keyword1 && tc_strcmp(ts_keyword1, "*") == 0) ts_keyword1 = NULL;

				// CASE 1: Search by ID
				if (tml_std_number != NULL)
				{
				    char *id_val = MEM_alloc(200);
				    tc_strcpy(id_val, "*");
				    tc_strcat(id_val, tml_std_number);
				    tc_strcat(id_val, "*");

				    ITK_CALL(QRY_execute(
				        Query1,
				        1,
				        (char*[]){"ID"},
				        (char*[]){id_val},
				        &nCount,
				        &nTags));
				}
				// CASE 2: Search by description
				else if (ts_description != NULL)
				{
				    char *desc = MEM_alloc(200);
				    tc_strcpy(desc, "*");
				    tc_strcat(desc, ts_description);
				    tc_strcat(desc, "*");

				    ITK_CALL(QRY_execute(
				        Query1,
				        1,
				        (char*[]){"Description"},
				        (char*[]){desc},
				        &nCount,
				        &nTags));
				}
				// CASE 3: Search by keyword
				else if (ts_keyword1 != NULL)
				{
				    char *key = MEM_alloc(200);
				    tc_strcpy(key, "*");
				    tc_strcat(key, ts_keyword1);
				    tc_strcat(key, "*");

				    ITK_CALL(QRY_execute(
				        Query1,
				        3,
				        (char*[]){"Keyword 1", "Keyword 2", "Keyword 3"},
				        (char*[]){key, key, key},
				        &nCount,
				        &nTags));
				}

		}
		else if (criteria == 2 && Query2)
		{
		    printf("\nmod_after_date  : [%s]", mod_after_date);
		    printf("\nmod_before_date : [%s]", mod_before_date);

		    TC_write_syslog("\nmod_after_date  : [%s]", mod_after_date);
		    TC_write_syslog("\nmod_before_date : [%s]", mod_before_date);

		    // Assign values EXACTLY as the query needs
		    tc_strcpy(qry_values_2[0], mod_after_date);      // "Modified after"
		    tc_strcpy(qry_values_2[1], mod_before_date);     // "Modified before"
		    tc_strcpy(qry_values_2[2], "Valid Standard for All");

		    // FIX: use correct number of entries (3)
		    ITK_CALL(QRY_execute_with_sort(
		        Query2,
		        nThree,      // NOT nOne
		        qry_entries_2,
		        qry_values_2,
		        num_to_sort,
		        keys,
		        orders,
		        &nCount,
		        &nTags));
		}
        d = 1;
        printf ("\nnCount : [%d]",nCount) ; fflush ( stdout );
        TC_write_syslog ("\nnCount : [%d]",nCount) ; fflush ( stdout );

        if ( nCount > 0 )
        {
                aString_test->__size = nCount;
                aString_test->__plmTMLSTDDetail = MEM_alloc ( ( aString_test ->__size + 1) * sizeof(*aString_test ->__plmTMLSTDDetail) );

				for ( i = 0 ; i < nCount ; i++ )
				{
				    ITK_CALL(AOM_ask_value_string(nTags[i], "t5_TSDelInd", &t5_TSRemark));
				
				    // Only process if Remark is N0 or Valid Standard for All
				    if ((tc_strcmp(t5_TSRemark, "N0") != 0) && (tc_strcmp(t5_TSRemark, "Valid Standard for All") != 0)) {
				        // Skip this record
				        continue;
				    }
				
				    // If it passes, normalize the value
				    if (tc_strcmp(t5_TSRemark, "N0") == 0) {
				        tc_strcpy(t5_TSRemark, "Valid");
				    }
				
				    // Now fetch the rest of the values
				    ITK_CALL(AOM_ask_value_string(nTags[i], "item_id", &item_id));
				    ITK_CALL(AOM_ask_value_string(nTags[i], "object_desc", &object_desc));
				    ITK_CALL(AOM_ask_value_string(nTags[i], "t5_DVolNo", &t5_DVolNo));
				    ITK_CALL(AOM_ask_value_date(nTags[i], "t5_TSMod_Date", &d_t5_TSMod_Date));
				    ITK_CALL(ITK_date_to_string(d_t5_TSMod_Date, &t5_TSMod_Date));
				    ITK_CALL(AOM_ask_value_string(nTags[i], "t5_TSAinNo", &t5_TSAinNo));
				    ITK_CALL(AOM_ask_value_string(nTags[i], "item_revision_id", &t5_IssueNo));
				
				    // Allocate memory and copy values as before
				    aString_test->__plmTMLSTDDetail[i].item_id = MEM_alloc(40 * sizeof(char*));
				    tc_strcpy(aString_test->__plmTMLSTDDetail[i].item_id, item_id);
				
				    aString_test->__plmTMLSTDDetail[i].object_desc = MEM_alloc(128 * sizeof(char*));
				    tc_strcpy(aString_test->__plmTMLSTDDetail[i].object_desc, object_desc);
				
				    aString_test->__plmTMLSTDDetail[i].t5_DVolNo = MEM_alloc(128 * sizeof(char*));
				    tc_strcpy(aString_test->__plmTMLSTDDetail[i].t5_DVolNo, t5_DVolNo);
				
				    aString_test->__plmTMLSTDDetail[i].t5_TSMod_Date = MEM_alloc(100);
				    if ((tc_strcmp(t5_TSMod_Date, "") == 0) || (t5_TSMod_Date == NULL)) {
				        tc_strcpy(t5_TSMod_Date, "No Date");
				    }
				    tc_strcpy(aString_test->__plmTMLSTDDetail[i].t5_TSMod_Date, t5_TSMod_Date);
				
				    aString_test->__plmTMLSTDDetail[i].t5_TSAinNo = MEM_alloc(128 * sizeof(char*));
				    tc_strcpy(aString_test->__plmTMLSTDDetail[i].t5_TSAinNo, t5_TSAinNo);
				
				    aString_test->__plmTMLSTDDetail[i].t5_IssueNo = MEM_alloc(128 * sizeof(char*));
				    tc_strcpy(aString_test->__plmTMLSTDDetail[i].t5_IssueNo, t5_IssueNo);
				
				    aString_test->__plmTMLSTDDetail[i].t5_TSRemark = MEM_alloc(128 * sizeof(char*));
				    tc_strcpy(aString_test->__plmTMLSTDDetail[i].t5_TSRemark, t5_TSRemark);
				
				    printf("%s^%s^%s^%s^%s^%s^%s\n", item_id, object_desc, t5_DVolNo, t5_TSMod_Date, t5_TSAinNo, t5_IssueNo, t5_TSRemark);
				    TC_write_syslog("%s^%s^%s^%s^%s^%s^%s\n", item_id, object_desc, t5_DVolNo, t5_TSMod_Date, t5_TSAinNo, t5_IssueNo, t5_TSRemark);
				}

        }
        else
        {
                printf ( "\nno record found" ) ;
                TC_write_syslog ( "\nno record found" ) ;
        }
        ITK_exit_module(true);
        dup2(fd, fileno(stdout));
        close(fd);
        clearerr(stdout);
        fsetpos(stdout, &pos);
        return SOAP_OK;

}
int ns__TsViewer_ws(struct soap* soap,char *tml_std_number, struct ns__CharArray4Test *aString_test)
{
        int nOne = 2;
        int nCount = 0;
        tag_t *nTags = NULLTAG;
        char *qry_entries[2] = { "Type", "Item ID" } ;
        char *qry_values[2] =  { "T5_TMLStdRevision", "*" } ;//Query all TS STD
        int length = 0;
        int i = 0;
        tag_t Query = NULLTAG;
        int d = 0 ;
        char *item_id = NULL;
        char *object_desc = NULL;
        char *t5_DVolNo = NULL;
        date_t d_t5_TSMod_Date;
        char *t5_TSMod_Date = NULL;
        char *t5_TSAinNo = NULL;
        char *t5_IssueNo = NULL;
        char *t5_TSRemark = NULL;
        fpos_t pos;
        fgetpos(stdout, &pos);
        int fd = dup(fileno(stdout));
        freopen("/tmp/tml_std.txt", "w", stdout);
        ITK_CALL ( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) ) ;
        //ITK_CALL ( ITK_auto_login ( ) ) ;
        ITK_CALL (ITK_init_module("ak924461.ttl", "Ilovemyindia@2027", "PLM_Support_Group"));
    ITK_CALL ( ITK_set_journalling ( TRUE ) ) ;
        ITK_CALL ( QRY_find2 ( "Latest Item Revision...", &Query ) );
        if ( Query )
        {
                ITK_CALL ( QRY_execute ( Query, nOne, qry_entries, qry_values, &nCount, &nTags ) );
                d = 1;
                if ( nCount > 0 )
                {
                        aString_test->__size = nCount;
                        aString_test->__plmTMLSTDDetail = MEM_alloc ( ( aString_test ->__size + 1) * sizeof(*aString_test ->__plmTMLSTDDetail) );

                        for ( i = 0 ; i < nCount ; i++ )
                        {
                                ITK_CALL ( AOM_ask_value_string(nTags[i],"item_id",&item_id) );
                                aString_test->__plmTMLSTDDetail[i].item_id = MEM_alloc(40* sizeof(char*));
                                tc_strcpy ( aString_test->__plmTMLSTDDetail[i].item_id, item_id );

                                ITK_CALL ( AOM_ask_value_string(nTags[i],"object_desc",&object_desc) );
                                aString_test->__plmTMLSTDDetail[i].object_desc = MEM_alloc(128* sizeof(char*));
                                tc_strcpy ( aString_test->__plmTMLSTDDetail[i].object_desc, object_desc );

                                ITK_CALL ( AOM_ask_value_string(nTags[i],"t5_DVolNo",&t5_DVolNo) );
                                aString_test->__plmTMLSTDDetail[i].t5_DVolNo = MEM_alloc(128* sizeof(char*));
                                tc_strcpy ( aString_test->__plmTMLSTDDetail[i].t5_DVolNo, t5_DVolNo );

                                ITK_CALL ( AOM_ask_value_date(nTags[i],"t5_TSMod_Date",&d_t5_TSMod_Date) );
                                ITK_CALL(ITK_date_to_string(d_t5_TSMod_Date,&t5_TSMod_Date));
                                aString_test->__plmTMLSTDDetail[i].t5_TSMod_Date = MEM_alloc(20* sizeof(char*));
                                tc_strcpy ( aString_test->__plmTMLSTDDetail[i].t5_TSMod_Date, t5_TSMod_Date );

                                ITK_CALL ( AOM_ask_value_string(nTags[i],"t5_TSAinNo",&t5_TSAinNo) );
                                aString_test->__plmTMLSTDDetail[i].t5_TSAinNo = MEM_alloc(128* sizeof(char*));
                                tc_strcpy ( aString_test->__plmTMLSTDDetail[i].t5_TSAinNo, t5_TSAinNo );

                                ITK_CALL ( AOM_ask_value_string(nTags[i],"item_revision_id",&t5_IssueNo) );//revision as per tce in number
                                aString_test->__plmTMLSTDDetail[i].t5_IssueNo = MEM_alloc(128* sizeof(char*));
                                tc_strcpy ( aString_test->__plmTMLSTDDetail[i].t5_IssueNo, t5_IssueNo );

                                ITK_CALL ( AOM_ask_value_string(nTags[i],"t5_TSDelInd",&t5_TSRemark) );//as per tce
                                if (tc_strcmp(t5_TSRemark, "N0") == 0) {
                                        tc_strcpy(t5_TSRemark, "Valid");
								}
                                aString_test->__plmTMLSTDDetail[i].t5_TSRemark = MEM_alloc(128* sizeof(char*));
                                tc_strcpy ( aString_test->__plmTMLSTDDetail[i].t5_TSRemark, t5_TSRemark );
                                printf ( "%s^%s^%s^%s^%s^%s^%s\n",item_id, object_desc, t5_DVolNo, t5_TSMod_Date, t5_TSAinNo, t5_IssueNo, t5_TSRemark) ; fflush ( stdout ) ;
                        }
                }
        }
        ITK_exit_module(true);
        dup2(fd, fileno(stdout));
        close(fd);
        clearerr(stdout);
        fsetpos(stdout, &pos);
        return SOAP_OK;
}

/*
QRY_API int QRY_execute_with_sort       (       tag_t   query_tag,
int     entry_count,
char **         entries,
char **         values,
int     num_to_sort,
char **         keys,
int *   orders,
int *   num_found,
tag_t **        results
)
This API returns the objects that meet the given search criteria. The order of the objects in the returned array is determined according to the given sort criteria.

Return Values:

QRY_enquiry_not_available - invalid query
QRY_not_a_number - String xxx is found when expecting a number. Please see other query error codes.

Parameters:
query_tag               (I) The tag of a saved query object
entry_count     (I) The number of the user entries
entries                 (I) The array of the user entry names
values                  (I) The array of the values. Each user name in the "entries" array must have a corresponding value in the "values" array.
num_to_sort     (I) The number of the class attributes to be sorted
keys                    (I) The array of the names of the attributes that the found objects are to be sorted against. An attribute must be from the query target class.
orders                  (I) The array of the sort orders. The possible values of a sort order are:
                                        1 (Ascending Order)
                                        2 (Descending Order)
num_found               (O) The number of the found objects
results                 (OF) num_found The tag array of the found objects
*/
