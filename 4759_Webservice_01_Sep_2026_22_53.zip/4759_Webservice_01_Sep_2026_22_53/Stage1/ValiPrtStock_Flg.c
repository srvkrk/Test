#define _CLMAIN_DEFNS
#include <cfg.h>
#include <cl.h>
#include <ft.h>
#include <malloc.h>
#include <meta.h>
#include <mserv.h>
#include <msg.h>
#include <msgapc.h>
#include <msglcm.h>
#include <msgomf.h>
#include <msgtel.h>
#include <Mtimsg.h>
#include <Mtimsgh.h>
#include <mutproto.h>
#include <nls.h>
#include <pdmc.h>
#include <pdmitem.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <sc.h>
#include <serv.h>
#include <status.h>
#include <stdlib.h>
#include <string.h>
#include <sys.h>
#include <tel.h>
#include <ui.h>
#include <usc.h>

#include "soapH.h"
#include "ValiPrtStock_Flg.nsmap"

//int DZ_Check_Stock_V(char PartNumber[60],char PlantName[30]);
int DZ_Check_Stock_V(char PartNumber[60],char pvflg[2],char PlantName[30]);
int main(int argc, char *argv[])
{
	t5MethodInitWMD("ValiPrtStock_Flg.c");
	dstat = clInitMB2 (argc,&argv,NULL);
	return soap_serve(soap_new()); /* call the request dispatcher */

}
;

int ns__getValiPrtStock(struct soap* soap,char *partnumber, char *sapplant, char* pvflg,char **Response)
{
	FILE           *valiprtstock;

	string		    FileNameDup			=	NULL;
	string			TodayDate			=	NULL;
	string			PartNumDup			=	NULL;
	string			PartNum				=	NULL;
	string			PartRevDup			=	NULL;
	string			PartRev				=	NULL;
	string			StkCnt				=	NULL;

	ObjectPtr		oPart				=	NULL;

	SetOfObjects    soPart				=   NULL;

	SetOfStrings	strDbScope			=	NULL;
	
	SqlPtr          Sql_ptr				=   NULL;
	
	//int		StkIndCnt		=	0;
	float	StkIndCnt		=	0.0;

	status dstat	=	OKAY;
	int mfail		=	USC_OKAY;

	char* mod_name="ns__ConnectionTest";

	if (dstat = clInitialize2 (TRUE)) goto CLEANUP;
	
	FileNameDup		=	nlsStrAlloc(500);
	//printf("\nWebservice Start...!!!");

	TodayDate=sysGetCTime();

	low_strrpl(TodayDate,' ','_');
	low_strrpl(TodayDate,':','_');

	nlsStrCpy(FileNameDup,"/plmuv_logs/omfprod/logs/");
	nlsStrCat(FileNameDup,"ValiPrtStock_");
	nlsStrCat(FileNameDup,partnumber);
	nlsStrCat(FileNameDup,"_");
	nlsStrCat(FileNameDup,TodayDate);
	nlsStrCat(FileNameDup,".log");
	
	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("log1.txt", "w", stdout);

	valiprtstock = fopen(FileNameDup , "a+") ;
	if(FileNameDup==NULL)
	{
		goto EXIT;
	}

	strDbScope = low_set_create_str(2);
	low_set_add_str_unique(strDbScope,"supprod");
	low_set_add_str_unique(strDbScope,"sujprod");
	low_set_add_str_unique(strDbScope,"suhprod");
	low_set_add_str_unique(strDbScope,"sulprod");
	if(dstat = smSetSessionDbScope(strDbScope)) goto CLEANUP;
	fprintf(valiprtstock,"\n********WEB SERVICE CALLED FOR BOM PART CHECK***********");
	
	//Query ERC DML
	if(Sql_ptr)	oiSqlDispose(Sql_ptr); Sql_ptr = NULL;
	if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto CLEANUP;
	if(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,partnumber)) goto CLEANUP;
	//if(dstat = oiSqlPrint(Sql_ptr));
	if(dstat = QueryDbObject(PartClass,Sql_ptr,-1,TRUE,SC_SCOPE_OF_SESSION,&soPart,&mfail));
	fprintf(valiprtstock,"\n No of Part Found	:	[%d]",setSize(soPart));
	//if (setSize(soPart)>0)
	{
		//oPart	=	setGet(soPart,0);

		//if(dstat = objGetAttribute(oPart,PartNumberAttr,&PartNumDup)) goto EXIT;
		//if(!nlsIsStrNull(PartNumDup))
		//	PartNum	=	nlsStrDup(PartNumDup);
		//else
			PartNum	=	nlsStrDup(partnumber);
		fprintf(valiprtstock,"\n PART NUMBER	:	[%s]",PartNum);

		//if(dstat = objGetAttribute(oPart,RevisionAttr,&PartRevDup)) goto EXIT;
		//if(!nlsIsStrNull(PartRevDup))
		//	PartRev	=	nlsStrDup(PartRevDup);
		//fprintf(valiprtstock,"\n PART REVISION	:	[%s]",PartRev);
		
		fprintf(valiprtstock,"\n GOING TO CHECK STOCK IN SAP");

		StkIndCnt	=	DZ_Check_Stock_V(PartNum,pvflg,sapplant);
		StkCnt			=	NULL;
		StkCnt			=	nlsStrAlloc(10);
		nlsStrCpy(StkCnt,"");
		sprintf(StkCnt,"%.2f",StkIndCnt);

		// if (StkIndCnt <= 0)
		// {
		// 	fprintf(valiprtstock,"\n PART STOCK IN SAP : %s",StkCnt);
		// 	*Response = (char *) malloc( (50) * sizeof(char));
		// 	nlsStrCpy(*Response,StkCnt);
		// }
		// else if (!nlsIsStrNull(StkCnt))
		// {
		// 	fprintf(valiprtstock,"\n PART STOCK IN SAP : %s",StkCnt);
		// 	*Response = (char *) malloc( (50) * sizeof(char));
		// 	nlsStrCpy(*Response,StkCnt);
		// }
		// else
		// {
		// 	fprintf(valiprtstock,"\n PART STOCK NOT FOUND");
		// 	*Response = (char *) malloc( (50) * sizeof(char));
		// 	nlsStrCpy(*Response,"-1");
		// }

        if(StkIndCnt >= 0)
		{
			fprintf(valiprtstock,"\n PART STOCK IN SAP : %s",StkCnt);
			*Response = (char *) malloc( (50) * sizeof(char));
		    nlsStrCpy(*Response,StkCnt);
		}
		else
		{
			fprintf(valiprtstock,"\n PART STOCK NOT FOUND");
		 	*Response = (char *) malloc( (50) * sizeof(char));
		    nlsStrCpy(*Response,"-1");
		}


	}
//	else
//	{
//		fprintf(valiprtstock,"\n PART FOUND NOT DML/EPA");
//		*Response = (char *) malloc( (50) * sizeof(char));
//		nlsStrCpy(*Response,"-1");
//	}
	
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
	return SOAP_OK;

	CLEANUP :
		fprintf(valiprtstock,"\n  Inside CLEANUP:\n");
		return SOAP_OK;
	EXIT:
		fprintf(valiprtstock,"\n  Inside EXIT \n");
		return SOAP_OK;
}