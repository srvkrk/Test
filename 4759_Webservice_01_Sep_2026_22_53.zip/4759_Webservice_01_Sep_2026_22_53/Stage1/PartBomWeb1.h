//gsoap ns service name:				 PartBomWeb1
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:PartBomWeb2 
//gsoap ns service location:			http://172.22.97.8:9010/cgi/PartBomWeb1.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:PartBomWeb1
//gsoap ns service method-documentation: Tests the Simple Web service

struct ns__plmPartDetail
{
	char	*PLevel;
	char	*PrtObid;
	char	*PartNum;
	char	*Revision;
	char	*Sequence;
	char	*Weight;
	char	*SurArea;
	char	*Volume;
	char	*CS;
	char	*Material;
	char	*Descrpt;
	char	*ProjCode;
	char	*ProjDesc;
	char	*PEnvDia;
	char	*Thickness;
	char	*Parttype;
	//struct ns__plmEstShtDetails *__ptrEstSheetDtls;
	

}
;
struct ns__plmRelDetails
{
	char	*rel_Obid;
	char	*ParentObid;
	char	*ChildObid;
	char	*c_Qty;

}
;

struct ns__plmPartDetailClt
{
		char  *PartClient;
         	
};

struct ns__CharArray4Test 
{
	int __sizeClt;
	struct ns__plmPartDetailClt *__plmPartDetailClt;
	int __size;
	struct ns__plmPartDetail *__plmPartDetail;
	int __sizeT;
	struct ns__plmRelDetails *__plmRelDetails;
	
}
; 

int ns__getBOMLDetails(char *partnumber, char	*revision, char	*ISequence, char	*ER_EW, char	*Plant,struct ns__CharArray4Test *aString_test);