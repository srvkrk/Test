#include "soapH.h"
#include "replace_named_referance.nsmap"

#include <ae/ae.h>
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/tcfile_cache.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>//new
#include <tc/iman.h>
#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <time.h>
#include <user_exits/epm_toolkit_utils.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128
//#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		//printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			//printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}
extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;
//int replace_dataset (tag_t PDF_Tag,char *path) 
//{
//	printf("\ninside replace_dataset");
//	char *datasettype = NULL;
//	AE_reference_type_t ref_type ;
//	tag_t text_file = NULLTAG ;
//	tag_t new_text_file = NULL_TAG ;
//
//	ITK_CALL(AOM_UIF_ask_value (PDF_Tag,"object_type",&datasettype));
//
//	printf("\ndatasettype : [%s]",datasettype);
//	
//	ITK_CALL(AE_ask_dataset_named_ref(PDF_Tag, "PDF_Reference", &ref_type, &text_file));
//
//	//if (text_file!=NULLTAG)
//	//{
//	//
//	//		//printf("\n****inside function");
//	//		//ITK_CALL(AOM_refresh(text_file, TRUE));
//	//		printf("\ninside function");
//	//}
//	//
//	//else
//	//{
//	//
//	//	printf("\n**1111**inside function");
//	//
//	//}
//
//	IMF_file_data_p_t file_data;
//	ITK_CALL(IMF_get_file_access(text_file, 0, &file_data));
//	ITK_CALL(AOM_refresh(text_file, TRUE));
//	ITK_CALL(IMF_replace_file_and_get_new_tag(text_file,path, TRUE, &new_text_file));//new filename to be uploaded /replaced
//	ITK_CALL(AOM_unload(text_file));
//	ITK_CALL(AOM_refresh(PDF_Tag, TRUE));
//	ITK_CALL(AE_replace_dataset_named_ref2(PDF_Tag, text_file,"PDF_Reference", ref_type, new_text_file));
//	ITK_CALL(AE_save_myself(PDF_Tag));
//	ITK_CALL(AOM_unload(PDF_Tag));
//	ITK_CALL(IMF_release_file_access (&file_data));
//	ITK_CALL(AOM_lock_for_delete(text_file));
//	ITK_CALL(AOM_delete(text_file));
//	
//	
//	return 0;
//}

int ns__ReplaceNamedReference(struct soap* soap,char *Part_no, char* Revision, char* sequence ,char* path,char **Response)
{
	
	int status;
	int n_entries			= 2;
	int resultCount 		= 0;
	int dataset_count 		= 0;
	int cnt                 = 0 ;
	int i                   = 0 ;
	int num_to_sort         = 1;
	
	char *sUserName         = NULL;
	char *sPassword         = NULL;
	char *qry_entries[2]    = {"ID","Revision"};
	char **qry_values       = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t *partObjs		        = NULLTAG;
	tag_t query_tag		        = NULLTAG;
	tag_t Item_Tag		        = NULLTAG;
	tag_t*Rev1Tag	            = NULLTAG;
	tag_t Rel_type		   		= NULLTAG;
	tag_t PDF_Tag		   		= NULLTAG;
	tag_t *secondary_obj    	= NULLTAG;
	tag_t a_datasettype			= NULLTAG;

	char *dataset_name			= NULL;
	char *Rev 		            = NULL;
	char *Name_reference 		= NULL;
	char *datasettype_PDF_name 	= NULL;
	char File_PDF_name[WSO_name_size_c+1];
				
	Rev = (char*)MEM_alloc(sizeof(char) * 50);
	Name_reference = (char*)MEM_alloc(sizeof(char) * 50);

	AE_reference_type_t ref_type ;
	tag_t text_file             = NULLTAG ;
	tag_t new_text_file         = NULL_TAG ;
	char *datasettype           = NULL;
	IMF_file_data_p_t file_data;

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
    freopen("/tmp/tcuadml.txt", "a", stdout);

	*Response = (char *) malloc( (1000) * sizeof(char));


	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	//sUserName = ITK_ask_cli_argument("-u=");
	//sPassword = ITK_ask_cli_argument("-p=");
	//Part_no  = ITK_ask_cli_argument("-i=");
	//Revision = ITK_ask_cli_argument("-r=");
	//sequence = ITK_ask_cli_argument("-s=");
	//path     = ITK_ask_cli_argument("-p=");

	tc_strcpy(Rev,Revision);
	tc_strcat(Rev,"*");
	tc_strcat(Rev,sequence);

	
	ITK_CALL(QRY_find("Design Revision", &query_tag));
			
			
	if(query_tag)
	{
		
		qry_values[0] = (char *)MEM_alloc( strlen( Part_no ) + 1);
		tc_strcpy(qry_values[0], Part_no );
	
		qry_values[1] = (char *)MEM_alloc( strlen( Rev ) + 1);
		tc_strcpy(qry_values[1], Rev  );
	
		ITK_CALL(QRY_execute(query_tag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));
		
		if (resultCount > 0)
		{
		
			Item_Tag = partObjs[i];
		
			ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&Rel_type));
		
			ITK_CALL(GRM_list_secondary_objects_only(Item_Tag,Rel_type,&dataset_count,&secondary_obj));
		

			if(dataset_count > 0)
			{

				for ( i = 0; i < dataset_count ; i++ )
				{

				   PDF_Tag = secondary_obj[i];
				   
				   tc_strcpy(Name_reference,"PDF_Reference");
				   
				   ITK_CALL(AE_find_datasettype("PDF", &a_datasettype));
				   ITK_CALL(AOM_UIF_ask_value (PDF_Tag,"object_name",&dataset_name));
				   ITK_CALL(AOM_UIF_ask_value (PDF_Tag,"object_type",&datasettype_PDF_name));
				   ITK_CALL(AOM_refresh(PDF_Tag, TRUE));
				   
				   if(tc_strcmp(datasettype_PDF_name,"PDF")==0)
				   {
				   	   //replace_dataset(PDF_Tag,path);
					   ITK_CALL(AOM_UIF_ask_value (PDF_Tag,"object_type",&datasettype));	   
	                   ITK_CALL(AE_ask_dataset_named_ref(PDF_Tag, "PDF_Reference", &ref_type, &text_file));
	                   ITK_CALL(IMF_get_file_access(text_file, 0, &file_data));
	                   ITK_CALL(AOM_refresh(text_file, TRUE));
	                   ITK_CALL(IMF_replace_file_and_get_new_tag(text_file,path, TRUE, &new_text_file));//new filename to be uploaded /replaced
	                   ITK_CALL(AOM_unload(text_file));
	                   ITK_CALL(AOM_refresh(PDF_Tag, TRUE));
	                   ITK_CALL(AE_replace_dataset_named_ref2(PDF_Tag, text_file,"PDF_Reference", ref_type, new_text_file));
	                   ITK_CALL(AE_save_myself(PDF_Tag));
	                   ITK_CALL(AOM_unload(PDF_Tag));
	                   ITK_CALL(IMF_release_file_access (&file_data));
	                   ITK_CALL(AOM_lock_for_delete(text_file));
	                   ITK_CALL(AOM_delete(text_file));

                       tc_strcpy(*Response,"PDF Is Relpaced Successfully");
                       printf("PDF Is Relpaced Successfully");
				   }
				   else
				   {
					   tc_strcpy(*Response,"PDF Not Attached To Name Reference");
					   printf("PDF Not Attached To Name Reference");
				   }
					
				}	
			}
			else
			{
               tc_strcpy(*Response,"Dataset Not Found With Rendering Relation");
               printf("Dataset Not Found With Rendering Relation");
			}
		}
		else
		{
			tc_strcpy(*Response,"Part Not Found");
			printf("Part Not Found");
		}
	}
	else
	{
		tc_strcpy(*Response,"Query Not Found");
		printf("Query Not Found");
	}

	fflush(stdout);
    dup2(fd, fileno(stdout));
    close(fd);
    clearerr(stdout);
    fsetpos(stdout, &pos);

	return SOAP_OK;
}
