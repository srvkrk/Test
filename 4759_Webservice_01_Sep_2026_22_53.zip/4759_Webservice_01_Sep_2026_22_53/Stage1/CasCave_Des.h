//gsoap ns service name:                          CasCave_Des
//gsoap ns service style:                          rpc
//gsoap ns service namespace:                    urn:CasCave_Des
//gsoap ns service location:                     http://172.22.97.18:9080/cgi/CasCave_Des.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:CasCave_Des
//gsoap ns service method-documentation: Tests the Simple Web service


struct ns__plmPartDetail
{
	    char	*PLevel;
		char	*PartNum; 
    	char	*Revision;
		char	*Sequence;
        char *Weight;
     	char	*SurArea;
     	char	*Volume;
     	char	*CS;     
	    char	*Material;
		char	*Descrpt;
		char	*ProjCode;
		char	*ProjDesc;
		char	*PEnvDia;
		char	*Thickness;
		char	*Parttype;		
		char	*c_Qty;
};

struct ns__CharArray4Test 
{
	int __size;
	struct ns__plmPartDetail *__plmPartDetail;		
}; 

int ns__getPartDetailCasCave(char *partnumber,char*revision,char*ISequence, char*ER_EW,char *Plant,struct ns__CharArray4Test *aString_test);

