//gsoap ns service name:				 ProjectOrgID
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:ProjectOrgID
//gsoap ns service location:			 http://172.22.97.12:9080/cgi/ProjectOrgID.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:ProjectOrgID
//gsoap ns service method-documentation: Tests the Simple Web service


struct ns__ItemDet
{
   char *ProjIDDetails;
}
;
struct ns__CharArray1
{
   struct ns__ItemDet *__ptrDetails;
   int __size;
}
;

int ns__getItemData(char *Item,struct ns__CharArray1 *aString_test);


