//gsoap ns service name:				 GroupChildRelUA
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:GroupChildRelUA  
//gsoap ns service location:			 http://172.22.97.8:9010/cgi/GroupChildRelUA.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:GroupChildRelUA 
//gsoap ns service method-documentation: Tests the Simple Web service

struct ns__plmPrtDet
{   
   char *prt_no;
  // char *prt_rev;
   //char *prt_seq;  
   
}
;
struct ns__CharArray1 
{
   struct ns__plmPrtDet *__ptrPrt;
   int __size;
}
; 

int ns__getGrpChildlistsDataUA(char *Grp_prt,char *Plant, struct ns__CharArray1 *aString_test);