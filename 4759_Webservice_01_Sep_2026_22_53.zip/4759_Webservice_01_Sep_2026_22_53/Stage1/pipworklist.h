//gsoap ns service name:				 pipworklist
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:pipworklist
//gsoap ns service location:			 http://172.22.249.220:9080/cgi/pipworklist.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:pipworklist

struct ns__plmtaskstatus
{
   char *project_name; 
   char *task_name;   
   char *dept_name;
   char *role_name;
   char *user_name;
   char *status;  
};
 

struct ns__plmtasklist
{
   struct ns__plmtaskstatus *__ptr;
   int __size;
};
 
int ns__getWorkList(char *userId,struct ns__plmtasklist *return_);
 
int ns__signoffTask(char *projectName,char *taskName,char *deptName,char *roleName,char *userid,char *result, char *comments, char **return_);