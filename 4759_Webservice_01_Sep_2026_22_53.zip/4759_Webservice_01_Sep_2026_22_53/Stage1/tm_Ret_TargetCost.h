//gsoap ns service name:                         tm_Ret_TargetCost
//gsoap ns service style:                        rpc
//gsoap ns service namespace:                    urn:tm_Ret_TargetCost
//gsoap ns service location:                     http://172.22.97.12:9080/cgi/tm_Ret_TargetCost.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:tm_Ret_TargetCost
//gsoap ns service method-documentation: Tests the tm_Ret_TargetCost

//typedef char * xsd__string;
struct ns__ItemDet
{
   char *TCT_item_id;
   char *ModuleNumber;
   char *s_Module;
   char *s_tct_description;
   double f_TargetCost;
   double f_TargetToolingCpx;
   
};

struct ns__CharArray
{
	struct ns__ItemDet *__ptrItem;
	int __size; // array size
};

int ns__tm_Ret_TargetCost(char *TCT_item_id,char *ModuleNumber,struct ns__CharArray *aString);

//--should cost structure-----------------------------------------------------------
struct ns__ShouldCst
{
   char *ShouldCostPdf;
   char *ShouldCostPdfErrMsg;
};

struct ns__ShouldCstArray
{
	struct ns__ShouldCst *__sptrItem;
	int __ShouldCstArrsize; // array size
};

int ns__tm_ShouldCostDocCreate(char *ShouldCostPdf,struct ns__ShouldCstArray *aString);
