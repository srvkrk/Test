//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================
#include "soapH.h"
#include "DesignAttribute.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   // ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
	//fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;



int ns__getItemData(struct soap* soap,char *Part_no,struct ns__CharArray1 *aString_test)
{
        int ifail =0;
		int i,j = 0;
		int n_tags_found = 0;
		int num = 0;
		int d = 0;
		int row = 7;
		int		tt1	= 0;

		tag_t *tags_found = NULLTAG;
		tag_t item_t = NULLTAG;
		tag_t itemRev_t = NULLTAG;

			

		char*			responseString			= NULL;
		char*			responseString1			= NULL;
		char*			responseString2			= NULL;
		char*			responseString3			= NULL;
		char*			responseString4			= NULL;
		char*			responseString5			= NULL;
		char*			responseString6			= NULL;
		char*			responseString7         = NULL;
		char*			responseString8         = NULL;
		char*			responseString9         = NULL;
		char*			responseString10        = NULL;
		char*			responseString11        = NULL;
		char*			responseString12        = NULL;

		char*			PartNo			= NULL;
		char*			RefDrawing		= NULL;
		char*			Material		= NULL;
		char*			Prtdesc			= NULL;
		double			MatWeight;
		char*			MatWeightStr	= NULL;
		char*			SurfPrt			= NULL;
		char*			OppHand			= NULL;
		char*			Thickness		= NULL;
		char*			EnvDim		    = NULL;
		char*			DsgYield        = NULL;
		char*			ModDescr        = NULL;
		char*			Revision        = NULL;
		char*			Part_Revision	= NULL;
		char*			Print_Report	= NULL;

		char**	ReportSetSTR	= NULL;

		size_t len;
		
		//const char* u = NULL;
		//const char* p = NULL;
		//const char* g = NULL;

		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/DesignAttribute.txt", "w", stdout);
		//CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//u = ITK_ask_cli_argument( "-u=ercjsup");
		//p = ITK_ask_cli_argument( "-p=Tcua_tst@789");
		//g = ITK_ask_cli_argument( "-g=dba");
		//if (ITK_init_module(u,p,g) == ITK_ok )
		//{


		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		



		printf("\n Input .. %s",Part_no);fflush(stdout);
		if((Part_no !=NULL) && (tc_strcmp(Part_no,"")!=0))
		{
			const char *attrs[2];
			const char *values[2];
			attrs[0] ="item_id";
			attrs[1] ="object_type";
			values[0] = (char *)Part_no;
			values[1] = "Design";
			printf("\n values[0] <%s> \n",values[0] );fflush(stdout);
			printf("\n values[1] <%s> \n",values[1] );fflush(stdout);

			ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);

			printf("\n Tag Found <%d> \n",n_tags_found );fflush(stdout);
			if(n_tags_found>0)
			{
				responseString1=(char *)MEM_alloc(200);
				responseString2=(char *)MEM_alloc(200);
				responseString3=(char *)MEM_alloc(200);
				responseString4=(char *)MEM_alloc(200);
				responseString5=(char *)MEM_alloc(200);
				responseString6=(char *)MEM_alloc(200);
				responseString7=(char *)MEM_alloc(200);
				responseString8=(char *)MEM_alloc(200);
				responseString9=(char *)MEM_alloc(200);
				responseString10=(char *)MEM_alloc(200);
				responseString11=(char *)MEM_alloc(200);
				responseString12=(char *)MEM_alloc(200);

				item_t = tags_found[0];
				ITEM_ask_latest_rev(item_t,&itemRev_t);
				//itemRev_t = tags_found[0];
				AOM_ask_value_string(itemRev_t,"item_id",&PartNo);
				printf("\n PartNo <%s> \n",PartNo);fflush(stdout);
				tc_strcpy(responseString1,"PARTNUMBER=");
				tc_strcat(responseString1,PartNo);
				setAddStr(&tt1,&ReportSetSTR,responseString1);
				
				AOM_ask_value_string(itemRev_t,"t5_RefDrawing",&RefDrawing);
				printf("\n RefDrawing <%s> \n",RefDrawing);fflush(stdout);
				tc_strcpy(responseString2,"REFERENCE_DRAWING=");
				if(tc_strlen(RefDrawing)>0)
				{
					tc_strcat(responseString2,RefDrawing);
				}
				else
				{
					tc_strcat(responseString2,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString2);
				
				AOM_ask_value_string(itemRev_t,"t5_Material",&Material);
				printf("\n Material <%s> \n",Material);fflush(stdout);
				tc_strcpy(responseString3,"MATERIAL=");
				if(tc_strlen(Material)>0)
				{
					tc_strcat(responseString3,Material);
				}
				else
				{
					tc_strcat(responseString3,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString3);

				AOM_ask_value_string(itemRev_t,"object_desc",&Prtdesc);
				printf("\n Prtdesc <%s> \n",Prtdesc);fflush(stdout);
				tc_strcpy(responseString4,"DESCRIPTION="); 
				if(tc_strlen(Prtdesc)>0)
				{
					tc_strcat(responseString4,Prtdesc);
				}
				else
				{
					tc_strcat(responseString4,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString4);

				AOM_ask_value_double(itemRev_t,"t5_Weight",&MatWeight);
				printf("\n MatWeight <%f> \n",MatWeight);fflush(stdout);
				MatWeightStr=(char *)MEM_alloc(30);
				snprintf(MatWeightStr, 30, "%.3f", MatWeight);
				printf("\n MatWeightStr <%s> \n",MatWeightStr);fflush(stdout);
				tc_strcpy(responseString5,"MATERIAL_WEIGHT=");
				if(tc_strlen(MatWeightStr)>0)
				{
					tc_strcat(responseString5,MatWeightStr);
				}
				else
				{
					tc_strcat(responseString5,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString5);
				

				AOM_ask_value_string(itemRev_t,"t5_SurfPrtStd",&SurfPrt);
				printf("\n SurfPrt <%s> \n",SurfPrt);fflush(stdout);
				tc_strcpy(responseString6,"SURFACE_PROTECTION="); 
				if(tc_strlen(SurfPrt)>0)
				{
					tc_strcat(responseString6,SurfPrt);
				}
				else
				{
					tc_strcat(responseString6,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString6);

				AOM_ask_value_string(itemRev_t,"t5_OppHandDrg",&OppHand);				
				printf("\n DMLCretordate <%s> \n",OppHand);fflush(stdout);
				tc_strcpy(responseString7,"OPPOSITE_HAND=");
				if(tc_strlen(OppHand)>0)
				{
					tc_strcat(responseString7,OppHand);
				}
				else
				{
					tc_strcat(responseString7,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString7);

				AOM_ask_value_string(itemRev_t,"t5_MThickness",&Thickness);
				printf("\n Thickness <%s> \n",Thickness);fflush(stdout);
				tc_strcpy(responseString8,"THICKNESS=");
				if(tc_strlen(Thickness)>0)
				{
					tc_strcat(responseString8,Thickness);
				}
				else
				{
					tc_strcat(responseString8,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString8);

				AOM_ask_value_string(itemRev_t,"t5_EnvelopeDimensions",&EnvDim);
				printf("\n EnvDim <%s> \n",EnvDim);fflush(stdout);
				tc_strcpy(responseString9,"ENVELOPE_DIMENSIONS=");
				if(tc_strlen(EnvDim)>0)
				{
					tc_strcat(responseString9,EnvDim);
				}
				else
				{
					tc_strcat(responseString9,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString9);

				AOM_ask_value_string(itemRev_t,"t5_PerYield",&DsgYield);
				printf("\n DsgYield <%s> \n",DsgYield);fflush(stdout);
				tc_strcpy(responseString10,"DESIGN_YIELD=");
				if(tc_strlen(DsgYield)>0)
				{
					tc_strcat(responseString10,DsgYield);
				}
				else
				{
					tc_strcat(responseString10,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString10);

				AOM_ask_value_string(itemRev_t,"t5_DocRemarks",&ModDescr);
				printf("\n ModDescr <%s> \n",ModDescr);fflush(stdout);
				tc_strcpy(responseString11,"MODIFICATION_DESC=");
				if(tc_strlen(ModDescr)>0)
				{
					tc_strcat(responseString11,ModDescr);
				}
				else
				{
					tc_strcat(responseString11,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString11);
				
				AOM_ask_value_string(itemRev_t,"item_revision_id",&Revision);
				printf("\n Revision <%s> \n",Revision);fflush(stdout);
				tc_strcpy(responseString12,"REVISION=");
				if(tc_strlen(Revision)>0)
				{
					Part_Revision = tc_strtok(Revision,";");
					printf("\n Part_Revision <%s> \n",Part_Revision);fflush(stdout);
					tc_strcat(responseString12,Part_Revision);
				}
				else
				{
					tc_strcat(responseString12,"NULL");
				}
				setAddStr(&tt1,&ReportSetSTR,responseString12);

				printf("\n tt1 <%d> \n",tt1);fflush(stdout);

				//aString_test-> __size =1;
				aString_test-> __size =tt1;
				//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
				aString_test->__ptrDetails = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrDetails) );
				for(i=0;i<tt1;i++)
				{
					Print_Report = ReportSetSTR[i];
					printf("\n Print_Report <%s> \n",Print_Report);fflush(stdout);

					aString_test->__ptrDetails[i].PartDetails = malloc(500 * sizeof(char *) );
					strcpy(aString_test->__ptrDetails[i].PartDetails,Print_Report); // PART NO
				}
				/*
				for(i=0;i<1;i++)
				{
					aString_test->__ptrItem[i].PART_NO = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_NO,responseString1); // PART NO

					aString_test->__ptrItem[i].PART_REFDRW = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_REFDRW,responseString2); // PART_REFDRW

					aString_test->__ptrItem[i].PART_MATERIAL = malloc(200 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_MATERIAL,responseString3); // PART_MATERIAL

					aString_test->__ptrItem[i].PART_DESC = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_DESC,responseString4); // PART_DESC

					aString_test->__ptrItem[i].MAT_WT = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].MAT_WT,responseString5); // MAT_WT

					aString_test->__ptrItem[i].SURFACE_PROTECT = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].SURFACE_PROTECT,responseString6); // SURFACE_PROTECT

					aString_test->__ptrItem[i].OPP_HAND = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].OPP_HAND,responseString7); // OPP_HAND

					aString_test->__ptrItem[i].PART_THICKNESS = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_THICKNESS,responseString8); // PART_THICKNESS

					aString_test->__ptrItem[i].PART_ENVDIM = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_ENVDIM,responseString9); // PART_ENVDIM

					aString_test->__ptrItem[i].PART_DSGNYIELD = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_DSGNYIELD,responseString10); // PART_DSGNYIELD

					aString_test->__ptrItem[i].PART_MODDESC = malloc(200 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_MODDESC,responseString11); // PART_MODDESC

					aString_test->__ptrItem[i].PART_REV = malloc(200 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_REV,responseString12); // PART_REV
				}
				*/
			}
		}///
		//}
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

		return SOAP_OK;
}

