/* Group part Ws Requirement to fetch GROUP part for any given input Child part
 which is having parent As a group part  */
#include "soapH.h"								/* get the gSOAP-generated definitions */
#include "GrpPartWS.nsmap"		 /* get the gSOAP-generated namespace bindings */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/project.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#include <tc/preferences.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>

#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}


struct Prt_Det
{
	char	GPART[40];
	char	Resp[10];
	
}get_Prt_List_Rev;


FILE	*GrpPrtWSLog;

char 		szHMCL_file_log[250] 			= "";
char 		szHMCL_file_err[250]			= "";
char 		szHMCL_file_output[250] 		= "";
static void vLog(char* givenFormat, va_list givenArgs, char* fileName)
{
	char			* logFile 			= NULL;
	FILE			* logFp;
	time_t 			now;
	struct 			tm when;
	char 			date_str[50];
	long 			size;
	logical 		check_size 			= false;
	logFile 							= fileName;
	if (logFile)
	{
		logFp = fopen(logFile, "a+");
		if(!logFp)
		{
			fprintf(stderr, "ERROR: Cannot open '%s'\n", logFile);
			perror(logFile);
			logFp = stderr;
		}
		else{
			fseek(logFp, 0, SEEK_END);
			size = ftell(logFp);
			if(size > 3000000 && check_size)
			{	fclose (logFp);
				logFp = fopen(logFile, "w");
			}
			  }
	}
	else
	{	logFp = stderr;
	}
	if (tc_strcmp(logFile, szHMCL_file_output) == 0)
	{
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp,"\n");
		if (logFp != stderr)
		{			fclose(logFp);
		}
	}
	else
	{
		time(&now);
		when = *localtime(&now);
		strftime(date_str, 50, "%d-%m-%Y %H:%M:%S",&when);
		fprintf(logFp, "%s --- ", date_str);
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp, "\n");
		if (logFp != stderr)
		{	fclose(logFp);
		}
	}
}
void Debug(char* givenFormat, ...)
{
	va_list   functArgs;
	va_start(functArgs, givenFormat);
	vLog(givenFormat, functArgs, szHMCL_file_log);
	va_end(functArgs);
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
	{
	char *error_msg_string;
	EMH_ask_error_text(return_code, &error_msg_string);
	//EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	printf("ERROR1: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}


extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new());										/* call the request dispatcher */
};

int getPrevOfficialRev1(tag_t itemMstr,char* rlsinfo,tag_t curTag, tag_t* prevTag)
{
	int ifail = ITK_ok;
	int partRevCnt=0;
	tag_t* partRevTagObjs = NULLTAG;

	char* currItemId = NULL;
	char* currPartRev = NULL;

	date_t curr_creation_dt;
	date_t prev_creation_dt;
	int ans =0;
	CALLAPI(AOM_ask_value_string(curTag,"item_id",&currItemId))
	CALLAPI(AOM_ask_value_string(curTag,"item_revision_id",&currPartRev))
	CALLAPI(AOM_ask_value_date(curTag,"creation_date",&curr_creation_dt));


	CALLAPI(ITEM_list_all_revs (itemMstr, &partRevCnt, &partRevTagObjs));
	fprintf(GrpPrtWSLog,"\nPart Revision counts :%d\n",partRevCnt);fflush(GrpPrtWSLog);

	if(partRevCnt>0)
	{
		int i=0;
		tag_t partRevTag = NULLTAG;
		for(i=partRevCnt-1;i>=0;i--)
		{
			partRevTag = partRevTagObjs[i];
			char* itemId = NULL;
			char* partRev = NULL;
			char* rel_status = NULL;
			CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId))
			CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev))
			CALLAPI(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status))

			fprintf(GrpPrtWSLog,"\t\tPart Revision rls status to cmpr with rlsinfo :%s\n",rlsinfo);fflush(GrpPrtWSLog);
			fprintf(GrpPrtWSLog,"\t\tPart Revision  rel_status :%s\n",rel_status);fflush(GrpPrtWSLog);

			CALLAPI(AOM_ask_value_date(partRevTag,"creation_date",&prev_creation_dt));
			CALLAPI(POM_compare_dates(prev_creation_dt, curr_creation_dt, &ans));
            
			if(ans==1) continue;//Ignore the part created later that the current part

//			if(tc_strcmp(partRev,currPartRev)==0)
//			{
//				continue;
//			}
			if(tc_strstr(rel_status,rlsinfo)!=NULL)
			{
				*prevTag = partRevTag;
				fprintf(GrpPrtWSLog,"\nPrevious official revision of part %s;%s is %s;%s\n",currItemId,currPartRev,itemId,partRev);fflush(GrpPrtWSLog);
				break;
			}


		}
	}


	return ifail;
}


int ns__getGrpPartWs(struct soap* soap,char *partnumber,struct ns__CharArray4GrpPart *aString_test)
{
	int ifail =0;
	int i= 0;
    int StrctInt = 0;
    int flg_grp = 0;
	int length = 0;
	int cnt				= 0;
	char *infoVal0 = NULL;
	char *infoVal1 = NULL;
	char *infoVal2 = NULL;
	char *infoVal3 = NULL;
	char *infoVal4 = NULL;
	char *infoVal5 = NULL;
	char *infoVal6 = NULL;
	char *infoVal7 = NULL;
	char *infoVal8 = NULL;

    char *input   =NULL;
	char *input1 =	NULL;
	char *ExeLogFile =	NULL;
	char *loggedInUser = NULL;
    //tag_t queryPart   =NULLTAG;

	//tag_t *result=NULLTAG;
	tag_t rev_tag =NULLTAG;
	tag_t rev_tag1 =NULLTAG;
	tag_t prev_rev_tag =NULLTAG;
	tag_t partfnd = NULLTAG;
	char *Rev =NULL;
	char *new_rev =NULL;
	int  	n_parents=0;
	int * 	levels;
	tag_t * 	parents	 =NULLTAG;
//
//	int		n_entries	=	1;
//	int    	num_to_sort =	1;
//	int  	orders[1]  	=	{1};
//	int		count=	0;
//	char 	*keys[1] 	= 	{"creation_date"};
//	char 	*qry_part_entries[1] = {"Item ID"};
//	char 	*qry_part_values [1] = {partnumber};
//
	ExeLogFile = (char	*)MEM_alloc(100);
	tc_strcpy(ExeLogFile,"");
	tc_strcpy(ExeLogFile,"/tmp/");
	tc_strcat(ExeLogFile,partnumber);
	tc_strcat(ExeLogFile,"_GrpPartWS.log");
	GrpPrtWSLog = fopen(ExeLogFile,"w");
	//freopen(ExeLogFile, "w",GrpPrtWSLog);
	fprintf(GrpPrtWSLog,"\n Part Execution Log file is :: %s\n",ExeLogFile);


	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/GrpPartWS.txt", "a", stdout);


        CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login());
		CALLAPI(ITK_set_journalling( TRUE ));
//        ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
//        ITK_auto_login();
//        ITK_set_journalling( TRUE );

		fprintf(GrpPrtWSLog," Auto Login Successfull..!!\n");fflush(GrpPrtWSLog);
		POM_get_user_id(&loggedInUser);
		fprintf(GrpPrtWSLog," Logged in User: [%s]\n",loggedInUser);fflush(GrpPrtWSLog);

        tag_t	queryPart	=	NULLTAG;
		tag_t*  result	=	NULLTAG;

        int		n_entries	=	1;
        int		l	=	2;
		int    	num_to_sort =	1;
		int  	orders[]  	=	{2};
		int		count=	0;
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[1] = {"ID"};
		char 	*qry_part_values[1] = {partnumber};
		struct Prt_Det prtLst[500];
        
		CALLAPI(QRY_find2("Design Revision", &queryPart));
		CALLAPI(QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &count, &result));
		fprintf(GrpPrtWSLog,"\nNumber of for Revsion null rev of part  [%s]found : [%d]\n",partnumber,count);fflush(GrpPrtWSLog);


		fprintf(GrpPrtWSLog,"\nNumber of rev   [%s]found : [%d]\n",partnumber,count);fflush(GrpPrtWSLog);

		if (count>0)
		{
			int j = 0;
			int k = 0;
			
			tag_t itemMstr = NULLTAG;
			char *itemId = NULL;
			char *partfnditemId = NULL;
			char *partfndType = NULL;
			char *RevisionS = NULL;
			char *rel_status = NULL;
           
			 fprintf(GrpPrtWSLog,"\n Number of design rev found :%d \n",count);fflush(GrpPrtWSLog);
			 rev_tag=result[j];
			 CALLAPI(AOM_ask_value_string(rev_tag,"item_id",&itemId));
			 CALLAPI(ITEM_find_item(itemId,&itemMstr));
			 CALLAPI(getPrevOfficialRev1(itemMstr,"ERC Released",rev_tag,&prev_rev_tag));

			if(prev_rev_tag!=NULLTAG)
			{
			  CALLAPI(PS_where_used_all(prev_rev_tag,2,&n_parents,&levels,&parents));
			  fprintf(GrpPrtWSLog,"\n***** No of Parent objects are n_parents : %d\n",n_parents);fflush(GrpPrtWSLog);
              
			  if(n_parents>0)
				{
				  for(k=0;n_parents>k;k++)
					{
					  partfnd = parents[k];
					  CALLAPI(AOM_ask_value_string(partfnd,"item_id",&partfnditemId));
					  CALLAPI(AOM_ask_value_string(partfnd,"t5_PartType",&partfndType));
					  CALLAPI(AOM_ask_value_string(partfnd,"item_revision_id",&RevisionS));
					  CALLAPI(AOM_UIF_ask_value(partfnd, "release_status_list", &rel_status));
					   fprintf(GrpPrtWSLog,"\t\tPart Revision  partfnditemId:-  %s\n",partfnditemId);fflush(GrpPrtWSLog);
					   fprintf(GrpPrtWSLog,"\t\tPart Revision  partfndType:---  %s\n",partfndType);fflush(GrpPrtWSLog);
					   fprintf(GrpPrtWSLog,"\t\tPart Revision  RevisionS  :---  %s\n",RevisionS);fflush(GrpPrtWSLog);
					   fprintf(GrpPrtWSLog,"\t\tPart Revision  rel_status :---  %s\n",rel_status);fflush(GrpPrtWSLog);


					  if((tc_strcmp(partfndType,"Group Id")==0)||(tc_strcmp(partfndType,"G")==0))
						{
						  fprintf(GrpPrtWSLog,"\t\tPart Revision %s is a group part :-  %s\n",partfnditemId,partfndType);fflush(GrpPrtWSLog);

                           StrctInt	=	StrctInt + 1;
                           flg_grp = 1;
                            
							tc_strcpy(prtLst[StrctInt].GPART,partfnditemId);
                            tc_strcpy(prtLst[StrctInt].Resp,"1");	
							break; 
						     
					    }
					
				    }
					 if(flg_grp == 0)
					 {
						 StrctInt	=	StrctInt + 1;
					     aString_test->__size = StrctInt;
				         tc_strcpy(prtLst[StrctInt].GPART,"NOT_FOUND");
                         tc_strcpy(prtLst[StrctInt].Resp,"0");

					 }

			    }
				 fprintf(GrpPrtWSLog,"\n***** flg_grp : %d\n",flg_grp);fflush(GrpPrtWSLog);

           if(StrctInt>0)
				{

				   aString_test->__size = StrctInt;
				   aString_test->__plmPartDetail	= malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__plmPartDetail) );

				   length	=	strlen(partfnditemId);
				   aString_test->__plmPartDetail[0].PartNum = malloc(length* sizeof(char*)+5);
				   aString_test->__plmPartDetail[0].opresp = malloc(length* sizeof(char*)+5);
					
				  if((flg_grp > 0)&&(length>0))
					{
					strcpy(aString_test->__plmPartDetail[i].PartNum, prtLst[1].GPART);
					strcpy(aString_test->__plmPartDetail[i].opresp,"1");
					
					}
					else
					{
					strcpy(aString_test->__plmPartDetail[i].PartNum,"NA");
					strcpy(aString_test->__plmPartDetail[i].opresp,"0");
					}

				
				}


			}
		}
	fclose(GrpPrtWSLog);
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;

//	CLEANUP :
//
//		return SOAP_OK;
//
//	EXIT:
//		return SOAP_OK;
}
;

