//gsoap ns service name:				 NoPoTaskEpa1UACV
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:NoPoTaskEpa1UACV
//gsoap ns service location:			http://172.22.97.8:9010/cgi/NoPoTaskEpa1UACV.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:NoPoTaskEpa1UACV
//gsoap ns service method-documentation: Tests the Simple Web service

struct ns__VcDetailsData
{
   char *PartDetails;
}
;
struct ns__CharArray3
{
   struct ns__VcDetailsData *__ptrVcDetails;
   int __size;
}
;

int ns__getDMLPODetailsData(char *TaskName,struct ns__CharArray3 *aString_test3);


