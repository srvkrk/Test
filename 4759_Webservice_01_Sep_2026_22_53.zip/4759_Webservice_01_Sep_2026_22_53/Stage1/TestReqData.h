//gsoap ns service name:				 TestReqData
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:TestReqData
//gsoap ns service location:			 http://172.22.97.28:9080/cgi/TestReqData.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:TestReqData
//gsoap ns service method-documentation: Tests the Simple Web service

typedef char * xsd__string;

struct ns__CharArray
{
	xsd__string     *__ptr;         // pointer to array of string
	int             __size;         // array size
};

int ns__TestReqDetailsAll(char *Item, struct ns__CharArray *aString);
