//gsoap ns service name:				 DesignRuleCreation
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:DesignRuleCreation
//gsoap ns service location:			 http://172.22.99.106:9080/cgi/DesignRuleCreation.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:DesignRuleCreation
//gsoap ns service method-documentation: Tests the Simple Web service

int ns__getDesignRuleCre(char *Design_RuleGrp,char *Design_RuleSGrp,char *Design_BusUn,char *Design_DesGrp,char *Design_DesSGrp,char *Design_DrApp,
 char *Design_Modladd,char *Design_Rule,char *Design_RuleRev,char *Design_Autid,char *Design_Ruletitle,char *Design_RuleStat,char *Design_Appid,
 char *Design_AppDate,char *Design_MultiKey,char *Design_MastSrN,char *Design_Wrkfid,char **Response);