//gsoap ns service name:			DMLPartValid
//gsoap ns service style:			rpc
//gsoap ns service namespace:		urn:DMLPartValid  
//gsoap ns service location:			http://172.22.97.8:9010/cgi/DMLPartValid.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:		urn:DMLPartValid 
//gsoap ns service method-documentation: Tests the Simple Web service
int ns__getdmlpartvalid(char *dmlnumber, char *assemblynumber, char **Response);