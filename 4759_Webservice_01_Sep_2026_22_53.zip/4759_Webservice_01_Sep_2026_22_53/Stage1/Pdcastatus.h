//gsoap ns service name:                          Pdcastatus
//gsoap ns service style:                          rpc
//gsoap ns service namespace:                    urn:Pdcastatus
//gsoap ns service location:                    http://172.22.97.12:9080/cgi/Pdcastatus.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:Pdcastatus
//gsoap ns service method-documentation: Tests the Simple Web service



//int ns__getDmlDetails(char *tzname,char *emailid,struct ns__CharArray4Test *aString_test);
int ns__getStatusPDCA(char *Dml_Num,char *Status,char **Response);
