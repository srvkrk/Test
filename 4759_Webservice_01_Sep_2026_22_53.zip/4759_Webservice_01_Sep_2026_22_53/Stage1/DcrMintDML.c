#include <soapH.h> /* get the gSOAP-generated definitions */
#include <DcrMintDML.nsmap> /* get the gSOAP-generated namespace bindings */
#include <tc/tc_startup.h>
#include <tc/tc_macros.h>
#include <tccore/part.h>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <qry/qry.h>
#include <epm/epm.h>
#include <sa/sa.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

char* subString (char* mainStringf ,int fromCharf,int toCharf);

char* subString
(
	char* mainStringf ,
	int fromCharf     ,
	int toCharf
)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
	{
	char *error_msg_string;

	EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}

extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new()); /* call the request dispatcher */
} 
;


int ns__DmlDcrData(struct soap* soap, char* Dmlno, char **responseT)
{
	int ifail =0;

	int cnt =0;
	int dn =0;
	int R =0;
	int P =0;
	int W =0;

	int n_items1 =0;	
	int n_items =0;	
	int n_items2 =0;	

	tag_t item_t= NULLTAG;
	tag_t itemRev_t = NULLTAG;
	char *LatRev_ObjectType;
	int iProp_Count=0;
	char **PropName;
	char *d_value,*sDisplayName,*sSetValueis;
	char *cmd,*docFile;

	tag_t	*item_tags1		= NULLTAG;
	tag_t	*item_tags2		= NULLTAG;
	tag_t	*item_tags		= NULLTAG;
	tag_t	item=NULLTAG;
	tag_t	item1=NULLTAG;
	tag_t	rev1=NULLTAG;
	tag_t	copy_tag		= NULLTAG;
	tag_t	unit_of_measure=NULLTAG;
	tag_t	objTypeTag3= NULLTAG;
	tag_t	objTypeTag2= NULLTAG;
	tag_t	objTypeTag= NULLTAG;
	tag_t	tRelationFind	= NULLTAG;
	tag_t	tRelationObj1	= NULLTAG;
	tag_t	tRelationFind1	= NULLTAG;
	tag_t	tRelationObj11	= NULLTAG;
	tag_t	tRelationFind2	= NULLTAG;
	tag_t	tRelationObj12	= NULLTAG;
	char	type_name13[TCTYPE_name_size_c+1];
	char	type_name1[TCTYPE_name_size_c+1];
	char	type_name12[TCTYPE_name_size_c+1];
	char*	ent_uom=NULL;
	//char*	result		= NULL;
	char*	result1		= NULL;
	logical	logProModifiable;

	int status;
	int n_found = 0;
	int result = 0;
	int ret = 0;
	int ss = 0;
	char *s;
	//char *revSeq;
	char *dmlname;
	char *dcrname;

	tag_t boTag= NULLTAG;
//	tag_t boRevTag= NULLTAG;
	tag_t creInputTag= NULLTAG;
	tag_t creInputTag_r= NULLTAG;
	tag_t boTypeTag= NULLTAG;
	tag_t boTypeTag_r= NULLTAG;
	tag_t* foundItemsMtag;
	tag_t rev;

	//char docFile[50];
	tag_t Newdataset =  NULLTAG;
	tag_t relation_type, relation, relation_type1,Rel_dcr_part;
	tag_t datasettype =  NULLTAG;
	tag_t Fndrelation = NULLTAG;
	tag_t Newdataset_t = NULLTAG;
	int			status_count;
	tag_t*		status_list;
	char *CurrentRelStatus = NULL;

	char *token;
	char *buff;
	tag_t *DcrList=NULLTAG;
	char *logFile;
	char *part,*revv,*seq,*revSeq;
	char *t5_DesignGrp, *t5_DCR_Desc,*t5_DCR_Name;
	int i=0, j;
	int Dcrcnt=0;
	tag_t rev_tag=NULLTAG;
	tag_t implemRelationType_t=NULLTAG;

	int    index;
	int    l_strings=80;
	int		n_strings = 1;
	int		tempStrLength = 80;
	char**	stringArray = NULL;
	char*	tempString = NULL;

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	//freopen("log.txt", "w", stdout);

	logFile = (char *) malloc(sizeof (char) * 50 );
	strcpy(logFile,"/tmp/");
	//strcat(logFile,DCR_No);
	strcat(logFile,"DMLDCR.log");
	freopen(logFile, "w", stdout);

	CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	CALLAPI(ITK_auto_login( ));
	CALLAPI(ITK_set_journalling( TRUE ));  

	*responseT = malloc(sizeof (char) * 500 );
	token = (char *) malloc(sizeof (char) * 500 );
	buff = (char *) malloc(sizeof (char) * 500 );
	docFile = (char *) malloc(sizeof (char) * 100 );

	tc_strcpy(*responseT,"NULL");

	stringArray = malloc( n_strings * sizeof *stringArray );
	for( index=0; index<n_strings; index++ )
	{
		stringArray[index] = malloc( l_strings + 1 );
	}
	tempString = malloc( tempStrLength + 1 );

	TCTYPE_find_type("T5_DChangeReport", NULL, &boTypeTag);
	TCTYPE_find_type("T5_DChangeReportRevision", NULL, &boTypeTag_r);
	if(boTypeTag != NULLTAG) 
		printf("\nType Tag Found. \n", n_found);fflush(stdout);

	if(boTypeTag_r != NULLTAG) 
		printf("\n Revision Type Tag Found. \n", n_found);fflush(stdout);
	
	GRM_find_relation_type("CMImplements",&implemRelationType_t);
	//printf("Created DCR NUMBER IS :%s",DCR_No);fflush(stdout);
	

		if(Dmlno != NULL)
		{
			revSeq = (char *) malloc(sizeof (char) * 2000 );
            tc_strcpy(revSeq,"");
			const char s[2] = ",";
			printf("\n Dmlno: %s\n",Dmlno);fflush(stdout);
			buff = strdup(Dmlno);
			printf("\n buff: %s",buff);fflush(stdout);
			//token=strtok(buff,",");    
			//while(token!=NULL)                    
			//{
			//  printf("string =%s\n",token);fflush(stdout);
			 // i++;
			 
			  //token=strtok(NULL,",");
			
			  
			  char *rest = NULL;
   

    for (token = strtok_r(buff, ",", &rest);
         token != NULL;
         token = strtok_r(NULL, ",", &rest)) {   
        printf("token:%s\n", token);
		ITEM_find_item(token,&item_t);
    

				if(item_t)
				{
					printf("\n DCR FOUND");fflush(stdout);
					ITEM_ask_latest_rev(item_t,&itemRev_t);
					AOM_UIF_ask_value(itemRev_t,"object_type",&LatRev_ObjectType);
					printf("\n Object Type of Latest Revision is :%s",LatRev_ObjectType);fflush(stdout);
					if(tc_strcasecmp(LatRev_ObjectType,"ERC DML Revision")==0)
					{
					 WSOM_ask_release_status_list(itemRev_t,&status_count,&status_list);

								 if (status_count > 0)  /* No Status, so the Item is not yet Released */
									{
											for(ss=0; ss<status_count ; ss++)
											{
													AOM_ask_value_string(status_list[0],"object_name",&CurrentRelStatus);
													printf("\n CurrentRelStatus: %s",CurrentRelStatus);fflush(stdout);
													if((tc_strstr(CurrentRelStatus,"ERC Released")==NULL) || (tc_strstr(CurrentRelStatus,"T5_LcsErcRlzd")==NULL) )
													{
														if(AOM_ask_value_string(itemRev_t,"item_id",&dmlname));
														tc_strcat(revSeq,dmlname);
														
														if(implemRelationType_t != NULLTAG)
														{
															GRM_list_secondary_objects_only(itemRev_t,implemRelationType_t,&Dcrcnt,&DcrList);
															
															//TC_write_syslog("\n DCR count = %d\n",Dcrcnt);
															printf("\n DCR count = %d\n",Dcrcnt);fflush(stdout);
															if(Dcrcnt > 0)
															{
																
                                                                
																
																tc_strcat(revSeq,"::");
																for(dn=0; dn<Dcrcnt ; dn++)
																{
																	if(AOM_ask_value_string(DcrList[dn],"item_id",&dcrname));
																	tc_strcat(revSeq,dcrname);
																	tc_strcat(revSeq,",");

																}
																tc_strcat(revSeq,"~");
															}
														}
													}
													
											}
									}
					}
				}

			
		
		}
		printf("\n response: %s",revSeq);fflush(stdout);

		
	
	}
          	
	printf("\n********************************************************************************************\n");fflush(stdout);
	strcpy(*responseT,revSeq);
	
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos); 
	
	return SOAP_OK;

}
;
