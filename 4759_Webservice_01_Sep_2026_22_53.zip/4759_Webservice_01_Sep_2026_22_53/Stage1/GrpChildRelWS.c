#include "soapH.h"
#include "GrpChildRelWS.nsmap"

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
//#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <fclasses/tc_string.h>
//#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/project.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#include <tc/preferences.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>



#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

//#include "tm_apl_std_common_function.c"


#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}

/*struct BomChldStrut
{
        tag_t child_objs;
        tag_t child_objs_bvr;
        int child_objs_lvl;
}*get_BomChldStrut;
*/

struct WSBomChildStrut
{
  tag_t child_objs;
  //tag_t child_objs_bvr;//BVR
  char *PartNo;
  //char PartNo[100];
  //char *Qty;
  //char *UOM;
}*get_WSBomChildStrut;

struct ChldStruct
{
        //char child_parts[10000];
        char *child_parts;
        //char *PartNo;

}*get_ChldStruct;

FILE    *GrpChildRelWSLog;

char            szHMCL_file_log[250]                    = "";
char            szHMCL_file_err[250]                    = "";
char            szHMCL_file_output[250]                 = "";
static void vLog(char* givenFormat, va_list givenArgs, char* fileName)
{
        char                    * logFile                       = NULL;
        FILE                    * logFp;
        time_t                  now;
        struct                  tm when;
        char                    date_str[50];
        long                    size;
        logical                 check_size                      = false;
        logFile                                                         = fileName;
        if (logFile)
        {
                logFp = fopen(logFile, "a+");
                if(!logFp)
                {
                        fprintf(stderr, "ERROR: Cannot open '%s'\n", logFile);
                        perror(logFile);
                        logFp = stderr;
                }
                else{
                        fseek(logFp, 0, SEEK_END);
                        size = ftell(logFp);
                        if(size > 3000000 && check_size)
                        {       fclose (logFp);
                                logFp = fopen(logFile, "w");
                        }
                          }
        }
        else
        {       logFp = stderr;
        }
        if (tc_strcmp(logFile, szHMCL_file_output) == 0)
        {
                vfprintf(logFp, givenFormat, givenArgs);
                fprintf(logFp,"\n");
                if (logFp != stderr)
                {                       fclose(logFp);
                }
        }
        else
        {
                time(&now);
                when = *localtime(&now);
                strftime(date_str, 50, "%d-%m-%Y %H:%M:%S",&when);
                fprintf(logFp, "%s --- ", date_str);
                vfprintf(logFp, givenFormat, givenArgs);
                fprintf(logFp, "\n");
                if (logFp != stderr)
                {       fclose(logFp);
                }
        }
}
void Debug(char* givenFormat, ...)
{
        va_list   functArgs;
        va_start(functArgs, givenFormat);
        vLog(givenFormat, functArgs, szHMCL_file_log);
        va_end(functArgs);
}
void setAddStr1(int count,char ***strset,char* str)
{

        count=count+1;
        //printf("\n setAddStr %d",*count);fflush(stdout);
        if(count==1)
        {
                (*strset) = (char **)malloc((count ) * sizeof(char *));
        }
        else
        {
                (*strset) = (char **)realloc((*strset),(count ) * sizeof(char *));
        }
        (*strset)[count-1] = malloc((strlen(str)+1) * sizeof(char));
         tc_strcpy((*strset)[count-1],str);
         //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}
void setFindStr(char **str_list,int count,char *str,int *found)
{

        int k=0;
        *found=0;
        for(k=0;k<count;k++)
        {

                //printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
                if(tc_strcmp(str_list[k],str)==0)
                {
                        *found=1;
                        break;
                }

        }
}
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
        printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
                printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
                printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}
//#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
        {
        char *error_msg_string;

        //EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        EMH_ask_error_text (return_code, &error_msg_string);
        printf("ERROR1: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

        }
        return return_code;
}


void tm_EBOM_MBOM_Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct WSBomChildStrut WSBomChildStrut[],int* StructChldCnt)
{
        int ifail;
    int iChildItemTag=0;
        char * ItemName =NULL;
        char * parttype =NULL;
        char * ItemUOM =NULL;
        char * ItemQty =NULL;
        char * CUOM =NULL;
        char * CQty =NULL;
        char * CItemName =NULL;
        char    conQtyString[20];
        int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
    int ItemQtyInt=0;
    int CQtyInt=0;
    int cnt=0;
    int conQty=0;
    int FlagFound=0;
        int     n_values_bvr=0;
        tag_t                   *bvr_assy_part= NULLTAG;
        tag_t                   bvr_tag= NULLTAG;
        tag_t   t_ChildItemRev;
        tag_t*  childrenTag     = NULLTAG;
        char *view_name=NULL;
        tag_t   window                          = NULLTAG;
        char*                   partTok                                 =NULL;
        char*                   viewTok                                 =NULL;
        tag_t   top_line                        = NULLTAG;
        int bvrfound=0;
        tag_t  *children=NULLTAG;
        char* partNumber        = NULL;
        tag_t   objChild                        = NULLTAG;
        tag_t   objChild_bvr                    = NULLTAG;

    ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
        printf("\n Part number===>%s\n",partNumber);fflush(stdout);

        if( level >= reqLevel )
        {
                goto CLEANUP;
        }

        ITKCALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
        printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

        if(n_values_bvr==0)
        {
                flagBVR=0;
        }
        else if(n_values_bvr>0)
        {
                //printf("\n BVR found");fflush(stdout);
                for(assbvr=0;assbvr<n_values_bvr;assbvr++)
                {
                        ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
                        partTok = strtok (view_name,"-");
                        viewTok = strtok (NULL,"-");
                        if(strlen(viewTok)>0)
                        {
                                if(tc_strcmp(viewTok,ViewBVR)==0)
                                {
                                        flagBVR=1;
                                        bvr_tag=bvr_assy_part[assbvr];
                                        break;
                                }
                        }
                }
                if(flagBVR!=1)
                {
                        for(assbvr=0;assbvr<n_values_bvr;assbvr++)
                        {
                                ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
                                partTok = strtok (view_name,"-");
                                viewTok = strtok (NULL,"-");
                                if(strlen(viewTok)>0)
                                {
                                                flagBVR=1;
                                                bvr_tag=bvr_assy_part[assbvr];
                                                break;

                                }
                        }
                }

        }

        ITKCALL(BOM_create_window (&window));
        ITKCALL(BOM_set_window_config_rule(window,revRule));
        ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
        if(flagBVR==1)
        {
                BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
                //ITKCALL(BOM_window_hide_suppressed(window));
                ITKCALL(BOM_window_show_suppressed(window));
                ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
            fprintf(GrpChildRelWSLog,"\n\n\t\t 1111 No of child objects are n : %d\n",n);fflush(GrpChildRelWSLog);
                level = level + 1;
                for (k = 0; k < n; k++)
                {
                        BOM_line_unpack (children[k]);
                        //BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
                        //BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
                        AOM_ask_value_tag(children[k],bomAttr_lineItemRevTag, &t_ChildItemRev);
                        if(t_ChildItemRev!=NULLTAG)
                        {
                                ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName));
                ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&parttype));
                                FlagFound=0;

                                if(*StructChldCnt>0)
                                {
                                        for (cnt=1;cnt<= *StructChldCnt;cnt++ )
                                        {
                                                objChild                = NULLTAG;
                                                objChild_bvr    = NULLTAG;
                                                CQty                    = NULL;
                                                CUOM                    = NULL;
                                                CItemName               = NULL;

                                                objChild=WSBomChildStrut[cnt].child_objs;
                                                ITKCALL(AOM_ask_value_string(objChild,"item_id",&CItemName));
                                                if(tc_strcmp(ItemName,CItemName)==0)
                                                {
                                                        fprintf(GrpChildRelWSLog,"\nCItemName = %s \n",CItemName);fflush(GrpChildRelWSLog);
                                                        FlagFound=1;
                                                        break;
                                                }

                                        }
                                        if(FlagFound==1)
                                        {
                        continue;

                                        }
                                        else
                                        {
                                                *StructChldCnt  =       *StructChldCnt+1;
                                                WSBomChildStrut[*StructChldCnt].child_objs = t_ChildItemRev;
                                                WSBomChildStrut[*StructChldCnt].PartNo=ItemName;

                                        }
                                }
                                else
                                {
                                                *StructChldCnt  =       *StructChldCnt+1;
                                        WSBomChildStrut[*StructChldCnt].child_objs = t_ChildItemRev;
                                        WSBomChildStrut[*StructChldCnt].PartNo=ItemName;

                                }

                                tm_EBOM_MBOM_Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,WSBomChildStrut,StructChldCnt);

                        }
                }
                level = level - 1;
        }
        CLEANUP:
                 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int tm_EBOM_MBOM_Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct WSBomChildStrut WSBomChildStrut[] ,int* StructChldCnt)
{
        int   ifail                             = 0;

        tag_t revRule                   = NULLTAG;
        char* vehicleNumber     = NULL;
        int j                                   = 0;
        int cnt                                 = 0;
        PIE_scope_t scope;
        int     n_closure_tags;
        tag_t *         closure_tags;
        tag_t   closure_tag;
        int k1=0;
        int n=0;
        int     n_values_bvr=0;
        tag_t                   *bvr_assy_part= NULLTAG;
        tag_t                   bvr_tag= NULLTAG;
        int level                               = 0;
        tag_t   window                          = NULLTAG;
        tag_t   top_line                        = NULLTAG;
        tag_t   objChild                        = NULLTAG;
        tag_t   objChild_bvr                    = NULLTAG;
        int child_lvl=0;
        char    *c_Qty                                          =       NULL;
        tag_t  *children1=NULLTAG;
        int iChildItemTag=0;
        int assbvr=0;
        int bvrfound=0;
        int flagRevRule=0;
        int flagClosureRule=0;
        char *view_name=NULL;
        char*                   partTok                                 =NULL;
        char*                   viewTok                                 =NULL;
        tag_t   t_ChildItemRev;
        char * ItemName ;
        char * CItemName ;

        printf("\nInside tm_EBOM_MBOM_Get_Part_BOM_Lvl ....\n");

        if(VehicleObj == NULLTAG)
        {
                printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
                return ifail;
        }
        CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
        printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

        printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
        printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
        printf("\nBefore level==>%d\n",level);fflush(stdout);
        printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
        printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
        printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

        ITKCALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
        if(n_values_bvr>0)
        {
                for(assbvr=0;assbvr<n_values_bvr;assbvr++)
                {
                        ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
                        partTok = strtok (view_name,"-");
                        viewTok = strtok (NULL,"-");
                        if(strlen(viewTok)>0)
                        {
                                if(tc_strcmp(viewTok,ViewBVR)==0)
                                {
                                        bvrfound++;
                                        bvr_tag=bvr_assy_part[assbvr];
                                        break;
                                }
                        }
                }
                if(bvrfound!=1)
                {
                        for(assbvr=0;assbvr<n_values_bvr;assbvr++)
                        {
                                ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
                            partTok = strtok (view_name,"-");
                                viewTok = strtok (NULL,"-");
                                if(strlen(viewTok)>0)
                                {
                                        bvrfound=1;
                                        bvr_tag=bvr_assy_part[assbvr];
                                        break;

                                }
                        }
                }

        }

        printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
        if(bvrfound==0)
        {
                printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
        }
        else
        {
                CALLAPI(CFM_find(revRuleName, &revRule));
                if (revRule != NULLTAG)
                {
                        //printf("\nFind revRule\n");fflush(stdout);
                        flagRevRule=1;
                }

                scope=PIE_TEAMCENTER;
                CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
                //printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
                if(n_closure_tags==1)
                {
                        closure_tag=closure_tags[0];
                        flagClosureRule=1;
                }
                //printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
                //printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);

                if(*StructChldCnt>0)
                {

                        printf("\n Inside tm_EBOM_MBOM_Get_Part_BOM_Lvl ..StructChldCnt is 0 ");fflush(stdout);
                }
                else
                {
                        WSBomChildStrut[*StructChldCnt].child_objs = t_ChildItemRev;
                        WSBomChildStrut[*StructChldCnt].PartNo=vehicleNumber;
                }



                if((flagClosureRule==1) && (flagRevRule==1))
                {

                        tm_EBOM_MBOM_Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,WSBomChildStrut,StructChldCnt);
                }
                else
                {
                        printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
                }

        }
        printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

        return ifail;
}


//int ns__getGrpChildRelWS(struct soap* soap,char *Grp_prt,char *Plant,struct ns__CharArray1 *aString_test)
int ns__getGrpChildRelWS(struct soap* soap,char *Grp_prt,char *Plant,char *Release_status,struct ns__CharArray1 *aString_test)
{

            int reqlevel = 99;
                int StructChldCnt = 0;
        int childcnt = 1;
                int ifail  =  0;
                int j=0,i=0;
                int k=0,ip=0,p=0;
                int strcount = 0;
                int     d=0;
                int chcnt=0;
                int flag = 0;
                int prtptr=0;
                int PartCnt = 0;
        int cnt = 0;
                int BPSFlg = 0;
                int     SysReturn =     0;
                int cntdp = 0;
                int Released_cnt = 0;

                char *ExeLogFile =      NULL;
                char *loggedInUser = NULL;

                char *ClosureRName= NULL;
        char *RevisionRName= NULL;
                char *ClosureRNamed= NULL;
        char *RevisionRNamed= NULL;
                char *ViewBVR= NULL;
                char *Released_status = NULL;
                char *Rlzd_status = NULL;
                char*   Owner               =   NULL;
            char*   owning_group        =   NULL;

                char *PartName  = NULL;
                //char** grppart        = NULL;
                char *itemId = NULL;
                char *partRev = NULL;
                char filewrite[3000];

        tag_t   Childobj = NULLTAG;
                tag_t PrtRltnTag = NULLTAG;
                tag_t PartTag = NULLTAG;
                tag_t itemRev_tag = NULLTAG;
                //tag_t rev_tag = NULLTAG;
                tag_t *PartsTags = NULLTAG;
                tag_t *status_list = NULLTAG;

                //struct WSBomChildStrut ChldStrutPart[10000];
       // struct ChldStruct ChldPrtList[10000];

                char *inputfile =       NULL;
                FILE *fp1;

                ExeLogFile = (char      *)MEM_alloc(100);
            tc_strcpy(ExeLogFile,"");
            tc_strcpy(ExeLogFile,"/tmp/");
            tc_strcat(ExeLogFile,Grp_prt);
                //tc_strcat(ExeLogFile,"_");
                //tc_strcat(ExeLogFile,Plant);
            tc_strcat(ExeLogFile,"_GrpChildRelWS.log");
            GrpChildRelWSLog = fopen(ExeLogFile,"w");

            fprintf(GrpChildRelWSLog,"\n Part Execution Log file is :: %s\n",ExeLogFile);fflush(GrpChildRelWSLog);
			fprintf(GrpChildRelWSLog,"\n Release status........\n");fflush(GrpChildRelWSLog);


                fpos_t pos;
                fgetpos(stdout, &pos);
                int fd = dup(fileno(stdout));
                freopen("/tmp/GrpChildRelWS.txt", "w", stdout);

                // CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
        // CALLAPI(ITK_initialize_text_services( 0 ));
                // CALLAPI(ITK_auto_login());

        // ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
        // CALLAPI(ITK_auto_login());
        // ITK_set_bypass(true);

    //ifail = ITK_init_module("aplplanner","XYT1ESA","dba");
        //ifail = ITK_init_module("ap922200.ttl","letmelogin@2522QWERTY","PLM_Support_Group");
        //ifail = ITK_init_module("ap922200.ttl","letmelogin@2225RAMBO","PLM_Support_Group");
        ifail = ITK_init_module("cb923330.ttl","Newyear@2610#","PLM_Support_Group");
        //ifail = ITK_init_module("akk923977","XYT1ESA","PLM_Support_Group");
        if(ifail==1)
        {
                fprintf(GrpChildRelWSLog,"\n Login successful\n");fflush(GrpChildRelWSLog);
        }
        else
        {
                fprintf(GrpChildRelWSLog,"\n Login Failed\n");fflush(GrpChildRelWSLog);
        }
                //CALLAPI(ITK_set_journalling( TRUE ));

                //fprintf(GrpChildRelWSLog," Auto Login Successfull..!!\n");fflush(GrpChildRelWSLog);
                POM_get_user_id(&loggedInUser);
                fprintf(GrpChildRelWSLog," Logged in User: [%s]\n",loggedInUser);fflush(GrpChildRelWSLog);


                        ClosureRName=(char *) MEM_alloc(200 * sizeof(char *));
                RevisionRName=(char *) MEM_alloc(200 * sizeof(char *));
                        ClosureRNamed=(char *) MEM_alloc(200 * sizeof(char *));
                RevisionRNamed=(char *) MEM_alloc(200 * sizeof(char *));
                ViewBVR=(char *) MEM_alloc(100 * sizeof(char *));
                Rlzd_status=(char *) MEM_alloc(50 * sizeof(char *));
                        fprintf(GrpChildRelWSLog,"\nPlant = %s \n",Plant);fflush(GrpChildRelWSLog);
                        fprintf(GrpChildRelWSLog,"\nGrp_prt = %s \n",Grp_prt);fflush(GrpChildRelWSLog);
						fprintf(GrpChildRelWSLog,"\nRelease_status = %s \n",Release_status);fflush(GrpChildRelWSLog);

                        if(tc_strcmp(Plant,"CVBUJSR")==0)
                        {
                            tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLJ");
                    tc_strcpy(RevisionRName,"APLJ Release and Above");
                                tc_strcpy(ClosureRNamed,"BOMViewClosureRuleSTDJ");
                    tc_strcpy(RevisionRNamed,"STDJ Released and Above");
                    tc_strcpy(ViewBVR,"View");
                    //tc_strcpy(Rlzd_status,"T5_LcsStdjRlzd");

                        }
                        else if(tc_strcmp(Plant,"DHARWAD")==0)
                        {
                    tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLD");
                    tc_strcpy(RevisionRName,"APLD Release and Above");
                                tc_strcpy(ClosureRNamed,"BOMViewClosureRuleSTDD");
                    tc_strcpy(RevisionRNamed,"STDD Released and Above");
                    tc_strcpy(ViewBVR,"View");
                                //tc_strcpy(Rlzd_status,"T5_LcsStddRlzd");

                        }
                        else if(tc_strcmp(Plant,"CVBULKO")==0)
                        {
                                tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLL");
                    tc_strcpy(RevisionRName,"APLL Release and Above");
                                tc_strcpy(ClosureRNamed,"BOMViewClosureRuleSTDL");
                    tc_strcpy(RevisionRNamed,"STDL Released and Above");
                    tc_strcpy(ViewBVR,"View");
                                //tc_strcpy(Rlzd_status,"T5_LcsStdlRlzd");

                        }
                        else if(tc_strcmp(Plant,"CVBUPUNE")==0)
                        {
                            tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLP");
                    tc_strcpy(RevisionRName,"APLP Release and Above");
                                tc_strcpy(ClosureRNamed,"BOMViewClosureRuleSTDP");
                    tc_strcpy(RevisionRNamed,"STDP Released and Above");
                //tc_strcpy(RevisionRName,"ERC release and above");
                fprintf(GrpChildRelWSLog,"\n RevisionRName :%s \n",RevisionRName);fflush(GrpChildRelWSLog);
                    tc_strcpy(ViewBVR,"View");
                                //tc_strcpy(Rlzd_status,"T5_LcsStdpRlzd");

                        }
                        else if(tc_strcmp(Plant,"CVBUPNR")==0)
                        {
                                tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLU");
                    tc_strcpy(RevisionRName,"APLU Release and Above");
                                tc_strcpy(ClosureRNamed,"BOMViewClosureRuleSTDU");
                    tc_strcpy(RevisionRNamed,"STDU Released and Above");
                    tc_strcpy(ViewBVR,"View");
                                //tc_strcpy(Rlzd_status,"T5_LcsStduRlzd");

                        }
                        else
                        {
                                tc_strcpy(ClosureRName,"BOMViewClosureRuleERC");
                    tc_strcpy(RevisionRName,"ERC release and above");
                    tc_strcpy(ViewBVR,"View");
                                //tc_strcpy(Rlzd_status,"T5_LcsStdpRlzd");
                        }


            fprintf(GrpChildRelWSLog,"\nClosureRName = %s \n",ClosureRName);fflush(GrpChildRelWSLog);
                        fprintf(GrpChildRelWSLog,"\nRevisionRName = %s \n",RevisionRName);fflush(GrpChildRelWSLog);
            fprintf(GrpChildRelWSLog,"\nClosureRNamed = %s \n",ClosureRNamed);fflush(GrpChildRelWSLog);
                        fprintf(GrpChildRelWSLog,"\nRevisionRNamed = %s \n",RevisionRNamed);fflush(GrpChildRelWSLog);
                        fprintf(GrpChildRelWSLog,"\nRlzd_status = %s \n",Rlzd_status);fflush(GrpChildRelWSLog);

                tag_t   queryGrpPart    =       NULLTAG;
                tag_t   rev_tag = NULLTAG;
                tag_t*  result  =       NULLTAG;

                int RlzdStatusFlag = 0;
        int             n_entries       =       2;
                int StrctInt = 0;
                int Release_count = 0;
        int             l       =       2;
                int Tag_count = 0;
                int     num_to_sort =   1;
                int     orders[1]       =       {2};
                //int   orders[1]       =       {1};
                int             n_found=        0;
                char    *keys[1]        =       {"creation_date"};
                char    *qry_GrpPart_entries[2] = {"Item ID","Release Status"};
                //char  *qry_GrpPart_values[2] = {Grp_prt,"T5_LcsErcRlzd;T5_LcsAPLlWrkg;T5_LcsApllRlzd;T5_LcsAPLpWrkg;T5_LcsAplpRlzd;T5_LcsAPLuWrkg;T5_LcsApluRlzd;T5_LcsAPLjWrkg;T5_LcsApljRlzd;T5_LcsAPLdWrkg;T5_LcsApldRlzd;T5_LcsAPLsWrkg;T5_LcsAplsRlzd;T5_LcsStdsRlzd;T5_LcsSTDsWrkg;T5_LcsSTDjWrkg;T5_LcsStdjRlzd;T5_LcsSTDdWrkg;T5_LcsStddRlzd;T5_LcsSTDlWrkg;T5_LcsStdlRlzd;T5_LcsSTDuWrkg;T5_LcsStduRlzd;T5_LcsSTDpWrkg;T5_LcsStdpRlzd;T5_MBOMReleased;T5_MBOMWorking"};
                char    *qry_GrpPart_values[2] = {Grp_prt,"T5_LcsErcRlzd:T5_LcsAPLlWrkg:T5_LcsApllRlzd:T5_LcsAPLpWrkg:T5_LcsAplpRlzd:T5_LcsAPLuWrkg:T5_LcsApluRlzd:T5_LcsAPLjWrkg:T5_LcsApljRlzd:T5_LcsAPLdWrkg:T5_LcsApldRlzd:T5_LcsAPLsWrkg:T5_LcsAplsRlzd:T5_LcsStdsRlzd:T5_LcsSTDsWrkg:T5_LcsSTDjWrkg:T5_LcsStdjRlzd:T5_LcsSTDdWrkg:T5_LcsStddRlzd:T5_LcsSTDlWrkg:T5_LcsStdlRlzd:T5_LcsSTDuWrkg:T5_LcsStduRlzd:T5_LcsSTDpWrkg:T5_LcsStdpRlzd"};

                //char  *qry_GrpPart_values[2] = {Grp_prt,Rlzd_status};

                CALLAPI(QRY_find2("Item Revision...", &queryGrpPart));
                CALLAPI(QRY_execute_with_sort(queryGrpPart, n_entries, qry_GrpPart_entries, qry_GrpPart_values, num_to_sort, keys, orders, &Release_count, &result));



                fprintf(GrpChildRelWSLog,"\n 111 Number of Group part  [%s]found : [%d]\n",Grp_prt,Release_count);fflush(GrpChildRelWSLog);
                struct WSBomChildStrut ChldStrutPart[1000];
                struct ChldStruct ChldPrtList[10000];
                if(Release_count>0)
            {
                        for(Tag_count=0;Tag_count<Release_count;Tag_count++)
                        {

                                    fprintf(GrpChildRelWSLog,"\nTag_count : %d ",Tag_count);fflush(GrpChildRelWSLog);
                                        //fprintf(GrpChildRelWSLog,"\n Release_count of group part :%d \n",Release_count);fflush(GrpChildRelWSLog);
                                        rev_tag = result[Tag_count];
                                        //CALLAPI(ITEM_ask_latest_rev(rev_tag,&itemRev_tag));
                                        CALLAPI(AOM_ask_value_string(rev_tag,"item_id",&itemId));
                                        fprintf(GrpChildRelWSLog,"\nitemRev_tag : %s ",itemId);fflush(GrpChildRelWSLog);

                                        CALLAPI(AOM_ask_value_string(rev_tag,"item_revision_id",&partRev));
                                        fprintf(GrpChildRelWSLog,"\n partRev : %s ",partRev);fflush(GrpChildRelWSLog);

                                        CALLAPI(AOM_UIF_ask_value(rev_tag, "owning_group", &owning_group));
                                        fprintf(GrpChildRelWSLog,"\n\n\t\t owning_group  is :%s",owning_group); fflush(GrpChildRelWSLog);

                                        CALLAPI(AOM_UIF_ask_value(rev_tag, "owning_user", &Owner));
                                        fprintf(GrpChildRelWSLog,"\n\n\t\t Owner  is :%s",Owner);       fflush(GrpChildRelWSLog);


                                        //int j = 0;
                                        int k = 0;
                                        int Length = 0;
                                        int PartLength = 0;

                                        int Travcnt = 0;
                                        //char *itemId = NULL;
                                        char *PartNumber = NULL;

                                        //struct WSBomChildStrut ChldStrutPart[1000];
                                        //if((tc_strstr(owning_group,"ERC") != NULL) || (tc_strcmp(owning_group,"dba")==0 && tc_strstr(Owner,"loader")!=NULL))
					if((tc_strstr(Release_status,"ERC_RELEASED") != NULL))
                                        {
                                                fprintf(GrpChildRelWSLog,"\nInside ERC Before StructChldCnt = %d \n",StructChldCnt);fflush(GrpChildRelWSLog);
                                                ITKCALL(tm_EBOM_MBOM_Get_Part_BOM_Lvl(rev_tag,reqlevel,"BOMViewClosureRuleERC","ERC release and above",ViewBVR,ChldStrutPart,&StructChldCnt));
                                                fprintf(GrpChildRelWSLog,"\nInside ERC After StructChldCnt = %d \n",StructChldCnt);fflush(GrpChildRelWSLog);
                                        }
                                        //else if((tc_strstr(owning_group,"APL") != NULL)|| (tc_strcmp(owning_group,"dba")==0 && tc_strstr(Owner,"aplloader")!=NULL))
					else if((tc_strstr(Release_status,"STD_RELEASED") != NULL))
                                        {
                                                fprintf(GrpChildRelWSLog,"\nInside APL Before StructChldCnt = %d \n",StructChldCnt);fflush(GrpChildRelWSLog);
                                                ITKCALL(tm_EBOM_MBOM_Get_Part_BOM_Lvl(rev_tag,reqlevel,ClosureRName,RevisionRName,ViewBVR,ChldStrutPart,&StructChldCnt));
                                                fprintf(GrpChildRelWSLog,"\nInside APL After StructChldCnt = %d \n",StructChldCnt);fflush(GrpChildRelWSLog);
                                        }
                                        else
                                        {
                                                fprintf(GrpChildRelWSLog,"\n Invalid Owning Group \n");fflush(GrpChildRelWSLog);
                                        }
                                        // fprintf(GrpChildRelWSLog,"\nBefore StructChldCnt = %d \n",StructChldCnt);fflush(GrpChildRelWSLog);
                                        // ITKCALL(tm_EBOM_MBOM_Get_Part_BOM_Lvl(rev_tag,reqlevel,ClosureRName,RevisionRName,ViewBVR,ChldStrutPart,&StructChldCnt));
                                        // fprintf(GrpChildRelWSLog,"\nAfter StructChldCnt = %d \n",StructChldCnt);fflush(GrpChildRelWSLog);


                                        int partCnt=0;
                                        if(StructChldCnt>0)
                                        {
                                                flag = 1;

                                        }
                                        fprintf(GrpChildRelWSLog,"\nflag : %d\n",flag);fflush(GrpChildRelWSLog);

                        }
                        fprintf(GrpChildRelWSLog,"\nflag : %d\n",flag);fflush(GrpChildRelWSLog);
                        if(flag>0)
                        {
                                childcnt = 0;
                                aString_test->__size = StructChldCnt  ;
                                aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );
                                for(childcnt=0;childcnt<StructChldCnt;childcnt++) //for(childcnt=0;childcnt<=partCnt;childcnt++)
                                {

                                        aString_test->__ptrPrt[childcnt].prt_no = malloc(StructChldCnt* sizeof(char*)+5);

                                        fprintf(GrpChildRelWSLog,"\nchild Parts : %s \n",ChldStrutPart[childcnt+1].PartNo);fflush(GrpChildRelWSLog);
                                        tc_strcpy(aString_test->__ptrPrt[childcnt].prt_no,ChldStrutPart[childcnt+1].PartNo);
                                        fprintf(GrpChildRelWSLog,"\n WS child Parts : %s \n",aString_test->__ptrPrt[childcnt].prt_no);fflush(GrpChildRelWSLog);
                                }

                        }
                        else
                        {
                                StrctInt = StrctInt + 1;
                                aString_test->__size = StrctInt;
                                aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );

                                aString_test->__ptrPrt[i].prt_no = malloc(StrctInt* sizeof(char*)+5);
                                fprintf(GrpChildRelWSLog,"\nChild Parts Not found\n");fflush(GrpChildRelWSLog);
                                //tc_strcpy(ChldPrtList[i].child_parts,"NA");
                                //tc_strcpy(aString_test->__ptrPrt[i].prt_no,ChldPrtList[i].child_parts);
                                //tc_strcpy(ChldStrutPart[1].PartNo,"NA");
                                tc_strcpy(aString_test->__ptrPrt[i].prt_no,"NA");
                                fprintf(GrpChildRelWSLog,"\n In side else Response : %s \n",aString_test->__ptrPrt[i].prt_no);fflush(GrpChildRelWSLog);

                        }


                }
                if((Release_count==0)||(StructChldCnt==0))
            {

                        fprintf(GrpChildRelWSLog,"\n Group Part not found in TCUA , then check in TCE : %d\n",flag);fflush(GrpChildRelWSLog);
                        char* Response = NULL;
                        Response=(char *)MEM_alloc(200);
                        tc_strcpy(Response,"");
                        tc_strcat(Response,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GrpChildRel/TCE_GrpChildRel.sh");
                        tc_strcat(Response," ");
                        tc_strcat(Response,Grp_prt);
                        tc_strcat(Response," ");
                        tc_strcat(Response,Plant);
                        system(Response);
                        fprintf(GrpChildRelWSLog,"\nResponse path : %s",Response);fflush(GrpChildRelWSLog);


            inputfile = (char *)MEM_alloc(500);
                        tc_strcpy(inputfile,"");
                        tc_strcat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GrpChildRel/");
                        tc_strcat(inputfile,Grp_prt);
                        tc_strcat(inputfile,Plant);
                        tc_strcat(inputfile,"_TCEGrpChildRelWS.txt");
                        fprintf(GrpChildRelWSLog,"\n FIleNameSDup: [%s]\n",inputfile);  fflush(GrpChildRelWSLog);

//                          inputfile = (char *)MEM_alloc(500);
//                              tc_strcpy(inputfile,"");
//                              tc_strcat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GrpChildRel/");
//                              tc_strcat(inputfile,"/");
//                              tc_strcat(inputfile,Plant);
//                              tc_strcat(inputfile,"");
//                              tc_strcat(inputfile,".txt");
//                              fprintf(GrpChildRelWSLog,"\nFilename : %s",inputfile);fflush(GrpChildRelWSLog);

                                fp1=fopen(inputfile,"r");

                                if(fp1!=NULL)
                                {
                                        int partCnt=0;
                                        fprintf(GrpChildRelWSLog,"\n file not null : ");fflush(GrpChildRelWSLog);
                                        char *Response1 =NULL;
                                        //char **ResponseOP =NULL;
                                        //int partcnt=0;
                                        //ResponseOP=(char *)MEM_alloc(500);
                                        //tc_strcpy(ResponseOP,"");

                                        while (fgets(filewrite,1000,fp1)!=NULL )
                                        {
                                                //fputs(filewrite,inputfile);
                                                fprintf(GrpChildRelWSLog,"\n fgets open and fp1 not null :");fflush(GrpChildRelWSLog);
                                                fprintf(GrpChildRelWSLog,"\n filewrite %s  ",filewrite);fflush(GrpChildRelWSLog);
                                                fputs(inputfile,stdout);
                                Response1=NULL;
                                                Response1=tc_strtok(filewrite,",");

                                                fprintf(GrpChildRelWSLog,"\n Response1 is : %s",Response1);fflush(GrpChildRelWSLog);


                                    if(tc_strcmp(Response1,"")!=0)
                                    {
                                                        StructChldCnt++;
                                                        partCnt=StructChldCnt-1;
                                                        ChldPrtList[partCnt].child_parts = (char *) MEM_realloc((ChldPrtList[partCnt].child_parts),100* sizeof(char*));
                                                        fprintf(GrpChildRelWSLog,"\n StructChldCnt is : %d",StructChldCnt);fflush(GrpChildRelWSLog);
                                                        tc_strcpy(ChldPrtList[partCnt].child_parts,Response1);

                                                    fprintf(GrpChildRelWSLog,"\n ChldPrtList[partCnt].child_parts = %s \n",ChldPrtList[partCnt].child_parts);fflush(GrpChildRelWSLog);
                                    }

                                                //Response1 = (char *) MEM_realloc(Response1,100* sizeof(char*));


                                        }

                                        if(StructChldCnt>0)
                                    {
                                                        childcnt = 0;

                                        aString_test->__size = StructChldCnt  ;
                            aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );
                                            for(childcnt=0;childcnt<StructChldCnt;childcnt++)
                                        {
                                                                  ChldPrtList[childcnt].child_parts = (char *) MEM_realloc((ChldPrtList[childcnt].child_parts),100* sizeof(char*));
                                                      aString_test->__ptrPrt[childcnt].prt_no = malloc(StructChldCnt* sizeof(char*)+5);

                                                     // fprintf(GrpChildRelWSLog,"\nPartLength : %d \n",PartLength);fflush(GrpChildRelWSLog);
                                  fprintf(GrpChildRelWSLog,"\nchild Parts : %s \n",ChldPrtList[childcnt].child_parts);fflush(GrpChildRelWSLog);
                                  tc_strcpy(aString_test->__ptrPrt[childcnt].prt_no,ChldPrtList[childcnt].child_parts);
                                  fprintf(GrpChildRelWSLog,"\n WS child Parts : %s \n",aString_test->__ptrPrt[childcnt].prt_no);fflush(GrpChildRelWSLog);
                                             }
                                    }
                                        else
                                            {
                                                        strcount = strcount + 1;
                                            aString_test->__size = strcount;
                                            aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );
                                                    tc_strcpy(aString_test->__ptrPrt[p].prt_no,"NA");
                                                    fprintf(GrpChildRelWSLog,"\n Response is : %s",aString_test->__ptrPrt[p].prt_no);fflush(GrpChildRelWSLog);
                                        }

                                }
                                fclose(fp1);

                }


        fclose(GrpChildRelWSLog);
        fflush(stdout);

        dup2(fd, fileno(stdout));
        close(fd);
        clearerr(stdout);
        fsetpos(stdout, &pos);


        return SOAP_OK;


};

extern int ITK_user_main(int argc, char *argv[])
{
        return soap_serve(soap_new()); /* call the request dispatcher */

};
