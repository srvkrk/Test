//gsoap ns service name:			ByPsCntrlObj
//gsoap ns service style:			rpc
//gsoap ns service namespace:		urn:ByPsCntrlObj  
//gsoap ns service location:			http://172.22.97.8:9010/cgi/ByPsCntrlObj.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:		urn:ByPsCntrlObj 
//gsoap ns service method-documentation: Tests the Simple Web service
int ns__creByPsCntrlObj(char *plant,char *tasknumber, char **Response);