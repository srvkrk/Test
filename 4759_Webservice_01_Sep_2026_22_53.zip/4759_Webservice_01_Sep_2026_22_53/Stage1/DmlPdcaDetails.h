//gsoap ns service name:				 DmlPdcaDetails
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:DmlPdcaDetails
//gsoap ns service location:			 http://172.25.184.156:8080/cgi/DmlPdcaDetails.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:DmlPdcaDetails
//gsoap ns service method-documentation: Tests the Simple Web service


struct ns__ItemDet
{
   char *DML_NO;
   char *DESIGN_GRP;
   char *DML_DESC;
   char *DML_PRJCODE;
   char *DML_BU;
   char *DML_CRE;
   char *DML_CREDATE;
   char *DML_REASON;
}
;
struct ns__CharArray1
{
   struct ns__ItemDet *__ptrItem;
   int __size;
}
;

int ns__getItemData(char *Item,struct ns__CharArray1 *aString_test);


