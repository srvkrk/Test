#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]); fflush ( stdout ) ;
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line); fflush ( stdout ) ;
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}



char* Create_Rfi_SOR_ProNext_Frm_WS(char *RfiSor_number,char *RfiSor_desc,char *RevisionR,char *PPPM_Pcode,char *BunitR,char *Design_group,char *GPart_Name,char *Cat,char *Sor_creater,char *Sor_lifrcycle,char *Owner,char *Sor_Vcreater,char *Sor_CDate);
;
/*
int main(int argc, char *argv[])
{

	int stat=0;
    int iii=0;
    int i=0;
    int ji=0;
	int t=0;
	char c1 = ",";
	char c2 = " ";
	char *Cre_Date = NULL;
	string			LoginS             =  "super user" ;
    string			PasswordS          =  "abc123" ;
	string          filename           = NULL;
	string			TempCatS		   = NULL;
	string			docobjst		   = NULL;
	string			Commodity		   = NULL;
	string			DescriptionDup	   = NULL;
	string			Description		   = NULL;
	string			Part_Desc		   = NULL;
	string			LifeCycleDup	   = NULL;
	string			LifeCycle		   = NULL;
	string			QtyDUP		       = NULL;
	string			Qty		           = NULL;
	string			RFISorNub		   = NULL;
	string			SORNo		       = NULL;
	string			SORNoDup		   = NULL;
	string			CommodityDup	   = NULL;
	string			RFIDecDUP		   = NULL;
	string			RFIDec		       = NULL;
	string			RFISORNumDup	   = NULL;
	string			RFISORNum	       = NULL;
	string			RFISORRevDup	   = NULL;
	string			RFISORRev	       = NULL;
	string			RFISORPPPMDup	       = NULL;
	string			RFISORPPPM	       = NULL;
	string			RFISORBUDup	       = NULL;
	string			RFISORBU	       = NULL;
	string			RFISORDesignGDup   = NULL;
	string			RFISORDesignG	   = NULL;
	string			RFISORGprtDup	   = NULL;
	string			RFISORGprt	       = NULL;
	string			RFISORCatDup	   = NULL;
	string			RFISORCat	       = NULL;
	string			RFISOROwnerDup	   = NULL;
	string			RFISOROwner	       = NULL;
	string			RFISORLCSDup	   = NULL;
	string			RFISORLCS	       = NULL;
	string			RFISORVcrDup	   = NULL;
	string			RFISORVcr	       = NULL;
	string			RFISORCrdDup	   = NULL;
	string			RFISORCrd	       = NULL;
	string          pppmCode           = NULL;
	string          pppmCodeDsc        = NULL;
	string          RFISORRelDateDup   = NULL;
	string          RFISORRelDate      = NULL;
	SetOfObjects    SORObj		       = NULL;
    ObjectPtr		SORObjOp	       = NULL;
    SqlPtr			sql			       = NULL;
    string          OriUser2Dup        = NULL;
	string          OriUser2           = NULL;
	SetOfStrings	dbScp	           = setCreate(1);
	SetOfStrings	dbScopeBkp1	       = setCreate(1);
	string          year               = NULL;
	string          month              = NULL;
	string          day                = NULL;
	string          CreationDate       = NULL;

	year = nlsStrAlloc ( 10 ) ;
	month = nlsStrAlloc ( 10 ) ;
	day = nlsStrAlloc ( 10 ) ;
	CreationDate = nlsStrAlloc ( 20 ) ;

	t5MethodInitWMD("CCRFIPLMtoProNext.c");

	//INPUT ARGU ITEM......... 

  	LoginS		       =nlsStrAlloc(20);
	TempCatS	       =nlsStrAlloc(2000);
	filename	       =nlsStrAlloc(2000);
	PasswordS	       =nlsStrAlloc(20);
	RFISorNub          =nlsStrAlloc(2000);


    RFISorNub  =argv[1];
	printf("\n Arg1:[%s]",RFISorNub);

	printf("\n !!!!!!!!!!!!Starting here!!!!!!!! \n");
	t5CheckDstat(clInitMB2(argc,&argv,NULL));
	t5CheckDstat(clTestNetwork ());
	t5CheckDstat(clInitialize2 (FALSE));
	t5CheckDstat(clLogin2(LoginS,PasswordS,&stat));
	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s, %s \n", LoginS,PasswordS);
		goto EXIT;
	}
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScopeBkp1,mfail));
	for (ji=0;ji<setSize(dbScopeBkp1) ; ji++)
	{
		docobjst=low_set_get(dbScopeBkp1,ji);
		printf("\nDB pref check before... :%s\n",docobjst);fflush(stdout);
	}
	low_set_add_str(dbScp, "suhprod");
	low_set_add_str(dbScp, "supprod");
	low_set_add_str(dbScp, "sujprod");
	low_set_add_str(dbScp, "sulprod");
	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	{
		for (i=0;i<setSize(dbScp) ; i++)
		{
			docobjst=low_set_get(dbScp,i);
			printf("\n PP:DB pref set... :%s\n",docobjst);fflush(stdout);
		}
	}

	if (dstat = smGetSessionUsrName(&OriUser2Dup)) goto CLEANUP;
	if(!nlsIsStrNull(OriUser2Dup))		OriUser2 = nlsStrDup(OriUser2Dup);
	printf("\n P:RPT: smGetSessionUsrName OriUser2: [%s]",OriUser2);fflush(stdout);




	if(dstat = (oiSqlCreateSelect(&sql))) goto CLEANUP;
	if(dstat = (oiSqlWhereBegParen(sql)))  goto CLEANUP;
	if(dstat = (oiSqlWhereEQ(sql, "t5RfiSORNum", RFISorNub))) goto CLEANUP;
	//if(dstat = oiSqlWhereAND(sql)) goto CLEANUP;
	//if(dstat = (oiSqlWhereEQ(sql, OwnerNameAttr, "Release Vault"))) goto CLEANUP;
	if(dstat = oiSqlDescOrder(sql,"CreationDate")) goto EXIT;
	if(dstat = (oiSqlWhereEndParen(sql))) goto CLEANUP;
	if(dstat = (QueryDbObject("t5RfiSor", sql, 0 ,TRUE,  SC_SCOPE_OF_SESSION,  &SORObj,  &mfail)))  goto CLEANUP;
	printf("\n RFI SOR Found =%d\n",setSize(SORObj));fflush(stdout);

	if(setSize(SORObj)>0)
	{
			SORObjOp=setGet(SORObj,0);
			
			if(dstat = objGetAttribute(SORObjOp,"t5RfiDesc",&RFIDecDUP))  goto CLEANUP;   
			if(!nlsIsStrNull(RFIDecDUP))  RFIDec = nlsStrDup(RFIDecDUP);
            printf("\n ##::RFI Desc    : %s",RFIDec);fflush(stdout);	

	        if(dstat = objGetAttribute(SORObjOp,"t5RfiSORNum",&RFISORNumDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORNumDup))  RFISORNum = nlsStrDup(RFISORNumDup);
            printf("\n ##::RFI SOR NO  : %s",RFISORNum);fflush(stdout);
			
			if(dstat = objGetAttribute(SORObjOp,"Revision",&RFISORRevDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORRevDup))  RFISORRev = nlsStrDup(RFISORRevDup);
            printf("\n ##::RFI SOR Rev : %s",RFISORRev);fflush(stdout);

			if(dstat = objGetAttribute(SORObjOp,"t5RfiPPPMPrjCode",&RFISORPPPMDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORPPPMDup))  RFISORPPPM = nlsStrDup(RFISORPPPMDup);
            printf("\n ##::PPPM Code   : %s",RFISORPPPM);fflush(stdout);

			if ( nlsStrStr ( RFISORPPPM, "$$" ) != NULL )
		    {
		    	pppmCode = strtok(RFISORPPPM, "$$");
		    	pppmCodeDsc = strtok(NULL, "$$");
		    }
		    else
		    {
		    	pppmCode = nlsStrAlloc ( 100 ) ;
		    	pppmCodeDsc = nlsStrAlloc ( 100 ) ;
		    	nlsStrCpy ( pppmCode, RFISORPPPM ) ;
		    	nlsStrCpy ( pppmCodeDsc, "" ) ;
		    }

			if(dstat = objGetAttribute(SORObjOp,"t5RfiBusUnit",&RFISORBUDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORBUDup))  RFISORBU = nlsStrDup(RFISORBUDup);
            printf("\n ##::Busines Unit: %s",RFISORBU);fflush(stdout);

			if(dstat = objGetAttribute(SORObjOp,"t5DesignGroup",&RFISORDesignGDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORDesignGDup))  RFISORDesignG = nlsStrDup(RFISORDesignGDup);
            printf("\n ##::Design Group: %s",RFISORDesignG);fflush(stdout);
           
			if(dstat = objGetAttribute(SORObjOp,"t5GenPartName",&RFISORGprtDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORGprtDup))  RFISORGprt = nlsStrDup(RFISORGprtDup);
            printf("\n ##::GenPartName : %s",RFISORGprt);fflush(stdout);
			
			if(dstat = objGetAttribute(SORObjOp,"t5RfiCat",&RFISORCatDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORCatDup))  RFISORCat = nlsStrDup(RFISORCatDup);
            printf("\n ##::Category    : %s",RFISORCat);fflush(stdout);

			if(dstat = objGetAttribute(SORObjOp,"OwnerName",&RFISOROwnerDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISOROwnerDup))  RFISOROwner = nlsStrDup(RFISOROwnerDup);
            printf("\n ##::Owner Name  : %s",RFISOROwner);fflush(stdout);
 
			if(dstat = objGetAttribute(SORObjOp,"LifeCycleState",&RFISORLCSDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORLCSDup))  RFISORLCS = nlsStrDup(RFISORLCSDup);
            printf("\n ##::Life Cycle  : %s",RFISORLCS);fflush(stdout);

			if(dstat = objGetAttribute(SORObjOp,"t5VerCreator",&RFISORVcrDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORVcrDup))  RFISORVcr = nlsStrDup(RFISORVcrDup);
            printf("\n ##::Ver Creator : %s",RFISORVcr);fflush(stdout);

			if(dstat = objGetAttribute(SORObjOp,"CreationDate",&RFISORCrdDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORCrdDup))  RFISORCrd = nlsStrDup(RFISORCrdDup);
			Cre_Date = strtok(RFISORCrdDup,"-");
			printf("\n ##::Date Created: %s",Cre_Date);fflush(stdout);

			//2023/03/15
            //03/15/2023
            if ( nlsStrStr ( Cre_Date, "/" ) != NULL )
		    {
		    	year = strtok(Cre_Date, "/");
		    	month = strtok(NULL, "/");
		    	day = strtok(NULL, "/");
				
                nlsStrCpy(CreationDate,month);
                nlsStrCat(CreationDate,"/");
                nlsStrCat(CreationDate,day);
                nlsStrCat(CreationDate,"/");
                nlsStrCat(CreationDate,year);

		    }

		    	


			printf("\n #######################################::Date Created: %s",CreationDate);fflush(stdout);


			if(dstat = objGetAttribute(SORObjOp,"ActualRelDate",&RFISORRelDateDup))  goto CLEANUP;   
			if(!nlsIsStrNull(RFISORRelDateDup))  RFISORRelDate = nlsStrDup(RFISORRelDateDup);
            printf("\n ##::APL Rel Date : %s",RFISORRelDate);fflush(stdout);

			Create_Rfi_SOR_ProNext_Frm_WS(RFISORNum,RFIDec,RFISORRev,pppmCode,RFISORBU,RFISORDesignG,RFISORGprt,RFISORCat,RFISOROwner,RFISORLCS,RFISOROwner,RFISORVcr,CreationDate);
			//Create_Rfi_SOR_ProNext_Frm_WS(RFISORNum,RFIDec,RFISORRev,pppmCode,RFISORBU,RFISORDesignG,RFISORGprt,RFISORCat,RFISOROwner,RFISORLCS,RFISOROwner,RFISORVcr,"03/15/2023");


    } 
	else
	{
	 printf("\n		~~~~~~~~~~~~~~~  RFI SOR NOT FOUND !!!   ~~~~~~~~~~~~~~~~~~~~ \n ");fflush(stdout);
	}

		//fclose(fp);										
		if(dstat = smSetSessionDbScope(dbScopeBkp1)) goto CLEANUP;
		printf("\n		~~~~~~~~~~~~~~~  REPORT GENERATION COMPLETE !!!   ~~~~~~~~~~~~~~~~~~~~ \n ");fflush(stdout);
		printf("\n		~~~~~~~~  L I V E   L O N G   &   P R O S P E R    ~~~~~~~~~~~~~~ \n\n ");fflush(stdout);

CLEANUP :

       // t5FreeSetOfObjects(AllTmlStdSetObjs);
	   if (TempCatS) t5FreeString(TempCatS);

EXIT:
        if (dstat != OKAY) dlow_return_trace(mod_name, dstat);
         return (dstat);
}*/

void list_displayable_properties_with_value(tag_t object)
{
    logical
        is_displayable = TRUE;
    int
        n_props = 0,
        ii = 0;
    char
        **prop_names = NULL,
        *disp_name = NULL,
        *value = NULL;

    ECHO("\n\n%-31s %-37s %s \n", "Real Name", "Display Name", "Value");
    ECHO("%-31s %-37s %s \n", "==============", "=============", "=============");

    ITK_CALL( AOM_ask_prop_names(object, &n_props, &prop_names) );
    for( ii = 0; ii < n_props; ii++)
    {
        ITK_CALL( AOM_UIF_is_displayable(object, prop_names[ii],
            &is_displayable));
        if (is_displayable == TRUE)
        {
            value = NULL;
            ITK_CALL( AOM_UIF_ask_name(object, prop_names[ii], &disp_name) );
            ITK_CALL( AOM_UIF_ask_value(object, prop_names[ii], &value) );
            if ( (value != NULL) && (strlen(value) > 0 ) )
            {
                if (strlen(value) == 1 )
                {
                    if ( strcmp(value, " ") != 0 )
                        printf("%-31s %-37s %s \n", prop_names[ii], disp_name, value );
                }
                else
                printf( "%-31s %-37s %s \n", prop_names[ii], disp_name, value );
            }
        }
    }
    if (prop_names != NULL) MEM_free(prop_names);
    if (disp_name != NULL) MEM_free(disp_name);
    if (value != NULL) MEM_free(value);
}

int transfer_RFI_Sor_to_pronext( char* rfi_sor_no)
{
	int status = ITK_ok;
	int iCntr = 0;
	int n_items = 0;
	tag_t *item_tags = NULLTAG;
	tag_t item = NULLTAG;
	char *item_type = NULL ;
	int	rev_count = 0 ;
	tag_t *rev_list = NULLTAG;

	
	tag_t query = NULLTAG;
	char *release_status_list = NULL;
	char *tbl_row_entries[3] = { (char *)"Item ID", (char *)"Type", (char *)"Release Status" } ;
	char** tbl_row_values = NULL;
	
	int n_tbl_row_entries = 3;
	tag_t *result_tbl_row_objects = NULLTAG;
	
	int n_tbl_row_found = 0;

	int	num_to_sort = 1;
	char** keys = NULL;
	int	orders[] = { 2 };

	char *RFISORNum = NULL;
	char *RFIDec = NULL;
	char *RFISORRev = NULL;
	char *pppmCode = NULL;
	char *RFISORBU = NULL;
	char *RFISORDesignG = NULL;
	char *RFISORGprt = NULL;
	char *RFISORCat = NULL;
	char *RFISOROwner = NULL;
	char *RFISORLCS = NULL;
	char *RFISORVcr = NULL;
	char *RFISORcreator = NULL;
	date_t creation_dt;
	char *CreationDate = NULL;
	tag_t rev_tag = NULLTAG;
	date_t date_structure;
	char *CreationDate2 = NULL;


	keys = (char**)MEM_alloc(1 * sizeof(char*));
	keys[0] = (char*)MEM_alloc(100);
	tc_strcpy(keys[0], "creation_date");

	tbl_row_values = (char**)MEM_alloc(3 * sizeof(char*));
	
	tbl_row_values[0] = (char*)MEM_alloc(100);
	tbl_row_values[1] = (char*)MEM_alloc(100);
	tbl_row_values[2] = (char*)MEM_alloc(100);

	tbl_row_values[0] = rfi_sor_no;
	tbl_row_values[1] = "T5_RfiSorRevision";
	tbl_row_values[2] = "T5_LcsErcRlzd";


	ITK_CALL ( QRY_find2 ( "Item Revision...", &query ) ) ;
	QRY_execute_with_sort(query, n_tbl_row_entries, tbl_row_entries, tbl_row_values, num_to_sort, keys, orders, &n_tbl_row_found, &result_tbl_row_objects);

	printf("\nn_tbl_row_found : [%d]",n_tbl_row_found);

	if ( n_tbl_row_found > 0)
	{
		rev_tag =  result_tbl_row_objects[0] ;
		//list_displayable_properties_with_value(result_tbl_row_objects[0]);

		ITK_CALL ( AOM_UIF_ask_value ( rev_tag, "release_status_list", &release_status_list) ) ;
		printf("\nrelease_status_list : [%s]", release_status_list) ; fflush ( stdout ) ;

		if (tc_strstr(release_status_list, "ERC Released" ) != NULL )
		{
			RFISORLCS = MEM_alloc ( 100 ) ;
			RFISOROwner = MEM_alloc ( 100 ) ;
			tc_strcpy ( RFISORLCS, "ERC Released" ) ;
			tc_strcpy ( RFISOROwner, "Release Vault" ) ;
			
			//t5_RfiProjName
			//t5_RfiVerticle

			ITK_CALL ( AOM_ask_value_string ( rev_tag, "item_id", &RFISORNum) ) ;
			ITK_CALL ( AOM_ask_value_string ( rev_tag, "t5_RfiDesc", &RFIDec) ) ;
			ITK_CALL ( AOM_ask_value_string ( rev_tag, "item_revision_id", &RFISORRev) ) ;
			ITK_CALL ( AOM_ask_value_string ( rev_tag, "t5_RfiPPPMPrjCode", &pppmCode) ) ;
			ITK_CALL ( AOM_ask_value_string ( rev_tag, "t5_RfiBusUnit", &RFISORBU) ) ;
			ITK_CALL ( AOM_ask_value_string ( rev_tag, "t5_DesignGroup", &RFISORDesignG) ) ;
			ITK_CALL ( AOM_ask_value_string ( rev_tag, "t5_GenPartName", &RFISORGprt) ) ;
			ITK_CALL ( AOM_ask_value_string ( rev_tag, "t5_RfiCat", &RFISORCat) ) ;
			//ITK_CALL ( AOM_UIF_ask_value ( rev_tag, "owning_user", &RFISORVcr) ) ;

			tag_t Child_owning_user = NULLTAG;
			ITK_CALL ( AOM_ask_owner( rev_tag, &Child_owning_user ));
			ITK_CALL ( SA_ask_user_identifier2(Child_owning_user,&RFISORVcr));


			ITK_CALL ( AOM_ask_value_date ( rev_tag, "creation_date", &creation_dt) ) ;

			ITK_CALL ( ITK_date_to_string(creation_dt, &CreationDate ) );


			ITK_CALL ( DATE_date_to_string ( creation_dt, "%m/%d/%Y", &CreationDate2 ) ) ;


			printf ( "\nRFISORNum  : [%s]",RFISORNum );
			printf ( "\nRFIDec  : [%s]",RFIDec );
			printf ( "\nRFISORRev  : [%s]",RFISORRev );
			printf ( "\npppmCode  : [%s]",pppmCode );
			printf ( "\nRFISORBU  : [%s]",RFISORBU );
			printf ( "\nRFISORDesignG  : [%s]",RFISORDesignG );
			printf ( "\nRFISORGprt  : [%s]",RFISORGprt );
			printf ( "\nRFISORCat  : [%s]",RFISORCat );
			printf ( "\nRFISOROwner  : [%s]",RFISOROwner );
			printf ( "\nRFISORLCS  : [%s]",RFISORLCS );
			printf ( "\nRFISOROwner  : [%s]",RFISOROwner );
			printf ( "\nRFISORVcr  : [%s]",RFISORVcr );
			printf ( "\nCreationDate2  : [%s]",CreationDate2 );//correct date format


			Create_Rfi_SOR_ProNext_Frm_WS(RFISORNum,RFIDec,RFISORRev,pppmCode,RFISORBU,RFISORDesignG,RFISORGprt,RFISORCat,RFISOROwner,RFISORLCS,RFISOROwner,RFISORVcr,CreationDate2);
					
		}
		else
		{
			printf ( "\nRFI SOR not found ERC Released") ;
		}
	}
	else
	{
		printf ( "\nRFI SOR not found in TCUA") ;
	}
	return status;
}

extern int ITK_user_main(int argc, char ** argv )
{
    int status = ITK_ok;
	//char *sUserName = NULL;
	//char *sPassword = NULL;
	char *rfi_sor_no = NULL;
	
	ITK_CALL( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) );
	ITK_CALL( ITK_auto_login ( ) );
	ITK_CALL( ITK_set_journalling ( TRUE ) );
	
	//sUserName = ITK_ask_cli_argument("-u=");
	//sPassword = ITK_ask_cli_argument("-p=");
	rfi_sor_no = ITK_ask_cli_argument("-r=");
	
	transfer_RFI_Sor_to_pronext( rfi_sor_no );
	
	ITK_CALL(POM_logout(false));
	return status;

}