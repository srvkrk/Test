//gsoap ns service name:                          tm_NewMbomRlzdMonitoring
//gsoap ns service style:                          rpc
//gsoap ns service namespace:                    urn:tm_NewMbomRlzdMonitoring
//gsoap ns service location:                     http://172.22.97.28:8080/cgi/tm_NewMbomRlzdMonitoring.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:ProjectOrgID
//gsoap ns service method-documentation: Tests the Simple Web service



struct ns__plmStdDmlData
{
	char *Srl_Num;
	char *Dml_Num;
	char *Task_Num;
	char *Design_Grp;
	char *DrStatus;
	char *TaskStatus;
	char *ERCRelzDate;
	char *ProjectCode;
	char *MbomDesigner;
	char *MbomDsnerAssgndDate;
	char *MbomDsnerRelzdDate;
	char *MbomReviewdBy;
	char *MbomReviewerRlzDate;
	char *MbomManager;
	char *MbomManagerRlzDate;
	char *releasedMbomAssmlyNo;
	char *Dml_Desc;

}
;
struct ns__CharArray1
{
	struct ns__plmStdDmlData *__ptrRlzDmlData;
	int __size;
}
;

int ns__getStddmlfsullDataInfo(char *StrDateInp, struct ns__CharArray1 *aString_Ret);