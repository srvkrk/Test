./compile RFIPLMtoProNextCC.c
./linkitk -o RFIPLMtoProNextCC RFIPLMtoProNextCC.o RFIPLMtoProNext.a 

