#define _CLMAIN_DEFNS
#include <cl.h>
#include <ft.h>
#include <malloc.h>
#include <mserv.h>
#include <msgapc.h>
#include <msglcm.h>
#include <msgomf.h>
#include <msgtel.h>
#include <nls.h>
#include <oi.h>
#include <pdmc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <sc.h>
#include <semaphore.h>
#include <serv.h>
#include <status.h>
#include <stdlib.h>
#include <string.h>
#include <tel.h>
#include <ui.h>
#include <usc.h>
#include "soapH.h"
#include "AmDMLCreationWebSvr.nsmap"

char* subString(char* mainStringf,  int fromCharf,  int toCharf)
{
        int substr1;
        char *retStringf;
        retStringf =  (char*) malloc(toCharf + 1);
        for(substr1 = 0; substr1 < toCharf; substr1++ )
                *(retStringf + substr1) =  *(mainStringf + substr1 + fromCharf);
        *(retStringf + substr1) =  '\0';
        return retStringf;
}
;

status t0UpdateObject1(ObjectPtr *itemObj,integer *mfail)
{
        char            *mod_name       =   "t0UpdateObject1";
        status          dstat           =   OKAY;
        string          SclsName        =   NULL;
        string          SclsNameDup        =   NULL;
        string          SframeName      =   NULL;
	string          SframeNameDup      =   NULL;

		//printf("\n .... inside t0UpdateObject ...  updating object ... \n"); fflush(stdout);
	if ( dstat = objGetAttribute(*itemObj,ClassAttr,&SclsName)) 
	    goto CLEANUP;
	SclsNameDup=nlsStrDup(SclsName);
	//printf("\n .... inside t0UpdateObject ...updating object ..SclsName=%s...1111\n",SclsName); fflush(stdout);
        if (dstat = BeginDbFrame(SclsName,&SframeName,mfail))
            goto CLEANUP;
        if (*mfail) 
	    goto CLEANUP;
	SframeNameDup=nlsStrDup(SframeName);
	//printf("\n .... inside t0UpdateObject ...  updating object ...SframeName=%s...222\n",SframeName); fflush(stdout);
        //objDump(*itemObj); fflush(stdout);
        if (dstat = UpdateDbObject(*itemObj,mfail))
            goto CLEANUP;
        //printf("\nAfter UpdateDbObject ....33333.\n");fflush(stdout);

        if (*mfail != 0)
        {
		//printf("\n .... inside t0UpdateObject ...  updating object ...4444444444 \n"); fflush(stdout);
            if (dstat = ClearDbFrame(SclsNameDup,SframeNameDup,mfail))
				goto CLEANUP;
            goto CLEANUP;
        }
	//printf("\n .... inside t0UpdateObject ...  updating object ... 555555555\n"); fflush(stdout);
	//printf("\nParameters to End DB Frame are:[%s],[%s]",SclsNameDup,SframeNameDup);
        if (dstat = EndDbFrame(SclsNameDup,SframeNameDup,mfail))
            goto CLEANUP;
        if (*mfail) 
			goto CLEANUP;

CLEANUP:
		//printf("\n.... in cleanup t0UpdateObject ...."); fflush(stdout);
    t5PrintCleanUpModName;
		
EXIT:
    if (dstat != OKAY) dlow_return_trace(mod_name, dstat);

    return (dstat);
}
;

int main(int argc, char *argv[])
{
	t5MethodInitWMD("AmDMLCreationWebSvr.c");
	dstat = clInitMB2 (argc,&argv,NULL);
	return soap_serve(soap_new()); /* call the request dispatcher */

}
;

status getUsrDetailsAPL(string	*usrDept,string	*usrLocation,string	*usrAgency,integer* mfail)
{
	SqlPtr a_sql = NULL;
	char* user = NULL;
	char* Dept = NULL;
	char* dupDesDept = NULL;
	char* Location = NULL;
	char* Agency = NULL;
	SetOfObjects UsrSet = NULL;
	ObjectPtr CurrentUsr = NULL;

	char *mod_name = "getUsrDetailsAPL";
	status dstat = OKAY;
	*mfail = USC_OKAY;
	Dept		 = nlsStrAlloc(10);
	if (dstat = smGetSessionUsrName(&user)) goto EXIT;
	//printf(" In  side getUsrDetails  %s \n" ,user );
	fflush(stdout);
	// Getting user Data.
	if(dstat = oiSqlCreateSelect(&a_sql)) goto EXIT;
	if(dstat = oiSqlWhereEQValue(a_sql,ParticipantAttr,user)) goto EXIT;
	if(dstat = QueryWhere(UsrClass,a_sql,&UsrSet,mfail)) goto EXIT;
	if ((dstat = oiSqlCreateSelect(&a_sql)) ||
	(dstat = oiSqlWhereEQValue(a_sql,ParticipantAttr,user)) ||
	(dstat = QueryWhere(UsrClass,a_sql,&UsrSet,mfail))
	)goto EXIT;
	if (*mfail) goto CLEANUP;

	CurrentUsr = (ObjectPtr) low_set_get(UsrSet,0);
	// Getting Various Values For Current User.
	if (dstat = objGetAttribute(CurrentUsr,DeptAttr,&Dept)) goto EXIT;
	if (dstat = objGetAttribute(CurrentUsr,t5UsrLocationAttr,&Location)) goto EXIT;
	if (dstat = objGetAttribute(CurrentUsr,DeptAttr,&Agency)) goto EXIT;

	dupDesDept = nlsStrDup(Dept);

	// Copying User Department
	if (!nlsIsStrNull(Dept)) nlsStrCpy(*usrDept,dupDesDept);
	else nlsStrCpy(*usrDept,"");

	// If usrLocation is not null then set this as location else set as TMLPUN.
	if (!nlsIsStrNull(Location)) nlsStrCpy(*usrLocation,Location);
	else  nlsStrCpy(*usrLocation,"");

	// If user Agency is null then taking Default as ERC
	if (!nlsIsStrNull(Agency)) nlsStrCpy(*usrAgency,Agency);
	else nlsStrCpy(*usrAgency,"ERC");

	//printf("End of getUsrDetails Location= %s \n Dept= %s Agency = %s \n\n",usrLocation,usrDept,usrAgency);
	//fflush(stdout);
CLEANUP:
	// Disposing User class object Set
//	if (UsrSet != NULL)
//	t5FreeSetOfObjects(UsrSet);

EXIT:
	if (dstat != OKAY)
	uiShowFatalError(dstat, WHERE);
	return (dstat);
}
;
status	getUserLocationbasedonDML(string sPlant, string	*sUserLocation, FILE	*createamdml,int *mfail)
{
	//char *mod_name = "getUserLocationbasedonDML";
	//integer mfail = USC_OKAY;
	//status	dstat = OKAY;
	
	t5MethodInit("AttachedErrFileToTask");
    *mfail 		= USC_OKAY;

	//printf("\nPlant : %s",sPlant);fflush(stdout);
	fprintf(createamdml,"\nPlant : %s",sPlant);fflush(createamdml);
	
	*sUserLocation	=	NULL;
	*sUserLocation	=	nlsStrAlloc(10);
	//if (nlsStrCmp(sPlant,"APLCAR")==0)
	if (nlsStrStr(sPlant,"APLC"))
	{
		nlsStrCpy(*sUserLocation,"CARPLT");
		fprintf(createamdml,"\nPlant1 : %s",sPlant);fflush(createamdml);
	}
	else if (nlsStrStr(sPlant,"APLP")) 
	{
		nlsStrCpy(*sUserLocation,"PCVBU");
		fprintf(createamdml,"\nPlant2 : %s",sPlant);fflush(createamdml);
	}
	else if (nlsStrStr(sPlant,"APLJ")) 
	{
		nlsStrCpy(*sUserLocation,"JSR");
		fprintf(createamdml,"\nPlant3 : %s",sPlant);fflush(createamdml);
	}
	else if (nlsStrStr(sPlant,"APLL")) 
	{
		nlsStrCpy(*sUserLocation,"LKO");
		fprintf(createamdml,"\nPlant44 : %s",sPlant);fflush(createamdml);
	}
	else if (nlsStrStr(sPlant,"APLD")) 
	{
		nlsStrCpy(*sUserLocation,"DWD");
		fprintf(createamdml,"\nPlant5 : %s",sPlant);fflush(createamdml);
	}
	else if (nlsStrStr(sPlant,"APLU")) 
	{
		nlsStrCpy(*sUserLocation,"PNR");
		fprintf(createamdml,"\nPlant6 : %s",sPlant);fflush(createamdml);
	}
	else if (nlsStrStr(sPlant,"APLS")) 
	{
		nlsStrCpy(*sUserLocation,"AHD");
		fprintf(createamdml,"\nPlant7 : %s",sPlant);fflush(createamdml);
	}
	else
	{
		nlsStrCpy(*sUserLocation,"CARPLT");
		fprintf(createamdml,"\nPlant8 : %s",sPlant);fflush(createamdml);
	}
	
	//printf("\nUser Location : %s",*sUserLocation);fflush(stdout);
	fprintf(createamdml,"\nUser Location : %s",*sUserLocation);fflush(createamdml);


	CLEANUP:
	//printf("\n Cleanup of getUserLocationbasedonDML\n");
	t5PrintCleanUpModName;

	EXIT:
    t5CheckDstatAndReturn;
	//printf("\n I am in EXIT getUserLocationbasedonDML............. \n");fflush(stdout);
}
;
//status AMDMLCreateFunc(string project,string sDesignGrp,string t5EcnType,string sUserLocation,FILE	*createamdml,ObjectPtr *AMDmlObj,integer* mfail)
//{
//	//char *mod_name = "AMDMLCreateFunc";
//	//integer mfail = USC_OKAY;
//	//status	dstat = OKAY;
//	t5MethodInit("AMDMLCreateFunc");
//    *mfail 		= USC_OKAY;
//
//	ObjectPtr DmlCreateDia				=	NULL;
//	ObjectPtr DmlObj					=	NULL;
//	ObjectPtr UsrObj					=	NULL;
//	ObjectPtr CntrlObj					=	NULL;
//	ObjectPtr CntrlObjUA				=	NULL;
//	ObjectPtr tskObj					=	NULL;
//	ObjectPtr dialogObj					=	NULL;
//
//	string			StrUsrAgn1			=	NULL;
//	string			StrUsrAgn1Dup		=	NULL;
//	string			StrUsrLoc1			=	NULL;
//	string			StrUsrLoc1Dup		=	NULL;
//	string			sTaskNum			=	NULL;
//	string			sTaskNumDup			=	NULL;
//	
//	SetOfStrings	extraStrECN			=	NULL;
//	SetOfObjects	extraObjECN			=	NULL;
//	SetOfObjects	UsrObjSet			=	NULL;
//	SetOfObjects	soCntrlObj			=	NULL;
//	SetOfObjects	soCntrlObjPrj		=	NULL;
//	SetOfObjects	soCntrlObjPrjUA		=	NULL;
//	SetOfObjects	brkTaskObjsTo		=	NULL;
//	SetOfObjects	extraObj			=	NULL;
//
//	SetOfStrings	DsgnGrpValue			= NULL;
//	SetOfStrings	extraStr				= NULL;
//
//	SqlPtr			Sql_ptr				=	NULL;
//	SqlPtr			sqlPtr				=	NULL;
//
//	//t5MethodInitWMD("AMDMLCreateFunc");
//
//	//printf("\nIn AMDMLCreateFunc : %s",DMLNameS); fflush(stdout);
//	
//	DsgnGrpValue	= setCreate(1);
//
//	low_set_add_str(DsgnGrpValue,sDesignGrp);
//
//    printf("\nBefore set attributes\n");	fflush(stdout);
//	//if (dstat = smSetSessionUsrName ("APLAna1")) goto EXIT;
//	if (dstat = smSetSessionUsrName ("APLAna2")) goto EXIT;
//	if(Sql_ptr) oiSqlDispose(Sql_ptr);sqlPtr = NULL;
//	if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
//	//if(dstat = oiSqlWhereEQ(Sql_ptr,ParticipantAttr, "APLAna1")) goto EXIT;
//	if(dstat = oiSqlWhereEQ(Sql_ptr,ParticipantAttr, "APLAna2")) goto EXIT;
//	//printf("\nQuery User...!!!");fflush(stdout);
//	fprintf(createamdml,"\nQuery User...!!!");fflush(createamdml);
//	//if(dstat = QueryDbObject(UsrClass, Sql_ptr, 1, TRUE, SC_SCOPE_OF_SESSION, &UsrObjSet, mfail)) goto EXIT;
//	if(dstat = QueryDbObject(UsrClass, Sql_ptr, 1, TRUE, SC_SCOPE_OF_SESSION, &UsrObjSet, mfail)) goto EXIT;
//	//oiSqlPrint(Sql_ptr);fflush(stdout);
//	//printf("\nQuery User... %d!!!",setSize(UsrObjSet));fflush(stdout);
//	fprintf(createamdml,"\nQuery User... %d!!!",setSize(UsrObjSet));fflush(createamdml);
//	//if (*mfail) goto CLEANUP;
//	if(setSize(UsrObjSet)>0)
//	{
//		UsrObj = setGet(UsrObjSet,0);
//
//		if(dstat=objGetAttribute(UsrObj, t5UsrLocationAttr, &StrUsrLoc1)) goto EXIT;
//		if (!nlsIsStrNull(StrUsrLoc1)) StrUsrLoc1Dup = nlsStrDup(StrUsrLoc1);
//
//		//printf("\n APLAna1 StrUsrLoc1Dup : [%s]", StrUsrLoc1Dup); fflush(stdout);
//		fprintf(createamdml,"\n APLAna1 StrUsrLoc1Dup : [%s]", StrUsrLoc1Dup); fflush(createamdml);
//
//		//if(nlsStrCmp(StrUsrLoc1Dup,"CARPLT")!=0)//Need to change Here...
//		if(nlsStrCmp(StrUsrLoc1Dup,sUserLocation)!=0)//Need to change Here...
//		{
//			//if(dstat=objSetAttribute(UsrObj,t5UsrLocationAttr,"CARPLT")) goto EXIT;
//			if(dstat=objSetAttribute(UsrObj,t5UsrLocationAttr,sUserLocation)) goto EXIT;
//			if (dstat = t0UpdateObject1(&UsrObj,mfail))goto EXIT;
//			printf("\n Location Updated\n");fflush(stdout);
//		}
//		//TZ 3.59
//
//		if(dstat=objGetAttribute(UsrObj, t5UsrAgencyAttr, &StrUsrAgn1)) goto EXIT;
//		if (!nlsIsStrNull(StrUsrAgn1)) StrUsrAgn1Dup = nlsStrDup(StrUsrAgn1);
//
//		//printf("\n APLAna1 StrUsrAgn1Dup : [%s]", StrUsrAgn1Dup); fflush(stdout);
//		fprintf(createamdml,"\n APLAna1 StrUsrAgn1Dup : [%s]", StrUsrAgn1Dup); fflush(createamdml);
//
//		if(nlsStrCmp(StrUsrAgn1Dup,"APL")!=0)
//		{
//			if(dstat=objSetAttribute(UsrObj,t5UsrAgencyAttr,"APL")) goto EXIT;
//			if (dstat = t0UpdateObject1(&UsrObj,mfail))goto EXIT;
//			//printf("\n Location Updated\n");fflush(stdout);
//			fprintf(createamdml,"\n Location Updated\n");fflush(createamdml);
//		}
//	}
//	//printf("\n Query Driver VC...!!!"); fflush(stdout);
//	fprintf(createamdml,"\n Query Driver VC...!!!"); fflush(createamdml);
//	if(sqlPtr) oiSqlDispose(sqlPtr); sqlPtr = NULL;
//	if (dstat = oiSqlCreateSelect(&sqlPtr)) goto CLEANUP;
//	if (dstat = oiSqlWhereEQ(sqlPtr,t5SyscdAttr,"APLVErr")) goto CLEANUP;
//	if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
//	if (dstat = oiSqlWhereEQ(sqlPtr,t5SubSyscdAttr,"SignOffErr")) goto CLEANUP;
//	if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
//	if (dstat = oiSqlWhereEQ(sqlPtr,t5Userinfo1Attr,"DriverVC")) goto CLEANUP;
//	if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
//	//if (dstat = oiSqlWhereEQ(sqlPtr,t5Userinfo2Attr,StrUsrLoc1Dup)) goto CLEANUP;
//	if (dstat = oiSqlWhereEQ(sqlPtr,t5Userinfo2Attr,sUserLocation)) goto CLEANUP;
//	if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
//	if (dstat = oiSqlWhereEQ(sqlPtr,t5Userinfo4Attr,"Live")) goto CLEANUP;
//	if (dstat = QueryDbObject(t5CntrolClass,sqlPtr,-1,FALSE,SC_SCOPE_OF_SESSION,&soCntrlObj,mfail)) goto CLEANUP;
//	if(sqlPtr) oiSqlDispose(sqlPtr); sqlPtr = NULL;
//
//	//printf("\n\n Driver VC Control Object count is %d\n",setSize(soCntrlObj)); fflush(stdout);
//	fprintf(createamdml,"\n\n Driver VC Control Object count is %d\n",setSize(soCntrlObj)); fflush(createamdml);
//	if(setSize(soCntrlObj)>0)
//	{
//		CntrlObj	= setGet(soCntrlObj,0);
//		if(dstat=objSetAttribute(setGet(soCntrlObj,0),t5Userinfo4Attr,"UALive")) goto CLEANUP;
//		t5CheckMfail(t0UpdateObject1(&CntrlObj,mfail));
//	}
//
//	if(dstat = SetUpDialog(CmChNtItClass, NULL, CreateDialogCAttr, &extraStrECN, &extraObjECN, &DmlCreateDia, mfail)) goto CLEANUP;
//	//if(*mfail) goto CLEANUP;
//
//	//printf("start setting \n");	fflush(stdout);
//
//	//Query the project if it is not not live then make it live
//	//commented for testing
//	string		sDltInd				=	NULL;
//	string		sDltIndDup			=	NULL;
//	int			iupdcntrl			=	0;
//	if(sqlPtr) oiSqlDispose(sqlPtr); sqlPtr = NULL;
//	if (dstat = oiSqlCreateSelect(&sqlPtr)) goto CLEANUP;
//	if (dstat = oiSqlWhereEQ(sqlPtr,t5SyscdAttr,"PlantDML")) goto CLEANUP;
//	if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
//	if (dstat = oiSqlWhereEQ(sqlPtr,t5SubSyscdAttr,project)) goto CLEANUP;
//	if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
//	if (dstat = oiSqlWhereEQ(sqlPtr,t5Userinfo1Attr,sUserLocation)) goto CLEANUP;
//	if (dstat = QueryDbObject(t5CntrolClass,sqlPtr,-1,FALSE,SC_SCOPE_OF_SESSION,&soCntrlObjPrj,mfail)) goto CLEANUP;
//	if(sqlPtr) oiSqlDispose(sqlPtr); sqlPtr = NULL;
//	
//	if (setSize(soCntrlObjPrj)>0)
//	{
//		CntrlObjUA	=	setGet(soCntrlObjPrj,0);	
//		if(dstat=objGetAttribute(CntrlObjUA,t5DelIndAttr,&sDltInd)) goto CLEANUP;
//		if (!nlsIsStrNull(sDltInd))
//		{
//			sDltIndDup	=	nlsStrDup(sDltInd);
//		}
//		fprintf(createamdml,"Delete Indicator %s\n",sDltIndDup);fflush(createamdml);
//
//		if (nlsStrCmp(sDltIndDup,"+")==0)
//		{
//			iupdcntrl++;
//			if(dstat=objSetAttribute(CntrlObjUA,t5DelIndAttr,"-")) goto CLEANUP;
//			if(dstat=t0UpdateObject1(&CntrlObjUA,mfail));
//		}
//	}
//
//	fprintf(createamdml,"start setting \n");	fflush(createamdml);
//
//	if (dstat = smSetSessionUsrName ("APLAna1")) goto EXIT;
//	//if(dstat=objSetAttribute(DmlCreateDia,WbsIDAttr,DMLNameS)) goto CLEANUP;
//	if(dstat=objSetAttribute(DmlCreateDia,"t5EcnType",t5EcnType)) goto CLEANUP;
//	if(dstat=objSetAttribute(DmlCreateDia,"ProjectName",project)) goto CLEANUP;
//	if(dstat=objSetAttribute(DmlCreateDia,"WbsName","SYSTEM GENERATED APL DML FOR TCUA")) goto CLEANUP;
//	if(dstat=objSetAttribute(DmlCreateDia,"WbsDescription","SYSTEM GENERATED APL DML FOR TCUA")) goto CLEANUP;
//	//if(drvVCNumDup)	if(dstat=objSetAttribute(DmlCreateDia,"t5DriverVCNo",drvVCNumDup)) goto EXIT;
//	if(dstat=objSetList(DmlCreateDia,DesignGroupListAttr,DsgnGrpValue)) goto EXIT;
//	if(dstat=objSetAttribute(DmlCreateDia,WbsPriorityAttr,"CcfPriority3")) goto CLEANUP;
//	if(dstat=objSetAttribute(DmlCreateDia,ReasonAttr,"CcfDefect")) goto CLEANUP;
//
//	//printf("Before create dml\n");	fflush(stdout);
//	fprintf(createamdml,"Before create dml\n");	fflush(createamdml);
//	//objDump(DmlCreateDia);
//
//	if(dstat=CreateObject(CmChNtItClass,DmlCreateDia,&DmlObj,mfail)) goto CLEANUP;
//	//printf("dump...DmlObj.. \n");	fflush(stdout);
//	fprintf(createamdml,"dump...DmlObj.. \n");	fflush(createamdml);
//	//objDump(DmlObj);
//	//Commeted for testing
//	if (iupdcntrl > 0)
//	{
//		if(dstat=objSetAttribute(CntrlObjUA,t5DelIndAttr,"+")) goto CLEANUP;
//		if(dstat=t0UpdateObject1(&CntrlObjUA,mfail));
//	}
//	//if (nlsStrCmp(sDltIndDup,"+")==0)
//	//{
//	//}
//	
//	//if(dstat = ExpandObject5(CmPlRvRvClass,DmlObj,"CMPlanBreaksDownInTo",SC_SCOPE_OF_SESSION,&brkTaskObjsTo,mfail)) goto CLEANUP;
//	//printf("\nNo of task found : %d",setSize(brkTaskObjsTo));fflush(stdout);
//	//fprintf(createamdml,"\nNo of task found : %d",setSize(brkTaskObjsTo));fflush(createamdml);
//	
//	//if (dstat = smSetSessionUsrName ("Loader")) goto EXIT;
//	//if (*mfail)
//	//{
//	//		printf("\n DML mfail:%d  ........\n",*mfail);fflush(stdout);
//	//		mfail=USC_OKAY;
//	//}
//
//	//printf("\n DML has been Loaded Succesfully End .....\n");fflush(stdout);
//	fprintf(createamdml,"\n DML has been Loaded Succesfully End .....\n");fflush(createamdml);
//	
//	if(setSize(soCntrlObj)>0)
//	{
//		CntrlObj	= setGet(soCntrlObj,0);
//		if(dstat=objSetAttribute(CntrlObj,t5Userinfo4Attr,"Live")) goto CLEANUP;
//		t5CheckMfail(t0UpdateObject1(&CntrlObj,mfail));
//	}
//
//    if(DmlObj)
//    {
//		string	DMLNumber		=	NULL;
//		string	DMLNumberDup	=	NULL;
//		if(dstat = objCopy(AMDmlObj,DmlObj)) goto CLEANUP;
//		if(dstat = objGetAttribute(AMDmlObj,WbsIDAttr,&DMLNumber))goto CLEANUP;
//		if (!nlsIsStrNull(DMLNumber))
//		{
//			DMLNumberDup	=	nlsStrDup(DMLNumber);
//		}
//		fprintf(createamdml,"\n DML has been Loaded Succesfully End .....%s\n",DMLNumberDup);fflush(createamdml);
//
//    }
//	
//
//	//t5CheckMfail(CheckInItem(AMDmlObj,"WIP Vault", mfail));	
//	//if(dstat =RefreshDbObject(AMDmlObj,mfail)) goto EXIT;
////	extraStr	=	NULL;
////	extraObj	=	NULL;
////	ObjectPtr	BIDialogueObjP	=	NULL;
////	SetOfObjects failedSO=NULL;
////	if(dstat =SetUpDialog(objClass(AMDmlObj),AMDmlObj,"TransferDialogC",&extraStr,&extraObj, &BIDialogueObjP,mfail));
////		t5CheckDstat(objSetAttribute(BIDialogueObjP,DestOwnerNameAttr,"WIP Vault"));
////	{		
////		t5CheckDstat(objSetAttribute(BIDialogueObjP,DestOwnerNameAttr,"WIP Vault"));	
////	}
//
////	if(dstat =(objSetAttribute(BIDialogueObjP,IncludeAttachedDIsAttr,"-")));
////	if(dstat =(TransferAllObject(AMDmlObj,BIDialogueObjP,&failedSO,mfail)));
//	
//	CLEANUP:
//		//printf("\n In CLEANUP Section  \n");fflush(stdout);
//			if(DmlObj)   objDispose(DmlObj);
//			if(DmlCreateDia)   objDispose(DmlCreateDia);
//
//	EXIT:
//		//printf("\n In EXIT Section  \n");fflush(stdout);
//		if(dstat != OKAY) uiShowFatalError(dstat,WHERE);
//		return(dstat);
//}

//status AMDMLCreateFunc(string project,string sDesignGrp,string t5EcnType,string sUserLocation,FILE	*createamdml,ObjectPtr *AMDmlObj,integer* mfail)
status AMDMLCreateFunc(string project,string t5EcnType,string sUserLocation,FILE	*createamdml,ObjectPtr *AMDmlObj,integer* mfail)
{
	//char *mod_name = "AMDMLCreateFunc";
	//integer mfail = USC_OKAY;
	//status	dstat = OKAY;
	t5MethodInit("AMDMLCreateFunc");
    *mfail 		= USC_OKAY;

	ObjectPtr DmlCreateDia				=	NULL;
	ObjectPtr DmlObj					=	NULL;
	//ObjectPtr UsrObj					=	NULL;
	//ObjectPtr CntrlObj					=	NULL;
	//ObjectPtr CntrlObjUA				=	NULL;
	//ObjectPtr tskObj					=	NULL;
	//ObjectPtr dialogObj					=	NULL;

	//string			StrUsrAgn1			=	NULL;
	//string			StrUsrAgn1Dup		=	NULL;
	//string			StrUsrLoc1			=	NULL;
	//string			StrUsrLoc1Dup		=	NULL;
	//string			sTaskNum			=	NULL;
	//string			sTaskNumDup			=	NULL;
	
	SetOfStrings	extraStrECN			=	NULL;
	SetOfObjects	extraObjECN			=	NULL;
	//SetOfObjects	UsrObjSet			=	NULL;
	//SetOfObjects	soCntrlObj			=	NULL;
	//SetOfObjects	soCntrlObjPrj		=	NULL;
	//SetOfObjects	soCntrlObjPrjUA		=	NULL;
	//SetOfObjects	brkTaskObjsTo		=	NULL;
	//SetOfObjects	extraObj			=	NULL;

	//SetOfStrings	DsgnGrpValue			= NULL;
	//SetOfStrings	extraStr				= NULL;

	//SqlPtr			Sql_ptr				=	NULL;
	//SqlPtr			sqlPtr				=	NULL;
	SqlPtr			a_sql				=	NULL;

	//ADDED FOR TCE_TCAU NUMBER GENERATION
	string			Curr_date					= NULL;
	string			Curr_Year					= NULL;
	string			Curr_Year_Srch				= NULL;
	string			CurrAMDml					= NULL;
	string			Prev_DmlSeq					= NULL;
	string			PrevAMDmlDup				= NULL;
	string			PrevAMDml					= NULL;
	string			token						= NULL;
	string			tokenDup					= NULL;
   
    int				iSquence					= 0;
	int				ilen						= 0;
	int				itotlen						= 0;
    SetOfObjects			sAMDMLObjs			= NULL;
    ObjectPtr			sAMDML			= NULL;
	SetOfStrings	ScopDbset			= NULL;
	int				s					= 0;
	string         ScopDb              = NULL;

	//t5MethodInitWMD("AMDMLCreateFunc");

	//printf("\nIn AMDMLCreateFunc : %s",DMLNameS); fflush(stdout);
	
	//DsgnGrpValue	= setCreate(1);

	//low_set_add_str(DsgnGrpValue,sDesignGrp);



	if(dstat = SetUpDialog(CmChNtItClass, NULL, CreateDialogCAttr, &extraStrECN, &extraObjECN, &DmlCreateDia, mfail)) goto CLEANUP;
	//if(*mfail) goto CLEANUP;

	
	fprintf(createamdml,"start setting \n");	fflush(createamdml);
	fprintf(createamdml,"Project code : %s, ECN Type : %s , User Location : %s \n",project,t5EcnType,sUserLocation);	fflush(createamdml);

    //newcode


	t5CheckDstat(GetDatabaseScope("PdmSessn",&ScopDbset,mfail));



	if(!nlsStrCmp(sUserLocation,"PCVBU"))
	{
		low_set_add_str_unique(ScopDbset,"supprod");
		low_set_add_str_unique(ScopDbset,"suhprod");
		low_set_add_str_unique(ScopDbset,"admpprod");
 
	}
	else if(!nlsStrCmp(sUserLocation,"JSR"))
	{
		low_set_add_str_unique(ScopDbset,"sujprod");
		low_set_add_str_unique(ScopDbset,"sulprod");//TZ 3.67
		low_set_add_str_unique(ScopDbset,"supprod");
		low_set_add_str_unique(ScopDbset,"suhprod");
		low_set_add_str_unique(ScopDbset,"admpprod");
 
	}
	else if(!nlsStrCmp(sUserLocation,"LKO"))
	{
		low_set_add_str_unique(ScopDbset,"sujprod");//TZ 3.67
		low_set_add_str_unique(ScopDbset,"sulprod");
		low_set_add_str_unique(ScopDbset,"supprod");
		low_set_add_str_unique(ScopDbset,"suhprod");
		low_set_add_str_unique(ScopDbset,"admpprod");
 
	}
	else if(!nlsStrCmp(sUserLocation,"PNR"))
	{
		low_set_add_str_unique(ScopDbset,"supprod");
		low_set_add_str_unique(ScopDbset,"suhprod");
		low_set_add_str_unique(ScopDbset,"admpprod");
 
	}
	else if(!nlsStrCmp(sUserLocation,"DWD"))
	{
		low_set_add_str_unique(ScopDbset,"supprod");
		low_set_add_str_unique(ScopDbset,"suhprod");
		low_set_add_str_unique(ScopDbset,"admpprod");
 
	}
	else if(!nlsStrCmp(sUserLocation,"JDL"))
	{
		low_set_add_str_unique(ScopDbset,"sujprod");
		low_set_add_str_unique(ScopDbset,"sulprod");//TZ 3.67
		low_set_add_str_unique(ScopDbset,"supprod");
		low_set_add_str_unique(ScopDbset,"suhprod");
		low_set_add_str_unique(ScopDbset,"admpprod");
 
	}
	else
	{
		low_set_add_str_unique(ScopDbset,"supprod");
		low_set_add_str_unique(ScopDbset,"suhprod");
		low_set_add_str_unique(ScopDbset,"admpprod");
	}
 
 
	if (dstat = SetDatabaseScope("PdmSessn",ScopDbset,mfail))goto EXIT;
 
	t5CheckDstat(smGetSessionDbScope(&ScopDbset));
	//printf("\nNo of Session db Scop are :%d\n",setSize(ScopDbset));fflush(stdout);
	for (s=0;s<setSize(ScopDbset);s++)
	{
		ScopDb=setGet(ScopDbset,s);
		printf("\nScope db:%s\n",ScopDb);fflush(stdout);
	}

	//newcode




	if (nlsStrCmp(t5EcnType,"MCNote")==0)
	{
		fprintf(createamdml,"MCNote DML creation in TCE \n");	fflush(createamdml);
	}
	else
	{
		fprintf(createamdml,"AM DML creation in TCE\n");	fflush(createamdml);
	}

	if (dstat = smSetSessionUsrName ("APLAna2")) goto EXIT;
	//if(dstat=objSetAttribute(DmlCreateDia,WbsIDAttr,DMLNameS)) goto CLEANUP;

	//TCE_TCUA NUMBER GENERATION
	
	


		Curr_date		= nlsStrAlloc(50);
		Curr_Year		= nlsStrAlloc(10);
		Curr_Year_Srch	= nlsStrAlloc(30);

		Curr_date = sysGetDate2();

		nlsStrCpy(Curr_Year,subString(Curr_date,2,2));

		nlsStrCpy(Curr_Year_Srch, Curr_Year);

		if(!nlsStrCmp(sUserLocation,"JSR"))
		{
			nlsStrCat(Curr_Year_Srch, "AM80");
		}
		else if(!nlsStrCmp(sUserLocation,"LKO"))
			nlsStrCat(Curr_Year_Srch, "AM70");
		else
			nlsStrCat(Curr_Year_Srch, "AM90");


		nlsStrCat (Curr_Year_Srch, "%");

		printf("\n  Curr_Year_Srch is %s \n",Curr_Year_Srch); fflush(stdout);

		if (dstat = oiSqlCreateSelect(&a_sql)) goto CLEANUP;
		if (dstat = oiSqlWhereLikeValue(a_sql,"WbsID",Curr_Year_Srch)) goto CLEANUP;
		if (dstat = oiSqlDescOrder(a_sql,WbsIDAttr)) goto CLEANUP;
		if (dstat = QueryDbObject("CmChNtIt",a_sql,0,TRUE,SC_SCOPE_OF_SESSION,&sAMDMLObjs,mfail)) goto CLEANUP;
		if(a_sql) oiSqlDispose(a_sql); a_sql = NULL;
		printf("\n Sarin after query db %d\n",setSize(sAMDMLObjs));fflush(stdout);

		Prev_DmlSeq = nlsStrAlloc(40);
		if(setSize(sAMDMLObjs) <= 0)
		{

			if(!nlsStrCmp(sUserLocation,"JSR"))
			{
				nlsStrCpy(Prev_DmlSeq, "801001");
			}

			else if(!nlsStrCmp(sUserLocation,"LKO"))
			nlsStrCpy(Prev_DmlSeq, "701001");
			else
			nlsStrCpy(Prev_DmlSeq, "901001");
		}
		else
		{
			sAMDML = setGet(sAMDMLObjs,0);
			PrevAMDml = nlsStrAlloc(25) ;
			if (dstat = objGetAttribute(sAMDML,WbsIDAttr,&PrevAMDml)) goto EXIT;
			PrevAMDmlDup = low_getspace (25) ;
			token = low_getspace (25) ;
			tokenDup = low_getspace (25) ;
			nlsStrCpy(PrevAMDmlDup,PrevAMDml);
			token = strtok(PrevAMDmlDup,"_");
			nlsStrCpy(tokenDup,token);
			Prev_DmlSeq = subString(tokenDup,4,6);
			itotlen=nlsStrLen(Prev_DmlSeq);
			iSquence=atoi(Prev_DmlSeq);
			iSquence++;
			ilen=nlsStrLen(low_rad_convert(iSquence,10));
			nlsStrTruncate(Prev_DmlSeq,(itotlen-ilen));
			nlsStrCat (Prev_DmlSeq,low_rad_convert(iSquence,10));
		}



	CurrAMDml = nlsStrAlloc(40);
	printf("\n Sarin  After Curr_DmlSeq for APLSGR %s\n",Prev_DmlSeq);fflush(stdout);

	nlsStrCpy(CurrAMDml, Curr_Year);

	nlsStrCat (CurrAMDml, "AM");
	nlsStrCat (CurrAMDml, Prev_DmlSeq);

	if(!nlsStrCmp(sUserLocation,"JSR"))
	{
		nlsStrCat (CurrAMDml, "_APLJ");
	}
	else if(!nlsStrCmp(sUserLocation,"LKO"))
	{
		nlsStrCat (CurrAMDml, "_APLL");
	}
	else if(!nlsStrCmp(sUserLocation,"DWD"))
	{
		nlsStrCat (CurrAMDml, "_APLD");
	}
	else if(!nlsStrCmp(sUserLocation,"PNR"))
	{
		nlsStrCat (CurrAMDml, "_APLU");
	}
	else if(!nlsStrCmp(sUserLocation,"AHD"))
	{
		nlsStrCat (CurrAMDml, "_APLS");
	}
	else if(!nlsStrCmp(sUserLocation,"PCVBU"))
	{
		nlsStrCat (CurrAMDml, "_APL");
	}
	else
	{
		nlsStrCat (CurrAMDml, "_APL");
	}

	printf("\n Current DML No is %s \n",CurrAMDml);fflush(stdout);

	if(dstat=objSetAttribute(DmlCreateDia,"t5TmpEcnNo",CurrAMDml)) goto CLEANUP; // ADDED BY DEEPTI

	//END OF NUMBER GENERATION LOGIC

	if (nlsStrCmp(t5EcnType,"MCNote")==0)
	{
		if(dstat=objSetAttribute(DmlCreateDia,"t5EcnType",t5EcnType)) goto CLEANUP;
	}
	else
	{
		if(dstat=objSetAttribute(DmlCreateDia,"t5EcnType","AMDML")) goto CLEANUP;
	}
	if(dstat=objSetAttribute(DmlCreateDia,"ProjectName",project)) goto CLEANUP;
	if(dstat=objSetAttribute(DmlCreateDia,"WbsName","SYSTEM GENERATED APL DML FOR TCUA")) goto CLEANUP;
	if(dstat=objSetAttribute(DmlCreateDia,"WbsDescription","SYSTEM GENERATED APL DML FOR TCUA")) goto CLEANUP;
	//if(drvVCNumDup)	
	if(dstat=objSetAttribute(DmlCreateDia,"t5DriverVCNo",sUserLocation)) goto EXIT;
	//if(dstat=objSetList(DmlCreateDia,DesignGroupListAttr,DsgnGrpValue)) goto EXIT;
	if(dstat=objSetAttribute(DmlCreateDia,WbsPriorityAttr,"CcfPriority3")) goto CLEANUP;
	if(dstat=objSetAttribute(DmlCreateDia,ReasonAttr,"CcfDefect")) goto CLEANUP;

	//printf("Before create dml\n");	fflush(stdout);
	fprintf(createamdml,"Before create dml\n");	fflush(createamdml);
	//objDump(DmlCreateDia);

	if(dstat=CreateObject(CmChNtItClass,DmlCreateDia,&DmlObj,mfail)) goto CLEANUP;
	//printf("dump...DmlObj.. \n");	fflush(stdout);
	fprintf(createamdml,"dump...DmlObj.. \n");	fflush(createamdml);
	
	fprintf(createamdml,"\n DML has been Loaded Succesfully End .....\n");fflush(createamdml);

    if(DmlObj)
    {
		string	DMLNumber		=	NULL;
		string	DMLNumberDup	=	NULL;
		if(dstat = objCopy(AMDmlObj,DmlObj)) goto CLEANUP;
		if(dstat = objGetAttribute(AMDmlObj,WbsIDAttr,&DMLNumber))goto CLEANUP;
		if (!nlsIsStrNull(DMLNumber))
		{
			DMLNumberDup	=	nlsStrDup(DMLNumber);
		}
		fprintf(createamdml,"\n DML has been Loaded Succesfully End .....%s\n",DMLNumberDup);fflush(createamdml);

    }
	
	CLEANUP:
		//printf("\n In CLEANUP Section  \n");fflush(stdout);
			if(DmlObj)   objDispose(DmlObj);
			if(DmlCreateDia)   objDispose(DmlCreateDia);

	EXIT:
		//printf("\n In EXIT Section  \n");fflush(stdout);
		if(dstat != OKAY) uiShowFatalError(dstat,WHERE);
		return(dstat);
}

int ns__creAMDMLInTCE(struct soap* soap,char *plant,char *projectcode, char	*Description, char *DesignGroup, char	*ECNType,char **Response)
{
	FILE           *createamdml;

	status	dstat = OKAY;
	int	mfail =USC_OKAY;

	//FILE	*DMLInTCE;

	//int				itotlen				=	0;
	//int				iSquence			=	0;
	//int				ilen				=	0;


	string		    FileNameDup			=	NULL;
	string			TodayDate			=	NULL;
	string			usrAgency			=	NULL;
	string			usrDept				=	NULL;
	string			usrLocation			=	NULL;
	string			sUserLocation		=	NULL;
	string			creator				=	NULL;
	string			DMLNumber			=	NULL;
	string			DMLNumberDup		=	NULL;
	/*string			Curr_date			=	NULL;
	string			Curr_Year			=	NULL;
	string			Curr_Year_Srch		=	NULL;
	string			Prev_DmlSeq			=	NULL;
	string			PrevAMDml			=	NULL;
	string			PrevAMDmlDup		=	NULL;
	string			token				=	NULL;
	string			tokenDup			=	NULL;
	string			CurrAMDml			=	NULL;*/
	string			DMLNumberRtn		=	NULL;

	ObjectPtr		AMDmlObj			=	NULL;
	//ObjectPtr		sAMDML				=	NULL;

	SetOfStrings	strDbScope			=	NULL;

	//SetOfObjects	UsrObjSet			=	NULL;
	//SetOfObjects	sAMDMLObjs			=	NULL;

	//SqlPtr			Sql_ptr				=	NULL;

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("logAPLDML.txt", "w", stdout);

	
	
	TodayDate=sysGetCTime();
	low_strrpl(TodayDate,' ','_');
	low_strrpl(TodayDate,':','_');
	
	FileNameDup	=	NULL;
	FileNameDup	=	nlsStrAlloc(300);
	nlsStrCpy(FileNameDup,"/plmuv_logs/omfprod/logs/");
	nlsStrCat(FileNameDup,"APLDML_");
	nlsStrCat(FileNameDup,TodayDate);
	nlsStrCat(FileNameDup,".log");

	createamdml = fopen(FileNameDup , "a+") ;
	if(FileNameDup==NULL)
	{
			goto EXIT;
	}
	
	if (dstat = clInitialize2 (TRUE)) goto CLEANUP;
	if (dstat = clLogin2 ("Loader","123loader",&mfail))goto CLEANUP;
	if (mfail!=OKAY)
	{
		fprintf(createamdml,"\nLogin Failed \n"); fflush(createamdml);
		goto EXIT;
	}

	strDbScope = low_set_create_str(2);
	low_set_add_str_unique(strDbScope,"supprod");
	low_set_add_str_unique(strDbScope,"suhprod");
	//low_set_add_str_unique(strDbScope,"admpprod");
	if(dstat = smSetSessionDbScope(strDbScope)) goto CLEANUP;
	fprintf(createamdml,"\n********WEB SERVICE CALLED FOR BOM PART CHECK***********");fflush(createamdml);

	if (dstat = smSetSessionUsrName ("APLAna2")) goto EXIT;

	usrAgency = nlsStrAlloc(30);
	usrDept = nlsStrAlloc(30);
	usrLocation = nlsStrAlloc(30);

	nlsStrCpy(usrAgency,"");
	nlsStrCpy(usrDept,"");
	nlsStrCpy(usrLocation,"");

	fprintf(createamdml,"\nplant : %s, Project code : %s, Description : %s, DesignGroup : %s, ECNType : %s\n",plant,projectcode,Description,DesignGroup,ECNType);fflush(createamdml);

	if (dstat = getUsrDetailsAPL(&usrDept,&usrLocation,&usrAgency,&mfail)) goto EXIT;
	fprintf(createamdml,"\nUser Department : %s, User Location : %s, User Agency : %s",usrDept,usrLocation,usrAgency);fflush(createamdml);
	
	if (dstat = smGetSessionUsrName (&creator)) goto EXIT;
	fprintf(createamdml,"\nUser creator : %s",creator);fflush(createamdml);

	if (dstat = getUserLocationbasedonDML(plant, &sUserLocation,createamdml,&mfail));
	fprintf(createamdml,"\nUser Location : %s",sUserLocation);fflush(createamdml);
	
	//if (dstat = AMDMLCreateFunc(projectcode,DesignGroup, ECNType, sUserLocation,createamdml,&AMDmlObj, &mfail));
	if (dstat = AMDMLCreateFunc(projectcode, ECNType, sUserLocation,createamdml,&AMDmlObj, &mfail));
	//AMDMLCreateFunc(string project,string sDesignGrp,string t5EcnType,string sUserLocation,FILE	*createamdml,ObjectPtr *AMDmlObj,integer* mfail)
	DMLNumberRtn	=	NULL;
	DMLNumberRtn	=	nlsStrAlloc(50);
	if (AMDmlObj!=NULL)
	{
		if (dstat = objGetAttribute(AMDmlObj,WbsIDAttr,&DMLNumberDup));
		if(!nlsIsStrNull(DMLNumberDup))
		{
			DMLNumber = nlsStrDup(DMLNumberDup);
			//nlsStrCpy(DMLNumberRtn,DMLNumber);
			if (nlsStrLen(DMLNumber)>10)
			{
				//nlsStrCpy(*Response,DMLNumberRtn);
				nlsStrCpy(DMLNumberRtn,DMLNumber);
			}
			else
			{
				//nlsStrCpy(*Response,"NODMLCREATED");
				nlsStrCpy(DMLNumberRtn,"NODMLCREATED");
			}
		}
		else
		{
			DMLNumber	=	NULL;
			DMLNumber	=	nlsStrAlloc(30);
			nlsStrCpy(DMLNumber,"NODMLCREATED");
			nlsStrCpy(DMLNumberRtn,"NODMLCREATED");
		}
		fprintf(createamdml,"\nDMLNumber : %s",DMLNumber);fflush(createamdml);
		*Response = (char *) malloc( (50) * sizeof(char));
		nlsStrCpy(*Response,DMLNumberRtn);
		fprintf(createamdml,"\nDMLNumber : %s",DMLNumberRtn);fflush(createamdml);
	}
	else
	{
		printf("\nAMDmlObj is NULL");fflush(stdout);
		*Response = (char *) malloc( (50) * sizeof(char));
		nlsStrCpy(*Response,"NODMLCREATED");
	}
	
	if (createamdml)
	{
		fclose(createamdml);
	}
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
return SOAP_OK;

 CLEANUP :
	 fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
		return SOAP_OK;
EXIT:
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
return SOAP_OK;

}