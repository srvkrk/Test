/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: CasCave_Des.c
*  Created By      :  
*  Created On      :13/12/2021
*  Project         :  APL
**
*******************************************************************************/
#include "soapH.h"								/* get the gSOAP-generated definitions */
#include "CasCave_Des.nsmap"		 /* get the gSOAP-generated namespace bindings */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/project.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#include <tc/preferences.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>

#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}

FILE	*CascaveLog;

struct Prt_Bom
{
	char	Level[5];
	char	PartNumber[30];
	char	PartRev[5];
	char PartSeq[5];
	char	PartWeight[20];
	char	PartSurfArea[50];
	char	PartVolume[50];
	char	PartCS[50];
	char	PartMaterial[50];
	char	PartDesc[500];
	char	PartProjCode[10];
	char	PartProjDesc[500];
	char	PEnvDia[500];
	char	PThickness[300];
	char	PParttype[300];
	char	Qty[5];

}get_Prt_List_Rev;


     int ifail =0;
	 int count=0;
	 int n_closure_tags=	0;

	 tag_t* childLines		= NULLTAG;
	 tag_t * 	closure_tags	= NULLTAG;
	 tag_t	closure_tag		=	NULLTAG;

	char*			responseString			= NULL;
	char*			responseString1			= NULL;
	char*			responseString2			= NULL;
	char*			responseString3			= NULL;
	char*			responseString4			= NULL;
	char*			responseString5			= NULL;
	char*			responseString6			= NULL;
	char*			responseString7         = NULL;
	char*			responseString8         = NULL;
	char*			responseString9         = NULL;
	char*			responseString10        = NULL;
	char*			responseString11        = NULL;
	char*			responseString12       = NULL;
	char*			responseString13       = NULL;
	char*			responseString14       = NULL;
	char*			responseString15       = NULL;
	char*			responseString16       = NULL;

	char	*closureRuleName					=	NULL;


PIE_scope_t scope;

char 		szHMCL_file_log[250] 			= "";
char 		szHMCL_file_err[250]			= "";
char 		szHMCL_file_output[250] 		= "";
static void vLog(char* givenFormat, va_list givenArgs, char* fileName)
{
	char			* logFile 			= NULL;
	FILE			* logFp;
	time_t 			now;
	struct 			tm when;
	char 			date_str[50];
	long 			size;
	logical 		check_size 			= false;
	logFile 							= fileName;
	if (logFile)
	{
		logFp = fopen(logFile, "a+");
		if(!logFp)
		{
			fprintf(stderr, "ERROR: Cannot open '%s'\n", logFile);
			perror(logFile);
			logFp = stderr;
		}
		else{
			fseek(logFp, 0, SEEK_END);
			size = ftell(logFp);
			if(size > 3000000 && check_size)
			{	fclose (logFp);
				logFp = fopen(logFile, "w");
			}
			  }
	}
	else
	{	logFp = stderr;
	}
	if (tc_strcmp(logFile, szHMCL_file_output) == 0)
	{
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp,"\n");
		if (logFp != stderr)
		{			fclose(logFp);
		}
	}
	else
	{
		time(&now);
		when = *localtime(&now);
		strftime(date_str, 50, "%d-%m-%Y %H:%M:%S",&when);
		fprintf(logFp, "%s --- ", date_str);
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp, "\n");
		if (logFp != stderr)
		{	fclose(logFp);
		}
	}
}
void Debug(char* givenFormat, ...)
{
	va_list   functArgs;
	va_start(functArgs, givenFormat);
	vLog(givenFormat, functArgs, szHMCL_file_log);
	va_end(functArgs);
}

/* Function to add Tag into a set of Tag */
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{
*count=*count+1;
if(*count==1)
{
fprintf(CascaveLog,"\n ****setAddTAG1******************\n");fflush(CascaveLog);
(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
}
else
{
fprintf(CascaveLog,"\n ****setAddTAG2*********************\n");fflush(CascaveLog);
(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
}
(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf);

char* subString
(
	char* mainStringf ,
	int fromCharf     ,
	int toCharf
)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
     *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
{
	char *error_msg_string;
	EMH_ask_error_text(return_code,&error_msg_string);
	//EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	printf("ERROR1: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}

extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new());										/* call the request dispatcher */
};

int getBomLineAttributes(tag_t tagBOMline)                /*Getting all attributes of BOM line which is required for web service*/
{
	tag_t  projobj=NULLTAG;
	char*   partNumber = NULL;
	char*   partRevNumber = NULL;
	char*   partSeqNumber = NULL;
	char *  item_level= NULL;
	char *  quantity = NULL;
	char *  PuneCS= NULL;
	char* Weight= NULL;
	char* PartProjCode1 = NULL;
	char* CS= NULLTAG;
	char* PartProjCode = NULLTAG;
	char* PartType = NULLTAG;
	char* Material = NULLTAG;
	char* Description = NULLTAG;
	char*	SurfaceArea =NULL;
	char*	Volume =NULL;
	char*	Thicknes =NULL;
	char*	EnvelopeDimensions =NULL;
	char	*ModItem_Rev			=	NULL;
	char	*ModItem_Seq			=	NULL;

	responseString1=(char *)MEM_alloc(200);
	responseString2=(char *)MEM_alloc(200);
	responseString3=(char *)MEM_alloc(200);
	responseString4=(char *)MEM_alloc(200);
	responseString5=(char *)MEM_alloc(200);
	responseString6=(char *)MEM_alloc(200);
	responseString7=(char *)MEM_alloc(200);
	responseString8=(char *)MEM_alloc(200);
	responseString9=(char *)MEM_alloc(200);
	responseString10=(char *)MEM_alloc(200);
	responseString11=(char *)MEM_alloc(200);
	responseString12=(char *)MEM_alloc(200);
	responseString13=(char *)MEM_alloc(200);
	responseString14=(char *)MEM_alloc(200);
	responseString15=(char *)MEM_alloc(200);
	responseString16=(char *)MEM_alloc(200);

    fprintf(CascaveLog,"-----------------------------------------------------------------------------------------***\n");fflush(CascaveLog);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_level_starting_0",&item_level);
	fprintf(CascaveLog,"Part Level number===>%s\n",item_level);fflush(CascaveLog);
	tc_strcpy(responseString1,"");
	tc_strcat(responseString1,item_level);

	ifail=AOM_ask_value_string(tagBOMline,"bl_item_item_id",&partNumber);
	fprintf(CascaveLog,"Part number===>%s\n",partNumber);fflush(CascaveLog);
    tc_strcpy(responseString2,"");
	tc_strcat(responseString2,partNumber);

    ifail=AOM_ask_value_string(tagBOMline,"bl_rev_item_revision_id",&partRevNumber);
	fprintf(CascaveLog,"Part Rev number===>%s\n",partRevNumber);fflush(CascaveLog);

   	ModItem_Rev =  tc_strtok(partRevNumber,";");
	fprintf(CascaveLog,"Item_Rev --> : %s\n",ModItem_Rev); fflush(CascaveLog);
	tc_strcpy(responseString3,"");
	tc_strcat(responseString3,ModItem_Rev);

	ModItem_Seq = tc_strtok(NULL,";");
	fprintf(CascaveLog,"Item_Seq ----> : %s\n",ModItem_Seq); fflush(CascaveLog);
	tc_strcpy(responseString4,"");
	tc_strcat(responseString4,ModItem_Seq);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Weight",&Weight);
	fprintf(CascaveLog,"Part Weight: [%s]\n", Weight); fflush(CascaveLog);
	tc_strcpy(responseString5,"");
	tc_strcat(responseString5,Weight);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_SurfaceArea",&SurfaceArea);
	fprintf(CascaveLog,"SurfaceArea : [%s]\n", SurfaceArea); fflush(CascaveLog);
	tc_strcpy(responseString6,"");
	tc_strcat(responseString6,SurfaceArea);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Volume",&Volume);
	fprintf(CascaveLog,"Volume : [%s]\n", Volume); fflush(CascaveLog);
	tc_strcpy(responseString7,"");
	tc_strcat(responseString7,Volume);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_PunMakeBuyIndicator",&PuneCS);
	fprintf(CascaveLog,"Part CS number=>%s\n",PuneCS);fflush(CascaveLog);
	tc_strcpy(responseString8,"");
	tc_strcat(responseString8,PuneCS);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_Material",&Material);
	fprintf(CascaveLog,"Material: [%s]\n", Material); fflush(CascaveLog);
	tc_strcpy(responseString9,"");
	tc_strcat(responseString9,Material);

	ifail=AOM_ask_value_string(tagBOMline,"bl_rev_object_desc",&Description);
	fprintf(CascaveLog,"object_description: [%s]\n", Description); fflush(CascaveLog);
	tc_strcpy(responseString10,"");
	tc_strcat(responseString10,Description);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_ProjectCode",&PartProjCode);
	fprintf(CascaveLog,"Part ProjCode: [%s]\n", PartProjCode); fflush(CascaveLog);
	tc_strcpy(responseString11,"");
	tc_strcat(responseString11,PartProjCode);

	 ITKCALL (PROJ_find(PartProjCode,&projobj));
	 if(projobj !=NULLTAG)
	{
		AOM_ask_value_string(projobj,"project_desc",&PartProjCode1);
	 	fprintf(CascaveLog,"Project Description:%s", PartProjCode1); fflush(CascaveLog);
		tc_strcpy(responseString12,"");
		tc_strcat(responseString12,PartProjCode1);
	}
	else
	{	fprintf(CascaveLog,"Project not Resister for Item\n");fflush(CascaveLog); }

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_EnvelopeDimensions",&EnvelopeDimensions);
	fprintf(CascaveLog,"EnvelopeDimensions : [%s]\n", EnvelopeDimensions); fflush(CascaveLog);
	tc_strcpy(responseString13,"");
	tc_strcat(responseString13,EnvelopeDimensions);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_MThickness",&Thicknes);
	fprintf(CascaveLog,"Thicknes : [%s]\n", Thicknes); fflush(CascaveLog);
	tc_strcpy(responseString14,"");
	tc_strcat(responseString14,Thicknes);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_PartType",&PartType);
	fprintf(CascaveLog,"PartType: [%s]\n", PartType); fflush(CascaveLog);
	tc_strcpy(responseString15,"");
	tc_strcat(responseString15,PartType);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_quantity",&quantity);
	fprintf(CascaveLog,"Part Quantity number===>%s\n",quantity);fflush(CascaveLog);
	tc_strcpy(responseString16,"");
	tc_strcat(responseString16,quantity);
	fprintf(CascaveLog,"--------------------------------------****---------------------------------------------------\n\n");fflush(CascaveLog);

	return 0;
}

int findChild(tag_t AffectedObjectBomLineTag1, int  bomlineItemId , int  bomlineRevId , int bomlineItemRevAttr)
{
	int 			count2 					 				= 0;
	int 			childCountCfgTopBomLine1 				= 0;
	int 			childCountCfgTopBomLine2 				= 0;
	tag_t   		*childTagCfgTopBomLine1	  				= NULLTAG;
	tag_t   		*childTagCfgTopBomLine2	  				= NULLTAG;
	char*   partNumber = NULL;
	char *  item_level= NULL;

	ifail=BOM_line_ask_child_lines(AffectedObjectBomLineTag1, &childCountCfgTopBomLine1, &childTagCfgTopBomLine1);
	CHECK_FAIL;

	ifail=AOM_UIF_ask_value(AffectedObjectBomLineTag1,"bl_level_starting_0",&item_level);
	fprintf(CascaveLog,"Child Part Level number===>%s\n",item_level);fflush(CascaveLog);

	ifail=AOM_ask_value_string(AffectedObjectBomLineTag1,"bl_item_item_id",&partNumber);
	fprintf(CascaveLog,"Chilld Part number===>%s\n",partNumber);fflush(CascaveLog);

	fprintf(CascaveLog,"*********Number of Child Lines are [%d] for Part [ %s] and its level is [%s]  \n",childCountCfgTopBomLine1,partNumber,item_level);fflush(CascaveLog);

	for (count2 = 0;count2 < childCountCfgTopBomLine1;count2++)
	{
		ifail=getBomLineAttributes(childTagCfgTopBomLine1[count2]);CHECK_FAIL;

		ifail=BOM_line_ask_child_lines(childTagCfgTopBomLine1[count2], &childCountCfgTopBomLine2, &childTagCfgTopBomLine2);CHECK_FAIL;

		fprintf(CascaveLog,"Number of Child Lines %d \n",childCountCfgTopBomLine2);fflush(CascaveLog);
        fprintf(CascaveLog,"-----------------------------------------------------------------------------------------\n");fflush(CascaveLog);

		if (childCountCfgTopBomLine2 != 0)
			{
				ifail = findChild(childTagCfgTopBomLine1[count2],bomlineItemId ,bomlineRevId,bomlineItemRevAttr);CHECK_FAIL;
			}
			else
		    { fprintf(CascaveLog,"NO Child Lines Present\n");fflush(CascaveLog);
			}
	}
	return 0;
}

/*calling BOM Window Child Part Line Count for tags and calling recursive function as well*/

int findChildTag(tag_t tagBOMline,struct Prt_Bom prtLst[ ],int* StrctInt)
{
	int 			count2 					 				= 0;
	int 			childCountCfgTopBomLine1 				= 0;
	int 			childCountCfgTopBomLine2 				= 0;
	tag_t   		*childTagCfgTopBomLine1	  				= NULLTAG;
	tag_t   		*childTagCfgTopBomLine2	  				= NULLTAG;
	tag_t   projobj	  				= NULLTAG;

	char*   partNumber = NULL;
	char*   partRevNumber = NULL;
	char*   partSeqNumber = NULL;
	char *  item_level= NULL;
	char *  quantity = NULL;
	char *  PuneCS= NULL;
	char* Weight= NULL;
	char* PartProjCode1 = NULLTAG;
	char* CS= NULLTAG;
	char* PartProjCode = NULLTAG;
	char* PartType = NULLTAG;
	char* Material = NULLTAG;
	char* Description = NULLTAG;
	char*	SurfaceArea =NULL;
	char*	Volume =NULL;
	char*	Thicknes =NULL;
	char*	EnvelopeDimensions =NULL;
	char	*ModItem_Rev			=	NULL;
	char	*ModItem_Seq			=	NULL;

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_level_starting_0",&item_level);
	fprintf(CascaveLog,"Part Level number===>%s\n",item_level);fflush(CascaveLog);

	ifail=AOM_ask_value_string(tagBOMline,"bl_item_item_id",&partNumber);
	fprintf(CascaveLog,"Part number===>%s\n",partNumber);fflush(CascaveLog);

    ifail=AOM_ask_value_string(tagBOMline,"bl_rev_item_revision_id",&partRevNumber);
	fprintf(CascaveLog,"Part Rev number===>%s\n",partRevNumber);fflush(CascaveLog);

	ModItem_Rev =  tc_strtok(partRevNumber,";");
	fprintf(CascaveLog,"Item_Rev --> : %s\n",ModItem_Rev); fflush(CascaveLog);

	ModItem_Seq = tc_strtok(NULL,";");
	fprintf(CascaveLog,"Item_Seq --> : %s\n",ModItem_Seq); fflush(CascaveLog);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Weight",&Weight);
	fprintf(CascaveLog,"Part Weight: [%s]\n", Weight); fflush(CascaveLog);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_SurfaceArea",&SurfaceArea);
	fprintf(CascaveLog,"SurfaceArea : [%s]\n", SurfaceArea); fflush(CascaveLog);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Volume",&Volume);
	fprintf(CascaveLog,"Volume : [%s]\n", Volume); fflush(CascaveLog);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_PunMakeBuyIndicator",&PuneCS);
	fprintf(CascaveLog,"Part CS number===>%s\n",PuneCS);fflush(CascaveLog);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_Material",&Material);
	fprintf(CascaveLog,"Material: [%s]\n", Material); fflush(CascaveLog);

	ifail=AOM_ask_value_string(tagBOMline,"bl_rev_object_desc",&Description);
	fprintf(CascaveLog,"object_description: [%s]\n", Description); fflush(CascaveLog);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_ProjectCode",&PartProjCode);
	fprintf(CascaveLog,"Part ProjCode: [%s]\n", PartProjCode); fflush(CascaveLog);

	 ITKCALL (PROJ_find(PartProjCode,&projobj));
	 if(projobj !=NULLTAG)
	{
		AOM_ask_value_string(projobj,"project_desc",&PartProjCode1);
	 	fprintf(CascaveLog,"Part Project Description: %s", PartProjCode1); fflush(CascaveLog);
	}
	else
	{	fprintf(CascaveLog,"Project not Resister for Item\n");fflush(CascaveLog); }

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_EnvelopeDimensions",&EnvelopeDimensions);
	fprintf(CascaveLog,"EnvelopeDimensions : [%s]\n", EnvelopeDimensions); fflush(CascaveLog);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_MThickness",&Thicknes);
	fprintf(CascaveLog,"Thicknes : [%s]\n", Thicknes); fflush(CascaveLog);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_PartType",&PartType);
	fprintf(CascaveLog,"PartType: [%s]\n", PartType); fflush(CascaveLog);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_quantity",&quantity);
	fprintf(CascaveLog,"Part Quantity number==>%s\n\n",quantity);fflush(CascaveLog);

	*StrctInt	=	*StrctInt+1;
	tc_strcpy(prtLst[*StrctInt].Level,item_level);
	tc_strcpy(prtLst[*StrctInt].PartNumber,partNumber);
	fprintf(CascaveLog,"***********Part number******%s\n",partNumber);fflush(CascaveLog);
	fprintf(CascaveLog,"***********prtLst[*StrctInt].PartNumber******%s\n",prtLst[*StrctInt].PartNumber);fflush(CascaveLog);
	tc_strcpy(prtLst[*StrctInt].PartRev,partRevNumber);
	tc_strcpy(prtLst[*StrctInt].PartSeq,ModItem_Seq);
	tc_strcpy(prtLst[*StrctInt].PartWeight,Weight);
	tc_strcpy(prtLst[*StrctInt].PartSurfArea,SurfaceArea);
	tc_strcpy(prtLst[*StrctInt].PartVolume,Volume);
	tc_strcpy(prtLst[*StrctInt].PartCS,PuneCS);
	tc_strcpy(prtLst[*StrctInt].PartMaterial,Material);
	tc_strcpy(prtLst[*StrctInt].PartDesc,Description);
	tc_strcpy(prtLst[*StrctInt].PartProjCode,PartProjCode);
	tc_strcpy(prtLst[*StrctInt].PartProjDesc,PartProjCode1);
	tc_strcpy(prtLst[*StrctInt].PEnvDia,EnvelopeDimensions);
	tc_strcpy(prtLst[*StrctInt].PThickness,Thicknes);
	tc_strcpy(prtLst[*StrctInt].PParttype,PartType);
	tc_strcpy(prtLst[*StrctInt].Qty,quantity);


	ifail=BOM_line_ask_child_lines(tagBOMline, &childCountCfgTopBomLine1, &childTagCfgTopBomLine1);CHECK_FAIL;

	fprintf(CascaveLog,"*********Number of Child Lines & its ChildTag*********** %d \n",childCountCfgTopBomLine1);fflush(CascaveLog);

	for (count2 = 0;count2 < childCountCfgTopBomLine1;count2++)
	{
		ifail = findChildTag(childTagCfgTopBomLine1[count2],prtLst,StrctInt);		CHECK_FAIL;
		setAddTAG(&count,&childLines,childTagCfgTopBomLine1[count2]);
	}
	fprintf(CascaveLog,"\n findChildTag: Total Number of Child Parts Found--->[%d] \n",count);fflush(CascaveLog);
	return 0;
}

int Traverse_bom(char *strItemTpnode, char *partRevNo2, char *ER_EW,char *Plant,char *Revrule,char *Clorrule)
{
	fprintf(CascaveLog,"\n------------------------Inside Traverse_bom-----------------------------------------\n");fflush(CascaveLog);
	int 			childCountTopBomLine 				= 0;
	int 			bomlineItemId1 						= 0;
	int 			bomlineRevId1      					= 0;
	int 			bomlineItemRevAttr1 				= 0;
	int 			iCount								= 0;

	char	*ModItem_Rev			=	NULL;
	char	*ModItem_Seq			=	NULL;
    char*Group= NULL;
    char*User= NULL;


	tag_t 			tagItemTpnode       				= NULLTAG;
	tag_t 			tagBOMwindow  					= NULLTAG;
	tag_t 			tagItemRevTpnode 			= NULLTAG;
	tag_t 			tagBOMline 							= NULLTAG;
	tag_t 			tagRule 									= NULLTAG;
	tag_t 			*tagTopBLchildLine 			= NULLTAG;
	closureRuleName=(char *) MEM_alloc(200 * sizeof(char *));

	ifail=BOM_create_window(&tagBOMwindow);CHECK_FAIL;
	ifail = BOM_set_window_pack_all(tagBOMwindow, true);CHECK_FAIL;

	ifail=ITEM_find_item(strItemTpnode, &tagItemTpnode);CHECK_FAIL;
	fprintf(CascaveLog,"\nTop BomLine ItemID %s \n",strItemTpnode); fflush(CascaveLog);

	ITEM_find_rev (strItemTpnode,partRevNo2,&tagItemRevTpnode);

	if(tagItemRevTpnode !=NULLTAG)
	{	 fprintf(CascaveLog,"item_revision_id:%s\n",partRevNo2);fflush(CascaveLog);	}
	else
	{	fprintf(CascaveLog,"No item_revision_id found \n");fflush(CascaveLog);	}

	ModItem_Rev =  tc_strtok(partRevNo2,";");
	fprintf(CascaveLog,"Item_Rev --> : %s\n",ModItem_Rev); fflush(CascaveLog);
	ModItem_Seq = tc_strtok(NULL,";");
	fprintf(CascaveLog,"Item_Seq --> : %s\n",ModItem_Seq); fflush(CascaveLog);

	fprintf(CascaveLog,"ER_EW Lifecycle statte:%s\n",ER_EW);fflush(CascaveLog);

	//AOM_UIF_ask_value(tagItemRevTpnode,"owning_group",&Group);fflush(stdout);
	//printf("\n owning_group of part_REV isTraverse  ---->%s\n", Group);fflush(stdout);

    AOM_UIF_ask_value(tagItemRevTpnode,"owning_user",&User);fflush(stdout);
	fprintf(CascaveLog,"\n owning_user of part_REV is  ---->%s\n", User);fflush(CascaveLog);

		if (tc_strcmp(ER_EW,"EW")==0)
		{
			fprintf(CascaveLog,"\n Latest Working Applied");fflush(CascaveLog);
		    ifail = CFM_find("Latest Working", &tagRule);CHECK_FAIL;
		}
        else if((tc_strstr(Plant,"PUN")!=NULL))
		{
			fprintf(CascaveLog,"\n ERC release Applied");fflush(CascaveLog);
			ifail = CFM_find(Revrule, &tagRule);CHECK_FAIL;
		}
	    else if((tc_strstr(Plant,"AHD")!=NULL))
		{
			fprintf(CascaveLog,"\n ERC release Applied");fflush(CascaveLog);
			ifail = CFM_find(Revrule, &tagRule);CHECK_FAIL;
		}
	    else 
		{
			fprintf(CascaveLog,"\n ERC release Applied");fflush(CascaveLog);
			ifail = CFM_find(Revrule, &tagRule);CHECK_FAIL;
		}

	    ifail = BOM_set_window_config_rule( tagBOMwindow, tagRule );CHECK_FAIL;

        
  

	     /*if(tc_strstr(Group,"dba")!=NULL)
		 {
             if  (tc_strstr(Plant,"PUN")!=NULL)
			 {
			fprintf(CascaveLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPLC****** applied\n");fflush(CascaveLog);
		    tc_strcpy(closureRuleName,Clorrule);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(CascaveLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(CascaveLog);
		    }
            else if  (tc_strstr(Plant,"AHD")!=NULL)
			 {
			fprintf(CascaveLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPLA****** applied\n");fflush(CascaveLog);
		    tc_strcpy(closureRuleName,Clorrule);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(CascaveLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(CascaveLog);
		    }
			else
		   {
			fprintf(CascaveLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ****** applied\n" );fflush(CascaveLog);
		    tc_strcpy(closureRuleName,Clorrule);
	        scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(CascaveLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(CascaveLog);
			}
		 }*/
		 if (tc_strcmp(ER_EW,"ER")==0)
		 {

			if (tc_strstr(Plant,"PUN")!=NULL)
			{
				fprintf(CascaveLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPLC******/applied\n");fflush(CascaveLog);
			
				
				tc_strcpy(closureRuleName,Clorrule);
				scope=PIE_TEAMCENTER;
				ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
				fprintf(CascaveLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(CascaveLog);
			}
			else if (tc_strstr(Plant,"AHD")!=NULL)
			{
				fprintf(CascaveLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPLA******/applied\n");fflush(CascaveLog);
				tc_strcpy(closureRuleName,Clorrule);
				scope=PIE_TEAMCENTER;
				ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
				fprintf(CascaveLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(CascaveLog);
			}
			else
			{
				fprintf(CascaveLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ******/applied\n" );fflush(CascaveLog);
				tc_strcpy(closureRuleName,Clorrule);
				scope=PIE_TEAMCENTER;
				ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
				fprintf(CascaveLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(CascaveLog);
			}
		 }
		else
        {
			fprintf(CascaveLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ******/applied\n" );fflush(CascaveLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleERC");
		    fprintf(CascaveLog,"\n**********closureRuleName*********** \n",closureRuleName);fflush(CascaveLog);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(CascaveLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(CascaveLog);
		 }


	if(n_closure_tags==1)
	{
		closure_tag=closure_tags[0];
	}

	ITKCALL(BOM_window_set_closure_rule(tagBOMwindow,closure_tag,0,NULL,NULL));
	ITKCALL(BOM_save_window (tagBOMwindow));

  	ifail=BOM_set_window_top_line(tagBOMwindow, tagItemTpnode, tagItemRevTpnode, NULLTAG, &tagBOMline);CHECK_FAIL;

	ifail=BOM_line_ask_child_lines(tagBOMline, &childCountTopBomLine, &tagTopBLchildLine); CHECK_FAIL;
	fprintf(CascaveLog,"BOM Window, Parent Part Child Line Count:-%d \n",childCountTopBomLine);fflush(CascaveLog);

	ifail=getBomLineAttributes(tagBOMline);CHECK_FAIL;

	fprintf(CascaveLog,"On Parent, Number of Child Lines %d \n\n",childCountTopBomLine);fflush(CascaveLog);
   int x=0;
	for(iCount =0 ; iCount < childCountTopBomLine; iCount++)
	{

		 x++;
        fprintf(CascaveLog,"%d \n",x);fflush(CascaveLog);
		fprintf(CascaveLog,"Getting Child Parts and its Attribute Starts \n\n");fflush(CascaveLog);
		ifail=getBomLineAttributes(tagTopBLchildLine[iCount]);CHECK_FAIL;

		ifail = findChild(tagTopBLchildLine[iCount],bomlineItemId1 ,bomlineRevId1,bomlineItemRevAttr1);CHECK_FAIL;
	}
	return 0;
}

int ns__getPartDetailCasCave(struct soap* soap,char *partnumber,char*revision,char	*ISequence, char*ER_EW, char *Plant,struct ns__CharArray4Test *aString_test)
{
	int ifail =0;
	int i= 0;

	int cnt				= 0;
	int StrctInt   =0;
		int	length			=	0;

	struct Prt_Bom getList[3000];
	int	iPrt=0;

	char 	*Num_Rev_ID			=NULL;
	char*	logFile							= NULL;
	char *releaseStatCheck=NULL;
	char *Rev_NumCat=NULL;
		char		*TrevisionS	= NULL;
	closureRuleName=(char *) MEM_alloc(200 * sizeof(char *));

	char* ExeLogFile = NULL;


	tag_t	tagBOMwindow  = NULLTAG;
	tag_t 	tagRule 					= NULLTAG;
	tag_t 	tagBOMline 			= NULLTAG;
	tag_t	VCRevision_tag	= NULLTAG;

/*********************For Log file creation*******************/

    ExeLogFile = (char	*)MEM_alloc(100);
	tc_strcpy(ExeLogFile,"");
	tc_strcpy(ExeLogFile,"/tmp/");
	tc_strcat(ExeLogFile,partnumber);
	tc_strcat(ExeLogFile,"_Cascave.log");
    CascaveLog = fopen(ExeLogFile,"w");
	fprintf(CascaveLog,"\n Part Execution Log file is :: %s\n",ExeLogFile);
	
	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	//freopen("/user/tcuaadev/devgroups/Shubham_Shrivastav/webservice_TCUA/Cascave_parts2.txt", "w", stdout);
	freopen("/tmp/Cascave_partsforCost.txt", "a", stdout);

/*-----------------------Log file created------------------------*/

	// ITK_initialize_text_services( ITK_BATCH_TEXT_MODE);
	// ITK_auto_login();

	ITKCALL(ITK_init_module("rd929455.ttl","9623CAD@7262","PLM_Support_Group"));
	// if(ITK_init_module("rd929455.ttl","CAD9623@7262","PLM_Support_Group"))
	// {	
	//     fprintf(CascaveLog,"Login Successfull to TCUA \n");fflush(CascaveLog);
 
	// }
	// else
	// {		
	// 	fprintf(CascaveLog,"\n\n\t\t Login does not exist invalid userid or password ");fflush(CascaveLog);
	// }
	ITK_set_journalling( TRUE );

    fprintf(CascaveLog,"\n#####---------------------------------------------------Starting Program For PROD-----------------------------------------------#####"); fflush(CascaveLog);
	fprintf(CascaveLog,"\n Part No : [%s]\n", partnumber); fflush(CascaveLog);
	fprintf(CascaveLog,"Part revision : [%s]\n", revision); fflush(CascaveLog);
	fprintf(CascaveLog,"Part ISequence : [%s]\n", ISequence); fflush(CascaveLog);
	fprintf(CascaveLog,"Part ER_EW : [%s]\n", ER_EW); fflush(CascaveLog);

	TrevisionS=(char *)MEM_alloc(200);
	tc_strcpy(TrevisionS,revision);
	tc_strcat(TrevisionS,"*");
	tc_strcat(TrevisionS,ISequence);
	fprintf(CascaveLog,"\nItem_Rev Seq For Query Run****** ----> : %s\n",TrevisionS); fflush(CascaveLog);

		const char *attrs[1];
		const char *values[1];
		attrs[0] ="item_id";
		values[0] = (char *)partnumber;
		fprintf(CascaveLog,"values for Part <%s> \n",values[0] );fflush(CascaveLog);


	int n_entries =	3;
	char *qry_entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	char *usrinf1 = NULL;
	char *usrinf2 = NULL;
	char *usrinf3 = NULL;
	char *usrinf4 = NULL;
	char *usrinf5 = NULL;
	char *usrinf6 = NULL;
	char *usrinf7 = NULL;
	char *usrinf8 = NULL;
	int resultCount=0;
	tag_t	Cntl_obj_Qtag	=	NULLTAG;
	tag_t *qry_cntrlobj = NULLTAG;
	tag_t Ob_Q_tag = NULLTAG;
	if(QRY_find2("Control Objects...", &Cntl_obj_Qtag));
	{
		fprintf(CascaveLog,"\n Control Object Query Found \n");fflush(CascaveLog);
		qry_values[0] =	"UAPROD_CASCAVE_2.0" ;
		qry_values[1] =	Plant ;
		qry_values[2] =	"0" ;
		ITKCALL(QRY_execute(Cntl_obj_Qtag, n_entries, qry_entries, qry_values, &resultCount, &qry_cntrlobj));
		fprintf(CascaveLog,"\nNo. of control object found : %d",resultCount);fflush(CascaveLog);
		if(resultCount>0)
		{		
			ITKCALL(AOM_ask_value_string(qry_cntrlobj[0], "t5_Userinfo1", &usrinf1));//closure
		    fprintf(CascaveLog,"\n  UAPROD_CASCAVE_2 Cntrl OBJECT --> usrinfo1 ---> [ %s ]\n", usrinf1);fflush(CascaveLog);
			ITKCALL(AOM_ask_value_string(qry_cntrlobj[0], "t5_Userinfo2", &usrinf2));//revision
		    fprintf(CascaveLog,"\n  UAPROD_CASCAVE_2 Cntrl OBJECT --> usrinfo2 ---> [ %s ]\n", usrinf2);fflush(CascaveLog);
			ITKCALL(AOM_ask_value_string(qry_cntrlobj[0], "t5_Userinfo3", &usrinf3));
		    fprintf(CascaveLog,"\n  UAPROD_CASCAVE_2 Cntrl OBJECT --> usrinfo3 ---> [ %s ]\n", usrinf3);fflush(CascaveLog);
			ITKCALL(AOM_ask_value_string(qry_cntrlobj[0], "t5_Userinfo4", &usrinf4));
		    fprintf(CascaveLog,"\n  UAPROD_CASCAVE_2 Cntrl OBJECT --> usrinfo4 ---> [ %s ]\n", usrinf4);fflush(CascaveLog);
            ITKCALL(AOM_ask_value_string(qry_cntrlobj[0], "t5_Userinfo5", &usrinf5));
		    fprintf(CascaveLog,"\n  UAPROD_CASCAVE_2 Cntrl OBJECT --> usrinfo5 ---> [ %s ]\n", usrinf5);fflush(CascaveLog);
			ITKCALL(AOM_ask_value_string(qry_cntrlobj[0], "t5_Userinfo6", &usrinf6));
		    fprintf(CascaveLog,"\n  UAPROD_CASCAVE_2 Cntrl OBJECT --> usrinfo6 ---> [ %s ]\n", usrinf6);fflush(CascaveLog);
			ITKCALL(AOM_ask_value_string(qry_cntrlobj[0], "t5_Userinfo7", &usrinf7));
		    fprintf(CascaveLog,"\n  UAPROD_CASCAVE_2 Cntrl OBJECT --> usrinfo7 ---> [ %s ]\n", usrinf7);fflush(CascaveLog);
			ITKCALL(AOM_ask_value_string(qry_cntrlobj[0], "t5_Userinfo8", &usrinf8));
		    fprintf(CascaveLog,"\n  UAPROD_CASCAVE_2 Cntrl OBJECT --> usrinfo8 ---> [ %s ]\n", usrinf8);fflush(CascaveLog);
		}
	}

        int	n_tags_found= 0;
		int iii=0;
		int st_count		=	0;
		int iStCnt=0;
		int	nCRItem			=	0;
		//char  	rev_id1[ITEM_id_size_c+1];
		//char  	rev_id2[ITEM_id_size_c+1];
		char* rev_id1 = NULL;
		char* rev_id2 = NULL;
		int *j=0;

		char*lifecycle_state= NULL;
		char*Group= NULL;
		char*User= NULL;

		tag_t	queryPart	=	NULLTAG;
		tag_t   *results	=	NULL;
		tag_t *tags_found= NULLTAG;
		tag_t item_t	= NULLTAG;
		tag_t*	status_list			=	NULLTAG;
		tag_t	ChRDsgnTag			=	NULLTAG;
		tag_t		*CRitem_revs_tag		=	NULLTAG;

		if(tc_strcmp(ER_EW,"EW")==0)
		{
		if (  (tc_strlen(partnumber)>0) && (tc_strlen (revision)>0) && ( tc_strlen(ISequence)>0)  )
		{
		fprintf(CascaveLog,"\n tc_strlen(of partnumber revision & ISequence )  is :(%d )""(%d)""(%d)",tc_strlen(partnumber),tc_strlen(revision),tc_strlen(ISequence));fflush(CascaveLog);
		fprintf(CascaveLog,"\n ***INSIDE  ER_EW  check Query*** --------------------LifeCycValSetEW-----");fflush(CascaveLog);

        int		n_entries	=	2;
		int    	num_to_sort =	1;
		int  	orders[]  	=	{1};
		int		n_found=	0;
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[2] = {"Item ID","Revision"};
		char 	*qry_part_values[2] = {partnumber,TrevisionS};

		QRY_find2("Item Revision...", &queryPart);
		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
		fprintf(CascaveLog,"\nNumber of ERC Release and Above rev of part  [%s]found : [%d]\n",partnumber,n_found);fflush(CascaveLog);

			for (iii = 0; iii < n_found; iii++)
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id1);
			fprintf(CascaveLog,"\n rev_id are  ---->%s", rev_id1);fflush(CascaveLog);														//diplay the previous revision

			AOM_UIF_ask_value(results[iii],"release_status_list",&lifecycle_state);fflush(stdout);
			fprintf(CascaveLog,"\n Its ReleaseStatus_Name********==%s\n",lifecycle_state);fflush(CascaveLog);

			ITEM_ask_rev_id2 ( results[iii], &rev_id2);
			fprintf(CascaveLog,"ERC Above Release_Status_Name of required part==%s",rev_id2);fflush(CascaveLog);
			VCRevision_tag = results[iii];

			fprintf(CascaveLog,"\n\n");fflush(CascaveLog);
			 

			}
		}
	}
	else
	{
		if (  (tc_strlen(partnumber)>0) && (tc_strlen (revision)>0) && ( tc_strlen(ISequence)>0)  )
		{
		fprintf(CascaveLog,"\n Lemmgth of partnumber revision & ISequence )  is :(%d )""(%d)""(%d)",tc_strlen(partnumber),tc_strlen(revision),tc_strlen(ISequence));fflush(CascaveLog);
		fprintf(CascaveLog,"\n ***INSIDE  ER_EW*******  check Query*** --------------------LifeCycValSetEW-----");fflush(CascaveLog);

        int		n_entries	=	2;
		int		n_found=	0;
		char 	*qry_part_entries[2] = {"Item ID","Revision"};
		char 	*qry_part_values[2] = {partnumber,TrevisionS};

				ITKCALL(QRY_find2("Item Revision...", &queryPart));
				ITKCALL(QRY_execute(queryPart, n_entries, qry_part_entries, qry_part_values, &n_found, &results));
	         	fprintf(CascaveLog,"\nNumber of ERC Release and Above rev of part  [%s]found : [%d]\n",partnumber,n_found);fflush(CascaveLog);

			for (iii = 0; iii < n_found; iii++)
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id1);
			fprintf(CascaveLog,"\n rev_id are  ---->%s", rev_id1);fflush(CascaveLog);														//diplay the previous revision

			AOM_UIF_ask_value(results[iii],"release_status_list",&lifecycle_state);fflush(stdout);
			fprintf(CascaveLog,"\n Its ReleaseStatus_Name==%s\n",lifecycle_state);fflush(CascaveLog);

		    /*if((tc_strstr(lifecycle_state,"ERC Released")!=NULL) ||(tc_strstr(lifecycle_state,"APLC Working")!=NULL)|| (tc_strstr(lifecycle_state,"APLC Review")!=NULL) ||
			(tc_strstr(lifecycle_state,"APLC Released")!=NULL)||(tc_strstr(lifecycle_state,"STDSIC Working")!=NULL)||(tc_strstr(lifecycle_state,"STDSIC Released")!=NULL) ||(tc_strstr(lifecycle_state,"APLA Working")!=NULL)|| (tc_strstr(lifecycle_state,"APLA Review")!=NULL) ||
			(tc_strstr(lifecycle_state,"APLA Released")!=NULL)||(tc_strstr(lifecycle_state,"STDSIA Working")!=NULL)||(tc_strstr(lifecycle_state,"STDSIA Released")!=NULL))
			{
			ITEM_ask_rev_id ( results[iii], rev_id2);
			printf("ERC Above Release_Status_Name of required part*********==%s",rev_id2);fflush(stdout);
			VCRevision_tag = results[iii];
			}*/
			if((tc_strstr(lifecycle_state,"ERC Released")!=NULL) ||(tc_strstr(lifecycle_state,usrinf4)!=NULL)|| (tc_strstr(lifecycle_state,usrinf5)!=NULL) ||
			(tc_strstr(lifecycle_state,usrinf6)!=NULL)||(tc_strstr(lifecycle_state,usrinf7)!=NULL)||(tc_strstr(lifecycle_state,usrinf8)!=NULL) ||(tc_strstr(lifecycle_state,usrinf3)!=NULL) )
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id2);
			fprintf(CascaveLog,"ERC Above Release_Status_Name of required part*********==%s",rev_id2);fflush(CascaveLog);
			VCRevision_tag = results[iii];
			}
			break;

			 //printf("\n\n");fflush(stdout);
			}

		}
		 else if(tc_strcmp(revision,"-")==0)
		{
		int		n_entries	=	1;
		int    	num_to_sort =	1;
		int  	orders[]  	=	{2};
		int		n_found=	0;
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[1] = {"Item ID",};
		char 	*qry_part_values[1] = {partnumber};

		QRY_find2("Item Revision...", &queryPart);
		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
		fprintf(CascaveLog,"\nNumber of ERC Release and Above rev of part  [%s]found****** : [%d]\n",partnumber,n_found);fflush(CascaveLog);


			for (iii = 0; iii < n_found; iii++)
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id1);
			fprintf(CascaveLog,"\n rev_id are  ---->%s", rev_id1);fflush(CascaveLog);														//diplay the previous revision

			AOM_UIF_ask_value(results[iii],"release_status_list",&lifecycle_state);fflush(stdout);
			fprintf(CascaveLog,"\n Its ReleaseStatus_Name==%s\n",lifecycle_state);fflush(CascaveLog);


			if((tc_strstr(lifecycle_state,"ERC Released")!=NULL) ||(tc_strstr(lifecycle_state,usrinf4)!=NULL)|| (tc_strstr(lifecycle_state,usrinf5)!=NULL) ||
			(tc_strstr(lifecycle_state,usrinf6)!=NULL)||(tc_strstr(lifecycle_state,usrinf7)!=NULL)||(tc_strstr(lifecycle_state,usrinf8)!=NULL) ||(tc_strstr(lifecycle_state,usrinf3)!=NULL))

			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id2);
			fprintf(CascaveLog,"ERC Above Release_Status_Name of required ********part==%s",rev_id2);fflush(CascaveLog);
			VCRevision_tag = results[iii];

			}
			break;
			 //printf("\n\n");fflush(stdout);

			}
		}
      	else  /* if (  (!nlsIsStrNull (partnumber)) && (!nlsIsStrNull (revision))  )*/
		{
		if ((tc_strcmp(revision,"")==0)||(tc_strcmp(revision,"*")==0))
		{
         fprintf(CascaveLog," Item revision Input is empty or Not Proper:--Please Enter by Initial of Revision or by (-) :\n");fflush(CascaveLog);
		}
		else
		{
		fprintf(CascaveLog,"\n***** Else Initial *******\n");fflush(CascaveLog);
		Rev_NumCat	=	(char *)MEM_alloc(10);
		tc_strcpy(Rev_NumCat,revision);
		tc_strcat(Rev_NumCat,"*");
		fprintf(CascaveLog,"Rev_NumCat:%s\n", Rev_NumCat);fflush(CascaveLog);

		int		n_entries	=	2;
		int    	num_to_sort =	1;
		int		orders[]  	=	{2};
		int		n_found		=	0;
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[2] = {"Item ID","Revision"};
		char 	*qry_part_values[2] = {partnumber,Rev_NumCat,};

		QRY_find2("Item Revision...", &queryPart);
		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
		fprintf(CascaveLog,"\nNumber of ERC Release and Above rev of ******part  [%s]found : [%d]\n",partnumber,n_found);fflush(CascaveLog);


			for (iii = 0; iii < n_found; iii++)
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id1);
			fprintf(CascaveLog,"\n rev_id are  ---->%s", rev_id1);fflush(CascaveLog);														//diplay the previous revision

			AOM_UIF_ask_value(results[iii],"release_status_list",&lifecycle_state);fflush(stdout);
			fprintf(CascaveLog,"\n Its ReleaseStatus_Name==%s\n",lifecycle_state);fflush(CascaveLog);


			if((tc_strstr(lifecycle_state,"ERC Released")!=NULL) ||(tc_strstr(lifecycle_state,usrinf4)!=NULL)|| (tc_strstr(lifecycle_state,usrinf5)!=NULL) ||
			(tc_strstr(lifecycle_state,usrinf6)!=NULL)||(tc_strstr(lifecycle_state,usrinf7)!=NULL)||(tc_strstr(lifecycle_state,usrinf8)!=NULL) ||(tc_strstr(lifecycle_state,usrinf3)!=NULL))
				{
				ITEM_ask_rev_id2 ( results[iii], &rev_id2);
				fprintf(CascaveLog,"******ERC Above Release_Status_Name of required part1==%s",rev_id2);fflush(CascaveLog);
				VCRevision_tag = results[iii];
			   }
			   break;
			}
		   }
		}
	}

	fprintf(CascaveLog,"\n\nItem ID **&  item_revision_id for BOM Expansion CAME FROM ELSE : %s\t%s\n",partnumber,rev_id2);fflush(CascaveLog);

	 if(rev_id2 !=NULL)
	 {
		
           Traverse_bom(partnumber,rev_id2,ER_EW,Plant,usrinf2,usrinf1);
		
      

     AOM_UIF_ask_value(VCRevision_tag,"owning_group",&Group);fflush(stdout);
	 fprintf(CascaveLog,"\n owning_group of part_REV is  ---->%s\n", Group);fflush(CascaveLog);

	 	 AOM_UIF_ask_value(VCRevision_tag,"owning_user",&User);fflush(stdout);
		 fprintf(CascaveLog,"\n owning_user of part_REV is  ---->%s\n", User);fflush(CascaveLog);

	     /*if(tc_strstr(Group,"dba")!=NULL)
		 {
             if  (tc_strstr(Plant,"PUN")!=NULL)
			 {
			fprintf(CascaveLog,"\n Part Revision Belongs to APL Group So ****** BOMViewClosureRuleAPLC****** applied\n");fflush(CascaveLog);
		    tc_strcpy(closureRuleName,usrinf1);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(CascaveLog,"\n closure_tags1:[%d]\n",n_closure_tags);fflush(CascaveLog);
		    }
            else if  (tc_strstr(Plant,"AHD")!=NULL)
			 {
			fprintf(CascaveLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPLA****** applied\n");fflush(CascaveLog);
		    tc_strcpy(closureRuleName,usrinf1);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(CascaveLog,"\n closure_tags1:[%d]\n",n_closure_tags);fflush(CascaveLog);
		    }
			else
		   {
			fprintf(CascaveLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ****** applied\n" );fflush(CascaveLog);
		    tc_strcpy(closureRuleName,usrinf1);
	        scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(CascaveLog,"\n closure_tags2:[%d]\n",n_closure_tags);fflush(CascaveLog);
			}
		 }*/
		if(tc_strcmp(ER_EW,"ER")==0)
		{
			if(tc_strstr(Plant,"PUN")!=NULL)
			{
				fprintf(CascaveLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPLC******/applied\n");fflush(CascaveLog);
				tc_strcpy(closureRuleName,usrinf1);
				scope=PIE_TEAMCENTER;
				ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
				fprintf(CascaveLog,"\n closure_tags3:[%d]\n",n_closure_tags);fflush(CascaveLog);
			}
			else if(tc_strstr(Plant,"AHD")!=NULL)
			{
				fprintf(CascaveLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPLA******/applied\n");fflush(CascaveLog);
				tc_strcpy(closureRuleName,usrinf1);
				scope=PIE_TEAMCENTER;
				ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
				fprintf(CascaveLog,"\n closure_tags3:[%d]\n",n_closure_tags);fflush(CascaveLog);
			}
			else
			{
				fprintf(CascaveLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ******/applied\n" );fflush(CascaveLog);
				tc_strcpy(closureRuleName,usrinf1);
				scope=PIE_TEAMCENTER;
				ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
				fprintf(CascaveLog,"\n closure_tags4:[%d]\n",n_closure_tags);fflush(CascaveLog);
			}
		}
		else
        {
			fprintf(CascaveLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ******/applied\n" );fflush(CascaveLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleERC");
		    fprintf(CascaveLog,"\n**********closureRuleName*********** \n",closureRuleName);fflush(CascaveLog);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(CascaveLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(CascaveLog);
		 }
		


 																	//function call to get BOM line and its child lines upto end lines

	fprintf(CascaveLog,"\n----------------------------------------------For getting Tags for all child parts-----------------------------------------\n");fflush(CascaveLog);
	ifail=  BOM_create_window(&tagBOMwindow);CHECK_FAIL;
	ifail = BOM_set_window_pack_all(tagBOMwindow, true);CHECK_FAIL;


	if (tc_strcmp(ER_EW,"EW")==0)
    {
		fprintf(CascaveLog,"\n Latest Working Applied");fflush(CascaveLog);
	ifail = CFM_find("Latest Working", &tagRule);CHECK_FAIL;
    }
  else if((tc_strstr(Plant,"PUN")!=NULL))
	{
	fprintf(CascaveLog,"\n ERC release Applied");fflush(CascaveLog);
	ifail = CFM_find(usrinf2, &tagRule);CHECK_FAIL;
	}
  else if((tc_strstr(Plant,"AHD")!=NULL))
	{
	fprintf(CascaveLog,"\n ERC release Applied");fflush(CascaveLog);
	ifail = CFM_find(usrinf2, &tagRule);CHECK_FAIL;
	}
  else 
	{
	fprintf(CascaveLog,"\n ERC release Applied");fflush(CascaveLog);
	ifail = CFM_find(usrinf2, &tagRule);CHECK_FAIL;
	}


	ifail = BOM_set_window_config_rule( tagBOMwindow, tagRule );CHECK_FAIL;

	if(n_closure_tags==1)
	{
		closure_tag=closure_tags[0];
	}
	ITKCALL(BOM_window_set_closure_rule(tagBOMwindow,closure_tag,0,NULL,NULL));
	ITKCALL(BOM_save_window (tagBOMwindow));
	ifail=BOM_set_window_top_line(tagBOMwindow, NULLTAG, VCRevision_tag, NULLTAG, &tagBOMline);	CHECK_FAIL;

    fprintf(CascaveLog,"\n\n\n**********************************NOW FOR CHILD TAGS TO PRINT******************************\n\n\n");fflush(CascaveLog);
	ifail = findChildTag(tagBOMline,getList,&StrctInt);														//function call to get BOM line tag and its child lines tags upto end lines

	fprintf(CascaveLog,"\n Total Parts Found from BOM Line count --->[%d]\n", count); fflush(CascaveLog);
	fprintf(CascaveLog,"\n Total Parts tags Found from Top to Bottom--->[%d]\n\n", StrctInt); fflush(CascaveLog);


	fprintf(CascaveLog,"\n\n\n**********************************NOW TO PRINT IN SOAP UI******************************\n\n\n");fflush(CascaveLog);



					aString_test->__size = StrctInt;
					aString_test->__plmPartDetail	=	 malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__plmPartDetail) );
					if(StrctInt>0)
					{
					for(i=0;i<StrctInt;i++)
						{
							cnt		=	i+1;
							fprintf(CascaveLog,"\nBOM_Part Number===>%s\n",getList[cnt].PartNumber);fflush(CascaveLog);

						     length	=	strlen(getList[cnt].Level);
							 aString_test->__plmPartDetail[i].PLevel = malloc(length* sizeof(char*)+5);
							 if(((getList[cnt].Level)!=NULL)&&(length>0))
							{
							strcpy(aString_test->__plmPartDetail[i].PLevel, getList[cnt].Level);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].PLevel);fflush(CascaveLog);
							}else
							{
							strcpy(aString_test->__plmPartDetail[i].PLevel,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}


							length	=	strlen(getList[cnt].PartNumber);
							aString_test->__plmPartDetail[i].PartNum = malloc(length* sizeof(char*)+5);
							 if(((getList[cnt].PartNumber)!=NULL)&&(length>0))
                            {
							strcpy(aString_test->__plmPartDetail[i].PartNum, getList[cnt].PartNumber);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].PartNum);fflush(CascaveLog);
		                    }else
							{
							strcpy(aString_test->__plmPartDetail[i].PartNum,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}


						   length	=	strlen(getList[cnt].PartRev);
                           aString_test->__plmPartDetail[i].Revision = malloc(length* sizeof(char*)+5);
							if(((getList[cnt].PartRev)!=NULL)&&(length>0))
                            {
							strcpy(aString_test->__plmPartDetail[i].Revision, getList[cnt].PartRev);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].Revision);fflush(CascaveLog);
							}else
							{
							strcpy(aString_test->__plmPartDetail[i].Revision,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}

						    length	=	strlen(getList[cnt].PartSeq);
                           aString_test->__plmPartDetail[i].Sequence = malloc(length* sizeof(char*)+5);
							if(((getList[cnt].PartSeq)!=NULL)&&(length>0))
                            {
							strcpy(aString_test->__plmPartDetail[i].Sequence, getList[cnt].PartSeq);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].Sequence);fflush(CascaveLog);
							}else
							{
							strcpy(aString_test->__plmPartDetail[i].Sequence,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}


							length	=	strlen(getList[cnt].PartWeight);
						    aString_test->__plmPartDetail[i].Weight = malloc(length* sizeof(char*)+5);////
						    if(((getList[cnt].PartWeight)!=NULL)&&(length>0))
							{
							strcpy(aString_test->__plmPartDetail[i].Weight, getList[cnt].PartWeight);////
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].Weight);fflush(CascaveLog);///
                            }else
							{
							strcpy(aString_test->__plmPartDetail[i].Weight,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
                            }


							 length	=	strlen(getList[cnt].PartSurfArea);
							 aString_test->__plmPartDetail[i].SurArea = malloc(length* sizeof(char*)+5);////
							 if(((getList[cnt].PartSurfArea)!=NULL)&&(length>0))
							{
							 strcpy(aString_test->__plmPartDetail[i].SurArea, getList[cnt].PartSurfArea);
							 fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].SurArea);fflush(CascaveLog);
							 }
							 else
							{
							strcpy(aString_test->__plmPartDetail[i].SurArea,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}

							 length	=	strlen(getList[cnt].PartVolume);
							 aString_test->__plmPartDetail[i].Volume = malloc(length* sizeof(char*)+5);////
							  if(((getList[cnt].PartVolume)!=NULL)&&(length>0))
							{
								strcpy(aString_test->__plmPartDetail[i].Volume, getList[cnt].PartVolume);
								fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].Volume);fflush(CascaveLog);
							 }
							 else
							 {
								 strcpy(aString_test->__plmPartDetail[i].Volume,"NA");
								 fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							  }

                             length	=	strlen(getList[cnt].PartCS);
							aString_test->__plmPartDetail[i].CS = malloc(length* sizeof(char*)+5);////
							 if(((getList[cnt].PartCS)!=NULL)&&(length>0))
							{
							strcpy(aString_test->__plmPartDetail[i].CS, getList[cnt].PartCS);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].CS);fflush(CascaveLog);
							}
							else
							{
							strcpy(aString_test->__plmPartDetail[i].CS,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}

                            length	=	strlen(getList[cnt].PartMaterial);
							aString_test->__plmPartDetail[i].Material = malloc(length* sizeof(char*)+5);////
							if(((getList[cnt].PartMaterial)!=NULL)&&(length>0))
							{
								strcpy(aString_test->__plmPartDetail[i].Material,getList[cnt].PartMaterial);
								fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].Material);fflush(CascaveLog);
							}
							else
							{
							strcpy(aString_test->__plmPartDetail[i].Material,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}

                            length	=	strlen(getList[cnt].PartDesc);
							aString_test->__plmPartDetail[i].Descrpt = malloc(length* sizeof(char*)+5);////
							if(((getList[cnt].PartDesc)!=NULL)&&(length>0))
							{
							strcpy(aString_test->__plmPartDetail[i].Descrpt,getList[cnt].PartDesc);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].Descrpt);fflush(CascaveLog);
							}
							else
							{
							strcpy(aString_test->__plmPartDetail[i].Descrpt,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}

                            length	=	strlen(getList[cnt].PartProjCode);
							aString_test->__plmPartDetail[i].ProjCode = malloc(length* sizeof(char*)+5);////
							if(((getList[cnt].PartProjCode)!=NULL)&&(length>0))
								{
								strcpy(aString_test->__plmPartDetail[i].ProjCode,getList[cnt].PartProjCode);
							    fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].ProjCode);fflush(CascaveLog);
							    }
								else
								{
									strcpy(aString_test->__plmPartDetail[i].ProjCode,"NA");
									fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
								}

                            length	=	strlen(getList[cnt].PartProjDesc);
							aString_test->__plmPartDetail[i].ProjDesc = malloc(length* sizeof(char*)+5);///
                            if(((getList[cnt].PartProjDesc)!=NULL)&&(length>0))
							{
								strcpy(aString_test->__plmPartDetail[i].ProjDesc,getList[cnt].PartProjDesc);
								fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].ProjDesc);fflush(CascaveLog);
							}
							else
							{
							strcpy(aString_test->__plmPartDetail[i].ProjDesc,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}

                            length	=	strlen(getList[cnt].PEnvDia);
							aString_test->__plmPartDetail[i].PEnvDia = malloc(length* sizeof(char*)+5);////
							if(((getList[cnt].PEnvDia)!=NULL)&&(length>0))
							{
							strcpy(aString_test->__plmPartDetail[i].PEnvDia,getList[cnt].PEnvDia);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].PEnvDia);fflush(CascaveLog);
							}
							else
							{
							strcpy(aString_test->__plmPartDetail[i].PEnvDia,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}


                            length	=	strlen(getList[cnt].PThickness);
							aString_test->__plmPartDetail[i].Thickness = malloc(length* sizeof(char*)+5);////
							if(((getList[cnt].PThickness)!=NULL)&&(length>0))
							{
							strcpy(aString_test->__plmPartDetail[i].Thickness,getList[cnt].PThickness);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].Thickness);fflush(CascaveLog);
							}
							else
							{
							strcpy(aString_test->__plmPartDetail[i].Thickness,"NA");
						    fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}

                            length	=	strlen(getList[cnt].PParttype);
							aString_test->__plmPartDetail[i].Parttype = malloc(length* sizeof(char*)+5);////
							if(((getList[cnt].PParttype)!=NULL)&&(length>0))
							{
							strcpy(aString_test->__plmPartDetail[i].Parttype,getList[cnt].PParttype);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].Parttype);fflush(CascaveLog);
							}
							else
							{
								strcpy(aString_test->__plmPartDetail[i].Parttype,"NA");
								fprintf(CascaveLog,"\nNA");fflush(CascaveLog);
							}

                            length	=	strlen(getList[cnt].Qty);
							aString_test->__plmPartDetail[i].c_Qty = malloc(length* sizeof(char*)+5);////
							if(((getList[cnt].Qty)!=NULL)&&(length>0))
							{
							strcpy(aString_test->__plmPartDetail[i].c_Qty,getList[cnt].Qty);
							fprintf(CascaveLog,"\n%s",aString_test->__plmPartDetail[i].c_Qty);fflush(CascaveLog);
							}
							else
							{
							strcpy(aString_test->__plmPartDetail[i].c_Qty,"NA");
						    fprintf(CascaveLog,"\nNA\n");fflush(CascaveLog);
							}

						}
						fprintf(CascaveLog,"\n---------------------------------------------END CODE----------------------------------------------------------- \n"); fflush(CascaveLog);
					}
	      }
	       else
			{
			fprintf(CascaveLog,"\n\n  Exits  item_revision_id for BOM Expansion ");fflush(CascaveLog);
			}



	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
	return SOAP_OK;
}
;