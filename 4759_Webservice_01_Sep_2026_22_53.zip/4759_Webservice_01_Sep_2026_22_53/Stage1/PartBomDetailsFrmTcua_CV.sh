#!/bin/ksh
. /user/omfprod/.bash_profile
echo  "---- Calling TCUA ITK for PartBom WEB SERVICE ----" > /tmp/CVWSPARTBOM.txt
echo $*
echo "Before calling cvprod shell" > /tmp/CVWSPARTBOM.txt
echo "Part number:"$1 >> /tmp/CVWSPARTBOM.txt
echo "Revision:"$2 >> /tmp/CVWSPARTBOM.txt
echo "Sequense:"$3 >> /tmp/CVWSPARTBOM.txt
echo "ER-EW:"$4 >> /tmp/CVWSPARTBOM.txt
echo "Plant:"$5 >> /tmp/CVWSPARTBOM.txt
read 3
if [ "$3" = "?" ]; then
    partNo=$1
    partRev=$2
    partSeq="TBD"
    er_EW=$4
    plantVal=$5
    echo "partNo:"$partNo >> /tmp/CVWSPARTBOM.txt
    echo "partRev:"$partRev >> /tmp/CVWSPARTBOM.txt
    echo "partSeq:"$partSeq >> /tmp/CVWSPARTBOM.txt
    echo "er_EW:"$er_EW >> /tmp/CVWSPARTBOM.txt
    echo "plantVal:"$plantVal >> /tmp/CVWSPARTBOM.txt
    #3 = "-"
    echo "Sequense ? found:"$3 >> /tmp/CVWSPARTBOM.txt
else
    partNo=$1
    partRev=$2
    partSeq="TBD"
    er_EW=$4
    plantVal=$5
    echo "partNo:"$partNo >> /tmp/CVWSPARTBOM.txt
    echo "partRev:"$partRev >> /tmp/CVWSPARTBOM.txt
    echo "partSeq:"$partSeq >> /tmp/CVWSPARTBOM.txt
    echo "er_EW:"$er_EW >> /tmp/CVWSPARTBOM.txt
    echo "plantVal:"$plantVal >> /tmp/CVWSPARTBOM.txt
    echo "Sequense ? not found:" >> /tmp/CVWSPARTBOM.txt
fi
#ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/QryPartBomDetailsInTCUA_CV.sh ${1} ${2} ${3} ${4} ${5}"
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/QryPartBomDetailsInTCUA_CV.sh $partNo $partRev $partSeq $er_EW $plantVal"
echo "After calling cvprod shell" >> /tmp/CVWSPARTBOM.txt
if [ -s "/proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUACV_PARTBOMDETAIL.txt" ]; then
lineCnt=`cat "/proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUACV_PARTBOMDETAIL.txt" | wc -l`
if [ $lineCnt -gt 0 ]; then
mv /proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUACV_PARTBOMDETAIL.txt /plmuv_logs/omfprod/logs/PFIRST_TCE_TCUA_PART/.
ls -ltr /plmuv_logs/omfprod/logs/PFIRST_TCE_TCUA_PART/$1_TCUACV_PARTBOMDETAIL.txt
fi
fi

