#include "soapH.h"								/* get the gSOAP-generated definitions */
#include "tm_NewAPLRlzdMonitoring.nsmap"		 /* get the gSOAP-generated namespace bindings */

 #define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
//#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <fclasses/tc_string.h>
//#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define Debug TRUE
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}

int X;
int status;
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char getPrevDate(int* day, int* month, int* year)
{
	char	Previous_date[30];
    if (*day == 1)
		{
        if (*month == 4 || *month == 6 || *month == 9 || *month == 11)
		{
            *day = 31;
            *month = *month - 1;
        }
        else if (*month == 3)
		{
            if (*year % 4 == 0)
                *day = 29;
            else
                *day = 28;
            *month = *month - 1;
        }
        else if (*month == 1)
		{
            *day = 31;
            *month = 12;
            *year = *year - 1;
        }
        else if (*month == 2)
		{
            *day = 31;
            *month = *month - 1;
        }
        else
		{
            *day = 30;
            *month = *month - 1;
        }
    }
	else
	{
        *day = *day - 1;
    }
}
void getMonthinInt(char *Month)
{
	if(strcmp(Month,"Jan")==0)
	{
		strcpy(Month,"1");
	}
	else if(strcmp(Month,"Feb")==0)
	{
		strcpy(Month,"2");
	}
	else if(strcmp(Month,"Mar")==0)
	{
		strcpy(Month,"3");
	}
	else if(strcmp(Month,"Apr")==0)
	{
		strcpy(Month,"4");
	}
	else if(strcmp(Month,"May")==0)
	{
		strcpy(Month,"5");
	}
	else if(strcmp(Month,"Jun")==0)
	{
		strcpy(Month,"6");
	}
	else if(strcmp(Month,"Jul")==0)
	{
		strcpy(Month,"7");
	}
	else if(strcmp(Month,"Aug")==0)
	{
		strcpy(Month,"8");
	}
	else if(strcmp(Month,"Sep")==0)
	{
		strcpy(Month,"9");
	}
	else if(strcmp(Month,"Oct")==0)
	{
		strcpy(Month,"10");
	}
	else if(strcmp(Month,"Nov")==0)
	{
		strcpy(Month,"11");
	}
	else if(strcmp(Month,"Dec")==0)
	{
		strcpy(Month,"12");
	}
}
void GetMonthinStr(char *strMon)
{
	if(strcmp(strMon,"01")==0 || strcmp(strMon,"1")==0 )
	{
		strcpy(strMon,"Jan");
	}
	else if(strcmp(strMon,"02")==0 || strcmp(strMon,"2")==0)
	{
		strcpy(strMon,"Feb");
	}
	else if(strcmp(strMon,"03")==0 || strcmp(strMon,"3")==0)
	{
		strcpy(strMon,"Mar");
	}
	else if(strcmp(strMon,"04")==0 || strcmp(strMon,"4")==0)
	{
		strcpy(strMon,"Apr");
	}
	else if(strcmp(strMon,"05")==0 || strcmp(strMon,"5")==0)
	{
		strcpy(strMon,"May");
	}
	else if(strcmp(strMon,"06")==0 || strcmp(strMon,"6")==0)
	{
		strcpy(strMon,"Jun");
	}
	else if(strcmp(strMon,"07")==0 || strcmp(strMon,"7")==0)
	{
		strcpy(strMon,"Jul");
	}
	else if(strcmp(strMon,"08")==0 || strcmp(strMon,"8")==0)
	{
		strcpy(strMon,"Aug");
	}
	else if(strcmp(strMon,"09")==0 || strcmp(strMon,"9")==0)
	{
		strcpy(strMon,"Sep");
	}
	else if(strcmp(strMon,"10")==0)
	{
		strcpy(strMon,"Oct");
	}
	else if(strcmp(strMon,"11")==0)
	{
		strcpy(strMon,"Nov");
	}
	else if(strcmp(strMon,"12")==0)
	{
		strcpy(strMon,"Dec");
	}
}
char* GetSrNum(int num)
{
	char *Srl = NULL;
	if(num==1)
	{
		Srl = "1";
	}
	else if(num==2)
	{
		Srl = "2'";
	}
	else if(num==3)
	{
		Srl = "3";
	}
	else if(num==4)
	{
		Srl = "4";
	}
	else if(num==5)
	{
		Srl = "5";
	}
	else if(num==6)
	{
		Srl = "6";
	}
	else if(num==7)
	{
		Srl = "7";
	}
	else if(num==8)
	{
		Srl = "8";
	}
	else if(num==9)
	{
		Srl = "9";
	}
	else if(num==10)
	{
		Srl = "10";
	}
	else if(num==11)
	{
		Srl = "11";
	}
	else if(num==12)
	{
		Srl = "12";
	}
	else if(num==13)
	{
		Srl = "13";
	}
	else if(num==14)
	{
		Srl = "14";
	}
	else if(num==15)
	{
		Srl = "15";
	}
	return Srl;
}

int ns__getStddmlfsullDataInfo(struct soap* soap, char *StrDateInp,char *StrPlantInp ,struct ns__CharArray1 *aString_Ret)
{

	char *previousDate[30];
	char *PreviousDateInput = NULL;
	char *currentDateTime = NULL;
	FILE     *inputfile ;
	char*	FileNeme=	NULL;
	char*	qry_entry[3] = {"ID","from","To"};
	char*	qry_entry1[3] = {"ID","from","To"};
	char	**qry_values= (char **) MEM_alloc(5 * sizeof(char *));
	char	**qry_values1= (char **) MEM_alloc(5 * sizeof(char *));
	char	*Item_Plant= (char *) MEM_alloc(5 * sizeof(char *));
	int	entry = 3;
	int	entry1 = 3;
	int	NumOfCnt = 2;
	int SrNum = 0;

	char *Srl_Num;
	char *Dml_Num;
	char *Task_Num;
	char *Design_Grp;
	char *DrStatus;
	char *ERCRlzDt;
	char *DMLStatus;
	char *TaskStatus;
	char *APLPlanner;
	char *APLAssgnDate;
	char *APLPlannerDate;
	char *APLReviwr;
	char *APLReviwrDate;
	char *APLRlzdDate;
	char *ProjectCode;
	char *DML_Desc;


	char *day = NULL;
	char *month = NULL;
	char *inputDate = NULL;
	char *year = NULL;
	char *StrPlntNam = NULL;
	char *Dmlname = NULL;
	char *DsgnGrp = NULL;
	char *StrDmlExt = NULL;
	char *TaskName = NULL;
	char *APlRelesDate = NULL;
	char *ObjectType = NULL;
	char *Designgroup = NULL;
	char *relName = NULL;
	char *Reviwer = NULL;
	char *PropertyName = NULL;
	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	int dy,mt,yr=0;
	int controlObjfound =0;
	int controlObjfound1 =0;
	int i,j,k=0;
	int TaskCount=0;
	int TaskCount1=0;
	int size =0;

	date_t			Release_date;

	tc_strdup(StrDateInp,&inputDate);
	tag_t	queryTag	= NULLTAG;
	tag_t	queryTag1	= NULLTAG;
	tag_t	ActualIntrTsks	= NULLTAG;
	tag_t	LatestDmltag	= NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	tag_t	tsk_dml_rel_type1	= NULLTAG;
	tag_t	Tasktag	= NULLTAG;
	tag_t	release	= NULLTAG;
	tag_t	lastRel	= NULLTAG;
	tag_t	DmlTag	= NULLTAG;
	tag_t	DmlTag1= NULLTAG;
	tag_t	*List_Of_objects	= NULLTAG;
	tag_t	*List_Of_objects1	= NULLTAG;
	tag_t	*ActuatedInteractiveTsks	= NULLTAG;
	tag_t	*Tasks	= NULLTAG;
	tag_t	*Tasks1	= NULLTAG;
	tag_t	*status_list	= NULLTAG;

	if(tc_strstr(inputDate,"/")!=NULL)
	{
		strcat(inputDate,"/");
		day = strtok(inputDate,"/");
		month = strtok(NULL,"/");
		year = strtok(NULL,"/");
	}
	else if(tc_strstr(inputDate,"-")!=NULL)
	{
		strcat(inputDate,"-");
		day = strtok(inputDate,"-");
		month = strtok(NULL,"-");
		year = strtok(NULL,"-");
	}


	if (tc_strcmp(FileNeme,"NULL")==0) MEM_free(FileNeme);
	FileNeme=(char *)MEM_alloc(3000);
	if (tc_strcmp(PreviousDateInput,"NULL")==0) MEM_free(PreviousDateInput);
	PreviousDateInput=(char *)MEM_alloc(3000);

	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE);
	ITK_auto_login();
	ITK_set_journalling( TRUE );

	tc_strcpy(Item_Plant,"");
	tc_strcpy(Item_Plant,"*");
	tc_strcat(Item_Plant,StrPlantInp);

	tc_strcpy(FileNeme,"");
	tc_strcpy(FileNeme,"/user/tcuaadev/devgroups/Srikanth_Beerapor/APL_DML_Released_Monitoring/");
	tc_strcat(FileNeme,"Log_file");
	tc_strcat(FileNeme,".txt");

	inputfile=fopen(FileNeme,"a+");
	if(inputfile == NULL)

	{
		printf("File not Opened\n");
	}
		else
	{
			printf("file opend....!");
	}
	dy =atoi(day);
	fprintf(inputfile,"month is %s\n",month);
	getMonthinInt(month);
	mt =atoi(month);
	yr =atoi(year);

	fprintf(inputfile,"Day = %s\n",day);
	fprintf(inputfile,"Month = %s\n",month);
	fprintf(inputfile,"year = %s\n",year);
	getPrevDate(&dy, &mt, &yr);
	sprintf(strDay,"%d",dy);
	sprintf(strMon,"%d",mt);
	sprintf(strYear,"%d",yr);

	fprintf(inputfile,"Given Date input %s\n",StrDateInp);


	tc_strcpy(PreviousDateInput,"");
	tc_strcat(PreviousDateInput,strDay);
	tc_strcat(PreviousDateInput,"-");
	GetMonthinStr(strMon);
	tc_strcat(PreviousDateInput,strMon);
	tc_strcat(PreviousDateInput,"-");
	tc_strcat(PreviousDateInput,strYear);
	fprintf(inputfile,"Previous Date Input  %s\n",PreviousDateInput);
	fprintf(inputfile,"User Entered Plant is  %s\n",Item_Plant);

	//size

	if(QRY_find2("DML Released Between Date", &queryTag1));
	if(queryTag1)
	{
		qry_values1[0]=Item_Plant;
		qry_values1[1]=PreviousDateInput;
		qry_values1[2]=StrDateInp;

		if(QRY_execute(queryTag1, entry1, qry_entry1, qry_values1, &controlObjfound1, &List_Of_objects1));
		fprintf(inputfile,"number of object found  %d\n",controlObjfound1);
		if(controlObjfound1>0)
		{
			for(i=0;i<controlObjfound1;i++)
			{
				DmlTag1 = List_Of_objects1[i];
				GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type1);
				GRM_list_secondary_objects_only(DmlTag1,tsk_dml_rel_type1,&TaskCount1,&Tasks1);

				size = size + TaskCount1;
			}
		}
	}
	fprintf(inputfile,"Final number of object/Task found  for given input is %d\n",size);

	aString_Ret->__size = size;

	aString_Ret->__ptrRlzDmlData = (struct ns__plmStdDmlData *) malloc((aString_Ret->__size + 100000) * sizeof(struct ns__plmStdDmlData));


	if(QRY_find2("DML Released Between Date", &queryTag));
	if(queryTag)
	{
		qry_values[0]=Item_Plant;
		qry_values[1]=PreviousDateInput;
		qry_values[2]=StrDateInp;

		if(QRY_execute(queryTag, entry, qry_entry, qry_values, &controlObjfound, &List_Of_objects));
		fprintf(inputfile,"number of object found  %d\n",controlObjfound);
		if(controlObjfound>0)
		{
			for(i=0;i<controlObjfound;i++)
			{
				DmlTag = List_Of_objects[i];

				AOM_ask_value_string(DmlTag,"item_id",&Dml_Num);
				fprintf(inputfile,"DML Number is  %s\n",Dml_Num);
					AOM_UIF_ask_value(DmlTag,"t5_crdesigngroup",&Design_Grp);
					fprintf(inputfile,"Design Group is  %s\n",Design_Grp);

					AOM_ask_value_string(DmlTag,"t5_cDRstatus",&DrStatus);
					fprintf(inputfile,"DML DR/AR status is %s\n",DrStatus);

					AOM_ask_value_string(DmlTag,"object_name",&DML_Desc);
					fprintf(inputfile,"DML Description is %s\n",DML_Desc);

					AOM_UIF_ask_value(DmlTag,"release_status_list",&DMLStatus);
					fprintf(inputfile,"Task Release status %s\n",DMLStatus);

					AOM_ask_value_string(DmlTag,"t5_cprojectcode",&ProjectCode);
					fprintf(inputfile,"Project Code is %s\n",ProjectCode);

					GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
					GRM_list_secondary_objects_only(DmlTag,tsk_dml_rel_type,&TaskCount,&Tasks);
					fprintf(inputfile,"Total no of Task : %d\n",TaskCount);fflush(stdout);
					if(TaskCount>0)
					{
						for(j=0;j<TaskCount;j++)
						{
							Tasktag = Tasks[j];
							SrNum++;
							fprintf(inputfile,"Serial Number %d\n",SrNum);
							AOM_ask_value_string(Tasktag,"item_id",&Task_Num);
							fprintf(inputfile,"Task Number is %s\n",Task_Num);

							ITKCALL(AOM_UIF_ask_value(Tasktag,"date_released",&APLRlzdDate));
							fprintf(inputfile,"Task Number is %s\n",APLRlzdDate);
							if(tc_strstr(Task_Num,"PR"))
							{
								continue;
							}

							//WorkFlow
							ITKCALL(AOM_ask_value_tags(Tasktag,"fnd0ActuatedInteractiveTsks",&NumOfCnt,&ActuatedInteractiveTsks));
							fprintf(inputfile,"ActuatedInteractiveTsks count is : %d\n",NumOfCnt);fflush(stdout);
							if(NumOfCnt>0)
							{
								for(k=0;k<NumOfCnt;k++)
								{
									ActualIntrTsks = ActuatedInteractiveTsks[k];
									ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"object_type",&ObjectType));
									//fprintf(inputfile,"Object Type is : %s\n",ObjectType);fflush(stdout);

									ITKCALL(AOM_ask_value_string(ActualIntrTsks,"current_name",&PropertyName));
									fprintf(inputfile,"PropertyName Number is : %s\n",PropertyName);fflush(stdout);

									if(tc_strcmp(PropertyName,"Work On DML")==0 || tc_strcmp(PropertyName,"APL Task BreakDown")==0 || tc_strcmp(PropertyName,"AM DML WorkFlow")==0 )
									{
										ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0Performer",&APLPlanner));
										fprintf(inputfile,"APLPlanner Name is : %s\n",APLPlanner);fflush(stdout);

										ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0StartDate",&APLAssgnDate));
										fprintf(inputfile,"MbomStartDate Number is : %s\n",APLAssgnDate);fflush(stdout);

										ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0EndDate",&APLPlannerDate));
										fprintf(inputfile,"MbomEndDate Number is : %s\n",APLPlannerDate);fflush(stdout);
									}
									if(tc_strcmp(PropertyName,"Review The Changes Done By APL Planner")==0)
									{
										ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0Performer",&APLReviwr));
										fprintf(inputfile,"APLReviwr Name is : %s\n",APLReviwr);fflush(stdout);

										ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0EndDate",&APLReviwrDate));
										fprintf(inputfile,"APLReviwrDate Date is : %s\n",APLReviwrDate);fflush(stdout);
									}
								}
							}
							//WorkFlow

							ITKCALL(AOM_UIF_ask_value(Tasktag,"release_status_list",&TaskStatus));
							fprintf(inputfile,"Task Release status %s\n",TaskStatus);

							Srl_Num = GetSrNum(SrNum);

							fprintf(inputfile,"Serial Number is %s\n",Srl_Num);

							if(tc_strlen(Srl_Num)>0)
							{
								tc_strdup(Srl_Num,&aString_Ret->__ptrRlzDmlData[j].Srl_Num);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].Srl_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[j].Srl_Num);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].Srl_Num);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].Srl_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[j].Srl_Num);fflush(stdout);
							}

							if(tc_strlen(Dml_Num)>0)
							{
								tc_strdup(Dml_Num,&aString_Ret->__ptrRlzDmlData[j].Dml_Num);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].Dml_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[j].Dml_Num);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].Dml_Num);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].Dml_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[j].Dml_Num);fflush(stdout);
							}

							if(tc_strlen(Task_Num)>0)
							{
								tc_strdup(Task_Num,&aString_Ret->__ptrRlzDmlData[j].Task_Num);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].Task_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[j].Task_Num);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].Task_Num);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].Task_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[j].Task_Num);fflush(stdout);
							}

							if(tc_strlen(Design_Grp)>0)
							{
								tc_strdup(Design_Grp,&aString_Ret->__ptrRlzDmlData[j].Design_Grp);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].Design_Grp ==> %s\n",aString_Ret->__ptrRlzDmlData[j].Design_Grp);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].Design_Grp);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].Design_Grp ==> %s\n",aString_Ret->__ptrRlzDmlData[j].Design_Grp);fflush(stdout);
							}

							if(tc_strlen(DrStatus)>0)
							{
								tc_strdup(DrStatus,&aString_Ret->__ptrRlzDmlData[j].DrStatus);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].DrStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[j].DrStatus);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].DrStatus);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].DrStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[j].DrStatus);fflush(stdout);
							}


							tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].ERCRlzDt);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].ERCRlzDt ==> %s\n",aString_Ret->__ptrRlzDmlData[j].ERCRlzDt);fflush(stdout);

							if(tc_strlen(DMLStatus)>0)
							{
								tc_strdup(DMLStatus,&aString_Ret->__ptrRlzDmlData[j].DMLStatus);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].DMLStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[j].DMLStatus);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].DMLStatus);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].DMLStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[j].DMLStatus);fflush(stdout);
							}

							if(tc_strlen(TaskStatus)>0)
							{
								tc_strdup(TaskStatus,&aString_Ret->__ptrRlzDmlData[j].TaskStatus);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].TaskStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[j].TaskStatus);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].TaskStatus);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].TaskStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[j].TaskStatus);fflush(stdout);

							}

							if(tc_strlen(APLPlanner)>0)
							{
								tc_strdup(APLPlanner,&aString_Ret->__ptrRlzDmlData[j].APLPlanner);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLPlanner ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLPlanner);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].APLPlanner);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLPlanner ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLPlanner);fflush(stdout);
							}

							if(tc_strlen(APLAssgnDate)>0)
							{
								tc_strdup(APLAssgnDate,&aString_Ret->__ptrRlzDmlData[j].APLAssgnDate);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLAssgnDate ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLAssgnDate);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].APLAssgnDate);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLAssgnDate ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLAssgnDate);fflush(stdout);
							}

							if(tc_strlen(APLPlannerDate)>0)
							{
								tc_strdup(APLPlannerDate,&aString_Ret->__ptrRlzDmlData[j].APLPlannerDate);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLPlannerDate ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLPlannerDate);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].APLPlannerDate);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLPlannerDate ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLPlannerDate);fflush(stdout);
							}

							if(tc_strlen(APLReviwr)>0)
							{
								tc_strdup(APLReviwr,&aString_Ret->__ptrRlzDmlData[j].APLReviwr);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLReviwr ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLReviwr);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].APLReviwr);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLReviwr ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLReviwr);fflush(stdout);
							}

							if(tc_strlen(APLReviwrDate)>0)
							{
								tc_strdup(APLReviwrDate,&aString_Ret->__ptrRlzDmlData[j].APLReviwrDate);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLReviwrDate ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLReviwrDate);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].APLReviwrDate);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLReviwrDate ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLReviwrDate);fflush(stdout);
							}
							if(tc_strlen(APLRlzdDate)>0)
							{
								tc_strdup(APLRlzdDate,&aString_Ret->__ptrRlzDmlData[j].APLRlzdDate);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLRlzdDate ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLRlzdDate);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].APLRlzdDate);
									fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].APLRlzdDate ==> %s\n",aString_Ret->__ptrRlzDmlData[j].APLRlzdDate);fflush(stdout);
							}

							if(tc_strlen(ProjectCode)>0)
							{
								tc_strdup(ProjectCode,&aString_Ret->__ptrRlzDmlData[j].ProjectCode);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].ProjectCode ==> %s\n",aString_Ret->__ptrRlzDmlData[j].ProjectCode);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].ProjectCode);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].ProjectCode ==> %s\n",aString_Ret->__ptrRlzDmlData[j].ProjectCode);fflush(stdout);
							}

							if(tc_strlen(DML_Desc)>0)
							{
								tc_strdup(DML_Desc,&aString_Ret->__ptrRlzDmlData[j].DML_Desc);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].DML_Desc ==> %s\n",aString_Ret->__ptrRlzDmlData[j].DML_Desc);fflush(stdout);
							}
							else
							{
								tc_strdup("-",&aString_Ret->__ptrRlzDmlData[j].DML_Desc);
								fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[j].DML_Desc ==> %s\n",aString_Ret->__ptrRlzDmlData[j].DML_Desc);fflush(stdout);
							}

						}
					}
			}
		}
	}
	fclose(inputfile);
	return SOAP_OK;
}
;
int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new());										/* call the request dispatcher */
};