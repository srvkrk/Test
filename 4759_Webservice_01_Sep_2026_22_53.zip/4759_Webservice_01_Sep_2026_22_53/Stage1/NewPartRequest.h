//gsoap ns service name:				 NewPartRequest
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:DmlPdcaDetails
//gsoap ns service location:			 http://172.22.97.12:9080/cgi/NewPartRequest.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:NewPartRequest
//gsoap ns service method-documentation: Tests the Simple Web service


struct ns__ItemDet
{
   char *TM_PART_NO;
}
;
struct ns__CharArray1
{
   struct ns__ItemDet *__ptrItem;
   int __size;
}
;

int ns__getItemData(char *Item,struct ns__CharArray1 *aString_test);


