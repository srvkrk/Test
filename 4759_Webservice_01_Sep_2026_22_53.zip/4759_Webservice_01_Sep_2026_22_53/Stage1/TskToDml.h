//gsoap ns service name:			TskToDml
//gsoap ns service style:			rpc
//gsoap ns service namespace:		urn:TskToDml
//gsoap ns service location:			http://172.22.97.8:9010/cgi/TskToDml.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:		urn:TskToDml
//gsoap ns service method-documentation: Tests the Simple Web service
int ns__getTskToDml(char *tasknumber, char **Response);