#!/bin/bash

. /use/omfprod/.bash_profile

export ORACLE_HOME=/user/oraclnt/10ghome/lib

export PATH=/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass:$PATH

now="$(date +'%Y_%m_%d')"

echo "DML NUMBER : "$1
echo $now

WorkingPath="/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/"

echo {$WorkingPath}

cd ${WorkingPath}
mkdir $now
chmod 777 $now
FilePath=${WorkingPath}$now/
echo $FilePath

#${WorkingPath}NoPoTaskEpa_CV -u=aplloader -pf=/user/cvprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=$1 -fp=$FilePath
ssh cvprod@172.22.99.106 -n "sh ${WorkingPath}fetchNOPOPrtSTD_CV.sh $1 $FilePath"
echo "Shell Executed Successfully"
