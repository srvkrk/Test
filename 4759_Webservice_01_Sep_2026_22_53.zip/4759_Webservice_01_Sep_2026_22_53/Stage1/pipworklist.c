#include "soapH.h" /* get the gSOAP-generated definitions */
#include "pipworklist.nsmap" /* get the gSOAP-generated namespace bindings */
#include "tc/tc_startup.h"
#include "tc/tc_macros.h"
#include "qry.h"
#include "epm.h"
#include "sa.h"
#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}


extern int ITK_user_main(int argc, char *argv[])
{
   	
	return soap_serve(soap_new()); /* call the request dispatcher */  

} 
;


int getProjectTeam(tag_t msg_task,tag_t *team_tag)
{
	int ifail =0;
	tag_t rootTask			=NULLTAG;
	tag_t *attachments		=NULLTAG;
	int noAttachment =0;
	int t=0;
	char *object_type		= NULL;
	char *object_name		= NULL;
	tag_t project			= NULLTAG;
	tag_t projet_team_tag	= NULLTAG;
	char *project_ids		= NULL; 

	CALLAPI(EPM_ask_root_task(msg_task,&rootTask)); 		       
	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
	Write_To_Log("\nTarget Attachment:%d\n",noAttachment);

	if(noAttachment > 0)
	{
         for(t=0;t<noAttachment;t++)
	     {
			  AOM_ask_value_string(attachments[t],"object_type",&object_type);
			  if(strcmp(object_type,"T8_Project")==0)
		      {
				CALLAPI(AOM_ask_value_string(attachments[t],"object_name",&object_name));
				CALLAPI(AOM_ask_value_string(attachments[t],"project_ids",&project_ids));
				Write_To_Log("\nobject_name:%s Project ids:%s\n",object_name,project_ids);
	 			CALLAPI(PROJ_find(project_ids,&project)); 
				AOM_ask_value_tag(project,"project_team",&projet_team_tag);  
				*team_tag = projet_team_tag;
			    break;
			  }

		    
		 }  
	}

	return ifail;
}
 
int check_is_tertiary(tag_t team_tag,char *dept_name,int *is_tertiary)
{	
	int ifail =0;
	tag_t *mem		= NULLTAG;
	int num =0;
	tag_t group_tag = NULLTAG;
	tag_t role_tag  = NULLTAG;
	tag_t usertag	= NULLTAG;
	char group_name[SA_name_size_c+1];
	char role_name[SA_name_size_c+1];
	char *user_name	=NULL;
	int z = 0;

	if(team_tag != NULLTAG)
	{

		CALLAPI(AOM_ask_value_tags(team_tag,"project_members",&num,&mem));
		Write_To_Log("\nteamsize:%d\n",num);
		for(z=0;z<num;z++)
		{
			 AOM_ask_value_tag(mem[z],"the_group",&group_tag); 				 
			 SA_ask_group_name(group_tag,group_name); 
			 AOM_ask_value_tag(mem[z],"the_role",&role_tag); 
			 SA_ask_role_name(role_tag,role_name); 
			 AOM_ask_value_tag(mem[z],"the_user",&usertag);  
			 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
			 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
			 if(strcmp(group_name,dept_name)==0 && strcmp(role_name,"Tertiary")==0)
			 {
					*is_tertiary = 1;
					break;												 
			 }
									  
		}

	}

	Write_To_Log("\nis_tertiary:%d\n",*is_tertiary); 
	return ifail;

}

int ns__getWorkList(struct soap* soap, char *userId,struct ns__plmtasklist *return_)
{
		int ifail =0;
		char *uid = NULL;
        
		char	entryNamesArray[NUM_ENTRIES][QRY_uid_name_size_c+1]	= { "Id" };
		char	entryValuesArray[NUM_ENTRIES][QRY_clause_size_c+1]	= { "*" };

		char**	critNames;
		char**	critValues;
		int     index,resultCount;
		int		entryCount;
		char**	entryNames;
		char**	entryValues;
		tag_t*	resultTags;
		tag_t	queryTag	= NULLTAG;
		char * inboxName = NULL;
		char * object_name = NULL;
		char * job_name = NULL;
		int cnt =0,i=0;
		tag_t *fld_content  =NULLTAG;
		char *dept_name = NULL;
		char *role_name = NULL;
		int is_tertiary =0;
		tag_t team_tag = NULLTAG;

		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("log.txt", "w", stdout);
 
		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE )); 

		
		dept_name=malloc(100);
		role_name=malloc(100);

		uid=malloc(100);
		strcpy(uid,userId);  

		critNames = malloc( NUM_ENTRIES * sizeof *critNames );
		for( index=0; index<NUM_ENTRIES; index++ )
		{
			critNames[index] = malloc( strlen(entryNamesArray[index] + 1) );
			if( critNames[index] )
			strcpy( critNames[index], entryNamesArray[index] );
		}

		critValues = malloc( NUM_ENTRIES * sizeof *critValues );
		for( index=0; index<NUM_ENTRIES; index++ )
		{
			critValues[index] = malloc( strlen(entryValuesArray[index] + 1) );
			if( critValues[index] )
			strcpy( critValues[index], uid );
		}

		//*********************************************
		// DISPLAY THE CRITERIA
		//*********************************************

		for( index=0; index<NUM_ENTRIES; index++ )
		{
		   Write_To_Log("**************************************%s - %s\n", critNames[index], critValues[index]);fflush(stdout);
		}

		CALLAPI( QRY_find("__WS_UserInbox", &queryTag) );
		if(queryTag != NULLTAG)
	    {

		//*********************************************
		// DISPLAY THE VALIE ENTRIES, JUST FYI
		//*********************************************

		CALLAPI( QRY_find_user_entries(queryTag, &entryCount, &entryNames, &entryValues) );
		Write_To_Log("\nentryCount:%d\n", entryCount);fflush(stdout);
		for( index=0; index<entryCount; index++ )
		{
		    Write_To_Log("\t\t%s - %s\n", entryNames[index], entryValues[index]);
		}

		//*********************************************
		// EXECUTE THE QUERY
		//*********************************************

			CALLAPI( QRY_execute(queryTag, entryCount, critNames, critValues, &resultCount, &resultTags) );

		}

		Write_To_Log("\nQry Result:%d\n", resultCount);fflush(stdout);

        if(resultCount > 0 )
	    {
			CALLAPI( AOM_ask_name(resultTags[0], &inboxName) );
			Write_To_Log("\ninboxName:%s \n",inboxName);
			CALLAPI(AOM_ask_value_tags(resultTags[0],"tasks_to_perform",&cnt,&fld_content));
			Write_To_Log("\n================\n\ncontents:%d\n",cnt);fflush(stdout);
			return_-> __size =cnt;
			return_->__ptr = malloc( (return_->__size + 1) * sizeof(*return_->__ptr) );

			
			
			for(i=0;i<cnt;i++)
			{ 
				is_tertiary = 0;
				CALLAPI(AOM_ask_value_string(fld_content[i],"job_name",&job_name));
				CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
				Write_To_Log("\nname:%s(%s)\n",job_name,object_name); fflush(stdout);   
				if(strstr(object_name,"Process")!=NULL)
				{
				  return_->__ptr[i].task_name = malloc(150 * sizeof(char *) ); 
				  return_->__ptr[i].project_name = malloc(500 * sizeof(char *) ); 
				  return_->__ptr[i].user_name = malloc(100 * sizeof(char *) ); 
				  return_->__ptr[i].status = malloc(100 * sizeof(char *) );  

				  strcpy(return_->__ptr[i].project_name,job_name);					
				  strcpy(return_->__ptr[i].task_name,object_name);					
				  strcpy(return_->__ptr[i].dept_name,"");					
				  strcpy(return_->__ptr[i].role_name,"");					
				  strcpy(return_->__ptr[i].user_name,"");					
				  strcpy(return_->__ptr[i].status,"Aborted");
				  
				  continue;

				}
				if(strstr(object_name,"Marketing")!= NULL)
				{
					strcpy(dept_name,"Marketing");
				}
				if(strstr(object_name,"NPI")!= NULL)
				{
					strcpy(dept_name,"NPI");
				}
				if(strstr(object_name,"ERC")!= NULL)
				{
					strcpy(dept_name,"ERC");
				}
				if(strstr(object_name,"VD")!= NULL)
				{
					strcpy(dept_name,"VD");
				}
				if(strstr(object_name,"TS")!= NULL)
				{
					strcpy(dept_name,"TS");
				}
				if(strstr(object_name,"Finance")!= NULL)
				{
					strcpy(dept_name,"Finance");
				}

				Write_To_Log("\ndept_name:%s\n",dept_name);

				if(strstr(object_name,"Input")!= NULL)
				{
					if(strstr(object_name,"NPI")!= NULL)
					{
					   strcpy(role_name,"PM");
					}
					else
					{
					   CALLAPI(getProjectTeam(fld_content[i],&team_tag));
					   CALLAPI(check_is_tertiary(team_tag,dept_name,&is_tertiary));
					   if(is_tertiary==1)
					   {
						  strcpy(role_name,"Tertiary");
					   }
					   else
					   {
						  strcpy(role_name,"Secondary");
					   }
					}
				} 

				if(strstr(object_name,"Review")!= NULL)
				{
					if(strstr(object_name,"Primary")!= NULL)
					{
					  strcpy(role_name,"Primary");
					}
					if(strstr(object_name,"Secondary")!= NULL)
					{
					  strcpy(role_name,"Secondary");
					}
					if(strstr(object_name,"PM Review")!= NULL)
					{
					  strcpy(role_name,"PM");
					}
				}

				Write_To_Log("\nrole_name:%s\n",role_name);

				return_->__ptr[i].project_name = malloc(500 * sizeof(char *) ); 
				return_->__ptr[i].task_name = malloc(150 * sizeof(char *) ); 
				return_->__ptr[i].dept_name = malloc(500 * sizeof(char *) ); 
				return_->__ptr[i].role_name = malloc(500 * sizeof(char *) ); 
				return_->__ptr[i].user_name = malloc(100 * sizeof(char *) ); 
				return_->__ptr[i].status = malloc(100 * sizeof(char *) );  

				strcpy(return_->__ptr[i].project_name,job_name);					
				strcpy(return_->__ptr[i].task_name,object_name);					
				strcpy(return_->__ptr[i].dept_name,dept_name);					
				strcpy(return_->__ptr[i].role_name,role_name);					
				strcpy(return_->__ptr[i].user_name,userId);					
				strcpy(return_->__ptr[i].status,"Started");	 		
			}
				 
 			 

		} 

		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos); 
		
	 return SOAP_OK;

}
;

int call_shell_to_insert_data_in_mint(char *project_Name,char *dept_Name, char *role_Name,char *user_id,char *result,char *comments,char *last_mod_str)
{
	int ifail =0,i=0;
	char *command = NULL;
	char *commandMail = NULL;
	char *status = NULL;

	char	entryNamesArray[NUM_ENTRIES1][QRY_uid_name_size_c+1]	= { "Project Name","Type" };
	char	entryValuesArray[NUM_ENTRIES1][QRY_clause_size_c+1]	= { "*" , "EPMConditionTask" }; 
	char**	critNames = NULL;
	char**	critValues = NULL;
	int     index =0,resultCount = 0;
	int		entryCount =0;
	char**	entryNames = NULL;
	char**	entryValues = NULL;
	tag_t*	resultTags = NULLTAG;
	tag_t	queryTag	= NULLTAG;

	char * object_name = NULL;
	char * job_name = NULL;
	char * resp_party = NULL;
	tag_t team_tag = NULLTAG;
	int is_tertiary =0;


	char**	critNames1 = NULL ;
	char**	critValues1 = NULL;
	int     index1=0,resultCount1=0;
	int		entryCount1=0; 
	tag_t*	userTags = NULLTAG;
	tag_t	queryTag1	= NULLTAG;
 
     command = MEM_alloc(1000);
     commandMail = MEM_alloc(1000);
     status = MEM_alloc(100);
 

	 if(strstr(result,"Reject")!=NULL)
	 {
	   strcpy(status,"Waiting");
	 }
	 else
	 {
	   strcpy(status,"Completed");
	 }	 

	 strcpy(command,"/home/req83/NPIexes/workflow.sh"); 
	 strcat(command," \""); 
	 strcat(command,project_Name); 
	 strcat(command,"\" "); 
	 strcat(command,"-a=\""); 
	 strcat(command,"updwf"); 
	 strcat(command,"\" "); 
	 strcat(command,"-d=\""); 
	 strcat(command,dept_Name); 
	 strcat(command,"\" ");  
	 strcat(command,"-n=\""); 
	 strcat(command,role_Name); 
	 strcat(command,"\" "); 
	 strcat(command,"-r=\""); 
	 strcat(command,user_id); 
	 strcat(command,"\" "); 
	 strcat(command,"-s=\""); 
	 strcat(command,status); 
	 strcat(command,"\" "); 
	 strcat(command,"-c=\""); 
	 strcat(command,comments); 
	 strcat(command,"\" "); 
	 strcat(command,"-l=\""); 
	 strcat(command,last_mod_str); 
	 strcat(command,"\" "); 
	 strcat(command," & "); 
	 Write_To_Log("Command:%s\n",command);
	 system(command);

	 //get next task
	 critNames = (char**)malloc( 2 * sizeof(char*) );
 	 for( index=0; index<NUM_ENTRIES1; index++ )
	 {
		critNames[index] = (char*)malloc( 128 * sizeof(char) );
		if( critNames[index] )
			strcpy( critNames[index], entryNamesArray[index] );
	 }

	 strcpy(entryValuesArray[0],project_Name);  		
	 strcpy(entryValuesArray[1],"EPMConditionTask"); 

	 critValues =(char**)malloc( 2 * sizeof(char*) );
	 for( index=0; index<NUM_ENTRIES1; index++ )
	 {
		critValues[index] = (char*)malloc( 128 * sizeof(char) );
		if( critValues[index] )
			strcpy( critValues[index], entryValuesArray[index] );
	 }

	 //*********************************************
	 // DISPLAY THE CRITERIA
	 //*********************************************
  	 for( index=0; index<NUM_ENTRIES1; index++ )
	 {
	
		   Write_To_Log("**************************************%s - %s\n", critNames[index], critValues[index]);fflush(stdout);
	 }

	 

	 CALLAPI( QRY_find("__WS_PendingTask", &queryTag) );
	 if(queryTag != NULLTAG)
	 {
 
		CALLAPI( QRY_find_user_entries(queryTag, &entryCount, &entryNames, &entryValues) );
		Write_To_Log("\nentryCount:%d\n", entryCount);fflush(stdout);
		for( index=0; index<entryCount; index++ )
		{
		    Write_To_Log("\t\t%s - %s\n", entryNames[index], entryValues[index]);
		}

		//*********************************************
		// EXECUTE THE QUERY
		//*********************************************

		CALLAPI( QRY_execute(queryTag, entryCount, critNames, critValues, &resultCount, &resultTags) ); 

	 } 


	 Write_To_Log("\nQry Result:%d\n", resultCount);fflush(stdout); 
	 if(resultCount > 0 )
	 { 
 		for(i=0;i<resultCount;i++)
		{

			 strcpy(command,""); 
			// strcpy(project_Name,"");  
			 strcpy(dept_Name,"");  
			 strcpy(role_Name,"");  
			 strcpy(user_id,"");  
			 strcpy(status,"Started");  
			 strcpy(comments,"");  
			 strcpy(last_mod_str,""); 
			
			CALLAPI(AOM_ask_value_string(resultTags[i],"job_name",&job_name));
			CALLAPI(AOM_ask_value_string(resultTags[i],"object_name",&object_name));
			CALLAPI(AOM_ask_value_string(resultTags[i],"resp_party",&resp_party));
			Write_To_Log("\nNext Task=%s:%s:%s\n",job_name,object_name,resp_party); fflush(stdout);
			//Get User Id
			critNames1 = malloc( 1 * sizeof *critNames1 );
			critNames1[0] = malloc( strlen("Name" + 1) );
		 	critValues1   = malloc( 1 * sizeof *critValues );
			critValues1[0] = malloc(strlen(resp_party + 1) );
			strcpy(critNames1[0],"Name"); 
			strcpy(critValues1[0],resp_party);   
			CALLAPI( QRY_find("__WS_User", &queryTag1) );
			if(queryTag1 != NULLTAG)
		    {
			
					CALLAPI( QRY_find_user_entries(queryTag1, &entryCount1, &entryNames, &entryValues) );  
					CALLAPI( QRY_execute(queryTag1, entryCount1, critNames1, critValues1, &resultCount1, &userTags) );
					Write_To_Log("\nresultCount1:%d\n",resultCount1);fflush(stdout);
					if(resultCount1 > 0)
					{
						CALLAPI(AOM_ask_value_string(userTags[0],"user_id",&user_id));
						Write_To_Log("\nuser_id:%s\n", user_id);fflush(stdout);
					}


			}

			if(strstr(object_name,"Marketing")!= NULL)
			{
				strcpy(dept_Name,"Marketing");
			}
			if(strstr(object_name,"NPI")!= NULL)
			{
				strcpy(dept_Name,"NPI");
			}
			if(strstr(object_name,"ERC")!= NULL)
			{
				strcpy(dept_Name,"ERC");
			}
			if(strstr(object_name,"VD")!= NULL)
			{
				strcpy(dept_Name,"VD");
			}
			if(strstr(object_name,"TS")!= NULL)
			{
				strcpy(dept_Name,"TS");
			}
			if(strstr(object_name,"Finance")!= NULL)
			{
				strcpy(dept_Name,"Finance");
			}
			Write_To_Log("\ndept_Name:%s\n",dept_Name);
			if(strstr(object_name,"Input")!= NULL)
			{
				if(strstr(object_name,"NPI")!= NULL)
				{
					   strcpy(role_Name,"PM");
				}
				else
				{
					   is_tertiary =0;
					   CALLAPI(getProjectTeam(resultTags[i],&team_tag));
					   CALLAPI(check_is_tertiary(team_tag,dept_Name,&is_tertiary));
					   if(is_tertiary==1)
					   {
						  strcpy(role_Name,"Tertiary");
					   }
					   else
					   {
						  strcpy(role_Name,"Secondary");
					   }
				}
			} 
			if(strstr(object_name,"Review")!= NULL)
			{
				if(strstr(object_name,"Primary")!= NULL)
				{
				  strcpy(role_Name,"Primary");
				}
				if(strstr(object_name,"Secondary")!= NULL)
				{
				  strcpy(role_Name,"Secondary");
				}
				if(strstr(object_name,"PM Review")!= NULL)
				{
				  strcpy(role_Name,"PM");
				}
			}

			Write_To_Log("\nrole_name:%s\n",role_Name);

			 strcpy(command,"/home/req83/NPIexes/workflow.sh"); 
			 strcat(command," \""); 
			 strcat(command,project_Name); 
			 strcat(command,"\" "); 
			 strcat(command,"-a=\""); 
			 strcat(command,"updwf"); 
			 strcat(command,"\" "); 
			 strcat(command,"-d=\""); 
			 strcat(command,dept_Name); 
			 strcat(command,"\" ");  
			 strcat(command,"-n=\""); 
			 strcat(command,role_Name); 
			 strcat(command,"\" "); 
			 strcat(command,"-r=\""); 
			 strcat(command,user_id); 
			 strcat(command,"\" "); 
			 strcat(command,"-s=\""); 
			 strcat(command,status); 
			 strcat(command,"\" "); 
			 strcat(command,"-c=\""); 
			 strcat(command,comments); 
			 strcat(command,"\" "); 
			 strcat(command,"-l=\""); 
			 strcat(command,last_mod_str); 
			 strcat(command,"\" "); 
			 strcat(command," & "); 
			 Write_To_Log("Command:%s\n",command);
			 system(command);

			 //import deliverables
			 strcpy(command,""); 
			 strcpy(command,"/home/req83/NPIexes/import_docs "); 
			 strcat(command,"-i=\""); 
			 strcat(command,project_Name); 
			 strcat(command,"\" "); 
			 strcat(command," & "); 
			 Write_To_Log("\nCommand:%s\n",command);
			 system(command);



//mail section
			 strcpy(commandMail,"/home/req83/NPIexes/mail.sh");
			 strcat(commandMail," \""); 
			 strcat(commandMail,project_Name);
			 strcat(commandMail,"\" ");
			 strcat(commandMail,"\""); 
			 strcat(commandMail,"anil.gautam@tatatechnologies.com");
			 strcat(commandMail,"\""); 
			 strcat(commandMail," & "); 
			 Write_To_Log("commandMail:%s\n",commandMail);
			 system(commandMail);
		}
	 }

	return ifail;

}

 
int ns__signoffTask(struct soap* soap, char *projectName, char *taskName,char *deptName, char *roleName,  char *userid,char *result,char *comments, char **return_)
{
		int ifail =0;
         
		char	entryNamesArray[NUM_ENTRIES1][QRY_uid_name_size_c+1]	= { "User Name","Task Name" };
		char	entryValuesArray[NUM_ENTRIES1][QRY_clause_size_c+1]	= { "*" , "*" }; 
		char**	critNames = NULL;
		char**	critValues = NULL;
		int     index =0,resultCount = 0;
		int		entryCount =0;
		char**	entryNames = NULL;
		char**	entryValues = NULL;
		tag_t*	resultTags = NULLTAG;
		tag_t	queryTag	= NULLTAG;
 		char * object_name = NULL;
		char * job_name = NULL;
		char * user_id = NULL;
		char * resp_party = NULL;

 
		char**	critNames1 = NULL ;
		char**	critValues1 = NULL;
		int     index1=0,resultCount1=0;
		int		entryCount1=0; 
		tag_t*	userTags = NULLTAG;
		tag_t	queryTag1	= NULLTAG;

		char *uid = NULL;
		char *tname = NULL;

		EPM_action_t  	action = EPM_complete_action;
		
		int i=0,flag =0;

		date_t last_mod_date;
		char *last_mod_str = NULL;

 
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("log.txt", "w", stdout);
 
		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));  

		uid = (char *) MEM_alloc (sizeof (char) * 128);
		tname = (char *) MEM_alloc (sizeof (char) * 128);
		 
		strcpy(uid,userid);  
		strcpy(tname,taskName);   
 
		critNames = (char**)malloc( 2 * sizeof(char*) );
 		for( index=0; index<NUM_ENTRIES1; index++ )
		{
			critNames[index] = (char*)malloc( 128 * sizeof(char) );
			if( critNames[index] )
			strcpy( critNames[index], entryNamesArray[index] );
		}

		strcpy(entryValuesArray[0],uid);  		
		strcpy(entryValuesArray[1],tname); 

		critValues =(char**)malloc( 2 * sizeof(char*) );
		for( index=0; index<NUM_ENTRIES1; index++ )
		{
			critValues[index] = (char*)malloc( 128 * sizeof(char) );
			if( critValues[index] )
			strcpy( critValues[index], entryValuesArray[index] );
		}

		//*********************************************
		// DISPLAY THE CRITERIA
		//*********************************************

		for( index=0; index<NUM_ENTRIES1; index++ )
		{
		   Write_To_Log("**************************************%s - %s\n", critNames[index], critValues[index]);fflush(stdout);
		}

		CALLAPI( QRY_find("__WS_Signoff", &queryTag) );
		if(queryTag != NULLTAG)
	    {

		//*********************************************
		// DISPLAY THE VALIE ENTRIES, JUST FYI
		//*********************************************

		CALLAPI( QRY_find_user_entries(queryTag, &entryCount, &entryNames, &entryValues) );
		Write_To_Log("\nentryCount:%d\n", entryCount);fflush(stdout);
		for( index=0; index<entryCount; index++ )
		{
		    Write_To_Log("\t\t%s - %s\n", entryNames[index], entryValues[index]);
		}

		//*********************************************
		// EXECUTE THE QUERY
		//*********************************************

			CALLAPI( QRY_execute(queryTag, entryCount, critNames, critValues, &resultCount, &resultTags) );

		} 


		Write_To_Log("\nQry Result:%d\n", resultCount);fflush(stdout);	 
		*return_ = malloc(sizeof (char) * 128 );
		strcpy(*return_,"NotOK");
		if(resultCount > 0 )
	    { 
 			
			
			for(i=0;i<resultCount;i++)
			{
				CALLAPI(AOM_ask_value_string(resultTags[i],"job_name",&job_name));
				CALLAPI(AOM_ask_value_string(resultTags[i],"object_name",&object_name));
				CALLAPI(AOM_ask_value_string(resultTags[i],"resp_party",&resp_party));
				Write_To_Log("\nname:%s %s %s \n",job_name,object_name,resp_party); fflush(stdout); 
				//Get User 
				critNames1 = malloc( 1 * sizeof *critNames1 );
				critNames1[0] = malloc( strlen("Name" + 1) );
				critValues1   = malloc( 1 * sizeof *critValues );
				critValues1[0] = malloc(strlen(resp_party + 1) );
				strcpy(critNames1[0],"Name"); 
				strcpy(critValues1[0],resp_party);   
				CALLAPI( QRY_find("__WS_User", &queryTag1) );
				if(queryTag1 != NULLTAG)
			    {
			
					CALLAPI( QRY_find_user_entries(queryTag1, &entryCount1, &entryNames, &entryValues) );  
					CALLAPI( QRY_execute(queryTag1, entryCount1, critNames1, critValues1, &resultCount1, &userTags) );
					Write_To_Log("\nresultCount1:%d\n",resultCount1);fflush(stdout);
					if(resultCount1 > 0)
					{
						CALLAPI(AOM_ask_value_string(userTags[0],"user_id",&user_id));
						Write_To_Log("\nuser_id:%s\n", user_id);fflush(stdout);
					}


				}	 
				
				Write_To_Log("\nMatching job_name:%s = %s user_id:%s = %s\n",job_name,projectName,user_id,userid); fflush(stdout); 
				if(strcmp(job_name,projectName)==0 && strcmp(user_id,userid)==0)
				{

				   Write_To_Log("\ntask sign off\n"); fflush(stdout);
				   if(strcmp(result,"Approve")==0 || strcmp(result,"Complete")==0)
				   {
						if(strstr(object_name,"Inputs")!=NULL)
						{
							CALLAPI(EPM_set_task_result(resultTags[i],"Complete"));
							flag = 1;
					    }
						else
					    {
						   CALLAPI(EPM_set_task_result(resultTags[i],"Approve"));
						   flag = 1;
						}
				   }
				   if(strstr(result,"Reject")!=NULL)
				   {
					  if(!strcmp(result,"Reject") || !strcmp(result,"Reject to Marketing") || !strcmp(result,"Reject to NPI") || !strcmp(result,"Reject to ERC") || !strcmp(result,"Reject to VD") || !strcmp(result,"Reject to TS") || !strcmp(result,"Reject to Finance"))
					  {
					  	 CALLAPI(EPM_set_task_result(resultTags[i],result));
						 flag = 1;
					  }
				   }

				   Write_To_Log("\nflag:%d\n",flag);

				   if(flag == 1)
				   {
					   CALLAPI(EPM_trigger_action(resultTags[i],action,comments));		
					   if(ifail == ITK_ok)
					   {
						   strcpy(*return_,"OK");	 
					   } 

					   CALLAPI(AOM_ask_value_date(resultTags[i],"last_mod_date",&last_mod_date)); 
					   CALLAPI(ITK_date_to_string(last_mod_date,&last_mod_str)); 
					   CALLAPI(call_shell_to_insert_data_in_mint(projectName,deptName,roleName,userid,result,comments,last_mod_str));

	



				   }
				}
				 
 			}

			MEM_free(resultTags);

		} 

	    	

		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos); 


		
	 return SOAP_OK;

}
;
