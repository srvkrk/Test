//gsoap ns service name:                          DMLPDCA
//gsoap ns service style:                          rpc
//gsoap ns service namespace:                    urn:DMLPDCA
//gsoap ns service location:                     http://172.25.184.156:8080/cgi/DMLPDCA.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:DMLPDCA
//gsoap ns service method-documentation: Tests the Simple Web service



//int ns__getDmlDetails(char *tzname,char *emailid,struct ns__CharArray4Test *aString_test);
//int ns__getDmlDetailPDCA(char *DML_No,char *PDCA_No,char *PDCA_Type,char **Response);
int ns__getDmlDetailPDCA(char *DML_No,char *PDCA_Type,char **Response);
