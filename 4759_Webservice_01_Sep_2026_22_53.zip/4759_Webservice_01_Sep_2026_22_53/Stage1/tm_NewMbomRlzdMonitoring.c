/****************************************************************************************************
*  File	           :   tm_NewMbomRlzdMonitoring.c ( File name )
*  Pupuse        :   Featch MBOM DML Released between 24hrs based on user input(date)
*  Date			   :   03/01/2024
*  Developer	   : Srikanth Beerapor

*******************************************************************************************************/


#include "soapH.h"				/* get the gSOAP-generated definitions */
#include "tm_NewMbomRlzdMonitoring.nsmap"		 /* get the gSOAP-generated namespace bindings */

 #define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
//#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <fclasses/tc_string.h>
//#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define Debug TRUE
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}

int X;
int status;
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

//to get previous date
char getPrevDate(int* day, int* month, int* year)
{
	char	Previous_date[30];
    if (*day == 1)
		{
        if (*month == 4 || *month == 6 || *month == 9 || *month == 11)
		{
            *day = 31;
            *month = *month - 1;
        }
        else if (*month == 3)
		{
            if (*year % 4 == 0)
                *day = 29;
            else
                *day = 28;
            *month = *month - 1;
        }
        else if (*month == 1)
		{
            *day = 31;
            *month = 12;
            *year = *year - 1;
        }
        else if (*month == 2)
		{
            *day = 31;
            *month = *month - 1;
        }
        else
		{
            *day = 30;
            *month = *month - 1;
        }
    }
	else
	{
        *day = *day - 1;
    }
}
void getMonthinInt(char *Month)
{
	if(strcmp(Month,"Jan")==0)
	{
		strcpy(Month,"1");
	}
	else if(strcmp(Month,"Feb")==0)
	{
		strcpy(Month,"2");
	}
	else if(strcmp(Month,"Mar")==0)
	{
		strcpy(Month,"3");
	}
	else if(strcmp(Month,"Apr")==0)
	{
		strcpy(Month,"4");
	}
	else if(strcmp(Month,"May")==0)
	{
		strcpy(Month,"5");
	}
	else if(strcmp(Month,"Jun")==0)
	{
		strcpy(Month,"6");
	}
	else if(strcmp(Month,"Jul")==0)
	{
		strcpy(Month,"7");
	}
	else if(strcmp(Month,"Aug")==0)
	{
		strcpy(Month,"8");
	}
	else if(strcmp(Month,"Sep")==0)
	{
		strcpy(Month,"9");
	}
	else if(strcmp(Month,"Oct")==0)
	{
		strcpy(Month,"10");
	}
	else if(strcmp(Month,"Nov")==0)
	{
		strcpy(Month,"11");
	}
	else if(strcmp(Month,"Dec")==0)
	{
		strcpy(Month,"12");
	}
}
//to featch series number
char* GetSrNum(int num)
{
	char *Srl = NULL;
	if(num==1)			{		Srl = "1";		}
	else if(num==2)		{		Srl = "2";		}
	else if(num==3)		{		Srl = "3";		}
	else if(num==4)		{		Srl = "4";		}
	else if(num==5)		{		Srl = "5";		}
	else if(num==6)		{		Srl = "6";		}
	else if(num==7)		{		Srl = "7";		}
	else if(num==8)		{		Srl = "8";		}
	else if(num==9)		{		Srl = "9";		}
	else if(num==10)	{		Srl = "10";	}
	else if(num==11)	{		Srl = "11";	}
	else if(num==12)	{		Srl = "12";	}
	else if(num==13)	{		Srl = "13";	}
	else if(num==14)	{		Srl = "14";	}
	else if(num==15)	{		Srl = "15";	}
	else if(num==16)	{		Srl = "16";	}
	else if(num==17)	{		Srl = "17";	}
	else if(num==18)	{		Srl = "18";	}
	else if(num==19)	{		Srl = "19";	}
	else if(num==20)	{		Srl = "20";	}
	else if(num==21)	{		Srl = "21";	}
	else if(num==22)	{		Srl = "22";	}
	else if(num==23)	{		Srl = "23";	}
	else if(num==24)	{		Srl = "24";	}
	else if(num==25)	{		Srl = "25";	}
	else if(num==26)	{		Srl = "26";	}
	else if(num==27)	{		Srl = "27";	}
	else if(num==28)	{		Srl = "28";	}
	else if(num==29)	{		Srl = "29";	}
	else if(num==30)	{		Srl = "30";	}
	else if(num==31)	{		Srl = "31";	}
	else if(num==32)	{		Srl = "32";	}
	else if(num==33)	{		Srl = "33";	}
	else if(num==34)	{		Srl = "34";	}
	else if(num==35)	{		Srl = "35";	}
	else if(num==36)	{		Srl = "36";	}
	else if(num==37)	{		Srl = "37";	}
	else if(num==38)	{		Srl = "38";	}
	else if(num==39)	{		Srl = "39";	}
	else if(num==40)	{		Srl = "40";	}
	else if(num==41)	{		Srl = "41";	}
	else if(num==42)	{		Srl = "42";	}
	else if(num==43)	{		Srl = "43";	}
	else if(num==44)	{		Srl = "44";	}
	else if(num==45)	{		Srl = "45";	}
	else if(num==46)	{		Srl = "46";	}
	else if(num==47)	{		Srl = "47";	}
	else if(num==48)	{		Srl = "48";	}
	else if(num==49)	{		Srl = "49";	}
	else if(num==50)	{		Srl = "50";	}
	else if(num==51)	{		Srl = "51";	}
	else if(num==52)	{		Srl = "52";	}
	else if(num==53)	{		Srl = "53";	}
	else if(num==54)	{		Srl = "54";	}
	else if(num==55)	{		Srl = "55";	}
	else if(num==56)	{		Srl = "56";	}
	else if(num==57)	{		Srl = "57";	}
	else if(num==58)	{		Srl = "58";	}
	else if(num==59)	{		Srl = "59";	}
	else if(num==60)	{		Srl = "60";	}
	else if(num==61)	{		Srl = "61";	}
	else if(num==62)	{		Srl = "62";	}
	else if(num==63)	{		Srl = "63";	}
	else if(num==64)	{		Srl = "64";	}
	else if(num==65)	{		Srl = "65";	}
	else if(num==66)	{		Srl = "66";	}
	else if(num==67)	{		Srl = "67";	}
	else if(num==68)	{		Srl = "68";	}
	else if(num==69)	{		Srl = "69";	}
	else if(num==70)	{		Srl = "70";	}
	else if(num==71)	{		Srl = "71";	}
	else if(num==72)	{		Srl = "72";	}
	else if(num==73)	{		Srl = "73";	}
	else if(num==74)	{		Srl = "74";	}
	else if(num==75)	{		Srl = "75";	}
	else if(num==76)	{		Srl = "76";	}
	else if(num==77)	{		Srl = "77";	}
	else if(num==78)	{		Srl = "78";	}
	else if(num==79)	{		Srl = "79";	}
	else if(num==80)	{		Srl = "80";	}
	else if(num==81)	{		Srl = "81";	}
	else if(num==82)	{		Srl = "82";	}
	else if(num==83)	{		Srl = "83";	}
	else if(num==84)	{		Srl = "84";	}
	else if(num==85)	{		Srl = "85";	}
	else if(num==86)	{		Srl = "86";	}
	else if(num==87)	{		Srl = "87";	}
	else if(num==88)	{		Srl = "88";	}
	else if(num==89)	{		Srl = "89";	}
	else if(num==90)	{		Srl = "90";	}
	else if(num==91)	{		Srl = "91";	}
	else if(num==92)	{		Srl = "92";	}
	else if(num==93)	{		Srl = "93";	}
	else if(num==94)	{		Srl = "94";	}
	else if(num==95)	{		Srl = "95";	}
	else if(num==96)	{		Srl = "96";	}
	else if(num==97)	{		Srl = "97";	}
	else if(num==98)	{		Srl = "98";	}
	else if(num==99)	{		Srl = "99";	}
	else if(num==100)	{		Srl = "100";	}
	return Srl;
}
//to fetch Month in charecter
void GetMonthinStr(char *strMon)
{
	if(strcmp(strMon,"01")==0 || strcmp(strMon,"1")==0 )
	{
		strcpy(strMon,"Jan");
	}
	else if(strcmp(strMon,"02")==0 || strcmp(strMon,"2")==0)
	{
		strcpy(strMon,"Feb");
	}
	else if(strcmp(strMon,"03")==0 || strcmp(strMon,"3")==0)
	{
		strcpy(strMon,"Mar");
	}
	else if(strcmp(strMon,"04")==0 || strcmp(strMon,"4")==0)
	{
		strcpy(strMon,"Apr");
	}
	else if(strcmp(strMon,"05")==0 || strcmp(strMon,"5")==0)
	{
		strcpy(strMon,"May");
	}
	else if(strcmp(strMon,"06")==0 || strcmp(strMon,"6")==0)
	{
		strcpy(strMon,"Jun");
	}
	else if(strcmp(strMon,"07")==0 || strcmp(strMon,"7")==0)
	{
		strcpy(strMon,"Jul");
	}
	else if(strcmp(strMon,"08")==0 || strcmp(strMon,"8")==0)
	{
		strcpy(strMon,"Aug");
	}
	else if(strcmp(strMon,"09")==0 || strcmp(strMon,"9")==0)
	{
		strcpy(strMon,"Sep");
	}
	else if(strcmp(strMon,"10")==0)
	{
		strcpy(strMon,"Oct");
	}
	else if(strcmp(strMon,"11")==0)
	{
		strcpy(strMon,"Nov");
	}
	else if(strcmp(strMon,"12")==0)
	{
		strcpy(strMon,"Dec");
	}
}

/*
Fetching MBOM DML's which is released within 24 hrs. data will be fetched based on input date "StrDateInp"
*/
int ns__getStddmlfsullDataInfo(struct soap* soap, char *StrDateInp, struct ns__CharArray1 *aString_Ret)
{

	char			*previousDate[30];
	char			*PreviousDateInput				= NULL;
	char			*FileNeme								=	NULL;
	char			*qry_entry[3]						= {"from","To","Name"};
	char			**qry_values							= (char **) MEM_alloc(5 * sizeof(char *));
	char			*qry_entry1[3]						= {"from","To","Name"};
	char			**qry_values1						= (char **) MEM_alloc(5 * sizeof(char *));
	char			*day										= NULL;
	char			*month									= NULL;
	char			*inputDate								= NULL;
	char			*year										= NULL;
	char			*StrPlntNam							= NULL;
	char			*ErcObjectType							= NULL;
	char			*Dmlname								= NULL;
	char			*DsgnGrp								= NULL;
	char			*TaskName							= NULL;
	char			*APlRelesDate						= NULL;
	char			*Designgroup						= NULL;
	char			strDay[20];
	char			strMon[20];
	char			strYear[20];

	char			*Srl_Num  =  NULL;
	char			*Dml_Num;
	char			*Task_Num;
	char			*Design_Grp;
	char			*DrStatus;
	char			*TaskStatus;
	char			*ERCRelzDate;
	char			*ProjectCode;
	char			*MbomDesigner;
	char			*MbomDsnerAssgndDate;
	char			*MbomDsnerRelzdDate;
	char			*MbomReviewdBy;
	char			*MbomReviewerRlzDate;
	char			*MbomManager;
	char			*MbomManagerRlzDate;
	char			*releasedMbomAssmlyNo;

	char			*Dml_Desc;
	char			*MbomEndDate				= NULL;
	char			*MbomStartDate				= NULL;
	char			*ManagerRevwddate			= NULL;
	char			*ManagerRevwdby			= NULL;
	char			*ObjectType						= NULL;
	char			*PropertyName					= NULL;
	char			*objectrelstatus					= NULL;
	char			*CurrentTime					= NULL;
	char			*DateTime						= NULL;
	char			*stamptime						= NULL;
	char			*DMName						= NULL;
	time_t		t										= time(NULL);
	struct tm	tm										= *localtime(&t);
	char str1[100];
	char str2[100];
	char str3[100];
	char str4[100];
	char str5[100];
	stamptime = (char *) MEM_alloc (sizeof (char) * 128);

	int				dy,mt,yr								= 0;
	int				controlObjfound					= 0;
	int				controlObjfound1					= 0;
	int				i,j,k										= 0;
	int				TaskCount							= 0;
	int				TaskCount1							= 0;
	int				TaskCount2							= 0;
	int				num										= 0;
	int				Linecnt									= 0;
	int				entry										= 3;
	int				SrNum									= 0;
	int				NumOfCnt							= 0;
	int				size										= 0;
	int				sizeCntOfStrctre					= 0;
	int				Struct_allocation         = 100;

	tag_t			queryTag								= NULLTAG;
	tag_t			Rel_Typ_tag							= NULLTAG;
	tag_t			LatestDmltag							= NULLTAG;
	tag_t			tsk_dml_rel_type					= NULLTAG;
	tag_t			tsk_dml_rel_type1					= NULLTAG;
	tag_t			tsk_dml_rel_type2					= NULLTAG;
	tag_t			Tasktag									= NULLTAG;
	tag_t			ERCTag								= NULLTAG;
	tag_t			release									= NULLTAG;
	tag_t			lastRel									= NULLTAG;
	tag_t			DmlTag1								= NULLTAG;
	tag_t			DmlTag									= NULLTAG;
	tag_t			*List_Of_objects					= NULLTAG;
	tag_t			*List_Of_objects1				= NULLTAG;
	tag_t			*Tasks									= NULLTAG;
	tag_t			*Tasks1								= NULLTAG;
	tag_t			*Tasks2								= NULLTAG;
	tag_t			*status_list							= NULLTAG;
	tag_t			*ActuatedInteractiveTsks		= NULLTAG;
	tag_t			ActualIntrTsks						= NULLTAG;
	FILE			*inputfile ;
	date_t		 Release_date;

	tc_strdup(StrDateInp,&inputDate);

	if(tc_strstr(inputDate,"/")!=NULL)
	{
		strcat(inputDate,"/");
		day = strtok(inputDate,"/");
		month = strtok(NULL,"/");
		year = strtok(NULL,"/");
	}
	else if(tc_strstr(inputDate,"-")!=NULL)
	{
		strcat(inputDate,"-");
		day = strtok(inputDate,"-");
		month = strtok(NULL,"-");
		year = strtok(NULL,"-");
	}

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/Log_file_tm_NewMbomRlzdMonitoring.txt", "a", stdout);

	if (tc_strcmp(FileNeme,"NULL")==0) MEM_free(FileNeme);
	FileNeme=(char *)MEM_alloc(3000);
	if (tc_strcmp(PreviousDateInput,"NULL")==0) MEM_free(PreviousDateInput);
	PreviousDateInput=(char *)MEM_alloc(3000);

	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE);
	ITK_auto_login();
	ITK_set_journalling( TRUE );

	sprintf(str1, "%d", tm.tm_mday);
	sprintf(str2, "%d", tm.tm_mon + 1);
	sprintf(str3, "%d", tm.tm_year + 1900);
	sprintf(str4, "%d", tm.tm_hour);
	sprintf(str5, "%d", tm.tm_min);
	tc_strcpy(stamptime, str1);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str2);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str3);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str4);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str5);
	printf("Cuurent Date and time is %s\n",stamptime);


	tc_strcpy(FileNeme,"");
	tc_strcpy(FileNeme,"/tmp/");
	tc_strcat(FileNeme,"Log_file_tm_NewMbomRlzdMonitoring");
	tc_strcat(FileNeme,"_");
	tc_strcat(FileNeme,stamptime);
	tc_strcat(FileNeme,".txt");

	inputfile=fopen(FileNeme,"a+");
	if(inputfile == NULL)

	{
		printf("File not Opened\n");
	}
	else
	{
			printf("\nfile opend....!\n");
	}
	dy =atoi(day);
	fprintf(inputfile,"month is %s\n",month);
	getMonthinInt(month);
	mt =atoi(month);
	yr =atoi(year);

	fprintf(inputfile,"Day = %s\n",day);
	fprintf(inputfile,"Month = %s\n",month);
	fprintf(inputfile,"year = %s\n",year);
	getPrevDate(&dy, &mt, &yr);
	sprintf(strDay,"%d",dy);
	sprintf(strMon,"%d",mt);
	sprintf(strYear,"%d",yr);

	fprintf(inputfile,"Given Date input %s\n",StrDateInp);

	tc_strcpy(PreviousDateInput,"");
	tc_strcat(PreviousDateInput,strDay);
	tc_strcat(PreviousDateInput,"-");
	GetMonthinStr(strMon);
	tc_strcat(PreviousDateInput,strMon);
	tc_strcat(PreviousDateInput,"-");
	tc_strcat(PreviousDateInput,strYear);
	fprintf(inputfile,"Previous Date Input  %s\n",PreviousDateInput);

	//find size of tasks
	if(QRY_find2("MBOM DML Released Between Date", &queryTag));
	if(queryTag)
	{
		qry_values1[0]=PreviousDateInput;
		qry_values1[1]=StrDateInp;
		qry_values1[2]="T5_MBOMReleased";

		if(QRY_execute(queryTag, entry, qry_entry1, qry_values1, &controlObjfound, &List_Of_objects));
		if(controlObjfound>0)
		{
			for(i=0;i<controlObjfound;i++)
			{
				DmlTag1 = List_Of_objects[i];
				tag_t  Tasktag1= NULLTAG;
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type1));
				ITKCALL(GRM_list_secondary_objects_only(DmlTag1,tsk_dml_rel_type1,&TaskCount1,&Tasks1));
				char *TaskObjectType = NULL;
				if(TaskCount1>0)
				{
					int c = 0;
					for(c=0;c<TaskCount1;c++)
					{
						Tasktag1 = Tasks1[c];

						ITKCALL(AOM_ask_value_string(Tasktag1,"item_id",&DMName));
						printf("Task Name is %s\n",DMName);

						ITKCALL(AOM_ask_value_string(Tasktag1,"object_type",&TaskObjectType));

						fprintf(inputfile,"Object Type is : %s\n",TaskObjectType);fflush(stdout);
						if(tc_strcmp(TaskObjectType,"APL DML Revision")==0 || tc_strcmp(TaskObjectType,"T5_APLDMLRevision")==0)
						{
							continue;
						}
						sizeCntOfStrctre++;
					}
				}
			}
		}

	size = size +sizeCntOfStrctre;
	fprintf(inputfile,"Total no of Tasks for above input is : %d\n",size);fflush(stdout);
	fprintf(inputfile,"Final Total no of Tasks for above input is : %d\n",size);fflush(stdout);

	//find size of tasks
	aString_Ret->__size = size;//controlObjfound;
	aString_Ret->__ptrRlzDmlData = (struct ns__plmStdDmlData *) malloc((aString_Ret->__size + 100000) * sizeof(struct ns__plmStdDmlData));

		if(controlObjfound>0)
		{
			for(i=0;i<controlObjfound;i++)
			{
				DmlTag = List_Of_objects[i];

					//ERCDML
					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type2));
					ITKCALL(GRM_list_primary_objects_only(DmlTag,tsk_dml_rel_type2,&TaskCount2,&Tasks));
					fprintf(inputfile,"ERC DML found  %d\n",TaskCount2);
					ERCRelzDate = NULL;
					if(TaskCount2>0)
					{
						ERCTag = Tasks[0];

						ITKCALL(AOM_UIF_ask_value(ERCTag,"object_type",&ErcObjectType));
						fprintf(inputfile,"ERC DML Object Type is %s\n",ErcObjectType);

						if(tc_strcmp(ErcObjectType,"ERC DML Revision")==0)
						{
							ITKCALL(AOM_UIF_ask_value(ERCTag,"date_released",&ERCRelzDate));
							fprintf(inputfile,"DML Number is  %s\n",ERCRelzDate);
						}
						else
						{
							ERCRelzDate = "-";
						}
					}
					//ERCDML

					tag_t		part_tsk_rel				= NULLTAG;
					tag_t		Part							= NULLTAG;
					tag_t		*Part_objects			= NULLTAG;
					int			part_cnt					= 0;
					int			ptcnt							= 0;
					char		*Part_Num				= NULL;
					char		*Part_objTyp				= NULL;
					char		*Assembly;



					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					ITKCALL(GRM_list_secondary_objects_only(DmlTag,tsk_dml_rel_type,&TaskCount,&Tasks));
					fprintf(inputfile,"Total no of Task : %d\n",TaskCount);fflush(stdout);
					if(TaskCount>0)
					{
						for(j=0;j<TaskCount;j++)
						{
							int			max_char_size			= 1000;
							Tasktag = Tasks[j];
							Srl_Num = NULL;
							Dml_Num = NULL;
							Task_Num = NULL;
							Design_Grp = NULL;
							DrStatus = NULL;
							TaskStatus = NULL;
							ProjectCode = NULL;
							MbomDesigner = NULL;
							MbomDsnerAssgndDate = NULL;
							MbomDsnerRelzdDate = NULL;
							MbomReviewdBy = NULL;
							MbomReviewerRlzDate = NULL;
							MbomManager = NULL;
							MbomManagerRlzDate = NULL;
							releasedMbomAssmlyNo = NULL;

							Part_Num = NULL;
								Assembly = NULL;
							Assembly = (char *)MEM_alloc(max_char_size * sizeof(char));

							AOM_ask_value_string(DmlTag,"item_id",&Dml_Num);
							fprintf(inputfile,"DML Number is  %s\n",Dml_Num);

							char *TaskObjectType = NULL;

							ITKCALL(AOM_UIF_ask_value(Tasktag,"object_type",&TaskObjectType));
							fprintf(inputfile,"Object Type is : %s\n",TaskObjectType);fflush(stdout);
							if(tc_strcmp(TaskObjectType,"APL DML Revision")==0)
							{
								continue;
							}
							else if(tc_strcmp(TaskObjectType,"MBOMTASK Revision")==0)
							{
								num++;
								ITKCALL(AOM_ask_value_tags(Tasktag,"fnd0ActuatedInteractiveTsks",&NumOfCnt,&ActuatedInteractiveTsks));
								fprintf(inputfile,"ActuatedInteractiveTsks count is : %d\n",NumOfCnt);fflush(stdout);
								if(NumOfCnt>0)
								{
									for(k=0;k<NumOfCnt;k++)
									{
										ActualIntrTsks = NULLTAG;
										ActualIntrTsks = ActuatedInteractiveTsks[k];
										ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"object_type",&ObjectType));
										fprintf(inputfile,"Object Type is : %s\n",ObjectType);fflush(stdout);

										if(tc_strcmp(ObjectType,"Signoff")==0)
										{
											continue;
										}
										PropertyName = NULL;
										ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"current_name",&PropertyName));
										fprintf(inputfile,"PropertyName Name is : %s\n",PropertyName);fflush(stdout);

										if( (tc_strcmp(PropertyName,"Work On MBOM-DML")==0) || (tc_strcmp(PropertyName,"Designer Acknowledge")==0) || (tc_strcmp(PropertyName,"Assign MBOM Planner & Reviewer")==0) )
										{
											fprintf(inputfile,"I am in Work On MBOM-DML\n");fflush(stdout);

											ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0Performer",&MbomDesigner));
											fprintf(inputfile,"MbomDesigner Number is : %s\n",MbomDesigner);fflush(stdout);

											ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0StartDate",&MbomDsnerAssgndDate));
											fprintf(inputfile,"MbomStartDate Number is : %s\n",MbomDsnerAssgndDate);fflush(stdout);

											ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0EndDate",&MbomDsnerRelzdDate));
											fprintf(inputfile,"MbomEndDate Number is : %s\n",MbomDsnerRelzdDate);fflush(stdout);
										}
										else if( tc_strcmp(PropertyName,"Review The Changes")==0)
										{
											fprintf(inputfile,"i am in review the changes\n");
											ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0Performer",&MbomReviewdBy));
											fprintf(inputfile,"changes reviewed by is : %s\n",MbomReviewdBy);fflush(stdout);

											ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0EndDate",&MbomReviewerRlzDate));
											fprintf(inputfile,"changes reviewed by is : %s\n",MbomReviewerRlzDate);fflush(stdout);
										}
										else if(tc_strcmp(PropertyName,"Manager Review")==0)
										{
											fprintf(inputfile,"i am in manager review\n");
											ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0Performer",&MbomManager));
											fprintf(inputfile,"Manager reviewed by is : %s\n",MbomManager);fflush(stdout);

											ITKCALL(AOM_UIF_ask_value(ActualIntrTsks,"fnd0EndDate",&MbomManagerRlzDate));
											fprintf(inputfile,"Manager reviewed on: %s\n",MbomManagerRlzDate);fflush(stdout);
										}
									}
								}
								part_tsk_rel = NULLTAG;
								Part_objects = NULLTAG;
								part_cnt = 0;

								ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
								fprintf(inputfile,"\nExpanding Task to Parts relation\n");fflush(stdout);
								ITKCALL(GRM_list_secondary_objects_only(Tasktag, part_tsk_rel, &part_cnt, &Part_objects));

								fprintf(inputfile,"\n part_cnt for CMHasSolutionItem : [%d]\n",part_cnt);fflush(stdout);fflush(stdout);

								if(part_cnt==0)
								{
									part_tsk_rel = NULLTAG;
									Part_objects = NULLTAG;

									ITKCALL(GRM_find_relation_type("CMReferences", &part_tsk_rel));
									fprintf(inputfile,"\nExpanding Task to Parts relation\n");fflush(stdout);
									ITKCALL(GRM_list_secondary_objects_only(Tasktag, part_tsk_rel, &part_cnt, &Part_objects));
								}


								fprintf(inputfile,"\n part_cnt for CMReferences : [%d]\n",part_cnt);fflush(stdout);fflush(stdout);
								if(part_cnt>0)
								{
									for(ptcnt=0;ptcnt<part_cnt;ptcnt++)
									{
										Part = NULLTAG;
										Part = Part_objects[ptcnt];

										ITKCALL(AOM_UIF_ask_value(Part,"object_type",&Part_objTyp));
										if(tc_strcmp(Part_objTyp,"Folder")==0)
										{
											continue;
										}
										ITKCALL(AOM_ask_value_string(Part,"item_id",&Part_Num));
										fprintf(inputfile,"Part Number is  %s\n",Part_Num);fflush(stdout);
										tc_strcat(Assembly,Part_Num);
										if(ptcnt<part_cnt-1)
										{
											tc_strcat(Assembly,",");
										}
									}
								}
								ITKCALL(AOM_ask_value_string(Tasktag,"item_id",&Task_Num));
								fprintf(inputfile,"Task Number %s\n",Task_Num);fflush(stdout);

								ITKCALL(AOM_UIF_ask_value(DmlTag,"t5_crdesigngroup",&Design_Grp));
								fprintf(inputfile,"Design Group is  %s\n",Design_Grp);fflush(stdout);

								ITKCALL(AOM_ask_value_string(DmlTag,"t5_cDRstatus",&DrStatus));
								fprintf(inputfile,"DML DR/AR status is %s\n",DrStatus);fflush(stdout);

								ITKCALL(AOM_UIF_ask_value(Tasktag,"release_status_list",&TaskStatus));
								fprintf(inputfile,"Task Release status %s\n",TaskStatus);fflush(stdout);

								ITKCALL(AOM_ask_value_string(DmlTag,"t5_cprojectcode",&ProjectCode));
								fprintf(inputfile,"Project Code is %s\n",ProjectCode);fflush(stdout);

								ITKCALL(AOM_ask_value_string(DmlTag,"object_desc",&Dml_Desc));
								fprintf(inputfile,"DML Description is %s\n",Dml_Desc);fflush(stdout);

								Srl_Num = GetSrNum(num);

								fprintf(inputfile,"Serial Number is %s\n",Srl_Num);fflush(stdout);
								fprintf(inputfile,"Value of Linecnt is %d\n",Linecnt);fflush(stdout);


								aString_Ret->__ptrRlzDmlData[Linecnt].Srl_Num = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Num = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].Task_Num = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].Design_Grp = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].DrStatus = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].TaskStatus = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].ERCRelzDate = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].ProjectCode = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].MbomDesigner = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerAssgndDate = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerRelzdDate = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewdBy = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewerRlzDate = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].MbomManager = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].MbomManagerRlzDate = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].releasedMbomAssmlyNo = malloc(1000 * sizeof(char *) );
								aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Desc = malloc(1000 * sizeof(char *) );


								if(tc_strlen(Srl_Num)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Srl_Num,Srl_Num);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Srl_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Srl_Num);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Srl_Num,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Srl_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Srl_Num);fflush(stdout);
								}
								if(tc_strlen(Dml_Num)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Num,Dml_Num);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Num);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Num,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Num);fflush(stdout);
								}
								if(tc_strlen(Task_Num)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Task_Num,Task_Num);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Task_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Task_Num);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Task_Num,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Task_Num ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Task_Num);fflush(stdout);
								}
								if(tc_strlen(Design_Grp)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Design_Grp,Design_Grp);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Design_Grp ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Design_Grp);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Design_Grp,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Design_Grp ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Design_Grp);fflush(stdout);
								}
								if(tc_strlen(DrStatus)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].DrStatus,DrStatus);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].DrStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].DrStatus);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].DrStatus,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].DrStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].DrStatus);fflush(stdout);
								}
								if(tc_strlen(TaskStatus)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].TaskStatus,TaskStatus);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].TaskStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].TaskStatus);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].TaskStatus,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].TaskStatus ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].TaskStatus);fflush(stdout);
								}
								if(tc_strlen(ERCRelzDate)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].ERCRelzDate,ERCRelzDate);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].ERCRelzDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].ERCRelzDate);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].ERCRelzDate,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].ERCRelzDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].ERCRelzDate);fflush(stdout);
								}
								if(tc_strlen(ProjectCode)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].ProjectCode,ProjectCode);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].ProjectCode ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].ProjectCode);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].ProjectCode,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].ProjectCode ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].ProjectCode);fflush(stdout);
								}
								if(tc_strlen(MbomDesigner)>0)
								{
										tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomDesigner,MbomDesigner);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomDesigner ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomDesigner);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomDesigner,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomDesigner ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomDesigner);fflush(stdout);
								}
								if(tc_strlen(MbomDsnerAssgndDate)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerAssgndDate,MbomDsnerAssgndDate);
											fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerAssgndDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerAssgndDate);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerAssgndDate,"-");
											fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerAssgndDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerAssgndDate);fflush(stdout);
								}
								if(tc_strlen(MbomDsnerRelzdDate)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerRelzdDate,MbomDsnerRelzdDate);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerRelzdDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerRelzdDate);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerRelzdDate,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerRelzdDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomDsnerRelzdDate);fflush(stdout);

								}
								if(tc_strlen(MbomReviewdBy)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewdBy,MbomReviewdBy);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewdBy ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewdBy);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewdBy,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewdBy ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewdBy);fflush(stdout);
								}
								if(tc_strlen(MbomReviewerRlzDate)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewerRlzDate,MbomReviewerRlzDate);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewerRlzDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewerRlzDate);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewerRlzDate,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewerRlzDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomReviewerRlzDate);fflush(stdout);
								}
								if(tc_strlen(MbomManager)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomManager,MbomManager);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomManager ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomManager);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomManager,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomManager ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomManager);fflush(stdout);
								}
								if(tc_strlen(MbomManagerRlzDate)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomManagerRlzDate,MbomManagerRlzDate);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomManagerRlzDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomManagerRlzDate);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].MbomManagerRlzDate,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].MbomManagerRlzDate ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].MbomManagerRlzDate);fflush(stdout);
								}
								fprintf(inputfile,"Entire part Number is %s\n",Assembly);
								if(tc_strlen(Assembly)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].releasedMbomAssmlyNo,Assembly);
											fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].releasedMbomAssmlyNo ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].releasedMbomAssmlyNo);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].releasedMbomAssmlyNo,"-");
											fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].releasedMbomAssmlyNo ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].releasedMbomAssmlyNo);fflush(stdout);
								}

								if(tc_strlen(Dml_Desc)>0)
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Desc,Dml_Desc);
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Desc ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Desc);fflush(stdout);
								}
								else
								{
									tc_strcpy(aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Desc,"-");
										fprintf(inputfile,"aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Desc ==> %s\n",aString_Ret->__ptrRlzDmlData[Linecnt].Dml_Desc);fflush(stdout);
								}
								Linecnt++;
						}
					}
					}
					else
					{
						fprintf(inputfile,"Task Not Found");fflush(stdout);
					}
//				}
//				else
//				{
//					continue;
//				}
			}
		}
	}

	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;

	CLEANUP :

		return SOAP_OK;

	EXIT:
		return SOAP_OK;
}
;
int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new());										/* call the request dispatcher */
};