######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it.
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : JULY-2023
#
#######################################################################################

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "DML Number: -----> "$1

echo "Report Generation Date And Time: -----> "$2

echo "Report File Name: -----> "$3

echo "DML Project Code: -----> "$4

echo "DML Design Group: -----> "$5

echo "JAR Path: -----> "$6

echo -e "\nIn Shell Argument Print Ended...."

echo -e "\nJAR Calling Started...."
#java -jar V6_LCS_PreProd_WS.jar $3
java -jar $6 $3
echo -e "\nJAR Calling Ended...."
echo -e "\nReport Send To User Email Started...."
ls -lrt $3
if [ $? == 0 ]
      then
        echo "File Successfully Found on Server"
        echo "Sending DML Part Transfer Report To User Email"
        echo -e "Dear All, \n\n                Please Check Attached DML Part Transfer Report For CATIA V6.\n                Report Details.\n                DML: $1\n                DML Project Code: $4\n                DML Design Group: $5\n                Report Date: $2\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS : DML Part Transfer Report For CATIA V6" -a $3 sandipb.ttl@tatamotors.com rajeshbasak.ttl@tatamotors.com po.ttl@tatamotors.com ajinkyau.ttl@tatamotors.com schopade.ttl@tatamotors.com souravk.ttl@tatamotors.com
      else
        echo "File NOT Foud on server"
        echo "Sending DML Part Transfer Report To Developer Email"
        echo -e "Dear Team, \n\n                There is Some Issue in Sending DML Part Transfer JAR Calling For CATIA V6.\n                Please Check Log & Transfer Parts To CATIA V6.\n                Report Details.\n                DML: $1\n                DML Project Code: $4\n                DML Design Group: $5\n                Report Date: $2\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED : DML Part Transfer Report For CATIA V6" souravk.ttl@tatamotors.com rajeshbasak.ttl@tatamotors.com 
fi
echo -e "\nReport Send To User Email Ended...."
echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"