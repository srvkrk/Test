//cl tm_Ret_TargetCost.c stdsoap2.c soapServerLib.c soapClientLib.c  soapC.c
//link tm_Ret_TargetCost.obj stdsoap2.obj soapServer.obj soapClientLib.obj soapC.obj -out:tm_Ret_TargetCost.cgi
//sample is on path /user/omf9dev/devgroups/devkant/webservice_1/to_be_publish
#include "soapH.h"
#include "tm_Ret_TargetCost.nsmap"
#define Get_Data_SIZE 100
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <tc/tc_startup.h>

void OUTI(const char *text,const unsigned pos,const unsigned len,int i_str)
{
  printf("%*.0s",pos,text); printf("%-*s : [%d]\n",len,text,i_str);fflush(stdout);
  TC_write_syslog("%*.0s",pos,text); TC_write_syslog("%-*s : [%d]\n",len,text,i_str);fflush(stdout);
  return;
}
void OUTF(const char *text,const unsigned pos,const unsigned len,float f_str)
{
  printf("%*.0s",pos,text); printf("%-*s : [%f]\n",len,text,f_str);fflush(stdout);
  TC_write_syslog("%*.0s",pos,text); TC_write_syslog("%-*s : [%f]\n",len,text,f_str);fflush(stdout);
  return;
}

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("%*.0s",pos,text); printf("%-*s : [%s]\n",len,text,str);fflush(stdout);
  TC_write_syslog("%*.0s",pos,text); TC_write_syslog("%-*s : [%s]\n",len,text,str);fflush(stdout);
  return;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}


int ns__tm_ShouldCostDocCreate(struct soap* soap,char *ShouldCostPdf,struct ns__ShouldCstArray *aString_test)
{
	int d = 1;
//	fpos_t pos;
//	fgetpos(stdout, &pos);
//	int fd = dup(fileno(stdout));
	int i = 0;
	char *pdfpath =	NULL;
	char *lcl_ShouldCostPdf = NULL;
	char *ExtensionTok = NULL;
	char *Typetok = NULL;
	char *Parttok = NULL;
	char *PartRevtok = NULL;
	char *PartSeqtok = NULL;
	char *SerialNumtok = NULL;
	char *PartTypeS = NULL;
	char *PartNumberS = NULL;
	char *PartRevSeq = NULL;
	char *T5_DFC_Document_item_id = NULL;
	char *curentname = NULL;
	tag_t Part_tag = NULLTAG;
	tag_t latestrev = NULLTAG;

	char *ProjctCdeS = NULL;	
	tag_t DatasetType = NULLTAG;
	tag_t dad_tag = NULLTAG;
	int number_of_types1 = 0;
	tag_t *type_tag3 = NULLTAG;
	tag_t object_create_input_tag3 = NULLTAG;
	tag_t DADrevTag = NULLTAG;
	
	tag_t tRelationFind	= NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t DADRel_t = NULLTAG;
	tag_t relationSpeci_type = NULLTAG;;
	char *pdfpath1 =	NULL;
	tag_t PdfDataset = NULLTAG;
	tag_t specificationRel_t = NULLTAG;
	logical checkout = 0;
	logical checkout2 = 0;
	int status_count = 0;
	int ss = 0;
	tag_t *relStatus_list = NULLTAG;
	tag_t status_rel = NULLTAG;
	char *ReleaseStatus = NULL;
	logical retain = 0;
	char *latest_rev_Rel_Stus= NULL;
	tag_t *Dataset_fnd_Tags = NULL;
	int i_resultCount = 0 ;
	int i_dataset_Cnt = 0 ;
	tag_t dataset_obj_type_tag = NULLTAG;
	char dataset_type_name[TCTYPE_name_size_c+1] = "";
	char *pdf_dataset_name = NULL;
	tag_t item_obj_type_tag = NULLTAG;
	char item_type_name[TCTYPE_name_size_c+1] = "";
	tag_t *LstDesrev = NULLTAG;
	tag_t ReqDesrev = NULLTAG;
	int rev_count = 0;
	int rev_index = 0;
	char *s_item_revision_id = NULL;
	char *srch_PartRev = NULL;
	tag_t srch_lat_rev_tag = NULLTAG;

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/ShouldCostPdfCr_log.txt", "w", stdout);
				
							
	//freopen("/tmp/ShouldCostPdfCr_log.txt", "w", stdout);

	OUTS("ShouldCostPdf",10,30,ShouldCostPdf);
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	//ITK_CALL(ITK_init_module("infodba", "infodba", "dba"));
	ITK_CALL(ITK_set_journalling( TRUE ));
	if ( ShouldCostPdf != NULL )
	{
		OUTS("Condition",10,30,"ShouldCostPdf != NULL");
		if ( tc_strlen(ShouldCostPdf) != 0 )//input should have length
		{
			OUTS("Condition",10,30,"tc_strlen(ShouldCostPdf) != 0");
			pdfpath	= NULL;
			pdfpath	= (char *)MEM_alloc(250);
			lcl_ShouldCostPdf =	(char *)MEM_alloc(50);
			tc_strcpy(lcl_ShouldCostPdf,ShouldCostPdf);
			OUTS("lcl_ShouldCostPdf",10,30,lcl_ShouldCostPdf);

			tc_strcpy(pdfpath,"");
			tc_strcat(pdfpath,"/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/PDFFiles");//location for uaprod provided by Richa
			//tc_strcat(pdfpath,"D:\\");//for windows testing
			tc_strcat(pdfpath,"/");
			tc_strcat(pdfpath,ShouldCostPdf);
			OUTS("pdfpath",10,30,pdfpath);

			
			ExtensionTok = NULL;
			Typetok = NULL;
			Parttok = NULL;
			PartRevtok = NULL;
			PartSeqtok = NULL;
			SerialNumtok = NULL;

			ExtensionTok = tc_strtok(lcl_ShouldCostPdf, ".");//remove .pdf extension
			Typetok = tc_strtok(lcl_ShouldCostPdf, "_");// DFA
			Parttok = tc_strtok(NULL, "_");		// 1234567
			PartRevtok = tc_strtok(NULL, "_");	//NR
			PartSeqtok = tc_strtok(NULL, "_");	//1
			SerialNumtok = tc_strtok(NULL, "_");//01

			OUTS("Typetok",10,30,Typetok);
			OUTS("Parttok",10,30,Parttok);
			OUTS("PartRevtok",10,30,PartRevtok);
			OUTS("PartSeqtok",10,30,PartSeqtok);
			OUTS("SerialNumtok",10,30,SerialNumtok);
			PartRevSeq = MEM_alloc(5);
			T5_DFC_Document_item_id = MEM_alloc(50);

			tc_strcpy(PartRevSeq,PartRevtok);
			OUTS("PartRevSeq",10,30,PartRevSeq);

			//Document item_id like DFC_544565708202
			tc_strcpy(T5_DFC_Document_item_id,Typetok);
			tc_strcat(T5_DFC_Document_item_id,"_");
			tc_strcat(T5_DFC_Document_item_id,Parttok);
			tc_strcat(T5_DFC_Document_item_id,"_");
			tc_strcat(T5_DFC_Document_item_id,PartRevtok);
			tc_strcat(T5_DFC_Document_item_id,"_");
			tc_strcat(T5_DFC_Document_item_id,PartSeqtok);
			tc_strcat(T5_DFC_Document_item_id,"_");
			tc_strcat(T5_DFC_Document_item_id,SerialNumtok);
		
			OUTS("T5_DFC_Document_item_id",10,30,T5_DFC_Document_item_id);

			PartTypeS = (char *)MEM_alloc(10);
			tc_strcpy(PartTypeS,Typetok);
			OUTS("PartTypeS",10,30,PartTypeS);
			
			PartNumberS = (char	*)MEM_alloc(50);
			tc_strcpy(PartNumberS,Parttok);
			OUTS("PartNumberS",10,30,PartNumberS);

			ITK_CALL(ITEM_find_item (PartNumberS,&Part_tag));
			if ( Part_tag == NULLTAG )
			{
				OUTS("Part Tag not found",10,30,"");

				aString_test->__ShouldCstArrsize = d;
				aString_test->__sptrItem = malloc( (aString_test->__ShouldCstArrsize + 1) * sizeof(*aString_test->__sptrItem) );
				
				for( i = 0; i < 1; i++ )
				{
					aString_test->__sptrItem[i].ShouldCostPdf = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdf,PartNumberS); //Error Message
						
					//Error Message
					aString_test->__sptrItem[i].ShouldCostPdfErrMsg = malloc(100 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,"Part Tag not found"); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg," "); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,ShouldCostPdf);
					OUTS("Error",10,30,"Part Tag not found");

					fflush(stdout);
					dup2(fd, fileno(stdout));
					close(fd);
					clearerr(stdout);
					fsetpos(stdout, &pos);
					ITK_CALL(POM_logout ( false ) ) ;
					return SOAP_OK;	
				}
			}

//			ITK_CALL(ITEM_ask_latest_rev(Part_tag,&latestrev));
//			if ( latestrev == NULLTAG )
//			{
//				OUTS("Part latest revision Tag not found",10,30,"");
//			}

			ITK_CALL(ITEM_list_all_revs(Part_tag,&rev_count,&LstDesrev));//item_revision_id ------------------------------
			OUTI("no of rev_count",10,30,rev_count);
			if ( rev_count <= 0 )
			{
				OUTS("Part revision Tags not found",10,30,"");

				aString_test->__ShouldCstArrsize = d;
				aString_test->__sptrItem = malloc( (aString_test->__ShouldCstArrsize + 1) * sizeof(*aString_test->__sptrItem) );
				
				for( i = 0; i < 1; i++ )
				{
					aString_test->__sptrItem[i].ShouldCostPdf = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdf,PartNumberS); //Error Message
						
					//Error Message
					aString_test->__sptrItem[i].ShouldCostPdfErrMsg = malloc(100 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,"Part revision Tags not found"); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg," "); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,ShouldCostPdf);
					OUTS("Error",10,30,"Part revision Tags not found");
					fflush(stdout);
					dup2(fd, fileno(stdout));
					close(fd);
					clearerr(stdout);
					fsetpos(stdout, &pos);
					ITK_CALL(POM_logout ( false ) ) ;
					return SOAP_OK;	
				}
			}
			else
			{
				srch_PartRev = MEM_alloc(10);
				tc_strcpy(srch_PartRev,PartRevtok);
				tc_strcat(srch_PartRev,";");

				for ( rev_index = (rev_count-1); rev_index >=0 ; rev_index = rev_index - 1 )
				{
					ITK_CALL(AOM_ask_value_string(LstDesrev[rev_index],"item_revision_id",&s_item_revision_id));
					OUTI("rev_index",10,30,rev_index);
					OUTS("Revision",10,30,s_item_revision_id);
					if ( tc_strstr(s_item_revision_id,srch_PartRev) != NULL )
					{
						srch_lat_rev_tag = LstDesrev[rev_index];
						break;
					}
					
				}
			}
			
			if ( srch_lat_rev_tag == NULLTAG )
			{
				OUTS("Part searched rev Tag not found",10,30,"");

				aString_test->__ShouldCstArrsize = d;
				aString_test->__sptrItem = malloc( (aString_test->__ShouldCstArrsize + 1) * sizeof(*aString_test->__sptrItem) );
				
				for( i = 0; i < 1; i++ )
				{
					aString_test->__sptrItem[i].ShouldCostPdf = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdf,PartNumberS); //Error Message
						
					//Error Message
					aString_test->__sptrItem[i].ShouldCostPdfErrMsg = malloc(100 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,"Part searched rev Tag not found"); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg," "); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,ShouldCostPdf);

					fflush(stdout);
					dup2(fd, fileno(stdout));
					close(fd);
					clearerr(stdout);
					fsetpos(stdout, &pos);
					ITK_CALL(POM_logout ( false ) ) ;
					return SOAP_OK;	
				}
			}
			ITK_CALL(TCTYPE_ask_object_type(srch_lat_rev_tag, &item_obj_type_tag));
			ITK_CALL(TCTYPE_ask_name(item_obj_type_tag, item_type_name));
			OUTS("item_type_name",10,30,item_type_name);

			if (tc_strcmp( item_type_name, "Design Revision" ) == 0 )
			{
				ITK_CALL( AOM_ask_value_string(srch_lat_rev_tag,"t5_ProjectCode",&ProjctCdeS));
				
				OUTS("project code",10,30,ProjctCdeS);

				if(access(pdfpath,F_OK)!=-1)//file found
				{
					OUTS("File found",10,30,ShouldCostPdf);
					if (tc_strstr(pdfpath,".pdf")!=NULL)
					{
					
						OUTS("PDF FOUND",10,30,"");
						ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));

						if((tc_strcmp(PartTypeS,"DFC")==0))
						{
							ITK_CALL(ITEM_find_item (T5_DFC_Document_item_id,&dad_tag));
							if (dad_tag!=NULLTAG)
							{
								OUTS("T5_DFC_Document already exists",10,30,"OK");
							}
							else
							{					
								OUTS("T5_DFC_Document does not exist hence creating",10,30,"OK");
								ITK_CALL(TCTYPE_find_types_for_class("T5_DFC_Document",&number_of_types1,&type_tag3));
								TC_write_syslog("\nnumber_of_types T5_DFC_Document-------->  : %d\n",number_of_types1);fflush(stdout);
								ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
								ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",T5_DFC_Document_item_id));
								ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc","PFIRST DATA"));
								ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &dad_tag));//DFA Item Master
								OUTS("obj dad_tag created",10,30,"OK");
								ITK_CALL(AOM_save(dad_tag));
								
							}

							ITK_CALL(ITEM_ask_latest_rev(dad_tag,&DADrevTag));					//DFA Item Revision

							OUTS("AFTER 4D_REV_TAG",10,30,"OK");
							ITK_CALL(AOM_lock(DADrevTag));
							//ITK_CALL(AOM_set_value_string(DADrevTag,"t5_DsgnNum",T5_DFC_Document_item_id));
							//ITK_CALL(AOM_set_value_string(DADrevTag,"item_revision_id","A;1"));//NEW CHANGE
							ITK_CALL(AOM_set_value_string(DADrevTag,"item_revision_id",PartRevSeq));//NEW CHANGE
							ITK_CALL(AOM_set_value_int(DADrevTag,"sequence_id",atoi(PartSeqtok)));//NEW CHANGE
							ITK_CALL(AOM_set_value_string(DADrevTag,"t5_Should_Run_Serial",SerialNumtok));//NEW CHANGE//t5_Should_Run_Serial 
							
							ITK_CALL(AOM_save(DADrevTag));
							ITK_CALL(AOM_unlock(DADrevTag));
							OUTS("AFTER setting value on dad revision",10,30,"OK");
							OUTS("CREATING RELATION BETWEEN PART AND DAD DOC",10,30,"OK");
							
							ITK_CALL(GRM_find_relation_type("T5_PartHasDFC",&tRelationFind));

							if (tRelationFind!=NULLTAG && DADrevTag !=NULLTAG && DADrevTag!=NULLTAG)
							{
								OUTS("CREATING GRM_find_relation",10,30,"OK");
								ITK_CALL( GRM_find_relation(srch_lat_rev_tag,DADrevTag,tRelationFind,&tRelationExist)); 

								OUTS("AFTER TESTING HERE tRelationExist",10,30,"OK");
								if(tRelationExist)
								{
									OUTS("tRelationExist tRelationExist tRelationExist",10,30,"OK");
								}
								else
								{
									OUTS("tRelationExist DOES NOT EXIST HENCE CREATING",10,30,"OK");
									ITK_CALL(GRM_create_relation(srch_lat_rev_tag,DADrevTag,tRelationFind,NULLTAG,&DADRel_t));//latest part revision and dad doc revision
									ITK_CALL(GRM_save_relation(DADRel_t));
									ITK_CALL(AOM_refresh(srch_lat_rev_tag,0));
								}
							}
								  
							ITK_CALL(GRM_find_relation_type("IMAN_specification", &relationSpeci_type));
							if(relationSpeci_type != NULLTAG)
							{
								OUTS("Attaches/IMAN SPECIFICATION Relationship tag found",10,30,"OK");
								ITK_CALL(AE_find_all_datasets2( ShouldCostPdf,&i_resultCount, &Dataset_fnd_Tags ) ) ;

								TC_write_syslog("\ni_resultCount:%d\n",i_resultCount);
								TC_write_syslog("\nShouldCostPdf:%s\n",ShouldCostPdf);
								
								for ( i_dataset_Cnt = 0 ; i_dataset_Cnt < i_resultCount ; i_dataset_Cnt++ )
								{

									ITK_CALL(TCTYPE_ask_object_type(Dataset_fnd_Tags[i_dataset_Cnt], &dataset_obj_type_tag));
									ITK_CALL(TCTYPE_ask_name(dataset_obj_type_tag, dataset_type_name));
									OUTS("dataset_type_name",10,30,dataset_type_name);

									ITK_CALL(AOM_ask_value_string(Dataset_fnd_Tags[i_dataset_Cnt], "object_name", &pdf_dataset_name));
									OUTS("pdf_dataset_name",10,30,pdf_dataset_name);
								}

								if ( i_resultCount <= 0 )
								{

									ITK_CALL(AE_create_dataset_with_id(DatasetType,ShouldCostPdf,"PDF Dataset Creation Tool","","",&PdfDataset));
									ITK_CALL(AE_save_myself(PdfDataset));

									OUTS("PDF created",10,30,"OK");
								}
								else
								{
									OUTS("PDF already exist with same name hence skipped creation",10,30,"OK");
								}

								if(PdfDataset != NULLTAG)
								{
									OUTS("CREATING GRM_create_relation",10,30,"OK");
									ITK_CALL(GRM_create_relation(DADrevTag,PdfDataset,relationSpeci_type,NULLTAG,&specificationRel_t));//dad doc revision and pdf
									ITK_CALL(GRM_save_relation(specificationRel_t));
									if(specificationRel_t != NULLTAG)
									{
										OUTS("Spec rel found",10,30,"OK");
										
										ITK_CALL(AOM_refresh(PdfDataset,TRUE));
										ITK_CALL(AE_import_named_ref(PdfDataset,"PDF_Reference",pdfpath,NULL,SS_BINARY));

										AOM_save(PdfDataset);
										AOM_refresh(PdfDataset, FALSE);
										AOM_unload(PdfDataset);
										ITK_CALL(AE_save_myself(PdfDataset));
										OUTS("AFTER IMPORTING NAMED REFERENCE",10,30,"OK");
										
										OUTS("check in the 4D Doc",10,30,"OK");

										ITK_CALL(RES_is_checked_out(DADrevTag,&checkout));
										OUTS("Value of checkout Attribute in Checkin DADrevTag",10,30,"OK");
										OUTI("Value of checkout Attribute in Checkin DADrevTag",10,30,checkout);
										if (checkout==1)
										{
											ITK_CALL(RES_checkin(DADrevTag));
											OUTI("DADrevTag Checked In",10,30,checkout);
											OUTS("DADrevTag Checked In",10,30,"OK");
										}									
										  
										ITK_CALL(RES_is_checked_out(PdfDataset,&checkout2));
										OUTI("Value of checkout Attribute in Checkin PdfDataset",10,30,checkout2);
										if (checkout2==1)
										{
											ITK_CALL(RES_checkin(PdfDataset));
											OUTS("PdfDataset Checked In",10,30,"OK");
										}
									

										ITK_CALL(WSOM_ask_release_status_list(srch_lat_rev_tag, &status_count, &relStatus_list));
										if(status_count>0)
										{
											for(ss=0; ss<status_count ; ss++)
											{
												ITK_CALL(AOM_ask_value_string(relStatus_list[ss],"object_name",&latest_rev_Rel_Stus));
												OUTS("latest_rev_Rel_Stus",10,30,latest_rev_Rel_Stus);
											
												if((strcmp(latest_rev_Rel_Stus,"ERC Review")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsReview")==0))
												{
													ITK_CALL (CR_create_release_status("T5_LcsReview",&status_rel));
													ITK_CALL( AOM_ask_name(status_rel, &ReleaseStatus));
													ITK_CALL(EPM_add_release_status(status_rel,1,&DADrevTag,retain));
													OUTS("after setting review status to the 4D Doc",10,30,"OK");
												}

												else if((strcmp(latest_rev_Rel_Stus,"ERC Released")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsErcRlzd")==0))
												{
													ITK_CALL (CR_create_release_status("T5_LcsErcRlzd",&status_rel));
													ITK_CALL( AOM_ask_name(status_rel, &ReleaseStatus));
													ITK_CALL(EPM_add_release_status(status_rel,1,&DADrevTag,retain));
													OUTS("after setting release status to the 4D Doc",10,30,"OK");
												}
											}
										}
									}
								}
							}					
						}

					}
					
				}
				else//file not found hence return error
				{
					OUTS("No such File found",10,30,ShouldCostPdf);
					aString_test->__ShouldCstArrsize = d;
					aString_test->__sptrItem = malloc( (aString_test->__ShouldCstArrsize + 1) * sizeof(*aString_test->__sptrItem) );
					
					for( i = 0; i < 1; i++ )
					{
						aString_test->__sptrItem[i].ShouldCostPdf = malloc(50 * sizeof(char *) );
						strcpy(aString_test->__sptrItem[i].ShouldCostPdf,ShouldCostPdf); //Error Message
							
						//Error Message
						aString_test->__sptrItem[i].ShouldCostPdfErrMsg = malloc(100 * sizeof(char *) );
						strcpy(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,"Given PDF does not exist on path"); 
						strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg," "); 
						strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,ShouldCostPdf);
						OUTS("Error",10,30,"Given PDF does not exist on path");
					}
					ITK_CALL(POM_logout ( false ) ) ;
					return SOAP_OK;	
				}

				aString_test->__ShouldCstArrsize = d;
				aString_test->__sptrItem = malloc( (aString_test->__ShouldCstArrsize + 1) * sizeof(*aString_test->__sptrItem) );
				for( i = 0; i < 1; i++ )
				{
					aString_test->__sptrItem[i].ShouldCostPdf = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdf,ShouldCostPdf); //Error Message
					
					//Error Message
					aString_test->__sptrItem[i].ShouldCostPdfErrMsg = malloc(100 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,"Doc object Created Sucessfully"); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg," "); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,ShouldCostPdf);
					OUTS("Success",10,30,"Doc object Created Sucessfully");
				}
			}
			else if (tc_strcmp( item_type_name, "Design Revision" ) != 0 )
			{
				aString_test->__ShouldCstArrsize = d;
				aString_test->__sptrItem = malloc( (aString_test->__ShouldCstArrsize + 1) * sizeof(*aString_test->__sptrItem) );
				for( i = 0; i < 1; i++ )
				{
					aString_test->__sptrItem[i].ShouldCostPdf = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdf,ShouldCostPdf); //Error Message
					
					//Error Message
					aString_test->__sptrItem[i].ShouldCostPdfErrMsg = malloc(100 * sizeof(char *) );
					strcpy(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,"Design Revision not found for Given Document"); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg," "); 
					strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,ShouldCostPdf);
					OUTS("Error",10,30,"Design Revision not found for Given Document");
				}
			}
		}
		else if ( tc_strlen(ShouldCostPdf) == 0 )//blank pdf input
		{
			OUTS("Condition",10,30,"else if ( tc_strlen(ShouldCostPdf) == 0 )");
			aString_test->__ShouldCstArrsize = d;
			aString_test->__sptrItem = malloc( (aString_test->__ShouldCstArrsize + 1) * sizeof(*aString_test->__sptrItem) );
			
			for( i = 0; i < 1; i++ )
			{
				aString_test->__sptrItem[i].ShouldCostPdf = malloc(50 * sizeof(char *) );
				strcpy(aString_test->__sptrItem[i].ShouldCostPdf,"NO PDF Name__"); //Error Message
					
				//Error Message
				aString_test->__sptrItem[i].ShouldCostPdfErrMsg = malloc(100 * sizeof(char *) );
				strcpy(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,"PDF Name is 0 length. Provide Valid input name"); 
				strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg," "); 
				strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,ShouldCostPdf);
				OUTS("Error",10,30,"PDF Name is 0 length. Provide Valid input name");
			}
		}
	}
	else if ( ShouldCostPdf == NULL )
	{
		OUTS("Condition",10,30,"else if ( ShouldCostPdf == NULL )");
		aString_test->__ShouldCstArrsize = d;
		aString_test->__sptrItem = malloc( (aString_test->__ShouldCstArrsize + 1) * sizeof(*aString_test->__sptrItem) );
		
		for( i = 0; i < 1; i++ )
		{
			aString_test->__sptrItem[i].ShouldCostPdf = malloc(50 * sizeof(char *) );
			strcpy(aString_test->__sptrItem[i].ShouldCostPdf,"NO PDF Name-"); //Error Message
				
			//Error Message
			aString_test->__sptrItem[i].ShouldCostPdfErrMsg = malloc(100 * sizeof(char *) );
			strcpy(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,"PDF Name is NULL. Provide Valid input name"); 
			strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg," "); 
			strcat(aString_test->__sptrItem[i].ShouldCostPdfErrMsg,ShouldCostPdf);
			OUTS("Error",10,30,"PDF Name is NULL. Provide Valid input name");
		}
	}
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
	ITK_CALL(POM_logout ( false ) ) ;	
	return SOAP_OK;	
}
int ns__tm_Ret_TargetCost(struct soap* soap,char *TCT_item_id,char *ModuleNumber,struct ns__CharArray *aString_test)
{
		int d = 1;
		char *responseString = NULL;
		tag_t tct_item_module_Qry = NULLTAG;
		tag_t *t_tct_row_ObjTags = NULLTAG;
		char *entry_fields[2] = {"ID","Module Address"};
		char *value_fields[2]  = {TCT_item_id,ModuleNumber};
		int no_of_entry = 2;
		int i_tct_row_obj_Count = 0;
		int i_index_tct_row_obj = 0;
		char *s_Module = NULL;
		char *s_tct_description = NULL;
		double f_TargetCost = 0.0;
		double f_TargetToolingCpx = 0.0;
		int i = 0;

		char *item_type = NULL;
		char *s_ProjectDescription = NULL;
		
		tag_t tct_item_tag = NULLTAG;
		//tag_t latest_tct_item_rev = NULLTAG;

		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/TCT_log.txt", "w", stdout);
		

		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		ITK_CALL(ITK_auto_login( ));
		//ITK_CALL(ITK_init_module("infodba", "infodba", "dba"));
		ITK_CALL(ITK_set_journalling( TRUE ));
		
		OUTS("TCT_item_id",10,30,TCT_item_id);
		OUTS("ModuleNumber",10,30,ModuleNumber);

		//tm_TCT_Table_row_qry1
		//Revision
		//ID
		//Module Address
		
		//--------------Proj Desc from Item-------------
		ITK_CALL(ITEM_find_item(  TCT_item_id, &tct_item_tag ));
		if ( tct_item_tag == NULLTAG )
		{
			aString_test->__size = d;
			aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
				
			for( i = 0; i < 1; i++ )
			{
				aString_test->__ptrItem[i].TCT_item_id = malloc(40 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].TCT_item_id,"TCT Not found"); //TCT_item_id

				aString_test->__ptrItem[i].ModuleNumber = malloc(40 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].ModuleNumber,"module Not found"); //ModuleNumber

				aString_test->__ptrItem[i].s_Module = malloc(40 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].s_Module,"s_Module Not found"); //s_Module

				aString_test->__ptrItem[i].s_tct_description = malloc(100 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].s_tct_description,"s_tct_description Not found"); //s_tct_description

				aString_test->__ptrItem[i].f_TargetCost = 0.000;

				aString_test->__ptrItem[i].f_TargetToolingCpx = 0.000;
			}
			OUTS("Error",10,30,"No record found for given input TCT-Item");
			return SOAP_OK;
		}
		ITK_CALL(ITEM_ask_type2 (tct_item_tag, &item_type));
		OUTS("item_type",10,30,item_type);
		if ( tc_strcmp ( item_type, "T5_DFC_TCT" ) == 0 )
		{
			ITK_CALL ( AOM_ask_value_string ( tct_item_tag, "t5_ProjectDescription" , &s_ProjectDescription ) );
			OUTS("s_ProjectDescription",10,30,s_ProjectDescription);
		}
		//--------------Proj Desc from Item-------------

		ITK_CALL(QRY_find("tm_TCT_Table_row_qry1", &tct_item_module_Qry));
		ITK_CALL(QRY_execute(tct_item_module_Qry,no_of_entry,entry_fields,value_fields,&i_tct_row_obj_Count,&t_tct_row_ObjTags));
		
		OUTI("i_tct_row_obj_Count",10,30,i_tct_row_obj_Count);
		if ( i_tct_row_obj_Count > 0 )
		{
			
			for (i_index_tct_row_obj = 0; i_index_tct_row_obj < i_tct_row_obj_Count; i_index_tct_row_obj++)
			{
				ITK_CALL ( AOM_ask_value_string(t_tct_row_ObjTags[i_index_tct_row_obj],"t5_Module",&s_Module));
				OUTS("s_Module",10,30,s_Module);

				
				ITK_CALL ( AOM_ask_value_double(t_tct_row_ObjTags[i_index_tct_row_obj],"t5_TargetDMC",&f_TargetCost));
				OUTF("f_TargetCost",10,30,f_TargetCost);
				
				ITK_CALL ( AOM_ask_value_double(t_tct_row_ObjTags[i_index_tct_row_obj],"t5_TrgtToolCpx",&f_TargetToolingCpx));
				OUTF("f_TargetToolingCpx",10,30,f_TargetToolingCpx);
				
				aString_test->__size = d;
				aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
			

				s_Module [ tc_strlen(s_Module) ] = '\0';

				for( i = 0; i < 1; i++ )
				{
					
					aString_test->__ptrItem[i].TCT_item_id = malloc(40 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].TCT_item_id,TCT_item_id); //TCT_item_id

					aString_test->__ptrItem[i].ModuleNumber = malloc(40 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].ModuleNumber,ModuleNumber); //ModuleNumber

					aString_test->__ptrItem[i].s_Module = malloc(40 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].s_Module,s_Module); //s_Module

					aString_test->__ptrItem[i].s_tct_description = malloc(100 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].s_tct_description,s_ProjectDescription); //s_tct_description

					aString_test->__ptrItem[i].f_TargetCost = f_TargetCost;

					aString_test->__ptrItem[i].f_TargetToolingCpx = f_TargetToolingCpx;

					OUTS("Copying to struct completed",10,30,"done");
				}
			}

		}
		else
		{
			aString_test->__size = d;
			aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
				
			for( i = 0; i < 1; i++ )
			{
				aString_test->__ptrItem[i].TCT_item_id = malloc(40 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].TCT_item_id,"TCT Not found"); //TCT_item_id

				aString_test->__ptrItem[i].ModuleNumber = malloc(40 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].ModuleNumber,"module Not found"); //ModuleNumber

				aString_test->__ptrItem[i].s_Module = malloc(40 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].s_Module,"Not found"); //s_Module

				aString_test->__ptrItem[i].s_tct_description = malloc(100 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].s_tct_description,"tct_description not found"); //s_tct_description

				aString_test->__ptrItem[i].f_TargetCost = 0.000;

				aString_test->__ptrItem[i].f_TargetToolingCpx = 0.000;
			}
			OUTS("No record found for given input TCT-Item and module",10,30,"done");
		}
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);
		ITK_CALL(POM_logout ( false ) ) ;
		return SOAP_OK;
}


extern int ITK_user_main(int argc, char *argv[])
{
		return soap_serve(soap_new()); 

}
