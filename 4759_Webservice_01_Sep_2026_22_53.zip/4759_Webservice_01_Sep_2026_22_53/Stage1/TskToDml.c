#define _CLMAIN_DEFNS
#include <cfg.h>
#include <cl.h>
#include <ft.h>
#include <malloc.h>
#include <meta.h>
#include <mserv.h>
#include <msg.h>
#include <msgapc.h>
#include <msglcm.h>
#include <msgomf.h>
#include <msgtel.h>
#include <Mtimsg.h>
#include <Mtimsgh.h>
#include <mutproto.h>
#include <nls.h>
#include <pdmc.h>
#include <pdmitem.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <sc.h>
#include <serv.h>
#include <status.h>
#include <stdlib.h>
#include <string.h>
#include <sys.h>
#include <tel.h>
#include <ui.h>
#include <usc.h>
#include "soapH.h"
#include "TskToDml.nsmap"

int main(int argc, char *argv[])
{
	t5MethodInitWMD("TskToDml.c");
	dstat = clInitMB2 (argc,&argv,NULL);
	return soap_serve(soap_new()); /* call the request dispatcher */

}
;

int ns__getTskToDml(struct soap* soap,char *tasknumber, char **Response)
{
	FILE           *tsktodml;
	
	string		    FileNameDup			=	NULL;
	string			TodayDate			=	NULL;
	string			TskNumDup			=	NULL;
	string			TskNum				=	NULL;
	string			DmlNumDup			=	NULL;
	string			DmlNum				=	NULL;

	ObjectPtr		oTsk				=	NULL;
	ObjectPtr		oDml				=	NULL;

	SetOfObjects    soTsk				=   NULL;
	SetOfObjects    soDml				=   NULL;

	SetOfStrings	strDbScope			=	NULL;
	
	SqlPtr          Sql_ptr				=   NULL;

	//UA Variable
	string			StrFullPathShell	=	NULL;
	string			sysdate				=	NULL;
	string			inputfile			=	NULL;
	char			fileRead[500];
	const char		*txtargv[3];
	int				cnt					=	0;
	int				SysReturn			=	0;
	FILE           *fp1;
	//UA ENDS
	status dstat	=	OKAY;
	int mfail		=	USC_OKAY;

	//char* mod_name="ns__ConnectionTest";
	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/log1.txt", "w", stdout);

	if (dstat = clInitialize2 (TRUE)) goto CLEANUP;
//	if (dstat = clLogin2 ("Loader","123loader",&mfail))goto CLEANUP;
	//if (dstat = clLogin2 ("hps08540","Nexon@123",&mfail))goto CLEANUP;
//	if (mfail!=OKAY)
//	{
		//printf("\nLogin Failed \n"); fflush(stdout);
//		goto EXIT;
//	}

//	if (dstat = clLogin2 ("Loader","123loader",&mfail))goto CLEANUP;
//	if (mfail!=OKAY)//
//	{
//		//printf("\n Invalid User Name or PasswordS : 'Loader' \n");  fflush(stdout);
//		goto EXIT;
//	}
	
	FileNameDup		=	nlsStrAlloc(500);

	TodayDate=sysGetCTime();

	low_strrpl(TodayDate,' ','_');
	low_strrpl(TodayDate,':','_');

	nlsStrCpy(FileNameDup,"/plmuv_logs/omfprod/logs/");
	nlsStrCat(FileNameDup,"TskToDml_");
	nlsStrCat(FileNameDup,TodayDate);
	nlsStrCat(FileNameDup,".log");



	tsktodml = fopen(FileNameDup , "a+") ;
	if(FileNameDup==NULL)
	{
		goto EXIT;
	}


	//if(dstat = smSetSessionDbScope(strDbScope)) goto CLEANUP;
	//if(dstat = SetDatabaseScope(strDbScope)) goto CLEANUP;

 if(dstat = GetDatabaseScope(PdmSessnClass,&strDbScope,&mfail))  goto EXIT;
  fprintf(tsktodml,"\n GetDatabaseScope****");fflush(tsktodml);

  	strDbScope = low_set_create_str(2);
	low_set_add_str_unique(strDbScope,"supprod");
	low_set_add_str_unique(strDbScope,"sujprod");
	low_set_add_str_unique(strDbScope,"suhprod");
	low_set_add_str_unique(strDbScope,"sulprod");

	if(dstat = SetDatabaseScope(PdmSessnClass,strDbScope,&mfail)) goto EXIT;
	 fprintf(tsktodml,"\n SetDatabaseScope****");fflush(tsktodml);


	fprintf(tsktodml,"\n********WEB SERVICE CALLED FOR BOM PART CHECK New***********");fflush(tsktodml);
	fprintf(tsktodml,"\n TASK NUMBER	:	[%s]",tasknumber);fflush(tsktodml);

	if (nlsStrStr(tasknumber,"APL")!=NULL || nlsStrStr(tasknumber,"STD")!=NULL)
	{
		fprintf(tsktodml,"\n CHECKING FOR DML new	:	[%s]",tasknumber);
		//Query Task DML
		if(Sql_ptr)	oiSqlDispose(Sql_ptr); Sql_ptr = NULL;
		if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(Sql_ptr,WbsIDAttr,tasknumber)) goto CLEANUP;
		//if(dstat = oiSqlPrint(Sql_ptr));
		if(dstat = QueryDbObject(CmTaskItClass,Sql_ptr,-1,TRUE,SC_SCOPE_OF_SESSION,&soTsk,&mfail));
		fprintf(tsktodml,"\n No of Task Found	:	[%d]",setSize(soTsk));fflush(tsktodml);

		if (setSize(soTsk)>0)
		{
			oTsk	=	setGet(soTsk,0);

			if(dstat = objGetAttribute(oTsk,WbsIDAttr,&TskNumDup)) goto EXIT;
			if(!nlsIsStrNull(TskNumDup))
				TskNum	=	nlsStrDup(TskNumDup);
			fprintf(tsktodml,"\n TASK NUMBER	:	[%s]",TskNum);fflush(tsktodml);

			fprintf(tsktodml,"\n GOING TO FETCH DML FROM TASK");fflush(tsktodml);
			
			if(dstat = ExpandObject5(CmPlRvRvClass,oTsk,"CMPlanRollsUpInTo",SC_SCOPE_OF_SESSION,&soDml,&mfail)) goto CLEANUP;
			fprintf(tsktodml,"\n No of Dml Found	:	[%d]",setSize(soDml));fflush(tsktodml);

			if (setSize(soDml)>0)
			{
				oDml	=	setGet(soDml,0);

				if(dstat = objGetAttribute(oDml,WbsIDAttr,&DmlNumDup)) goto EXIT;
				if(!nlsIsStrNull(DmlNumDup))
					DmlNum	=	nlsStrDup(DmlNumDup);
				*Response = (char *) malloc( (50) * sizeof(char));
				nlsStrCpy(*Response,DmlNum);
				fprintf(tsktodml,"\n DML NUMBER	:	[%s]",DmlNum);fflush(tsktodml);
			}
			else
			{
				*Response = (char *) malloc( (50) * sizeof(char));
				nlsStrCpy(*Response,"-1");
			}
		}
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		else if(nlsStrStr(tasknumber,"APLC")!=NULL || nlsStrStr(tasknumber,"STDC")!=NULL || nlsStrStr(tasknumber,"APLA")!=NULL || nlsStrStr(tasknumber,"STDA")!=NULL)
		{
			fprintf(tsktodml,"\n Task not found in TCE, check in TCUA UA");
			StrFullPathShell = nlsStrAlloc(200);//"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass"
			nlsStrCpy(StrFullPathShell,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/TskToDML.sh");
			
			txtargv[0] = StrFullPathShell;
			txtargv[1] = tasknumber;
			txtargv[2] = NULL;


			for (cnt = 0;cnt < 1; cnt++ )
			{
				fprintf(tsktodml,"txtargv[%d] : [%s]", cnt, txtargv[cnt]); fflush(tsktodml);
			}

			fprintf(tsktodml,"\nStrFullPathShell : [%s]", StrFullPathShell); fflush(tsktodml);

			SysReturn = sysExecute(StrFullPathShell, txtargv);
			if(SysReturn == 0)
			{
				fprintf(tsktodml,"\n Execution Done Successfully ...");  fflush(tsktodml);
			}
			else
			{
				fprintf(tsktodml,"\n Execution Done Fail, Pl check Env variable and calling shell..\n");  fflush(tsktodml);
			}

			sysdate		=	sysGetDate();
			low_strrpl(sysdate,'-','_');
			//low_strrpl(sysdate,' ','_');
			fprintf(tsktodml,"\n sysdate : %s",sysdate);  fflush(tsktodml);
			inputfile	=	nlsStrAlloc(nlsStrLen("/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/")+100);
			nlsStrCpy(inputfile,"");
			nlsStrCat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass");
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,sysdate);
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,tasknumber);
			nlsStrCat(inputfile,"_");
			//nlsStrCat(inputfile,plant);
			nlsStrCat(inputfile,"TskToDML");
			nlsStrCat(inputfile,".txt");
			fprintf(tsktodml,"\nFilename : %s",inputfile);fflush(tsktodml);

			fp1=fopen(inputfile,"r");
			if(fp1!=NULL)
			{
				while (fgets(fileRead,500,fp1)!=NULL )
				{
					fprintf(tsktodml,"\n  DML in TCUA: [%s] FOUND IN PLM\n", tasknumber);fflush(tsktodml);
					*Response = (char *) malloc( (50) * sizeof(char));
					nlsStrCpy(*Response,fileRead);//TASK NOT FOUND
				}
			}
			else
			{
				fprintf(tsktodml,"\n  DML in TCUA: [%s] FOUND IN PLM\n", tasknumber);fflush(tsktodml);
				*Response = (char *) malloc( (50) * sizeof(char));
				nlsStrCpy(*Response,"-1");//TASK NOT FOUND
			}

		}
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		else
		{
			//*Response = (char *) malloc( (50) * sizeof(char));
			//nlsStrCpy(*Response,"-1");

			fprintf(tsktodml,"\n Task not found in TCE, check in TCUA CV");fflush(tsktodml);
			StrFullPathShell = nlsStrAlloc(200);//"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass"
			nlsStrCpy(StrFullPathShell,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/TskToDML_CV.sh");
			
			txtargv[0] = StrFullPathShell;
			txtargv[1] = tasknumber;
			txtargv[2] = NULL;


			for (cnt = 0;cnt < 1; cnt++ )
			{
				fprintf(tsktodml,"\ntxtargv[%d] : [%s]", cnt, txtargv[cnt]); fflush(tsktodml);
			}

			fprintf(tsktodml,"\nStrFullPathShell : [%s]", StrFullPathShell); fflush(tsktodml);

			SysReturn = sysExecute(StrFullPathShell, txtargv);
			if(SysReturn == 0)
			{
				fprintf(tsktodml,"\n Execution Done Successfully ...");  fflush(tsktodml);
			}
			else
			{
				fprintf(tsktodml,"\n Execution Done Fail, Pl check Env variable and calling shell..\n");  fflush(tsktodml);
			}

			sysdate		=	sysGetDate();
			low_strrpl(sysdate,'-','_');
			//low_strrpl(sysdate,' ','_');
			fprintf(tsktodml,"\n sysdate : %s",sysdate);  fflush(tsktodml);

			inputfile	=	nlsStrAlloc(nlsStrLen("/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/")+100);
			nlsStrCpy(inputfile,"");
			nlsStrCat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass");
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,sysdate);
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,tasknumber);
			nlsStrCat(inputfile,"_TskToDML");
			nlsStrCat(inputfile,".txt");
			fprintf(tsktodml,"\nFilename : %s",inputfile);fflush(tsktodml);


			fp1=fopen(inputfile,"r");
			if(fp1!=NULL)
			{
				while (fgets(fileRead,500,fp1)!=NULL )
				{
					fprintf(tsktodml,"\n  DML in TCUA: [%s] FOUND IN PLM\n", tasknumber);fflush(tsktodml);
					*Response = (char *) malloc( (50) * sizeof(char));
					nlsStrCpy(*Response,fileRead);//TASK  FOUND
				}
			}
			else
			{
				fprintf(tsktodml,"\n CNTRL DML TCUA: [%s] NOT FOUND IN PLM\n", tasknumber);fflush(tsktodml);
				*Response = (char *) malloc( (50) * sizeof(char));
				nlsStrCpy(*Response,"-1");//TASK NOT FOUND
			}
		}
		
	}
	else
	{
		fprintf(tsktodml,"\nTASK NOT FOUND CHECK FOR EPA");fflush(tsktodml);
		
		//Query Task DML
		if(Sql_ptr)	oiSqlDispose(Sql_ptr); Sql_ptr = NULL;
		if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(Sql_ptr,WbsIDAttr,tasknumber)) goto CLEANUP;
		//if(dstat = oiSqlPrint(Sql_ptr));
		if(dstat = QueryDbObject(t5StdDmlClass,Sql_ptr,-1,TRUE,SC_SCOPE_OF_SESSION,&soTsk,&mfail));
		fprintf(tsktodml,"\n No of Task Found	:	[%d]",setSize(soTsk));fflush(tsktodml);
		if (setSize(soTsk)>0)
		{
			oTsk	=	setGet(soTsk,0);
			if(dstat = objGetAttribute(oTsk,WbsIDAttr,&DmlNumDup)) goto EXIT;
			if(!nlsIsStrNull(DmlNumDup))
				DmlNum	=	nlsStrDup(DmlNumDup);
			*Response = (char *) malloc( (50) * sizeof(char));
			nlsStrCpy(*Response,DmlNum);
			fprintf(tsktodml,"\n EPA NUMBER	:	[%s]",DmlNum);fflush(tsktodml);
		}
		else
		{
			fprintf(tsktodml,"\n Task not found in TCE, check in TCUA CV");
			StrFullPathShell = nlsStrAlloc(200);//"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass"
			nlsStrCpy(StrFullPathShell,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/TskToDML_CV.sh");
			
			txtargv[0] = StrFullPathShell;
			txtargv[1] = tasknumber;
			//txtargv[2] = plant;
			txtargv[2] = NULL;


			for (cnt = 0;cnt < 1; cnt++ )
			{
				fprintf(tsktodml,"txtargv[%d] : [%s]", cnt, txtargv[cnt]); fflush(tsktodml);
			}

			fprintf(tsktodml,"\nStrFullPathShell : [%s]", StrFullPathShell); fflush(tsktodml);

			SysReturn = sysExecute(StrFullPathShell, txtargv);
			if(SysReturn == 0)
			{
				fprintf(tsktodml,"\n Execution Done Successfully ...");  fflush(tsktodml);
			}
			else
			{
				fprintf(tsktodml,"\n Execution Done Fail, Pl check Env variable and calling shell..\n");  fflush(tsktodml);
			}

			sysdate		=	sysGetDate();
			low_strrpl(sysdate,'-','_');
			//low_strrpl(sysdate,' ','_');
			fprintf(tsktodml,"\n sysdate : %s",sysdate);  fflush(tsktodml);
			//*Response = (char *) malloc( (50) * sizeof(char));
			//nlsStrCpy(*Response,"-1");
			inputfile	=	nlsStrAlloc(nlsStrLen("/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass/")+100);
			nlsStrCpy(inputfile,"");
			nlsStrCat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_PO_Bypass");
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,sysdate);
			nlsStrCat(inputfile,"/");
			nlsStrCat(inputfile,tasknumber);
			nlsStrCat(inputfile,"_TskToDML");
			nlsStrCat(inputfile,".txt");
			fprintf(tsktodml,"\nFilename : %s",inputfile);fflush(tsktodml);


			fp1=fopen(inputfile,"r");
			if(fp1!=NULL)
			{
				while (fgets(fileRead,500,fp1)!=NULL )
				{
					fprintf(tsktodml,"\n CNTRL DML TCUA: [%s] NOT FOUND IN PLM\n", tasknumber);fflush(tsktodml);
					*Response = (char *) malloc( (50) * sizeof(char));
					nlsStrCpy(*Response,fileRead);//TASK NOT FOUND
				}
			}
			else
			{
				fprintf(tsktodml,"\n CNTRL DML TCUA: [%s] NOT FOUND IN PLM\n", tasknumber);fflush(tsktodml);
				*Response = (char *) malloc( (50) * sizeof(char));
				nlsStrCpy(*Response,"-1");//TASK NOT FOUND
			}
		}
	}
	

	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
	return SOAP_OK;

CLEANUP :
		fprintf(tsktodml,"\n  Inside CLEANUP:\n");
		return SOAP_OK;
EXIT:
		fprintf(tsktodml,"\n  Inside EXIT \n");
		return SOAP_OK;
}