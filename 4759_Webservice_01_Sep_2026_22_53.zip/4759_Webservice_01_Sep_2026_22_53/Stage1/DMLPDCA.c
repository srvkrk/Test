#include "soapH.h" /* get the gSOAP-generated definitions */
#include "DMLPDCA.nsmap" /* get the gSOAP-generated namespace bindings */
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>

#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

char* subString (char* mainStringf ,int fromCharf,int toCharf);

char* subString
(
	char* mainStringf ,
	int fromCharf     ,
	int toCharf
)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
	{
	char *error_msg_string;

	EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}

extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new()); /* call the request dispatcher */
} 
;

//int ns__getDmlDetailPDCA(struct soap* soap,char *DML_No,char *PDCA_No,char *PDCA_Type, char **Response)
int ns__getDmlDetailPDCA(struct soap* soap,char *DML_No, char *PDCA_Type, char **Response)
{
	int ifail =0;

	char*	logFile				= NULL;
	char*	LatRev_ObjectType	= NULL;
	char*	dmlNo				= NULL;
	char*	pdcaobjnum			= NULL;
	
	

	char
        *qry_entries[2] = {"Name","Type"},
        *qry_values[2]	= {"*","*"};

	tag_t item_t				= NULLTAG;
	tag_t itemRev_t				= NULLTAG;
	tag_t relation_type			= NULLTAG;
	tag_t *pdca_objects			= NULLTAG;
	tag_t *QueryPDCA_objects	= NULLTAG;
	tag_t PDCA_type_tag			= NULLTAG;
	tag_t pdca_cre_input_tag	= NULLTAG;
	tag_t pdca_newCre_object	= NULLTAG;
	tag_t dml_pdca_relation		= NULLTAG;
	tag_t query					= NULLTAG;
	tag_t *tags_found			= NULLTAG;


	int	n_pdcattchs				= 0;
	int	n_entries				= 2;
	int	n_found					= 0;
	int	n_tags_found			= 0;

	//FILE* LogFilePtr1 = NULL;
	


	

	//logFile = (char *) malloc(sizeof (char) * 50 );
	//*Response = (char *) malloc( (100) * sizeof(char));
	//pdcaobjnum = (char *) malloc(sizeof (char) * 50 );

	//logFile=(char *)MEM_alloc(200);
	*Response=(char *)MEM_alloc(200);
	pdcaobjnum=(char *)MEM_alloc(200);
	
	//tc_strcpy(logFile,"/tmp/");
	//tc_strcat(logFile,DML_No);
	//tc_strcat(logFile,"_PDCA_Det.log");
	//LogFilePtr1 = fopen(logFile, "a+");

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	//freopen(logFile, "w", stdout);
	freopen("/tmp/PDCA_Det.txt", "w", stdout);

	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE);
	ITK_auto_login();
	ITK_set_journalling( TRUE );

	

	printf("\nDML No : [%s]\n", DML_No); fflush(stdout);

	//printf("\nPDCA No : [%s]\n", PDCA_No); fflush(stdout);

	printf("\nPDCA Type : [%s]\n", PDCA_Type); fflush(stdout);

	if((DML_No !=NULL) && (tc_strcmp(DML_No,"")!=0))
	{
		const char *attrs[1];
		const char *values[1];
		attrs[0] ="item_id";
		//attrs[1] ="object_type";
		values[0] = (char *)DML_No;
		//values[1] = "ERC DML";
		printf("\n values[0] <%s> \n",values[0] );fflush(stdout);

		ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);

		printf("\n Tag Found <%d> \n",n_tags_found );fflush(stdout);
		if(n_tags_found>0)
		{
			printf("\n DML FOUND");fflush(stdout);
			item_t = tags_found[0];
			ITEM_ask_latest_rev(item_t,&itemRev_t);
			AOM_UIF_ask_value(itemRev_t,"object_type",&LatRev_ObjectType);
			printf("\n Object Type of Latest Revision is :%s",LatRev_ObjectType);fflush(stdout);
			if(tc_strcasecmp(LatRev_ObjectType,"ERC DML Revision")==0)
			{
				AOM_ask_value_string(itemRev_t,"item_id",&dmlNo);
				printf("\n DML No is : [%s]\n", dmlNo); fflush(stdout);

				CALLAPI(GRM_find_relation_type("T5_DmlHasPdca", &relation_type));
				if (relation_type!=NULLTAG)
				{
					CALLAPI(GRM_list_secondary_objects_only(itemRev_t,relation_type,&n_pdcattchs,&pdca_objects));
					printf("\n n_pdcattchs is : [%d]\n", n_pdcattchs); fflush(stdout);
					if(n_pdcattchs>0)
					{
						printf("\n the object relation alreday creation \n");fflush(stdout);
						tc_strcpy(*Response,"The PDCA object already attached for this DML");
					}
					else
					{
						
						tc_strcpy(pdcaobjnum,dmlNo);
						tc_strcat(pdcaobjnum,"_PDCA");
						printf("\n pdcaobjnum : [%s]\n", pdcaobjnum); fflush(stdout);
						if(pdcaobjnum!=NULL)qry_values[0] = pdcaobjnum;
						if(pdcaobjnum!=NULL)qry_values[1] = "PDCA";

						QRY_find("General...", &query);
						if(query!=NULLTAG && pdcaobjnum!=NULL && tc_strlen(pdcaobjnum)>0)
						{
							QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &QueryPDCA_objects);
							if(n_found>0)
							{
								printf("\n the object alreday exist \n"); fflush(stdout);
								tc_strcpy(*Response,"The PDCA object already exist for this DML");
							}
							else
							{
								TCTYPE_find_type("T5_PDCA", "T5_PDCA", &PDCA_type_tag);				
								if(PDCA_type_tag!=NULLTAG)
								{
									TCTYPE_construct_create_input(PDCA_type_tag, &pdca_cre_input_tag);
									AOM_set_value_string(pdca_cre_input_tag,"object_name",pdcaobjnum);
									AOM_set_value_string(pdca_cre_input_tag,"object_desc",pdcaobjnum);
									AOM_set_value_string(pdca_cre_input_tag,"t5_PdcaNumber",pdcaobjnum);
									//AOM_set_value_string(pdca_cre_input_tag,"t5_PartNumList",pdcaobjnum);
									//AOM_set_value_string(pdca_cre_input_tag,"t5_FileType","PDFVis");
									AOM_set_value_string(pdca_cre_input_tag,"t5_PdcaType",PDCA_Type);
									TCTYPE_create_object(pdca_cre_input_tag, &pdca_newCre_object);
									AOM_save_with_extensions(pdca_newCre_object);
								}
								else
								{
									printf("\n pdca_newCre_object is not created \n"); fflush(stdout);
								}
								if(pdca_newCre_object!=NULLTAG)
								{
									printf("\n pdca_newCre_object is created \n"); fflush(stdout);
									AOM_refresh( pdca_newCre_object, POM_modify_lock);
									AOM_save(pdca_newCre_object);
									AOM_refresh(pdca_newCre_object,POM_no_lock);
									
									printf("\n new object created**** \n"); fflush(stdout);

									GRM_create_relation(itemRev_t, pdca_newCre_object, relation_type, NULLTAG, &dml_pdca_relation);
									GRM_save_relation(dml_pdca_relation);
									printf("\n Inside the if Relation creation \n"); fflush(stdout);
									tc_strcpy(*Response,"1");
								}
								else
								{
									printf("\n Inside else object not created\n"); fflush(stdout);
									tc_strcpy(*Response,"null");
								}
							}
						}
					}
				}
			}
		}
		else
		{
			printf("\n Inside else1 \n"); fflush(stdout);
			tc_strcpy(*Response,"DML Not Found");
		}
	}
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;
}
;
