//gsoap ns service name:				 get_module_child
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:get_module_child
//gsoap ns service location:			 http://172.22.97.12:9080/cgi/get_module_child.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:get_module_child
//gsoap ns service method-documentation: Module name web service

//typedef char * xsd__string;

struct ns__ModuleChildStr
{
   char		*__partno;		 
};

struct ns__ModuleAddrStr
{
   struct ns__ModuleChildStr	*__ptr;		//Pointer to the array of string.
   int				__size;			//Size of Array.
};

int ns__get_module_child(char* module_num, struct ns__ModuleAddrStr *ModChildStr);

 