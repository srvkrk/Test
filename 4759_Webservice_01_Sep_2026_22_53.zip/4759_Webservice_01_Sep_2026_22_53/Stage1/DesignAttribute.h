//gsoap ns service name:				 DesignAttribute
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:DesignAttribute
//gsoap ns service location:			 http://172.22.97.12:9080/cgi/DesignAttribute.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:DesignAttribute
//gsoap ns service method-documentation: Test the Simple Web service


struct ns__ItemDet
{
   char *PartDetails;
   /*
   char *PART_NO;
   char *PART_REFDRW;
   char *PART_MATERIAL;
   char *PART_DESC;
   char *MAT_WT;
   char *SURFACE_PROTECT;
   char *OPP_HAND;
   char *PART_THICKNESS;
   char *PART_ENVDIM;
   char *PART_DSGNYIELD;
   char *PART_MODDESC;
   char *PART_REV;
   */
}
;
struct ns__CharArray1
{
   struct ns__ItemDet *__ptrDetails;
   int __size;
}
;

int ns__getItemData(char *Item,struct ns__CharArray1 *aString_test);


