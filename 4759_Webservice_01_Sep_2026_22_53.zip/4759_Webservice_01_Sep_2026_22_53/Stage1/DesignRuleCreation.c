#include "soapH.h"
#include "DesignRuleCreation.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <time.h>
#include <tccore/tctype.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128
//#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		//printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			//printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}                                  
extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;

int ns__getDesignRuleCre(struct soap* soap,char *Design_RuleGrp,char *Design_RuleSGrp,char *Design_BusUn,char *Design_DesGrp,char *Design_DesSGrp,char *Design_DrApp,
char *Design_Modladd,char *Design_Rule,char *Design_RuleRev,char *Design_Autid,char *Design_Ruletitle,char *Design_RuleStat,char *Design_Appid,
char *Design_AppDate,char *Design_MultiKey,char *Design_MastSrN,char *Design_Wrkfid,char **Response)
{
		*Response = (char *) malloc( (5000) * sizeof(char));

		tag_t query_tag         = NULLTAG;
	
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
        freopen("/tmp/DesignRule.txt", "a", stdout);

        // Login to teamcenter
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		ITK_CALL(ITK_auto_login( ));
		ITK_CALL(ITK_set_journalling( TRUE ));



		printf("\n ****************Design Rule Creation Webservice**************** \n\n");fflush(stdout);
		printf(" Group Name :															[%s]\n", Design_RuleGrp); fflush(stdout); 
		printf(" Subgroup Name :														[%s]\n", Design_RuleSGrp); fflush(stdout); 
		printf(" Business Unit :														[%s]\n", Design_BusUn); fflush(stdout);                                       
		printf(" Design Group :															[%s]\n", Design_DesGrp); fflush(stdout);                            
		printf(" Design Sub Group :														[%s]\n", Design_DesSGrp); fflush(stdout);                            
		printf(" DR/AR Gateway applicability (DR0/DR1/DR2/DR3/DR4/DR5/Multiple) :		[%s]\n", Design_DrApp); fflush(stdout);                            
		printf(" Module Address :														[%s]\n", Design_Modladd); fflush(stdout);                            
		printf(" Design Rule No :														[%s]\n", Design_Rule); fflush(stdout);                            
		printf(" Design Rule Revision :													[%s]\n", Design_RuleRev); fflush(stdout);                            
		printf(" Author ID :															[%s]\n", Design_Autid); fflush(stdout);                            
		printf(" DR Title :																[%s]\n", Design_Ruletitle); fflush(stdout);                            
		printf(" Status :																[%s]\n", Design_RuleStat); fflush(stdout);                            
		printf(" Approver Id :															[%s]\n", Design_Appid); fflush(stdout);                            
		printf(" Approver Date :														[%s]\n", Design_AppDate); fflush(stdout);                            
		printf(" Master SR No :															[%s]\n", Design_MastSrN); fflush(stdout);                            
		printf(" Application ID/ Workflow ID/System Name in which it is being managed : [%s]\n", Design_Wrkfid); fflush(stdout);
		printf(" Keyword/ Multiple keyword :											[%s]\n", Design_MultiKey); fflush(stdout);
		

		// Query Design revision
		ITK_CALL(QRY_find2("DesignRuleObject",&query_tag));

		if (query_tag)
		{
			
			printf(" Found Query\n"); fflush(stdout);
		}
		else
		{
			printf(" *** Query Not Found *** \n"); fflush(stdout);
		}

		tag_t*	designRuleObj_tag	= NULLTAG;
		tag_t	object_type_tag		= NULLTAG,
		object_create_input_tag		= NULLTAG;
		tag_t	itemTag				= NULLTAG;
		//tag_t	queryTag			= NULLTAG;
		int		n_entries			= 1;
		int		resultCount			= 0;
		char ** qry_entries = (char **)MEM_alloc(n_entries * sizeof(char *));
		char **qry_values	= (char **)MEM_alloc(n_entries * sizeof(char *));
		char searchEntry[1][30] = { "Name" };
		
		qry_entries[0] = (char *)MEM_alloc(strlen(searchEntry[0]) + 1);
		strcpy(qry_entries[0], searchEntry[0]);
		qry_values[0] = (char *)MEM_alloc(strlen(Design_Rule) + 1);
		tc_strcpy(qry_values[0], Design_Rule);
		
		if (query_tag)
		{
			ITK_CALL(QRY_execute(query_tag, n_entries, qry_entries, qry_values, &resultCount, &designRuleObj_tag));
			printf("\n No. of Design Revision Object Found are -- %d\n", resultCount);
			if(resultCount < 1)
			{
				printf("\n L0 : Inside if condition\n");
				ITKCALL( TCTYPE_find_type("T5_DesignRuleObj", NULL, &object_type_tag));
				printf("\n L1 : Inside if condition\n");
				ITKCALL(TCTYPE_construct_create_input(object_type_tag,&object_create_input_tag));

				AOM_set_value_string(object_create_input_tag, "object_name", Design_Rule);
				AOM_set_value_string(object_create_input_tag, "t5_GroupName", Design_RuleGrp);
				AOM_set_value_string(object_create_input_tag, "t5_SubGroupName", Design_RuleSGrp);
				AOM_set_value_string(object_create_input_tag, "t5_BusinessUnit", Design_BusUn);
				AOM_set_value_string(object_create_input_tag, "t5_DesgnGroup", Design_DesGrp);
				AOM_set_value_string(object_create_input_tag, "t5_SubDesgnGroup", Design_DesSGrp);
				AOM_set_value_string(object_create_input_tag, "t5_DRARGateAppl", Design_DrApp);
				AOM_set_value_string(object_create_input_tag, "t5_ModuleAddress", Design_Modladd);
				AOM_set_value_string(object_create_input_tag, "t5_DesignRule", Design_Rule);
				AOM_set_value_string(object_create_input_tag, "t5_DesignRuleRevision", Design_RuleRev);
				AOM_set_value_string(object_create_input_tag, "t5_AuthorID", Design_Autid);
				AOM_set_value_string(object_create_input_tag, "t5_DesignRuleTitle", Design_Ruletitle);
				AOM_set_value_string(object_create_input_tag, "t5_RuleStatus", Design_RuleStat);
				AOM_set_value_string(object_create_input_tag, "t5_ApprovedID", Design_Appid);
				AOM_set_value_string(object_create_input_tag, "t5_ApprovedDate", Design_AppDate);
				AOM_set_value_string(object_create_input_tag, "t5_MuliKeywords", Design_MultiKey);
				AOM_set_value_string(object_create_input_tag, "t5_MasterSrNo", Design_MastSrN);
				AOM_set_value_string(object_create_input_tag, "t5_WorkSystemID", Design_Wrkfid);

				ITK_CALL(TCTYPE_create_object(object_create_input_tag, &itemTag));
				ITK_CALL(AOM_save_with_extensions(itemTag));

				printf("\n Design Rule Object Created Successfully...!\n");fflush(stdout);    
				tc_strcpy(*Response,"Design Rule Object Created Successfully...!");       

			}
			else
			{
				printf("\n Object already Available in Teamcenter!\n");fflush(stdout);
				tc_strcpy(*Response,"Design rule already available in Teamcenter...!");
			}
		}
		else
		{
			tc_strcpy(*Response,"***********Design Rule Applicability WS**************");
			printf("\n query_tag not found !\n");fflush(stdout);
		}
		
		fflush(stdout);
        dup2(fd, fileno(stdout));
        close(fd);
        clearerr(stdout);
        fsetpos(stdout, &pos);

		return SOAP_OK;
}