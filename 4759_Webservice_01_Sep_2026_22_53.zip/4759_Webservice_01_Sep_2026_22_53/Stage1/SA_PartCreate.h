//gsoap ns service name:                          SA_PartCreate
//gsoap ns service style:                          rpc
//gsoap ns service namespace:                    urn:SA_PartCreate
//gsoap ns service location:                     http://172.22.97.90:8080/cgi/SA_PartCreate.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:ProjectOrgID
//gsoap ns service method-documentation: Tests the Simple Web service


typedef char * xsd__string;

struct ns__CharArray
{
	xsd__string     *__ptr;         // pointer to array of string
	int             __size;         // array size
};


int ns__SANumberingPartCreate(char *PartNumber,char **Response);

