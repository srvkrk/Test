//gsoap ns service name:				 get_recall_attributes
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:get_recall_attributes
//gsoap ns service location:			 http://172.22.97.12:9080/cgi/get_recall_attributes.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:get_recall_attributes
//gsoap ns service method-documentation: Tests the Simple Web service


//struct ns__ItemDet
//{
//   char *PartNo;
//   char *Description;
//   char *Modification_description;
//   char *TrackTrace;
//   char *CTECTS;
//   char *SheetSize;
//   //char *DML_CRE;
//   //char *DML_CREDATE;
//   //char *DML_REASON;
//}
//;
//struct ns__CharArray1
//{
//   struct ns__ItemDet *__ptrItem;
//   int __size;
//}
//;

//int ns__GetRecallAttributes(char  *Item, char* Rev, char* Seq ,struct ns__CharArray1 *aString_test);
int ns__GetRecallAttributes(char *Item, char* Rev, char* Seq ,char **Response);