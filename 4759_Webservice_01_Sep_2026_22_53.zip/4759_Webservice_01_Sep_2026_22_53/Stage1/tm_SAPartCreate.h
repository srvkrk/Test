//gsoap ns service name:                          tm_SAPartCreate
//gsoap ns service style:                          rpc
//gsoap ns service namespace:                    urn:tm_SAPartCreate
//gsoap ns service location:                     http://172.22.97.28:9080/cgi/tm_SAPartCreate.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:ProjectOrgID
//gsoap ns service method-documentation: Tests the Simple Web service


typedef char * xsd__string;

struct ns__CharArray
{
	xsd__string     *__ptr;         // pointer to array of string
	int             __size;         // array size
};


int ns__SANumberingPartCreate(char *PartNumber,char **Response);


