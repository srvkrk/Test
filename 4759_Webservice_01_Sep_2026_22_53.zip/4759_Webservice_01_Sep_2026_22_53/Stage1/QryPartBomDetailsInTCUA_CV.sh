. /user/cvprod/.bash_profile
#!/bin/ksh
date
cd /proj/PLMLoading/PFIRST_TCE_TCUA_PART/
pwd

if [ -f "$1_TCUACV_PARTBOMDETAIL.txt" ]; then
touch "$1_TCUACV_PARTBOMDETAIL.txt_old"; chmod 777 "$1_TCUACV_PARTBOMDETAIL.txt_old";
cat "$1_TCUACV_PARTBOMDETAIL.txt" >> "$1_TCUACV_PARTBOMDETAIL.txt_old"
rm -rf "$1_TCUACV_PARTBOMDETAIL.txt"
fi
touch "$1_TCUACV_PARTBOMDETAIL.txt"
chmod 777 "$1_TCUACV_PARTBOMDETAIL.txt"
echo "Part number:"${1} > /proj/PLMLoading/PFIRST_TCE_TCUA_PART/CVWSPARTBOM1.txt
echo "Revision:"${2} >> /proj/PLMLoading/PFIRST_TCE_TCUA_PART/CVWSPARTBOM1.txt
echo "Sequense:"${3} >> /proj/PLMLoading/PFIRST_TCE_TCUA_PART/CVWSPARTBOM1.txt
echo "ER-EW:"${4} >> /proj/PLMLoading/PFIRST_TCE_TCUA_PART/CVWSPARTBOM1.txt
echo "Plant:"${5} >> /proj/PLMLoading/PFIRST_TCE_TCUA_PART/CVWSPARTBOM1.txt
#/user/cvprod/Program_Shells/PARTBOMWeb1CV -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -prt="${1}" -rev="${2}" -seq="${3}" -lc="${4}" -pl="${5}"
/user/cvprod/Program_Shells/PARTBOMWeb1CV -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -prt=$1 -rev=$2 -seq=$3 -lc=$4 -pl=$5
mv /proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_PartBomCV.log $1_$(date +"%Y-%m-%d")_$(date +"%H:%M:%S")_NewPartBomCV.log
if [ ! -s "$1_TCUACV_PARTBOMDETAIL.txt" ]; then
#    echo "File not found!"
    touch $1_TCUACV_PARTBOMDETAIL.txt
fi
echo "========="
cat $1_TCUACV_PARTBOMDETAIL.txt
echo "=========Success====="

