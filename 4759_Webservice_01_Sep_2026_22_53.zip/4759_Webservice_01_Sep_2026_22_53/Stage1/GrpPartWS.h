//gsoap ns service name:                          GrpPartWS
//gsoap ns service style:                          rpc
//gsoap ns service namespace:                    urn:GrpPartWS
//gsoap ns service location:                     http://172.22.99.106:9080/cgi/GrpPartWS.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:GrpPartWS
//gsoap ns service method-documentation: Tests the Simple Web service


int ns__getGrpPartWs(char *partnumber,char **PartNum);

