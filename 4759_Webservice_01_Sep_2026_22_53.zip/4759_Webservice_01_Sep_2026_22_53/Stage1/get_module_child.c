/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: get_module_child.c
**
** Functions:- 	This utility gets module address as command line input and queries into teamcenter and gets list of
**				modules and write it's appropriate information into the output file.
**
**
**
**	Date							Author								Modification
**	05-Sept-2018					Kalpesh Gondhali					Code creation
**	23-Oct-2018						Kalpesh Gondhali					Fetching uses parts present under module.
**	28-jan-2019						Kalpesh Gondhali					Check added for Dummy and standard parts.
**
** command to run:
** get_module_child -u=<username> -pf=<password file path> -g=<group> -m=<module_address> -path=<path of output file>
***********************************************************************************************************************************************************/
#include "soapH.h"					/* get the gSOAP-generated definitions */
#include "get_module_child.nsmap"	/* get the gSOAP-generated namespace bindings */
#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int			ifail 				= ITK_ok;

int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new()); /* call the request dispatcher */
};

//int ns__get_module_list(struct soap* soap, char* module_add, struct ns__ModuleAddrStr *ModuleStr, struct ns__ModuleAddrStr *ModChildStr)
int ns__get_module_child(struct soap* soap, char* module_num, struct ns__ModuleAddrStr *ModChildStr)
{
	int				i 							= 0;
	int				j 							= 0;
	int				results 					= 0;
	int				child_count					= 0;

	tag_t			query_tag					= NULLTAG;
	tag_t			window						= NULLTAG;
	tag_t			top_bomline					= NULLTAG;
	tag_t			*module_list				= NULL;
	tag_t			*child_bomlines				= NULL;

	tag_t			child_part					= NULLTAG;
	char*			prt_type					= NULL;

 	tag_t			grp_bomline					= NULLTAG;
	tag_t			*grp_bomlines				= NULL;
	tag_t			rule;
	int				grp_cnt = 0,k=0;

	/*
	char 			*entry0						= "Part Type";
	char 			*entry1						= "Module Address";
	char			*part_type					= "Module";
*/
	char*			addr						= NULL;
	char 			*entry0						= "Item ID";
	//char 			*entry1						= "Type";
	char			*itemid						= NULL;
	//char			*item_type					= "Design Revision";

	char			*child_itemid				= NULL;
	char			*child_rev					= NULL;
	char			*child_desc					= NULL;
	char			*child_projcode				= NULL;
	char			*child_designgrp			= NULL;
	char			*module_obj_string			= NULL;
	char			*module_child_string		= NULL;

	char			*Test						= (char*)MEM_alloc(sizeof(char) * 50);
	char**  		entries						= NULL;
	char**  		values						= NULL;

	char** partlist = NULL;
	int globalcnt = 0;

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/comments.txt", "w", stdout);

	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	ifail = ITK_auto_login( );
	ifail = ITK_set_journalling(TRUE);
	partlist	= (char**) MEM_alloc (sizeof(char*) * 100);

	entries		= (char**) MEM_alloc (sizeof(char*) * 10);
	values		= (char**) MEM_alloc (sizeof(char*) * 10);

	entries[0] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry0) + 1));
	//itemid		= (char*) MEM_alloc (sizeof(char) * (tc_strlen(module_add) + 4));
	values[0]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(module_num) + 4));

	//entries[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry1) + 1));
	//values[1]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(item_type) + 1));

    //addr	= (char*) MEM_alloc (sizeof(char*) * (tc_strlen(module_add)));

	tc_strcpy(entries[0], "");
	tc_strcpy(entries[0], entry0);

	/*tc_strcpy(itemid, "*");
	addr = strtok(module_add,"M");
	printf("\naddr:%s\n",addr);
	strcat(itemid,addr);
	strcat(itemid,"*");*/

	//printf("\nModule address to be queried:%s",itemid);
	tc_strcpy(values[0],"");
	tc_strcpy(values[0],module_num);

	/*tc_strcpy(entries[1], "");
	tc_strcpy(entries[1], entry1);
	tc_strcpy(values[1], "");
	tc_strcpy(values[1], item_type);*/

	ifail = QRY_ignore_case_on_search(TRUE);
	ifail = QRY_find2("Latest Item Revision...", &query_tag);

	if(query_tag == NULLTAG)
	{
		//printf("\nQuery Not Found in TC....!!\n");
		return 0;
	}
	ifail = QRY_execute(query_tag,1, entries, values, &results, &module_list);
	 //printf("\n\nTotal Modules found:%d\n\n",results);

	//ModuleStr->__size	= results;
	//ModuleStr->__ptr	= malloc( (ModuleStr->__size + 1) * sizeof(*ModuleStr->__ptr));

	for(i=0;i<results;i++)
	{
		ifail = AOM_UIF_ask_value(module_list[i], "bl_item_item_id", &module_obj_string);
		partlist[globalcnt]=(char*) MEM_alloc (sizeof(char) * (tc_strlen(module_obj_string) + 10));
		strcpy(partlist[globalcnt], module_obj_string);
		globalcnt++;

		//printf("\nModule:%s\t\t", module_obj_string);
		//ModuleStr->__ptr[i] = (char *) malloc( (1500) * sizeof(char));
		//strcpy(ModuleStr->__ptr[i], module_obj_string);

		ifail = BOM_create_window(&window);
	 	//ifail = CFM_find("Latest Working", &rule);
	 	//ifail = BOM_set_window_config_rule(window, rule);
		ifail = BOM_set_window_top_line(window, NULLTAG, module_list[i], NULLTAG, &top_bomline);
		ifail = BOM_window_show_suppressed(window);
		ifail = BOM_line_unpack (top_bomline);
		ifail = BOM_line_ask_all_child_lines(top_bomline, &child_count, &child_bomlines);
		printf("M%d Child count:%d\n",i,child_count);

		//ModChildStr->__size = child_count;
		//ModChildStr->__ptr = malloc( (ModChildStr->__size + 1) * sizeof(*ModChildStr->__ptr));

		for(j=0;j<child_count;j++)
		{
			child_part = child_bomlines[j];
			ifail = AOM_UIF_ask_value(child_part, "bl_item_item_id", &child_itemid);
			ifail = AOM_UIF_ask_value(child_part, "bl_rev_item_revision_id ", &child_rev);
			ifail = AOM_UIF_ask_value(child_part, "bl_item_object_desc", &child_desc);
			ifail = AOM_UIF_ask_value(child_part, "bl_item_project_list ", &child_projcode);
			ifail = AOM_UIF_ask_value(child_part, "bl_Design Revision_t5_DesignGrp ", &child_designgrp);

			//ifail = AOM_UIF_ask_value (child_part, "bl_Design_t5_RevPartType", &prt_type);//bl_Design Revision_t5_PartType
			//printf("\nPart Type is:%s\n", prt_type);

			partlist[globalcnt]=(char*) MEM_alloc (sizeof(char) * (tc_strlen(child_itemid) + 10));
			strcpy(partlist[globalcnt], child_itemid);
			globalcnt++;

			partlist[globalcnt]=(char*) MEM_alloc (sizeof(char) * (tc_strlen(child_rev) + 10));
			strcpy(partlist[globalcnt], child_rev);
			globalcnt++;

			partlist[globalcnt]=(char*) MEM_alloc (sizeof(char) * (tc_strlen(child_desc) + 10));
			strcpy(partlist[globalcnt], child_desc);
			globalcnt++;

			partlist[globalcnt]=(char*) MEM_alloc (sizeof(char) * (tc_strlen(child_projcode) + 10));
			strcpy(partlist[globalcnt], child_projcode);
			globalcnt++;

			partlist[globalcnt]=(char*) MEM_alloc (sizeof(char) * (tc_strlen(child_designgrp) + 10));
			strcpy(partlist[globalcnt], child_designgrp);
			globalcnt++;

			//ModChildStr->__ptr[j] = (char *) malloc( (1500) * sizeof(char));
			//strcpy(ModChildStr->__ptr[j], child_name);
		}
	}
	MEM_free(module_obj_string);
	MEM_free(module_list);

	if(globalcnt>0)
	{
		ModChildStr->__size = globalcnt;
		ModChildStr->__ptr = malloc((globalcnt + 1) * sizeof(*(ModChildStr)->__ptr));
		//ModChildStr->__ptr = malloc( (globalcnt) * sizeof(*ModChildStr->__ptr));
		for (i=0;i<globalcnt;i++)
		{
			//ModChildStr->__ptr[i].__partno = (char *) malloc(strlen(partlist[i])+1);
			ModChildStr->__ptr[i].__partno = malloc(strlen(partlist[i])+1);
			strcpy(ModChildStr->__ptr[i].__partno,partlist[i]);
		//	strcpy(ModChildStr->__ptr[i].__partno,partlist[i]);
			printf("\ni:%d %s",i,ModChildStr->__ptr[i].__partno);
		}
	}

	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;
}
