//gsoap ns service name:                          tm_NewAPLRlzdMonitoring
//gsoap ns service style:                          rpc
//gsoap ns service namespace:                    urn:tm_NewAPLRlzdMonitoring
//gsoap ns service location:                     http://172.22.97.90:8080/cgi/tm_NewAPLRlzdMonitoring.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:ProjectOrgID
//gsoap ns service method-documentation: Tests the Simple Web service



struct ns__plmStdDmlData
{
	char *Srl_Num;
	char *Dml_Num;
	char *Task_Num;
	char *Design_Grp;
	char *DrStatus;
	char *ERCRlzDt;
	char *DMLStatus;
	char *TaskStatus;
	char *APLPlanner;
	char *APLAssgnDate;
	char *APLPlannerDate;
	char *APLReviwr;
	char *APLReviwrDate;
	char *APLRlzdDate;
	char *ProjectCode;
	char *DML_Desc;
}
;
struct ns__CharArray1
{
	struct ns__plmStdDmlData *__ptrRlzDmlData;
	int __size;
}
;

int ns__getStddmlfsullDataInfo(char *StrDateInp, char *StrPlantInp, struct ns__CharArray1 *aString_Ret);