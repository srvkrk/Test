//gsoap ns service name:				 CheckPartInGrpIDInTCE
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:CheckPartInGrpIDInTCE
//gsoap ns service location:			 http://172.22.97.8:9010/cgi/CheckPartInGrpIDInTCE.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:CheckPartInGrpIDInTCE
//gsoap ns service method-documentation: Tests the Simple Web service
int ns__CheckPartInGrpIDInTCE(char* Item_id_par,char* GroupID,char **Response);