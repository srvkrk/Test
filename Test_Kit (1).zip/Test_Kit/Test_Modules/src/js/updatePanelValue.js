import app from 'app';
import appCtxService from 'js/appCtxService';

export let updatePanelValue = function(ctx, data) {
    console.log("Get In Success");

    if (!ctx.user || !ctx.user.props) {
        console.error("User context is missing. Ensure user data is available in ctx.");
        return;
    }

    var selected_user_id = ctx.user.props.userid ? ctx.user.props.userid.dbValue : "No ID";
    var selected_user_name = ctx.user.props.user_name ? ctx.user.props.user_name.dbValue : "No Name";

    console.log("Selected User ID = ", selected_user_id);
    console.log("Selected User Name = ", selected_user_name);

    // Update the panel's data model
    if (data) {
        data.user_id.dbValue = selected_user_id;
        data.user_name.dbValue = selected_user_name;
    }

    // Ensure UI reflects changes
    appCtxService.updatePartialCtx('panelData', data);

    return {
        selected_user_id: selected_user_id
    };
};

export default {
    updatePanelValue: updatePanelValue
};

