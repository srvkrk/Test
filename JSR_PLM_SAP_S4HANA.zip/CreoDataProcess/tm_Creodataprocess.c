/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Design Revision After Reading Data From Input File & Create Creo JT generation process files.
*  File Name    :   tm_Creodataprocess.c
*  Created on   :   Jun 30th, 2025
*  Usage        :   tm_Creodataprocess
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     30/06/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

/* char* TC_RefDataset(tag_t DesRevTag, tag_t IMANReferenceType)
{
	int IMANRefCnt = 0;
	tag_t* IMANRefAttach = NULLTAG;
	int t = 0;
	char* RefSecObjName = NULL;
	char* Refobject_type = NULL;
	char* RefRefName = NULL;
	AE_reference_type_t RefRefType;
	tag_t RefRefObject = NULLTAG;
	char* RefOrginal_Name = NULL;
	char *RefList = (char *) malloc(70000*sizeof(char));
	tc_strcpy(RefList,"@");
	printf(" @@@@@@@@@@@@ IMAN REFERENCE START @@@@@@@@@@@@\n");fflush(stdout);
	if(IMANReferenceType != NULLTAG)
	{
		ITK_CALL(GRM_list_secondary_objects_only(DesRevTag,IMANReferenceType,&IMANRefCnt,&IMANRefAttach));
		printf("Dataset Object Count[IMAN_Reference]: [%d]\n",IMANRefCnt);fflush(stdout);
		if(IMANRefCnt > 0)
		{
			for(t = 0; t < IMANRefCnt; t++)
			{
				ITK_CALL(WSOM_ask_object_id_string(IMANRefAttach[t],&RefSecObjName));
				printf("RefSecObjName: [%s]\n",RefSecObjName);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(IMANRefAttach[t],"object_type",&Refobject_type));
				printf("Object Type: [%s]\n",Refobject_type);fflush(stdout);
				ITK_CALL(AE_find_dataset_named_ref2(IMANRefAttach[t],0,&RefRefName,&RefRefType,&RefRefObject));
				ITK_CALL(IMF_ask_original_file_name2(RefRefObject,&RefOrginal_Name));
				printf("Before Set Orginal File Name: [%s]\n",RefOrginal_Name);fflush(stdout);
				if(tc_strcmp(Refobject_type,"CMI2Product")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");	
					}
				}
				else if(tc_strcmp(Refobject_type,"CMI2Part")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"CMI2Drawing")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"ProPrt")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"ProAsm")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"ProDrw")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"PDF")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else
				{
				  printf("\n [Refobject_type] Not Matched For [IMAN_Reference] Relation..!!\n");fflush(stdout);
				}
			}
		}
		else
		{
		  printf("\n No Object Found in [IMAN_Reference] Relation..!!\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n Relation Tag[IMAN_Reference] Not Found..!!\n");fflush(stdout);
	}
	printf(" @@@@@@@@@@@@ IMAN REFERENCE END @@@@@@@@@@@@\n");fflush(stdout);
	printf("\n Ref_List Before STRING_REPLACE: [%s]",RefList);fflush(stdout);
	STRNG_replace_str(RefList,"@","",&RefList);
	printf("\n Ref_List After STRING_REPLACE: [%s]",RefList);fflush(stdout);
	
	return RefList;	
} */

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
    FILE *fpOutput_file = NULL;
	char* SubModAddr_Str = NULL;
	char* InpPart_Str = NULL;
	char* InpRev_Str = NULL;
	char* InpSeq_Str = NULL;
	char* SubModAddr_StrDup = NULL;
	char* InpPart_StrDup = NULL;
	char* InpRev_StrDup = NULL;
	char* InpSeq_StrDup = NULL;
	char* LibPartNo = NULL;
	char* LibPartRev = NULL;
	char* LibPartSeq = NULL;
	char* LibPartNoDup = NULL;
	char* LibPartRevDup = NULL;
	char* LibPartSeqDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tdesrev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	tag_t* IMANRenAttach = NULLTAG;
	int IMANRenCnt = 0;
	int i = 0;
	int j = 0;
	tag_t dataset = NULLTAG;
	AE_reference_type_t RenRefType;
	char* RenRefName = NULL;
	tag_t SecObjTypeTag = NULLTAG;
	char SecObjTypeName[TCTYPE_name_size_c+1];
	int ReferenceCount = 0;
	int k = 0;
	tag_t RenRefObject = NULLTAG;
	char* RenOrginal_Name = NULL;
	char* Renobject_type = NULL;
	char* Data_Name  = NULL;
	char* ItemIDChk = NULL;
	char* New_Name= (char *) malloc(400*sizeof(char));
	char* RenSecObjName = NULL;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	char *item_parttype_str = NULL;
	char *item_parttype_strDup = NULL;
	char *item_desgrp_str = NULL;
	char *item_desgrp_strDup = NULL;
	char *item_model_str = NULL;
	char *item_model_strDup = NULL;
	char *Owner = NULL;
	char *OwnerDup = NULL;
	char *inpitem_id_str = NULL;
	char *inpitem_id_strDup = NULL;
	char *inpitem_rev_str = NULL;
	char *inpitem_rev_strDup = NULL;
	char *inpitem_seq_str = NULL;
	char *inpitem_seq_strDup = NULL;
	/* char *PDFFileStatus = (char *) malloc(10*sizeof(char));
	char *PDFFileName = (char *) malloc(50*sizeof(char));
	char *JTFileStatus = (char *) malloc(10*sizeof(char));
	char *JTFileName = (char *) malloc(50*sizeof(char)); */
	/* char* PDFFileStatus = NULL;
	char* PDFFileName = NULL;
	char* JTFileStatus = NULL;
	char* JTFileName = NULL; */
	char* RefDSList_Status = NULL;
	char *ERCRlzdDt = NULL;
	char *item_class = NULL;
	char *item_classDup = NULL;
	char *item_partcategory = NULL;
	char *item_partcategoryDup = NULL;
	char *item_partypart = NULL;
	char *item_partypartDup = NULL;
	char *vendor_details = NULL;
	char *vendor_id = NULL;
	char *vendor_name = NULL;
	int IMANSpecCnt = 0;
	tag_t* IMANSpecAttach = NULLTAG;
	int m = 0;
	char* SpecSecObjName = NULL;
	char* Specobject_type = NULL;
	char* SpecRefName = NULL;
	AE_reference_type_t SpecRefType;
	tag_t SpecRefObject = NULLTAG;
	char* SpecOrginal_Name = NULL;
	/* char* CMI2ProdFileStatus = NULL;
	char* CMI2ProdFileName = NULL;
	char* CMI2PartFileStatus = NULL;
	char* CMI2PartFileName = NULL;
	char* CMI2DrwFileStatus = NULL;
	char* CMI2DrwFileName = NULL;
	char* CreoPrtFileStatus = NULL;
	char* CreoPrtFileName = NULL;
	char* CreoAsmFileStatus = NULL;
	char* CreoAsmFileName = NULL;
	char* CreoDrwFileStatus = NULL;
	char* CreoDrwFileName = NULL; */
	date_t dcreation_date;
    char *cCreation_date = NULL;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	int mach_type = SS_UNIX_MACHINE;
	char* SpecOrginal_Path = NULL;
	char* RenOrginal_Path = NULL;
	char *SpecListPrt = (char *) malloc(70000*sizeof(char));
	char *SpecListAsm = (char *) malloc(70000*sizeof(char));
	char *SpecListDrw = (char *) malloc(70000*sizeof(char));
	char *inp_revseq_strdup = (char *) malloc(20*sizeof(char));
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}

	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
    tc_strcpy(RptFile,"TCUA_CREO_DATA_PROCESS");
    tc_strcat(RptFile,"_");
    tc_strcat(RptFile,GenDate);
    tc_strcat(RptFile,".csv");
    printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
    printf("\n CSV Report File Generated..!!");fflush(stdout);
	
	tag_t IMANSpecType = NULLTAG;
	tag_t IMANRefType = NULLTAG;
	tag_t IMANRenType = NULLTAG;
	ITK_CALL(GRM_find_relation_type("IMAN_specification",&IMANSpecType));
	ITK_CALL(GRM_find_relation_type("IMAN_reference",&IMANRefType));
	ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&IMANRenType));

    fpPart_List = fopen("PartList.txt","r");
	fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"PART_NO, REV-SEQ, IMAN_SPECIFICATION_ProPrt, IMAN_SPECIFICATION_ProAsm, IMAN_SPECIFICATION_ProDrw\n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
		printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
			return 0;
	}
	
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			inpitem_id_str=strtok(Buffer,"^");
			inpitem_rev_str=strtok(NULL,"^");
			inpitem_seq_str=strtok(NULL,"^");
			if(inpitem_id_str!=NULL)tc_strdup(inpitem_id_str,&inpitem_id_strDup);
			if(inpitem_rev_str!=NULL)tc_strdup(inpitem_rev_str,&inpitem_rev_strDup);
			if(inpitem_seq_str!=NULL)tc_strdup(inpitem_seq_str,&inpitem_seq_strDup);
			if(inpitem_id_strDup!=NULL)trimwhitespace(inpitem_id_strDup);
			if(inpitem_rev_strDup!=NULL)trimwhitespace(inpitem_rev_strDup);
			if(inpitem_seq_strDup!=NULL)trimwhitespace(inpitem_seq_strDup);
			
			printf("\n Part No(inpitem_id_strDup): [%s]\n",inpitem_id_strDup);
			printf("\n Part Rev(inpitem_rev_strDup): [%s]\n",inpitem_rev_strDup);
			printf("\n Part Seq(inpitem_seq_strDup): [%s]\n",inpitem_seq_strDup);
			
			tc_strcpy(inp_revseq_strdup,inpitem_rev_strDup);
	        tc_strcat(inp_revseq_strdup,"*");
	        tc_strcat(inp_revseq_strdup,inpitem_seq_strDup);
	        printf(" Final: Part_Rev_Seq Value(inp_revseq_strdup): [%s]\n",inp_revseq_strdup);

			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
			if(tItemobj != NULLTAG)
			{
				printf("Query[DesignRevision Sequence] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {inp_revseq_strdup,inpitem_id_strDup};
				//char *cValues[2]  = {"A*2","51780353R"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[DesignRevision Sequence] Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Objects[DesignRevision Sequence] Exist So Continue..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						tdesrev = titemobj_results[i];
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
						if(tc_strlen(item_id_str)>0)
						{
							tc_strdup(item_id_str,&item_id_strDup);
							trimwhitespace(item_id_strDup);
						}
						else
						{
							tc_strdup("",&item_id_strDup);
							printf("\n Part Number Value is NULL..!!");fflush(stdout);
						}
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&Newitem_revseq_str));
						if(tc_strlen(Newitem_revseq_str)>0)
						{
							tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
							trimwhitespace(Newitem_revseq_strDup);
						}
						else
						{
							tc_strdup("",&Newitem_revseq_strDup);
							printf("\n [New]Part Revision Sequence Value is NULL..!!");fflush(stdout);
						}
						
						char finalSpecver_no[10];
						tc_strcpy(SpecListPrt,"@");
						tc_strcpy(SpecListAsm,"@");
						tc_strcpy(SpecListDrw,"@");
						printf(" @@@@@@@@@@@@ IMAN SPECIFICATION START @@@@@@@@@@@@\n");fflush(stdout);
						if(IMANSpecType != NULLTAG)
						{
							ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i],IMANSpecType,&IMANSpecCnt,&IMANSpecAttach));
							printf("Dataset Object Count[IMAN_Specification]: [%d]\n",IMANSpecCnt);fflush(stdout);
							if(IMANSpecCnt > 0)
							{
								for (m = 0; m < IMANSpecCnt; m++)
								{
									int Specver_no = 0;
									ITK_CALL(WSOM_ask_object_id_string(IMANSpecAttach[m],&SpecSecObjName));
									printf("SpecSecObjName: [%s]\n",SpecSecObjName);fflush(stdout);
									ITK_CALL(AOM_ask_value_string(IMANSpecAttach[m],"object_type",&Specobject_type));
									printf("Object Type: [%s]\n",Specobject_type);fflush(stdout);
									ITK_CALL(AOM_ask_value_int(IMANSpecAttach[m],"revision_number",&Specver_no));
									printf("Version Number: [%d]\n",Specver_no);fflush(stdout);
									tostring(finalSpecver_no, Specver_no);
									printf("Version Number: [%s]\n",finalSpecver_no);fflush(stdout);
									ITK_CALL(AE_find_dataset_named_ref2(IMANSpecAttach[m],0,&SpecRefName,&SpecRefType,&SpecRefObject));
									ITK_CALL(IMF_ask_original_file_name2(SpecRefObject,&SpecOrginal_Name));
									printf("Before Set Orginal File Name: [%s]\n",SpecOrginal_Name);fflush(stdout);
									ITK_CALL(IMF_ask_file_pathname2(SpecRefObject,mach_type,&SpecOrginal_Path));
									printf("Before Set Orginal File Path: [%s]\n",SpecOrginal_Path);fflush(stdout);
									if(tc_strcmp(Specobject_type,"ProPrt")==0)
									{
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										   tc_strcat(SpecListPrt,item_id_strDup);
						                   tc_strcat(SpecListPrt,"/@");
										   tc_strcat(SpecListPrt,Newitem_revseq_strDup);
						                   tc_strcat(SpecListPrt,"/@");
										   tc_strcat(SpecListPrt,"IMAN_specification");
						                   tc_strcat(SpecListPrt,"/@");
										   tc_strcat(SpecListPrt,SpecSecObjName);
						                   tc_strcat(SpecListPrt,"/@");
										   tc_strcat(SpecListPrt,finalSpecver_no);
						                   tc_strcat(SpecListPrt,"/@");
										}
										else
										{
										   tc_strcat(SpecListPrt,"-");
						                   tc_strcat(SpecListPrt,"/@");
										   tc_strcat(SpecListPrt,"-");
						                   tc_strcat(SpecListPrt,"/@");
										   tc_strcat(SpecListPrt,"-");
						                   tc_strcat(SpecListPrt,"/@");
										   tc_strcat(SpecListPrt,"-");
						                   tc_strcat(SpecListPrt,"/@");
										   tc_strcat(SpecListPrt,"-");
						                   tc_strcat(SpecListPrt,"/@");
										}
									}
									else if(tc_strcmp(Specobject_type,"ProAsm")==0)
									{
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										   tc_strcat(SpecListAsm,item_id_strDup);
						                   tc_strcat(SpecListAsm,"/@");
										   tc_strcat(SpecListAsm,Newitem_revseq_strDup);
						                   tc_strcat(SpecListAsm,"/@");
										   tc_strcat(SpecListAsm,"IMAN_specification");
						                   tc_strcat(SpecListAsm,"/@");
										   tc_strcat(SpecListAsm,SpecSecObjName);
						                   tc_strcat(SpecListAsm,"/@");
										   tc_strcat(SpecListAsm,finalSpecver_no);
						                   tc_strcat(SpecListAsm,"/@");
										}
										else
										{
										   tc_strcat(SpecListAsm,"-");
						                   tc_strcat(SpecListAsm,"/@");
										   tc_strcat(SpecListAsm,"-");
						                   tc_strcat(SpecListAsm,"/@");
										   tc_strcat(SpecListAsm,"-");
						                   tc_strcat(SpecListAsm,"/@");
										   tc_strcat(SpecListAsm,"-");
						                   tc_strcat(SpecListAsm,"/@");
										   tc_strcat(SpecListAsm,"-");
						                   tc_strcat(SpecListAsm,"/@");
										}
									}
									else if(tc_strcmp(Specobject_type,"ProDrw")==0)
									{
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										   tc_strcat(SpecListDrw,item_id_strDup);
						                   tc_strcat(SpecListDrw,"/@");
										   tc_strcat(SpecListDrw,Newitem_revseq_strDup);
						                   tc_strcat(SpecListDrw,"/@");
										   tc_strcat(SpecListDrw,"IMAN_specification");
						                   tc_strcat(SpecListDrw,"/@");
										   tc_strcat(SpecListDrw,SpecSecObjName);
						                   tc_strcat(SpecListDrw,"/@");
										   tc_strcat(SpecListDrw,finalSpecver_no);
						                   tc_strcat(SpecListDrw,"/@");
										}
										else
										{
										   tc_strcat(SpecListDrw,"-");
						                   tc_strcat(SpecListDrw,"/@");
										   tc_strcat(SpecListDrw,"-");
						                   tc_strcat(SpecListDrw,"/@");
										   tc_strcat(SpecListDrw,"-");
						                   tc_strcat(SpecListDrw,"/@");
										   tc_strcat(SpecListDrw,"-");
						                   tc_strcat(SpecListDrw,"/@");
										   tc_strcat(SpecListDrw,"-");
						                   tc_strcat(SpecListDrw,"/@");
										}
									}
									else
									{
									  printf("\n [Specobject_type] Not Matched For [IMAN_Specification] Relation..!!\n");fflush(stdout);
									}
								}
							}
							else
							{
							  printf("\n No Object Found in [IMAN_Specification] Relation..!!\n");fflush(stdout);
							}
						}
						else
						{
							printf("\n Relation Tag[IMAN_Specification] Not Found..!!\n");fflush(stdout);
						}
						printf(" @@@@@@@@@@@@ IMAN SPECIFICATION END @@@@@@@@@@@@\n");fflush(stdout);
						printf("\n Spec_ListPrt Before STRING_REPLACE: [%s]",SpecListPrt);fflush(stdout);
						printf("\n Spec_ListAsm Before STRING_REPLACE: [%s]",SpecListAsm);fflush(stdout);
						printf("\n SpecListDrw Before STRING_REPLACE: [%s]",SpecListDrw);fflush(stdout);
	                    STRNG_replace_str(SpecListPrt,"@","",&SpecListPrt);
						STRNG_replace_str(SpecListAsm,"@","",&SpecListAsm);
						STRNG_replace_str(SpecListDrw,"@","",&SpecListDrw);
	                    printf("\n Spec_ListPrt After STRING_REPLACE: [%s]",SpecListPrt);fflush(stdout);
						printf("\n Spec_ListAsm After STRING_REPLACE: [%s]",SpecListAsm);fflush(stdout);
						printf("\n Spec_ListDrw After STRING_REPLACE: [%s]",SpecListDrw);fflush(stdout);
						
						
						/* printf("\n Function1: Reference Relation Dataset Find Start..!!\n");fflush(stdout);
						RefDSList_Status = TC_RefDataset(tdesrev,IMANRefType);
						printf("\n Reference Relation Dataset: [%s]", RefDSList_Status);fflush(stdout);
						printf("\n Function1: Reference Relation Dataset Find End..!!\n");fflush(stdout); */
						
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s\n",item_id_strDup,Newitem_revseq_strDup,SpecListPrt,SpecListAsm,SpecListDrw);fflush(fpOutput_file);
					}						
				}
				else
				{
				   printf("\n Objects[DesignRevision Sequence] Not Found..!!\n");fflush(stdout);
				}					
			}
			else
			{
				printf("\n Query[DesignRevision Sequence] Tag Not Found..!! \n");fflush(stdout);
			}
		}
	}
	else
	{
		printf("\n Input PartList File is NULL..!!");fflush(stdout);
	}
	fclose(fpOutput_file);
	fclose(fpPart_List);
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_Creodataprocess.c
* // ./linkitk -o tm_Creodataproces tm_Creodataproces.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/CreoDataProcess/tm_Creodataproces .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/CreoDataProcess/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/CreoDataProcess/InputList.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/CreoDataProcess/usage.txt .
* // ./tm_Creodataproces -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_Creodataproces -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/