######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : DECEMBER-2023
#
#######################################################################################
. /user/cvprod/.bash_profile

echo -e "\n~~~~~~~~~~ N A M E D - R E F E R E N C E  I M P O R T  S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "Part_No: -----> "$1

echo "Revision: -----> "$2

echo "Sequence: -----> "$3

echo "Name: -----> "$4

echo "File_Name: -----> "$5

echo -e "\nIn Shell Argument Print Ended...."

echo -e "\nEXE(tm_DatasetImport) Execution Started...."
/user/cvprod/sourav/DATASETIMPORT/tm_DatasetImport -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=ERC_Designers_Group -prt=$1 -rev=$2 -seq=$3 -name=$4 -fname=$5
echo -e "\nEXE(tm_DatasetImport) Execution Ended...."

echo -e "\n~~~~~~~~~~ N A M E D - R E F E R E N C E  I M P O R T  S H E L L   E N D E D ~~~~~~~~~~~~"
