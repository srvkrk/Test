scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_Update/tm_namedref_update .
