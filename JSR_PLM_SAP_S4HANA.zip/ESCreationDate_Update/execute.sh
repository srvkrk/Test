/user/cvprod/sourav/Revision_Property_Update/tm_property_update -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
