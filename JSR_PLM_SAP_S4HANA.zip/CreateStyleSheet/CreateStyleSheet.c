/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   AE(Dataset)
*  Description  :   Create Stylesheet & Import NamedReference File into Dataset  
*  File Name    :   CreateStyleSheet.c
*  Created on   :   Aug 28th, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     28/09/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *Filename = NULL;
	char *Dstype = NULL;
	char *Dsname = NULL;
	char *Refname = NULL;
	char *Toolname = NULL;
	char *Formatname = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	Filename = ITK_ask_cli_argument("-f="); //NamedReference File Name with extension
	Dstype = ITK_ask_cli_argument("-type="); //Dataset Type
	Dsname = ITK_ask_cli_argument("-d="); //Dataset Name
	Refname = ITK_ask_cli_argument("-ref="); //NamedReference reference_name
	Toolname = ITK_ask_cli_argument("-tool="); //Tool Used
	Formatname = ITK_ask_cli_argument("-format="); //Named Reference File Format Name
	
	printf(" [1]: NamedReference File Name with extension(Filename): [%s]\n",Filename);
	printf(" [2]: Dataset Type(Dstype): [%s]\n",Dstype);
	printf(" [3]: Dataset Name(Dsname): [%s]\n",Dsname);
	printf(" [4]: NamedReference reference_name(Refname): [%s]\n",Refname);
	printf(" [5]: Tool Used(Toolname): [%s]\n",Toolname);
	printf(" [6]: Named Reference File Format Name(Formatname): [%s]\n",Formatname);
	
    if((tc_strlen(Filename)>0) && (tc_strlen(Dstype)>0) && (tc_strlen(Dsname)>0) && (tc_strlen(Refname)>0) && (tc_strlen(Toolname)>0) && (tc_strlen(Formatname)>0))
	{		
		printf("\n Stylesheet Creation Start..!!\n");fflush(stdout);
		char *FileLoc = NULL;
		IMF_file_t	fileDescriptor;
		tag_t	datasettype = NULLTAG;
		tag_t	tool 		= NULLTAG;
		tag_t	Newdataset 	= NULLTAG;
		tag_t	filetag 	= NULLTAG;
		
		FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
		//tc_strcpy(Filename,RptFile);
		//printf(" File Name: [%s]\n", Filename);fflush(stdout);

		//tc_strcpy(FileLoc,"/user/cvprod/sourav/ReportBuilderPartAppRpt/");
		//tc_strcat(FileLoc,Filename);
		tc_strcpy(FileLoc,Filename);
		printf(" File Location: [%s]\n", FileLoc);fflush(stdout);

		ITK_CALL(AE_find_datasettype2(Dstype,&datasettype));
		ITK_CALL(AE_find_tool2(Toolname, &tool));
		ITK_CALL(AE_create_dataset_with_id(datasettype,Dsname,"",NULL,NULL,&Newdataset));
		ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
		ITK_CALL(AE_set_dataset_format2(Newdataset,Formatname));
		ITK_CALL(AOM_save_without_extensions(Newdataset));
		if(tc_strcmp(Formatname,"TEXT_REF")==0)
		{
			ITK_CALL(IMF_fmsfile_import(FileLoc,Filename,SS_TEXT,&filetag,&fileDescriptor));
		}
		else
		{
			ITK_CALL(IMF_fmsfile_import(FileLoc,Filename,SS_BINARY,&filetag,&fileDescriptor));
		}
		if(filetag == NULLTAG)
		{
			printf(" File Tag Not Found..!!\n");fflush(stdout);
		}
		ITK_CALL(AOM_refresh(Newdataset,TRUE));
		ITK_CALL(AE_add_dataset_named_ref2(Newdataset, Refname, AE_PART_OF, filetag));
		ITK_CALL(AOM_save_without_extensions(Newdataset));
		ITK_CALL(AOM_refresh(Newdataset,FALSE));
		printf("\n Stylesheet Creation Completed Successfully..!!\n");fflush(stdout);
	}
	else
    {
		printf(" !!!!! Stylesheet Creation Failed. Please Check Input Argument !!!!!\n");fflush(stdout);
		printf(" [1]: NamedReference File Name with extension(Filename)\n");
	    printf(" [2]: Dataset Type(Dstype)\n");
	    printf(" [3]: Dataset Name(Dsname)\n");
	    printf(" [4]: NamedReference reference_name(Refname)\n");
	    printf(" [5]: Tool Used(Toolname)\n");
	    printf(" [6]: Named Reference File Format Name(Formatname)\n");
    }
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}