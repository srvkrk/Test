/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Calculate Days between two dates excluding Saturday & Sunday 
*  File Name    :   tm_daycalculate.c
*  Created on   :   Jun 19th, 2025
*  Usage        :   tm_daycalculate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     19/06/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

// Function to check if a date is a weekday (Monday-Friday)
bool isWeekday(struct tm *date) 
{
    int dayOfWeek = date->tm_wday;
    return (dayOfWeek != 0 && dayOfWeek != 6);
}

// Function to calculate the number of weekdays between two dates
int weekdaysBetween(time_t start, time_t end) 
{
    int weekdays = 0;
    struct tm startDate, endDate;
    localtime_r(&start, &startDate);
    localtime_r(&end, &endDate);

    while (difftime(mktime(&endDate), mktime(&startDate)) > 0) 
    {
        if (isWeekday(&startDate)) 
        {
            weekdays++;
        }
        startDate.tm_mday++;
        mktime(&startDate);
    }

    return weekdays;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	//char* received = "09-10-2024  09:23:00";
	//char* completed = "18-11-2024  14:09:00";
	
	//char received[50] = "25-06-2025/18:12:00";
	//char completed[50] = "25-06-2025/18:14:00";
	char received[50] = "26-06-2025/16:32:00";
	char completed[50] = "01-07-2025/09:28:00";
	/* if(received != NULL)
	{
		STRNG_replace_str(received,"  ","/",&received);
	} */
	char* Freceived = NULL;
	char* Sreceived = NULL;
	Freceived = tc_strtok(received,"/");
	Sreceived = tc_strtok(NULL,"/");
	printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
	printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
	char* ReInpDay = NULL;
	char* ReInpMon = NULL;
	char* ReInpYear = NULL;
	char* ReInpYearChar = NULL;
	ReInpDay=tc_strtok(Freceived,"-");
	ReInpMon=tc_strtok(NULL,"-");
	ReInpYear=tc_strtok(NULL,"-");
	printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
	printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
	printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
	ReInpYearChar=subString(ReInpYear,2,2);
	printf("\n ReInpYearChar: [%s]",ReInpYearChar);fflush(stdout);
	char* ReInpYearCharFinal = NULL;
	ReInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
	tc_strcpy(ReInpYearCharFinal,"1");
	tc_strcat(ReInpYearCharFinal,ReInpYearChar);
	printf("\n ReInpYearCharFinal: [%s] \n", ReInpYearCharFinal);fflush(stdout);
	char* ReInpHr = NULL;
	char* ReInpMnt = NULL;
	char* ReInpSec = NULL;
	ReInpHr=tc_strtok(Sreceived,":");
	ReInpMnt=tc_strtok(NULL,":");
	ReInpSec=tc_strtok(NULL,":");
	printf("\n ReInpHr: [%s]\n", ReInpHr);fflush(stdout);
	printf("\n ReInpMnt: [%s]\n", ReInpMnt);fflush(stdout);
	printf("\n ReInpSec: [%s]\n", ReInpSec);fflush(stdout);
	
	
	/* if(completed != NULL)
	{
		STRNG_replace_str(completed,"  ","/",&completed);
	} */
	char* Fcompleted = NULL;
	char* Scompleted = NULL;
	Fcompleted = tc_strtok(completed,"/");
	Scompleted = tc_strtok(NULL,"/");
	printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
	printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
	char* ComInpDay = NULL;
	char* ComInpMon = NULL;
	char* ComInpYear = NULL;
	char* ComInpYearChar = NULL;
	ComInpDay=tc_strtok(Fcompleted,"-");
	ComInpMon=tc_strtok(NULL,"-");
	ComInpYear=tc_strtok(NULL,"-");
	printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
	printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
	printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
	ComInpYearChar=subString(ComInpYear,2,2);
	printf("\n ComInpYearChar: [%s]",ComInpYearChar);fflush(stdout);
	char* ComInpYearCharFinal = NULL;
	ComInpYearCharFinal = (char *) MEM_alloc( 20 * sizeof(char) );
	tc_strcpy(ComInpYearCharFinal,"1");
	tc_strcat(ComInpYearCharFinal,ComInpYearChar);
	printf("\n ComInpYearCharFinal: [%s] \n", ComInpYearCharFinal);fflush(stdout);
	char* ComInpHr = NULL;
	char* ComInpMnt = NULL;
	char* ComInpSec = NULL;
	ComInpHr=tc_strtok(Scompleted,":");
	ComInpMnt=tc_strtok(NULL,":");
	ComInpSec=tc_strtok(NULL,":");
	printf("\n ComInpHr: [%s]\n", ComInpHr);fflush(stdout);
	printf("\n ComInpMnt: [%s]\n", ComInpMnt);fflush(stdout);
	printf("\n ComInpSec: [%s]\n", ComInpSec);fflush(stdout);
	
	int ReInpdayFinal = atoi(ReInpDay);
	int ReInpMonFinal = atoi(ReInpMon);
	int ReInpYearFinal = atoi(ReInpYearCharFinal);
	int ReInpHrFinal = atoi(ReInpHr);
	int ReInpMntFinal = atoi(ReInpMnt);
	int ReInpSecFinal = atoi(ReInpSec);
	
	int ComInpDayFinal = atoi(ComInpDay);
	int ComInpMonFinal = atoi(ComInpMon);
	int ComInpYearFinal = atoi(ComInpYearCharFinal);
	int ComInpHrFinal = atoi(ComInpHr);
	int ComInpMntFinal = atoi(ComInpMnt);
	int ComInpSecFinal = atoi(ComInpSec);
	
	
    //struct tm tm_start = {0, 5, 0, 1, 00, 125}; // January 1, 2025
    //struct tm tm_end = {0, 5, 0, 19, 1, 125};  // January 10, 2025
	
	struct tm tm_start = {ReInpSecFinal, ReInpMntFinal, ReInpHrFinal, ReInpdayFinal, ReInpMonFinal, ReInpYearFinal}; // January 1, 2025
    struct tm tm_end = {ComInpSecFinal, ComInpMntFinal, ComInpHrFinal, ComInpDayFinal, ComInpMonFinal, ComInpYearFinal};  // January 10, 2025
    
    time_t start = mktime(&tm_start);
    time_t end = mktime(&tm_end);
    
    printf("Current start: %s", ctime(&start));
    printf("Current end: %s", ctime(&end));

    int weekdayCount = weekdaysBetween(start, end);
    printf("Number of weekdays between the dates: %d\n", weekdayCount);
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_daycalculate.c
* // ./linkitk -o tm_daycalculate tm_daycalculate.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DayCalculate/tm_daycalculate .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DayCalculate/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DayCalculate/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DayCalculate/SendEmail.sh .
* // ./tm_daycalculate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_daycalculate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_daycalculate -u=infodba -p=infodba123 -g=dba
*
***************************************************************************/