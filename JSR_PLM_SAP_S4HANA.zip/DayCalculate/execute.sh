/user/cvprod/sourav/DayCalculate/tm_daycalculate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
