######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : OCTOBER-2025
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'S4Hana Part Wise Material Loading(CREATE) Program Started...'
echo  "-----------------------------------------------------------------------------------------"
echo "Change Number Generation Start"
DATE=$(date +"%d%m%y")
cno="CORRCT$DATE"
echo "Generated Change No: $cno"
echo "Change Number Generation End"

PrtList='PartListCreate.lst'

if [ ! -f $PrtList ]; then
        echo "Part List File Not Found"
        exit 1
fi

while read PartNumber; do
Total=$((Total+1))
echo "Part $Total : $PartNumber"
done < $PrtList

echo "Total Input Part : $Total"

line_no=1

date
for i in `cat PartListCreate.lst`
do
echo "------------------- Loading On Going For Part : $i ----------------------"
start_time=$(date)
echo "[$line_no/$Total] SOURAV: LOADING-START For Part : $PartNumber Start-Time: $start_time"
echo "EXE Calling Start....."
/user/cvprod/PLMSAP/liveXfr_po/PartMatCreChangeUA -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -i=$i -j=2001 -f=CR -c=$cno -s=CVP
echo "EXE Calling End......."
end_time=$(date)
echo "[$line_no/$Total] SOURAV: LOADING-END For Part : $PartNumber End-Time: $end_time"
line_no=$((line_no+1))
done
date
echo  "-----------------------------------------------------------------------------------------"
echo  'S4Hana Part Wise Material Loading(CREATE) Program Finished...'
echo  "-----------------------------------------------------------------------------------------"
