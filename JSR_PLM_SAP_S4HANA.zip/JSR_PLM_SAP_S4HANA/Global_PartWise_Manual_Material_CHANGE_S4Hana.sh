######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : OCTOBER-2025
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'Global S4Hana Part Wise Material(CHANGE) Program Started...'
echo  "-----------------------------------------------------------------------------------------"
echo "Change Number Generation Start"
DATE=$(date +"%d%m%y")
cno="CORRCT$DATE"
echo "Generated Change No: $cno"
echo "Change Number Generation End"

PrtList='GlobalPartListChange.lst'

if [ ! -f $PrtList ]; then
        echo "Part List File Not Found"
        exit 1
fi

while read PartNumber; do
Total=$((Total+1))
echo "Part $Total : $PartNumber"
done < $PrtList

echo "Total Input Part : $Total"

line_no=1

date
for i in `cat GlobalPartListChange.lst`
do
echo "------------------- Loading On Going For Item : $i ----------------------"
one=$(echo "$i" | cut -d',' -f1)
two=$(echo "$i" | cut -d',' -f2)
echo "First Argument: $one"
echo "Second Argument: $two"
start_time=$(date)
echo "[$line_no/$Total] SOURAV: Material Change For Item : $i Start-Time: $start_time"
echo "EXE Calling Start....."
/user/cvprod/PLMSAP/liveXfr_po/PartMatCreChangeUA -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -i=$one -j=$two -f=CH -c=$cno -s=CVP
echo "EXE Calling End......."
end_time=$(date)
echo "[$line_no/$Total] SOURAV: Material Change For Item : $i End-Time: $end_time"
line_no=$((line_no+1))
done
date
echo  "-----------------------------------------------------------------------------------------"
echo  'Global S4Hana Part Wise Material(CHANGE) Program Finished...'
echo  "-----------------------------------------------------------------------------------------"
