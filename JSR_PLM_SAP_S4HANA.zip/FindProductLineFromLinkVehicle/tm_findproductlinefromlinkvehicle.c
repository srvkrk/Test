/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Query Design Revision & Sequence & Return It's Linked with Any Vehicle or Not then Return Product_Line.
*  File Name    :   tm_findproductlinefromlinkvehicle.c
*  Created on   :   Nov 15th, 2025
*  Usage        :   tm_findproductlinefromlinkvehicle
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     15/11/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int TC_EEVehLinkStatus(char* ModAdd,char* PNSrch,char* RevSeqSrch,FILE* ResRpt,char* RptDT)
{
	int ifail = ITK_ok;
	char* item_rev_strDup = NULL;
	char* item_seq_strDup = NULL;
	item_rev_strDup=strtok(RevSeqSrch,";");
    item_seq_strDup=strtok(NULL,";");
	printf("\n Vehicle Rev Value After Token: [%s]\n", item_rev_strDup);fflush(stdout);
	printf("\n Vehicle Seq Value After Token: [%s]\n", item_seq_strDup);fflush(stdout);
	char *PNRevSeqSrch = (char *) malloc(20*sizeof(char));
	tc_strcpy(PNRevSeqSrch,item_rev_strDup);
	tc_strcat(PNRevSeqSrch,";");
	tc_strcat(PNRevSeqSrch,item_seq_strDup);
	printf("\n Final Revision & Sequence: [%s]\n", PNRevSeqSrch);fflush(stdout);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char* ResponseVehlinkStat = NULL;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	tag_t rev_tags_found = NULLTAG;
	tag_t tParentDesRev = NULLTAG;
	int linkcount = 0;

	printf("\n Searched Module Address Value: [%s]\n", ModAdd);fflush(stdout);
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
            int	status_count = 0;
	        tag_t* relStatus_list = NULLTAG;
            char* latest_rev_Rel_Status = NULL;
	        char* latest_rev_Rel_StatusDup = NULL;			
	        rev_tags_found = tpLCQryobj_results[0];
	
			tag_t	tPNSrch	= NULLTAG;
			ITK_CALL(ITEM_find_item(PNSrch,&tPNSrch));
			char  **relations=NULL;
			ITK_CALL(WSOM_where_referenced2(tPNSrch, 1 ,&n_parents,&levels,&parents,&relations));
			//ITK_CALL(PS_where_used_all(rev_tags_found, 1, &n_parents, &levels, &parents));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Attachment Found: [%d]\n",n_parents);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_parents > 0)
			{
				int z = 0;
				printf(" Parent Attachment Found..!!\n");fflush(stdout);
				for(z = 0; z < n_parents; z++)
				{ 
				   tParentDesRev = parents[z];
				   char *Parent_ID = NULL;
				   char *Parent_IDDup = NULL;
				   char *Parent_RevSeq = NULL;
				   char *Parent_RevSeqDup = NULL;
				   char *Parent_PartType = NULL;
				   char *Parent_PartTypeDup = NULL;
				   char *Parent_Product = NULL;
				   char *Parent_ProductDup = NULL;
				   char *Parent_ObjType = NULL;
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_id",&Parent_ID));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_revision_id",&Parent_RevSeq));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_PartType",&Parent_PartType));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_Product",&Parent_Product));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"object_type",&Parent_ObjType));
				    if(tc_strlen(Parent_Product)>0)
					{
						tc_strdup(Parent_Product,&Parent_ProductDup);
					}
					else
					{
						tc_strdup("NA",&Parent_ProductDup);
						printf("\n Part Parent Product Value is NULL/Blank");fflush(stdout);
					}
				   
				   printf("\n Parent Part_No: [%s]",Parent_ID);fflush(stdout);
				   printf("\n Parent Rev&Seq No: [%s]",Parent_RevSeq);fflush(stdout);
				   printf("\n Parent Part Type: [%s]",Parent_PartType);fflush(stdout);
				   printf("\n Parent Part Product: [%s]",Parent_ProductDup);fflush(stdout);
				   printf("\n Parent Part Object Type: [%s]",Parent_ObjType);fflush(stdout);
				   
				   if(Parent_ID!=NULL)tc_strdup(Parent_ID,&Parent_IDDup);
				   if(Parent_RevSeq!=NULL)tc_strdup(Parent_RevSeq,&Parent_RevSeqDup);
				   if(Parent_PartType!=NULL)tc_strdup(Parent_PartType,&Parent_PartTypeDup);
				    if(tc_strlen(Parent_PartTypeDup)>0)
				    {
					    if(((tc_strcmp(Parent_PartTypeDup,"V") == 0) || (tc_strcmp(Parent_PartTypeDup,"VC") == 0) || (tc_strcmp(Parent_PartTypeDup,"VCCR") == 0)) && (tc_strcmp(Parent_ObjType,"Design Revision") == 0))
					    {
							if((tc_strcmp(Parent_ProductDup,"HCV") == 0) || (tc_strcmp(Parent_ProductDup,"ILMCV") == 0) || (tc_strcmp(Parent_ProductDup,"BUS") == 0) || (tc_strcmp(Parent_ProductDup,"DEFENCE") == 0) || (tc_strcmp(Parent_ProductDup,"SCV") == 0))
							{
								fprintf(ResRpt,"%s,%s,%s,%s,%s,%s\n",ModAdd,PNSrch,item_rev_strDup,item_seq_strDup,Parent_ID,Parent_ProductDup);fflush(ResRpt);
								printf("\n \033[32m>>>>> Product Line Found & Written in Successfully 🔥 \033[0m<<<<<<");fflush(stdout);
								goto jump;								
							}
							else
							{
							   printf("\n >>>>> Product Line Not Found From Vehicle So, Continue.. <<<<<<");fflush(stdout);
							}
					    }
				    }   
				}
			}
			else
			{
				printf("Parent Count Zero[0]..!!\n");fflush(stdout);
			}	
		}
		else
		{
			printf("\nEntered Revision Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\nDesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	jump:
	    printf("\n All Vehicle Product_Line Details Written Successfully on File..!!\n");fflush(stdout);
	
	return ifail;
}

int TC_VehLinkStatus(char* ModAdd,char* PNSrch,char* RevSeqSrch,FILE* ResRpt,char* RptDT)
{
	int ifail = ITK_ok;
	char* item_rev_strDup = NULL;
	char* item_seq_strDup = NULL;
	item_rev_strDup=strtok(RevSeqSrch,";");
    item_seq_strDup=strtok(NULL,";");
	printf("\n Vehicle Rev Value After Token: [%s]\n", item_rev_strDup);fflush(stdout);
	printf("\n Vehicle Seq Value After Token: [%s]\n", item_seq_strDup);fflush(stdout);
	char *PNRevSeqSrch = (char *) malloc(20*sizeof(char));
	tc_strcpy(PNRevSeqSrch,item_rev_strDup);
	tc_strcat(PNRevSeqSrch,";");
	tc_strcat(PNRevSeqSrch,item_seq_strDup);
	printf("\n Final Revision & Sequence: [%s]\n", PNRevSeqSrch);fflush(stdout);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char* ResponseVehlinkStat = NULL;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	tag_t rev_tags_found = NULLTAG;
	tag_t tParentDesRev = NULLTAG;
	int linkcount = 0;
	printf("\n Searched Module Address Value: [%s]\n", ModAdd);fflush(stdout);
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
            int	status_count = 0;
	        tag_t* relStatus_list = NULLTAG;
            char* latest_rev_Rel_Status = NULL;
	        char* latest_rev_Rel_StatusDup = NULL;			
	        rev_tags_found = tpLCQryobj_results[0];
			tag_t RevRuleObjTag = NULLTAG;
			
			ITK_CALL(CFM_find("MBOM Release and Above", &RevRuleObjTag));
			//ITK_CALL(PS_where_used_all(rev_tags_found, 1, &n_parents, &levels, &parents));
			ITK_CALL(PS_where_used_configured(rev_tags_found,RevRuleObjTag,1,&n_parents,&levels,&parents));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Attachment Found: [%d]\n",n_parents);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_parents > 0)
			{
				int z = 0;
				printf(" Parent Attachment Found..!!\n");fflush(stdout);
				for(z = 0; z < n_parents; z++)
				{ 
				   tParentDesRev = parents[z];
				   char *Parent_ID = NULL;
				   char *Parent_IDDup = NULL;
				   char *Parent_RevSeq = NULL;
				   char *Parent_RevSeqDup = NULL;
				   char *Parent_PartType = NULL;
				   char *Parent_PartTypeDup = NULL;
				   char *Parent_Product = NULL;
				   char *Parent_ProductDup = NULL;
				   char *Parent_ObjType = NULL;
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_id",&Parent_ID));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_revision_id",&Parent_RevSeq));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_PartType",&Parent_PartType));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_Product",&Parent_Product));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"object_type",&Parent_ObjType));
				    if(tc_strlen(Parent_Product)>0)
					{
						tc_strdup(Parent_Product,&Parent_ProductDup);
					}
					else
					{
						tc_strdup("NA",&Parent_ProductDup);
						printf("\n Part Parent Product Value is NULL/Blank");fflush(stdout);
					}
				   
				   printf("\n Parent Part_No: [%s]",Parent_ID);fflush(stdout);
				   printf("\n Parent Rev&Seq No: [%s]",Parent_RevSeq);fflush(stdout);
				   printf("\n Parent Part Type: [%s]",Parent_PartType);fflush(stdout);
				   printf("\n Parent Part Product: [%s]",Parent_ProductDup);fflush(stdout);
				   printf("\n Parent Part Object Type: [%s]",Parent_ObjType);fflush(stdout);
				   
				   if(Parent_ID!=NULL)tc_strdup(Parent_ID,&Parent_IDDup);
				   if(Parent_RevSeq!=NULL)tc_strdup(Parent_RevSeq,&Parent_RevSeqDup);
				   if(Parent_PartType!=NULL)tc_strdup(Parent_PartType,&Parent_PartTypeDup);
				    if(tc_strlen(Parent_PartTypeDup)>0)
				    {
					    if(((tc_strcmp(Parent_PartTypeDup,"V") == 0) || (tc_strcmp(Parent_PartTypeDup,"VC") == 0) || (tc_strcmp(Parent_PartTypeDup,"VCCR") == 0)) && (tc_strcmp(Parent_ObjType,"Design Revision") == 0))
					    {
							
							if((tc_strcmp(Parent_ProductDup,"HCV") == 0) || (tc_strcmp(Parent_ProductDup,"ILMCV") == 0) || (tc_strcmp(Parent_ProductDup,"BUS") == 0) || (tc_strcmp(Parent_ProductDup,"DEFENCE") == 0) || (tc_strcmp(Parent_ProductDup,"SCV") == 0))
							{
								fprintf(ResRpt,"%s,%s,%s,%s,%s,%s\n",ModAdd,PNSrch,item_rev_strDup,item_seq_strDup,Parent_ID,Parent_ProductDup);fflush(ResRpt);
								printf("\n \033[32m>>>>> Product Line Found & Written in Successfully 🔥 \033[0m<<<<<<");fflush(stdout);
                                goto jump;								
							}
							else
							{
							   printf("\n >>>>> Product Line Not Found From Vehicle So, Continue.. <<<<<<");fflush(stdout);
							}
					    }
				    }   
				}
			}
			else
			{
				printf("Parent Count Zero[0]..!!\n");fflush(stdout);
			}	
		}
		else
		{
			printf("\nEntered Revision Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\nDesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	jump:
	    printf("\n All Vehicle Product_Line Details Written Successfully on File..!!\n");fflush(stdout);
	  

	return ifail;
}

int ITK_user_main(int argc,char* argv[])
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_file_str = NULL;
	char *inp_file_strDup = NULL;
	int i = 0;
	char *SrcPart_No = NULL;
	char *SrcRevSeq = NULL;
	char *SrcDesGrp = NULL;
	char *RptFile = (char *) malloc(200*sizeof(char));
	FILE *fpOutput_file = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *sr_no_strDup = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *item_revseq_strDup = (char *) malloc(20*sizeof(char));
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tQryDesRev = NULLTAG;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	int j = 0;
	char *Parent_ID = NULL;
	char *Parent_RevSeq = NULL;
	char *Parent_IDDup = NULL;
	char *Parent_RevSeqDup = NULL;
	char *Parent_PartType = NULL;
	char *Parent_PartTypeDup = NULL;
	tag_t tParentDesRev = NULLTAG;
	char *item_add_str = NULL;
	char *item_add_strDup = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inp_file_str = ITK_ask_cli_argument("-i=");
	trimwhitespace(inp_file_str);
	if(inp_file_str!=NULL)tc_strdup(inp_file_str,&inp_file_strDup);
	printf(" [1]: Input File_Name(inp_file_strDup): [%s]\n",inp_file_strDup);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Output_Vehicle_Link_Pltform_Status_Rpt_File");
	//tc_strcat(RptFile,".txt");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
	fpPart_List = fopen(inp_file_strDup,"r");
	 
    fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"ADDRESS, PART_NO, REV, SEQ, LINKED_VEHICLE, PRODUCT_LINE \n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_add_str=strtok(Buffer,"^");
			item_id_str=strtok(NULL,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			
			if(item_add_str!=NULL)tc_strdup(item_add_str,&item_add_strDup);
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			
			if(item_add_strDup!=NULL)trimwhitespace(item_add_strDup);
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_rev_strDup!=NULL)trimwhitespace(item_rev_strDup);
			if(item_seq_strDup!=NULL)trimwhitespace(item_seq_strDup);
			
			tc_strcpy(item_revseq_strDup,item_rev_strDup);
			tc_strcat(item_revseq_strDup,"*");
			tc_strcat(item_revseq_strDup,item_seq_strDup);
			
			printf("\n Mod Address(item_add_strDup): [%s]\n",item_add_strDup);
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			printf("\n Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
			printf("\n Part Rev&Seq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"A*2","5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						tQryDesRev = titemobj_results[i];
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_id",&SrcPart_No));
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_revision_id",&SrcRevSeq));
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"t5_DesignGrp",&SrcDesGrp));
						printf("Child Part Details: ----> Child_Part_No: [%s], Child_Part_RevSeq: [%s]\n",SrcPart_No,SrcRevSeq);fflush(stdout);
						
						if(tc_strcmp(SrcDesGrp,"16")==0)
						{
							printf("\n Function2: [EE_Part] Vehicle Link And Platform Status Find Start..!!\n");fflush(stdout);
						    TC_EEVehLinkStatus(item_add_strDup,SrcPart_No,SrcRevSeq,fpOutput_file,GenDate);
						    printf("\n Function2: [EE_Part] Vehicle Link And Platform Status Find End..!!\n");fflush(stdout);
						}
						else
						{
							printf("\n Function1: [Normal_Part] Vehicle Link And Platform Status Find Start..!!\n");fflush(stdout);
						    TC_VehLinkStatus(item_add_strDup,SrcPart_No,SrcRevSeq,fpOutput_file,GenDate);
						    printf("\n Function1: [Normal_Part] Vehicle Link And Platform Status Find End..!!\n");fflush(stdout);
						}
					}
				}
				else
				{
					printf("\n Design Revision Not Found Continue..!!\n");fflush(stdout);
				}
			}
		}
        printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 		
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
    fclose(fpOutput_file);
	fclose(fpPart_List);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_findproductlinefromlinkvehicle.c
* // ./linkitk -o tm_findproductlinefromlinkvehicle tm_findproductlinefromlinkvehicle.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/FindProductLineFromLinkVehicle/tm_findproductlinefromlinkvehicle .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/FindProductLineFromLinkVehicle/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/FindProductLineFromLinkVehicle/usage.txt .
* // ./tm_findproductlinefromlinkvehicle -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_findproductlinefromlinkvehicle -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/