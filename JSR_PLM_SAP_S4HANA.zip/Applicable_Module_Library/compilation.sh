./compile tm_applicable_module_library.c
./linkitk -o tm_applicable_module_library tm_applicable_module_library.o
chmod 777 tm_applicable_module_library*
