/user/cvprod/sourav/Junk_Character_Report/tm_junk_character_report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -part=2829012083R
