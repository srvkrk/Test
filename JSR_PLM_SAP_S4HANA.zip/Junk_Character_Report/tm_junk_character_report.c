/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query All Revision of Input Part & Print it's Previous All Revision Metadata and Latest Revision's BOM on Reports  
*  File Name    :   tm_junk_character_report.c
*  Created on   :   Sept 04th, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     04/09/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int TC_AllRevMetadata(char* partno, FILE* OPRpt)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t revTag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *item_drw_str = NULL;
	char *item_drw_strDup = NULL;
	char *inp_parttype_str = NULL;
	char *item_mod_desc = NULL;
	char *item_mod_descDup = NULL;
	char *item_modname_str = NULL;
	char *item_modname_strDup = NULL;
	char *item_drwind_str = NULL;
	char *item_drwind_strDup = NULL;
	char *item_srfcstd_str = NULL;
	char *item_srfcstd_strDup = NULL;
	char *item_mat_str = NULL;
	char *item_mat_strDup = NULL;
	char *inp_part_str = NULL;
	char *inp_rev_str = NULL;
	char *inp_seq_str = NULL;
	char *item_owner = NULL;
	char *item_ownerDup = NULL;
	
	printf("\n Part No in Function1: [%s]\n",partno);fflush(stdout);
	printf("\n Finding Query[Item Revision...] !!\n");fflush(stdout);
	ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query [Item Revision...] Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Item ID","Revision","Type"};
		char *cValues[3]  = {partno,"*","Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total Revision Object Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
			{
				revTag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
				if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
				}
				else
				{
					tc_strdup(" ",&item_id_strDup);
					printf("\n Final Part_No Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
				tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
				item_rev_str=strtok(Newitem_revseq_strDup,";");
				item_seq_str=strtok(NULL,";");
				if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
				if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
				
				ITK_CALL(AOM_UIF_ask_value(revTag,"owning_user",&item_owner));
				if(tc_strlen(item_owner)>0)
				{
				    tc_strdup(item_owner,&item_ownerDup);
					trimwhitespace(item_ownerDup);
					printf("\n Item Owner Value After Dup & Trim: [%s]", item_ownerDup);fflush(stdout);
					STRNG_replace_str(item_ownerDup,","," ",&item_ownerDup);
					STRNG_replace_str(item_ownerDup,";"," ",&item_ownerDup);
					STRNG_replace_str(item_ownerDup,"\n"," ",&item_ownerDup);
					STRNG_replace_str(item_ownerDup,"'"," ",&item_ownerDup);
					printf("\n Item Owner Final Value: [%s]", item_ownerDup);fflush(stdout);
				}
				else
				{
					tc_strdup(" ",&item_ownerDup);
					printf("\n Final Item Owner Value is NULL..!!");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_string(revTag,"t5_DrawingNo",&item_drw_str));
				if(tc_strlen(item_drw_str)>0)
				{
					tc_strdup(item_drw_str,&item_drw_strDup);
				}
				else
				{
					tc_strdup(" ",&item_drw_strDup);
					printf("\n Final Drawing_No Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(revTag,"t5_DocRemarks",&item_mod_desc));
				if(tc_strlen(item_mod_desc)>0)
				{
					tc_strdup(item_mod_desc,&item_mod_descDup);
					trimwhitespace(item_mod_descDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", item_mod_descDup);fflush(stdout);
					STRNG_replace_str(item_mod_descDup,","," ",&item_mod_descDup);
					STRNG_replace_str(item_mod_descDup,";"," ",&item_mod_descDup);
					STRNG_replace_str(item_mod_descDup,"\n"," ",&item_mod_descDup);
					STRNG_replace_str(item_mod_descDup,"'"," ",&item_mod_descDup);
					printf("\n Item Description Final Value: [%s]", item_mod_descDup);fflush(stdout);
				}
				else
				{
					tc_strdup(" ",&item_mod_descDup);
					printf("\n Final Modification Description Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(revTag,"t5_ModuleName",&item_modname_str));
				if(tc_strlen(item_modname_str)>0)
				{
					tc_strdup(item_modname_str,&item_modname_strDup);
					STRNG_replace_str(item_modname_strDup,","," ",&item_modname_strDup);
					STRNG_replace_str(item_modname_strDup,";"," ",&item_modname_strDup);
					STRNG_replace_str(item_modname_strDup,"\n"," ",&item_modname_strDup);
					STRNG_replace_str(item_modname_strDup,"'"," ",&item_modname_strDup);
				}
				else
				{
					tc_strdup(" ",&item_modname_strDup);
					printf("\n Final Module_Name Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(revTag,"t5_DrawingInd",&item_drwind_str));
				if(tc_strlen(item_drwind_str)>0)
				{
					tc_strdup(item_drwind_str,&item_drwind_strDup);
				}
				else
				{
					tc_strdup(" ",&item_drwind_strDup);
					printf("\n Final Drawing Indicator Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(revTag,"t5_SurfPrtStd",&item_srfcstd_str));
				if(tc_strlen(item_srfcstd_str)>0)
				{
					tc_strdup(item_srfcstd_str,&item_srfcstd_strDup);
					trimwhitespace(item_srfcstd_strDup);
					printf("\n Item Surface Protection Std Value After Dup & Trim: [%s]", item_srfcstd_strDup);fflush(stdout);
					STRNG_replace_str(item_srfcstd_strDup,","," ",&item_srfcstd_strDup);
					STRNG_replace_str(item_srfcstd_strDup,";"," ",&item_srfcstd_strDup);
					STRNG_replace_str(item_srfcstd_strDup,"\n"," ",&item_srfcstd_strDup);
					STRNG_replace_str(item_srfcstd_strDup,"'"," ",&item_srfcstd_strDup);
					printf("\n Item Surface Protection Std Final Value: [%s]", item_srfcstd_strDup);fflush(stdout);
				}
				else
				{
					tc_strdup(" ",&item_srfcstd_strDup);
					printf("\n Final Surface Protection Std Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(revTag,"t5_Material",&item_mat_str));
				if(tc_strlen(item_mat_str)>0)
				{
					tc_strdup(item_mat_str,&item_mat_strDup);
					trimwhitespace(item_mat_strDup);
					printf("\n Item Part Material Value After Dup & Trim: [%s]", item_mat_strDup);fflush(stdout);
					STRNG_replace_str(item_mat_strDup,","," ",&item_mat_strDup);
					STRNG_replace_str(item_mat_strDup,";"," ",&item_mat_strDup);
					STRNG_replace_str(item_mat_strDup,"\n"," ",&item_mat_strDup);
					STRNG_replace_str(item_mat_strDup,"'"," ",&item_mat_strDup);
					printf("\n Item Part Material Final Value: [%s]", item_mat_strDup);fflush(stdout);
				}
				else
				{
					tc_strdup(" ",&item_mat_strDup);
					printf("\n Final Part Material Value is NULL..!!");fflush(stdout);
				}
				printf("\n  Part_No: [%s]\n",item_id_strDup);fflush(stdout);
				printf("\n  Part_Rev: [%s]\n",item_rev_strDup);fflush(stdout);
				printf("\n  Part_Seq: [%s]\n",item_seq_strDup);fflush(stdout);
				printf("\n  Part_Owner: [%s]\n",item_ownerDup);fflush(stdout);
				printf("\n  Drawing_No: [%s]\n",item_drw_strDup);fflush(stdout);
				printf("\n  Modification_Desc: [%s]\n",item_mod_descDup);fflush(stdout);
				printf("\n  Module_Name: [%s]\n",item_modname_strDup);fflush(stdout);
				printf("\n  Drawing_Indicator: [%s]\n",item_drwind_strDup);fflush(stdout);
				printf("\n  Surface_Protection_Std: [%s]\n",item_srfcstd_strDup);fflush(stdout);
				printf("\n  Part_Material: [%s]\n",item_mat_strDup);fflush(stdout);
				fprintf(OPRpt,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,item_ownerDup,item_drw_strDup,item_mod_descDup,item_modname_strDup,item_drwind_strDup,item_srfcstd_strDup,item_mat_strDup);fflush(OPRpt);		
			}			
		}
		else
		{
			printf(" Item Found Zero[0] on [Item Revision...] Query!!\n");fflush(stdout);
		}
	}
	else
	{
		printf(" [Item Revision...] Query Tag Not Found!!\n");fflush(stdout);
	}
	return iFail;
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport)
{
		char* cItem_Id = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;

		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
	
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			printf("\n Inner Function1: TC Part's All Revision's Metadata Find Start");fflush(stdout);
            TC_AllRevMetadata(cItem_Id,FP_OutputReport);
	        printf("\n Inner Function1: TC Part's All Revision's Metadata Find End\n");fflush(stdout);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\n-------------------------------------------------------------------------\n");
			
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				printf("\n!!!!!!!!!! I N N E R  C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			}
		}
		
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRev,char* VehicleSeq,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char *VehicleRS = (char *) malloc(20*sizeof(char));
	
	
	tc_strcpy(VehicleRS,VehicleRev);
	tc_strcat(VehicleRS,"*");
	tc_strcat(VehicleRS,VehicleSeq);
	printf(" Final: Part_Rev_Seq Value(VehicleRS): [%s]\n",VehicleRS);
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		//ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		ITK_CALL(CFM_find("Latest Working", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			printf("\n Inner Function1: TC Part's All Revision's Metadata Find Start");fflush(stdout);
            TC_AllRevMetadata(ctopSubItem_Id,VehRpt);
	        printf("\n Inner Function1: TC Part's All Revision's Metadata Find End\n");fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\n-------------------------------------------------------------------------\n");
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t revTag = NULLTAG;
	char *preitem_id_str   = NULL;
	char *preitem_id_strDup  = NULL;
	tag_t tNextItemobj = NULLTAG;
	int n_nextentries = 3;
	int n_nextitemobj_found = 0;
	tag_t* tnextitemobj_results = NULLTAG;
	int j = 0;
	tag_t nextrevTag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *item_drw_str = NULL;
	char *item_drw_strDup = NULL;
	char *inp_parttype_str = NULL;
	char *item_mod_desc = NULL;
	char *item_mod_descDup = NULL;
	char *item_modname_str = NULL;
	char *item_modname_strDup = NULL;
	char *item_drwind_str = NULL;
	char *item_drwind_strDup = NULL;
	char *item_srfcstd_str = NULL;
	char *item_srfcstd_strDup = NULL;
	char *item_mat_str = NULL;
	char *item_mat_strDup = NULL;
	char *inp_part_str = NULL;
	char *inp_rev_str = NULL;
	char *inp_seq_str = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
    inp_part_str = ITK_ask_cli_argument("-part=");
	inp_rev_str = ITK_ask_cli_argument("-rev=");
	inp_seq_str = ITK_ask_cli_argument("-seq=");
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Input Part_No: --------> [%s]",inp_part_str);fflush(stdout);
	printf("\n Input Part_Revision: --------> [%s]",inp_rev_str);fflush(stdout);
	printf("\n Input Part_Sequence: --------> [%s]",inp_seq_str);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Junk_Character_Report_For_");
	tc_strcat(RptFile,inp_part_str);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,inp_rev_str);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,inp_seq_str);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n CSV Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n CSV Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"PART_NO, REVISION, SEQUENCE, OWNER, DRAWING_NO, MODIFICATION_DESC, MODULE_NAME, DRAWING_INDICATOR, SURFACE_PROTECTION_STD, PART_MATERIAL\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create CSV Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	printf("\n Function1: TC Part's All Revision's Metadata Find Start");fflush(stdout);
    TC_AllRevMetadata(inp_part_str,fpOutput_file);
	printf("\n Function1: TC Part's All Revision's Metadata Find End\n");fflush(stdout);
	
	printf("\n Function2: Input Part & Revision & Sequence BOM's Metadata Find Start");fflush(stdout);
    TC_VehChild_Details(inp_part_str,inp_rev_str,inp_seq_str,fpOutput_file);
	printf("\n Function2: Input Part & Revision & Sequence BOM's Metadata Find End\n");fflush(stdout);
		
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_junk_character_report.c
* // ./linkitk -o tm_junk_character_report tm_junk_character_report.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Junk_Character_Report/tm_junk_character_report .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Junk_Character_Report/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Junk_Character_Report/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Junk_Character_Report/SendEmail.sh .
* // ./tm_junk_character_report -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -part="2829012083R"
* // ./tm_junk_character_report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -part="2829012083R"
*
***************************************************************************/
