/user/cvprod/sourav/ControlObject_Creation/tm_CntObj_Create -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
