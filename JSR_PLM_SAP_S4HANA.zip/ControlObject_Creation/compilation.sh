./compile tm_CntObj_Create.c
./linkitk -o tm_CntObj_Create tm_CntObj_Create.o
chmod 777 tm_CntObj_Create*
