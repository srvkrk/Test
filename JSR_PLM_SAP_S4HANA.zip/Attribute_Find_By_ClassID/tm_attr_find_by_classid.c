/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Find All Classified Object By Class ID & Print It's Attribute & Value
*  File Name    :   tm_attr_find_by_classid.c
*  Created on   :   Jan 7th 2026
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     07/01/2026                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	//char *retStringf;
	//retStringf = (char*) malloc(200);
	char *retStringf = (char *)MEM_alloc(100 * sizeof(char));
	
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* lastFiveChars(const char* str) {
    if (str == NULL) {
        return NULL;
    }

    size_t len = strlen(str);

    // If string length is less than or equal to 5, return a copy of the whole string
    if (len <= 5) {
        char* result = (char*)malloc(len + 1);
        if (result == NULL) {
            return NULL; // malloc failed
        }
        strcpy(result, str);
        return result;
    }

    // Allocate memory for last 5 characters + null terminator
    char* result = (char*)malloc(6);
    if (result == NULL) {
        return NULL; // malloc failed
    }

    strcpy(result, str + len - 5);
    return result;
}

static void describe_classification_view(char *class_name, char *view_name, FILE* RptHead)
{
    tag_t
        class_tag = NULLTAG,
        view_tag = NULLTAG;
		
    int 
        ii = 0,
        nAttributes = 0;

	int * 	theAttrIDs;
	int * 	formats;
	char ** 	theAttrAnnotations;
	char ** 	theAttrNames;
	char ** 	theAttrShortNames;
	char **	theAttrUnits;
	char **	theUserData1;
	//char ** 	configField;
	char ** 	theUserData2;
	int * 	theFlags ;
	int *	uncts;
	int * 	nonMetricFormats;
	char ** 	attributeIds;
	char ** 	attributeNames1;
	char ** 	shortNames;
	char ** 	units;
	char ** 	configBefore;
	char ** 	configField;
	char ** 	configAfter;
	int * 	flags;
	char **	metricMin;
	char ** 	metricMax;
	char ** 	nonMetricMin;
	char ** 	nonMetricMax;
	char **	metricDefaultValue;
	char **	nonMetricDefaultValue; 

    char 
        **attributeNames = NULL;
		
	char HeaderAttribute[2000] = "";   // Initialize empty string

    //ICS_init_module();
    ICS_find_class(class_name, &class_tag);
    ICS_find_view(class_tag, view_name, &view_tag);

    ITK_CALL(ICS_view_describe_view(class_tag,&nAttributes,&uncts,&formats,&nonMetricFormats,&attributeIds,&attributeNames,&shortNames,&units,&configBefore,&configField,&configAfter,&flags,&metricMin,&metricMax,&nonMetricMin,&nonMetricMax,&metricDefaultValue,&nonMetricDefaultValue));
    printf("\n nAttributes: [%d]\n", nAttributes);fflush(stdout);
	if(nAttributes > 0)
	{
		tc_strcat(HeaderAttribute, "Object~");
		for (ii = 0; ii < nAttributes; ii++)
		{       
			printf("    attributeId: %d\n", attributeIds[ii]);fflush(stdout);
			printf("    format: %d\n", formats[ii]);fflush(stdout);
			printf("    attributeName: %s\n", attributeNames[ii]);fflush(stdout);
			printf("    shortName: %s\n", shortNames[ii]);fflush(stdout);
			printf("    unit: %s\n", units[ii]);fflush(stdout);
			printf("    configBefore: %s\n", configBefore[ii]);fflush(stdout);
			printf("    configField: %s\n", configField[ii]);fflush(stdout);
			printf("    configAfter: %s\n", configAfter[ii]);fflush(stdout);
			printf("    flag: %d\n", flags[ii]);fflush(stdout);
			printf("\n");fflush(stdout);
			tc_strcat(HeaderAttribute, attributeNames[ii]);
			tc_strcat(HeaderAttribute, "~");
		}
		tc_strcat(HeaderAttribute, "#");
	}
	printf("\n Final Header: [%s]\n", HeaderAttribute);fflush(stdout);
	fprintf(RptHead,"%s\n",HeaderAttribute);fflush(RptHead);
    //ICS_exit_module();
    /* GTAC_free(attributeIds);
    GTAC_free(formats);
    GTAC_free(flags);
	GTAC_free(annotations);
    GTAC_free(attributeNames);
    GTAC_free(units);
    GTAC_free(configBefore);
    GTAC_free(configField); */
}

static void classification_details(tag_t PartMaster, char *ClassID, char *Objectno, FILE* RptData)
{
	int theAttributeCount = 0;
	int *theAttributeIds = 0;
	char **theAttributeNames;
	int *theAttributeValCounts = 0;
	char***       theAttributeValues;
	char***       theAttributeOptimizedUnits;
	char*   attrId = NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	tag_t IcsClsTag = NULLTAG;
	int attobj = 0;
	int cnt	= 0;
	tag_t *ClsObjTag_results = NULLTAG;
	/* tag_t objTypeTag = NULLTAG;
	char *Ptype_name = NULL;
	tag_t clstag = NULLTAG; */
	int cls	= 0;
	char* class_name = NULL;
	
	ITK_CALL(ICS_ask_classification_object(PartMaster,&IcsClsTag));
	ITK_CALL(AOM_ask_value_tags(PartMaster,"IMAN_classification",&cnt,&ClsObjTag_results));
	printf("\n !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"); fflush(stdout);
	printf("\n !!!!! Module Master Class Object Tag Count: [%d] !!!!!\n", cnt); fflush(stdout);
	if(cnt > 0)
	{
		for(cls = 0; cls < cnt; cls++)
		{
			tag_t objTypeTag = NULLTAG;
	        char *Ptype_name = NULL;
	        tag_t clstag = NULLTAG;
			char *ClsClass = NULL;
			clstag = ClsObjTag_results[cls];
			if(TCTYPE_ask_object_type(clstag,&objTypeTag));
			if(TCTYPE_ask_name2(objTypeTag,&Ptype_name));
			printf("\n [Ptype_name]: [%s]\n", Ptype_name);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(ClsObjTag_results[cls],"cid",&ClsClass));
		    printf("\n ClsClass:  [%s]",ClsClass);fflush(stdout);
			printf("\n !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"); fflush(stdout);
			if(tc_strcmp(ClsClass,ClassID)==0)
            {
				char *ClsAttrVal = NULL;
                ClsAttrVal = (char *) MEM_alloc( 1000 * sizeof(char) );
				int x = 0;
				ITK_CALL(ICS_ico_ask_attributes_optimized(ClsObjTag_results[cls],&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
				printf("\n theAttributeCount:  [%d]\n",theAttributeCount);fflush(stdout);
				if(theAttributeCount > 0)
				{
					tc_strcpy(ClsAttrVal,"");
					tc_strcat(ClsAttrVal,Objectno);
					tc_strcat(ClsAttrVal,"~");
					for(attobj = 0; attobj < theAttributeCount; attobj++)
					{
						sprintf(attrId,"%d",theAttributeIds[attobj]);	
						//tc_strcpy(ClsAttrVal,"");
						//tc_strcat(ClsAttrVal,Objectno);
						//tc_strcat(ClsAttrVal,"~");
						for(x=0; x<theAttributeValCounts[attobj]; x++)
						{
							tc_strcat(ClsAttrVal,theAttributeValues[attobj][x]);
						}
						tc_strcat(ClsAttrVal,"~");
						printf("\t Attribute Name: [%s] - Attribute ID: [%s]\n", theAttributeNames[attobj], attrId);
						MEM_free(theAttributeNames[attobj]);
						MEM_free(theAttributeValues[attobj]);
					}
					MEM_free(theAttributeNames);
					MEM_free(theAttributeValues);
					tc_strcat(ClsAttrVal,"#");
					fprintf(RptData,"%s\n",ClsAttrVal);fflush(RptData);
				}
			}
			else
			{
				printf("\n ~~~~ Module Master Class Name & Input Class ID not Matched ~~~~\n");fflush(stdout);
			}
		}
	}
	/* printf("\n !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"); fflush(stdout);
	ITK_CALL(ICS_ico_ask_attributes_optimized(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
	if(theAttributeCount > 0)
	{
		for(attobj = 0; attobj < theAttributeCount; attobj++)
		{
			sprintf(attrId,"%d",theAttributeIds[attobj]);
			printf("\t Attribute Name: [%s] - Attribute ID: [%s]\n", theAttributeNames[attobj], attrId);
			MEM_free(theAttributeNames[attobj]);
			MEM_free(theAttributeValues[attobj]);
		}
		MEM_free(theAttributeNames);
		MEM_free(theAttributeValues);
	} */
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* inpclassid = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int s = 0;
	tag_t VCRev_tag = NULLTAG;
	int z = 0;
	int ChldCount = 0;
    tag_t *PartChildTags = NULLTAG;
	tag_t Veh_tag = NULLTAG;
	char *vehno_str = NULL;
	char *vehno_strDup = NULL;
	tag_t vehtItemobj = NULLTAG;
	int vehn_entries = 2;
	int vehn_itemobj_found = 0;
	tag_t* vehtitemobj_results = NULLTAG;
	int y = 0;
	tag_t Rev_tag = NULLTAG;
	tag_t VehRev_tag = NULLTAG;
	int num_to_sort = 1;
	int sort_order[1] = {2}; //1 --> Ascending Order & 2 --> Descending Order
	char *keysAttr[1] =  {"creation_date"};
	char *partClrInd = NULL;
	tag_t* NonColPartTags =  NULLTAG;
	int Count = 0;
	int iFail = ITK_ok;
	tag_t VehMstrTag = NULLTAG;
	int cnt	= 0;
	tag_t* ClsObjTag_results = NULLTAG;
	tag_t IcsClsTag = NULLTAG;
	char* ModdAddress = NULL;
	char *QryModdAddress = (char *) malloc(10*sizeof(char));
	int i = 0;
	tag_t DesMaster_tag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *Classifications = NULL;
	char *Classified = NULL;
	char *Classifiedin = NULL;
	char *RptFile = (char *) malloc(100*sizeof(char));
	 
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inpclassid = ITK_ask_cli_argument("-i=");
	trimwhitespace(inpclassid);
	printf(" [1]: Input Class ID(inpclassid): [%s]\n",inpclassid);
	ModdAddress = lastFiveChars(inpclassid);
    if(ModdAddress != NULL) 
	{
        printf("Final: Module Address From Input Class ID: [%s]\n", ModdAddress);fflush(stdout);
    }
	tc_strcpy(QryModdAddress,"*");
	tc_strcat(QryModdAddress,ModdAddress);
	tc_strcat(QryModdAddress,"*");
	printf(" Final: Query Module Address(QryModdAddress): [%s]\n",QryModdAddress);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"/tmp/");
	tc_strcat(RptFile,inpclassid);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Name Generated..!!");fflush(stdout);
	FILE* fpOutput_file = fopen(RptFile, "w");
	
	printf("\n Function1--->[describe_classification_view] Call Start..!!\n");fflush(stdout);
	describe_classification_view(inpclassid,"defaultView",fpOutput_file);
	printf("\n Function1--->[describe_classification_view] Call End..!!\n");fflush(stdout);
	
	printf("\n Finding Query[Item...]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("Item...",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n Query[Item...] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Item ID","Type"};
		char *cValues[2]  = {QryModdAddress,"Design"};
		//char *cValues[2]  = {"*H2C01*","Design"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Object[Item...] Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				DesMaster_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
			    /* if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
					trimwhitespace(item_id_strDup);
				}
				else
			    {
					tc_strdup("--",&item_id_strDup);
					printf("\n Module Number Value is NULL..!!");fflush(stdout);
				} */
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i], "fnd0IcsClassNames", &Classifications));
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i], "ics_classified", &Classified));
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i], "ics_subclass_name", &Classifiedin));
				printf("    Module Number: [%s]\n", item_id_str);fflush(stdout);
				printf("    Classifications: [%s]\n", Classifications);fflush(stdout);
				printf("    Classified: [%s]\n", Classified);fflush(stdout);
				printf("    Classified in: [%s]\n", Classifiedin);fflush(stdout);
				if((tc_strstr(Classifications,inpclassid)!=NULL) && (tc_strcmp(Classified,"YES")==0))
                {
					printf("    Module is Classified & Classifiactions Matched with Input Class ID\n");fflush(stdout);
					printf("\n Function2--->[classification_details] Call Start..!!\n");fflush(stdout);
					classification_details(DesMaster_tag,inpclassid,item_id_str,fpOutput_file);
					printf("\n Function2--->[classification_details] Call End..!!\n");fflush(stdout);
					
				}
			}
		}
	}
	fclose(fpOutput_file);
	
	/* tag_t class;
	tag_t* theInstanceTags;
	int theCount = 0;
	char* objectId = NULL;
	char* theClassId = NULL;
	tag_t classificationInstance = NULLTAG;
	
	tag_t* theTags = NULLTAG;
	char
	   **theTypes = NULL,
	   **theCIDs = NULL,
	   **theNames = NULL,
	   *query = NULL;
	int 
	  *theInstancesCounts = NULL,
	  *theChildCounts = NULL,
	  *theViewCounts = NULL,
	  *theSubClassCounts = NULL;
	  
	query=(char *)MEM_alloc(30);
	snprintf(query, 30, "-600 = %s", "MCVMH2C01");
	ITK_CALL(ICS_class_search(query,0,&theCount,&theTags,&theTypes,&theCIDs,&theNames,&theInstancesCounts,&theChildCounts,&theViewCounts,&theSubClassCounts));
	printf("\n  No of Instance Found: [%d]\n",theCount);fflush(stdout); */
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_exit_module(TRUE);
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_attr_find_by_classid.c
* // ./linkitk -o tm_attr_find_by_classid tm_attr_find_by_classid.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Attribute_Find_By_ClassID/tm_attr_find_by_classid .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Attribute_Find_By_ClassID/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Attribute_Find_By_ClassID/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Attribute_Find_By_ClassID/SendEmail.sh .
* // ./tm_attr_find_by_classid -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -i=MCVMH2C01
* // ./tm_attr_find_by_classid -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=MCVMH2C01
*
***************************************************************************/