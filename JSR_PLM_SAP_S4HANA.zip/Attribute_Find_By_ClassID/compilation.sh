./compile tm_attr_find_by_classid.c
./linkitk -o tm_attr_find_by_classid tm_attr_find_by_classid.o
chmod 777 tm_attr_find_by_classid*
