$TC_ROOT/*Patch*/tcPatchExecutable tm_attr_find_by_classid
