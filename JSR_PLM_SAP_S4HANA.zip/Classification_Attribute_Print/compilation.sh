./compile tm_classification_attr_print.c
./linkitk -o tm_classification_attr_print tm_classification_attr_print.o
chmod 777 tm_classification_attr_print*
