$TC_ROOT/*Patch*/tcPatchExecutable tm_classification_attr_print
