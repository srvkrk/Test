##############################################  Service#9876
sftp PLMSAPCV@172.16.1.140:/to_TML/QA/S4HANA/Source <<EOF
mput epochjsr1psd1021.txt
exit
EOF
##############################################
