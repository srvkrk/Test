##############################################  760%7a1eRzJi%J
sftp PLMSAPCV@172.16.1.140:/to_TML/PRD/Source <<EOF
mput epochjsrpsd1106.txt
exit
EOF
##############################################
