##############################################  760%7a1eRzJi%J
sftp PLMSAPCV@172.16.1.140:/to_TML/DEV/S4HANA/Source <<EOF
mput epochjsrpsdua0228.txt
exit
EOF
##############################################
