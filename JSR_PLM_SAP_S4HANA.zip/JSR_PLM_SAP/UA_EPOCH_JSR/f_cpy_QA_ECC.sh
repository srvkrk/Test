##############################################  760%7a1eRzJi%J
sftp PLMSAPCV@172.16.1.140:/to_TML/QA/Source <<EOF
mput epochjsrpsd1015.txt
exit
EOF
##############################################
