######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : MARCH-2024
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'Material Loading Program Started...'
echo  "-----------------------------------------------------------------------------------------"
PrtList='DMLList.lst'

if [ ! -f $PrtList ]; then
        echo "DML List File Not Found"
        exit 1
fi

while read PartNumber; do
Total=$((Total+1))
echo "DML $Total : $PartNumber"
done < $PrtList

echo "Total Input DML : $Total"

line_no=1

date
for i in `cat DMLList.lst`
do
echo "------------------- Loading On Going For DML : $i ----------------------"
start_time=$(date)
echo "[$line_no/$Total] SOURAV: LOADING-START For DML : $PartNumber Start-Time: $start_time"
echo "EXE Calling Start....."
/user/cvprod/PLMSAP/liveXfr/AplDmlSapMatCreateUA -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=CVP -d=$i
echo "EXE Calling End......."
echo "NS Code EXE Calling Start....."
/user/cvprod/PLMSAP/liveXfr/AplDmlSapMatCreateUA_NSCODE -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -d=$i -s=CVP
echo "NS Code EXE Calling End......."
end_time=$(date)
echo "[$line_no/$Total] SOURAV: LOADING-END For DML : $PartNumber End-Time: $end_time"
line_no=$((line_no+1))
done
date
echo  "-----------------------------------------------------------------------------------------"
echo  'Material Loading Program Finished...'
echo  "-----------------------------------------------------------------------------------------"
