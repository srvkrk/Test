##############################################  760%7a1eRzJi%J
sftp PLMSAPCV@172.16.1.140:/to_TML/PRD/Source <<EOF
mput epochjsr1psd1031.txt
exit
EOF
##############################################
