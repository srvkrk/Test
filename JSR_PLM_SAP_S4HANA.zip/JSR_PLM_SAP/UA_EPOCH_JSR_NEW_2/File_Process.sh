######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : October-2025
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'Estimate-Sheet File Generation Program Started...'
echo  "-----------------------------------------------------------------------------------------"
PrtList='ESList.lst'

if [ ! -f $PrtList ]; then
        echo "Estimate-Sheet List File Not Found"
        exit 1
fi

while read PartNumber; do
Total=$((Total+1))
echo "EstimateSheet $Total : $PartNumber"
done < $PrtList

echo "Total Input ES : $Total"

line_no=1

date
for i in `cat ESList.lst`
do
echo "------------------- Loading On Going For ES: $i ----------------------"
start_time=$(date)
echo "[$line_no/$Total] SOURAV: LOADING-START For ES: $PartNumber Start-Time: $start_time"
echo "EXE Calling Start....."
/user/cvprod/sourav/JSR_PLM_SAP/UA_EPOCH_JSR_NEW_2/UAEpoch -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -b="CVBU JSR" -a=$i
echo "EXE Calling End......."
end_time=$(date)
echo "[$line_no/$Total] SOURAV: LOADING-END For ES: $PartNumber End-Time: $end_time"
line_no=$((line_no+1))
done
date
echo  "-----------------------------------------------------------------------------------------"
echo  'Estimate-Sheet File Generation Program Finished...'
echo  "-----------------------------------------------------------------------------------------"
