##############################################  760%7a1eRzJi%J
sftp PLMSAPCV@172.16.1.140:/to_TML/QA/S4HANA/Source <<EOF
mput epochjsr1psd1015.txt
exit
EOF
##############################################
