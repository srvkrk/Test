##############################################  760%7a1eRzJi%J
sftp PLMSAPCV@172.16.1.140:/to_TML/PRD/S4HANA/Source <<EOF
mput epochjsr7psd1101.txt
exit
EOF
##############################################
