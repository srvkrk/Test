######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : MARCH-2025
#
#######################################################################################

. /user/cvprod/.bash_profile

echo  "-----------------------------------------------------------------------------------------"
echo  'Material Sloc Update Program Started...'
echo  "-----------------------------------------------------------------------------------------"
echo -e "\nIn Shell Argument Print Started...."

echo "Part_Number: -----> "$1

echo "DML_Number: -----> "$2

echo -e "\nIn Shell Argument Print Ended...."
first="$(cut -d'_' -f1 <<<"$2")"
second="$(cut -d'_' -f2 <<<"$2")"
echo "First Part of DML: -----> "$first

echo "Second Part of DML: -----> "$second

final="${first}JP"
echo "Final DML Number For Sloc Update: -----> "$final

echo "Main DML_Number: -----> "$2

echo "EXE Calling Start....."
/user/cvprod/sourav/JSR_PLM_SAP/PLMSAPMANUAL/PartMatCreChangeUASloc -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -i=$1  -j=2001 -f=CH -c=$final -s=CVP
echo "EXE Calling End......."
echo "NS Code EXE Calling Start....."
/user/cvprod/PLMSAP/liveXfr/AplDmlSapMatCreateUA_NSCODE -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -d=$2 -s=CVP
echo "NS Code EXE Calling End......."

echo  "-----------------------------------------------------------------------------------------"
echo  'Material Sloc Update Program Finished...'
echo  "-----------------------------------------------------------------------------------------"
