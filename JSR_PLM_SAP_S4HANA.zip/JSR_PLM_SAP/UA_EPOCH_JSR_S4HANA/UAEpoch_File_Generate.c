/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : UAEpoch_File_Generate.c
* Created By                   : Sourav Karak
* Created On                   : 19-02-2026
* Description                  : Generate Final Estimate Sheet File From PLM For Data Download
*
* Modification History :
* S.No    Date          CR No        Modified By              Modification Notes
*
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define MAX_LINE 1024
#define INITIAL_SIZE 100
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

typedef struct {
    char col1[100];
    char col2[100];
    double col3;
    char fullLine[MAX_LINE];
} Record;

void processFile(const char *inputFile, const char *outputFile)
{
    FILE *fpIn = fopen(inputFile, "r");
    if (!fpIn) 
	{
        printf("Cannot open input file\n");
        return;
    }

    FILE *fpOut = fopen(outputFile, "w");
    if (!fpOut) 
	{
        printf("Cannot open output file\n");
        fclose(fpIn);
        return;
    }

    Record *records = malloc(INITIAL_SIZE * sizeof(Record));
    int capacity = INITIAL_SIZE;
    int count = 0;

    char line[MAX_LINE];

    while (fgets(line, sizeof(line), fpIn)) {

        char originalLine[MAX_LINE];
        strcpy(originalLine, line);  // Preserve full line

        char tempCol1[100] = {0};
        char tempCol2[100] = {0};
        char tempCol3[100] = {0};

        char *token;
        int columnIndex = 0;

        token = strtok(line, "^");
        while (token != NULL) 
		{
            if (columnIndex == 0)
                strcpy(tempCol1, token);
            else if (columnIndex == 1)
                strcpy(tempCol2, token);
            else if (columnIndex == 2)
                strcpy(tempCol3, token);

            columnIndex++;
            token = strtok(NULL, "^");
        }

        double value3 = atof(tempCol3);

        int found = -1;

        for (int i = 0; i < count; i++) 
		{
            if (strcmp(records[i].col1, tempCol1) == 0 &&
                strcmp(records[i].col2, tempCol2) == 0) {
                found = i;
                break;
            }
        }

        if (found != -1) 
		{
            // Keep highest column3
            if (value3 > records[found].col3) {
                records[found].col3 = value3;
                strcpy(records[found].fullLine, originalLine);
            }
        } 
		else 
		{
            if (count == capacity) {
                capacity *= 2;
                records = realloc(records, capacity * sizeof(Record));
            }

            strcpy(records[count].col1, tempCol1);
            strcpy(records[count].col2, tempCol2);
            records[count].col3 = value3;
            strcpy(records[count].fullLine, originalLine);
            count++;
        }
    }

    // Write final output
    for (int i = 0; i < count; i++) {
        fputs(records[i].fullLine, fpOut);
    }

    free(records);
    fclose(fpIn);
    fclose(fpOut);
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *inpfile = NULL;
	char *outfile = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inpfile = ITK_ask_cli_argument("-i=");
	outfile = ITK_ask_cli_argument("-o=");
	printf(" [1]: Input File Name(inpfile): [%s]\n",inpfile);
	printf(" [2]: Output File Name(outfile): [%s]\n",outfile);
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Function(processFile) Call Started...");fflush(stdout);
	processFile(inpfile,outfile);
	printf("\n Function(processFile) Call Ended...");fflush(stdout);
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}












	
 
	






	
