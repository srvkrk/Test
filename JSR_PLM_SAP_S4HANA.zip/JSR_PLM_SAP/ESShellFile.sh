#!/bin/bash

# Current time in HHMM (24-hour format)
now=$(date +"%H%M")

# Date pieces
today_ymd=$(date +"%Y-%m-%d")
today_suffix=$(date +"%m%d")
yesterday_ymd=$(date -d "yesterday" +"%Y-%m-%d")
tomorrow_ymd=$(date -d "tomorrow" +"%Y-%m-%d")

# Output format (e.g., 26-Apr-2026 19:00)
fmt="%d-%b-%Y %H:%M"

# Initialize
suffix=""
intime=""
outtime=""

# -------- Time slot logic --------

# Slot 0: 7:00 PM → next day 10:00 AM (crosses midnight)
if [[ $now -ge 1900 || $now -lt 1001 ]]; then
    suffix="0${today_suffix}"

    if [[ $now -ge 1900 ]]; then
        # same day evening → next day morning
        intime=$(date +"$fmt" -d "$today_ymd 19:00")
        outtime=$(date +"$fmt" -d "$tomorrow_ymd 10:00")
    else
        # after midnight → belongs to previous day's slot
        intime=$(date +"$fmt" -d "$yesterday_ymd 19:00")
        outtime=$(date +"$fmt" -d "$today_ymd 10:00")
    fi

# Slot 1: 10:00 AM → 12:00 PM
elif [[ $now -ge 1000 && $now -lt 1201 ]]; then
    suffix="1${today_suffix}"
    intime=$(date +"$fmt" -d "$today_ymd 10:00")
    outtime=$(date +"$fmt" -d "$today_ymd 12:00")

# Slot 2: 12:00 PM → 03:00 PM
elif [[ $now -ge 1200 && $now -lt 1501 ]]; then
    suffix="2${today_suffix}"
    intime=$(date +"$fmt" -d "$today_ymd 12:00")
    outtime=$(date +"$fmt" -d "$today_ymd 15:00")

# Slot 3: 03:00 PM → 05:00 PM
elif [[ $now -ge 1500 && $now -lt 1701 ]]; then
    suffix="3${today_suffix}"
    intime=$(date +"$fmt" -d "$today_ymd 15:00")
    outtime=$(date +"$fmt" -d "$today_ymd 17:00")

# Slot 4: 05:00 PM → 07:00 PM
elif [[ $now -ge 1700 && $now -lt 1901 ]]; then
    suffix="4${today_suffix}"
    intime=$(date +"$fmt" -d "$today_ymd 17:00")
    outtime=$(date +"$fmt" -d "$today_ymd 19:00")
fi

# -------- File names --------
file1="inputepochjsr${suffix}.txt"
file2="outputepochjsr${suffix}.txt"
file3="epochjsr${suffix}.txt"

# -------- Output --------
echo "file1=$file1"
echo "file2=$file2"
echo "file3=$file3"
echo "intime=$intime"
echo "outtime=$outtime"