./compile tm_CompleteMCCLibraryRpt.c
./linkitk -o tm_CompleteMCCLibraryRpt tm_CompleteMCCLibraryRpt.o
chmod 777 tm_CompleteMCCLibraryRpt*
