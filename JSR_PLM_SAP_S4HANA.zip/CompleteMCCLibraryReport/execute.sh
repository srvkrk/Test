/user/cvprod/sourav/CompleteMCCLibraryReport/tm_CompleteMCCLibraryRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
