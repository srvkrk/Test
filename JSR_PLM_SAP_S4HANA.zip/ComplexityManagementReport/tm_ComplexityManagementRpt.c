/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   POM
*  Description  :   Generate Complexity Management Data From TCUA - CV 
*  File Name    :   tm_ComplexityManagementRpt.c
*  Created on   :   Jun 17th, 2025
*  Usage        :   tm_ComplexityManagementRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     17/06/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ValidateString (char *B)
{
    int i;
    for (i = 0; B[i] != '\0'; i++)
    {
        if (!(B[i] >= 65 && B[i] <= 90) && !(B[i] >= 97 && B[i] <= 122) && !(B[i] >= 44 && B[i] <= 57) && !(B[i] >31 && B[i] <= 32))
        {
            return 0;
        }
    }
       return 1;
}

char* TC_Vendor_Details(char* RefPartNo)
{
        trimwhitespace(RefPartNo);
        tag_t tpQryobj = NULLTAG;
        int np_entries = 2;
        int np_Qryobj_found = 0;
        tag_t* tpQryobj_results = NULLTAG;
        char* cItem_id = NULL;
        char* cItem_idDup = NULL;
        char* cItem_name = NULL;
        char* cItem_nameDup = NULL;
        tag_t DesRev_tag = NULLTAG;
        char *Item_revseq = NULL;
        int y = 0;
        //char *VList = (char *) malloc(200*sizeof(char));
		char *VList = NULL;
	    VList = (char *) MEM_alloc( 500 * sizeof(char) );
        printf("\n Reference Part Number Value: [%s]\n", RefPartNo);fflush(stdout);
        ITK_CALL(QRY_find2("General...",&tpQryobj));
        if(tpQryobj!=NULLTAG)
        {
			printf("\n [General...] Query Found Successfully...\n");fflush(stdout);
			char *PartEntries[2]  = {"Name","Type"};
			char *PartValues[2]  = {RefPartNo,"Vendor Part"};
			ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(np_Qryobj_found > 0)
			{
				printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
				for (y = 0; y < np_Qryobj_found; y++)
				{
					tag_t rev_tags_found = NULLTAG;
					rev_tags_found = tpQryobj_results[y];
					if(rev_tags_found != NULLTAG)
					{
						ITK_CALL(AOM_UIF_ask_value(tpQryobj_results[y],"vendor_id",&cItem_id));
						if(tc_strlen(cItem_id)>0)
						{
							tc_strdup(cItem_id,&cItem_idDup);
						}
						else
						{
							tc_strdup("",&cItem_idDup);
							printf("\n Vendor ID Value is NULL");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(tpQryobj_results[y],"vendor_name",&cItem_name));
						if(tc_strlen(cItem_name)>0)
						{
							tc_strdup(cItem_name,&cItem_nameDup);
						}
						else
						{
							tc_strdup("",&cItem_nameDup);
							printf("\n Vendor Name Value is NULL");fflush(stdout);
						}
						tc_strcpy(VList,"");
						tc_strcat(VList,cItem_idDup);
						tc_strcat(VList,"@");
						tc_strcat(VList,cItem_nameDup);
						printf("\n Vendor Details Final Value: [%s]", VList);fflush(stdout);
					}
					else
					{
						tc_strcpy(VList,"");
						printf("\nSorry! Vendor Part Revision Tag Not Found...");fflush(stdout);
					}
				}
			}
			else
			{
				tc_strcpy(VList,"");
				printf("\nSorry! Entered Vendor Part Revision Not Found...");fflush(stdout);
			}

        }
        else
        {
			tc_strcpy(VList,"");
			printf("\nSorry! [Genearal...] Query Tag Not Found...");fflush(stdout);
        }

    return VList;
}

char* TC_PlantCS(char* PNum, char* PRev, char* PSeq, char* PlntCSName)
{
	tag_t tCSItemobj = NULLTAG;
	int n_csentries = 2;
	int n_csitemobj_found = 0;
	tag_t* tcsitemobj_results = NULLTAG;
	int t = 0;
	char *RlzStatusName = NULL;
	char *CSVal = NULL;
	char *CSValDup = NULL;
	tag_t CSRev_tag = NULLTAG;
	//char *PRevSeq = (char *) malloc(50*sizeof(char));
	char *PRevSeq = NULL;
	PRevSeq = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(PRevSeq,PRev);
	tc_strcat(PRevSeq,"*");
	tc_strcat(PRevSeq,PSeq);
	printf("\n Part Rev&Seq(PRevSeq): [%s]\n",PRevSeq);
	
	ITK_CALL(QRY_find2("DesignRevision Sequence",&tCSItemobj));
	if(tCSItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
		char *cCSEntries[2]  = {"Revision","ID"};
		char *cCSValues[2]  = {PRevSeq,PNum};
		//char *cCSValues[2]  = {"A;2","5137D1D0270001_WE"};
		ITK_CALL(QRY_execute(tCSItemobj, n_csentries, cCSEntries, cCSValues, &n_csitemobj_found, &tcsitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_csitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_csitemobj_found > 0)
		{
			printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
			for (t = 0; t < n_csitemobj_found; t++)
			{
				CSRev_tag = tcsitemobj_results[t];
				ITK_CALL(AOM_ask_value_string(tcsitemobj_results[t],PlntCSName,&CSVal));
				if(tc_strlen(CSVal)>0)
				{
					tc_strdup(CSVal,&CSValDup);
				}
				else
				{
					tc_strdup("-",&CSValDup);
					printf("\n CS Value is NULL..!!");fflush(stdout);
				}
			}
		}
	}
	if(tc_strlen(CSVal)>0)
	{
	   tc_strdup(CSVal,&CSValDup);
	}
	else
	{
	   tc_strdup("-",&CSValDup);
	}
	return CSValDup;
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSeqSrch)
{
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision PartType",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision PartType Query Found Successfully..!!\n");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[n];
				if(LC_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpLCQryobj_results[n],"release_status_list",&sRelStatus);
					printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						tc_strdup("-",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL..!!\n");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
					printf("\n Item Release Status After Dup & Trim: [%s]\n", sRelStatusDup);fflush(stdout);
					STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
					printf("\n Item Release Status Final Value: [%s]\n", sRelStatusDup);fflush(stdout);
				}
				else
				{
					tc_strdup("-",&sRelStatusDup);
					printf("\nSorry! Revision Tag Not Found...\n");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("-",&sRelStatusDup);
			printf("\nSorry! Entered Revision Not Found...\n");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("-",&sRelStatusDup);
		printf("\nSorry! DesignRevision PartType Query Tag Not Found...\n");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	//char *RptFile1 = (char *) malloc(5000*sizeof(char));
	char *RptFile1 = NULL;
	RptFile1 = (char *) MEM_alloc( 2000 * sizeof(char) );
	//FILE *fpOutput_file = NULL;
	FILE *fpOutput_file1 = NULL;
	char *Part_No = NULL;
	char *Part_RevSeq = NULL;
	char *Part_RevSeqDup = NULL;
	char *Part_Rev = NULL;
	char *Part_Seq = NULL;
	char *Part_Type = NULL;
	char *Part_TypeDup = NULL;
	//char *Input_File = (char *) malloc(400*sizeof(char));
	int z=0;
	tag_t iteamrev2 = NULLTAG;
	double Weight;
	char *Env_Dim = NULL;
	char *Env_DimDup = NULL;
	//char *Mat_Clas = NULL;
	//char *Mat_ClasDup = NULL;
	char *Spare_Ctr = NULL;
	char *Spare_CtrDup = NULL;
	char *MatDrw = NULL;
	char *MatDrwDup = NULL;
	tag_t PartMasterTag	= NULLTAG;
	//char *MstrUnitTag = NULL;
	//char *MstrUnitTagDup = NULL;
	//char *MstrUnitVal = NULL;
	//char *MstrUnitValDup = NULL;
	char *RevUnitVal = NULL;
	char *RevUnitValDup = NULL;
	char *Part_DrwInd = NULL;
	char *Part_DrwIndDup = NULL;
	char *Part_DrwNo = NULL;
	char *Part_DrwNoDup = NULL;	
	char *Item_Desc = NULL;
	char *Item_DescDup = NULL;
	char *DesGrp = NULL;
	char *DesGrpDup = NULL;
	char *AHDCS = NULL;
	char *DWDCS = NULL;
	char *JSRCS = NULL;
	char *LKNCS = NULL;
	char *PUNCS = NULL;
	char *SNDCS = NULL;
	char *PNRCS = NULL;
	char *CARCS = NULL;
	char *Owner = NULL;
	char *OwnerDup = NULL;
	char *Mod_Addr = NULL;
	char *Mod_AddrDup = NULL;
	char *AggrGrp = NULL;
	char *AggrGrpDup = NULL;
	char *Aggr = NULL;
	char *AggrDup = NULL;
	char *ModGrp = NULL;
	char *ModGrpDup = NULL;
	char *Mod = NULL;
	char *ModDup = NULL;
	char *vendor_details = NULL;
    char *vendor_id = NULL;
    char *vendor_name = NULL;
	char *item_partypart = NULL;
	char *item_partypartDup = NULL;
	char *Color_Ind = NULL;
	char *Color_IndDup = NULL;
	char *Coated = NULL;
	char *CoatedDup = NULL;
	char *Item_RevSeq = NULL;
    //Item_RevSeq = (char *) malloc(20*sizeof(char));
	Item_RevSeq = (char *) MEM_alloc( 20 * sizeof(char) );
    char *Item_LCDetails = NULL;
	char *Thick = NULL;
	char *ThickDup = NULL;
	char *SpInd = NULL;
	char *SpIndDup = NULL;
	char *ArDr = NULL;
	char *ArDrDup = NULL;
	char *ProjCode = NULL;
	char *ProjCodeDup = NULL;
	char *CabinAppl = NULL;
	char *CabinApplDup = NULL;
	double SrfcArea;
	

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char *start_limit = NULL;
	char *end_limit = NULL;
	start_limit = ITK_ask_cli_argument("-s=");
	end_limit = ITK_ask_cli_argument("-e=");
	trimwhitespace(start_limit);
	trimwhitespace(end_limit);
	printf(" [1]: Input Starting(start_limit): [%s]\n",start_limit);fflush(stdout);
	printf(" [2]: Input Ending(end_limit): [%s]\n",end_limit);fflush(stdout);
	
	int strtl = 0;
	int endl = 0;
	if (start_limit != NULL)
	{
		strtl = atoi(start_limit);
	}
	if (end_limit != NULL)
	{
		endl = atoi(end_limit);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile1,"TCUA_ComplexityManagement_");
	tc_strcat(RptFile1,"From");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,start_limit);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,"To");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,end_limit);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,GenDate);
	tc_strcat(RptFile1,".csv");
	printf("\n CSV Report File Name: [%s]", RptFile1);fflush(stdout);
	printf("\n CSV Report File Generated..!!");fflush(stdout);
	
	fpOutput_file1 = fopen(RptFile1, "w");
	fprintf(fpOutput_file1,"PART_NO, DESCRIPTION, PART_REV, PART_SEQ, DRAWING_IND, DRAWING_NO, UOM, AHD_CS, DWD_CS, JSR_CS, LKN_CS, PUN_CS, SND_CS, PNR_CS, CAR_CS, DESG_GROUP, OWNER, PART_TYPE, MOD_ADDRESS, AGGR_GRP, AGGR, MOD_GRP, MOD, VENDOR_ID, VENDOR_NAME, COL_IND, COATED, WEIGHT, THICKNESS, MAT_DRW, SPR_IND, PART_CAT, DR/AR, PROJECT_CODE, RELEASE_STATUS, CABIN_KIT_APPL, ENV_DIM, SURFACE_AREA\n");fflush(fpOutput_file1); 
	int objtyplen = 1;
	int rlztyplen = 3;
	//int ownUsrlen = 1;
	const char* object_type_data[]={"Design Revision"};
	const char* fnd_lat_ERCRlz_lst=NULL;
	//const char* select_attrs[]={"item_id","item_revision_id","creation_date","last_mod_date","puid"};
	const char* select_attrs[]={"puid","item_revision_id"};
	const char *select_attrs_Item[] = { "item_id" };
	//const char* release_status_data[]={"T5_LcsErcRlzd"};
	const char* release_status_data[]={"T5_LcsWorking","T5_LcsReview","T5_LcsErcRlzd"};
	//const char* owning_user_data[]={"loader"};
	int  rows = 0, columns = 0;
	void ***report;
	char *pQry = "fnd_lat_ERCRlz_lst";
	ITK_CALL(POM_enquiry_create(pQry));
	ITK_CALL(POM_enquiry_add_select_attrs (pQry,"ItemRevision",1,select_attrs));
	ITK_CALL(POM_enquiry_add_select_attrs(pQry, "Item", 1,select_attrs_Item));
 
	ITK_CALL(POM_enquiry_set_string_value (pQry,"object_type_expr",objtyplen,object_type_data,POM_enquiry_bind_value));
	ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_object_type_in","ItemRevision","object_type",POM_enquiry_in,"object_type_expr"));
 
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr2","ItemRevision", "release_status_list", POM_enquiry_equal, "ReleaseStatus", "puid"));
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr3","ItemRevision", "owning_user", POM_enquiry_equal, "User", "puid"));
 
	ITK_CALL(POM_enquiry_set_string_value (pQry,"release_stat_expr",rlztyplen,release_status_data,POM_enquiry_bind_value));
	ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_rlz_stat_in","ReleaseStatus","name",POM_enquiry_in,"release_stat_expr"));
 
	//ITK_CALL(POM_enquiry_set_string_value (pQry,"own_user_expr",ownUsrlen,owning_user_data,POM_enquiry_bind_value));
	//ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_own_user_in","User","user_id",POM_enquiry_in,"own_user_expr"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr","join_expr1", POM_enquiry_and, "join_expr2"));
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr1","combine_expr",POM_enquiry_and,"expr_object_type_in"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr2","combine_expr1",POM_enquiry_and,"join_expr3"));
	//ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr3","combine_expr2",POM_enquiry_and,"expr_own_user_in"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"expr_AND_expression","combine_expr2",POM_enquiry_and,"expr_rlz_stat_in"));
	ITK_CALL(POM_enquiry_set_where_expr (pQry,"expr_AND_expression"));
 
	ITK_CALL(POM_enquiry_add_order_attr (pQry, "Item", "item_id", POM_enquiry_asc_order));
 
	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_execute(pQry, &rows, &columns, &report));
	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_delete(pQry));
	printf(" \n Number of Rows [%d] and Number of Coloumns [%d]\n",rows,columns);fflush(stdout);
	if (endl > rows)
	{
		endl = rows;
	}
	if(rows > 0 && strtl < rows)
	{
		for(z=strtl;z < endl; z++)
		{
			//iteamrev2 = titemobj_results[z];
			iteamrev2 = *(tag_t*)(report[z][0]);
			ITK_CALL(AOM_ask_value_string(iteamrev2,"item_id",&Part_No));
			printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \n");fflush(stdout);
			printf("\n Part No:  <%s> \n",Part_No);fflush(stdout);
			if(Part_No!=NULL)
			{
				ITK_CALL(AOM_ask_value_string(iteamrev2,"item_revision_id",&Part_RevSeq));
				if(tc_strlen(Part_RevSeq)>0)
				{
					tc_strdup(Part_RevSeq,&Part_RevSeqDup);
				}
				Part_Rev=strtok(Part_RevSeqDup,";");
				Part_Seq=strtok(NULL,";");
				printf("\n Part Rev:  <%s> \n",Part_Rev);fflush(stdout);
				printf("\n Part Seq:  <%s> \n",Part_Seq);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"object_desc",&Item_Desc));
				printf("\n Item Description Before Dup & Trim:  <%s> \n",Item_Desc);fflush(stdout);
				if(tc_strlen(Item_Desc)>0)
				{
					tc_strdup(Item_Desc,&Item_DescDup);
					trimwhitespace(Item_DescDup);
				}
				else
				{
					tc_strdup("-",&Item_DescDup);
					printf("\n Item Description Value is NULL");fflush(stdout);
				}
				printf("\n Item Description Value After Dup & Trim: [%s]", Item_DescDup);fflush(stdout);
				STRNG_replace_str(Item_DescDup,","," ",&Item_DescDup);
				STRNG_replace_str(Item_DescDup,";"," ",&Item_DescDup);
				STRNG_replace_str(Item_DescDup,"\n"," ",&Item_DescDup);
				STRNG_replace_str(Item_DescDup,"'"," ",&Item_DescDup);
				STRNG_replace_str(Item_DescDup,"&"," ",&Item_DescDup);
				STRNG_replace_str(Item_DescDup,"<"," ",&Item_DescDup);
				STRNG_replace_str(Item_DescDup,">"," ",&Item_DescDup);
				printf("\n Item Description Final Value: [%s]", Item_DescDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_DrawingInd",&Part_DrwInd));
				if(tc_strlen(Part_DrwInd)>0)
				{
					tc_strdup(Part_DrwInd,&Part_DrwIndDup);
				}
				else
				{
					tc_strdup("-",&Part_DrwIndDup);
					printf("\n Part Drawing Indicator Value is NULL..!!\n");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_DrawingNo",&Part_DrwNo));
				if(tc_strlen(Part_DrwNo)>0)
				{
					tc_strdup(Part_DrwNo,&Part_DrwNoDup);
				}
				else
				{
					tc_strdup("-",&Part_DrwNoDup);
					printf("\n Part Drawing Number Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_uom",&RevUnitVal));
				if(tc_strlen(RevUnitVal)>0)
				{
					tc_strdup(RevUnitVal,&RevUnitValDup);
				}
				else
				{
					tc_strdup("-",&RevUnitValDup);
					printf("\n Revision Unit of Measure Value[t5_uom] is NULL..!!\n");fflush(stdout);
				}
				
				AHDCS = TC_PlantCS(Part_No,Part_Rev,Part_Seq,"t5_AhdMakeBuyIndicator");
				DWDCS = TC_PlantCS(Part_No,Part_Rev,Part_Seq,"t5_DwdMakeBuyIndicator");
				JSRCS = TC_PlantCS(Part_No,Part_Rev,Part_Seq,"t5_JsrMakeBuyIndicator");
				LKNCS = TC_PlantCS(Part_No,Part_Rev,Part_Seq,"t5_LkoMakeBuyIndicator");
				PUNCS = TC_PlantCS(Part_No,Part_Rev,Part_Seq,"t5_PunMakeBuyIndicator");
				SNDCS = TC_PlantCS(Part_No,Part_Rev,Part_Seq,"t5_SndMakeBuyIndicator");
				PNRCS = TC_PlantCS(Part_No,Part_Rev,Part_Seq,"t5_PnrMakeBuyIndicator");
				CARCS = TC_PlantCS(Part_No,Part_Rev,Part_Seq,"t5_CarMakeBuyIndicator");
				
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_DesignGrp",&DesGrp));
				if(tc_strlen(DesGrp)>0)
				{
					tc_strdup(DesGrp,&DesGrpDup);
				}
				else
				{
					tc_strdup("-",&DesGrpDup);
					printf("\n Revision Design Group Value[t5_DesignGrp] is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"owning_user",&Owner));
				if(tc_strlen(Owner)>0)
				{
					tc_strdup(Owner,&OwnerDup);
				}
				else
				{
					tc_strdup("-",&OwnerDup);
					printf("\n Revision Owner Value[owning_user] is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PartType",&Part_Type));
				if(tc_strlen(Part_Type)>0)
				{
					tc_strdup(Part_Type,&Part_TypeDup);
				}
				else
				{
					tc_strdup("-",&Part_TypeDup);
					printf("\n Part Type Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_ModuleAddress",&Mod_Addr));
				if(tc_strlen(Mod_Addr)>0)
				{
					tc_strdup(Mod_Addr,&Mod_AddrDup);
				}
				else
				{
					tc_strdup("-",&Mod_AddrDup);
					printf("\n Part Module Address Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_AggregateGroup",&AggrGrp));
				printf("\n Aggregate Group Before Dup & Trim:  <%s> \n",AggrGrp);fflush(stdout);
				if(tc_strlen(AggrGrp)>0)
				{
					tc_strdup(AggrGrp,&AggrGrpDup);
					trimwhitespace(AggrGrpDup);
				}
				else
				{
					tc_strdup("-",&AggrGrpDup);
					printf("\n Item Aggregate Group Value is NULL");fflush(stdout);
				}
				printf("\n Aggregate Group Value After Dup & Trim: [%s]", AggrGrpDup);fflush(stdout);
				STRNG_replace_str(AggrGrpDup,","," ",&AggrGrpDup);
				STRNG_replace_str(AggrGrpDup,";"," ",&AggrGrpDup);
				STRNG_replace_str(AggrGrpDup,"\n"," ",&AggrGrpDup);
				STRNG_replace_str(AggrGrpDup,"'"," ",&AggrGrpDup);
				STRNG_replace_str(AggrGrpDup,"&","&amp;",&AggrGrpDup);
				STRNG_replace_str(AggrGrpDup,"<","&lt;",&AggrGrpDup);
				STRNG_replace_str(AggrGrpDup,">","&gt;",&AggrGrpDup);
				printf("\n Aggregate Group Final Value: [%s]", AggrGrpDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_Aggregate",&Aggr));
				printf("\n Aggregate Before Dup & Trim:  <%s> \n",Aggr);fflush(stdout);
				if(tc_strlen(Aggr)>0)
				{
					tc_strdup(Aggr,&AggrDup);
					trimwhitespace(AggrDup);
				}
				else
				{
					tc_strdup("-",&AggrDup);
					printf("\n Aggregate Value is NULL");fflush(stdout);
				}
				printf("\n Aggregate Value After Dup & Trim: [%s]", AggrDup);fflush(stdout);
				STRNG_replace_str(AggrDup,","," ",&AggrDup);
				STRNG_replace_str(AggrDup,";"," ",&AggrDup);
				STRNG_replace_str(AggrDup,"\n"," ",&AggrDup);
				STRNG_replace_str(AggrDup,"'"," ",&AggrDup);
				STRNG_replace_str(AggrDup,"&","&amp;",&AggrDup);
				STRNG_replace_str(AggrDup,"<","&lt;",&AggrDup);
				STRNG_replace_str(AggrDup,">","&gt;",&AggrDup);
				printf("\n Aggregate Final Value: [%s]", AggrDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_Module_Group",&ModGrp));
				printf("\n Module Group Before Dup & Trim:  <%s> \n",ModGrp);fflush(stdout);
				if(tc_strlen(ModGrp)>0)
				{
					tc_strdup(ModGrp,&ModGrpDup);
					trimwhitespace(ModGrpDup);
				}
				else
				{
					tc_strdup("-",&ModGrpDup);
					printf("\n Module Group Value is NULL");fflush(stdout);
				}
				printf("\n Module Group Value After Dup & Trim: [%s]", ModGrpDup);fflush(stdout);
				STRNG_replace_str(ModGrpDup,","," ",&ModGrpDup);
				STRNG_replace_str(ModGrpDup,";"," ",&ModGrpDup);
				STRNG_replace_str(ModGrpDup,"\n"," ",&ModGrpDup);
				STRNG_replace_str(ModGrpDup,"'"," ",&ModGrpDup);
				STRNG_replace_str(ModGrpDup,"&"," ",&ModGrpDup);
				STRNG_replace_str(ModGrpDup,"<"," ",&ModGrpDup);
				STRNG_replace_str(ModGrpDup,">"," ",&ModGrpDup);
				printf("\n Module Group Final Value: [%s]", ModGrpDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_Module",&Mod));
				printf("\n Module Value Before Dup & Trim:  <%s> \n",Mod);fflush(stdout);
				if(tc_strlen(Mod)>0)
				{
					tc_strdup(Mod,&ModDup);
					trimwhitespace(ModDup);
				}
				else
				{
					tc_strdup("-",&ModDup);
					printf("\n Module Value is NULL");fflush(stdout);
				}
				printf("\n Module Value After Dup & Trim: [%s]", ModDup);fflush(stdout);
				STRNG_replace_str(ModDup,","," ",&ModDup);
				STRNG_replace_str(ModDup,";"," ",&ModDup);
				STRNG_replace_str(ModDup,"\n"," ",&ModDup);
				STRNG_replace_str(ModDup,"'"," ",&ModDup);
				STRNG_replace_str(ModDup,"&","&amp;",&ModDup);
				STRNG_replace_str(ModDup,"<","&lt;",&ModDup);
				STRNG_replace_str(ModDup,">","&gt;",&ModDup);
				printf("\n Module Final Value: [%s]", ModDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_RefPartNumber",&item_partypart));
				if(tc_strlen(item_partypart)>0)
				{
					tc_strdup(item_partypart,&item_partypartDup);
					trimwhitespace(item_partypartDup);
					printf("\n Function: Vendor Details Find Start..!!\n");fflush(stdout);
					vendor_details = TC_Vendor_Details(item_partypartDup);
					printf("\n Vendor Detais Before Tok: [%s]", vendor_details);fflush(stdout);
					printf("\n Function: Vendor Details Find End..!!\n");fflush(stdout);
					vendor_id=strtok(vendor_details,"@");
					vendor_name=strtok(NULL,"@");
					printf("\n Vendor ID Value After Token: [%s]\n", vendor_id);fflush(stdout);
					printf("\n Vendor Name Value After Token: [%s]\n", vendor_name);fflush(stdout);
					STRNG_replace_str(vendor_id,","," ",&vendor_id);
					STRNG_replace_str(vendor_id,";"," ",&vendor_id);
					STRNG_replace_str(vendor_id,"\n"," ",&vendor_id);
					STRNG_replace_str(vendor_id,"'"," ",&vendor_id);
					STRNG_replace_str(vendor_name,","," ",&vendor_name);
					STRNG_replace_str(vendor_name,";"," ",&vendor_name);
					STRNG_replace_str(vendor_name,"\n"," ",&vendor_name);
					STRNG_replace_str(vendor_name,"'"," ",&vendor_name);

				}
				else
				{
					tc_strdup("-",&item_partypartDup);
					tc_strdup("-",&vendor_id);
					tc_strdup("-",&vendor_name);
					printf("\n Party Part Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_ColourInd",&Color_Ind));
				if(tc_strlen(Color_Ind)>0)
				{
					tc_strdup(Color_Ind,&Color_IndDup);
				}
				else
				{
					tc_strdup("-",&Color_IndDup);
					printf("\n Part Colour Indicator Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_Coated",&Coated));
				if(tc_strlen(Coated)>0)
				{
					tc_strdup(Coated,&CoatedDup);
				}
				else
				{
					tc_strdup("-",&CoatedDup);
					printf("\n Coated Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_double(iteamrev2,"t5_Weight",&Weight));
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_MThickness",&Thick));
				if(tc_strlen(Thick)>0)
				{
					tc_strdup(Thick,&ThickDup);
				}
				else
				{
					tc_strdup("-",&ThickDup);
					printf("\n Thickness Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_Material",&MatDrw));
				if(tc_strlen(MatDrw)>0)
				{
					tc_strdup(MatDrw,&MatDrwDup);
					trimwhitespace(MatDrwDup);	
				}
				else
				{
					tc_strdup("-",&MatDrwDup);
					printf("\n Material in Drawing Value is NULL..!!\n");fflush(stdout);
				}
				STRNG_replace_str(MatDrwDup,","," ",&MatDrwDup);
				STRNG_replace_str(MatDrwDup,";"," ",&MatDrwDup);
				STRNG_replace_str(MatDrwDup,"\n"," ",&MatDrwDup);
				STRNG_replace_str(MatDrwDup,"'"," ",&MatDrwDup);
				STRNG_replace_str(MatDrwDup,"&"," ",&MatDrwDup);
				STRNG_replace_str(MatDrwDup,"<"," ",&MatDrwDup);
				STRNG_replace_str(MatDrwDup,">"," ",&MatDrwDup);
				printf("\n Material in Drawing Final Value: [%s]\n", MatDrwDup);fflush(stdout);
				
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_SpareInd",&SpInd));
				if(tc_strlen(SpInd)>0)
				{
					tc_strdup(SpInd,&SpIndDup);
				}
				else
				{
					tc_strdup("-",&SpIndDup);
					printf("\n Spare Indicator Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_SpareCriteria",&Spare_Ctr));
				if(tc_strlen(Spare_Ctr)>0)
				{
					trimwhitespace(Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,","," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,";"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"\n"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"'"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"`"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"~"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"@"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"#"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"$"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"|"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"!"," ",&Spare_Ctr);
					tc_strdup(Spare_Ctr,&Spare_CtrDup);
				}
				else
				{
					tc_strdup("-",&Spare_CtrDup);
					printf("\n Spare Criteria Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_PartStatus",&ArDr));
				if(tc_strlen(ArDr)>0)
				{
					tc_strdup(ArDr,&ArDrDup);
				}
				else
				{
					tc_strdup("-",&ArDrDup);
					printf("\n AR/DR Status Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_ProjectCode",&ProjCode));
				if(tc_strlen(ProjCode)>0)
				{
					tc_strdup(ProjCode,&ProjCodeDup);
				}
				else
				{
					tc_strdup("-",&ProjCodeDup);
					printf("\n Project Code Value is NULL..!!\n");fflush(stdout);
				}
				printf("\n Function1: Release Status List Find Start..!!\n");fflush(stdout);
				tc_strcpy(Item_RevSeq,Part_Rev);
				tc_strcat(Item_RevSeq,"*");
				tc_strcat(Item_RevSeq,Part_Seq);
				printf("Item RevSeq: [%s] \n", Item_RevSeq);fflush(stdout);
				Item_LCDetails = TC_PartLCDetails(Part_No,Item_RevSeq);
				printf("\n Vehicle Release Status Value After Dup & Trim: [%s]", Item_LCDetails);fflush(stdout);
				printf("\n Function1: Release Status List Find End..!!\n");fflush(stdout);
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_cabkitapp",&CabinAppl));
				if(tc_strlen(CabinAppl)>0)
				{
					tc_strdup(CabinAppl,&CabinApplDup);
				}
				else
				{
					tc_strdup("-",&CabinApplDup);
					printf("\n Cabin Kit Applicability Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_EnvelopeDimensions",&Env_Dim));
				if(tc_strlen(Env_Dim)>0)
				{
					trimwhitespace(Env_Dim);
					STRNG_replace_str(Env_Dim,","," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,";"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"\n"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"'"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"`"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"~"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"@"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"#"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"$"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"|"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"!"," ",&Env_Dim);
					tc_strdup(Env_Dim,&Env_DimDup);
				}
				else
				{
					tc_strdup("-",&Env_DimDup);
					printf("\n Envelope Dimension Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_double(iteamrev2,"t5_SurfaceArea",&SrfcArea));
				/* ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_EnvelopeDimensions",&Env_Dim));
				if(Env_Dim!=NULL)
				{
					trimwhitespace(Env_Dim);
					STRNG_replace_str(Env_Dim,","," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,";"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"\n"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"'"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"`"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"~"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"@"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"#"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"$"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"|"," ",&Env_Dim);
					STRNG_replace_str(Env_Dim,"!"," ",&Env_Dim);
					tc_strdup(Env_Dim,&Env_DimDup);
				}
				else
				{
					tc_strdup("--",&Env_DimDup);
					printf("\n Envelope Dimension Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_double(iteamrev2,"t5_Weight",&Part_Weight));
			    ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_MatlClass",&Mat_Clas));
				if(Mat_Clas!=NULL)
				{
					trimwhitespace(Mat_Clas);
					STRNG_replace_str(Mat_Clas,","," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,";"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"\n"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"'"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"`"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"~"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"@"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"#"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"$"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"|"," ",&Mat_Clas);
					STRNG_replace_str(Mat_Clas,"!"," ",&Mat_Clas);
					tc_strdup(Mat_Clas,&Mat_ClasDup);
				}
				else
				{
					tc_strdup("--",&Mat_ClasDup);
					printf("\n Material Class Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_SpareCriteria",&Spare_Ctr));
				if(Spare_Ctr!=NULL)
				{
					trimwhitespace(Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,","," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,";"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"\n"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"'"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"`"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"~"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"@"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"#"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"$"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"|"," ",&Spare_Ctr);
					STRNG_replace_str(Spare_Ctr,"!"," ",&Spare_Ctr);
					tc_strdup(Spare_Ctr,&Spare_CtrDup);
				}
				else
				{
					tc_strdup("--",&Spare_CtrDup);
					printf("\n Spare Criteria Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PartType",&Part_Type));
				if(Part_Type!=NULL)
				{
					tc_strdup(Part_Type,&Part_TypeDup);
				}
				else
				{
					tc_strdup("--",&Part_TypeDup);
					printf("\n Part Type Value is NULL..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"t5_Material",&Mat_Drw));
				if(Mat_Drw!=NULL)
				{
					trimwhitespace(Mat_Drw);
					STRNG_replace_str(Mat_Drw,","," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,";"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"\n"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"'"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"`"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"~"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"@"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"#"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"$"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"|"," ",&Mat_Drw);
					STRNG_replace_str(Mat_Drw,"!"," ",&Mat_Drw);
					tc_strdup(Mat_Drw,&Mat_DrwDup);
				}
				else
				{
					tc_strdup("--",&Mat_DrwDup);
					printf("\n Material in Drawing Value is NULL..!!\n");fflush(stdout);
				} 
				
				ITK_CALL(ITEM_find_item(Part_No,&PartMasterTag));
				if(PartMasterTag != NULLTAG)
				{
					ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&MstrUnitTag));
				}
				if(MstrUnitTag!=NULL)
				{
					tc_strdup(MstrUnitTag,&MstrUnitTagDup);
				}
				else
				{
					tc_strdup("--",&MstrUnitTagDup);
					printf("\n Master Unit of Measure Tag[uom_tag] is NULL..!!\n");fflush(stdout);
				}
				
				ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"t5_uom",&MstrUnitVal));
				if(MstrUnitVal!=NULL)
				{
					tc_strdup(MstrUnitVal,&MstrUnitValDup);
				}
				else
				{
					tc_strdup("--",&MstrUnitValDup);
					printf("\n Master Unit of Measure Value[t5_uom] is NULL..!!\n");fflush(stdout);
				}
				printf(" Part Details Start...!!\n");fflush(stdout);
				printf("[1] Part_No: [%s]\n",Part_No);fflush(stdout);
				printf("[2] Part_Rev: [%s]\n",Part_Rev);fflush(stdout);
				printf("[3] Part_Seq: [%s]\n",Part_Seq);fflush(stdout);
				printf("[4] Part_Type: [%s]\n",Part_TypeDup);fflush(stdout);
				printf("[5] Part_Drawing_Indicator: [%s]\n",Part_DrwIndDup);fflush(stdout);
				printf("[6] Part_Drawing_No: [%s]\n",Part_DrwNoDup);fflush(stdout);
				printf("[4] Envelope_Dimension: [%s]\n",Env_DimDup);fflush(stdout);
				printf("[5] Weight: [%.3f]\n",Part_Weight);fflush(stdout);
				printf("[6] Material_Class: [%.3f]\n",Mat_ClasDup);fflush(stdout);
				printf("[7] Spare_Criteria: [%s]\n",Spare_CtrDup);fflush(stdout);
				printf("[8] Part_Type: [%s]\n",Part_TypeDup);fflush(stdout);
				printf("[9] Material_Drawing: [%s]\n",Mat_DrwDup);fflush(stdout);
				printf("[10] Master_UOM_Tag: [%s]\n",MstrUnitTagDup);fflush(stdout);
				printf("[11] Master_UOM_Value: [%s]\n",MstrUnitValDup);fflush(stdout);
				printf("[12] Revision_UOM_Value: [%s]\n",RevUnitValDup);fflush(stdout); 
				printf(" Part Details End...!!\n");fflush(stdout); */
				//fprintf(fpOutput_file1,"%s,%s,%s,%s,%.3f,%s,%s,%s,%s,%s,%s,%s\n",Part_No,Part_Rev,Part_Seq,Env_DimDup,Part_Weight,Mat_ClasDup,Spare_CtrDup,Part_TypeDup,Mat_DrwDup,MstrUnitTagDup,MstrUnitValDup,RevUnitValDup);fflush(fpOutput_file1);
				
				if((tc_strcmp(ArDrDup,"DR3")==0) || (tc_strcmp(ArDrDup,"AR3")==0) || (tc_strcmp(ArDrDup,"DR3P")==0) || (tc_strcmp(ArDrDup,"AR3P")==0) || (tc_strcmp(ArDrDup,"DR4")==0) || (tc_strcmp(ArDrDup,"AR4")==0) || (tc_strcmp(ArDrDup,"DR5")==0) || (tc_strcmp(ArDrDup,"AR5")==0))
				{
				    if((tc_strstr(AHDCS,"E")!=NULL) || (tc_strstr(AHDCS,"F")!=NULL) || (tc_strstr(DWDCS,"E")!=NULL) || (tc_strstr(DWDCS,"F")!=NULL) || (tc_strstr(JSRCS,"E")!=NULL) || (tc_strstr(JSRCS,"F")!=NULL) || (tc_strstr(LKNCS,"E")!=NULL) || (tc_strstr(LKNCS,"F")!=NULL) || (tc_strstr(PUNCS,"E")!=NULL) || (tc_strstr(PUNCS,"F")!=NULL) || (tc_strstr(SNDCS,"E")!=NULL) || (tc_strstr(SNDCS,"F")!=NULL) || (tc_strstr(PNRCS,"E")!=NULL) || (tc_strstr(PNRCS,"F")!=NULL) || (tc_strstr(CARCS,"E")!=NULL) || (tc_strstr(CARCS,"F")!=NULL))
				    {
				      fprintf(fpOutput_file1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%.3f,%s,%s,%s,%s,%s,%s,%s,%s,%s,%.3f\n",Part_No,Item_DescDup,Part_Rev,Part_Seq,Part_DrwIndDup,Part_DrwNoDup,RevUnitValDup,AHDCS,DWDCS,JSRCS,LKNCS,PUNCS,SNDCS,PNRCS,CARCS,DesGrpDup,OwnerDup,Part_TypeDup,Mod_AddrDup,AggrGrpDup,AggrDup,ModGrpDup,ModDup,vendor_id,vendor_name,Color_IndDup,CoatedDup,Weight,ThickDup,MatDrwDup,SpIndDup,Spare_CtrDup,ArDrDup,ProjCodeDup,Item_LCDetails,CabinApplDup,Env_DimDup,SrfcArea);fflush(fpOutput_file1);
				    }
					else
					{
					   printf("\n Plant CS Not Applicable..!!");fflush(stdout);
					}
				}
                else
                {
					printf("\n AR/DR Status Not Applicable..!!");fflush(stdout);
				}					
            }
            else
            {
				printf("\n Part Number is NULL..!!");fflush(stdout);
			}
            printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \n");fflush(stdout);			
		}
	}
	fprintf(fpOutput_file1,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file1);
	fclose(fpOutput_file1);
	printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ComplexityManagementRpt.c
* // ./linkitk -o tm_ComplexityManagementRpt tm_ComplexityManagementRpt.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ComplexityManagementReport/tm_ComplexityManagementRpt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ComplexityManagementReport/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ComplexityManagementReport/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ComplexityManagementReport/SendEmail.sh .
* // ./tm_ComplexityManagementRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -s=0 -e=100000
* // ./tm_ComplexityManagementRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -s=0 -e=100000
*
***************************************************************************/