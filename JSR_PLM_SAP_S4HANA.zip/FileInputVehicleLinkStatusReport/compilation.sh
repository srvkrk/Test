./compile tm_FileInputVehicleLinkStatus.c
./linkitk -o tm_FileInputVehicleLinkStatus tm_FileInputVehicleLinkStatus.o
chmod 777 tm_FileInputVehicleLinkStatus*
