./compile tm_FileInpVehComplianceRpt.c
./linkitk -o tm_FileInpVehComplianceRpt tm_FileInpVehComplianceRpt.o
chmod 777 tm_FileInpVehComplianceRpt*
