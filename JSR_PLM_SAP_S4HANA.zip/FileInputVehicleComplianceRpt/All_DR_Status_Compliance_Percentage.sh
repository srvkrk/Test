grep "All DR Status Compliance Percentage" *.csv >> All_DR_Status_Compliance_Percentage.txt
