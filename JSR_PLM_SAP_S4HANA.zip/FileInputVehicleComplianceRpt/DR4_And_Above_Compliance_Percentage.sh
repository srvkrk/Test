grep "DR4 and Above Compliance Percentage" *.csv >> DR4_And_Above_Compliance_Percentage.txt
