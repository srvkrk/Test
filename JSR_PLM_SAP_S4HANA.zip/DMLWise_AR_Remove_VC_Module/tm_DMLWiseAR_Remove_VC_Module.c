/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   DML Wise Released Obsolete Part's Details From TCUA - CV
*  File Name    :   tm_DMLWiseAR_Remove_VC_Module.c
*  Created on   :   Feb 3rd, 2026
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     03/02/2026                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	//char *retStringf;
	//retStringf = (char*) malloc(200);
	char *retStringf = (char *)MEM_alloc(100 * sizeof(char));
	
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_id_str = NULL;
	char *inp_id_strDup = NULL;
	tag_t QueryTag = NULLTAG;
	int n_entries = 4;
	int n_itemobj_found = 0;
	int i = 0;
	int num_to_sort = 1;
	char *keysAttr[1] =  {"creation_date"};
	int sort_order[1] = {2}; //1 --> Ascending Order & 2 --> Descending Order
	int resultcount = 0;
	tag_t* outtag = NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t ObjTypeTag = NULLTAG;
	char *TypeName = NULL;
	char* DMLNum = NULL;
	char* ComDMLNum = NULL;
	char* DMLRelType = NULL;
	char* DMLRelStatus = NULL;
	char* DMLOwner = NULL;
	char* FComDMLNum = NULL;
	char* DMLPlant = NULL;
	tag_t relation_type	= NULLTAG;
	int tcount = 0;
	tag_t *TaskRevision	= NULLTAG;
	int TaskCnt = 0;
	tag_t TaskRevTag = NULLTAG;
	char* TaskObjectType = NULL;
	char* TaskId = NULL;
	int pcount = 0;
	tag_t *PartTags	= NULLTAG;
	tag_t PartRevTag = NULLTAG;
	char* PartNo = NULL;
	char* PartRevSeq = NULL;
	char* PartType = NULL;
	char* PartDesc = NULL;
	char* PartDescDup = NULL;
	int PartCnt = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	FILE *fpOutput_file = NULL;
    char* PlantCode = NULL;
	char* PartRelStatus = NULL;
	char* start_time_str = NULL;
	char* end_time_str = NULL;
	
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	start_time_str = ITK_ask_cli_argument("-s=");
	end_time_str = ITK_ask_cli_argument("-e=");
	printf(" [1]: Start Time(start_time_str): [%s]\n",start_time_str);fflush(stdout);
	printf(" [2]: End Time(end_time_str): [%s]\n",end_time_str);fflush(stdout);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"PartList_Remove_AR");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
	fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	ITK_CALL(QRY_find2("APL_DML_PLMSAP", &QueryTag));
	if(QueryTag != NULLTAG)
	{
	   printf("\n [APL_DML_PLMSAP] Found Successfully..!!\n");fflush(stdout);
	   char *qry_entries[4]  = {"ID","Released_After","Released_Before","Release Type"};
	   char *qry_values[4]  = {"*",start_time_str,end_time_str,"WO"};
	   ITK_CALL(QRY_execute_with_sort(QueryTag, n_entries, qry_entries, qry_values, num_to_sort, keysAttr, sort_order, &resultcount, &outtag));
	   printf("\n -----------------------------------------------\n");fflush(stdout);
	   printf("\n  No of Object Found: [%d]\n",resultcount);fflush(stdout);
	   printf("\n -----------------------------------------------\n");fflush(stdout);
	    if(resultcount > 0)
	    {
		    for(i = 0; i < resultcount; i++)
		    {
				DMLTag = outtag[i];
				ITK_CALL(TCTYPE_ask_object_type(DMLTag,&ObjTypeTag));
				ITK_CALL(TCTYPE_ask_name2(ObjTypeTag,&TypeName));
				ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_id",&DMLNum));
				ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_id",&ComDMLNum));
				ITK_CALL(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLRelType));
				ITK_CALL(AOM_UIF_ask_value(DMLTag,"release_status_list",&DMLRelStatus));
				ITK_CALL(AOM_UIF_ask_value(DMLTag,"owning_user",&DMLOwner));
				printf("\n DML Object Type Name: [%s]\n",TypeName);fflush(stdout);
				printf("\n DML Number: [%s]\n",DMLNum);fflush(stdout);
				printf("\n DML Release Type: [%s]\n",DMLRelType);fflush(stdout);
				printf("\n DML Release Status List: [%s]\n",DMLRelStatus);fflush(stdout);
				printf("\n DML Owner: [%s]\n",DMLOwner);fflush(stdout);
				FComDMLNum = tc_strtok(ComDMLNum,"_");
			    DMLPlant = tc_strtok(NULL,"_");
				printf("\n DML Plant Code: [%s]\n", DMLPlant);fflush(stdout);
				if(tc_strcmp(DMLRelType,"WT")==0)
				{
					printf("\n \033[31m>>>>> DML: [%s] & Release Type: [%s] 😄 \033[0m<<<<<<\n",DMLNum, DMLRelType);fflush(stdout);
					if((tc_strstr(DMLRelStatus,"APLC Released")!=NULL)||(tc_strstr(DMLRelStatus,"APLP Released")!=NULL)||(tc_strstr(DMLRelStatus,"APLD Released")!=NULL)||(tc_strstr(DMLRelStatus,"APLU Released")!=NULL)||(tc_strstr(DMLRelStatus,"APLJ Released")!=NULL)||(tc_strstr(DMLRelStatus,"APLL Released")!=NULL)||(tc_strstr(DMLRelStatus,"APLA Released")!=NULL))
					{
						printf("\n \033[31m>>>>> DML Number & Release Status Match: [%s] [%s] 😄 \033[0m<<<<<<\n",DMLNum, DMLRelStatus);fflush(stdout);
						ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
						ITK_CALL(GRM_list_secondary_objects_only(DMLTag, relation_type, &tcount, &TaskRevision));
						printf("\n -----------------------------------------------\n");fflush(stdout);
						printf("\n  No of APL Task Revision Found: [%d]\n",tcount);fflush(stdout);
						printf("\n -----------------------------------------------\n");fflush(stdout);
						if(tcount > 0)
						{
							for(TaskCnt = 0; TaskCnt < tcount; TaskCnt++ )
							{
								TaskRevTag = TaskRevision[TaskCnt];
								ITK_CALL(AOM_ask_value_string(TaskRevTag,"object_type",&TaskObjectType));
								ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&TaskId));
								printf("\n Task Object Type: [%s]\n",TaskObjectType);fflush(stdout);
								printf("\n Task Number: [%s]\n",TaskId);fflush(stdout);
								ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pcount,&PartTags));
								printf("\nTask To Part Count : [%d]",pcount);fflush(stdout);
								for(PartCnt = 0; PartCnt < pcount; PartCnt++)
								{
									PartRevTag = PartTags[PartCnt];
									ITK_CALL(AOM_ask_value_string(PartRevTag,"item_id",&PartNo));
									ITK_CALL(AOM_ask_value_string(PartRevTag,"item_revision_id",&PartRevSeq));
									ITK_CALL(AOM_ask_value_string(PartRevTag,"t5_PartType",&PartType));
									ITK_CALL(AOM_ask_value_string(PartRevTag,"object_desc",&PartDesc));
									printf("\n Part Description Before Dup & Trim:  <%s> \n",PartDesc);fflush(stdout);
									if(tc_strlen(PartDesc)>0)
									{
										tc_strdup(PartDesc,&PartDescDup);
									}
									else
									{
										tc_strdup("--",&PartDescDup);
										printf("\n Item Description Value is NULL");fflush(stdout);
									}
									trimwhitespace(PartDescDup);
									printf("\n Part Description Value After Dup & Trim: [%s]", PartDescDup);fflush(stdout);
									STRNG_replace_str(PartDescDup,","," ",&PartDescDup);
									STRNG_replace_str(PartDescDup,";"," ",&PartDescDup);
									STRNG_replace_str(PartDescDup,"\n"," ",&PartDescDup);
									STRNG_replace_str(PartDescDup,"'"," ",&PartDescDup);
									printf("\n Part Description Final Value: [%s]", PartDescDup);fflush(stdout);
									printf("\n Part Type: [%s]\n",PartType);fflush(stdout);
									ITK_CALL(AOM_UIF_ask_value(PartRevTag,"release_status_list",&PartRelStatus));
									printf("\n Part Release Status: [%s]\n",PartRelStatus);fflush(stdout);
									if((tc_strcmp(DMLPlant,"APLP")==0) && (tc_strstr(DMLRelStatus,"APLP Released")!=NULL) && (tc_strstr(PartRelStatus,"APLP Released")!=NULL))
									{
										tc_strdup("1001",&PlantCode);
										if((tc_strcmp(PartType,"VC")==0) || (tc_strcmp(PartType,"V")==0) || (tc_strcmp(PartType,"M")==0))
										{
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File Start\n");fflush(stdout);
											fprintf(fpOutput_file,"%s|%s|%s|%s|%s|%s|%s|%s|\n",DMLNum,TaskId,PartNo,PlantCode,PartRevSeq,PartDescDup,PartType,DMLOwner);fflush(fpOutput_file);
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
										}
									}
									if((tc_strcmp(DMLPlant,"APLL")==0) && (tc_strstr(DMLRelStatus,"APLL Released")!=NULL) && (tc_strstr(PartRelStatus,"APLL Released")!=NULL))
									{
										tc_strdup("3001",&PlantCode);
										if((tc_strcmp(PartType,"VC")==0) || (tc_strcmp(PartType,"V")==0) || (tc_strcmp(PartType,"M")==0))
										{
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File Start\n");fflush(stdout);
											fprintf(fpOutput_file,"%s|%s|%s|%s|%s|%s|%s|%s|\n",DMLNum,TaskId,PartNo,PlantCode,PartRevSeq,PartDescDup,PartType,DMLOwner);fflush(fpOutput_file);
											printf("\n Function1: As Part Type: VC or V or  Module So, Write in File End\n");fflush(stdout);
										}
									}
									if((tc_strcmp(DMLPlant,"APLJ")==0) && (tc_strstr(DMLRelStatus,"APLJ Released")!=NULL) && (tc_strstr(PartRelStatus,"APLJ Released")!=NULL))
									{
										tc_strdup("2001",&PlantCode);
										if((tc_strcmp(PartType,"VC")==0) || (tc_strcmp(PartType,"V")==0) || (tc_strcmp(PartType,"M")==0))
										{
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File Start\n");fflush(stdout);
											fprintf(fpOutput_file,"%s|%s|%s|%s|%s|%s|%s|%s|\n",DMLNum,TaskId,PartNo,PlantCode,PartRevSeq,PartDescDup,PartType,DMLOwner);fflush(fpOutput_file);
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
										}
									}
									if((tc_strcmp(DMLPlant,"APLU")==0) && (tc_strstr(DMLRelStatus,"APLU Released")!=NULL) && (tc_strstr(PartRelStatus,"APLU Released")!=NULL))
									{
										tc_strdup("3100",&PlantCode);
										if((tc_strcmp(PartType,"VC")==0) || (tc_strcmp(PartType,"V")==0) || (tc_strcmp(PartType,"M")==0))
										{
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File Start\n");fflush(stdout);
											fprintf(fpOutput_file,"%s|%s|%s|%s|%s|%s|%s|%s|\n",DMLNum,TaskId,PartNo,PlantCode,PartRevSeq,PartDescDup,PartType,DMLOwner);fflush(fpOutput_file);
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
										}
									}
									if((tc_strcmp(DMLPlant,"APLD")==0) && (tc_strstr(DMLRelStatus,"APLD Released")!=NULL) && (tc_strstr(PartRelStatus,"APLD Released")!=NULL))
									{
										tc_strdup("1500",&PlantCode);
										if((tc_strcmp(PartType,"VC")==0) || (tc_strcmp(PartType,"V")==0) || (tc_strcmp(PartType,"M")==0))
										{
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File Start\n");fflush(stdout);
											fprintf(fpOutput_file,"%s|%s|%s|%s|%s|%s|%s|%s|\n",DMLNum,TaskId,PartNo,PlantCode,PartRevSeq,PartDescDup,PartType,DMLOwner);fflush(fpOutput_file);
											printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
										}
									}
									else
									{
										printf("\n \033[31m>>>>> DML Release Status and Part Release Status not matched or Part not Obsolete 😄 \033[0m<<<<<<\n");fflush(stdout);
									}
								}
							}
						}
						else
						{
							printf("\n \033[31m>>>>> DML To Task Not Found 😄 \033[0m<<<<<<\n");fflush(stdout);
						}						
					}
					else
					{
						printf("\n \033[31m>>>>> DML Not Stamped 😄 \033[0m<<<<<<\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n \033[31m>>>>> DML Release Type is not [Withdraw TPL]😄 \033[0m<<<<<<\n");fflush(stdout);
				}
			}
	    }
		else
		{
			printf("\n \033[31m>>>>> DML Object Not Found 😄 \033[0m<<<<<<\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n \033[31m>>>>> Query[APL_DML_PLMSAP] Tag Not Found 😄 \033[0m<<<<<<\n");fflush(stdout);
	}
	fclose(fpOutput_file); 

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_exit_module(TRUE);
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_DMLWiseAR_Remove_VC_Module.c
* // ./linkitk -o tm_DMLWiseAR_Remove_VC_Module tm_DMLWiseAR_Remove_VC_Module.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DMLWise_AR_Remove_VC_Module/tm_DMLWiseAR_Remove_VC_Module .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DMLWise_AR_Remove_VC_Module/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DMLWise_AR_Remove_VC_Module/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DMLWise_AR_Remove_VC_Module/SendEmail.sh .
* // ./tm_DMLWiseAR_Remove_VC_Module -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -s="20-Jan-2026 06:00" -e="03-Feb-2026 18:00"
* // ./tm_DMLWiseAR_Remove_VC_Module -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -s="20-Jan-2026 06:00" -e="03-Feb-2026 18:00"
*
***************************************************************************/