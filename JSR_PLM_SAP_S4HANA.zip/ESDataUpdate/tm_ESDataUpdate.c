/*************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*
* Modification History :
* S.No      Date			CR No      Modified By				Modification Notes
*  1     14-Jan-2019			  			         Creation Date Stamping on Master and Revision.
**************************************************************************************************************/

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tc/tc_startup.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <fclasses/tc_date.h>
#include <ae/dataset.h>
#include <stdlib.h>
#include <tcinit/tcinit.h>
#include <tccore/libtccore_exports.h>
#include <ae/dataset.h>
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


int update_des_no(tag_t, char*);
int update_creation_date(tag_t, date_t);
int ITK_auto_login (void);

char* MonthAbbreviation (char* MonthNo)
{
	char *ResponseMonth = (char *) malloc(400*sizeof(char));
	printf("\n Input Month No in String: --------> [%s]\n", MonthNo);fflush(stdout);
	int monno = atoi(MonthNo);
	printf("\n Input Month No in Integer: --------> [%d]\n", monno);fflush(stdout);
	switch(monno)
   {
	case 1:
	       tc_strcpy(ResponseMonth,"Jan");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 2:
	       tc_strcpy(ResponseMonth,"Feb");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 3:
	       tc_strcpy(ResponseMonth,"Mar");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 4:
	       tc_strcpy(ResponseMonth,"Apr");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 5:
	       tc_strcpy(ResponseMonth,"May");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 6:
	       tc_strcpy(ResponseMonth,"Jun");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 7:
	       tc_strcpy(ResponseMonth,"Jul");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 8:
	       tc_strcpy(ResponseMonth,"Aug");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 9:
	       tc_strcpy(ResponseMonth,"Sep");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 10:
	       tc_strcpy(ResponseMonth,"Oct");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 11:
	       tc_strcpy(ResponseMonth,"Nov");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 12:
	       tc_strcpy(ResponseMonth,"Dec");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	default:
	       printf("Invalid Number");
	       break;
      }
	  
	  return ResponseMonth;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* DateFormatConstruct (char* InputDt)
{
	char* FormatDtRlzd = (char *) malloc(400*sizeof(char));
	char* RespMonth = NULL;
	char* InpYear = NULL;
	char* InpMonth = NULL;
	char* InpRemainDay = NULL;
	char* InpSeperate = NULL;
	char* InpHour = NULL;
	char* InpMin = NULL;
	char* InpSec = NULL;
	char* InpRemainMinHour = NULL;
	char* InpDay = NULL;
	
	InpYear=strtok(InputDt,"/");
	InpMonth=strtok(NULL,"/");
	InpRemainDay=strtok(NULL,"/");
	printf("\n Input Year: [%s]\n", InpYear);fflush(stdout);
	printf("\n Input Month: [%s]\n", InpMonth);fflush(stdout);
	printf("\n Input Remain Day: [%s]\n", InpRemainDay);fflush(stdout);
												
	InpDay=strtok(InpRemainDay,"-");
	InpRemainMinHour=strtok(NULL,"-");
	printf("\n Input Day: [%s]\n", InpDay);fflush(stdout);
	printf("\n Input Remain Minute & Hour: [%s]\n", InpRemainMinHour);fflush(stdout);
												
	InpHour=strtok(InpRemainMinHour,":");
	InpMin=strtok(NULL,":");
	InpSec=strtok(NULL,":");
												
	printf("\n Input Hour: [%s]\n", InpHour);fflush(stdout);
	printf("\n Input Minute: [%s]\n", InpMin);fflush(stdout);
	printf("\n Input Second: [%s]\n", InpSec);fflush(stdout);
												
	RespMonth = MonthAbbreviation(InpMonth);
	printf("\n Input Month Abbreviated Form: [%s]\n", RespMonth);fflush(stdout);
												
	tc_strcpy(FormatDtRlzd,InpDay);
	tc_strcat(FormatDtRlzd,"-");
	tc_strcat(FormatDtRlzd,RespMonth);
	tc_strcat(FormatDtRlzd,"-");
    tc_strcat(FormatDtRlzd,InpYear);
	tc_strcat(FormatDtRlzd," ");
    tc_strcat(FormatDtRlzd,InpHour);
    tc_strcat(FormatDtRlzd,":");
    tc_strcat(FormatDtRlzd,InpMin);
    printf("\n Formatted Date Released: [%s]\n", FormatDtRlzd);fflush(stdout);
	  
	return FormatDtRlzd;
}

int ITK_user_main (int argc, char *argv[])
{
    int				ifail						= 0;
    int				sec_count					= 0;
    int				sec_rev_count				= 0;
	
	char			inputline[1000];
	char			*inputfile					= NULL;
	char			*date						= NULL;
	char			*itemId						= NULL;
	char			*desanynoStr				= NULL;
	char			*seqId						= NULL;
	char			*VaultStr					= NULL;
	char			*CreDateStr				    = NULL;
	char			*lastUpdateStr				= NULL;

	tag_t			itemTag						= NULLTAG;
	tag_t			revTag						= NULLTAG;
	tag_t			relation_master				= NULLTAG;
	tag_t			relation_rev				= NULLTAG;
	tag_t			*sec_tag					= NULL;
	tag_t			*sec_form					= NULL;
    char			*creation_date				= NULL;

	date_t			date_created;
	date_t			date_rlzd;
	FILE			*file_p						= NULL;
	
	char* Part_No = NULL;
	char* Part_RevSeq = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char* FormatCreateDate = NULL;
	char* FormatLastUpdDate = NULL;
	tag_t attr_id=NULLTAG;
	tag_t Stat_tag = NULLTAG;
    char *message;
	char *loggedInUser = NULL;
	char* item_id_str = NULL;
	char* item_id_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	int i = 0;
	char *itemdetails = (char *) malloc(50*sizeof(char));
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	printf("\nLOGIN SUCCESSFULL");fflush(stdout);
	
	fpPart_List = fopen("PartList.txt","r");
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			tc_strcpy(itemdetails,item_id_strDup);
			tc_strcat(itemdetails,"-*");
			printf("\n @@@@@@ Item Details: [%s]\n",itemdetails);fflush(stdout);
			ITK_CALL(QRY_find2("Estimate_Sheet_PLMSAP",&tItemobj));
			if(tItemobj != NULLTAG)
			{
				printf("\n Query [Estimate_Sheet_PLMSAP] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[3]  = {"ID","Release_Status","Plant Name"};
				char *cValues[3]  = {itemdetails,"T5_PSDFinalReleased","CVBU JSR"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					for (i = 0; i < n_itemobj_found; i++)
					{
						revTag = titemobj_results[i];
						printf(" Design Revision & Sequence Found..!!\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&Part_No));
						printf(" ES-No: [%s]\n",Part_No);fflush(stdout);
						printf("\n Function[update_des_no] Call Start..!!");fflush(stdout);
						ifail = update_des_no(revTag, "20251205_1700_HRS_SAP_JOB");
						printf("\n Function[update_des_no] Call End..!!");fflush(stdout);
					}
				}
				else
				{
					printf("\n ES Revision Not Found..!!");fflush(stdout);
				}
			}
			else
			{
				printf("\n ES Revision Query Tag Not Found..!!");fflush(stdout);
			}
	    }
    }		
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	
    CLEANUP:
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	ITK_CALL(ITK_exit_module(TRUE));	
	return ifail;
}

int update_des_no(tag_t obj_tag, char* upd_val)
{
	printf("\n Function(update_des_no) Start..!!\n");
	int	ifail = ITK_ok;
	tag_t attr_id1=NULLTAG;
	
	printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 	
	ITK_CALL(AOM_refresh(obj_tag, POM_modify_lock));
	printf("\n Lock..!!\n");fflush(stdout);
	ITK_CALL(POM_attr_id_of_attr("t5_Design_Number", "T5_EstimateSheetRevision", &attr_id1));
	printf("\n Attr_Id:  [%d]",attr_id1);fflush(stdout);  
	printf("\n Property Name Tag Found..!!\n");fflush(stdout); 
	ITK_CALL(POM_set_attr_string(1, &obj_tag, attr_id1, upd_val));
	printf("\n Set Property Value..!!\n");fflush(stdout);  
	ITK_CALL(POM_save_instances(1, &obj_tag, true));
	printf("\n Save...!!\n");fflush(stdout);
	ITK_CALL(AOM_refresh(obj_tag, POM_no_lock));
	printf("\n Unlock..!!\n");fflush(stdout);												
	printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
	
	if(ifail == ITK_ok)
	{
		printf("\n Date Release Updated.....!!");fflush(stdout);
	}
    printf("\n Function(update_des_no) End..!!\n");

	return ifail;
}

/* int update_creation_date(tag_t obj_tag, date_t date_created)
{
	printf("\n Function[update_creation_date] Start..!!");fflush(stdout);
	int	ifail = ITK_ok;
	tag_t attr_id1=NULLTAG;
	
	printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);  
	ITK_CALL(AOM_refresh(obj_tag, POM_modify_lock));
	printf("\n Lock..!!\n");fflush(stdout);  
	POM_set_creation_date(obj_tag, date_created);
	printf("\n Set Property Value..!!\n");fflush(stdout);  
	ITK_CALL(POM_save_instances(1, &obj_tag, true));
	printf("\n Save...!!\n");fflush(stdout);  
	ITK_CALL(AOM_refresh(obj_tag, POM_no_lock));
    printf("\n Unlock..!!\n");fflush(stdout);
	printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
	
	if(ifail == ITK_ok)
	{
		printf("\n CreationDate Updated.....!!");fflush(stdout);
	}
    printf("\n Function[update_creation_date] End..!!");fflush(stdout);

	return ifail;
}
 */

/***************************************************************************
*
* // ./compile tm_ESDataUpdate.c
* // ./linkitk -o tm_ESDataUpdate tm_ESDataUpdate.o
*
***************************************************************************/