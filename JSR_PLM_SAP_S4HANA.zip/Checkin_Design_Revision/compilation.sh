./compile tm_Part_Checkin.c
./linkitk -o tm_Part_Checkin tm_Part_Checkin.o
chmod 777 tm_Part_Checkin*
