$TC_ROOT/*Patch*/tcPatchExecutable Classificationpcdetails
