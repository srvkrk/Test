./compile Classificationpcdetails.c
./linkitk -o Classificationpcdetails Classificationpcdetails.o
chmod 777 Classificationpcdetails*
