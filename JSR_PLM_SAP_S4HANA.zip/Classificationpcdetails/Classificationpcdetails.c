/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Classification Attribute Details Generate For Profit Center  
*  File Name    :   Classificationpcdetails.c
*  Created on   :   Sept 25th, 2025
*  Usage        :   Classificationpcdetails
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     25/09/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#include <ics/ics2.h>
#include <ics/ics.h>
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int getClsValueFrmICSTag_pm( tag_t  IcsClsTag_pm , char *clsKeyAtrrId_pm,char **AttrVal)
{
	tag_t objTypeTag_pm=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name_pm[TCTYPE_name_size_c+1];
	char   *Ptype_name_pm	=	NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag_pm,&objTypeTag_pm));
	//if(TCTYPE_ask_name(objTypeTag_pm,Ptype_name_pm));
	if(TCTYPE_ask_name2(objTypeTag_pm,&Ptype_name_pm)); // TC 14.3 Upgrade

	
	if(IcsClsTag_pm!=NULLTAG)
	{
		    char * 	theClassId = NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId_pm); fflush(stdout);
			//char keyPrefix[10];
			//tc_strcpy(keyPrefix,"-");
			//tc_strcat(keyPrefix,clsKeyAtrrId);
			int intid2 = 0;
			char * 	unctName = NULL;
		    char *	shortName = NULL;
		    char * 	unctUnit = NULL;
		    int  unctFormat = 0;
			intid2=atoi(clsKeyAtrrId_pm);
			printf("\n  input intid2[%d]",intid2); fflush(stdout);
	 
			printf("\n  111"); fflush(stdout);
			ITKCALL(ICS_describe_unct(intid2,&unctName,&shortName,&unctUnit,&unctFormat));
			printf("\n  222 ifail[%d]",ifail); fflush(stdout);
			if(ifail != ITK_ok)
			{
				printf("\n FAIL:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);						
				return ifail;	
			}
			
			printf("\n SUCCESS:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);
			//printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			//const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char theKeyLOVId[10];
			const char * 	key_lov_id;
			if(unctFormat)
			{

				sprintf(theKeyLOVId, "%d", unctFormat);
				key_lov_id=theKeyLOVId;	
			}
			char * 	key_lov_name;
			int  	options;
			int t = 0;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites;
			theICOTag=IcsClsTag_pm;
			ITKCALL(ICS_ask_attribute_value(theICOTag,clsKeyAtrrId_pm,&AttrKeyValue));
			
			printf("\n AttrKeyValue: [%s]  key_lov_id: [%s]",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			    if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    //CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    printf("\n key_lov_name: [%s] n_lov_entries: [%d] options: [%d]",key_lov_name,n_lov_entries,options); fflush(stdout);
 				for(t=0;t<n_lov_entries;t++)								
				{
					//printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
					
					//if(tc_strcasecmp(AttrKeyValue,lov_keys[t])==0)
					if(tc_strstr(lov_keys[t],AttrKeyValue) != NULL)
					{
						printf("\n AttrKeyValue: [%s]",AttrKeyValue);fflush(stdout);
						printf("\n Mascot lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						
						if(lov_values[t])
						{
							tc_strdup(lov_values[t],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						printf("\n Before Break RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
						break;
					}	
				} 
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}
    printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	printf("\n RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
			
	return ITK_ok;
}

int TC_VCClassification_Details(char* partno,char* rev,char* seq,FILE* fpfile)
{
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int s = 0;
	tag_t VCRev_tag = NULLTAG;
	char *item_revseq = (char *) malloc(20*sizeof(char));
	int ChldCount = 0;
    tag_t *PartChildTags = NULLTAG;
	tag_t Veh_tag = NULLTAG;
	char *vehno_str = NULL;
	char *vehno_strDup = NULL;
	int z = 0;
	tag_t vehtItemobj = NULLTAG;
	int vehn_entries = 4;
	int vehn_itemobj_found = 0;
	tag_t* vehtitemobj_results = NULLTAG;
	int y = 0;
	tag_t VehRev_tag = NULLTAG;
	int iFail = ITK_ok;
	char *prodlineval = NULL;
	prodlineval = (char *) malloc(100*sizeof(char));
	char *platformval = NULL;
	platformval = (char *) malloc(100*sizeof(char));
	char *segmentval = NULL;
	segmentval = (char *) malloc(100*sizeof(char));
	char *variantval = NULL;
	variantval = (char *) malloc(100*sizeof(char));
	char *vcprofit_centre_sap = NULL;
	char *VC_Desc = NULL;
	char *VC_DescDup = NULL;
	
	if(prodlineval!=NULL)trimwhitespace(prodlineval);
	if(platformval!=NULL)trimwhitespace(platformval);
	if(segmentval!=NULL)trimwhitespace(segmentval);
	if(variantval!=NULL)trimwhitespace(variantval);
	char *vcctnpc = NULL;
	
	tc_strcpy(item_revseq,rev);
	tc_strcat(item_revseq,"*");
	tc_strcat(item_revseq,seq);
	printf(" Final: Part_Rev_Seq Value(item_revseq): [%s]\n",item_revseq);
	
	printf("\n Finding Query[DesignRevision Sequence]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","ID"};
		char *cValues[2]  = {item_revseq,partno};
		//char *cValues[2]  = {"A*2","51780353000R"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
			for(s = 0; s < n_itemobj_found; s++)
			{
				VCRev_tag = titemobj_results[s];
				AOM_ask_value_string(VCRev_tag,"object_desc",&VC_Desc);
				printf("\n Item Description Before Dup & Trim:  <%s> \n",VC_Desc);fflush(stdout);
				if(tc_strlen(VC_Desc)>0)
				{
					tc_strdup(VC_Desc,&VC_DescDup);
				}
				else
				{
					tc_strdup("--",&VC_DescDup);
					printf("\n Item Description Value is NULL");fflush(stdout);
				}
				trimwhitespace(VC_DescDup);
				printf("\n Item Description Value After Dup & Trim: [%s]", VC_DescDup);fflush(stdout);
				STRNG_replace_str(VC_DescDup,","," ",&VC_DescDup);
				STRNG_replace_str(VC_DescDup,";"," ",&VC_DescDup);
				STRNG_replace_str(VC_DescDup,"\n"," ",&VC_DescDup);
				STRNG_replace_str(VC_DescDup,"'"," ",&VC_DescDup);
				printf("\n Item Description Final Value: [%s]", VC_DescDup);fflush(stdout);
				ITK_CALL(AOM_ask_value_tags(VCRev_tag,"ps_children",&ChldCount,&PartChildTags));
				if(ChldCount>0)
				{
					for(z = 0; z < ChldCount; z++)
			        {
						Veh_tag = PartChildTags[z];
						ITK_CALL(AOM_ask_value_string(PartChildTags[z],"item_id",&vehno_str));
						if(tc_strlen(vehno_str)>0)
						{
							tc_strdup(vehno_str,&vehno_strDup);
							ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&vehtItemobj));
							if(vehtItemobj != NULLTAG)
							{
								printf("\n Query [MCC_ERC_Released_Latest_Revision] Found Successfully..!!\n");fflush(stdout);
								char *vehEntries[4]  = {"Item ID","Release Status","Part Type","Type"};
								char *vehValues[4]  = {vehno_strDup,"T5_LcsErcRlzd","V","Design Revision"};
								ITK_CALL(QRY_execute(vehtItemobj, vehn_entries, vehEntries, vehValues, &vehn_itemobj_found, &vehtitemobj_results));
								printf("\n -----------------------------------------------\n");fflush(stdout);
								printf("\n No of Revision Found: [%d]\n",vehn_itemobj_found);fflush(stdout);
								printf("\n -----------------------------------------------\n");fflush(stdout);
								if(vehn_itemobj_found > 0)
								{
									printf("\n Query [MCC_ERC_Released_Latest_Revision] Found..!!\n");fflush(stdout);
									for (y = 0; y < vehn_itemobj_found; y++)
									{
										VehRev_tag = vehtitemobj_results[y];
										printf("\n Function2: Classification Attribute Find Start");fflush(stdout);
										tag_t Vc_spec_relation_type = NULLTAG;
										int vcspec_count_f = 0;
										tag_t* Vc_specObjects_f = NULLTAG;
										char *vcspec_item_id_f = NULL;
										char *vcclass_f = NULL;
										tag_t VehMstrTag = NULLTAG;
										int cnt	= 0;
										tag_t *ClsObjTag_results = NULLTAG;
										tag_t ClsObj_f = NULLTAG;
									
										ITK_CALL(GRM_find_relation_type("T5_VCSpec",&Vc_spec_relation_type));
										if(Vc_spec_relation_type != NULLTAG)
										{
											ITK_CALL(GRM_list_secondary_objects_only(VehRev_tag, Vc_spec_relation_type, &vcspec_count_f, &Vc_specObjects_f));
											printf("\n ----------------------------------------------");fflush(stdout);
											printf("\n Total Tech_Spech Attached with Vehicle: [%d]",vcspec_count_f);fflush(stdout);
											printf("\n ----------------------------------------------\n");fflush(stdout);
											if(vcspec_count_f > 0)
											{
												ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"item_id",&vcspec_item_id_f));
												printf("\n Tech_Spech No: [%s]\n",vcspec_item_id_f);fflush(stdout);
																						
												ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"t5_VCClassName",&vcclass_f));
												printf("\n Vehicle Class: [%s]",vcclass_f);fflush(stdout);
												
												if(tc_strlen(vcclass_f) > 0)
												{
													char *geproductlineval_id = NULL;
													geproductlineval_id = (char *) malloc(100*sizeof(char));
													char *getplatformval_id = NULL;
													getplatformval_id = (char *) malloc(100*sizeof(char));
													char *getsegmentval_id = NULL;
													getsegmentval_id = (char *) malloc(100*sizeof(char));
													char *getvariantval_id = NULL;
													getvariantval_id = (char *) malloc(100*sizeof(char));
													
													if(tc_strcmp(vcclass_f,"MCV")==0)
													{
														printf("\n Attribute_ID Start: [MCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_MCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_MCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_MCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_MCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [MCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"HCV")==0)
													{
														printf("\n Attribute_ID Start: [HCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_HCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_HCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_HCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_HCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [HCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"LCV")==0)
													{
														printf("\n Attribute_ID Start: [LCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_LCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_LCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_LCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_LCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [LCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"LMV")==0)
													{
														printf("\n Attribute_ID Start: [LMV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
													
														printf("\n geproductlineval_id_LMV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_LMV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_LMV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_LMV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [LMV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"BUS")==0)
													{
														printf("\n Attribute_ID Start: [BUS] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_BUS: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_BUS: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_BUS: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_BUS: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [BUS] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"UV_VAN")==0)
													{
														printf("\n Attribute_ID Start: [UV_VAN] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_UV_VAN: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_UV_VAN: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_UV_VAN: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_UV_VAN: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [UV_VAN] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"ICV")==0)
													{
														printf("\n Attribute_ID Start: [ICV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_ICV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_ICV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_ICV [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_ICV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [ICV] \n");fflush(stdout);
													}
													else
													{
														printf("\n VC Class Not Matched..!! \n");fflush(stdout);
													}
													
													ITK_CALL(ITEM_ask_item_of_rev(VehRev_tag,&VehMstrTag));
													ITK_CALL(AOM_ask_value_tags(VehMstrTag,"IMAN_classification",&cnt,&ClsObjTag_results));
													printf("\n Vehicle Master Object Count: [%d]\n", cnt); fflush(stdout);
													if(cnt > 0)
													{
														ClsObj_f=*ClsObjTag_results;	
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,geproductlineval_id,&prodlineval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getplatformval_id,&platformval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getsegmentval_id,&segmentval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getvariantval_id,&variantval));
														
														if(prodlineval!=NULL)trimwhitespace(prodlineval);
														if(platformval!=NULL)trimwhitespace(platformval);
														if(segmentval!=NULL)trimwhitespace(segmentval);
														if(variantval!=NULL)trimwhitespace(variantval);	
														
														printf("\n PRODUCTLINE : [%s]",prodlineval); fflush(stdout);
														printf("\n PLATFORM : [%s]",platformval); fflush(stdout);
														printf("\n SEGMENT : [%s]",segmentval); fflush(stdout);
														printf("\n VARIANT : [%s]",variantval); fflush(stdout);
													}
													else
													{
														printf("\n VC Master Not Found..!! \n");fflush(stdout);
														tc_strcpy(prodlineval,"");
														tc_strcpy(platformval,"");
														tc_strcpy(segmentval,"");
														tc_strcpy(variantval,"");
													}				
												}
												else
												{
													printf("\n VC Class Not Found..!! \n");fflush(stdout);
													tc_strcpy(prodlineval,"");
													tc_strcpy(platformval,"");
													tc_strcpy(segmentval,"");
													tc_strcpy(variantval,"");
												}
											}
											else
											{
												printf("\n No Tech_Spech Attached with Vehicle..!! \n");fflush(stdout);
												tc_strcpy(prodlineval,"");
												tc_strcpy(platformval,"");
												tc_strcpy(segmentval,"");
												tc_strcpy(variantval,"");
											}
										}
										printf("\n Function3: Classification Attribute Find End");fflush(stdout);
									}
								}
								else
								{
								   printf("\n Veh_No Value is NULL..!!");fflush(stdout);
								}
							}
						}
						else
						{
							tc_strdup("",&vehno_strDup);
							printf("\n Veh Master Value is NULL..!!");fflush(stdout);
						}
					}
				}
				else
				{
					printf(" VC To Vehicle Not Found..!!\n");fflush(stdout);
				}
			}
		}
	}
	
	if((tc_strlen(prodlineval)>0) && (tc_strlen(platformval)>0))
	{
		tag_t ctltItemobj = NULLTAG;
		int ctln_entries = 4;
		int newctln_entries = 3;
		int ctln_itemobj_found = 0;
		tag_t* ctltitemobj_results = NULLTAG;
		int v = 0;
		tag_t CtlRev_tag = NULLTAG;
		vcprofit_centre_sap = (char *)malloc(100 * sizeof(char));
		
		if(((tc_strcmp(prodlineval,"Passenger")==0) || (tc_strcmp(prodlineval,"SCV PU")==0)) && ((tc_strcmp(platformval,"Buses")==0) || (tc_strcmp(platformval,"PU Small")==0) || (tc_strcmp(platformval,"Vans")==0)))
		{
			printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
			printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
			ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
			if(ctltItemobj != NULLTAG)
			{
				printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
				char *ctlEntries[4]  = {"SYSCD","Information-1","Information-2","Information-3"};
				char *ctlValues[4]  = {"S4HANAPLANTDATAVC",prodlineval,platformval,segmentval};
				//char *ctlValues[4]  = {"S4HANAPLANTDATAVC","Passenger","Buses","ICV Buses"};
				ITK_CALL(QRY_execute(ctltItemobj, ctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(ctln_itemobj_found > 0)
				{
					printf(" Queried Control Object Found..!!\n");fflush(stdout);
					printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for(v = 0; v < ctln_itemobj_found; v++)
					{
						CtlRev_tag = ctltitemobj_results[v];
						ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
						printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
						//tc_strcpy(vcprofit_centre_sap,"0000");
						//tc_strcat(vcprofit_centre_sap,vcctnpc);
						tc_strcpy(vcprofit_centre_sap,vcctnpc);
					}
				}
			}
		}
		else
		{
			printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
			printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
			ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
			if(ctltItemobj != NULLTAG)
			{
				printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
				char *ctlEntries[3]  = {"SYSCD","Information-1","Information-2"};
				char *ctlValues[3]  = {"S4HANAPLANTDATAVC",prodlineval,platformval};
				//char *ctlValues[3]  = {"S4HANAPLANTDATAVC","Passenger","Buses"};
				ITK_CALL(QRY_execute(ctltItemobj, newctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(ctln_itemobj_found > 0)
				{
					printf(" Queried Control Object Found..!!\n");fflush(stdout);
					printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for(v = 0; v < ctln_itemobj_found; v++)
					{
						CtlRev_tag = ctltitemobj_results[v];
						ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
						printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
						//tc_strcpy(vcprofit_centre_sap,"0000");
						//tc_strcat(vcprofit_centre_sap,vcctnpc);
						tc_strcpy(vcprofit_centre_sap,vcctnpc);
					}
				}
			}
		}
		//if(tc_strlen(vcprofit_centre_sap)>0)
		if(tc_strlen(partno)>0)
		{
		    fprintf(fpfile,"%s,%s,%s,%s,%s,%s,%s,%s\n",partno,rev,seq,VC_Desc,prodlineval,platformval,segmentval,vcprofit_centre_sap);fflush(fpfile);
		}
		else
		{
			printf("\n !!!!!!!!!!! Profit Center Value Not Found For VC not Found !!!!!!!!!!!\n");fflush(stdout);
		}
	}

	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *PartNumber = NULL;
	char *PartRev = NULL;
	char *PartSeq = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	fpPart_List = fopen("PartList.txt","r");
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"classificationpc_details");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"PART_NO, REV, SEQ, DESCRIPTION, PRODUCT_LINE, PLATFORM, SEGMENT, PROFIT_CENTER\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			PartNumber=strtok(Buffer,"^");
			PartRev=strtok(NULL,"^");
			PartSeq=strtok(NULL,"^");
			
			printf(" [1]: Input PartNumber(PartNumber): [%s]\n",PartNumber);
	        printf(" [2]: Input PartRev(PartRev): [%s]\n",PartRev);
	        printf(" [3]: Input PartSeq(PartSeq): [%s]\n",PartSeq);
			
			printf("\n Function1: VC To Vehicle Classification Details Find Start\n");fflush(stdout);
		    TC_VCClassification_Details(PartNumber,PartRev,PartSeq,fpOutput_file);
	        printf("\n Function1: VC To Vehicle Classification Details Find End\n");fflush(stdout);
		}
	}
		
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	fclose(fpPart_List);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_exit_module(TRUE);	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile Classificationpcdetails.c
* // ./linkitk -o Classificationpcdetails Classificationpcdetails.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Classificationpcdetails/Classificationpcdetails .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Classificationpcdetails/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Classificationpcdetails/usage.txt .
* // ./Classificationpcdetails -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./Classificationpcdetails -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/