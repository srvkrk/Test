/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Latest Released Design Revision After Reading Data From Input File .
*  File Name    :   tm_Datasethunttcua.c
*  Created on   :   Aug 28th, 2024
*  Usage        :   tm_Datasethunttcua
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     28/08/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* TC_ERC_DTReleased(tag_t PartRev_tag)
{
	int	status = 0;
	tag_t *Stat_list = NULLTAG;
	tag_t Stat_tag = NULLTAG;
	int Stat_Cnt = 0;
	char *RlzStatusName = NULL;
	char *Dt_Rlzd = NULL;
	char *Dt_RlzdDup = NULL;
	int j = 0;
	
    ITK_CALL(WSOM_ask_release_status_list(PartRev_tag,&Stat_Cnt,&Stat_list));
    for(j=0;j<Stat_Cnt;j++)
	{
		Stat_tag = Stat_list[j];
		ITK_CALL(AOM_ask_name(Stat_tag, &RlzStatusName));
		printf("\n Part`s Release Status Name: [%s]\n",RlzStatusName);fflush(stdout);
        if ((tc_strcmp(RlzStatusName,"T5_LcsRlzd")==0) || (tc_strcmp(RlzStatusName,"T5_LcsErcRlzd")==0))
		{
			ITK_CALL(AOM_UIF_ask_value(Stat_tag,"date_released",&Dt_Rlzd));
			printf(" \n ERC-Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
             
		}
	}
	if(tc_strlen(Dt_Rlzd)>0)
	{
	   tc_strdup(Dt_Rlzd,&Dt_RlzdDup);
	}
	else
	{
	   tc_strdup("Not_ERC_Released",&Dt_RlzdDup);
	}
	return Dt_RlzdDup;
}

char* TC_RefDataset(tag_t DesRevTag, tag_t IMANReferenceType)
{
	int IMANRefCnt = 0;
	tag_t* IMANRefAttach = NULLTAG;
	int t = 0;
	char* RefSecObjName = NULL;
	char* Refobject_type = NULL;
	char* RefRefName = NULL;
	AE_reference_type_t RefRefType;
	tag_t RefRefObject = NULLTAG;
	char* RefOrginal_Name = NULL;
	char *RefList = (char *) malloc(70000*sizeof(char));
	tc_strcpy(RefList,"@");
	printf(" @@@@@@@@@@@@ IMAN REFERENCE START @@@@@@@@@@@@\n");fflush(stdout);
	if(IMANReferenceType != NULLTAG)
	{
		ITK_CALL(GRM_list_secondary_objects_only(DesRevTag,IMANReferenceType,&IMANRefCnt,&IMANRefAttach));
		printf("Dataset Object Count[IMAN_Reference]: [%d]\n",IMANRefCnt);fflush(stdout);
		if(IMANRefCnt > 0)
		{
			for(t = 0; t < IMANRefCnt; t++)
			{
				ITK_CALL(WSOM_ask_object_id_string(IMANRefAttach[t],&RefSecObjName));
				printf("RefSecObjName: [%s]\n",RefSecObjName);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(IMANRefAttach[t],"object_type",&Refobject_type));
				printf("Object Type: [%s]\n",Refobject_type);fflush(stdout);
				ITK_CALL(AE_find_dataset_named_ref2(IMANRefAttach[t],0,&RefRefName,&RefRefType,&RefRefObject));
				ITK_CALL(IMF_ask_original_file_name2(RefRefObject,&RefOrginal_Name));
				printf("Before Set Orginal File Name: [%s]\n",RefOrginal_Name);fflush(stdout);
				if(tc_strcmp(Refobject_type,"CMI2Product")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");	
					}
				}
				else if(tc_strcmp(Refobject_type,"CMI2Part")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"CMI2Drawing")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"ProPrt")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"ProAsm")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"ProDrw")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else if(tc_strcmp(Refobject_type,"PDF")==0)
				{
					if(tc_strlen(RefOrginal_Name)>0)
					{
					    tc_strcat(RefList,RefOrginal_Name);
						tc_strcat(RefList,"/@");
					}
				}
				else
				{
				  printf("\n [Refobject_type] Not Matched For [IMAN_Reference] Relation..!!\n");fflush(stdout);
				}
			}
		}
		else
		{
		  printf("\n No Object Found in [IMAN_Reference] Relation..!!\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n Relation Tag[IMAN_Reference] Not Found..!!\n");fflush(stdout);
	}
	printf(" @@@@@@@@@@@@ IMAN REFERENCE END @@@@@@@@@@@@\n");fflush(stdout);
	printf("\n Ref_List Before STRING_REPLACE: [%s]",RefList);fflush(stdout);
	STRNG_replace_str(RefList,"@","",&RefList);
	printf("\n Ref_List After STRING_REPLACE: [%s]",RefList);fflush(stdout);
	
	return RefList;	
}

char* TC_Vendor_Details(char* RefPartNo)
{
	
	trimwhitespace(RefPartNo);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_id = NULL;
	char* cItem_idDup = NULL;
	char* cItem_name = NULL;
	char* cItem_nameDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int y = 0;
	char *VList = (char *) malloc(200*sizeof(char));
	printf("\n Reference Part Number Value: [%s]\n", RefPartNo);fflush(stdout);
    ITK_CALL(QRY_find2("General...",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n [General...] Query Found Successfully...\n");fflush(stdout);
		char *PartEntries[2]  = {"Name","Type"};
		char *PartValues[2]  = {RefPartNo,"Vendor Part"};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (y = 0; y < np_Qryobj_found; y++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[y];
				if(rev_tags_found != NULLTAG)
				{	
					ITK_CALL(AOM_UIF_ask_value(tpQryobj_results[y],"vendor_id",&cItem_id));
					if(tc_strlen(cItem_id)>0)
					{
						tc_strdup(cItem_id,&cItem_idDup);
					}
					else
					{
						tc_strdup("",&cItem_idDup);
						printf("\n Vendor ID Value is NULL");fflush(stdout);
					}
					ITK_CALL(AOM_UIF_ask_value(tpQryobj_results[y],"vendor_name",&cItem_name));
					if(tc_strlen(cItem_name)>0)
					{
						tc_strdup(cItem_name,&cItem_nameDup);
					}
					else
					{
						tc_strdup("",&cItem_nameDup);
						printf("\n Vendor Name Value is NULL");fflush(stdout);
					}
	                tc_strcpy(VList,"");
					tc_strcat(VList,cItem_idDup);
					tc_strcat(VList,"@");
					tc_strcat(VList,cItem_nameDup);
					printf("\n Vendor Details Final Value: [%s]", VList);fflush(stdout);
				}
				else
				{
					tc_strcpy(VList,"");
					printf("\nSorry! Vendor Part Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strcpy(VList,"");
			printf("\nSorry! Entered Vendor Part Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strcpy(VList,"");
		printf("\nSorry! [Genearal...] Query Tag Not Found...");fflush(stdout);
	}
	
	return VList;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
    FILE *fpOutput_file = NULL;
	char* SubModAddr_Str = NULL;
	char* InpPart_Str = NULL;
	char* InpRev_Str = NULL;
	char* InpSeq_Str = NULL;
	char* SubModAddr_StrDup = NULL;
	char* InpPart_StrDup = NULL;
	char* InpRev_StrDup = NULL;
	char* InpSeq_StrDup = NULL;
	char* LibPartNo = NULL;
	char* LibPartRev = NULL;
	char* LibPartSeq = NULL;
	char* LibPartNoDup = NULL;
	char* LibPartRevDup = NULL;
	char* LibPartSeqDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tdesrev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	tag_t* IMANRenAttach = NULLTAG;
	int IMANRenCnt = 0;
	int i = 0;
	int j = 0;
	tag_t dataset = NULLTAG;
	AE_reference_type_t RenRefType;
	char* RenRefName = NULL;
	tag_t SecObjTypeTag = NULLTAG;
	char SecObjTypeName[TCTYPE_name_size_c+1];
	int ReferenceCount = 0;
	int k = 0;
	tag_t RenRefObject = NULLTAG;
	char* RenOrginal_Name = NULL;
	char* Renobject_type = NULL;
	char* Data_Name  = NULL;
	char* ItemIDChk = NULL;
	char* New_Name= (char *) malloc(400*sizeof(char));
	char* RenSecObjName = NULL;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	char *item_parttype_str = NULL;
	char *item_parttype_strDup = NULL;
	char *item_desgrp_str = NULL;
	char *item_desgrp_strDup = NULL;
	char *item_model_str = NULL;
	char *item_model_strDup = NULL;
	char *Owner = NULL;
	char *OwnerDup = NULL;
	char *inpitem_id_str = NULL;
	char *inpitem_id_strDup = NULL;
	/* char *PDFFileStatus = (char *) malloc(10*sizeof(char));
	char *PDFFileName = (char *) malloc(50*sizeof(char));
	char *JTFileStatus = (char *) malloc(10*sizeof(char));
	char *JTFileName = (char *) malloc(50*sizeof(char)); */
	/* char* PDFFileStatus = NULL;
	char* PDFFileName = NULL;
	char* JTFileStatus = NULL;
	char* JTFileName = NULL; */
	char* RefDSList_Status = NULL;
	char *ERCRlzdDt = NULL;
	char *item_class = NULL;
	char *item_classDup = NULL;
	char *item_partcategory = NULL;
	char *item_partcategoryDup = NULL;
	char *item_partypart = NULL;
	char *item_partypartDup = NULL;
	char *vendor_details = NULL;
	char *vendor_id = NULL;
	char *vendor_name = NULL;
	int IMANSpecCnt = 0;
	tag_t* IMANSpecAttach = NULLTAG;
	int m = 0;
	char* SpecSecObjName = NULL;
	char* Specobject_type = NULL;
	char* SpecRefName = NULL;
	AE_reference_type_t SpecRefType;
	tag_t SpecRefObject = NULLTAG;
	char* SpecOrginal_Name = NULL;
	/* char* CMI2ProdFileStatus = NULL;
	char* CMI2ProdFileName = NULL;
	char* CMI2PartFileStatus = NULL;
	char* CMI2PartFileName = NULL;
	char* CMI2DrwFileStatus = NULL;
	char* CMI2DrwFileName = NULL;
	char* CreoPrtFileStatus = NULL;
	char* CreoPrtFileName = NULL;
	char* CreoAsmFileStatus = NULL;
	char* CreoAsmFileName = NULL;
	char* CreoDrwFileStatus = NULL;
	char* CreoDrwFileName = NULL; */
	date_t dcreation_date;
    char *cCreation_date = NULL;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	int mach_type = SS_UNIX_MACHINE;
	char* SpecOrginal_Path = NULL;
	char* RenOrginal_Path = NULL;
	char* item_noncolor = NULL;
	char* item_noncolorDup = NULL;
	char* item_appown = NULL;
	char* item_appownDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}

	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
    tc_strcpy(RptFile,"TCUA_Dataset_Hunt");
    tc_strcat(RptFile,"_");
    tc_strcat(RptFile,GenDate);
    tc_strcat(RptFile,".csv");
    printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
    printf("\n CSV Report File Generated..!!");fflush(stdout);
	
	tag_t IMANSpecType = NULLTAG;
	tag_t IMANRefType = NULLTAG;
	tag_t IMANRenType = NULLTAG;
	ITK_CALL(GRM_find_relation_type("IMAN_specification",&IMANSpecType));
	ITK_CALL(GRM_find_relation_type("IMAN_reference",&IMANRefType));
	ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&IMANRenType));

    fpPart_List = fopen("PartList.txt","r");
	fpOutput_file = fopen(RptFile, "w");
    //fprintf(fpOutput_file,"PART_NO, REVISION, SEQUENCE, AVAILABLE_IN_PLM, PLM_TYPE, CMI2DRAWING_FILE, CMI2DRAWING_PATH, CMI2PRODUCT_FILE, CMI2PRODUCT_PATH, CMI2PART_FILE, CMI2PART_PATH, CREO_PART_FILE, CREO_PART_PATH, CREO_ASSEMBLY_FILE, CREO_ASSEMBLY_PATH, CREO_DRAWING_FILE, CREO_DRAWING_PATH, PDF_FILE, PDF_PATH, JT_FILE, JT_PATH, CLASS, PART_TYPE, PART_CATEGORY, PARTY_PART_NO, VENDOR_ID, VENDOR_NAME, PART_HAS_REF_DRW_DOC, CREATION_DATE, ERC_RELEASED_DATE, RELEASE_STATUS, NON_COLOR_PART)\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"PART_NO, REVISION, SEQUENCE, APPLICATION_OWNER, AVAILABLE_IN_PLM, PLM_TYPE, CMI2DRAWING_FILE, CMI2DRAWING_PATH, CMI2PRODUCT_FILE, CMI2PRODUCT_PATH, CMI2PART_FILE, CMI2PART_PATH, CREO_PART_FILE, CREO_PART_PATH, CREO_ASSEMBLY_FILE, CREO_ASSEMBLY_PATH, CREO_DRAWING_FILE, CREO_DRAWING_PATH, PDF_FILE, PDF_PATH, JT_FILE, JT_PATH, CLASS, PART_TYPE, PART_HAS_REF_DRW_DOC, CREATION_DATE, ERC_RELEASED_DATE, RELEASE_STATUS, NON_COLOR_PART)\n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
		printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
			return 0;
	}
	
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			inpitem_id_str=strtok(Buffer,"^");
			if(inpitem_id_str!=NULL)tc_strdup(inpitem_id_str,&inpitem_id_strDup);
			if(inpitem_id_strDup!=NULL)trimwhitespace(inpitem_id_strDup);
			
			printf("\n Part No(inpitem_id_strDup): [%s]\n",inpitem_id_strDup);

			//ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
			ITK_CALL(QRY_find2("Latest Item Revision...",&tItemobj));
			if(tItemobj != NULLTAG)
			{
				printf("Query[MCC_ERC_Released_Latest_Revision] Found Successfully..!!\n");fflush(stdout);
				//char *cEntries[2]  = {"Item ID","Release Status"};
				//char *cValues[2]  = {inpitem_id_strDup,"T5_LcsErcRlzd"};
				//char *cEntries[2]  = {"Item ID","Type"};
				//char *cValues[2]  = {inpitem_id_strDup,"Design Revision"};
				char *cEntries[1]  = {"Item ID"};
				char *cValues[1]  = {inpitem_id_strDup};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[MCC_ERC_Released_Latest_Revision] Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Objects[MCC_ERC_Released_Latest_Revision] Exist So Continue..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						tdesrev = titemobj_results[i];
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
						if(tc_strlen(item_id_str)>0)
						{
							tc_strdup(item_id_str,&item_id_strDup);
							trimwhitespace(item_id_strDup);
						}
						else
						{
							tc_strdup("",&item_id_strDup);
							printf("\n Part Number Value is NULL..!!");fflush(stdout);
						}
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&Newitem_revseq_str));
						if(tc_strlen(Newitem_revseq_str)>0)
						{
							tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
							trimwhitespace(Newitem_revseq_strDup);
							item_rev_str=strtok(Newitem_revseq_strDup,";");
							item_seq_str=strtok(NULL,";");
							if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
							if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
							trimwhitespace(item_rev_strDup);
							trimwhitespace(item_seq_strDup);
						}
						else
						{
							tc_strdup("",&item_rev_strDup);
							tc_strdup("",&item_seq_strDup);
							printf("\n [New]Part Revision Sequence Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ApplicationOwner",&item_appown));
						if(tc_strlen(item_appown)>0)
						{
							tc_strdup(item_appown,&item_appownDup);
						}
						else
						{
							tc_strdup("",&item_appownDup);
							printf("\n Item Application Owner Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"object_type",&item_class));
						if(tc_strlen(item_class)>0)
						{
							tc_strdup(item_class,&item_classDup);
						}
						else
						{
							tc_strdup("",&item_classDup);
							printf("\n Item Class Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartType",&item_parttype_str));
						if(tc_strlen(item_parttype_str)>0)
						{
							tc_strdup(item_parttype_str,&item_parttype_strDup);
							trimwhitespace(item_parttype_strDup);
							STRNG_replace_str(item_parttype_strDup,","," ",&item_parttype_strDup);
							STRNG_replace_str(item_parttype_strDup,";"," ",&item_parttype_strDup);
							STRNG_replace_str(item_parttype_strDup,"\n"," ",&item_parttype_strDup);
							STRNG_replace_str(item_parttype_strDup,"'"," ",&item_parttype_strDup);
						}
						else
						{
							tc_strdup("",&item_parttype_strDup);
							printf("\n Part Type Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_SpareCriteria",&item_partcategory));
						if(tc_strlen(item_partcategory)>0)
						{
							tc_strdup(item_partcategory,&item_partcategoryDup);
							trimwhitespace(item_partcategoryDup);
							STRNG_replace_str(item_partcategoryDup,","," ",&item_partcategoryDup);
							STRNG_replace_str(item_partcategoryDup,";"," ",&item_partcategoryDup);
							STRNG_replace_str(item_partcategoryDup,"\n"," ",&item_partcategoryDup);
							STRNG_replace_str(item_partcategoryDup,"'"," ",&item_partcategoryDup);
						}
						else
						{
							tc_strdup("",&item_partcategoryDup);
							printf("\n Part Category Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_RefPartNumber",&item_partypart));
						if(tc_strlen(item_partypart)>0)
						{
							tc_strdup(item_partypart,&item_partypartDup);
							trimwhitespace(item_partypartDup);
							printf("\n Function: Vendor Details Find Start..!!\n");fflush(stdout);
							vendor_details = TC_Vendor_Details(item_partypartDup);
							printf("\n Vendor Detais Before Tok: [%s]", vendor_details);fflush(stdout);
							printf("\n Function: Vendor Details Find End..!!\n");fflush(stdout);
							vendor_id=strtok(vendor_details,"@");
							vendor_name=strtok(NULL,"@");
							printf("\n Vendor ID Value After Token: [%s]\n", vendor_id);fflush(stdout);
							printf("\n Vendor Name Value After Token: [%s]\n", vendor_name);fflush(stdout);
							STRNG_replace_str(vendor_id,","," ",&vendor_id);
							STRNG_replace_str(vendor_id,";"," ",&vendor_id);
							STRNG_replace_str(vendor_id,"\n"," ",&vendor_id);
							STRNG_replace_str(vendor_id,"'"," ",&vendor_id);
							STRNG_replace_str(vendor_name,","," ",&vendor_name);
							STRNG_replace_str(vendor_name,";"," ",&vendor_name);
							STRNG_replace_str(vendor_name,"\n"," ",&vendor_name);
							STRNG_replace_str(vendor_name,"'"," ",&vendor_name);
							
						}
						else
						{
							tc_strdup("",&item_partypartDup);
							tc_strdup("",&vendor_id);
							tc_strdup("",&vendor_name);
							printf("\n Party Part Value is NULL..!!");fflush(stdout);
						}
			
						ITK_CALL(AOM_ask_value_date(titemobj_results[i],"creation_date",&dcreation_date));
	                    ITK_date_to_string(dcreation_date, &cCreation_date);
	                    printf("\n Creation Date: [%s] \n",cCreation_date);fflush(stdout);
						
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"release_status_list",&sRelStatus));
						printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
						if(tc_strlen(sRelStatus)>0)
						{
							tc_strdup(sRelStatus,&sRelStatusDup);
							trimwhitespace(sRelStatusDup);
							printf("\n Item Release Status After Dup & Trim: [%s]", sRelStatusDup);fflush(stdout);
							STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
							STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
							STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
							STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
						}
						else
						{
							tc_strdup("",&sRelStatusDup);
							printf("\n Item Release Status Value is NULL");fflush(stdout);
						}
						printf("\n Item Release Status Final Value: [%s]", sRelStatusDup);fflush(stdout);
						
						char* CMI2ProdFileStatus = NULL;
						char* CMI2ProdFileName = NULL;
						char* CMI2PartFileStatus = NULL;
						char* CMI2PartFileName = NULL;
						char* CMI2DrwFileStatus = NULL;
						char* CMI2DrwFileName = NULL;
						char* CreoPrtFileStatus = NULL;
						char* CreoPrtFileName = NULL;
						char* CreoAsmFileStatus = NULL;
						char* CreoAsmFileName = NULL;
						char* CreoDrwFileStatus = NULL;
						char* CreoDrwFileName = NULL;
						
						printf(" @@@@@@@@@@@@ IMAN SPECIFICATION START @@@@@@@@@@@@\n");fflush(stdout);
						if(IMANSpecType != NULLTAG)
						{
							ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i],IMANSpecType,&IMANSpecCnt,&IMANSpecAttach));
							printf("Dataset Object Count[IMAN_Specification]: [%d]\n",IMANSpecCnt);fflush(stdout);
							if(IMANSpecCnt > 0)
							{
								for (m = 0; m < IMANSpecCnt; m++)
								{
									ITK_CALL(WSOM_ask_object_id_string(IMANSpecAttach[m],&SpecSecObjName));
									printf("SpecSecObjName: [%s]\n",SpecSecObjName);fflush(stdout);
									ITK_CALL(AOM_ask_value_string(IMANSpecAttach[m],"object_type",&Specobject_type));
									printf("Object Type: [%s]\n",Specobject_type);fflush(stdout);
									ITK_CALL(AE_find_dataset_named_ref2(IMANSpecAttach[m],0,&SpecRefName,&SpecRefType,&SpecRefObject));
									ITK_CALL(IMF_ask_original_file_name2(SpecRefObject,&SpecOrginal_Name));
									printf("Before Set Orginal File Name: [%s]\n",SpecOrginal_Name);fflush(stdout);
									ITK_CALL(IMF_ask_file_pathname2(SpecRefObject,mach_type,&SpecOrginal_Path));
									printf("Before Set Orginal File Path: [%s]\n",SpecOrginal_Path);fflush(stdout);
									if(tc_strcmp(Specobject_type,"CMI2Product")==0)
									{
										//tc_strdup("Yes",&CMI2ProdFileStatus);
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										  tc_strdup(SpecOrginal_Name,&CMI2ProdFileStatus);
										  tc_strdup(SpecOrginal_Path,&CMI2ProdFileName);
										}
										else
										{
										  tc_strdup("",&CMI2ProdFileStatus);
										  tc_strdup("",&CMI2ProdFileName);
										}
									}
									else if(tc_strcmp(Specobject_type,"CMI2Part")==0)
									{
										//tc_strdup("Yes",&CMI2PartFileStatus);
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										  tc_strdup(SpecOrginal_Name,&CMI2PartFileStatus);
										  tc_strdup(SpecOrginal_Path,&CMI2PartFileName);
										}
										else
										{
										  tc_strdup("",&CMI2PartFileStatus);
										  tc_strdup("",&CMI2PartFileName);
										}
									}
									else if(tc_strcmp(Specobject_type,"CMI2Drawing")==0)
									{
										//tc_strdup("Yes",&CMI2DrwFileStatus);
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										  tc_strdup(SpecOrginal_Name,&CMI2DrwFileStatus);
										  tc_strdup(SpecOrginal_Path,&CMI2DrwFileName);
										}
										else
										{
										  tc_strdup("",&CMI2DrwFileStatus);
										  tc_strdup("",&CMI2DrwFileName);
										}
									}
									else if(tc_strcmp(Specobject_type,"ProPrt")==0)
									{
										//tc_strdup("Yes",&CreoPrtFileStatus);
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										  tc_strdup(SpecOrginal_Name,&CreoPrtFileStatus);
										  tc_strdup(SpecOrginal_Path,&CreoPrtFileName);
										}
										else
										{
										  tc_strdup("",&CreoPrtFileStatus);
										  tc_strdup("",&CreoPrtFileName);
										}
									}
									else if(tc_strcmp(Specobject_type,"ProAsm")==0)
									{
										//tc_strdup("Yes",&CreoAsmFileStatus);
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										  tc_strdup(SpecOrginal_Name,&CreoAsmFileStatus);
										  tc_strdup(SpecOrginal_Path,&CreoAsmFileName);
										}
										else
										{
										  tc_strdup("",&CreoAsmFileStatus);
										  tc_strdup("",&CreoAsmFileName);
										}
									}
									else if(tc_strcmp(Specobject_type,"ProDrw")==0)
									{
										//tc_strdup("Yes",&CreoDrwFileStatus);
										if(tc_strlen(SpecOrginal_Name)>0)
										{
										  tc_strdup(SpecOrginal_Name,&CreoDrwFileStatus);
										  tc_strdup(SpecOrginal_Path,&CreoDrwFileName);
										}
										else
										{
										  tc_strdup("",&CreoDrwFileStatus);
										  tc_strdup("",&CreoDrwFileName);
										}
									}
									else
									{
									  printf("\n [Specobject_type] Not Matched For [IMAN_Specification] Relation..!!\n");fflush(stdout);
									}
								}
							}
							else
							{
							  printf("\n No Object Found in [IMAN_Specification] Relation..!!\n");fflush(stdout);
							}
						}
						else
						{
							printf("\n Relation Tag[IMAN_Specification] Not Found..!!\n");fflush(stdout);
						}
						printf(" @@@@@@@@@@@@ IMAN SPECIFICATION END @@@@@@@@@@@@\n");fflush(stdout);
						
						char* PDFFileStatus = NULL;
						char* PDFFileName = NULL;
						char* JTFileStatus = NULL;
						char* JTFileName = NULL;
						printf(" @@@@@@@@@@@@ IMAN RENDERING START @@@@@@@@@@@@\n");fflush(stdout);
						if(IMANRenType != NULLTAG)
						{
							ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i],IMANRenType,&IMANRenCnt,&IMANRenAttach));
							printf("Dataset Object Count[IMAN_Rendering]: [%d]\n",IMANRenCnt);fflush(stdout);
							if(IMANRenCnt > 0)
							{
								for (j = 0; j < IMANRenCnt; j++)
								{
									ITK_CALL(WSOM_ask_object_id_string(IMANRenAttach[j],&RenSecObjName));
									printf("RenSecObjName: [%s]\n",RenSecObjName);fflush(stdout);
									ITK_CALL(AOM_ask_value_string(IMANRenAttach[j],"object_type",&Renobject_type));
									printf("Object Type: [%s]\n",Renobject_type);fflush(stdout);
									ITK_CALL(AE_find_dataset_named_ref2(IMANRenAttach[j],0,&RenRefName,&RenRefType,&RenRefObject));
									ITK_CALL(IMF_ask_original_file_name2(RenRefObject,&RenOrginal_Name));
									printf("Before Set Orginal File Name: [%s]\n",RenOrginal_Name);fflush(stdout);
									ITK_CALL(IMF_ask_file_pathname2(RenRefObject,mach_type,&RenOrginal_Path));
									printf("Before Set Orginal File Path: [%s]\n",RenOrginal_Path);fflush(stdout);
									if(tc_strcmp(Renobject_type,"DirectModel")==0)
									{
										//tc_strdup("Yes",&JTFileStatus);
										if(tc_strlen(RenOrginal_Name)>0)
										{
										  tc_strdup(RenOrginal_Name,&JTFileStatus);
										  tc_strdup(RenOrginal_Path,&JTFileName);
										}
										else
										{
										  tc_strdup("",&JTFileStatus);
										  tc_strdup("",&JTFileName);
										}
									}
									else if(tc_strcmp(Renobject_type,"PDF")==0)
									{
										//tc_strdup("Yes",&PDFFileStatus);
										if(tc_strlen(RenOrginal_Name)>0)
										{
										  tc_strdup(RenOrginal_Name,&PDFFileStatus);
										  tc_strdup(RenOrginal_Path,&PDFFileName);
										}
										else
										{
										  tc_strdup("",&PDFFileStatus);
										  tc_strdup("",&PDFFileName);
										}
									}
									else
									{
									  printf("\n [Renobject_type] Not Matched For [IMAN_Rendering] Relation..!!\n");fflush(stdout);
									}
								}
							}
							else
							{
							  printf("\n No Object Found in [IMAN_Rendering] Relation..!!\n");fflush(stdout);
							}
						}
						else
						{
							printf("\n Relation Tag[IMAN_Rendering] Not Found..!!\n");fflush(stdout);
						}
						printf(" @@@@@@@@@@@@ IMAN RENDERING END @@@@@@@@@@@@\n");fflush(stdout);
						
						printf("\n Function1: Reference Relation Dataset Find Start..!!\n");fflush(stdout);
						RefDSList_Status = TC_RefDataset(tdesrev,IMANRefType);
						printf("\n Reference Relation Dataset: [%s]", RefDSList_Status);fflush(stdout);
						printf("\n Function1: Reference Relation Dataset Find End..!!\n");fflush(stdout);
						
						printf("\n Function2: ERC-Release Date Find Start");fflush(stdout);
						ERCRlzdDt = TC_ERC_DTReleased(tdesrev);
			            printf("\n Function2: ERC-Release Date Find End\n");fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_NcPartNo",&item_noncolor));
						if(tc_strlen(item_noncolor)>0)
						{
							tc_strdup(item_noncolor,&item_noncolorDup);
						}
						else
						{
							tc_strdup("",&item_noncolorDup);
							printf("\n Item Non Color Value is NULL..!!");fflush(stdout);
						}
						
						//fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,"Yes","TCUA",CMI2DrwFileStatus,CMI2DrwFileName,CMI2ProdFileStatus,CMI2ProdFileName,CMI2PartFileStatus,CMI2PartFileName,CreoPrtFileStatus,CreoPrtFileName,CreoAsmFileStatus,CreoAsmFileName,CreoDrwFileStatus,CreoDrwFileName,PDFFileStatus,PDFFileName,JTFileStatus,JTFileName,item_classDup,item_parttype_strDup,item_partcategoryDup,item_partypartDup,vendor_id,vendor_name,RefDSList_Status,cCreation_date,ERCRlzdDt,sRelStatusDup,item_noncolorDup);fflush(fpOutput_file);
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,item_appownDup,"Yes","TCUA",CMI2DrwFileStatus,CMI2DrwFileName,CMI2ProdFileStatus,CMI2ProdFileName,CMI2PartFileStatus,CMI2PartFileName,CreoPrtFileStatus,CreoPrtFileName,CreoAsmFileStatus,CreoAsmFileName,CreoDrwFileStatus,CreoDrwFileName,PDFFileStatus,PDFFileName,JTFileStatus,JTFileName,item_classDup,item_parttype_strDup,RefDSList_Status,cCreation_date,ERCRlzdDt,sRelStatusDup,item_noncolorDup);fflush(fpOutput_file);
					}						
				}
				else
				{
				   printf("\n Objects[MCC_ERC_Released_Latest_Revision] Not Found..!!\n");fflush(stdout);
				}					
			}
			else
			{
				printf("\n Query[MCC_ERC_Released_Latest_Revision] Tag Not Found..!! \n");fflush(stdout);
			}
		}
	}
	else
	{
		printf("\n Input PartList File is NULL..!!");fflush(stdout);
	}
	fclose(fpOutput_file);
	fclose(fpPart_List);
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_Datasethunttcua.c
* // ./linkitk -o tm_Datasethunttcua tm_Datasethunttcua.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DatasetHuntTCUA/tm_Datasethunttcua .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DatasetHuntTCUA/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DatasetHuntTCUA/InputList.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/DatasetHuntTCUA/usage.txt .
* // ./tm_Datasethunttcua -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_Datasethunttcua -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/