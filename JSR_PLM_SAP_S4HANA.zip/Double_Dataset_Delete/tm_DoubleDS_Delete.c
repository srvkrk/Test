/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Part & Delete Double Dataset Present within it For Specific Type As Input  
*  File Name    :   tm_DoubleDS_Delete.c
*  Created on   :   Dec 13th, 2023
*  Usage        :   tm_DoubleDS_Delete
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     13/12/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *item_id_str = NULL;
	char *item_revseq_str = NULL;
	char *rel_type_str = NULL;
	char *ds_type_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_strDup = NULL;
	char *ds_type_strDup = NULL;
	char *rel_type_strDup = NULL;
	char *item_revseq_strdup = (char *) malloc(400*sizeof(char));
	tag_t tRelationType = NULLTAG;
	tag_t* tSecObjectList = NULLTAG;
	int iSec_ObjCount = 0;
	char* SecObjType = NULL;
	char* SecObjString = NULL;
	tag_t tdel_rel = NULLTAG;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	int i, j = 0;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_revseq_str=strtok(NULL,"^");
			rel_type_str=strtok(NULL,"^");
			ds_type_str=strtok(NULL,"^");
			
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_revseq_str!=NULL)tc_strdup(item_revseq_str,&item_revseq_strDup);
			if(rel_type_str!=NULL)tc_strdup(rel_type_str,&rel_type_strDup);
			if(ds_type_str!=NULL)tc_strdup(ds_type_str,&ds_type_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_revseq_strDup!=NULL)trimwhitespace(item_revseq_strDup);
			if(rel_type_strDup!=NULL)trimwhitespace(rel_type_strDup);
			if(ds_type_strDup!=NULL)trimwhitespace(ds_type_strDup);
			
			printf(" Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf(" Part RevSeq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			printf(" Part Relation(rel_type_strDup): [%s]\n",rel_type_strDup);
			printf(" Part Dataset Type(ds_type_strDup): [%s]\n",ds_type_strDup);
			
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if((tItemobj != NULLTAG) && (item_id_strDup != NULL))
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found>0)
			    {
					for (i = 0; i < n_itemobj_found; i++)
					{
						if((tc_strcmp(ds_type_strDup," ") !=0) || (tc_strcmp(rel_type_strDup," ") !=0))
						{
							int SEC_COUNT = 0;
							ITK_CALL(GRM_find_relation_type(rel_type_strDup, &tRelationType));
							ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i], tRelationType, &iSec_ObjCount, &tSecObjectList));
							printf("\n Secondary Objects Attached with Part_No: [%s] Rev_Seq: [%s] Object_Count: [%d]\n",item_id_strDup,item_revseq_strDup,iSec_ObjCount);fflush(stdout);
							if(iSec_ObjCount>1)
							{
								for (j = 0; j < iSec_ObjCount; j++)
								{
									ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_type", &SecObjType));
									printf("\n Secondary Object Original Type: [%s]", SecObjType);fflush(stdout);
									ITK_CALL(AOM_ask_value_string( tSecObjectList[j], "object_string", &SecObjString));
									printf("\n Secondary Object Name: [%s]", SecObjString);fflush(stdout);
									if(tc_strcmp(SecObjType,ds_type_strDup) == 0)
									{
										printf("\n Dataset Type Matched(SEC_COUNT++)..!!");fflush(stdout);
										SEC_COUNT = SEC_COUNT + 1;
										printf("\n Currently(SEC_COUNT++): [%d]", SEC_COUNT);fflush(stdout);
										if(SEC_COUNT > 1)
										{
											printf("\n Secondary Object_Count(SEC_COUNT) Greater Than One [DELETE]..!!\n");fflush(stdout);
											printf("\n ~~~~~~~~ D E L E T E   S T A R T ~~~~~~~~\n");fflush(stdout);
											ITK_CALL(GRM_find_relation(titemobj_results[i], tSecObjectList[j], tRelationType ,&tdel_rel));
											ITK_CALL(GRM_delete_relation(tdel_rel));
											ITK_CALL(AOM_lock(titemobj_results[i]));
											printf("\n Lock..!!\n");
                                            ITK_CALL(AOM_save_without_extensions(titemobj_results[i]));
											printf("\n Save..!!\n");
                                            ITK_CALL(AOM_unlock(titemobj_results[i]));
											printf("\n Unlock..!!\n");
											printf("\n ~~~~~~~~ D E L E T E   E N D ~~~~~~~~\n");fflush(stdout);
										}
										else
										{
											printf("\n Secondary Object_Count(SEC_COUNT): One, Continue..\n");fflush(stdout);
										}
									}
									else
									{
										printf("\n Returned Secondary Object_Type & Input_Type Not Matched..!!\n");fflush(stdout);
									}
								}
							}
							else
							{
								printf("\n Secondary Object Not Found For Input Dataset_Type & Relation_Name..!!\n");fflush(stdout);
							}
						}
						else
						{
							printf("\n Input Dataset_Type or Relation_Name NULL..!!");fflush(stdout);
						}						
					}
				}
				else
				{
				   printf("\n Design Revision Not Found For Given Input..!!");fflush(stdout);
				}
			}
		    else
			{
				printf("\n DesignRevision Sequence Query Tag Not Found or Input_Part No NULL..!!");fflush(stdout);
			}
			if (titemobj_results)
			{
				MEM_free(titemobj_results);
			}		

		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_DoubleDS_Delete.c
* // ./linkitk -o tm_DoubleDS_Delete tm_DoubleDS_Delete.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Double_Dataset_Delete/tm_DoubleDS_Delete .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Double_Dataset_Delete/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Double_Dataset_Delete/usage.txt .
* // ./tm_DoubleDS_Delete -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_DoubleDS_Delete -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/