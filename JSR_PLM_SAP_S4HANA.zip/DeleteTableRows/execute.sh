/user/cvprod/sourav/DeleteTableRows/tm_DeleteTableRows -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
