/user/cvprod/sourav/Latest_Released_Item_Details/tm_LatestRlzdItem -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -PT="V"
