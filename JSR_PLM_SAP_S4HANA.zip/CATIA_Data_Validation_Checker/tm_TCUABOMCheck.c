/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   BOM
*  Description  :   Find 99 Level TCUA BOM 
*  File Name    :   tm_TCUABOMCheck.c
*  Created on   :   Aug 06th, 2025
*  Usage        :   tm_TCUABOMCheck
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     06/08/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport)
{
	    //char* cItem_Level = NULL;
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		/* char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cItem_LCDetails = NULL; */
		char* cParentName = NULL;
		char* cParentNameDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		//char* cItem_Desc = NULL;
		char* cQuantity = NULL;
		char* cQuantityDup = NULL;
		//char* cProjCode = NULL;
	    //char* cProjCodeDup = NULL;
	    //char* cDesGrp = NULL;
	    //char* cDesGrpDup = NULL;
	    //tag_t PrtMstrTag = NULLTAG;
	    //char *MstrUOMTag = NULL;
	    //char *MstrUOMTagDup = NULL;
		//char *cParentPart = NULL;
		//char *cParentRevSeq = NULL;
		//char *cParentPartType = NULL;
		//char *cNewParentName = NULL;
		//char *cNewParentNameDup = NULL;
		
		char* cchildParent_PartNo = NULL;
		char* cchildParent_Remain = NULL;
		char* cchildParent_PartRev = NULL;
		char* cchildParent_PartSeq = NULL;
		char* cSubObjType = NULL;
		char* cSubObjTypeDup = NULL;
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_formatted_parent_name", &cParentName));
			if(tc_strlen(cParentName)>0)
			{
				tc_strdup(cParentName,&cParentNameDup);
			}
			else
			{
				tc_strdup("NA",&cParentNameDup);
				printf("\n Parent Part Value is NULL");fflush(stdout);
			}
			trimwhitespace(cParentNameDup);
			printf("\n Parent Part Value After Trim: [%s]", cParentNameDup);fflush(stdout);
			
			if(tc_strcmp(cParentNameDup,"NA") !=0)
			{
				cchildParent_PartNo = tc_strtok(cParentNameDup,"/");
			    cchildParent_Remain = tc_strtok(NULL,"/");
				printf("\n (cchildParent_PartNo) After Token: [%s]\n", cchildParent_PartNo);fflush(stdout);
			    printf("\n (cchildParent_Remain) After Token: [%s]\n", cchildParent_Remain);fflush(stdout);
				cchildParent_PartRev = tc_strtok(cchildParent_Remain,";");
			    cchildParent_PartSeq = tc_strtok(NULL,";");
			    printf("\n (cchildParent_PartRev) After Token: [%s]\n", cchildParent_PartRev);fflush(stdout);
			    printf("\n (cchildParent_PartSeq) After Token: [%s]\n", cchildParent_PartSeq);fflush(stdout);
			}
			else
			{
				tc_strdup("NA",&cchildParent_PartNo);
				tc_strdup("NA",&cchildParent_PartRev);
				tc_strdup("NA",&cchildParent_PartSeq);
				printf("\n (cchildParent_PartNo): [%s]\n", cchildParent_PartNo);fflush(stdout);
				printf("\n (cchildParent_PartRev): [%s]\n", cchildParent_PartRev);fflush(stdout);
			    printf("\n (cchildParent_PartSeq): [%s]\n", cchildParent_PartSeq);fflush(stdout);
			}
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			if(tc_strlen(cQuantity)>0)
			{
				tc_strdup(cQuantity,&cQuantityDup);
			}
			else
			{
				tc_strdup("NA",&cQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(cQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", cQuantityDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_object_type", &cSubObjType));
			if(tc_strlen(cSubObjType)>0)
			{
				tc_strdup(cSubObjType,&cSubObjTypeDup);
			}
			else
			{
				tc_strdup("NA",&cSubObjTypeDup);
				printf("\n Child Part Object Type Value is NULL");fflush(stdout);
			}
			printf("\n Child Part Object Type Value After Trim: [%s]", cSubObjTypeDup);fflush(stdout);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level Parent_Part_No: [%s]", cchildParent_PartNo);
			printf("\nChild_Level Parent_Part_Rev: [%s]", cchildParent_PartRev);
			printf("\nChild_Level Parent_Part_Seq: [%s]", cchildParent_PartSeq);
			printf("\nChild_Level Child_Part_No: [%s]", cItem_Id);
			printf("\nChild_Level Child_Part_Rev: [%s]", cItem_Rev);
			printf("\nChild_Level Child_Part_Seq: [%s]", cItem_Seq);
			printf("\nChild_Level Child_Part_QTY: [%s]", cQuantityDup);
			printf("\nChild_Level Child_Part_Object_Type: [%s]", cSubObjTypeDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cItem_Id)>0)
		    {
				fprintf(FP_OutputReport,"%s^%s^%s^%s^%s^%s^%s^%s^\n",cchildParent_PartNo,cchildParent_PartRev,cchildParent_PartSeq,cItem_Id,cItem_Rev,cItem_Seq,cQuantityDup,cSubObjTypeDup);fflush(FP_OutputReport);
			}
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			}
		}
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRS,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	/* char* ctopSubLevel = NULL;
	char* ctopSubMAddress = NULL;
	char* ctopSubMAddressDup = NULL;
	char* ctopSubMAdd = NULL; */
	char* ctopSubItem_Id = NULL;
	/* char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL; */
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopModAggr = NULL;
	char* ctopLowerVal = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	//char* ctopSubItem_Desc = NULL;
	char* ctopSubParentName = NULL;
	char* ctopSubParentNameDup = NULL;
	char* ctopSubQuantity = NULL;
	char* ctopSubQuantityDup = NULL;
	//char* ctopSubItem_LCDetails = NULL;
	//char* ctopSubItem_Level = NULL;
	//char* ctopSubProjCode = NULL;
	//char* ctopSubProjCodeDup = NULL;
	//char* ctopSubDesGrp = NULL;
	//char* ctopSubDesGrpDup = NULL;
	//tag_t PartMasterTag	= NULLTAG;
	//char *MstrUnitTag = NULL;
	//char *MstrUnitTagDup = NULL;
	char* ctopSubParent_PartNo = NULL;
	char* ctopSubParent_Remain = NULL;
	char* ctopSubParent_PartRev = NULL;
	char* ctopSubParent_PartSeq = NULL;
	char* ctopSubObjType = NULL;
	char* ctopSubObjTypeDup = NULL;
	
	PIE_scope_t scope;
    scope = PIE_TEAMCENTER;
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {
			
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		//ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		ITK_CALL(CFM_find("Latest Working", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",scope, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_formatted_parent_name", &ctopSubParentName));
			if(tc_strlen(ctopSubParentName)>0)
			{
				tc_strdup(ctopSubParentName,&ctopSubParentNameDup);
			}
			else
			{
				tc_strdup("NA",&ctopSubParentNameDup);
				printf("\n Parent Part Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubParentNameDup);
			printf("\n Parent Part Value After Trim: [%s]", ctopSubParentNameDup);fflush(stdout);
			
			if(tc_strcmp(ctopSubParentNameDup,"NA") !=0)
			{
				ctopSubParent_PartNo = tc_strtok(ctopSubParentNameDup,"/");
			    ctopSubParent_Remain = tc_strtok(NULL,"/");
				printf("\n (ctopSubParent_PartNo) After Token: [%s]\n", ctopSubParent_PartNo);fflush(stdout);
			    printf("\n (ctopSubParent_Remain) After Token: [%s]\n", ctopSubParent_Remain);fflush(stdout);
				ctopSubParent_PartRev = tc_strtok(ctopSubParent_Remain,";");
			    ctopSubParent_PartSeq = tc_strtok(NULL,";");
			    printf("\n (ctopSubParent_PartRev) After Token: [%s]\n", ctopSubParent_PartRev);fflush(stdout);
			    printf("\n (ctopSubParent_PartSeq) After Token: [%s]\n", ctopSubParent_PartSeq);fflush(stdout);
			}
			else
			{
				tc_strdup("NA",&ctopSubParent_PartNo);
				tc_strdup("NA",&ctopSubParent_PartRev);
				tc_strdup("NA",&ctopSubParent_PartSeq);
				printf("\n (ctopSubParent_PartNo): [%s]\n", ctopSubParent_PartNo);fflush(stdout);
				printf("\n (ctopSubParent_PartRev): [%s]\n", ctopSubParent_PartRev);fflush(stdout);
			    printf("\n (ctopSubParent_PartSeq): [%s]\n", ctopSubParent_PartSeq);fflush(stdout);
			}
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_quantity", &ctopSubQuantity));
			if(tc_strlen(ctopSubQuantity)>0)
			{
				tc_strdup(ctopSubQuantity,&ctopSubQuantityDup);
			}
			else
			{
				tc_strdup("NA",&ctopSubQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", ctopSubQuantityDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_object_type", &ctopSubObjType));
			if(tc_strlen(ctopSubObjType)>0)
			{
				tc_strdup(ctopSubObjType,&ctopSubObjTypeDup);
			}
			else
			{
				tc_strdup("NA",&ctopSubObjTypeDup);
				printf("\n Parent Part Object Type Value is NULL");fflush(stdout);
			}
			printf("\n Parent Part Object Type Value After Trim: [%s]", ctopSubObjTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Parent_Part_No: [%s]", ctopSubParent_PartNo);
			printf("\nTop_Level Parent_Part_Rev: [%s]", ctopSubParent_PartRev);
			printf("\nTop_Level Parent_Part_Seq: [%s]", ctopSubParent_PartSeq);
			printf("\nTop_Level Child_Part_No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Child_Part_Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Child_Part_Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Child_Part_QTY: [%s]", ctopSubQuantityDup);
			printf("\nTop_Level Child_Part_Object_Type: [%s]", ctopSubObjTypeDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubParent_PartNo)>0)
		    {
				if(tc_strcmp(ctopSubParent_PartNo,"NA")!=0)
				{
				   fprintf(VehRpt,"%s^%s^%s^%s^%s^%s^%s^%s^\n",ctopSubParent_PartNo,ctopSubParent_PartRev,ctopSubParent_PartSeq,ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubQuantityDup,ctopSubObjTypeDup);fflush(VehRpt);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	char *RptFile1 = (char *) malloc(100*sizeof(char));
	FILE *ExpOutput_file = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *item_revseq_strdup = (char *) malloc(20*sizeof(char));
	tag_t DesRev_tag = NULLTAG;
	char* tceinp_file_str = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	item_id_str = ITK_ask_cli_argument("-Part=");
	item_rev_str = ITK_ask_cli_argument("-Rev=");
	item_seq_str = ITK_ask_cli_argument("-Seq=");
	tceinp_file_str = ITK_ask_cli_argument("-File=");
	
	trimwhitespace(item_id_str);
	trimwhitespace(item_rev_str);
	trimwhitespace(item_seq_str);
	if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
	if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
	if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);

	printf(" [1]: Input Part No(item_id_strDup): [%s]\n",item_id_strDup);
	printf(" [2]: Input Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
	printf(" [3]: Input Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
	printf(" [4]: TCE Input File(tceinp_file_str): [%s]\n",tceinp_file_str);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	tc_strcpy(item_revseq_strdup,item_rev_strDup);
	tc_strcat(item_revseq_strdup,"*");
	tc_strcat(item_revseq_strdup,item_seq_strDup);
	printf(" Final: Part_Rev_Seq Value(item_revseq_strdup): [%s]\n",item_revseq_strdup);
	
	printf("\n Generating Final Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"CATIA_Data_Validation_Checker_Report");
	//tc_strcpy(RptFile,"/tmp/");
	//tc_strcat(RptFile,"CATIA_Data_Validation_Checker");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,item_id_strDup);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,item_rev_strDup);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,item_seq_strDup);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Final Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Final Report File Name Generated..!!");fflush(stdout);
	
	printf("\n Generating TCUA BOM Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile1,"TCUA_EBOM_Report");
	//tc_strcpy(RptFile1,"/tmp/");
	//tc_strcat(RptFile1,"TCUA_EBOM_Report");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,item_id_strDup);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,item_rev_strDup);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,item_seq_strDup);
	tc_strcat(RptFile1,".txt");
	printf("\n TCUA BOM Report File Name: [%s]", RptFile1);fflush(stdout);
	printf("\n TCUA BOM Report File Name Generated..!!");fflush(stdout);
	
	printf("\n Finding Query[DesignRevision Sequence]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","ID"};
		char *cValues[2]  = {item_revseq_strdup,item_id_strDup};
		//char *cValues[2]  = {"A*2","51780353R"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				DesRev_tag = titemobj_results[i];
				ExpOutput_file = fopen(RptFile1, "w");
				if(ExpOutput_file == NULL)
				{
					printf("\n Unable to Create Part Expansion[99 Level] Report File: --------> [%s]",ExpOutput_file);fflush(stdout);
					return 0;
				}
				printf("\n Function1: Parts[99 Level] Child Details Find Start");fflush(stdout);
				TC_VehChild_Details(item_id_strDup,item_revseq_strdup,ExpOutput_file);
			    printf("\n Function1: Parts[99 Level] Child Details Find End\n");fflush(stdout);
				fclose(ExpOutput_file);
			}
		}
		else
        {
			printf(" Revision Found Zero[0] on DesignRevision Sequence Query..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
    }
	
	printf("\n TCE-TCUA Checker Final Started..!!\n");fflush(stdout);
	FILE* fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, [TCE-TCUA BOM CHECKER REPORT] ,,,,");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, TC_Part_No: [%s]",item_id_strDup);fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, TC_Part_Rev: [%s]",item_rev_strDup);fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, TC_Part_Seq: [%s]",item_seq_strDup);fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Revision_Rule: [%s]","Latest Working");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Closure_Rule: [%s]","BOMViewClosureRuleERC");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Report_TimeStamp: [%s]",GenDate);fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(fpOutput_file);
    fprintf(fpOutput_file,"PARENT_PART_NO, PARENT_PART_REV, PARENT_PART_SEQ, CHILD_PART_NO, CHILD_PART_REV, CHILD_PART_SEQ, STATUS, QTY_MISMATCH, BVR_MISSING, CREATED_AS_ITEM, REVISION_MISMATCH, TCUA_EXTRA_CHILDS, UOM_MISMATCH\n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
    FILE* fptcefile = fopen(tceinp_file_str, "r");
    if(fptcefile == NULL)
    {
        printf("\n Unable To Open TCE EBOM File: --------> [%s]",tceinp_file_str);fflush(stdout);
        return 0;
    }
    else 
    { 
        char buffer2[1024];
        while(fgets(buffer2,1024,fptcefile)) 
        {
            char* tceparentpart = tc_strtok(buffer2, "^");
			char* tceparentrev = tc_strtok(NULL, "^");
            char* tceparentseq = tc_strtok(NULL, "^");
            char* tcechldpart = tc_strtok(NULL, "^");
			char* tcechldrev = tc_strtok(NULL, "^");
			char* tcechldseq = tc_strtok(NULL, "^");
			char* tcechldqty = tc_strtok(NULL, "^");
			char* tcechlduom = tc_strtok(NULL, "^");
            int tcechldqtynew = atoi(tcechldqty);
			
            FILE* fptcuafile = fopen(RptFile1, "r");
            if(fptcuafile == NULL)
			{
				printf("\n Unable To Open TCUA EBOM File: --------> [%s]",RptFile1);fflush(stdout);
				return 0;
			}
            else 
            { 
                char buffer3[1024];
                while(fgets(buffer3,1024,fptcuafile)) 
                {
                   char* tcuaparentpart = tc_strtok(buffer3, "^");
				   char* tcuaparentrev = tc_strtok(NULL, "^");
				   char* tcuaparentseq = tc_strtok(NULL, "^");
				   char* tcuachldpart = tc_strtok(NULL, "^");
				   char* tcuachldrev = tc_strtok(NULL, "^");
				   char* tcuachldseq = tc_strtok(NULL, "^");
				   char* tcuachldqty = tc_strtok(NULL, "^");
				   char* tcuachldtype= tc_strtok(NULL, "^");
				   char* tcuachlduom_tag = tc_strtok(NULL, "^");
				   char* tcuachlduom1 = tc_strtok(NULL, "^");
				   char* tcuachlduom2 = tc_strtok(NULL, "^");
				   int tcuachldqtynew = atoi(tcuachldqty);
				   
                   if(tc_strcmp(FIItemNo,FItemNo) == 0)
                   {
                     if(FItemQtyNew > 0)
                     {
                        fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%.5f\n", FItemLvl, FItemNo, FItemRev, FItemSeq, FItemDesc, FItemProjCode, FItemDesGrp, FItemUOM, FItemArDr, FItemType, FItemLC, FItemParent, FItemQtyNew);fflush(fpOutput_file);
                     }
                   }
                }
            }
            fclose(fptcuafile);
        }
    }
    fclose(fptcefile);
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
    fclose(fpOutput_file); 
	printf("\n TCE-TCUA Checker Final Ended..!!\n");fflush(stdout);
		
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_TCUABOMCheck.c
* // ./linkitk -o tm_TCUABOMCheck tm_TCUABOMCheck.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/CATIA_Data_Validation_Checker/tm_TCUABOMCheck .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/CATIA_Data_Validation_Checker/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/CATIA_Data_Validation_Checker/usage.txt .
* // ./tm_TCUABOMCheck -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Part="51780353R" -Rev=A -Seq=2 -File="TCE_EBOM_Report.txt"
* // ./tm_TCUABOMCheck -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Part="51780353R" -Rev=A -Seq=2 -File="TCE_EBOM_Report.txt"
*
***************************************************************************/