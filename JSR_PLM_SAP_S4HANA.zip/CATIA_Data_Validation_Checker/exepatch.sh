$TC_ROOT/*Patch*/tcPatchExecutable tm_TCUABOMCheck
