./compile tm_TCUABOMCheck.c
./linkitk -o tm_TCUABOMCheck tm_TCUABOMCheck.o
chmod 777 tm_TCUABOMCheck*
