./compile control_object.c
./linkitk -o control_object control_object.o
chmod 777 *
