#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
//#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>


#include <tc/tc_startup.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int i_row_cnt = 0;
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

int Create_workspace_TCT_ctrl_object( char *t5_Syscd,char *t5_SubSyscd,char *t5_Userinfo1,char *t5_Userinfo2, char *t5_Userinfo3, char *t5_Userinfo4 )
{
	int retcode               = ITK_ok;


	tag_t tItemRevTag         = NULLTAG;
	tag_t tItemTag            = NULLTAG;

	tag_t tItemTypeTag        = NULLTAG;
	tag_t tItemCreateInputTag = NULLTAG;


    TCTYPE_find_type ( "T5_ControlObject", NULL, &tItemTypeTag ) ;
    TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ;
    TC_write_syslog("find the item type Item \n");


	if ( retcode == ITK_ok && tItemCreateInputTag != NULLTAG )
	{
		AOM_set_value_string ( tItemCreateInputTag, "object_name", t5_Syscd ) ;
		//AOM_set_value_string ( tItemCreateInputTag, "item_id", tct_item_id ) ;
		AOM_set_value_string ( tItemCreateInputTag, "object_desc", "Platform control object" ) ;
		AOM_set_value_string ( tItemCreateInputTag, "t5_Syscd", t5_Syscd ) ;
		AOM_set_value_string ( tItemCreateInputTag, "t5_SubSyscd", t5_SubSyscd ) ;
		AOM_set_value_string ( tItemCreateInputTag, "t5_Userinfo1", t5_Userinfo1 ) ;
		AOM_set_value_string ( tItemCreateInputTag, "t5_Userinfo2", t5_Userinfo2 ) ;
		AOM_set_value_string ( tItemCreateInputTag, "t5_Userinfo3", t5_Userinfo3 ) ;
		AOM_set_value_string ( tItemCreateInputTag, "t5_Userinfo4", t5_Userinfo4 ) ;


		TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ;

		if ( retcode == ITK_ok && tItemTag != NULLTAG )
		{
			AOM_save_without_extensions ( tItemTag ) ;
			AOM_unlock ( tItemTag ) ;

			//t5_platform_ctrl_obj_Load ( tItemTag,tct_item_id ) ;
		}
	}
 
 return 0;


}
extern int ITK_user_main(int argc, char** argv)
{
	char *item_no = NULL;
	char *s_row_cnt = NULL;
	char *tct_item_id = NULL;
	char *t5_Syscd = NULL;
	char *t5_SubSyscd = NULL;
	char *t5_Userinfo1 = NULL;
	char *t5_Userinfo2 = NULL;
	char *t5_Userinfo3 = NULL;
	char *t5_Userinfo4 = NULL;
	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	t5_Syscd = ITK_ask_cli_argument( "-s=" );
	t5_SubSyscd = ITK_ask_cli_argument( "-b=" );
	t5_Userinfo1 = ITK_ask_cli_argument( "-i1=" );
	t5_Userinfo2 = ITK_ask_cli_argument( "-i2=" );
	t5_Userinfo3 = ITK_ask_cli_argument( "-i3=" );
	t5_Userinfo4 = ITK_ask_cli_argument( "-i4=" );
	
	//enter number of objects to be loaded from file
	//Create_workspace_TCT_ctrl_object( tct_item_id ) ;
	Create_workspace_TCT_ctrl_object( t5_Syscd,t5_SubSyscd,t5_Userinfo1,t5_Userinfo2,t5_Userinfo3,t5_Userinfo4 );
	//print_table_property_ws_object ( tct_item_id ) ;
	//Load_tbl_pr_ws_obj_to_TCTRevTble ( "X4", "TCT-5445-000144" ) ;
	ITK_CALL(POM_logout ( false ) ) ;
	return 0;
}
