./compile tm_InputVehicleCompareReport.c
./linkitk -o tm_InputVehicleCompareReport tm_InputVehicleCompareReport.o
chmod 777 tm_InputVehicleCompareReport*
