/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   MCC Library & System Data Compare Report
*  File Name    :   tm_Libandsystemdatacompare.c
*  Created on   :   March 04, 2025
*  Usage        :   tm_Libandsystemdatacompare
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     04/03/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char [], int);

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_SystemProductLineStatus(char* InpModNo, char* InpPartType)
{
	//trimwhitespace(InpModNo);
	//trimwhitespace(InpPartType);
	char* SysResSubModProdStat = NULL;
	char* SysPLine = NULL;
	char* SysPLineDup = NULL;
	printf("\n ProductLine Check Started..!!\n");fflush(stdout);
	tag_t tSysProdLineobj = NULLTAG;
	tag_t* tSysProdLineobj_results = NULLTAG;
	int n_sysprodlinepathentries = 4;
	int n_sysprodline_obj_found = 0;
	ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tSysProdLineobj));
	printf("\n Query[MCC_ERC_Released_Latest_Revision] Tag Found Successfully...!!\n");
	char *cSysProdLineEntries[4]  = {"Item ID","Release Status","Part Type","Type"};
	char *cSysProdLineValues[4]  = {InpModNo,"T5_LcsErcRlzd",InpPartType,"Design Revision"};
	ITK_CALL(QRY_execute(tSysProdLineobj, n_sysprodlinepathentries, cSysProdLineEntries, cSysProdLineValues, &n_sysprodline_obj_found, &tSysProdLineobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Object Found: [%d]\n",n_sysprodline_obj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_sysprodline_obj_found > 0)
	{
		printf("\n Object Found..!!\n");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tSysProdLineobj_results[0], "t5_Product", &SysPLine));
		trimwhitespace(SysPLine);
	    if(SysPLine!=NULL)tc_strdup(SysPLine,&SysPLineDup);
		if(tc_strlen(SysPLineDup)>0)
		{
			tc_strdup(SysPLineDup,&SysResSubModProdStat);
		}
		else
		{
			tc_strdup("NOTFOUND",&SysResSubModProdStat);
		}	
	}
	else
	{
		tc_strdup("NOTFOUND",&SysResSubModProdStat);
		printf("\n As Object Not Found So, Taking ProductLine As NOTFOUND Case...");fflush(stdout);
	}
	printf("\n ProductLine Check Ended..!!\n");fflush(stdout);
	return SysResSubModProdStat;	
}

char* TC_SubModuleProductLineStatus(char* InpModAddr,char* InpModNo)
{
	
	trimwhitespace(InpModAddr);
	trimwhitespace(InpModNo);
	char* ResSubModProdStat = NULL;
	char* PLine = NULL;
	char* PLineDup = NULL;
	printf("\n ProductLine Check Started..!!\n");fflush(stdout);
	tag_t tProdLineobj = NULLTAG;
	tag_t* tProdLineobj_results = NULLTAG;
	int n_prodlinepathentries = 3;
	int n_prodline_obj_found = 0;
	ITK_CALL(QRY_find2("SubModuleLibraryTableDetails_Vehicle_Linked",&tProdLineobj));
	printf("\n Query[SubModuleLibraryTableDetails_Vehicle_Linked] Tag Found Successfully...!!\n");
	char *cProdLineEntries[3]  = {"ID","SubModule No","Vehicle Linked?"};
	char *cProdLineValues[3]  = {InpModAddr,InpModNo,"Yes"};
	ITK_CALL(QRY_execute(tProdLineobj, n_prodlinepathentries, cProdLineEntries, cProdLineValues, &n_prodline_obj_found, &tProdLineobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Object Found: [%d]\n",n_prodline_obj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_prodline_obj_found > 0)
	{
		printf("\n Vehicle Linked Object Found..!!\n");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tProdLineobj_results[0], "t5_productline", &PLine));
		trimwhitespace(PLine);
	    if(PLine!=NULL)tc_strdup(PLine,&PLineDup);
		if(tc_strlen(PLineDup)>0)
		{
			tc_strdup(PLineDup,&ResSubModProdStat);
		}
		else
		{
			tc_strdup("NOTFOUND",&ResSubModProdStat);
		}	
	}
	else
	{
		tc_strdup("NOTFOUND",&ResSubModProdStat);
		printf("\n As Vehcile Link Object Not Found So, Taking ProductLine As NOTFOUND Case...");fflush(stdout);
	}
	printf("\n ProductLine Check Ended..!!\n");fflush(stdout);
	return ResSubModProdStat;	
}

char* TC_SubModuleVehicleLinkStatus(char* InpModAddr,char* InpModNo)
{
	
	trimwhitespace(InpModAddr);
	trimwhitespace(InpModNo);
	char* ResSubModStat = NULL;
	printf("\n Query Check Started..!!\n");fflush(stdout);
	tag_t tVehLinkobj = NULLTAG;
	tag_t* tVehLinkobj_results = NULLTAG;
	int n_vehlinkpathentries = 3;
	int n_vehlink_obj_found = 0;
	ITK_CALL(QRY_find2("SubModuleLibraryTableDetails_Vehicle_Linked",&tVehLinkobj));
	printf("\n Query[SubModuleLibraryTableDetails_Vehicle_Linked] Tag Found Successfully...!!\n");
	char *cVehLinkEntries[3]  = {"ID","SubModule No","Vehicle Linked?"};
	char *cVehLinkValues[3]  = {InpModAddr,InpModNo,"Yes"};
	ITK_CALL(QRY_execute(tVehLinkobj, n_vehlinkpathentries, cVehLinkEntries, cVehLinkValues, &n_vehlink_obj_found, &tVehLinkobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Object Found: [%d]\n",n_vehlink_obj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_vehlink_obj_found > 0)
	{
		printf("\n Vehicle Linked Object Found..!!\n");fflush(stdout);
		tc_strdup("LINK",&ResSubModStat);
	}
	else
	{
		tc_strdup("NOTLINK",&ResSubModStat);
		printf("\n As Vehcile Link Object Not Found So, Taking As [NOTLINK] Case...\n");fflush(stdout);
	}
	printf("\n Query Check Ended..!!\n");fflush(stdout);
	return ResSubModStat;	
}

char* TC_ModuleAddrStatus(char* InpModAddr)
{
	
	trimwhitespace(InpModAddr);
	char* ResModAdd = NULL;
	char* Info1 = NULL;
	char* Info2 = NULL;
	char* Info3 = NULL;
	char* Info4 = NULL;
	char* Info5 = NULL;
	char* Info6 = NULL;
	char* Info7 = NULL;
	char* Info8 = NULL;
	char* Info9 = NULL;
	char* Info10 = NULL;
	char* Fundesresponse = NULL;
	Fundesresponse = (char *) malloc(2000*sizeof(char ));
	printf("\n Control Object Check Started..!!\n");fflush(stdout);
	tag_t tCtrlobj = NULLTAG;
	tag_t* tPathctrlobj_results = NULLTAG;
	int n_pathentries = 4;
	int n_path_ctrlobj_found = 0;
	ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
	printf("\n Control Object Query Tag Found Successfully...!!\n");
	char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
	char *cPathValues[4]  = {"MCCInvalidAdd","MCCInvalidAddSub","MCCInvalidAddCntObj","0"};
	ITK_CALL(QRY_execute(tCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tPathctrlobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Control Object Found: [%d]\n",n_path_ctrlobj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_path_ctrlobj_found > 0)
	{
		printf("\n Control Object Found..!!\n");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo1", &Info1));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo2", &Info2));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo3", &Info3));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo4", &Info4));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo5", &Info5));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo6", &Info6));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo7", &Info7));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo8", &Info8));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo9", &Info9));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_userinfo10", &Info10));
		tc_strcpy(Fundesresponse,Info1);
		tc_strcat(Fundesresponse,Info2);
		tc_strcat(Fundesresponse,Info3);
		tc_strcat(Fundesresponse,Info4);
		tc_strcat(Fundesresponse,Info5);
		tc_strcat(Fundesresponse,Info6);
		tc_strcat(Fundesresponse,Info7);
		tc_strcat(Fundesresponse,Info8);
		tc_strcat(Fundesresponse,Info9);
		tc_strcat(Fundesresponse,Info10);
		printf("\n Concatinated Module_Address: --------> [%s]\n",Fundesresponse);fflush(stdout);
		if(tc_strstr(Fundesresponse,InpModAddr) != NULL)
		{
			tc_strdup("INVALID",&ResModAdd);
		}
		else
		{
			tc_strdup("VALID",&ResModAdd);
		}
	}
	else
	{
		tc_strdup("VALID",&ResModAdd);
		printf("\nControl Object Not Found So, Taking As Valid Case...");fflush(stdout);
	}
	
	return ResModAdd;	
}

char* TC_MonthName(int monno)
{
	char *monname = NULL;
	switch(monno) 
	{
        case 1 : 
                tc_strdup("Jan",&monname);				
				break;
        case 2 : 
				tc_strdup("Feb",&monname);
          		break;
        case 3 : 
				tc_strdup("Mar",&monname);
				break;
        case 4 : 
                tc_strdup("Apr",&monname);				
				break;
        case 5 : 
				tc_strdup("May",&monname);
				break;
        case 6 : 
				tc_strdup("Jun",&monname);
				break;
        case 7 : 
				tc_strdup("Jul",&monname);
				break;
        case 8 : 
				tc_strdup("Aug",&monname);
				break;
        case 9 : 
                tc_strdup("Sep",&monname);				
				break;
        case 10 : 
				tc_strdup("Oct",&monname);
				break;
        case 11 : 
                tc_strdup("Nov",&monname);				
				break;
        case 12 : 
				tc_strdup("Dec",&monname);
				break;
        default : printf("Input Number is Wrong..!!\n");
    }
	
   return monname;
}

char* TC_LeapYrChk(int yrno)
{
   char *leapstatus = NULL;
    if((yrno%4==0) && ((yrno%400==0) || (yrno%100!=0)))  
    {  
        tc_strdup("yes",&leapstatus);
    } 
	else 
	{  
        tc_strdup("no",&leapstatus); 
    }  
   return leapstatus;
}

int TC_CVDS2()
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int k = 0;
	tag_t tsubmodlib_rev = NULLTAG;
	char *SubModAddr_Str = NULL;
	char *SubModAddr_StrDup = NULL;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	char *LbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fplb_file = NULL;
	char *MstrLbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fmstrplb_file = NULL;
	char *Tbl_SubModVehLink = NULL;
	char *Tbl_SubModVehLinkDup = NULL;
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Submodule Library Report File Name..!!");fflush(stdout);
	//tc_strcpy(LbRptFile,"/tmp/");
	tc_strcpy(LbRptFile,"LibrarySystemCompareFile");
	tc_strcat(LbRptFile,"_");
	tc_strcat(LbRptFile,GenDate);
	tc_strcat(LbRptFile,".csv");
	printf("\n Submodule Library Report File Name: [%s]", LbRptFile);fflush(stdout);
	printf("\n Submodule Library Report File Generated..!!");fflush(stdout);
	
	fplb_file = fopen(LbRptFile, "w");
	//fmstrplb_file = fopen(MstrLbRptFile, "w");
	fprintf(fplb_file,"PART_NO, VEHICLE_LINK, LIBRARY_PRODUCTLINE_STRING, SYSTEM_PRODUCTLINE\n");fflush(fplb_file);
	printf("\n Submodule Library Report Report File Generated..!!");fflush(stdout);
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\nSubModule Address Revision Found..!!\n");fflush(stdout);
			for(k = 0; k < n_itemobj_found; k++)
			{
				tsubmodlib_rev = titemobj_results[k];
				ITK_CALL(AOM_ask_value_string(tsubmodlib_rev,"item_id",&SubModAddr_Str));
				trimwhitespace(SubModAddr_Str);
				if(SubModAddr_Str!=NULL)tc_strdup(SubModAddr_Str,&SubModAddr_StrDup);
				ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
				printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SubModAddr_StrDup);fflush(stdout);
				if(n_valid_rows>0)
				{
					int iValCnt=0;
					for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
					{
						char* Tbl_SubModNo = NULL;
						char* Tbl_SubModNodup = NULL;
						char* Tbl_SubModProd = NULL;
						char* Tbl_SubModProddup = NULL;
						char *Tbl_Str_SubModProd = NULL;
	                    char *Tbl_Str_SubModProdDup = NULL;
						printf("\n [Start] Printing of Table Row: [%d]\n",iValCnt);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_Str_SubModProd));
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_VehLink",&Tbl_SubModVehLink));
						//ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_Platform",&Tbl_SubModProd));
						
						printf("\n SubFunction: System Product Line Status Find Start");fflush(stdout);
                        Tbl_SubModProd = TC_SystemProductLineStatus(Tbl_SubModNo,"M");
                        printf("\n SubFunction: System Product Line Status Find End");fflush(stdout);
						
						trimwhitespace(Tbl_SubModNo);
						trimwhitespace(Tbl_SubModProd);
						trimwhitespace(Tbl_SubModVehLink);
						if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
						if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
						if(Tbl_SubModVehLink!=NULL)tc_strdup(Tbl_SubModVehLink,&Tbl_SubModVehLinkDup);
						if((tc_strlen(Tbl_SubModNodup)>0) && (tc_strcmp(Tbl_SubModVehLinkDup,"Yes")==0))
						{
						  fprintf(fplb_file,"%s,%s,%s,%s\n",Tbl_SubModNodup,Tbl_SubModVehLinkDup,Tbl_Str_SubModProd,Tbl_SubModProddup);fflush(fplb_file);
						}  
						printf("\n [End] Printing of Table Row: [%d]",iValCnt);fflush(stdout);
					}
				}
				else
				{
					printf("\n No Table Row Found Zero For Input SubModule Address: [%s]\n", SubModAddr_StrDup);fflush(stdout);
				}
			}				
		}
		else
		{
		   printf("\n SubModule Address Revision Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
	}
	fclose(fplb_file);
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	char STDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	strftime(STDate,100,"%d %b, %Y (%A)",&when);
	printf(" Stylesheet TimeStamp: [%s]\n", STDate);fflush(stdout);

	printf(" Input_File Not Null..!!\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222222222222222222222222222222222222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function2: TCUA-CV Data Sheet2 Print Start");fflush(stdout);
	TC_CVDS2();
	printf("\n Function2: TCUA-CV Data Sheet2 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222222222222222222222222222222222222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);		
	printf("\n All Details Written Successfully on the XML File....\n");fflush(stdout);

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_Libandsystemdatacompare.c
* // ./linkitk -o tm_Libandsystemdatacompare tm_Libandsystemdatacompare.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/LibAndSystemDataCompare/tm_Libandsystemdatacompare .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/LibAndSystemDataCompare/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/LibAndSystemDataCompare/PartList.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/LibAndSystemDataCompare/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/LibAndSystemDataCompare/SendEmail.sh .
* // ./tm_Libandsystemdatacompare -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_Libandsystemdatacompare -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_Libandsystemdatacompare -u=infodba -p=loader123 -g=dba
*
***************************************************************************/