/user/cvprod/sourav/LibAndSystemDataCompare/tm_Libandsystemdatacompare -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
