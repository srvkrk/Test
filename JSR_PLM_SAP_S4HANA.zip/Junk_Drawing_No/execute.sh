/user/cvprod/sourav/Junk_Drawing_No/tm_junk_drawing_no -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Type="M"
