/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query All Design Revision Details & Print its Drawing No Properties on Reports  
*  File Name    :   tm_junk_drawing_no.c
*  Created on   :   March 24th, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     24/03/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t revTag = NULLTAG;
	char *preitem_id_str   = NULL;
	char *preitem_id_strDup  = NULL;
	tag_t tNextItemobj = NULLTAG;
	int n_nextentries = 3;
	int n_nextitemobj_found = 0;
	tag_t* tnextitemobj_results = NULLTAG;
	int j = 0;
	tag_t nextrevTag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *item_drw_str = NULL;
	char *item_drw_strDup = NULL;
	char *inp_parttype_str = NULL;
	char *item_mod_desc = NULL;
	char *item_mod_descDup = NULL;
	char *item_modname_str = NULL;
	char *item_modname_strDup = NULL;
	char *item_drwind_str = NULL;
	char *item_drwind_strDup = NULL;
	char *item_srfcstd_str = NULL;
	char *item_srfcstd_strDup = NULL;
	char *item_mat_str = NULL;
	char *item_mat_strDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
    inp_parttype_str = ITK_ask_cli_argument("-Type=");
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf("\n Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Junk_Drawing_No_Report");
	//tc_strcat(RptFile,"_");
	//tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n CSV Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n CSV Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"PART_NO, REVISION, SEQUENCE, DRAWING_NO, MODIFICATION_DESC, MODULE_NAME, DRAWING_INDICATOR, SURFACE_PROTECTION_STD, PART_MATERIAL\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create CSV Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	printf("\n Finding Query[MCC_ERC_Released_Latest_Revision]..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query MCC_ERC_Released_Latest_Revision Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Item ID","Type","Part Type"};
		char *cValues[3]  = {"*","Design Revision",inp_parttype_str};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total MCC_ERC_Released_Latest_Revision Object Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
			{
				revTag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(revTag,"item_id",&preitem_id_str));
				if(tc_strlen(preitem_id_str)>0)
				{
					tc_strdup(preitem_id_str,&preitem_id_strDup);
				}
				else
				{
					tc_strdup(" ",&preitem_id_strDup);
					printf("\n Part_No Value is NULL..!!");fflush(stdout);
				}
			
				ITK_CALL(QRY_find2("Item Revision...",&tNextItemobj));
                if(tNextItemobj != NULLTAG)
                {
                    printf("\n Query[Item Revision...] Found Successfully..!!\n");fflush(stdout);
                    char *cNextEntries[3]  = {"Item ID","Revision","Type"};
                    char *cNextValues[3]  = {preitem_id_strDup,"*","Design Revision"};
                    //char *cNextValues[3]  = {"5020K1A0858001","*","Design Revision"};
                    ITK_CALL(QRY_execute(tNextItemobj, n_nextentries, cNextEntries, cNextValues, &n_nextitemobj_found, &tnextitemobj_results));
                    printf("\n -----------------------------------------------\n");fflush(stdout);
                    printf("\n No of Total Revision Found: [%d]\n",n_nextitemobj_found);fflush(stdout);
                    printf("\n -----------------------------------------------\n");fflush(stdout);
                    for (j = 0; j < n_nextitemobj_found; j++)
                    {
						nextrevTag = tnextitemobj_results[j];
						ITK_CALL(AOM_ask_value_string(nextrevTag,"item_id",&item_id_str));
						if(tc_strlen(item_id_str)>0)
						{
							tc_strdup(item_id_str,&item_id_strDup);
						}
						else
						{
							tc_strdup(" ",&item_id_strDup);
							printf("\n Final Part_No Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(nextrevTag,"item_revision_id",&Newitem_revseq_str));
						tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
						item_rev_str=strtok(Newitem_revseq_strDup,";");
						item_seq_str=strtok(NULL,";");
						if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
						if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
						
						ITK_CALL(AOM_ask_value_string(nextrevTag,"t5_DrawingNo",&item_drw_str));
						if(tc_strlen(item_drw_str)>0)
						{
							tc_strdup(item_drw_str,&item_drw_strDup);
						}
						else
						{
							tc_strdup(" ",&item_drw_strDup);
							printf("\n Final Drawing_No Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(nextrevTag,"t5_DocRemarks",&item_mod_desc));
						if(tc_strlen(item_mod_desc)>0)
						{
							tc_strdup(item_mod_desc,&item_mod_descDup);
							trimwhitespace(item_mod_descDup);
							printf("\n Item Description Value After Dup & Trim: [%s]", item_mod_descDup);fflush(stdout);
							STRNG_replace_str(item_mod_descDup,","," ",&item_mod_descDup);
							STRNG_replace_str(item_mod_descDup,";"," ",&item_mod_descDup);
							STRNG_replace_str(item_mod_descDup,"\n"," ",&item_mod_descDup);
							STRNG_replace_str(item_mod_descDup,"'"," ",&item_mod_descDup);
							printf("\n Item Description Final Value: [%s]", item_mod_descDup);fflush(stdout);
						}
						else
						{
							tc_strdup(" ",&item_mod_descDup);
							printf("\n Final Modification Description Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(nextrevTag,"t5_ModuleName",&item_modname_str));
						if(tc_strlen(item_modname_str)>0)
						{
							tc_strdup(item_modname_str,&item_modname_strDup);
							STRNG_replace_str(item_modname_strDup,","," ",&item_modname_strDup);
							STRNG_replace_str(item_modname_strDup,";"," ",&item_modname_strDup);
							STRNG_replace_str(item_modname_strDup,"\n"," ",&item_modname_strDup);
							STRNG_replace_str(item_modname_strDup,"'"," ",&item_modname_strDup);
						}
						else
						{
							tc_strdup(" ",&item_modname_strDup);
							printf("\n Final Module_Name Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(nextrevTag,"t5_DrawingInd",&item_drwind_str));
						if(tc_strlen(item_drwind_str)>0)
						{
							tc_strdup(item_drwind_str,&item_drwind_strDup);
						}
						else
						{
							tc_strdup(" ",&item_drwind_strDup);
							printf("\n Final Drawing Indicator Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(nextrevTag,"t5_SurfPrtStd",&item_srfcstd_str));
						if(tc_strlen(item_srfcstd_str)>0)
						{
							tc_strdup(item_srfcstd_str,&item_srfcstd_strDup);
							trimwhitespace(item_srfcstd_strDup);
							printf("\n Item Surface Protection Std Value After Dup & Trim: [%s]", item_srfcstd_strDup);fflush(stdout);
							STRNG_replace_str(item_srfcstd_strDup,","," ",&item_srfcstd_strDup);
							STRNG_replace_str(item_srfcstd_strDup,";"," ",&item_srfcstd_strDup);
							STRNG_replace_str(item_srfcstd_strDup,"\n"," ",&item_srfcstd_strDup);
							STRNG_replace_str(item_srfcstd_strDup,"'"," ",&item_srfcstd_strDup);
							printf("\n Item Surface Protection Std Final Value: [%s]", item_srfcstd_strDup);fflush(stdout);
						}
						else
						{
							tc_strdup(" ",&item_srfcstd_strDup);
							printf("\n Final Surface Protection Std Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(nextrevTag,"t5_Material",&item_mat_str));
						if(tc_strlen(item_mat_str)>0)
						{
							tc_strdup(item_mat_str,&item_mat_strDup);
							trimwhitespace(item_mat_strDup);
							printf("\n Item Part Material Value After Dup & Trim: [%s]", item_mat_strDup);fflush(stdout);
							STRNG_replace_str(item_mat_strDup,","," ",&item_mat_strDup);
							STRNG_replace_str(item_mat_strDup,";"," ",&item_mat_strDup);
							STRNG_replace_str(item_mat_strDup,"\n"," ",&item_mat_strDup);
							STRNG_replace_str(item_mat_strDup,"'"," ",&item_mat_strDup);
							printf("\n Item Part Material Final Value: [%s]", item_mat_strDup);fflush(stdout);
						}
						else
						{
							tc_strdup(" ",&item_mat_strDup);
							printf("\n Final Part Material Value is NULL..!!");fflush(stdout);
						}
						printf("\n  Part_No: [%s]\n",item_id_strDup);fflush(stdout);
						printf("\n  Part_Rev: [%s]\n",item_rev_strDup);fflush(stdout);
						printf("\n  Part_Seq: [%s]\n",item_seq_strDup);fflush(stdout);
						printf("\n  Drawing_No: [%s]\n",item_drw_strDup);fflush(stdout);
						printf("\n  Modification_Desc: [%s]\n",item_mod_descDup);fflush(stdout);
						printf("\n  Module_Name: [%s]\n",item_modname_strDup);fflush(stdout);
						printf("\n  Drawing_Indicator: [%s]\n",item_drwind_strDup);fflush(stdout);
						printf("\n  Surface_Protection_Std: [%s]\n",item_srfcstd_strDup);fflush(stdout);
						printf("\n  Part_Material: [%s]\n",item_mat_strDup);fflush(stdout);
					    fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,item_drw_strDup,item_mod_descDup,item_modname_strDup,item_drwind_strDup,item_srfcstd_strDup,item_mat_strDup);fflush(fpOutput_file);
                    }
                }
                else
				{
					printf("\n After Query Execution No Item Found..!!");fflush(stdout);
				}	
			}			
		}
		else
		{
			printf(" Item Found Zero[0] on MCC_ERC_Released_Latest_Revision..!!\n");fflush(stdout);
		}
	}
	else
	{
		printf(" MCC_ERC_Released_Latest_Revision Query Tag Not Found..!!\n");fflush(stdout);
	}
		
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_junk_drawing_no.c
* // ./linkitk -o tm_junk_drawing_no tm_junk_drawing_no.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Junk_Drawing_No/tm_junk_drawing_no .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Junk_Drawing_No/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Junk_Drawing_No/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/Junk_Drawing_No/SendEmail.sh .
* // ./tm_junk_drawing_no -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Type="M"
* // ./tm_junk_drawing_no -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Type="M"
*
***************************************************************************/
