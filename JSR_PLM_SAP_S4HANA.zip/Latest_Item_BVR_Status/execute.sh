/user/cvprod/sourav/Latest_Item_BVR_Status/tm_LatestRlzdItemBVRStatus -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
