/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Sub Module Similarity Reports on Input (Module Address)
*  File Name    :   tm_InpSubModSimilarityRpt.c
*  Created on   :   April 24th, 2025
*  Usage        :   tm_InpSubModSimilarityRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     24/04/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_PlantCS(char* PNum, char* PRev, char* PSeq, char* PlntCSName)
{
	tag_t tCSItemobj = NULLTAG;
	int n_csentries = 2;
	int n_csitemobj_found = 0;
	tag_t* tcsitemobj_results = NULLTAG;
	int t = 0;
	char *RlzStatusName = NULL;
	char *CSVal = NULL;
	char *CSValDup = NULL;
	tag_t CSRev_tag = NULLTAG;
	char *PRevSeq = (char *) malloc(10*sizeof(char));
	tc_strcpy(PRevSeq,PRev);
	tc_strcat(PRevSeq,"*");
	tc_strcat(PRevSeq,PSeq);
	printf("\n Part Rev&Seq(PRevSeq): [%s]\n",PRevSeq);
	
	ITK_CALL(QRY_find2("DesignRevision Sequence",&tCSItemobj));
	if(tCSItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
		char *cCSEntries[2]  = {"Revision","ID"};
		char *cCSValues[2]  = {PRevSeq,PNum};
		//char *cCSValues[2]  = {"A;2","5137D1D0270001_WE"};
		ITK_CALL(QRY_execute(tCSItemobj, n_csentries, cCSEntries, cCSValues, &n_csitemobj_found, &tcsitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_csitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_csitemobj_found > 0)
		{
			printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
			for (t = 0; t < n_csitemobj_found; t++)
			{
				CSRev_tag = tcsitemobj_results[t];
				ITK_CALL(AOM_ask_value_string(tcsitemobj_results[t],PlntCSName,&CSVal));
				if(tc_strlen(CSVal)>0)
				{
					tc_strdup(CSVal,&CSValDup);
				}
				else
				{
					tc_strdup("--",&CSValDup);
					printf("\n CS Value is NULL..!!");fflush(stdout);
				}
			}
		}
	}
	if(tc_strlen(CSVal)>0)
	{
	   tc_strdup(CSVal,&CSValDup);
	}
	else
	{
	   tc_strdup("-",&CSValDup);
	}
	return CSValDup;
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSeqSrch)
{
	
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char *Item_revseq = NULL;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[n];
				if(LC_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpLCQryobj_results[n],"release_status_list",&sRelStatus);
					printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						tc_strdup("--",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
					printf("\n Item Release Status After Dup & Trim: [%s]", sRelStatusDup);fflush(stdout);
					STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
					printf("\n Item Release Status Final Value: [%s]", sRelStatusDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&sRelStatusDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&sRelStatusDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&sRelStatusDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport, char* VNo, char* VRev, char* VSeq)
{
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cItem_Desc = NULL;
		char* cModAddress = NULL;
		char* cProdLine = NULL;
		char* cProdLineDup = NULL;
		char* cPlatform = NULL;
		char* cPlatformDup = NULL;
		char* cProjCode = NULL;
	    char* cProjCodeDup = NULL;
	    char* cDesGrp = NULL;
	    char* cDesGrpDup = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cQuantity = NULL;
		char* cQuantityDup = NULL;
	    tag_t PrtMstrTag = NULLTAG;
	    char *MstrUOMTag = NULL;
	    char *MstrUOMTagDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* LibStatus = NULL;
		char* LibRevStatus = NULL;
		char* LibSeqStatus = NULL;
		char* LibGateStatus = NULL;
		char* LibMaxGateStatus = NULL;
		char* LibVehLinkFreqStatus = NULL;
		int yescount = 0;
		int nocount = 0;
		int maxdrpasscount = 0;
		int maxdrfailcount = 0;
		int compliance = 0;
		int totalcount = 0;
		double finalcompliance;
		char total[10];
		char totalpresent[10];
		char totalnotpresent[10];
		char complianceper[10];
		char maxdrpasscountdup[10];
		char maxdrfailcountdup[10];
		int maxcompliance = 0;
		int allcompliance = 0;
		double maxdrfinalcompliance;
		double alldrfinalcompliance;
		char* totalpresentDup = NULL;
		char* totalnotpresentDup = NULL;
		char* maxdrpasscountdupfinal = NULL;
		char* maxdrfailcountdupfinal = NULL;
		char *PreVCompFile = (char *) malloc(100*sizeof(char));
		int slno = 1;
		char finalslno[10];
		char DTStamp[100] = "";
		time_t 	dtnow;
		struct 	tm dtwhen;
		time(&dtnow);
		dtwhen = *localtime(&dtnow);
		strftime(DTStamp,100,"%d_%b_%Y_%H_%M_%S",&dtwhen);
		printf(" Current TimeStamp: [%s]\n", DTStamp);fflush(stdout);
		char* cItemLevel = NULL;
		char* cItemLevelDup = NULL;
		char *AHDCS = NULL;
		char *DWDCS = NULL;
		char *JSRCS = NULL;
		char *LKNCS = NULL;
		char *PUNCS = NULL;
		char *SNDCS = NULL;
		char *PNRCS = NULL;
		char *CARCS = NULL;
		char *AHDCSVal = (char *) malloc(10*sizeof(char));
		char *DWDCSVal = (char *) malloc(10*sizeof(char));
		char *JSRCSVal = (char *) malloc(10*sizeof(char));
		char *LKNCSVal = (char *) malloc(10*sizeof(char));
		char *PUNCSVal = (char *) malloc(10*sizeof(char));
		char *SNDCSVal = (char *) malloc(10*sizeof(char));
		char *PNRCSVal = (char *) malloc(10*sizeof(char));
		char *CARCSVal = (char *) malloc(10*sizeof(char));
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
	        ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_level_starting_0", &cItemLevel));
			if(tc_strlen(cItemLevel)>0)
			{
				tc_strdup(cItemLevel,&cItemLevelDup);
			}
			else
			{
				tc_strdup("--",&cItemLevelDup);
				printf("\n Part Level Value is NULL");fflush(stdout);
			}
			trimwhitespace(cItemLevelDup);
			printf("\n Part Level Value After Dup & Trim: [%s]\n", cItemLevelDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			cItem_Desc = TC_PartDesc(cItem_Id,cItem_RevSeq);
			printf("\n Part Description Value: [%s]", cItem_Desc);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			if(tc_strlen(cQuantity)>0)
			{
				tc_strdup(cQuantity,&cQuantityDup);
			}
			else
			{
				tc_strdup("--",&cQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(cQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", cQuantityDup);fflush(stdout);
			
			ITK_CALL(ITEM_find_item(cItem_Id,&PrtMstrTag));
			if(PrtMstrTag != NULLTAG)
			{
			   ITK_CALL(AOM_UIF_ask_value(PrtMstrTag,"uom_tag",&MstrUOMTag));
			}
			if(MstrUOMTag!=NULL)
			{
				tc_strdup(MstrUOMTag,&MstrUOMTagDup);
			}
			else
			{
				tc_strdup("--",&MstrUOMTagDup);
				printf("\n Master Unit of Measure Tag[uom_tag] is NULL..!!\n");fflush(stdout);
			}
			printf("\n Master Unit of Measure Tag[uom_tag]: [%s]\n", MstrUOMTagDup);fflush(stdout);
				
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_ProjectCode", &cProjCode));
			if(tc_strlen(cProjCode)>0)
			{
				tc_strdup(cProjCode,&cProjCodeDup);
			}
			else
			{
				tc_strdup("--",&cProjCodeDup);
				printf("\n Project Code Value is NULL");fflush(stdout);
			}
			trimwhitespace(cProjCodeDup);
			printf("\n Project Code Value After Dup & Trim: [%s]\n", cProjCodeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("--",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			
			AHDCS = TC_PlantCS(cItem_Id,cItem_Rev,cItem_Seq,"t5_AhdMakeBuyIndicator");
			DWDCS = TC_PlantCS(cItem_Id,cItem_Rev,cItem_Seq,"t5_DwdMakeBuyIndicator");
			JSRCS = TC_PlantCS(cItem_Id,cItem_Rev,cItem_Seq,"t5_JsrMakeBuyIndicator");
			LKNCS = TC_PlantCS(cItem_Id,cItem_Rev,cItem_Seq,"t5_LkoMakeBuyIndicator");
			PUNCS = TC_PlantCS(cItem_Id,cItem_Rev,cItem_Seq,"t5_PunMakeBuyIndicator");
			SNDCS = TC_PlantCS(cItem_Id,cItem_Rev,cItem_Seq,"t5_SndMakeBuyIndicator");
			PNRCS = TC_PlantCS(cItem_Id,cItem_Rev,cItem_Seq,"t5_PnrMakeBuyIndicator");
			CARCS = TC_PlantCS(cItem_Id,cItem_Rev,cItem_Seq,"t5_CarMakeBuyIndicator");
			
			tc_strcpy(AHDCSVal,"");
		    tc_strcat(AHDCSVal,"AHD");
			//tc_strcpy(AHDCSVal,"AHD");
			tc_strcat(AHDCSVal,"~");
			tc_strcat(AHDCSVal,AHDCS);
			
			tc_strcpy(DWDCSVal,"");
			//tc_strcpy(DWDCSVal,"DWD");
			tc_strcat(DWDCSVal,"DWD");
			tc_strcat(DWDCSVal,"~");
			tc_strcat(DWDCSVal,DWDCS);
			
			tc_strcpy(JSRCSVal,"");
			//tc_strcpy(JSRCSVal,"JSR");
			tc_strcat(JSRCSVal,"JSR");
			tc_strcat(JSRCSVal,"~");
			tc_strcat(JSRCSVal,JSRCS);
			
			tc_strcpy(LKNCSVal,"");
			//tc_strcpy(LKNCSVal,"LKN");
			tc_strcat(LKNCSVal,"LKN");
			tc_strcat(LKNCSVal,"~");
			tc_strcat(LKNCSVal,LKNCS);
			
			tc_strcpy(PUNCSVal,"");
			//tc_strcpy(PUNCSVal,"PUN");
			tc_strcat(PUNCSVal,"PUN");
			tc_strcat(PUNCSVal,"~");
			tc_strcat(PUNCSVal,PUNCS);
			
			tc_strcpy(SNDCSVal,"");
			//tc_strcpy(SNDCSVal,"SND");
			tc_strcat(SNDCSVal,"SND");
			tc_strcat(SNDCSVal,"~");
			tc_strcat(SNDCSVal,SNDCS);
			
			tc_strcpy(PNRCSVal,"");
			//tc_strcpy(PNRCSVal,"PNR");
			tc_strcat(PNRCSVal,"PNR");
			tc_strcat(PNRCSVal,"~");
			tc_strcat(PNRCSVal,PNRCS);
			
			tc_strcpy(CARCSVal,"");
			//tc_strcpy(CARCSVal,"CAR");
			tc_strcat(CARCSVal,"CAR");
			tc_strcat(CARCSVal,"~");
			tc_strcat(CARCSVal,CARCS);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nParent_Part_No: [%s]", VNo);
			printf("\nParent_Part_Rev: [%s]", VRev);
			printf("\nParent_Part_Seq: [%s]", VSeq);
			printf("\nChild_Level: [%s]", cItemLevelDup);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Part Revision: [%s]", cItem_Rev);
			printf("\nChild_Level Part Sequence: [%s]", cItem_Seq);
			printf("\nChild_Level Part Description: [%s]", cItem_Desc);
			printf("\nChild_Level Project Code: [%s]", cProjCodeDup);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\nChild_Level Part Quantity: [%s]", cQuantityDup);
			printf("\nChild_Level UOM Tag: [%s]", MstrUOMTagDup);
			printf("\nChild_Level AHD CS String: [%s]", AHDCSVal);
			printf("\nChild_Level DWD CS String: [%s]", DWDCSVal);
			printf("\nChild_Level JSR CS String: [%s]", JSRCSVal);
			printf("\nChild_Level LKN CS String: [%s]", LKNCSVal);
			printf("\nChild_Level PUN CS String: [%s]", PUNCSVal);
			printf("\nChild_Level SND CS String: [%s]", SNDCSVal);
			printf("\nChild_Level PNR CS String: [%s]", PNRCSVal);
			printf("\nChild_Level CAR CS String: [%s]", CARCSVal);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if((tc_strcmp(cProjCodeDup,"1111")!=0) && (tc_strcmp(cPartTypeDup,"Dummy")!=0))
				{
					//if((tc_strcmp(AHDCS,"F")==0) || (tc_strcmp(AHDCS,"F30")==0) || (tc_strcmp(DWDCS,"F")==0) || (tc_strcmp(DWDCS,"F30")==0) || (tc_strcmp(JSRCS,"F")==0) || (tc_strcmp(JSRCS,"F30")==0) || (tc_strcmp(LKNCS,"F")==0) || (tc_strcmp(LKNCS,"F30")==0) || (tc_strcmp(PUNCS,"F")==0) || (tc_strcmp(PUNCS,"F30")==0) || (tc_strcmp(SNDCS,"F")==0) || (tc_strcmp(SNDCS,"F30")==0) || (tc_strcmp(PNRCS,"F")==0) || (tc_strcmp(PNRCS,"F30")==0) || (tc_strcmp(CARCS,"F")==0) || (tc_strcmp(CARCS,"F30")==0))
					//if((tc_strcmp(JSRCS,"F")==0) || (tc_strcmp(JSRCS,"F30")==0) || (tc_strcmp(LKNCS,"F")==0) || (tc_strcmp(LKNCS,"F30")==0) || (tc_strcmp(PUNCS,"F")==0) || (tc_strcmp(PUNCS,"F30")==0))
					//{
				      fprintf(FP_OutputReport,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",VNo,VRev,VSeq,cItemLevelDup,cItem_Id,cItem_Rev,cItem_Seq,cItem_Desc,cQuantityDup,MstrUOMTagDup,AHDCSVal,DWDCSVal,JSRCSVal,LKNCSVal,PUNCSVal,SNDCSVal,PNRCSVal,CARCSVal);fflush(FP_OutputReport);
					//}
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			//if(iNumber_SubChild > 0)
			//{
			//	printf("\n!!!!!!!!!! I N N E R  C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
			//	bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport,cItem_Id,cItem_Rev,cItem_Seq);
			//}
		}
		
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRev,char* VehicleSeq,char* VehicleRS,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Desc = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubModAddress = NULL;
	char* ctopSubProdLine = NULL;
	char* ctopSubProdLineDup = NULL;
	char* ctopSubPlatform = NULL;
	char* ctopSubPlatformDup = NULL;
	char* ctopSubProjCode = NULL;
	char* ctopSubProjCodeDup = NULL;
	char* ctopSubDesGrp = NULL;
	char* ctopSubDesGrpDup = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	char* ctopSubQuantity = NULL;
	char* ctopSubQuantityDup = NULL;
	tag_t PartMasterTag	= NULLTAG;
	char *MstrUnitTag = NULL;
	char *MstrUnitTagDup = NULL;
	char* ctopSubLevel = NULL;
	char* ctopSubLevelDup = NULL;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_level_starting_0", &ctopSubLevel));
			if(tc_strlen(ctopSubLevel)>0)
			{
				tc_strdup(ctopSubLevel,&ctopSubLevelDup);
			}
			else
			{
				tc_strdup("--",&ctopSubLevelDup);
				printf("\n Part Level Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubLevelDup);
			printf("\n Part Level Value After Dup & Trim: [%s]\n", ctopSubLevelDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ctopSubItem_Desc = TC_PartDesc(ctopSubItem_Id,ctopSubItem_RevSeq);
			printf("\n Part Description Value: [%s]", ctopSubItem_Desc);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_quantity", &ctopSubQuantity));
			if(tc_strlen(ctopSubQuantity)>0)
			{
				tc_strdup(ctopSubQuantity,&ctopSubQuantityDup);
			}
			else
			{
				tc_strdup("--",&ctopSubQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", ctopSubQuantityDup);fflush(stdout);
			
			ITK_CALL(ITEM_find_item(ctopSubItem_Id,&PartMasterTag));
			if(PartMasterTag != NULLTAG)
			{
			   ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&MstrUnitTag));
			}
			if(MstrUnitTag!=NULL)
			{
				tc_strdup(MstrUnitTag,&MstrUnitTagDup);
			}
			else
			{
				tc_strdup("--",&MstrUnitTagDup);
				printf("\n Master Unit of Measure Tag[uom_tag] is NULL..!!\n");fflush(stdout);
			}
			printf("\n Master Unit of Measure Tag[uom_tag]: [%s]\n", MstrUnitTagDup);fflush(stdout);
				
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_ProjectCode", &ctopSubProjCode));
			if(tc_strlen(ctopSubProjCode)>0)
			{
				tc_strdup(ctopSubProjCode,&ctopSubProjCodeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubProjCodeDup);
				printf("\n Project Code Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubProjCodeDup);
			printf("\n Project Code Value After Dup & Trim: [%s]\n", ctopSubProjCodeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Parent_Part: [%s]", Vehicle);
			printf("\nTop_Parent_Rev: [%s]", VehicleRev);
			printf("\nTop_Parent_Seq: [%s]", VehicleSeq);
			printf("\nTop_Level: [%s]", ctopSubLevelDup);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Description: [%s]", ctopSubItem_Desc);
			printf("\nTop_Level Project Code: [%s]", ctopSubProjCodeDup);
			printf("\nTop_Level Part Type: [%s]", ctopSubPartTypeDup);
			printf("\nTop_Level QTY: [%s]", ctopSubQuantityDup);
			printf("\nTop_Level UOM Tag: [%s]", MstrUnitTagDup);		
			printf("\n-------------------------------------------------------------------------\n");
			/* if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if((tc_strcmp(ctopSubProjCodeDup,"1111")!=0) && (tc_strcmp(ctopSubPartTypeDup,"Dummy")!=0))
				{
				   fprintf(VehRpt,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",Vehicle,VehicleRev,VehicleSeq,ctopSubLevelDup,ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubItem_Desc,ctopSubQuantityDup,MstrUnitTagDup);fflush(VehRpt);
				}
			} */
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt, Vehicle, VehicleRev, VehicleSeq);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 5;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	char *VCompFile = (char *) malloc(100*sizeof(char));
	char *AllSubModFile = (char *) malloc(100*sizeof(char));
	char *VFData = (char *) malloc(500*sizeof(char));
	tag_t DesRev_tag = NULLTAG;
	char *inp_modadd_str = NULL;
	char *inp_modadd_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str = NULL;
	char *item_drar_strDup = NULL;
	char *Veh_Desc = NULL;
	char *Veh_DescDup = NULL;
	char *vplat_str = NULL;
	char *vplat_strDup = NULL;
	char *inp_id_str = NULL;
	char *inp_rev_str = NULL;
	char *inp_seq_str = NULL;
	char *inp_email_str = NULL;
	char *inp_email_strDup = NULL;
	char *inp_finalmodadd_strdup = (char *) malloc(10*sizeof(char));
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *SubMod_Desc = NULL;
	char *SubMod_DescDup = NULL;
	char *SubModProd_str = NULL;
	char *SubModProd_strDup = NULL;
	char *SubMod_RelStatus = NULL;
	char *SubMod_RelStatusDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inp_modadd_str = ITK_ask_cli_argument("-Add=");
	//inp_email_str = ITK_ask_cli_argument("-Email=");
	
	trimwhitespace(inp_modadd_str);
	//trimwhitespace(inp_email_str);
	if(inp_modadd_str!=NULL)tc_strdup(inp_modadd_str,&inp_modadd_strDup);
	//if(inp_email_str!=NULL)tc_strdup(inp_email_str,&inp_email_strDup);
	
	printf(" [1]: Input Module Address(inp_modadd_strDup): [%s]\n",inp_modadd_strDup);
	//printf(" [2]: Input User Email(inp_email_strDup): [%s]\n",inp_email_strDup);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	tc_strcpy(inp_finalmodadd_strdup,"*");
	tc_strcat(inp_finalmodadd_strdup,inp_modadd_strDup);
	tc_strcat(inp_finalmodadd_strdup,"*");
	printf(" Final: Module Address(inp_finalmodadd_strdup): [%s]\n",inp_finalmodadd_strdup);
	
	printf("\n Generating All SubModules Report File Name..!!");fflush(stdout);
	//tc_strcpy(AllSubModFile,"/tmp/");
	//tc_strcat(AllSubModFile,"ALL_SUBMOUDLES_");
	tc_strcpy(AllSubModFile,"ALL_SUBMOUDLES_");
	tc_strcat(AllSubModFile,inp_modadd_strDup);
	tc_strcat(AllSubModFile,".txt");
	printf("\n All SubModules Report File Name: [%s]", AllSubModFile);fflush(stdout);
	printf("\n All SubModules Report File Name Generated..!!");fflush(stdout);
	FILE* fpallsubmod_file = fopen(AllSubModFile, "w");
	if(fpallsubmod_file == NULL)
	{
		printf("\n Unable to Create All Sub-Module Report File: --------> [%s]",fpallsubmod_file);fflush(stdout);
		return 0;
	}
	
	printf("\n Finding Query[MCC_ERC_Released_Latest_Revision]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n [MCC_ERC_Released_Latest_Revision] Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[5]  = {"Module Address","Item ID","Release Status","Part Type","Type"};
		char *cValues[5]  = {inp_finalmodadd_strdup,"??????????????","T5_LcsErcRlzd","M","Design Revision"};
		//char *cValues[5]  = {"*D1B21*","??????????????","T5_LcsErcRlzd","M","Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Module Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Queried Modules Found For Input Module Address..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
			    if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
					trimwhitespace(item_id_strDup);
				}
				else
			    {
					tc_strdup("--",&item_id_strDup);
					printf("\n Module Number Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
			    if(tc_strlen(item_revseq_str)>0)
				{
					tc_strdup(item_revseq_str,&item_revseq_strDup);
					trimwhitespace(item_revseq_strDup);
				}
				else
			    {
					tc_strdup("--",&item_revseq_strDup);
					printf("\n Module Revision Sequence Value is NULL..!!");fflush(stdout);
				}
				
				SubMod_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
				if(tc_strlen(SubMod_Desc)>0)
				{
					tc_strdup(SubMod_Desc,&SubMod_DescDup);
					trimwhitespace(SubMod_DescDup);
				}
				else
			    {
					tc_strdup("--",&SubMod_DescDup);
					printf("\n Module Description Value is NULL..!!");fflush(stdout);
				}
				printf("\n Module Description Value: [%s]", SubMod_DescDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Product",&SubModProd_str));
			    if(tc_strlen(SubModProd_str)>0)
				{
					tc_strdup(SubModProd_str,&SubModProd_strDup);
					trimwhitespace(SubModProd_strDup);
				}
				else
			    {
					tc_strdup("--",&SubModProd_strDup);
					printf("\n Module Product Line Value is NULL..!!");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&Newitem_revseq_str));
			    if(tc_strlen(Newitem_revseq_str)>0)
				{
					tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
					trimwhitespace(Newitem_revseq_strDup);
					item_rev_str=strtok(Newitem_revseq_strDup,";");
			        item_seq_str=strtok(NULL,";");
					if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			        if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
					trimwhitespace(item_rev_strDup);
					trimwhitespace(item_seq_strDup);
				}
				else
			    {
					tc_strdup("--",&Newitem_revseq_strDup);
					printf("\n [New]Module Revision Sequence Value is NULL..!!");fflush(stdout);
				}
				
				SubMod_RelStatus = TC_PartLCDetails(item_id_strDup,item_revseq_strDup);
				if(tc_strlen(SubMod_RelStatus)>0)
				{
					tc_strdup(SubMod_RelStatus,&SubMod_RelStatusDup);
					trimwhitespace(SubMod_RelStatusDup);
				}
				else
			    {
					tc_strdup("--",&SubMod_RelStatusDup);
					printf("\n Module Release Status Value is NULL..!!");fflush(stdout);
				}
				printf("\n Module Release Status Value: [%s]", SubMod_RelStatusDup);fflush(stdout);
				
				printf("\n  Module Address: [%s]\n",inp_modadd_strDup);fflush(stdout);
				printf("\n  Module Number: [%s]\n",item_id_strDup);fflush(stdout);
				printf("\n  Module Revision: [%s]\n",item_rev_strDup);fflush(stdout);
				printf("\n  Module Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
				printf("\n  Module Description: [%s]\n",SubMod_DescDup);fflush(stdout);
				printf("\n  Module ProductLine: [%s]\n",SubModProd_strDup);fflush(stdout);
				printf("\n  Module Release Status: [%s]\n",SubMod_RelStatusDup);fflush(stdout);
				
				fprintf(fpallsubmod_file,"%s^%s^%s^%s^%s^%s^%s^\n",inp_modadd_strDup,item_id_strDup,item_rev_strDup,item_seq_strDup,SubMod_DescDup,SubModProd_strDup,SubMod_RelStatusDup);fflush(fpallsubmod_file);
				
				char *SingleSubModFile = (char *) malloc(100*sizeof(char));
				printf("\n Generating Single Sub-Module Report File Name..!!");fflush(stdout);
				//tc_strcpy(SingleSubModFile,"/tmp/");
				//tc_strcat(SingleSubModFile,item_id_strDup);
				tc_strcpy(SingleSubModFile,item_id_strDup);
				tc_strcat(SingleSubModFile,"_");
				tc_strcat(SingleSubModFile,item_rev_strDup);
				tc_strcat(SingleSubModFile,"_");
				tc_strcat(SingleSubModFile,item_seq_strDup);
				tc_strcat(SingleSubModFile,".txt");
				printf("\n Generating Single Sub-Module Report File Name: [%s]", SingleSubModFile);fflush(stdout);
				printf("\n Single Sub-Module Report File Name Generated..!!");fflush(stdout);

				FILE* fpOutput_file = fopen(SingleSubModFile, "w");
				if(fpOutput_file == NULL)
				{
					printf("\n Unable to Create Single Sub-Module Report File: --------> [%s]",SingleSubModFile);fflush(stdout);
					return 0;
				}
				
				printf("\n Function1: Vehicle Child Details Find Start\n");fflush(stdout);
				TC_VehChild_Details(item_id_strDup,item_rev_strDup,item_seq_strDup,item_revseq_strDup,fpOutput_file);
			    printf("\n Function1: Vehicle Child Details Find End\n");fflush(stdout);
                fclose(fpOutput_file);			
			}
		}
		else
        {
			printf(" Module Found Zero[0] After MCC_ERC_Released_Latest_Revision Query..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Query[MCC_ERC_Released_Latest_Revision] Tag Not Found..!!\n");fflush(stdout);
    }
	printf(" Sub-Module Similarity Report Generation End..!!\n");fflush(stdout);
    fclose(fpallsubmod_file);	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_InpSubModSimilarityRpt.c
* // ./linkitk -o tm_InpSubModSimilarityRpt tm_InpSubModSimilarityRpt.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/InputSubModSimilarityReport/tm_InpSubModSimilarityRpt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/InputSubModSimilarityReport/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/InputSubModSimilarityReport/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/InputSubModSimilarityReport/SendEmail.sh .
* // ./tm_InpSubModSimilarityRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Add="F2B01"
* // ./tm_InpSubModSimilarityRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Add="F2B01"
*
***************************************************************************/
