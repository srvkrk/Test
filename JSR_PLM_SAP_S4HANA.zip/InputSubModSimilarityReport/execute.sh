echo "Input Module Address: $1"

echo "Creating directory as MCC_DATA_$1"

mkdir MCC_DATA_$1

cd MCC_DATA_$1

/user/cvprod/sourav/InputSubModSimilarityReport/tm_InpSubModSimilarityRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Add=$1

sleep 5

echo "Completed....."
