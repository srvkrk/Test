./compile tm_InpSubModSimilarityRpt.c
./linkitk -o tm_InpSubModSimilarityRpt tm_InpSubModSimilarityRpt.o
chmod 777 tm_InpSubModSimilarityRpt*
