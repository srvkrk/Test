./compile tm_BOMComp.c
./linkitk -o tm_BOMComp tm_BOMComp.o
chmod 777 tm_BOMComp*
