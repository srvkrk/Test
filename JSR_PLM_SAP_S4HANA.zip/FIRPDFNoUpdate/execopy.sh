scp infodba04@172.27.128.199:/user/infodba04/sourav/FIRPDFNoUpdate/tm_FIRPDFNoUpdate .
