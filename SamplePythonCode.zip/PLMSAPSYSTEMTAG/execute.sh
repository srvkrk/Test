/user/cvprod/sourav/PLMSAPSYSTEMTAG/PLMSAPSystemTag -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -File=InputList.txt
