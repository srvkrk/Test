/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   After Reading Submodule From File Create Module Property Details & Print its Properties on Reports  
*  File Name    :   tm_ModulePropertyStamp.c
*  Created on   :   Dec 05th, 2024
*  Usage        :   tm_ModulePropertyStamp
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     05/12/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_FunCntrlObjForAggrModSubmod(char* Inp_Sys,char* Inp_SubSys,char* remainmodaddstr,char* Inp_Info1)
{
	//trimwhitespace(Inp_Sys);
	//trimwhitespace(Inp_SubSys);
	//trimwhitespace(remainmodaddstr);
	//trimwhitespace(Inp_Info1);
	tag_t tOtherQryobj = NULLTAG;
	int nOther_entries = 3;
	int nOther_Qryobj_found = 0;
	tag_t* tOtherQryobj_results = NULLTAG;
	int z = 0;
	char* sinfo2 = NULL;
	char* sinfo2Dup = NULL;
	char* sinfo2tok = NULL;
	
	printf("\n Searched SYSCD Value: [%s]\n", Inp_Sys);fflush(stdout);
	printf("\n Searched SUBSYSCD Value: [%s]\n", Inp_SubSys);fflush(stdout);
	printf("\n Searched Remain Module Address Value: [%s]\n", remainmodaddstr);fflush(stdout);
	printf("\n Searched Information-1 Value: [%s]\n", Inp_Info1);fflush(stdout);
    ITK_CALL(QRY_find2("Control Objects...",&tOtherQryobj));
    if(tOtherQryobj!=NULLTAG)
	{
		printf("\n Control Objects... Query Found Successfully..!!\n");fflush(stdout);
		char *OtherEntries[3]  = {"SYSCD","SUBSYSCD","Information-1"};
		char *OtherValues[3]  = {Inp_Sys,Inp_SubSys,Inp_Info1};
		ITK_CALL(QRY_execute(tOtherQryobj, nOther_entries, OtherEntries, OtherValues, &nOther_Qryobj_found, &tOtherQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Object Found: [%d]\n",nOther_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nOther_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (z = 0; z < nOther_Qryobj_found; z++)
			{
				AOM_ask_value_string(tOtherQryobj_results[z],"t5_Userinfo2",&sinfo2);
				printf("\n Information-2 Complete Value:  <%s> \n",sinfo2);fflush(stdout);
				AOM_ask_value_string(tOtherQryobj_results[z],"t5_Userinfo2",&sinfo2tok);
				printf("\n Information-2 Value For Token:  <%s> \n",sinfo2tok);fflush(stdout);
				if(tc_strlen(sinfo2)>0)
				{
					char *sinfo2First = NULL;
					char *sinfo2Remain = NULL;
					sinfo2First=strtok(sinfo2tok,"-");
					sinfo2Remain=strtok(NULL,"-");
					if(tc_strcmp(sinfo2First,remainmodaddstr)==0)
					{
						tc_strdup(sinfo2,&sinfo2Dup);
					}
					else
					{
					  printf("\n Input Information2 & Control Table Information2 Not Matched..!!\n");fflush(stdout);
					}
				}
				else
				{
					printf("\n Information-2 Value is NULL..!!\n");fflush(stdout);
				}	
			}
			if(tc_strlen(sinfo2Dup)>0)
			{
				printf("\n Information-2 Value Already Printed..!!\n");fflush(stdout);
			}
			else
			{
				tc_strdup("--",&sinfo2Dup);
			}	
		}
		else
		{
			tc_strdup("--",&sinfo2Dup);
			printf("\nSorry! Other Object Not Found...\n");fflush(stdout);
		}	
	}
	else
	{
		tc_strdup("--",&sinfo2Dup);
		printf("\nSorry! Control Objects... Query Tag Not Found...\n");fflush(stdout);
	}
	
	return sinfo2Dup;	
}

char* TC_FunCntrlObjForAggGroup(char* Inp_Sys,char* Inp_SubSys,char* firstmodaddstr)
{
	//trimwhitespace(Inp_Sys);
	//trimwhitespace(Inp_SubSys);
	//trimwhitespace(firstmodaddstr);
	tag_t tAggGrpQryobj = NULLTAG;
	int nAggGrp_entries = 2;
	int nAggGrp_Qryobj_found = 0;
	tag_t* tAggGrpQryobj_results = NULLTAG;
	int n = 0;
	char* sinfo1 = NULL;
	char* sinfo1Dup = NULL;
	char* sinfo1tok = NULL;
	
	printf("\n Searched SYSCD Value: [%s]\n", Inp_Sys);fflush(stdout);
	printf("\n Searched SUBSYSCD Value: [%s]\n", Inp_SubSys);fflush(stdout);
	printf("\n Module Address First Character Value: [%s]\n", firstmodaddstr);fflush(stdout);
    ITK_CALL(QRY_find2("Control Objects...",&tAggGrpQryobj));
    if(tAggGrpQryobj!=NULLTAG)
	{
		printf("\n Control Objects... Query Found Successfully..!!\n");fflush(stdout);
		char *AggGrpEntries[2]  = {"SYSCD","SUBSYSCD"};
		char *AggGrpValues[2]  = {Inp_Sys,Inp_SubSys};
		ITK_CALL(QRY_execute(tAggGrpQryobj, nAggGrp_entries, AggGrpEntries, AggGrpValues, &nAggGrp_Qryobj_found, &tAggGrpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Object Found: [%d]\n",nAggGrp_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nAggGrp_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nAggGrp_Qryobj_found; n++)
			{	
				AOM_ask_value_string(tAggGrpQryobj_results[n],"t5_Userinfo1",&sinfo1);
				printf("\n Information-1 Complete Value:  <%s> \n",sinfo1);fflush(stdout);
				AOM_ask_value_string(tAggGrpQryobj_results[n],"t5_Userinfo1",&sinfo1tok);
				printf("\n Information-1 Value For Token:  <%s> \n",sinfo1tok);fflush(stdout);
				if(tc_strlen(sinfo1)>0)
				{
					char *sinfo1First = NULL;
					char *sinfo1Remain = NULL;
					sinfo1First=strtok(sinfo1tok,"-");
					sinfo1Remain=strtok(NULL,"-");
					if(tc_strcmp(sinfo1First,firstmodaddstr)==0)
					{
						tc_strdup(sinfo1,&sinfo1Dup);
					}
					else
					{
					  printf("\n Input Information1 & Control Table Information1 Not Matched..!!\n");fflush(stdout);
					}
				}
				else
				{
					printf("\n Information-1 Value is NULL..!!\n");fflush(stdout);
				}
			}
			if(tc_strlen(sinfo1Dup)>0)
			{
				printf("\n Information-1 Value Already Printed..!!\n");fflush(stdout);
			}
			else
			{
				tc_strdup("--",&sinfo1Dup);
			}
		}
		else
		{
			tc_strdup("--",&sinfo1Dup);
			printf("\nSorry! Aggregate Group Object Not Found...\n");fflush(stdout);
		}	
	}
	else
	{
		tc_strdup("--",&sinfo1Dup);
		printf("\nSorry! Control Objects... Query Tag Not Found...\n");fflush(stdout);
	}
	
	return sinfo1Dup;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	char *TxtRptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	FILE *fpOutput_file_txt = NULL;
	char *inp_id_str = NULL;
	char *inp_id_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	fpPart_List = fopen("PartList.txt","r");
	printf("\n Generating Report File Name[CSV]..!!");fflush(stdout);
	tc_strcpy(RptFile,"Module_Property_Stamp");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name[CSV]: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated[CSV]..!!");fflush(stdout);
	printf("\n Generating Report File Name[TXT]..!!");fflush(stdout);
	tc_strcpy(TxtRptFile,"Module_Property_Stamp");
	tc_strcat(TxtRptFile,"_");
	tc_strcat(TxtRptFile,GenDate);
	tc_strcat(TxtRptFile,".txt");
	printf("\n Report File Name[TXT]: [%s]", TxtRptFile);fflush(stdout);
	printf("\n Report File Generated[TXT]..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
	fpOutput_file_txt = fopen(TxtRptFile, "w");
    fprintf(fpOutput_file,"MODULE_NO, MODULE_ADDRESS, AGGREGATE_GROUP, AGGREGATE, MODULE, SUBMODULE\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File[CSV]: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpOutput_file_txt == NULL)
	{
	    printf("\n Unable to Create Report File[TXT]: --------> [%s]",TxtRptFile);fflush(stdout);
		return 0;
	}
	
	printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@ Generation Start @@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	if(fpPart_List != NULL)
	{
		printf("\n Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			inp_id_str=strtok(Buffer,"^");
			if(inp_id_str!=NULL)tc_strdup(inp_id_str,&inp_id_strDup);
			if(inp_id_strDup!=NULL)trimwhitespace(inp_id_strDup);
			char* modaddr_str = NULL;
			char* modaddrfirst_str = NULL;
			char* modaddrsecond_str = NULL;
			char* modaddrthird_str = NULL;
			char* modaddrremain_str = NULL;
			modaddr_str=subString(inp_id_strDup,4,5);
			printf("\n Module Address Value: [%s]\n", modaddr_str);fflush(stdout);
			modaddrfirst_str=subString(modaddr_str,0,1);
			printf("\n Module Address First Digit: [%s]\n", modaddrfirst_str);fflush(stdout);
			modaddrsecond_str=subString(modaddr_str,1,1);
			printf("\n Module Address Second Digit: [%s]\n", modaddrsecond_str);fflush(stdout);
			modaddrthird_str=subString(modaddr_str,2,1);
			printf("\n Module Address Third Digit: [%s]\n", modaddrthird_str);fflush(stdout);
			modaddrremain_str=subString(modaddr_str,3,2);
			printf("\n Module Address Remain Digit: [%s]\n", modaddrremain_str);fflush(stdout);
			char *Cmplt_AggGroup = NULL;
			char *Cmplt_Aggregates = NULL;
			char *Cmplt_Module = NULL;
			char *Cmplt_SubModule = NULL;
			char *Cmplt_AggGroupDup = NULL;
			char *Cmplt_AggregatesDup = NULL;
			char *Cmplt_ModuleDup = NULL;
			char *Cmplt_SubModuleDup = NULL;
			printf("\n >>>>>>>>>>>>>> Function1: Finding Aggregate Group Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
			Cmplt_AggGroup = TC_FunCntrlObjForAggGroup("AggrGrp","Aggregate",modaddrfirst_str);
			printf("\n >>>>>>>>>>>>>> Function1: Finding Aggregate Group End <<<<<<<<<<<<<<<<\n");fflush(stdout);
			printf("\n >>>>>>>>>>>>>> Function2: Finding Aggregates Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
			Cmplt_Aggregates = TC_FunCntrlObjForAggrModSubmod("AggrGrp","Aggregate",modaddrsecond_str,Cmplt_AggGroup);
			printf("\n >>>>>>>>>>>>>> Function2: Finding Aggregates End <<<<<<<<<<<<<<<<\n");fflush(stdout);
			printf("\n >>>>>>>>>>>>>> Function3: Finding Module Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
			Cmplt_Module = TC_FunCntrlObjForAggrModSubmod("Aggregate","ModuleGrp",modaddrthird_str,Cmplt_Aggregates);
			printf("\n >>>>>>>>>>>>>> Function3: Finding Module End <<<<<<<<<<<<<<<<\n");fflush(stdout);
			printf("\n >>>>>>>>>>>>>> Function4: Finding Sub-Module Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
			Cmplt_SubModule = TC_FunCntrlObjForAggrModSubmod("ModuleGrp","Module",modaddrremain_str,Cmplt_Module);
			printf("\n >>>>>>>>>>>>>> Function4: Finding Sub-Module End <<<<<<<<<<<<<<<<\n");fflush(stdout);
			char *AggGrpFirst = NULL;
			char *AggGrpRemain = NULL;
			char *AggregatesFirst = NULL;
			char *AggregatesRemain = NULL;
			char *ModuleFirst = NULL;
			char *ModuleRemain = NULL;
			char *SubModuleFirst = NULL;
			char *SubModuleRemain = NULL;
	        tc_strdup(Cmplt_AggGroup,&Cmplt_AggGroupDup);
			//AggGrpFirst=strtok(Cmplt_AggGroupDup,"-");
			//AggGrpRemain=strtok(NULL,"-");
			tc_strdup(Cmplt_Aggregates,&Cmplt_AggregatesDup);
			//AggregatesFirst=strtok(Cmplt_AggregatesDup,"-");
			//AggregatesRemain=strtok(NULL,"-");
			tc_strdup(Cmplt_Module,&Cmplt_ModuleDup);
			//ModuleFirst=strtok(Cmplt_ModuleDup,"-");
			//ModuleRemain=strtok(NULL,"-");
			tc_strdup(Cmplt_SubModule,&Cmplt_SubModuleDup);
			//SubModuleFirst=strtok(Cmplt_SubModuleDup,"-");
			//SubModuleRemain=strtok(NULL,"-");
			printf("\n >>>>>>>>>>>>>>> Item Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
			printf("[1] Module_No: [%s]\n",inp_id_strDup);fflush(stdout);
			printf("[2] Module_Address: [%s]\n",modaddr_str);fflush(stdout);
			//printf("[3] Aggregate_Group: [%s]\n",AggGrpRemain);fflush(stdout);
			//printf("[4] Aggregate: [%s]\n",AggregatesRemain);fflush(stdout);
			//printf("[5] Module: [%s]\n",ModuleRemain);fflush(stdout);
			//printf("[6] SubModule: [%s]\n",SubModuleRemain);fflush(stdout);
			printf("[3] Aggregate_Group: [%s]\n",Cmplt_AggGroupDup);fflush(stdout);
			printf("[4] Aggregate: [%s]\n",Cmplt_AggregatesDup);fflush(stdout);
			printf("[5] Module: [%s]\n",Cmplt_ModuleDup);fflush(stdout);
			printf("[6] SubModule: [%s]\n",Cmplt_SubModuleDup);fflush(stdout);
			printf("\n >>>>>>>>>>>>>>> Item Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
			
			//fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s\n",inp_id_strDup,modaddr_str,AggGrpRemain,AggregatesRemain,ModuleRemain,SubModuleRemain);fflush(fpOutput_file);
			fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s\n",inp_id_strDup,modaddr_str,Cmplt_AggGroupDup,Cmplt_AggregatesDup,Cmplt_ModuleDup,Cmplt_SubModuleDup);fflush(fpOutput_file);
			fprintf(fpOutput_file_txt,"%s^%s^%s^%s^%s^%s^\n",inp_id_strDup,modaddr_str,Cmplt_AggGroupDup,Cmplt_AggregatesDup,Cmplt_ModuleDup,Cmplt_SubModuleDup);fflush(fpOutput_file_txt);
		}
	}
	else
	{
		printf("\n Input File is NULL..!!\n");fflush(stdout);
	}	
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	fclose(fpOutput_file_txt);
	fclose(fpPart_List);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@ Generation End @@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@ Updation Start @@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	FILE *fpPart_List_Txt = NULL;
	char Buffer1[MAX_LINE_LENGTH];
	char *inp_modid_str = NULL;
	char *inp_modadd_str = NULL;
	char *inp_modaggrgrp_str = NULL;
	char *inp_modaggr_str = NULL;
	char *inp_mod_str = NULL;
	char *inp_submod_str = NULL;
	char *inp_modid_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t Aggrgrp_AttrID = NULLTAG;
	tag_t Aggr_AttrID = NULLTAG;
	tag_t ModGrp_AttrID = NULLTAG;
	tag_t SubMod_AttrID = NULLTAG;
	int i = 0;
	fpPart_List_Txt = fopen(TxtRptFile,"r");
	if(fpPart_List_Txt != NULL)
	{
		printf("\n Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer1,MAX_LINE_LENGTH,fpPart_List_Txt)!=NULL)
		{
			inp_modid_str=strtok(Buffer1,"^");
			inp_modadd_str=strtok(NULL,"^");
			inp_modaggrgrp_str=strtok(NULL,"^");
			inp_modaggr_str=strtok(NULL,"^");
			inp_mod_str=strtok(NULL,"^");
			inp_submod_str=strtok(NULL,"^");
			if(inp_modid_str!=NULL)tc_strdup(inp_modid_str,&inp_modid_strDup);
			if(inp_modid_strDup!=NULL)trimwhitespace(inp_modid_strDup);
			
			ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n Query[Item Revision...] Found Successfully..!!\n");fflush(stdout);
				//char *cEntries[4]  = {"Item ID","Revision","Type","Release Status"};
				//char *cValues[4]  = {inp_modid_strDup,"*","Design Revision","T5_LcsErcRlzd"};
				//char *cValues[4]  = {"5020K1A0858001","*","Design Revision","T5_LcsErcRlzd"};
				char *cEntries[3]  = {"Item ID","Revision","Type"};
				char *cValues[3]  = {inp_modid_strDup,"*","Design Revision"};
				//char *cValues[3]  = {"5020K1A0858001","*","Design Revision"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Released Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				for (i = 0; i < n_itemobj_found; i++)
		        {
					if((tc_strcmp(inp_modaggrgrp_str," ") !=0) && (tc_strcmp(inp_modaggr_str," ") !=0) && (tc_strcmp(inp_mod_str," ") !=0) && (tc_strcmp(inp_submod_str," ") !=0))
					{
					    printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 
						ITK_CALL(AOM_refresh(titemobj_results[i], POM_modify_lock));
						printf("\n Lock..!!\n");
						ITK_CALL(POM_attr_id_of_attr("t5_AggregateGroup", "Design_0_Revision_alt", &Aggrgrp_AttrID));
						ITK_CALL(POM_attr_id_of_attr("t5_Aggregate", "Design_0_Revision_alt", &Aggr_AttrID));
						ITK_CALL(POM_attr_id_of_attr("t5_Module_Group", "Design_0_Revision_alt", &ModGrp_AttrID));
						ITK_CALL(POM_attr_id_of_attr("t5_Module", "Design_0_Revision_alt", &SubMod_AttrID));
						ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], Aggrgrp_AttrID, inp_modaggrgrp_str));				
						ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], Aggr_AttrID, inp_modaggr_str));
						ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], ModGrp_AttrID, inp_mod_str));				
						ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], SubMod_AttrID, inp_submod_str));
						ITK_CALL(POM_save_instances(1, &titemobj_results[i], true));
						ITK_CALL(AOM_refresh(titemobj_results[i], POM_no_lock));
						printf("\n Unlock..!!\n");
						printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
					}
                    else
                    {
						printf("\n Property Value NULL..!!");
					}						
				}
			}
		    else
			{
				printf("\n After Query Execution No Item Found..!!");fflush(stdout);
			}
		}
	}
	else
	{
		printf("\n Input File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List_Txt);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@ Updation End @@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ModulePropertyStamp.c
* // ./linkitk -o tm_ModulePropertyStamp tm_ModulePropertyStamp.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ModulePropertyStamp/tm_ModulePropertyStamp .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ModulePropertyStamp/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ModulePropertyStamp/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ModulePropertyStamp/SendEmail.sh .
* // ./tm_ModulePropertyStamp -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_ModulePropertyStamp -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/