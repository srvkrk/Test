/user/cvprod/sourav/ModulePropertyStamp/tm_ModulePropertyStamp -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
