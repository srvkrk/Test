######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it.
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : April-2024
#
#######################################################################################

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "First Report File Name: -----> "$1

echo "Second Report File Name: -----> "$2

echo "Receiver Email: -----> "$3

echo -e "\nIn Shell Argument Print Ended...."

echo -e "\nReport Send To User Email Started...."
ls -lrt $1
if [ $? == 0 ]
      then
        echo "File Successfully Found on Server"
        echo "Sending Report To User Email"
        echo -e "Hi, \n\n                Please Check Attached Report.\n                   \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS : PART-USAGE REPORT" -a $1 -a $2 $3 souravk.ttl@tatamotors.com kaletk.ttl@tatamotors.com kishor.raskar@tatamotors.com anup.barik@tatamotors.com
      else
        echo "File NOT Foud on server"
        echo "Sending Report To Developer Email"
        echo -e "Hi, \n\n                There is Some Issue in Sending Report To User Email.\n                Please Check Log & Retry.\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED : PART-USAGE REPORT" $3 souravk.ttl@tatamotors.com 
fi
echo -e "\nReport Send To User Email Ended...."
echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"
