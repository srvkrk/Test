######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : APRIL-2025
#
#######################################################################################

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "Pre Unique File: -----> "$5

echo "Unique File: -----> "$6

echo -e "\n UnSort To Sort Started...."
sort -u $5 -o $6
echo -e "\n UnSort To Sort Ended...."

echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"
