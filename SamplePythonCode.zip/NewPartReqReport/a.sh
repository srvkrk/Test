scp infodba03@172.27.128.199:/user/infodba03/sudhir/NewPartReqReport/NewPartReqMCCSignOff.c .
$TC_ROOT/sample/compile -DIPLIB=none NewPartReqMCCSignOff.c
./linkitk -o NewPartReqMCCSignOff NewPartReqMCCSignOff.o
$TC_ROOT/*Patch*/tcPatchExecutable NewPartReqMCCSignOff
rm -rf nohup.out
nohup ./NewPartReqMCCSignOff -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -F=07-Apr-2024 -T=23-May-2025 &
