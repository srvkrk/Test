nohup ./NewPartReqMCCSignOff -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -F=07-Apr-2024 -T=18-Jun-2025 &
