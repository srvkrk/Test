/user/cvprod/sourav/ProNextDataGenerate/tm_ProNextDataGen -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
