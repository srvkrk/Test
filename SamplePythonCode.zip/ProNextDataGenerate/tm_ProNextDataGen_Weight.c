/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Generate Pronext Data on Design Revision's Property  
*  File Name    :   tm_ProNextDataGen.c
*  Created on   :   Oct 21st, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     21/10/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
																            \
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...\n");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	FILE *fpPart_List = NULL;
	FILE *fpOutput_file = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 4;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
    char *RptFile = (char *) malloc(200*sizeof(char));
	tag_t tQryDesRev = NULLTAG;
	char *cItem_Id = NULL;
	char *cItem_RevSeq = NULL;
	char *cItem_Desc = NULL;
	char *cItem_Rev = NULL;
	char *cItem_Seq = NULL;
	double cItem_Wt = 0.0;
	char str_cItem_Wt[50];
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"ProNext_Data_Generate_Rpt");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"PART_NO, REV, SEQ, DESCRIPTION, WEIGHT \n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	fpPart_List = fopen("PartList.txt","r");
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			printf(" Part No(item_id_strDup): [%s]\n",item_id_strDup);
			ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n Query[Item Revision...] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[4]  = {"Item ID","Revision","Type","Release Status"};
				char *cValues[4]  = {item_id_strDup,"*","Design Revision","T5_LcsErcRlzd"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Released Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				for (i = 0; i < n_itemobj_found; i++)
		        {
					tQryDesRev = titemobj_results[i];
					ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_id",&cItem_Id));
				    ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_revision_id",&cItem_RevSeq));
					cItem_Desc = TC_PartDesc(cItem_Id,cItem_RevSeq);
					printf("\n Part Description Value: [%s]", cItem_Desc);fflush(stdout);
					cItem_Rev=strtok(cItem_RevSeq,";");
					cItem_Seq=strtok(NULL,";");
					printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
					printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
					ITK_CALL(AOM_ask_value_double(tQryDesRev,"t5_Weight",&cItem_Wt));
					sprintf(str_cItem_Wt, "%.2f", cItem_Wt);
					if(tc_strlen(cItem_Id)>0)
		            {
                       fprintf(fpOutput_file,"%s,%s,%s,%s,%s\n",cItem_Id,cItem_Rev,cItem_Seq,cItem_Desc,str_cItem_Wt);fflush(fpOutput_file);
                    }
                    else
                    {
						printf("\n Item ID Invalid..!!");fflush(stdout);
					}						 
				}
			}
		    else
			{
				printf("\n After Query Execution No Item Found..!!");fflush(stdout);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fprintf(fpOutput_file,"\n ,, E N D - O F    R E P O R T ,,\n");fflush(fpOutput_file);
	fclose(fpPart_List);
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_exit_module(TRUE);	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ProNextDataGen.c
* // ./linkitk -o tm_ProNextDataGen tm_ProNextDataGen.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ProNextDataGenerate/tm_ProNextDataGen .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ProNextDataGenerate/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/ProNextDataGenerate/PartList.txt .
* // ./tm_ProNextDataGen -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_ProNextDataGen -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/