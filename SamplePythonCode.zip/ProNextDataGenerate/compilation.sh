./compile tm_ProNextDataGen.c
./linkitk -o tm_ProNextDataGen tm_ProNextDataGen.o
chmod 777 tm_ProNextDataGen*
