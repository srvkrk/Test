/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Part Wise Prfit Center Object Create & Submit in LifeCycle
*  File Name    :   tm_PartWisePC_Create_Submit_LC.c
*  Created on   :   Dec 25rd, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     25/12/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	//char *retStringf;
	//retStringf = (char*) malloc(200);
	char *retStringf = (char *)MEM_alloc(100 * sizeof(char));
	
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int tm_check_control_object ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) );
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) );
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ); fflush(stdout);

	return n_found ;
}

int Submit_PCObject_to_workflow ( tag_t pc_obj_tag )
{
	tag_t template_tag = NULLTAG;
	tag_t test_job_a  = NULLTAG;
	int attachment_types[1];
	attachment_types[0] = EPM_target_attachment;
	int n_PC_WFL = 0;
	char* ItemDetails = NULL;
	const char* cpProcessTempName = "ERC Released";
	const char* cpProcessName = "Profit Center Mapping Workflow Process";
	ITK_CALL(AOM_ask_value_string(pc_obj_tag,"object_name",&ItemDetails));
	printf("\n PC Object Name: [%s]\n",ItemDetails);fflush(stdout);
	n_PC_WFL = tm_check_control_object ( "PC_WFLSYS", "TRUE" );
	printf("\n -----------------------------------------------\n");fflush(stdout);
	printf("\n  No of Control Object Found: [%d]\n",n_PC_WFL);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
	if ( n_PC_WFL > 0 )
	{
		ITK_CALL(EPM_find_process_template(cpProcessTempName, &template_tag));
		if((template_tag != NULLTAG) && (pc_obj_tag != NULLTAG))
		{
			printf("\n Template Tag & Target Object Tag is not NULLTAG..!!\n");fflush(stdout);
			ITK_CALL(EPM_create_process(cpProcessName, "Profit Center Mapping Workflow", template_tag, 1, &pc_obj_tag, attachment_types, &test_job_a));
			if(test_job_a != NULLTAG)
			{
				printf("\n Workflow Process Tag is not NULLTAG..!!\n");fflush(stdout);
				printf("\n Profit Center Object Submitted into Workflow");fflush(stdout);
			}
			else
			{
				printf("\n Workflow Process Tag is NULLTAG..!!\n");fflush(stdout);
			}
		}
        else
		{
           printf("\n Either Template Tag or Target Object Tag is NULL..!!\n");fflush(stdout);
        }		   
	}
	return ITK_ok;
}

int getClsValueFrmICSTag_pm( tag_t  IcsClsTag_pm , char *clsKeyAtrrId_pm,char **AttrVal)
{
	tag_t objTypeTag_pm=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name_pm[TCTYPE_name_size_c+1];
	char   *Ptype_name_pm	=	NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag_pm,&objTypeTag_pm));
	//if(TCTYPE_ask_name(objTypeTag_pm,Ptype_name_pm));
	if(TCTYPE_ask_name2(objTypeTag_pm,&Ptype_name_pm)); // TC 14.3 Upgrade

	
	if(IcsClsTag_pm!=NULLTAG)
	{
		    char * 	theClassId = NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId_pm); fflush(stdout);
			//char keyPrefix[10];
			//tc_strcpy(keyPrefix,"-");
			//tc_strcat(keyPrefix,clsKeyAtrrId);
			int intid2 = 0;
			char * 	unctName = NULL;
		    char *	shortName = NULL;
		    char * 	unctUnit = NULL;
		    int  unctFormat = 0;
			intid2=atoi(clsKeyAtrrId_pm);
			printf("\n  input intid2[%d]",intid2); fflush(stdout);
	 
			printf("\n  111"); fflush(stdout);
			ITKCALL(ICS_describe_unct(intid2,&unctName,&shortName,&unctUnit,&unctFormat));
			printf("\n  222 ifail[%d]",ifail); fflush(stdout);
			if(ifail != ITK_ok)
			{
				printf("\n FAIL:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);						
				return ifail;	
			}
			
			printf("\n SUCCESS:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);
			//printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			//const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char theKeyLOVId[10];
			const char * 	key_lov_id;
			if(unctFormat)
			{

				sprintf(theKeyLOVId, "%d", unctFormat);
				key_lov_id=theKeyLOVId;	
			}
			char * 	key_lov_name;
			int  	options;
			int t = 0;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites;
			theICOTag=IcsClsTag_pm;
			ITKCALL(ICS_ask_attribute_value(theICOTag,clsKeyAtrrId_pm,&AttrKeyValue));
			
			printf("\n AttrKeyValue: [%s]  key_lov_id: [%s]",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			    if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    //CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    printf("\n key_lov_name: [%s] n_lov_entries: [%d] options: [%d]",key_lov_name,n_lov_entries,options); fflush(stdout);
 				for(t=0;t<n_lov_entries;t++)								
				{
					//printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
					
					//if(tc_strcasecmp(AttrKeyValue,lov_keys[t])==0)
					if(tc_strstr(lov_keys[t],AttrKeyValue) != NULL)
					{
						printf("\n AttrKeyValue: [%s]",AttrKeyValue);fflush(stdout);
						printf("\n Mascot lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						
						if(lov_values[t])
						{
							tc_strdup(lov_values[t],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						printf("\n Before Break RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
						break;
					}	
				} 
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}
    printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	printf("\n RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
			
	return ITK_ok;
}

int TC_VCClassification_Details(char* partno,char* rev,char* seq,char* Name,char* Description,char* ERCDMLNo,char* ExtrAttr1,char* ExtrAttr5)
{
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int s = 0;
	tag_t VCRev_tag = NULLTAG;
	char *item_revseq = (char *) malloc(20*sizeof(char));
	int ChldCount = 0;
    tag_t *PartChildTags = NULLTAG;
	tag_t Veh_tag = NULLTAG;
	char *vehno_str = NULL;
	char *vehno_strDup = NULL;
	int z = 0;
	tag_t vehtItemobj = NULLTAG;
	int vehn_entries = 2;
	int vehn_itemobj_found = 0;
	tag_t* vehtitemobj_results = NULLTAG;
	int y = 0;
	tag_t Rev_tag = NULLTAG;
	tag_t VehRev_tag = NULLTAG;
	int iFail = ITK_ok;
	char *prodlineval = NULL;
	prodlineval = (char *) malloc(100*sizeof(char));
	char *platformval = NULL;
	platformval = (char *) malloc(100*sizeof(char));
	char *segmentval = NULL;
	segmentval = (char *) malloc(100*sizeof(char));
	char *variantval = NULL;
	variantval = (char *) malloc(100*sizeof(char));
	int num_to_sort = 1;
	int sort_order[1] = {2}; //1 --> Ascending Order & 2 --> Descending Order
	char *keysAttr[1] =  {"creation_date"};
	char *partClrInd = NULL;
	tag_t* NonColPartTags =  NULLTAG;
	int Count = 0;
	
	if(prodlineval!=NULL)trimwhitespace(prodlineval);
	if(platformval!=NULL)trimwhitespace(platformval);
	if(segmentval!=NULL)trimwhitespace(segmentval);
	if(variantval!=NULL)trimwhitespace(variantval);
	char *vcctnpc = NULL;
	
	tc_strcpy(item_revseq,rev);
	tc_strcat(item_revseq,"*");
	tc_strcat(item_revseq,seq);
	printf(" Final: Part_Rev_Seq Value(item_revseq): [%s]\n",item_revseq);
	
	printf("\n Finding Query[Item Revision...]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n Query [Item Revision...] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","Item ID"};
		char *cValues[2]  = {item_revseq,partno};
		//char *cValues[2]  = {"A*2","51780353000R"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Queried [Item Revision...] Found..!!\n");fflush(stdout);
			for(s = 0; s < n_itemobj_found; s++)
			{
				VCRev_tag = titemobj_results[s];
				ITK_CALL(AOM_ask_value_tags(VCRev_tag,"ps_children",&ChldCount,&PartChildTags));
				if(ChldCount>0)
				{
					for(z = 0; z < ChldCount; z++)
			        {
						Veh_tag = PartChildTags[z];
						ITK_CALL(AOM_ask_value_string(PartChildTags[z],"item_id",&vehno_str));
						if(tc_strlen(vehno_str)>0)
						{
							tc_strdup(vehno_str,&vehno_strDup);
							ITK_CALL(QRY_find2("Item Revision...",&vehtItemobj));
							if(vehtItemobj != NULLTAG)
							{
								printf("\n Query [Item Revision...] Found Successfully..!!\n");fflush(stdout);
								char *vehEntries[2]  = {"Item ID","Release Status"};
								char *vehValues[2]  = {vehno_strDup,"T5_LcsErcRlzd"};
								ITK_CALL(QRY_execute(vehtItemobj, vehn_entries, vehEntries, vehValues, &vehn_itemobj_found, &vehtitemobj_results));
					            ITK_CALL(QRY_execute_with_sort(vehtItemobj, vehn_entries, vehEntries, vehValues, num_to_sort, keysAttr, sort_order, &vehn_itemobj_found, &vehtitemobj_results));
								printf("\n -----------------------------------------------\n");fflush(stdout);
								printf("\n No of Revision Found: [%d]\n",vehn_itemobj_found);fflush(stdout);
								printf("\n -----------------------------------------------\n");fflush(stdout);
								if(vehn_itemobj_found > 0)
								{
									printf("\n Query [Item Revision...] Found..!!\n");fflush(stdout);
									for (y = 0; y < vehn_itemobj_found; y++)
									{
										Rev_tag = vehtitemobj_results[y];
										ITK_CALL(AOM_ask_value_string(Rev_tag,"t5_ColourInd",&partClrInd));
										printf("\n Colour Indicator: [%s]",partClrInd);fflush(stdout);
										if(tc_strcmp(partClrInd,"C") == 0)
										{
											ITK_CALL(AOM_ask_value_tags(Rev_tag,"TC_Is_Represented_By",&Count,&NonColPartTags));
											if (Count > 0)
											{
										       VehRev_tag = NonColPartTags[0];
											}
										}
										else
										{
											VehRev_tag = vehtitemobj_results[y];
										}
										
										printf("\n Function2: Classification Attribute Find Start");fflush(stdout);
										tag_t Vc_spec_relation_type = NULLTAG;
										int vcspec_count_f = 0;
										tag_t* Vc_specObjects_f = NULLTAG;
										char *vcspec_item_id_f = NULL;
										char *vcclass_f = NULL;
										tag_t VehMstrTag = NULLTAG;
										int cnt	= 0;
										tag_t *ClsObjTag_results = NULLTAG;
										tag_t ClsObj_f = NULLTAG;
									
										ITK_CALL(GRM_find_relation_type("T5_VCSpec",&Vc_spec_relation_type));
										if(Vc_spec_relation_type != NULLTAG)
										{
											ITK_CALL(GRM_list_secondary_objects_only(VehRev_tag, Vc_spec_relation_type, &vcspec_count_f, &Vc_specObjects_f));
											printf("\n ----------------------------------------------");fflush(stdout);
											printf("\n Total Tech_Spech Attached with Vehicle: [%d]",vcspec_count_f);fflush(stdout);
											printf("\n ----------------------------------------------\n");fflush(stdout);
											if(vcspec_count_f > 0)
											{
												ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"item_id",&vcspec_item_id_f));
												printf("\n Tech_Spech No: [%s]\n",vcspec_item_id_f);fflush(stdout);
																						
												ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"t5_VCClassName",&vcclass_f));
												printf("\n Vehicle Class: [%s]",vcclass_f);fflush(stdout);
												
												if(tc_strlen(vcclass_f) > 0)
												{
													char *geproductlineval_id = NULL;
													geproductlineval_id = (char *) malloc(100*sizeof(char));
													char *getplatformval_id = NULL;
													getplatformval_id = (char *) malloc(100*sizeof(char));
													char *getsegmentval_id = NULL;
													getsegmentval_id = (char *) malloc(100*sizeof(char));
													char *getvariantval_id = NULL;
													getvariantval_id = (char *) malloc(100*sizeof(char));
													
													if(tc_strcmp(vcclass_f,"MCV")==0)
													{
														printf("\n Attribute_ID Start: [MCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_MCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_MCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_MCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_MCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [MCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"HCV")==0)
													{
														printf("\n Attribute_ID Start: [HCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_HCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_HCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_HCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_HCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [HCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"LCV")==0)
													{
														printf("\n Attribute_ID Start: [LCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_LCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_LCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_LCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_LCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [LCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"LMV")==0)
													{
														printf("\n Attribute_ID Start: [LMV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
													
														printf("\n geproductlineval_id_LMV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_LMV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_LMV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_LMV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [LMV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"BUS")==0)
													{
														printf("\n Attribute_ID Start: [BUS] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_BUS: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_BUS: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_BUS: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_BUS: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [BUS] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"UV_VAN")==0)
													{
														printf("\n Attribute_ID Start: [UV_VAN] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_UV_VAN: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_UV_VAN: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_UV_VAN: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_UV_VAN: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [UV_VAN] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"ICV")==0)
													{
														printf("\n Attribute_ID Start: [ICV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_ICV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_ICV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_ICV [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_ICV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [ICV] \n");fflush(stdout);
													}
													else
													{
														printf("\n VC Class Not Matched..!! \n");fflush(stdout);
													}
													
													ITK_CALL(ITEM_ask_item_of_rev(VehRev_tag,&VehMstrTag));
													ITK_CALL(AOM_ask_value_tags(VehMstrTag,"IMAN_classification",&cnt,&ClsObjTag_results));
													printf("\n Vehicle Master Object Count: [%d]\n", cnt); fflush(stdout);
													if(cnt > 0)
													{
														ClsObj_f=*ClsObjTag_results;	
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,geproductlineval_id,&prodlineval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getplatformval_id,&platformval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getsegmentval_id,&segmentval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getvariantval_id,&variantval));
														
														if(prodlineval!=NULL)trimwhitespace(prodlineval);
														if(platformval!=NULL)trimwhitespace(platformval);
														if(segmentval!=NULL)trimwhitespace(segmentval);
														if(variantval!=NULL)trimwhitespace(variantval);	
														
														printf("\n PRODUCTLINE : [%s]",prodlineval); fflush(stdout);
														printf("\n PLATFORM : [%s]",platformval); fflush(stdout);
														printf("\n SEGMENT : [%s]",segmentval); fflush(stdout);
														printf("\n VARIANT : [%s]",variantval); fflush(stdout);
													}
													else
													{
														printf("\n VC Master Not Found..!! \n");fflush(stdout);
														tc_strcpy(prodlineval,"");
														tc_strcpy(platformval,"");
														tc_strcpy(segmentval,"");
														tc_strcpy(variantval,"");
													}				
												}
												else
												{
													printf("\n VC Class Not Found..!! \n");fflush(stdout);
													tc_strcpy(prodlineval,"");
													tc_strcpy(platformval,"");
													tc_strcpy(segmentval,"");
													tc_strcpy(variantval,"");
												}
											}
											else
											{
												printf("\n No Tech_Spech Attached with Vehicle..!! \n");fflush(stdout);
												tc_strcpy(prodlineval,"");
												tc_strcpy(platformval,"");
												tc_strcpy(segmentval,"");
												tc_strcpy(variantval,"");
											}
										}
										printf("\n Function3: Classification Attribute Find End");fflush(stdout);
										if((tc_strlen(prodlineval)>0) && (tc_strlen(platformval)>0) && (tc_strlen(segmentval)>0) && (tc_strlen(variantval)>0))
										{
											printf("\n Classification Attribute Found So, JUMP..!!");fflush(stdout);
											goto JUMP;
										}
										else
										{
											printf("\n Classification Attribute Still Not Found So, Continue..!!");fflush(stdout);
										}	
									}
								}
								else
								{
								   printf("\n Veh_No Value is NULL..!!");fflush(stdout);
								}
							}
						}
						else
						{
							tc_strdup("",&vehno_strDup);
							printf("\n Veh Master Value is NULL..!!");fflush(stdout);
						}
					}
				}
				else
				{
					printf(" VC To Vehicle Not Found..!!\n");fflush(stdout);
				}

			}
		}
	}
	JUMP:
		printf("\n Classification Attribute Found..!!");fflush(stdout);
	
	char *vcprofit_centre_sap = NULL;
	if((tc_strlen(prodlineval)>0) && (tc_strlen(platformval)>0))
	{
		tag_t ctltItemobj = NULLTAG;
		int ctln_entries = 4;
		int newctln_entries = 3;
		int ctln_itemobj_found = 0;
		tag_t* ctltitemobj_results = NULLTAG;
		int v = 0;
		tag_t CtlRev_tag = NULLTAG;
		vcprofit_centre_sap = (char *)malloc(100 * sizeof(char));
		
		if(((tc_strcmp(prodlineval,"Passenger")==0) || (tc_strcmp(prodlineval,"SCV PU")==0)) && ((tc_strcmp(platformval,"Buses")==0) || (tc_strcmp(platformval,"PU Small")==0) || (tc_strcmp(platformval,"Vans")==0)))
		{
			printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
			printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
			ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
			if(ctltItemobj != NULLTAG)
			{
				printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
				char *ctlEntries[4]  = {"SYSCD","Information-1","Information-2","Information-3"};
				char *ctlValues[4]  = {"S4HANAPLANTDATAVC",prodlineval,platformval,segmentval};
				//char *ctlValues[4]  = {"S4HANAPLANTDATAVC","Passenger","Buses","ICV Buses"};
				ITK_CALL(QRY_execute(ctltItemobj, ctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(ctln_itemobj_found > 0)
				{
					printf(" Queried Control Object Found..!!\n");fflush(stdout);
					printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for(v = 0; v < ctln_itemobj_found; v++)
					{
						CtlRev_tag = ctltitemobj_results[v];
						ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
						printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
						//tc_strcpy(vcprofit_centre_sap,"0000");
						//tc_strcat(vcprofit_centre_sap,vcctnpc);
						tc_strcpy(vcprofit_centre_sap,vcctnpc);
					}
				}
			}
		}
		else
		{
			printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
			printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
			ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
			if(ctltItemobj != NULLTAG)
			{
				printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
				char *ctlEntries[3]  = {"SYSCD","Information-1","Information-2"};
				char *ctlValues[3]  = {"S4HANAPLANTDATAVC",prodlineval,platformval};
				//char *ctlValues[3]  = {"S4HANAPLANTDATAVC","Passenger","Buses"};
				ITK_CALL(QRY_execute(ctltItemobj, newctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(ctln_itemobj_found > 0)
				{
					printf(" Queried Control Object Found..!!\n");fflush(stdout);
					printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for(v = 0; v < ctln_itemobj_found; v++)
					{
						CtlRev_tag = ctltitemobj_results[v];
						ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
						printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
						//tc_strcpy(vcprofit_centre_sap,"0000");
						//tc_strcat(vcprofit_centre_sap,vcctnpc);
						tc_strcpy(vcprofit_centre_sap,vcctnpc);
					}
				}
			}
		}
	}
	
	printf("\n \033[31m>>>>> Profit Center Mapping Object Creation in PLM and Submit in Lifecycle Start 😄 \033[0m<<<<<<\n");fflush(stdout);
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d-%b-%Y %H:%M",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	tag_t tObjCreate_Input=NULLTAG;
	tag_t tDocObj_Type=NULLTAG;
	tag_t new_object=NULLTAG;

	ITK_CALL(TCTYPE_find_type ("T5_ProfitCenterMapping", NULL, &tDocObj_Type));
	ITK_CALL(TCTYPE_construct_create_input(tDocObj_Type, &tObjCreate_Input));
	if(tObjCreate_Input != NULLTAG)
	{
		printf(" Input Tag Not NULL..!!\n");fflush(stdout);
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"object_name",Name)); //Name
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"object_desc",Description)); //Description
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_BusinessUnit","CVBU")); //Business Unit
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_ERCDMLNo",ERCDMLNo)); //ERCDML No
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_VcNumber",partno)); //Vc Number
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_ProductLine",prodlineval)); //Product Line
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Platform",platformval)); //Platform
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Segment",segmentval)); //Segment
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_Variant",variantval)); //Variant
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_ProfitCenter",vcprofit_centre_sap)); //Profit Center
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_ApprovalStatus","PENDING")); //Approval Status
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_ExtraAttr1",ExtrAttr1)); //Extra Attr1 -> Part Release Date
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_ExtraAttr2",GenDate)); //Extra Attr1 -> Object Created Date
		ITK_CALL(AOM_set_value_string(tObjCreate_Input,"t5_ExtraAttr5",ExtrAttr5)); //Extra Attr5 -> Plant Code
		ITK_CALL(TCTYPE_create_object(tObjCreate_Input, &new_object));
		ITK_CALL(AOM_save_with_extensions(new_object));
		printf("\n Save...!!\n");
		ITK_CALL(AOM_unlock(new_object));
		printf("\n Unlock..!!\n");
		if(new_object != NULLTAG)
		{
		  printf("\n \033[31m>>>>> Profit Center Object Created 😄 \033[0m<<<<<<\n");fflush(stdout);
		  printf("\n Function3: PC Object Submit into Work-Flow Start\n");fflush(stdout);
		  Submit_PCObject_to_workflow(new_object);
		  printf("\n Function3: PC Object Submit into Work-Flow End\n");fflush(stdout);
		}
		else
		{
		   printf("\n \033[31m>>>>> Profit Center Object Not Created 😄 \033[0m<<<<<<\n");fflush(stdout);
		}	
	}
	else
	{
		printf(" Input Tag NULL..!!\n");fflush(stdout);
	}
	printf("\n \033[31m>>>>> Profit Center Mapping Object Creation in PLM and Submit in Lifecycle End 😄 \033[0m<<<<<<\n");fflush(stdout);


	return iFail;	
}

char* PC_Object_Exist_Status(char* PartNum,char* PartPlantCode)
{
	tag_t tPCObject = NULLTAG;
	int n_entriespc = 2;
	int n_itemobj_found_pc = 0;
	tag_t* titemobj_results_pc = NULLTAG;
	tag_t tsubmodlib_rev_npr = NULLTAG;
    char* pcobjectstat = NULL;
	
	ITK_CALL(QRY_find2("Profit_Center_Mapping_Query",&tPCObject));
	if(tPCObject != NULLTAG)
	{
		printf("\n Query[Profit_Center_Mapping_Query] Found Successfully..!!\n");fflush(stdout);
		char *cEntriespc[2]  = {"Vc Number","Extra Attr5"};
		char *cValuespc[2]  = {PartNum,PartPlantCode};
		//char *cValuespc[2]  = {"55552735000R","1001"};
		ITK_CALL(QRY_execute(tPCObject, n_entriespc, cEntriespc, cValuespc, &n_itemobj_found_pc, &titemobj_results_pc));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Profit_Center_Mapping_Query] Found: [%d]\n",n_itemobj_found_pc);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found_pc > 0)
		{
			printf("\n Profit Center Object Found..!!\n");fflush(stdout);
		    tc_strdup("YES",&pcobjectstat);   
		}
		else
		{
		   printf("\n Profit Center Object Not Found..!!\n");fflush(stdout);
		   tc_strdup("NO",&pcobjectstat);
		}					
	}
	else
	{
		printf("\n Query[Profit_Center_Mapping_Query] Tag Not Found..!!");fflush(stdout);
		tc_strdup("NO",&pcobjectstat);
	}
	   
	return pcobjectstat;
}

int PC_Create_Status_Check(char* DMLPlantCode,tag_t PartRevisionTag,char* PNo,char* PRS,char* PDesc,char* APLDMLNo)
{
	char *PartRev = NULL;
	char *PartSeq = NULL;
	char *PartRevDup = NULL;
	char *PartSeqDup = NULL;
	char *PCObjectName = (char *) MEM_alloc(100 * sizeof(char));
	int iFail = ITK_ok;
	PartRev = tc_strtok(PRS,";");
	PartSeq = tc_strtok(NULL,";");
	if(PartRev!=NULL)tc_strdup(PartRev,&PartRevDup);
	if(PartSeq!=NULL)tc_strdup(PartSeq,&PartSeqDup);
	int status_count = 0;
	tag_t* relStatus_list = NULLTAG;
	char* latest_rev_Rel_StatusDup = NULL;
	char* PCObjStat = NULL;
	char *Dt_Rlzd = NULL;
	
	ITK_CALL(WSOM_ask_release_status_list(PartRevisionTag, &status_count, &relStatus_list));
	printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
	if(status_count>0)
	{
		int g = 0;
		for(g = 0; g<status_count; g++)
		{
			ITK_CALL(AOM_ask_value_string(relStatus_list[g],"object_name",&latest_rev_Rel_StatusDup));
			printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
			if((tc_strcmp(DMLPlantCode,"APLP")==0) && (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsAplpRlzd")==0))
			{ 
		        ITK_CALL(AOM_UIF_ask_value(relStatus_list[g],"date_released",&Dt_Rlzd));
			    printf(" \n APLP Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
				tc_strcpy(PCObjectName,PNo); //APLP
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartRevDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartSeqDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,"1001");
				printf("\n \033[31m>>>>> DML Plant: [%s] & Part Release Status: [%s] Matched & PC Object Name [%s] Created 😄 \033[0m<<<<<<\n",DMLPlantCode,latest_rev_Rel_StatusDup,PCObjectName);fflush(stdout);
				PCObjStat = PC_Object_Exist_Status(PNo,"1001");
				if(tc_strcmp(PCObjStat,"NO")==0)
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Not Present So, Creation and Submit in Life-Cycle Start 😄 \033[0m<<<<<<\n");fflush(stdout);
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation Start\n");fflush(stdout);
					TC_VCClassification_Details(PNo,PartRev,PartSeq,PCObjectName,PDesc,APLDMLNo,Dt_Rlzd,"1001");
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation End\n");fflush(stdout);
				}
				else
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Object Already Created 😄 \033[0m<<<<<<\n");fflush(stdout);
				}
			}
			else if((tc_strcmp(DMLPlantCode,"APLL")==0) && (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsApllRlzd")==0))
			{
				ITK_CALL(AOM_UIF_ask_value(relStatus_list[g],"date_released",&Dt_Rlzd));
			    printf(" \n APLL Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
				tc_strcpy(PCObjectName,PNo); //APLL
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartRevDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartSeqDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,"3001");
				printf("\n \033[31m>>>>> DML Plant: [%s] & Part Release Status: [%s] Matched & PC Object Name [%s] Created 😄 \033[0m<<<<<<\n",DMLPlantCode,latest_rev_Rel_StatusDup,PCObjectName);fflush(stdout);
				PCObjStat = PC_Object_Exist_Status(PNo,"3001");
				if(tc_strcmp(PCObjStat,"NO")==0)
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Not Present So, Creation and Submit in Life-Cycle Start 😄 \033[0m<<<<<<\n");fflush(stdout);
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation Start\n");fflush(stdout);
					TC_VCClassification_Details(PNo,PartRev,PartSeq,PCObjectName,PDesc,APLDMLNo,Dt_Rlzd,"3001");
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation End\n");fflush(stdout);
				}
				else
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Object Already Created 😄 \033[0m<<<<<<\n");fflush(stdout);
				}
			}
			else if((tc_strcmp(DMLPlantCode,"APLJ")==0) && (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsApljRlzd")==0))
			{
				ITK_CALL(AOM_UIF_ask_value(relStatus_list[g],"date_released",&Dt_Rlzd));
			    printf(" \n APLJ Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
				tc_strcpy(PCObjectName,PNo); //APLJ
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartRevDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartSeqDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,"2001");
				printf("\n \033[31m>>>>> DML Plant: [%s] & Part Release Status: [%s] Matched & PC Object Name [%s] Created 😄 \033[0m<<<<<<\n",DMLPlantCode,latest_rev_Rel_StatusDup,PCObjectName);fflush(stdout);
				PCObjStat = PC_Object_Exist_Status(PNo,"2001");
				if(tc_strcmp(PCObjStat,"NO")==0)
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Not Present So, Creation and Submit in Life-Cycle Start 😄 \033[0m<<<<<<\n");fflush(stdout);
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation Start\n");fflush(stdout);
					TC_VCClassification_Details(PNo,PartRev,PartSeq,PCObjectName,PDesc,APLDMLNo,Dt_Rlzd,"2001");
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation End\n");fflush(stdout);
				}
				else
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Object Already Created 😄 \033[0m<<<<<<\n");fflush(stdout);
				}
			}
			else if((tc_strcmp(DMLPlantCode,"APLU")==0) && (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsApluRlzd")==0))
			{
				ITK_CALL(AOM_UIF_ask_value(relStatus_list[g],"date_released",&Dt_Rlzd));
			    printf(" \n APLU Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
				tc_strcpy(PCObjectName,PNo); //APLU
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartRevDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartSeqDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,"3100");
				printf("\n \033[31m>>>>> DML Plant: [%s] & Part Release Status: [%s] Matched & PC Object Name [%s] Created 😄 \033[0m<<<<<<\n",DMLPlantCode,latest_rev_Rel_StatusDup,PCObjectName);fflush(stdout);
				PCObjStat = PC_Object_Exist_Status(PNo,"3100");
				if(tc_strcmp(PCObjStat,"NO")==0)
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Not Present So, Creation and Submit in Life-Cycle Start 😄 \033[0m<<<<<<\n");fflush(stdout);
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation Start\n");fflush(stdout);
					TC_VCClassification_Details(PNo,PartRev,PartSeq,PCObjectName,PDesc,APLDMLNo,Dt_Rlzd,"3100");
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation End\n");fflush(stdout);
				}
				else
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Object Already Created 😄 \033[0m<<<<<<\n");fflush(stdout);
				}
			}
			else if((tc_strcmp(DMLPlantCode,"APLD")==0) && (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsApldRlzd")==0))
			{
				ITK_CALL(AOM_UIF_ask_value(relStatus_list[g],"date_released",&Dt_Rlzd));
			    printf(" \n APLD Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
				tc_strcpy(PCObjectName,PNo); //APLD
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartRevDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,PartSeqDup);
				tc_strcat(PCObjectName,"_");
				tc_strcat(PCObjectName,"1500");
				printf("\n \033[31m>>>>> DML Plant: [%s] & Part Release Status: [%s] Matched & PC Object Name [%s] Created 😄 \033[0m<<<<<<\n",DMLPlantCode,latest_rev_Rel_StatusDup,PCObjectName);fflush(stdout);
				PCObjStat = PC_Object_Exist_Status(PNo,"1500");
				if(tc_strcmp(PCObjStat,"NO")==0)
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Not Present So, Creation and Submit in Life-Cycle Start 😄 \033[0m<<<<<<\n");fflush(stdout);
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation Start\n");fflush(stdout);
					TC_VCClassification_Details(PNo,PartRev,PartSeq,PCObjectName,PDesc,APLDMLNo,Dt_Rlzd,"1500");
					printf("\n Function2: Classification Attribute Details Find & PC Object Creation End\n");fflush(stdout);
				}
				else
				{
					printf("\n \033[31m>>>>> Profit Center Mapping Object Already Created 😄 \033[0m<<<<<<\n");fflush(stdout);
				}
			}
			else
			{
				printf("\n \033[31m>>>>> Continue, Release Status Not Matched: [%s] 😄 \033[0m<<<<<<\n",latest_rev_Rel_StatusDup);fflush(stdout);
			}
		}
	}
	else
	{
		printf("\n \033[31m>>>>> Part Release Status Not Stamped 😄 \033[0m<<<<<<\n");fflush(stdout);
	}

	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_id_str = NULL;
	char *inp_id_strDup = NULL;
	char *inp_plant_str = NULL;
	char *inp_plant_strDup = NULL;
	char *inp_dml_str = NULL;
	char *inp_dml_strDup = NULL;
	tag_t QueryTag = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	int i = 0;
	int num_to_sort = 1;
	char *keysAttr[1] =  {"creation_date"};
	int sort_order[1] = {2}; //1 --> Ascending Order & 2 --> Descending Order
	int resultcount = 0;
	tag_t* outtag = NULLTAG;
	tag_t PartRevTag = NULLTAG;
	char* PartNo = NULL;
	char* PartRevSeq = NULL;
	char* PartType = NULL;
	char* PartDesc = NULL;
	char* PartDescDup = NULL;
	char *DMLPlant = (char *) MEM_alloc(50 * sizeof(char));
	char *LCS = (char *) MEM_alloc(50 * sizeof(char));
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inp_id_str = ITK_ask_cli_argument("-i=");
	inp_plant_str = ITK_ask_cli_argument("-j=");
	inp_dml_str = ITK_ask_cli_argument("-c=");
	trimwhitespace(inp_id_str);
	trimwhitespace(inp_plant_str);
	trimwhitespace(inp_dml_str);
	if(inp_id_str!=NULL)tc_strdup(inp_id_str,&inp_id_strDup);
	if(inp_plant_str!=NULL)tc_strdup(inp_plant_str,&inp_plant_strDup);
	if(inp_dml_str!=NULL)tc_strdup(inp_dml_str,&inp_dml_strDup);
	printf(" [1]: Input Part No(inp_id_strDup): [%s]\n",inp_id_strDup);
	printf(" [2]: Input Plant Code(inp_plant_strDup): [%s]\n",inp_plant_strDup);
	printf(" [3]: Input Change No(inp_dml_strDup): [%s]\n",inp_dml_strDup);
	
	if(tc_strcmp(inp_plant_strDup,"1001")==0)  //APLP
	{
	   tc_strcpy(DMLPlant,"APLP");
	   tc_strcpy(LCS,"T5_LcsAplpRlzd");
	}
	else if(tc_strcmp(inp_plant_strDup,"3001")==0)  //APLL
	{
	   tc_strcpy(DMLPlant,"APLL");
	   tc_strcpy(LCS,"T5_LcsApllRlzd");
	}
	else if(tc_strcmp(inp_plant_strDup,"2001")==0) //APLJ
	{
	   tc_strcpy(DMLPlant,"APLJ"); 
	   tc_strcpy(LCS,"T5_LcsApljRlzd");
	}
	else if(tc_strcmp(inp_plant_strDup,"3100")==0) //APLU
	{
	   tc_strcpy(DMLPlant,"APLU");
	   tc_strcpy(LCS,"T5_LcsApluRlzd");
	}
	else if(tc_strcmp(inp_plant_strDup,"1500")==0) //APLD
	{
	   tc_strcpy(DMLPlant,"APLD");
       tc_strcpy(LCS,"T5_LcsApldRlzd");	   
	}
	else
	{
	    printf("\n  Input Plant Code Blank, So, Exit\n");fflush(stdout);
		goto CLEANUP;
	}
    printf("\n DML Plant Code: [%s]\n", DMLPlant);fflush(stdout);
	printf("\n Part LCS: [%s]\n", LCS);fflush(stdout);
	ITK_CALL(QRY_find2("Driver VC Query", &QueryTag));
	if(QueryTag != NULLTAG)
	{
	   printf("\n [Driver VC Query] Found Successfully..!!\n");fflush(stdout);
	   char *qry_entries[2]  = {"Item ID","Release Status"};
	   char *qry_values[2]  = {inp_id_strDup,LCS};
	   ITK_CALL(QRY_execute_with_sort(QueryTag, n_entries, qry_entries, qry_values, num_to_sort, keysAttr, sort_order, &resultcount, &outtag));
	   printf("\n -----------------------------------------------\n");fflush(stdout);
	   printf("\n  No of Object Found: [%d]\n",resultcount);fflush(stdout);
	   printf("\n -----------------------------------------------\n");fflush(stdout);
	    if(resultcount>0)
		{
			PartRevTag = outtag[0];
			ITK_CALL(AOM_ask_value_string(PartRevTag,"item_id",&PartNo));
			ITK_CALL(AOM_ask_value_string(PartRevTag,"item_revision_id",&PartRevSeq));
			ITK_CALL(AOM_ask_value_string(PartRevTag,"t5_PartType",&PartType));
			ITK_CALL(AOM_ask_value_string(PartRevTag,"object_desc",&PartDesc));
			printf("\n Part Description Before Dup & Trim:  <%s> \n",PartDesc);fflush(stdout);
			if(tc_strlen(PartDesc)>0)
			{
				tc_strdup(PartDesc,&PartDescDup);
			}
			else
			{
				tc_strdup("--",&PartDescDup);
				printf("\n Item Description Value is NULL");fflush(stdout);
			}
			trimwhitespace(PartDescDup);
			printf("\n Part Description Value After Dup & Trim: [%s]", PartDescDup);fflush(stdout);
			STRNG_replace_str(PartDescDup,","," ",&PartDescDup);
			STRNG_replace_str(PartDescDup,";"," ",&PartDescDup);
			STRNG_replace_str(PartDescDup,"\n"," ",&PartDescDup);
			STRNG_replace_str(PartDescDup,"'"," ",&PartDescDup);
			printf("\n Part Description Final Value: [%s]", PartDescDup);fflush(stdout);
			printf("\n Part Type: [%s]\n",PartType);fflush(stdout);
			printf("\n Part RevSeq: [%s]\n",PartRevSeq);fflush(stdout);
			printf("\n Part No: [%s]\n",PartNo);fflush(stdout);
			if(tc_strcmp(PartType,"VC")==0)
			{
				printf("\n Function1: As Part Type: VC So, [PC_Create_Status_Check] Start\n");fflush(stdout);
				PC_Create_Status_Check(DMLPlant,PartRevTag,PartNo,PartRevSeq,PartDescDup,inp_dml_strDup);
				printf("\n Function1: As Part Type: VC So, [PC_Create_Status_Check] End\n");fflush(stdout);
			}
			else
			{
				printf("\nInput Part's [%s] Part Type is Not VC in TCUA\n", inp_id_strDup);fflush(stdout);
			    goto CLEANUP;
			}
		}
		else
		{
			printf("\nPart [%s] Not Found APL Released For Plant [%s] in TCUA\n", inp_id_strDup,inp_plant_strDup);fflush(stdout);
			goto CLEANUP;
		}
	}
	else
	{
		printf("\n \033[31m>>>>> Query[Driver VC Query] Tag Not Found 😄 \033[0m<<<<<<\n");fflush(stdout);
	}

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_exit_module(TRUE);
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PartWisePC_Create_Submit_LC.c
* // ./linkitk -o tm_PartWisePC_Create_Submit_LC tm_PartWisePC_Create_Submit_LC.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/PartWisePC_Create_Submit_LC/tm_PartWisePC_Create_Submit_LC .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/PartWisePC_Create_Submit_LC/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/PartWisePC_Create_Submit_LC/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/PartWisePC_Create_Submit_LC/SendEmail.sh .
* // ./tm_PartWisePC_Create_Submit_LC -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -i=51746238000R -j=2001 -c=CORRCT171125
* // ./tm_PartWisePC_Create_Submit_LC -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=51746238000R -j=2001 -c=CORRCT171125
*
***************************************************************************/