######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : APRIL-2024
#
#######################################################################################
. /user/cvprod/.bash_profile

echo -e "\n~~~~~~~~~~ C R O N  S H E L L   S T A R T E D ~~~~~~~~~~~~"

cd /user/cvprod/PLMSAPMATJSR/
ls -lrt DMLList.lst
if [ $? == 0 ]
    then
        echo "Input File[DMLList.lst] Already Exist. So Remove Start..!!"
        rm -rf DMLList.lst
        echo "Input File[DMLList.lst] Remove End..!!"
else
    echo "Input File[DMLList.lst] Does Not Exist..!!"
fi
echo -e "\nEXE(tm_PLMSAPMatTransfer) Execution Started...."
/user/cvprod/PLMSAPMATJSR/tm_PLMSAPMatTransfer -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
echo -e "\nEXE(tm_PLMSAPMatTransfer) Execution Ended...."
chmod 777 DMLList.lst
sleep 10
GENDATETIME=`date +"%d_%b_%Y_%H_%M_%S"`
echo "Generated DMLList Date & Time: " $GENDATETIME >> MasterDMLList.txt
cat DMLList.lst >> MasterDMLList.txt
sort -u MasterDMLList.txt -o SortMasterDMLList.txt
rm -rf MasterDMLList.txt
mv SortMasterDMLList.txt MasterDMLList.txt
chmod 777 MasterDMLList.txt
ls -lrt DMLList.lst
if [ $? == 0 ]
    then
        echo "Input File[DMLList.lst] Present..!!"
echo -e "\nMaterial Transfer Program Started...."
        ./Material_Transfer_JSR_PLMSAP.sh
echo -e "\nMaterial Transfer Program Ended...."
        echo "Material Transfer Report Send To Email Start..!!"
        echo -e "Dear All, \n\n                Please Check Attached Report of Transferred DML.\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Plese do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS : PLM-SAP Material Transfer" -a DMLList.lst souravk.ttl@tatamotors.com poonams.ttl@tatamotors.com
echo "Material Transfer Report Send To Email End..!!"
else
    echo "Input File[DMLList.lst] Not Present..!!"
echo "Material Transfer Failed Report Send To Developer Email Start..!!"
echo -e "Dear Team, \n\n                There is Some Issue in Material Transfer.\n                Please Check Log & Re-Run Job.\n\nRegrds,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED : PLM-SAP Material Transfer" souravk.ttl@tatamotors.com
echo "Material Transfer Failed Report Send To Developer Email End..!!"
fi
echo -e "\n~~~~~~~~~~ C R O N  S H E L L   E N D E D ~~~~~~~~~~~~"
