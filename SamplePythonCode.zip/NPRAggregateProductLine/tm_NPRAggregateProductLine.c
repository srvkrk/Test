/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: tm_NPRAggregateProductLine.c
**
** Functions:- 	This utility takes all created NPR object and check Platform value accordingly update product line as AGGR-BUSINESS
                1. AGE_ AGGREGATE_GENSET_ENGINE
				2. AIE_ AGGREGATE_INDUSTRIAL_ENGINE
				3. ALA_ AGGREGATE_LIVE_AXLE
				4. ATA_ AGGREGATE_TRAILER_AXLE
***********************************************************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_platform_str = NULL;
	char *item_platform_strDup = NULL;
	char *item_prodline_str = NULL;	
	char *item_prodline_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	tag_t DesRev_tag = NULLTAG;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char*  F_date = ITK_ask_cli_argument("-F=");
	char*  T_date = ITK_ask_cli_argument("-T=");
	char* From_date = NULL;
	char* To_date = NULL;
	From_date = (char *) MEM_alloc(100);
	To_date = (char *) MEM_alloc(100);
			
	tc_strcpy(From_date,"");
	tc_strcpy(From_date,F_date);
	tc_strcat(From_date," 00:00");
			
	tc_strcpy(To_date,"");
	tc_strcpy(To_date,T_date);
	tc_strcat(To_date," 23:59");
	
	printf(" [1]: Input From_Date(From_date): [%s]\n",From_date);
	printf(" [2]: Input To_Date(To_date): [%s]\n",To_date);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	//tc_strcpy(RptFile,"/tmp/");
	tc_strcpy(RptFile,"NPR_Aggregate_ProductLine");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Name Generated..!!");fflush(stdout);
	FILE* fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"NPR_NO, PLATFORM, PRODUCT_LINE, \n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
		printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	ITK_CALL(QRY_find2("Item...",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n [Item...] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Type","Created After","Created Before"};
		char *cValues[3]  = {"New Part Request",From_date,To_date};
		//char *cValues[3]  = {"New Part Request","07-Apr-2024","02-Aug-2025"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of NPR Object Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		for (i = 0; i < n_itemobj_found; i++)
		{
			DesRev_tag = titemobj_results[i];
			ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
			if(tc_strlen(item_id_str)>0)
			{
				tc_strdup(item_id_str,&item_id_strDup);
				trimwhitespace(item_id_strDup);
			}
			else
			{
				tc_strdup("NA",&item_id_strDup);
				printf("\n NPR Number Value is NULL..!!");fflush(stdout);
			}
			printf("\n NPR Item: [%s]\n",item_id_strDup);fflush(stdout);
			if(tc_strlen(item_id_strDup)==25)
			{
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Plateform",&item_platform_str));
				if(tc_strlen(item_platform_str)>0)
				{
					tc_strdup(item_platform_str,&item_platform_strDup);
					trimwhitespace(item_platform_strDup);
				}
				else
				{
					tc_strdup("NA",&item_platform_strDup);
					printf("\n NPR Platform Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ProductLine",&item_prodline_str));
				if(tc_strlen(item_prodline_str)>0)
				{
					tc_strdup(item_prodline_str,&item_prodline_strDup);
					trimwhitespace(item_prodline_strDup);
				}
				else
				{
					tc_strdup("NA",&item_prodline_strDup);
					printf("\n NPR Platform Value is NULL..!!");fflush(stdout);
				}
				if((tc_strcmp(item_platform_strDup,"AGE-AGGREGATE_GENSET_ENGINE")==0) || (tc_strcmp(item_platform_strDup,"AIE-AGGREGATE_INDUSTRIAL_ENGINE")==0) || (tc_strcmp(item_platform_strDup,"ALA-AGGREGATE_LIVE_AXLE")==0) || (tc_strcmp(item_platform_strDup,"ATA-AGGREGATE_TRAILER_AXLE")==0))
				{
					if(tc_strcmp(item_prodline_strDup,"AGGR-BUSINESS")!=0)
					{
						fprintf(fpOutput_file,"%s,%s,%s\n",item_id_strDup,item_platform_strDup,item_prodline_strDup);fflush(fpOutput_file);
					}
					else
					{
						printf(" Product_Line Already Updated As[AGGR-BUSINESS]..!!\n");fflush(stdout);
					}
				}
				else
				{
					printf(" Platform Value Not Related To AGGREGATE..!!\n");fflush(stdout);
				}
			}			
		}
	}
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_NPRAggregateProductLine.c
* // ./linkitk -o tm_NPRAggregateProductLine tm_NPRAggregateProductLine.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/NPRAggregateProductLine/tm_NPRAggregateProductLine .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/NPRAggregateProductLine/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/NPRAggregateProductLine/usage.txt .
* // ./tm_NPRAggregateProductLine -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_NPRAggregateProductLine -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/