/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: tm_NPRDashboardRpt.c
**
** Functions:- 	This utility takes from_date & to_date as input & generates NPR submitted between that dat's signoff history report
**
***********************************************************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <epm/signoff.h>
#include <ce/ce.h>
#include <tc/folder.h>
#include <tccore/project.h>
#include <tc/tc_startup.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <ug_va_copy.h>
#include <base_utils/Mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/item_msg.h>
#include <constants/constants.h>
#include <common/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>
#include <time.h>
#include <stdbool.h>
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


int	ifail = ITK_ok;
FILE *Report = NULL;
int ctr=0;

int read_value_from_file(char*);
//int get_object(char* item_id);
int get_object();
int get_owning_user_and_group(tag_t);
void setAddTAG(int *count,tag_t **objlist,tag_t obj );

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"NewPartRequest -u=<username> -pf=<password> -g=<group> -i=<NPRMaster>\n"
	"--------------------------------------------------------------------\n\n"
	);fflush(stdout);
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
					It checks for the proper Usr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int a;
	const char* u = NULL;
	const char* p = NULL;
	const char* g = NULL;
	char* itemId = NULL;
	char* rev = NULL;
	char* propName = NULL;
	char* propValue	= NULL;

	u = ITK_ask_cli_argument( "-u=loader");
	p = ITK_ask_cli_argument( "-pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf");
	g = ITK_ask_cli_argument( "-g=dba");

	char*  F_date = ITK_ask_cli_argument("-F=");
	char*  T_date = ITK_ask_cli_argument("-T=");
	char*   From_date = NULL;
	char*   To_date = NULL;
	
	From_date = (char *) MEM_alloc(100);
	To_date = (char *) MEM_alloc(100);
			
	tc_strcpy(From_date,"");
	tc_strcpy(From_date,F_date);
	tc_strcat(From_date," 00:00");
			
	tc_strcpy(To_date,"");
	tc_strcpy(To_date,T_date);
	tc_strcat(To_date," 23:59");
	printf("\n\n\n\n\n From Date: [%s] \n To Date: [%s]",From_date,To_date);fflush(stdout);
	
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("\n Error in Login to Teamcenter\n");fflush(stdout);
		return ifail;
	}
	else
	{
		printf("\n Login Successfull.....!!\n");fflush(stdout);
		printf("\n Welcome to Teamcenter.....!!\n");fflush(stdout);
	}

	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		ifail = ITK_set_bypass(true);
		//output = fopen("output.csv", "w");
		//ifail = get_object();
		ifail = get_object(From_date,To_date);		
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\n User is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}

	printf("\nEnd of program.....!!\n");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
/*
int read_value_from_file(char* Filename)
{
	char 		*itemid					= NULL;
	char 		temp[200];

	FILE		* fp 					= NULL;

	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "~");
				printf("\nInput Item_id:%s\n",itemid);fflush(stdout);

				ifail = get_object(itemid);
			}
			printf("***************************************\n");fflush(stdout);
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");fflush(stdout);
	}
	fclose(fp);
	return ifail;
}
*/


/********************************************************************************************
    Function:       get_object
    Description:    This function takes the item_id as input and queries into TC and gets
					item, BV, item_rev, it's BVR, and secondary object.
********************************************************************************************/

char* NewPartsubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf = NULL;
	//retStringf = (char*) malloc(30);
	retStringf = (char *) MEM_alloc( 30 * sizeof(char) );
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;

}

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

/* Function to add Tag into a set of Tag */
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTAG1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTAG2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y_%H_%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%m_%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

char* MonthAbbreviation (char* MonthName)
{
	//char *ResponseMonth = (char *) malloc(400*sizeof(char));
	char *ResponseMonth = NULL;
	ResponseMonth = (char *) MEM_alloc( 400 * sizeof(char) );
	printf("\n Input Month Name in String: --------> [%s]\n", MonthName);fflush(stdout);
	if(tc_strcmp(MonthName,"Jan")==0)
	{
		tc_strcpy(ResponseMonth,"01");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Feb")==0)
	{
		tc_strcpy(ResponseMonth,"02");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Mar")==0)
	{
		tc_strcpy(ResponseMonth,"03");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Apr")==0)
	{
		tc_strcpy(ResponseMonth,"04");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"May")==0)
	{
		tc_strcpy(ResponseMonth,"05");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Jun")==0)
	{
		tc_strcpy(ResponseMonth,"06");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Jul")==0)
	{
		tc_strcpy(ResponseMonth,"07");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Aug")==0)
	{
		tc_strcpy(ResponseMonth,"08");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Sep")==0)
	{
		tc_strcpy(ResponseMonth,"09");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Oct")==0)
	{
		tc_strcpy(ResponseMonth,"10");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Nov")==0)
	{
		tc_strcpy(ResponseMonth,"11");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Dec")==0)
	{
		tc_strcpy(ResponseMonth,"12");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else
	{
		printf("Invalid Number");
	}
	  
	return ResponseMonth;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

// Function to calculate the number of weekdays between two dates
int weekdayDifference(struct tm start_date, struct tm end_date) 
{
    int weekday_count = 0;
    time_t start_time = mktime(&start_date);
    time_t end_time = mktime(&end_date);
    
    // Handle cases where start_date is after end_date
    if (start_time > end_time) 
    {
        return -1;
    }

    //while (start_time <= end_time)
	while (start_time < end_time)
    {
        struct tm current_date = *localtime(&start_time);
        int day_of_week = current_date.tm_wday;

        // Check if the current day is not a Saturday (6) or Sunday (0)
        if (day_of_week != 0 && day_of_week != 6) 
        {
            weekday_count++;
        }

        // Increment the time by one day
        start_time += 24 * 60 * 60; // Add 24 hours in seconds
    }

    return weekday_count;
}

void replaceSpacesWithSlash(char *str) {
    int i;
    // Iterate through the string until the null terminator is reached
    for (i = 0; str[i] != '\0'; i++) {
        // If the current character is a space, replace it with a forward slash
        if (str[i] == ' ') {
            str[i] = '/';
        }
    }
}

int TC_DaysCount(char* MccStartDate,char* NPRMCCApproveDate)
{
	printf(" @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@\n");fflush(stdout);
	char CrDate[100] = "";
	time_t 	loc;
	struct 	tm when;
	time(&loc);
	when = *localtime(&loc);
	strftime(CrDate,100,"%d-%m-%Y %H:%M",&when);
	printf(" Current TimeStamp: [%s]\n", CrDate);fflush(stdout);
	
	printf(" MccStartDate: [%s]\n", MccStartDate);fflush(stdout);
	printf(" NPRMCCApproveDate: [%s]\n", NPRMCCApproveDate);fflush(stdout);
	printf(" Current Time: [%s]\n", CrDate);fflush(stdout);
	
	/* @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@*/
	int difference = 0;
	if((tc_strstr(MccStartDate,"Jan")!=NULL) || (tc_strstr(MccStartDate,"Feb")!=NULL) || (tc_strstr(MccStartDate,"Mar")!=NULL) || (tc_strstr(MccStartDate,"Apr")!=NULL) || (tc_strstr(MccStartDate,"May")!=NULL) || (tc_strstr(MccStartDate,"Jun")!=NULL) || (tc_strstr(MccStartDate,"Jul")!=NULL) || (tc_strstr(MccStartDate,"Aug")!=NULL) || (tc_strstr(MccStartDate,"Sep")!=NULL) || (tc_strstr(MccStartDate,"Oct")!=NULL) || (tc_strstr(MccStartDate,"Nov")!=NULL) || (tc_strstr(MccStartDate,"Dec")!=NULL))
	{
		if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA") !=0))
		{
			char* ReNwMccStartDate = NULL;
			ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwMccStartDate,MccStartDate);
			printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwMccStartDate);
			if(ReNwMccStartDate != NULL)
			{
				STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
			}
			 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
			char* Freceived = NULL;
			char* Sreceived = NULL;
			Freceived = tc_strtok(ReNwMccStartDate,"/");
			Sreceived = tc_strtok(NULL,"/");
			printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
			printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
			char* ReInpDay = NULL;
			char* ReInpMon = NULL;
			char* ReInpYear = NULL;
			char* ReInpYearChar = NULL;
			ReInpDay=tc_strtok(Freceived,"-");
			ReInpMon=tc_strtok(NULL,"-");
			ReInpYear=tc_strtok(NULL,"-");
			printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
			printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
			char* RespMonth = NULL;
			RespMonth = MonthAbbreviation(ReInpMon);
			printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
			printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
			
			
			char* ReNwNPRMCCApproveDate = NULL;
			ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwNPRMCCApproveDate,NPRMCCApproveDate);
			printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
			if(ReNwNPRMCCApproveDate != NULL)
			{
				STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
			}
			printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			char* Fcompleted = NULL;
			char* Scompleted = NULL;
			Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
			Scompleted = tc_strtok(NULL,"/");
			printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
			printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
			char* ComInpDay = NULL;
			char* ComInpMon = NULL;
			char* ComInpYear = NULL;
			char* ComInpYearChar = NULL;
			ComInpDay=tc_strtok(Fcompleted,"-");
			ComInpMon=tc_strtok(NULL,"-");
			ComInpYear=tc_strtok(NULL,"-");
			printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
			printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
			char* ComRespMonth = NULL;
			ComRespMonth = MonthAbbreviation(ComInpMon);
			printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
			printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
			
			int ReInpdayFinal = atoi(ReInpDay);
			int ReInpMonFinal = atoi(RespMonth);
			int ReInpYearFinal = atoi(ReInpYear);
			
			int ComInpDayFinal = atoi(ComInpDay);
			int ComInpMonFinal = atoi(ComRespMonth);
			int ComInpYearFinal = atoi(ComInpYear);
		
			struct tm start_date = {0};
			struct tm end_date = {0};

			// Example usage: Setting the dates
			start_date.tm_year = ReInpYearFinal; // Year - 1900
			start_date.tm_mon = ReInpMonFinal; // Month (0-11)
			start_date.tm_mday = ReInpdayFinal; // Day of the month (1-31)

			end_date.tm_year = ComInpYearFinal;
			end_date.tm_mon = ComInpMonFinal;
			end_date.tm_mday = ComInpDayFinal;


			difference = weekdayDifference(start_date, end_date);

			if (difference != -1) 
			{
				 printf("Difference: [%d]", difference);
			} 
			else 
			{
				difference = 0;
				printf("Difference: [%d]", difference);
			}
			printf("Number of weekdays between the dates: [%d]\n", difference);
		}
		else if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA") ==0))
		{
			char* ReNwMccStartDate = NULL;
			ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwMccStartDate,MccStartDate);
			printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwMccStartDate);
			if(ReNwMccStartDate != NULL)
			{
				STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
			}
			 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
			char* Freceived = NULL;
			char* Sreceived = NULL;
			Freceived = tc_strtok(ReNwMccStartDate,"/");
			Sreceived = tc_strtok(NULL,"/");
			printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
			printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
			char* ReInpDay = NULL;
			char* ReInpMon = NULL;
			char* ReInpYear = NULL;
			//char* ReInpYearChar = NULL;
			ReInpDay=tc_strtok(Freceived,"-");
			ReInpMon=tc_strtok(NULL,"-");
			ReInpYear=tc_strtok(NULL,"-");
			printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
			printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
			char* RespMonth = NULL;
			RespMonth = MonthAbbreviation(ReInpMon);
			printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
			printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
			
			char* ReNwNPRMCCApproveDate = NULL;
			ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwNPRMCCApproveDate,CrDate);
			printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
			if(ReNwNPRMCCApproveDate != NULL)
			{
				STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
			}
			printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			char* Fcompleted = NULL;
			char* Scompleted = NULL;
			Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
			Scompleted = tc_strtok(NULL,"/");
			printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
			printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
			char* ComInpDay = NULL;
			char* ComInpMon = NULL;
			char* ComInpYear = NULL;
			//char* ComInpYearChar = NULL;
			ComInpDay=tc_strtok(Fcompleted,"-");
			ComInpMon=tc_strtok(NULL,"-");
			ComInpYear=tc_strtok(NULL,"-");
			printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
			printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
			//char* ComRespMonth = NULL;
			//ComRespMonth = MonthAbbreviation(ComInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
			printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
			
			int ReInpdayFinal = atoi(ReInpDay);
			int ReInpMonFinal = atoi(RespMonth);
			int ReInpYearFinal = atoi(ReInpYear);
			
			int ComInpDayFinal = atoi(ComInpDay);
			int ComInpMonFinal = atoi(ComInpMon);
			int ComInpYearFinal = atoi(ComInpYear);
			
			struct tm start_date = {0};
			struct tm end_date = {0};

			// Example usage: Setting the dates
			start_date.tm_year = ReInpYearFinal; // Year - 1900
			start_date.tm_mon = ReInpMonFinal; // Month (0-11)
			start_date.tm_mday = ReInpdayFinal; // Day of the month (1-31)

			end_date.tm_year = ComInpYearFinal;
			end_date.tm_mon = ComInpMonFinal;
			end_date.tm_mday = ComInpDayFinal;


			difference = weekdayDifference(start_date, end_date);

			if (difference != -1) 
			{
				 printf("Difference: [%d]", difference);
			} 
			else 
			{
				difference = 0;
				printf("Difference: [%d]", difference);
			}
			printf("Number of weekdays between the dates: [%d]\n", difference);
		}
		else
		{
			difference = 0;
		}
	}
	else
	{
		if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA") !=0))
		{
			char* ReNwMccStartDate = NULL;
			ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwMccStartDate,MccStartDate);
			printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwMccStartDate);
			if(ReNwMccStartDate != NULL)
			{
				STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
			}
			 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
			char* Freceived = NULL;
			char* Sreceived = NULL;
			Freceived = tc_strtok(ReNwMccStartDate,"/");
			Sreceived = tc_strtok(NULL,"/");
			printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
			printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
			char* ReInpDay = NULL;
			char* ReInpMon = NULL;
			char* ReInpYear = NULL;
			char* ReInpYearChar = NULL;
			ReInpDay=tc_strtok(Freceived,"-");
			ReInpMon=tc_strtok(NULL,"-");
			ReInpYear=tc_strtok(NULL,"-");
			printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
			printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
			//char* RespMonth = NULL;
			//RespMonth = MonthAbbreviation(ReInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
			printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
			
			
			char* ReNwNPRMCCApproveDate = NULL;
			ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwNPRMCCApproveDate,NPRMCCApproveDate);
			printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
			if(ReNwNPRMCCApproveDate != NULL)
			{
				STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
			}
			printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			char* Fcompleted = NULL;
			char* Scompleted = NULL;
			Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
			Scompleted = tc_strtok(NULL,"/");
			printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
			printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
			char* ComInpDay = NULL;
			char* ComInpMon = NULL;
			char* ComInpYear = NULL;
			char* ComInpYearChar = NULL;
			ComInpDay=tc_strtok(Fcompleted,"-");
			ComInpMon=tc_strtok(NULL,"-");
			ComInpYear=tc_strtok(NULL,"-");
			printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
			printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
			//char* ComRespMonth = NULL;
			//ComRespMonth = MonthAbbreviation(ComInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
			printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
			
			int ReInpdayFinal = atoi(ReInpDay);
			int ReInpMonFinal = atoi(ReInpMon);
			int ReInpYearFinal = atoi(ReInpYear);
			
			int ComInpDayFinal = atoi(ComInpDay);
			int ComInpMonFinal = atoi(ComInpMon);
			int ComInpYearFinal = atoi(ComInpYear);
		
			struct tm start_date = {0};
			struct tm end_date = {0};

			// Example usage: Setting the dates
			start_date.tm_year = ReInpYearFinal; // Year - 1900
			start_date.tm_mon = ReInpMonFinal; // Month (0-11)
			start_date.tm_mday = ReInpdayFinal; // Day of the month (1-31)

			end_date.tm_year = ComInpYearFinal;
			end_date.tm_mon = ComInpMonFinal;
			end_date.tm_mday = ComInpDayFinal;


			difference = weekdayDifference(start_date, end_date);

			if (difference != -1) 
			{
				 printf("Difference: [%d]", difference);
			} 
			else 
			{
				difference = 0;
				printf("Difference: [%d]", difference);
			}
			printf("Number of weekdays between the dates: [%d]\n", difference);
		}
		else if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA")==0))
		{
			char* ReNwMccStartDate = NULL;
			ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwMccStartDate,MccStartDate);
			printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwMccStartDate);
			if(ReNwMccStartDate != NULL)
			{
				STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
			}
			 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
			char* Freceived = NULL;
			char* Sreceived = NULL;
			Freceived = tc_strtok(ReNwMccStartDate,"/");
			Sreceived = tc_strtok(NULL,"/");
			printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
			printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
			char* ReInpDay = NULL;
			char* ReInpMon = NULL;
			char* ReInpYear = NULL;
			//char* ReInpYearChar = NULL;
			ReInpDay=tc_strtok(Freceived,"-");
			ReInpMon=tc_strtok(NULL,"-");
			ReInpYear=tc_strtok(NULL,"-");
			printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
			printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
			//char* RespMonth = NULL;
			//RespMonth = MonthAbbreviation(ReInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
			printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
			
			char* ReNwNPRMCCApproveDate = NULL;
			ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwNPRMCCApproveDate,CrDate);
			printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
			if(ReNwNPRMCCApproveDate != NULL)
			{
				STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
			}
			printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			char* Fcompleted = NULL;
			char* Scompleted = NULL;
			Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
			Scompleted = tc_strtok(NULL,"/");
			printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
			printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
			char* ComInpDay = NULL;
			char* ComInpMon = NULL;
			char* ComInpYear = NULL;
			//char* ComInpYearChar = NULL;
			ComInpDay=tc_strtok(Fcompleted,"-");
			ComInpMon=tc_strtok(NULL,"-");
			ComInpYear=tc_strtok(NULL,"-");
			printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
			printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
			//char* ComRespMonth = NULL;
			//ComRespMonth = MonthAbbreviation(ComInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
			printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
			
			int ReInpdayFinal = atoi(ReInpDay);
			int ReInpMonFinal = atoi(ReInpMon);
			int ReInpYearFinal = atoi(ReInpYear);
			
			int ComInpDayFinal = atoi(ComInpDay);
			int ComInpMonFinal = atoi(ComInpMon);
			int ComInpYearFinal = atoi(ComInpYear);
			
			struct tm start_date = {0};
			struct tm end_date = {0};

			// Example usage: Setting the dates
			start_date.tm_year = ReInpYearFinal; // Year - 1900
			start_date.tm_mon = ReInpMonFinal; // Month (0-11)
			start_date.tm_mday = ReInpdayFinal; // Day of the month (1-31)

			end_date.tm_year = ComInpYearFinal;
			end_date.tm_mon = ComInpMonFinal;
			end_date.tm_mday = ComInpDayFinal;


			difference = weekdayDifference(start_date, end_date);

			if (difference != -1) 
			{
				 printf("Difference: [%d]", difference);
			} 
			else 
			{
				difference = 0;
				printf("Difference: [%d]", difference);
			}
			printf("Number of weekdays between the dates: [%d]\n", difference);
		}
		else
		{
			difference = 0;
		}
	}						
/* @@@@@@@@@@@@@@@  Weekdays calculation logic end @@@@@@@@@@@@@@@@ */
	printf(" @@@@@@@@@@@@@ Weekdays calculation logic end @@@@@@@@@@@@@@\n");fflush(stdout);
	return difference;	
}

int get_object(char* s_date, char* e_date)
{
	int				n_tags_found				= 0;
	int				count						= 0;
	int				totalprocess				= 0;
	int				processcounter				= 0;
	int				ModuleRevsignOfCount		= 0;
	int				COCsignOfCount				= 0;
	int				COCHsignOfCount				= 0;
	int				MCCsignOfCount				= 0;
	int				AssignsignOfCount			= 0;
	int				ACKNOWsignOfCount			= 0;
	int				reviewcounter				= 0;
	int				process_counter				= 0;
	int				ModuleTL					= 0;
	int				COCP						= 0;
	int				COCH						= 0;
	int				MCC							= 0;
	int				ASSIGN						= 0;
	int             ACKNOW                      = 0;

	tag_t			itemRev_t				= NULLTAG;
	tag_t			latest_rev_tag			= NULLTAG;
	tag_t			*ProcessStageList		= NULLTAG;
	tag_t			query					= NULLTAG;
	tag_t			ProcessStage			= NULLTAG;

	tag_t			*tags_found				= NULLTAG;
	tag_t			*ModuleRevSignOffTeam	= NULLTAG;
	tag_t			*COCSignOffTeam			= NULLTAG;
	tag_t			*COCHSignOffTeam		= NULLTAG;
	tag_t			*MCCSignOffTeam			= NULLTAG;
	tag_t			*AssignSignOffTeam		= NULLTAG;
	tag_t			*ACKNOWSignOffTeam		= NULLTAG;
	tag_t			Process_Stage			= NULLTAG;
	tag_t			ReviewProcessStage		= NULLTAG;


	FILE		*output 			= NULL;
	FILE		*output1 			= NULL;


	char 			*AssignedTCUATmlPartNumber	= NULL;
	char 			*NewPartReqNumber			= NULL;
	char 			*LatRev_ObjectType			= NULL;
	char 			*NPRCreator					= NULL;
	char 			*processName				= NULL;
	char 			*processResult				= NULL;
	char 			*processState				= NULL;
	char 			*processtype				= NULL;
	char 			*processname				= NULL;

	char 			*ModuleRevprocessResult		= NULL;
	char 			*ModuleRevprocessState		= NULL;
	char 			*ModuleRevprocessStDate		= NULL;
	char 			*ModuleRevprocessEndDate	= NULL;
	char 			*ModuleRevprocessPerformer	= NULL;

	char 			*COCPprocessResult			= NULL;
	char 			*COCPprocessState			= NULL;
	char 			*COCPprocessStDate			= NULL;
	char 			*COCPprocessEndDate			= NULL;
	char 			*COCPprocessPerformer		= NULL;

	char 			*COCHprocessResult			= NULL;
	char 			*COCHprocessState			= NULL;
	char 			*COCHprocessStDate			= NULL;
	char 			*COCHprocessEndDate			= NULL;
	char 			*COCHprocessPerformer		= NULL;

	char 			*MCCprocessResult			= NULL;
	char 			*MCCprocessState			= NULL;
	char 			*MCCprocessStDate			= NULL;
	char 			*MCCprocessEndDate			= NULL;
	char 			*MCCprocessPerformer		= NULL;

	char 			*ModuleRevSignOffTeamMember		= NULL;
	char 			*COCPSignOffTeamMember			= NULL;
	char 			*COCHSignOffTeamMember			= NULL;
	char 			*MCCSignOffTeamMember			= NULL;
	char 			*AssignSignOffTeamMember		= NULL;
	char 			*ACKNOWSignOffTeamMember		= NULL;
	char 			*MCCSignOffStatus		= NULL;

	char 			*AssignprocessResult			= NULL;
	char 			*AssignprocessState				= NULL;
	char 			*AssignprocessStDate			= NULL;
	char 			*AssignprocessEndDate			= NULL;
	char 			*AssignprocessPerformer			= NULL;
	
	char 			*ACKNOWprocessResult		= NULL;
	char 			*ACKNOWprocessState			= NULL;
	char 			*ACKNOWprocessStDate		= NULL;
	char 			*ACKNOWprocessEndDate		= NULL;
	char 			*ACKNOWprocessPerformer		= NULL;

	char 			*process_Name					= NULL;
	char 			*process_type					= NULL;
	char 			*MCCStatus					= NULL;
	char 			*NPRType					= NULL;
	char 			*Aggregate_value					= NULL;
	char 			*ApproveComment					= NULL;
	char 			*MCCproduct_line					= NULL;

	
	printf("\n value of from_date and to_date -> getting from main function %s,%s",s_date,e_date);fflush(stdout);
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	char Data[100] = "";
	
	char
        *qry_entries[3] = {"Type","Created After","Created Before"},
        *qry_values[3]	= {"*","*","*"};

	const char *attrs[1];
	const char *values[1];
	attrs[0] ="item_id";
	output = fopen("NPRDashboard.csv", "w");
	//output1=fopen("/tmp/output1.xml","w");
	//fprintf(output,",,,,,New Part Request WorkFlow Details\n");fflush(output);
	//fprintf(output,"New Part Request Number,MCCReviewer,,,,COC Principal Engineer Review,,,,COC Head Plantform Engineer Review,,,,Module TeamLeader Review,\n");fflush(stdout);
	//fprintf(output,",,MCCReviewer,,,,COC Head Plantform Engineer Review,,,,COC Principal Engineer Review,,,,Module TeamLeader Review,,,,Assign Reviewer Assignemnt,\n");fflush(output);
	fprintf(output,"NPR_Number,Product_Line,NPR_RaiserName,Start,End,Ageing,Status,Module_ReviewerName,Start,End,Ageing,Status,COC_PrincipalReviewerName,Start,End,Ageing,Status,MCC_ReviewerName,Start,End,Ageing,Status,COC_HeadReviewerName,Start,End,Ageing,Status,ACK_ReviewerName,Start,End,Ageing,Status,TML_Part_Number\n");fflush(output);
	//fprintf(output,",MCCReviewerName,Start Date,End Date,SignOffStatus,MCC Status,PartType,AggregateGroup,Comment,ProductLine,Assigned TML Part Number\n");fflush(output);


	if (output == NULL)
	{
		printf("\n ERROR: CSV File Cannot be Opened..!!\n");
		return -1;
	}
	else
	{
		printf("\n SUCCESS: CSV File Opened Successfully..!!\n");
	}
	strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
	
	QRY_find2("Item...", &query);
	qry_values[0] = "New Part Request";
	qry_values[1] = s_date;
	qry_values[2] = e_date;
	QRY_execute(query, 3, qry_entries, qry_values, &n_tags_found, &tags_found);
	printf("\n NPR_Object_Found[n_tags_found]: [%d]\n",n_tags_found);fflush(stdout);
	if(n_tags_found>0)
	{
		for(count=0;count<n_tags_found;count++)
		{
			itemRev_t = tags_found[count];
			AOM_UIF_ask_value(itemRev_t,"object_type",&LatRev_ObjectType);
			if(tc_strcasecmp(LatRev_ObjectType,"New Part Request")==0)
			{
				ifail = ITEM_ask_latest_rev (itemRev_t, &latest_rev_tag);
				if(latest_rev_tag!=NULLTAG)
				{
					AOM_UIF_ask_value(itemRev_t,"item_id",&NewPartReqNumber);
					if(tc_strlen(NewPartReqNumber)==25)
					{
						fprintf(output,"%s,",NewPartReqNumber);fflush(output);
						AOM_ask_value_string(itemRev_t,"t5_NwTmlPtNo",&AssignedTCUATmlPartNumber);
						AOM_ask_value_string(itemRev_t,"t5_NwRaisedBy",&NPRCreator);
						AOM_ask_value_string(itemRev_t,"t5_MCCStatus",&MCCStatus);
						AOM_UIF_ask_value(itemRev_t,"t5_PartType",&NPRType);
						AOM_UIF_ask_value(itemRev_t,"t5_AggregateGrp",&Aggregate_value);
						AOM_UIF_ask_value(itemRev_t,"t5_MCCapproveRejectComment",&ApproveComment);
						AOM_UIF_ask_value(itemRev_t,"t5_ProductLine",&MCCproduct_line);
						fprintf(output,"%s,",MCCproduct_line);fflush(output);

						AOM_ask_value_tags(latest_rev_tag,"fnd0ActuatedInteractiveTsks",&totalprocess,&ProcessStageList);
						printf("\n totalprocess[%d]\n",totalprocess);fflush(stdout);
						
						if(totalprocess>0)
						{
							tag_t *soResult1 = NULLTAG;
							int	TotalReviewTask	= 0;
							for(reviewcounter=0;reviewcounter<totalprocess;reviewcounter++)
							{
								ReviewProcessStage = ProcessStageList[reviewcounter];
								AOM_UIF_ask_value(ReviewProcessStage,"object_type",&processtype);
								if(tc_strcmp(processtype,"Review Task")==0 || tc_strcmp(processtype,"Do Task")==0 || tc_strcmp(processtype,"Acknowledge Task")==0)
								{
									setAddTAG(&TotalReviewTask,&soResult1,ReviewProcessStage);
								}
							}
							printf("\n TotalReviewTask[%d]\n",TotalReviewTask);fflush(stdout);
							if(TotalReviewTask>0)
							{
								ASSIGN = 0;
								ModuleTL = 0;
								COCP = 0;
								MCC = 0;
								COCH = 0;
								ACKNOW = 0;
								
								for(process_counter=0;process_counter<TotalReviewTask;process_counter++)
								{
									Process_Stage = soResult1[process_counter];
									AOM_ask_value_string(Process_Stage,"object_name",&process_Name);
									AOM_UIF_ask_value(Process_Stage,"object_type",&process_type);
									if(tc_strcmp(process_Name,"Assign Reviewers and Review NPR")==0 && tc_strcmp(process_type,"Do Task")==0)
									{
										ASSIGN++;
										AOM_ask_value_string(Process_Stage,"task_result",&AssignprocessResult);
										AOM_ask_value_string(Process_Stage,"task_state",&AssignprocessState);
										AOM_UIF_ask_value(Process_Stage,"fnd0StartDate",&AssignprocessStDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0EndDate",&AssignprocessEndDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0Performer",&AssignprocessPerformer);
										AOM_ask_value_tags(Process_Stage,"valid_signoffs",&AssignsignOfCount,&AssignSignOffTeam);
									}
									if(tc_strcmp(process_Name,"ModuleReview")==0 && tc_strcmp(process_type,"Review Task")==0)
									{
										ModuleTL++;
										AOM_ask_value_string(Process_Stage,"task_result",&ModuleRevprocessResult);
										AOM_ask_value_string(Process_Stage,"task_state",&ModuleRevprocessState);
										AOM_UIF_ask_value(Process_Stage,"fnd0StartDate",&ModuleRevprocessStDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0EndDate",&ModuleRevprocessEndDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0Performer",&ModuleRevprocessPerformer);
										AOM_ask_value_tags(Process_Stage,"valid_signoffs",&ModuleRevsignOfCount,&ModuleRevSignOffTeam);
									}
									if(tc_strcmp(process_Name,"COC Principal Engineer Review")==0 && tc_strcmp(process_type,"Review Task")==0)
									{
										COCP++;
										AOM_ask_value_string(Process_Stage,"task_result",&COCPprocessResult);
										AOM_ask_value_string(Process_Stage,"task_state",&COCPprocessState);
										AOM_UIF_ask_value(Process_Stage,"fnd0StartDate",&COCPprocessStDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0EndDate",&COCPprocessEndDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0Performer",&COCPprocessPerformer);
										AOM_ask_value_tags(Process_Stage,"valid_signoffs",&COCsignOfCount,&COCSignOffTeam);
									}
									if(tc_strcmp(process_Name,"MCCReviewer")==0 && tc_strcmp(process_type,"Review Task")==0)
									{
										MCC++;
										AOM_ask_value_string(Process_Stage,"task_result",&MCCprocessResult);
										AOM_ask_value_string(Process_Stage,"task_state",&MCCprocessState);
										AOM_UIF_ask_value(Process_Stage,"fnd0StartDate",&MCCprocessStDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0EndDate",&MCCprocessEndDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0Performer",&MCCprocessPerformer);
										AOM_ask_value_tags(Process_Stage,"valid_signoffs",&MCCsignOfCount,&MCCSignOffTeam);
									}
									if(tc_strcmp(process_Name,"COC Head Plantform Engineer Review")==0 && tc_strcmp(process_type,"Review Task")==0)
									{
										COCH++;
										AOM_ask_value_string(Process_Stage,"task_result",&COCHprocessResult);
										AOM_ask_value_string(Process_Stage,"task_state",&COCHprocessState);
										AOM_UIF_ask_value(Process_Stage,"fnd0StartDate",&COCHprocessStDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0EndDate",&COCHprocessEndDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0Performer",&COCHprocessPerformer);
										AOM_ask_value_tags(Process_Stage,"valid_signoffs",&COCHsignOfCount,&COCHSignOffTeam);
									}
									if(tc_strcmp(process_Name,"Acknowledge Assignment")==0 && tc_strcmp(process_type,"Acknowledge Task")==0)
									{
										ACKNOW++;
										AOM_ask_value_string(Process_Stage,"task_result",&ACKNOWprocessResult);
										AOM_ask_value_string(Process_Stage,"task_state",&ACKNOWprocessState);
										AOM_UIF_ask_value(Process_Stage,"fnd0StartDate",&ACKNOWprocessStDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0EndDate",&ACKNOWprocessEndDate);
										AOM_UIF_ask_value(Process_Stage,"fnd0Performer",&ACKNOWprocessPerformer);
										AOM_ask_value_tags(Process_Stage,"valid_signoffs",&ACKNOWsignOfCount,&ACKNOWSignOffTeam);
									}
								}
								printf("\n ASSIGN: [%d]\n",ASSIGN);fflush(stdout);
								printf("\n ModuleTL: [%d]\n",ModuleTL);fflush(stdout);
								printf("\n COCP: [%d]\n",COCP);fflush(stdout);
								printf("\n MCC: [%d]\n",MCC);fflush(stdout);
								printf("\n COCH: [%d]\n",COCH);fflush(stdout);
								printf("\n ACKNOW: [%d]\n",ACKNOW);fflush(stdout);
								
								    int NPRRaiseAge = 0;
								    char NPRRaiseAgeStr[20];
								    if(ASSIGN>0)
									{										
										printf("\n AssignprocessResult[%s]\n",AssignprocessResult);fflush(stdout);
										printf("\n AssignprocessState[%s]\n",AssignprocessState);fflush(stdout);
										printf("\n AssignprocessStDate[%s]\n",AssignprocessStDate);fflush(stdout);
										printf("\n AssignprocessEndDate[%s]\n",AssignprocessEndDate);fflush(stdout);
										printf("\n AssignprocessPerformer[%s]\n",AssignprocessPerformer);fflush(stdout);
										printf("\n AssignsignOfCount[%d]\n",AssignsignOfCount);fflush(stdout);
										if(tc_strcmp(AssignprocessState,"Completed")==0 || tc_strcmp(AssignprocessState,"Started")==0)
										{
											if(tc_strcmp(AssignprocessState,"Completed")==0)
											{
												NPRRaiseAge = TC_DaysCount(AssignprocessStDate,AssignprocessEndDate);
												sprintf(NPRRaiseAgeStr, "%d", NPRRaiseAge);
												fprintf(output,"%s,%s,%s,%s,%s,",AssignprocessPerformer,AssignprocessStDate,AssignprocessEndDate,NPRRaiseAgeStr,AssignprocessResult);fflush(output);
											}
											if(tc_strcmp(AssignprocessResult,"Unset")==0 && tc_strcmp(AssignprocessState,"Started")==0)
											{
												printf("\n 2AssignsignOfCount[%d]\n",AssignsignOfCount);fflush(stdout);
												if(AssignsignOfCount>0)
												{
													AOM_UIF_ask_value(AssignSignOffTeam[0],"fnd0Performer",&AssignSignOffTeamMember);
													printf("\n AssignSignOffTeamMember[%s]\n",AssignSignOffTeamMember);fflush(stdout);
													NPRRaiseAge = TC_DaysCount(AssignprocessStDate,"NA");
													sprintf(NPRRaiseAgeStr, "%d", NPRRaiseAge);
													printf("\n Ageing in String: [%s]\n",NPRRaiseAgeStr);fflush(stdout);
													fprintf(output,"%s,%s,%s,%s,%s,",AssignSignOffTeamMember,AssignprocessStDate,"NA",NPRRaiseAgeStr,"Pending");fflush(output);
												}

											}
										}										
									}
									else
									{
									   fprintf(output,"NA,NA,NA,0,Pending,");fflush(output);
									}
									
									int ModRevAge = 0;
								    char ModRevAgeStr[20];
								    if(ModuleTL>0)
									{										
										printf("\n ModuleRevprocessResult[%s]\n",ModuleRevprocessResult);fflush(stdout);
										printf("\n ModuleRevprocessState[%s]\n",ModuleRevprocessState);fflush(stdout);
										printf("\n ModuleRevprocessStDate[%s]\n",ModuleRevprocessStDate);fflush(stdout);
										printf("\n ModuleRevprocessEndDate[%s]\n",ModuleRevprocessEndDate);fflush(stdout);
										printf("\n ModuleRevprocessPerformer[%s]\n",ModuleRevprocessPerformer);fflush(stdout);
										printf("\n ModuleRevsignOfCount[%d]\n",ModuleRevsignOfCount);fflush(stdout);
										if(tc_strcmp(ModuleRevprocessState,"Completed")==0 || tc_strcmp(ModuleRevprocessState,"Started")==0)
										{
											if(tc_strcmp(ModuleRevprocessState,"Completed")==0)
											{
												ModRevAge = TC_DaysCount(ModuleRevprocessStDate,ModuleRevprocessEndDate);
                                                sprintf(ModRevAgeStr, "%d", ModRevAge);
												fprintf(output,"%s,%s,%s,%s,%s,",ModuleRevprocessPerformer,ModuleRevprocessStDate,ModuleRevprocessEndDate,ModRevAgeStr,ModuleRevprocessResult);fflush(output);
											}
											if(tc_strcmp(ModuleRevprocessResult,"Unset")==0 && tc_strcmp(ModuleRevprocessState,"Started")==0)
											{
												printf("\n 2ModuleRevsignOfCount[%d]\n",ModuleRevsignOfCount);fflush(stdout);
												if(ModuleRevsignOfCount>0)
												{
													AOM_UIF_ask_value(ModuleRevSignOffTeam[0],"fnd0Performer",&ModuleRevSignOffTeamMember);
													printf("\n ModuleRevSignOffTeamMember[%s]\n",ModuleRevSignOffTeamMember);fflush(stdout);
													ModRevAge = TC_DaysCount(ModuleRevprocessStDate,"NA");
													sprintf(ModRevAgeStr, "%d", ModRevAge);
													fprintf(output,"%s,%s,NA,%s,Pending,",ModuleRevSignOffTeamMember,ModuleRevprocessStDate,ModRevAgeStr);fflush(output);
												}

											}
										}										
									}
									else
									{
									    fprintf(output,"NA,NA,NA,0,Pending,");fflush(output);
									}
									
									int COCPAge = 0;
								    char COCPAgeStr[20];
									if(COCP>0)
									{
										printf("\n COCPprocessResult[%s]\n",COCPprocessResult);fflush(stdout);
										printf("\n COCPprocessState[%s]\n",COCPprocessState);fflush(stdout);
										printf("\n COCPprocessStDate[%s]\n",COCPprocessStDate);fflush(stdout);
										printf("\n COCPprocessEndDate[%s]\n",COCPprocessEndDate);fflush(stdout);
										printf("\n COCPprocessPerformer[%s]\n",COCPprocessPerformer);fflush(stdout);
										printf("\n COCsignOfCount[%d]\n",COCsignOfCount);fflush(stdout);
										if(tc_strcmp(COCPprocessState,"Completed")==0 || tc_strcmp(COCPprocessState,"Started")==0)
										{
											if(tc_strcmp(COCPprocessState,"Completed")==0)
											{
												COCPAge = TC_DaysCount(COCPprocessStDate,COCPprocessEndDate);
												sprintf(COCPAgeStr, "%d", COCPAge);
												fprintf(output,"%s,%s,%s,%s,%s,",COCPprocessPerformer,COCPprocessStDate,COCPprocessEndDate,COCPAgeStr,COCPprocessResult);fflush(output);
											}
											if(tc_strcmp(COCPprocessResult,"Unset")==0 && tc_strcmp(COCPprocessState,"Started")==0)
											{
												printf("\n 2COCsignOfCount[%d]\n",COCsignOfCount);fflush(stdout);
												if(COCsignOfCount>0)
												{
													AOM_UIF_ask_value(COCSignOffTeam[0],"fnd0Performer",&COCPSignOffTeamMember);
													printf("\n COCPSignOffTeamMember[%s]\n",COCPSignOffTeamMember);fflush(stdout);
													COCPAge = TC_DaysCount(COCPprocessStDate,"NA");
													sprintf(COCPAgeStr, "%d", COCPAge);
													fprintf(output,"%s,%s,NA,%s,Pending,",COCPSignOffTeamMember,COCPprocessStDate,COCPAgeStr);fflush(output);
												}
											}
										}									
									}
									else
									{
										fprintf(output,"NA,NA,NA,0,Pending,");fflush(output);
									}
                                    
									int MCCRevAge = 0;
								    char MCCRevAgeStr[20];
									if(MCC>0)
									{
										int RejectStatus=0;
										printf("\n MCCprocessResult[%s]\n",MCCprocessResult);fflush(stdout);
										printf("\n MCCprocessState[%s]\n",MCCprocessState);fflush(stdout);
										printf("\n MCCprocessStDate[%s]\n",MCCprocessStDate);fflush(stdout);
										printf("\n MCCprocessEndDate[%s]\n",MCCprocessEndDate);fflush(stdout);
										printf("\n MCCprocessPerformer[%s]\n",MCCprocessPerformer);fflush(stdout);
										printf("\n MCCsignOfCount[%d]\n",MCCsignOfCount);fflush(stdout);
										if(tc_strcmp(MCCprocessState,"Completed")==0 || tc_strcmp(MCCprocessState,"Started")==0)
										{
											if(tc_strcmp(MCCprocessState,"Completed")==0)
											{	
                                                MCCRevAge = TC_DaysCount(MCCprocessStDate,MCCprocessEndDate);
                                                sprintf(MCCRevAgeStr, "%d", MCCRevAge);										
												fprintf(output,"%s,%s,%s,%s,%s,",MCCprocessPerformer,MCCprocessStDate,MCCprocessEndDate,MCCRevAgeStr,MCCprocessResult);fflush(output);
											}
											if(tc_strcmp(MCCprocessResult,"Unset")==0 && tc_strcmp(MCCprocessState,"Started")==0)
											{
												printf("\n 2MCCsignOfCount[%d]\n",MCCsignOfCount);fflush(stdout);
												if(MCCsignOfCount>0)
												{
													int k=0;
													for(k=0;k<MCCsignOfCount;k++)
													{
														RejectStatus = 0;
														AOM_UIF_ask_value(MCCSignOffTeam[k],"fnd0Performer",&MCCSignOffTeamMember);
														AOM_UIF_ask_value(MCCSignOffTeam[k],"fnd0Status",&MCCSignOffStatus);
														if(tc_strcmp(MCCSignOffStatus,"Reject")==0)
														{
															RejectStatus = 1;
															break;
														}
														if(tc_strcmp(MCCSignOffStatus,"No Decision")==0)
														{
															RejectStatus = 0;
															
														}
													}
												}
												printf("\n 2MCCSignOffTeamMember[%s]\n",MCCSignOffTeamMember);fflush(stdout);
												printf("\n 2MCCSignOffStatus[%s]\n",MCCSignOffStatus);fflush(stdout);
												
												if(RejectStatus==1)
												{
													MCCRevAge = TC_DaysCount(MCCprocessStDate,"NA");
													sprintf(MCCRevAgeStr, "%d", MCCRevAge);
													fprintf(output,"%s,%s,%s,%s,%s,",MCCSignOffTeamMember,MCCprocessStDate,"NA",MCCRevAgeStr,MCCSignOffStatus);fflush(output);
												}
												if(RejectStatus==0)
												{
													fprintf(output,"%s,%s,%s,%s,%s,","NA","NA","NA","0","NA");fflush(output);
												}
											}
										}							
									}
									else
									{
									   fprintf(output,"%s,%s,%s,%s,%s,","NA","NA","NA","0","NA");fflush(output);	
									}
									
									int COCHeadRaiseAge = 0;
								    char COCHeadRaiseAgeStr[20];
									if(COCH>0)
									{																				
										printf("\n COCHprocessResult[%s]\n",COCHprocessResult);fflush(stdout);
										printf("\n COCHprocessState[%s]\n",COCHprocessState);fflush(stdout);
										printf("\n COCHprocessStDate[%s]\n",COCHprocessStDate);fflush(stdout);
										printf("\n COCHprocessEndDate[%s]\n",COCHprocessEndDate);fflush(stdout);
										printf("\n COCHprocessPerformer[%s]\n",COCHprocessPerformer);fflush(stdout);
										printf("\n COCHsignOfCount[%d]\n",COCHsignOfCount);fflush(stdout);
										if(tc_strcmp(COCHprocessState,"Completed")==0 || tc_strcmp(COCHprocessState,"Started")==0)
										{
											if(tc_strcmp(COCHprocessState,"Completed")==0)
											{
												COCHeadRaiseAge = TC_DaysCount(COCHprocessStDate,COCHprocessEndDate);
                                                sprintf(COCHeadRaiseAgeStr, "%d", COCHeadRaiseAge);
												fprintf(output,"%s,%s,%s,%s,%s,",COCHprocessPerformer,COCHprocessStDate,COCHprocessEndDate,COCHeadRaiseAgeStr,COCHprocessResult);fflush(output);
											}
											if(tc_strcmp(COCHprocessResult,"Unset")==0 && tc_strcmp(COCHprocessState,"Started")==0)
											{
												printf("\n 2COCHsignOfCount[%d]\n",COCHsignOfCount);fflush(stdout);
												if(COCHsignOfCount>0)
												{
													AOM_UIF_ask_value(COCHSignOffTeam[0],"fnd0Performer",&COCHSignOffTeamMember);
													printf("\n COCHSignOffTeamMember[%s]\n",COCHSignOffTeamMember);fflush(stdout);
													COCHeadRaiseAge = TC_DaysCount(COCHprocessStDate,"NA");
													sprintf(COCHeadRaiseAgeStr, "%d", COCHeadRaiseAge);
													fprintf(output,"%s,%s,NA,%s,Pending,",COCHSignOffTeamMember,COCHprocessStDate,COCHeadRaiseAgeStr);fflush(output);
												}
											}
										}										
									}
									else
									{
										fprintf(output,"NA,NA,NA,0,Pending,");fflush(output);
									}
									
									
									int ACKNOWRaiseAge = 0;
								    char ACKNOWRaiseAgeStr[20];
									if(ACKNOW>0)
									{										
										printf("\n ACKNOWprocessResult[%s]\n",ACKNOWprocessResult);fflush(stdout);
										printf("\n ACKNOWprocessState[%s]\n",ACKNOWprocessState);fflush(stdout);
										printf("\n ACKNOWprocessStDate[%s]\n",ACKNOWprocessStDate);fflush(stdout);
										printf("\n ACKNOWprocessEndDate[%s]\n",ACKNOWprocessEndDate);fflush(stdout);
										printf("\n ACKNOWprocessPerformer[%s]\n",ACKNOWprocessPerformer);fflush(stdout);
										printf("\n ACKNOWsignOfCount[%d]\n",ACKNOWsignOfCount);fflush(stdout);
										if(tc_strcmp(ACKNOWprocessState,"Completed")==0 || tc_strcmp(ACKNOWprocessState,"Started")==0)
										{
											if(tc_strcmp(ACKNOWprocessState,"Completed")==0)
											{
												ACKNOWRaiseAge = TC_DaysCount(ACKNOWprocessStDate,ACKNOWprocessEndDate);
												sprintf(ACKNOWRaiseAgeStr, "%d", ACKNOWRaiseAge);
												fprintf(output,"%s,%s,%s,%s,%s,",ACKNOWprocessPerformer,ACKNOWprocessStDate,ACKNOWprocessEndDate,ACKNOWRaiseAgeStr,ACKNOWprocessResult);fflush(output);
											}
											if(tc_strcmp(ACKNOWprocessResult,"Unset")==0 && tc_strcmp(ACKNOWprocessState,"Started")==0)
											{
												printf("\n 2AssignsignOfCount[%d]\n",ACKNOWsignOfCount);fflush(stdout);
												if(ACKNOWsignOfCount>0)
												{
													AOM_UIF_ask_value(ACKNOWSignOffTeam[0],"fnd0Performer",&ACKNOWSignOffTeamMember);
													printf("\n ACKNOWSignOffTeamMember: [%s]\n",ACKNOWSignOffTeamMember);fflush(stdout);
													ACKNOWRaiseAge = TC_DaysCount(ACKNOWprocessStDate,"NA");
													sprintf(ACKNOWRaiseAgeStr, "%d", ACKNOWRaiseAge);
													fprintf(output,"%s,%s,%s,%s,%s,",ACKNOWSignOffTeamMember,ACKNOWprocessStDate,"NA",ACKNOWRaiseAgeStr,"Pending");fflush(output);
												}

											}
										}										
									}
									else
									{
									   fprintf(output,"NA,NA,NA,0,Pending,");fflush(output);
									}
							}
							fprintf(output,"%s,",AssignedTCUATmlPartNumber);fflush(output);
						}
						else
						{
							fprintf(output,"NA,NA,NA,0,NA,NA,NA,NA,0,NA,NA,NA,NA,0,NA,NA,NA,NA,0,NA,NA,NA,NA,0,NA,NA,NA,NA,0,NA,NA");fflush(output);
						    //fprintf(output,"NA,NA,NA,Not Submitted,NA,NA,NA,Not Submitted,NA,NA,NA,Not Submitted,NA,NA,NA,Not Submitted,NA,");fflush(output);
							//fprintf(output,"NA,NA,NA,Not Submitted,NA,%s,%s,%s,%s,NA,",NPRType,Aggregate_value,ApproveComment,MCCproduct_line);fflush(output);
						}
						fprintf(output,"\n");fflush(output);
					}
				}
			}
		}
	}
	//write2xml(output1,"</PLMXML>\n");
	MEM_free(tags_found);
	if(output!=NULL)fclose(output);output = NULL;
	if(output1!=NULL)fclose(output1);output1 = NULL;

	return ifail;
}
