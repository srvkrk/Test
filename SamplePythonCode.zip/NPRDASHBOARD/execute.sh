/user/cvprod/sourav/NPRDASHBOARD/tm_NPRDashboardRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -F=01-Jun-2025 -T=30-Jun-2025
