######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : APRIL-2024
#
#######################################################################################
. /user/cvprod/.bash_profile

echo -e "\nIn Execution Shell Argument Print Started...."

echo "Part: -----> "$1

echo "Rev: -----> "$2

echo "Seq: -----> "$3

echo "User: -----> "$4

echo "Email: -----> "$5

echo -e "\nIn Execution Shell Argument Print Ended...."

echo -e "\nEXE(tm_PartUsageRpt) Execution Started...."
/user/cvprod/sourav/ReportBuilderPartUsgRpt/tm_PartUsageRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Part=$1 -Rev=$2 -Seq=$3 -User=$4 -Email=$5
echo -e "\nEXE(tm_PartUsageRpt) Execution Ended...."
