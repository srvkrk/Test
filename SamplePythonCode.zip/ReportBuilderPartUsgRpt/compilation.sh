./compile tm_PartUsageRpt.c
./linkitk -o tm_PartUsageRpt tm_PartUsageRpt.o
chmod 777 tm_PartUsageRpt*
