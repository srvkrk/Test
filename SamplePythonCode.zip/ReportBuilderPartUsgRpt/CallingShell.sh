######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : MARCH-2024
#
#######################################################################################

. /user/cvprod/.bash_profile

echo -e "\nIn Calling Shell Argument Print Started...."

echo "Part: -----> "$1

echo "Rev: -----> "$2

echo "Seq: -----> "$3

echo "User: -----> "$4

echo "Email: -----> "$5

echo -e "\nIn Calling Shell Argument Print Ended...."

echo -e "\nRedirection(SSH:vztcua11srv3[172.22.99.106]) Execution Shell Call Started...."
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/sourav/ReportBuilderPartUsgRpt/ExecutionShell.sh $1 $2 $3 $4 $5"
echo -e "\nRedirection(SSH:vztcua11srv3[172.22.99.106]) Execution Shell Call Ended...."

