./compile tm_property_update.c
./linkitk -o tm_property_update tm_property_update.o
chmod 777 tm_property_update*
