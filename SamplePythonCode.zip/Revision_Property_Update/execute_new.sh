/user/cvprod/sourav/Revision_Property_Update/tm_property_update -u=infodba -pf=/user/cvprod/shells/Admin/infodbapasswdfile.pwf -g=dba
