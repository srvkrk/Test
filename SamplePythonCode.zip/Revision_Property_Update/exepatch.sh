$TC_ROOT/*Patch*/tcPatchExecutable tm_property_update
