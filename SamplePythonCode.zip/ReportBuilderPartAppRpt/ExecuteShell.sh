######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : APRIL-2024
#
#######################################################################################
. /user/cvprod/.bash_profile

echo -e "\nIn Execution Shell Argument Print Started...."

echo "PartList: -----> "$1

echo "User: -----> "$2

echo "Email: -----> "$3

echo -e "\nIn Execution Shell Argument Print Ended...."

echo -e "\nEXE(tm_PartApplicability_Rpt) Execution Started...."
/user/cvprod/sourav/ReportBuilderPartAppRpt/tm_PartApplicability_Rpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -PartList=$1 -User=$2 -Email=$3
echo -e "\nEXE(tm_PartApplicability_Rpt) Execution Ended...."
