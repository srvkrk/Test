$TC_ROOT/*Patch*/tcPatchExecutable tm_PartApplicability_Rpt
