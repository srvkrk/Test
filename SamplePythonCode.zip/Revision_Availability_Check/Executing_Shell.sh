######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : NOVEMBER-2023
#
#######################################################################################
. /user/cvprod/.bash_profile

echo -e "\n~~~~~~~~~~ E X E E X E C U T I O N - S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "Part_No: -----> "$1

echo "Revision: -----> "$2

echo "Condition: -----> "$3

echo "File_Name: -----> "$4

echo -e "\nIn Shell Argument Print Ended...."

echo -e "\nEXE Shell Execution Started...."
/user/cvprod/sourav/Revision_Availability_Check/tm_revision_check -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -id=$1 -rev=$2 -con=$3 -fname=$4
echo -e "\nEXE Shell Execution Ended...."

echo -e "\n~~~~~~~~~~ E X E E X E C U T I O N - S H E L L   E N D E D ~~~~~~~~~~~~"