/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Weekly IB VC Profit Center Data Report From TCUA - CV
*  File Name    :   tm_plmsap_ibvcpc_report.c
*  Created on   :   Mar 05th, 2026
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     05/03/2026                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	//char *retStringf;
	//retStringf = (char*) malloc(200);
	char *retStringf = (char *)MEM_alloc(100 * sizeof(char));
	
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int TC_VCClassification_Details(char* partno,char* rev,char* seq,char* desc,char* type,char* plant,char* server,FILE* RptOut)
{
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int s = 0;
	tag_t VCRev_tag = NULLTAG;
	char *item_revseq = (char *) malloc(20*sizeof(char));
	int ChldCount = 0;
    tag_t *PartChildTags = NULLTAG;
	tag_t Veh_tag = NULLTAG;
	char *vehno_str = NULL;
	char *vehno_strDup = NULL;
	int z = 0;
	tag_t vehtItemobj = NULLTAG;
	int vehn_entries = 2;
	int vehn_itemobj_found = 0;
	tag_t* vehtitemobj_results = NULLTAG;
	int y = 0;
	tag_t Rev_tag = NULLTAG;
	tag_t VehRev_tag = NULLTAG;
	int iFail = ITK_ok;
	char *prodlineval 	= NULL;
	prodlineval = (char *) MEM_alloc( 5000 * sizeof(char) );
	char *platformval 	= NULL;
	platformval = (char *) MEM_alloc( 5000 * sizeof(char) );
	char *segmentval = NULL;
	segmentval = (char *) MEM_alloc( 5000 * sizeof(char) );
	char *variantval 	= NULL;
	variantval = (char *) MEM_alloc( 5000 * sizeof(char) );
	char *customerval = NULL;
	customerval = (char *) MEM_alloc( 5000 * sizeof(char) );
	char *wbsval = NULL;
	wbsval = (char *) MEM_alloc( 5000 * sizeof(char) );
	int num_to_sort = 1;
	int sort_order[1] = {2}; //1 --> Ascending Order & 2 --> Descending Order
	char *keysAttr[1] =  {"creation_date"};
	char *partClrInd = NULL;
	tag_t* NonColPartTags =  NULLTAG;
	int Count = 0;
	
	if(prodlineval!=NULL)trimwhitespace(prodlineval);
	if(platformval!=NULL)trimwhitespace(platformval);
	if(segmentval!=NULL)trimwhitespace(segmentval);
	if(variantval!=NULL)trimwhitespace(variantval);
	char *vcctnpc = NULL;
	
	tc_strcpy(item_revseq,rev);
	tc_strcat(item_revseq,"*");
	tc_strcat(item_revseq,seq);
	printf(" Final: Part No Value(partno): [%s]\n",partno);
	printf(" Final: Part_Rev_Seq Value(item_revseq): [%s]\n",item_revseq);
	
	printf("\n Finding Query[Item Revision...]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n Query [Item Revision...] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","Item ID"};
		char *cValues[2]  = {item_revseq,partno};
		//char *cValues[2]  = {"A*2","51780353000R"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Queried [Item Revision...] Found..!!\n");fflush(stdout);
			for(s = 0; s < n_itemobj_found; s++)
			{
				VCRev_tag = titemobj_results[s];
				ITK_CALL(AOM_ask_value_tags(VCRev_tag,"ps_children",&ChldCount,&PartChildTags));
				if(ChldCount>0)
				{
					for(z = 0; z < ChldCount; z++)
			        {
						Veh_tag = PartChildTags[z];
						ITK_CALL(AOM_ask_value_string(PartChildTags[z],"item_id",&vehno_str));
						if(tc_strlen(vehno_str)>0)
						{
							tc_strdup(vehno_str,&vehno_strDup);
							ITK_CALL(QRY_find2("Item Revision...",&vehtItemobj));
							if(vehtItemobj != NULLTAG)
							{
								printf("\n Query [Item Revision...] Found Successfully..!!\n");fflush(stdout);
								char *vehEntries[2]  = {"Item ID","Release Status"};
								char *vehValues[2]  = {vehno_strDup,"T5_LcsErcRlzd"};
								ITK_CALL(QRY_execute(vehtItemobj, vehn_entries, vehEntries, vehValues, &vehn_itemobj_found, &vehtitemobj_results));
					            ITK_CALL(QRY_execute_with_sort(vehtItemobj, vehn_entries, vehEntries, vehValues, num_to_sort, keysAttr, sort_order, &vehn_itemobj_found, &vehtitemobj_results));
								printf("\n -----------------------------------------------\n");fflush(stdout);
								printf("\n No of Revision Found: [%d]\n",vehn_itemobj_found);fflush(stdout);
								printf("\n -----------------------------------------------\n");fflush(stdout);
								if(vehn_itemobj_found > 0)
								{
									printf("\n Query [Item Revision...] Found..!!\n");fflush(stdout);
									for (y = 0; y < vehn_itemobj_found; y++)
									{
										Rev_tag = vehtitemobj_results[y];
										ITK_CALL(AOM_ask_value_string(Rev_tag,"t5_ColourInd",&partClrInd));
										printf("\n Colour Indicator: [%s]",partClrInd);fflush(stdout);
										if(tc_strcmp(partClrInd,"C") == 0)
										{
											ITK_CALL(AOM_ask_value_tags(Rev_tag,"TC_Is_Represented_By",&Count,&NonColPartTags));
											if (Count > 0)
											{
										       VehRev_tag = NonColPartTags[0];
											}
										}
										else
										{
											VehRev_tag = vehtitemobj_results[y];
										}
									}
									
									tag_t VehMstrTag = NULLTAG;
									int theAttributeCount = 0;
									int *theAttributeIds = 0;
									char **theAttributeNames;
									int *theAttributeValCounts = 0;
									char***       theAttributeValues;
									char***       theAttributeOptimizedUnits;
									char* 	attrId 					= NULL;
									attrId = (char *) MEM_alloc( 50 * sizeof(char) );
									int i,j,x = 0;
									int *vcattr = 0;
									tag_t* ClsObjTag_results = NULLTAG;
	                                tag_t IcsClsTag = NULLTAG;
									
									ITK_CALL(ITEM_ask_item_of_rev(VehRev_tag,&VehMstrTag));
									ITK_CALL(ICS_ask_classification_object(VehMstrTag,&IcsClsTag));
                                    ITK_CALL(ICS_ico_ask_attributes_optimized(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
									if(theAttributeCount > 0)
									{
										for(i = 0; i < theAttributeCount; i++)
										{
											sprintf(attrId,"%d",theAttributeIds[i]);
											if(tc_strcmp(theAttributeNames[i],"PRODUCT LINE")==0)
											{
												tc_strcpy(prodlineval,"");
												for(x=0; x<theAttributeValCounts[i]; x++)
												{
													tc_strcat(prodlineval,theAttributeValues[i][x]);
												}
											}
											
											if(tc_strcmp(theAttributeNames[i],"PLATFORM")==0)
											{
												tc_strcpy(platformval,"");
												for(x = 0; x <theAttributeValCounts[i]; x++)
												{
													tc_strcat(platformval,theAttributeValues[i][x]);
												}
											}
											
											if(tc_strcmp(theAttributeNames[i],"SEGMENT")==0)
											{
												tc_strcpy(segmentval,"");
												for(x=0; x<theAttributeValCounts[i]; x++)
												{
													tc_strcat(segmentval,theAttributeValues[i][x]);
												}
											}
											
											if(tc_strcmp(theAttributeNames[i],"VARIANT")==0)
											{
												tc_strcpy(variantval,"");
												for(x=0; x<theAttributeValCounts[i]; x++)
												{
													tc_strcat(variantval,theAttributeValues[i][x]);
												}
											}
											
											if(tc_strcmp(theAttributeNames[i],"[VC]CUSTOMER(CUSTOMER)")==0)
											{
												tc_strcpy(customerval,"");
												for(x=0; x<theAttributeValCounts[i]; x++)
												{
													tc_strcat(customerval,theAttributeValues[i][x]);
												}
											}
											
											if(tc_strcmp(theAttributeNames[i],"WBS")==0)
											{
												tc_strcpy(wbsval,"");
												for(x=0; x<theAttributeValCounts[i]; x++)
												{
													tc_strcat(wbsval,theAttributeValues[i][x]);
												}
											}
											
											printf("\t Attribute Name: [%s] - Attribute ID: [%s]\n", theAttributeNames[i], attrId);
											MEM_free(theAttributeNames[i]);
											MEM_free(theAttributeValues[i]);
										}
										MEM_free(theAttributeNames);
										MEM_free(theAttributeValues);
									}
									printf("\t !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");fflush(stdout);
									printf("\t [PRODUCT LINE]: [%s] \n", prodlineval);fflush(stdout);
									printf("\t [PLATFORM]: [%s] \n", platformval);fflush(stdout);
									printf("\t [SEGMENT]: [%s] \n", segmentval);fflush(stdout);
                                    printf("\t [VARIANT]: [%s] \n", variantval);fflush(stdout);
									printf("\t [[VC]CUSTOMER(CUSTOMER)]: [%s] \n", customerval);fflush(stdout);
									printf("\t [WBS]: [%s] \n", wbsval);fflush(stdout);
                                    printf("\t !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");fflush(stdout);									
								}
							}
						}
					}
				}
			}
		}
	}
	
	if((tc_strlen(prodlineval)>0) && (tc_strlen(platformval)>0))
	{
		tag_t ctltItemobj = NULLTAG;
		int ctln_entries = 4;
		int newctln_entries = 3;
		int ctln_itemobj_found = 0;
		tag_t* ctltitemobj_results = NULLTAG;
		int v = 0;
		tag_t CtlRev_tag = NULLTAG;
		//vcprofit_centre_sap = (char *)malloc(100 * sizeof(char));
		
		if(tc_strlen(customerval)>0)
		{
		    if((tc_strcmp(customerval,"EXPORT")==0) || (tc_strcmp(customerval,"KUWAIT")==0) || (tc_strcmp(customerval,"SOUTH_AFRICA")==0))
			{
				if(((tc_strcmp(prodlineval,"Passenger")==0) || (tc_strcmp(prodlineval,"SCV PU")==0)) && ((tc_strcmp(platformval,"Buses")==0) || (tc_strcmp(platformval,"PU Small")==0) || (tc_strcmp(platformval,"Vans")==0)))
				{
					printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
					printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
					ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
					if(ctltItemobj != NULLTAG)
					{
						printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
						char *ctlEntries[4]  = {"SYSCD","Information-1","Information-2","Information-3"};
						char *ctlValues[4]  = {"S4HANAPLANTDATAIBVC",prodlineval,platformval,segmentval};
						//char *ctlValues[4]  = {"S4HANAPLANTDATAIBVC","Passenger","Buses","ICV Buses"};
						ITK_CALL(QRY_execute(ctltItemobj, ctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
						printf("\n -----------------------------------------------\n");fflush(stdout);
						printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
						printf("\n -----------------------------------------------\n");fflush(stdout);
						if(ctln_itemobj_found > 0)
						{
							printf(" Queried Control Object Found..!!\n");fflush(stdout);
							printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
							for(v = 0; v < ctln_itemobj_found; v++)
							{
								CtlRev_tag = ctltitemobj_results[v];
								ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
								printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
								//tc_strcpy(vcprofit_centre_sap,"0000");
								//tc_strcat(vcprofit_centre_sap,vcctnpc);
							}
						}
					}
				}
				else
				{
					printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
					printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
					ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
					if(ctltItemobj != NULLTAG)
					{
						printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
						char *ctlEntries[3]  = {"SYSCD","Information-1","Information-2"};
						char *ctlValues[3]  = {"S4HANAPLANTDATAIBVC",prodlineval,platformval};
						//char *ctlValues[3]  = {"S4HANAPLANTDATAIBVC","Passenger","Buses"};
						ITK_CALL(QRY_execute(ctltItemobj, newctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
						printf("\n -----------------------------------------------\n");fflush(stdout);
						printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
						printf("\n -----------------------------------------------\n");fflush(stdout);
						if(ctln_itemobj_found > 0)
						{
							printf(" Queried Control Object Found..!!\n");fflush(stdout);
							printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
							for(v = 0; v < ctln_itemobj_found; v++)
							{
								CtlRev_tag = ctltitemobj_results[v];
								ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
								printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
								//tc_strcpy(vcprofit_centre_sap,"0000");
								//tc_strcat(vcprofit_centre_sap,vcctnpc);
							}
						}
					}
				}
			}
			else
			{
				if(((tc_strcmp(prodlineval,"Passenger")==0) || (tc_strcmp(prodlineval,"SCV PU")==0)) && ((tc_strcmp(platformval,"Buses")==0) || (tc_strcmp(platformval,"PU Small")==0) || (tc_strcmp(platformval,"Vans")==0)))
				{
					printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
					printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
					ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
					if(ctltItemobj != NULLTAG)
					{
						printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
						char *ctlEntries[4]  = {"SYSCD","Information-1","Information-2","Information-3"};
						char *ctlValues[4]  = {"S4HANAPLANTDATAVC",prodlineval,platformval,segmentval};
						//char *ctlValues[4]  = {"S4HANAPLANTDATAVC","Passenger","Buses","ICV Buses"};
						ITK_CALL(QRY_execute(ctltItemobj, ctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
						printf("\n -----------------------------------------------\n");fflush(stdout);
						printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
						printf("\n -----------------------------------------------\n");fflush(stdout);
						if(ctln_itemobj_found > 0)
						{
							printf(" Queried Control Object Found..!!\n");fflush(stdout);
							printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
							for(v = 0; v < ctln_itemobj_found; v++)
							{
								CtlRev_tag = ctltitemobj_results[v];
								ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
								printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
								//tc_strcpy(vcprofit_centre_sap,"0000");
								//tc_strcat(vcprofit_centre_sap,vcctnpc);
							}
						}
					}
				}
				else
				{
					printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
					printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
					ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
					if(ctltItemobj != NULLTAG)
					{
						printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
						char *ctlEntries[3]  = {"SYSCD","Information-1","Information-2"};
						char *ctlValues[3]  = {"S4HANAPLANTDATAVC",prodlineval,platformval};
						//char *ctlValues[3]  = {"S4HANAPLANTDATAVC","Passenger","Buses"};
						ITK_CALL(QRY_execute(ctltItemobj, newctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
						printf("\n -----------------------------------------------\n");fflush(stdout);
						printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
						printf("\n -----------------------------------------------\n");fflush(stdout);
						if(ctln_itemobj_found > 0)
						{
							printf(" Queried Control Object Found..!!\n");fflush(stdout);
							printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
							for(v = 0; v < ctln_itemobj_found; v++)
							{
								CtlRev_tag = ctltitemobj_results[v];
								ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
								printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
								//tc_strcpy(vcprofit_centre_sap,"0000");
								//tc_strcat(vcprofit_centre_sap,vcctnpc);
							}
						}
					}
				}
			}
		}
		else
		{
			printf("\n [VC]CUSTOMER(CUSTOMER) Value is NULL");fflush(stdout);
		}
		
		if(tc_strlen(customerval)>0)
		{
			if((tc_strcmp(customerval,"EXPORT")==0) || (tc_strcmp(customerval,"KUWAIT")==0) || (tc_strcmp(customerval,"SOUTH_AFRICA")==0))
			{
				fprintf(RptOut,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",partno,rev,seq,desc,plant,prodlineval,platformval,segmentval,variantval,vcctnpc);fflush(RptOut);
			}
		}
		else
		{
			printf("\n [VC]CUSTOMER(CUSTOMER) Value is NULL");fflush(stdout);
		}
	}

	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_id_str = NULL;
	char *inp_id_strDup = NULL;
	tag_t QueryTag = NULLTAG;
	int n_entries = 6;
	int n_itemobj_found = 0;
	int i = 0;
	int num_to_sort = 1;
	char *keysAttr[1] =  {"creation_date"};
	int sort_order[1] = {2}; //1 --> Ascending Order & 2 --> Descending Order
	int resultcount = 0;
	tag_t* outtag = NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t ObjTypeTag = NULLTAG;
	char *TypeName = NULL;
	char* DMLNum = NULL;
	char* ComDMLNum = NULL;
	char* DMLRelType = NULL;
	char* DMLRelStatus = NULL;
	char* DMLOwner = NULL;
	char* FComDMLNum = NULL;
	char* DMLPlant = NULL;
	tag_t relation_type	= NULLTAG;
	int tcount = 0;
	tag_t *TaskRevision	= NULLTAG;
	int TaskCnt = 0;
	tag_t TaskRevTag = NULLTAG;
	char* TaskObjectType = NULL;
	char* TaskId = NULL;
	int pcount = 0;
	tag_t *PartTags	= NULLTAG;
	tag_t PartRevTag = NULLTAG;
	char* PartNo = NULL;
	char* PartRevSeq = NULL;
	char* PartType = NULL;
	char* PartDesc = NULL;
	char* PartDescDup = NULL;
	int PartCnt = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	FILE *fpOutput_file = NULL;
    char* PlantCode = NULL;
	char* PartRelStatus = NULL;
	char* start_time_str = NULL;
	char* end_time_str = NULL;
	char* PartRev = NULL;
	char* PartSeq = NULL;
	
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	start_time_str = ITK_ask_cli_argument("-s=");
	end_time_str = ITK_ask_cli_argument("-e=");
	printf(" [1]: Start Time(start_time_str): [%s]\n",start_time_str);fflush(stdout);
	printf(" [2]: End Time(end_time_str): [%s]\n",end_time_str);fflush(stdout);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Profit_Center_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
	fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]\n",RptFile);fflush(stdout);
		return 0;
	}
	fprintf(fpOutput_file,"PART_NO, PART_REV, PART_SEQ, PART_DESCRIPTION, PLANT_CODE, PRODUCT_LINE, PLATFORM, SEGMENT, VARIANT, PROFIT_CENTER\n");fflush(fpOutput_file);
	ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision", &QueryTag));
	if(QueryTag != NULLTAG)
	{
	   printf("\n [MCC_ERC_Released_Latest_Revision] Found Successfully..!!\n");fflush(stdout);
	   char *qry_entries[6]  = {"Item ID","Release Status","Released After","Released Before","Part Type","Type"};
	   char *qry_values[6]  = {"*","T5_MBOMReleased",start_time_str,end_time_str,"VC","Design Revision"};
	   ITK_CALL(QRY_execute(QueryTag, n_entries, qry_entries, qry_values, &n_itemobj_found, &outtag));
	   printf("\n -----------------------------------------------\n");fflush(stdout);
	   printf("\n  No of Object Found: [%d]\n",n_itemobj_found);fflush(stdout);
	   printf("\n -----------------------------------------------\n");fflush(stdout);
	    if(n_itemobj_found > 0)
	    {
		    for(i = 0; i < n_itemobj_found; i++)
		    {
				PartRevTag = outtag[i];
				ITK_CALL(AOM_ask_value_string(PartRevTag,"item_id",&PartNo));
				ITK_CALL(AOM_ask_value_string(PartRevTag,"item_revision_id",&PartRevSeq));
				PartRev = tc_strtok(PartRevSeq,";");
			    PartSeq = tc_strtok(NULL,";");
				printf("\n Part No: [%s]", PartNo);fflush(stdout);
				printf("\n Part Revision: [%s]", PartRev);fflush(stdout);
				printf("\n Part Sequence: [%s]", PartSeq);fflush(stdout);
				printf("\n Part Description Final Value: [%s]", PartDescDup);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(PartRevTag,"t5_PartType",&PartType));
				ITK_CALL(AOM_ask_value_string(PartRevTag,"object_desc",&PartDesc));
				printf("\n Part Description Before Dup & Trim:  <%s> \n",PartDesc);fflush(stdout);
				if(tc_strlen(PartDesc)>0)
				{
					tc_strdup(PartDesc,&PartDescDup);
				}
				else
				{
					tc_strdup("--",&PartDescDup);
					printf("\n Item Description Value is NULL");fflush(stdout);
				}
				trimwhitespace(PartDescDup);
				printf("\n Part Description Value After Dup & Trim: [%s]", PartDescDup);fflush(stdout);
				STRNG_replace_str(PartDescDup,","," ",&PartDescDup);
				STRNG_replace_str(PartDescDup,";"," ",&PartDescDup);
				STRNG_replace_str(PartDescDup,"\n"," ",&PartDescDup);
				STRNG_replace_str(PartDescDup,"'"," ",&PartDescDup);
				printf("\n Part Description Final Value: [%s]", PartDescDup);fflush(stdout);
				ITK_CALL(AOM_UIF_ask_value(PartRevTag,"release_status_list",&PartRelStatus));
				printf("\n Part Type: [%s]\n",PartType);fflush(stdout);
				printf("\n Part Release Status: [%s]\n",PartRelStatus);fflush(stdout);
				
				if(tc_strstr(PartRelStatus,"APLP Released")!=NULL)
				{
					tc_strdup("1001",&PlantCode);
					if(tc_strcmp(PartType,"VC")==0)
					{
						printf("\n Function: As Part Type: VC So, Function[TC_VCClassification_Details] Call Start\n");fflush(stdout);
						printf("\n Function1: VC To Vehicle Classification Details Find Start\n");fflush(stdout);
						TC_VCClassification_Details(PartNo,PartRev,PartSeq,PartDescDup,PartType,PlantCode,"CVP",fpOutput_file);
						printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
					}
				}
				if(tc_strstr(PartRelStatus,"APLL Released")!=NULL)
				{
					tc_strdup("3001",&PlantCode);
					if(tc_strcmp(PartType,"VC")==0)
					{
						printf("\n Function: As Part Type: VC So, Function[TC_VCClassification_Details] Call Start\n");fflush(stdout);
						printf("\n Function1: VC To Vehicle Classification Details Find Start\n");fflush(stdout);
						TC_VCClassification_Details(PartNo,PartRev,PartSeq,PartDescDup,PartType,PlantCode,"CVP",fpOutput_file);
						printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
					}
				}
				if(tc_strstr(PartRelStatus,"APLJ Released")!=NULL)
				{
					tc_strdup("2001",&PlantCode);
					if(tc_strcmp(PartType,"VC")==0)
					{
						printf("\n Function: As Part Type: VC So, Function[TC_VCClassification_Details] Call Start\n");fflush(stdout);
						printf("\n Function1: VC To Vehicle Classification Details Find Start\n");fflush(stdout);
						TC_VCClassification_Details(PartNo,PartRev,PartSeq,PartDescDup,PartType,PlantCode,"CVP",fpOutput_file);
						printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
					}
				}
				if(tc_strstr(PartRelStatus,"APLU Released")!=NULL)
				{
					tc_strdup("3100",&PlantCode);
					if(tc_strcmp(PartType,"VC")==0)
					{
						printf("\n Function: As Part Type: VC So, Function[TC_VCClassification_Details] Call Start\n");fflush(stdout);
						printf("\n Function1: VC To Vehicle Classification Details Find Start\n");fflush(stdout);
						TC_VCClassification_Details(PartNo,PartRev,PartSeq,PartDescDup,PartType,PlantCode,"CVP",fpOutput_file);
						printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
					}
				}
				if(tc_strstr(PartRelStatus,"APLD Released")!=NULL)
				{
					tc_strdup("1500",&PlantCode);
					if(tc_strcmp(PartType,"VC")==0)
					{
						printf("\n Function: As Part Type: VC So, Function[TC_VCClassification_Details] Call Start\n");fflush(stdout);
						printf("\n Function1: VC To Vehicle Classification Details Find Start\n");fflush(stdout);
						TC_VCClassification_Details(PartNo,PartRev,PartSeq,PartDescDup,PartType,PlantCode,"CVP",fpOutput_file);
						printf("\n Function1: As Part Type: VC or V or Module So, Write in File End\n");fflush(stdout);
					}
				}
				else
				{
					printf("\n \033[31m>>>>> Part Release Status not matched 😄 \033[0m<<<<<<\n");fflush(stdout);
				}
			}
	    }
		else
		{
			printf("\n \033[31m>>>>> Object Not Found 😄 \033[0m<<<<<<\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n \033[31m>>>>> Query[MCC_ERC_Released_Latest_Revision] Tag Not Found 😄 \033[0m<<<<<<\n");fflush(stdout);
	}
	fclose(fpOutput_file);

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_exit_module(TRUE);
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_plmsap_profit_center_report.c
* // ./linkitk -o tm_plmsap_profit_center_report tm_plmsap_profit_center_report.o
* // scp cvprod@172.22.99.106:/user/cvprod/PLMSAPPROFITCENTERJOB/tm_plmsap_profit_center_report .
* // scp cvprod@172.22.99.106:/user/cvprod/PLMSAPPROFITCENTERJOB/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/PLMSAPPROFITCENTERJOB/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/PLMSAPPROFITCENTERJOB/SendEmail.sh .
* // ./tm_plmsap_profit_center_report -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -s="20-Jan-2026 06:00" -e="03-Feb-2026 18:00"
* // ./tm_plmsap_profit_center_report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -s="20-Jan-2026 06:00" -e="03-Feb-2026 18:00"
*
***************************************************************************/