######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it.
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : April-2024
#
#######################################################################################

echo -e "\n~~~~~~~~~~ PROFIT CENTER MAIL SEND STARTED ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "Report File Name: -----> "$1

echo -e "\nIn Shell Argument Print Ended...."

echo -e "\nReport Send To User Email Started...."
ls -lrt $1
if [ $? == 0 ]
      then
        echo "File Successfully Found on Server"
        echo "Sending Report To User Email"
        echo -e "Dear Sir / Madam, \n\n                Please Check Attached VCs are created in SAP with the profit center indicated.\n                Start Date-Time: 18-Feb-2026 06:00\n                End Date-Time:: 05-Mar-2026 17:00\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Plese do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS: Profit Center for new VCs" -a $1 rajesh.mandal@tatamotors.com swati.udupa@tatamotors.com dhiraj.patil@tatamotors.com sandeep.bhonde@tatamotors.com Nitesh.Kedia@tatamotors.com SDB866587@tatamotors.com Amit.Sanghvi@tatamotors.com ashishm@tatamotors.com RAA866573@tatamotors.com prasoon.agrawal@tatamotors.com saurav.sarkar@tatamotors.com amrut.pawar@tatamotors.com souravk.ttl@tatamotors.com manishaj.ttl@tatamotors.com devkantk.ttl@tatamotors.com prasadb1.ttl@tatamotors.com nishantp.ttl@tatamotors.com poonams.ttl@tatamotors.com dhrubak.ttl@tatamotors.com ujjawalk.ttl@tatamotors.com
      else
        echo "File NOT Foud on server"
        echo "Sending Report To Developer Email"
        echo -e "Hi, \n\n                There is Some Issue in Cron Job of Profit Center Report\n                Please Check Cron Job & Re-Execute Job.\n                \n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED: Profit Center for new VCs" souravk.ttl@tatamotors.com
fi
echo -e "\nReport Send To User Email Ended...."
echo -e "\n~~~~~~~~~~ PROFIT CENTER MAIL SEND ENDED ~~~~~~~~~~~~"

sleep 5

echo -e "\nFile Move Start...."
mv $1 /user/cvprod/PLMSAPPROFITCENTERJOB/LOGS/
echo -e "\nFile Move End...."