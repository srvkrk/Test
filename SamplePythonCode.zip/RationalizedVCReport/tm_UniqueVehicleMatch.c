/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Query Design Revision & Sequence(SubModule No, Revision, Sequence) & Return It's Linked with Any Vehicle or Not. 
*  File Name    :   tm_InputVehicleLinkStatus.c
*  Created on   :   Aug 05th, 2024
*  Usage        :   tm_InputVehicleLinkStatus
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     05/08/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_EEVehLinkStatus(char* ModAdd,char* PNSrch,char* PNRevSeqSrch,FILE* ResRpt)
{
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char* ResponseVehlinkStat = NULL;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	tag_t rev_tags_found = NULLTAG;
	tag_t tParentDesRev = NULLTAG;
	char *VCList = (char *) malloc(60000*sizeof(char));
	int linkcount = 0;
	
	char *PreVCompFile = (char *) malloc(100*sizeof(char));
	char DTStamp[100] = "";
	time_t 	dtnow;
	struct 	tm dtwhen;
	time(&dtnow);
	dtwhen = *localtime(&dtnow);
	strftime(DTStamp,100,"%d_%b_%Y_%H_%M_%S",&dtwhen);
	printf(" Current TimeStamp: [%s]\n", DTStamp);fflush(stdout);
	
	printf("\n Searched Module Address Value: [%s]\n", ModAdd);fflush(stdout);
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
            int	status_count = 0;
	        tag_t* relStatus_list = NULLTAG;
            char* latest_rev_Rel_Status = NULL;
	        char* latest_rev_Rel_StatusDup = NULL;			
	        rev_tags_found = tpLCQryobj_results[0];
			
			tag_t	tPNSrch	= NULLTAG;
			ITK_CALL(ITEM_find_item(PNSrch,&tPNSrch));
			char  **relations=NULL;
			ITK_CALL(WSOM_where_referenced2(tPNSrch, 1 ,&n_parents,&levels,&parents,&relations));
			//ITK_CALL(PS_where_used_all(rev_tags_found, 1, &n_parents, &levels, &parents));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Attachment Found: [%d]\n",n_parents);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_parents > 0)
			{
				int z = 0;
				printf(" Parent Attachment Found..!!\n");fflush(stdout);
				tc_strcpy(VCList,"@");
				for(z = 0; z < n_parents; z++)
				{ 
				   tParentDesRev = parents[z];
				   char *Parent_ID = NULL;
				   char *Parent_IDDup = NULL;
				   char *Parent_RevSeq = NULL;
				   char *Parent_RevSeqDup = NULL;
				   char *Parent_PartType = NULL;
				   char *Parent_PartTypeDup = NULL;
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_id",&Parent_ID));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_revision_id",&Parent_RevSeq));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_PartType",&Parent_PartType));
				   
				   printf("\n Parent Part_No: [%s]",Parent_ID);fflush(stdout);
				   printf("\n Parent Rev&Seq No: [%s]",Parent_RevSeq);fflush(stdout);
				   printf("\n Parent Part Type: [%s]",Parent_PartType);fflush(stdout);
				   
				   if(Parent_ID!=NULL)tc_strdup(Parent_ID,&Parent_IDDup);
				   if(Parent_RevSeq!=NULL)tc_strdup(Parent_RevSeq,&Parent_RevSeqDup);
				   if(Parent_PartType!=NULL)tc_strdup(Parent_PartType,&Parent_PartTypeDup);
				    if(tc_strlen(Parent_PartTypeDup)>0)
				    {
					    if((tc_strcmp(Parent_PartTypeDup,"V") == 0) || (tc_strcmp(Parent_PartTypeDup,"VCCR") == 0))
					    {
						    WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list);
							printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
							if(status_count>0)
							{
								int g = 0;
								for(g = 0; g<status_count; g++)
								{			  
									AOM_ask_value_string(relStatus_list[g],"object_name",&latest_rev_Rel_StatusDup);
									printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
									if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"ERC Released") == 0))
									{
									    tc_strdup("Yes",&ResponseVehlinkStat);
									   	linkcount = linkcount + 1;
                                        tc_strcat(VCList,Parent_IDDup);
										//tc_strcat(VCList,"_");
										//tc_strcat(VCList,Parent_RevSeqDup);
									    tc_strcat(VCList,"/@");										
									}
									else
									{
									   continue;
									}			  
								}
							}
					    }
				    }   
				}
			}
			else
			{
				tc_strdup("No",&ResponseVehlinkStat);
				printf("Parent Count Zero[0] Continue..!!\n");fflush(stdout);
			}	
		}
		else
		{
			tc_strdup("No",&ResponseVehlinkStat);
			printf("\nEntered Revision Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\nDesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	if(tc_strlen(ResponseVehlinkStat)>0)
	{
		printf("\n Vehicle Link Status Already Received..!!\n");fflush(stdout);
		printf("\n VC_List Before STRING_REPLACE: [%s]",VCList);fflush(stdout);
	    STRNG_replace_str(VCList,"@","",&VCList);
	    printf("\n VC_List After STRING_REPLACE: [%s]",VCList);fflush(stdout);
    }
    else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\n As ResponseVehlinkStat value was empty so status[No] added..!!\n");fflush(stdout);
	}
	
	
	printf("\n @@@@@@@@@@@@ Compare Start @@@@@@@@@@@@..!!\n");fflush(stdout);
	FILE *fpmsPart_List = NULL;
	char Buffer3[MAX_LINE_LENGTH];
	char *veh_item_id_str = NULL;
	char *veh_item_id_strDup = NULL;
	fpmsPart_List = fopen("/user/cvprod/sourav/RationalizedVCReport/Input_MasterVehicleList.txt","r");
	if(fpmsPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer3,MAX_LINE_LENGTH,fpmsPart_List)!=NULL)
		{
			veh_item_id_str=strtok(Buffer3,"^");
			if(veh_item_id_str!=NULL)tc_strdup(veh_item_id_str,&veh_item_id_strDup);
			printf("\n Input Vehicle String(veh_item_id_strDup): [%s]\n",veh_item_id_strDup);
		}
	}
	fclose(fpmsPart_List);
	if(tc_strcmp(ResponseVehlinkStat,"Yes") == 0)
	{
		if(tc_strcmp(veh_item_id_strDup,VCList) == 0)
		{
			printf("\n Exact Matched..!!\n");fflush(stdout);
			fprintf(ResRpt,"%s,%s,%s,%s,%d,%s,%s,%s\n",ModAdd,PNSrch,PNRevSeqSrch,ResponseVehlinkStat,linkcount,VCList,veh_item_id_strDup,"Yes");fflush(ResRpt);
		}
		else
		{
			printf("\n Not Exact Matched..!!\n");fflush(stdout);
			fprintf(ResRpt,"%s,%s,%s,%s,%d,%s,%s,%s\n",ModAdd,PNSrch,PNRevSeqSrch,ResponseVehlinkStat,linkcount,VCList,veh_item_id_strDup,"No");fflush(ResRpt);
		}
	}
	printf("\n @@@@@@@@@@@@ Compare End @@@@@@@@@@@@..!!\n");fflush(stdout);
	
	return ResponseVehlinkStat;	
}

char* TC_VehLinkStatus(char* ModAdd,char* PNSrch,char* PNRevSeqSrch,FILE* ResRpt)
{
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char* ResponseVehlinkStat = NULL;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	tag_t rev_tags_found = NULLTAG;
	tag_t tParentDesRev = NULLTAG;
	char *VCList = (char *) malloc(60000*sizeof(char));
	int linkcount = 0;
	
	char *PreVCompFile = (char *) malloc(100*sizeof(char));
	char DTStamp[100] = "";
	time_t 	dtnow;
	struct 	tm dtwhen;
	time(&dtnow);
	dtwhen = *localtime(&dtnow);
	strftime(DTStamp,100,"%d_%b_%Y_%H_%M_%S",&dtwhen);
	printf(" Current TimeStamp: [%s]\n", DTStamp);fflush(stdout);
	
	printf("\n Searched Module Address Value: [%s]\n", ModAdd);fflush(stdout);
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
            int	status_count = 0;
	        tag_t* relStatus_list = NULLTAG;
            char* latest_rev_Rel_Status = NULL;
	        char* latest_rev_Rel_StatusDup = NULL;			
	        rev_tags_found = tpLCQryobj_results[0];
			tag_t RevRuleObjTag = NULLTAG;
			
			ITK_CALL(CFM_find("ERC release and above", &RevRuleObjTag));
			if(RevRuleObjTag == NULLTAG)
			{
			    printf("\n !!!!!! Revision Rule Tag is Null..!!!!!!!");fflush(stdout);
			}
			else
			{
				printf("\n !!!!!! Revision Rule Tag is not Null..!!!!!!!");fflush(stdout);
			}
            //ITK_CALL(PS_where_used_all(rev_tags_found, 1, &n_parents, &levels, &parents));
            ITK_CALL(PS_where_used_configured(rev_tags_found,RevRuleObjTag,1,&n_parents,&levels,&parents));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Attachment Found: [%d]\n",n_parents);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_parents > 0)
			{
				int z = 0;
				printf(" Parent Attachment Found..!!\n");fflush(stdout);
				tc_strcpy(VCList,"@");
				for(z = 0; z < n_parents; z++)
				{ 
				   tParentDesRev = parents[z];
				   char *Parent_ID = NULL;
				   char *Parent_IDDup = NULL;
				   char *Parent_RevSeq = NULL;
				   char *Parent_RevSeqDup = NULL;
				   char *Parent_PartType = NULL;
				   char *Parent_PartTypeDup = NULL;
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_id",&Parent_ID));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"item_revision_id",&Parent_RevSeq));
				   ITK_CALL(AOM_ask_value_string(tParentDesRev,"t5_PartType",&Parent_PartType));
				   
				   printf("\n Parent Part_No: [%s]",Parent_ID);fflush(stdout);
				   printf("\n Parent Rev&Seq No: [%s]",Parent_RevSeq);fflush(stdout);
				   printf("\n Parent Part Type: [%s]",Parent_PartType);fflush(stdout);
				   
				   if(Parent_ID!=NULL)tc_strdup(Parent_ID,&Parent_IDDup);
				   if(Parent_RevSeq!=NULL)tc_strdup(Parent_RevSeq,&Parent_RevSeqDup);
				   if(Parent_PartType!=NULL)tc_strdup(Parent_PartType,&Parent_PartTypeDup);
				    if(tc_strlen(Parent_PartTypeDup)>0)
				    {
					    if((tc_strcmp(Parent_PartTypeDup,"V") == 0) || (tc_strcmp(Parent_PartTypeDup,"VCCR") == 0))
					    {
						    WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list);
							printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
							if(status_count>0)
							{
								int g = 0;
								for(g = 0; g<status_count; g++)
								{			  
									AOM_ask_value_string(relStatus_list[g],"object_name",&latest_rev_Rel_StatusDup);
									printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
									if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"ERC Released") == 0))
									{
									    tc_strdup("Yes",&ResponseVehlinkStat);
									   	linkcount = linkcount + 1;
                                        tc_strcat(VCList,Parent_IDDup);
										//tc_strcat(VCList,"_");
										//tc_strcat(VCList,Parent_RevSeqDup);
									    tc_strcat(VCList,"/@");										
									}
									else
									{
									   continue;
									}			  
								}
							}
					    }
				    }   
				}
			}
			else
			{
				tc_strdup("No",&ResponseVehlinkStat);
				printf("Parent Count Zero[0] Continue..!!\n");fflush(stdout);
			}	
		}
		else
		{
			tc_strdup("No",&ResponseVehlinkStat);
			printf("\nEntered Revision Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\nDesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	if(tc_strlen(ResponseVehlinkStat)>0)
	{
		printf("\n Vehicle Link Status Already Received..!!\n");fflush(stdout);
		printf("\n VC_List Before STRING_REPLACE: [%s]",VCList);fflush(stdout);
	    STRNG_replace_str(VCList,"@","",&VCList);
	    printf("\n VC_List After STRING_REPLACE: [%s]",VCList);fflush(stdout);
    }
    else
	{
		tc_strdup("No",&ResponseVehlinkStat);
		printf("\n As ResponseVehlinkStat value was empty so status[No] added..!!\n");fflush(stdout);
	}
	
	printf("\n @@@@@@@@@@@@ Compare Start @@@@@@@@@@@@..!!\n");fflush(stdout);
	FILE *fpmsPart_List = NULL;
	char Buffer3[MAX_LINE_LENGTH];
	char *veh_item_id_str = NULL;
	char *veh_item_id_strDup = NULL;
	fpmsPart_List = fopen("/user/cvprod/sourav/RationalizedVCReport/Input_MasterVehicleList.txt","r");
	if(fpmsPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer3,MAX_LINE_LENGTH,fpmsPart_List)!=NULL)
		{
			veh_item_id_str=strtok(Buffer3,"^");
			if(veh_item_id_str!=NULL)tc_strdup(veh_item_id_str,&veh_item_id_strDup);
			printf("\n Input Vehicle String(veh_item_id_strDup): [%s]\n",veh_item_id_strDup);
		}
	}
	fclose(fpmsPart_List);
	if(tc_strcmp(ResponseVehlinkStat,"Yes") == 0)
	{
		if(tc_strcmp(veh_item_id_strDup,VCList) == 0)
		{
			printf("\n Exact Matched..!!\n");fflush(stdout);
			fprintf(ResRpt,"%s,%s,%s,%s,%d,%s,%s,%s\n",ModAdd,PNSrch,PNRevSeqSrch,ResponseVehlinkStat,linkcount,VCList,veh_item_id_strDup,"Yes");fflush(ResRpt);
		}
		else
		{
			printf("\n Not Exact Matched..!!\n");fflush(stdout);
			fprintf(ResRpt,"%s,%s,%s,%s,%d,%s,%s,%s\n",ModAdd,PNSrch,PNRevSeqSrch,ResponseVehlinkStat,linkcount,VCList,veh_item_id_strDup,"No");fflush(ResRpt);
		}
	}
	printf("\n @@@@@@@@@@@@ Compare End @@@@@@@@@@@@..!!\n");fflush(stdout);
	
	return ResponseVehlinkStat;	
}

int ITK_user_main(int argc,char* argv[])
{
	char *message;
	char *loggedInUser = NULL;
	int i = 0;
	char *SrcPart_No = NULL;
	char *SrcRevSeq = NULL;
	char *SrcDesGrp = NULL;
	char *RptFile = (char *) malloc(200*sizeof(char));
	FILE *fpOutput_file = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *sr_no_strDup = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *item_revseq_strDup = (char *) malloc(20*sizeof(char));
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tQryDesRev = NULLTAG;
	int n_parents = 0;
	int *levels	= 0;
	tag_t *parents = NULLTAG;
	int j = 0;
	char *Parent_ID = NULL;
	char *Parent_RevSeq = NULL;
	char *Parent_IDDup = NULL;
	char *Parent_RevSeqDup = NULL;
	char *Parent_PartType = NULL;
	char *Parent_PartTypeDup = NULL;
	tag_t tParentDesRev = NULLTAG;
	char *item_add_str = NULL;
	char *item_add_strDup = NULL;
	char *item_email_str = NULL;
	char *item_email_strDup = NULL;
	

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"/tmp/");
	tc_strcpy(RptFile,"Vehicle_Link_Status_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
	fpPart_List = fopen("/user/cvprod/sourav/RationalizedVCReport/Input_GenObsoleteStatus.txt","r");
	 
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"ADDRESS, PART_NO, REVSEQ, VEHICLE_LINK_STATUS, LINK_COUNT, ATTACHED_VEHICLE_DETAILS, INPUT_VEHICLE_DETAILS, EXACT_MATCH_STATUS\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			tc_strcpy(item_revseq_strDup,item_rev_strDup);
			tc_strcat(item_revseq_strDup,"*");
			tc_strcat(item_revseq_strDup,item_seq_strDup);
			printf("\n Part Rev&Seq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			printf(" [1]: Input Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf(" [2]: Input Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			printf(" [3]: Input Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
		
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
			if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"A*2","5137D1D0270001_WE"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						tQryDesRev = titemobj_results[i];
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_id",&SrcPart_No));
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_revision_id",&SrcRevSeq));
						ITK_CALL(AOM_ask_value_string(tQryDesRev,"t5_DesignGrp",&SrcDesGrp));
						item_add_strDup = subString(SrcPart_No, 4, 5);
			            trimwhitespace(item_add_strDup);
			            printf("\n Part Module Address Value: [%s]", item_add_strDup);fflush(stdout);
						printf("Child Part Details: ----> Child_Part_No: [%s], Child_Part_RevSeq: [%s], Child_Part_DesignGroup: [%s]\n",SrcPart_No,SrcRevSeq, SrcDesGrp);fflush(stdout);
						
						char* Veh_LinkStatus = NULL;
						if(tc_strcmp(SrcDesGrp,"16")==0)
						{
							printf("\n Function2: [EE_Part] Vehicle Link And Platform Status Find Start..!!\n");fflush(stdout);
							Veh_LinkStatus = TC_EEVehLinkStatus(item_add_strDup,SrcPart_No,item_revseq_strDup,fpOutput_file);
							printf("\n Part Attached with Vehicle[Vehicle Link Status]: [%s]", Veh_LinkStatus);fflush(stdout);
							printf("\n Function2: [EE_Part] Vehicle Link And Platform Status Find End..!!\n");fflush(stdout);
						}
						else
						{
							printf("\n Function1: [Normal_Part] Vehicle Link And Platform Status Find Start..!!\n");fflush(stdout);
							Veh_LinkStatus = TC_VehLinkStatus(item_add_strDup,SrcPart_No,item_revseq_strDup,fpOutput_file);
							printf("\n Part Attached with Vehicle[Vehicle Link Status]: [%s]", Veh_LinkStatus);fflush(stdout);
							printf("\n Function1: [Normal_Part] Vehicle Link And Platform Status Find End..!!\n");fflush(stdout);
						}
					}
				}
				else
				{
					printf("\n Design Revision Not Found Continue..!!\n");fflush(stdout);
				}
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	fclose(fpPart_List);
	printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout);	
					
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_InputVehicleLinkStatus.c
* // ./linkitk -o tm_InputVehicleLinkStatus tm_InputVehicleLinkStatus.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/InputVehicleLinkStatus/tm_InputVehicleLinkStatus .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/InputVehicleLinkStatus/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/InputVehicleLinkStatus/usage.txt .
* // ./tm_InputVehicleLinkStatus -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Add="D1D02" -Part="5137D1D0270001" -Rev="NR" -Seq="1" -Email="souravk.ttl@tatamotors.com"
* // ./tm_InputVehicleLinkStatus -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Add="D1D02" -Part="5137D1D0270001" -Rev="NR" -Seq="1" -Email="souravk.ttl@tatamotors.com"
*
***************************************************************************/