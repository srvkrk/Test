./compile tm_SamplePythonCode.c
./linkitk -o tm_SamplePythonCode tm_SamplePythonCode.o
chmod 777 tm_SamplePythonCode*
