######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : JANUARY-2024
#
#######################################################################################


echo  "-----------------------------------------------------------------------------------------"
echo  'Project Code Control-Object Creation Program Started...'
echo  "-----------------------------------------------------------------------------------------"
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5701 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=29 >XFRDML_5701.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5836 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=30 >XFRDML_5836.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2084 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=31 >XFRDML_2084.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2202 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=32 >XFRDML_2202.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5120 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=33 >XFRDML_5120.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5567 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=34 >XFRDML_5567.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5197 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=35 >XFRDML_5197.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5873 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=36 >XFRDML_5873.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5080 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=37 >XFRDML_5080.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5088 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=38 >XFRDML_5088.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2885 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=39 >XFRDML_2885.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5166 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=40 >XFRDML_5166.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5167 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=41 >XFRDML_5167.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5169 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=42 >XFRDML_5169.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5185 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=43 >XFRDML_5185.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5203 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=44 >XFRDML_5203.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2525 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=45 >XFRDML_2525.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2726 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=46 >XFRDML_2726.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5706 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=47 >XFRDML_5706.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5709 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=48 >XFRDML_5709.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5737 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=49 >XFRDML_5737.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5810 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=50 >XFRDML_5810.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5821 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=51 >XFRDML_5821.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2574 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=52 >XFRDML_2574.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2753 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=53 >XFRDML_2753.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5017 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=54 >XFRDML_5017.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5027 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=54 >XFRDML_5027.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5039 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=55 >XFRDML_5039.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5569 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=56 >XFRDML_5569.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5568 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=57 >XFRDML_5568.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5004 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=58 >XFRDML_5004.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5006 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=59 >XFRDML_5006.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5714 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=60 >XFRDML_5714.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5155 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=61 >XFRDML_5155.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5193 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=62 >XFRDML_5193.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5207 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=63 >XFRDML_5207.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5211 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=64 >XFRDML_5211.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5560 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=65 >XFRDML_5560.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5716 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=66 >XFRDML_5716.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5805 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=67 >XFRDML_5805.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5817 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=68 >XFRDML_5817.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5846 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=69 >XFRDML_5846.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2816 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=70 >XFRDML_2816.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=2841 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=71 >XFRDML_2841.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5007 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=72 >XFRDML_5007.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5081 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=73 >XFRDML_5081.out &
nohup $OPNEXE/control_object -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -s=XFRDML -b=5147 -i1=APLJ -i2=STDJ -i3=2001 -i4=SAPLIVE -i5="" -i6="" -i7=74 >XFRDML_5147.out &
echo  "-----------------------------------------------------------------------------------------"
echo  'Project Code Control-Object Creation Program Finished...'
echo  "-----------------------------------------------------------------------------------------"
