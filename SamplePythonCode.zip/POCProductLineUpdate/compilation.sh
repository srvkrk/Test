./compile tm_pocproductlineupdate.c
./linkitk -o tm_pocproductlineupdate tm_pocproductlineupdate.o
chmod 777 tm_pocproductlineupdate*
