/user/cvprod/sourav/PlatformUpdate/tm_platformupdate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
