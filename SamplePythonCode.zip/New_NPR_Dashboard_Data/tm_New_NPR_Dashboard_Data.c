/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: tm_New_NPR_Dashboard_Data.c
**
** Functions:- 	This utility takes all created NPR object and generate NPR Dashboard data in csv format.

***********************************************************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y_%H_%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%m_%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

char* MonthAbbreviation (char* MonthName)
{
	//char *ResponseMonth = (char *) malloc(400*sizeof(char));
	char *ResponseMonth = NULL;
	ResponseMonth = (char *) MEM_alloc( 400 * sizeof(char) );
	printf("\n Input Month Name in String: --------> [%s]\n", MonthName);fflush(stdout);
	if(tc_strcmp(MonthName,"Jan")==0)
	{
		tc_strcpy(ResponseMonth,"01");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Feb")==0)
	{
		tc_strcpy(ResponseMonth,"02");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Mar")==0)
	{
		tc_strcpy(ResponseMonth,"03");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Apr")==0)
	{
		tc_strcpy(ResponseMonth,"04");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"May")==0)
	{
		tc_strcpy(ResponseMonth,"05");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Jun")==0)
	{
		tc_strcpy(ResponseMonth,"06");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Jul")==0)
	{
		tc_strcpy(ResponseMonth,"07");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Aug")==0)
	{
		tc_strcpy(ResponseMonth,"08");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Sep")==0)
	{
		tc_strcpy(ResponseMonth,"09");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Oct")==0)
	{
		tc_strcpy(ResponseMonth,"10");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Nov")==0)
	{
		tc_strcpy(ResponseMonth,"11");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Dec")==0)
	{
		tc_strcpy(ResponseMonth,"12");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else
	{
		printf("Invalid Number");
	}
	  
	return ResponseMonth;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

// Function to calculate the number of weekdays between two dates
int weekdayDifference(struct tm start_date, struct tm end_date) 
{
    int weekday_count = 0;
    time_t start_time = mktime(&start_date);
    time_t end_time = mktime(&end_date);
    
    // Handle cases where start_date is after end_date
    if (start_time > end_time) 
    {
        return -1;
    }

    //while (start_time <= end_time)
	while (start_time < end_time)
    {
        struct tm current_date = *localtime(&start_time);
        int day_of_week = current_date.tm_wday;

        // Check if the current day is not a Saturday (6) or Sunday (0)
        if (day_of_week != 0 && day_of_week != 6) 
        {
            weekday_count++;
        }

        // Increment the time by one day
        start_time += 24 * 60 * 60; // Add 24 hours in seconds
    }

    return weekday_count;
}

void replaceSpacesWithSlash(char *str) {
    int i;
    // Iterate through the string until the null terminator is reached
    for (i = 0; str[i] != '\0'; i++) {
        // If the current character is a space, replace it with a forward slash
        if (str[i] == ' ') {
            str[i] = '/';
        }
    }
}

void remove_chars(char *str, const char *chars_to_remove) {
    int i, j;
	printf("\n 1remove_chars::str========>:[%s]\n",str);fflush(stdout);
    int str_len = strlen(str);
    int chars_len = strlen(chars_to_remove);

    for (i = 0, j = 0; i < str_len; i++) {
        int remove = 0;
        for (int k = 0; k < chars_len; k++) {
            if (str[i] == chars_to_remove[k]) {
                remove = 1;
                break;
            }
        }
        if (!remove) {
            str[j++] = str[i];
        }
    }
    str[j] = '\0';
	printf("\n 2remove_chars::str========>:[%s]\n",str);fflush(stdout);
}

void trim_newline(char *str) {
    size_t len = strlen(str);
    if (len > 0 && (str[len - 1] == '\n' || str[len - 1] == '\r' || str[len - 1] == ',')) {
        str[len - 1] = '\0';
    }
}

int TC_DaysCount(char* MccStartDate,char* NPRMCCApproveDate)
{
	printf(" @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@\n");fflush(stdout);
	char CrDate[100] = "";
	time_t 	loc;
	struct 	tm when;
	time(&loc);
	when = *localtime(&loc);
	strftime(CrDate,100,"%d-%m-%Y %H:%M",&when);
	printf(" Current TimeStamp: [%s]\n", CrDate);fflush(stdout);
	
	printf(" MccStartDate: [%s]\n", MccStartDate);fflush(stdout);
	printf(" NPRMCCApproveDate: [%s]\n", NPRMCCApproveDate);fflush(stdout);
	printf(" Current Time: [%s]\n", CrDate);fflush(stdout);
	
	/* @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@*/
	int difference = 0;
	if((tc_strstr(MccStartDate,"Jan")!=NULL) || (tc_strstr(MccStartDate,"Feb")!=NULL) || (tc_strstr(MccStartDate,"Mar")!=NULL) || (tc_strstr(MccStartDate,"Apr")!=NULL) || (tc_strstr(MccStartDate,"May")!=NULL) || (tc_strstr(MccStartDate,"Jun")!=NULL) || (tc_strstr(MccStartDate,"Jul")!=NULL) || (tc_strstr(MccStartDate,"Aug")!=NULL) || (tc_strstr(MccStartDate,"Sep")!=NULL) || (tc_strstr(MccStartDate,"Oct")!=NULL) || (tc_strstr(MccStartDate,"Nov")!=NULL) || (tc_strstr(MccStartDate,"Dec")!=NULL))
	{
		if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA") !=0))
		{
			char* ReNwMccStartDate = NULL;
			ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwMccStartDate,MccStartDate);
			printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwMccStartDate);
			if(ReNwMccStartDate != NULL)
			{
				STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
			}
			 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
			char* Freceived = NULL;
			char* Sreceived = NULL;
			Freceived = tc_strtok(ReNwMccStartDate,"/");
			Sreceived = tc_strtok(NULL,"/");
			printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
			printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
			char* ReInpDay = NULL;
			char* ReInpMon = NULL;
			char* ReInpYear = NULL;
			char* ReInpYearChar = NULL;
			ReInpDay=tc_strtok(Freceived,"-");
			ReInpMon=tc_strtok(NULL,"-");
			ReInpYear=tc_strtok(NULL,"-");
			printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
			printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
			char* RespMonth = NULL;
			RespMonth = MonthAbbreviation(ReInpMon);
			printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
			printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
			
			
			char* ReNwNPRMCCApproveDate = NULL;
			ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwNPRMCCApproveDate,NPRMCCApproveDate);
			printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
			if(ReNwNPRMCCApproveDate != NULL)
			{
				STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
			}
			printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			char* Fcompleted = NULL;
			char* Scompleted = NULL;
			Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
			Scompleted = tc_strtok(NULL,"/");
			printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
			printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
			char* ComInpDay = NULL;
			char* ComInpMon = NULL;
			char* ComInpYear = NULL;
			char* ComInpYearChar = NULL;
			ComInpDay=tc_strtok(Fcompleted,"-");
			ComInpMon=tc_strtok(NULL,"-");
			ComInpYear=tc_strtok(NULL,"-");
			printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
			printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
			char* ComRespMonth = NULL;
			ComRespMonth = MonthAbbreviation(ComInpMon);
			printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
			printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
			
			int ReInpdayFinal = atoi(ReInpDay);
			int ReInpMonFinal = atoi(RespMonth);
			int ReInpYearFinal = atoi(ReInpYear);
			
			int ComInpDayFinal = atoi(ComInpDay);
			int ComInpMonFinal = atoi(ComRespMonth);
			int ComInpYearFinal = atoi(ComInpYear);
		
			struct tm start_date = {0};
			struct tm end_date = {0};

			// Example usage: Setting the dates
			start_date.tm_year = ReInpYearFinal; // Year - 1900
			start_date.tm_mon = ReInpMonFinal; // Month (0-11)
			start_date.tm_mday = ReInpdayFinal; // Day of the month (1-31)

			end_date.tm_year = ComInpYearFinal;
			end_date.tm_mon = ComInpMonFinal;
			end_date.tm_mday = ComInpDayFinal;


			difference = weekdayDifference(start_date, end_date);

			if (difference != -1) 
			{
				 printf("Difference: [%d]", difference);
			} 
			else 
			{
				difference = 0;
				printf("Difference: [%d]", difference);
			}
			printf("Number of weekdays between the dates: [%d]\n", difference);
		}
		else if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA") ==0))
		{
			char* ReNwMccStartDate = NULL;
			ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwMccStartDate,MccStartDate);
			printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwMccStartDate);
			if(ReNwMccStartDate != NULL)
			{
				STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
			}
			 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
			char* Freceived = NULL;
			char* Sreceived = NULL;
			Freceived = tc_strtok(ReNwMccStartDate,"/");
			Sreceived = tc_strtok(NULL,"/");
			printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
			printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
			char* ReInpDay = NULL;
			char* ReInpMon = NULL;
			char* ReInpYear = NULL;
			//char* ReInpYearChar = NULL;
			ReInpDay=tc_strtok(Freceived,"-");
			ReInpMon=tc_strtok(NULL,"-");
			ReInpYear=tc_strtok(NULL,"-");
			printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
			printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
			char* RespMonth = NULL;
			RespMonth = MonthAbbreviation(ReInpMon);
			printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
			printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
			
			char* ReNwNPRMCCApproveDate = NULL;
			ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwNPRMCCApproveDate,CrDate);
			printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
			if(ReNwNPRMCCApproveDate != NULL)
			{
				STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
			}
			printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			char* Fcompleted = NULL;
			char* Scompleted = NULL;
			Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
			Scompleted = tc_strtok(NULL,"/");
			printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
			printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
			char* ComInpDay = NULL;
			char* ComInpMon = NULL;
			char* ComInpYear = NULL;
			//char* ComInpYearChar = NULL;
			ComInpDay=tc_strtok(Fcompleted,"-");
			ComInpMon=tc_strtok(NULL,"-");
			ComInpYear=tc_strtok(NULL,"-");
			printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
			printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
			//char* ComRespMonth = NULL;
			//ComRespMonth = MonthAbbreviation(ComInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
			printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
			
			int ReInpdayFinal = atoi(ReInpDay);
			int ReInpMonFinal = atoi(RespMonth);
			int ReInpYearFinal = atoi(ReInpYear);
			
			int ComInpDayFinal = atoi(ComInpDay);
			int ComInpMonFinal = atoi(ComInpMon);
			int ComInpYearFinal = atoi(ComInpYear);
			
			struct tm start_date = {0};
			struct tm end_date = {0};

			// Example usage: Setting the dates
			start_date.tm_year = ReInpYearFinal; // Year - 1900
			start_date.tm_mon = ReInpMonFinal; // Month (0-11)
			start_date.tm_mday = ReInpdayFinal; // Day of the month (1-31)

			end_date.tm_year = ComInpYearFinal;
			end_date.tm_mon = ComInpMonFinal;
			end_date.tm_mday = ComInpDayFinal;


			difference = weekdayDifference(start_date, end_date);

			if (difference != -1) 
			{
				 printf("Difference: [%d]", difference);
			} 
			else 
			{
				difference = 0;
				printf("Difference: [%d]", difference);
			}
			printf("Number of weekdays between the dates: [%d]\n", difference);
		}
		else
		{
			difference = 0;
		}
	}
	else
	{
		if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA") !=0))
		{
			char* ReNwMccStartDate = NULL;
			ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwMccStartDate,MccStartDate);
			printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwMccStartDate);
			if(ReNwMccStartDate != NULL)
			{
				STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
			}
			 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
			char* Freceived = NULL;
			char* Sreceived = NULL;
			Freceived = tc_strtok(ReNwMccStartDate,"/");
			Sreceived = tc_strtok(NULL,"/");
			printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
			printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
			char* ReInpDay = NULL;
			char* ReInpMon = NULL;
			char* ReInpYear = NULL;
			char* ReInpYearChar = NULL;
			ReInpDay=tc_strtok(Freceived,"-");
			ReInpMon=tc_strtok(NULL,"-");
			ReInpYear=tc_strtok(NULL,"-");
			printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
			printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
			//char* RespMonth = NULL;
			//RespMonth = MonthAbbreviation(ReInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
			printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
			
			
			char* ReNwNPRMCCApproveDate = NULL;
			ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwNPRMCCApproveDate,NPRMCCApproveDate);
			printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
			if(ReNwNPRMCCApproveDate != NULL)
			{
				STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
			}
			printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			char* Fcompleted = NULL;
			char* Scompleted = NULL;
			Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
			Scompleted = tc_strtok(NULL,"/");
			printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
			printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
			char* ComInpDay = NULL;
			char* ComInpMon = NULL;
			char* ComInpYear = NULL;
			char* ComInpYearChar = NULL;
			ComInpDay=tc_strtok(Fcompleted,"-");
			ComInpMon=tc_strtok(NULL,"-");
			ComInpYear=tc_strtok(NULL,"-");
			printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
			printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
			//char* ComRespMonth = NULL;
			//ComRespMonth = MonthAbbreviation(ComInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
			printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
			
			int ReInpdayFinal = atoi(ReInpDay);
			int ReInpMonFinal = atoi(ReInpMon);
			int ReInpYearFinal = atoi(ReInpYear);
			
			int ComInpDayFinal = atoi(ComInpDay);
			int ComInpMonFinal = atoi(ComInpMon);
			int ComInpYearFinal = atoi(ComInpYear);
		
			struct tm start_date = {0};
			struct tm end_date = {0};

			// Example usage: Setting the dates
			start_date.tm_year = ReInpYearFinal; // Year - 1900
			start_date.tm_mon = ReInpMonFinal; // Month (0-11)
			start_date.tm_mday = ReInpdayFinal; // Day of the month (1-31)

			end_date.tm_year = ComInpYearFinal;
			end_date.tm_mon = ComInpMonFinal;
			end_date.tm_mday = ComInpDayFinal;


			difference = weekdayDifference(start_date, end_date);

			if (difference != -1) 
			{
				 printf("Difference: [%d]", difference);
			} 
			else 
			{
				difference = 0;
				printf("Difference: [%d]", difference);
			}
			printf("Number of weekdays between the dates: [%d]\n", difference);
		}
		else if((tc_strlen(MccStartDate) > 0) && (tc_strcmp(MccStartDate,"NA") !=0) && (tc_strlen(NPRMCCApproveDate) > 0) && (tc_strcmp(NPRMCCApproveDate,"NA")==0))
		{
			char* ReNwMccStartDate = NULL;
			ReNwMccStartDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwMccStartDate,MccStartDate);
			printf("\n ReNwMccStartDate Before: [%s]\n", ReNwMccStartDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwMccStartDate);
			if(ReNwMccStartDate != NULL)
			{
				STRNG_replace_str(ReNwMccStartDate,"//","/",&ReNwMccStartDate);
			}
			 printf("\n ReNwMccStartDate After: [%s]\n", ReNwMccStartDate);fflush(stdout);
			char* Freceived = NULL;
			char* Sreceived = NULL;
			Freceived = tc_strtok(ReNwMccStartDate,"/");
			Sreceived = tc_strtok(NULL,"/");
			printf("\n Freceived: [%s]\n", Freceived);fflush(stdout);
			printf("\n Sreceived: [%s]\n", Sreceived);fflush(stdout);
			char* ReInpDay = NULL;
			char* ReInpMon = NULL;
			char* ReInpYear = NULL;
			//char* ReInpYearChar = NULL;
			ReInpDay=tc_strtok(Freceived,"-");
			ReInpMon=tc_strtok(NULL,"-");
			ReInpYear=tc_strtok(NULL,"-");
			printf("\n ReInpDay: [%s]\n", ReInpDay);fflush(stdout);
			printf("\n ReInpMon: [%s]\n", ReInpMon);fflush(stdout);
			//char* RespMonth = NULL;
			//RespMonth = MonthAbbreviation(ReInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
			printf("\n ReInpYear: [%s]\n", ReInpYear);fflush(stdout);
			
			char* ReNwNPRMCCApproveDate = NULL;
			ReNwNPRMCCApproveDate = (char *) MEM_alloc( 50 * sizeof(char) );
			tc_strcpy(ReNwNPRMCCApproveDate,CrDate);
			printf("\n ReNwNPRMCCApproveDate Before: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			replaceSpacesWithSlash(ReNwNPRMCCApproveDate);
			if(ReNwNPRMCCApproveDate != NULL)
			{
				STRNG_replace_str(ReNwNPRMCCApproveDate,"//","/",&ReNwNPRMCCApproveDate);
			}
			printf("\n ReNwNPRMCCApproveDate After: [%s]\n", ReNwNPRMCCApproveDate);fflush(stdout);
			char* Fcompleted = NULL;
			char* Scompleted = NULL;
			Fcompleted = tc_strtok(ReNwNPRMCCApproveDate,"/");
			Scompleted = tc_strtok(NULL,"/");
			printf("\n Fcompleted: [%s]\n", Fcompleted);fflush(stdout);
			printf("\n Scompleted: [%s]\n", Scompleted);fflush(stdout);
			char* ComInpDay = NULL;
			char* ComInpMon = NULL;
			char* ComInpYear = NULL;
			//char* ComInpYearChar = NULL;
			ComInpDay=tc_strtok(Fcompleted,"-");
			ComInpMon=tc_strtok(NULL,"-");
			ComInpYear=tc_strtok(NULL,"-");
			printf("\n ComInpDay: [%s]\n", ComInpDay);fflush(stdout);
			printf("\n ComInpMon: [%s]\n", ComInpMon);fflush(stdout);
			//char* ComRespMonth = NULL;
			//ComRespMonth = MonthAbbreviation(ComInpMon);
			//printf("\n Input Month(MonthAbbreviation): [%s]\n", ComRespMonth);fflush(stdout);
			printf("\n ComInpYear: [%s]\n", ComInpYear);fflush(stdout);
			
			int ReInpdayFinal = atoi(ReInpDay);
			int ReInpMonFinal = atoi(ReInpMon);
			int ReInpYearFinal = atoi(ReInpYear);
			
			int ComInpDayFinal = atoi(ComInpDay);
			int ComInpMonFinal = atoi(ComInpMon);
			int ComInpYearFinal = atoi(ComInpYear);
			
			struct tm start_date = {0};
			struct tm end_date = {0};

			// Example usage: Setting the dates
			start_date.tm_year = ReInpYearFinal; // Year - 1900
			start_date.tm_mon = ReInpMonFinal; // Month (0-11)
			start_date.tm_mday = ReInpdayFinal; // Day of the month (1-31)

			end_date.tm_year = ComInpYearFinal;
			end_date.tm_mon = ComInpMonFinal;
			end_date.tm_mday = ComInpDayFinal;


			difference = weekdayDifference(start_date, end_date);

			if (difference != -1) 
			{
				 printf("Difference: [%d]", difference);
			} 
			else 
			{
				difference = 0;
				printf("Difference: [%d]", difference);
			}
			printf("Number of weekdays between the dates: [%d]\n", difference);
		}
		else
		{
			difference = 0;
		}
	}						
/* @@@@@@@@@@@@@@@  Weekdays calculation logic end @@@@@@@@@@@@@@@@ */
	printf(" @@@@@@@@@@@@@ Weekdays calculation logic end @@@@@@@@@@@@@@\n");fflush(stdout);
	return difference;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *Part_Type = NULL;
	char *Part_TypeDup = NULL;
	char *ModAddress = NULL;	
	char *ModAddressDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	tag_t DesRev_tag = NULLTAG;
	char* MccStatusvalue = NULL;
	char* MccStatusvalueDup = NULL;
	char* MccAppRejStatus = NULL;
	char* MccAppRejStatusDup = NULL;
	char* MccStartDate = NULL;
	char* MccStartDateDup = NULL;
	char* MccCompleteDate = NULL;
	char* MccCompleteDateDup = NULL;
	char* MccApproveDate = NULL;
	char* MccApproveDateDup = NULL;
	char* MccApprovedBy = NULL;
	char* MccApprovedByDup = NULL;
	char* MccRejectDate = NULL;
	char* MccRejectDateDup = NULL;
	char* MccRejectBy = NULL;
	char* MccRejectByDup = NULL;
	char* MccProductLine = NULL;
	char* MccProductLineDup = NULL;
	char* MccAggrGrp = NULL;
	char* MccAggrGrpDup = NULL;
	char* MccTmlPartNo = NULL;
	char* MccTmlPartNoDup = NULL;
    tag_t refrelation_type = NULLTAG;
	tag_t* refnprchklist = NULLTAG;
	int	refcnt	= 0;
	char* NewVCNumber = NULL;
	char* NewVCNumberDup = NULL;
	char* NewVCDesc = NULL;
	char* NewVCDescDup = NULL;
	char* BaseVCNumber = NULL;
	char* BaseVCNumberDup = NULL;
	char* BaseVCDesc = NULL;
	char* BaseVCDescDup = NULL;
	char* BaseSubModNumber = NULL;
	char* BaseSubModNumberDup = NULL;
	char* BaseSubModDesc = NULL;
	char* BaseSubModDescDup = NULL;
	char* MccNPRModAddress = NULL;
	char* MccNPRModAddressDup = NULL;
	char* IBDomestic = NULL;
	char* IBDomesticDup = NULL;
	char* COCDesg = NULL;
	char* COCDesgDup = NULL;
	char* MccRemark = NULL;
	char* MccRemarkDup = NULL;
	char chars_to_remove[] = "\n\r*,#";
	char* MccReason = NULL;
	char* MccReasonDup = NULL;
				
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char*  F_date = ITK_ask_cli_argument("-F=");
	char*  T_date = ITK_ask_cli_argument("-T=");
	char* From_date = NULL;
	char* To_date = NULL;
	From_date = (char *) MEM_alloc(100);
	To_date = (char *) MEM_alloc(100);
			
	tc_strcpy(From_date,"");
	tc_strcpy(From_date,F_date);
	tc_strcat(From_date," 00:00");
			
	tc_strcpy(To_date,"");
	tc_strcpy(To_date,T_date);
	tc_strcat(To_date," 23:59");
	
	printf(" [1]: Input From_Date(From_date): [%s]\n",From_date);
	printf(" [2]: Input To_Date(To_date): [%s]\n",To_date);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	char NewGenDate[100] = "";
	struct 	tm newwhen;
	time(&now);
	newwhen = *localtime(&now);
	strftime(NewGenDate,100,"%d-%m-%Y %H:%M",&newwhen);
	printf(" New Current TimeStamp: [%s]\n", NewGenDate);fflush(stdout); 
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	//tc_strcpy(RptFile,"/tmp/");
	tc_strcpy(RptFile,"NPR_Dashboard_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Name Generated..!!");fflush(stdout);
	FILE* fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"NPR_Number, Product_Line, Aggregate_Group, MCC_Reviewer_Name, Start, End,  Ageing,  Status, TML_Part_Number, New_VC, New_VC_Desc, Base_VC, Base_VC_Desc, Base_SubModule, Base_SubModule_Desc, Module_Address, IB/Domestic, COC_Designer, Remarks, Reason\n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
		printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	tag_t ModAddctrlquery = NULLTAG;
	int ModAddctrl_n_found = 0;
	tag_t* ModAddCntrlObjs = NULLTAG;
	char* modinfo01Str = NULL;
	char* modinfo02Str = NULL;
	char* modinfo03Str = NULL;
	char* modinfo04Str = NULL;
	char* MODULE_OTHER_ADDRESS = NULL;
	ITK_CALL(QRY_find2("ControlObjQry",&ModAddctrlquery));
	if(ModAddctrlquery != NULLTAG)
	{
		printf("\n [ControlObjQry] Found Successfully..!!\n");fflush(stdout);
		char *ModAddctrl_qry_entries[1]  = {"SYSCD"};
		char *ModAddctrl_qry_values[1]  = {"NewPartReqPartTypeCheckForIFD"};
		//char *ModAddctrl_qry_values[1]  = {"NewPartReqPartTypeCheckForIFD"};
		ITK_CALL(QRY_execute(ModAddctrlquery,1, ModAddctrl_qry_entries, ModAddctrl_qry_values, &ModAddctrl_n_found, &ModAddCntrlObjs));
		printf("\n TML_New_MCC_NODE_Function:ModAddctrl_n_found: [%d]",ModAddctrl_n_found);fflush(stdout);
		if(ModAddctrl_n_found>0)
		{
			ITK_CALL(AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo1",&modinfo01Str));
			ITK_CALL(AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo2",&modinfo02Str));
			ITK_CALL(AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo3",&modinfo03Str));
			ITK_CALL(AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo4",&modinfo04Str));
			printf("\n modinfo01Str: [%s]",modinfo01Str);fflush(stdout);
			printf("\n modinfo02Str: [%s]",modinfo02Str);fflush(stdout);
			printf("\n modinfo03Str: [%s]",modinfo03Str);fflush(stdout);
			printf("\n modinfo04Str: [%s]",modinfo04Str);fflush(stdout);
			MODULE_OTHER_ADDRESS = (char *) MEM_alloc(2000);
			tc_strcpy(MODULE_OTHER_ADDRESS,modinfo01Str);
			tc_strcat(MODULE_OTHER_ADDRESS,modinfo02Str);
		    tc_strcat(MODULE_OTHER_ADDRESS,modinfo03Str);
			tc_strcat(MODULE_OTHER_ADDRESS,modinfo04Str);
		}
		printf("\n MODULE_OTHER_ADDRESS: [%s]",MODULE_OTHER_ADDRESS);fflush(stdout);
	}
	
	ITK_CALL(QRY_find2("Item...",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n [Item...] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Type","Created After","Created Before"};
		char *cValues[3]  = {"New Part Request",From_date,To_date};
		//char *cValues[3]  = {"New Part Request","07-Apr-2024","02-Aug-2025"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of NPR Object Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		for (i = 0; i < n_itemobj_found; i++)
		{
			DesRev_tag = titemobj_results[i];
			ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
			if(tc_strlen(item_id_str)>0)
			{
				tc_strdup(item_id_str,&item_id_strDup);
				trimwhitespace(item_id_strDup);
			}
			else
			{
				tc_strdup("NA",&item_id_strDup);
				printf("\n NPR Number Value is NULL..!!");fflush(stdout);
			}
			ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartType",&Part_Type));
			if(tc_strlen(Part_Type)>0)
			{
				tc_strdup(Part_Type,&Part_TypeDup);
				trimwhitespace(Part_TypeDup);
			}
			else
			{
				tc_strdup("NA",&Part_TypeDup);
				printf("\n NPR Part Type Value is NULL..!!");fflush(stdout);
			}
			ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ModuleAddress",&ModAddress));
			if(tc_strlen(ModAddress)>0)
			{
				tc_strdup(ModAddress,&ModAddressDup);
				trimwhitespace(ModAddressDup);
			}
			else
			{
				tc_strdup("NA",&ModAddressDup);
				printf("\n NPR Module Address Value is NULL..!!");fflush(stdout);
			}
			printf("\n NPR Item_ID: [%s]\n",item_id_strDup);fflush(stdout);
			printf("\n NPR Part_Type: [%s]\n",Part_TypeDup);fflush(stdout);
			printf("\n NPR Module_Address: [%s]\n",ModAddressDup);fflush(stdout);
			
			if((tc_strlen(item_id_strDup)==25) && (tc_strcmp(Part_Type,"Module")==0 || tc_strcmp(Part_Type,"M")==0 || tc_strcmp(Part_Type,"ECU Module")==0 || tc_strcmp(Part_Type,"EM")==0 || tc_strcmp(Part_Type,"IFD Module")==0 || tc_strcmp(Part_Type,"IM")==0) && (tc_strstr(MODULE_OTHER_ADDRESS,ModAddress)==NULL))
			{
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCStatus",&MccStatusvalue)); 
				if(tc_strlen(MccStatusvalue)>0)
				{
					tc_strdup(MccStatusvalue,&MccStatusvalueDup);
					trimwhitespace(MccStatusvalueDup);
				}
				else
				{
					tc_strdup("NA",&MccStatusvalueDup);
					printf("\n MCC Status Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCApproveReject",&MccAppRejStatus));
				if(tc_strlen(MccAppRejStatus)>0)
				{
					tc_strdup(MccAppRejStatus,&MccAppRejStatusDup);
					trimwhitespace(MccAppRejStatusDup);
				}
				else
				{
					tc_strdup("NA",&MccAppRejStatusDup);
					printf("\n MCC Approve/Reject Status Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCStartDate",&MccStartDate));
				if(tc_strlen(MccStartDate)>0)
				{
					tc_strdup(MccStartDate,&MccStartDateDup);
					trimwhitespace(MccStartDateDup);
				}
				else
				{
					tc_strdup("NA",&MccStartDateDup);
					printf("\n MCC Start Date Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCCompleteDate",&MccCompleteDate));
				if(tc_strlen(MccCompleteDate)>0)
				{
					tc_strdup(MccCompleteDate,&MccCompleteDateDup);
					trimwhitespace(MccCompleteDateDup);
				}
				else
				{
					tc_strdup("NA",&MccCompleteDateDup);
					printf("\n MCC Complete Date Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCApproveDate",&MccApproveDate));
				if(tc_strlen(MccApproveDate)>0)
				{
					tc_strdup(MccApproveDate,&MccApproveDateDup);
					trimwhitespace(MccApproveDateDup);
				}
				else
				{
					tc_strdup("NA",&MccApproveDateDup);
					printf("\n MCC Approved Date Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCApprovedBy",&MccApprovedBy));
				if(tc_strlen(MccApprovedBy)>0)
				{
					tc_strdup(MccApprovedBy,&MccApprovedByDup);
					trimwhitespace(MccApprovedByDup);
				}
				else
				{
					tc_strdup("NA",&MccApprovedByDup);
					printf("\n MCC Approved By Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCRejectDate",&MccRejectDate));
				if(tc_strlen(MccRejectDate)>0)
				{
					tc_strdup(MccRejectDate,&MccRejectDateDup);
					trimwhitespace(MccRejectDateDup);
				}
				else
				{
					tc_strdup("NA",&MccRejectDateDup);
					printf("\n MCC Reject Date Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCRejectBy",&MccRejectBy));
				if(tc_strlen(MccRejectBy)>0)
				{
					tc_strdup(MccRejectBy,&MccRejectByDup);
					trimwhitespace(MccRejectByDup);
				}
				else
				{
					tc_strdup("NA",&MccRejectByDup);
					printf("\n MCC Reject By Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_ProductLine",&MccProductLine));
				if(tc_strlen(MccProductLine)>0)
				{
					tc_strdup(MccProductLine,&MccProductLineDup);
					trimwhitespace(MccProductLineDup);
				}
				else
				{
					tc_strdup("NA",&MccProductLineDup);
					printf("\n MCC Product Line Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_AggregateGrp",&MccAggrGrp));
				if(tc_strlen(MccAggrGrp)>0)
				{
					tc_strdup(MccAggrGrp,&MccAggrGrpDup);
					trimwhitespace(MccAggrGrpDup);
					STRNG_replace_str(MccAggrGrpDup," ","_",&MccAggrGrpDup);
					STRNG_replace_str(MccAggrGrpDup,"&","_AND_",&MccAggrGrpDup);
				}
				else
				{
					tc_strdup("NA",&MccAggrGrpDup);
					printf("\n MCC Aggregate Group Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_NwTmlPtNo",&MccTmlPartNo));
				if(tc_strlen(MccTmlPartNo)>0)
				{
					tc_strdup(MccTmlPartNo,&MccTmlPartNoDup);
					trimwhitespace(MccTmlPartNoDup);
				}
				else
				{
					tc_strdup("NA",&MccTmlPartNoDup);
					printf("\n MCC TML Part_No Value is NULL..!!");fflush(stdout);
				}
				/* @@@@@@@@@@@@@@@ NPR Checklist Object Data Start @@@@@@@@@@@@@@@ */
				ITK_CALL(GRM_find_relation_type("IMAN_reference", &refrelation_type));
				ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i],refrelation_type,&refcnt,&refnprchklist));
				if(refcnt>0)
				{
					int checklistcnt = 0;
					tag_t	checkListObj = NULLTAG;
					char * CheckListType = NULL;
					for(checklistcnt=0;checklistcnt<refcnt;checklistcnt++)
					{
						checkListObj = refnprchklist[checklistcnt];
						ITK_CALL(AOM_UIF_ask_value(checkListObj,"object_type",&CheckListType));
						if(tc_strcmp(CheckListType,"New Part Request CheckList")==0)
						{
							break;
						}
					}
					if((checkListObj!=NULLTAG) && (tc_strcmp(CheckListType,"New Part Request CheckList")==0))
					{
						ITK_CALL(AOM_UIF_ask_value(checkListObj,"t5_VCNumber",&NewVCNumber));
						if(tc_strlen(NewVCNumber)>0)
						{
							tc_strdup(NewVCNumber,&NewVCNumberDup);
							trimwhitespace(NewVCNumberDup);
							printf("\n New VC Number Value After Dup & Trim: --------> <%s>", NewVCNumberDup);fflush(stdout);
							STRNG_replace_str(NewVCNumberDup,","," ",&NewVCNumberDup);
							STRNG_replace_str(NewVCNumberDup,";"," ",&NewVCNumberDup);
							STRNG_replace_str(NewVCNumberDup,"\n"," ",&NewVCNumberDup);
							STRNG_replace_str(NewVCNumberDup,"'"," ",&NewVCNumberDup);
							STRNG_replace_str(NewVCNumberDup,"&","_AND_",&NewVCNumberDup);
							printf("\n New VC Number Final Value: --------> [%s]\n", NewVCNumberDup);fflush(stdout);
						}
						else
						{
							tc_strdup("NA",&NewVCNumberDup);
							printf("\n New VC Number Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(checkListObj,"t5_VCDesc",&NewVCDesc));
						if(tc_strlen(NewVCDesc)>0)
						{
							tc_strdup(NewVCDesc,&NewVCDescDup);
							trimwhitespace(NewVCDescDup);
							printf("\n New VC Description Value After Dup & Trim: --------> <%s>", NewVCDescDup);fflush(stdout);
							STRNG_replace_str(NewVCDescDup,","," ",&NewVCDescDup);
							STRNG_replace_str(NewVCDescDup,";"," ",&NewVCDescDup);
							STRNG_replace_str(NewVCDescDup,"\n"," ",&NewVCDescDup);
							STRNG_replace_str(NewVCDescDup,"'"," ",&NewVCDescDup);
							STRNG_replace_str(NewVCDescDup,"&","_AND_",&NewVCDescDup);
							printf("\n New VC Description Final Value: --------> [%s]\n", NewVCDescDup);fflush(stdout);
						}
						else
						{
							tc_strdup("NA",&NewVCDescDup);
							printf("\n New VC Description Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(checkListObj,"t5_BaseVCNum",&BaseVCNumber));
						if(tc_strlen(BaseVCNumber)>0)
						{
							tc_strdup(BaseVCNumber,&BaseVCNumberDup);
							trimwhitespace(BaseVCNumberDup);
							printf("\n Base VC Number Value After Dup & Trim: --------> <%s>", BaseVCNumberDup);fflush(stdout);
							STRNG_replace_str(BaseVCNumberDup,","," ",&BaseVCNumberDup);
							STRNG_replace_str(BaseVCNumberDup,";"," ",&BaseVCNumberDup);
							STRNG_replace_str(BaseVCNumberDup,"\n"," ",&BaseVCNumberDup);
							STRNG_replace_str(BaseVCNumberDup,"'"," ",&BaseVCNumberDup);
							STRNG_replace_str(BaseVCNumberDup,"&","_AND_",&BaseVCNumberDup);
							printf("\n Base VC Number Final Value: --------> [%s]\n", BaseVCNumberDup);fflush(stdout);
						}
						else
						{
							tc_strdup("NA",&BaseVCNumberDup);
							printf("\n Base VC Number Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(checkListObj,"t5_BaseVCDesc",&BaseVCDesc));
						if(tc_strlen(BaseVCDesc)>0)
						{
							tc_strdup(BaseVCDesc,&BaseVCDescDup);
							trimwhitespace(BaseVCDescDup);
							printf("\n Base VC Description Value After Dup & Trim: --------> <%s>", BaseVCDescDup);fflush(stdout);
							STRNG_replace_str(BaseVCDescDup,","," ",&BaseVCDescDup);
							STRNG_replace_str(BaseVCDescDup,";"," ",&BaseVCDescDup);
							STRNG_replace_str(BaseVCDescDup,"\n"," ",&BaseVCDescDup);
							STRNG_replace_str(BaseVCDescDup,"'"," ",&BaseVCDescDup);
							STRNG_replace_str(BaseVCDescDup,"&","_AND_",&BaseVCDescDup);
							printf("\n Base VC Description Final Value: --------> [%s]\n", BaseVCDescDup);fflush(stdout);
						}
						else
						{
							tc_strdup("NA",&BaseVCDescDup);
							printf("\n Base VC Description Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(checkListObj,"t5_BaseSubModule",&BaseSubModNumber));
						if(tc_strlen(BaseSubModNumber)>0)
						{
							tc_strdup(BaseSubModNumber,&BaseSubModNumberDup);
							trimwhitespace(BaseSubModNumberDup);
							printf("\n Base SubModule Number Value After Dup & Trim: --------> <%s>", BaseSubModNumberDup);fflush(stdout);
							STRNG_replace_str(BaseSubModNumberDup,","," ",&BaseSubModNumberDup);
							STRNG_replace_str(BaseSubModNumberDup,";"," ",&BaseSubModNumberDup);
							STRNG_replace_str(BaseSubModNumberDup,"\n"," ",&BaseSubModNumberDup);
							STRNG_replace_str(BaseSubModNumberDup,"'"," ",&BaseSubModNumberDup);
							STRNG_replace_str(BaseSubModNumberDup,"&","_AND_",&BaseSubModNumberDup);
							printf("\n Base SubModule Number Final Value: --------> [%s]\n", BaseSubModNumberDup);fflush(stdout);
						}
						else
						{
							tc_strdup("NA",&BaseSubModNumberDup);
							printf("\n Base SubModule Number Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(checkListObj,"t5_SubModDes",&BaseSubModDesc));
						if(tc_strlen(BaseSubModDesc)>0)
						{
							tc_strdup(BaseSubModDesc,&BaseSubModDescDup);
							trimwhitespace(BaseSubModDescDup);
							printf("\n Base SubModule Description Value After Dup & Trim: --------> <%s>", BaseSubModDescDup);fflush(stdout);
							STRNG_replace_str(BaseSubModDescDup,","," ",&BaseSubModDescDup);
							STRNG_replace_str(BaseSubModDescDup,";"," ",&BaseSubModDescDup);
							STRNG_replace_str(BaseSubModDescDup,"\n"," ",&BaseSubModDescDup);
							STRNG_replace_str(BaseSubModDescDup,"'"," ",&BaseSubModDescDup);
							STRNG_replace_str(BaseSubModDescDup,"&","_AND_",&BaseSubModDescDup);
							printf("\n Base VC Description Final Value: --------> [%s]\n", BaseSubModDescDup);fflush(stdout);
						}
						else
						{
							tc_strdup("NA",&BaseSubModDescDup);
							printf("\n Base SubModule Description Value is NULL..!!");fflush(stdout);
						}
						
					}
					else
					{
						tc_strdup("NA",&NewVCNumberDup);
						tc_strdup("NA",&NewVCDescDup);
						tc_strdup("NA",&BaseVCNumberDup);
						tc_strdup("NA",&BaseVCDescDup);
						tc_strdup("NA",&BaseSubModNumberDup);
						tc_strdup("NA",&BaseSubModDescDup);
					}
				}
				else
				{
					tc_strdup("NA",&NewVCNumberDup);
					tc_strdup("NA",&NewVCDescDup);
					tc_strdup("NA",&BaseVCNumberDup);
					tc_strdup("NA",&BaseVCDescDup);
					tc_strdup("NA",&BaseSubModNumberDup);
					tc_strdup("NA",&BaseSubModDescDup);
				}
				/* @@@@@@@@@@@@@@@ NPR Checklist Object Data End @@@@@@@@@@@@@@@ */
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_ModuleAddress",&MccNPRModAddress));
				if(tc_strlen(MccNPRModAddress)>0)
				{
					tc_strdup(MccNPRModAddress,&MccNPRModAddressDup);
					trimwhitespace(MccNPRModAddressDup);
				}
				else
				{
					tc_strdup("NA",&MccNPRModAddressDup);
					printf("\n MCC NPR Module Address Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_IBDomestic",&IBDomestic));
				if(tc_strlen(IBDomestic)>0)
				{
					tc_strdup(IBDomestic,&IBDomesticDup);
					trimwhitespace(IBDomesticDup);
				}
				else
				{
					tc_strdup("NA",&IBDomesticDup);
					printf("\n MCC NPR IB/Domestic Value is NULL..!!");fflush(stdout);
				}
				/* ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_NwRaisedBy",&COCDesg));
				if(tc_strlen(COCDesg)>0)
				{
					tc_strdup(COCDesg,&COCDesgDup);
					trimwhitespace(COCDesgDup);
				}
				else
				{
					tc_strdup("NA",&COCDesgDup);
					printf("\n COC Designer Value is NULL..!!");fflush(stdout);
				} */
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"owning_user",&COCDesg));
				if(tc_strlen(COCDesg)>0)
				{
					tc_strdup(COCDesg,&COCDesgDup);
					trimwhitespace(COCDesgDup);
				}
				else
				{
					tc_strdup("NA",&COCDesgDup);
					printf("\n COC Designer Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCFinalComment",&MccRemark));
				if(tc_strlen(MccRemark)>0)
				{
					tc_strdup(MccRemark,&MccRemarkDup);
					trimwhitespace(MccRemarkDup);
					printf("\n MCC Remarks Value After Dup & Trim: --------> <%s>", MccRemarkDup);fflush(stdout);
					STRNG_replace_str(MccRemarkDup,","," ",&MccRemarkDup);
					STRNG_replace_str(MccRemarkDup,";"," ",&MccRemarkDup);
					STRNG_replace_str(MccRemarkDup,"\n"," ",&MccRemarkDup);
					STRNG_replace_str(MccRemarkDup,"'"," ",&MccRemarkDup);
					STRNG_replace_str(MccRemarkDup,"&","_AND_",&MccRemarkDup);
					remove_chars(MccRemarkDup, chars_to_remove);
					printf("\n MCC Remarks Final Value: --------> [%s]\n", MccRemarkDup);fflush(stdout);
				}
				else
				{
					tc_strdup("NA",&MccRemarkDup);
					printf("\n MCC Remarks Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"t5_MCCapproveRejectComment",&MccReason));
				if(tc_strlen(MccReason)>0)
				{
					tc_strdup(MccReason,&MccReasonDup);
					trimwhitespace(MccReasonDup);
					printf("\n MCC Reason Value After Dup & Trim: --------> <%s>", MccReasonDup);fflush(stdout);
					STRNG_replace_str(MccReasonDup,","," ",&MccReasonDup);
					STRNG_replace_str(MccReasonDup,";"," ",&MccReasonDup);
					STRNG_replace_str(MccReasonDup,"\n"," ",&MccReasonDup);
					STRNG_replace_str(MccReasonDup,"'"," ",&MccReasonDup);
					STRNG_replace_str(MccReasonDup,"&","_AND_",&MccReasonDup);
					remove_chars(MccReasonDup, chars_to_remove);
					printf("\n MCC Reason Final Value: --------> [%s]\n", MccReasonDup);fflush(stdout);
				}
				else
				{
					tc_strdup("NA",&MccReasonDup);
					printf("\n MCC Reason Value is NULL..!!");fflush(stdout);
				}
				
				if(tc_strcmp(MccStatusvalueDup,"WIP")==0)
				{
					if((tc_strlen(MccStartDateDup) > 0) && (tc_strcmp(MccStartDateDup,"NA") !=0) && (tc_strcmp(MccCompleteDateDup,"NA") ==0))
					{
						printf("\n Case2: MCC Start Date(t5_MCCStartDate) - Not_Blank &&  MCC Status(t5_MCCStatus) - WIP  ----> Pending..!!\n");fflush(stdout);
						/* @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@ */
						int NPRPendingAge = 0;
					    char NPRPendingAgeStr[20];
						NPRPendingAge = TC_DaysCount(MccStartDateDup,"NA");
						sprintf(NPRPendingAgeStr, "%d", NPRPendingAge);
						printf("\n Ageing in String: [%s]\n",NPRPendingAgeStr);fflush(stdout);					
					    /* @@@@@@@@@@@@@@@  Weekdays calculation logic end @@@@@@@@@@@@@@@@ */
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,MccProductLineDup,MccAggrGrpDup,"MCC_Review_Team",MccStartDateDup,NewGenDate,NPRPendingAgeStr,"Pending",MccTmlPartNoDup,NewVCNumberDup,NewVCDescDup,BaseVCNumberDup,BaseVCDescDup,BaseSubModNumberDup,BaseSubModDescDup,MccNPRModAddressDup,IBDomesticDup,COCDesgDup,MccRemarkDup,MccReasonDup);fflush(fpOutput_file);
					}
					else
					{
						printf("\n Case1: MCC Start Date(t5_MCCStartDate) - Blank  &&  MCC Status(t5_MCCStatus) - WIP  ----> Ignore..!!\n");fflush(stdout);
					}
				}
				else if((tc_strcmp(MccStatusvalueDup,"Aggreed")==0) || (tc_strcmp(MccAppRejStatusDup,"Approved")==0))
				{
					if((tc_strlen(MccStartDateDup) > 0) && (tc_strcmp(MccStartDateDup,"NA") !=0) && (tc_strlen(MccApproveDateDup) > 0) && (tc_strcmp(MccApproveDateDup,"NA") !=0))
					{
					  printf("\n Case3: MCC Start Date(t5_MCCStartDate) - Not_Blank &&  MCC Complete Date(t5_MCCCompleteDate) - Not_Blank && MCC Status(t5_MCCStatus) - Aggreed  ----> Approve..!!\n");fflush(stdout);
					    /* @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@ */
						int NPRApproveAge = 0;
					    char NPRApproveAgeStr[20];
						NPRApproveAge = TC_DaysCount(MccStartDateDup,MccApproveDateDup);
						sprintf(NPRApproveAgeStr, "%d", NPRApproveAge);
						printf("\n Ageing in String: [%s]\n",NPRApproveAgeStr);fflush(stdout);					
					    /* @@@@@@@@@@@@@@@  Weekdays calculation logic end @@@@@@@@@@@@@@@@ */
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,MccProductLineDup,MccAggrGrpDup,MccApprovedByDup,MccStartDateDup,MccApproveDateDup,NPRApproveAgeStr,"Approved",MccTmlPartNoDup,NewVCNumberDup,NewVCDescDup,BaseVCNumberDup,BaseVCDescDup,BaseSubModNumberDup,BaseSubModDescDup,MccNPRModAddressDup,IBDomesticDup,COCDesgDup,MccRemarkDup,MccReasonDup);fflush(fpOutput_file);
					}
					else
					{
						printf("\n Else Part in Case3..!!");fflush(stdout);
					}
				}
				else if((tc_strcmp(MccStatusvalueDup,"Dropped")==0) || (tc_strcmp(MccAppRejStatusDup,"Reject")==0))
				{
					if((tc_strlen(MccStartDateDup) > 0) && (tc_strcmp(MccStartDateDup,"NA") !=0) && (tc_strlen(MccRejectDateDup) > 0) && (tc_strcmp(MccRejectDateDup,"NA") !=0))
					{
					  printf("\n Case4: MCC Start Date(t5_MCCStartDate) - Not_Blank &&  MCC Reject Date(t5_MCCRejectDate) - Not_Blank && MCC Status(t5_MCCStatus) - Dropped  ----> Reject..!!\n");fflush(stdout);
					  /* @@@@@@@@@@@@@ Weekdays calculation logic start @@@@@@@@@@@@@@ */
						int NPRRejectAge = 0;
					    char NPRRejectAgeStr[20];
						NPRRejectAge = TC_DaysCount(MccStartDateDup,MccRejectDateDup);
						sprintf(NPRRejectAgeStr, "%d", NPRRejectAge);
						printf("\n Ageing in String: [%s]\n",NPRRejectAgeStr);fflush(stdout);					
					    /* @@@@@@@@@@@@@@@  Weekdays calculation logic end @@@@@@@@@@@@@@@@ */
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,MccProductLineDup,MccAggrGrpDup,MccRejectByDup,MccStartDateDup,MccRejectDateDup,NPRRejectAgeStr,"Reject",MccTmlPartNoDup,NewVCNumberDup,NewVCDescDup,BaseVCNumberDup,BaseVCDescDup,BaseSubModNumberDup,BaseSubModDescDup,MccNPRModAddressDup,IBDomesticDup,COCDesgDup,MccRemarkDup,MccReasonDup);fflush(fpOutput_file);
					}
					else
					{
						printf("\n Else Part in Case4..!!");fflush(stdout);
					}
				}
			}			
		}
	}
	//fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_exit_module(TRUE);
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_New_NPR_Dashboard_Data.c
* // ./linkitk -o tm_New_NPR_Dashboard_Data tm_New_NPR_Dashboard_Data.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/New_NPR_Dashboard_Data/tm_New_NPR_Dashboard_Data .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/New_NPR_Dashboard_Data/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/New_NPR_Dashboard_Data/usage.txt .
* // ./tm_New_NPR_Dashboard_Data -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_New_NPR_Dashboard_Data -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/