/user/cvprod/sourav/New_NPR_Dashboard_Data/tm_New_NPR_Dashboard_Data -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -F=07-Apr-2024 -T=08-Aug-2025
