./compile tm_productlineupdate.c
./linkitk -o tm_productlineupdate tm_productlineupdate.o
chmod 777 tm_productlineupdate*
