	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int tm_ECUNewSnapshot(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = tm_ECUNewSnapshot(dmlNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int tm_ECUNewSnapshot(char* dmlNo)
{
	int ifail = ITK_ok;
	tag_t priObjTag			= NULLTAG;
	tag_t priObjTypeTag		= NULLTAG;
	tag_t *attachments		= NULLTAG;
	tag_t DMLTaskTag		= NULLTAG;
	tag_t user_tag			= NULLTAG;
	tag_t rootTask			= NULLTAG;
	tag_t DMLRevTag			= NULLTAG;
	char *CurrentTask		= NULL;
	char * parent_name		= NULL;
	char *username			= NULL;
	char *taskTempLT		= NULL;
	char *dmlTaskNo			= NULL;
	char *type_name1        = NULL;
	char* Rel_type			= NULL;
//	char *DMLNo				= NULL;
	tag_t DML_tag			= NULLTAG;
	tag_t *Pendingtasks		= NULLTAG;
	int   noAttachment      = 0;
	int   Pncount			= 0;

	char	 *DML_item				 = NULL;
	char	 *PartNo				 = NULL;
	char	 *RevIDNo				 = NULL;
	char	 *Mod_no				 = NULL;
	char	 *ModRevNo				 = NULL;
	char	 *ModNo1				 = NULL;
	char	 *ModNo2				 = NULL;
	char	 *CCIDNo1				 = NULL;
	char	 *CCIDNo2				 = NULL;
	char*	 jobName= NULL;;
	char*	 CCIDNo= NULL;;
	char*	 PartNumber= NULL;;
	char*	 MPartNumber= NULL;;
	char*	 NewModule= NULL;;
	char*	 SnapshotNo= NULL;;
	char*	 NewCCID= NULL;;
	char*	 ModTok= NULL;;
	char*	 ModNo= NULL;;

	tag_t	 snapshot			  = NULLTAG;
	tag_t	 SnapshotRelationType = NULLTAG;
	//tag_t	 HasRefCCIDRelType    = NULLTAG;
	tag_t	 HasNewCCIDRelTypeX   = NULLTAG;
	tag_t	 IsMemberOfCCID   = NULLTAG;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t	 CCVCHasECUModuleTag  = NULLTAG;
	tag_t	 HasNewCCIDRelType    = NULLTAG;
	tag_t	 Rel_task			  = NULLTAG;

	tag_t *VCObjSO				 = NULLTAG;

	char *DMLprojcode				 = NULL;
	tag_t	ProQryContObj			 = NULLTAG;
	char	*info1					 = NULL;
	char	*info2					 = NULL;
	char	*info3					 = NULL;
	char	*info4					 = NULL;
	char	*info5					 = NULL;
	char	*info6					 = NULL;
	char	*info7					 = NULL;
	char	*info8					 = NULL;
	char	*info9					 = NULL;
	char	*info10					 = NULL;

	tag_t *ProjCnObj				 = NULL;
	int		n_Input					 = 2;
	int    ProjCount				 = 0;
	int    CheckFlag				 = 0;
	char	*qry_Input[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_ProjVal[2] = {"CCID", "PROJCT"};

	//int		ifail;
	int		status;
	int		cnt;
	tag_t    DesignrevTag		  = NULLTAG;
	//tag_t    FinalModuleTag		  = NULLTAG;
	//tag_t    Latestrev			  = NULLTAG;
	tag_t	 top_line;
	tag_t	*children;
	tag_t	 window;

	char	**SSDetails	         = NULL;

	int   n_tags_found	  = 0;
	int   n_rev			  = 0;
	char*  partno         = NULL;
	char*  partno1        = NULL;
	char*  PartType       = NULL;
	char*  MPartType      = NULL;
	char*  MPartNo        = NULL;
	//char*  MPartNumber        = NULL;
	char*  SSRead         = NULL;
	char*  MRevIDNo       = NULL;
	char*  NewMRevIDNo    = NULL;
	char*  ModuleNo       = NULL;
	tag_t DMLToTaskRel    = NULLTAG;
	tag_t *PartsTag		  = NULLTAG;
	int   tsk_cnt		  = 0;
	int   p				  = 0;
	int   t				  = 0;
	int   ss			  = 0;
	int   sr			  = 0;
	int   partcnt		  = 0;
	int   *levels		  = 0;
	int   SSDetRead		  = 0;
	int   CCIDcnt		  = 0;
	int   cc			  = 0;
	int   vc			  = 0;
	int   VCCnt			  = 0;

	tag_t *Tsk_objects    = NULLTAG;
	char* Taskobject_type = NULL;
	char* ReleaseType	  = NULL;
	char* MReleaseType	  = NULL;
	char* NewModuleNum	  = NULL;
	char* NewModulerev	  = NULL;
	char*	CCIDPartNo	  = NULL;
	char*	Cciditem_rev  = NULL;
	//char*	CcidSeq		  = NULL; removed
	char*	NewCCIDNum	  = NULL;
	char*	NewCCIDRem	  = NULL;
	char*	VCnum		  = NULL;
	char* ModPartType     = NULL; //Adi latest 99

	tag_t 	part_tsk_rel  = NULLTAG;
	tag_t 	ModuleTag	  = NULLTAG;
	tag_t 	CCIDRevTag	  = NULLTAG;
	tag_t 	VCTag		  = NULLTAG;
	tag_t 	RevRuleTag	  = NULLTAG;

	int     iWrite		  = 0;
	int		n_parents     = 0;
	tag_t   *parents		= NULL;
	tag_t   CcidMstr		= NULLTAG;
	tag_t   Cciditem		= NULLTAG;
	tag_t   CCIDRefRel_task = NULLTAG;

	tag_t  *CCIDattachments	= NULLTAG;
	tag_t   object_create_input_tag		= NULLTAG;
	tag_t   CCIDdata_type_tag			= NULLTAG;
	tag_t	CCIDItemtag		= NULLTAG;
	tag_t	latest_Cciditem	= NULLTAG;
	tag_t	NewModuleTag	= NULLTAG;
	tag_t	item_tag		= NULLTAG;
	tag_t	Mod_tag			= NULLTAG;
	//int		n_tags_found	= 0;
	tag_t	*tags_found		= NULL;

	int		id_count	= 0;
	int		icnt	= 0;
	char	**rev_seq	= NULL;

	tag_t	IsMemberOfCCIDx			 = NULLTAG;
	tag_t	ReferencesCCVTag		 = NULLTAG;
	tag_t	IsMemberOfCCID_Rel		 = NULLTAG;
	tag_t	ReferencesCCV_Rel		 = NULLTAG;
	tag_t*	attccidTag		 = NULLTAG;
	tag_t*	attccidTagMem		 = NULLTAG;


	tag_t 	CCIDMastRevTag	  = NULLTAG; //new Adi
	int		CcidSeq     = 0; //new Adi
	int		attccidcnt     = 0; //new Adi
	int		attccidcntMem     = 0; //new Adi
	char cidsequence[10]; //new Adi
	//char cidsequence[10]; //new Adi

	tag_t	sn_rule		 = NULLTAG; //NEW 9 JULY

	SSDetails = (char**)MEM_alloc( 1 * sizeof *SSDetails );

	char cCurrentAccessDate[20]={0};

	/**********JULY 30************/
	tag_t	*snapObj		  = NULLTAG;
	int		SnapshotCount     = 0;
	//char	*qry_Input1[1]	  = {"object_name"}; //Adi AUGUST
	char	*qry_Input1[1]	  = {"Name"};  //Adi AUGUST
	char	*values1[1];
	int		n_Input1					 = 1;
	tag_t	ProQrySSObj			= NULLTAG;
	/**********JULY 30************/

		
			int		count1			=0;
			tag_t	item_tag1		= NULLTAG;
			tag_t	*rev_list		= NULL;

	
		ITK_CALL(POM_get_user_id (&username));//JULY 28
		printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);//JULY 28

		//CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		//printf("\n tm_ECUNewSnapshot...");fflush(stdout);

		//CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		//printf("\n tm_ECUNewSnapshot CurrentTask: %s",CurrentTask);fflush(stdout);

		//CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		//printf("\n tm_ECUNewSnapshot Parent Name: %s",parent_name);fflush(stdout);

		getCurrentDateTime(cCurrentAccessDate);
		printf("\n tm_ECUNewSnapshot cCurrentAccessDate : %s",cCurrentAccessDate);fflush(stdout);

		//if(strcmp(parent_name,"ECU_SnapShot")==0)
		//if(strcmp(parent_name,"ERC Task Workflow")==0)
		//(strcmp(parent_name,"VI Review(DMU & BOM Analyst Review)")==0)
		// {
		//CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		//printf("\n tm_ECUNewSnapshot Target Attachment:%d",noAttachment);fflush(stdout);

		ifail = ITEM_find_item (dmlNo, &item_tag1);
		CHECK_FAIL;
		ifail = ITEM_list_all_revs (item_tag1, &count1, &rev_list);
		CHECK_FAIL;

		if(count1 > 0)
		{
			DMLTaskTag = rev_list[0];

			if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
			printf("\n tm_ECUNewSnapshot dmlTaskNo: [%s]", dmlTaskNo);fflush(stdout); //getting dml number here

			//if (tc_strstr(dmlTaskNo,"_") != NULL)
			//{
			//	DMLNo=strtok(dmlTaskNo,"_");
			//	printf("\n tm_ECUNewSnapshot DMLNo =====> [%s]", DMLNo);fflush(stdout);
			//}
			//if(ITEM_find_item(DMLNo, &DML_tag)!=ITK_ok)PrintErrorStack();
			if(ITEM_find_item(dmlTaskNo, &DML_tag)!=ITK_ok)PrintErrorStack();

			if (DML_tag != NULLTAG)
			{
				if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
				printf(" tm_ECUNewSnapshot DML Rel_type: [%s]", Rel_type);fflush(stdout);

				if((tc_strcmp(Rel_type,"ECU Parts Release")==0)||(tc_strcmp(Rel_type,"EP")==0))
				{
					if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DMLprojcode)==ITK_ok) PrintErrorStack();
					if(tc_strlen(DMLprojcode)>0)
					{
						printf("\nRevision Project Code [%s]",DMLprojcode);fflush(stdout);

						if(QRY_find2("ControlObjQry", &ProQryContObj));
						if(ProQryContObj)
						{
							if(QRY_execute(ProQryContObj, n_Input, qry_Input, qry_ProjVal, &ProjCount, &ProjCnObj));
							printf("\n CONT Objects for CCID == %d", ProjCount);fflush(stdout);
						}
						else
						{
							printf("\n ContrlObj not found for CCID");fflush(stdout);
						}

						if(ProjCount >0)
						{
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo3",&info3)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo4",&info4)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo5",&info5)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo6",&info6)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo7",&info7)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo8",&info8)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo9",&info9)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_userinfo10",&info10)!=ITK_ok) PrintErrorStack();

							printf("\n CCID Project Codes List [%s]",info1); fflush(stdout);

							if(tc_strstr(info1,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info2,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info3,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info4,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info5,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info6,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info7,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info8,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info9,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info10,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
						}
					}
					if(CheckFlag==1)
					{
						//ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
						//ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects));

						//printf("\n  Task count is : %d",tsk_cnt);fflush(stdout);
						//if (tsk_cnt>0)
						//{
						//for (t=0;t<tsk_cnt ;t++ )
						//{
						//ITK_CALL(AOM_ask_value_string(Tsk_objects[t],"object_type",&Taskobject_type));
						////printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);
						//if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
						//{
						////printf("\n inside T5_ChangeTaskRevision :\n");fflush(stdout);
						//ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
						//if (part_tsk_rel!=NULLTAG)
						//{
						//}
						//}
						//}
						//}
						//////start
						ITK_CALL(GRM_find_relation_type("T5_HasNewCCID",&HasNewCCIDRelTypeX));
						printf("\n after finding HasNewCCIDRelTypeX \n");fflush(stdout);

						ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag, HasNewCCIDRelTypeX, &attccidcnt, &attccidTag));
						printf("\n  attccidcnt.:%d\n",attccidcnt);fflush(stdout);

						for (icnt=0;icnt<attccidcnt;icnt++)
						{
							latest_Cciditem=attccidTag[icnt];

							if(latest_Cciditem)
							{
								printf("\n tm_ECUNewSnapshot CCID after GRM_save_relation--------->\n");fflush(stdout);

								if(AOM_ask_value_string(latest_Cciditem,"item_id",&CCIDNo)==ITK_ok);
								printf("\n  CCIDNo.:%s\n",CCIDNo);fflush(stdout);

								if(AOM_ask_value_string(latest_Cciditem,"item_revision_id",&Cciditem_rev)!=ITK_ok)PrintErrorStack();
								printf("\n tm_ECUNewSnapshot Cciditem_rev IS --------->[%s]\n",Cciditem_rev);fflush(stdout);

								ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&IsMemberOfCCID));
								printf("\n after finding IsMemberOfCCID \n");fflush(stdout);

								ITK_CALL(GRM_list_primary_objects_only(latest_Cciditem, IsMemberOfCCID, &attccidcntMem, &attccidTagMem));
								printf("\n  attccidcntMem.:%d\n",attccidcntMem);fflush(stdout);

								//create snapshot and attach to CCID in relation T5_CCIDHasSnapshot
								if (attccidcntMem>0)
								{
									Mod_tag=attccidTagMem[0];
									ifail = BOM_create_window (&window);
									CHECK_FAIL;

									//ITK_CALL(CFM_find("ERC Review And Above", &sn_rule ));	//NEW 9 JULY 2020
									ITK_CALL(CFM_find("ERC release and above", &sn_rule ));	//NEW 9 JULY 2020

									ITK_CALL(BOM_set_window_config_rule( window, sn_rule )); //NEW 9 JULY 2020

									ifail = BOM_set_window_top_line (window, null_tag, Mod_tag, null_tag, &top_line);
									CHECK_FAIL;

									ifail = BOM_window_show_suppressed (window);
									CHECK_FAIL;

									ITK_CALL(BOM_set_window_pack_all(window, FALSE));

									ITK_CALL(EPM__parse_string(Cciditem_rev, ";", &id_count, &rev_seq));//removed

									if(top_line!=NULLTAG)
									{
										printf("\n tm_ECUNewSnapshot inside top line ECU:\n");fflush(stdout);

										SnapshotNo	=NULL;
										SnapshotNo=(char *) MEM_alloc(30);

										tc_strcpy(SnapshotNo,CCIDNo);
										tc_strcat(SnapshotNo,"_");
										tc_strcat(SnapshotNo,rev_seq[0]);
										tc_strcat(SnapshotNo,"_");
										tc_strcat(SnapshotNo,rev_seq[1]);

										printf("\n tm_ECUNewSnapshot SnapshotNo is ------->[%s]\n",SnapshotNo);fflush(stdout);
										if(SnapshotNo)	/**********JULY 30************/
										{
											values1[0] = SnapshotNo;
											//values[1] = "ERC DML Revision";

											if(QRY_find2("SnapShot", &ProQrySSObj));//PRODUCTION
											if(ProQrySSObj)
											{
												if(QRY_execute(ProQrySSObj, n_Input1, qry_Input1, values1, &SnapshotCount, &snapObj));
												printf("\n qUERY for SnapshotCount count== %d", SnapshotCount);fflush(stdout);
												//}//Adi AUGUST

												if (SnapshotCount == 0)
												{
													printf ("\n XXXXXXX SnapshotNoCount  =0 hence creating snapshot %s\n", SnapshotNo); fflush(stdout);

													if(BOM_create_snapshot(window,SnapshotNo,"Snapshot for ECU",&snapshot));

													if(snapshot!=NULLTAG)
													{
														if(AOM_lock(snapshot))
														printf("\n after snapshot creation :\n");fflush(stdout);
														if(AOM_save( snapshot))
														if(AOM_refresh(snapshot,1));
														if(AOM_unlock(snapshot));

														printf("\n tm_ECUNewSnapshot snapshot unlocked :\n");fflush(stdout);

														ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
														printf("\n tm_ECUNewSnapshot after finding HasSnapshotType \n");fflush(stdout);

														if(HasSnapshotType!=NULLTAG)
														{
															printf("\n creating relation between ccid and snapshot \n");fflush(stdout);
															if(GRM_create_relation(latest_Cciditem,snapshot,HasSnapshotType,NULLTAG,&Rel_task));
															//if(GRM_create_relation(DesignrevTag,snapshot,SnapshotRelationType,NULLTAG,&Rel_task));
															if(GRM_save_relation (Rel_task));
															ITK_CALL(AOM_refresh(latest_Cciditem,1));
															ITK_CALL(AOM_save(latest_Cciditem));
															ITK_CALL(AOM_refresh(latest_Cciditem,0));

															//////////////////////////////////////////////9th JULY 2020///////////////////////////////////////////////////

															/*	tag_t	 HasContents			  = NULLTAG;
															tag_t	 HasSolution			  = NULLTAG;
															tag_t	 t_previousRevision_SnChild			  = NULLTAG;
															tag_t	 SNRel_task			  = NULLTAG;
															tag_t	 SnChild			  = NULLTAG;
															tag_t	 SnContentsPart			  = NULLTAG;
															tag_t*	 snapchild				= NULL;
															char *  dmlNoSn =NULL;
															char *  ECUPrtLatestRlzSt_3 =NULL;
															char *  dmlTaskNoSn =NULL;
															char *  PartItemIdSn =NULL;
															char *  PartItemRevIdSn =NULL; //JULY 28
															char *  PartItemRevIdSndup =NULL; //JULY 28
															char *  PartItemRevIdSntok =NULL; //JULY 28
															tag_t * ECU_Rlz_St_list_3=NULL;
															tag_t * attchTasksnObj=NULL;
															int snapcount =0;
															int sn =0;
															int ss6 =0;
															int snA =0;
															int attchTasksn =0;
															int ECU_RlzStatusCnt_3 =0;

															ITK_CALL(GRM_find_relation_type("contents",&HasContents));
															//ITK_CALL(GRM_list_secondary_objects_only(snapshot, HasContents, &snapcount, &snapchild));//removed
															ITK_CALL(AOM_ask_value_tags(snapshot,"contents",&snapcount,&snapchild));//added
															printf("\n  snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);


															ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNoSn));
															printf("\n tm_ECUNewSnapshot dmlTaskNo: [%s]", dmlNoSn);fflush(stdout);
															ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&HasSolution));

															if(snapcount >0)
															{
															for (sn=0;sn<snapcount;sn++)
															{
															SnChild=snapchild[sn];



															if(WSOM_ask_release_status_list(SnChild, &ECU_RlzStatusCnt_3, &ECU_Rlz_St_list_3)!=ITK_ok)PrintErrorStack();
															printf("\t ECU_RlzStatusCnt_3: %d",ECU_RlzStatusCnt_3);	fflush(stdout);

															int ECURlzRevFlag_3=0;
															if (ECU_RlzStatusCnt_3 > 0)
															{
															for(ss6=0; ss6<ECU_RlzStatusCnt_3; ss6++)
															{
															if(AOM_ask_value_string(ECU_Rlz_St_list_3[ss6],"object_name",&ECUPrtLatestRlzSt_3)!=ITK_ok)PrintErrorStack();
															if((tc_strcmp(ECUPrtLatestRlzSt_3,"ERC Released")==0) || (tc_strcmp(ECUPrtLatestRlzSt_3,"T5_LcsErcRlzd")==0))
															{
																printf("\t ECUPrtLatestRlzSt_3: %s ",ECUPrtLatestRlzSt_3);fflush(stdout);
																ECURlzRevFlag_3=1;
																break;
															}
															}
															}

															printf("\t ECUPrtLatestRlzSt_3: %s ",ECUPrtLatestRlzSt_3);fflush(stdout);

															int FlagDmlFound=0;

															if (!ECURlzRevFlag_3)
															{
															ITK_CALL(GRM_list_primary_objects_only(SnChild, HasSolution, &attchTasksn, &attchTasksnObj));
															printf("\n  attccidcntMem.:%d\n",attchTasksn);fflush(stdout);

															if (attchTasksn>0)
															{
															for (snA=0;snA<attchTasksn;snA++)
															{
																if(AOM_ask_value_string(attchTasksnObj[snA],"item_id",&dmlTaskNoSn)!=ITK_ok)PrintErrorStack();
																printf("\n tm_ECUNewSnapshot dmlTaskNo: [%s]", dmlTaskNoSn);fflush(stdout); //getting dml number here

																if (tc_strstr(dmlTaskNoSn,dmlNoSn))
																{
																	FlagDmlFound=1;
																	break;
																}
															}
															}

															if (FlagDmlFound==0)
															{
															if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok)PrintErrorStack();
															printf("\n tm_ECUNewSnapshot previous revision to be found PartItemIdSn: [%s]", PartItemIdSn);fflush(stdout); //getting dml number here

															if(AOM_ask_value_string(SnChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok)PrintErrorStack();//JULY 28
															printf("\n  PartItemRevIdSn iss--------> %s \n", PartItemRevIdSn);fflush(stdout);//JULY 28


															tc_strdup(PartItemRevIdSn,&PartItemRevIdSndup);//JULY 28

															PartItemRevIdSntok = tc_strtok (PartItemRevIdSndup,";");//JULY 28
															printf("\n  PartItemRevIdSntok  is----> [%s]\n",PartItemRevIdSntok);fflush(stdout);//JULY 28


															///******************JULY 28****************/
															/*	if(tc_strcmp(PartItemRevIdSntok,"NR")==0)
															{
																printf("\n  NR found whcih is not attached to DML [%s] \n", PartItemIdSn);fflush(stdout);

																ITK_CALL(AOM_lock(snapshot));
																ITK_CALL(FL_remove(snapshot,SnChild));
																printf("\n  after fl remove AA \n");fflush(stdout);

																ITK_CALL(AOM_save(snapshot));

																ITK_CALL(AOM_refresh(snapshot,0));

																ITK_CALL(AOM_unlock(snapshot));

																printf("\n  Relation OF nr part deleted in Snapshot\n");fflush(stdout);*/

															/*	} ///******************JULY 28******************/
															/*	else
															{

															tm_find_Prev_Official_Rev(PartItemIdSn,SnChild, &t_previousRevision_SnChild);

															if (t_previousRevision_SnChild)
															{
																printf("\n  previous released found Snapshot %s \n", PartItemIdSn);fflush(stdout);
																//ITK_CALL(GRM_find_relation(snapshot,SnChild,HasContents,&SnContentsPart)); new removed
																ITK_CALL(AOM_lock(snapshot));
																ITK_CALL(FL_remove(snapshot,SnChild));//new addedb;2
																printf("\n  after fl remove AA \n");fflush(stdout);

																//if (SnContentsPart)new removed
																//{new removed
																	 //ITK_CALL(AOM_load(SnContentsPart));
																	 //ITK_CALL(AOM_delete(SnContentsPart));
																	 //ITK_CALL(GRM_delete_relation(SnContentsPart));new removed
																	 //ITK_CALL(AOM_refresh(snapshot,1));
																	 ITK_CALL(AOM_save(snapshot));
																	 //ITK_CALL(AOM_unlock(snapshot));
																	 ITK_CALL(AOM_refresh(snapshot,0));

																	 ITK_CALL(AOM_unlock(snapshot));

																	 printf("\n  Relation deleted in Snapshot\n");fflush(stdout);

																	 //if(GRM_create_relation(snapshot,t_previousRevision_SnChild,HasContents,NULLTAG,&SNRel_task));

																	 ITK_CALL(AOM_lock(snapshot));

																	 ITK_CALL(FL_insert(snapshot,t_previousRevision_SnChild,999));//new added

																	 //AOM_set_value_tag	(	snapshot,"contents",t_previousRevision_SnChild ) //try this



																	 //if(GRM_save_relation (SNRel_task));//new removed
																	 //ITK_CALL(AOM_refresh(snapshot,1));
																	 ITK_CALL(AOM_save(snapshot));
																	// ITK_CALL(AOM_unlock(snapshot));
																	 ITK_CALL(AOM_refresh(snapshot,0));
																	 ITK_CALL(AOM_unlock(snapshot));

																	 printf("\n  Relation created in Snapshot AA \n");fflush(stdout);


																//}new removed
															}
															}
															}
															}
															}
															}*/
															//////////////////////////////////////////////////////9th JULY 2020///////////////////////////////////////
															printf("\n tm_ECUNewSnapshot SNAPSHOT RELATION CREATED WITH THE DESIGN REV:\n");fflush(stdout);
														}
														else
														{
															printf("\n tm_ECUNewSnapshot T5_CCIDHasSnapshot not found \n");fflush(stdout);
														}

													}
													else
													{
														printf("\n tm_ECUNewSnapshot snapshot not created :\n");fflush(stdout);
													}

												}
											}
											else
											{
												printf("\n snapshot query not found\n");fflush(stdout);//Adi AUGUST
											}
										}

									}
									/**********************************JULY 30 **************************************************/
									/*
									tag_t HasContents1 = NULLTAG;
									tag_t HasSolution1 = NULLTAG;
									tag_t Bomline_tag = NULLTAG;
									char *dmlNoSn1 =NULL;
									char *ECUPrtLatestRlzSt_6 =NULL;
									char *dmlTaskNoSn1 =NULL;
									char *Rlz_St_list  =NULL;
									char *PartItemIdSn1 =NULL;
									char *PartItemRevIdSn1 =NULL;
									char *PartItemRevIdSndup1 =NULL;
									char *PartItemRevIdSntok1 =NULL;
									tag_t * ECU_Rlz_St_list_6=NULL;
									tag_t * attchTasksnObj1=NULL;
									//int snapcount =0;
									int ck =0;
									int ss9 =0;
									int snA1 =0;
									int attchTasksn1 =0;
									int nClhd =0;
									int ECU_RlzStatusCnt_6 =0;

									tag_t  *children;
									tag_t Bomline_tagrev = NULLTAG;


									ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNoSn1));
									printf("\n bomline dmlTaskNo: [%s]\n", dmlNoSn1);fflush(stdout);
									ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&HasSolution1));
									printf("\n AFTER HasSolution1 \n");fflush(stdout);

									ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
									printf("\n COUNT nClhd [%d],",nClhd);fflush(stdout);

									for (ck = 0; ck < nClhd; ck++)//bl_rev_release_status_list
									{
									Bomline_tag = children[ck];

									//if(WSOM_ask_release_status_list(Bomline_tag, &ECU_RlzStatusCnt_6, &ECU_Rlz_St_list_6)!=ITK_ok)PrintErrorStack();
									//if(AOM_UIF_ask_value(Bomline_tag, "bl_rev_release_status_list", &ECU_Rlz_St_list_6)!=ITK_ok)PrintErrorStack();
									if(AOM_UIF_ask_value(Bomline_tag, "bl_rev_release_status_list", &Rlz_St_list)!=ITK_ok)PrintErrorStack();
									printf("\n Rel Status: [%s]\n",Rlz_St_list);fflush(stdout);//new

									//printf("\t ECU_RlzStatusCnt_6: %d",ECU_RlzStatusCnt_6);	fflush(stdout);

									int ECURlzRevFlag_6=0;
									//if (ECU_RlzStatusCnt_6 > 0)
									//{
									//	for(ss9=0; ss9<ECU_RlzStatusCnt_6; ss9++)
									//	{
									//		if(AOM_ask_value_string(ECU_Rlz_St_list_6[ss9],"object_name",&ECUPrtLatestRlzSt_6)!=ITK_ok)PrintErrorStack();
									//		if((tc_strcmp(ECUPrtLatestRlzSt_6,"ERC Released")==0) || (tc_strcmp(ECUPrtLatestRlzSt_6,"T5_LcsErcRlzd")==0))
									if((tc_strcmp(Rlz_St_list,"ERC Released")==0) || (tc_strcmp(Rlz_St_list,"T5_LcsErcRlzd")==0))
									{
									printf("\t Rlz_St_list: %s ",Rlz_St_list);fflush(stdout);
									ECURlzRevFlag_6=1;
									break;
									}
									//	}
									//}

									//printf("\t ECUPrtLatestRlzSt_6: %s ",ECUPrtLatestRlzSt_6);fflush(stdout);

									int FlagDmlFound3=0;

									//AOM_ask_value_tag(tag_t object_tag, const char * prop_name, tag_t * value)
									if(AOM_ask_value_tag(Bomline_tag,"mfg0realRevision",&Bomline_tagrev)!=ITK_ok)PrintErrorStack();

									//CALLAPI(AOM_ask_value_tags(Bomline_tag,"T5_DMLTaskRelation",&TaskCnt,&SetOfDmlTasksTag));

									if (!ECURlzRevFlag_6)
									{
									ITK_CALL(GRM_list_primary_objects_only(Bomline_tagrev, HasSolution1, &attchTasksn1, &attchTasksnObj1));
									printf("\n  attccidcntMem11111111111111111111.:%d\n",attchTasksn1);fflush(stdout);

									if (attchTasksn1>0)
									{
									for (snA1=0;snA1<attchTasksn1;snA1++)
									{
									if(AOM_ask_value_string(attchTasksnObj1[snA1],"item_id",&dmlTaskNoSn1)!=ITK_ok)PrintErrorStack();
									printf("\n bomline dmlTaskNo: [%s]", dmlTaskNoSn1);fflush(stdout);

									if (tc_strstr(dmlTaskNoSn1,dmlNoSn1))
									{
									FlagDmlFound3=1;
									break;
									}
									}
									}

									if (FlagDmlFound3==0)
									{
									if(AOM_ask_value_string(Bomline_tag,"bl_item_item_id",&PartItemIdSn1)!=ITK_ok)PrintErrorStack();
									printf("\n bomline previous revision to be found PartItemIdSn1111111111111[%s]", PartItemIdSn1);fflush(stdout);

									if(AOM_ask_value_string(Bomline_tag,"bl_rev_item_revision_id",&PartItemRevIdSn1)!=ITK_ok)PrintErrorStack();
									printf("\n  bomline PartItemRevIdSn iss--------> %s \n", PartItemRevIdSn1);fflush(stdout);

									tc_strdup(PartItemRevIdSn1,&PartItemRevIdSndup1);

									PartItemRevIdSntok1 = tc_strtok (PartItemRevIdSndup1,";");
									printf("\n  PartItemRevIdSntok11111111  is----> [%s]\n",PartItemRevIdSntok1);fflush(stdout);

									if(tc_strcmp(PartItemRevIdSntok1,"NR")==0)
									{
									printf("\n  NR found whICh is not attached to DML [%s] \n", PartItemIdSn1);fflush(stdout);
									ITKCALL(BOM_line_cut(Bomline_tag));
									printf("\n  Relation OF nr part deleted in BOMLINE \n");fflush(stdout);
									}
									}
									}
									}
									ITKCALL(BOM_save_window(window));
									printf("\n  afterrrrr bom save window \n");fflush(stdout);
									ITKCALL(BOM_close_window(window));
									printf("\n  afterrrrr bom CLOSE window \n");fflush(stdout);*/
									/**********************************JULY 30 **************************************************/
								}
							}
						}

					}
					else
					{
						printf ("\n tm_ECUNewSnapshot project not present in control object \n"); fflush(stdout);
					}

				}
				else
				{
					printf ("\n tm_ECUNewSnapshot Rel type is not ECU PARTS REL \n"); fflush(stdout);
				}
			}
		}

	return ifail;
}
