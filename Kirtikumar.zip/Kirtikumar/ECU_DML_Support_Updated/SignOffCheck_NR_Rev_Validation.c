	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int SignOffCheck_NR_Rev_Validation(char*);
char* EE_Part_BOM_Validation_for_NR_Rev(char*,int,tag_t*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = SignOffCheck_NR_Rev_Validation(dmlNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int SignOffCheck_NR_Rev_Validation(char* dmlNo)
{
	int		ifail					= ITK_ok;

	char*	username				= NULL;
	tag_t	root_task				= NULLTAG;
	tag_t	*attachments			= NULLTAG;

	int				i 							= 0;
	int				j 							= 0;
	int				k 							= 0;
	int				l 							= 0;
	int				count1 						= 0;
	int				count 						= 0;
	int				n_attchs 					= 0;
	int				count_status				= 0;
	int				partcnt						= 0;
	int				sequence_id					= 0;
	//int             NR_REV_CHECK				= 0;

	tag_t			item_tag					= NULLTAG;
	tag_t			*status_list				= NULL;
	tag_t			DMLLcmTag					= NULL;
	tag_t			class_id					= NULL;
	tag_t			class_id1					= NULL;
	tag_t			tsk_dml_rel_type			= NULL;
	tag_t			*DMLRevision				= NULL;
	tag_t			*secondary_objects			= NULL;
	tag_t			*PartsTag					= NULL;
	tag_t			objTypeTag					= NULL;


	tag_t			DMLRevTag					= NULLTAG;
	tag_t			relation_type				= NULLTAG;
	tag_t			AssyTag						= NULLTAG;

	char			*status_name				= NULL;

	char			*rev_id						= NULL;
	char			*releaseType				= NULL;
	char			*t5current_name				= NULL;
	char			*s							= NULL;
	char			*class_name					= NULL;
	char			*class_name1				= NULL;
	char		   *projectname					= NULL;
	char		   *DMLNumber					= NULL;
	char		   *taskGrp					    = NULL;
	char		   *current_name				= NULL;
	char		   *t5current_name1				= NULL;
	char		   *object_type					= NULL;
	char		   *Part_no						= NULL;
	char		   *tempPart_no					= NULL;
	char		   type_name[TCTYPE_name_size_c+1];
	char		   *NRRevCheck					= NULL;
	char		   *token						= NULL;

	char		   *childWithNR_ERC_Review			 = NULL;

	//EPM_decision_t decision						= EPM_go;

	childWithNR_ERC_Review						=(char *)MEM_alloc(500);

	tc_strcpy(childWithNR_ERC_Review," ");
	tc_strcat(childWithNR_ERC_Review,"Part No : ");


	char		   *DMLtype						= NULL;
	char		   *DMLNo						= NULL;
	logical		    is_latest;

	tag_t			DMLtag					= NULLTAG;
	tag_t			*DMLRevListTag					= NULLTAG;

	NRRevCheck=(char *)MEM_alloc(300);

	CALLAPI(POM_get_user_id (&username));
	printf("\n\n\t  Session login username :: %s\n",username); fflush(stdout);

	ifail = ITEM_find_item (dmlNo, &DMLtag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (DMLtag, &count1, &DMLRevListTag);
	CHECK_FAIL;	

	if(count1 > 0)
	{
		DMLLcmTag = DMLRevListTag[0];

	}
	ifail = AOM_ask_value_string(DMLLcmTag,"current_id",&t5current_name);
	printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);

	 if ( ifail != ITK_ok)
	 {
		 EMH_ask_error_text( ifail, &s);
		 printf("Error with AOM_ask_value_string : %s \n",s);
		 MEM_free(s);
		 return ifail;
	 }

	 ifail = POM_class_of_instance(DMLLcmTag,&class_id);
	 ifail = POM_name_of_class(class_id,&class_name);
	 printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout);

	 if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
	 {
			ifail = GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
			if (tsk_dml_rel_type!=NULLTAG)
			{
				ifail = GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count,&DMLRevision);
				printf("\n\n\t\t ***********DML Revision from Task **********: %d",count);fflush(stdout);
				for (i=0;i<count ;i++ )
				{
					ifail = ITEM_rev_sequence_is_latest(DMLRevision[i],&is_latest);
					printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
					if(is_latest != true)
					{
						printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);

					} 
					else
					{
						DMLRevTag = DMLRevision[i];

						ifail = AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname);
						printf("\n\n\t\t Projectname from leftObject : %s\n",projectname);fflush(stdout);

						printf("\n\n\t\t is_latest is  true .....\n");fflush(stdout);
						ifail = AOM_ask_value_string(DMLRevTag,"current_name",&current_name);
						printf("\n\n\t\t current_name is :%s\n",current_name);fflush(stdout);

						DMLNumber = strtok( current_name, "_" );
						taskGrp	  = strtok ( NULL, "_" );

						printf("\n\n\t\t DMLNumber is :%s",DMLNumber); fflush(stdout);
						printf("\n\n\t\t taskGrp is :%s",taskGrp); fflush(stdout);

						ifail = AOM_ask_value_int(DMLRevTag,"sequence_id",&sequence_id);
						printf("\n\n\t\t sequence_id is :%d\n",sequence_id);fflush(stdout);

						ifail = POM_class_of_instance(DMLRevTag,&class_id1);
						ifail = POM_name_of_class(class_id1,&class_name1);
						printf("\n\n\t\t class_name found1 :%s",class_name1);

						ifail = AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype);
						printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);

						if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
						{
							if(strcmp(DMLtype,"")==0)
							{
								printf("\n\n\t\t t5_rlstype is NULL\n");fflush(stdout);
								printf("\n\n\t\t ERC-DML Type IsNULL, plz update release type as required\n");fflush(stdout);
								//EMH_clear_errors();
								//EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "ERC-DML Type IsNULL, plz update release type as required");
								//decision = EPM_nogo;
								return ifail;

							} //If for DML Type check ends
							else
							{
								ifail = AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo);
								printf("\n\n\t\t DMLNo is :%s",DMLNo);fflush(stdout);

								if((strcmp(DMLtype,"EP")==0))
								{
									// Validation check for ECU Part release DML only
									ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation_type);
									if (relation_type!=NULLTAG)
									{
										ifail = GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects);
										printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);
										if(n_attchs>0)
										{
											for (j=0;j<n_attchs;j++ )
											{
												 ifail = AOM_ask_value_string(secondary_objects[j],"current_id",&t5current_name1);
												  printf("\n\n\t\t t5current_name1 is :%s",t5current_name1);fflush(stdout);
												  if ( ifail != ITK_ok)
												   {
													 //EMH_ask_error_text( status, &s);
													 printf("Error with AOM_ask_value_string2 : %s \n",s);
													// MEM_free(s);
													 //return status;
												   }
												   else
												   {
														 ifail = AOM_ask_value_string(secondary_objects[j],"object_type",&object_type);
														 printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);

														 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
														 {
															 ifail = AOM_ask_value_tags(secondary_objects[j],"CMHasSolutionItem",&partcnt,&PartsTag);
															 printf("\n\n\t\t No. of Part in Solution Folder :%d \n",partcnt);fflush(stdout);

															 if (partcnt>0)
															 {
																 //This is the loop for Solution items present in Solution folder of DML:
																for (k=0;k<partcnt ;k++ )
																{
																		AssyTag=PartsTag[k];
																		ifail = AOM_ask_value_string(AssyTag,"item_id",&Part_no);
																		printf("\n\n\t\t Part_no  is :%s \n",Part_no);	fflush(stdout);

																		ifail = TCTYPE_ask_object_type(AssyTag,&objTypeTag);
																		ifail = TCTYPE_ask_name(objTypeTag,type_name);
																		printf("\n\n\t\t AssyTag type_name := %s \n",type_name);fflush(stdout);
																		//20-07-2023 ECU Module added.
																		//if(strcmp(type_name,"T5_EE_PartRevision") == 0)
																		if((strcmp(type_name,"T5_EE_PartRevision") == 0) || (strcmp(type_name,"Design Revision") == 0))
																		{
																				printf("\n\n\t\t Inside Validation for EE Parts.\n");	fflush(stdout);
																				//Get child of Assembly having Rev ID NR
																				NRRevCheck = EE_Part_BOM_Validation_for_NR_Rev(Part_no,partcnt,PartsTag);
																				if(tc_strcmp(NRRevCheck,"")==0)//if(NRRevCheck)//
																				{
																					printf("\n\n\t\t No NR Rev Child Part found... \n");fflush(stdout);
																					//EPM_go;
																				}
																				else
																				{

																					tc_strcat(childWithNR_ERC_Review,Part_no);
																					tc_strcat(childWithNR_ERC_Review,",");
																					tc_strcat(childWithNR_ERC_Review,"have child part(s)[");
																					tc_strcat(childWithNR_ERC_Review,NRRevCheck);
																					tc_strcat(childWithNR_ERC_Review,"]");
																					tc_strcat(childWithNR_ERC_Review,"with NR Revision and Status ERC Review.And not found in solution item folder of DML,Please add this parts to solution folder,to procced further");

																					printf("\n\n\t\t chlidPartNos with NR Rev := %s \n",NRRevCheck);fflush(stdout);
																					printf("\n\n\t\t Error MSG := %s \n",childWithNR_ERC_Review);fflush(stdout);
																					//EMH_clear_errors();
																					//EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,childWithNR_ERC_Review);
																					//decision = EPM_nogo;
																					return ifail;
																					//EPM_nogo;
																				}
																		}
																}
															 }

														 }

												   }
											}
										}

									}

								}

							}
						}

					}
				}

			}
	 }

	printf("\n\n\t\t End of function Check_NR_Rev_with_ERC_Reivew... \n");fflush(stdout);
	return ifail;
}
//method for EE Part child validation. Added by Kirtikumar For NR Rev and ERC Reveiw check
char* EE_Part_BOM_Validation_for_NR_Rev(char *item_id,int partcnt,tag_t *PartsTag)
{
	int			chlid_count			= 0;
	int			i					= 0;
	int			j					= 0;
	int			ifail				= 0;
	int			attrReleaseStatusID = 0;
	int			attrRevID			= 0;
	tag_t		item_tag		= NULLTAG;
	tag_t		latestRev		= NULLTAG;
	tag_t		window			= NULLTAG;
	tag_t		rule			= NULLTAG;
	tag_t		top_line		= NULLTAG;
	tag_t		*children1		= NULLTAG;
	tag_t		statusTag		= NULLTAG;
	tag_t		RevIDTag		= NULLTAG;

	//char 	statusName[WSO_name_size_c+1];
	char 	RevName[WSO_name_size_c+1];

	char		*statusName		= NULL;
	char		*RevID			= NULL;
	char		*bomID			= NULL;
	//char		*PartWithNR_rev	= NULL;
	char 		*tempNRRevID	= NULL;
	char		*PartWithNR_rev				= (char *) MEM_alloc( 100 * sizeof(char) );
	char		*tempPart_no	= NULL;
	logical isChildPresentInSolutionFolder  = false;

	printf("\n\n\t\t In EE_Part_BOM_Validation_for_NR_Rev_function.");fflush(stdout);
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_ask_latest_rev(item_tag,&latestRev);

	ifail = BOM_create_window (&window);
	ifail = CFM_find( "Latest Working", &rule );
	ifail = BOM_set_window_config_rule( window, rule );
	ifail = BOM_set_window_pack_all (window, false);
	ifail = BOM_set_window_top_line (window, null_tag,latestRev , null_tag, &top_line);
	ifail = BOM_line_ask_child_lines (top_line, &chlid_count, &children1);
	CHECK_FAIL;

	printf("\n\n\t\t No of child foud : %d.",chlid_count);fflush(stdout);

	tc_strcpy(PartWithNR_rev,"");

	for (i=0;i< chlid_count; i++)
	{
		ifail = AOM_UIF_ask_value(children1[i],"bl_rev_release_status_list",&statusName);
		ifail = AOM_UIF_ask_value(children1[i],"bl_rev_item_revision_id",&RevID);
		ifail = AOM_UIF_ask_value(children1[i],"bl_item_item_id",&bomID);

		printf("\n\n\t\t ID of child is :%s",bomID);fflush(stdout);
		printf("\n\n\t\t statusName is :%s",statusName);fflush(stdout);
		printf("\n\n\t\t RevName is :%s",RevID);fflush(stdout);

		tempNRRevID = strtok(RevID, ";");

		//Condition for NR rev with ERC Review status
		if(tc_strcmp(tempNRRevID,"NR")==0 && tc_strcmp(statusName,"ERC Review")==0)
		{

			printf("\n\n\t\t ******NR Rev Part Found*****");

			for (j=0; j<partcnt; j++ )
			{
				ifail = AOM_ask_value_string(PartsTag[j],"item_id",&tempPart_no);
				if(tc_strcmp(bomID,tempPart_no)==0)
				{
					printf("\n\n\t\t chlidPartNo is Present in Solution item folder %s\n",bomID);fflush(stdout);
					isChildPresentInSolutionFolder =true;
					break;
				}
				//else
				//{
					//printf("\n\n\t\t chlidPartNo is NOT Present in Solution item folder %s\n",bomID);fflush(stdout);
				//}
			}
			if(isChildPresentInSolutionFolder)
			{
				printf("\n\n\t\t isChildPresentInSolutionFolder is TRUE");

			}
			else {

				printf("\n\n\t\t chlidPartNo is NOT Present in Solution item folder %s\n",bomID);fflush(stdout);
				if(tc_strcmp(PartWithNR_rev,"") == 0)
				{
					tc_strcpy(PartWithNR_rev,bomID);
					printf("\n\n\t\t PartWithNR_rev %s\n",PartWithNR_rev);
				}
				else
				{
					tc_strcat(PartWithNR_rev, ",");
					tc_strcat(PartWithNR_rev, bomID);
					printf("\n\n\t\t PartWithNR_re %s\n",PartWithNR_rev);
				}
			}

		}
		//
		isChildPresentInSolutionFolder =false;
	}
	return PartWithNR_rev;
}