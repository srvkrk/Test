#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s\n",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{

	//printf("****item_id******* %s",item_id);
	tag_t itemTag = NULLTAG;
	char* itemName = NULL;
	int	 count	=0;
	tag_t latestRev = NULLTAG;
	char* itemRevObjStr	=NULLTAG;

	///

	 char* ObjStr = NULL;
	 tag_t objTypeTag,item_tag = NULLTAG;
	 char  type_name[TCTYPE_name_size_c+1];
	 char* itemRevIDObj =	NULL;
	 tag_t			ItemTag				= NULLTAG;
	 char*			ObjStrItem			= NULLTAG;
	 int			count1				= 0;
	 tag_t *		rev_list1			= NULLTAG;
	 int			i1					=	0;
	 int			j1					=	0;
	 int			k1					=   0;

	 char*			Prevrev_tagItemRevID	= NULL;
	 char*			Prevrev_tagObjStr		= NULL;
	 tag_t			MastSlvRelTag			=  NULLTAG;
	 int			masterCout					= 0;
	 tag_t*			masterTag					= NULLTAG;

	//char*			slaveObjStr					= NULL;
	//tag_t		    relationTag					= NULLTAG;
	//tag_t			newRelation					= NULLTAG;

	char*			MasterItemRevId				= NULLTAG;
	char*			MasterObject_string				= NULLTAG;
	tag_t			masterItemTag				= NULLTAG;
	tag_t			MasterLatestItemRevTag		= NULLTAG;
	char*			MasterLatestItemRevID		= NULLTAG;

	int			    slaveCount					= 0;
	tag_t*		    SlaveTag					= NULLTAG;
	char*			slaveObjStr					= NULL;
	tag_t		    relationTag					= NULLTAG;
	tag_t			newRelation					= NULLTAG;

	//

	ifail = ITEM_find_item (item_id, &itemTag);
	ITK_CALL(AOM_ask_value_string(itemTag,"object_name",&itemName));
	printf("\n\t itemName : =%s \n\n",itemName);fflush(stdout);

	//ifail = ITEM_list_all_revs (itemTag, &count, &rev_list);
	ITK_CALL(ITEM_ask_latest_rev(itemTag,&latestRev));
	ITK_CALL(AOM_ask_value_string(latestRev,"object_string",&itemRevObjStr));

	printf("\n\t itemRevObjStr : =%s \n\n",itemRevObjStr);fflush(stdout);


	 //Control Obj for On and Off Validation.
	tag_t	qry_t1MastSlv			= NULLTAG;
	char **qry_val3MastSlv			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1MastSlv[1]   = {"SYSCD"};
	int n_entr1MastSlv				= 1;
	int rsltCunt1MastSlv			= 0;
	tag_t *CntrlObjTag1MastSlv		= NULLTAG;

	if(QRY_find("ControlObjects", &qry_t1MastSlv));
	if (qry_t1MastSlv)
	{
		printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
	}
	qry_val3MastSlv[0] = "MasterSlavContRel";
	if(QRY_execute(qry_t1MastSlv, n_entr1MastSlv, qry_entr1MastSlv, qry_val3MastSlv, &rsltCunt1MastSlv, &CntrlObjTag1MastSlv));

	printf("\n\t ****rsltCunt1MastSlv => %d*****\n",rsltCunt1MastSlv);fflush(stdout);

	if(rsltCunt1MastSlv>0)
	{
		 ITKCALL(AOM_ask_value_string(latestRev,"object_string",&ObjStr));
		 printf("\n\t ****ObjStr => %s*****\n",ObjStr);fflush(stdout);

		 if(TCTYPE_ask_object_type(latestRev,&objTypeTag)!=ITK_ok) ;
		 if(TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok) ;
		 if(tc_strcmp(type_name,"T5_EE_PartRevision")==0)
		 {
			   ITK_CALL(GRM_find_relation_type("T5_ContHasSlave",&MastSlvRelTag));
			   printf("\n after finding MastSlvRelTag \n");fflush(stdout);

			   printf("\n\t ****T5_EE_PartRevision Found..*****\n");fflush(stdout);
				
			   ITKCALL(AOM_ask_value_string(latestRev,"item_revision_id",&itemRevIDObj));
			   printf("\n\t ****itemRevIDObj => %s*****\n",itemRevIDObj);fflush(stdout);

			   ITK_CALL(ITEM_ask_item_of_rev(latestRev,&ItemTag));

			   ITKCALL(AOM_ask_value_string(ItemTag,"object_string",&ObjStrItem));
			   printf("\n\t ****ObjStrItem => %s*****\n",ObjStrItem);fflush(stdout);
			   ITKCALL(ITEM_list_all_revs(ItemTag,&count1,&rev_list1));

			    printf("\n\t **** Total Rev count is :: => %d*****\n",count1);fflush(stdout);

			   for(i1=count1-1;i1>=0;i1--)
			   {
				  printf("\n  -- :: i1  ::-- %d ",i1);fflush(stdout);

				  if( AOM_ask_value_string(rev_list1[i1],"object_string",&Prevrev_tagObjStr)!=ITK_ok);;
				  if( AOM_ask_value_string(rev_list1[i1],"item_revision_id",&Prevrev_tagItemRevID)!=ITK_ok);

				  printf("\n Prevrev_tagObjStr  ::-- %s ",Prevrev_tagObjStr);fflush(stdout);
				  printf("\n Previous revision Item Rev Id %s ",Prevrev_tagItemRevID);fflush(stdout);

				  ITK_CALL(GRM_list_primary_objects_only(rev_list1[i1], MastSlvRelTag, &masterCout, &masterTag));
				  printf("\n  masterCout.:%d\n",masterCout);fflush(stdout);

				    if(masterCout > 0)
			        {
						printf("\n\t ****Slave has Master container*****\n");fflush(stdout);
						for(j1= 0 ;j1 < masterCout; j1++)
					    {
							ITKCALL(AOM_ask_value_string(masterTag[j1],"object_string",&MasterObject_string));
							printf("\n MasterObject_string is :%s\n",MasterObject_string);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(masterTag[j1],"item_revision_id",&MasterItemRevId));
							printf("\n MasterItemRevId is :%s\n",MasterItemRevId);fflush(stdout);

							ITK_CALL(ITEM_ask_item_of_rev(masterTag[j1],&masterItemTag));
							ITK_CALL(ITEM_ask_latest_rev(masterItemTag,&MasterLatestItemRevTag));

							ITK_CALL(AOM_ask_value_string(MasterLatestItemRevTag,"item_revision_id",&MasterLatestItemRevID));
							printf("\n MasterLatestItemRevID :%s\n",MasterLatestItemRevID);fflush(stdout);
							//CHEK FOR ONLY LATEST  REV OF MASTER CONTAINER
							if(strcmp(MasterItemRevId,MasterLatestItemRevID)==0)
							{
								ITK_CALL(GRM_list_secondary_objects_only(masterTag[j1], MastSlvRelTag, &slaveCount, &SlaveTag));
								printf("\n  slaveCount.:%d\n",slaveCount);fflush(stdout);

				   			   if(slaveCount > 0)
							   {
								    for(k1 =0; k1 < slaveCount; k1++)
								    {
										  ITKCALL(AOM_ask_value_string(SlaveTag[k1],"object_string",&slaveObjStr));
									      printf("\n\t ****slaveObjStr => %s*****\n",slaveObjStr);fflush(stdout);
										  if((tc_strcmp(Prevrev_tagObjStr,slaveObjStr) == 0))
										  {
												 ITK_CALL(GRM_find_relation(masterTag[j1], SlaveTag[k1], MastSlvRelTag, &relationTag));
												 if(relationTag)
												 {
													ITK_CALL(GRM_delete_relation(relationTag));
													printf("\n\t ****OLD Slave Revision has been removed.*****\n");fflush(stdout);

												 }

										   }
									}

							   }
							 ITK_CALL(AOM_refresh(masterTag[j1],1));
							 ITK_CALL(GRM_create_relation(masterTag[j1], latestRev, MastSlvRelTag, NULLTAG,&newRelation));
							 ITK_CALL(GRM_save_relation(newRelation));
							 ITK_CALL(AOM_save(masterTag[j1]));
							 ITK_CALL(AOM_refresh(masterTag[j1],0));
							 printf("\n\t ****Relation is created with Master and Latest slave revision.*****\n");fflush(stdout);

							}

						}
					}
					 //Just need to consider previous revision only.
					 int tempCount = 0;
					 tempCount = count1 -2;
					 printf("\n\t **** tempCount :: => %d*****\n",tempCount);fflush(stdout);
					 if(tempCount == i1)
				     {
						break;
					 }

			   }

		 }
		else
		{
			printf("\n Not a Valid Obj Type for  :: carryMastSlvRelationOnCheckOutForEEPartRev !! \n");fflush(stdout);

		}

	}
	else
	{
		printf("\n Auto Relation Carryforword is OFF  :: RES CheckOutMsg !! \n");fflush(stdout);
		
	}

	return ifail;
}
