#!/usr/bin/bash
(
echo "To:kt.ttl@tatamotors.com"
#echo "Cc:harshadp.ttl@tatamotors.com,gr.ttl@tatamotors.com"
echo "SUBJECT: This is the system Generated mail"
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
echo "<html>"
echo "<body>"
echo "<p> This is the paragraph"
echo "</body>"
echo "</html>"
) | /usr/sbin/sendmail -f kt.ttl@tatamotors.com kt.ttl@tatamotors.com

