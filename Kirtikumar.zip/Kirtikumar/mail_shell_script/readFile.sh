
sed -n 's/^ObjectName=//p' abc.txt
