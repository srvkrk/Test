#!/bin/bash
TO_ADD="kt.tt@tatamotors.com"
FROM_ADD="kt.tt@tatamotors.com"
SUB="This is the test mail, Please ignore it"
BODY_FILE="/user/testcmi/devgroups/Kirtikumar/mailBody.txt"
ATTACH="/user/testcmi/devgroups/Kirtikumar/abc.txt"
CC_LIST="prachiw.ttl@tatamotors.com,harshadp.ttl@tatamotors.com"
#echo $BODY_FILE
#mail -s ${SUB} -A ${ATTACH} -c ${CC_LIST} -r ${FROM_ADD} ${TO_ADD} < ${BODY_FILE}
mail -s $SUB -A $ATTACH -c $CC_LIST -r $FROM_ADD $TO_ADD < $BODY_FILE
