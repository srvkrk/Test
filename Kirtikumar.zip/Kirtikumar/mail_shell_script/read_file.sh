#!/bin/bash
echo input file is: $1
cat $1
