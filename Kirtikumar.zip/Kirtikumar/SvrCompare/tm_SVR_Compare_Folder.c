#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <unidefs.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <property/prop.h>
#include <pie/pie.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <textsrv/textserver.h>
#include <string.h>
#include <epm/cr_effectivity.h>

#include <tccore/aom.h>
#include <tccore/tctype.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/cr_action_handlers.h>
#include <epm/epm.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <ict/ict_userservice.h>
#include <tccore/item.h>
#include <itk/bmf.h>
#include <itk/mem.h>
#include <property/propdesc.h>
#include <sa/sa.h>
#include <server_exits/user_server_exits.h>
#include <ss/ss_errors.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tccore/custom.h>
#include <tccore/tctype.h>
#include <user_exits/epm_toolkit_utils.h>
#include <user_exits/user_exit_msg.h>
#include <user_exits/user_exits.h>
#include <server_exits/user_server_exits.h>
#include <bom/bom.h>
#include <tc/folder.h>
#define NUM_ENTRIES 1
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;
//static void print_bom (tag_t line,tag_t Parent, int depth,FILE *fdf,FILE *fus,char *inid);
//static void print_data_item(tag_t this_itemRev,char *attr);
//char* subString (char* mainStringf ,int fromCharf,int toCharf);

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
extern int ITK_user_main (int argc, char ** argv )
{
    int     status=0; 
 
	char *SVR = NULL;
	char *svr_name = NULL;
	 
 	int ifail =0;
	
	 
	
	int n_modes=0;
	char **mode_names = NULL;

 
		char*			mod_name_SVR				=NULL;  
		char*			mod_name_VC				=NULL;  
		char*			SVRname				=NULL;  
		char*			FileDown				=NULL;  
		tag_t			bom_window				=NULLTAG;
		tag_t			bom_window_VC				=NULLTAG;
		tag_t			bom_window_SVR				=NULLTAG;
		tag_t			top_line_VC				=NULLTAG; 
		tag_t			top_line_SVR				=NULLTAG; 
		tag_t			rule					=NULLTAG;
		tag_t			PrdConfigTag			=NULLTAG;
		tag_t			objTypeTagDi			=NULLTAG;
		tag_t			primaryTag				=NULLTAG;
		tag_t			PlatformTag				=NULLTAG;
		tag_t			PlatformTagRev				=NULLTAG;
		tag_t			SvrTag				=NULLTAG;
		//tag_t			*SvrTagS			=NULL;

		tag_t           *bom_variant_config=NULL;
		tag_t           *bomvariantlist_SVR=NULL;
		FILE	*fd;
		

		tag_t *Primary_objects1 = NULL;
		tag_t *Primary_objects2 = NULL;
		tag_t *secondary_objects1 = NULL;
		tag_t *lines_VC = NULL;
		tag_t *sub_lines_VC = NULL;
		tag_t *sub_lines_SVR = NULL;

		char   type_name3[TCTYPE_name_size_c+1];

		WSO_search_criteria_t  	criteria;
		int number_found=0,countS=0;
		tag_t *list_of_WSO_tags=NULL;
		int i=0,k=0,n_lines=0,zz=0,n_lines1=0, vcount=0,countDep=0,vcountSVR=0,SvrFolder_Size=0,sub_n_lines_VC=0,sub_n_lines_SVR=0,n_lines_SVR_Cnt=0;
		int sub_n_lines=0,sub_n_lines1=0, zt=0,countDep1=0,n_lines_VC_Cnt=0,zx=0,zy=0,flagMatch=0,K=0;
		logical modB=FALSE;
		logical modB_SVR=FALSE;

		 tag_t 	*bomvariantlist = NULLTAG;
		 tag_t 	*SvrTagS = NULLTAG;
		 tag_t 	*lines_SVR = NULLTAG;
		 tag_t 	FolderTag = NULLTAG;
		 //char* SVR_Name= NULLTAG;
		 //char* SvrName_Dup= (char *) MEM_alloc ( 100);
		 
		char	SVR_Name_Type[WSO_name_size_c+1] ;
		char	SVR_Name[WSO_name_size_c+1] ;
		char	SvrName_Dup[WSO_name_size_c+1] ;
		char*	 VcName			= NULL;
		tag_t *tags_found = NULL;
		int n_tags_found= 0;
		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
		char **values = (char **) MEM_alloc(1 * sizeof(char *));
		tag_t *closurerule = NULL;
		int rulefound=0;
		tag_t close_tag=NULLTAG;
	    char **rulename = NULL;
		char **rulevalue = NULL;
	    char **rulename_SVR = NULL;
		char **rulevalue_SVR = NULL;

		 int ReqCnt=0;
   

	 if( ITK_init_module("infodba" ,"infodba","dba")!=ITK_ok) ;
	 ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ); 
     ifail = ITK_auto_login (); 
//	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
//	//ITK_CALL(ITK_auto_login( ));
//    ITK_CALL(ITK_set_journalling( TRUE ));
  
	 SVR = (char *) MEM_alloc (sizeof (char) * 128);
	 FileDown = (char *) MEM_alloc (sizeof (char) * 128);
     SVR = ITK_ask_cli_argument("-i=");

	//Validate SVR  Assuming X4 Platform
	//////////////////////////////////////
	WSOM_clear_search_criteria(&criteria);
	strcpy(criteria.name,SVR);
	strcpy(criteria.class_name,"Folder");
	CALLAPI(WSOM_search(criteria, &number_found, &list_of_WSO_tags));
	printf("\n\n\t\t FOLDER found : %d\n",number_found);fflush(stdout);
	FolderTag=list_of_WSO_tags[0];
	//CALLAPI(CFM_find( "Latest Working", &rule));
	CALLAPI(CFM_find("ERC release and above", &rule));

	CALLAPI(PIE_find_closure_rules( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
    printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
	close_tag = closurerule[0];
	printf ("closure rule found \n");fflush(stdout);
	
	}



	tc_strcpy(FileDown,SVR);
	tc_strcat(FileDown,"_BomCompare.csv");

	//CALLAPI(FL_ask_size(FolderTag,&SvrFolder_Size));
	CALLAPI(FL_ask_references(FolderTag,FL_fsc_by_name,&SvrFolder_Size,&SvrTagS));
	printf("\n\n\t\t folder size : %d\n",SvrFolder_Size);fflush(stdout);
	if (SvrFolder_Size >0)
	{
			fd=fopen(FileDown,"w");
			if(fd==NULL)
			{
				printf("\nError in opening the file \n");fflush(stdout);
				fprintf(fd," SVR  and VC");
			}
		
		for (ReqCnt=0;ReqCnt<SvrFolder_Size;ReqCnt++)
		{
			SvrTag=SvrTagS[ReqCnt];
			CALLAPI(WSOM_ask_name(SvrTag,SVR_Name));
			CALLAPI(WSOM_ask_name(SvrTag,SvrName_Dup));
			CALLAPI(WSOM_ask_object_type(SvrTag,SVR_Name_Type));
			printf("\nDvoReqRel_Name [%s] and it Is [%s]\n",SVR_Name,SVR_Name_Type);fflush(stdout);
			if (tc_strcmp(SVR_Name_Type,"VariantRule")==0)
			{
				
				fprintf(fd,",SVR  and VC\n");
				
				VcName = tc_strtok(SVR_Name,"_");
				fprintf(fd,"%d,%s and %s \n",ReqCnt,SvrName_Dup,VcName);

				printf("\nVC_Name [%s]\n",VcName);fflush(stdout);
				attrs[0] ="item_id";
				values[0] = (char *)VcName;
				
				ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

				if (n_tags_found == 0)
				{
					printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", VcName);fflush(stdout);
				}
				else if (n_tags_found > 1)
				{
					printf ( "More than one items matched with id %s\n", VcName);fflush(stdout);
				}

				if (n_tags_found==1)
				{
					if (bom_window_VC)
					{
						bom_window_VC=NULLTAG;
					}
					if (top_line_VC)
					{
						top_line_VC=NULLTAG;
					}

					CALLAPI(BOM_create_window(&bom_window_VC));
					CALLAPI(BOM_set_window_config_rule( bom_window_VC, rule));	
					//CALLAPI(BOM_window_set_closure_rule( bom_window_VC,close_tag, 0, rulename,rulevalue ));
					CALLAPI(BOM_set_window_pack_all(bom_window_VC, TRUE));  
					CALLAPI(BOM_set_window_top_line( bom_window_VC, tags_found[0], NULLTAG, NULLTAG, &top_line_VC));
					printf("\n inside bom_window_SVR-----444\n"); fflush(stdout);

					CALLAPI(BOM_line_ask_all_child_lines(top_line_VC, &n_lines_VC_Cnt, &lines_VC));
					printf("\n VC expansion: %d \n", n_lines_VC_Cnt); fflush(stdout);	
					if (n_lines_VC_Cnt >0)
					{
							for (zz=0;zz<n_lines_VC_Cnt ;zz++)
							{
								//CALLAPI(AOM_ask_value_string(lines_VC[zz],"bl_line_name",&mod_name));	
								//printf("\nmod_name:%s\n",mod_name);	fflush(stdout);
								CALLAPI(BOM_line_ask_all_child_lines(lines_VC[zz], &sub_n_lines_VC, &sub_lines_VC));		
							}  
					}

				}

				
				CALLAPI(GRM_list_primary_objects_only(SvrTag,NULLTAG,&countDep,&Primary_objects1));
				printf("count found %d ",countDep);fflush(stdout);
				for (K=0;K < countDep;K++ )
				{
				PrdConfigTag=Primary_objects1[K];							
				CALLAPI(TCTYPE_ask_object_type(PrdConfigTag,&objTypeTagDi));
				CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
				printf( "\n type_name Prd config :%s ..\n",type_name3);
				if (tc_strcmp(type_name3,"Cfg0ProductItem")==0)
				{
					CALLAPI(GRM_list_primary_objects_only(PrdConfigTag,NULLTAG,&countDep1,&Primary_objects2));
					for (i=0;i < countDep1;i++ )
					{
						primaryTag=Primary_objects2[i];
						CALLAPI(TCTYPE_ask_object_type(primaryTag,&objTypeTagDi));
						CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
						printf( "\n type_name Platform :%s ..\n",type_name3);
						if (tc_strcmp(type_name3,"T5_Platform")==0)
						{
							//CALLAPI ( ITEM_ask_latest_rev( primaryTag, &PlatformRevTag ));
							PlatformTag=Primary_objects2[i];
							CALLAPI ( ITEM_ask_latest_rev( PlatformTag, &PlatformTagRev ));
							break;
							
						}
					}
					if (PlatformTag)
					{
						break;
					}

				}
				}
				/// SVR and PLatform both found here
				
				if (PlatformTagRev && SvrTag)
				{
					
					
					CALLAPI(BOM_create_window(&bom_window_SVR));
					CALLAPI(BOM_set_window_config_rule( bom_window_SVR, rule));	
					CALLAPI(BOM_window_set_closure_rule( bom_window_SVR,close_tag, 0, rulename_SVR,rulevalue_SVR ));
					CALLAPI(BOM_set_window_pack_all(bom_window_SVR, TRUE));  
					CALLAPI(BOM_set_window_top_line( bom_window_SVR, NULLTAG,PlatformTagRev , NULLTAG, &top_line_SVR));
					printf("\n inside bom_window-----444\n"); fflush(stdout);			
					BOM_window_apply_variant_configuration(bom_window_SVR,1,&SvrTag);
					CALLAPI(BOM_window_hide_unconfigured(bom_window_SVR));				
					CALLAPI(BOM_window_hide_variants(bom_window_SVR));  

					printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
					BOM_window_ask_variant_rules(bom_window_SVR,&vcount,&bomvariantlist); 
					if(vcount > 0)
					{													
						printf( "\n SVR is applied:..\n");																		 
						printf("\nSVR count:%d\n",vcount);	fflush(stdout);
					}
					else
					{
						printf( "\n NO SVR applied in BOM window ..\n");
					}		
					
					CALLAPI(BOM_window_ask_is_modified(bom_window_SVR,&modB));
					if(modB)
					{
						printf( "\n modified bom window:..\n");
					}
					else
					{
						printf( "\n not modfiifed ..\n");
					}	

					
					CALLAPI(BOM_line_ask_all_child_lines(top_line_SVR, &n_lines_SVR_Cnt, &lines_SVR));
					printf("\n After applying SVR all childlines: %d \n", n_lines_SVR_Cnt); fflush(stdout);	
					if (n_lines_SVR_Cnt >0)
					{
							for (zx=0;zx<n_lines_SVR_Cnt ;zx++)
							{
								//CALLAPI(AOM_ask_value_string(lines_SVR[zx],"bl_line_name",&mod_name_SVR));	
								//printf("\nmod_name:%s\n",mod_name_SVR);	fflush(stdout);
									CALLAPI(BOM_line_ask_all_child_lines(lines_SVR[zx], &sub_n_lines_SVR, &sub_lines_SVR));
									for (zy=0;zy<sub_n_lines_SVR ;zy++)
									{
										CALLAPI(AOM_ask_value_string(sub_lines_SVR[zy],"bl_item_item_id",&mod_name_SVR));
										flagMatch=0;
										//printf("\n\t\t\t starting to comparemod_name SVR:%s\n",mod_name_SVR);	fflush(stdout);	
										for (zt=0;zt<sub_n_lines_VC ;zt++)
										{
											
											CALLAPI(AOM_ask_value_string(sub_lines_VC[zt],"bl_item_item_id",&mod_name_VC));	
											//printf("\n\t\t\tmod_name VC:%s\n",mod_name_VC);	fflush(stdout);
											
											if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
											{
												flagMatch=1;
												break;
											}


										}
										if (flagMatch==0)
										{
											printf("\n\t\t\t difference in BOM for SVR=========================================>>> %s\n",mod_name_SVR);	fflush(stdout);
											fprintf(fd," ,%s, Module from Solved BOM not found under the VC %s BOM \n",mod_name_SVR,VcName);
										}
										
									}  		
							}
							
							///////////// comparing VC
							printf("\n\t\t\tStarting for VC:====================>>>>>>>>>>>>\n");	fflush(stdout);
							for (zt=0;zt<sub_n_lines_VC ;zt++)
							{
											
								CALLAPI(AOM_ask_value_string(sub_lines_VC[zt],"bl_item_item_id",&mod_name_VC));	
								//printf("\n\t\t\tmod_name VC:%s\n",mod_name_VC);	fflush(stdout);
								flagMatch=0;
								for (zx=0;zx<n_lines_SVR_Cnt ;zx++)
								{
										//CALLAPI(AOM_ask_value_string(lines_SVR[zx],"bl_line_name",&mod_name_SVR));	
										//printf("\nmod_name:%s\n",mod_name_SVR);	fflush(stdout);
										CALLAPI(BOM_line_ask_all_child_lines(lines_SVR[zx], &sub_n_lines_SVR, &sub_lines_SVR));
										for (zy=0;zy<sub_n_lines_SVR ;zy++)
										{
											CALLAPI(AOM_ask_value_string(sub_lines_SVR[zy],"bl_item_item_id",&mod_name_SVR));
											
											//printf("\n\t\t\t starting to comparemod_name SVR:%s\n",mod_name_SVR);	fflush(stdout);	

												
												if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
												{
													flagMatch=1;
													break;
												}
											
										}
										if (flagMatch==1)
										{
											break;
										}
								}
								if (flagMatch==0)
								{
												fprintf(fd,", %s,Module from VC not found under the solved BOM of SVR %s \n",mod_name_VC,SvrName_Dup);
												printf("\n\t\t\t difference in BOM for VC=========================================>>> %s\n",mod_name_VC);	fflush(stdout);
												
								}
							}
					}


				} 


			}


		}
		if (fd)
		{
			fclose(fd);
		}
}


MEM_free(list_of_WSO_tags);
//BOM_close_window(bom_window_SVR);
BOM_close_window(bom_window_VC);
 		 
	

	return status;	
} 
//---------------------------------------------------------------------------------------------------------
 
 