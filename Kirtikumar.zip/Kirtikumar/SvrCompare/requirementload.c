#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <form/form.h>
#include <tccore/aom.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom_prop.h>
#include <sa/tcfile.h>
#include <tc/preferences.h>
#include <ae/ae.h>
#include <user_exits/user_exits.h>
#include <ae/datasettype.h>
#include <time.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <mechatronics/psconnection.h>
#include <tccoreext/gde.h>
#include <mechatronics/gdelink.h>
#include <tccore/tctype.h>
#include <ecm/ecm.h>
#include <ae/nxsm.h>
#include <tccore/grm.h>
#include <me/me.h>
#include <math.h>
#include <fclasses/tc_date.h>
#include <itk/mem.h>
#include <tccore/item_errors.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok)return ifail;
#ifdef WNT
#include <windows.h>
#include <mapiwin.h>
#include <winbase.h>
#endif
#ifdef UNX
#include <pwd.h>
#include <unistd.h>
#include <sys/statvfs.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#endif
#define ERROR_CALL(x) {               \
  int stat;                     \
  char *err_string = NULL;             \
  if( (stat = (x)) != ITK_ok)   \
  {                             \
    EMH_ask_error_text (stat, &err_string);              \
    if(err_string != NULL) {\
	printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string);        \
    printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__);             \
	TC_write_syslog("Workflow ERROR[%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
	MEM_free (err_string);\
	err_string=NULL;\
	}\
    return (stat);          \
  }                         \
 }

static int
PrintErrorStack(
    void                      /* Utility function for error reporting */
);

#define Debug TRUE

#define ITK_CALL(X)                                                     \
                if(Debug)                                                               \
                {                                                                               \
                        printf(#X);                                                     \
                }                                                                               \
                fflush(NULL);                                                   \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("\t%3d error(s)\n", n_ifails);                                      \
                        for( index=0; index<n_ifails; index++)                                     \
                        {                                                                          \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                          \
                        return status;                                                             \
                }                                                                                  \
                else                                                                    \
                {                                                                               \
                        if(Debug)                                                       \
                        printf("\tSUCCESS\n");                          \
                }                                                                               \




extern int ITK_user_main( int argc, char **argv )
{
        /*START VARIABLE DECLARATION*/
        char *file1 = NULL;
        char *Filename = NULL;
        char *DmlNumberDup = NULL;
        char *Parentsequence_id = NULL;
        char *ItemDesc = NULL;
        char *ItemRevDesc = NULL;
        char *PriorLevel = NULL;
        char *ReqDesc = NULL;
        //char *reqtype = NULL;
        char *ReqOwneratt = NULL;
        char *Reqatt = NULL;
        char *level=NULL;
        char *inputfile=NULL;
        char *criteriaid=NULL;
        char *criterianame=NULL;
        char *defaulttarget=NULL;
        char *unit=NULL;
        char *targettype=NULL;
        char *projdesc=NULL;
        char *inputline=NULL;
		char Criteria_itemId[8];
		char	HitsS[7];
		int foundcnt=0;

		char *reqid	= NULL;
		char *reqname = NULL;
		char *reqcode = NULL;
		char *reqtext = NULL;
		char *reqowning = NULL;
		char *reqpriority = NULL;
		char *reqtype = NULL;
		char *reqstatus = NULL;


       int status = 0;
	   WSO_search_criteria_t  criteria;
	   int number_found;
	   tag_t *list_of_WSO_tags = NULLTAG;

        char  type_name[TCTYPE_name_size_c+1];
        char  Rev_name[TCTYPE_name_size_c+1];
        char  secondtype_name[TCTYPE_name_size_c+1];
		char	CrDesc[100];

int error_code;

        int ifail;
        int n_items=0;
        int n_attchs=0;
        int cnt=0;
        int TotalCount=0;
        int RevCnt=0;
        int all=0;
        int Criteria_itemId_num=421;
		char	* Wso_code		= NULL;

        tag_t   *item_tags              = NULL;
    tag_t    item = NULLTAG;
        tag_t   *secondary_objects              = NULLTAG;
        tag_t   user_data               = NULLTAG;
        tag_t   *relist         = NULLTAG;
        tag_t   *RelationShip           = NULLTAG;
        tag_t   Rel_type                = NULLTAG;
        tag_t   reln_type= NULLTAG;
        tag_t   objType;
        tag_t   primary;
        tag_t   tReqItem                = NULLTAG;
        tag_t   datasettype_tag                = NULLTAG;
        tag_t   default_tool_tag                = NULLTAG;
        tag_t   second;
        tag_t   secondobjType;
        tag_t   RevType;
		tag_t	ReqMaster						= NULLTAG;
		tag_t	ReqRev						= NULLTAG;
		IMF_file_t fileDescriptor;
        tag_t   newfile                = NULLTAG;
        AE_reference_type_t  reference_type;

        GRM_relation_t **  secondary_listl;
        GRM_relation_t **  relsecondary_listl;
        //char DmlNumberDup[];

        FILE *fp1;
        FILE *fp2;

        tag_t   *pTagAttch;
        /*END OF VAIABLE DECLARATION*/

     ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		 //ITK_CALL(ITK_auto_login( ));
         ITK_CALL(ITK_init_module  ("ercpsup","XYT1ESA","dba"));
         ITK_CALL(ITK_set_journalling( TRUE ));


        Filename=malloc(30000);
        inputfile=ITK_ask_cli_argument("-i=");

        fp1=fopen(inputfile,"r");
        fp2=fopen("error.log","a");
        if(fp1!=NULL)
        {
                inputline=(char *) MEM_alloc(500);
                while(fgets(inputline,500,fp1)!=NULL)
                {
                        fputs(inputline,stdout);
                        reqid=strtok(inputline,"^");
						if(tc_strcmp(reqid,"ID")==0)
						{
							printf("\nInside If Condition\n");
							continue;					
						}
                        reqname=strtok(NULL,"^");
                        reqcode=strtok(NULL,"^");
                        reqtext=strtok(NULL,"^");
                        reqowning=strtok(NULL,"^");
                        reqpriority=strtok(NULL,"^");
                        reqtype=strtok(NULL,"^");
                        reqstatus=strtok(NULL,"^");
        				//projdesc=strtok(NULL,"^");
                        //item_sequence_id=strtok(NULL,"^");


						printf("\n  reqid : %s , reqname = %s , reqcode : %s = reqtext = %s reqowning = %s reqpriority = %s reqtype = %s reqstatus = %s\n",reqid,reqname,reqcode,reqtext,reqowning,reqpriority,reqtype,reqstatus);fflush(stdout);


						printf("\nBefore create\n");
						ERROR_CALL(ITEM_create_item( reqid,reqname,"Requirement","A",&ReqMaster,&ReqRev));
						printf("\nAfter create\n");

						printf("\nBefore Save\n");
						ITEM_save_item ( ReqMaster );//printf("\n  Criteria Description = %s\n",projdesc);fflush(stdout);
						printf("\nAfter Save\n");

						if ((tc_strcmp(reqcode,"NULL")!=0) || (tc_strcmp(reqcode,"null")!=0))
						{
						printf("\nBefore set 1\n");
						AOM_set_value_string(ReqRev,"t5attribute",reqcode);	
						printf("\nAfter set 1\n");
						}

						if ((tc_strcmp(reqtext,"NULL")!=0) || (tc_strcmp(reqtext,"null")!=0))
						{
						printf("\nBefore set 2\n");
						AOM_set_value_string(ReqRev,"t5description",reqtext);	
						printf("\nafter set 2\n");
						}

						if ((tc_strcmp(reqowning,"NULL")!=0) || (tc_strcmp(reqowning,"null")!=0))
						{
						printf("\nBefore set 3\n");
						AOM_set_value_string(ReqRev,"t5ownattrgrp",reqowning);	
						printf("\nafter set 3\n");
						}

						if ((tc_strcmp(reqpriority,"NULL")!=0) || (tc_strcmp(reqpriority,"null")!=0))
						{
						printf("\nBefore set 4\n");
						AOM_set_value_string(ReqRev,"t5priorlevel",reqpriority);	
						printf("\nafter set 4\n");
						}

						if ((tc_strcmp(reqtype,"NULL")!=0) || (tc_strcmp(reqtype,"null")!=0))
						{
						printf("\nBefore set 5\n");
						AOM_set_value_string(ReqRev,"t5reqtype",reqtype);	
						printf("\nafter set 5\n");
						}

						if ((tc_strcmp(reqstatus,"NULL")!=0) || (tc_strcmp(reqstatus,"null")!=0))
						{
						printf("\nBefore set 6\n");
						AOM_set_value_string(ReqRev,"t5reqstatus",reqstatus);	
						printf("\nafter set 6\n");
						}

						printf("\nBefore save revision\n");
						AOM_save(ReqRev);
						printf("\nAfter save revision\n");

						printf("\nBefore Save Master 2\n");
						AOM_save(ReqMaster);
						printf("\nAfter Save Master 2\n");

						printf("\n Done......\n");

/*
AE_find_datasettype ("MSExcel",&datasettype_tag);
AE_ask_datasettype_def_tool(datasettype_tag,&default_tool_tag);


	

//strcat(new_name1,"Marketing_FeaturesList");
	printf("\n  I am inside the function and New Name prepared FeatureList= %s\n",projname);fflush(stdout);
	if ( IMF_import_file("/home/req83/bhaskar/datasetcre/noname.xls",projname,SS_BINARY,&newfile,&fileDescriptor) !=ITK_ok ) 
		//PrintErrorStack();
	printf("\n  11111111111111111111111 \n");fflush(stdout);
	AOM_save(newfile);
	printf("\n  222222222222222222222 \n");fflush(stdout);
    IMF_close_file (fileDescriptor);
	printf("\n  44444444444444444444444 \n");fflush(stdout);
	AE_create_dataset_with_id(datasettype_tag, projname,projdesc, 0, 0, &tReqItem);	
	printf("\n  5555555555555555 \n");fflush(stdout);
	//AOM_set_value_strings 	(tReqItem,"markup_acl",1,&markup_aclVal);
	
	//save_object(dataset_tag);
	AE_set_dataset_tool (tReqItem, default_tool_tag);
	reference_type = AE_PART_OF;
	printf(" \n Before named ref\n");fflush(stdout);
	AE_add_dataset_named_ref(tReqItem,"excel",reference_type,newfile);
	printf(" \n After named ref\n");fflush(stdout);
	AOM_save(tReqItem);


	// bhaskar end




*/

                                }

                 }




        //fclose (fp1);
}
