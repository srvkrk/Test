#include <tccore/aom.h>
#include <tccore/tctype.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/cr_action_handlers.h>
#include <epm/epm.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <ict/ict_userservice.h>
#include <tccore/item.h>
#include <itk/bmf.h>
#include <itk/mem.h>
#include <property/propdesc.h>
#include <sa/sa.h>
#include <server_exits/user_server_exits.h>
#include <ss/ss_errors.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tccore/custom.h>
#include <tccore/tctype.h>
#include <user_exits/epm_toolkit_utils.h>
#include <user_exits/user_exit_msg.h>
#include <user_exits/user_exits.h>
#include <server_exits/user_server_exits.h>
#include <bom/bom.h>
#define NUM_ENTRIES 1
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;
//static void print_bom (tag_t line,tag_t Parent, int depth,FILE *fdf,FILE *fus,char *inid);
//static void print_data_item(tag_t this_itemRev,char *attr);
//char* subString (char* mainStringf ,int fromCharf,int toCharf);

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
extern int ITK_user_main (int argc, char ** argv )
{
    int     status=0; 
 
	char *SVR = NULL;
	char *svr_name = NULL;
	 
 	int ifail =0;
	
	 
	
	int n_modes=0;
	char **mode_names = NULL;

 
		char*			*mod_name				=NULL;  
		char*			SVRname				=NULL;  
		char*			FileDown				=NULL;  
		tag_t			bom_window				=NULLTAG;
		tag_t			bom_window_SVR				=NULLTAG;
		tag_t			top_line				=NULLTAG; 
		tag_t			top_line_SVR				=NULLTAG; 
		tag_t			rule					=NULLTAG;
		tag_t			PrdConfigTag			=NULLTAG;
		tag_t			objTypeTagDi			=NULLTAG;
		tag_t			primaryTag				=NULLTAG;
		tag_t			PlatformTag				=NULLTAG;
		tag_t			SvrTag				=NULLTAG;
		//tag_t			*SvrTagS			=NULL;

		tag_t           *bom_variant_config=NULL;
		tag_t           *bomvariantlist_SVR=NULL;
		FILE	*fd;
		

		tag_t *Primary_objects1 = NULL;
		tag_t *Primary_objects2 = NULL;
		tag_t *secondary_objects1 = NULL;

		char   type_name3[TCTYPE_name_size_c+1];

		WSO_search_criteria_t  	criteria;
		int number_found=0,countS=0;
		tag_t *list_of_WSO_tags=NULL;
		int i=0,k=0,n_lines=0,zz=0,n_lines1=0, vcount=0,countDep=0,vcountSVR=0;
		int sub_n_lines=0,sub_n_lines1=0, zt=0,countDep1=0;
		logical modB=FALSE;
		logical modB_SVR=FALSE;

		 tag_t 	*bomvariantlist = NULLTAG;
   

	 if( ITK_init_module("infodba" ,"infodba","dba")!=ITK_ok) ;
	 ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ); 
     ifail = ITK_auto_login (); 
//	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
//	//ITK_CALL(ITK_auto_login( ));
//    ITK_CALL(ITK_set_journalling( TRUE ));
  
	 SVR = (char *) MEM_alloc (sizeof (char) * 128);
	 FileDown = (char *) MEM_alloc (sizeof (char) * 128);
     SVR = ITK_ask_cli_argument("-i=");

	//Validate SVR  Assuming X4 Platform
	//////////////////////////////////////
	WSOM_clear_search_criteria(&criteria);
	strcpy(criteria.name,SVR);
	strcpy(criteria.class_name,"VariantRule");
	CALLAPI(WSOM_search(criteria, &number_found, &list_of_WSO_tags));
	printf("\n\n\t\t SVR Count found : %d\n",number_found);fflush(stdout);
	SvrTag=list_of_WSO_tags[0];
	CALLAPI(GRM_list_primary_objects_only(SvrTag,NULLTAG,&countDep,&Primary_objects1));
	printf("count found %d ",countDep);fflush(stdout);
	PrdConfigTag=Primary_objects1[0];							
	CALLAPI(TCTYPE_ask_object_type(PrdConfigTag,&objTypeTagDi));
	CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
	printf( "\n type_name3 :%s ..\n",type_name3);
	if (tc_strcmp(type_name3,"Cfg0ProductItem")==0)					 ////// Going to find Product configurator
	{
		CALLAPI(GRM_list_primary_objects_only(PrdConfigTag,NULLTAG,&countDep1,&Primary_objects2));
		for (i=0;i < countDep1;i++ )
		{
			primaryTag=Primary_objects2[i];
			CALLAPI(TCTYPE_ask_object_type(primaryTag,&objTypeTagDi));
			CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
			printf( "\n type_name3 :%s ..\n",type_name3);
			if (tc_strcmp(type_name3,"T5_Platform")==0)					////// Going to find Platform
			{
				//CALLAPI ( ITEM_ask_latest_rev( primaryTag, &PlatformRevTag ));
				PlatformTag=Primary_objects2[i];
				break;
			}
		}

	}
	
	
	CALLAPI(CFM_find( "Latest Working", &rule));
	if (PlatformTag && SvrTag)    /// INPUT SVR BOM SOLVE
	{
		tc_strcpy(FileDown,SVR);
		tc_strcat(FileDown,"_BomCompare.csv");
		
		fd=fopen(FileDown,"w");
		if(fd==NULL)
		{
			printf("\nError in opening the file \n");fflush(stdout);
		}
		fprintf(fd,"\n,SVR Name ==> %s\n\n",SVR);
		fprintf(fd,"Serial nos,SVR,Platform/Architecture Node/Module, Description, Revision Change,Qty Change, Added/Removed");
		CALLAPI(BOM_create_window(&bom_window));
		CALLAPI(BOM_set_window_config_rule( bom_window, rule));	
		CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));  
		CALLAPI(BOM_set_window_top_line( bom_window, PlatformTag,NULLTAG , NULLTAG, &top_line));
		printf("\n inside bom_window-----444\n"); fflush(stdout);			
		BOM_window_apply_variant_configuration(bom_window,1,&SvrTag);
		CALLAPI(BOM_window_hide_unconfigured(bom_window));				
		CALLAPI(BOM_window_hide_variants(bom_window));  

		printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
		BOM_window_ask_variant_rules(bom_window,&vcount,&bomvariantlist); 
		if(vcount > 0)
		{													
			printf( "\n SVR is applied:..\n");																		 
			printf("\nSVR count:%d\n",vcount);	fflush(stdout);
		}
		else
		{
			printf( "\n NO SVR applied in BOM window ..\n");
		}		
		
		CALLAPI(BOM_window_ask_is_modified(bom_window,&modB));
		if(modB)
		{
			printf( "\n modified bom window:..\n");
		}
		else
		{
			printf( "\n not modfiifed ..\n");
		}	
	}

	if (PrdConfigTag)  /// BOM Solve of  SVR attached to Product config of Input SVR 
	{
		ITK_CALL(GRM_list_secondary_objects_only(PrdConfigTag,NULLTAG,&countS,&secondary_objects1));
		printf("Secondary object found %d ",countS);fflush(stdout);


		int SrlCnt=0;
		for (k=0;k<countS;k++)
		{
		
			SvrTag=secondary_objects1[k];							
			ITK_CALL(TCTYPE_ask_object_type(SvrTag,&objTypeTagDi));
			ITK_CALL(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
			printf( "\n type_name3 :%s ..\n",type_name3);
			if (tc_strcmp(type_name3,"VariantRule")==0)
			{
				ITK_CALL(AOM_ask_value_string(SvrTag,"object_name",&SVRname));;
				printf("\n SVRname Vraint rule is  :: %s =============>>>    %s object count %d Total %d\n",SVRname,SVR,k,countS);fflush(stdout);

				//fprintf(fd,"\n");
				if (tc_strcmp(SVR,SVRname))
				{
					SrlCnt++;
					fprintf(fd,"\n");
//					fprintf(fd,SVR);
//					fprintf(fd," and ");
					fprintf(fd,"%d,",SrlCnt);
					fprintf(fd,SVRname);
					fprintf(fd,"\n");

					if (bom_window_SVR)
					{
						bom_window_SVR=NULLTAG;
					}
					if (top_line_SVR)
					{
						top_line_SVR=NULLTAG;
					}
					//if (SvrTagS)
					//{
						//*SvrTagS=NULL;
					//}
					//SvrTagS[0]=SvrTag;
					CALLAPI(BOM_create_window(&bom_window_SVR));
					CALLAPI(BOM_set_window_config_rule( bom_window_SVR, rule));	
					CALLAPI(BOM_set_window_pack_all(bom_window_SVR, TRUE));  
					CALLAPI(BOM_set_window_top_line( bom_window_SVR, PlatformTag, NULLTAG, NULLTAG, &top_line_SVR));
					printf("\n inside bom_window_SVR-----444\n"); fflush(stdout);			
					BOM_window_apply_variant_configuration(bom_window_SVR,1,&SvrTag);
					CALLAPI(BOM_window_hide_unconfigured(bom_window_SVR));				
					CALLAPI(BOM_window_hide_variants(bom_window_SVR));  

					printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
					BOM_window_ask_variant_rules(bom_window_SVR,&vcountSVR,&bomvariantlist_SVR); 
					if(vcountSVR > 0)
					{													
						printf( "\n SVR is applied:..\n");																		 
						printf("\nSVR count:%d\n",vcount);	fflush(stdout);
					}
					else
					{
						printf( "\n NO SVR applied in BOM window SVR ..\n");
					}		
					
					CALLAPI(BOM_window_ask_is_modified(bom_window_SVR,&modB_SVR));
					if(modB_SVR)
					{
						printf( "\n modified bom window SVR:..\n");
					}
					else
					{
						printf( "\n not modfiifed SVR ..\n");
					}	

					CALLAPI(BOM_compare_execute(NULLTAG, top_line, top_line_SVR,"IMAN_bcm_ext_var_level", BOM_compare_output_report));  
					printf("\n difference in  :: %s =============    %s\n",SVRname,SVR);fflush(stdout); 
					int report_length = 0;
					int report_width = 0;
					int column_spacer = 0;
					int column_count = 0;
					int* column_width = 0;
					char** report_lines;
					tag_t* report_items=NULL;
					int ii =0;

					BOM_compare_report(top_line, &report_length, &report_lines,&report_items);
					BOM_compare_report_size(top_line,&report_width,&column_spacer,&column_count,&column_width );
					printf("\n Report details %d %d %d ------>> %d %d %d \n", report_width,column_spacer,column_count,column_width[0],column_width[1],column_width[2],column_width[3]);
					int Col_1_Start=0;
					int Col_1_End=						column_width[0];
					int Col_2_Start=	Col_1_End +		column_spacer;
					int Col_2_End=		Col_2_Start +	column_width[1];
					int Col_3_Start=	Col_2_End +		column_spacer;    
					int Col_3_End=		Col_3_Start +	column_width[2];
					int Col_4_Start=	Col_3_End +		column_spacer;    
					int Col_4_End=		Col_4_Start +	column_width[3];

					char* line=NULL;

					char* Col1=NULL;
					char* Col2=NULL;
					char* Col3=NULL;
					char* Col4=NULL;
					char* Col2_O=NULL;

					line=(char *) MEM_alloc(report_length + 100);
					Col1=(char *) MEM_alloc(column_width[0] + 20);
					Col2=(char *) MEM_alloc(column_width[1] + 20);
					Col3=(char *) MEM_alloc(column_width[2] + 20);
					Col4=(char *) MEM_alloc(column_width[3] + 20);
					Col2_O=(char *) MEM_alloc(column_width[3] + 20);

					if (report_length==1)
					{
						fprintf(fd,",No Changes,\n");
					}
					printf("\n Report details column length \n %d %d \n %d %d \n %d %d \n %d %d \n", Col_1_Start,Col_1_End,Col_2_Start,Col_2_End,Col_3_Start,Col_3_End,Col_4_Start,Col_4_End);fflush(stdout); 
					for(ii = 1; ii < report_length; ii++)
					{
							
							//line=report_lines[ii];
							
							tc_strcpy (line,"");
							tc_strcpy (Col1,"");
							tc_strcpy (Col2,"");
							tc_strcpy (Col3,"");
							tc_strcpy (Col4,"");
							tc_strcpy (Col2_O,"");
							tc_strcat (line,report_lines[ii]);
							printf("\n Line is ------->>>>>>> %s , Line nos %d , Report length %d\n", line,ii,report_length);fflush(stdout); 
	
							tc_strcat (Col1,subString(line,Col_1_Start,column_width[0]));
							tc_strcat (Col2,subString(line,Col_2_Start,column_width[1]));
							tc_strcat (Col3,subString(line,Col_3_Start,column_width[2]));
							tc_strcat (Col4,subString(line,Col_4_Start,column_width[3]));
							STRNG_replace_str(Col2,",",";",&Col2_O);

							//fprintf(fd,"%d",ii);
							fprintf(fd,",,");
							fprintf(fd,Col1);
							fprintf(fd,",");
							if (!tc_strstr(Col2_O,"\\"))
							{
								fprintf(fd,Col2_O);
							}
							
							fprintf(fd,",");
							if (!tc_strstr(Col3,"\\"))
							{
								fprintf(fd,Col3);
							}
							
							fprintf(fd,",");
							if (!tc_strstr(Col4,"\\"))
							{
			
								fprintf(fd,Col4);
								fprintf(fd,",");
								if (tc_strstr(Col4,"->0"))
								{
									fprintf(fd,"Module Removed");
								}
								else if (tc_strstr(Col4,"0->"))
								{
									fprintf(fd,"Module Added");
								}


							}
							
							fprintf(fd,"\n");


							printf("\nData <%s> \n", Col1);fflush(stdout); 
							printf("\nData <%s> \n", Col2);fflush(stdout); 
							printf("\nData <%s> \n", Col3);fflush(stdout); 
							printf("\nData <%s> \n", Col4);fflush(stdout); 
					}
				
				if(report_lines) MEM_free(report_lines);
				if(report_items) MEM_free(report_items);
				}

			}
		}

	}

	printf("\n Completed =\n");fflush(stdout); 

	
								 //mode_names     =  (char **) MEM_alloc(50 * sizeof(char *));
								//BOM_compare_ask_modes(false,&n_modes,&mode_names);
								//printf("\n\n\t\t n_modes Count1 : %d\n",n_modes);fflush(stdout);
								//if(n_modes > 0)
								//{

									//int w = 0;
									//for (w=0;w<n_modes ;w++ )
									//{
										//printf("\nmode_names:%s\n", mode_names[w]);fflush(stdout);
									//}

									//svrTag=list_of_WSO_tags[k];
									////(AOM_ask_value_string(svrTag,"object_name",&svr_name));	
								   //// printf("\nSVR Name:%s\n",svr_name);	fflush(stdout);
								//}

								//WSOM_clear_search_criteria(&criteria);
								//strcpy(criteria.name,"X3");
								//strcpy(criteria.class_name,"T5_PlatformRevision");
								//CALLAPI(WSOM_search(criteria, &number_found, &list_of_WSO_tags));
								//printf("\n\n\t\t Platform Count1 : %d\n",number_found);fflush(stdout);
								//if(number_found > 0)
								//{
										//CALLAPI(BOM_create_window(&bom_window));
										//CALLAPI(CFM_find( "Latest Working", &rule));
										//CALLAPI(BOM_set_window_config_rule( bom_window, rule));	
										//CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));  
										//CALLAPI(BOM_set_window_top_line( bom_window, NULLTAG, list_of_WSO_tags[0], NULLTAG, &top_line1));
										//printf("SVR_Release BOM_set_window_top_line..1\n");fflush(stdout); 
										//if(top_line1!=NULLTAG)
										//{
											  //CALLAPI(BOM_line_ask_all_child_lines(top_line1, &n_lines, &lines));
											  //printf("\n Before apply SVR count all childlines in BOM 444:%d\n", n_lines); fflush(stdout);
											  //if (n_lines >0)
											  //{
													 //for (zz=0;zz<n_lines ;zz++)
													 //{
														//CALLAPI(AOM_ask_value_string(lines[zz],"bl_line_name",&mod_name));	
														//printf("\nmod_name:%s\n",mod_name);	fflush(stdout);
														//CALLAPI(BOM_line_ask_all_child_lines(lines[zz], &sub_n_lines, &sub_lines));
														//for (zt=0;zt<sub_n_lines ;zt++)
														//{
																//CALLAPI(AOM_ask_value_string(sub_lines[zt],"bl_line_name",&mod_name));	
																//printf("\n\t\t\tmod_name:%s\n",mod_name);	fflush(stdout);															 
				
														//}  		
													 //}  

													 //printf("\n inside bom_window-----444\n"); fflush(stdout);			
													 //BOM_window_apply_variant_configuration(bom_window,1,&svrTag);
													 //CALLAPI(BOM_window_hide_unconfigured(bom_window));				
													 //CALLAPI(BOM_window_hide_variants(bom_window));  

													 ////	CALLAPI(BOM_window_show_variants(bom_window));
													 ////	CALLAPI(BOM_create_window_variant_config(bom_window,1,&bom_variant_config));
													 ////	CALLAPI(BOM_variant_config_apply (bom_variant_config));			
															
																			
													 //printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
													 //BOM_window_ask_variant_rules(bom_window,&vcount,&bomvariantlist); 
													 //if(bomvariantlist != NULLTAG)
													 //{													
																			    //printf( "\n SVR is applied:..\n");																		 
																				//printf("\nSVR count:%d\n",vcount);	fflush(stdout);
													 //}
													 //else
													 //{
																				//printf( "\n NO SVR applied in BOM window ..\n");
													 //}		
												
													 //CALLAPI(BOM_window_ask_is_modified(bom_window,&modB));
													 //if(modB)
													 //{
																				//printf( "\n modified bom window:..\n");
													 //}
													 //else
													 //{
																				//printf( "\n not modfiifed ..\n");
													 //}														
													
													//CALLAPI(BOM_line_ask_all_child_lines(top_line1, &n_lines1, &lines1));
													//printf("\n After applying SVR all childlines: %d \n", n_lines1); fflush(stdout);	
													//if (n_lines1 >0)
													//{
															//for (zz=0;zz<n_lines1 ;zz++)
															//{
																//CALLAPI(AOM_ask_value_string(lines1[zz],"bl_line_name",&mod_name));	
																//printf("\nmod_name:%s\n",mod_name);	fflush(stdout);
																	//CALLAPI(BOM_line_ask_all_child_lines(lines1[zz], &sub_n_lines1, &sub_lines1));
																	//for (zt=0;zt<sub_n_lines1 ;zt++)
																	//{
																		//CALLAPI(AOM_ask_value_string(sub_lines1[zt],"bl_line_name",&mod_name));	
																		//printf("\n\t\t\tmod_name:%s\n",mod_name);	fflush(stdout);															 
						
																	//}  		
															//}  
													//}

	
											

											//////////////////////////////////////////////////
											///*

											//CALLAPI(BOM_create_window (&bom_window2)); 
											//CALLAPI(CFM_find( "Latest Working", &rule2));
											//CALLAPI(BOM_set_window_config_rule(bom_window2,rule2));
											//CALLAPI(BOM_set_window_pack_all(bom_window2, TRUE)); 
										////	CALLAPI(BOM_set_window_top_line( bom_window2, NULLTAG, list_of_WSO_tags[0], NULLTAG, &top_line)); 										
											//*/

											 
										//}	
									//}


								
									////MEM_free(list_of_WSO_tags);
								//}



 		      
			  //tag_t bomcompare = NULLTAG;;
			  //tag_t rule2 = NULLTAG;
			  //int ii=0;

			  
			//tag_t			bom_window2				=NULLTAG;
			//CALLAPI(BOM_create_window (&bom_window2)); 
			//CALLAPI(CFM_find( "Latest Working", &rule2));
			//CALLAPI(BOM_set_window_config_rule(bom_window2,rule2));
			//CALLAPI(BOM_set_window_pack_all(bom_window2, TRUE)); 
			//CALLAPI(BOM_set_window_top_line( bom_window2, NULLTAG, list_of_WSO_tags[0], NULLTAG, &top_line));   		    	 

		   	//CALLAPI(BOM_compare_execute(NULLTAG, top_line, top_line1,"IMAN_bcm_ext_var_level", BOM_compare_output_report));  
      
		//int report_length = 0;
		//char** report_lines = 0;
        //tag_t* report_items = 0;
        //BOM_compare_report(top_line, &report_length, &report_lines,&report_items);
	    //for(ii = 0; ii < report_length; ii++)
		//{
				//printf("\n %s \n", report_lines[ii]);
		//}
		if (fd)
		{
			fclose(fd);
		}
		MEM_free(list_of_WSO_tags);
		BOM_close_window(bom_window_SVR);
		BOM_close_window(bom_window);
 		 
	

	return status;	
} 
//---------------------------------------------------------------------------------------------------------
 
 