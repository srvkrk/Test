#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <unidefs.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <property/prop.h>
#include <pie/pie.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <textsrv/textserver.h>
#include <string.h>
#include <epm/cr_effectivity.h>

#include <tccore/aom.h>
#include <tccore/tctype.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/cr_action_handlers.h>
#include <epm/epm.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <ict/ict_userservice.h>
#include <tccore/item.h>
#include <itk/bmf.h>
#include <itk/mem.h>
#include <property/propdesc.h>
#include <sa/sa.h>
#include <server_exits/user_server_exits.h>
#include <ss/ss_errors.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tccore/custom.h>
#include <tccore/tctype.h>
#include <user_exits/epm_toolkit_utils.h>
#include <user_exits/user_exit_msg.h>
#include <user_exits/user_exits.h>
#include <server_exits/user_server_exits.h>
#include <bom/bom.h>
#include <tc/folder.h>
#define NUM_ENTRIES 1
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;
//static void print_bom (tag_t line,tag_t Parent, int depth,FILE *fdf,FILE *fus,char *inid);
//static void print_data_item(tag_t this_itemRev,char *attr);
//char* subString (char* mainStringf ,int fromCharf,int toCharf);

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
	const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}



 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}

// ./tm_SVR_Compare_Custom_Report -Platform=X4 -Input_1=54428724000R_NR -Input_2=54422324R,E,1 -RevisionRule="ERC release and above" -u=loader -g=dba -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf
extern int ITK_user_main (int argc, char ** argv )
{
    int     status=0; 
 
	char *SVR = NULL;
	char *svr_name = NULL;
	 
 	int ifail =0;
 	int DateConvFlag =0;
	
	 
	
	int n_modes=0;
	char **mode_names = NULL;

 
		char*			mod_name_SVR				=NULL;  
		char*			mod_name_VC				=NULL;  
		char*			SVRname				=NULL;  
		char*			FileDown				=NULL;  
		char*			DataSetName				=NULL;  
		tag_t			bom_window				=NULLTAG;
		tag_t			bom_window_VC				=NULLTAG;
		tag_t			bom_window_SVR				=NULLTAG;
		tag_t			top_line_VC				=NULLTAG; 
		tag_t			top_line_SVR				=NULLTAG; 
		tag_t			rule					=NULLTAG;
		tag_t			PrdConfigTag			=NULLTAG;
		tag_t			objTypeTagDi			=NULLTAG;
		tag_t			primaryTag				=NULLTAG;
		tag_t			PlatformTag				=NULLTAG;
		tag_t			PlatformTagRev				=NULLTAG;
		tag_t			SvrTag				=NULLTAG;
		//tag_t			*SvrTagS			=NULL;

		tag_t           *bom_variant_config=NULL;
		tag_t           *bomvariantlist_SVR=NULL;
		FILE	*fd;
		

		tag_t *Primary_objects1 = NULL;
		tag_t *Primary_objects2 = NULL;
		tag_t *secondary_objects1 = NULL;
		tag_t *lines_VC = NULL;
		tag_t *sub_lines_VC = NULL;
		tag_t *sub_lines_SVR = NULL;

		char   type_name3[TCTYPE_name_size_c+1];

		WSO_search_criteria_t  	criteria1;
		WSO_search_criteria_t  	criteria2;
		int number_found1=0,number_found2=0,countS=0;
		tag_t *list_of_WSO_tags1=NULL;
		tag_t *list_of_WSO_tags2=NULL;
		int i=0,k=0,n_lines=0,zz=0,n_lines1=0, vcount=0,countDep=0,vcountSVR=0,SvrFolder_Size=0,sub_n_lines_VC=0,sub_n_lines_SVR=0,n_lines_SVR_Cnt=0;
		int sub_n_lines=0,sub_n_lines1=0, zt=0,countDep1=0,n_lines_VC_Cnt=0,zx=0,zy=0,flagMatch=0,K=0;
		logical modB=FALSE;
		logical modB_SVR=FALSE;

		 tag_t 	*bomvariantlist = NULLTAG;
		 tag_t 	*SvrTagS = NULLTAG;
		 tag_t 	*lines_SVR = NULLTAG;
		 tag_t 	SvrTag1 = NULLTAG;
		 tag_t 	SvrTag2 = NULLTAG;
		 tag_t 	FolderTag = NULLTAG;
		 tag_t 	InpModTag1 = NULLTAG;
		 tag_t 	InpModTag2 = NULLTAG;
		 tag_t 	Plt_tag = NULLTAG;
		 tag_t 	PlatformRevTag = NULLTAG;
		 tag_t	LINE_VC[1000];
		 tag_t	LINE_SVR[1000];
		 tag_t	CommonModule[1000];
		 //char* SVR_Name= NULLTAG;
		 //char* SvrName_Dup= (char *) MEM_alloc ( 100);
		 
		char	SVR_Name_Type[WSO_name_size_c+1] ;
		char	SVR_Name[WSO_name_size_c+1] ;
		char	SvrName_Dup[WSO_name_size_c+1] ;
		char*	 VcName			= NULL;
		char*	 SVR1			= NULL;
		char*	 SVR2			= NULL;
		char*	 Usr			= NULL;
		char*	 Pass			= NULL;
		char*	 Group			= NULL;
		char*	 Platform			= NULL;
		char*	 RevisionRule        			= NULL;
		char*	 Date_Eff_Str        			= NULL;
		char*	 mod_name_SVR_desc   			= NULL;
		char*	 mod_name_SVR_descDup   			= NULL;
		char*	 mod_name_SVR_Add    			= NULL;
		char*	 mod_name_common_desc			= NULL;
		char*	 mod_name_common_descDup			= NULL;
		char*	 mod_name_common_Add 			= NULL;

		
		tag_t *tags_found = NULL;
		
		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
		char **values = (char **) MEM_alloc(1 * sizeof(char *));
		tag_t *closurerule = NULL;
		int rulefound=0;
		tag_t close_tag=NULLTAG;
		tag_t queryTag= NULLTAG;
		tag_t VehRev2= NULLTAG;
		tag_t VehRev1= NULLTAG;
		tag_t *rev2= NULLTAG;
		tag_t *rev1= NULLTAG;
	    char **rulename = NULL;
		char **rulevalue = NULL;
	    char **rulename_SVR = NULL;
		char **rulevalue_SVR = NULL;

		 int ReqCnt=0;
		 int VehFlag2=0;
		 int VehFlag1=0;
		 int resultCount1=0;
		 int resultCount2=0;
		 int sub_n_lines_VC_Cnt=0;
		 int sub_n_lines_SVR_Cnt=0;

   



	 //tm_SVR_Compare_Custom_Report -Input_1=54422224000R_C -Input_2=54422224R,B,1  -Platform=X4 -RevisionRule="ERC release and above"
	 //tm_SVR_Compare_Custom_Report -Input_1=54422324000R_C -Input_2=54422324R,B,1  -Platform=X4 -RevisionRule="ERC release and above"
	 //ftp(1):/home/uadev/devgroups/saurabh/SvrCompare/tm_SVR_Compare_Custom_Report.c
	 SVR1 = (char *) MEM_alloc (sizeof (char) * 128);
	 SVR2 = (char *) MEM_alloc (sizeof (char) * 128);
	 Usr = (char *) MEM_alloc (sizeof (char) * 128);
	 Pass = (char *) MEM_alloc (sizeof (char) * 128);
	 Group = (char *) MEM_alloc (sizeof (char) * 128);
	 FileDown = (char *) MEM_alloc (sizeof (char) * 128);
	 DataSetName = (char *) MEM_alloc (sizeof (char) * 128);
     SVR1 = ITK_ask_cli_argument("-Input_1=");
     SVR2 = ITK_ask_cli_argument("-Input_2=");
     //Usr = ITK_ask_cli_argument("-u=loader");
    // Pass = ITK_ask_cli_argument("-pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf");
    // Group = ITK_ask_cli_argument("-g=dba");
     Platform = ITK_ask_cli_argument("-Platform=");
	 RevisionRule 	= ITK_ask_cli_argument("-RevisionRule=");
	 Date_Eff_Str 	= ITK_ask_cli_argument("-EffectiveDate=");

	 ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ); 
	 ITK_CALL(ITK_auto_login( ));
	 //if( ITK_init_module(Usr,Pass,Group)!=ITK_ok) ;
	 
	 //ITK_CALL(ITK_init_module("ercpsup" ,"ERCpsup2019","")) ;
     

	 char			Data[100]					= "";
	char			outputFile[300]				= "";

	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	//for output file with date.
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.csv",Data);

	



	 char*	 Veh_1			= NULL;
	 char*	 Veh_Rev_1			= NULL;
	 char*	 Veh_Seq_1			= NULL;

	 char*	 Veh_2			= NULL;
	 char*	 Veh_Rev_2			= NULL;
	 char*	 Veh_Seq_2			= NULL;

	 char*	 itemRevSeq1			= NULL;
	 char*	 mod_name_common			= NULL;
	 char*	 mod_name_VC_desc			= NULL;
	 char*	 mod_name_VC_descDup			= NULL;
	 char*	 mod_name_VC_Add			= NULL;
	 date_t	 Date_Eff;
	 

	 //DateConvFlag=DATE_convert_formatted_string_to_date(Date_Eff_Str,"%m/%d/%Y",false,true,&Date_Eff);


	 
	
	/////////////////////////////Platform is Queryed/////////////////////////////////////////
	char **valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));
	int n_entriesP = 1;
	char *qry_entries10[1] = {"ID"};
	int n_tags_found = 0;
	if(QRY_find("Platform", &PlatformTag));
	if (PlatformTag) { printf("\nFound Query PlatformTag"); fflush(stdout); 
	}else {
		printf("\nNot Found Query PlatformTag"); fflush(stdout);
		return status;
	}
	valuesPlatfrom[0] = Platform;
	if(QRY_execute(PlatformTag, n_entriesP, qry_entries10, valuesPlatfrom, &n_tags_found, &tags_found));
	printf("\n\n\n Platform count is-------->  : %d",n_tags_found);fflush(stdout);
	if (n_tags_found > 0)
	{
		Plt_tag = tags_found[0];
		ITK_CALL(ITEM_ask_latest_rev(Plt_tag , &PlatformRevTag));
	}else { printf ("\n Platform tag not found\n"); fflush(stdout);	}


	//CALLAPI(CFM_find( "Latest Working", &rule));
	

	CALLAPI(PIE_find_closure_rules( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
    printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = closurerule[0];
		printf ("closure rule found \n");fflush(stdout);
	}
	
	if (tc_strstr(SVR1,","))
	{
		VehFlag1=1;
		Veh_1=tc_strtok(SVR1,",");
		Veh_Rev_1 = tc_strtok(NULL,",");
		Veh_Seq_1 = tc_strtok(NULL,",");
		printf ("Vehicle 1 is  <%s>   <%s>   <%s>\n",Veh_1,Veh_Rev_1,Veh_Seq_1);fflush(stdout);

		if (Veh_1 && Veh_Rev_1 && Veh_Seq_1)
		{
			printf("\n\t Inside Part Rev Seq 1.... "); fflush(stdout);
			if(QRY_find("DesignRevision Sequence", &queryTag));
			printf("\n\t After QRY_find .... "); fflush(stdout);

			if (queryTag)
			{
				printf("Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
			}
			else
			{
				printf("Not Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
				
			}
			char *qry_entries4[2] = {"Revision","ID"};
			char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

			char* itemRevSeq1 = NULL;
			itemRevSeq1=(char *) MEM_alloc(32);
			tc_strcpy(itemRevSeq1,Veh_Rev_1);
			tc_strcat(itemRevSeq1,"?");
			tc_strcat(itemRevSeq1,Veh_Seq_1);

			qry_values[0] = itemRevSeq1 ;
			qry_values[1] = Veh_1;
			int n_entries = 2;

			if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount1, &rev1));

			if (resultCount1 == 0)
			{
				printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", Veh_1);
				
			}
			else 
			{
				VehRev1 = rev1[0];
				printf ( "More than one items matched with id %s\n",Veh_1 );
				
			}
			
		}
	}
	else
	{
		WSOM_clear_search_criteria(&criteria1);
		strcpy(criteria1.name,SVR1);
		strcpy(criteria1.class_name,"VariantRule");
		CALLAPI(WSOM_search(criteria1, &number_found1, &list_of_WSO_tags1));
		printf("\n\n\t\t SVR1 Count found : %d\n",number_found1);fflush(stdout);
		if ( number_found1 > 0)
		{
			SvrTag1=list_of_WSO_tags1[0];
		}
		
	}


	if (tc_strstr(SVR2,","))
	{
		VehFlag2=1;
		Veh_2=tc_strtok(SVR2,",");
		Veh_Rev_2 = tc_strtok(NULL,",");
		Veh_Seq_2 = tc_strtok(NULL,",");
		printf ("Vehicle 1 is  <%s>   <%s>   <%s>\n",Veh_2,Veh_Rev_2,Veh_Seq_2);fflush(stdout);
		if (Veh_2 && Veh_Rev_2 && Veh_Seq_2)
		{
			printf("\n\t Inside Part Rev Seq 2 .... "); fflush(stdout);
			if(QRY_find("DesignRevision Sequence", &queryTag));
			printf("\n\t After QRY_find .... "); fflush(stdout);

			if (queryTag)
			{
				printf("Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
			}
			else
			{
				printf("Not Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
				return status;
			}
			char *qry_entries4[2] = {"Revision","ID"};
			char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

			char* itemRevSeq2 = NULL;
			itemRevSeq2=(char *) MEM_alloc(32);
			tc_strcpy(itemRevSeq2,Veh_Rev_2);
			tc_strcat(itemRevSeq2,"?");
			tc_strcat(itemRevSeq2,Veh_Seq_2);

			qry_values[0] = itemRevSeq2 ;
			qry_values[1] = Veh_2;
			int n_entries = 2;

			if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount2, &rev2));

			if (resultCount2 == 0)
			{
				printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", Veh_2);fflush(stdout);
				
			}
			else
			{
				printf ( "More than one items matched with id2 %s\n", Veh_2);fflush(stdout);
				VehRev2 = rev2[0];
				
			}
			
		}
	}
	else
	{
		char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
		printf ( "SVRd with id %s\n", SVR2);fflush(stdout);
		char *qry_entries[1] = {"Name"};
		tag_t	queryTag	= NULLTAG;
		int n_entries = 1;
		int resultCount=0;
		tag_t *svrobj=NULLTAG;
		if(QRY_find("VariantRule1", &queryTag));
		qry_values[0] = SVR2;

		
		if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &svrobj));
		printf("\n resultCount : %d\n", resultCount); fflush(stdout);

		if (resultCount >0)
		{
			SvrTag2=svrobj[0];
		}

//		WSOM_clear_search_criteria(&criteria2);
//		strcpy(criteria2.name,SVR2);
//		strcpy(criteria2.class_name,"VariantRule");
//		CALLAPI(WSOM_search(criteria2, &number_found2, &list_of_WSO_tags2));
//		printf("\n\n\t\t SVR2 Count found : %d\n",number_found2);fflush(stdout);
//		if (number_found2 >0)
//		{
//			SvrTag2=list_of_WSO_tags2[0];
//		}

		
	}



	printf ( "File name1\n");fflush(stdout);
	tc_strcpy(FileDown,"/tmp/");
	tc_strcat(FileDown,SVR1);
	tc_strcat(FileDown,"_");
	tc_strcat(FileDown,SVR2);
	tc_strcat(FileDown,"_BomCompare1.csv");
	printf ( "File name2 %s\n",FileDown);fflush(stdout);

	tc_strcpy(DataSetName,"ModuleCompare_");
	tc_strcat(DataSetName,SVR1);
	tc_strcat(DataSetName,"_");
	tc_strcat(DataSetName,SVR2);
	


	fd=fopen(FileDown,"w");
	fprintf(fd,"Module Comparision Report,\n");
	fprintf(fd,"Module name,Module Desc,Module Address,\n\n");
	if(fd==NULL)
	{
		printf("\nError in opening the file \n");fflush(stdout);
		
	}
		



	if (bom_window_VC)
	{
		bom_window_VC=NULLTAG;
	}
	if (top_line_VC)
	{
		top_line_VC=NULLTAG;
	}
	


	CALLAPI(BOM_create_window(&bom_window_VC));

	printf ( "BOM window created1\n");fflush(stdout);
	
	if (VehFlag1==0)
	{
		CALLAPI(BOM_window_set_closure_rule( bom_window_VC,close_tag, 0, rulename_SVR,rulevalue_SVR ));
		CALLAPI(CFM_find("ERC release and above", &rule));
	}
	else
	{	
		CALLAPI(CFM_find( RevisionRule, &rule ));
		if (!DateConvFlag)
		{
			//CALLAPI(CFM_rule_set_date( rule, Date_Eff )); //sks
		}
		
	}
	printf ( "BOM window config rule1\n");fflush(stdout);
	CALLAPI(BOM_set_window_config_rule( bom_window_VC, rule));
	CALLAPI(BOM_set_window_pack_all(bom_window_VC, TRUE));
	printf ( "BOM window pack all\n");fflush(stdout);
	

	if (VehFlag1==0)
	{
		CALLAPI(BOM_set_window_top_line( bom_window_VC, NULLTAG,PlatformRevTag , NULLTAG, &top_line_VC));
		printf ( "BOM window set top line SVR\n");fflush(stdout);
		BOM_window_apply_variant_configuration(bom_window_VC,1,&SvrTag1);
		printf ( "BOM window variant apply\n");fflush(stdout);
		CALLAPI(BOM_window_hide_unconfigured(bom_window_VC));				
		CALLAPI(BOM_window_hide_variants(bom_window_VC));  
		printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
		BOM_window_ask_variant_rules(bom_window_VC,&vcount,&bomvariantlist); 
		if(vcount > 0)
		{													
			printf( "\n SVR is applied:..\n");																		 
			printf("\nSVR count:%d\n",vcount);	fflush(stdout);
		}
		else
		{
			printf( "\n NO SVR applied in BOM window ..\n");
		}	
		CALLAPI(BOM_window_ask_is_modified(bom_window_VC,&modB));
		if(modB)
		{
			printf( "\n modified bom window:..\n");
		}
		else
		{
			printf( "\n not modfiifed ..\n");
		}	
		
	}
	else
	{
		CALLAPI(BOM_set_window_top_line( bom_window_VC, NULLTAG,VehRev1 , NULLTAG, &top_line_VC));
		printf ( "BOM window set top line Veh\n");fflush(stdout);
		
	}
	CALLAPI(BOM_line_ask_all_child_lines(top_line_VC, &n_lines_VC_Cnt, &lines_VC));
	printf("\n Total BOM Lines 1 %d\n",n_lines_VC_Cnt); fflush(stdout);
	
	int CNT_VC1=0;
	int TotalModuleInput1=0;
	if (VehFlag1==0)
	{
		for (zx=0;zx<n_lines_VC_Cnt ;zx++)
		{
			char*			BL_ID				=NULL;
			char*			Item_Revision_str				=NULL;
			CALLAPI(AOM_ask_value_string(lines_VC[zx],"bl_item_item_id",&BL_ID));
			printf("\n Total BOM Lines of arch node %d  %d  <%s>\n",zx,sub_n_lines_VC_Cnt,BL_ID); fflush(stdout);
			if (tc_strcmp(BL_ID,"X4MT3Z01") && tc_strcmp(BL_ID,"X4MC1D01"))
			{
				
				CALLAPI(BOM_line_ask_all_child_lines(lines_VC[zx], &sub_n_lines_VC_Cnt, &sub_lines_VC));
				
				for (zy=0;zy<sub_n_lines_VC_Cnt ;zy++)
				{

					CALLAPI(AOM_ask_value_string(sub_lines_VC[zy],"bl_item_item_id",&BL_ID));
					printf("\n \t\t Total BOM Lines of Module %d  <%s>\n",zy,BL_ID); fflush(stdout);
					
					CALLAPI(AOM_ask_value_string(sub_lines_VC[zy], "bl_rev_item_revision_id", &Item_Revision_str));
					printf("\n2] Item_Revision_str Module =%s\n",Item_Revision_str);fflush(stdout);

					LINE_VC[CNT_VC1]=sub_lines_VC[zy];
					CNT_VC1++;
				}
			}
		}
		printf("\n Total Modules in Input 1  %d\n",CNT_VC1); fflush(stdout);
		TotalModuleInput1=CNT_VC1;
	}
	else
	{
		printf("\n Total Modules in Input 1  %d\n",n_lines_VC_Cnt); fflush(stdout);
		TotalModuleInput1=n_lines_VC_Cnt;
	}
	
	


	/// Find the platform


	CALLAPI(BOM_create_window(&bom_window_SVR));
	
	if (VehFlag2==0)
	{
		CALLAPI(BOM_window_set_closure_rule( bom_window_SVR,close_tag, 0, rulename_SVR,rulevalue_SVR ));
		CALLAPI(CFM_find("ERC release and above", &rule));
	}
	else
	{
		CALLAPI(CFM_find( RevisionRule, &rule ));

		if (!DateConvFlag)
		{
			//CALLAPI(CFM_rule_set_date( rule, Date_Eff )); //sks
		}
		
	}
	CALLAPI(BOM_set_window_config_rule( bom_window_SVR, rule));	
	CALLAPI(BOM_set_window_pack_all(bom_window_SVR, TRUE));  
	

	if (VehFlag2==0)
	{
		CALLAPI(BOM_set_window_top_line( bom_window_SVR, NULLTAG,PlatformRevTag , NULLTAG, &top_line_SVR));
		BOM_window_apply_variant_configuration(bom_window_SVR,1,&SvrTag2);
		CALLAPI(BOM_window_hide_unconfigured(bom_window_SVR));				
		CALLAPI(BOM_window_hide_variants(bom_window_SVR));  
		printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
		BOM_window_ask_variant_rules(bom_window_SVR,&vcount,&bomvariantlist); 
		if(vcount > 0)
		{													
			printf( "\n SVR is applied:..\n");																		 
			printf("\nSVR count:%d\n",vcount);	fflush(stdout);
		}
		else
		{
			printf( "\n NO SVR applied in BOM window ..\n");
		}	
		CALLAPI(BOM_window_ask_is_modified(bom_window_SVR,&modB));
		if(modB)
		{
			printf( "\n modified bom window:..\n");
		}
		else
		{
			printf( "\n not modfiifed ..\n");
		}	
	}
	else
	{
		CALLAPI(BOM_set_window_top_line( bom_window_SVR, NULLTAG,VehRev2 , NULLTAG, &top_line_SVR));
	}
	printf("\n inside bom_window-----444\n"); fflush(stdout);	
	
	CALLAPI(BOM_line_ask_all_child_lines(top_line_SVR, &n_lines_SVR_Cnt, &lines_SVR));

	printf("\n Total BOM Lines 2 %d\n",n_lines_SVR_Cnt); fflush(stdout);	


	int CNT_SVR1=0;
	int TotalModuleInput2=0;
	if (VehFlag2==0)
	{
		for (zx=0;zx<n_lines_SVR_Cnt ;zx++)
		{
			printf("\n Arch Node %d\n",zx); fflush(stdout);

			char*			BL_ID				=NULL;
			char*			Item_Revision_str				=NULL;
			CALLAPI(AOM_ask_value_string(lines_SVR[zx],"bl_item_item_id",&BL_ID));
			printf("\n Total BOM Lines of arch node SVR 2 %d  %d  <%s>\n",zx,sub_n_lines_SVR_Cnt,BL_ID); fflush(stdout);
			if (tc_strcmp(BL_ID,"X4MT3Z01") && tc_strcmp(BL_ID,"X4MC1D01"))
			{
				CALLAPI(BOM_line_ask_all_child_lines(lines_SVR[zx], &sub_n_lines_SVR_Cnt, &sub_lines_SVR));
				for (zy=0;zy<sub_n_lines_SVR_Cnt ;zy++)
				{
					LINE_SVR[CNT_SVR1]=sub_lines_SVR[zy];
					CNT_SVR1++;
					printf("\n Total Modules 2 %d\n",CNT_SVR1); fflush(stdout);
				}
			}
		}
		printf("\n Total Modules 2 %d\n",CNT_SVR1); fflush(stdout);
		TotalModuleInput2=CNT_SVR1;
	}
	else
	{
		printf("\n Total Modules in Input 2  %d\n",n_lines_SVR_Cnt); fflush(stdout);
		TotalModuleInput2=n_lines_SVR_Cnt;

	}


	int CMcnt=0;
	int I1=0;
	int I2=0;





	if (VehFlag1==0)
	{
		fprintf(fd,"Module only availabe with SVR %s\n",SVR1);
	}
	else
	{
		fprintf(fd,"Module only availabe with Vehicle %s;%s;%s\n",Veh_1,Veh_Rev_1,Veh_Seq_1);
	}

	
	for (I1=0;I1<TotalModuleInput1;I1++)
	{
		if (VehFlag1==0)
		{
			InpModTag1=LINE_VC[I1];
		}
		else
		{
			InpModTag1=lines_VC[I1];
		}


		CALLAPI(AOM_ask_value_string(InpModTag1,"bl_item_item_id",&mod_name_VC));
		flagMatch=0;

		for (I2=0;I2<TotalModuleInput2;I2++)
		{
			if (VehFlag2==0)
			{
				InpModTag2=LINE_SVR[I2];
			}
			else
			{
				InpModTag2=lines_SVR[I2];
			}
			CALLAPI(AOM_ask_value_string(InpModTag2,"bl_item_item_id",&mod_name_SVR));
			if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
			{
				flagMatch=1;
				CommonModule[CMcnt]=InpModTag2;
				CMcnt++;
				break;
			}
		}

		if (flagMatch==0)
		{
			
			
			CALLAPI(AOM_ask_value_string(InpModTag1,"bl_item_object_desc",&mod_name_VC_desc));
			STRNG_replace_str(mod_name_VC_desc,",",";",&mod_name_VC_descDup);
			CALLAPI(AOM_ask_value_string(InpModTag1,"bl_Design Revision_t5_ModuleAddress",&mod_name_VC_Add));
			printf("\n\t\t\t difference in BOM for SVR=========================================>>> %s\n",mod_name_VC,mod_name_VC_descDup,mod_name_VC_Add);	fflush(stdout);
			fprintf(fd,"%s,%s,%s,\n",mod_name_VC,mod_name_VC_descDup,mod_name_VC_Add);
		}

	}

	if (VehFlag2==0)
	{
		fprintf(fd,"\n\nModule only availabe with SVR %s\n",SVR2);
	}
	else
	{
		fprintf(fd,"\n\nModule only availabe with Vehicle %s;%s;%s\n",Veh_2,Veh_Rev_2,Veh_Seq_2);
	}

	for (I2=0;I2<TotalModuleInput2;I2++)
	{
		if (VehFlag2==0)
		{
			InpModTag2=LINE_SVR[I2];
		}
		else
		{
			InpModTag2=lines_SVR[I2];
		}


		CALLAPI(AOM_ask_value_string(InpModTag2,"bl_item_item_id",&mod_name_SVR));
		flagMatch=0;

		for (I1=0;I1<TotalModuleInput1;I1++)
		{
			if (VehFlag1==0)
			{
				InpModTag1=LINE_VC[I1];
			}
			else
			{
				InpModTag1=lines_VC[I1];
			}
			CALLAPI(AOM_ask_value_string(InpModTag1,"bl_item_item_id",&mod_name_VC));
			if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
			{
				flagMatch=1;
				break;
			}
		}

		if (flagMatch==0)
		{
			CALLAPI(AOM_ask_value_string(InpModTag2,"bl_item_object_desc",&mod_name_SVR_desc));
			STRNG_replace_str(mod_name_SVR_desc,",",";",&mod_name_SVR_descDup);
			CALLAPI(AOM_ask_value_string(InpModTag2,"bl_Design Revision_t5_ModuleAddress",&mod_name_SVR_Add));
			printf("\n\t\t\t difference in BOM for SVR=========================================>>> %s,%s,%s\n",mod_name_SVR,mod_name_SVR_descDup,mod_name_SVR_Add);	fflush(stdout);
			fprintf(fd,"%s,%s,%s,\n",mod_name_SVR,mod_name_SVR_descDup,mod_name_SVR_Add);
		}

	}

	int I3=0;



	fprintf(fd,"\n\nCommon Module \n");

	for (I3=0;I3<CMcnt;I3++)
	{
		CALLAPI(AOM_ask_value_string(CommonModule[I3],"bl_item_item_id",&mod_name_common));
		CALLAPI(AOM_ask_value_string(CommonModule[I3],"bl_item_object_desc",&mod_name_common_desc));
		STRNG_replace_str(mod_name_common_desc,",",";",&mod_name_common_descDup);
		CALLAPI(AOM_ask_value_string(CommonModule[I3],"bl_Design Revision_t5_ModuleAddress",&mod_name_common_Add));
		printf("\n\t\t\t common================================>>> %s,%s,%s\n",mod_name_common,mod_name_common_descDup,mod_name_common_Add);	fflush(stdout);
		fprintf(fd,"%s,%s,%s,\n",mod_name_common,mod_name_common_descDup,mod_name_common_Add);
	}

		
	if (fd)
	{
		fclose(fd);
	}


	
	tag_t msExcelType	= NULLTAG;
	tag_t ExcelDataset	= NULLTAG;
	tag_t ExlLatestDat_t	= NULLTAG;

	printf("\n going for dataset\n");fflush(stdout);
	//CALLAPI(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
	CALLAPI(AE_find_datasettype2("MSExcel",&msExcelType));
	if(msExcelType == NULLTAG)
	{
		printf("\n Could not find Dataset\n");fflush(stdout);
	}
	printf("\n Dataset Creation, ");fflush(stdout);
	CALLAPI(AE_create_dataset_with_id(msExcelType,DataSetName,"Module Comparision Report","","",&ExcelDataset));
	CALLAPI(AE_save_myself(ExcelDataset));
	//printf(" Relation Creation, ");fflush(stdout);
	//(GRM_create_relation(DmlTag,ExcelDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
	//printf(" done, ");fflush(stdout);
	//CALLAPI(AOM_load(dml_Ref_Rel_t));
	//printf(" load, ");fflush(stdout);
	//CALLAPI(GRM_save_relation(dml_Ref_Rel_t));
	printf(" save, ");fflush(stdout);
	CALLAPI(AE_ask_dataset_latest_rev(ExcelDataset,&ExlLatestDat_t));
	printf(" lst rev, ");fflush(stdout);
	CALLAPI(AOM_refresh(ExlLatestDat_t,TRUE));
	CALLAPI(AE_import_named_ref(ExlLatestDat_t,"excel",FileDown,NULL,SS_BINARY));
	printf(" name ref, ");fflush(stdout);
	CALLAPI(AE_save_myself(ExlLatestDat_t));
	CALLAPI(AE_save_myself(ExcelDataset));
	//CALLAPI(AOM_refresh (DmlTag, 0));
	

	int n_entry = 1;
	int rsltCount = 0;
	tag_t qryTag = NULLTAG;
	tag_t *CntrolObjectTag = NULLTAG;
	char *qry_entry[1] = {"Name"};
	char **qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));


	if(QRY_find("folder custom", &qryTag));
	if (qryTag)
	{
		//printf("\n ERCVali:Found Query ControlObjects \n");fflush(stdout);
		qry_values2[0] = "VC_SVR_Comparision_Report";
		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag));
		printf("\t  rsltCount :%d:", rsltCount); fflush(stdout);
		if(rsltCount > 0)
		{

		CALLAPI(AOM_lock(CntrolObjectTag[0]));
		CALLAPI(FL_insert(CntrolObjectTag[0],ExlLatestDat_t,999));
		CALLAPI(AOM_save(CntrolObjectTag[0]));
		CALLAPI(AOM_unlock(CntrolObjectTag[0]));
		CALLAPI(AOM_refresh(CntrolObjectTag[0],1));
			

		}
	}


	remove(FileDown);
	
	//if( FL_user_update_newstuff_folder(ExcelDataset) );

MEM_free(list_of_WSO_tags1);
MEM_free(list_of_WSO_tags2);
BOM_close_window(bom_window_VC);
 		 
	

	return status;	
} 
//---------------------------------------------------------------------------------------------------------
 
 