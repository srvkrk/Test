#!/bin/bash
TO_ADDRESS="kt.ttl@tatatmotors.com"
FROM_ADDRESS="kt.ttl@tatamotors.com"
SUBJ="I am attaching the Attachments"
BODY=/user/testcmi/devgroups/Kirtikumar/mailBody.txt
ATTACH=/user/testcmi/devgroups/Kirtikumar/abc.txt
CC_LIST="kt.ttl@tatamotors.com"
mail -s $SUBJ -A$ATTACH -c $CC_LIST $TO_ADDRESS -- -r $FROM_ADDRESS < $BODY
