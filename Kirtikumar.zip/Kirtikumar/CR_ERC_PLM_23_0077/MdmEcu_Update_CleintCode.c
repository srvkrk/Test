/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();

	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{

	int status;
	int AttachmentCount=0;
	tag_t *attachments		= NULLTAG;
	tag_t rootTask			= NULLTAG;
	tag_t VCMDU_DMLTag		= NULLTAG;

	char *parent_name	= NULL;
	char *dmlNo			= NULL;
	char *dmlProj		= NULL;
	char *username		= NULL;
	char *object_type	= NULL;

	int taskcount = 0, partcount=0;
	int a = 0, t = 0, p = 0, d = 0, c = 0;
	int a1 =0;
	int b1 =0;
	int c1 =0;
	int refCount = 0, vcCount = 0, ColCount = 0;

	int vcCount_t5_ECUtypeV		= 0;
	int vcCount_t5_EcuReadWrtV  = 0;
	int vcCount_t5_SwPartTypeV  = 0;

	int SvrCount = 0;
	int vehCount = 0;
	int vehColCount = 0;

	tag_t *DmlTasksTags		= NULLTAG;
	tag_t *RefItemTags		= NULLTAG;
	tag_t *PartTags			= NULLTAG;
	tag_t *ChildTags		= NULLTAG;
	tag_t *ColPartTags		= NULLTAG;
	tag_t *SVRTags			= NULLTAG;
	tag_t *opSVRTags		= NULLTAG;

	tag_t PartTag			= NULLTAG;
	tag_t PartMasterTag		= NULLTAG;
	tag_t VarientQryTag		= NULLTAG;


	char *FormName		= NULL;

	char *PartNum		= NULL;
	char *PartNumDup	= NULL;
	char *PartRev		= NULL;
	char *PartRevDup	= NULL;
	char *part_type		= NULL;
	char *part_typeDup	= NULL;
	char *vehNumber		= NULL;
	char *vehOldDesc	= NULL;
	char *vehNewDesc	= NULL;
	char *ColorInd		= NULL;
	char *ColorIndDup	= NULL;
	char *RefObjtype	= NULL;
	
	char **Vc_Desc		= NULL;
	char** vcDesc_t5_SwPartType =NULL;
	char** vcDesc_t5_EcuType =NULL;
	char** vcDesc_t5_EPReadable =NULL;

 	int ist5_AppForEOL  = 0;
	int ist5_EcuType    = 0;
	int ist5_EPReadable = 0;
	int ist5_SwPartType = 0;

	char *ApplicationVal		= (char *) MEM_alloc(40);
	char *ECUTypeValue			= (char *) MEM_alloc(40);
	char *ECUTReadWriteValue    = (char *) MEM_alloc(40);
	char *ECUSWTypeValue		= (char *) MEM_alloc(40);

	ITK_CALL(POM_get_user_id (&username));
	printf("\n In MdmEcu_Update Session User is : %s\n",username); fflush(stdout);

	if((tc_strcmp(username,"infodba") !=0))
	{
		//ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

		//ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		//printf("\n In MdmEcu_Update Parent Name: %s",parent_name);fflush(stdout);

		//ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
		//printf("\n  In MdmEcu_Update Target Attachment:%d",AttachmentCount);fflush(stdout);

		int		count			=0;
		tag_t	item_tag		= NULLTAG;
		tag_t	*rev_list		= NULL;
		char* ErrorText =NULL;

		ifail = ITEM_find_item (item_id, &item_tag);
		CHECK_FAIL;
	
		ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
		CHECK_FAIL;	

		if(count > 0)
		{
			for(a=0;a<count;a++)
			{
				char* DML_No=NULL;

				AOM_ask_value_string(rev_list[0],"object_type",&object_type);
				printf("\n In MdmEcu_Update Object_type is  :%s\n",object_type);fflush(stdout);


				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					VCMDU_DMLTag = rev_list[0];

					AOM_ask_value_string(VCMDU_DMLTag,"item_id",&DML_No);
					printf("\n In MdmEcu_Update DML_No is :%s\n",DML_No);fflush(stdout);

					ITK_CALL(AOM_ask_value_tags(VCMDU_DMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
					printf("\n In MdmEcu_Update DML Task Count : %d\n",taskcount);fflush(stdout);

					ITK_CALL(AOM_ask_value_tags(VCMDU_DMLTag,"IMAN_reference",&refCount,&RefItemTags));
					printf("\n In MdmEcu_Update Count  :%d \n",refCount);fflush(stdout);

					if (refCount>0)
					{
						for ( c=0; c<refCount ;c++ )
						{
							AOM_ask_value_string(RefItemTags[c],"object_type",&RefObjtype);
							printf("\n Check In MDM Update DML IMAN_reference object Type : %s\n",RefObjtype);fflush(stdout);

							if (tc_strcmp(RefObjtype,"T5_EcuUpd")==0)
							{
								printf("\n Inside T5_EcuUpd find for the t5_mdm IMAN_reference object Type : %s\n",RefObjtype);fflush(stdout);

								ITK_CALL(AOM_ask_value_strings(RefItemTags[c],"t5_AppForEOLV",&vcCount,&Vc_Desc));
								printf("\n t5_AppForEOLV  Count : %d\n",vcCount);fflush(stdout);

								ITK_CALL(AOM_ask_value_strings(RefItemTags[c],"t5_ECUtypeV",&vcCount_t5_ECUtypeV,&vcDesc_t5_EcuType));
								printf("\n t5_ECUtypeV  Count : %d\n",vcCount_t5_ECUtypeV);fflush(stdout);
								
								ITK_CALL(AOM_ask_value_strings(RefItemTags[c],"t5_EcuReadWrtV",&vcCount_t5_EcuReadWrtV,&vcDesc_t5_EPReadable));
								printf("\n t5_EcuReadWrtV  Count : %d\n",vcCount_t5_EcuReadWrtV);fflush(stdout);
							
								ITK_CALL(AOM_ask_value_strings(RefItemTags[c],"t5_SwPartTypeV",&vcCount_t5_SwPartTypeV,&vcDesc_t5_SwPartType));
								printf("\n t5_SwPartTypeV  Count : %d\n",vcCount_t5_SwPartTypeV);fflush(stdout);
								
								//break;
							}
							else
							{continue;}
						}
					}

				//This is for t5_AppForEOLV
				if (taskcount>0 && vcCount>0)
					{
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMReferences",&partcount,&PartTags)); //Change References

							printf("\n In MdmEcu_Update No of Parts found = %d\n",partcount);
							if (partcount>0 && vcCount>0)
							{
								printf("\n Inside part found for updation  = %d\n",partcount);
								for(p=0;p<partcount;p++)
								{
									PartTag = PartTags[p];
									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_AppForEOL",&part_type));
									tc_strdup(part_type,&part_typeDup);

									printf("\nPart %s,%s,%s\n",PartNumDup,PartRevDup,part_typeDup);

									for (d=0;d<vcCount;d++)
									{
										if(tc_strstr(Vc_Desc[d],PartNumDup)!=NULL)
										{
											printf("\n Details : %s \n",Vc_Desc[d]);
											vehNumber	= tc_strtok( Vc_Desc[d], "$" );

											ApplicationVal	= tc_strtok( NULL, "$" );
											printf("\n Part Number : %s ,ApplicationVal : %s\n",vehNumber,ApplicationVal);fflush(stdout);

											if (tc_strcmp(ApplicationVal,"Both")==0)
											{
												printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ApplicationVal,"");
												tc_strcat(ApplicationVal,"BothES");
												printf("\n Application Value: %s",ApplicationVal);fflush(stdout);
											}
											else if (tc_strcmp(ApplicationVal,"NA")==0)
											{
												printf("\n as value is NA \n");fflush(stdout);
												tc_strcpy(ApplicationVal,"");
												tc_strcat(ApplicationVal,"NotApp");
												printf("\n Application Value: %s",ApplicationVal);fflush(stdout);
											}
											else if (tc_strcmp(ApplicationVal,"Service")==0)
											{
												printf("\n as value is Service \n");fflush(stdout);
												tc_strcpy(ApplicationVal,"");
												tc_strcat(ApplicationVal,"Service");
												printf("\n Application Value: %s",ApplicationVal);fflush(stdout);
											}
											else if (tc_strcmp(ApplicationVal,"EOL")==0)
											{
												printf("\n as value is EOL \n");fflush(stdout);
												tc_strcpy(ApplicationVal,"");
												tc_strcat(ApplicationVal,"EOL");
												printf("\n Application Value: %s",ApplicationVal);fflush(stdout);
											}
											else if (tc_strcmp(ApplicationVal,"Trial")==0)
											{
												printf("\n as value is Trial \n");fflush(stdout);
												tc_strcpy(ApplicationVal,"");
												tc_strcat(ApplicationVal,"Trial");
												printf("\n Application Value: %s",ApplicationVal);fflush(stdout);
											}
											else if (tc_strcmp(ApplicationVal,"Trial-fail")==0)
											{
												printf("\n as value is Trial -fail \n");fflush(stdout);
												tc_strcpy(ApplicationVal,"");
												tc_strcat(ApplicationVal,"TrialF");
												printf("\n Application Value: %s",ApplicationVal);fflush(stdout);
											}
											else
											{
												printf("\n Invalid value of Application EOL %s \n", ApplicationVal);fflush(stdout);
												//EMH_clear_errors();
												//EMH_store_error_s1(EMH_severity_error,ITK_err,"Please Enter Correct Value.You have Entered Invalid Value");
												//return 1;
											}

											AOM_lock(PartTag);
											ITK_CALL(AOM_set_value_string(PartTag,"t5_AppForEOL",ApplicationVal));
											AOM_save(PartTag);
											ITK_CALL(AOM_refresh(PartTag, TRUE));
											printf("\n Applicability  Desc Updated %s,%s\n",PartNumDup,PartRevDup);fflush(stdout);



										}

									}

								}

							}


						}

					}
					//This is for t5_ECUtypeV
					if (taskcount>0 && vcCount_t5_ECUtypeV>0)
					{
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMReferences",&partcount,&PartTags)); //Change References
							printf("\n In MdmEcu_Update No of Parts found ,I am in t5_ECUtypeV= %d\n",partcount);
							if (partcount>0 && vcCount_t5_ECUtypeV>0)
							{
								for(p=0;p<partcount;p++)
								{
									PartTag = PartTags[p];
									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_EcuType",&part_type));
									tc_strdup(part_type,&part_typeDup);

									printf("\nPart %s,%s,%s, I am in t5_ECUtypeV\n",PartNumDup,PartRevDup,part_typeDup);
									for (a1=0;a1<vcCount_t5_ECUtypeV;a1++)
									{
										if(tc_strstr(vcDesc_t5_EcuType[a1],PartNumDup)!=NULL)
										{
											printf("\n Details : %s, I am in t5_ECUtypeV \n",vcDesc_t5_EcuType[a1]);
											vehNumber	= tc_strtok( vcDesc_t5_EcuType[a1], "$" );

											ECUTypeValue	= tc_strtok( NULL, "$" );
											printf("\n Part Number : %s ,ECUTypeValue : %s\n",vehNumber,ECUTypeValue);fflush(stdout);

											if(strlen(ECUTypeValue) > 0)
											{
													AOM_lock(PartTag);
													ITK_CALL(AOM_set_value_string(PartTag,"t5_EcuType",ECUTypeValue));
													AOM_save(PartTag);
													ITK_CALL(AOM_refresh(PartTag, TRUE));
													printf("\n ECUTypeValue Updated %s,%s\n",PartNumDup,PartRevDup);fflush(stdout);

											}
											else
											{
														printf("\n Invalid value of ECUTypeValue %s \n", ECUTypeValue);fflush(stdout);
														//EMH_clear_errors();
														//EMH_store_error_s1(EMH_severity_error,ITK_err,"Please Enter Correct Value.You have Entered Invalid Value");
														//return 1;
											}
										
											
											
										}

									}
								}

							}

						}
					
					}
					//This is for t5_EcuReadWrtV
					if (taskcount>0 && vcCount_t5_EcuReadWrtV>0)
					{
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMReferences",&partcount,&PartTags)); //Change References
							printf("\n In MdmEcu_Update No of Parts found ,I am in t5_EcuReadWrtV= %d\n",partcount);
							if (partcount>0 && vcCount_t5_EcuReadWrtV>0)
							{
								for(p=0;p<partcount;p++)
								{
									PartTag = PartTags[p];
									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_EPReadable",&part_type));
									tc_strdup(part_type,&part_typeDup);

									printf("\nPart %s,%s,%s, I am in t5_EcuReadWrtV=\n",PartNumDup,PartRevDup,part_typeDup);

									for (b1=0;b1<vcCount_t5_EcuReadWrtV;b1++)
									{
										if(tc_strstr(vcDesc_t5_EPReadable[b1],PartNumDup)!=NULL)
										{
											printf("\n Details : %s, I am in t5_EcuReadWrtV \n",vcDesc_t5_EPReadable[b1]);
											vehNumber	= tc_strtok( vcDesc_t5_EPReadable[b1], "$" );

											ECUTReadWriteValue	= tc_strtok( NULL, "$" );
											printf("\n Part Number : %s ,ECUTReadWriteValue : %s\n",vehNumber,ECUTReadWriteValue);fflush(stdout);

											if (tc_strcmp(ECUTReadWriteValue,"Read Only")==0 || tc_strcmp(ECUTReadWriteValue,"Write")==0   || tc_strcmp(ECUTReadWriteValue,"Both")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												//tc_strcpy(ECUTReadWriteValue,"");
												//tc_strcat(ECUTReadWriteValue,"CAL");
												//printf("\n ECUTReadWriteValue Value: %s",ECUTReadWriteValue);fflush(stdout);

												AOM_lock(PartTag);
												ITK_CALL(AOM_set_value_string(PartTag,"t5_EPReadable",ECUTReadWriteValue));
												AOM_save(PartTag);
												ITK_CALL(AOM_refresh(PartTag, TRUE));
												printf("\n ECUTReadWriteValue Updated %s,%s\n",PartNumDup,PartRevDup);fflush(stdout);
											}
											else
											{
												printf("\n Invalid value of ECUTReadWriteValue %s \n", ECUTReadWriteValue);fflush(stdout);
												//EMH_clear_errors();
												//EMH_store_error_s1(EMH_severity_error,ITK_err,"Please Enter Correct Value.You have Entered Invalid Value");
												//return 1;

											}
											

										}
									}

								}

							}


						}

					}
					//This is for t5_SwPartTypeV
					if (taskcount>0 && vcCount_t5_SwPartTypeV>0)
					{
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMReferences",&partcount,&PartTags)); //Change References
							printf("\n In MdmEcu_Update No of Parts found ,I am in t5_SwPartTypeV= %d\n",partcount);
							if (partcount>0 && vcCount_t5_SwPartTypeV>0)
							{
								for(p=0;p<partcount;p++)
								{
									PartTag = PartTags[p];
									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_SwPartType",&part_type));
									tc_strdup(part_type,&part_typeDup);

									printf("\nPart %s,%s,%s ,I am in t5_SwPartTypeV\n",PartNumDup,PartRevDup,part_typeDup);

									for (c1=0;c1<vcCount_t5_SwPartTypeV;c1++)
									{
										if(tc_strstr(vcDesc_t5_SwPartType[c1],PartNumDup)!=NULL)
										{
											printf("\n Details : %s, I am in t5_SwPartTypeV \n",vcDesc_t5_SwPartType[c1]);
											vehNumber	= tc_strtok( vcDesc_t5_SwPartType[c1], "$" );

											ECUSWTypeValue		= tc_strtok( NULL, "$" );
											printf("\n Part Number : %s ,ECUSWTypeValue	 : %s\n",vehNumber,ECUSWTypeValue);fflush(stdout);

											if (tc_strcmp(ECUSWTypeValue,"Calibration Software")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"CAL");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Configuration Software")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"CFG");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Parameter")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"PRM");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Container")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"CON");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Sticker")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"STK");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Hardware Control Module")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"HWC");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Homologation ID/Vehicle CAL ID")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"VCI");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Application Software")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"APP");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Basic Software")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"BAS");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Primary Boot Loader")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"PBL");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Secondary Boot Loader")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"SBL");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else if (tc_strcmp(ECUSWTypeValue,"Others")==0)
											{
												//printf("\n as value is Both \n");fflush(stdout);
												tc_strcpy(ECUSWTypeValue,"");
												tc_strcat(ECUSWTypeValue,"Others");
												printf("\n ECUSWTypeValue Value: %s",ECUSWTypeValue);fflush(stdout);
											}
											else 
											{
												printf("\n Invalid value of ECUSWTypeValue %s \n", ECUSWTypeValue);fflush(stdout);
												//EMH_clear_errors();
												//EMH_store_error_s1(EMH_severity_error,ITK_err,"Please Enter Correct Value.You have Entered Invalid Value");
												//return 1;
											}

											
											AOM_lock(PartTag);
											ITK_CALL(AOM_set_value_string(PartTag,"t5_SwPartType",ECUSWTypeValue));
											AOM_save(PartTag);
											ITK_CALL(AOM_refresh(PartTag, TRUE));
											printf("\n ECUSWTypeValue Updated %s,%s\n",PartNumDup,PartRevDup);fflush(stdout);


										}

									}

								}
							}


						}

					}


				}

			}

		}

		printf("\n OUTSIDE BEFORE RETURN \n");fflush(stdout);
	}

	printf ("\n--------------MdmEcu_Update=Completed--------------------\n");fflush(stdout);

	return ifail;
}
