#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* user_id 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			* module					= NULL;
	char			* BL_FormulaEdited          = NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
		user_id			= ITK_ask_cli_argument("-u=");
		password 		= ITK_ask_cli_argument("-pf=");
		group 			= ITK_ask_cli_argument("-g=");
		module 			= ITK_ask_cli_argument("-module=");
	//BL_FormulaEdited 	= ITK_ask_cli_argument("-BL_FormulaEdited=");
	//file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(user_id)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail =ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	//Variables::

	char *child_rev_id = NULL;
 	char *child_rev_seq = NULL;
	char *child_rev_stat = NULL;
	char *child_objType = NULL;
	char *mod_addr = NULL;
 	int			revid			= 0;
 	int			revseq			= 0;
 	int			revstat			= 0;
 	int			blobjType		= 0;
	int			PartTypeI		= 0;
 	int			PartTypeCI		= 0;
 	int			modadd			= 0;
	int	ifail = 0;
	char *username;
	char *group_name;
	char *userid;
	tag_t user_tag=NULLTAG;
	tag_t group_tag=NULLTAG;
	char *designer_role = NULL;
	char *manager_role = NULL;
	int designer_found=0,manager_found=0;
	tag_t * 	list;
	tag_t window=NULLTAG;
	tag_t top_bom_line=NULLTAG;
	//ass915906
	int     fndidlatest			=0;
	char   *child_fndid_latest	= NULL;
	int		Variantflag			= 0;
 	int		Variantflag1		= 0;
	char *child_PartType = NULL;
	char *child_ColorIndicator = NULL;

	//tag_t	qry_t1	= NULLTAG;
	tag_t	Module	= NULLTAG;
	tag_t	ModuleIDRev	= NULLTAG;
	tag_t	moduleRev =NULLTAG;
	tag_t	moduleTag =NULLTAG;
	//char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
	//int n_entr1 = 1;
	//char    *qry_entr1[1]  = {"SYSCD"};
	//int rsltCunt1=0;
	//tag_t *CntrlObjTag1=NULLTAG;
	char	*info1r	= NULL;
	char	*ModuleGroup_Name	= NULL;

	tag_t windowW1= NULLTAG;

	tag_t bomline = NULLTAG;

	///////////Module Variant Formula  Validation////////

		int parent_item_seq=0;
		tag_t itemrev =NULLTAG;
		char* Trgt_bl_formula=NULL;
		char*  Part_no =NULL;
		int n_parents=0;
		int *levels = 0;
		tag_t *parents = NULL;
		int jd=0;
		tag_t ArchAssyTag =NULLTAG;
		char* Arch_obj= NULL;
		tag_t ArchobjTypeTag=NULLTAG;
		char   Archtype_name[TCTYPE_name_size_c+1];
		//tag_t window=NULLTAG;
		tag_t  rule=NULLTAG;
		tag_t top_line =NULLTAG;
		int n_BL=0;
		tag_t *children1= NULL;
		int p1=0;
		tag_t Childobject=NULLTAG;
		char* child_item_id = NULL;
		char* child_bl_formula_cmp = NULL;
		char* child_bl_formula = NULL;
		tag_t  	master =	NULLTAG;
		char*  Arch_obj_str = NULL;
		tag_t relation_dep=	NULLTAG;
		int countConfigCtx = 0;
		tag_t  *ConfigCtxSecObject	= NULLTAG;
		tag_t ConfigCtx = NULLTAG;
		tag_t  ConfigCtxObjTypeTag=NULLTAG;
		char   Config_CtxType[TCTYPE_name_size_c+1];
		char*	 SmVCContext			= NULL;
		char*	 SmCrIDContext			= NULL;
		char*	 ContextobjName			= NULL;

		tag_t	qry_t1	= NULLTAG;
		char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
		int n_entr1 = 1;
		char    *qry_entr1[1]  = {"SYSCD"};
		int rsltCunt1=0;
		tag_t *CntrlObjTag1=NULLTAG;

		tag_t	queryTag	= NULLTAG;
		char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
		int n_entries = 1;
		int resultCount=0;
		char *qry_entries[1] = {"ID"};
		
	
		tag_t *ConId  = NULL;
		int j=0;
		tag_t Optfmly_tag = NULLTAG;

		int dmlIncnt =0;
		int CmpleteVrf=0;
		char *username_vf =NULL;
		tag_t user_tag_vf =NULLTAG;

		BL_FormulaEdited ="([Teamcenter]AGGREGATE = POWERTRAIN AND [Teamcenter]'RAIN LIGHT SENSOR COMPATIBILITY' = Petrol+CNG AND [Teamcenter]ARMREST = YES)";

		printf("\n!!!!!!!!!!!!!!!!! check_vf_module!!!!!!!!!!  <<<%s>>>\t\n",BL_FormulaEdited);fflush(stdout);

		POM_ask_group(&group_name, &group_tag);
		printf ("Logged in group:%s\n",group_name);fflush(stdout);

		ITEM_find_item(module,&moduleTag);
		ITEM_ask_latest_rev(moduleTag,&moduleRev);
		
		ifail = BOM_create_window (&windowW1);
		CHECK_FAIL;
		ifail = BOM_set_window_top_line (windowW1, null_tag, moduleRev, null_tag, &bomline); 
		CHECK_FAIL;

		if(bomline != NULLTAG)
		{
				printf("\n Validate VF\n");fflush(stdout);
				if(BOM_line_look_up_attribute("bl_item_item_id",&revid))PrintErrorStack();
				if(BOM_line_look_up_attribute("bl_rev_item_revision_id",&revseq))PrintErrorStack();
				if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat))PrintErrorStack();
				if(BOM_line_look_up_attribute ("bl_item_object_type",&blobjType))PrintErrorStack();
				if(BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&PartTypeI))PrintErrorStack();
				if(BOM_line_look_up_attribute ("bl_Design Revision_t5_ColourInd",&PartTypeCI))PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline,revid,&child_rev_id))PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline,revseq,&child_rev_seq))PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline, revstat, &child_rev_stat))PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline, blobjType, &child_objType))PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline, PartTypeI, &child_PartType))PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline, PartTypeCI, &child_ColorIndicator))PrintErrorStack();

				if(BOM_line_ask_attribute_string(bomline, PartTypeCI, &child_ColorIndicator))PrintErrorStack();
				printf("\n Part:%s %s Status:%s  child_objType <%s> \n",child_rev_id,child_rev_seq,child_rev_stat,child_objType);fflush(stdout);

				if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
				if(BOM_line_ask_attribute_string(bomline,fndidlatest,&child_fndid_latest));
				printf("\n child_fndid_latest===============>>>>>> %s\n",child_fndid_latest);fflush(stdout);

				if (tc_strcmp(child_objType,"Colour Part")!=0)
				{
					if(BOM_line_ask_window(bomline,&window))PrintErrorStack();
					if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();

					/////////Module Variant Formula  Validation////////
					if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq))PrintErrorStack();
					if(BOM_line_ask_attribute_tag(bomline, parent_item_seq, &itemrev))PrintErrorStack();

					if(AOM_ask_value_string(itemrev,"item_id",&Part_no))PrintErrorStack();
					printf("\n\n\t CP Part_no  is :%s",Part_no);fflush(stdout);

					if(PS_where_used_all(itemrev,1,&n_parents,&levels,&parents))PrintErrorStack();
					printf("\n\t CP where_used count of objects are Drag Drop : %d",n_parents); fflush(stdout); // 1

					if(top_bom_line != NULLTAG)
					{
						if(BOM_line_ask_attribute_tag(top_bom_line, parent_item_seq, &ArchAssyTag))PrintErrorStack();
						printf("\n\t Inside top bomline"); fflush(stdout);

						  if(ArchAssyTag)
						  {
							  if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))PrintErrorStack();
							  printf("\n\t Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

								if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))PrintErrorStack();
								if(TCTYPE_ask_name(ArchobjTypeTag,Archtype_name))PrintErrorStack();
								printf("\n\t Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

								if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
								{
									 printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
									 if(ITEM_ask_item_of_rev(ArchAssyTag, &master));
									 if(AOM_ask_value_string(master,"item_id",&Arch_obj_str))PrintErrorStack();
									 printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

									 if(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep))PrintErrorStack();
									 if(relation_dep != NULLTAG)
									 {
										printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
									 }

									 if(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject))PrintErrorStack();
									 printf("\n\t Configuration Context count is : %d",countConfigCtx);

								}


						  }

					}

				}

		}


	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


