#include <time.h>
#include <tc/tc.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <itk/mem.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pom/pom/pom.h>
#include <tccore/grm.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <unistd.h>
#include <iostream>

int GetFeatureDetails(char *);
FILE *filePointer;
using namespace std;



int ITK_user_main(int argc, char ** argv) {

    char * user = NULL;
    char * pw = NULL;
    char * grp = NULL;
    char * FeatureName = NULL;

	char * 	Errtext;

	//File code
	time_t 	now;
	struct 	tm when;
	char	Data[100]= "";
	char	outputFile[200]= "";
	char	DataSetName[300]   = "Comp_Report_";
	
	tag_t textType			= NULLTAG;
	tag_t textDataset		= NULLTAG;
	tag_t textLatestDat_t	= NULLTAG;
	tag_t			msWordType				= NULLTAG;
	
	
	tag_t		qryTag					= NULLTAG;
	char		*qry_entry[1]			= {"Name"};
	char		**qry_values2			= (char **) MEM_alloc(10 * sizeof(char *));

	int			n_entry					= 1;
	int			rsltCount				= 0;
	tag_t		*CntrolObjectTag		= NULLTAG;
	

	int ifail = ITK_ok;
    int status = 0;
    //user			= ITK_ask_cli_argument("-u=");
   // pw				= ITK_ask_cli_argument("-p=");
    //grp				= ITK_ask_cli_argument("-g=");
    FeatureName		= ITK_ask_cli_argument("-featureName=");

   
    cout << "Input Feature Name=: "<< FeatureName << endl;
    cout << "Before Login......................\n";
	
	int i;

	time(&now);
	when = *localtime(&now);

	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	strcat(DataSetName,Data );
	sprintf(outputFile,"/tmp/Report_%s.txt",Data);
	//sprintf(outputFile,"/user/testcmi/devgroups/Kirtikumar/CMP_REPORT_%s.txt",Data);
	

	

	filePointer = fopen(outputFile, "a");
	if (filePointer == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
	{
			printf("File opened successfully.\n");
	}
	fprintf(filePointer,"%s\n","-----------------------------------------------------------------------------------------------------------------"); fflush(filePointer);
	fprintf(filePointer,"%s%s%s\n","Sr No.         ","Option Family Name                        ","Configurator Contexts Linked"); fflush(filePointer);
	fprintf(filePointer,"%s\n","-----------------------------------------------------------------------------------------------------------------"); fflush(filePointer);

	
   // status = ITK_init_module(user, pw, grp);
	status = TC_auto_login();
    if (status == 0) 
	{
			 cout << "Currently Login s";
			 ifail = GetFeatureDetails(FeatureName);
    } else 
	{
			 cout << "Invalid User Name or Password,Please Enter correct";
    }


	printf("\n going for dataset\n");fflush(stdout);

	ifail= AE_find_datasettype2("Text",&textType);
	if(ifail == ITK_ok)
		{
			printf("Dataset Type Fond");fflush(stdout);
			
	}
	else {
			//printf("\n Could not find Dataset\n");fflush(stdout);
			
	}
		printf("\n File Path %s\n",outputFile);fflush(stdout);
		ifail=	AE_create_dataset_with_id(textType,DataSetName,"Comparison Report","","",&textDataset);
		printf("\n After Dataset Create \n");fflush(stdout);

		if(ifail == ITK_ok) 
		{
				
				cout <<"Dataset created.\n";

		} else {
		
			cout <<"Dataset Not created.\n";
			
		}
		ifail=AE_save_myself(textDataset);
		printf("\n After AE_save_myself\n");fflush(stdout);
		ifail=AE_ask_dataset_latest_rev(textDataset,&textLatestDat_t);
		printf("\n After AE_ask_dataset_latest_rev \n");fflush(stdout);
		ifail=AOM_refresh(textLatestDat_t,TRUE);
	
		
		ifail=AE_import_named_ref(textLatestDat_t,"Text",outputFile,NULL,SS_TEXT);

		if(ifail == ITK_ok) { 

			cout <<"Name Ref uploaded.\n";
		
		} else {

			EMH_ask_error_text(ifail,&Errtext);
			printf("\nName Ref No loaded , because of this error:--> n%s",Errtext);
			cout <<"Name Ref NOT uploaded.\n";
		}

		AOM_save(textLatestDat_t);
		AOM_refresh(textLatestDat_t, FALSE);
		printf("\n After save \n");fflush(stdout);
		AOM_unload(textLatestDat_t);
		printf("\n After Unload \n");fflush(stdout);
		if(FL_user_update_newstuff_folder(textLatestDat_t)!=ITK_ok);
		printf("\n After Newstuff \n");fflush(stdout);


		// Folder Creation and Update Code START

		if(QRY_find2("folder custom", &qryTag));
		if (qryTag)
		{
			printf("\n ERCVali:Found Query ControlObjects \n");fflush(stdout);
			qry_values2[0] = "CMP_CONTEXT_REPORT";
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag));
			printf("\t  rsltCount for folder:%d:", rsltCount); fflush(stdout);
			if(rsltCount > 0)
			{

			AOM_lock(CntrolObjectTag[0]);
			FL_insert(CntrolObjectTag[0],textLatestDat_t,999);
			AOM_save(CntrolObjectTag[0]);
			AOM_unlock(CntrolObjectTag[0]);
			AOM_refresh(CntrolObjectTag[0],1);
				

			}
		}
		//remove(outputFile);
		fclose(filePointer);

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
}
int GetFeatureDetails(char * FeatureName)
{	
	int ifail = ITK_ok;
	int resultCount = 0;
	int n_entries = 2;
	int i;
	int j;
	int num;

	char *object_name;
	char *owner_name;
	char *objectType;
	char *configContextName;

	tag_t *configContext;
	tag_t owning_user;

	tag_t * FeaturesTag = NULL;

	char *userEntryName = "Name";

	char *userEntryType = "Type";
	char * userEntryTypeValue = "Feature";

	char**  entries = NULL;
	char**  values  = NULL;

	char* ownerName;

	tag_t queryTag;

	entries		= (char**) MEM_alloc (sizeof(char*) * 200);
	values		= (char**) MEM_alloc (sizeof(char*) * 200);


	entries[0] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(userEntryName) + 200));
	values[0]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(FeatureName) + 200));
			
	entries[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(userEntryType) + 200));
	values[1]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(userEntryTypeValue) + 200));

	tc_strcpy(entries[0], "");	
	tc_strcpy(entries[0], userEntryName);
	tc_strcpy(values[0], "");	
	tc_strcpy(values[0], FeatureName);
	
	tc_strcpy(entries[1], "");
	tc_strcpy(entries[1], userEntryType);
	tc_strcpy(values[1], "");	
	tc_strcpy(values[1], userEntryTypeValue);

	ifail = QRY_find2("General...", & queryTag);
	if (ifail != ITK_ok)
	{
          cout << "\n*** Error with Finding Query ***\n";
          return ifail;
     }
	 if (queryTag) 
	 {
				cout << "Found Query \n";
     } else {
                cout << "*** Query Not Found *** \n";
                return ifail;
            }

	ifail = QRY_execute(queryTag, n_entries, entries, values, & resultCount, & FeaturesTag);
    printf("\nNo. of Features found -- %d\n", resultCount);
	
	
	for(i=0; i<resultCount; i++)
	{
		//ifail = AOM_ask_value_string(FeaturesTag[i],"object_type",&objectType);
		//printf("\Object  type  -- %s\n", objectType);

		ifail = AOM_ask_value_string(FeaturesTag[i],"object_name",&object_name);
		ifail = AOM_ask_owner(FeaturesTag[i],&owning_user);
		ifail = AOM_ask_name(owning_user,&ownerName);
	
		printf("\-----Feature Name--------%s\n", object_name);
		printf("\-----Current Owner-------%s\n", ownerName);

		fprintf(filePointer,"%d\t\t\t%s\t\t\t",i+1,object_name); fflush(filePointer);
		//fprintf(filePointer,"%d%s\t\t\t",i,object_name); fflush(filePointer);
		
		ifail = AOM_ask_value_tags(FeaturesTag[i],"cfg0ProductItems",&num,&configContext);

		//printf("\No of string properties found %d\n", num);
		
		printf("\Configurator Context under Option values are:\n");
		for (j=0;j<num;j++) 
		{
				//fprintf(filePointer,",,"); fflush(filePointer);
				ifail = AOM_ask_value_string(configContext[j],"object_string",&configContextName);
				//ifail = AOM_ask_value_string(configContext[j],"object_name",&configContextName);
				fprintf(filePointer,"%s\n\t\t\t\t\t\t", configContextName); fflush(filePointer);				
				printf("%s\n", configContextName);

		}fprintf(filePointer,"\n");

		fprintf(filePointer,"\n-----------------------------------------------------------------------------------------------------------------\n"); fflush(filePointer);

		//ifail = AOM_ask_value_string(FeaturesTag[i],"object_string",&owner_name);
		//printf("\nFeature Owner  -- %s\n",owner_name);

		//
		
		//ifail = AOM_ask_value_strings(FeaturesTag[i],"cfg0ProductItems",&num,&configContext);

		//printf("\nFeature Name  -- %s\n", object_name);
		//for (j=0;j<num;j++)
		//{
		//	printf("Configurator Context is : -->%s\n",configContext[j]);
		//}
	}
			
} 
