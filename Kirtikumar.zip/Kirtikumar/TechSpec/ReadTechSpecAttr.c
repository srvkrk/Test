	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;
#define STRSIZE 200
#define NUMWORDS 11


int read_value_from_file(char*);
int check_rel_status(char*);
char* removeUnwantedChar(char*,char*);
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 						= NULL;
	char			* password						= NULL;
	char			* group							= NULL;
	char			* vc							= NULL;
	char			Data[100]						= "";
	char			outputFile[200]					= "";
	char			* inputFile						= "";
	char			* inputFileHasPara				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	vc 				= ITK_ask_cli_argument("-vc=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(vc)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\n\t Login Successfull.....!!\n");
			printf("\n\t Welcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\n\tUser is not Privileged Admin User \n\n");
		return -1;
	}	
		
	//ifail = read_value_from_file(vc);
	ifail = check_rel_status(vc);
	CHECK_FAIL;
		
	printf("\n\t End of program.....!!\n");
	printf("\n\t *********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

int check_rel_status(char* item_id)
{

	int	  status			= ITK_ok;
	int	  ic				= 0;
	int   t5NoEcuDupint		= 0;
	int	  nAttributes		= 0;
	int   na				= 0;

	char* ErrorText			= NULL;
	char* VCMasterTagObjStr	= NULL;
	char* vcLatestRevID		= NULL;
	char* attributeValue	= NULL;
	char* t5NoEcuDup		= NULL;

	char** attributeNames	= NULL;
	char** attributeValues	= NULL;


	tag_t VCMasterTag		= NULLTAG;
	tag_t VCLatestRev		= NULLTAG;
	tag_t Design_rev_cls_tag    = NULLTAG;
	
	int theAttributeCount =0;
	int *theAttributeIds ;
	char 			**theAttributeNames;
	int *theAttributeValCounts=0;
	char***       theAttributeValues;
	char***       theAttributeOptimizedUnits;
	char* 	attrId 					= NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	int i,j,x=0;
	int TotVCAttrCount=0;
	//struct VCAttrDetails VCAttrDetailsList[5000];
	int *vcattr = 0;


	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;
	int  	n_shared_sites;
	char	** shared_sites ;



	printf("\n\t Input Item ID is: %s\n\t",item_id);

	ITKCALL(ITEM_find_item(item_id,&VCMasterTag));
	ifail = AOM_ask_value_string(VCMasterTag,"object_string",&VCMasterTagObjStr);
	printf("\n VCMasterTagObjStr  is  = [%s]\n", VCMasterTagObjStr);fflush(stdout);

	ITEM_ask_latest_rev(VCMasterTag,&VCLatestRev);
	AOM_ask_value_string(VCLatestRev,"item_revision_id",&vcLatestRevID);
	printf("\n vcLatestRevID  is  = [%s]\n", vcLatestRevID);fflush(stdout);



	 ITKCALL(ICS_ask_classification_object(VCMasterTag,&Design_rev_cls_tag));
	//ITKCALL(ICS_ask_attribute_value	(Design_rev_cls_tag,"Total number of ECUs",&attributeValue));
	//printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);

	ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
	if(theAttributeCount>0)
	{
			for(i=0;i<theAttributeCount;i++)
			{
				TotVCAttrCount=TotVCAttrCount+theAttributeCount;

				sprintf(attrId,"%d",theAttributeIds[i]);
				//printf("\n attrId:[%s]",attrId);fflush(stdout);

				tc_strcpy(attributeNameDup,"");
				tc_strcpy(attributeNameDup,theAttributeNames[i]);

				//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);

				if(tc_strcmp(attributeNameDup,"Total number of ECUs")==0)
				{
					
					tc_strcpy(attributeValueDup,"");

					for(x=0;x<theAttributeValCounts[i];x++)
					{
						//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
						tc_strcat(attributeValueDup,theAttributeValues[i][x]);
						//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
					}
					printf("\n theAttribute Name :[%s]",attributeNameDup,i);fflush(stdout);
					printf("\n attrId:[%s]",attrId);fflush(stdout);
					printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);

				}

			}
			//printf("\n total VC attribute value:[%d] ",TotVCAttrCount);fflush(stdout);
			//printf("\n total vcattr value:[%d] ",*vcattr);fflush(stdout);
	}

	
//	ITKCALL(ICS_ask_attributes_of_classification_obj(Design_rev_cls_tag,&nAttributes,&attributeNames,&attributeValues));
//	printf("\n nAttributes  is  = [%d]\n", nAttributes);fflush(stdout);
//
//	for(na = 0 ; na < nAttributes; na++)
//	{
//		printf("\n attributeNames  is  = [%s]\n", attributeNames[na]);fflush(stdout);
//		printf("\n attributeValues  is  = [%s]\n", attributeValues[na]);fflush(stdout);
//
//	}

//	ITKCALL(ICS_keylov_get_keylov("Total number of ECUs",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
//	printf("\n VC validation key_lov_name===[%s]--- n_lov_entries===[%d]--- options===[%d]\n",key_lov_name,n_lov_entries,options); fflush(stdout);
//
//	for(ic=0;ic<n_lov_entries;ic++)
//	{
//		printf("\n lov_keys=[%s] lov_values=[%s]\n",lov_keys[ic],lov_values[ic]); fflush(stdout);
//		ITKCALL(ICS_ask_classification_object(VCMasterTag,&Design_rev_cls_tag));
//		ITKCALL(ICS_ask_attribute_value	(Design_rev_cls_tag,"8226",&attributeValue));
//		printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);
//
//		if(tc_strcmp(attributeValue,lov_keys[ic])==0)
//		{
//			printf("\n Value of classified object: \n Mascot lov_keys=%s lov_values=%s",lov_keys[ic],lov_values[ic]); fflush(stdout);
//
//			t5NoEcuDup		   =(char *) MEM_alloc(20);
//			tc_strcpy(t5NoEcuDup,lov_values[ic]);
//
//			printf("\n******************** ECU COUNT IS ************ =%s",t5NoEcuDup); fflush(stdout);//10
//
//			t5NoEcuDupint=atoi(t5NoEcuDup);
//
//			printf("\n *******************final ECU COUNT is t5NoEcuDupint *********** =%d",t5NoEcuDupint); fflush(stdout);//10
//
//		}
//
//
//	}

	return status;
	
}