/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   DML WF
*  Code                 :   tm_WeightRollupValid.c
*  Created on			:   12/01/2022
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*	1.	12/01/2022					Mohan Tayade		Unladen weight and Rolled up comparision and validation.
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_WeightRollupValid(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	tag_t *taskAttachments=NULLTAG;
	char	*PlntToPlnt		=  NULL;
	char	*TskNm			=  NULL;
	char	*FromPlnt		=  NULL;
	char	*rev_idd		=  NULL;
	char	*DMLtype		=  NULL;
	char	*TaskDsgGrp		=  NULL;
	char	*Partno		=  NULL;
	char	*Toplnt		=  NULL;
	char	*sDMLDR		=  NULL;
	char	*PartMstr_no		=  NULL;
	char	*rel_status		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	int	rel_status_cunt	=  0;
	int	ii	=  0;
	int	tsk	= 0;
	int	Mstr	= 0;
	int	Item_count	= 0;
	int	IsMilestoneLiveFlag	= 0;
	int	CMRefcount	= 0;
	int	Tskcnt	= 0;

	tag_t	*TaskCMRef = NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *BomComInfo1 =NULL;
	char   *Prtrel_status =NULL;
	char   *PRTSubStr =NULL;
	char   *Prtrev_idd =NULL;
	char   *DML_Milestone =NULL;
	char   *DMLDR =NULL;

	char   *PartTyp =NULL;
	char   *BomComInfo2 =NULL;
	char   *BOMComp =NULL;
	char   *DMLProj =NULL;
	tag_t	PartypObj		= NULLTAG;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *FolderObj_tag= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	char   sPartObjyp[TCTYPE_name_size_c+1];
	int     PRTSTVAL      =  0;
	int     UPdaFlag      =  0;
	int     fld      =  0;
	int     IsPartMilestoneLiveFlag      =  0;
	int     FlderObjCount      =  0;
	int     FlderSize      =  0;
	int     BOMCompFlag      =  0;
	int     iBOMComp      =  0;
	int     iBomComInfo2      =  0;
	int     RelRevFlag      =  0;
	char DRStrng[20];
	int	chkBOMComFlag	= 0;
	tag_t *ClsObjTag= NULLTAG;
	tag_t   *ccvMstrTag      = NULLTAG;
	tag_t   part_tsk_rel_typ      = NULLTAG;
	tag_t   master     = NULLTAG;
	tag_t   ClsObj     = NULLTAG;
	int     Conut_Mst      =  0;
	int TScount			     = 0;
	int     cnt_ccvcls      =  0;
	int     WeightFlag      =  0;
	double     iUnladenWeight      =  0;
	double     iWeightRollup      =  0;
	double     iTrgBOMComp      =  0;
	double     idegreesWt      =  0;
	double     iWtDiff      =  0;
	char	*sUnladenWeightt		=  NULL;
	char	*sdegreesWttDup		=  NULL;
	char	*sdegreesWtt		=  NULL;
	char	*sPrtColInd		=  NULL;
	char	*BomComInfo3		=  NULL;
	char	*BomComInfo4		=  NULL;
	char	*BomComInfo5		=  NULL;
	char	*BomComInfo7		=  NULL;
	char	*BomComInfo6		=  NULL;
	char	*sDMLtaskno		=  NULL;
	char	*sWeightRollup		=  NULL;
	char	*sDMLrlstype		=  NULL;
	char	*sPartTyp		=  NULL;
	char	*sDMLno		=  NULL;
	char	*AttrVal		=  NULL;
	char	*ErorStrg		=  NULL;
	char	*sdegreesWttDupp		=  NULL;
	char	*eptr		=  NULL;
	char	*sUnladenWeight		=  NULL;
	char    *relation_name      = NULL;
	char *TechSpecNum        = NULL;
	char *VCBusUnit          = NULL;
	char *VCBusUnitDup       = NULL;
	
	//new attri
	tag_t DMLRevTg =NULLTAG;
	tag_t tsk_dml_rel_type =NULLTAG;
	tag_t relation_type_tag  = NULLTAG;
	tag_t TechSpecObjTag     = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *primaryobjs	     = NULLTAG;
	int j =0;
	int countt =0;
	logical is_latest;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char*	CurrentTask				=NULL;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	sPartTyp =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLrlstype =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLDR =(char *) MEM_alloc(20 * sizeof(char *));
	ErorStrg =(char *) MEM_alloc(200 * sizeof(char *));
	sUnladenWeightt =(char *) MEM_alloc(200 * sizeof(char *));
	sdegreesWttDup =(char *) MEM_alloc(200 * sizeof(char *));
	sdegreesWtt =(char *) MEM_alloc(200 * sizeof(char *));
	
	printf("\n RolledUp weight validation start here........................");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n Wt: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			//Query Control table.
			if(QRY_find("ControlObjects", &DRqryTag));
			if (DRqryTag)
			{
				printf("\n Wt::Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n Wt::Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "ROLLUP";
			if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n Wt::DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
			if(DR_rsltCount > 0)
			{
				//ON/OFF
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&BomComInfo1)!=ITK_ok)   PrintErrorStack();
				//percentage
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&BomComInfo2)!=ITK_ok)   PrintErrorStack();
				printf("\n Wt:A:BomComInfo2: %s \n",BomComInfo2);fflush(stdout);
				iTrgBOMComp=atof(BomComInfo2);
				printf("\n Wt::iTrgBOMComp:%f \n",iTrgBOMComp);fflush(stdout);
				//iTrgBOMComp = strtod(BomComInfo2, &eptr);
				//printf("\n Wt::AAAAAAAAAAAAAAAAAA:%lf \n",iTrgBOMComp);fflush(stdout);
				//FROM TO values for GMD
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&BomComInfo3)!=ITK_ok)   PrintErrorStack();
				//DML DR-status and DML types.:,Veh,TODR,DR3,AR3,DR3P,DR4,AR3P,AR4,
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&BomComInfo4)!=ITK_ok)   PrintErrorStack();
				//Part Type
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&BomComInfo5)!=ITK_ok)   PrintErrorStack();
				//DR2 weight check:DR-status veh DML and FROMTO DR-status for GMD
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo6",&BomComInfo6)!=ITK_ok)   PrintErrorStack();
				//for veh DML only: ,Veh,
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo7",&BomComInfo7)!=ITK_ok)   PrintErrorStack();
				printf("\n Wt::BomComInfo1 is  = [%s] BomComInfo2:%s\n BomComInfo3:[%s] \n BomComInfo4:[%s] \n BomComInfo5:[%s]\n iTrgBOMComp:[%f]", BomComInfo1,BomComInfo2,BomComInfo3,BomComInfo4,BomComInfo5,iTrgBOMComp);fflush(stdout);
				printf("\n Wt:A:BomComInfo6:[%s] BomComInfo7:[%s] \n",BomComInfo6,BomComInfo7);fflush(stdout);
			}
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				printf("\n Wt::This is for veh DML submission.\n");fflush(stdout);
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
				printf("\n Wt:sDMLtaskno:%s.",sDMLtaskno);fflush(stdout);
				if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
				if (tsk_dml_rel_type!=NULLTAG)
				{
					if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
					printf("\n Wt:DML Revision from Task for MR : %d",countt);fflush(stdout);
					for (j=0;j<countt ;j++ )
					{
						if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
						printf("\n Wt: is_latest MR is : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\n Wt:is_latest is not true .....\n");fflush(stdout);
						}
						else
						{
							DMLRevTg = DMLRevision[j];
							if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
							printf("\n Wt:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);
							
							if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
							if(item_tag==NULLTAG)
							{
								printf("\n Wt::item_tag is NULL.\n");fflush(stdout);
								return decision;
							}
							else
							{
								printf("\n Wt::item_tag found.\n");fflush(stdout);
								if(ITEM_ask_latest_rev (item_tag, &DMLTag)!=ITK_ok)PrintErrorStack();
								if(DMLTag==NULLTAG)
								{
									printf("\n Wt::Object not found in Teamcenter...!!\n");fflush(stdout);
									return decision;
								}
								else
								{
									//DML Details:
									if(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
									printf("\n Wt:: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
									tc_strcpy(sDMLrlstype,"");
									tc_strcpy(sDMLrlstype,",");
									tc_strcat(sDMLrlstype,DMLtype);
									tc_strcat(sDMLrlstype,",");
									printf("\n Wt:sDMLrlstype:: %s Current  DMLtype:%s",sDMLrlstype,DMLtype);fflush(stdout);
									tc_strcpy(sDMLDR,"");
									tc_strcpy(sDMLDR,",");
									tc_strcat(sDMLDR,DMLDR);
									tc_strcat(sDMLDR,",");
									printf("\n Wt::sDMLDR:: %s Current  DMLDR:%s",sDMLDR,DMLDR);fflush(stdout);
									//for Veh DML only
									if(tc_strstr(BomComInfo7,sDMLrlstype) != NULL)
									{
										if(tc_strstr(BomComInfo1,sDMLno) != NULL)
										{
											printf("\n Wt:DML has been bypassed. \n");fflush(stdout);
										}
										else
										{
											if(tc_strstr(BomComInfo1,"RollupWt1") == NULL)
											{
												if(tc_strstr(BomComInfo4,sDMLrlstype) != NULL)
												{
													if(tc_strcmp(DMLtype,"TODR")==0)
													{
														printf("\n Wt:Inside Gate Maturation DML..................");fflush(stdout);
														if(PlntToPlnt != NULL)
														{
															if((tc_strstr(BomComInfo3,PlntToPlnt) != NULL)||(tc_strstr(BomComInfo6,PlntToPlnt) != NULL))
															{
																Tskcnt=0;
																if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
																printf("\n Wt::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
																if (Tskcnt>0)
																{
																	BOMCompFlag=0;
																	for (tsk=0;tsk<Tskcnt ;tsk++ )
																	{
																		if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n Wt:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																		if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																		{
																			if(TaskDsgGrp) TaskDsgGrp=NULL;
																			if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																			TaskDsgGrp=subString(TskNm,11,2);
																			printf("\n Wt: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

																			if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																			if (tsk_CMRef_type!=NULLTAG)
																			{
																				CMRefcount=0;
																				if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																				printf("\n Wt: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																				if(CMRefcount > 0)
																				{
																					Mstr=0;
																					BOMCompFlag=0;
																					for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																					{
																						printf("\n Wt:Design Mstr:%d",Mstr);fflush(stdout);
																						if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																						printf("\n Wt:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																						if(strcmp(Prt_object_type,"Folder")!=0)
																						{
																							// put condition for desi rev , to avoid other attachments.
																							if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																							printf("\n Wt:PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																							Item_count=0;
																							//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																							All_item_tag= t5GetItemRevison(PartMstr_no);
																							if(All_item_tag==NULLTAG)
																							{
																								printf("\n Wt:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																								//return 0;
																							}
																							else
																							{
																								if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																								printf("\n Wt:Total rev found: %d.", Item_count);fflush(stdout);
																								if(Item_count > 0)
																								{
																									ii=0;
																									BOMCompFlag=0;
																									WeightFlag=0;
																									for(ii=Item_count-1;ii>=0;ii--)
																									{
																										rel_status_cunt=0;
																										if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																										if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																										if(TCTYPE_ask_name(PartypObj,sPartObjyp));
																										printf("\n Wt:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp);fflush(stdout);
																										//check revison
																										chkBOMComFlag=0;
																										printf("\n Wt:sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																										if((tc_strcmp(sPrtColInd,"N")==0)|| (tc_strcmp(sPrtColInd,"Y")==0))
																										{
																											if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																											{
																												chkBOMComFlag=1;
																											}
																											else if(tc_strstr(BomComInfo1,"RollupWt2") != NULL)
																											{
																												chkBOMComFlag=1;
																											}
																											printf("\n Wt:chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																											if(chkBOMComFlag >0)
																											{
																												tc_strcpy(sPartTyp,"");
																												tc_strcpy(sPartTyp,",");
																												tc_strcat(sPartTyp,PartTyp);
																												tc_strcat(sPartTyp,",");
																												printf("\n Wt:sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																												if(tc_strstr(BomComInfo5,sPartTyp) != NULL)
																												{
																													if(AOM_UIF_ask_value(rev_list[ii], "t5_RolledupWt", &sWeightRollup)!=ITK_ok)PrintErrorStack();
																													printf("\n Wt:sWeightRollup:[%s] and ", sWeightRollup);fflush(stdout);
																													
																													if((sWeightRollup==NULL) ||(tc_strcmp(sWeightRollup,"")==0))
																													{
																														//NULL case
																														printf("\n Wt:sWeightRollup NULL, FAILED for GM DML.");fflush(stdout);
																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part not having RolledUp Weight value updated. \nPlease get it updated, then you can sign off this DML. \nRolledUp weight and unladen weight difference shoule not be more than percentage: ",BomComInfo2);	
																														decision = EPM_nogo;
																														return decision;
																													}
																													else
																													{
																														iWeightRollup=atof(sWeightRollup);
																														printf(" iWeightRollup: [%f]", iWeightRollup);fflush(stdout);
																														printf("\n Wt:BomComInfo6:[%s] and PlntToPlnt:[%s]",BomComInfo6,PlntToPlnt);fflush(stdout);
																														if(tc_strstr(BomComInfo6,PlntToPlnt) != NULL)
																														{
																															WeightFlag=1;
																															printf("\n Wt:This GMD is not applicable for further validation.:%d",WeightFlag);fflush(stdout);
																														}
																														else if(tc_strstr(BomComInfo1,"RollupWt3") == NULL)
																														{

																															ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
																															printf("\n after T5_VCSpec relation find"); fflush(stdout);
																															if(relation_type_tag != NULLTAG)
																															{
																																printf("\n inside T5_VCSpec relation found"); fflush(stdout);
																																ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
																																printf("\n relation_name[%s]",relation_name); fflush(stdout);
																																ITK_CALL(GRM_list_secondary_objects_only(rev_list[ii],relation_type_tag,&TScount,&primaryobjs));
																																printf("\n TScount: %d\n", TScount);fflush(stdout);
																																if(TScount>0)
																																{
																																	TechSpecObjTag=primaryobjs[0];
																																	printf("\nDlgTanCodeValuDup");fflush(stdout);
																																	ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																																	printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																																	ITK_CALL( AOM_get_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
																																	if(VCBusUnit)
																																	{
																																		tc_strdup(VCBusUnit,&VCBusUnitDup);
																																	}
																																	printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
																																}
																															}
																															//char *VCClsAddress=NULL
																															//char *TobeUpdAttrId=NULL;
																															if (VCBusUnitDup!=NULL)
																															{
																																char TobeUpdAttrId[30];
																																int retcount;
																																int ClsAttrId=0 ;
																																printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
																																ITK_CALL(getClsCodeAttrNoWrtTSBURew(VCBusUnitDup,&retcount));
																																printf("\n after call getTANCodeAttrNoWrtTSBURew count: %d \n",retcount);fflush(stdout);
																																ClsAttrId=retcount;
																																printf("\n ClsAttrId[%d] for TAN Code \n",ClsAttrId);fflush(stdout);
																																if(ClsAttrId>0)
																																{

																																	sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																																	printf("\n inside sprintf TobeUpdAttrId[%s] for UNLADEN Weight Code \n",TobeUpdAttrId);fflush(stdout);
																																	//key_lov_id=theKeyLOVId;	
																																}
																																printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);


																															if(ITEM_ask_item_of_rev(rev_list[ii], &master)!=ITK_ok)PrintErrorStack();
																															if(AOM_ask_value_tags(master,"IMAN_classification",&cnt_ccvcls,&ClsObjTag)!=ITK_ok)PrintErrorStack();
																															printf("\n Wt:Classification relation: %d.",cnt_ccvcls); fflush(stdout);
																															if (cnt_ccvcls >0)
																															{
																																ClsObj=*ClsObjTag;
																																iUnladenWeight= tm_GetVCAttriFrmClasssificationObj(ClsObj,TobeUpdAttrId);
																																printf("\n Wt: iUnladenWeight:[%f]\n",iUnladenWeight); fflush(stdout);
																																if(iUnladenWeight==0)
																																{
																																	//NULL case
																																	printf("\n Wt:iUnladenWeight NULL, FAILED for GM DML.");fflush(stdout);
																																	EMH_clear_errors();
																																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part not having Unladen Weight value updated. \nPlease get it updated, then you can sign off this DML. \nRolledUp weight and unladen weight difference shoule not be more than percentage: ",BomComInfo2);
																																	decision = EPM_nogo;
																																	return decision;
																																}
																																else
																																{
																																	//CHeck for diff now.
																																	printf("\n Wt:Input: iWeightRollup:[%f] iUnladenWeight [%f]\n",iWeightRollup,iUnladenWeight); fflush(stdout);
																																	idegreesWt = ((iUnladenWeight - iWeightRollup) * (1.000000/iUnladenWeight) * (100.000000));
																																	printf(" Wt:After Formula:Final diff percentage: [%f]", idegreesWt);fflush(stdout);
																																	sprintf(sdegreesWtt, "%f", idegreesWt);
																																	sprintf(sUnladenWeightt, "%f", iUnladenWeight);
																																	printf("\n Wt:After Formula:Final diff strng percentage:[%s] for sUnladenWeightt:[%s]\n", sdegreesWtt,sUnladenWeightt);fflush(stdout);
																																	if(tc_strstr(sdegreesWtt,"-")!=NULL)
																																	{
																																		printf("\n Wt:minus value, so "); fflush(stdout);
																																		tc_strcpy(sdegreesWttDup,(sdegreesWtt+1));
																																		printf("removed minus value:[%s]", sdegreesWttDup);fflush(stdout);
																																		sdegreesWttDupp = strtok(sdegreesWttDup,".");
																																		printf("...before dot value :[%s]", sdegreesWttDupp);fflush(stdout);
																																		iWtDiff = 0;
																																		iWtDiff=atof(sdegreesWttDupp);
																																		printf(" and Final iWtDiff is :[%f]", iWtDiff);fflush(stdout);
																																	}
																																	else
																																	{
																																		printf("\n Wt:Plus value "); fflush(stdout);
																																		sdegreesWttDupp = strtok(sdegreesWtt,".");
																																		printf(":before dot value: [%s] and \n", sdegreesWttDupp);fflush(stdout);
																																		iWtDiff = 0;
																																		iWtDiff=atof(sdegreesWttDupp);
																																		printf("Final iWtDiff is : [%f]", iWtDiff);fflush(stdout);
																																	}
																																	
																																	if((iTrgBOMComp >iWtDiff) ||(iTrgBOMComp == iWtDiff))
																																	{
																																		printf("\n Wt:.................................Weight is OK.\n"); fflush(stdout);
																																	}
																																	else
																																	{
																																		printf("\n Wt:Error:..Weight is not OK.\n"); fflush(stdout);
																																		tc_strcpy(ErorStrg,"");
																																		tc_strcpy(ErorStrg,"\n RolleduP Weight is:");
																																		tc_strcat(ErorStrg,sWeightRollup);
																																		tc_strcat(ErorStrg," and Unladen Weight is:");
																																		tc_strcat(ErorStrg,sUnladenWeightt);
																																		tc_strcat(ErorStrg,". Its difference should not be more than: ");
																																		tc_strcat(ErorStrg,BomComInfo2);
																																		tc_strcat(ErorStrg," Percentage.");
																																		printf("\n Wt:ErorStrg:: %s ",ErorStrg);fflush(stdout);

																																		EMH_clear_errors();
																																		EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part having difference in Rolled Up Weight and unladen weight. \nPlease get it corrected, then you can sign off this DML.",ErorStrg);
																																		decision = EPM_nogo;
																																		return decision;
																																	}
																																}
																															}
																															}
																														}
																													}
																													break;
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																						if (BOMCompFlag >0)
																						{
																							printf("\n Wt:BOMComp :%d",BOMCompFlag);fflush(stdout);
																							break;
																						}
																					}
																				}
																			}
																		}
																		if (BOMCompFlag >0)
																		{
																			printf("\n Wt:BOMComp :%d",BOMCompFlag);fflush(stdout);
																			break;
																		}
																	}
																}
															}
														}
														else
														{
															printf("\n Wt:FAILED for GM DML FROMTO-ststus is NULL.");fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Please update FROM-TO DR-status value for Gate maturation DML and re-process DML. \nDML number: ",sDMLno);	
															decision = EPM_nogo;
															return decision;
														}

														if(TaskCMRef) MEM_free(TaskCMRef);
														if(rev_list) MEM_free(rev_list);
													}
													else
													{
														printf("\n Wt::Inside vehicle DML..................");fflush(stdout);
														if(DMLDR != NULL)
														{
															if((tc_strstr(BomComInfo4,sDMLDR) != NULL) ||(tc_strstr(BomComInfo6,sDMLDR) != NULL))
															{
																Tskcnt=0;
																if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
																printf("\n Wt::no of tasks:%d\n",Tskcnt);fflush(stdout);
																if (Tskcnt>0)
																{
																	BOMCompFlag=0;
																	for (tsk=0;tsk<Tskcnt ;tsk++ )
																	{
																		if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n Wt::Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																		if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																		{
																			if(TaskDsgGrp) TaskDsgGrp=NULL;
																			if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																			TaskDsgGrp=subString(TskNm,11,2);
																			printf("\n Wt:: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

																			if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																			if (tsk_CMRef_type!=NULLTAG)
																			{
																				CMRefcount=0;
																				if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																				printf("\n Wt:: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																				if(CMRefcount > 0)
																				{
																					Mstr=0;
																					BOMCompFlag=0;
																					for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																					{
																						printf("\n Wt::Design Mstr taken...:%d",Mstr);fflush(stdout);
																						if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																						printf("\n Wt::Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																						if(strcmp(Prt_object_type,"Folder")!=0)
																						{
																							// put condition for desi rev , to avoid other attachments.
																							if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																							printf("\n Wt::PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																							Item_count=0;
																							//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																							All_item_tag= t5GetItemRevison(PartMstr_no);
																							if(All_item_tag==NULLTAG)
																							{
																								printf("\n Wt::ERROR:All_item_tag is NULL.\n");fflush(stdout);
																								//return 0;
																							}
																							else
																							{
																								if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																								printf("\n Wt::Total rev found: %d.", Item_count);fflush(stdout);
																								if(Item_count > 0)
																								{
																									ii=0;
																									BOMCompFlag=0;
																									WeightFlag=0;
																									for(ii=Item_count-1;ii>=0;ii--)
																									{
																										rel_status_cunt=0;
																										if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																										if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																										if(TCTYPE_ask_name(PartypObj,sPartObjyp));
																										printf("\n Wt::Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp);fflush(stdout);
																										//check revison
																										chkBOMComFlag=0;
																										printf("\n Wt::sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																										if((tc_strcmp(sPrtColInd,"N")==0)|| (tc_strcmp(sPrtColInd,"Y")==0))
																										{
																											if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																											{
																												chkBOMComFlag=1;
																											}
																											else if(tc_strstr(BomComInfo1,"RollupWt2") != NULL)
																											{
																												chkBOMComFlag=1;
																											}
																											printf("\n Wt::chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																											if(chkBOMComFlag >0)
																											{
																												tc_strcpy(sPartTyp,"");
																												tc_strcpy(sPartTyp,",");
																												tc_strcat(sPartTyp,PartTyp);
																												tc_strcat(sPartTyp,",");
																												printf("\n Wt::sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																												if(tc_strstr(BomComInfo5,sPartTyp) != NULL)
																												{
																													if(AOM_UIF_ask_value(rev_list[ii], "t5_RolledupWt", &sWeightRollup)!=ITK_ok)PrintErrorStack();
																													printf("\n Wt::sWeightRollup:[%s] and ", sWeightRollup);fflush(stdout);
																													
																													if((sWeightRollup==NULL) ||(tc_strcmp(sWeightRollup,"")==0))
																													{
																														//NULL case
																														printf("\n Wt::sWeightRollup NULL, FAILED for GM DML.");fflush(stdout);
																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part not having Rolled Up Weight value updated. \nPlease get it updated, then you can sign off this DML. \nRolledUp weight and unladen weight difference should not be more than percentage: ",BomComInfo2);	
																														decision = EPM_nogo;
																														return decision;
																													}
																													else
																													{
																														iWeightRollup=atof(sWeightRollup);
																														printf(" iWeightRollup: [%f]", iWeightRollup);fflush(stdout);
																														if(tc_strstr(BomComInfo6,sDMLDR) != NULL)
																														{
																															WeightFlag=1;
																															printf("\n Wt:this DMl is not applicable for further weight diff validation:%d",WeightFlag);fflush(stdout);
																														}
																														else if(tc_strstr(BomComInfo1,"RollupWt4") == NULL)
																														{


																															ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
																															printf("\n after T5_VCSpec relation find"); fflush(stdout);
																															if(relation_type_tag != NULLTAG)
																															{
																																printf("\n inside T5_VCSpec relation found"); fflush(stdout);
																																ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
																																printf("\n relation_name[%s]",relation_name); fflush(stdout);
																																ITK_CALL(GRM_list_secondary_objects_only(rev_list[ii],relation_type_tag,&TScount,&primaryobjs));
																																printf("\n TScount: %d\n", TScount);fflush(stdout);
																																if(TScount>0)
																																{
																																	TechSpecObjTag=primaryobjs[0];
																																	printf("\nDlgTanCodeValuDup");fflush(stdout);
																																	ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																																	printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																																	ITK_CALL( AOM_get_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
																																	if(VCBusUnit)
																																	{
																																		tc_strdup(VCBusUnit,&VCBusUnitDup);
																																	}
																																	printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
																																}
																															}
																															//char *VCClsAddress=NULL
																															//char *TobeUpdAttrId=NULL;
																															if (VCBusUnitDup!=NULL)
																															{
																																char TobeUpdAttrId[30];
																																int retcount;
																																int ClsAttrId=0 ;
																																printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
																																ITK_CALL(getClsCodeAttrNoWrtTSBURew(VCBusUnitDup,&retcount));
																																printf("\n after call getTANCodeAttrNoWrtTSBURew count: %d \n",retcount);fflush(stdout);
																																ClsAttrId=retcount;
																																printf("\n ClsAttrId[%d] for TAN Code \n",ClsAttrId);fflush(stdout);
																																if(ClsAttrId>0)
																																{

																																	sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																																	printf("\n inside sprintf TobeUpdAttrId[%s] for UNLADEN Weight Code \n",TobeUpdAttrId);fflush(stdout);
																																	//key_lov_id=theKeyLOVId;	
																																}
																																printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);



																															if(ITEM_ask_item_of_rev(rev_list[ii], &master)!=ITK_ok)PrintErrorStack();
																															if(AOM_ask_value_tags(master,"IMAN_classification",&cnt_ccvcls,&ClsObjTag)!=ITK_ok)PrintErrorStack();
																															printf("\n Wt::Classification relation: %d.",cnt_ccvcls); fflush(stdout);
																															if (cnt_ccvcls >0)
																															{
																																ClsObj=*ClsObjTag;
																																iUnladenWeight= tm_GetVCAttriFrmClasssificationObj(ClsObj,TobeUpdAttrId);
																																printf("\n Wt:: iUnladenWeight:[%f]\n",iUnladenWeight); fflush(stdout);
																																if(iUnladenWeight==0)
																																{
																																	//NULL case
																																	printf("\n Wt::iUnladenWeight NULL, FAILED for GM DML.");fflush(stdout);
																																	EMH_clear_errors();
																																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part not having Unladen Up Weight value updated. \nPlease get it updated, then you can sign off this DML. \nRolledUp weight and unladen weight difference should not be more than percentage: ",BomComInfo2);
																																	decision = EPM_nogo;
																																	return decision;
																																}
																																else
																																{
																																	//CHeck for diff now.
																																	printf("\n Wt::Input: iWeightRollup:[%f] iUnladenWeight [%f]\n",iWeightRollup,iUnladenWeight); fflush(stdout);
																																	idegreesWt = ((iUnladenWeight - iWeightRollup) * (1.000000/iUnladenWeight) * (100.000000));
																																	printf(" Wt::After Formula:Final diff percentage: [%f]", idegreesWt);fflush(stdout);
																																	sprintf(sdegreesWtt, "%f", idegreesWt);
																																	sprintf(sUnladenWeightt, "%f", iUnladenWeight);
																																	printf("\n Wt::After Formula:Final diff strng percentage:[%s] for sUnladenWeightt:[%s]\n", sdegreesWtt,sUnladenWeightt);fflush(stdout);
																																	if(tc_strstr(sdegreesWtt,"-")!=NULL)
																																	{
																																		printf("\n Wt::minus value, so "); fflush(stdout);
																																		tc_strcpy(sdegreesWttDup,(sdegreesWtt+1));
																																		printf("removed minus value:[%s]", sdegreesWttDup);fflush(stdout);
																																		sdegreesWttDupp = strtok(sdegreesWttDup,".");
																																		printf("...before dot value :[%s]", sdegreesWttDupp);fflush(stdout);
																																		iWtDiff = 0;
																																		iWtDiff=atof(sdegreesWttDupp);
																																		printf(" and Final iWtDiff is :[%f]", iWtDiff);fflush(stdout);
																																	}
																																	else
																																	{
																																		printf("\n Wt::Plus value "); fflush(stdout);
																																		sdegreesWttDupp = strtok(sdegreesWtt,".");
																																		printf(":before dot value: [%s] and \n", sdegreesWttDupp);fflush(stdout);
																																		iWtDiff = 0;
																																		iWtDiff=atof(sdegreesWttDupp);
																																		printf("Final iWtDiff is : [%f]", iWtDiff);fflush(stdout);
																																	}
																																	
																																	if((iTrgBOMComp >iWtDiff) ||(iTrgBOMComp == iWtDiff))
																																	{
																																		printf("\n Wt::.................................Weight is OK.\n"); fflush(stdout);
																																	}
																																	else
																																	{
																																		printf("\n Wt::Error:..Weight is not OK.\n"); fflush(stdout);
																																		tc_strcpy(ErorStrg,"");
																																		tc_strcpy(ErorStrg,"\n RolleduP Weight is:");
																																		tc_strcat(ErorStrg,sWeightRollup);
																																		tc_strcat(ErorStrg," and Unladen Weight is:");
																																		tc_strcat(ErorStrg,sUnladenWeightt);
																																		tc_strcat(ErorStrg,". Its difference should not be more than: ");
																																		tc_strcat(ErorStrg,BomComInfo2);
																																		tc_strcat(ErorStrg," Percentage.");
																																		printf("\n Wt::ErorStrg:: %s ",ErorStrg);fflush(stdout);

																																		EMH_clear_errors();
																																		EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part having difference in Rolled Up Weight and unladen weight. \nPlease get it corrected, then you can sign off this DML.",ErorStrg);
																																		decision = EPM_nogo;
																																		return decision;
																																	}
																																}
																															}
																															}
																														}
																													}
																													break;
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																						if (BOMCompFlag >0)
																						{
																							printf("\n Wt:::BOMComp :%d,WeightFlag:%d",BOMCompFlag,WeightFlag);fflush(stdout);
																							break;
																						}
																					}
																				}
																			}
																		}
																		if (BOMCompFlag >0)
																		{
																			printf("\n Wt::BOMComp :%d,WeightFlag:%d",BOMCompFlag,WeightFlag);fflush(stdout);
																			break;
																		}
																	}
																}
															}
														}
														else
														{
															//Blank value
															printf("\n Wt::FAILED for DML DR-ststus is NULL.");fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML DR-status is NULL. \nPlease update valid AR/DR-status to DML: ",sDMLno);	
															decision = EPM_nogo;
															return decision;
														}
														if(TaskCMRef) MEM_free(TaskCMRef);
														if(rev_list) MEM_free(rev_list);
													}
												}
												//break;
											}
										}
									}
								}
							}
							if (BOMCompFlag >0)
							{
								printf("\n FAILED for GM DML.");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part having difference in Rolled Up Weight and unladen weight. \nPlease get it corrected, then you can sign off this DML.",ErorStrg);
								decision = EPM_nogo;
								return decision;
							}
							else
							{
								printf("\n PASSSS for GM DML1......");fflush(stdout);
							}
						}
					}
				}
			}
			else if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				printf("\n Wt::This is for Gate maturation DML submission.\n");fflush(stdout);
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
				printf("\n Wt:sDMLno....:%s.",sDMLno);fflush(stdout);
				if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
				if(item_tag==NULLTAG)
				{
					printf("\n Wt::item_tag is NULL.\n");fflush(stdout);
					return decision;
				}
				else
				{
					printf("\n Wt::item_tag found.\n");fflush(stdout);
					if(ITEM_ask_latest_rev (item_tag, &DMLTag)!=ITK_ok)PrintErrorStack();
					if(DMLTag==NULLTAG)
					{
						printf("\n Wt::Object not found in Teamcenter...!!\n");fflush(stdout);
						return decision;
					}
					else
					{
						//DML Details:
						if(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
						printf("\n Wt:: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
						tc_strcpy(sDMLrlstype,"");
						tc_strcpy(sDMLrlstype,",");
						tc_strcat(sDMLrlstype,DMLtype);
						tc_strcat(sDMLrlstype,",");
						printf("\n Wt:sDMLrlstype:: %s Current  DMLtype:%s",sDMLrlstype,DMLtype);fflush(stdout);
						tc_strcpy(sDMLDR,"");
						tc_strcpy(sDMLDR,",");
						tc_strcat(sDMLDR,DMLDR);
						tc_strcat(sDMLDR,",");
						printf("\n Wt::sDMLDR:: %s Current  DMLDR:%s",sDMLDR,DMLDR);fflush(stdout);
						
						if(tc_strstr(BomComInfo1,sDMLno) != NULL)
						{
							printf("\n Wt:DML has been bypassed. \n");fflush(stdout);
						}
						else
						{
							if(tc_strstr(BomComInfo1,"RollupWt1") == NULL)
							{
								if(tc_strstr(BomComInfo4,sDMLrlstype) != NULL)
								{
									if(tc_strcmp(DMLtype,"TODR")==0)
									{
										printf("\n Wt:Inside Gate Maturation DML..................");fflush(stdout);
										if(PlntToPlnt != NULL)
										{
											if((tc_strstr(BomComInfo3,PlntToPlnt) != NULL)||(tc_strstr(BomComInfo6,PlntToPlnt) != NULL))
											{
												Tskcnt=0;
												if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
												printf("\n Wt::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
												if (Tskcnt>0)
												{
													BOMCompFlag=0;
													for (tsk=0;tsk<Tskcnt ;tsk++ )
													{
														if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
														printf("\n Wt:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

														if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
														{
															if(TaskDsgGrp) TaskDsgGrp=NULL;
															if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
															TaskDsgGrp=subString(TskNm,11,2);
															printf("\n Wt: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

															if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
															if (tsk_CMRef_type!=NULLTAG)
															{
																CMRefcount=0;
																if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																printf("\n Wt: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																if(CMRefcount > 0)
																{
																	Mstr=0;
																	BOMCompFlag=0;
																	for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																	{
																		printf("\n Wt:Design Mstr:%d",Mstr);fflush(stdout);
																		if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n Wt:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																		if(strcmp(Prt_object_type,"Folder")!=0)
																		{
																			// put condition for desi rev , to avoid other attachments.
																			if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																			if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																			if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																			printf("\n Wt:PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																			Item_count=0;
																			//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																			All_item_tag= t5GetItemRevison(PartMstr_no);
																			if(All_item_tag==NULLTAG)
																			{
																				printf("\n Wt:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																				//return 0;
																			}
																			else
																			{
																				if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																				printf("\n Wt:Total rev found: %d.", Item_count);fflush(stdout);
																				if(Item_count > 0)
																				{
																					ii=0;
																					BOMCompFlag=0;
																					WeightFlag=0;
																					for(ii=Item_count-1;ii>=0;ii--)
																					{
																						rel_status_cunt=0;
																						if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																						if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																						if(TCTYPE_ask_name(PartypObj,sPartObjyp));
																						printf("\n Wt:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp);fflush(stdout);
																						//check revison
																						chkBOMComFlag=0;
																						printf("\n Wt:sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																						if((tc_strcmp(sPrtColInd,"N")==0)|| (tc_strcmp(sPrtColInd,"Y")==0))
																						{
																							if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																							{
																								chkBOMComFlag=1;
																							}
																							else if(tc_strstr(BomComInfo1,"RollupWt2") != NULL)
																							{
																								chkBOMComFlag=1;
																							}
																							printf("\n Wt:chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																							if(chkBOMComFlag >0)
																							{
																								tc_strcpy(sPartTyp,"");
																								tc_strcpy(sPartTyp,",");
																								tc_strcat(sPartTyp,PartTyp);
																								tc_strcat(sPartTyp,",");
																								printf("\n Wt:sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																								if(tc_strstr(BomComInfo5,sPartTyp) != NULL)
																								{
																									if(AOM_UIF_ask_value(rev_list[ii], "t5_RolledupWt", &sWeightRollup)!=ITK_ok)PrintErrorStack();
																									printf("\n Wt:sWeightRollup:[%s] and ", sWeightRollup);fflush(stdout);
																									
																									if((sWeightRollup==NULL) ||(tc_strcmp(sWeightRollup,"")==0))
																									{
																										//NULL case
																										printf("\n Wt:sWeightRollup NULL, FAILED for GM DML.");fflush(stdout);
																										EMH_clear_errors();
																										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part not having RolledUp Weight value updated. \nPlease get it updated, then you can sign off this DML. \nRolledUp weight and unladen weight difference shoule not be more than percentage: ",BomComInfo2);	
																										decision = EPM_nogo;
																										return decision;
																									}
																									else
																									{
																										iWeightRollup=atof(sWeightRollup);
																										printf(" iWeightRollup: [%f]", iWeightRollup);fflush(stdout);
																										printf("\n Wt:BomComInfo6:[%s] and PlntToPlnt:[%s]",BomComInfo6,PlntToPlnt);fflush(stdout);
																										if(tc_strstr(BomComInfo6,PlntToPlnt) != NULL)
																										{
																											WeightFlag=1;
																											printf("\n Wt:This GMD is not applicable for further validation.:%d",WeightFlag);fflush(stdout);
																										}
																										else if(tc_strstr(BomComInfo1,"RollupWt3") == NULL)
																										{

																											ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
																											printf("\n after T5_VCSpec relation find"); fflush(stdout);
																											if(relation_type_tag != NULLTAG)
																											{
																												printf("\n inside T5_VCSpec relation found"); fflush(stdout);
																												ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
																												printf("\n relation_name[%s]",relation_name); fflush(stdout);
																												ITK_CALL(GRM_list_secondary_objects_only(rev_list[ii],relation_type_tag,&TScount,&primaryobjs));
																												printf("\n TScount: %d\n", TScount);fflush(stdout);
																												if(TScount>0)
																												{
																													TechSpecObjTag=primaryobjs[0];
																													printf("\nDlgTanCodeValuDup");fflush(stdout);
																													ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																													printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																													ITK_CALL( AOM_get_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
																													if(VCBusUnit)
																													{
																														tc_strdup(VCBusUnit,&VCBusUnitDup);
																													}
																													printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
																												}
																											}
																											//char *VCClsAddress=NULL
																											//char *TobeUpdAttrId=NULL;
																											if (VCBusUnitDup!=NULL)
																											{
																												char TobeUpdAttrId[30];
																												int retcount;
																												int ClsAttrId=0 ;
																												printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
																												ITK_CALL(getClsCodeAttrNoWrtTSBURew(VCBusUnitDup,&retcount));
																												printf("\n after call getTANCodeAttrNoWrtTSBURew count: %d \n",retcount);fflush(stdout);
																												ClsAttrId=retcount;
																												printf("\n ClsAttrId[%d] for TAN Code \n",ClsAttrId);fflush(stdout);
																												if(ClsAttrId>0)
																												{

																													sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																													printf("\n inside sprintf TobeUpdAttrId[%s] for UNLADEN Weight Code \n",TobeUpdAttrId);fflush(stdout);
																													//key_lov_id=theKeyLOVId;	
																												}
																												printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);


																											if(ITEM_ask_item_of_rev(rev_list[ii], &master)!=ITK_ok)PrintErrorStack();
																											if(AOM_ask_value_tags(master,"IMAN_classification",&cnt_ccvcls,&ClsObjTag)!=ITK_ok)PrintErrorStack();
																											printf("\n Wt:Classification relation: %d.",cnt_ccvcls); fflush(stdout);
																											if (cnt_ccvcls >0)
																											{

																												ClsObj=*ClsObjTag;
																												iUnladenWeight= tm_GetVCAttriFrmClasssificationObj(ClsObj,TobeUpdAttrId);
																												printf("\n Wt: iUnladenWeight:[%f]\n",iUnladenWeight); fflush(stdout);
																												if(iUnladenWeight==0)
																												{
																													//NULL case
																													printf("\n Wt:iUnladenWeight NULL, FAILED for GM DML.");fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part not having Unladen Weight value updated. \nPlease get it updated, then you can sign off this DML. \nRolledUp weight and unladen weight difference shoule not be more than percentage: ",BomComInfo2);
																													decision = EPM_nogo;
																													return decision;
																												}
																												else
																												{
																													//CHeck for diff now.
																													printf("\n Wt:Input: iWeightRollup:[%f] iUnladenWeight [%f]\n",iWeightRollup,iUnladenWeight); fflush(stdout);
																													idegreesWt = ((iUnladenWeight - iWeightRollup) * (1.000000/iUnladenWeight) * (100.000000));
																													printf(" Wt:After Formula:Final diff percentage: [%f]", idegreesWt);fflush(stdout);
																													sprintf(sdegreesWtt, "%f", idegreesWt);
																													sprintf(sUnladenWeightt, "%f", iUnladenWeight);
																													printf("\n Wt:After Formula:Final diff strng percentage:[%s] for sUnladenWeightt:[%s]\n", sdegreesWtt,sUnladenWeightt);fflush(stdout);
																													if(tc_strstr(sdegreesWtt,"-")!=NULL)
																													{
																														printf("\n Wt:minus value, so "); fflush(stdout);
																														tc_strcpy(sdegreesWttDup,(sdegreesWtt+1));
																														printf("removed minus value:[%s]", sdegreesWttDup);fflush(stdout);
																														sdegreesWttDupp = strtok(sdegreesWttDup,".");
																														printf("...before dot value :[%s]", sdegreesWttDupp);fflush(stdout);
																														iWtDiff = 0;
																														iWtDiff=atof(sdegreesWttDupp);
																														printf(" and Final iWtDiff is :[%f]", iWtDiff);fflush(stdout);
																													}
																													else
																													{
																														printf("\n Wt:Plus value "); fflush(stdout);
																														sdegreesWttDupp = strtok(sdegreesWtt,".");
																														printf(":before dot value: [%s] and \n", sdegreesWttDupp);fflush(stdout);
																														iWtDiff = 0;
																														iWtDiff=atof(sdegreesWttDupp);
																														printf("Final iWtDiff is : [%f]", iWtDiff);fflush(stdout);
																													}
																													
																													if((iTrgBOMComp >iWtDiff) ||(iTrgBOMComp == iWtDiff))
																													{
																														printf("\n Wt:.................................Weight is OK.\n"); fflush(stdout);
																													}
																													else
																													{
																														printf("\n Wt:Error:..Weight is not OK.\n"); fflush(stdout);
																														tc_strcpy(ErorStrg,"");
																														tc_strcpy(ErorStrg,"\n RolleduP Weight is:");
																														tc_strcat(ErorStrg,sWeightRollup);
																														tc_strcat(ErorStrg," and Unladen Weight is:");
																														tc_strcat(ErorStrg,sUnladenWeightt);
																														tc_strcat(ErorStrg,". Its difference should not be more than: ");
																														tc_strcat(ErorStrg,BomComInfo2);
																														tc_strcat(ErorStrg," Percentage.");
																														printf("\n Wt:ErorStrg:: %s ",ErorStrg);fflush(stdout);

																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part having difference in Rolled Up Weight and unladen weight. \nPlease get it corrected, then you can sign off this DML.",ErorStrg);
																														decision = EPM_nogo;
																														return decision;
																													}
																												}
																												}
																											}
																										}
																									}
																									break;
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																		if (BOMCompFlag >0)
																		{
																			printf("\n Wt:BOMComp :%d",BOMCompFlag);fflush(stdout);
																			break;
																		}
																	}
																}
															}
														}
														if (BOMCompFlag >0)
														{
															printf("\n Wt:BOMComp :%d",BOMCompFlag);fflush(stdout);
															break;
														}
													}
												}
											}
										}
										else
										{
											printf("\n Wt:FAILED for GM DML FROMTO-ststus is NULL.");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Please update FROM-TO DR-status value for Gate maturation DML and re-process DML. \nDML number: ",sDMLno);	
											decision = EPM_nogo;
											return decision;
										}

										if(TaskCMRef) MEM_free(TaskCMRef);
										if(rev_list) MEM_free(rev_list);
									}
									else
									{
										printf("\n Wt::Inside vehicle DML..................");fflush(stdout);
										if(DMLDR != NULL)
										{
											if((tc_strstr(BomComInfo4,sDMLDR) != NULL) ||(tc_strstr(BomComInfo6,sDMLDR) != NULL))
											{
												Tskcnt=0;
												if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
												printf("\n Wt::no of tasks:%d\n",Tskcnt);fflush(stdout);
												if (Tskcnt>0)
												{
													BOMCompFlag=0;
													for (tsk=0;tsk<Tskcnt ;tsk++ )
													{
														if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
														printf("\n Wt::Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

														if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
														{
															if(TaskDsgGrp) TaskDsgGrp=NULL;
															if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
															TaskDsgGrp=subString(TskNm,11,2);
															printf("\n Wt:: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

															if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
															if (tsk_CMRef_type!=NULLTAG)
															{
																CMRefcount=0;
																if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																printf("\n Wt:: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																if(CMRefcount > 0)
																{
																	Mstr=0;
																	BOMCompFlag=0;
																	for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																	{
																		printf("\n Wt::Design Mstr taken...:%d",Mstr);fflush(stdout);
																		if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n Wt::Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																		if(strcmp(Prt_object_type,"Folder")!=0)
																		{
																			// put condition for desi rev , to avoid other attachments.
																			if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																			if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																			if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																			printf("\n Wt::PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																			Item_count=0;
																			//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																			All_item_tag= t5GetItemRevison(PartMstr_no);
																			if(All_item_tag==NULLTAG)
																			{
																				printf("\n Wt::ERROR:All_item_tag is NULL.\n");fflush(stdout);
																				//return 0;
																			}
																			else
																			{
																				if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																				printf("\n Wt::Total rev found: %d.", Item_count);fflush(stdout);
																				if(Item_count > 0)
																				{
																					ii=0;
																					BOMCompFlag=0;
																					WeightFlag=0;
																					for(ii=Item_count-1;ii>=0;ii--)
																					{
																						rel_status_cunt=0;
																						if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																						if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																						if(TCTYPE_ask_name(PartypObj,sPartObjyp));
																						printf("\n Wt::Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp);fflush(stdout);
																						//check revison
																						chkBOMComFlag=0;
																						printf("\n Wt::sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																						if((tc_strcmp(sPrtColInd,"N")==0)|| (tc_strcmp(sPrtColInd,"Y")==0))
																						{
																							if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																							{
																								chkBOMComFlag=1;
																							}
																							else if(tc_strstr(BomComInfo1,"RollupWt2") != NULL)
																							{
																								chkBOMComFlag=1;
																							}
																							printf("\n Wt::chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																							if(chkBOMComFlag >0)
																							{
																								tc_strcpy(sPartTyp,"");
																								tc_strcpy(sPartTyp,",");
																								tc_strcat(sPartTyp,PartTyp);
																								tc_strcat(sPartTyp,",");
																								printf("\n Wt::sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																								if(tc_strstr(BomComInfo5,sPartTyp) != NULL)
																								{
																									if(AOM_UIF_ask_value(rev_list[ii], "t5_RolledupWt", &sWeightRollup)!=ITK_ok)PrintErrorStack();
																									printf("\n Wt::sWeightRollup:[%s] and ", sWeightRollup);fflush(stdout);
																									
																									if((sWeightRollup==NULL) ||(tc_strcmp(sWeightRollup,"")==0))
																									{
																										//NULL case
																										printf("\n Wt:::sWeightRollup NULL, FAILED for GM DML.");fflush(stdout);
																										EMH_clear_errors();
																										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part not having Rolled Up Weight value updated. \nPlease get it updated, then you can sign off this DML. \nRolledUp weight and unladen weight difference should not be more than percentage: ",BomComInfo2);	
																										decision = EPM_nogo;
																										return decision;
																									}
																									else
																									{
																										iWeightRollup=atof(sWeightRollup);
																										printf(" iWeightRollup: [%f]", iWeightRollup);fflush(stdout);
																										if(tc_strstr(BomComInfo6,sDMLDR) != NULL)
																										{
																											WeightFlag=1;
																											printf("\n Wt:this DMl is not applicable for further weight diff validation:%d",WeightFlag);fflush(stdout);
																										}
																										else if(tc_strstr(BomComInfo1,"RollupWt4") == NULL)
																										{
																											
																											ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
																											printf("\n after T5_VCSpec relation find"); fflush(stdout);
																											if(relation_type_tag != NULLTAG)
																											{
																												printf("\n inside T5_VCSpec relation found"); fflush(stdout);
																												ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
																												printf("\n relation_name[%s]",relation_name); fflush(stdout);
																												ITK_CALL(GRM_list_secondary_objects_only(rev_list[ii],relation_type_tag,&TScount,&primaryobjs));
																												printf("\n TScount: %d\n", TScount);fflush(stdout);
																												if(TScount>0)
																												{
																													TechSpecObjTag=primaryobjs[0];
																													printf("\nDlgTanCodeValuDup");fflush(stdout);
																													ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																													printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																													ITK_CALL( AOM_get_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
																													if(VCBusUnit)
																													{
																														tc_strdup(VCBusUnit,&VCBusUnitDup);
																													}
																													printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
																												}
																											}
																											//char *VCClsAddress=NULL
																											//char *TobeUpdAttrId=NULL;
																											if (VCBusUnitDup!=NULL)
																											{
																												char TobeUpdAttrId[30];
																												int retcount;
																												int ClsAttrId=0 ;
																												printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
																												ITK_CALL(getClsCodeAttrNoWrtTSBURew(VCBusUnitDup,&retcount));
																												printf("\n after call getTANCodeAttrNoWrtTSBURew count: %d \n",retcount);fflush(stdout);
																												ClsAttrId=retcount;
																												printf("\n ClsAttrId[%d] for TAN Code \n",ClsAttrId);fflush(stdout);
																												if(ClsAttrId>0)
																												{

																													sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																													printf("\n inside sprintf TobeUpdAttrId[%s] for UNLADEN Weight Code \n",TobeUpdAttrId);fflush(stdout);
																													//key_lov_id=theKeyLOVId;	
																												}
																												printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);

																											if(ITEM_ask_item_of_rev(rev_list[ii], &master)!=ITK_ok)PrintErrorStack();
																											if(AOM_ask_value_tags(master,"IMAN_classification",&cnt_ccvcls,&ClsObjTag)!=ITK_ok)PrintErrorStack();
																											printf("\n Wt::Classification relation: %d.",cnt_ccvcls); fflush(stdout);
																											if (cnt_ccvcls >0)
																											{

																												ClsObj=*ClsObjTag;
																												iUnladenWeight= tm_GetVCAttriFrmClasssificationObj(ClsObj,TobeUpdAttrId);
																												printf("\n Wt:: iUnladenWeight:[%f]\n",iUnladenWeight); fflush(stdout);
																												if(iUnladenWeight==0)
																												{
																													//NULL case
																													printf("\n Wt::iUnladenWeight NULL, FAILED for GM DML.");fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part not having Unladen Up Weight value updated. \nPlease get it updated, then you can sign off this DML. \nRolledUp weight and unladen weight difference should not be more than percentage: ",BomComInfo2);
																													decision = EPM_nogo;
																													return decision;
																												}
																												else
																												{
																													//CHeck for diff now.
																													printf("\n Wt::Input: iWeightRollup:[%f] iUnladenWeight [%f]\n",iWeightRollup,iUnladenWeight); fflush(stdout);
																													idegreesWt = ((iUnladenWeight - iWeightRollup) * (1.000000/iUnladenWeight) * (100.000000));
																													printf(" Wt::After Formula:Final diff percentage: [%f]", idegreesWt);fflush(stdout);
																													sprintf(sdegreesWtt, "%f", idegreesWt);
																													sprintf(sUnladenWeightt, "%f", iUnladenWeight);
																													printf("\n Wt::After Formula:Final diff strng percentage:[%s] for sUnladenWeightt:[%s]\n", sdegreesWtt,sUnladenWeightt);fflush(stdout);
																													if(tc_strstr(sdegreesWtt,"-")!=NULL)
																													{
																														printf("\n Wt::minus value, so "); fflush(stdout);
																														tc_strcpy(sdegreesWttDup,(sdegreesWtt+1));
																														printf("removed minus value:[%s]", sdegreesWttDup);fflush(stdout);
																														sdegreesWttDupp = strtok(sdegreesWttDup,".");
																														printf("...before dot value :[%s]", sdegreesWttDupp);fflush(stdout);
																														iWtDiff = 0;
																														iWtDiff=atof(sdegreesWttDupp);
																														printf(" and Final iWtDiff is :[%f]", iWtDiff);fflush(stdout);
																													}
																													else
																													{
																														printf("\n Wt::Plus value "); fflush(stdout);
																														sdegreesWttDupp = strtok(sdegreesWtt,".");
																														printf(":before dot value: [%s] and \n", sdegreesWttDupp);fflush(stdout);
																														iWtDiff = 0;
																														iWtDiff=atof(sdegreesWttDupp);
																														printf("Final iWtDiff is : [%f]", iWtDiff);fflush(stdout);
																													}
																													
																													if((iTrgBOMComp >iWtDiff) ||(iTrgBOMComp == iWtDiff))
																													{
																														printf("\n Wt::.................................Weight is OK.\n"); fflush(stdout);
																													}
																													else
																													{
																														printf("\n Wt::Error:..Weight is not OK.\n"); fflush(stdout);
																														tc_strcpy(ErorStrg,"");
																														tc_strcpy(ErorStrg,"\n RolleduP Weight is:");
																														tc_strcat(ErorStrg,sWeightRollup);
																														tc_strcat(ErorStrg," and Unladen Weight is:");
																														tc_strcat(ErorStrg,sUnladenWeightt);
																														tc_strcat(ErorStrg,". Its difference should not be more than: ");
																														tc_strcat(ErorStrg,BomComInfo2);
																														tc_strcat(ErorStrg," Percentage.");
																														printf("\n Wt::ErorStrg:: %s ",ErorStrg);fflush(stdout);

																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part having difference in Rolled Up Weight and unladen weight. \nPlease get it corrected, then you can sign off this DML.",ErorStrg);
																														decision = EPM_nogo;
																														return decision;
																													}
																												}
																												}
																											}
																										}
																									}
																									break;
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																		if (BOMCompFlag >0)
																		{
																			printf("\n Wt:::BOMComp :%d,WeightFlag:%d",BOMCompFlag,WeightFlag);fflush(stdout);
																			break;
																		}
																	}
																}
															}
														}
														if (BOMCompFlag >0)
														{
															printf("\n Wt::BOMComp :%d,WeightFlag:%d",BOMCompFlag,WeightFlag);fflush(stdout);
															break;
														}
													}
												}
											}
										}
										else
										{
											//Blank value
											printf("\n Wt::FAILED for DML DR-ststus is NULL.");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML DR-status is NULL. \nPlease update valid AR/DR-status to DML: ",sDMLno);	
											decision = EPM_nogo;
											return decision;
										}
										if(TaskCMRef) MEM_free(TaskCMRef);
										if(rev_list) MEM_free(rev_list);
									}
								}
								//break;
							}
						}
					}
				}
				if (BOMCompFlag >0)
				{
					printf("\n FAILED for GM DML.");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part having difference in Rolled Up Weight and unladen weight. \nPlease get it corrected, then you can sign off this DML.",ErorStrg);
					decision = EPM_nogo;
					return decision;
				}
				else
				{
					printf("\n PASSSS for GM DML.");fflush(stdout);
				}
			}
		}
	}

	return decision;
}

int tm_GetVCAttriFrmClasssificationObj( tag_t  ClsObj , char *clsKeyAtrrId)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   Ptype_name[TCTYPE_name_size_c+1];
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	double iUnladenWeight=0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	char * 	sUnladenWeight =NULL;
	
	//Create Relation between Intent and Vehicle.
	int partRevCnt=0;
    tag_t* partRevTagObjs = NULLTAG;
    tag_t partRevTag = NULLTAG;
	if(ClsObj!=NULLTAG)
	{
		char * 	theClassId =NULL;
		int  	theAttributeCount;
		int * 	theAttributeIds;
		int * 	theAttributeValCounts;
		char ** 	theAttributeValues;
		tag_t 	theICOTag=NULLTAG;
		printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
		char keyPrefix[10];
		tc_strcpy(keyPrefix,"-");
		tc_strcat(keyPrefix,clsKeyAtrrId);
		printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
		const char * 	key_lov_id=keyPrefix; 
		char * 	key_lov_name;
		int  	options;
		int i;
		int keyfound=0;
		int  	n_lov_entries;
		char ** 	lov_keys;
		char ** 	lov_values;
		logical * 	deprecated_staus;
		char * 	owning_site;
		char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
		int  	n_shared_sites;
		char ** 	shared_sites ;
		theICOTag=ClsObj;
		if(ICS_ask_attribute_value(ClsObj,clsKeyAtrrId,&AttrKeyValue)!=ITK_ok)PrintErrorStack();
		
		printf("\n AttrKeyValue=%s key_lov_id=%s",AttrKeyValue,key_lov_id); fflush(stdout);
		if(AttrKeyValue)
		{
		
		if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites)!=ITK_ok)PrintErrorStack();
		printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
			for(i=0;i<n_lov_entries;i++)								
			{
				if(tc_strcmp(AttrKeyValue,lov_keys[i])==0)
				{
					printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
					printf("\n Mascot lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
					
					if(lov_values[i])
					{
						sUnladenWeight    =(char *) MEM_alloc(20);
						tc_strcpy(sUnladenWeight,"");
						tc_strcpy(sUnladenWeight,lov_values[i]);
						printf("\n sUnladenWeight  =%s",sUnladenWeight); fflush(stdout);
						iUnladenWeight=atof(sUnladenWeight);
						printf("\n iUnladenWeight  =%f",iUnladenWeight); fflush(stdout);
						return iUnladenWeight;
					}
				}
			}
		}
		else
		{
			return iUnladenWeight;
			}
	}						
			printf("\n RetAttrVal=%s ",RetAttrVal); fflush(stdout);
			
	return iUnladenWeight;
}



int getClsCodeAttrNoWrtTSBURew( char *TechSpecBusunit,int   *retwgtCodeattrno )
{
    int ifail = ITK_ok;

    //tag_t        query           = NULLTAG;    
    tag_t    *RetICOWgtAttrNoContrlObjs=NULLTAG;
    char *CntrlObjName=NULL;
    char *WgtAttrid=NULL;
    int WgtAttridInt=0;
    int retCntrlObjcount=0;
    if(TechSpecBusunit)
    {

        retCntrlObjcount=0;
        //ITKCALL(getNPIAttrObj(TechSpecBusunit,"ICONpiAttrNo",&retCntrlObjcount,&RetICONpiAttrNoContrlObjs));
        ITKCALL(getICOUpdCOWGT(TechSpecBusunit,"ICOWGTAttrNo",&retCntrlObjcount,&RetICOWgtAttrNoContrlObjs));
        printf("\n after call getWgtCodeAttrNoWrtTSBURew count: %d \n",retCntrlObjcount);fflush(stdout);
        if(retCntrlObjcount>0)
        {
            ITKCALL( AOM_get_value_string(RetICOWgtAttrNoContrlObjs[0], "object_name", &CntrlObjName));
            printf("\n CntrlObjName: %s\n",CntrlObjName);fflush(stdout);
            AOM_ask_value_string(RetICOWgtAttrNoContrlObjs[0], "t5_Userinfo1", &WgtAttrid);
            printf("\n after getWgtAttrid: info1[%s] \n",WgtAttrid);fflush(stdout);
        }
    }
    printf("\n 22getWgtAttrObj: info1[%s] \n",WgtAttrid);fflush(stdout);
    if(WgtAttrid!=NULL)
    {
         WgtAttridInt=atoi(WgtAttrid);
    }
    if(WgtAttridInt>0)
    {
         *retwgtCodeattrno =WgtAttridInt;
    }
    else
    {
        WgtAttridInt=8101;
        printf("\n WgtAttridInt=%d\n",WgtAttridInt);fflush(stdout);
         *retwgtCodeattrno =WgtAttridInt;

 

    }
    printf("\n\n End Qry for getClsCodeAttrNoWrtTSBURew control object size ==%d with retwgtCodeattrno=%d\n",retCntrlObjcount,*retwgtCodeattrno);fflush(stdout);
    return ifail;
}	


int getICOUpdCOWGT( char *syscd,char *subsys,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries3[] = {"SYSCD","SUBSYSCD"},
	*qry_values3[]       = {syscd,subsys};

	printf("\n in getICOUpdCORew func");fflush(stdout);
	printf("\n\n Input syscd=%s SUBSYSCD==%s \n",syscd,subsys);fflush(stdout);
	
	printf("\n b4 Qry getICOUpdCORew");fflush(stdout);

	QRY_find("Control Objects...", &query);
	printf("\n in after qry find getICOUpdCORew");fflush(stdout);
	QRY_execute(query, 2, qry_entries3, qry_values3, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getICOUpdCORew control object size ==%d \n",*n_found);fflush(stdout);

	return ifail;
}





int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;	
}