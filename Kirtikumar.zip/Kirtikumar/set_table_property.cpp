#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <sa/sa.h>

#include "unidefs.h"

#include <unidefs.h>

#include <itk/mem.h>

#include <iostream>

#include <tcinit/tcinit.h>

#include <sa/imanfile.h>

#include <sa/tcfile.h>

#include <fclasses/tc_string.h>

#include <tc/tc.h>

#include <tccore/item_errors.h>

#include <tccore/item.h>

#include <tccore/aom.h>

#include <sa/tcfile.h>

#include <tccore/tctype.h>

#include <tccore/aom_prop.h>

#define _DEBUG

#include <string>

#include<fstream>

#include <tccore/grm.h>
#define PROP_set_value_tags_msg   "PROP_set_value_tags"


//int CreateDesignRuleObject(char * );
int SetCheckListTableProperty(char *);

using namespace std;

int ITK_user_main(int argc, char ** argv) {

    char * user = NULL;
    char * pw = NULL;
    char * grp = NULL;
    char * iRChklName = NULL;

	int ifail = ITK_ok;
    int status = 0;
    user			= ITK_ask_cli_argument("-u=");
    pw				= ITK_ask_cli_argument("-p=");
    grp				= ITK_ask_cli_argument("-g=");
    iRChklName		= ITK_ask_cli_argument("-irCheckListName=");

    cout << "User Name=: "<< user << endl;
    cout << "Password =: "<< pw << endl;
    cout << "User Group=: "<< grp << endl;
    cout << "Input File=: "<< iRChklName << endl;
    cout << "Before Login.............................";

    status = ITK_init_module(user, pw, grp);
    if (status == 0) {
        cout << "Currently Login Sucessfully";

        ifail = SetCheckListTableProperty(iRChklName);
    } else {
        cout << "Invalid User Name or Password,Please Enter correct";
    }

    return 0;
}

int SetCheckListTableProperty(char * iRChklName) 
	{

	tag_t row_object_type_tag				= NULLTAG;
	tag_t object_create_input_tag		= NULLTAG;

	int i = 0;
	int ifail = ITK_ok;
	char *object_name;
	char * 	text;

	int 	insert_at_row_index = 0;
	int 	num_rows_to_insert	= 1;
	tag_t  	table_row = NULL;
	tag_t* table_Rows_Array =NULL;

	int tableRow;

	tag_t * CheckListObj_tag = NULL;
	// tag_t obj_tag = NULLTAG;
    int n_entries = 2;
    tag_t queryTag;
    
    int resultCount = 0;
	char *form_type = "Type";
	char *form_name = "Name";
	char * form_type_value = "Interface Rule Checklist";
	char**  		entries						= NULL;
	char**  		values						= NULL;
		
	entries		= (char**) MEM_alloc (sizeof(char*) * 200);
	values		= (char**) MEM_alloc (sizeof(char*) * 200);
	
	entries[0] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(form_type) + 200));
	values[0]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(form_type_value) + 200));
			
	entries[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(form_name) + 200));
	values[1]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(iRChklName) + 200));
			
	tc_strcpy(entries[0], "");	
	tc_strcpy(entries[0], form_type);
	tc_strcpy(values[0], "");	
	tc_strcpy(values[0], form_type_value);
	
	tc_strcpy(entries[1], "");
	tc_strcpy(entries[1], form_name);
	tc_strcpy(values[1], "");	
	tc_strcpy(values[1], iRChklName);
	
	 ifail = QRY_find2("General...", & queryTag);
            if (ifail != ITK_ok) {
                cout << "\n*** Error with Finding Query ***\n";
                return ifail;
            }

            if (queryTag) {
                cout << "Found Query \n";
            } else {
                cout << "*** Query Not Found *** \n";
                return ifail;
            }
            ifail = QRY_execute(queryTag, n_entries, entries, values, & resultCount, & CheckListObj_tag);
            printf("\nNo. of Design Revision Object Found are -- %d\n", resultCount);
			
			for(i=0; i<resultCount; i++)
			{
			
				ifail = AOM_get_value_string(CheckListObj_tag[i],"object_name",&object_name);
				printf("\nDesign rule check list name is  -- %s\n", object_name);
				if(tc_strcmp(object_name,iRChklName)== 0)
				{
					printf("\nForm where need to modify table property\n.");

					//TCTYPE_find_type();
					//TCTYPE_construct_create_input();

					//ifail =AOM_insert_table_rows(CheckListObj_tag[i],"t5_ChecklistAttr",insert_at_row_index,num_rows_to_insert,&table_rows);
					ifail = TCTYPE_find_type("T5_IRChecklistRow", NULL, & row_object_type_tag);
					if(ifail == 0)
								{	
									cout<< "\nTable Row Type Found in TC....\n";
									ifail = TCTYPE_construct_create_input(row_object_type_tag, & object_create_input_tag);
									if(ifail == 0)
									{
											cout<< "\nInput created successfully\n";
											ifail = AOM_set_value_string(object_create_input_tag, "t5_RuleID", "002212");
											if(ifail == 0)
											{
												cout<< "\nValue set successfully\n";
												ifail = TCTYPE_create_object(object_create_input_tag, & table_row);
												if(ifail == 0)
												{
															cout<< "\Row Object created successfully\n";
															ifail =AOM_set_value_string(table_row,"t5_Aggregate","Power Train");
															ifail =AOM_set_value_string(table_row,"t5_AggrGrp","Petrole, is created using serverside");
															ifail =AOM_set_value_string(table_row,"t5_IRImplemented","Yes");
															ifail =AOM_set_value_string(table_row,"t5_RuleDesc","This is just to check.");

															if(ifail == 0)
															{

																cout<< "\Values correctly set to Row...\n";
																//table_Rows_Array[0] = table_row;
																AOM_refresh(CheckListObj_tag[i],1);
																ifail = AOM_set_table_rows(CheckListObj_tag[i],"t5_ChecklistAttr",num_rows_to_insert,&table_row);
																//ifail = AOM_append_table_rows(CheckListObj_tag[i],"t5_ChecklistAttr",num_rows_to_insert);
																AOM_refresh(CheckListObj_tag[i],0);
																if(ifail == 0)
																{
																	printf("\nTable Row set successully\n%s");
																}
																else 
																{
																	EMH_ask_error_text(ifail,&text);
																	printf("\nError while seetting table row\n%s",text);
																}

															}
															else
															{
																	EMH_ask_error_text(ifail,&text);
																	printf("\Properties not set to Row object n%s",text);
															}
												}
												else
												{
													EMH_ask_error_text(ifail,&text);
													printf("\nRow type creation failed...n%s",text);
												}


											}
											else
											{
												EMH_ask_error_text(ifail,&text);
												printf("\nValue not setn%s",text);

											}
									}
									else
									{
											EMH_ask_error_text(ifail,&text);
											printf("\nInpute creaton failed n%s",text);
									}

								}
								else
								{
									//printf("\nTable Row Type NOT Found in TC....\n");
									EMH_ask_error_text(ifail,&text);
									printf("\nTable Row Type NOT Found in TC....\n%s",text);
								}
				}	else 
				{

					printf("Other form then, requried");
				}

			
			}
			
			

    return ITK_ok;
}