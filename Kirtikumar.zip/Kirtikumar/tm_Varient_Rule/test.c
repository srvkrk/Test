#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char* replaceAll(char * str, char oldChar, char newChar);
int main(void)
{
	char* OptValName ="Petrol+CNG";
	char* temp =NULL;

	printf("\nString before replacing: \n%s", OptValName);

	temp =replaceAll(OptValName,'+', ' ');

	printf("\nString Afeter replacing: \n%s", temp);

		
  
  return 0;
}
char* replaceAll(char * str, char oldChar, char newChar)
{
    int i = 0;

    /* Run till end of string */
    while(str[i] != '\0')
    {
        /* If occurrence of character is found */
        if(str[i] == oldChar)
        {
            str[i] = newChar;
        }

        i++;
    }
}
