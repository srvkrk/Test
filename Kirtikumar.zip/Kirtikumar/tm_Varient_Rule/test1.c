// Online C compiler to run C program online
#include <stdio.h>
#include <string.h>
int customStrStr();
int main() {
    // Write C code here
	char* child_bl_formula="((([Teamcenter]AGGREGATE = 'E & E' & [Teamcenter]'RAIN LIGHT SENSOR COMPATIBILITY' = Petrol+CNG | [Teamcenter]'RAIN LIGHT SENSOR COMPATIBILITY' = Petrol & [Teamcenter]ARMREST = FIXED)))";

	//char* child_bl_formula="((([Teamcenter]AGGREGATE = 'E & E' & [Teamcenter]'RAIN LIGHT SENSOR COMPATIBILITY' = Petrol+CNG & [Teamcenter]ARMREST = FIXED)))";

	//char* child_bl_formula="((([Teamcenter]AGGREGATE = 'E & E' & [Teamcenter]'RAIN LIGHT SENSOR COMPATIBILITY' = HYD+GASO | [Teamcenter]'RAIN LIGHT SENSOR COMPATIBILITY' = HYD & [Teamcenter]ARMREST = FIXED)))";

	//char* child_bl_formula="((([Teamcenter]AGGREGATE = 'E & E' & [Teamcenter]'RAIN LIGHT SENSOR COMPATIBILITY' = Petrol | [Teamcenter]'RAIN LIGHT SENSOR COMPATIBILITY' = Petrol & [Teamcenter]ARMREST = FIXED)))";


  char* variantFormula = "'RAIN LIGHT SENSOR COMPATIBILITY' = Petrol";
	 //char* variantFormula = "'RAIN LIGHT SENSOR COMPATIBILITY' = Petrol+CNG";
	
	char* iRet = strstr(child_bl_formula, variantFormula);
	if(iRet) {
		printf("\n string found -: %s", iRet);
	} else {
		printf("\n string not found -: %d", iRet);
	}
	
	if(customStrStr(child_bl_formula, variantFormula) > 0)
	{
		printf("Exact Match found.....");
	}
    return 0;
}

int customStrStr(char* strEdited, char* strDefault) {
	printf("\n Inside customStrStr function");
	printf("\n Edited String -: %s", strEdited);
	printf("\n Default String -: %s", strDefault);
	printf("\n\n\n");
	char* tmpEdited = strEdited;
	char* tmpDefault = strDefault;
	int isFullTraversed = 0;
	int matchCnt = 0;
	int partialMatchCnt = 0;
	int exactMatchCnt = 0;
	while(*tmpEdited != '\0') {
		if(*tmpEdited == *tmpDefault) {
			isFullTraversed = 1;
			while(*tmpDefault != '\0') {
				if(*tmpEdited == *tmpDefault) {
					//printf("\n %c", *tmpEdited);
				} else {
					//printf("\n Not matched successive chars");
					isFullTraversed = 0;
					tmpDefault = strDefault;
					break;
				}
				tmpEdited ++;
				tmpDefault ++;
			}
			if(isFullTraversed) {
				if(((*tmpEdited == ' ') && (*(tmpEdited+1) == '|' || *(tmpEdited+1) == '&')) || (*tmpEdited == ')')){
					exactMatchCnt ++;
				} else {
					partialMatchCnt ++;
				}
				tmpDefault = strDefault;
				matchCnt ++;
			}
		}
		tmpEdited ++;
	}
	printf("\n matchCnt -: %d", matchCnt);
	printf("\n partialMatchCnt -: %d", partialMatchCnt);
	printf("\n exactMatchCnt -: %d\n", exactMatchCnt);
	
	return exactMatchCnt;
}
