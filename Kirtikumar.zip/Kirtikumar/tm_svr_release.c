#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>


#define TC_MAJOR_VERSION 2007

#if TC_MAJOR_VERSION <= 10
#define TC_master_form_rtype IMAN_master_form_rtype
#endif

#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define DFMEA_VAL EMH_USER_error_base+30
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\
 
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
} 

static void handle_ifail( char * file, int line )
/*  Prints out the full error stack.*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "ERROR: (%s:%d)\n", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf( "    %6d: %s\n", ifails[i], messages[i] );
    }
    exit( EXIT_FAILURE );
}
;

int SvrVehCompareRep (char*	 SVR1, char*	 SVR2,char*	 Platform,char*	 RevisionRule,char*	 Date_Eff_Str,char* Filename,char** Out)
{
    int     status=0; 
 
	char *SVR = NULL;
	char *svr_name = NULL;
	 
 	int ifail =0;
 	int DateConvFlag =1;
	
	 
	
	int n_modes=0;
	char **mode_names = NULL;

 
		char*			mod_name_SVR				=NULL;  
		char*			mod_name_VC				=NULL;  
		char*			SVRname				=NULL;  
		char*			FileDown				=NULL;  
		char*			DataSetName				=NULL;  
		tag_t			bom_window				=NULLTAG;
		tag_t			bom_window_VC				=NULLTAG;
		tag_t			bom_window_SVR				=NULLTAG;
		tag_t			top_line_VC				=NULLTAG; 
		tag_t			top_line_SVR				=NULLTAG; 
		tag_t			rule					=NULLTAG;
		tag_t			rule2					=NULLTAG;
		tag_t			PrdConfigTag			=NULLTAG;
		tag_t			objTypeTagDi			=NULLTAG;
		tag_t			primaryTag				=NULLTAG;
		tag_t			PlatformTag				=NULLTAG;
		tag_t			PlatformTagRev				=NULLTAG;
		tag_t			SvrTag				=NULLTAG;
		//tag_t			*SvrTagS			=NULL;

		tag_t           *bom_variant_config=NULL;
		tag_t           *bomvariantlist_SVR=NULL;
		FILE	*fd;
		

		tag_t *Primary_objects1 = NULL;
		tag_t *Primary_objects2 = NULL;
		tag_t *secondary_objects1 = NULL;
		tag_t *lines_VC = NULL;
		tag_t *sub_lines_VC = NULL;
		tag_t *sub_lines_SVR = NULL;

		char   type_name3[TCTYPE_name_size_c+1];

		WSO_search_criteria_t  	criteria1;
		WSO_search_criteria_t  	criteria2;
		int number_found1=0,number_found2=0,countS=0;
		tag_t *list_of_WSO_tags1=NULL;
		tag_t *list_of_WSO_tags2=NULL;
		int i=0,k=0,n_lines=0,zz=0,n_lines1=0, vcount=0,countDep=0,vcountSVR=0,SvrFolder_Size=0,sub_n_lines_VC=0,sub_n_lines_SVR=0,n_lines_SVR_Cnt=0;
		int sub_n_lines=0,sub_n_lines1=0, zt=0,countDep1=0,n_lines_VC_Cnt=0,zx=0,zy=0,flagMatch=0,K=0;
		logical modB=FALSE;
		logical modB_SVR=FALSE;

		 tag_t 	*bomvariantlist = NULLTAG;
		 tag_t 	*SvrTagS = NULLTAG;
		 tag_t 	*lines_SVR = NULLTAG;
		 tag_t 	SvrTag1 = NULLTAG;
		 tag_t 	SvrTag2 = NULLTAG;
		 tag_t 	FolderTag = NULLTAG;
		 tag_t 	InpModTag1 = NULLTAG;
		 tag_t 	InpModTag2 = NULLTAG;
		 tag_t 	Plt_tag = NULLTAG;
		 tag_t 	PlatformRevTag = NULLTAG;
		 tag_t	LINE_VC[1000];
		 tag_t	LINE_SVR[1000];
		 tag_t	CommonModule[1000];
		 //char* SVR_Name= NULLTAG;
		 //char* SvrName_Dup= (char *) MEM_alloc ( 100);
		 
		char	SVR_Name_Type[WSO_name_size_c+1] ;
		char	SVR_Name[WSO_name_size_c+1] ;
		char	SvrName_Dup[WSO_name_size_c+1] ;
		char*	 VcName			= NULL;

		char*	 mod_name_SVR_desc   			= NULL;
		char*	 mod_name_SVR_descDup   			= NULL;
		char*	 mod_name_SVR_Add    			= NULL;
		char*	 mod_name_common_desc			= NULL;
		char*	 mod_name_common_descDup			= NULL;
		char*	 mod_name_common_Add 			= NULL;

		
		tag_t *tags_found = NULL;
		
		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
		char **values = (char **) MEM_alloc(1 * sizeof(char *));
		tag_t *closurerule = NULL;
		int rulefound=0;
		tag_t close_tag=NULLTAG;
		tag_t queryTag= NULLTAG;
		tag_t VehRev2= NULLTAG;
		tag_t VehRev1= NULLTAG;
		tag_t *rev2= NULLTAG;
		tag_t *rev1= NULLTAG;
	    char **rulename = NULL;
		char **rulevalue = NULL;
	    char **rulename_SVR = NULL;
		char **rulevalue_SVR = NULL;

		 int ReqCnt=0;
		 int VehFlag2=0;
		 int VehFlag1=0;
		 int resultCount1=0;
		 int resultCount2=0;
		 int sub_n_lines_VC_Cnt=0;
		 int sub_n_lines_SVR_Cnt=0;

   
	
	 FileDown = (char *) MEM_alloc (sizeof (char) * 128);
	 DataSetName = (char *) MEM_alloc (sizeof (char) * 128);

     

	 char			Data[100]					= "";
	char			outputFile[300]				= "";

	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	//for output file with date.
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.csv",Data);

	



	 char*	 Veh_1			= NULL;
	 char*	 Veh_Rev_1			= NULL;
	 char*	 Veh_Seq_1			= NULL;

	 char*	 Veh_2			= NULL;
	 char*	 Veh_Rev_2			= NULL;
	 char*	 Veh_Seq_2			= NULL;

	 char*	 itemRevSeq1			= NULL;
	 char*	 mod_name_common			= NULL;
	 char*	 mod_name_VC_desc			= NULL;
	 char*	 mod_name_VC_descDup			= NULL;
	 char*	 mod_name_VC_Add			= NULL;
	 date_t	 Date_Eff;
	 
	

		printf("\n Inside SVR comparision module <%s> >>>>>>>>>>>>>>>",Date_Eff_Str); fflush(stdout);
	 if (tc_strcmp(Date_Eff_Str,"NA"))
	 {
		 DateConvFlag=DATE_convert_formatted_string_to_date(Date_Eff_Str,"%m/%d/%Y",false,true,&Date_Eff);
		 printf("\n Inside SVR comparision DateConv %d >>>>>>>>>>>>>>>",DateConvFlag); fflush(stdout);
	 }
	 printf("\n Outside SVR comparision DateConv %d >>>>>>>>>>>>>>>",DateConvFlag); fflush(stdout);


	 
	
	/////////////////////////////Platform is Queryed/////////////////////////////////////////
	char **valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));
	int n_entriesP = 1;
	char *qry_entries10[1] = {"ID"};
	int n_tags_found = 0;
	if(QRY_find("Platform", &PlatformTag));
	if (PlatformTag) { printf("\nFound Query PlatformTag"); fflush(stdout); 
	}else {
		printf("\nNot Found Query PlatformTag"); fflush(stdout);
		*Out="Report Error. Platform not found";
		return status;
	}
	valuesPlatfrom[0] = Platform;
	if(QRY_execute(PlatformTag, n_entriesP, qry_entries10, valuesPlatfrom, &n_tags_found, &tags_found));
	printf("\n\n\n Platform count is-------->  : %d",n_tags_found);fflush(stdout);
	if (n_tags_found > 0)
	{
		Plt_tag = tags_found[0];
		CALLAPI(ITEM_ask_latest_rev(Plt_tag , &PlatformRevTag));
	}else { printf ("\n Platform tag not found\n"); fflush(stdout);	}


	//CALLAPI(CFM_find( "Latest Working", &rule));
	

	CALLAPI(PIE_find_closure_rules( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
    printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = closurerule[0];
		printf ("closure rule found \n");fflush(stdout);
	}
	
	if (tc_strstr(SVR1,","))
	{
		VehFlag1=1;
		Veh_1=tc_strtok(SVR1,",");
		Veh_Rev_1 = tc_strtok(NULL,",");
		Veh_Seq_1 = tc_strtok(NULL,",");
		printf ("Vehicle 1 is  <%s>   <%s>   <%s>\n",Veh_1,Veh_Rev_1,Veh_Seq_1);fflush(stdout);

		if (Veh_1 && Veh_Rev_1 && Veh_Seq_1)
		{
			printf("\n\t Inside Part Rev Seq 1.... "); fflush(stdout);
			if(QRY_find("DesignRevision Sequence", &queryTag));
			printf("\n\t After QRY_find .... "); fflush(stdout);

			if (queryTag)
			{
				printf("Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
			}
			else
			{
				printf("Not Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
				
			}
			char *qry_entries4[2] = {"Revision","ID"};
			char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

			char* itemRevSeq1 = NULL;
			itemRevSeq1=(char *) MEM_alloc(32);
			tc_strcpy(itemRevSeq1,Veh_Rev_1);
			tc_strcat(itemRevSeq1,"?");
			tc_strcat(itemRevSeq1,Veh_Seq_1);

			qry_values[0] = itemRevSeq1 ;
			qry_values[1] = Veh_1;
			int n_entries = 2;

			if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount1, &rev1));

			if (resultCount1 == 0)
			{
				printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", Veh_1);
				*Out="Report Error. Vehicle not found";
				return status;
								
			}
			else 
			{
				VehRev1 = rev1[0];
				printf ( "More than one items matched with id %s\n",Veh_1 );
				
			}
			
		}
	}
	else
	{
		WSOM_clear_search_criteria(&criteria1);
		strcpy(criteria1.name,SVR1);
		strcpy(criteria1.class_name,"VariantRule");
		CALLAPI(WSOM_search(criteria1, &number_found1, &list_of_WSO_tags1));
		printf("\n\n\t\t SVR1 Count found : %d\n",number_found1);fflush(stdout);
		if ( number_found1 > 0)
		{
			SvrTag1=list_of_WSO_tags1[0];
		}
		else
		{
			*Out="Report Error. SVR not found";
			return status;
				
		}
		
	}


	if (tc_strstr(SVR2,","))
	{
		VehFlag2=1;
		Veh_2=tc_strtok(SVR2,",");
		Veh_Rev_2 = tc_strtok(NULL,",");
		Veh_Seq_2 = tc_strtok(NULL,",");
		printf ("Vehicle 1 is  <%s>   <%s>   <%s>\n",Veh_2,Veh_Rev_2,Veh_Seq_2);fflush(stdout);
		if (Veh_2 && Veh_Rev_2 && Veh_Seq_2)
		{
			printf("\n\t Inside Part Rev Seq 2 .... "); fflush(stdout);
			if(QRY_find("DesignRevision Sequence", &queryTag));
			printf("\n\t After QRY_find .... "); fflush(stdout);

			if (queryTag)
			{
				printf("Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
			}
			else
			{
				printf("Not Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
				*Out="Report Error. Query not found";
				return status;
			}
			char *qry_entries4[2] = {"Revision","ID"};
			char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

			char* itemRevSeq2 = NULL;
			itemRevSeq2=(char *) MEM_alloc(32);
			tc_strcpy(itemRevSeq2,Veh_Rev_2);
			tc_strcat(itemRevSeq2,"?");
			tc_strcat(itemRevSeq2,Veh_Seq_2);

			qry_values[0] = itemRevSeq2 ;
			qry_values[1] = Veh_2;
			int n_entries = 2;

			if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount2, &rev2));

			if (resultCount2 == 0)
			{
				printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", Veh_2);
				*Out="Report Error. Vehicle not found";
				return status;
				
			}
			else
			{
				printf ( "More than one items matched with id %s\n", Veh_2);
				VehRev2 = rev2[0];
				
			}
			
		}
	}
	else
	{
		WSOM_clear_search_criteria(&criteria2);
		strcpy(criteria2.name,SVR2);
		strcpy(criteria2.class_name,"VariantRule");
		CALLAPI(WSOM_search(criteria2, &number_found2, &list_of_WSO_tags2));
		printf("\n\n\t\t SVR2 Count found : %d\n",number_found2);fflush(stdout);
		if (number_found2 >0)
		{
			SvrTag2=list_of_WSO_tags2[0];
		}
		else
		{
			*Out="Report Error. SVR not found";
			return status;
		}
		
	}




	tc_strcpy(FileDown,"/tmp/");
	tc_strcat(FileDown,Filename);
	tc_strcat(FileDown,".csv");


	tc_strcpy(DataSetName,Filename);


	


	fd=fopen(FileDown,"w");
	fprintf(fd,"Module Comparision Report,\n");
	fprintf(fd,"Module name,Module Desc,Module Address,\n\n");
	if(fd==NULL)
	{
		printf("\nError in opening the file \n");fflush(stdout);
		*Out="Report Error. Error in opening the file";
		return status;	
		
	}
		



	if (bom_window_VC)
	{
		bom_window_VC=NULLTAG;
	}
	if (top_line_VC)
	{
		top_line_VC=NULLTAG;
	}
	


	CALLAPI(BOM_create_window(&bom_window_VC));
	
	if (VehFlag1==0)
	{
		CALLAPI(BOM_window_set_closure_rule( bom_window_VC,close_tag, 0, rulename_SVR,rulevalue_SVR ));
		CALLAPI(CFM_find("ERC release and above", &rule));
	}
	else
	{	
		CALLAPI(CFM_find( RevisionRule, &rule ));
		if (!DateConvFlag)
		{
			printf( "\n Inside date set1 applied:..\n");	fflush(stdout);
			CALLAPI(CFM_rule_set_date( rule, Date_Eff )); //sks
		}
		
	}
	if (rule)
	{
		CALLAPI(BOM_set_window_config_rule( bom_window_VC, rule));
	}
	
	CALLAPI(BOM_set_window_pack_all(bom_window_VC, TRUE));
	

	if (VehFlag1==0)
	{
		CALLAPI(BOM_set_window_top_line( bom_window_VC, NULLTAG,PlatformRevTag , NULLTAG, &top_line_VC));
		BOM_window_apply_variant_configuration(bom_window_VC,1,&SvrTag1);
		CALLAPI(BOM_window_hide_unconfigured(bom_window_VC));				
		CALLAPI(BOM_window_hide_variants(bom_window_VC));  
		printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
		BOM_window_ask_variant_rules(bom_window_VC,&vcount,&bomvariantlist); 
		if(vcount > 0)
		{													
			printf( "\n SVR is applied:..\n");																		 
			printf("\nSVR count:%d\n",vcount);	fflush(stdout);
		}
		else
		{
			printf( "\n NO SVR applied in BOM window ..\n");
		}	
		CALLAPI(BOM_window_ask_is_modified(bom_window_VC,&modB));
		if(modB)
		{
			printf( "\n modified bom window:..\n");
		}
		else
		{
			printf( "\n not modfiifed ..\n");
		}	
		
	}
	else
	{
		CALLAPI(BOM_set_window_top_line( bom_window_VC, NULLTAG,VehRev1 , NULLTAG, &top_line_VC));
		
	}
	CALLAPI(BOM_line_ask_all_child_lines(top_line_VC, &n_lines_VC_Cnt, &lines_VC));
	printf("\n Total BOM Lines 1 %d\n",n_lines_VC_Cnt); fflush(stdout);
	
	int CNT_VC1=0;
	int TotalModuleInput1=0;
	if (VehFlag1==0)
	{
		for (zx=0;zx<n_lines_VC_Cnt ;zx++)
		{
			CALLAPI(BOM_line_ask_all_child_lines(lines_VC[zx], &sub_n_lines_VC_Cnt, &sub_lines_VC));
			for (zy=0;zy<sub_n_lines_VC_Cnt ;zy++)
			{
				LINE_VC[CNT_VC1]=sub_lines_VC[zy];
				CNT_VC1++;
			}
		}
		printf("\n Total Modules in Input 1  %d\n",CNT_VC1); fflush(stdout);
		TotalModuleInput1=CNT_VC1;
	}
	else
	{
		printf("\n Total Modules in Input 1  %d\n",n_lines_VC_Cnt); fflush(stdout);
		TotalModuleInput1=n_lines_VC_Cnt;
	}
	
	


	/// Find the platform


	CALLAPI(BOM_create_window(&bom_window_SVR));
	
	if (VehFlag2==0)
	{
		CALLAPI(BOM_window_set_closure_rule( bom_window_SVR,close_tag, 0, rulename_SVR,rulevalue_SVR ));
		CALLAPI(CFM_find("ERC release and above", &rule2));
	}
	else
	{
		CALLAPI(CFM_find( RevisionRule, &rule2 ));

		if (!DateConvFlag)
		{
			printf( "\n Inside date set2 applied:..\n");	fflush(stdout);
			CALLAPI(CFM_rule_set_date( rule2, Date_Eff )); //sks
			
		}
		
	}
	if (rule2)
	{
		CALLAPI(BOM_set_window_config_rule( bom_window_SVR, rule2));	
	}
	CALLAPI(BOM_set_window_pack_all(bom_window_SVR, TRUE));  
	

	if (VehFlag2==0)
	{
		CALLAPI(BOM_set_window_top_line( bom_window_SVR, NULLTAG,PlatformRevTag , NULLTAG, &top_line_SVR));
		BOM_window_apply_variant_configuration(bom_window_SVR,1,&SvrTag2);
		CALLAPI(BOM_window_hide_unconfigured(bom_window_SVR));				
		CALLAPI(BOM_window_hide_variants(bom_window_SVR));  
		printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
		BOM_window_ask_variant_rules(bom_window_SVR,&vcount,&bomvariantlist); 
		if(vcount > 0)
		{													
			printf( "\n SVR is applied:..\n");	fflush(stdout);																	 
			printf("\nSVR count:%d\n",vcount);	fflush(stdout);
		}
		else
		{
			printf( "\n NO SVR applied in BOM window ..\n");fflush(stdout);
		}	
		CALLAPI(BOM_window_ask_is_modified(bom_window_SVR,&modB));
		if(modB)
		{
			printf( "\n modified bom window:..\n");fflush(stdout);
		}
		else
		{
			printf( "\n not modfiifed ..\n");fflush(stdout);
		}	
	}
	else
	{
		CALLAPI(BOM_set_window_top_line( bom_window_SVR, NULLTAG,VehRev2 , NULLTAG, &top_line_SVR));
	}
	printf("\n inside bom_window-----444\n"); fflush(stdout);	
	
	CALLAPI(BOM_line_ask_all_child_lines(top_line_SVR, &n_lines_SVR_Cnt, &lines_SVR));

	printf("\n Total BOM Lines 2 %d\n",n_lines_SVR_Cnt); fflush(stdout);	


	int CNT_SVR1=0;
	int TotalModuleInput2=0;
	if (VehFlag2==0)
	{
		for (zx=0;zx<n_lines_SVR_Cnt ;zx++)
		{
			printf("\n Arch Node %d\n",zx); fflush(stdout);
			CALLAPI(BOM_line_ask_all_child_lines(lines_SVR[zx], &sub_n_lines_SVR_Cnt, &sub_lines_SVR));
			for (zy=0;zy<sub_n_lines_SVR_Cnt ;zy++)
			{
				LINE_SVR[CNT_SVR1]=sub_lines_SVR[zy];
				CNT_SVR1++;
				printf("\n Total Modules 2 %d\n",CNT_SVR1); fflush(stdout);
			}
		}
		printf("\n Total Modules 2 %d\n",CNT_SVR1); fflush(stdout);
		TotalModuleInput2=CNT_SVR1;
	}
	else
	{
		printf("\n Total Modules in Input 2  %d\n",n_lines_SVR_Cnt); fflush(stdout);
		TotalModuleInput2=n_lines_SVR_Cnt;

	}


	int CMcnt=0;
	int I1=0;
	int I2=0;





	if (VehFlag1==0)
	{
		fprintf(fd,"Module only availabe with SVR %s\n",SVR1);
	}
	else
	{
		fprintf(fd,"Module only availabe with Vehicle %s;%s;%s\n",Veh_1,Veh_Rev_1,Veh_Seq_1);
	}

	
	for (I1=0;I1<TotalModuleInput1;I1++)
	{
		if (VehFlag1==0)
		{
			InpModTag1=LINE_VC[I1];
		}
		else
		{
			InpModTag1=lines_VC[I1];
		}


		CALLAPI(AOM_ask_value_string(InpModTag1,"bl_item_item_id",&mod_name_VC));
		flagMatch=0;

		for (I2=0;I2<TotalModuleInput2;I2++)
		{
			if (VehFlag2==0)
			{
				InpModTag2=LINE_SVR[I2];
			}
			else
			{
				InpModTag2=lines_SVR[I2];
			}
			CALLAPI(AOM_ask_value_string(InpModTag2,"bl_item_item_id",&mod_name_SVR));
			if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
			{
				flagMatch=1;
				CommonModule[CMcnt]=InpModTag2;
				CMcnt++;
				break;
			}
		}

		if (flagMatch==0)
		{
			
			
			CALLAPI(AOM_ask_value_string(InpModTag1,"bl_item_object_desc",&mod_name_VC_desc));
			STRNG_replace_str(mod_name_VC_desc,",",";",&mod_name_VC_descDup);
			CALLAPI(AOM_ask_value_string(InpModTag1,"bl_Design Revision_t5_ModuleAddress",&mod_name_VC_Add));
			printf("\n\t\t\t difference in BOM for SVR=========================================>>> %s\n",mod_name_VC,mod_name_VC_descDup,mod_name_VC_Add);	fflush(stdout);
			fprintf(fd,"%s,%s,%s,\n",mod_name_VC,mod_name_VC_descDup,mod_name_VC_Add);
		}

	}

	if (VehFlag2==0)
	{
		fprintf(fd,"\n\nModule only availabe with SVR %s\n",SVR2);
	}
	else
	{
		fprintf(fd,"\n\nModule only availabe with Vehicle %s;%s;%s\n",Veh_2,Veh_Rev_2,Veh_Seq_2);
	}

	for (I2=0;I2<TotalModuleInput2;I2++)
	{
		if (VehFlag2==0)
		{
			InpModTag2=LINE_SVR[I2];
		}
		else
		{
			InpModTag2=lines_SVR[I2];
		}


		CALLAPI(AOM_ask_value_string(InpModTag2,"bl_item_item_id",&mod_name_SVR));
		flagMatch=0;

		for (I1=0;I1<TotalModuleInput1;I1++)
		{
			if (VehFlag1==0)
			{
				InpModTag1=LINE_VC[I1];
			}
			else
			{
				InpModTag1=lines_VC[I1];
			}
			CALLAPI(AOM_ask_value_string(InpModTag1,"bl_item_item_id",&mod_name_VC));
			if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
			{
				flagMatch=1;
				break;
			}
		}

		if (flagMatch==0)
		{
			CALLAPI(AOM_ask_value_string(InpModTag2,"bl_item_object_desc",&mod_name_SVR_desc));
			STRNG_replace_str(mod_name_SVR_desc,",",";",&mod_name_SVR_descDup);
			CALLAPI(AOM_ask_value_string(InpModTag2,"bl_Design Revision_t5_ModuleAddress",&mod_name_SVR_Add));
			printf("\n\t\t\t difference in BOM for SVR=========================================>>> %s,%s,%s\n",mod_name_SVR,mod_name_SVR_descDup,mod_name_SVR_Add);	fflush(stdout);
			fprintf(fd,"%s,%s,%s,\n",mod_name_SVR,mod_name_SVR_descDup,mod_name_SVR_Add);
		}

	}

	int I3=0;



	fprintf(fd,"\n\nCommon Module \n");

	for (I3=0;I3<CMcnt;I3++)
	{
		CALLAPI(AOM_ask_value_string(CommonModule[I3],"bl_item_item_id",&mod_name_common));
		CALLAPI(AOM_ask_value_string(CommonModule[I3],"bl_item_object_desc",&mod_name_common_desc));
		STRNG_replace_str(mod_name_common_desc,",",";",&mod_name_common_descDup);
		CALLAPI(AOM_ask_value_string(CommonModule[I3],"bl_Design Revision_t5_ModuleAddress",&mod_name_common_Add));
		printf("\n\t\t\t common================================>>> %s,%s,%s\n",mod_name_common,mod_name_common_descDup,mod_name_common_Add);	fflush(stdout);
		fprintf(fd,"%s,%s,%s,\n",mod_name_common,mod_name_common_descDup,mod_name_common_Add);
	}

		
	if (fd)
	{
		fclose(fd);
	}


	
	tag_t msExcelType	= NULLTAG;
	tag_t ExcelDataset	= NULLTAG;
	tag_t ExlLatestDat_t	= NULLTAG;

	printf("\n going for dataset\n");fflush(stdout);
	//CALLAPI(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
	CALLAPI(AE_find_datasettype2("MSExcel",&msExcelType));
	if(msExcelType == NULLTAG)
	{
		printf("\n Could not find Dataset\n");fflush(stdout);
	}
	printf("\n Dataset Creation, ");fflush(stdout);
	CALLAPI(AE_create_dataset_with_id(msExcelType,DataSetName,"Module Comparision Report","","",&ExcelDataset));
	CALLAPI(AE_save_myself(ExcelDataset));
	//printf(" Relation Creation, ");fflush(stdout);
	//(GRM_create_relation(DmlTag,ExcelDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
	//printf(" done, ");fflush(stdout);
	//CALLAPI(AOM_load(dml_Ref_Rel_t));
	//printf(" load, ");fflush(stdout);
	//CALLAPI(GRM_save_relation(dml_Ref_Rel_t));
	printf(" save, ");fflush(stdout);
	CALLAPI(AE_ask_dataset_latest_rev(ExcelDataset,&ExlLatestDat_t));
	printf(" lst rev, ");fflush(stdout);
	CALLAPI(AOM_refresh(ExlLatestDat_t,TRUE));
	CALLAPI(AE_import_named_ref(ExlLatestDat_t,"excel",FileDown,NULL,SS_BINARY));
	printf(" name ref, ");fflush(stdout);
	CALLAPI(AE_save_myself(ExlLatestDat_t));
	CALLAPI(AE_save_myself(ExcelDataset));
	//CALLAPI(AOM_refresh (DmlTag, 0));
	if( FL_user_update_newstuff_folder(ExcelDataset) );
	
	//tag_t	tUser							= NULLTAG;
	//tag_t	tHome_Folder					= NULLTAG;
	//char*   user_name;
	//
	//CALLAPI(POM_get_user(&user_name,&tUser));
	//CALLAPI(SA_ask_user_home_folder (tUser,&tHome_Folder));
	//
	//CALLAPI(AOM_lock(tHome_Folder));
	//CALLAPI(FL_insert(tHome_Folder,ExlLatestDat_t,999));
	//CALLAPI(AOM_save(tHome_Folder));
	//CALLAPI(AOM_unlock(tHome_Folder));
	//CALLAPI(AOM_refresh(tHome_Folder,1));
	





	//remove(FileDown);
	
	

MEM_free(list_of_WSO_tags1);
MEM_free(list_of_WSO_tags2);
BOM_close_window(bom_window_VC);
	*Out="Report fired Successfully. Please check you NEWSTUFF folder";
	return status;	
}
;

tag_t svr_update_rel_status(tag_t object_tag)
{		
		tag_t		class_id				=     NULLTAG;
		char		*class_name				=    NULL;
		tag_t		tReleaseStatusList_checkin=NULLTAG; 
		logical		log1;
		int			n_values_checkin			=0;
		int			cunt1					=	0; 
		tag_t*		attr_tags_checkin		=	NULLTAG; 
		logical		*is_it_null_checkin		=   NULL; 
		logical		*is_it_empty_checkin	=   NULL;
		
		int status = ITK_ok;
		
		status = POM_class_of_instance(object_tag,&class_id); 

		status = POM_name_of_class(class_id,&class_name); 

		status = POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin);fflush(stdout);
		if(status==ITK_ok)
	    {
			printf("\nSVR:release_status_list found\n");
		}

		status =POM_unload_instances (1,&object_tag);
		status =POM_load_instances(1,&object_tag,class_id,1);
		status =POM_is_loaded(object_tag,&log1);
		if(status==ITK_ok)
	    {
			//printf("\n\nSVR:status Updated......\n");
		}

//		if(log1 == 1)
//		{
//			 printf(" Load Success\n " );
//		}else
//		printf("Load Failure\n"  );

		status =POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin);
		if(status==ITK_ok)
	    {
			printf("\nnSVR:No of status:%d\n",n_values_checkin);fflush(stdout);
		}
		
		if(n_values_checkin>0)
		{
			status = POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin);
//			if(status==ITK_ok)
//			{
//				printf("\nSVR:No of status:%d\n",n_values_checkin);fflush(stdout);
//			}

			for (cunt1 =0;cunt1 < n_values_checkin; cunt1++)
			{ 
				char*			WSO_Name					= NULL;
				status = AOM_ask_name(attr_tags_checkin[cunt1],&WSO_Name);
				printf("\nSVR:del existing status:%d\n",cunt1);fflush(stdout);  
				status =POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1);
				//				if(status==ITK_ok)
//				{
//					printf("\nSVR:no of status del:%d\n",cunt1);fflush(stdout);
//				}			
				status =POM_save_instances(1,&object_tag,1);
				status =POM_refresh_instances(1,&object_tag,class_id,2);
				status =AOM_lock(object_tag);
				status =AOM_save(object_tag);
				status =AOM_refresh(object_tag,1);
			}

			status =POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin);
			if(status==ITK_ok)
			{
				printf("\nnSVR: No of status after delete:%d\n",n_values_checkin);fflush(stdout);

			}


			 status =AOM_unlock(object_tag);
			 if(status==ITK_ok)
			 {
				printf("\nSVR return\n");fflush(stdout);
			 }
		  }
	return object_tag;
}
;


extern EPM_decision_t DLLAPI svr_chk_assigned_participants(EPM_rule_message_t msg)
	{
		int count,i = 0;
		tag_t root_task=NULLTAG;
		EPM_decision_t decision;
		tag_t *attachments = NULLTAG;
		tag_t objTypeTag = NULLTAG;
		tag_t    	    propEff_tag				    =NULLTAG;

		char*	username				=NULL;
		tag_t	user_tag				=NULLTAG;
 		char*	CurrentTask				=NULL;	
		char*	parent_name				=NULL; 
		char  	type_name[TCTYPE_name_size_c+1];
 		char*	 AnalystName		= NULL;		 
		char*	 biw_review		= NULL;
		char*	 trim_review		= NULL;
		char*	 chassis_review		= NULL;
		char*	 ee_review			= NULL;
		char*	 pt_review			= NULL;
		char*	 vi_review			= NULL;
		int ifail=0;
		
		POM_get_user(&username,&user_tag);
		printf("\n\t Starting for username :%s....\n",username);fflush(stdout);		

		CALLAPI(EPM_ask_root_task(msg.task,&root_task)); 

		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);	

		CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
		printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

		if(strstr(CurrentTask,"Assign Analyst and VI Reviewer")!=NULL)
		{
			CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
			printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);	 
			if(count>0)
			{
			  for(i=0;i<count;i++)
			  {			
				CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
				CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
				printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

				if(tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)				//Task - Analyst, COC Review  
				{				
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"Analyst",&AnalystName));		
//					printf("\n\n\t\t Analyst Name of task :: %s \n",AnalystName);fflush(stdout);  
//					if (tc_strcmp(AnalystName,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Analyst to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Analyst option"); 	
//						return ITK_err;
//					}


					/*******************/
					tag_t Tsk_CRB_rel_type = NULLTAG;
					tag_t* TskCRB = NULLTAG;
				 
					tag_t	ObjTypTskCRB	= NULLTAG;
					char   type_name8[TCTYPE_name_size_c+1];
					int CRBcunt =0;
					int d=0;
					int anaflag=0;

					if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
					if (Tsk_CRB_rel_type!=NULLTAG)
					{
							//printf("\n SVR:inside DML HasParticipant \n");fflush(stdout);
							if(GRM_list_secondary_objects_only(attachments[i],Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
							printf("\nSVR:Task Participants: %d",CRBcunt);fflush(stdout);	
							for (d=0;d<CRBcunt ;d++ )
							{	
							//	printf("\nSVR:d:%d\n",d);fflush(stdout); 
								if(TCTYPE_ask_object_type(TskCRB[d],&ObjTypTskCRB));
								if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
							//	printf("\n SVR:DML: type_name8 :: %s\n", type_name8);fflush(stdout);
								if (strcmp(type_name8,"Analyst")==0)
								{
									printf("\n SVR - Analyst present \n"); fflush(stdout); 
									anaflag=1;
								}
							}
					}
					if(anaflag!=1)
					{						
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Analyst to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Analyst option"); 	
						return ITK_err;					
					}

					/*******************/

//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_BIWReviewer",&biw_review));	
//					printf("\n\n\t\t biw_review:%s\n",biw_review);fflush(stdout);  
//					if (tc_strcmp(biw_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign BIW Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->BIW_COC_Reviewer option"); 	
//						return ITK_err;
//					}
//
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_TRIMReviewer",&trim_review));	
//					printf("\n\n\t\t trim_review:%s\n",trim_review);fflush(stdout);  
//					if (tc_strcmp(trim_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Trim Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Trim_COC_Reviewer option"); 	
//						return ITK_err;
//					}
//
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_CHReviewer",&chassis_review));	
//					printf("\n\n\t\t chassis_review:%s\n",chassis_review);fflush(stdout);  
//					if (tc_strcmp(chassis_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Chassis Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Chassis_COC_Reviewer option"); 	
//						return ITK_err;
//					}
//
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_EEReviewer",&ee_review));	
//					printf("\n\n\t\t ee_review:%s\n",ee_review);fflush(stdout);  
//					if (tc_strcmp(ee_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign E & E Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->EE_COC_Reviewer option"); 	
//						return ITK_err;
//					}
//
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_PTReviewer",&pt_review));	
//					if (tc_strcmp(ee_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Powertrain Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Powertrain_COC_Reviewer option"); 	
//						return ITK_err;
//					} 


				}

				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)   //DML - VI Manager Review 
				{					  
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_VIReviewer",&vi_review));    
//					printf("\n\n\t\t VI Reviewer Name of task :: %s \n",vi_review);fflush(stdout);
//
//					if (tc_strcmp(vi_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls Assign VI Reviewer/Manager to the DML, \nHelp: Go to target","\nUse: Select DML : Tools->Assign Participant->VI Reviewer"); 	
//						return ITK_err;
//					}

					/**************/
					tag_t dml_CRB_rel_type = NULLTAG;
					tag_t DmlCRBTag = NULLTAG;
					tag_t	ObjTypDmlCRB	= NULLTAG;
					int CRBcount = 0;
					char   type_name7[TCTYPE_name_size_c+1];
					int j = 0;
					int viflag=0;
					tag_t* DmlCRB = NULLTAG;

 					if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
					if (dml_CRB_rel_type!=NULLTAG)
					{
						//printf("\nSVR Inside DML HasParticipant.. \n");fflush(stdout);
						if(GRM_list_secondary_objects_only(attachments[i],dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
						printf("\nSVR DML Participant count: %d",CRBcount);fflush(stdout);	
						for (j=0;j<CRBcount ;j++ )
						{	
						 
							DmlCRBTag = DmlCRB[j];
							if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
							if(TCTYPE_ask_name(ObjTypDmlCRB,type_name7));
							//printf("\n SVR:DML: type_name7 :: %s\n", type_name7);fflush(stdout);
							if (strcmp(type_name7,"T5_VIReviewer")==0)
							{
									printf("\n SVR - VI reviewer present \n"); fflush(stdout); 
									viflag=1;
							}
						}
					}
					if(viflag!=1)
					{
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls Assign VI Reviewer/Manager to the DML, \nHelp: Go to target","\nUse: Select DML : Tools->Assign Participant->VI Reviewer"); 	
						return ITK_err;
					
					}
							
							 
					/**************/
				}
			  }
			}
		}

		decision = EPM_go;
		return decision;
	}


 
 extern EPM_decision_t DLLAPI svr_chk_signoff(EPM_rule_message_t msg) 
	{
	  int count,j,l;
	  int m = 0;
 	  tag_t *attachments = NULLTAG;
	  tag_t *DMLRevision = NULLTAG;
	  tag_t  *secondary_objects = NULLTAG;
	  char *user_name;
	  char *class_name;
	  char *class_name1;
 	  tag_t relation_type;
	  tag_t tsk_dml_rel_type;
	  int   n_attchs,partcnt = 0;

  	  tag_t class_id=NULLTAG;
	  tag_t class_id1=NULLTAG;
 	  tag_t root_task=NULLTAG;
 	  tag_t *PartsTag=NULLTAG;
 	  int status = ITK_ok;
  
	  char*	 object_type		= NULL;	
 	  
	  char*	 t5current_name		= NULL;	
 	  char*	 DMLtype			= NULL;	
   	  char*	 current_name		= NULL;
	  char*	 projectname		= NULL;
	  char	*s;
   	  logical is_latest;

 		tag_t DMLLcmTag = NULLTAG;
		tag_t DMLRevTag = NULLTAG;
		int   ifail				= 0;

   		char		   *DMLNumber =NULL;
		char		   *taskGrp	  =NULL;
 
		char*	username				=NULL;

 		EPM_decision_t decision = EPM_go;
		char obj_type[WSO_name_size_c+1];

		CALLAPI(POM_get_user_id (&username));
		printf("\n SVR Release session user:%s\n",username); fflush(stdout);

		if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
		{
		  CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 		  
		  CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		  printf("\nSVR Release No of attachments:%d",count);	
		  
		  if(count > 0)
		  {
				  DMLLcmTag = attachments[0];
				  status = AOM_ask_value_string(DMLLcmTag,"current_name",&t5current_name);
				  printf("\nSVR Release t5current_name:%s",t5current_name);fflush(stdout);

				  if ( status != ITK_ok)
				  {
					 EMH_ask_error_text( status, &s);
					 printf("\nSVR Release Error with AOM_ask_value_string : %s \n",s);
					 MEM_free(s);
					 return status;
				  }
				 
				  CALLAPI(POM_class_of_instance(DMLLcmTag,&class_id));
				  CALLAPI(POM_name_of_class(class_id,&class_name));
				  printf("\nSVR Release class_name of Task :%s",class_name);fflush(stdout); 
				  CALLAPI(AOM_refresh( DMLLcmTag, 0 ));
		  }		  
		  else
		  {
			  EMH_clear_errors();
			  EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "SVR DML Not Found");
			  decision = EPM_nogo;
			  return decision;
		  }
		  

		  if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
		  {
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					if (tsk_dml_rel_type!=NULLTAG)
					{
						CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count,&DMLRevision));
						printf("\nSVR Release DML Revision from Task : %d",count);fflush(stdout);			
							
						for (j=0;j<count ;j++ )
						{	
							CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
							printf("\nSVR Release is_latest : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\nSVR Release DML - Not latest\n");fflush(stdout);
							}else
							{	
								DMLRevTag = DMLRevision[j];
/*
								CALLAPI(AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname));
								printf("\nSVR Release DML Projectname: %s\n",projectname);fflush(stdout);
								
 								CALLAPI(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
								printf("\nSVR Release DML current_name:%s\n",current_name);fflush(stdout);

								DMLNumber = strtok( current_name, "_" );
								taskGrp	  = strtok ( NULL, "_" );
								printf("\nSVR Release DML taskGrp:%s",taskGrp); fflush(stdout); 
*/
								CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
								CALLAPI(POM_name_of_class(class_id1,&class_name1));
								printf("\nSVR Release DML class_name:%s",class_name1);
								
								CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
								printf("\nSVR Release DMLtype:%s",DMLtype);fflush(stdout);

								if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
								{
																
									if(strcmp(DMLtype,"SVR")==0)
									{								
										CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &relation_type));
										if (relation_type!=NULLTAG)
										{				
												CALLAPI(GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects));
												printf("\nSVR Release DML No of DI : %d",n_attchs);fflush(stdout);
												if(n_attchs>0)
												{
													for (l=0;l<n_attchs ;l++ )
													{										 
														 CALLAPI(AOM_ask_value_string(secondary_objects[l],"object_type",&object_type));
														 printf("\nSVR Release DML object_type:%s",object_type);fflush(stdout);											 
														 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
														 {
																CALLAPI(AOM_ask_value_tags(secondary_objects[l],"CMReferences",&partcnt,&PartsTag));
																printf("\nSVR Release DML svrcnt:%d",partcnt);fflush(stdout); 
																if (partcnt>0)
																{ 
																	int tt= 0;
																	tag_t*    list_status=NULLTAG;
																	

																	for (tt=0;tt<partcnt;tt++ )
																	{
																		CALLAPI(AOM_ask_value_string(PartsTag[tt],"object_type",&object_type));
																		 if(strcmp(object_type,"VariantRule")==0)
																		 {
																			 int scnt =0,pp=0,iswip=0;
																		     printf("\nSVR Release DML Target SVR Found:%d\n",tt);fflush(stdout); 
																			 CALLAPI(WSOM_ask_release_status_list(PartsTag[tt],&scnt,&list_status)); 
																			 if(scnt>0)
																			 {
																					for (pp=0;pp<scnt;pp++ )
																					{
																						char*	  WSO_Name	 = NULL;
																						CALLAPI(AOM_ask_name(list_status[pp],&WSO_Name));
																						printf("\nSVR status check:%s\n",WSO_Name);fflush(stdout);																						
																						if(strcmp(WSO_Name,"ERC Released")==0 || strcmp(WSO_Name,"T5_LcsErcRlzd")==0)
																						{
																							iswip =0;
																							EMH_clear_errors();
																							EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "SVR is already released");
																							decision = EPM_nogo;
																							return decision;																					
																						}
																						if(strcmp(WSO_Name,"ERC Review")==0)
																						{
																							iswip =1;																					
																						}

																					}
																			  }
//																			  if(iswip !=1)
//																			  {
//																					EMH_clear_errors();
//																					EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "Only WIP SVR can be attached to the Task of SVR Release DML.");
//																					decision = EPM_nogo;
//																					return decision;	
//																			  }



																		 }
																		 else
																		 {
																			EMH_clear_errors();
																			EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "Only SVR can be attached to the Task of SVR Release DML . Please remove objects other than SVR.");
																			decision = EPM_nogo;
																			return decision;																 
																		 }

																	}

																}
																else
																{
																	EMH_clear_errors();
																	EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "There is no SVR attached to the Task. Please attach SVR to task which you want to release with this dml or remove empty task.");
																	decision = EPM_nogo;
																	return decision;
																}
														 }
														 else
														 {
																	EMH_clear_errors();
																	EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "Error. Object type other than task is attached to DML.");
																	decision = EPM_nogo;
																	return decision;
														 
														 
														 }
														
													}
												}
										} 
								  }
								  else
								  {
									  EMH_clear_errors();
									  EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "ERC-DML should be of type SVR Release");
									  decision = EPM_nogo;
								  }
						  
						//}
							  }else
							  {
								  EMH_clear_errors();
								  EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "Select valid ERC DML");
								  decision = EPM_nogo;
								  return decision;
							  }
				   }
				}
			}
		}
	}
	  decision = EPM_go;
 
	  if(DMLRevision)
				MEM_free(DMLRevision);		
	  
	  if(attachments)
				MEM_free(attachments);


	  if(secondary_objects)
				MEM_free(secondary_objects);

	  return decision;
	  
}


extern EPM_decision_t DLLAPI svr_chk_dmlactive(EPM_rule_message_t msg) 
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;	
	logical			t5InProcess;
	char*			procedure_name				=NULL;	

	tag_t *attachments = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t DMLRevTag = NULLTAG;

	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\ninside svr_chk_dmlactive\n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nSVR DML CurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR DML No of attachments:%d",count);	

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
		CALLAPI(AOM_ask_value_string(DMLLcmTag,"current_name",&t5current_name));
		printf("\nSVR DML name:%s",t5current_name);fflush(stdout); 

		CALLAPI(EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents));
		printf("\nSVR DML No of Parents:%d\n",n_parents); fflush(stdout);

		CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
 
	}  
		
	if (n_parents>1)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "DML already submitted in Lifecycle");
		decision = EPM_nogo;		
	}else
	{
		decision = EPM_go;
	}	
		
	return decision;
}



int svr_stamp_status( EPM_action_message_t msg )
{	
		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l	,cnt	=0;
	
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
		tag_t			*objTypeTagTask			= NULLTAG;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
		tag_t DMLTag = NULLTAG;
		tag_t svrTag = NULLTAG;
		tag_t PrtTag = NULLTAG;
		tag_t *Dml_tasks= NULLTAG;
		tag_t *PartsTag= NULLTAG;
		tag_t attach = NULLTAG;
		tag_t   release_status =NULLTAG;  
 		tag_t    	    propEff_tag				    =NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;
		int  attype = 1,partcnt=0,k=0;
		
		char*			parent_name				=NULL; 
		char*			object_type				=NULL;	
		char*			Analyst_name			=NULL;	
		char*			DmlAnalyst_name			=NULL;	
		
		char*			task_no					=NULL;	
		char*			CurrentTask				=NULL;	
		char*			TaskName				=NULL;	
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;
		char*			svr_name					=NULL;
		char*			ReleaseStatus					=NULL;
		char*			value					=NULL;
		char			*eff_date         = NULL;
		char *FrmDate;
		char *ItemID;
		char cNextDate[20]={0};
		char cCurrentAccessDate[20]={0};
		date_t test_date_1;
		date_t cCurrent_date_1;
	    date_t DayTommorow ;
	    date_t test_date_2;
	    date_t *start_end_date = NULL;
	    //date_t *CLdate = NULL;
	    tag_t eff_d = NULLTAG;
		logical  retain_released_date =TRUE;
		logical stat  ;

		tag_t UpdateRlease_t1			= NULLTAG;
		tag_t UpdateRlease_t2			= NULLTAG;
		tag_t UpdateRlease_t3			= NULLTAG;

 		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
 
 
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);	 
 		
		if(strcmp(parent_name,"SVR Release Workflow")==0)
		{
  			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0)
			{
			    DMLTag = attachments[0];			    	
			}
			CALLAPI(AOM_lock(DMLTag));
			CALLAPI(AOM_set_value_string(DMLTag,"CMClosure","Closed"));
			CALLAPI(AOM_set_value_string(DMLTag,"CMMaturity","Complete"));
			CALLAPI(AOM_set_value_string(DMLTag,"CMDisposition","Approved"));
			
			if(ITK_ok != (ifail = AOM_save(DMLTag)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
			{
				return ifail;
			}

			UpdateRlease_t1 = svr_update_rel_status(DMLTag);
			if (UpdateRlease_t1)
			{
				printf("\n Status Updated NULL on SVR DML Revision Object\n");fflush(stdout);
			}else 
			printf("\n SVR UpdateRlease_t1 not found! ! !");  fflush(stdout);
			
			CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
			CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

			if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
			{
				CALLAPI(EPM_add_release_status(release_status,1,&DMLTag,retain_released_date));
			}
			if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
			{
				return ifail;
			}

		    CALLAPI(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&cnt,&Dml_tasks));
			printf("\n Now cnt:%d\n",cnt);fflush(stdout);

			if (cnt>0)
			{
				for (i=0;i<cnt ;i++ )
				{
					   AOM_ask_value_string(Dml_tasks[i],"object_type",&object_type);
					   printf("\n object_type is :%s\n",object_type);fflush(stdout);

					   if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
					   {
							getCurrentDateTime(cCurrentAccessDate);
							//AOM_set_value_date

							CALLAPI(AOM_lock(Dml_tasks[i]));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosure","Closed"));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMMaturity","Complete"));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMDisposition","Approved"));
							//CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosureDate",cCurrentAccessDate));
							
							if(ITK_ok != (ifail = AOM_save(Dml_tasks[i])))
							{
								return ifail;
							}

							if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
							{
								return ifail;
							}

							UpdateRlease_t2 = svr_update_rel_status(Dml_tasks[i]);
							if (UpdateRlease_t2)
							{
								printf("\nSVR: Status Updated on DML Task\n");fflush(stdout);
							}else 
							printf("\nSVR: release status not found! ! !");  fflush(stdout);
							
							CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
							CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

							if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0  )
							{
								CALLAPI(EPM_add_release_status(release_status,1,&Dml_tasks[i],retain_released_date));
							}
							if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
							{
								return ifail;
							} 
 
						    CALLAPI(AOM_ask_value_tags(Dml_tasks[i],"CMReferences",&partcnt,&PartsTag));
						    printf("\nSVR Cnt:%d\n",partcnt);fflush(stdout);

						   if (partcnt>0)
						   {
							 for (k=0;k<partcnt ;k++ )
							 {							
							 
								svrTag=PartsTag[k];

								CALLAPI(AOM_ask_value_string(svrTag,"object_name",&svr_name));	
								printf("\nSVR Name:%s\n",svr_name);	fflush(stdout);	

								UpdateRlease_t3 = svr_update_rel_status(svrTag);
								if (UpdateRlease_t3)
								{
									printf("\nSVR - Release Status Object returned after svr_update_rel_status\n");fflush(stdout);
								}else 
								printf("\n SVR - Release Status Object Not Found\n");  fflush(stdout);
								
								CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
								CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

								if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
								{
									CALLAPI(EPM_add_release_status(release_status,1,&svrTag,retain_released_date));
								}
								
		 						printf("\nSVR Release Status Created: %s\n",ReleaseStatus);fflush(stdout);
								 
								if((strcmp(ReleaseStatus,"ERC Released")==0) ||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
								{
									if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat)))	 return ifail;  
									printf("\n svr stat:%d\n",stat);

									if(stat != true)
									{
										printf("\nSVR  stat is not true .....\n");
									}
									else
									{
										printf("\nSVR  stat is  true .....\n");
									}
									
									getCurrentDateTime(cCurrentAccessDate);
									if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
									if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail; 
									printf("\nSVR  effectivity_text is value : %s\n",value);
										
									getNextDate(cNextDate);
									printf("\nSVR  cNextDate:%s",cNextDate);
									//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;											
									
									if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))									
									{
										return ifail;
									}
									start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2); 
									start_end_date[0] = test_date_1;
									start_end_date[1] = test_date_2;
									
									if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( release_status)))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_save(eff_d)))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_save(release_status)))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = AOM_refresh( release_status, 0 )))
									{
										return ifail;
									}
										
									if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
									if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail; 
									printf("\nSVR  After setting effectivity_text value : %s\n",value);
									if(ITK_ok != (ifail = AOM_refresh( svrTag, 0 )))
									{
										return ifail;
									}
										
								}
								else
								{
									printf("\nSVR  No status and Effectivity stamping\n ");
								}

								 
							  }
								
							}
						
						}
							
					 }

			 }
			   
	  }
	  else
	  {
		printf("\nSVR  inside else loop \n");fflush(stdout);
	  }
	
		return ITK_ok;
}
;


int GenerateRepSvrImpact (tag_t DmlTag )
{
    int     status=0; 
	char *SVR = NULL;
	char *svr_name = NULL;
 	int ifail =0;
	int n_modes=0;
	char **mode_names = NULL;

	
	char*			mod_name_SVR				=NULL;  
	char*			mod_name_VC				=NULL;  
	char*			SVRname				=NULL;  
	char*			FileDown				=NULL;  
	tag_t			bom_window				=NULLTAG;
	tag_t			bom_window_VC				=NULLTAG;
	tag_t			bom_window_SVR				=NULLTAG;
	tag_t			top_line_VC				=NULLTAG; 
	tag_t			top_line_SVR				=NULLTAG; 
	tag_t			rule					=NULLTAG;
	tag_t			PrdConfigTag			=NULLTAG;
	tag_t			objTypeTagDi			=NULLTAG;
	tag_t			primaryTag				=NULLTAG;
	tag_t			PlatformTag				=NULLTAG;
	tag_t			PlatformTagRev				=NULLTAG;
	tag_t			SvrTag				=NULLTAG;
	//tag_t			*SvrTagS			=NULL;

	tag_t           *bom_variant_config=NULL;
	tag_t           *bomvariantlist_SVR=NULL;
	FILE	*fd;
	

	tag_t *Primary_objects1 = NULL;
	tag_t *Primary_objects2 = NULL;
	tag_t *secondary_objects1 = NULL;
	tag_t *lines_VC = NULL;
	tag_t *sub_lines_VC = NULL;
	tag_t *sub_lines_SVR = NULL;

	char   type_name3[TCTYPE_name_size_c+1];

	WSO_search_criteria_t  	criteria;
	int number_found=0,countS=0;
	tag_t *list_of_WSO_tags=NULL;
	int i=0,k=0,n_lines=0,zz=0,n_lines1=0, vcount=0,countDep=0,vcountSVR=0,SvrFolder_Size=0,sub_n_lines_VC=0,sub_n_lines_SVR=0,n_lines_SVR_Cnt=0;
	int sub_n_lines=0,sub_n_lines1=0, zt=0,countDep1=0,n_lines_VC_Cnt=0,zx=0,zy=0,flagMatch=0,K=0;
	logical modB=FALSE;
	logical modB_SVR=FALSE;

	 tag_t 	*bomvariantlist = NULLTAG;
	 tag_t 	*SvrTagS = NULLTAG;
	 tag_t 	*lines_SVR = NULLTAG;
	 tag_t 	FolderTag = NULLTAG;
	 //char* SVR_Name= NULLTAG;
	 //char* SvrName_Dup= (char *) MEM_alloc ( 100);
	 
	char	SVR_Name_Type[WSO_name_size_c+1] ;
	char	SVR_Name[WSO_name_size_c+1] ;
	char	SvrName_Dup[WSO_name_size_c+1] ;
	const char*	 VcName			= NULL;
	char*	 dmlNumber			= NULL;
	tag_t *tags_found = NULL;
	int n_tags_found= 0;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	tag_t *closurerule = NULL;
	int rulefound=0;
	tag_t close_tag=NULLTAG;
	char **rulename = NULL;
	char **rulevalue = NULL;
	char **rulename_SVR = NULL;
	char **rulevalue_SVR = NULL;

	const char *cTemp="item_id";
	const char *item_name = NULL;

	 int ReqCnt=0;
   


  
	 SVR = (char *) MEM_alloc (sizeof (char) * 128);
	 FileDown = (char *) MEM_alloc (sizeof (char) * 128);
	
	WSOM_clear_search_criteria(&criteria);
	strcpy(criteria.name,"X4_SVR_list");
	strcpy(criteria.class_name,"Folder");
	CALLAPI(WSOM_search(criteria, &number_found, &list_of_WSO_tags));
	printf("\n\n\t\t FOLDER found : %d\n",number_found);fflush(stdout);
	FolderTag=list_of_WSO_tags[0];
	//CALLAPI(CFM_find( "Latest Working", &rule));
	CALLAPI(CFM_find("ERC release and above", &rule));

	//CALLAPI(PIE_find_closure_rules( "BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule ));
	CALLAPI(PIE_find_closure_rules( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
    printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
	close_tag = closurerule[0];
	printf ("closure rule found \n");fflush(stdout);
	
	}


	CALLAPI(AOM_ask_value_string(DmlTag,"item_id",&dmlNumber));
	tc_strcpy(FileDown,"/tmp/");
	tc_strcat(FileDown,dmlNumber);
	tc_strcat(FileDown,"_BomCompare.csv");


	printf("\n\n\t\t file name : %s\n",FileDown);fflush(stdout);
	//CALLAPI(FL_ask_size(FolderTag,&SvrFolder_Size));
	CALLAPI(FL_ask_references(FolderTag,FL_fsc_by_name,&SvrFolder_Size,&SvrTagS));
	printf("\n\n\t\t folder size : %d\n",SvrFolder_Size);fflush(stdout);
	if (SvrFolder_Size >0)
	{
		fd=fopen(FileDown,"w");
		if(fd==NULL)
		{
			printf("\nError in opening the file \n");fflush(stdout);
			
		}
		
		for (ReqCnt=0;ReqCnt<SvrFolder_Size;ReqCnt++)
		{
			SvrTag=SvrTagS[ReqCnt];
			CALLAPI(WSOM_ask_name(SvrTag,SVR_Name));
			CALLAPI(WSOM_ask_name(SvrTag,SvrName_Dup));
			CALLAPI(WSOM_ask_object_type(SvrTag,SVR_Name_Type));
			printf("\nDvoReqRel_Name [%s] and it Is [%s]\n",SVR_Name,SVR_Name_Type);fflush(stdout);
			if (tc_strcmp(SVR_Name_Type,"VariantRule")==0)
			{
				
				fprintf(fd,",SVR  and VC\n");
				
				VcName = tc_strtok(SVR_Name,"_");
				fprintf(fd,"%d,%s and %s \n",ReqCnt,SVR_Name,VcName);

				printf("\nVC_Name [%s]\n",VcName);fflush(stdout);
				//attrs[0] ="item_id";
				values[0] = (char *)VcName;
				
				CALLAPI(ITEM_find_items_by_key_attributes(1,&cTemp, &VcName, &n_tags_found, &tags_found));
				//CALLAPI(ITEM_find_items_by_key_attributes(1,&cTemp, values, &n_tags_found, &tags_found));

				if (n_tags_found == 0)
				{
					printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", VcName);fflush(stdout);
				}
				else if (n_tags_found > 1)
				{
					printf ( "More than one items matched with id %s\n", VcName);fflush(stdout);
				}

				if (n_tags_found==1)
				{
					if (bom_window_VC)
					{
						bom_window_VC=NULLTAG;
					}
					if (top_line_VC)
					{
						top_line_VC=NULLTAG;
					}

					CALLAPI(BOM_create_window(&bom_window_VC));
					CALLAPI(BOM_set_window_config_rule( bom_window_VC, rule));	
					//CALLAPI(BOM_window_set_closure_rule( bom_window_VC,close_tag, 0, rulename,rulevalue ));
					CALLAPI(BOM_set_window_pack_all(bom_window_VC, TRUE));  
					CALLAPI(BOM_set_window_top_line( bom_window_VC, tags_found[0], NULLTAG, NULLTAG, &top_line_VC));
					printf("\n inside bom_window_SVR-----444\n"); fflush(stdout);

					CALLAPI(BOM_line_ask_all_child_lines(top_line_VC, &n_lines_VC_Cnt, &lines_VC));
					printf("\n VC expansion: %d \n", n_lines_VC_Cnt); fflush(stdout);	
					if (n_lines_VC_Cnt >0)
					{
							for (zz=0;zz<n_lines_VC_Cnt ;zz++)
							{
								//CALLAPI(AOM_ask_value_string(lines_VC[zz],"bl_line_name",&mod_name));	
								//printf("\nmod_name:%s\n",mod_name);	fflush(stdout);
								CALLAPI(BOM_line_ask_all_child_lines(lines_VC[zz], &sub_n_lines_VC, &sub_lines_VC));		
							}  
					}

				}

				
				CALLAPI(GRM_list_primary_objects_only(SvrTag,NULLTAG,&countDep,&Primary_objects1));
				printf("count found %d ",countDep);fflush(stdout);
				for (K=0;K < countDep;K++ )
				{
				PrdConfigTag=Primary_objects1[K];							
				CALLAPI(TCTYPE_ask_object_type(PrdConfigTag,&objTypeTagDi));
				CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
				printf( "\n type_name Prd config :%s ..\n",type_name3);
				if (tc_strcmp(type_name3,"Cfg0ProductItem")==0)
				{
					CALLAPI(GRM_list_primary_objects_only(PrdConfigTag,NULLTAG,&countDep1,&Primary_objects2));
					for (i=0;i < countDep1;i++ )
					{
						primaryTag=Primary_objects2[i];
						CALLAPI(TCTYPE_ask_object_type(primaryTag,&objTypeTagDi));
						CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
						printf( "\n type_name Platform :%s ..\n",type_name3);
						if (tc_strcmp(type_name3,"T5_Platform")==0)
						{
							//CALLAPI ( ITEM_ask_latest_rev( primaryTag, &PlatformRevTag ));
							PlatformTag=Primary_objects2[i];
							CALLAPI ( ITEM_ask_latest_rev( PlatformTag, &PlatformTagRev ));
							break;
							
						}
					}
					if (PlatformTag)
					{
						break;
					}

				}
				}
				/// SVR and PLatform both found here
				
				if (PlatformTagRev && SvrTag)
				{
					
					
					CALLAPI(BOM_create_window(&bom_window_SVR));
					CALLAPI(BOM_set_window_config_rule( bom_window_SVR, rule));	
					CALLAPI(BOM_window_set_closure_rule( bom_window_SVR,close_tag, 0, rulename_SVR,rulevalue_SVR ));
					CALLAPI(BOM_set_window_pack_all(bom_window_SVR, TRUE));  
					CALLAPI(BOM_set_window_top_line( bom_window_SVR, NULLTAG,PlatformTagRev , NULLTAG, &top_line_SVR));
					printf("\n inside bom_window-----444\n"); fflush(stdout);			
					BOM_window_apply_variant_configuration(bom_window_SVR,1,&SvrTag);
					CALLAPI(BOM_window_hide_unconfigured(bom_window_SVR));				
					CALLAPI(BOM_window_hide_variants(bom_window_SVR));  

					printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
					BOM_window_ask_variant_rules(bom_window_SVR,&vcount,&bomvariantlist); 
					if(vcount > 0)
					{													
						printf( "\n SVR is applied:..\n");																		 
						printf("\nSVR count:%d\n",vcount);	fflush(stdout);
					}
					else
					{
						printf( "\n NO SVR applied in BOM window ..\n");
					}		
					
					CALLAPI(BOM_window_ask_is_modified(bom_window_SVR,&modB));
					if(modB)
					{
						printf( "\n modified bom window:..\n");
					}
					else
					{
						printf( "\n not modfiifed ..\n");
					}	

					
					CALLAPI(BOM_line_ask_all_child_lines(top_line_SVR, &n_lines_SVR_Cnt, &lines_SVR));
					printf("\n After applying SVR all childlines: %d \n", n_lines_SVR_Cnt); fflush(stdout);	
					if (n_lines_SVR_Cnt >0)
					{
							for (zx=0;zx<n_lines_SVR_Cnt ;zx++)
							{
								//CALLAPI(AOM_ask_value_string(lines_SVR[zx],"bl_line_name",&mod_name_SVR));	
								//printf("\nmod_name:%s\n",mod_name_SVR);	fflush(stdout);
									CALLAPI(BOM_line_ask_all_child_lines(lines_SVR[zx], &sub_n_lines_SVR, &sub_lines_SVR));
									for (zy=0;zy<sub_n_lines_SVR ;zy++)
									{
										CALLAPI(AOM_ask_value_string(sub_lines_SVR[zy],"bl_item_item_id",&mod_name_SVR));
										flagMatch=0;
										//printf("\n\t\t\t starting to comparemod_name SVR:%s\n",mod_name_SVR);	fflush(stdout);	
										for (zt=0;zt<sub_n_lines_VC ;zt++)
										{
											
											CALLAPI(AOM_ask_value_string(sub_lines_VC[zt],"bl_item_item_id",&mod_name_VC));	
											//printf("\n\t\t\tmod_name VC:%s\n",mod_name_VC);	fflush(stdout);
											
											if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
											{
												flagMatch=1;
												break;
											}


										}
										if (flagMatch==0)
										{
											printf("\n\t\t\t difference in BOM for SVR=========================================>>> %s\n",mod_name_SVR);	fflush(stdout);
											fprintf(fd," ,%s, Module from Solved BOM not found under the VC %s BOM \n",mod_name_SVR,VcName);
										}
										
									}  		
							}
							
							///////////// comparing VC
							printf("\n\t\t\tStarting for VC:====================>>>>>>>>>>>>\n");	fflush(stdout);
							for (zt=0;zt<sub_n_lines_VC ;zt++)
							{
											
								CALLAPI(AOM_ask_value_string(sub_lines_VC[zt],"bl_item_item_id",&mod_name_VC));	
								//printf("\n\t\t\tmod_name VC:%s\n",mod_name_VC);	fflush(stdout);
								flagMatch=0;
								for (zx=0;zx<n_lines_SVR_Cnt ;zx++)
								{
										//CALLAPI(AOM_ask_value_string(lines_SVR[zx],"bl_line_name",&mod_name_SVR));	
										//printf("\nmod_name:%s\n",mod_name_SVR);	fflush(stdout);
										CALLAPI(BOM_line_ask_all_child_lines(lines_SVR[zx], &sub_n_lines_SVR, &sub_lines_SVR));
										for (zy=0;zy<sub_n_lines_SVR ;zy++)
										{
											CALLAPI(AOM_ask_value_string(sub_lines_SVR[zy],"bl_item_item_id",&mod_name_SVR));
											
											//printf("\n\t\t\t starting to comparemod_name SVR:%s\n",mod_name_SVR);	fflush(stdout);	

												
												if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
												{
													flagMatch=1;
													break;
												}
											
										}
										if (flagMatch==1)
										{
											break;
										}
								}
								if (flagMatch==0)
								{
												fprintf(fd,", %s,Module from VC not found under the solved BOM of SVR %s \n",mod_name_VC,SvrName_Dup);
												printf("\n\t\t\t difference in BOM for VC=========================================>>> %s\n",mod_name_VC);	fflush(stdout);
												
								}
							}
					}


				} 


			}


		}
		if (fd)
		{
			fclose(fd);
		}
		tag_t dml_Ref_Rel	= NULLTAG;
		tag_t msExcelType	= NULLTAG;
		tag_t ExcelDataset	= NULLTAG;
		tag_t dml_Ref_Rel_t	= NULLTAG;
		tag_t ExlLatestDat_t	= NULLTAG;

		printf("\n going for dataset\n");fflush(stdout);
		CALLAPI(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
		CALLAPI(AE_find_datasettype2("MSExcel",&msExcelType));
		if(msExcelType == NULLTAG)
		{
			printf("\n Could not find Dataset\n");fflush(stdout);
		}
		printf("\n Dataset Creation, ");fflush(stdout);
		CALLAPI(AE_create_dataset_with_id(msExcelType,dmlNumber,"Impact Analysis report for SVR DML","","",&ExcelDataset));
		CALLAPI(AE_save_myself(ExcelDataset));
		printf(" Relation Creation, ");fflush(stdout);
		CALLAPI(GRM_create_relation(DmlTag,ExcelDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
		printf(" done, ");fflush(stdout);
		CALLAPI(AOM_load(dml_Ref_Rel_t));
		printf(" load, ");fflush(stdout);
		CALLAPI(GRM_save_relation(dml_Ref_Rel_t));
		printf(" save, ");fflush(stdout);
		CALLAPI(AE_ask_dataset_latest_rev(ExcelDataset,&ExlLatestDat_t));
		printf(" lst rev, ");fflush(stdout);
		CALLAPI(AOM_refresh(ExlLatestDat_t,TRUE));
		CALLAPI(AE_import_named_ref(ExlLatestDat_t,"excel",FileDown,NULL,SS_BINARY));
		printf(" name ref, ");fflush(stdout);
		CALLAPI(AE_save_myself(ExlLatestDat_t));
		CALLAPI(AE_save_myself(ExcelDataset));
		CALLAPI(AOM_refresh (DmlTag, 0));

		remove(FileDown);
	}

	MEM_free(list_of_WSO_tags);
	//BOM_close_window(bom_window_SVR);
	//BOM_close_window(bom_window_VC);
 		 
	return ITK_ok;	
} 

int svr_impact_analysis( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;
	tag_t	DMLRevTag			=NULLTAG;
	tag_t	DMLLcmTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	*attachments		=NULL;
	tag_t	*DMLRevision		=NULL;
	int i=0,j=0,count=0,count_rev=0;
	logical is_latest;
	char *dmlNumber=NULL;
	char *dmlrelease_type=NULL;
	char   ObjTyp[TCTYPE_name_size_c+1];
	tag_t tsk_dml_rel_type;
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			DMLLcmTag=attachments[i];
			if(TCTYPE_ask_object_type(DMLLcmTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				
				if (tsk_dml_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count_rev,&DMLRevision));
					printf("\nSVR Release DML Revision from Task : %d",count);fflush(stdout);			
						
					for (j=0;j<count_rev ;j++ )
					{	
						CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
						printf("\nSVR Release is_latest : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\nSVR Release DML - Not latest\n");fflush(stdout);
						}else
						{	
							DMLRevTag = DMLRevision[j];

							CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNumber));
							CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&dmlrelease_type));
							printf("\n DML Nos is %s  release type is %s\n",dmlNumber,dmlrelease_type);fflush(stdout);
							break;
							break;
							// need to write code here
						}
					}
				}
			}
		}

		if (DMLRevTag)
		{
			printf("\n Inside DMLRevTag DML Nos is %s  release type is %s\n",dmlNumber,dmlrelease_type);fflush(stdout);
			GenerateRepSvrImpact (DMLRevTag);
			printf("\n After GenerateRepSvrImpact\n");fflush(stdout);
		}

	}
return ITK_ok;
}
;
int svr_Report_Fun (tag_t DmlTag,tag_t SvrTag )
{
    int status=0; 
 	int ifail =0;



	FILE	*fd;


	tag_t  *Primary_objects1	= NULLTAG;
	tag_t  *secondary_objects	= NULLTAG;
	tag_t  primary	= NULLTAG;
	tag_t  primary1	= NULLTAG;
	tag_t  objTypeTagDi	= NULLTAG;
	tag_t  objTypeTagDi1	= NULLTAG;
	
	char   type_name3[TCTYPE_name_size_c+1];
	char   type_name[TCTYPE_name_size_c+1];
	char *Context_Str=NULL;
	char *Svr_Str=NULL;
	char *dmlNumber=NULL;
	char *FileDown=NULL;
	char *Context_VariantRule=NULL;
	char *OptfmlyName_O=NULL;
	char *OptValName_O=NULL;
	int countDep=0,countDep1=0,k=0,j=0,cnt1=0;

	FileDown = (char *) MEM_alloc (sizeof (char) * 200);

	CALLAPI(AOM_ask_value_string(SvrTag,"object_name",&Svr_Str));
	printf(" \n SVR Name %s \n",Svr_Str);fflush(stdout);
	

	CALLAPI(AOM_ask_value_string(SvrTag,"cfg0VariantRuleText",&Context_VariantRule));;
	printf("\n Context_VariantRule is  :: %s\n",Context_VariantRule);fflush(stdout);
	
	CALLAPI(GRM_list_primary_objects_only(SvrTag,NULLTAG,&countDep,&Primary_objects1));
	printf("count found %d ",countDep);fflush(stdout);
	for (cnt1=0;cnt1<countDep;cnt1++)
	{
		primary=Primary_objects1[cnt1];							
		CALLAPI(TCTYPE_ask_object_type(primary,&objTypeTagDi));
		CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
		printf( "\n type_name3 :%s ..\n",type_name3);
		if (tc_strcmp(type_name3,"Cfg0ProductItem")==0)
		{
			CALLAPI(AOM_ask_value_string(primary,"item_id",&Context_Str));
			printf("\n Context_Str  is  :: %s\n",Context_Str);

			break;
		}
	}
	
	CALLAPI(AOM_ask_value_string(DmlTag,"item_id",&dmlNumber));
	
	strcpy(FileDown,"/tmp/SVR_");
	strcat(FileDown,Svr_Str);
	strcat(FileDown,"_");
	strcat(FileDown,dmlNumber);
	strcat(FileDown,".csv");

	fd=fopen(FileDown,"a");
	if (fd)
	{
		fprintf(fd,"Sr.No,Option Family,Option Value,Value,\n");
		char *qry_entriesOptFam[] = {"ID"};
		char **qry_valuesOptFam = (char **) MEM_alloc(10 * sizeof(char *));
		tag_t Optfmly_tag = NULLTAG;
		tag_t queryTagOptFam = NULLTAG;
		tag_t *revOptFam=NULL;
		int resultCountOptFam=0,n_entriesOptFam=1;
		
		char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
		char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));
		tag_t OptfmlyVal_tag = NULLTAG;
		tag_t queryTagOptFamVal = NULLTAG;
		tag_t *revOptFamVal=NULL;
		int resultCountOptFamVal=0,n_entriesOptFamVal=2,i=0;
		char* OptValName=NULL;
		char* OptfmlyName=NULL;
		char* VariantFormulaStr=NULL;
		char* VariantFormulaStrOptionVal=NULL;
		VariantFormulaStr=(char *)MEM_alloc(300);
		VariantFormulaStrOptionVal=(char *)MEM_alloc(300);

		if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTagOptFam));
		printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
		if (queryTagOptFam)
		{
			printf("2.Found Query \n");fflush(stdout);
		}
		else
		{
			printf("Not Found Query");fflush(stdout);
		}
		 qry_valuesOptFam[0] = Context_Str;
		if(QRY_execute(queryTagOptFam, n_entriesOptFam, qry_entriesOptFam, qry_valuesOptFam, &resultCountOptFam, &revOptFam));
		printf(" \n resultCountOptFam : %d\n", resultCountOptFam); fflush(stdout);

		for (j=0;j<resultCountOptFam;j++ )
		{
			Optfmly_tag = revOptFam[j];
			CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName));
			printf("\n\t OptfmlyName Object String Type is :%s",OptfmlyName);	fflush(stdout);
			tc_strcpy(VariantFormulaStr,"");
			if (tc_strstr(OptfmlyName," ")!=NULL)
			{
				tc_strcat(VariantFormulaStr,"'");
				tc_strcat(VariantFormulaStr,OptfmlyName);
				tc_strcat(VariantFormulaStr,"'");
			}
			else
			{
				tc_strcat(VariantFormulaStr,OptfmlyName);
			}
			tc_strcat(VariantFormulaStr," = ");
			printf("\n\t VariantFormulaStr is :<%s>",VariantFormulaStr);	fflush(stdout);
			STRNG_replace_str(OptfmlyName,",",";",&OptfmlyName_O);
			fprintf(fd,"%d",j+1);
			fprintf(fd,",");
			fprintf(fd,OptfmlyName_O);
			fprintf(fd,",,\n");

			if(QRY_find("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTagOptFamVal));
			printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
			if (queryTagOptFamVal)
			{
				printf("2.Found Query \n");fflush(stdout);
			}
			else
			{
				printf("Not Found Query");fflush(stdout);
			}
			qry_valuesOptFamVal[0]= OptfmlyName;
			qry_valuesOptFamVal[1]= Context_Str;
			if(QRY_execute(queryTagOptFamVal, n_entriesOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &resultCountOptFamVal, &revOptFamVal));
			for (i=0;i<resultCountOptFamVal;i++ )
			{
				OptfmlyVal_tag = revOptFamVal[i];
				CALLAPI(AOM_ask_value_string(OptfmlyVal_tag,"object_name",&OptValName));
				printf("\n\t Value Object String  is :%s",OptValName);	fflush(stdout);
				STRNG_replace_str(OptValName,",",";",&OptValName_O);
				fprintf(fd,",,");
				fprintf(fd,OptValName_O);
				fprintf(fd,",");
				tc_strcpy(VariantFormulaStrOptionVal,"");
				tc_strcat(VariantFormulaStrOptionVal,VariantFormulaStr);
				
				if (tc_strstr(OptValName," ")!=NULL)
				{
					tc_strcat(VariantFormulaStrOptionVal,"'");
					tc_strcat(VariantFormulaStrOptionVal,OptValName);
					tc_strcat(VariantFormulaStrOptionVal,"'");
				}
				else
				{
					tc_strcat(VariantFormulaStrOptionVal,OptValName);
				}
				

				if (tc_strstr(Context_VariantRule,VariantFormulaStrOptionVal)!=NULL)
				{
					fprintf(fd,"1,\n");
					printf("\n\t Final VariantFormulaStr is :<%s>",VariantFormulaStrOptionVal);	fflush(stdout);
				}
				else
				{
					fprintf(fd,"0,\n");
				}
				//fprintf(fd,ContextobjName);

			}
			fprintf(fd,",,,\n");
		}
	}
	

	
	if (fd)
	{
		fclose(fd);
		tag_t dml_Ref_Rel	= NULLTAG;
		tag_t msExcelType	= NULLTAG;
		tag_t ExcelDataset	= NULLTAG;
		tag_t dml_Ref_Rel_t	= NULLTAG;
		tag_t ExlLatestDat_t	= NULLTAG;

		printf("\n going for dataset\n");fflush(stdout);
		CALLAPI(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
		CALLAPI(AE_find_datasettype2("MSExcel",&msExcelType));
		if(msExcelType == NULLTAG)
		{
			printf("\n Could not find Dataset\n");fflush(stdout);
		}
		printf("\n Dataset Creation, ");fflush(stdout);
		CALLAPI(AE_create_dataset_with_id(msExcelType,Svr_Str,"SVR Report","","",&ExcelDataset));
		CALLAPI(AE_save_myself(ExcelDataset));
		printf(" Relation Creation, ");fflush(stdout);
		CALLAPI(GRM_create_relation(DmlTag,ExcelDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
		printf(" done, ");fflush(stdout);
		CALLAPI(AOM_load(dml_Ref_Rel_t));
		printf(" load, ");fflush(stdout);
		CALLAPI(GRM_save_relation(dml_Ref_Rel_t));
		printf(" save, ");fflush(stdout);
		CALLAPI(AE_ask_dataset_latest_rev(ExcelDataset,&ExlLatestDat_t));
		printf(" lst rev, ");fflush(stdout);
		CALLAPI(AOM_refresh(ExlLatestDat_t,TRUE));
		CALLAPI(AE_import_named_ref(ExlLatestDat_t,"excel",FileDown,NULL,SS_BINARY));
		printf(" name ref, ");fflush(stdout);
		CALLAPI(AE_save_myself(ExlLatestDat_t));
		CALLAPI(AE_save_myself(ExcelDataset));
		CALLAPI(AOM_refresh (DmlTag, 0));

		remove(FileDown);
	}
	

	//MEM_free(list_of_WSO_tags);
	//BOM_close_window(bom_window_SVR);
	//BOM_close_window(bom_window_VC);
 		 
	return ITK_ok;	
} 
int svr_Report( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;
	tag_t	DMLRevTag			=NULLTAG;
	tag_t	DMLLcmTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	*attachments		=NULL;
	tag_t	*DMLRevision		=NULL;
	int i=0,j=0,count=0,count_rev=0;
	logical is_latest;
	char *dmlNumber=NULL;
	char *dmlrelease_type=NULL;
	char   ObjTyp[TCTYPE_name_size_c+1];
	tag_t tsk_dml_rel_type;
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			DMLLcmTag=attachments[i];
			if(TCTYPE_ask_object_type(DMLLcmTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				
				if (tsk_dml_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count_rev,&DMLRevision));
					printf("\nSVR Release DML Revision from Task : %d",count);fflush(stdout);			
						
					for (j=0;j<count_rev ;j++ )
					{	
						CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
						printf("\nSVR Release is_latest : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\nSVR Release DML - Not latest\n");fflush(stdout);
						}else
						{	
							DMLRevTag = DMLRevision[j];

							CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNumber));
							CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&dmlrelease_type));
							printf("\n DML Nos is %s  release type is %s\n",dmlNumber,dmlrelease_type);fflush(stdout);
							break;
							
							
						}
					}
				}
				////SVR Report //////
				int svrcnt=0,tt=0;
				tag_t *SvrsTag= NULLTAG;
				char*	object_type	=NULL;	

				CALLAPI(AOM_ask_value_tags(DMLLcmTag,"CMReferences",&svrcnt,&SvrsTag));
				printf("\nSVR Release DML svrcnt:%d",svrcnt);fflush(stdout); 
				if (svrcnt>0)
				{ 

					for (tt=0;tt<svrcnt;tt++ )
					{
						CALLAPI(AOM_ask_value_string(SvrsTag[tt],"object_type",&object_type));
						 if(strcmp(object_type,"VariantRule")==0)
						 {
							 svr_Report_Fun(DMLRevTag,SvrsTag[tt]);
						 }
					}
				}

			}
		}

	}
return ITK_ok;
}
;
 
 
int GetSpecialCharacterCount (char* mainStringf)
{
	int i=0,alphabets=0,digits=0,special=0,space=0;

	

	
  	while ( *(mainStringf+i) != '\0')
  	{
  		if( (*(mainStringf+i) >= 'a' && *(mainStringf+i) <= 'z') || (*(mainStringf+i) >= 'A' && *(mainStringf+i) <= 'Z') )
  		{
  			alphabets++;  	
 		}
  		else if (*(mainStringf+i) >= '0' && *(mainStringf+i) <= '9')
  		{
  			digits++;  	
  		}
		else if ((*(mainStringf+i)=='`')||(*(mainStringf+i)=='~')||(*(mainStringf+i)=='!')||(*(mainStringf+i)=='@')||(*(mainStringf+i)=='#')||(*(mainStringf+i)=='$')||(*(mainStringf+i)=='%')||(*(mainStringf+i)=='^')||(*(mainStringf+i)=='&')||(*(mainStringf+i)=='*')|| (*(mainStringf+i)=='(')||(*(mainStringf+i)==')')||(*(mainStringf+i)=='-')||(*(mainStringf+i)=='=')||(*(mainStringf+i)=='[')||(*(mainStringf+i)==']')||(*(mainStringf+i)=='|'))
		{
			special++;
		}
  		else
		{
			printf("\n!!!!!!!!!!!!!!!!! GetSpecialCharacterCount:::::::::NOT special..................\n");fflush(stdout);
		}
    	i++;
	}

	printf("\n!!!!!!!!!!!!!!!!! GetSpecialCharacterCount:::::::::special[%d],[%d][%d][%d]\n",special,alphabets,digits,space);fflush(stdout);


	return special;
}

extern DLLAPI int  save_method_MDMFamily_Pre(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int		ifail				= 0;
	int status;

	tag_t objTag = va_arg(args, tag_t);


	char*  OptFm_No=NULL;
	char*  MDM_DML=NULL;


	if (objTag)
	{
		ITK_CALL(AOM_UIF_ask_value(objTag,"t5_MDM_DML",&MDM_DML));

		ITK_CALL(AOM_ask_value_string(objTag,"object_name",&OptFm_No));  //T5_Opt_Family_Value
		printf("\n OptFm_No is :%s\n",OptFm_No);fflush(stdout);

		if (OptFm_No)
		{
			
			if (tc_strlen(OptFm_No) > 29 )
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Unable to create/Update this MDM Option family as this Option family Name has 30 or more than 30 characters.");
				return ITK_err;
			}

			if (!tc_strstr(OptFm_No," "))
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Single Value description of Options family Name should not get created into Teamcenter.");
				return ITK_err;
			}
			int SpecialChar=0;
			SpecialChar=GetSpecialCharacterCount(OptFm_No);
			printf("\n!!!!!!!!!!!!!!!!! save_method_OptValue_Pre:::::::::SpecialChar [%d]\n",SpecialChar);fflush(stdout);
			if (SpecialChar)
			{
				printf("\n!!!!!!!!!!!!!!!!! Inside ERROR MESSAGE:::::::::SpecialChar [%d]\n",SpecialChar);fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Special characters in Option family not allowed. Only Alphabets and digits are allowed.");
				return ITK_err;
			}
		}

		int num_Opt=0;
		int IOpt=0;
		char **OpTValueList;
		
		ITK_CALL(AOM_ask_value_strings(objTag,"t5_OptionValueMDM",&num_Opt,&OpTValueList));

		if (num_Opt > 0)
		{
			for (IOpt=0;IOpt<num_Opt;IOpt++ )
			{
				
				printf("\n OptFm_No is :%s\n",OpTValueList[IOpt]);fflush(stdout);

				if (tc_strlen(OpTValueList[IOpt]) > 29 )
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Unable to create/update  Option value as this Option value has 30 or more than 30 characters.");
					return ITK_err;
				}

				/*if (!tc_strstr(ObjFamilyVal," "))
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Single Value description of Options Value should not get created into Teamcenter.");
					return ITK_err;
				}*/

				int SpecialChar=0;
				SpecialChar=GetSpecialCharacterCount(OpTValueList[IOpt]);
				printf("\n!!!!!!!!!!!!!!!!! save_method_OptValue_Pre:::::::::SpecialChar [%d]\n",SpecialChar);fflush(stdout);

				if (SpecialChar)
				{
					printf("\n!!!!!!!!!!!!!!!!! Inside ERROR MESSAGE:::::::::SpecialChar [%d]\n",SpecialChar);fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Special characters not allowed in Option Value. Only Alphabets and digits are allowed.");
					return ITK_err;
				}
			}
		}
		else
		{
				printf("\n!!!!!!!!!!!!!!!!! Inside ERROR MESSAGE:::::::: No Value\n");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Option Value Field cannot be NULL.");
				return ITK_err;
		}


	}
	
	
	return error_code;


}
extern DLLAPI int  save_method_OptFamily_Pre(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int		ifail				= 0;

	tag_t objTypeTag = NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];

	tag_t objTag = va_arg(args, tag_t);
	char* ObjFamilyName=NULL;

	CALLAPI(TCTYPE_ask_object_type(objTag,&objTypeTag));
	CALLAPI(TCTYPE_ask_name(objTypeTag,type_name));

	printf("\n!!!!!!!!!!!!!!!!! save_method_OptFamily_Pre:::::::::type_name[%s]\n",type_name);fflush(stdout);

	if(AOM_ask_value_string(objTag,"cfg0ObjectId",&ObjFamilyName));

	printf("\n!!!!!!!!!!!!!!!!! save_method_OptValue_Pre:::::::::type_name[%s]\n",ObjFamilyName);fflush(stdout);

	if (ObjFamilyName)
	{
		
		if (tc_strlen(ObjFamilyName) > 29 )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Unable to create this Option family as this Option family has 30 or more than 30 characters.");
			return ITK_err;
		}

		if (!tc_strstr(ObjFamilyName," "))
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Single Value description of Options family should not get created into Teamcenter.");
			return ITK_err;
		}
		int SpecialChar=0;
		SpecialChar=GetSpecialCharacterCount(ObjFamilyName);
		printf("\n!!!!!!!!!!!!!!!!! save_method_OptValue_Pre:::::::::SpecialChar [%d]\n",SpecialChar);fflush(stdout);
		if (SpecialChar)
		{
			printf("\n!!!!!!!!!!!!!!!!! Inside ERROR MESSAGE:::::::::SpecialChar [%d]\n",SpecialChar);fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Special characters not allowed. Only Alphabets and digits are allowed.");
			return ITK_err;
		}
	}

	return error_code;


}

extern DLLAPI int  save_method_OptValue_Pre(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int		ifail				= 0;

	tag_t objTypeTag = NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];

	tag_t objTag = va_arg(args, tag_t);
	char* ObjFamilyVal=NULL;

	CALLAPI(TCTYPE_ask_object_type(objTag,&objTypeTag));
	CALLAPI(TCTYPE_ask_name(objTypeTag,type_name));

	printf("\n!!!!!!!!!!!!!!!!! save_method_OptValue_Pre:::::::::type_name[%s]\n",type_name);fflush(stdout);

	if(AOM_ask_value_string(objTag,"cfg0ObjectId",&ObjFamilyVal));

	printf("\n!!!!!!!!!!!!!!!!! save_method_OptValue_Pre:::::::::type_name[%s]\n",ObjFamilyVal);fflush(stdout);

	if (ObjFamilyVal)
	{
	
		if (tc_strlen(ObjFamilyVal) > 29 )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Unable to create this Option value as this Option value has 30 or more than 30 characters.");
			return ITK_err;
		}

		/*if (!tc_strstr(ObjFamilyVal," "))
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Single Value description of Options Value should not get created into Teamcenter.");
			return ITK_err;
		}*/

		int SpecialChar=0;
		SpecialChar=GetSpecialCharacterCount(ObjFamilyVal);
		printf("\n!!!!!!!!!!!!!!!!! save_method_OptValue_Pre:::::::::SpecialChar [%d]\n",SpecialChar);fflush(stdout);

		if (SpecialChar)
		{
			printf("\n!!!!!!!!!!!!!!!!! Inside ERROR MESSAGE:::::::::SpecialChar [%d]\n",SpecialChar);fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Special characters not allowed. Only Alphabets and digits are allowed.");
			return ITK_err;
		}


	}
	return error_code;


}

extern DLLAPI int OptFamilyMDM_post(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;
	tag_t		objTag				= va_arg(args, tag_t);
	int	isNew = va_arg(args, int);

	char		*MDM_DML		= NULL;
	char*		type_name = NULL;
	tag_t		objTypeTag			= NULLTAG;
	tag_t		DML_tag			= NULLTAG;
	tag_t		DMLRevTag			= NULLTAG;
	tag_t		rel_type			= NULLTAG;
	tag_t		relation			= NULLTAG;
	tag_t		objTag_Rev			= NULLTAG;



	if (AOM_ask_value_string(objTag,"object_type",&type_name)!=ITK_ok);PrintErrorStack();
	printf("\n MDM and new object type is:%s -------> %d \n", type_name,isNew);fflush(stdout);

	if (!isNew)
	{
		printf("\n!!!!!!!!!!!!!!!!! OptFamilyMDM_post isNew:::::::::!!!!!!!! \n");fflush(stdout);
		return error_code;
	}
	if(strcmp(type_name,"T5_FamilyMDM")==0)
	{

		ITEM_ask_latest_rev(objTag,&objTag_Rev);
		error_code = AOM_UIF_ask_value(objTag_Rev,"t5_MDM_DML",&MDM_DML);
		printf("\n MDM_DML:%s\n", MDM_DML);fflush(stdout);

		if(ITEM_find_item(MDM_DML, &DML_tag)!=ITK_ok)PrintErrorStack();
		if (DML_tag)
		{
			if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
			GRM_find_relation_type("CMReferences",&rel_type);
			GRM_create_relation(DMLRevTag,objTag_Rev,rel_type, NULLTAG, &relation);
			printf("\n GRM_create_relation ");fflush(stdout);
			GRM_save_relation(relation);
			printf("\n GRM_save_relation --");fflush(stdout);
		}

		/*int num_Opt=0;
		int IOpt=0;
		char **OpTValueList;
		if (AOM_ask_value_strings(objTag_Rev,"t5_OptionValueMDM",&num_Opt,&OpTValueList)!=ITK_ok)   PrintErrorStack();
		printf("\n  num_Opt  , %d\n",num_Opt); fflush(stdout);
		for (IOpt=0;IOpt<num_Opt;IOpt++ )
		{

			printf("\n OptFm_No is :%s\n",OpTValueList[IOpt]);fflush(stdout);
			int  	number_of_types1;
			tag_t * 	type_tag3;
			tag_t	object_create_input_tag3		    = NULLTAG;

			ITK_CALL(TCTYPE_find_types_for_class("T5_FeatureMDM",&number_of_types1,&type_tag3));
			printf("\n number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);


			ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
			ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",OpTValueList[IOpt]));
			ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",OpTValueList[IOpt]));
			ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &value_tag));
			if(value_tag)
			{
				printf("\n Option Value is created......\n");
				ITK_CALL(AOM_save(value_tag));
				ITK_CALL(AOM_unlock(value_tag));
				
				tag_t		rel_type_1			= NULLTAG;
				tag_t		value_tag_Rev			= NULLTAG;
				GRM_find_relation_type("T5_MDM_Fam_Val",&rel_type_1);

				
				tag_t		relation			= NULLTAG;

				ITEM_ask_latest_rev(value_tag,&value_tag_Rev);
	
				GRM_create_relation(objTag_Rev,value_tag_Rev,rel_type_1, NULLTAG, &relation);
				printf("\n GRM_create_relation ");fflush(stdout);
				GRM_save_relation(relation);
				printf("\n GRM_save_relation --");fflush(stdout);
			}

		}*/

	}
	return error_code;
}




int MDM_Print_SVR( EPM_action_message_t msg)
{

		tag_t *attachments	   = NULL;
	tag_t DMLRevTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	tag_t rel_type		   = NULLTAG;
	char*		type_name=NULL;

	char* parent_name=NULL;
	char* dmlNo=NULL;
	char* dmlProj=NULL;
	char * username			= NULL;
	
	tag_t*	Dml_OptFmS		    = NULL;
	char * object_type			= NULL;

	int AttachmentCount=0;
	int t=0,Dml_OptFmCnt=0,ic=0;
	int status; 


	ITK_CALL(POM_get_user_id (&username));
	printf("\n MDM_CreOptVal Session User is : %s\n",username); fflush(stdout);

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n MDM_CreOptVal Parent Name: %s",parent_name);fflush(stdout);

	ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
	printf("\n MDM_CreOptVal Target Attachment:%d",AttachmentCount);fflush(stdout);

	if(AttachmentCount > 0)
	{

		for(t=0;t<AttachmentCount;t++)
		{
			char* DML_No=NULL;
			
			AOM_ask_value_string(attachments[t],"object_type",&object_type);
			printf("\n object_type is :%s\n",object_type);fflush(stdout);

			AOM_ask_value_string(attachments[t],"item_id",&DML_No);
			printf("\n DML_No is :%s\n",DML_No);fflush(stdout);


			if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
			{
				DMLRevTag = attachments[t];
				GRM_find_relation_type("CMReferences",&rel_type);

				ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,rel_type,&Dml_OptFmCnt,&Dml_OptFmS));

				printf("\n  validation Dml_OptFmCnt count is : [%d] \n",Dml_OptFmCnt);fflush(stdout);

				char* SVRList[1000];
				int SVRListIndx=0;

				for (ic=0;ic<Dml_OptFmCnt;ic++)
				{
					tag_t	OptFm_Tg		    = NULLTAG;
					tag_t	value_tag		    = NULLTAG;
					OptFm_Tg=	Dml_OptFmS[ic];
					tag_t		objTypeTag			= NULLTAG;
					char* OptFm_No=NULL;

						
					ITK_CALL (AOM_ask_value_string(OptFm_Tg,"object_type",&type_name));
						printf("\n 1 MDM type is:%s \n", type_name);fflush(stdout);

					if(tc_strcmp(type_name,"T5_FamilyMDMRevision")==0)
					{


						tag_t		rel_type_1			= NULLTAG;
						GRM_find_relation_type("T5_MDM_Fam_Val",&rel_type_1);

						AOM_ask_value_string(OptFm_Tg,"object_name",&OptFm_No);  //T5_Opt_Family_Value
						printf("\n OptFm_No is :%s\n",OptFm_No);fflush(stdout);



						int num_Opt=0;
						int OptValCnt=0;
						int iSVR=0;
						int IOpt=0;
						int icn=0;
						int iindx=0;
						int num_OptSvr=0;
						char **OpTValueList;
						char **OpTValueSVRList;

						tag_t OptVal_Tg=NULLTAG;
						tag_t* OptVal_TAGS=NULL;
						if (AOM_ask_value_strings(OptFm_Tg,"t5_OptionValueMDM",&num_Opt,&OpTValueList)!=ITK_ok)   PrintErrorStack();
						printf("\n  num_Opt  , %d\n",num_Opt); fflush(stdout);

						ITK_CALL(GRM_list_secondary_objects_only(OptFm_Tg,rel_type_1,&OptValCnt,&OptVal_TAGS));
						for (IOpt=0;IOpt<OptValCnt;IOpt++ )///optionvalue
						{
							OptVal_Tg=OptVal_TAGS[IOpt];
							if (AOM_ask_value_strings(OptVal_Tg,"t5_AppSVR",&num_OptSvr,&OpTValueSVRList)!=ITK_ok)   PrintErrorStack();
							printf("\n  num_OptSvr  , %d\n",num_OptSvr); fflush(stdout);
							
							for (iSVR=0;iSVR<num_OptSvr;iSVR++)///svr
							{
								int FlagMatchSvr=0;
								if (SVRListIndx !=0)
								{
									for (icn=0;icn<SVRListIndx;icn++ )///checking for any duplicate svr
									{
										if (tc_strcmp(OpTValueSVRList[iSVR],SVRList[icn])==0)
										{

											FlagMatchSvr=1;
											break;
										}
									}
								}
								if (FlagMatchSvr==0)
								{
									printf("\n  OpTValueSVRList[iSVR]  , %s\n",OpTValueSVRList[iSVR]); fflush(stdout);

									SVRList[SVRListIndx]=OpTValueSVRList[iSVR];
									SVRListIndx++;
								}
			
							}
						}
						printf("\n SVRListIndx is :%d\n",SVRListIndx);fflush(stdout);
					}
				}

				printf("\n SVRListIndx FInal is :%d\n",SVRListIndx);fflush(stdout);

				char *qry_entries[1] = {"Name"};
				char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

				tag_t	queryTag	= NULLTAG;
				int ii=0;
				if(QRY_find("VariantRule1", &queryTag));
				for (ii=0;ii<SVRListIndx;ii++)
				{
					int n_entries = 1;
					int resultCount=0;
					tag_t *svrobj=NULL;
					qry_values[0] = SVRList[ii] ;

					
					if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &svrobj));
					printf("\n resultCount : %d\n", resultCount); fflush(stdout);

					if (resultCount>0)
					{
						char* Context_VRuleText2=NULL;
						char* Context_VRuleText=NULL;
						int countPrdCnfg=0;
						tag_t* PrdCnfgTags=NULL;
						tag_t vrule=NULLTAG;
						tag_t rel_typeSvr=NULLTAG;

						vrule=svrobj[0];
						BSLV_get_variant_expression(NULLTAG,vrule,&Context_VRuleText2 );
						printf("\n Context_VRuleText2 : \n\n\n%s\n\n\n", Context_VRuleText2); fflush(stdout);
					}
				}
			}
		}
	}

	return ITK_ok;

}

int MDM_CreOptVal( EPM_action_message_t msg)
{

	tag_t *attachments	   = NULL;
	tag_t DMLRevTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	tag_t rel_type		   = NULLTAG;
	char*		type_name=NULL;

	char* parent_name=NULL;
	char* dmlNo=NULL;
	char* dmlProj=NULL;
	char * username			= NULL;
	
	tag_t*	Dml_OptFmS		    = NULL;
	char * object_type			= NULL;

	int AttachmentCount=0;
	int t=0,Dml_OptFmCnt=0,ic=0;
	int status; 


	ITK_CALL(POM_get_user_id (&username));
	printf("\n MDM_CreOptVal Session User is : %s\n",username); fflush(stdout);

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n MDM_CreOptVal Parent Name: %s",parent_name);fflush(stdout);

	ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
	printf("\n MDM_CreOptVal Target Attachment:%d",AttachmentCount);fflush(stdout);

	if(AttachmentCount > 0)
	{

		for(t=0;t<AttachmentCount;t++)
		{
			char* DML_No=NULL;
			
			AOM_ask_value_string(attachments[t],"object_type",&object_type);
			printf("\n object_type is :%s\n",object_type);fflush(stdout);

			AOM_ask_value_string(attachments[t],"item_id",&DML_No);
			printf("\n DML_No is :%s\n",DML_No);fflush(stdout);


			if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
			{
				DMLRevTag = attachments[t];
				GRM_find_relation_type("CMReferences",&rel_type);

				ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,rel_type,&Dml_OptFmCnt,&Dml_OptFmS));

				printf("\n  validation Dml_OptFmCnt count is : [%d] \n",Dml_OptFmCnt);fflush(stdout);

				for (ic=0;ic<Dml_OptFmCnt;ic++)
				{
					tag_t	OptFm_Tg		    = NULLTAG;
					tag_t	value_tag		    = NULLTAG;
					OptFm_Tg=	Dml_OptFmS[ic];
					tag_t		objTypeTag			= NULLTAG;
					char* OptFm_No=NULL;

						
					ITK_CALL (AOM_ask_value_string(OptFm_Tg,"object_type",&type_name));
						printf("\n 1 MDM type is:%s \n", type_name);fflush(stdout);

					if(tc_strcmp(type_name,"T5_FamilyMDMRevision")==0)
					{

						AOM_ask_value_string(OptFm_Tg,"object_name",&OptFm_No);  //T5_Opt_Family_Value
						printf("\n OptFm_No is :%s\n",OptFm_No);fflush(stdout);

						int num_Opt=0;
						int IOpt=0;
						char **OpTValueList;
						if (AOM_ask_value_strings(OptFm_Tg,"t5_OptionValueMDM",&num_Opt,&OpTValueList)!=ITK_ok)   PrintErrorStack();
						printf("\n  num_Opt  , %d\n",num_Opt); fflush(stdout);
						for (IOpt=0;IOpt<num_Opt;IOpt++ )
						{

							printf("\n OptFm_No is :%s\n",OpTValueList[IOpt]);fflush(stdout);
							int  	number_of_types1;
							tag_t * 	type_tag3;
							tag_t * 	type_tag3_Rev;
							tag_t	object_create_input_tag3		    = NULLTAG;
							tag_t	object_create_input_tag3_Rev		    = NULLTAG;
							tag_t	value_tag_Rev		    = NULLTAG;

							ITK_CALL(TCTYPE_find_types_for_class("T5_FeatureMDM",&number_of_types1,&type_tag3));
							//ITK_CALL(TCTYPE_find_types_for_class("T5_FeatureMDMRevision",&number_of_types1,&type_tag3_Rev));
							printf("\n number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);


							//ITK_CALL(TCTYPE_construct_create_input(type_tag3_Rev[0], &object_create_input_tag3_Rev));
							ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));

							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",OpTValueList[IOpt]));
							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",OpTValueList[IOpt]));
							//ITK_CALL(AOM_set_value_tag(object_create_input_tag3, "revision",object_create_input_tag3_Rev));
							ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &value_tag));

							if(value_tag) 
							{
								ITK_CALL(AOM_save(value_tag));
								ITK_CALL(AOM_refresh(value_tag,0));
								ITK_CALL(AOM_unlock(value_tag));
								printf("\n Option Value is created......\n"); fflush(stdout);
							}



							if(value_tag)
							{
								ITEM_ask_latest_rev(value_tag,&value_tag_Rev);
								printf("\n Option Value is created......\n");fflush(stdout);
								ITK_CALL(AOM_save(value_tag_Rev));
								ITK_CALL(AOM_unlock(value_tag_Rev));
								
								tag_t		rel_type_1			= NULLTAG;
								GRM_find_relation_type("T5_MDM_Fam_Val",&rel_type_1);

								
								tag_t		relation			= NULLTAG;
					
								GRM_create_relation(OptFm_Tg,value_tag_Rev,rel_type_1, NULLTAG, &relation);
								printf("\n GRM_create_relation ");fflush(stdout);
								GRM_save_relation(relation);
								printf("\n GRM_save_relation --");fflush(stdout);
							}

						}
					}
				}
			}
		}

	}
	

	return ITK_ok;
}
char* AddAndSvrString(char* SVR)
{
	char* SVR_F=NULL;
	SVR_F = (char	*)MEM_alloc(5000);
	tc_strcpy(SVR_F,SVR);
	if (tc_strstr(SVR,"(((("))
	{
		tc_strcat(SVR_F,")");
	}
	tc_strcat(SVR_F," & ");
	return SVR_F;
}
char* GetSvrString(char* optFamily,char* OptFm_Value,char* String_FamVal)
{
	char* optFamily_Dup=NULL;
	char* optValue_Dup=NULL;
	char* FinalStr=NULL;
	optFamily_Dup = (char	*)MEM_alloc(1000);
	optValue_Dup = (char	*)MEM_alloc(1000);
	FinalStr = (char	*)MEM_alloc(5000);
	if (tc_strstr(optFamily," "))
	{
		tc_strcpy(optFamily_Dup,"'");
		tc_strcat(optFamily_Dup,optFamily);
		tc_strcat(optFamily_Dup,"'");
	}
	else
	{
		tc_strcpy(optFamily_Dup,optFamily);
	}
	printf("\n optFamily_Dup -- %s \n",optFamily_Dup);fflush(stdout);
	if (tc_strstr(OptFm_Value," "))
	{
		tc_strcpy(optValue_Dup,"'");
		tc_strcat(optValue_Dup,OptFm_Value);
		tc_strcat(optValue_Dup,"'");
	}
	else
	{
		tc_strcpy(optValue_Dup,OptFm_Value);
	}
	printf("\n optValue_Dup -- %s \n",optValue_Dup);fflush(stdout);
	

		printf("\n String_FamVal -- %s \n",String_FamVal);fflush(stdout);

		if (String_FamVal==NULL)
		{
			tc_strcpy(FinalStr,"((([Teamcenter]");
			tc_strcat(FinalStr,optFamily_Dup);
			tc_strcat(FinalStr," = ");
			tc_strcat(FinalStr,optValue_Dup);
			printf("\n FinalStr1 -- %s \n",FinalStr);fflush(stdout);
			
		}
		else
		{	
			if (!tc_strstr(String_FamVal,"|"))
			{
				tc_strcpy(FinalStr,"(");
				tc_strcat(FinalStr,String_FamVal);
			}
			else
			{
				tc_strcpy(FinalStr,String_FamVal);
			}
			
			tc_strcat(FinalStr," | ");
			tc_strcat(FinalStr,"[Teamcenter]");
			tc_strcat(FinalStr,optFamily_Dup);
			tc_strcat(FinalStr," = ");
			tc_strcat(FinalStr,optValue_Dup);
			printf("\n FinalStr2 -- %s \n",FinalStr);fflush(stdout);
			
		}

		printf("\n FinalStr -- %s \n",FinalStr);fflush(stdout);
		return FinalStr;

}
int MDM_Upd_SVR( EPM_action_message_t msg)
{

	tag_t *attachments	   = NULL;
	tag_t DMLRevTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	tag_t rel_type		   = NULLTAG;
	char*		type_name=NULL;

	char* parent_name=NULL;
	char* dmlNo=NULL;
	char* dmlProj=NULL;
	char * username			= NULL;
	char *OptFm_Value			= NULL;
	
	tag_t*	Dml_OptFmS		    = NULL;
	char * object_type			= NULL;

	int AttachmentCount=0;
	int t=0,Dml_OptFmCnt=0,ic=0;
	int status; 

	char *qry_entries[1] = {"Name"};
    char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));


	ITK_CALL(POM_get_user_id (&username));
	printf("\n MDM_Upd_SVR Session User is : %s\n",username); fflush(stdout);

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n MDM_CreOptVal Parent Name: %s",parent_name);fflush(stdout);

	ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
	printf("\n MDM_CreOptVal Target Attachment:%d",AttachmentCount);fflush(stdout);

	if(AttachmentCount > 0)
	{

		for(t=0;t<AttachmentCount;t++)
		{
			char* DML_No=NULL;
			
			AOM_ask_value_string(attachments[t],"object_type",&object_type);
			printf("\n object_type is :%s\n",object_type);fflush(stdout);

			AOM_ask_value_string(attachments[t],"item_id",&DML_No);
			printf("\n DML_No is :%s\n",DML_No);fflush(stdout);


			if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
			{
				DMLRevTag = attachments[t];
				GRM_find_relation_type("CMReferences",&rel_type);

				ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,rel_type,&Dml_OptFmCnt,&Dml_OptFmS));

				printf("\n  validation Dml_OptFmCnt count is : [%d] \n",Dml_OptFmCnt);fflush(stdout);

				for (ic=0;ic<Dml_OptFmCnt;ic++)
				{
					tag_t	OptFm_Tg		    = NULLTAG;
					tag_t	value_tag		    = NULLTAG;
					OptFm_Tg=	Dml_OptFmS[ic];
					tag_t		objTypeTag			= NULLTAG;
					tag_t		*OptVal_TAGS			= NULL;
					char* OptFm_No=NULL;
					int OptValCnt=0;

						
					if (AOM_ask_value_string(OptFm_Tg,"object_type",&type_name)!=ITK_ok);PrintErrorStack();
						printf("\n 1 MDM type is:%s \n", type_name);fflush(stdout);

					if(tc_strcmp(type_name,"T5_FamilyMDMRevision")==0)
					{
						tag_t		rel_type_1			= NULLTAG;
						GRM_find_relation_type("T5_MDM_Fam_Val",&rel_type_1);

						AOM_ask_value_string(OptFm_Tg,"object_name",&OptFm_No);  //T5_Opt_Family_Value
						printf("\n OptFm_No is :%s\n",OptFm_No);fflush(stdout);



						int num_Opt=0;
						int iSVR=0;
						int IOpt=0;
						int icn=0;
						int iindx=0;
						int num_OptSvr=0;
						char **OpTValueList;
						char **OpTValueSVRList;
						char* SVRList[1000];
						int SVRListIndx=0;
						tag_t OptVal_Tg=NULLTAG;
						if (AOM_ask_value_strings(OptFm_Tg,"t5_OptionValueMDM",&num_Opt,&OpTValueList)!=ITK_ok)   PrintErrorStack();
						printf("\n  num_Opt  , %d\n",num_Opt); fflush(stdout);

						ITK_CALL(GRM_list_secondary_objects_only(OptFm_Tg,rel_type_1,&OptValCnt,&OptVal_TAGS));
						for (IOpt=0;IOpt<OptValCnt;IOpt++ )///optionvalue
						{
							OptVal_Tg=OptVal_TAGS[IOpt];
							if (AOM_ask_value_strings(OptVal_Tg,"t5_AppSVR",&num_OptSvr,&OpTValueSVRList)!=ITK_ok)   PrintErrorStack();
							printf("\n  num_OptSvr  , %d\n",num_OptSvr); fflush(stdout);
							
							for (iSVR=0;iSVR<num_OptSvr;iSVR++)///svr
							{
								int FlagMatchSvr=0;
								if (SVRListIndx !=0)
								{
									for (icn=0;icn<SVRListIndx;icn++ )///checking for any duplicate svr
									{
										if (tc_strcmp(OpTValueSVRList[iSVR],SVRList[icn])==0)
										{

											FlagMatchSvr=1;
											break;
										}
									}
								}
								if (FlagMatchSvr==0)
								{
									printf("\n  OpTValueSVRList[iSVR]  , %s\n",OpTValueSVRList[iSVR]); fflush(stdout);

									SVRList[SVRListIndx]=OpTValueSVRList[iSVR];
									SVRListIndx++;
								}
			
							}
						}
						printf("\n SVRListIndx is :%d\n",SVRListIndx);fflush(stdout);
						
						
						for (iindx=0;iindx< SVRListIndx;iindx++ )
						{
							char* String_FamVal=NULL;

							printf("\n\n\n SVR PROCESSING >>>>>>>>>>>>>>>>>>>>>>>%s<<<<<<<<<<<<<<<<<<<\n",SVRList[iindx]); fflush(stdout);
							for (IOpt=0;IOpt<OptValCnt;IOpt++ )///optionvalue
							{
								int FlagMatchValue=0;
								OptVal_Tg=OptVal_TAGS[IOpt];
								if (AOM_ask_value_strings(OptVal_Tg,"t5_AppSVR",&num_OptSvr,&OpTValueSVRList)!=ITK_ok)   PrintErrorStack();
								printf("\n  num_OptSvr  , %d\n",num_OptSvr); fflush(stdout);

								AOM_ask_value_string(OptVal_Tg,"object_name",&OptFm_Value);  //T5_Opt_Family_Value
								printf("\n OptFm_Value is : %s------>>%s\n",OptFm_No,OptFm_Value);fflush(stdout);
								
								for (iSVR=0;iSVR<num_OptSvr;iSVR++)///svr
								{

									if (tc_strcmp(OpTValueSVRList[iSVR],SVRList[iindx])==0)
									{
										printf("\n OpTValueSVRList[iSVR],Svr is : <%s><%s>\n",OpTValueSVRList[iSVR],SVRList[iindx]);fflush(stdout);
											FlagMatchValue=1;
											break;
										
									}
								}

								if (FlagMatchValue==1)
								{
									String_FamVal=GetSvrString(OptFm_No,OptFm_Value,String_FamVal);
									printf("\n OptFm_Value is : <%s>\n",String_FamVal);fflush(stdout);
								}
							}
							char* String_SVR_Final=NULL;
							String_SVR_Final=AddAndSvrString(String_FamVal);
							tag_t	queryTag	= NULLTAG;
							int n_entries = 1;
							int resultCount=0;
							tag_t *svrobj=NULLTAG;
							if(QRY_find("VariantRule1", &queryTag));
							qry_values[0] = SVRList[iindx] ;

							
							if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &svrobj));
							printf("\n resultCount : %d\n", resultCount); fflush(stdout);

							if (resultCount>0)
							{
								char* Context_VRuleText2=NULL;
								char* Context_VRuleText=NULL;
								int countPrdCnfg=0;
								tag_t* PrdCnfgTags=NULL;
								tag_t vrule=NULLTAG;
								tag_t rel_typeSvr=NULLTAG;
								vrule=svrobj[0];
								BSLV_get_variant_expression(NULLTAG,vrule,&Context_VRuleText2 );
								
								GRM_find_relation_type("IMAN_reference",&rel_typeSvr);
								GRM_list_primary_objects_only(vrule,rel_typeSvr,&countPrdCnfg,&PrdCnfgTags);
								printf("\n countPrdCnfg : %d\n", countPrdCnfg); fflush(stdout);
								if (countPrdCnfg>0)
								{

									printf("\n  Prd Cnfg  FouND \n"); fflush(stdout);
									printf("\n Context_VRuleText2 : \n\n\n%s\n\n\n", Context_VRuleText2); fflush(stdout);

									STRNG_replace_str(Context_VRuleText2,"(((",String_SVR_Final,&Context_VRuleText);
									printf("\n Context_VRuleText2 : \n\n\n%s\n\n\n", Context_VRuleText); fflush(stdout);
									ITK_CALL(BSLV_set_variant_expression(PrdCnfgTags[0],NULLTAG,vrule,Context_VRuleText ));
								}
								else
								{
									printf("\n ERROR Prd Cnfg not FouND \n"); fflush(stdout);
								}

							}
						}



					}
				}
			}
		}

	}
	
	return ITK_ok;
}
tag_t Get_CC_Dictionary()
{
	int ifail=0;

	//__Configuration_Item_Name_or_ID

	tag_t CC_DICT_tag=NULLTAG;
	tag_t QryTag=NULLTAG;
	tag_t *tags_found=NULL;

	char **values= (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_entries= (char **) MEM_alloc(10 * sizeof(char *));
	int n_entries = 1;
	qry_entries[0] = "ID";//change it as per  QRy Builder entry
	int n_tags_found = 0;
	if(QRY_find("__Configuration_Item_Name_or_ID", &QryTag));
	if (QryTag) 
	{ 
		printf("\nFound Query QryTag"); fflush(stdout);

		values[0] = "TML OPTIONS DICTIONARY";
		if(QRY_execute(QryTag, n_entries, qry_entries, values, &n_tags_found, &tags_found));
		printf("\n\n\n CC DICT count is-------->  : %d",n_tags_found);fflush(stdout);
		if (n_tags_found > 0)
		{
			CC_DICT_tag = tags_found[0];
			
		}else 
		{ 
			printf ("\n Platform tag not found\n"); fflush(stdout);	
		}
	}else 
	{
		printf("\nNot Found Query QryTag"); fflush(stdout);
	}
	return CC_DICT_tag;

}
tag_t Get_CC_From_Platform_ArchModule(char* InputPart,char* Class)
{
	//MT start
	int ifail=0;
	tag_t   OutPutTag     = NULLTAG;
	tag_t   ConfigCtx     = NULLTAG;
	tag_t   relation_dep     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	char* SmVCContext=NULL;
	char* SmCrIDContext=NULL;
	

	int countConfigCtx=0;
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	tag_t *ConfigCtxSecObject = NULL;

	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	printf("\n MDM:part no :%s.", InputPart);fflush(stdout);
	CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));

	if (tc_strcmp(Class,"T5_Platform")==0)
	{
		
		const char *attrs2[2];
		const char *values2[2];
		attrs2[0] ="item_id";
		attrs2[1] ="object_type";
		values2[0] = (char *)InputPart;
		values2[1] = "T5_Platform";
		if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
		printf("\n MDM:T5_Platform part count :%d.", n_tags_foundd3);fflush(stdout);

		if (n_tags_found2>0)
		{


			OutPutTag= tags_found2[0];
		}
	}
	else if(tc_strcmp(Class,"T5_ArchModule")==0)
	{
		printf("\n MDM:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
		attrss3[0] ="item_id";
		attrss3[1] ="object_type";
		valuess3[0] = (char *)InputPart;
		valuess3[1] = "T5_ArchModule";
		if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
		printf("\n MDM:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
		if (n_tags_foundd3>0)
		{
			OutPutTag= tags_foundd3[0];
		}
	}
	else
	{

	}

	if (OutPutTag)
	{
		CALLAPI(GRM_list_secondary_objects_only(OutPutTag,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
		printf("\n\t Configuration Context count is : %d",countConfigCtx);

		if(countConfigCtx>0)
		{
			  ConfigCtx=ConfigCtxSecObject[0];


			  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
			  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

			  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
			  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);
		}
	}


	return ConfigCtx;	
}

OptionFamily_Create(char* OptFamName,tag_t* ConfigCtxtTags,int Nos_ConfigCtxt)
{
	int status;	
	int  	number_of_types;
	int  	number_of_types1;
	tag_t * 	type_tag4;
	tag_t 	CfgTag=NULLTAG;
	tag_t 	context_tag=NULLTAG;
	tag_t * 	type_tag3;
	tag_t * 	tags_found;
	tag_t	 	thread_tag;
	int cfg_cnt=0;
	tag_t object_create_input_tag,new_object,object_create_input_tag3,family_tag;

	char **valuesCfg = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_entries10 = (char **) MEM_alloc(10 * sizeof(char *));

	


		ITK_CALL(TCTYPE_find_types_for_class("Cfg0LiteralValueFamily",&number_of_types1,&type_tag3));
		printf("\n number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);

		ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0ObjectId",OptFamName));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",OptFamName));								
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0FamilyNamespace","Teamcenter"));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0ValueDataType","String"));
		ITK_CALL(AOM_set_value_logical(object_create_input_tag3,"cfg0HasFreeFormValues",false));
		ITK_CALL(AOM_set_value_logical(object_create_input_tag3,"cfg0IsDiscretionary",false));
		ITK_CALL(AOM_set_value_logical(object_create_input_tag3,"cfg0IsMultiselect",false));
		for (cfg_cnt=0;cfg_cnt<Nos_ConfigCtxt;cfg_cnt++)
		{
			context_tag=ConfigCtxtTags[cfg_cnt];
			ITK_CALL(AOM_set_value_tag_at(object_create_input_tag3,"cfg0ProductItems",cfg_cnt,context_tag));
		}
			
		ITK_CALL(AOM_set_value_int(object_create_input_tag3,"cfg0Sequence",0));
		ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &family_tag));
		if(family_tag)
		{
			printf("\n Option Value is created......\n");
			ITK_CALL(AOM_save(family_tag));
			ITK_CALL(AOM_unlock(family_tag));
		}

		//Added Option Values to Option family
		for (cfg_cnt=0;cfg_cnt<Nos_ConfigCtxt;cfg_cnt++)
		{
			context_tag=ConfigCtxtTags[cfg_cnt];
			ITK_CALL(TCTYPE_find_types_for_class("Cfg0Allocation",&number_of_types,&type_tag4));
			ITK_CALL(TCTYPE_construct_create_input(type_tag4[0], &object_create_input_tag));
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",OptFamName));
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"cfg0ObjectId",OptFamName));
			ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0Target",family_tag));
			ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0ProductItem",context_tag));
			ITK_CALL(TCTYPE_create_object(object_create_input_tag, &new_object));
			if(new_object)
			{
				printf("\n t5CreateObject : object created.\n");
				ITK_CALL(AOM_save(new_object));
				ITK_CALL(AOM_unlock(new_object));
			}
		}
}
OptionValue_Create(char* OptValName,tag_t Optfmly_tag,tag_t* ConfigCtxtTags,int Nos_ConfigCtxt)
{
	int status;	
	int  	number_of_types;
	int  	number_of_types1;
	tag_t * 	type_tag4;
	tag_t 	CfgTag=NULLTAG;
	tag_t 	context_tag=NULLTAG;
	tag_t * 	type_tag3;
	int cfg_cnt =0;
	tag_t	 	thread_tag;
	tag_t object_create_input_tag,new_object,object_create_input_tag3,value_tag;

	char **valuesCfg = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_entries10 = (char **) MEM_alloc(10 * sizeof(char *));

	



		ITK_CALL(TCTYPE_find_types_for_class("Cfg0LiteralOptionValue",&number_of_types1,&type_tag3));
		printf("\n number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);

		ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0ObjectId",OptValName));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",OptValName));
		if(Optfmly_tag != NULLTAG)
		{
			ITK_CALL(AOM_get_value_tag(Optfmly_tag,"wso_thread", &thread_tag));
			if(thread_tag != NULLTAG) {
				printf("\n\t go thread.......\n\n"); fflush(stdout);
			}else {
				printf("\n\t thread error.......\n\n"); fflush(stdout);
			}
		}else {
			printf("\n\t family error.......\n\n"); fflush(stdout);
		}
		//ITK_CALL(AOM_set_value_tag(object_create_input_tag3,"cfg0OptionFamily ",Optfmly_tag));
		ITK_CALL(AOM_set_value_tag(object_create_input_tag3,"cfg0OptionFamilyThread",thread_tag));
		//ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0FamilyObjectId",OptValName));

		for (cfg_cnt=0;cfg_cnt<Nos_ConfigCtxt;cfg_cnt++)
		{
			context_tag=ConfigCtxtTags[cfg_cnt];
			ITK_CALL(AOM_set_value_tag_at(object_create_input_tag3,"cfg0ProductItems",cfg_cnt,context_tag));
		}
			
		ITK_CALL(AOM_set_value_int(object_create_input_tag3,"cfg0Sequence",0));
		ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &value_tag));
		if(value_tag)
		{
			printf("\n Option Value is created......\n");
			ITK_CALL(AOM_save(value_tag));
			ITK_CALL(AOM_unlock(value_tag));
		}

		//Added Option Values to Option family
		for (cfg_cnt=0;cfg_cnt<Nos_ConfigCtxt;cfg_cnt++)
		{
			context_tag=ConfigCtxtTags[cfg_cnt];
			ITK_CALL(TCTYPE_find_types_for_class("Cfg0Allocation",&number_of_types,&type_tag4));
			ITK_CALL(TCTYPE_construct_create_input(type_tag4[0], &object_create_input_tag));
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",OptValName));
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"cfg0ObjectId",OptValName));
			ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0Target",value_tag));
			ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0ProductItem",context_tag));
			ITK_CALL(TCTYPE_create_object(object_create_input_tag, &new_object));
			if(new_object)
			{
				printf("\n t5CreateObject : object created.\n");
				ITK_CALL(AOM_save(new_object));
				ITK_CALL(AOM_unlock(new_object));
			}
		}
}
int MDM_CrePrdCnfgOpt_Fam_Val( EPM_action_message_t msg)
{
	tag_t *attachments	   = NULL;
	tag_t DMLRevTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	tag_t rel_type		   = NULLTAG;
	char*		type_name=NULL;

	char* parent_name=NULL;
	char* dmlNo=NULL;
	char* dmlProj=NULL;
	char * username			= NULL;
	
	tag_t*	Dml_OptFmS		    = NULL;
	
	char * object_type			= NULL;

	int AttachmentCount=0;
	int t=0,Dml_OptFmCnt=0,ic=0,iCTX=0;
	int status; 


	ITK_CALL(POM_get_user_id (&username));
	printf("\n MDM_CreOptVal Session User is : %s\n",username); fflush(stdout);

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n MDM_CreOptVal Parent Name: %s",parent_name);fflush(stdout);

	ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
	printf("\n MDM_CreOptVal Target Attachment:%d",AttachmentCount);fflush(stdout);

	if(AttachmentCount > 0)
	{

		for(t=0;t<AttachmentCount;t++)
		{
			char* DML_No=NULL;
			
			AOM_ask_value_string(attachments[t],"object_type",&object_type);
			printf("\n object_type is :%s\n",object_type);fflush(stdout);

			AOM_ask_value_string(attachments[t],"item_id",&DML_No);
			printf("\n DML_No is :%s\n",DML_No);fflush(stdout);


			if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
			{
				DMLRevTag = attachments[t];
				GRM_find_relation_type("CMReferences",&rel_type);

				ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,rel_type,&Dml_OptFmCnt,&Dml_OptFmS));

				printf("\n  validation Dml_OptFmCnt count is : [%d] \n",Dml_OptFmCnt);fflush(stdout);

				for (ic=0;ic<Dml_OptFmCnt;ic++)
				{
					tag_t	OptFm_Tg		    = NULLTAG;
					tag_t	value_tag		    = NULLTAG;
					tag_t	ConfigCtxtag		    = NULLTAG;
					tag_t	ConfigCtxDicttag		    = NULLTAG;
					tag_t	ConfigCtxTAGS[1000];
					OptFm_Tg=	Dml_OptFmS[ic];
					char* OptFm_No=NULL;

					AOM_ask_value_string(OptFm_Tg,"object_name",&OptFm_No);  //T5_Opt_Family_Value
					printf("\nCre OptFm_No is :%s\n",OptFm_No);fflush(stdout);

					ITK_CALL (AOM_ask_value_string(OptFm_Tg,"object_type",&type_name));
					printf("\n Cre MDM type is:%s \n", type_name);fflush(stdout);

					if(tc_strcmp(type_name,"T5_FamilyMDMRevision")==0)
					{


						int num_Opt=0;
						int IOpt=0;
						int iPlt=0;
						int iArch=0;
						int num_ArchNod=0;
						int num_Platform=0;
						char **OpTValueList;
						char **ArchNodList;
						char **PlatformList;
						if (AOM_ask_value_strings(OptFm_Tg,"t5_OptionValueMDM",&num_Opt,&OpTValueList)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_strings(OptFm_Tg,"t5_AffArchNode",&num_ArchNod,&ArchNodList)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_strings(OptFm_Tg,"t5_MDMPlatform",&num_Platform,&PlatformList)!=ITK_ok)   PrintErrorStack();
						printf("\n  num_Platform  , %d\n",num_Platform); fflush(stdout);

						
						ConfigCtxDicttag=Get_CC_Dictionary();
						if (ConfigCtxDicttag)
						{
							ConfigCtxTAGS[iCTX]=ConfigCtxDicttag;
							iCTX++;
						}
						for (iPlt=0;iPlt<num_Platform;iPlt++ )
						{

							printf("\n PlatformList no is :%s\n",PlatformList[iPlt]);fflush(stdout);

							ConfigCtxtag=Get_CC_From_Platform_ArchModule(PlatformList[iPlt],"T5_Platform");
							if (ConfigCtxtag)
							{
								ConfigCtxTAGS[iCTX]=ConfigCtxtag;
								iCTX++;
							}
							 
						}
						int ic =0;
						char* SmCrIDContext_curr=NULL;
						char* SmCrIDContext=NULL;
						for (iArch=0;iArch<num_ArchNod;iArch++ )
						{

							printf("\n ArchNodList no is :%s\n",ArchNodList[iArch]);fflush(stdout);

							ConfigCtxtag=Get_CC_From_Platform_ArchModule(ArchNodList[iArch],"T5_ArchModule");
							if (ConfigCtxtag)
							{	int FlagMatch=0;
								ITK_CALL(AOM_ask_value_string(ConfigCtxtag,"current_id",&SmCrIDContext_curr));
								for (ic=0;ic<iCTX;ic++)
								{

									ITK_CALL(AOM_ask_value_string(ConfigCtxTAGS[ic],"current_id",&SmCrIDContext));
									printf("\n\t finding Dup MDM  :<%s> <%s> \n",SmCrIDContext,SmCrIDContext_curr);	fflush(stdout);
									if (tc_strcmp(SmCrIDContext_curr,SmCrIDContext)==0)
									{
										FlagMatch=1;
										break;
									}
								}
								if (FlagMatch==0)
								{
									ConfigCtxTAGS[iCTX]=ConfigCtxtag;
									iCTX++;
								}

							}
							 
						}

						for (ic=0;ic<iCTX;ic++)
						{
							
							//ITK_CALL(AOM_ask_value_string(ConfigCtxTAGS[ic],"object_string",&SmVCContext));
							//printf("\n\t MDM SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

							ITK_CALL(AOM_ask_value_string(ConfigCtxTAGS[ic],"current_id",&SmCrIDContext));
							printf("\n\t FInal MDM SmCrIDContext Object String Type is :%s \n",SmCrIDContext);	fflush(stdout);
						}
						
						OptionFamily_Create(OptFm_No,ConfigCtxTAGS,iCTX);


						char **valuesFam = (char **) MEM_alloc(10 * sizeof(char *));
						tag_t* tags_found_fam=NULL;
						tag_t FamTag=NULLTAG;
						tag_t Optfmly_tag=NULLTAG;
						int n_tags_found_fam=0;
						int n_entriesP=1;
						char **qry_entries1 = (char **) MEM_alloc(10 * sizeof(char *));
						qry_entries1[0] = "Thread ID";
						valuesFam[0] = OptFm_No;

						ITK_CALL(QRY_find("__Cfg0OptionFamiliesFromIDs", &FamTag)); 

						if (FamTag)
						{
							ITK_CALL(QRY_execute(FamTag, n_entriesP, qry_entries1, valuesFam, &n_tags_found_fam, &tags_found_fam));
							printf("\n Query __Cfg0OptionFamiliesFromIDs %d <---- %s\n",n_tags_found_fam,OptFm_No); fflush(stdout);
							if (n_tags_found_fam>0)
							{
								Optfmly_tag=tags_found_fam[0];
								printf("\n  num_Opt  , %d\n",num_Opt); fflush(stdout);
								for (IOpt=0;IOpt<num_Opt;IOpt++ )
								{
									printf("\n OptFm_Value is :%s\n",OpTValueList[IOpt]);fflush(stdout);
									OptionValue_Create(OpTValueList[IOpt],Optfmly_tag,ConfigCtxTAGS,iCTX);
								}
							}
							else
							{
								printf("\n  OPTFamily %s not found  \n",OptFm_No); fflush(stdout);
							}
						}
						else
						{
							printf("\n  Query __Cfg0OptionFamiliesFromIDs not found  \n"); fflush(stdout);

						}
					}
				}
			}
		}

	}
	

	return ITK_ok;
}




extern int svr_release_register_method(int *decision, va_list args)
{
   

   int ifail=0;
   *decision = ALL_CUSTOMIZATIONS;
   tag_t objTag = va_arg(args, tag_t); 

   if( ITK_ok ==  EPM_register_rule_handler ("svr-assign-participants","SVR Release Validate Participants", (EPM_rule_handler_t) svr_chk_assigned_participants))
   {
		printf("\t\n Registered Rule  Handler svr_chk_assigned_participants\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler svr_chk_assigned_participants\n");fflush(stdout);
   }

  
   if( ITK_ok == EPM_register_rule_handler("svr-chk-signoff", "SVR Release Validate Signoff", svr_chk_signoff))
   {
		printf("\t\n Registered Rule Handler svr_chk_signoff\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler svr_chk_signoff\n");fflush(stdout);
   }  

   if(ITK_ok ==  EPM_register_rule_handler ("svr-chkdml-workflow","SVR Release Validate Active DML", (EPM_rule_handler_t) svr_chk_dmlactive))
   {
		printf("\t\n Registered Rule Handler svr_chk_dmlactive\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler svr_chk_dmlactive\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("svr_stamp_status", "", svr_stamp_status))
   {
		printf("\t\n Registered Action Handler svr_stamp_status\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler svr_stamp_status\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("svr_impact_analysis", "", svr_impact_analysis))
   {
		printf("\t\n Registered Action Handler svr_impact_analysis\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler svr_stamp_status\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("svr_Report", "SVR Report", svr_Report))
   {
		printf("\t\n Registered Action Handler svr_Report\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler svr_Report\n");fflush(stdout);
   }

   METHOD_id_t  methodSaveOptFamily ;
  

   if (ITK_ok == METHOD_find_method("Cfg0AbsOptionFamily", IMAN_save_msg, &methodSaveOptFamily))
	{
		printf("\t\n METHOD_find_method svr_Report\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to METHOD_find_method svr_Report\n");fflush(stdout);
   }


   METHOD_id_t  methodSaveOptValue ;
  

   if (ITK_ok == METHOD_find_method("Cfg0AbsOptionValue", IMAN_save_msg, &methodSaveOptValue))
	{
		printf("\t\n METHOD_find_method svr_Report\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to METHOD_find_method svr_Report\n");fflush(stdout);
   }

   	if (methodSaveOptFamily.id != NULLTAG)
	{
		//if( METHOD_add_action(methodSaveOptFamily, METHOD_pre_action_type, (METHOD_function_t) save_method_OptFamily_Pre, NULL)!=ITK_ok)
		if( METHOD_add_pre_condition(methodSaveOptFamily, (METHOD_function_t) save_method_OptFamily_Pre, NULL)!=ITK_ok)
		{
				printf("\n !!!!!!!!!!! methodSaveOptFamily error found!!!!!!!!!!\n");
		}
	}
    else
    {
		printf("\n !!!!!!!!!!! methodSaveOptFamily not found!!!!!!!!!!\n");
    }

   	if (methodSaveOptValue.id != NULLTAG)
	{
		//if( METHOD_add_action(methodSaveOptValue, METHOD_pre_action_type, (METHOD_function_t) save_method_OptValue_Pre, NULL)!=ITK_ok)
		if( METHOD_add_pre_condition(methodSaveOptValue, (METHOD_function_t) save_method_OptValue_Pre, NULL)!=ITK_ok)
		{
				printf("\n !!!!!!!!!!! methodSaveOptValue error found!!!!!!!!!!\n");
		}
	}
    else
    {
		printf("\n !!!!!!!!!!! methodSaveOptValue not found!!!!!!!!!!\n");
    }

	METHOD_id_t		methodOptFamilyMDM;
	CALLAPI (METHOD_find_method("T5_FamilyMDM", IMAN_save_msg, &methodOptFamilyMDM));
	
	if (methodOptFamilyMDM.id != NULLTAG)
	{
		printf("\n*****************Method methodOptFamilyMDM  found...!!*****************\n"); fflush(stdout);
		CALLAPI( METHOD_add_action(methodOptFamilyMDM, METHOD_post_action_type, (METHOD_function_t) OptFamilyMDM_post, NULL)!=ITK_ok);

	}
	else
	{
		printf("\n*****************Method methodOptFamilyMDM not found...!!*****************\n"); fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("tm_MDM_CreOptVal", "", MDM_CreOptVal))
   {
		printf("\t\n Registered Action Handler MDM_CreOptVal\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler MDM_CreOptVal\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_action_handler("tm_MDM_Cre_PrdCnfg_Option", "Creating Option family and Value", MDM_CrePrdCnfgOpt_Fam_Val))
   {
		printf("\t\n Registered Action Handler MDM_CrePrdCnfgOpt_Fam_Val\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler MDM_CrePrdCnfgOpt_Fam_Val\n");fflush(stdout);
   }
	if( ITK_ok == EPM_register_action_handler("tm_MDM_Upd_SVR", "Updating SVR", MDM_Upd_SVR))
   {
		printf("\t\n Registered Action Handler MDM_Upd_SVR \n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler MDM_Upd_SVR \n");fflush(stdout);
   }

   	if( ITK_ok == EPM_register_action_handler("tm_MDM_Dump_SVR", "Printing SVR", MDM_Print_SVR))
   {
		printf("\t\n Registered Action Handler MDM_Print_SVR \n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler MDM_Print_SVR \n");fflush(stdout);
   }

   METHOD_id_t  methodSaveMDMFamily ;
  

   if (ITK_ok == METHOD_find_method("T5_FamilyMDMRevision", IMAN_save_msg, &methodSaveMDMFamily))
	{
		printf("\t\n methodSaveMDMFamily svr_Report\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to methodSaveMDMFamily svr_Report\n");fflush(stdout);
   }

    if (methodSaveMDMFamily.id != NULLTAG)
	{
		
		if( METHOD_add_pre_condition(methodSaveMDMFamily, (METHOD_function_t) save_method_MDMFamily_Pre, NULL)!=ITK_ok)
		{
				printf("\n !!!!!!!!!!! methodSaveMDMFamily error found!!!!!!!!!!\n");
		}
	}
    else
    {
		printf("\n !!!!!!!!!!! methodSaveMDMFamily not found!!!!!!!!!!\n");
    }

   
   return ITK_ok;
}

int SVR_ReportFun( void *return_data )
{
	int status;
	int				ifail 						= ITK_ok;
	char			*PlatformObjNm					= NULL;
	char			*RevRule					= NULL;
	char			*Inp1					= NULL;
	char			*Inp2					= NULL;
	char			*Date					= NULL;
	char			*output						= NULL;
	char			*Filename						= NULL;




	USERARG_get_string_argument(&PlatformObjNm);
	USERARG_get_string_argument(&RevRule);
	USERARG_get_string_argument(&Inp1);
	USERARG_get_string_argument(&Inp2);
	USERARG_get_string_argument(&Date);
	USERARG_get_string_argument(&Filename);

	printf("\n in SVR_ReportFun function3");fflush(stdout);

	
	printf("\n Recieved Input argument in ITK ReportFun()3: %s | %s | %s | %s | %s | %s |",PlatformObjNm,RevRule,Inp1,Inp2,Date,Filename);fflush(stdout);
	
	char	*user_name						= NULL;
	tag_t	tUser							= NULLTAG;
	POM_get_user(&user_name,&tUser);

	printf("\n in SVR_ReportFun function3 %s \n",user_name);fflush(stdout);
	SvrVehCompareRep (Inp1,Inp2,PlatformObjNm,RevRule,Date,Filename,&output);


				




	printf("\n Item not found \n");fflush(stdout);
	//output = "Report Called. ";


	printf("\n End of program.....!!  %s \n\n",output);fflush(stdout);
	*((char **) return_data) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

	strcpy( *((char **) return_data), output); 
	
	return ifail;
	/* Program Logic End*/
}

extern DLLAPI int SvrRepModule(METHOD_message_t *msg, va_list args)
{   
 	int nargs=6;
	int *inputArgTypes;	
	int retValueType;
        
	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));	
	inputArgTypes[0]=USERARG_STRING_TYPE;
	inputArgTypes[1]=USERARG_STRING_TYPE;
	inputArgTypes[2]=USERARG_STRING_TYPE;
	inputArgTypes[3]=USERARG_STRING_TYPE;
	inputArgTypes[4]=USERARG_STRING_TYPE;
	inputArgTypes[5]=USERARG_STRING_TYPE;
	retValueType=USERARG_STRING_TYPE;
	
	printf("\n User Service Call SvrRepModule....");fflush(stdout);
	
    
	USERSERVICE_register_method("SvrVehBOMRep",(USER_function_t) SVR_ReportFun, nargs, inputArgTypes, retValueType);
    return ITK_ok;
}


extern DLLAPI int tm_svr_release_register_callbacks()
{     
	 CUSTOM_register_exit("tm_svr_release", "USER_init_module", (CUSTOM_EXIT_ftn_t) svr_release_register_method);
	 CUSTOM_register_exit ("tm_svr_release", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)SvrRepModule);

     printf("\n registered function svr_release_dml111\n");	fflush(stdout);

	 return ( ITK_ok );
}

