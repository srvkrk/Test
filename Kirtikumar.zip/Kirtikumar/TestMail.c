#include <stdio.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tc/envelope.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))




FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}
/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";


	tag_t person_tag		= NULLTAG;
	tag_t envelop_tag		= NULLTAG;
	tag_t env_input_tag		= NULLTAG;
	tag_t Envelop_object	= NULLTAG;

	char* username		= NULL;
	char* user_email	= NULL;
	char* mail_subject	= NULL;
	char* mail_body		= NULL;

	char path[100];

	mail_subject	= (char *) MEM_alloc(100 * sizeof(char ));
	mail_body		= (char *) MEM_alloc(250 * sizeof(char ));
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	//file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 )
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	

	char* userId = NULL;
	tag_t user_tag = NULLTAG;
	char* usernameDir = NULL;


	mail_subject	= (char *) MEM_alloc(100 * sizeof(char ));
	mail_body		= (char *) MEM_alloc(1000 * sizeof(char ));

	ITK_CALL(SA_find_user2(userId,&user_tag));
	if(user_tag == NULLTAG )
	{
		tc_strdup(userId,&username);
		tc_strdup("kt.ttl@tatamotors.com",&user_email);
	}
	else
	{
		ITK_CALL(SA_ask_user_person_name2(user_tag,&username));
		ITK_CALL(SA_find_person2(username,&person_tag));
		ITK_CALL(SA_ask_person_email_address(person_tag,&user_email));
	}
	printf("\nusername : %s user_email : %s",username,user_email);

	tc_strcpy(mail_subject,"FIR Released for: Testing-Indoor/06816 -PCB,FLOOR CONSOLE");
	

	tc_strcpy(mail_body,"<html><head>");
	tc_strcat(mail_body,"<title> This is sample test Title </title>");
	tc_strcat(mail_body,"<meta charset='UTF-8'>");
	tc_strcat(mail_body,"<meta name=viewport content='width=device-width,initial-scale=1>");
	tc_strcat(mail_body,"<link href='https://pfirst.inservices.tatamotors.com/pFirst/db/1320/upload/1/359782/1/1646369771/revise.PNG>'>");
	tc_strcat(mail_body,"</body></html>");


	printf("\nmail_subject : %s",mail_subject);
	printf("\nmail_body : %s",mail_body);


	ITK_CALL(TCTYPE_find_type("Envelope", NULL, &envelop_tag));   
	ITK_CALL(TCTYPE_construct_create_input(envelop_tag, &env_input_tag));

	ITK_CALL(AOM_set_value_string(env_input_tag,"object_name",mail_subject));
	ITK_CALL(AOM_set_value_string(env_input_tag,"object_desc",mail_body));
	
	ITK_CALL(TCTYPE_create_object(env_input_tag, &Envelop_object));

	if(Envelop_object)
	{
		printf("\nEnvelop_object : object created.");
		ITK_CALL(AOM_save(Envelop_object));
		ITK_CALL(AOM_unlock(Envelop_object));
	}

	ITK_CALL(AOM_lock(Envelop_object));

	ITK_CALL(MAIL_add_external_receiver(Envelop_object,MAIL_send_to,user_email));
	//ITK_CALL(MAIL_add_external_receiver(Envelop_object,MAIL_send_cc,"Tushar.Rasane@tatatechnologies.com"));
	//ITK_CALL(MAIL_add_external_receiver(Envelop_object,MAIL_send_cc,"Amol.Narke@tatatechnologies.com"));
	//ITK_CALL(MAIL_add_external_receiver(Envelop_object,MAIL_send_cc,"Devkant.Kedar@tatatechnologies.com"));
	
	ITK_CALL(AOM_save(Envelop_object));
	ITK_CALL(AOM_unlock(Envelop_object));
	ITK_CALL(AOM_refresh(Envelop_object,0));

	ITK_CALL(MAIL_send_envelope(Envelop_object));

		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


