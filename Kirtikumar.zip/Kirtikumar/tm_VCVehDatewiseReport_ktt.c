/*
./compile tm_VCVehDatewiseReport.c
./linkitk -o tm_VCVehDatewiseReport tm_VCVehDatewiseReport.o
scp tm_VCVehDatewiseReport tkr06466@172.22.97.12:/user/plmsap/PLMSAP/tkr/Report/VCVehDatewiseReport
./tm_VCVehDatewiseReport -u=ercpsup -p=ERCpsup2019 -fromdate="01-Mar-2021" -todate="20-Mar-2021" -InputVorVC=VC
*/

#define TE_MAXLINELEN  128

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <unidefs.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <time.h>

FILE * fsuccess;
FILE* fp=NULL;
char fsuccess_name[200];

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

char* userId = NULL;
char* usernameDir = NULL;

char group;
FILE *fsuccess,*ferror1;
char cComma[14]={",,,,,,,,,,,,"};
char SiamFile[100]={0};
char ferror_name[200] = {0};
int	cmvrFlag	= 0;
char *inputDML=NULL;

char *ColorIDPart = NULL;
char *ColorIDPartDup = NULL;
char *UrnCode = NULL;

char *st5Pollutant_CM1 = NULL;
char *CMUnit = NULL;
char *st5Pollutant_HC1 = NULL;
char *HCUnit = NULL;
char *st5Pollutant_NH1 = NULL;
char *NMHCUnit = NULL;
char *st5Pollutant_RHC1 = NULL;
char *RHCUnit = NULL;
char *st5Pollutant_NO1 = NULL;
char *NOUnit = NULL;
char *st5Pollutant_HCNO1 = NULL;
char *HCNOUnit = NULL;
char *st5Pollutant_PM1 = NULL;
char *PMUnit = NULL;
char *st5Pollutant_HO1 = NULL;
char *st5BystanderPos = NULL;

char *st5Pollutant_CM1Dup = NULL;
char *CMUnitDup = NULL;
char *st5Pollutant_HC1Dup = NULL;
char *HCUnitDup = NULL;
char *st5Pollutant_NH1Dup = NULL;
char *NMHCUnitDup = NULL;
char *st5Pollutant_RHC1Dup = NULL;
char *RHCUnitDup = NULL;
char *st5Pollutant_NO1Dup = NULL;
char *NOUnitDup = NULL;
char *st5Pollutant_HCNO1Dup = NULL;
char *HCNOUnitDup = NULL;
char *st5Pollutant_PM1Dup = NULL;
char *PMUnitDup = NULL;
char *st5Pollutant_HO1Dup = NULL;
char *st5BystanderPosDup = NULL;

char *st5Pollutant_CM1Dup1 = NULL;
char *st5Pollutant_HC1Dup1 = NULL;
char *st5Pollutant_NH1Dup1 = NULL;
char *st5Pollutant_RHC1Dup1 = NULL;
char *st5Pollutant_NO1Dup1 = NULL;
char *st5Pollutant_HCNO1Dup1 = NULL;
char *st5Pollutant_PM1Dup1 = NULL;

char *AmoniaUnit			= NULL;
char *AmoniaUnitDup		= NULL;
char *MethaneUnit			= NULL;
char *MethaneUnitDup		= NULL;
char *ParticleUnit		= NULL;
char *ParticleUnitDup		= NULL;

char *t5Pol_Amonia1		= NULL;
char *t5Pol_Amonia1Dup1	= NULL;
char *t5Pol_Methane1		= NULL;
char *t5Pol_Methane1Dup1	= NULL;
char *t5Pol_Particle1		= NULL;
char *t5Pol_Particle1Dup1	= NULL;

char *t5Pol_Amonia1Dup	= NULL;
char *t5Pol_Methane1Dup	= NULL;
char *t5Pol_Particle1Dup	= NULL;

char *BBBACNUM			= NULL;
char *BBBACNUMDup		= NULL;
char *BBBACISDT		= NULL;
char *BBBACISDTDup		= NULL;
char *BBBACVLDT		= NULL;
char *BBBACVLDTDup		= NULL;
char *VBCAPRCNUM		= NULL;
char *VBCAPRCNUMDup	= NULL;
char *VBCAPRDT			= NULL;
char *VBCAPRDTDup		= NULL;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		for( index=0; index<n_ifails; index++)
		{
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  return;
}

struct VCAttrDetails
{
	char VCAttrID[500];
	char VCAttrName[500]; //car
	char VCAttrNameValue[500];
};
struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;

void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t revRule,struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));

	BOM_set_window_top_line(window, null_tag,inputPart ,null_tag, &top_line);
	ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
	//printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

	level = level + 1;
	for (k = 0; k < n; k++)
	{
		BOM_line_unpack (children[k]);
		BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
		BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
		if(t_ChildItemRev!=NULLTAG)
		{
			AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
			*StructChldCnt	=	*StructChldCnt+1;
			BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
			BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
			BomChldStrut[*StructChldCnt].child_objs_lvl=level;

			Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,revRule,BomChldStrut,StructChldCnt);
		}
	}
	level = level - 1;

	MEM_free (childrenTag);

	CLEANUP:
		 printf("");fflush(stdout);
		 //printf("Inside Multi_Get_Part_BOM_Lvl");fflush(stdout);
}
int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  revRuleName,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1	= 0;
	int n	= 0;
	int 	n_values_bvr = 0;
	tag_t *bvr_assy_part	= NULLTAG;
	tag_t bvr_tag			= NULLTAG;
	int level 				= 0;
	tag_t	window 			= NULLTAG;
	tag_t	top_line		= NULLTAG;
	tag_t	objChild		= NULLTAG;
	tag_t	objChild_bvr	= NULLTAG;
	int child_lvl			= 0;
	char	*c_Qty			=	NULL;
	tag_t  *children1		= NULLTAG;
	int iChildItemTag		= 0;
	int assbvr				= 0;
	int bvrfound			= 0;
	int flagRevRule			= 0;
	int flagClosureRule		= 0;
	char *view_name			= NULL;
	char* partTok			= NULL;
	char* viewTok			= NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	//printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		//printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	ITKCALL(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	//printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	//printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	//printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	//printf("\nBefore level==>%d\n",level);fflush(stdout);
	//printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	//printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);

	ITKCALL(CFM_find(revRuleName, &revRule));
	if (revRule != NULLTAG)
	{
		//printf("\nFind revRule\n");fflush(stdout);
		flagRevRule=1;
	}

	scope=PIE_TEAMCENTER;

	//printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
	//printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
	if(flagRevRule==1)
	{

		Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,revRule,BomChldStrut,StructChldCnt);
	}
	else
	{
		printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
	}

	//printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       = 0;

		//printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		//printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		//printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		//printf("\nQty==>%s\n",c_Qty);fflush(stdout);
	}
	return ifail;
}
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

int tm_ebom_mbom_rpt(tag_t VObjTag,char ***SetModulePart,int *icount)
{
	int		ifail 				=   ITK_ok;
	char	*tasknumber			=	NULL;
	char	*type_name			=	NULL;
	char	*type_nameP			=	NULL;
	char	*type_name2			=	NULL;
	char	*tsk_object_name	=	NULL;
	char	*ClrSVROnly			=	NULL;
	char	*tmpSVR				=	NULL;
	char	*nonClrSvr			=	NULL;
	char	*clrSlr				=	NULL;
	char	*qry_entries3[1]	= {"Name"};
	char	*qry_entries10[1]	= {"ID"};
	char	*itemid;
	char	*svrName			=	NULL;
	char	*t5_SchmPlant		=	NULL;
	char	*t5_ClSrl			=	NULL;
	char	*arch_item_id		=	NULL;
	char	*arch_item_idrev	=	NULL;
	char	*Archtype_name		=	NULL;
	char	**rulename			=	NULL;
	char	**rulevalue			=	NULL;
	char	*item_Rev_Seq		=	NULL;
	char	*StagePartNo		=	NULL;
	char	*Stage_item_Rev_Seq	=	NULL;
	char	*StagePartType		=	NULL;
	char	*ModPartNo			=	NULL;
	char	*ModPartType		=	NULL;
	char	*ModPartLine		=	NULL;
	char	*ModItem_Rev		=	NULL;
	char	*ModItem_Seq		=	NULL;
	char	*ChildColInd		=	NULL;
	char	*Item_ID_str		=	NULL;
	char	*ModPartAct			=	NULL;

	char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
	char	**valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));

	date_t  eff_date;

	tag_t	objTypeTag			=	NULLTAG;
	tag_t	ItemTypeTag			=	NULLTAG;
	tag_t	*PartTags			=	NULLTAG;
	tag_t	t_svr				=	NULLTAG;
	tag_t	ClrVariqueryTag		=	NULLTAG;
	tag_t	*ColVRule_tags		=	NULLTAG;
	tag_t	*t5_clrscm			=	NULLTAG;
	tag_t	PlatformTag			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;
	tag_t	item_tag			=	NULLTAG;
	tag_t	PlatformTypeTag		=	NULLTAG;
	tag_t	PlatformRevTag		=	NULLTAG;
	tag_t	PlatformRevTypeTag	=	NULLTAG;
	tag_t   e_block				=	NULLTAG;
	tag_t	*lines2				=	NULLTAG;
	tag_t	*lines3				=	NULLTAG;
	tag_t	PartChildobj		=	NULLTAG;
	tag_t	StageChildobj		=	NULLTAG;
	tag_t   t_ChildItemRev		=	NULLTAG;


	int		PartCnt			=	0;
	int		n_entriesV		=	1;
	int		n_entriesP		=	1;
	int		n_tags_found	=	0;
	int		n_count			=	0;
	int		ClrCnt = 0;
	int		iSVR = 0;
	int		count_clrscm	=	0;
	int		rulefound		=	0;
	int		count			=	0;
	int		ichld			=	0;
	int		n_lines2		=	0;
	int		n_lines3		=	0;
	int		iMod			=	0;
	int		iMod1			=	0;
	int		NonClrPartlevel =	0;
	int		iChildItemTag	=   0;
	int		Revformula;
	const char *qry_entries[1];
	const char *qry_values[1];
	struct	BomChldStrut ChldStrutBdySh[5000];
	
	tag_t	*itemclass			=	NULLTAG;
	tag_t	item				=	NULLTAG;
	tag_t	tsk_HSI_rel_type	=	NULLTAG;
	tag_t	t5_appl_SVR			=	NULLTAG;
	tag_t	item_rev_tag		=	NULLTAG;
	tag_t	bom_wnd				=	NULLTAG;
	tag_t	rule				=	NULLTAG;
	tag_t	*closurerule		=	NULLTAG;
	tag_t	close_tag			=	NULLTAG;
	tag_t   bom_variant_rule	=	NULLTAG;
	tag_t  	objTypeTag1			=	NULLTAG;
	tag_t	top_lne				=	NULLTAG;
	tag_t	*ArchNodeLines		=	NULLTAG;
	tag_t	VarientRuletag		=	NULLTAG;
	tag_t	*ColIndChilds		=	NULLTAG;
	tag_t	Childobject			=	NULLTAG;
	char   *taskowning_groupVal =	NULL;
	
	//printf("\nInSide tm_ebom_mbom_rpt");fflush(stdout);
	
	char *VPrtNum=NULL;
	char *VPrtType=NULL;
	
	ITK_CALL(AOM_ask_value_string(VObjTag,"item_id",&VPrtNum));
	ITK_CALL(AOM_ask_value_string(VObjTag,"item_revision_id",&VPrtType));
	
	if(VObjTag!=NULLTAG)
	{		
		ITKCALL(BOM_create_window(&bom_wnd ));
		ITKCALL(CFM_find("ERC release and above", &rule));
		//printf ("\nrule count %d \n",rulefound);fflush(stdout);

		ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE));
		ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, VObjTag, NULLTAG, &top_lne ));

		if(top_lne!=NULLTAG)
		{
			ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
			//printf("\n n_count --------> : %d\n", n_count);
			ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
			//printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node
					
			if (count >0)
			{
				for (ichld=0;ichld<count ;ichld++ )
				{
					if(Childobject) Childobject=NULLTAG;
					Childobject=ColIndChilds[ichld];

					ITKCALL(AOM_ask_value_string(Childobject, "bl_item_item_id", &arch_item_id ));
					//printf("\n arch_item_id ..:%s\n",arch_item_id); fflush(stdout);
					ITKCALL(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &arch_item_idrev ));
					//printf("\n arch_item_idrev ..:%s\n",arch_item_idrev); fflush(stdout);
					char*	 arch_item_ModAdd    			= NULL;	
					ITKCALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&arch_item_ModAdd));
					//printf("\n arch_item_idrev ..:%s\n",arch_item_ModAdd); fflush(stdout);
					
					if((tc_strcmp(arch_item_ModAdd,"MC1D01")==0) || (tc_strcmp(arch_item_ModAdd,"MC2A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MC3Z01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1N01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP3A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MC1D02")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1L01")==0))
					{
						ModPartAct	=	(char	*)MEM_alloc(300);
						tc_strcpy(ModPartAct,arch_item_id);
						tc_strcat(ModPartAct,"/");
						tc_strcat(ModPartAct,arch_item_idrev);

						//printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
						setAddStr(icount,SetModulePart,ModPartAct);
					}
						//Find the ERC and explode and find PB part.
					if(lines2) lines2=NULL;

					ITKCALL(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
					//printf("\n Child parts count--> %d\n",n_lines2);fflush(stdout);

					if(n_lines2 > 0)
					{
						for (iMod=0;iMod<n_lines2 ;iMod++ )
						{
							if(PartChildobj) PartChildobj=NULLTAG;
							if(ModPartNo) ModPartNo=NULL;
							if(item_Rev_Seq) item_Rev_Seq=NULL;
							if(ModPartType) ModPartType=NULL;
							if(ModPartLine) ModPartLine=NULL;
							if(taskowning_groupVal) taskowning_groupVal=NULL;
							PartChildobj=lines2[iMod];

							ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
							//printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);

							ITKCALL(AOM_ask_value_string(PartChildobj, "bl_line_name", &ModPartLine ));
							//printf("\n ModPartLine --> : %s\n",ModPartLine); fflush(stdout);
							
							ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
							//printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);
							
							ITKCALL(AOM_ask_value_string(PartChildobj, "bl_Design_t5_RevPartType", &ModPartType ));
							//printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);
							
							char*	 ModPart_ModAdd    			= NULL;	
							ITKCALL(AOM_ask_value_string(PartChildobj,"bl_Design Revision_t5_ModuleAddress",&ModPart_ModAdd));

						
							if((tc_strcmp(ModPart_ModAdd,"MC1D01")==0) || (tc_strcmp(ModPart_ModAdd,"MC2A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MC3Z01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1N01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP3A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MC1D02")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1L01")==0))
							{
								ModPartAct	=	(char	*)MEM_alloc(300);
								tc_strcpy(ModPartAct,ModPartNo);
								tc_strcat(ModPartAct,"/");
								tc_strcat(ModPartAct,item_Rev_Seq);
								//printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);

								setAddStr(icount,SetModulePart,ModPartAct);
							}

							iChildItemTag=0;
							t_ChildItemRev=NULLTAG;
							BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
							BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);
							if(t_ChildItemRev!=NULLTAG)
							{	
								n_lines3=0;
								
								ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"ERC release and above",ChldStrutBdySh,&n_lines3));
								//printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
								
								//printf("\n Stage Assembly count--> %d\n",n_lines3);fflush(stdout);

								if(n_lines3 > 0)
								{
									for (iMod1=1;iMod1<=n_lines3 ;iMod1++ )
									{
										if(StageChildobj) StageChildobj=NULLTAG;	
										if(StagePartNo) StagePartNo=NULL;
										if(Stage_item_Rev_Seq) Stage_item_Rev_Seq=NULL;
										if(StagePartType) StagePartType=NULL;
										
										char*	 StagePartNo_ModAdd    			= NULL;
										
										StageChildobj=ChldStrutBdySh[iMod1].child_objs_bvr;

										ITKCALL(AOM_ask_value_string(StageChildobj, "bl_item_item_id", &StagePartNo ));
										//printf("\n StagePartNo --> : %s\n",StagePartNo); fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(StageChildobj, "bl_rev_item_revision_id", &Stage_item_Rev_Seq));
										//printf("\n Stage_item_Rev_Seq --> : %s\n",Stage_item_Rev_Seq); fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(StageChildobj, "bl_Design_t5_RevPartType", &StagePartType ));
										//printf("\n StagePartType --> : %s\n",StagePartType); fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(StageChildobj,"bl_Design Revision_t5_ModuleAddress",&StagePartNo_ModAdd));
										//printf("\n stage Part type Modules Under StagePartNo_ModAdd for child parts --> : %s\n",StagePartNo_ModAdd); fflush(stdout);

										if((tc_strcmp(StagePartNo_ModAdd,"MC1D01")==0) || (tc_strcmp(StagePartNo_ModAdd,"MC2A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MC3Z01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1N01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP3A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MC1D02")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1L01")==0))
										{
											//To add in set
											ModPartAct	=	(char	*)MEM_alloc(300);
											tc_strcpy(ModPartAct,StagePartNo);
											tc_strcat(ModPartAct,"/");
											tc_strcat(ModPartAct,Stage_item_Rev_Seq);

											//printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
											setAddStr(icount,SetModulePart,ModPartAct);
										}
									}
								}
							}
						}//for loop
					}//if(n_lines2 > 0)
				}
			}
		}

	}
	else 
	{
		printf ("\n  Object is null\n"); fflush(stdout);	
	}
	
	return ifail;
}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

int getClassifiedValue(char ***bufferedXmlStrOut,int *buff_cnt,int* vcattr,struct VCAttrDetails VCAttrDetailsList[])
{
	int ifail = ITK_ok;
	int m =0;
	int m1 =0;
	printf("\nBuff count=%d\n",*buff_cnt);fflush(stdout);
	char* ModPartNUmberREvseq	= NULL;
	char* ModPartNUmberREvseq1	= NULL;
	char* ModPartNum	= NULL;

	for(m1=0;m1<*buff_cnt;m1++)
	{
		ModPartNUmberREvseq1	= NULL;
		ModPartNUmberREvseq1 = (*bufferedXmlStrOut)[m1];
		//printf("\nModel solved Part number rev seq: %s",ModPartNUmberREvseq1);fflush(stdout);
	}
	
	m1=0;
	char**	ModPartNumSet = NULL;
	ModPartNumSet = (char**)MEM_alloc( 1 * sizeof *ModPartNumSet );
	int	ModPrtSr=0;
	for(m1=0;m1<*buff_cnt;m1++)
	{
		ModPartNum	= NULL;
		ModPartNUmberREvseq = (*bufferedXmlStrOut)[m1];
		ModPartNum = strtok (ModPartNUmberREvseq,"/");
		printf("\nModel Part number:: %s",ModPartNum);fflush(stdout);
		setAddStr(&ModPrtSr,&ModPartNumSet,ModPartNum);
	}
	m1=0;
	char**	ModPartNumUqSet = NULL;
	ModPartNumUqSet = (char**)MEM_alloc( 1 * sizeof *ModPartNumUqSet );
	int	ModPrtSrUq=0;
	
	for(m1=0;m1<ModPrtSr;m1++)
	{
		int FoundFlag=0;
		ModPartNum	= NULL;
		//printf("\n%s",(ModPartNumSet)[m1]);fflush(stdout);
		ModPartNum = (ModPartNumSet)[m1];
		//printf("\n Serching part number %s",ModPartNum);fflush(stdout);
		int j=0;
		for(j=0;j<ModPrtSrUq;j++) 
		{
			//printf("\n Compareing with  ===%s",(ModPartNumUqSet)[j]);fflush(stdout);
			if(tc_strcmp((ModPartNumUqSet)[j],ModPartNum)==0)
			{
				//printf("\n String Found ===%d",j);fflush(stdout);
				FoundFlag=1;
				break;
			}
			else
			{
				//printf("\n Part Number NOT Found %s",ModPartNum);fflush(stdout);
				//setAddStr(&ModPrtSrUq,&ModPartNumUqSet,ModPartNum);
				//FoundFlag=1;
			}
		
		}
		if(FoundFlag==0)
		{
			//printf("\n Part Number %s Added",ModPartNum);fflush(stdout);
			setAddStr(&ModPrtSrUq,&ModPartNumUqSet,ModPartNum);
		}
	}
	m1=0;
	//printf("\nTotal Number of Unique Model Found=%d\n",ModPrtSrUq);fflush(stdout);
	//fprintf(fUASAPMapping,"\n Number of Solved Unique Module:%d",ModPrtSrUq); fflush(fUASAPMapping);
	for(m1=0;m1<ModPrtSrUq;m1++)
	{
		ModPartNum	= NULL;
		ModPartNum = (ModPartNumUqSet)[m1];
		//printf("\nFinal Unique set is: %s",ModPartNum);fflush(stdout);
		//fprintf(fUASAPMapping,"\n :%s",ModPartNum); fflush(fUASAPMapping);
	}
	for(m=0;m<ModPrtSrUq;m++)
	{
		ModPartNum	= NULL;
		//printf("\n Loop Number %d",m);fflush(stdout);
		tag_t Modelrev_tag = NULLTAG;
		ModPartNum = (ModPartNumUqSet)[m];
		//printf("\nModel Part number: %s",ModPartNum);fflush(stdout);
		
		if(ITEM_find_item(ModPartNum,&Modelrev_tag)!=ITK_ok)PrintErrorStack();
		//printf("\n selected part part Master found");fflush(stdout);
		
		tag_t			classificationObject = NULLTAG;
		int theAttributeCount =0;
		int *theAttributeIds ;
		char 			**theAttributeNames;
		int *theAttributeValCounts=0;
		char***       theAttributeValues;
		char***       theAttributeOptimizedUnits;
		char* 	attrId 					= NULL;
		attrId = (char *) MEM_alloc( 50 * sizeof(char) );
		char 	*attributeNameDup 			= NULL;
		char 	*attributeValueDup 			= NULL;
		attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
		attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
		int i,x=0;
		int TotVCAttrCount=0;
		
		char*	 ModelrevPartRev = NULL;
		
		ITK_CALL(ICS_ask_classification_object(Modelrev_tag,&classificationObject));
	
		if (classificationObject != NULLTAG)
		{
			ITK_CALL( ICS_ico_ask_attributes_optimized(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
			//printf("### ICS_ico_ask_named_attributes nAttributes = %d\n", theAttributeCount);fflush(stdout);
			if(theAttributeCount>0)
			{
				for(i=0;i<theAttributeCount;i++)
				{
						
					TotVCAttrCount=TotVCAttrCount+theAttributeCount;
					
					sprintf(attrId,"%d",theAttributeIds[i]);
					//printf("\n attrId:[%s]",attrId);fflush(stdout);
						
					tc_strcpy(attributeNameDup,"");
					tc_strcpy(attributeNameDup,theAttributeNames[i]);
					
					//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);
					
					tc_strcpy(attributeValueDup,"");
					
					//printf("\n Number of attribute value is %d ",*theAttributeValCounts);fflush(stdout);
					
					for(x=0;x<theAttributeValCounts[i];x++)
					{
						//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
						tc_strcat(attributeValueDup,theAttributeValues[i][x]);
						//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
					}

					//printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrID,attrId);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrName,attributeNameDup);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrNameValue,attributeValueDup);
					
					//printf("\n attribute id in loop :[%s]",VCAttrDetailsList[*vcattr].VCAttrID);fflush(stdout);
					//printf("\n attribute name  in loop:[%s]",VCAttrDetailsList[*vcattr].VCAttrName);fflush(stdout);
					//printf("\n attribute Value in loop:[%s]",VCAttrDetailsList[*vcattr].VCAttrNameValue);fflush(stdout);
					*vcattr=*vcattr+1;
				}
					//printf("\n total VC attribute value:[%d] ",TotVCAttrCount);fflush(stdout);
					//printf("\n total vcattr value:[%d] ",*vcattr);fflush(stdout);
			}
		}
		else
		{
			//printf("\n VCclassificationObject NOt found");fflush(stdout);
		}
	}
	//printf("\n END For Loop");fflush(stdout);
	
	int j=0;
	for(j=0 ;j<*vcattr;j++ )
	{
		//printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
		//printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
		//printf("\n attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
		//printf("\n attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);  
	}

	//printf("\nGoing from getClassifiedValue");fflush(stdout);
	return ifail;									
}

static tag_t ask_item_revision_from_bom_line_SnapShot(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;
    
    ITKCALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITKCALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITKCALL(ITEM_find_rev(item_id, rev_id, &item_revision));
    
    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}

void GetAllChild_SnapShot(tag_t* top_line,int depth,char ***SetModulePart,int *icount)
{
	int n = 0;
	tag_t* children = NULLTAG;
	int k = 0;
	int Item_ID = 0;
	int Item_RevSeq = 0;
	char *Item_ID_str = NULL;
	char *Item_RevSeq_str = NULL;
	tag_t ChildItemRev = NULLTAG;
	char	*ModPartType=	NULL;
	int			modadd			= 0;
	char	*ModPartAct	=	NULL;
	char *mod_addr = NULL;

	depth++;
	//printf("\nInside GetAllChild_SnapShot********");fflush(stdout);
	ITKCALL( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	ITKCALL( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_RevSeq));
	ITKCALL(BOM_line_ask_attribute_string(*top_line, Item_ID, &Item_ID_str));
	ITKCALL(BOM_line_ask_attribute_string(*top_line, Item_RevSeq, &Item_RevSeq_str));
	//printf("\n%d]Item_ID_str: [%s] [%s]",depth,Item_ID_str,Item_RevSeq_str);fflush(stdout);
	ChildItemRev = ask_item_revision_from_bom_line_SnapShot(*top_line);
	tag_t ChildTagLatestRev	 = NULLTAG;

	if(ITEM_ask_latest_rev(ChildItemRev,&ChildTagLatestRev));
	
	if (ChildItemRev==NULLTAG)
	{
		printf("\nNULLTAG FOUND FOR BOM LINE ITEM : %s",Item_ID_str);fflush(stdout);
	}
	else
	{
		if(ModPartType) ModPartType=NULL;
		
		ITKCALL(AOM_ask_value_string(*top_line, "bl_Design_t5_RevPartType", &ModPartType ));
		//printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);
		
		if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd))PrintErrorStack();
		if(BOM_line_ask_attribute_string(*top_line, modadd, &mod_addr))PrintErrorStack();
		//printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
	
		if((tc_strcmp(ModPartType,"M")==0) || (tc_strcmp(ModPartType,"CM")==0))
		{
			/*X4MC1D01
			X4MC2A01
			X4MC3Z01vi 
			X4MP1A01
			X4MP1N01
			X4MP3A01
			X4MC1D02*/
			//this module is not menstioned in excel shee added as per mail MP1L01
			if((tc_strcmp(mod_addr,"MC1D01")==0) || (tc_strcmp(mod_addr,"MC2A01")==0)|| (tc_strcmp(mod_addr,"MC3Z01")==0)|| (tc_strcmp(mod_addr,"MP1A01")==0)|| (tc_strcmp(mod_addr,"MP1N01")==0)|| (tc_strcmp(mod_addr,"MP3A01")==0)|| (tc_strcmp(mod_addr,"MC1D02")==0)|| (tc_strcmp(mod_addr,"MP1L01")==0))
			{
				//printf("\nFor Adding Item_ID_str: [%s] [%s]",Item_ID_str,Item_RevSeq_str);fflush(stdout);
				//printf("\n adding Modules adderess --> : %s\n",mod_addr); fflush(stdout);
				//To add in set
				ModPartAct	=	(char	*)MEM_alloc(300);
				tc_strcpy(ModPartAct,Item_ID_str);
				tc_strcat(ModPartAct,"/");
				tc_strcat(ModPartAct,Item_RevSeq_str);

				//printf("\n ModPartAct --> : %s",ModPartAct); fflush(stdout);
				setAddStr(icount,SetModulePart,ModPartAct);
			}
		}
		ITKCALL(BOM_line_ask_child_lines (*top_line, &n, &children));

		//printf("\nAssembly:%s no of child found:%d",Item_ID_str,n);fflush(stdout);
		for (k = 0; k < n; k++)
		{
			GetAllChild_SnapShot(&children[k],depth,SetModulePart,icount);
		}
	}
}
int tm_ebom_snapshot(char *snapshot,char ***SetModulePart,int *icount)
{
	int	ifail 	=   ITK_ok;

	WSO_search_criteria_t SSCriteria;

	tag_t* SSobjTag		= NULLTAG;
	int SScount			= 0;
	int Item_ID			= 0;
	tag_t Snapshot_tag	= NULLTAG;
	tag_t window		= NULLTAG;
	tag_t item_rev_tags	= NULLTAG;
	tag_t top_line		= NULLTAG;
	char* SSTopLineRev	= NULL;
	char *Item_ID_str	= NULL;

	PIE_scope_t scope;
	scope=PIE_TEAMCENTER;

	//printf("\nInSide tm_ebom_snapshot functionssssssss");fflush(stdout);
	//printf("\nsnapshot ...%s\n", snapshot);fflush(stdout);
	
	ITKCALL(WSOM_clear_search_criteria(&SSCriteria));
	tc_strcpy(SSCriteria.class_name,"Snapshot");
	tc_strcpy(SSCriteria.name,snapshot);
	ITKCALL(WSOM_search(SSCriteria,&SScount,&SSobjTag));
	//printf("\nSnapShot found :%d",SScount);fflush(stdout);
	
	int		rulefound		=	0;
	tag_t	*closurerule	=	NULLTAG;
	tag_t	close_tag		=	NULLTAG;
	char	**rulename		=	NULL;
	char	**rulevalue		=	NULL;

	if (SScount > 0)
	{		
		Snapshot_tag = SSobjTag[0];

		ITKCALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
		ITKCALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));
		ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
		
		ITKCALL(PIE_find_closure_rules("BOMLineskipforunconfigured",scope, &rulefound, &closurerule ));
		//printf ("\nrule count %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			//printf ("closure rule found \n"); fflush(stdout);
		}
		ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
		//printf ("closure rule found applied \n"); fflush(stdout);
		ITKCALL(BOM_set_window_pack_all (window, FALSE));
		ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
		ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));

		ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
		ITKCALL(BOM_line_ask_attribute_string(top_line, Item_ID, &Item_ID_str));
		//printf("\nItem_ID_str#:%s",Item_ID_str);fflush(stdout);

		GetAllChild_SnapShot(&top_line,2,SetModulePart,icount);

	}
	else 
	{
		//printf ("\n  SnapShot not found [%s]\n", snapshot); fflush(stdout);	
	}
	
	return ifail;
}

extern int ITK_user_main(int argc, char ** argv )
{
	int status				= ITK_ok;
	char *fromdate			= NULL;
	char *todate			= NULL;
	char *report			= NULL;
	int i = 0;
	int n_entries;

	tag_t queryTag			= NULLTAG;
	int resultCount			= 0;
	tag_t *ERCDMLTags		= NULLTAG;
	tag_t ERCDMLTag			= NULLTAG;
	tag_t objTypeTag		= NULLTAG;
	char  type_name[TCTYPE_name_size_c+1];

	char *DmlId				= NULL;
	char *DmlIdDup			= NULL;
	char *DmlDesc			= NULL;
	char *DmlDescDup		= NULL;
	char *DmlRelType		= NULL;
	char *DmlRelTypeDup		= NULL;
	char *DmlRelStat		= NULL;
	char *DmlRelStatDup		= NULL;
	date_t DmlRelDate;
	char *DmlRelDateStr		= NULL;
	char *DmlDRstatus		= NULL;
	char *DmlDRstatusDup	= NULL;
	char *DmlDRfromto		= NULL;
	char *DmlDRfromtoDup	= NULL;
	char *Dmlreason			= NULL;
	char *DmlreasonDup		= NULL;
	char *Dmlsynopsis		= NULL;
	char *Dmlrequestor		= NULL;
	char *DmlRelTypeDup1	= NULL;
	char *DmlreasonDup1		= NULL;
	tag_t* TechSPecObjSet	= NULLTAG;
	int TechSpecCount		= 0;
	tag_t TechSPecObj		= NULLTAG;
	char *descDup			= NULL;

	tag_t snapshotObj		= NULLTAG;
	int snapshotCount		= 0;
	tag_t* snapshotObjSet	= NULLTAG;
	char snapshotObjtype_name[TCTYPE_name_size_c+1];
	tag_t snapshotObjTypeTag= NULLTAG;
	char* snapshot_itemid	= NULL;
	char* SSTopLineRev		= NULL;

	char** bufferedXmlStrOut;
	int buff_cnt= 0;

	int vcattr = 0;
	struct VCAttrDetails VCAttrDetailsList[5000];
	descDup = (char *)malloc(500 * sizeof(char));

	DmlRelTypeDup1 = (char *)malloc(500 * sizeof(char));
	DmlreasonDup1 = (char *)malloc(500 * sizeof(char));

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	fromdate	= ITK_ask_cli_argument("-fromdate=");
	todate		= ITK_ask_cli_argument("-todate=");
	report		= ITK_ask_cli_argument("-InputVorVC=");
		
	//OUTS("ERC DML Query fromdate",10,15, fromdate);
	//OUTS("ERC DML Query fromdate",10,15, todate);

	TC_write_syslog("\n NEW SYSLOG  1 \n");

	sprintf(fsuccess_name,"/user/testcmi/devgroups/Kirtikumar/vcvehdatewisereport.xml");
	fsuccess = fopen(fsuccess_name,"w+");

	if(fsuccess == NULL)
	{
		printf("\nUnable To open Or Create csv file"); fflush(stdout);
		goto CLEANUP;
	}

	fprintf(fsuccess,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); fflush(fsuccess);
	fprintf(fsuccess,"\n<Top>\n"); fflush(fsuccess);

	fprintf(fsuccess,"\n<From_Date>"); fflush(fsuccess);
	fprintf(fsuccess,fromdate); fflush(fsuccess);
	fprintf(fsuccess,"</From_Date>"); fflush(fsuccess);

	fprintf(fsuccess,"\n<To_Date>"); fflush(fsuccess);
	fprintf(fsuccess,todate); fflush(fsuccess);
	fprintf(fsuccess,"</To_Date>"); fflush(fsuccess);

	TC_write_syslog("\n NEW SYSLOG  2 \n");

	fprintf(fsuccess,"\n<Input_V_VC>"); fflush(fsuccess);
	fprintf(fsuccess,report); fflush(fsuccess);
	fprintf(fsuccess,"</Input_V_VC>"); fflush(fsuccess);

	//if(strcmp(report,"VC")==0)
	//	fprintf(fsuccess,"VC,Description,Revision,Color Ind,DR/AR Status,Previous rev DR status,First time rlz with DR4,Emission norms,Applicable for ESO,PRODUCT LINE,PLATFORM,Release Date,Vehicle Class,Plant Name,Business Unit,Dml No,DML type,DML DR status,DML from to,DML reason code,DML synopsis,Project Code,Project desc,Life Cycle State,Owner,Requestor \n");

	//if(strcmp(report,"V")==0)
	//	fprintf(fsuccess,"Veh,Description,Revision,Color Ind,DR/AR Status,Previous rev DR status,First time rlz with DR4,Emission norms,Applicable for ESO,PRODUCT LINE,PLATFORM,Release Date,Vehicle Class,Plant Name,Business Unit,Dml No,DML type,DML DR status,DML from to,DML reason code,DML synopsis,Project Code,Project desc,Life Cycle State,Owner,Requestor \n");

	n_entries = 3;
	char *qry_entries[3] = {"Name","date_released_after","date_released_before"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	qry_values[0] = (char *)MEM_alloc( strlen( "T5_LcsErcRlzd" ) + 1);
	strcpy(qry_values[0], "T5_LcsErcRlzd" );

	//qry_values[1] = (char *)MEM_alloc( strlen( "01-Mar-2021 00:00" ) + 1);
	qry_values[1] = (char *)MEM_alloc( strlen( fromdate ) + 1);
	//strcpy(qry_values[1], "01-Mar-2021 00:00"  );
	strcpy(qry_values[1], fromdate  );

	//qry_values[2] = (char *)MEM_alloc( strlen( "04-Mar-2021 00:00" ) + 1);
	qry_values[2] = (char *)MEM_alloc( strlen( todate ) + 1);
	//strcpy(qry_values[2], "04-Mar-2021 00:00"  );
	strcpy(qry_values[2], todate  );

	if(QRY_find("ERCDMLReleased", &queryTag));
	printf("\nAfter ERCDMLReleased : QRY_find \n");fflush(stdout);
	if (queryTag)
	{
		printf("\nFound Query ERCDMLReleased  \n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query ERCDMLReleased");fflush(stdout);
		goto CLEANUP;
	}

	TC_write_syslog("\n NEW SYSLOG  3 \n");

	if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ERCDMLTags));

    printf("\t resultCount :%d:\n", resultCount);fflush(stdout);
	printf("\n VC SVR fromdate: [%s] , todate: [%s]",fromdate,todate);fflush(stdout);

	TC_write_syslog("\n NEW SYSLOG  4 \n");

	if( resultCount > 0)
	{
		for (i=0;i<= resultCount;i++ )
		{
			ERCDMLTag = ERCDMLTags[i];

			if(TCTYPE_ask_object_type(ERCDMLTag,&objTypeTag));
			if(TCTYPE_ask_name(objTypeTag,type_name));
			//printf("\nErcDmlTag -> objTypeTag  %s\n", type_name);fflush(stdout);

			printf("\n Counting resultCount before :%d:\n", i);fflush(stdout);

			//OUTS("type_name",10,15,type_name); 

			if(strcmp(type_name,"ChangeRequestRevision")==0)
			{
				ITK_CALL(AOM_ask_value_string(ERCDMLTag,"item_id",&DmlId));
				tc_strdup(DmlId,&DmlIdDup);
				ITK_CALL(AOM_ask_value_string(ERCDMLTag,"t5_rlstype",&DmlRelType));
				tc_strdup(DmlRelType,&DmlRelTypeDup);
				ITK_CALL(AOM_UIF_ask_value(ERCDMLTag,"release_status_list",&DmlRelStat));
				tc_strdup(DmlRelStat,&DmlRelStatDup);

				printf("\nDmlIdDup [%s] DmlRelTypeDup [%s] DmlRelStatDup [%s]  \n",DmlIdDup,DmlRelTypeDup,DmlRelStatDup);fflush(stdout);
				
				TC_write_syslog("\n NEW SYSLOG  5 \n");

				if(tc_strcmp(DmlRelTypeDup,"Veh")==0 || tc_strcmp(DmlRelTypeDup,"CP")==0 || tc_strcmp(DmlRelTypeDup,"TODR")==0 || tc_strcmp(DmlRelTypeDup,"VCMDU")==0)
				{
					ITK_CALL(AOM_ask_value_string(ERCDMLTag,"current_name",&DmlDesc));
					tc_strdup(DmlDesc,&DmlDescDup);
					ITK_CALL(AOM_ask_value_string(ERCDMLTag,"t5_cDRstatus",&DmlDRstatus));
					tc_strdup(DmlDRstatus,&DmlDRstatusDup);
					ITK_CALL(AOM_ask_value_string(ERCDMLTag,"t5_PlntToPlnt",&DmlDRfromto));
					tc_strdup(DmlDRfromto,&DmlDRfromtoDup);
					ITK_CALL(AOM_ask_value_string(ERCDMLTag,"t5_reason",&Dmlreason));
					tc_strdup(Dmlreason,&DmlreasonDup);
					ITK_CALL(AOM_ask_value_string(ERCDMLTag,"object_name",&Dmlsynopsis));
					ITK_CALL(AOM_ask_value_string(ERCDMLTag,"requestor_user_id",&Dmlrequestor));

					ITK_CALL(AOM_ask_value_date(ERCDMLTag,"date_released",&DmlRelDate));
					ITK_CALL(DATE_date_to_string(DmlRelDate,"%d/%m/%Y",&DmlRelDateStr));
					
					TC_write_syslog("\n NEW SYSLOG  6 \n");	

					tc_strcpy(DmlRelTypeDup1,"");

					if (tc_strcmp(DmlRelTypeDup, "Veh") == 0)
					{
						tc_strcpy(DmlRelTypeDup1,"Vehicle release");
					}
					else if (tc_strcmp(DmlRelTypeDup, "CP") == 0)
					{
						tc_strcpy(DmlRelTypeDup1,"Colour Part release");
					}
					else if (tc_strcmp(DmlRelTypeDup, "TODR") == 0)
					{
						tc_strcpy(DmlRelTypeDup1,"Gate Maturation");
					}else if (tc_strcmp(DmlRelTypeDup, "VCMDU") == 0)
					{
						tc_strcpy(DmlRelTypeDup1,"VC/TPL Master data update");
					}else
					{
						tc_strcpy(DmlRelTypeDup1,DmlRelTypeDup);
					}
					
					tc_strcpy(DmlreasonDup1,"");

					if (tc_strcmp(DmlreasonDup, "CFL") == 0)		
					{
						tc_strcpy(DmlreasonDup1,"CHANGE IN FEATURE LIST");
					}
					else if (tc_strcmp(DmlreasonDup, "CMR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"COMMONIZATION/STANDARDIZATION/COMPLEXITY REDUCTION");
					}
					else if (tc_strcmp(DmlreasonDup, "CM") == 0)
					{
						tc_strcpy(DmlreasonDup1,"END CUSTOMER/FIELD COMPLAINTS &amp; SERVICE FEEDBACK/CCT");
					}else if (tc_strcmp(DmlreasonDup, "CR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"COST REDUCTION");
					}else if (tc_strcmp(DmlreasonDup, "DR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"DRAFTING ERROR CORRECTION/BOM-CAD QUALITY IMPROVEMENT");
					}else if (tc_strcmp(DmlreasonDup, "FM") == 0)
					{
						tc_strcpy(DmlreasonDup1,"TO FACILITATE MANUFACTURING");
					}else if (tc_strcmp(DmlreasonDup, "ICR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"INTEGRATED COST REDUCTION");
					}else if (tc_strcmp(DmlreasonDup, "MMDMR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"MODULE MASTER DATA MANAGEMENT REQUEST");
					}else if (tc_strcmp(DmlreasonDup, "NR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"NEW REQUIREMENTS (NEW VC, NEW AGGREGATE)");
					}else if (tc_strcmp(DmlreasonDup, "PQ") == 0)
					{
						tc_strcpy(DmlreasonDup1,"IMPROVEMENT IN JD POWER INITIAL QUALITY SCORE");
					}else if (tc_strcmp(DmlreasonDup, "QR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"QUALITY &amp; RELIABILITY IMPROVEMENT");
					}else if (tc_strcmp(DmlreasonDup, "RR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"REGULATORY REQUIREMENT");
					}else if (tc_strcmp(DmlreasonDup, "SR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"SAFETY REQUIREMENT");
					}else if (tc_strcmp(DmlreasonDup, "VAC") == 0)
					{
						tc_strcpy(DmlreasonDup1,"VC Attribute Change");
					}else if (tc_strcmp(DmlreasonDup, "WCR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"WARRANTY COST REDUCTION");
					}else if (tc_strcmp(DmlreasonDup, "WR") == 0)
					{
						tc_strcpy(DmlreasonDup1,"WEIGHT REDUCTION");
					}else
					{
						tc_strcpy(DmlreasonDup1,DmlreasonDup);
					}

					TC_write_syslog("\n NEW SYSLOG  7 \n");

					int tskcnt =0,t=0,p=0;
					tag_t *SetOfDmlTasksTag = NULLTAG;
					char *TaskId			= NULL;
					int partCnt	= 0;
					tag_t *SetOfPartTags	= NULLTAG;
					
					ITK_CALL(AOM_ask_value_tags(ERCDMLTag,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
					printf("\nDML Task Count : %d\n",tskcnt);fflush(stdout);
			
					if (tskcnt>0)
					{
						for(t=0;t<tskcnt;t++)
						{
							ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
							printf("\nDML Task [%s]",TaskId);fflush(stdout);

							if (tc_strstr(TaskId,"APL")!=NULL)
							{
								printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
								continue;
							}

							TC_write_syslog("\n NEW SYSLOG  8 \n");

							AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMHasSolutionItem",&partCnt,&SetOfPartTags);
							printf("\nNo of Design Rev=%d\n",partCnt);
							if (partCnt>0)
							{
								char *PartNum		= NULL;
								char *PartNumDup	= NULL;
								char *PartRev		= NULL;
								char *PartRevDup	= NULL;
								char *PartRelStat	= NULL;
								tag_t PartTag		= NULLTAG;
								char *part_type		= NULL;
								char *part_typeDup	= NULL;
								char *desc			= NULL;
								char *descDup		= NULL;
								char *partClrInd	= NULL;
								char *partClrIndDup = NULL;
								char *partsts		= NULL;
								char *partstsDup	= NULL;
								char *prjcode		= NULL;
								char *prjcodeDup	= NULL;
								char* PartColInd	= NULL;
								char* PartColIndDup = NULL;
								char *ColorIDPart	= NULL;
								char *ColorIDPartDup= NULL;
								char *UrnCode		= NULL;
								char *prepartsts	= NULL;
								char* PrerevDRstat	= NULL;

								tag_t Projobj		  = NULLTAG;
								tag_t	ObjTypProj	  = NULLTAG;
								char   type_Proj[TCTYPE_name_size_c+1];
								char* ProjVehclass    = NULL;
								char* ProjVehclassDup = NULL;
								char* Projplnname	  = NULL;
								char* ProjplnnameDup  = NULL;
								char* Projbuss		  = NULL;
								char* ProjbussDup	  = NULL;
								char* Projdesc		  = NULL;
								char* ProjdescDup	  = NULL;

								PrerevDRstat	=	(char	*)MEM_alloc(10);
								char* FirstrlzDR4	 = NULL;
								FirstrlzDR4	=	(char	*)MEM_alloc(10);

								char *VcAttvalem  =	NULL;
								VcAttvalem	=	(char	*)MEM_alloc(100);
								char *VcAttvaleso =	NULL;
								VcAttvaleso	=	(char	*)MEM_alloc(100);
								char *VcAttvalprl =	NULL;
								VcAttvalprl	=	(char	*)MEM_alloc(100);
								char *VcAttvalpt =	NULL;
								VcAttvalpt	=	(char	*)MEM_alloc(100);

								TC_write_syslog("\n NEW SYSLOG  9 \n");

								//displaying_objects();
								for(p=0;p<partCnt;p++)
								{
									PartTag=SetOfPartTags[p];

									printf("\n Counting resultCount after :%d:\n", i);fflush(stdout);
									printf("\n Counting Design Rev=%d\n",p);

									printf("\n Part Class [%s]",type_name); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"object_desc",&desc));
									tc_strdup(desc,&descDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&partClrInd));
									tc_strdup(partClrInd,&partClrIndDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartStatus",&partsts));
									tc_strdup(partsts,&partstsDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ProjectCode",&prjcode));
									tc_strdup(prjcode,&prjcodeDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
									tc_strdup(part_type,&part_typeDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&PartColInd));
									tc_strdup(PartColInd,&PartColIndDup);


									printf("\n PartNumDup :%s descDup :%s PartRevDup :%s partClrIndDup :%s partstsDup :%s prjcodeDup :%s part_typeDup :%s PartColIndDup :%s",PartNumDup,descDup,PartRevDup,partClrIndDup,partstsDup,prjcodeDup,part_typeDup,PartColIndDup);	fflush(stdout);
									 
									TC_write_syslog("\n NEW SYSLOG  10 \n");

									if ((tc_strcmp(PartNumDup,"54456224AIJR")==0) || (tc_strcmp(PartNumDup,"54426024RZV")==0) ) 
									{
										continue;
									}

									ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));

									if(tc_strstr(PartRelStat,"ERC Released")==NULL)
									{
										printf("\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
										continue;
									}
									else
									{
										printf("\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
									}
	
									TC_write_syslog("\n NEW SYSLOG  11 \n");

									if((tc_strcmp(part_typeDup,"V")==0) || (tc_strcmp(part_typeDup,"VC")==0) || (tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0))
									{
										//Previous Revision 	
										int revi = 0, revCnt = 0, preOffDR4 = 0, preOffDRstat = 0, ChkpreRev= 0;
										tag_t *allRevTag	 = NULLTAG;
										char* CurRev		 = NULL;
										char* preRevSeq		 = NULL;
										char* preRev		 = NULL;
										char* PreprtRelStat  = NULL;

										CurRev = strtok(PartRevDup,";");

										printf("\n TSSS Current Revision is %s",CurRev);fflush(stdout);

										TC_write_syslog("\n NEW SYSLOG  12 \n");

										if (tc_strcmp(CurRev,"NR")==0)
										{
											tc_strcpy(PrerevDRstat,"-");

											if (tc_strcmp(partstsDup,"DR4")==0)
											{
												tc_strcpy(FirstrlzDR4,"NR");
											}else{
												tc_strcpy(FirstrlzDR4,"-");
											}

											printf("\n Previous revision not present, Current Revision is %s",CurRev);fflush(stdout);
										}
										else
										{
											TC_write_syslog("\n NEW SYSLOG  13 \n");

											ITK_CALL(AOM_ask_value_tags(PartTag,"revision_list",&revCnt,&allRevTag));
											//ITK_CALL(ITEM_list_all_revs(PartTag, &revCnt, &allRevTag));
											printf("\nTotal Revision Found : %d", revCnt);fflush(stdout);

											if(revCnt > 0)
											{
												for(revi = revCnt-1; revi >= 0 ; revi--)
												{	
													ITK_CALL(AOM_UIF_ask_value(allRevTag[revi],"item_revision_id",&preRevSeq));
													preRev = strtok(preRevSeq,";");
													printf("\n Current Rev %s Rrevious Rev: %s",CurRev,preRev);fflush(stdout);

													TC_write_syslog("\n NEW SYSLOG  14 \n");

													if (tc_strcmp(CurRev,preRev)==0)
													{
														ChkpreRev = 1;
													}

													if((tc_strcmp(CurRev,preRev)!=0) && (ChkpreRev == 1))
													{
														ITK_CALL(AOM_UIF_ask_value(allRevTag[revi],"t5_PartStatus",&prepartsts));
														ITK_CALL(AOM_UIF_ask_value(allRevTag[revi],"release_status_list",&PreprtRelStat));

														if(tc_strstr(PreprtRelStat,"ERC Released")!=NULL)
														{
															if (preOffDRstat == 0)
															{
																tc_strdup(prepartsts,&PrerevDRstat);
																preOffDRstat = 1;
															}

															if (tc_strcmp(prepartsts,"DR4")==0)
															{
																tc_strcpy(FirstrlzDR4,preRev);
																preOffDR4 = 1;
																break;
															}
														}
														else
														{
															printf("\n Previous Rev %s is NOT ERC Released ",preRev);fflush(stdout);
														}
													}
													else
													{
														printf("\nPre Official Revision not found...Current Rev %s Latest Rev: %s",CurRev,preRev);fflush(stdout);
													}
												}
											}

											if (preOffDR4 == 0)
											{
												tc_strcpy(FirstrlzDR4,"-");
											}
											if (preOffDRstat == 0)
											{
												tc_strcpy(PrerevDRstat,"-");
											}
										}

										TC_write_syslog("\n NEW SYSLOG  15 \n");

										printf("\n...preOffDR4 %d preOffDRstat: %d",preOffDR4,preOffDRstat);fflush(stdout);
										printf("\n...PrerevDRstat %s FirstrlzDR4: %s",PrerevDRstat,FirstrlzDR4);fflush(stdout);

										ITK_CALL(ITEM_find_item(prjcodeDup,&Projobj));
										if(Projobj !=NULLTAG)
										{
											if(TCTYPE_ask_object_type(Projobj,&ObjTypProj));
											if(TCTYPE_ask_name(ObjTypProj,type_Proj));
											//printf("\n type_Proj :: %s\n", type_Proj);fflush(stdout);
											if (strcmp(type_Proj,"T5_Project")==0)
											{
												if(AOM_ask_value_string(Projobj,"t5_VehicleClass",&ProjVehclass)!=ITK_ok)PrintErrorStack();
												tc_strdup(ProjVehclass,&ProjVehclassDup);
												//printf("\n t5_VehicleClass :[%s]\n",ProjVehclassDup);   fflush(stdout);

												if(AOM_ask_value_string(Projobj,"t5_ParentProductLine",&Projplnname)!=ITK_ok)PrintErrorStack();
												tc_strdup(Projplnname,&ProjplnnameDup);
												//printf("\n t5_ParentProductLine :[%s]\n",ProjplnnameDup);   fflush(stdout);

												if(AOM_ask_value_string(Projobj,"t5_BussUnitType",&Projbuss)!=ITK_ok)PrintErrorStack();
												tc_strdup(Projbuss,&ProjbussDup);
												//printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);
											
												if(AOM_ask_value_string(Projobj,"t5_ProjectDesc",&Projdesc)!=ITK_ok)PrintErrorStack();
												tc_strdup(Projdesc,&ProjdescDup);
												//printf("\n t5_ProjectDesc :[%s]\n",ProjdescDup);   fflush(stdout);
											
											}
										}

										TC_write_syslog("\n NEW SYSLOG  16 \n");

										if (tc_strcmp(PartColIndDup,"C")==0)
										{
											printf("\n Colour "); fflush(stdout);
											tag_t NonCol_Prt_rel_type = NULLTAG;
											int NonColcount			  =  0;
											tag_t *NonColPart_tag	  = NULL;
											tag_t NonColPartObjm      = NULLTAG;
											char* NonColPartNo		  = NULL;
											char* NonColPartRev		  = NULL;
											char* NonColPartPrtType   = NULL;
											tag_t VPartTag			  = NULLTAG;
											if(GRM_find_relation_type("TC_Is_Represented_By",&NonCol_Prt_rel_type)!=ITK_ok)PrintErrorStack();
											
											TC_write_syslog("\n NEW SYSLOG  17 \n");

											if (NonCol_Prt_rel_type!=NULLTAG)
											{
												if(GRM_list_secondary_objects_only(PartTag,NonCol_Prt_rel_type,&NonColcount,&NonColPart_tag)!=ITK_ok)PrintErrorStack();
												printf("\nColour of NonColcount: %d",NonColcount);	fflush(stdout);

												NonColPartObjm=NonColPart_tag[0];
												AOM_ask_value_string(NonColPartObjm,"item_id",&NonColPartNo);
												AOM_ask_value_string(NonColPartObjm,"item_revision_id",&NonColPartRev);
												AOM_ask_value_string(NonColPartObjm,"t5_PartType",&NonColPartPrtType);

												printf("\nNon Colour part Number:%s ",NonColPartNo);fflush(stdout);
												printf("\nNon Colour part rev:%s ",NonColPartRev);fflush(stdout);
												printf("\nNon Colour part Type:%s ",NonColPartPrtType);fflush(stdout);
												printf("\nColour of NON-Colour Part Lenght: %d",strlen(NonColPartNo));fflush(stdout);

												tc_strdup(NonColPartNo,&UrnCode);
															
												tag_t   window,rule,top_line = NULLTAG;
												int VpartCount		= 0;
												tag_t  *children	= NULLTAG;
												tag_t   VchildPart	= NULLTAG;
												int iChildItemTag	= 0;
												char *VPrtNum		= NULL;
												char *VPrtNumRevId	= NULL;
												char *VPrtType		= NULL;

												TC_write_syslog("\n NEW SYSLOG  18 \n");

												if ((tc_strcmp(NonColPartPrtType,"VC")==0) && (strcmp(report,"VC")==0) )
												{
													ITKCALL(BOM_create_window (&window));
													if(CFM_find( "ERC release and above", &rule )!=ITK_ok)PrintErrorStack();
													ITKCALL(BOM_set_window_config_rule(window,rule));
													BOM_set_window_top_line(window, null_tag,NonColPartObjm ,null_tag, &top_line);
													ITKCALL(BOM_line_ask_child_lines (top_line, &VpartCount, &children));
													printf("\n VC Colour No of child objects are n : %d",VpartCount);fflush(stdout);
													if(VpartCount>0)
													{
														BOM_line_unpack (children[0]);
														BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
														BOM_line_ask_attribute_tag(children[0], iChildItemTag, &VPartTag);
														if(VPartTag!=NULLTAG)
														{
															AOM_ask_value_string(VPartTag,"item_id",&VPrtNum);
															AOM_ask_value_string(VPartTag,"item_revision_id",&VPrtNumRevId);
															ITK_CALL(AOM_ask_value_string(VPartTag,"t5_PartType",&VPrtType));
															
															printf("\nVC Colour VPrtNum : %s\n",VPrtNum);fflush(stdout);
															printf("\nVC Colour VPrtNumRevId : %s\n",VPrtNumRevId);fflush(stdout);
															printf("\nVC Colour VPrtType : %s\n",VPrtType);fflush(stdout);
														}

														TC_write_syslog("\n NEW SYSLOG  19 \n");

														ITK_CALL(AOM_ask_value_tags(VPartTag,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
														if(TechSpecCount>0)
														{
															TechSPecObj=TechSPecObjSet[0];
														
															bufferedXmlStrOut	= NULL;
															buff_cnt			= 0;
															char *ModPartAct	= NULL;
															ModPartAct	=	(char	*)MEM_alloc(300);
															tc_strcpy(ModPartAct,VPrtNum);
															tc_strcat(ModPartAct,"/");
															tc_strcat(ModPartAct,VPrtNumRevId);

															printf("\nVC Colour ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
															setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
															tm_ebom_mbom_rpt(VPartTag,&bufferedXmlStrOut,&buff_cnt);
															printf("\nVC Colour Calling getClassifiedValue"); fflush(stdout);
															printf("\nVC Colour Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
															ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
															printf("\nVC Colour After calling getClassifiedValue"); fflush(stdout);
															int j=0;
															for(j=0 ;j<vcattr;j++ )
															{
																//printf("\nVC Colour value of J:[%d] ",j);fflush(stdout);fflush(stdout);
																//printf("\nVC Colour attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
																//printf("\nVC Colour attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
																//printf("\nVC Colour attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);

																//Tech T5_Spec attribute 
																if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"[VC]EMMISSION_NORMS(EMMISSION_NORMS)")==0)
																{
																	printf("\nVC Colour value of J VcAttvalem :[%d] ",j);fflush(stdout);fflush(stdout);
																	printf("\nVC Colour attribute id VcAttvalem:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
															
																	tc_strcpy(VcAttvalem,VCAttrDetailsList[j].VCAttrNameValue);
																}

																TC_write_syslog("\n NEW SYSLOG  20 \n");

																if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"Applicable for ESO")==0)
																{
																	printf("\nVC Colour value of J VcAttvaleso :[%d] ",j);fflush(stdout);fflush(stdout);
																	printf("\nVC Colour attribute id VcAttvaleso:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
																	
																	tc_strcpy(VcAttvaleso,VCAttrDetailsList[j].VCAttrNameValue);
																}

																if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PRODUCT LINE")==0)
																{
																	printf("\nVC Colour value of J VcAttvalprl :[%d] ",j);fflush(stdout);fflush(stdout);
																	printf("\nVC Colour attribute id VcAttvalprl :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
																	
																	tc_strcpy(VcAttvalprl,VCAttrDetailsList[j].VCAttrNameValue);
																}

																if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PLATFORM")==0)
																{
																	printf("\nVC Colour value of J VcAttvalpt :[%d] ",j);fflush(stdout);fflush(stdout);
																	printf("\nVC Colour attribute id VcAttvalpt :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
																	
																	tc_strcpy(VcAttvalpt,VCAttrDetailsList[j].VCAttrNameValue);
																}
															}
															printf("\n VC Colour UrnCode is %s",UrnCode);fflush(stdout);	
														}
														else
														{
															printf("\nVC Colour Tech Spec is not attch with vehicle:%s",VPrtNum);fflush(stdout);
														}
													}
													else
													{
														printf("\n VC Colour %s has vehicle",NonColPartNo);fflush(stdout);
													}
												}
												else if (((tc_strcmp(NonColPartPrtType,"CCVC")==0) || (tc_strcmp(NonColPartPrtType,"CVC")==0)) && (strcmp(report,"VC")==0))
												{
													snapshotObjSet = NULLTAG;
													snapshotCount  = 0;
													
													TC_write_syslog("\n NEW SYSLOG  21 \n");

													ITK_CALL(AOM_ask_value_tags(NonColPartObjm,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet));
													
													printf("\nCCVC Colour snapshotCount:[%d] ******",snapshotCount); fflush(stdout);
													if(snapshotCount>0)
													{
														snapshotObj = NULLTAG;
														snapshotObj = snapshotObjSet[0];
														snapshotObjTypeTag = NULLTAG;

														if(TCTYPE_ask_object_type(snapshotObj,&snapshotObjTypeTag));
														if(TCTYPE_ask_name(snapshotObjTypeTag,snapshotObjtype_name));
														printf("\n\t CCVC Colour snapshotObjtype_name := %s", snapshotObjtype_name);fflush(stdout);
													}

													TC_write_syslog("\n NEW SYSLOG  22 \n");

													tag_t item_rev_tags	    = NULLTAG;
													snapshot_itemid			= NULL;
													SSTopLineRev			= NULL;
													bufferedXmlStrOut		= NULL;
													buff_cnt = 0;
													char *ModPartAct		= NULL;

													ModPartAct	=	(char	*)MEM_alloc(300);
													tc_strcpy(ModPartAct,NonColPartNo);
													tc_strcat(ModPartAct,"/");
													tc_strcat(ModPartAct,NonColPartRev);

													printf("\nCCVC Colour ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
													setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
													if(snapshotCount>0)
													{
														if (tc_strcmp(snapshotObjtype_name,"Snapshot")==0)
														{
															ITK_CALL(AOM_ask_value_string(snapshotObj,"object_name",&snapshot_itemid));
															printf("\n\t CCVC Colour snapshot_itemid :%s",snapshot_itemid);	fflush(stdout);
												
															TC_write_syslog("\n NEW SYSLOG  23 \n");

															ITKCALL(AOM_UIF_ask_value(snapshotObj,"topLine",&SSTopLineRev));
															printf("\n CCVC Colour Snapshot Top Line : %s",SSTopLineRev);fflush(stdout);

															ITKCALL(AOM_ask_value_tag(snapshotObj,"topLine",&item_rev_tags));
															//printf("\nSnapshot Top Line : %s",item_rev_tags);fflush(stdout);
															tm_ebom_snapshot(snapshot_itemid,&bufferedXmlStrOut,&buff_cnt);	
														}
													}
													printf("\nCCVC Colour Calling getClassifiedValue"); fflush(stdout);
													printf("\nCCVC Colour Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
													ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
													printf("\nCCVC Colour After calling getClassifiedValue"); fflush(stdout);
													int j=0;
													for(j=0 ;j<vcattr;j++ )
													{
														//printf("\nCCVC Colour value of J:[%d] ",j);fflush(stdout);fflush(stdout);
														//printf("\nCCVC Colour attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
														//printf("\nCCVC Colour attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
														//printf("\nCCVC Colour attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
														
														TC_write_syslog("\n NEW SYSLOG  24 \n");

														//Tech T5_Spec attribute 
														if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"[VC]EMMISSION_NORMS(EMMISSION_NORMS)")==0)
														{
															printf("\nCCVC Colour value of J VcAttvalem :[%d] ",j);fflush(stdout);fflush(stdout);
															printf("\nCCVC Colour attribute id VcAttvalem:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);

															tc_strcpy(VcAttvalem,VCAttrDetailsList[j].VCAttrNameValue);
														}

														if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"Applicable for ESO")==0)
														{
															printf("\nCCVC Colour value of J VcAttvaleso :[%d] ",j);fflush(stdout);fflush(stdout);
															printf("\nCCVC Colour attribute id VcAttvaleso:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);

															tc_strcpy(VcAttvaleso,VCAttrDetailsList[j].VCAttrNameValue);
														}

														if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PRODUCT LINE")==0)
														{
															printf("\nCCVC Colour value of J VcAttvalprl :[%d] ",j);fflush(stdout);fflush(stdout);
															printf("\nCCVC Colour attribute id VcAttvalprl :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
		
															tc_strcpy(VcAttvalprl,VCAttrDetailsList[j].VCAttrNameValue);
														}

														if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PLATFORM")==0)
														{
															printf("\nCCVC Colour value of J VcAttvalpt :[%d] ",j);fflush(stdout);fflush(stdout);
															printf("\nCCVC Colour attribute id VcAttvalpt :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
		
															tc_strcpy(VcAttvalpt,VCAttrDetailsList[j].VCAttrNameValue);
														}
													}

												}
												else if (((tc_strcmp(NonColPartPrtType,"V")==0) && strlen(NonColPartNo)==9) && (strcmp(report,"V")==0))
												{

													ITK_CALL(AOM_ask_value_tags(NonColPartObjm,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
														
													TC_write_syslog("\n NEW SYSLOG  25 \n");

													printf("\n\tV Colour Tech spec size %d",TechSpecCount);	fflush(stdout);
													if(TechSpecCount)
													{
														TechSPecObj=TechSPecObjSet[0];
													
														bufferedXmlStrOut=NULL;
														buff_cnt=0;
														char *ModPartAct  =	NULL;
														ModPartAct	=	(char	*)MEM_alloc(300);
														tc_strcpy(ModPartAct,NonColPartNo);
														tc_strcat(ModPartAct,"/");
														tc_strcat(ModPartAct,PartRevDup);

														printf("\nV Colour ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
														setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
														tm_ebom_mbom_rpt(NonColPartObjm,&bufferedXmlStrOut,&buff_cnt);
														
														TC_write_syslog("\n NEW SYSLOG  26 \n");

														printf("\nV  Colour Calling getClassifiedValue"); fflush(stdout);
														printf("\nV  Colour Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
														ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
														printf("\nV  Colour After calling getClassifiedValue"); fflush(stdout);
														int j = 0;
														
														for(j=0 ;j<vcattr;j++ )
														{
															//printf("\nV  Colour value of J:[%d] ",j);fflush(stdout);fflush(stdout);
															//printf("\nV  Colour attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
															//printf("\nV  Colour attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
															//printf("\nV  Colour attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
														
															//Tech T5_Spec attribute 
															if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"[VC]EMMISSION_NORMS(EMMISSION_NORMS)")==0)
															{
																printf("\nV Colour value of J VcAttvalem :[%d] ",j);fflush(stdout);fflush(stdout);
																printf("\nV Colour attribute id VcAttvalem:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
																
																tc_strcpy(VcAttvalem,VCAttrDetailsList[j].VCAttrNameValue);
															}

															if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"Applicable for ESO")==0)
															{
																printf("\nV Colour value of J VcAttvaleso :[%d] ",j);fflush(stdout);fflush(stdout);
																printf("\nV Colour attribute id VcAttvaleso:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
																
																tc_strcpy(VcAttvaleso,VCAttrDetailsList[j].VCAttrNameValue);
															}

															TC_write_syslog("\n NEW SYSLOG  27 \n");

															if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PRODUCT LINE")==0)
															{
																printf("\nV Colour value of J VcAttvalprl :[%d] ",j);fflush(stdout);fflush(stdout);
																printf("\nV Colour attribute id VcAttvalprl :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
		
																tc_strcpy(VcAttvalprl,VCAttrDetailsList[j].VCAttrNameValue);
															}

															if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PLATFORM")==0)
															{
																printf("\nV Colour value of J VcAttvalpt :[%d] ",j);fflush(stdout);fflush(stdout);
																printf("\nV Colour attribute id VcAttvalpt :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
				
																tc_strcpy(VcAttvalpt,VCAttrDetailsList[j].VCAttrNameValue);
															}
														}
													}
													else
													{
														printf("\nV  Colour vehicle:%s is not attch with any Tech Spec ",PartNumDup);fflush(stdout);
													}
													
													printf("\nV Colour %s of Non-Colour Vehicle No. %s",PartNumDup,NonColPartNo);fflush(stdout);
												}
												else
												{
													printf("\nColour of Non-Colour In Valide Part type : %s or Part : %s",NonColPartPrtType,NonColPartNo);fflush(stdout);
												}
											}
										}
										else
										{
											printf("\n NON Colour "); fflush(stdout);
											printf("\nNON Colour Part Lenght: %d",strlen(PartNumDup));fflush(stdout);

											TC_write_syslog("\n NEW SYSLOG  28 \n");

											if (((tc_strcmp(part_typeDup,"VC")==0)) && (strcmp(report,"VC")==0))
											{
												tc_strdup(PartNumDup,&UrnCode);
												tag_t window,rule,top_line = NULLTAG;
												int VpartCount,p1,k = 0;
												tag_t *children			= NULLTAG;
												tag_t VchildPart		= NULLTAG;
												int iChildItemTag		= 0;
												tag_t t_ChildItemRev;
												char * VPrtNum			= NULL;
												char * VPrtNumRevId		= NULL;
												tag_t VPartMaster		= NULLTAG;
												tag_t VPartTag			= NULLTAG;

												ITKCALL(BOM_create_window (&window));
												if(CFM_find( "ERC release and above", &rule )!=ITK_ok)PrintErrorStack();
												ITKCALL(BOM_set_window_config_rule(window,rule));
												BOM_set_window_top_line(window, null_tag,PartTag ,null_tag, &top_line);
												ITKCALL(BOM_line_ask_child_lines (top_line, &VpartCount, &children));
												printf("\nVC NON Colour No of child objects are n : %d\n",VpartCount);fflush(stdout);
												
												TC_write_syslog("\n NEW SYSLOG  29 \n");

												if(VpartCount>0)
												{
													for (k = 0; k < VpartCount; k++)
													{
														BOM_line_unpack (children[k]);
														BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
														BOM_line_ask_attribute_tag(children[k], iChildItemTag, &VPartTag);
														if(VPartTag!=NULLTAG)
														{
															AOM_ask_value_string(VPartTag,"item_id",&VPrtNum);
															AOM_ask_value_string(VPartTag,"item_revision_id",&VPrtNumRevId);
															printf("\nVC NON Colour VPrtNum : %s\n",VPrtNum);fflush(stdout);
															printf("\nVC NON Colour VPrtNumRevId : %s\n",VPrtNumRevId);fflush(stdout);
														}
													}
													ITK_CALL(AOM_ask_value_tags(VPartTag,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
													if(TechSpecCount>0)
													{
														TechSPecObj=TechSPecObjSet[0];
													
														bufferedXmlStrOut=NULL;
														buff_cnt=0;
														char *ModPartAct  =	NULL;
														ModPartAct	=	(char	*)MEM_alloc(300);
														tc_strcpy(ModPartAct,VPrtNum);
														tc_strcat(ModPartAct,"/");
														tc_strcat(ModPartAct,VPrtNumRevId);

														printf("\nVC NON Colour ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
														setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
														tm_ebom_mbom_rpt(VPartTag,&bufferedXmlStrOut,&buff_cnt);
														
														printf("\nVC NON Colour  Calling getClassifiedValue"); fflush(stdout);
														printf("\nVC NON Colour  Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
														ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
														printf("\nVC NON Colour  After calling getClassifiedValue"); fflush(stdout);
														int j=0;
														for(j=0 ;j<vcattr;j++ )
														{
															//printf("\nVC NON Colour  value of J:[%d] ",j);fflush(stdout);fflush(stdout);
															//printf("\nVC NON Colour  attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
															//printf("\nVC NON Colour  attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
															//printf("\nVC NON Colour  attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
														
															//Tech T5_Spec attribute 
															if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"[VC]EMMISSION_NORMS(EMMISSION_NORMS)")==0)
															{
																printf("\nVC NON Colour value of J VcAttvalem :[%d] ",j);fflush(stdout);fflush(stdout);
																printf("\nVC NON Colour attribute id VcAttvalem:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
																
																tc_strcpy(VcAttvalem,VCAttrDetailsList[j].VCAttrNameValue);
															}

															if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"Applicable for ESO")==0)
															{
																printf("\nVC NON Colour value of J VcAttvaleso :[%d] ",j);fflush(stdout);fflush(stdout);
																printf("\nVC NON Colour attribute id VcAttvaleso:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
																
																tc_strcpy(VcAttvaleso,VCAttrDetailsList[j].VCAttrNameValue);
															}

															if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PRODUCT LINE")==0)
															{
																printf("\nVC NON Colour value of J VcAttvalprl :[%d] ",j);fflush(stdout);fflush(stdout);
																printf("\nVC NON Colour attribute id VcAttvalprl :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
				
																tc_strcpy(VcAttvalprl,VCAttrDetailsList[j].VCAttrNameValue);
															}

															TC_write_syslog("\n NEW SYSLOG  30 \n");

															if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PLATFORM")==0)
															{
																printf("\nVC NON Colour value of J VcAttvalpt :[%d] ",j);fflush(stdout);fflush(stdout);
																printf("\nVC NON Colour attribute id VcAttvalpt :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
				
																tc_strcpy(VcAttvalpt,VCAttrDetailsList[j].VCAttrNameValue);
															}
														}
	
														printf("\n VC NON Colour  UrnCode is %s",UrnCode);fflush(stdout);
													}
													else
													{
														printf("\nVC NON Colour  Tech Spec is not attached with vehicle:%s",VPrtNum);fflush(stdout);
													}
												}
												else
												{
													printf("\nVC NON Colour VC %s has NO vehicle",PartNumDup);fflush(stdout);
												}
											}
											else if (((tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0)) && (strcmp(report,"VC")==0))
											{
												tc_strdup(PartNumDup,&UrnCode);
												char *CCVCPrtNum		= NULL;
												char *CCVCPrtNumRevId	= NULL;

												TC_write_syslog("\n NEW SYSLOG  31 \n");

												AOM_ask_value_string(PartTag,"item_id",&CCVCPrtNum);
												AOM_ask_value_string(PartTag,"item_revision_id",&CCVCPrtNumRevId);
												printf("\n\n\t\tCCVC NON Colour CCVCPrtNum : %s\n",CCVCPrtNum);fflush(stdout);
												printf("\n\n\t\tCCVC NON Colour CCVCPrtNumRevId : %s\n",CCVCPrtNumRevId);fflush(stdout);
												
												snapshotCount = 0;
												snapshotObjSet = NULLTAG;

												ITK_CALL(AOM_ask_value_tags(PartTag,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet));
												
												printf("\n CCVC NON Colour snapshotCount:[%d] ******",snapshotCount); fflush(stdout);
												if(snapshotCount>0)
												{
													snapshotObj = NULLTAG;
													snapshotObj = snapshotObjSet[0];
													snapshotObjTypeTag = NULLTAG;

													if(TCTYPE_ask_object_type(snapshotObj,&snapshotObjTypeTag));
													if(TCTYPE_ask_name(snapshotObjTypeTag,snapshotObjtype_name));
													printf("\n\tCCVC NON Colour snapshotObjtype_name := %s", snapshotObjtype_name);fflush(stdout);
												}

												tag_t item_rev_tags	= NULLTAG;
												snapshot_itemid     = NULL;
												SSTopLineRev		= NULL;
												bufferedXmlStrOut	= NULL;
												buff_cnt			= 0;
												char *ModPartAct	= NULL;

												TC_write_syslog("\n NEW SYSLOG  32 \n");

												ModPartAct	=	(char	*)MEM_alloc(300);
												tc_strcpy(ModPartAct,CCVCPrtNum);
												tc_strcat(ModPartAct,"/");
												tc_strcat(ModPartAct,CCVCPrtNumRevId);

												printf("\nCCVC NON Colour ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
												setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
												if(snapshotCount>0)
												{
													if (tc_strcmp(snapshotObjtype_name,"Snapshot")==0)
													{
														ITK_CALL(AOM_ask_value_string(snapshotObj,"object_name",&snapshot_itemid)); 
														printf("\n\tCCVC NON Colour snapshot_itemid :%s",snapshot_itemid);	fflush(stdout);
											
														ITKCALL(AOM_UIF_ask_value(snapshotObj,"topLine",&SSTopLineRev));
														printf("\nCCVC NON Colour Snapshot Top Line : %s",SSTopLineRev);fflush(stdout);

														ITKCALL(AOM_ask_value_tag(snapshotObj,"topLine",&item_rev_tags));
														//printf("\nSnapshot Top Line : %s",item_rev_tags);fflush(stdout);
														tm_ebom_snapshot(snapshot_itemid,&bufferedXmlStrOut,&buff_cnt);	
													}
												}

												TC_write_syslog("\n NEW SYSLOG  33 \n");

												printf("\nCCVC NON Colour Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
												printf("\nCCVC NON Colour Calling getClassifiedValue"); fflush(stdout);
												ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
												printf("\nCCVC NON Colour After calling getClassifiedValue"); fflush(stdout);
												int j=0;
												for(j=0 ;j<vcattr;j++ )
												{
													//printf("\nCCVC NON Colour value of J:[%d] ",j);fflush(stdout);fflush(stdout);
													//printf("\nCCVC NON Colour attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
													//printf("\nCCVC NON Colour attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
													//printf("\nCCVC NON Colour attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
												
													//Tech T5_Spec attribute 
													if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"[VC]EMMISSION_NORMS(EMMISSION_NORMS)")==0)
													{
														printf("\nCCVC NON Colour value of J VcAttvalem :[%d] ",j);fflush(stdout);fflush(stdout);
														printf("\nCCVC NON Colour attribute id VcAttvalem:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
														
														tc_strcpy(VcAttvalem,VCAttrDetailsList[j].VCAttrNameValue);
													}

													if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"Applicable for ESO")==0)
													{
														printf("\nCCVC NON Colour value of J VcAttvaleso :[%d] ",j);fflush(stdout);fflush(stdout);
														printf("\nCCVC NON Colour attribute id VcAttvaleso:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
														
														tc_strcpy(VcAttvaleso,VCAttrDetailsList[j].VCAttrNameValue);
													}

													TC_write_syslog("\n NEW SYSLOG  34 \n");

													if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PRODUCT LINE")==0)
													{
														printf("\nCCVC NON Colour value of J VcAttvalprl :[%d] ",j);fflush(stdout);fflush(stdout);
														printf("\nCCVC NON Colour attribute id VcAttvalprl :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);

														tc_strcpy(VcAttvalprl,VCAttrDetailsList[j].VCAttrNameValue);
													}

													if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PLATFORM")==0)
													{
														printf("\nCCVC NON Colour value of J VcAttvalpt :[%d] ",j);fflush(stdout);fflush(stdout);
														printf("\nCCVC NON Colour attribute id VcAttvalpt :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
														
														tc_strcpy(VcAttvalpt,VCAttrDetailsList[j].VCAttrNameValue);
													}
												}
											}
											else if ((tc_strcmp(part_typeDup,"V")==0 && strlen(PartNumDup)==9) && (strcmp(report,"V")==0))
											{
												ITK_CALL(AOM_ask_value_tags(PartTag,"T5_VCSpec",&TechSpecCount,&TechSPecObjSet));
												printf("\n\tV NON Colour Tech spec size %d",TechSpecCount);	fflush(stdout);
												if(TechSpecCount)
												{
													TechSPecObj=TechSPecObjSet[0];
												
													bufferedXmlStrOut=NULL;
													buff_cnt=0;
													char *ModPartAct  =	NULL;
													ModPartAct	=	(char	*)MEM_alloc(300);
													tc_strcpy(ModPartAct,PartNumDup);
													tc_strcat(ModPartAct,"/");
													tc_strcat(ModPartAct,PartRevDup);

													TC_write_syslog("\n NEW SYSLOG  35 \n");

													printf("\nV NON Colour ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
													setAddStr(&buff_cnt,&bufferedXmlStrOut,ModPartAct);
													tm_ebom_mbom_rpt(PartTag,&bufferedXmlStrOut,&buff_cnt);
													
													printf("\nV NON Colour Calling getClassifiedValue"); fflush(stdout);
													printf("\nV NON Colour Total Number of Model Found: %d ",buff_cnt); fflush(stdout);
													ITK_CALL(getClassifiedValue(&bufferedXmlStrOut,&buff_cnt,&vcattr,VCAttrDetailsList));
													printf("\nV NON Colour After calling getClassifiedValue"); fflush(stdout);
													int j=0;
													for(j=0 ;j<vcattr;j++ )
													{
														//printf("\nV NON Colour value of J:[%d] ",j);fflush(stdout);fflush(stdout);
														//printf("\nV NON Colour attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
														//printf("\nV NON Colour attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
														//printf("\nV NON Colour attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
													
														//Tech T5_Spec attribute 
														if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"[VC]EMMISSION_NORMS(EMMISSION_NORMS)")==0)
														{
															printf("\nV NON Colour value of J VcAttvalem :[%d] ",j);fflush(stdout);fflush(stdout);
															printf("\nV NON Colour attribute id VcAttvalem:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
			
															tc_strcpy(VcAttvalem,VCAttrDetailsList[j].VCAttrNameValue);
														}

														if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"Applicable for ESO")==0)
														{
															printf("\nV NON Colour value of J VcAttvaleso :[%d] ",j);fflush(stdout);fflush(stdout);
															printf("\nV NON Colour attribute id VcAttvaleso:[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
				
															tc_strcpy(VcAttvaleso,VCAttrDetailsList[j].VCAttrNameValue);
														}

														TC_write_syslog("\n NEW SYSLOG  36 \n");

														if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PRODUCT LINE")==0)
														{
															printf("\nV NON Colour value of J VcAttvalprl :[%d] ",j);fflush(stdout);fflush(stdout);
															printf("\nV NON Colour attribute id VcAttvalprl :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
						
															tc_strcpy(VcAttvalprl,VCAttrDetailsList[j].VCAttrNameValue);
														}

														if (tc_strcmp(VCAttrDetailsList[j].VCAttrName,"PLATFORM")==0)
														{
															printf("\nV NON Colour value of J VcAttvalpt :[%d] ",j);fflush(stdout);fflush(stdout);
															printf("\nV NON Colour attribute id VcAttvalpt :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
							
															tc_strcpy(VcAttvalpt,VCAttrDetailsList[j].VCAttrNameValue);
														}
													
													}
												}
												else
												{
													printf("\nV NON Colour vehicle:%s is not attch with any Tech Spec ",PartNumDup);fflush(stdout);
												}
											}
											else
											{
												printf("\nNON Colour In Valide Part type : %s or Part : %s",part_typeDup,PartNumDup);fflush(stdout);
											}
										}

										TC_write_syslog("\n NEW SYSLOG  37 \n");

										STRNG_replace_str(descDup,","," ",&descDup);
										STRNG_replace_str(DmlreasonDup1,","," ",&DmlreasonDup1);
										STRNG_replace_str(Dmlsynopsis,","," ",&Dmlsynopsis);
										STRNG_replace_str(DmlRelStatDup,","," ",&DmlRelStatDup);

										printf("\n report- [%s] ",report); fflush(stdout);

										if((strcmp(report,"VC")==0) && ((tc_strcmp(part_typeDup,"VC")==0) || (tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0)))
										{
											printf("\n Report is  [%s] Wise ",report); fflush(stdout);

											TC_write_syslog("\n 38 \n");

											//VC,Description,Revision,Color Ind,DR/AR Status,Previous rev DR status,First time rlz with DR4,Emission norms,Applicable for ESO,PRODUCT LINE,PLATFORM	Release Date,Vehicle Class,Plant Name,Business Unit,Dml No,DML type,DML DR status	DML from to,DML reason code,DML synopsis,Project Code,Project desc,Life Cycle State,Owner,Requestor
											printf("\nPartNumDup [%s] descDup [%s] PartRevDup [%s] partClrIndDup [%s] partstsDup [%s] PrerevDRstat [%s] FirstrlzDR4 [%s] VcAttvalem [%s] VcAttvaleso [%s] VcAttvalprl [%s] VcAttvalpt  [%s] DmlRelDateStr [%s] ProjVehclassDup [%s] ProjplnnameDup [%s] ProjbussDup [%s] DmlIdDup [%s]  DmlRelTypeDup1 [%s] DmlDRstatusDup [%s] DmlDRfromtoDup [%s] DmlreasonDup1 [%s] Dmlsynopsis [%s] prjcodeDup [%s] ProjdescDup [%s] DmlRelStatDup [%s] Dmlrequestor [%s]\n",PartNumDup,descDup,PartRevDup,partClrIndDup,partstsDup,PrerevDRstat,FirstrlzDR4,VcAttvalem,VcAttvaleso,VcAttvalprl,VcAttvalpt,DmlRelDateStr,DmlIdDup,DmlRelTypeDup1,DmlDRstatusDup,DmlDRfromtoDup,DmlreasonDup1,Dmlsynopsis,ProjdescDup,prjcodeDup,DmlRelStatDup,Dmlrequestor);fflush(stdout);
											//fprintf(fsuccess,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,T5_LcsErcRlzd,%s\n",PartNumDup,descDup,PartRevDup,partClrIndDup,partstsDup,PrerevDRstat,FirstrlzDR4,VcAttvalem,VcAttvaleso,VcAttvalprl,VcAttvalpt,DmlRelDateStr,ProjVehclassDup,ProjplnnameDup,ProjbussDup,DmlIdDup,DmlRelTypeDup1,DmlDRstatusDup,DmlDRfromtoDup,DmlreasonDup1,Dmlsynopsis,prjcodeDup,ProjdescDup,DmlRelStatDup,Dmlrequestor);
											 			
											fprintf(fsuccess,"<logo>\n");

											fprintf(fsuccess,"<field key =\"VC\">");
											fprintf(fsuccess,"%s",PartNumDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Description\">");
											fprintf(fsuccess,"%s",descDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Revision\">");
											fprintf(fsuccess,"%s",PartRevDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Color Ind\">");
											fprintf(fsuccess,partClrIndDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DR/AR Status\">");
											fprintf(fsuccess,partstsDup);
											fprintf(fsuccess,"</field>\n");

											TC_write_syslog("\n NEW SYSLOG  39 \n");

											fprintf(fsuccess,"<field key =\"Previous rev DR status\">");
											fprintf(fsuccess,PrerevDRstat);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"First time rlz with DR4\">");
											fprintf(fsuccess,FirstrlzDR4);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Emission norms\">");
											fprintf(fsuccess,VcAttvalem);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Applicable for ESO\">");
											fprintf(fsuccess,VcAttvaleso);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"PRODUCT LINE\">");
											fprintf(fsuccess,VcAttvalprl);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"PLATFORM\">");
											fprintf(fsuccess,VcAttvalpt);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Release Date\">");
											fprintf(fsuccess,DmlRelDateStr);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Vehicle Class\">");
											fprintf(fsuccess,ProjVehclassDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Plant Name\">");
											fprintf(fsuccess,ProjplnnameDup);
											fprintf(fsuccess,"</field>\n");

											TC_write_syslog("\n NEW SYSLOG  40 \n");

											fprintf(fsuccess,"<field key =\"Business Unit\">");
											fprintf(fsuccess,ProjbussDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Dml No\">");
											fprintf(fsuccess,DmlIdDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML type\">");
											fprintf(fsuccess,DmlRelTypeDup1);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML DR status\">");
											fprintf(fsuccess,DmlDRstatusDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML from to\">");
											fprintf(fsuccess,DmlDRfromtoDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML reason code\">");
											fprintf(fsuccess,DmlreasonDup1);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML synopsis\">");
											fprintf(fsuccess,Dmlsynopsis);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Project Code\">");
											fprintf(fsuccess,prjcodeDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Project desc\">");
											fprintf(fsuccess,ProjdescDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Life Cycle State\">");
											fprintf(fsuccess,DmlRelStatDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Owner\">");
											fprintf(fsuccess,"T5_LcsErcRlzd");
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Requestor\">");
											fprintf(fsuccess,Dmlrequestor);
											fprintf(fsuccess,"</field>\n");

											TC_write_syslog("\n NEW SYSLOG  41 \n");

											fprintf(fsuccess,"</logo>\n");
			
										}
										else if((strcmp(report,"V")==0) && (tc_strcmp(part_typeDup,"V")==0))
										{
											printf("\n Report is  [%s] Wise ",report); fflush(stdout);
											
											TC_write_syslog("\n NEW SYSLOG 42 \n");

											//V,Description,Revision,Color Ind,DR/AR Status,Previous rev DR status,First time rlz with DR4,Emission norms,Applicable for ESO,PRODUCT LINE,PLATFORM	Release Date,Vehicle Class,Plant Name,Business Unit,Dml No,DML type,DML DR status	DML from to,DML reason code,DML synopsis,Project Code,Project desc,Life Cycle State,Owner,Requestor
											printf("\nPartNumDup [%s] descDup [%s] PartRevDup [%s] partClrIndDup [%s] partstsDup [%s] PrerevDRstat [%s] FirstrlzDR4 [%s] VcAttvalem [%s] VcAttvaleso [%s] VcAttvalprl [%s] VcAttvalpt  [%s] DmlRelDateStr [%s] ProjVehclassDup [%s] ProjplnnameDup [%s] ProjbussDup [%s]  DmlIdDup [%s]  DmlRelTypeDup1 [%s] DmlDRstatusDup [%s] DmlDRfromtoDup [%s] DmlreasonDup1 [%s] Dmlsynopsis [%s]  prjcodeDup [%s] ProjdescDup [%s] DmlRelStatDup [%s] Dmlrequestor [%s]\n",PartNumDup,descDup,PartRevDup,partClrIndDup,partstsDup,PrerevDRstat,FirstrlzDR4,VcAttvalem,VcAttvaleso,VcAttvalprl,VcAttvalpt,DmlRelDateStr,DmlIdDup,DmlRelTypeDup1,DmlDRstatusDup,DmlDRfromtoDup,DmlreasonDup1,Dmlsynopsis,ProjdescDup,prjcodeDup,DmlRelStatDup,Dmlrequestor);fflush(stdout);
											//fprintf(fsuccess,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,T5_LcsErcRlzd,%s\n",PartNumDup,descDup,PartRevDup,partClrIndDup,partstsDup,PrerevDRstat,FirstrlzDR4,VcAttvalem,VcAttvaleso,VcAttvalprl,VcAttvalpt,DmlRelDateStr,ProjVehclassDup,ProjplnnameDup,ProjbussDup,DmlIdDup,DmlRelTypeDup1,DmlDRstatusDup,DmlDRfromtoDup,DmlreasonDup1,Dmlsynopsis,prjcodeDup,ProjdescDup,DmlRelStatDup,Dmlrequestor);
										
											fprintf(fsuccess,"<logo>\n");

											fprintf(fsuccess,"<field key =\"Veh\">");
											fprintf(fsuccess,"%s",PartNumDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Description\">");
											fprintf(fsuccess,"%s",descDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Revision\">");
											fprintf(fsuccess,"%s",PartRevDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Color Ind\">");
											fprintf(fsuccess,partClrIndDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DR/AR Status\">");
											fprintf(fsuccess,partstsDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Previous rev DR status\">");
											fprintf(fsuccess,PrerevDRstat);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"First time rlz with DR4\">");
											fprintf(fsuccess,FirstrlzDR4);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Emission norms\">");
											fprintf(fsuccess,VcAttvalem);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Applicable for ESO\">");
											fprintf(fsuccess,VcAttvaleso);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"PRODUCT LINE\">");
											fprintf(fsuccess,VcAttvalprl);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"PLATFORM\">");
											fprintf(fsuccess,VcAttvalpt);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Release Date\">");
											fprintf(fsuccess,DmlRelDateStr);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Vehicle Class\">");
											fprintf(fsuccess,ProjVehclassDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Plant Name\">");
											fprintf(fsuccess,ProjplnnameDup);
											fprintf(fsuccess,"</field>\n");

											TC_write_syslog("\n NEW SYSLOG  43 \n");

											fprintf(fsuccess,"<field key =\"Business Unit\">");
											fprintf(fsuccess,ProjbussDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Dml No\">");
											fprintf(fsuccess,DmlIdDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML type\">");
											fprintf(fsuccess,DmlRelTypeDup1);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML DR status\">");
											fprintf(fsuccess,DmlDRstatusDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML from to\">");
											fprintf(fsuccess,DmlDRfromtoDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML reason code\">");
											fprintf(fsuccess,DmlreasonDup1);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"DML synopsis\">");
											fprintf(fsuccess,Dmlsynopsis);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Project Code\">");
											fprintf(fsuccess,prjcodeDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Project desc\">");
											fprintf(fsuccess,ProjdescDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Life Cycle State\">");
											fprintf(fsuccess,DmlRelStatDup);
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Owner\">");
											fprintf(fsuccess,"T5_LcsErcRlzd");
											fprintf(fsuccess,"</field>\n");

											fprintf(fsuccess,"<field key =\"Requestor\">");
											fprintf(fsuccess,Dmlrequestor);
											fprintf(fsuccess,"</field>\n");

											TC_write_syslog("\n NEW SYSLOG  44 \n");

											fprintf(fsuccess,"</logo>\n");
										
										}
									}
									else
									{
										printf("\nPart : %s  having Part type : %s is NON Valide",PartNumDup,part_typeDup);fflush(stdout);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	else
	{ 
		printf("\n ERC Released DML not Found fromdate: [%s] , todate: [%s]",fromdate,todate);fflush(stdout);
		return 0;
	}

	fprintf(fsuccess,"</Top>\n");
	fclose(fsuccess);

	TC_write_syslog("\n NEW SYSLOG  45 \n");

	printf("\n*********************"); fflush(stdout);
	printf("\nEnd of program.....!!"); fflush(stdout);
	printf("\n*********************\n"); fflush(stdout);

	CLEANUP:
	ITK_CALL(POM_logout(false));
	return status;
	printf("\nCLEANUP...\n"); fflush(stdout);
}
