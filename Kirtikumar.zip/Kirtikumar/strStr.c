#include<stdio.h>  
#include <string.h>    
int main()
{    
  char *str ="((([Teamcenter]'VEHICLE AGGREGATE' = TRIM & [Teamcenter]'VEHICLE TYPE' = CUV & [Teamcenter]'MBOM INCLUSION' = YES & [Teamcenter]'DRL TYPE' = SEQUENTIAL & [Teamcenter]'CENTER LAMP' = STEADY)))";   
  char *sub;    
  sub=strstr(str,"CENTER LAMP' = STEADY+WELCOME");    
  printf("\nSubstring is: %s",sub);    
  return 0;    
}    