#!/bin/bash
echo input file is: $1
#while IFS= read -r line; do
#if [[$line == *"item_id="* ]]; then
#item_id=$(echo $line | cut -d'=' -f 2)
#fi
#done < "$1"
#echo $item_id
a=`grep -i 'to_mail' $1`
echo $a

