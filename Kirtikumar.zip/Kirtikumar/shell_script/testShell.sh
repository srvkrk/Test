echo I am callled from Report builder
