#include <time.h>
#include <tc/tc.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <itk/mem.h>
#include <tccore/workspaceobject.h>
#include <tccore/releasestatus.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pom/pom/pom.h>
#include <tccore/grm.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <unistd.h>
#include <iostream>


FILE *filePointer;
using namespace std;
int GetRequiredTP(char* , char*);

int ITK_user_main(int argc, char ** argv) 
{
	char * user				= NULL;
    char * pw				= NULL;
    char * grp				= NULL;
	char * created_After	= NULL;
	char * created_Before	= NULL;
	
	int ifail = ITK_ok;
    int status = 0;
	
    user			= ITK_ask_cli_argument("-u=");
	pw				= ITK_ask_cli_argument("-p=");
    grp				= ITK_ask_cli_argument("-g=");
	created_After	= ITK_ask_cli_argument("-ca=");
	created_Before	= ITK_ask_cli_argument("-cb=");

	//Login to TC
	status = ITK_init_module(user, pw, grp);
	if(status == ITK_ok){
		
		printf("\nLgoin to TC successful.......!!\n");
		
	} else  { 
		printf("\nLgoin to TC Failed.......!!\n");
	}
	//
	status = GetRequiredTP(created_After,created_Before);

		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
}

int GetRequiredTP(char *CA, char *CB)
{
	int ifail = ITK_ok;
	int resultCount = 0;
	int n_entries = 3;
	int i;
	int j;
	int num;

	char * 	Errortext;
	tag_t queryTag;

	char *object_name;

	//User entries of General... Query
	char *userEntryType = "Type";
	char *userEntryCA = "Created After";
	char *userEntryCB = "Created Before";

	//Values to user entries
	char *TypeValue = "Test Plan Revision";

	tag_t * TestPlanTag = NULL;
	tag_t * allWorkflow;
	char* workflowName;
	char* status;
	date_t workflowEndDate;
	char *wfEndDate;
	
	tag_t tp_close_status_tag;

	char**  entries = NULL;
	char**  values  = NULL;

	entries		= (char**) MEM_alloc (sizeof(char*) * 200);
	values		= (char**) MEM_alloc (sizeof(char*) * 200);
	

	entries[0] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(userEntryType) + 200));
	values[0]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(TypeValue) + 200));
			
	entries[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(userEntryCA) + 200));
	values[1]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(CA) + 200));

	entries[2] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(userEntryCB) + 200));
	values[2]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(CB) + 200));

	tc_strcpy(entries[0], "");	
	tc_strcpy(entries[0], userEntryType);
	tc_strcpy(values[0], "");	
	tc_strcpy(values[0], TypeValue);
	
	tc_strcpy(entries[1], "");
	tc_strcpy(entries[1], userEntryCA);
	tc_strcpy(values[1], "");	
	tc_strcpy(values[1], CA);

	tc_strcpy(entries[2], "");
	tc_strcpy(entries[2], userEntryCB);
	tc_strcpy(values[2], "");	
	tc_strcpy(values[2], CB);
	
	// Getting Query Tag

	ifail = QRY_find2("General...", & queryTag);
	if (ifail != ITK_ok)
	{
          cout << "\n*** Error with Finding Query ***\n";
		  EMH_ask_error_text(ifail,&Errortext);
		  printf("\nError Code is n%s",Errortext);
          return ifail;
     }
	 if (queryTag)  {

			cout << "Found Query \n";

     } else {
                cout << "*** Query Not Found *** \n";
                return ifail;
     }

	 //Executing the Query 
	 ifail = QRY_execute(queryTag, n_entries, entries, values, &resultCount, &TestPlanTag);
	 if(ifail == ITK_ok) 
	 {
		 cout << "*** Query Executed Successfully*** \n";
		 printf("\nNo. of TP found -- %d\n", resultCount);

	 } else {

		 cout << "*** Error occured while executing the Query*** \n";
		 EMH_ask_error_text(ifail,&Errortext);
		 printf("\nError Code is n%s",Errortext);
		 return ifail;
	 }
	//Looping the Result
	for(i=0; i<resultCount; i++)
	{
		ifail = AOM_ask_value_string(TestPlanTag[i],"object_string",&object_name);
		printf("\nTest Plan Name...%s\n", object_name);
		
		ifail = AOM_ask_value_tags(TestPlanTag[i],"fnd0AllWorkflows",&num,&allWorkflow);
		printf("\nTotal No of Worlflow attahced to Test Plan is %d\n",num);

		 for (j=0;j<num;j++) 
		  {
			ifail = AOM_ask_value_string(allWorkflow[j],"object_string",&workflowName);
			if((tc_strcmp(workflowName,"Testplan Workflow")==0))
			{
				printf("\nTestplan Workflow found\n");
				ifail = AOM_ask_value_string(allWorkflow[j],"fnd0Status",&status);
				//if((tc_strcmp(status,"Completed")==0))
				//{
					//printf("\n Workflow is completed.\n");
					//ifail = AOM_ask_value_string(allWorkflow[j],"fnd0EndDate",&workflowEndDate);
					 ifail = AOM_ask_value_date(allWorkflow[j],"fnd0EndDate",&workflowEndDate);
					 ifail = ITK_date_to_string(workflowEndDate,&wfEndDate);
					 printf("\n Workflow is completed on :%s\n",wfEndDate);
					 ifail = RELSTAT_create_release_status("TestPlan Closed",&tp_close_status_tag);
					 if(ifail == ITK_ok) 
					 {
						 cout << "*** TestPlan Closed status found*** \n";

					 } else {

						 cout << "*** estPlan Closed status NOT found*** \n";
						 EMH_ask_error_text(ifail,&Errortext);
						 printf("\nValue not setn%s",Errortext);
						 //return ifail;
					}
					ifail = AOM_refresh(TestPlanTag[i],0);
					ifail = RELSTAT_add_release_status(tp_close_status_tag,1,&TestPlanTag[i],true);
					ifail = AOM_set_value_date(TestPlanTag[i],"date_released",workflowEndDate);
					ifail = AOM_save(TestPlanTag[i]);
					ifail = AOM_refresh(TestPlanTag[i],1);
					
					if(ifail == ITK_ok) 
					 {
						 cout << "*** TestPlan Closed status added to TP Revision successfully*** \n";

					 } else {

						 cout << "*** Error while setting the Status*** \n";
						 EMH_ask_error_text(ifail,&Errortext);
						 printf("\nError Code is n%s",Errortext);
						 //return ifail;
					}
					 
					//ifail = AOM_refresh(TestPlanTag[i],0);
					//ifail = AOM_save(TestPlanTag[i]);
					//ifail = AOM_refresh(TestPlanTag[i],1);

			}
		//}


	  }

	}
	return ifail;
	
}
