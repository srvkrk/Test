#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	int				i 							= 0;
	int				j 							= 0;
	int				count 						= 0;
	int				count_status				= 0;
	int				num							= 0;
	int*			state_token;
	tag_t			item_tag					= NULLTAG;
	tag_t			*status_list				= NULL;
	tag_t			*rev_list					= NULL;
	tag_t *			allWorkflow					= NULL;
	tag_t			tp_close_status_tag;
	tag_t			date_released_attr			= NULL;

	
	char			*status						= NULL;
	char			*object_name				= NULL;
	char			*workflowName				= NULL;
	char			*wfEndDate;
	
	char			*rev_id						= NULL;
	date_t			workflowEndDate;
	
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);

	CHECK_FAIL;	
	for(i=0;i<count;i++)
	{
		ifail = AOM_ask_value_string(rev_list[i],"object_string",&object_name);
		printf("\nTest Plan Name...%s\n", object_name);


		ifail = AOM_ask_value_tags(rev_list[i],"fnd0AllWorkflows",&num,&allWorkflow);
		printf("\nTotal No of Worlflow attahced to Test Plan is %d\n",num);
		for (j=0;j<num;j++) 
		{
			ifail = AOM_ask_value_string(allWorkflow[j],"object_string",&workflowName);
			if((tc_strcmp(workflowName,"Testplan Workflow")==0))
			{
				printf("\nTestplan Workflow found\n");
				ifail = AOM_ask_value_string(allWorkflow[j],"fnd0Status",&status);

				if((tc_strcmp(status,"Completed")==0))
				{
					ifail = AOM_ask_value_date(allWorkflow[j],"fnd0EndDate",&workflowEndDate);
					ifail = ITK_date_to_string(workflowEndDate,&wfEndDate);
					printf("\n Workflow is completed on :%s\n",wfEndDate);
				

					ifail = RELSTAT_create_release_status("TestPlan Closed",&tp_close_status_tag);
					CHECK_FAIL;

					ifail = AOM_refresh(rev_list[i],0);
					ifail = RELSTAT_add_release_status(tp_close_status_tag,1,&rev_list[i],true);
					ifail = AOM_save(rev_list[i]);
					ifail = AOM_refresh(rev_list[i],1);
					CHECK_FAIL;
				
					ifail =	POM_attr_id_of_attr("date_released", "Design_0_Revision_alt", &date_released_attr);
					ifail = AOM_lock(rev_list[i]);
					ifail = POM_set_attr_date(1, &rev_list[i], date_released_attr, workflowEndDate);
					ifail = AOM_save(rev_list[i]);
					ifail = AOM_refresh(rev_list[i],1);
					ifail = AOM_unlock(rev_list[i]);

					//ifail = POM_ask_instance_state(&tp_close_status_tag,&state_token);
					//if(*state_token != POM_inst_is_loaded_for_modify)
					//{
					//ifail = POM_unload_instances(1,&tp_close_status_tag);
					//ifail = POM_load_instances_any_class(1,&tp_close_status_tag,POM_modify_lock);
					//}
					//ifail = POM_set_attr_date(1, &tp_close_status_tag, date_released_attr, workflowEndDate);
					//ifail = POM_save_instances(1,&tp_close_status_tag,true);


					//CHECK_FAIL;
					//ifail = AOM_refresh(rev_list[i],0);
					//ifail = POM_set_attr_date(1, &rev_list[i], date_released_attr, workflowEndDate);
					////ifail = AOM_save(rev_list[i]);
					//ifail = AOM_refresh(rev_list[i],1);
					//CHECK_FAIL;
				
					//Setting Release Date as workflow close date
					//ifail = ITK_set_bypass(true);
					//ifail =	AOM_load(rev_list[i]);
					//ifail = AOM_refresh(rev_list[i],0);
					//ifail = AOM_set_value_string(rev_list[i],"date_released",wfEndDate);
					//ifail = AOM_save(rev_list[i]);
					//ifail = AOM_refresh(rev_list[i],1);
					//CHECK_FAIL;
				}
				

				
			}


		}


	}	
	MEM_free(status);
	MEM_free(rev_id);
	MEM_free(rev_list);
	MEM_free(object_name);
	MEM_free(allWorkflow);

	return ifail;
}
