	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>	
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int PRM_REPORT();

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/


void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);


}
;

int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	//dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 )
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = PRM_REPORT();
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int PRM_REPORT()
{

	int status = ITK_ok;

	int i =0;
	int j =0;

	tag_t latestRev = NULL_TAG;
	char* swPartType = NULL;
	char* objStr	 =NULL;
	tag_t EErelation_type = NULLTAG;
	int cntEE = 0;
	tag_t *attachmentsEE = NULLTAG;
	char* clauseName = NULL;

	// To get Parameter parts
	tag_t	qry_t1	= NULLTAG;
	char **qry_val3 = (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1[1]  = {"Type"};
	int n_entr1 = 1;
	int rsltCunt1=0;
	tag_t *EE_PartsTag=NULLTAG;
		char **UniqPart1				=  NULL;
		char **UniqPart2				=  NULL;

		int p1 =0;
		int p2 =0;

	UniqPart1 = (char**)MEM_alloc( 10000 * sizeof *UniqPart1 );
	UniqPart2 = (char**)MEM_alloc( 10000 * sizeof *UniqPart2 );

	if(QRY_find("General...", &qry_t1));
	if (qry_t1)
	{
		printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
	}
	qry_val3[0] = "EE Part";
	if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &EE_PartsTag));

	printf("\n Total No of EE Parts found : [%d]",rsltCunt1);fflush(stdout);

	ifail = GRM_find_relation_type("T5_EEPrm",&EErelation_type); 

	if(rsltCunt1>0)
	{
		for(i=0;i<rsltCunt1;i++)
		{
			status = ITEM_ask_latest_rev(EE_PartsTag[i],&latestRev);
			status = AOM_ask_value_string(latestRev,"t5_SwPartType",&swPartType);
			status = AOM_ask_value_string(latestRev,"object_string",&objStr);
			//printf("\n swPartType [%s]",swPartType); fflush(stdout);

			if(tc_strcmp(swPartType,"PRM")==0)
			{
				printf("\n Parameter found: objStr [%s]",objStr);fflush(stdout);

				ifail = GRM_list_secondary_objects_only(latestRev,EErelation_type,&cntEE,&attachmentsEE);
				printf("\n Total No of Clauses : [%d]",cntEE);fflush(stdout);
				
				if (cntEE > 0)
				{
					for (j=0;j<cntEE ; j++)
					{
						ifail = AOM_ask_value_string(attachmentsEE[j],"object_name",&clauseName);
						printf("\nclauseName : [%s]",clauseName);fflush(stdout);

						//setAddStr(&p1,&UniqPart1,clauseName);
						//setAddStr(&p2,&UniqPart2,clauseName);

				

					}



				//for (i = 0 ; i < p1 ; i++ )
				//{
				//
				//	int counter = 0;
				//
				//	for (j = 0 ; j < p2 ; j++ )
				//	{
				//
				//		if(tc_strcmp(UniqPart1[i],UniqPart2[j])==0)
				//		{
				//
				//				counter++;
				//
				//				printf("\nUniqPart1[%d] : [%s]",i,UniqPart1[i]);
				//
				//
				//		}
				//
				//
				//	}
				//}
					//int t = 0;
					//int count = 0;
					//
					//for (i = 0 ; i< p ; i++ )
					//{
					//
					//		Partno = UniqPart[i];
					//
					//		printf("\n11111111111111");
					//		
					//		//printf("\n[%s]",UniqPart[i]);
					//		//printf("\n[%s]",UniqPart[j]);
					//
					//		int j;
					//
					//		printf("\ncount : [%d]",count);
					//		printf("\nj : [%d]",j);
					//
					//			for (j = 0; j < count; j++)
					//			{
					//					
					//
					//					printf("\n22222222222222");
					//					//printf("\n[%s]",Partno);
					//					//printf("\n[%s]",UniqPart[j]);
					//
					//				//if (tc_strcmp(Partno,UniqPart[j])==0)
					//
					//				printf("\ntemp [%d]: [%s]",j,temp[j]);
					//				if(tc_strcmp(UniqPart[i],temp[j])==0)
					//				{
					//
					//						printf("\n3333333333333");
					//						//t++;
					//						//printf("\nUniqPartno:[%s]",Partno);
					//						break;
					//
					//						//setAddStr(&k,&UniqPartno,UniqPart[i]);
					//						//break;
					//					//setAddStr(&k,&UniqPartno,Partno);
					//					//break;
					//
					//					
					//				}
					//
					//			}
					//				if (j == count)
					//				{
					//
					//					printf("\n********");
					//					temp[count]= (char *)MEM_alloc( strlen(Partno) + 1);	
					//					tc_strcpy(temp[count],Partno);
					//					printf("unique elements in an array is [%s]",Partno);
					//					setAddStr(&k,&UniqPartno,Partno);
					//					count++;
					//
					//
					//				}
					//
					//
					//				
					//
					//			
					//			//if (t==0)
					//			//{
					//			//	setAddStr(&k,&UniqPartno,Partno);
					//			//
					//			//}
					//
					//
					//		
					//
					//	
					//}
				}
			}

		}
	}


	return status;
}
