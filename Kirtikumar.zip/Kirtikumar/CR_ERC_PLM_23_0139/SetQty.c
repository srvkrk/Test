	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int SetQty(char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* archNo					= NULL;
	char			* Filename					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	archNo 			= ITK_ask_cli_argument("-archNo=");
	Filename		= ITK_ask_cli_argument("-file=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

//	ifail = ITK_set_bypass(true);
//    if (ifail != ITK_ok)
//	{
//		printf("\nUser is not Privileged Admin User \n\n");
//		return -1;
//	}
	
	ifail = SetQty(archNo,Filename);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int SetQty(char* archNo,char* fileName)
{
	char 		*module					= NULL;
	char 		temp[200];
	tag_t		window,windowW;
	tag_t		top_lineW = NULLTAG;
	tag_t		archNodeITemTag = NULLTAG;
	tag_t		LatestRev = NULLTAG;
	char*		objstr = NULL;
	int			countW = 0;

	int			Item_attr			= 0;
	int			Rev_attr			= 0;
	int			child_Qty			= 0;
	int			bl_Child_objType	= 0;
	char*		child_Item_id		= NULL;
	char*		child_Item_rev_id	= NULL;
	char*		child_qty			= NULL;
	char*		child_PartType		= NULL;

	int i =0;
	tag_t*		childrenW = NULLTAG;
	FILE		* fp 					= NULL;
	printf("\nInput archNo:%s\n",archNo);

	ifail = ITEM_find_item(archNo,&archNodeITemTag);
	ifail = ITEM_ask_latest_rev(archNodeITemTag,&LatestRev);
	ifail = AOM_ask_value_string(LatestRev,"object_string",&objstr);
	printf("\nInput archNo ObjStr :%s\n",objstr);
	

	ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_attr))PrintErrorStack();
	ITKCALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Rev_attr))PrintErrorStack();
	ITKCALL(BOM_line_look_up_attribute ("bl_quantity",&child_Qty))PrintErrorStack();
	ITKCALL(BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&bl_Child_objType))PrintErrorStack();

	ifail = BOM_create_window (&windowW);
	ifail = BOM_set_window_top_line (windowW, null_tag, LatestRev, null_tag, &top_lineW);
	ifail = BOM_line_ask_child_lines (top_lineW, &countW, &childrenW);



	printf("\nNo of Child under Arch Node are  : %d\n",countW);
	
	fp = fopen(fileName, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
		
			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				module = strtok(temp, " ");
				printf("\nInput module:%s\n",module);
				for(i =0; i < countW;i++)
				{
						ITKCALL(BOM_line_ask_attribute_string(childrenW[i], Item_attr, &child_Item_id))PrintErrorStack();
						ITKCALL(BOM_line_ask_attribute_string(childrenW[i], Rev_attr, &child_Item_rev_id))PrintErrorStack();
						ITKCALL(BOM_line_ask_attribute_string(childrenW[i], child_Qty, &child_qty))PrintErrorStack();
						ITKCALL(BOM_line_ask_attribute_string(childrenW[i], bl_Child_objType, &child_PartType))PrintErrorStack();

						printf("\n\t child_PartType => [%s]\n",child_PartType);fflush(stdout);
						if (tc_strcmp(child_PartType,"Module")==0 || tc_strcmp(child_PartType,"M") ==0)
						{
							if (tc_strcmp(module,child_Item_id)==0)
							{
								printf("\n\t **child_Item_id=> [%s]**\n",child_Item_id);fflush(stdout);
								printf("\n\t **child_Item_rev_id => [%s]**\n",child_Item_rev_id);fflush(stdout);
								printf("\n\t **child_qty => [%s]**\n",child_qty);fflush(stdout);

								ITKCALL(AOM_UIF_set_value(childrenW[i], "bl_quantity", "0") != ITK_ok);PrintErrorStack();
								printf("\nQuantity set to 0s\n");fflush(stdout);

							}
								
						}
				}
				
			}
			printf("***************************************\n");
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}
