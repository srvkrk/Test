	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int SortPRMClauses(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* prmno						= NULL;

	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	prmno 			= ITK_ask_cli_argument("-prmno=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(prmno)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = SortPRMClauses(prmno);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int SortPRMClauses(char* prm)
{
	int ifail = ITK_ok;

	int		count1			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	rev_list		= NULL;
	char* objStr			= NULL;
	int cntEE= 0;
	tag_t* prmClauses		= NULLTAG;
	
	tag_t EErelation_type	= NULLTAG;

	tag_t type_tag			= NULLTAG;
	tag_t property_tag		= NULLTAG;
	tag_t base_prop_tag		= NULLTAG;
	tag_t base_type_tag		= NULLTAG;

	int *order = (int* )MEM_alloc(sizeof(int));
	order[0] =0;
	int n_sorted_tags =0;
	tag_t *sorted_tags = NULLTAG;
	int i =0;
	int status =0;


	ifail = ITEM_find_item (prm, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_ask_latest_rev (item_tag, &rev_list);
	CHECK_FAIL;

	AOM_ask_value_string(rev_list,"object_string",&objStr);
	//printf("\n objStr is :%s\n",objStr);fflush(stdout);
	
	ifail = GRM_find_relation_type("T5_EEPrm",&EErelation_type);
	ifail = GRM_list_secondary_objects_only(rev_list,EErelation_type,&cntEE,&prmClauses);

	//printf("\n Total No of Clauses attached to PRM is ---------- [%d] \n",cntEE);

	
	ITK_CALL(TCTYPE_find_type("T5_EPara","T5_EPara",&type_tag));
	ITK_CALL(TCTYPE_ask_property_by_name(type_tag,"t5_EPDidValue",&property_tag));
	ITK_CALL(PROPDESC_ask_base_descriptor(property_tag,&base_prop_tag,&base_type_tag));

	ifail = AOM_sort_tags_by_properties(cntEE,prmClauses,1,&base_prop_tag,order,&n_sorted_tags,&sorted_tags);
	//printf("\n n_sorted_tags is :%d\n",n_sorted_tags);fflush(stdout);
	for(i =0;i <n_sorted_tags;i++)
	{
		char* clauseObjstr = NULL;
		char* DID =	NULL;

		AOM_ask_value_string(sorted_tags[i],"object_string",&clauseObjstr);
		//printf("\n clauseObjstr is :%s\n",clauseObjstr);fflush(stdout);

		AOM_ask_value_string(sorted_tags[i],"t5_EPDidValue",&DID);
		printf("\n DID is :%s\n",DID);fflush(stdout);

	}


	return ifail;
}
