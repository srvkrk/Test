	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>	
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <sa/user.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int PRM_REPORT();
int write_info(char*, char*,char*, char*, char*,char*,char*, char*, char*,char*,char*, char*, char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/


void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	// printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);


}
;


int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	//char			Data[100]					= "";
	//char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	//dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 )
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	char			outputFile[10000]				= "";
	char			Data[10000]						= "";
	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.csv",Data);
	
	output = fopen(outputFile,"a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	fprintf(output,"Part No,Rev Seq,Clause Name,Clause Desc,ECU Type,Supplier,Version,Unit,Lenght,DID,Data Type,App,ReadWrite\n");
	ifail = PRM_REPORT();
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	fclose(output);
	ifail = ITK_exit_module(true);

	return ifail;
}


int PRM_REPORT()
{

	int status = ITK_ok;

	int i =0;
	int j =0;
	int k =0;
	
	tag_t latestRev    = NULL_TAG;
	char* swPartType   = NULL;
	char* objStr	   = NULL;
	char* item_id		   = NULL;
	char* item_rev_id	   = NULL;
	char Owner[SA_user_size_c+1];
	tag_t EErelation_type = NULLTAG;
	int cntEE = 0;
	tag_t *attachmentsEE = NULLTAG;
	char* clauseName = NULL;

	// To get Parameter parts
	tag_t	qry_t1	= NULLTAG;
	char **qry_val3 = (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1[1]  = {"Type"};
	int n_entr1 = 1;
	int rsltCunt1=0;
	tag_t *EE_PartsTag=NULLTAG;
	tag_t OwnerTag =NULLTAG;

		

	

	if(QRY_find("General...", &qry_t1));
	if (qry_t1)
	{
		printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
	}
	qry_val3[0] = "EE Part";
	if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &EE_PartsTag));

	printf("\n Total No of EE Parts found : [%d]",rsltCunt1);fflush(stdout);

	ifail = GRM_find_relation_type("T5_EEPrm",&EErelation_type); 

	if(rsltCunt1>0)
	{
		for(i=0;i<rsltCunt1;i++)
		{
			status = ITEM_ask_latest_rev(EE_PartsTag[i],&latestRev);
			status = AOM_ask_value_string(latestRev,"t5_SwPartType",&swPartType);
			status = AOM_ask_value_string(latestRev,"object_string",&objStr);
			status = AOM_ask_value_string(latestRev,"item_id",&item_id);
			status = AOM_ask_value_string(latestRev,"item_revision_id",&item_rev_id);

			status = AOM_ask_owner( latestRev, &OwnerTag );
			status = SA_ask_user_identifier(OwnerTag,Owner);
			//printf("\n swPartType [%s]",swPartType); fflush(stdout);

			if(tc_strcmp(swPartType,"PRM")==0)
			{
				//printf("\n Parameter found: objStr [%s]",objStr);fflush(stdout);
				//printf("\n Owner [%s]",Owner); fflush(stdout);

				if(tc_strcmp(Owner,"loader")==0)
				{
					
					char **UniqPart1				=  NULL;
					char **UniqPart2				=  NULL;
					char **temp				=  NULL;

					UniqPart1 = (char**)MEM_alloc( 10000 * sizeof *UniqPart1 );
					//UniqPart2 = (char**)MEM_alloc( 10000 * sizeof *UniqPart2 );
					temp = (char**)MEM_alloc( 10000 * sizeof *temp );

					int p1 =0;
					int p2 =0;

					ifail = GRM_list_secondary_objects_only(latestRev,EErelation_type,&cntEE,&attachmentsEE);
					//printf("\n Total No of Clauses : [%d]",cntEE);fflush(stdout);
					
					if (cntEE > 0)
					{
						for (j=0;j<cntEE ; j++)
						{
							ifail = AOM_ask_value_string(attachmentsEE[j],"object_name",&clauseName);
							//printf("\nclauseName : [%s]",clauseName);fflush(stdout);
							
							setAddStr(&p1,&UniqPart1,clauseName);

						}
						//int size1 =sizeof(UniqPart1) / sizeof(UniqPart1[0]);
	//					int size1 =sizeof(UniqPart1);
	//					int size2 =sizeof(UniqPart1[0]);
	//
	//					printf("\n size1  : [%d]",size1);fflush(stdout);
	//					printf("\n size2  : [%d]",size2);fflush(stdout);
					
						char* tempClauase = NULL;
						int	  count = 0;

						for(k=0;k<p1;k++)
						{
							//printf("\nclauseName after storing it to char Array  : [%s]",UniqPart1[k]);fflush(stdout);
							tempClauase = UniqPart1[k];
							//printf("\n\t tempClauase [%s]",tempClauase);
							int l =0;
							//printf("\n count : [%d]",count);
							//printf("\n l     : [%d]",l);

							for (l = 0; l < count; l++)
							{
								//printf("\n\t temp [%d]: [%s]",l,temp[l]);
								if(tc_strcmp(UniqPart1[k],temp[l])==0)
								{
									
									//printf("\n\t Duplicate Clause found [%s]",tempClauase);

									printf("\n\t *******Parameter :[%s] have multiple claues with same name [%s]*********",objStr,tempClauase);
									int m =0;
									char* clName = NULL;
									char* clDesc = NULL;
									char* clECUType = NULL;
									char* clVer = NULL;
									char* clUnit = NULL;
									char* clLen = NULL;
									char* clDid = NULL;
									char* cldataType = NULL;
									char* clApp = NULL;
									char* clReadW = NULL;
									char* clSupp = NULL;

									for(m =0;m <cntEE;m++)
									{
										ifail = AOM_ask_value_string(attachmentsEE[m],"object_name",&clName);
										ifail = AOM_ask_value_string(attachmentsEE[m],"t5_t5EPDesc",&clDesc);

										if(tc_strcmp(tempClauase,clName)==0)
										{
											ifail = AOM_ask_value_string(attachmentsEE[m],"t5_ECUType",&clECUType);
											ifail = AOM_ask_value_string(attachmentsEE[m],"t5_ECUVendor",&clSupp);
											ifail = AOM_ask_value_string(attachmentsEE[m],",t5_ECUVersion",&clVer);
											ifail = AOM_ask_value_string(attachmentsEE[m],"t5_EPUnit",&clUnit);
											ifail = AOM_ask_value_string(attachmentsEE[m],"t5_EPLen",&clLen);
											ifail = AOM_ask_value_string(attachmentsEE[m],"t5_EPDidValue",&clDid);
											ifail = AOM_ask_value_string(attachmentsEE[m],"t5_EPType",&cldataType);
											ifail = AOM_ask_value_string(attachmentsEE[m],"t5_EPApplicable",&clApp);
											ifail = AOM_ask_value_string(attachmentsEE[m],"t5_EPReadable",&clReadW);

											ifail =write_info(objStr,item_rev_id,clName,clDesc,clECUType,clSupp,clVer,clUnit,clLen,clDid,cldataType,clApp,clReadW);

											//printf("\n\t object_name:[%s],clDesc:[%s],clECUType:[%s],clSupp:[%s],clVer:[%s],clUnit:[%s],clLen:[%s],clDid:[%s], cldataType:[%s],clApp:[%s],clReadW:[%s]",clName,clDesc,clECUType,clSupp,clVer,clUnit,clLen,clDid,cldataType,clApp,clReadW);
					
										}

									}

								}

							}
							if (l == count)
							{

								//printf("\n**************");
								temp[count]= (char *)MEM_alloc( strlen(tempClauase) + 1);	
								tc_strcpy(temp[count],tempClauase);
								//printf("unique elements in an array is [%s]",tempClauase);
								//setAddStr(&k,&UniqPartno,Partno);
								count++;

							}
						}
					}
				}

			
			}

		}
	}


	return status;
}
int write_info(char* item_Id,char* rev_id,char* Name,char* Desc,char* ECUType,char* Supp,char* Ver,char* Unit,char* Len,char* Did,char* dataType,char* App,char* ReadW)
{
	
	
	char 		*test1				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test2				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test3				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test4				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test5				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test6				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test7				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test8				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test9				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test10				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*test11				= (char*)MEM_alloc(sizeof(char) * 100);

	char		*itemID				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*reVID				= (char*)MEM_alloc(sizeof(char) * 100);




	tc_strcpy(itemID, "");
		tc_strcpy(itemID,item_Id);


	tc_strcpy(reVID, "");
		tc_strcpy(reVID,rev_id);
	
	
	tc_strcpy(test1, "");
		tc_strcpy(test1,Name);

	tc_strcpy(test2, "");
		tc_strcpy(test2,Desc);

	tc_strcpy(test3, "");
		tc_strcpy(test3,ECUType);

	tc_strcpy(test4, "");
		tc_strcpy(test4,Supp);

	tc_strcpy(test5, "");
		tc_strcpy(test5,Ver);

	tc_strcpy(test6, "");
		tc_strcpy(test6,Unit);

	tc_strcpy(test7, "");
		tc_strcpy(test7,Len);

	tc_strcpy(test8, "");
		tc_strcpy(test8,Did);

	tc_strcpy(test9, "");
		tc_strcpy(test9,dataType);

	tc_strcpy(test10, "");
		tc_strcpy(test10,App);

	tc_strcpy(test11, "");
		tc_strcpy(test11,ReadW);

	//printf("File opened successfully.\n");
	fprintf(output,"\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"\n",itemID,rev_id,test1,test2,test3,test4,test5,test6,test7,test8,test9,test10,test11);
	//fprintf(output,"%s\n",final2);

	
	
	return 0;
}
