	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int ContParaChildReport(char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* cd						= NULL;
	char			* cb						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	cd 				= ITK_ask_cli_argument("-cd=");
	cb				= ITK_ask_cli_argument("-cb=");

		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(cd)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = ContParaChildReport(cd,cb);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int ContParaChildReport(char* CD,char* CB)
{
	int ifail = ITK_ok;
	int i =0;
	int iw = 0;
	char* objStr =0;
	char* swPartyType = NULL;
	char* child_Item_id = NULL;
	char* child_Item_rev_id = NULL;
	char* childObjType = NULL;
	char* childSWPartType = NULL;
	int countW =0;
	int			Item_attr			= 0;
	int			blobjType			= 0;
	int			bl_Child_SWobjType	= 0;
	int			Rev_attr			= 0;
	tag_t *childrenW;
	tag_t windowW =NULLTAG;
	tag_t top_lineW = NULLTAG;

	//Control Obj for On and Off Validation.
	tag_t	qry_t1			= NULLTAG;
	char **qry_val3			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1[3]   = {"Type","Created After","Created Before"};
	int n_entr1				= 3;
	int rsltCunt1			= 0;
	tag_t *Objects		= NULLTAG;

	

	if(QRY_find("General...", &qry_t1));
	if (qry_t1)
	{
		printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
	}
	qry_val3[0] = "EE Part Revision";
	qry_val3[1] = CD;
	qry_val3[2] = CB;

	if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &Objects));

	if(rsltCunt1>0)
	{
		printf("\nTotal No of EE Parts found.. [%d] ",rsltCunt1);fflush(stdout);
		for(i =0 ;i < rsltCunt1;i++)
		{
			ITKCALL(AOM_ask_value_string(Objects[i],"object_string",&objStr));
			//ITKCALL(AOM_ask_value_string(Objects[i],"t5_SwPartType",&swPartyType));
			
			printf("\n objStr [%s] ",objStr);fflush(stdout);
			printf("\n swPartyType [%s] ",swPartyType);fflush(stdout);
			

			if (tc_strcmp(swPartyType,"CON")==0  || tc_strcmp(swPartyType,"PRM")==0)
			{
				//Cont or Parafound check for if it contains any child
				//printf("\n swPartyType [%s] ",swPartyType);fflush(stdout);

				ifail = BOM_create_window (&windowW);
				ifail = BOM_set_window_top_line (windowW, null_tag, Objects[i], null_tag, &top_lineW);
				ifail = BOM_line_ask_child_lines (top_lineW, &countW, &childrenW);

				printf("\n No of child [%d] ",countW);fflush(stdout);

				
				ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_attr))PrintErrorStack();
				ITKCALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Rev_attr))PrintErrorStack();
				ITKCALL(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType))PrintErrorStack();
				ITKCALL(BOM_line_look_up_attribute ("bl_T5_EE_PartRevision_t5_SwPartType",&bl_Child_SWobjType))PrintErrorStack();
				
				if(childrenW >0)
				{
					for (iw=0;iw<countW;iw++)
					{
							ITKCALL(BOM_line_ask_attribute_string(childrenW[iw], Item_attr, &child_Item_id))PrintErrorStack();
							ITKCALL(BOM_line_ask_attribute_string(childrenW[iw], Rev_attr, &child_Item_rev_id))PrintErrorStack();
							ITKCALL(BOM_line_ask_attribute_string(childrenW[iw], blobjType, &childObjType))PrintErrorStack();
							ITKCALL(BOM_line_ask_attribute_string(childrenW[iw], bl_Child_SWobjType, &childSWPartType))PrintErrorStack();

							if (tc_strcmp(childSWPartType,"Container") ==0 || tc_strcmp(childSWPartType,"Parameter") ==0)
							{
								//printf("\n\t childObjType		   => [%s]\n",childObjType);fflush(stdout);
								//printf("\n\t childSWPartType	   => [%s]\n",childSWPartType);fflush(stdout);

								printf("\n Part revision [%s] having child [%s] of Type [%s]",objStr,child_Item_id,childSWPartType);
								

							}
					}
				}
				

			}
			
		}

	}


	return ifail;
}
