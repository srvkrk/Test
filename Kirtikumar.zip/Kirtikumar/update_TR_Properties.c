/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        //TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
      //  TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int		count	 				= 0;
	
	char	*item_id							= NULL;
	char	*Request_Domain						= NULL;
	char	*Test_Request_Nos					= NULL;
	char	*Business_Unit						= NULL;
	char	*WBS_Description					= NULL;
	char	*WBS								= NULL;
	char	*Metallurgy_report					= NULL;
	char	*QA_Inspection_report				= NULL;
	char	*Partys_Test_Report					= NULL;
	char	*Samples_Peripherals_Given			= NULL;
	char	*Desciption_of_Component			= NULL;
	char	*Background_History					= NULL;
	char	*Project							= NULL;
	char	*Project_Description				= NULL;
	char	*Program							= NULL;
	char	*Investigation_Reason				= NULL;
	char	*Requesting_Dept_Name				= NULL;
	char	*RqVehStage							= NULL;
	char	*Design_Status						= NULL;

	char 	*rev_id					= NULL;
	char 	*attr_value				= NULL;
	char 	 temp[200];


	
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				//printf("\ntemp:%s",temp);
				Request_Domain = strtok(temp, ",");
				printf("\nRequest_Domain:%s",Request_Domain);
				Test_Request_Nos = strtok(NULL, ",");
				printf("\nTest_Request_Nos:%s",Test_Request_Nos);
				Business_Unit = strtok(NULL, ",");
				printf("\nBusiness_Unit:%s",Business_Unit);
				WBS_Description = strtok(NULL, ",");
				printf("\nWBS_Description:%s",WBS_Description);
				WBS = strtok(NULL, ",");
				printf("\nWBS:%s",WBS);
				Metallurgy_report = strtok(NULL, ",");
				printf("\nMetallurgy_report:%s",Metallurgy_report);
				QA_Inspection_report = strtok(NULL, ",");
				printf("\nQA_Inspection_report:%s",QA_Inspection_report);
				Partys_Test_Report = strtok(NULL, ",");
				printf("\nPartys_Test_Report:%s",Partys_Test_Report);
				Samples_Peripherals_Given = strtok(NULL, ",");
				printf("\nSamples_Peripherals_Given:%s",Samples_Peripherals_Given);
				Desciption_of_Component = strtok(NULL, ",");
				printf("\nDesciption_of_Component:%s",Desciption_of_Component);
				Background_History = strtok(NULL, ",");
				printf("\nBackground_History:%s",Background_History);
				Project = strtok(NULL, ",");
				printf("\nProject:%s",Project);
				Project_Description = strtok(NULL, ",");
				printf("\nProject_Description:%s",Project_Description);
				Program = strtok(NULL, ",");
				printf("\nProgram:%s",Program);
				Investigation_Reason = strtok(NULL, ",");
				printf("\nInvestigation_Reason:%s",Investigation_Reason);
				Requesting_Dept_Name = strtok(NULL, ",");
				printf("\nRequesting_Dept_Name:%s",Requesting_Dept_Name);
				RqVehStage = strtok(NULL, ",");
				printf("\nRqVehStage:%s",RqVehStage);
				Design_Status = strtok(NULL, ",");
				printf("\nDesign_Status:%s",Design_Status);
				ifail = check_rel_status(Request_Domain,Test_Request_Nos,Business_Unit,WBS_Description,WBS,Metallurgy_report,QA_Inspection_report,Partys_Test_Report,Samples_Peripherals_Given,Desciption_of_Component,Background_History,Project,Project_Description,Program,Investigation_Reason,Requesting_Dept_Name,RqVehStage,Design_Status);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* Request_Domain,char* Test_Request_Nos,char* Business_Unit,char* WBS_Description,char* WBS,char* Metallurgy_report,char* QA_Inspection_report,char* Partys_Test_Report,char* Samples_Peripherals_Given,char* Desciption_of_Component,char* Background_History,char* Project,char* Project_Description,char* Program,char* Investigation_Reason,char* Requesting_Dept_Name,char* RqVehStage,char* Design_Status)
{
	int				i 							= 0;
	int				j 							= 0;
	int				count 						= 0;
	int				count_status				= 0;

	//int PorjectCode = atoi(Project);
	
	tag_t			test_request_tag			= NULLTAG;
	tag_t			*status_list				= NULL;
	tag_t			testRequestRevTag			= NULL;
	
	char			*status_name				= NULL;
	
	char			*rev_id						= NULL;

	printf("\nIn Update properties function\n.");
	
	ITK_CALL(ITEM_find_item (Test_Request_Nos, &test_request_tag));

	ITK_CALL(ITEM_ask_latest_rev (test_request_tag,&testRequestRevTag));

	
	
	//ITK_set_bypass(true);
    ITK_CALL(AOM_refresh(testRequestRevTag,1));

	// Settting all TR properties
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqDomain",Request_Domain));
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_BU",Business_Unit));
	
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_WbsDesc",WBS_Description));
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_WBS",WBS));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqChkMetRep",Metallurgy_report));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqChkQaRep",QA_Inspection_report));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqChkPartyRep",Partys_Test_Report));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_SamplPeriGvn",Samples_Peripherals_Given));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_DescComp",Desciption_of_Component));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqBGHistory",Background_History));
		
	ITK_CALL(AOM_UIF_set_value(testRequestRevTag,"t5_RqProjCode",Project));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqProjDes",Project_Description));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqProgram",Program));
		
	ITK_CALL(AOM_UIF_set_value(testRequestRevTag,"t5_RqInvType",Investigation_Reason));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqReqDep",Requesting_Dept_Name));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqVehStage",RqVehStage));
		
	ITK_CALL(AOM_set_value_string(testRequestRevTag,"t5_RqDesStatus",Design_Status));

	ITK_CALL(AOM_save(testRequestRevTag));
	ITK_CALL(AOM_refresh(testRequestRevTag,0));
	
	printf("\nProperties are updated.\n");

	//MEM_free(status_list);
	//MEM_free(rev_id);
	//MEM_free(rev_list);
	

	return ifail;
}
