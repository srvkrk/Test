#include <time.h>
#include <stdio.h>
#include <string.h>


int main() {

       FILE		*output 					= NULL;
	   char		Data[100]					= "";
	   char		outputFile[200]				= "";
	   char		command[250];
	   char		fileNameInitial[100];

	   time_t 	now;
	   struct 	tm when;
	
	   time(&now);
	   when = *localtime(&now);
	
	   strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	   printf("Data %s\n",Data);
	   strcpy(fileNameInitial,Data);

	   sprintf(outputFile,"%s_output.txt",Data);


	   output = fopen(outputFile, "a");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
			printf("File opened successfully.\n");
		}

		fprintf(output,"%s\n","This is the file created using program.");

		printf("outputFile:-  %s\n",outputFile);

		sprintf(command,"/user/testcmi/devgroups/Kirtikumar/test_send_mail/dbk_sample.sh /user/testcmi/devgroups/Kirtikumar/test_send_mail/% s > myoutput.out &",outputFile);
		system(command);

		printf("command :- %s\n",command);
		//system("bash sample.sh 15_Mar_2022_09_46_29_output.txt Hi Hello");
		//

		fclose(output);

       return 0;
}
