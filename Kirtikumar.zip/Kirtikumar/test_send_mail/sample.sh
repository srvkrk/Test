. /user/testcmi/.bash_profile
cd /user/testcmi/devgroups/Kirtikumar/test_send_mail
echo "File Name : $1"
echo "In shell"
cat $1
