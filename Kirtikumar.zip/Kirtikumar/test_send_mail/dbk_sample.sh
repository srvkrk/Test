. /user/testcmi/.bash_profile
echo "hello" 
cat $1
