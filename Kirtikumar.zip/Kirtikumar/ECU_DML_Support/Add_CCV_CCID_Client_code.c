	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	tag_t *attachments	   = NULLTAG;
	tag_t DMLRevTag	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;

	char* parent_name=NULL;
	char* dmlNo=NULL;
	char* dmlProj=NULL;
	char * username			= NULL;
	char * object_type			= NULL;
	tag_t	HasNewCCIDRel		    = NULLTAG;
	tag_t	HasMemCCIDRel		    = NULLTAG;
	tag_t	CCVCHasECUModRel		    = NULLTAG;

	int AttachmentCount=0;
	int Dml_cnt=0,t=0,count=0;
	
	char* VCItemRevId = NULL;
	char* VCItemId =NULL;
	tag_t CCvcItemRevTag =NULLTAG;
	char* CCvcItemRevID =NULL;



	int status;
	tag_t			item_tag					= NULLTAG;
	tag_t			*rev_list					= NULL;


	ITK_CALL(POM_get_user_id (&username));
	printf("\n Add_ECU_Module_Veh Session User is : %s\n",username); fflush(stdout);

	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
	CHECK_FAIL;	

	if(count > 0)
	{
		char* DML_No=NULL;

		AOM_ask_value_string(rev_list[0],"object_type",&object_type);
		printf("\n object_type is :%s\n",object_type);fflush(stdout);

		AOM_ask_value_string(rev_list[0],"item_id",&DML_No);
		printf("\n DML_No is :%s\n",DML_No);fflush(stdout);

		if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
		{
			DMLRevTag = rev_list[0];

			tag_t*	Dml_ccids		    = NULL;
			int Dml_ccid=0,ic=0;
			ITK_CALL(GRM_find_relation_type("T5_HasNewCCID", &HasNewCCIDRel));
			ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,HasNewCCIDRel,&Dml_ccid,&Dml_ccids));

			printf("\n  validation Dml_ccid count is : [%d] \n",Dml_ccid);fflush(stdout);

			for (ic=0;ic<Dml_ccid;ic++)
			{
				tag_t*	EcuMods		    = NULL;

				int EcuModCnt=0;
				tag_t	CCid		    = NULLTAG;
				CCid=	Dml_ccids[ic];
				char* CCID_No=NULL;

				AOM_ask_value_string(CCid,"item_id",&CCID_No);
				printf("\n CCID_No is :%s\n",CCID_No);fflush(stdout);

				ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID", &HasMemCCIDRel));
				ITK_CALL(GRM_list_primary_objects_only(CCid,HasMemCCIDRel,&EcuModCnt,&EcuMods));
				if (EcuModCnt >0)
				{
					tag_t EcuItem		   = NULLTAG;
					ITK_CALL(ITEM_ask_item_of_rev(EcuMods[0],&EcuItem)); //T5_CCVCHasECUModule
					if (EcuItem)
					{
						char* EcuItem_No=NULL;
						AOM_ask_value_string(EcuItem,"item_id",&EcuItem_No);
						printf("\n EcuItem_No is :%s\n",EcuItem_No);fflush(stdout);

						int CCvcCnt=0,iCCvc=0;
						tag_t*	CCvcS		    = NULL;
						ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule", &CCVCHasECUModRel));
						ITK_CALL(GRM_list_primary_objects_only(EcuItem,CCVCHasECUModRel,&CCvcCnt,&CCvcS));
						for (iCCvc=0;iCCvc<CCvcCnt;iCCvc++)
						{
							
							tag_t CCvcItem		   = NULLTAG;
							
							ITK_CALL(AOM_ask_value_string(CCvcS[iCCvc],"item_id",&VCItemId));
							printf("\n VCItemId is :%s\n",VCItemId);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(CCvcS[iCCvc],"item_revision_id",&VCItemRevId));
							printf("\n VCItemRevId is :%s\n",VCItemRevId);fflush(stdout);

							ITK_CALL(ITEM_ask_item_of_rev(CCvcS[iCCvc],&CCvcItem));

							ITK_CALL(ITEM_ask_latest_rev(CCvcItem,&CCvcItemRevTag));

							ITK_CALL(AOM_ask_value_string(CCvcItemRevTag,"item_revision_id",&CCvcItemRevID));
							printf("\n Latest CCvcItemRevID is :%s\n",CCvcItemRevID);fflush(stdout);

							if(strcmp(CCvcItemRevID,VCItemRevId)==0)
						    {
								printf("\n\t Latest CCVc Rev Found and need to process");fflush(stdout);

								if (CCvcItem)
								{
									char* CCvcItem_No=NULL;
									tag_t RefCCVC		   = NULLTAG;
									AOM_ask_value_string(CCvcItem,"item_id",&CCvcItem_No);
									printf("\n CCvcItem_No is :%s\n",CCvcItem_No);fflush(stdout);

									tag_t	Rel_tag		    = NULLTAG;
									ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV", &RefCCVC));
									ITK_CALL(GRM_find_relation(CCid, CCvcItem,RefCCVC,&Rel_tag));

									if (Rel_tag)
									{
										printf("\n  Relation already exist between CCID and CCVC [%s] [%s]",CCID_No,CCvcItem_No);fflush(stdout);
									}
									else
									{
										//tag_t  relation=NULLTAG;
										//ITK_CALL(GRM_create_relation(CCid,CCvcItem, RefCCVC, NULLTAG, &relation));
										printf("\n GRM_create_relation ---->[%s] [%s]",CCID_No,CCvcItem_No);fflush(stdout);
										//ITK_CALL(GRM_save_relation(relation));
										//printf("\n GRM_save_relation ---->[%s] [%s]",CCID_No,CCvcItem_No);fflush(stdout);
									}
								}
							}
							else
							{
								printf("\n Attach CCVC is not requried, as reference rev is not latest.");fflush(stdout);
							}

							
						}

					}
				}
			}
		}	
	}

	return ifail;
}
