	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int createVCIDForCV(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* vhNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	vhNo 			= ITK_ask_cli_argument("-vhNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(vhNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = createVCIDForCV(vhNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int createVCIDForCV(char* vhNo)
{
	int ifail = ITK_ok;
	int status = 0;

	tag_t			VhTag							= NULLTAG;
	tag_t			letestVhRev						= NULLTAG;
	tag_t			HasECUCalibrationModule		    = NULLTAG;
	tag_t			*ECUMOduleTag		    = NULLTAG;


	tag_t			isMemOfVCID = NULLTAG;

	char * object_type			= NULL;
	char*  VH_No=NULL;
	int		RefCVVCount				= 0;
	int		i						= 0;

	ifail = ITEM_find_item (vhNo, &VhTag);
	CHECK_FAIL;

	ifail = ITEM_ask_latest_rev (VhTag, &letestVhRev);
	CHECK_FAIL;

	AOM_ask_value_string(letestVhRev,"object_string",&VH_No);
	printf("\n VH_No is :%s\n",VH_No);fflush(stdout);
	
	AOM_ask_value_string(letestVhRev,"object_type",&object_type);
	printf("\n object_type is :%s\n",object_type);fflush(stdout);

	ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule", &HasECUCalibrationModule));
	ITK_CALL(GRM_list_secondary_objects_only(letestVhRev,HasECUCalibrationModule,&RefCVVCount,&ECUMOduleTag));

	ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID", &isMemOfVCID));

	if(RefCVVCount > 0)
	{
		for(i =0 ;i < RefCVVCount;i ++)
		{
			tag_t	  temECUMod		= NULLTAG;
			tag_t ECUModLetstRev = NULLTAG;
			char* ecuModobjStr  =  NULL;
			tag_t VIDCreateTag  = NULL;

			tag_t newRelation = NULLTAG;

			tag_t object = NULL;

			tag_t newlyCreatedVCIDTag = NULLTAG;

			tag_t item_create_input_tag = NULLTAG;
			tag_t LatestVCIDRevTag = NULLTAG;

			temECUMod = ECUMOduleTag[i];

			ifail = ITEM_ask_latest_rev (temECUMod, &ECUModLetstRev);
			CHECK_FAIL;
		
			AOM_ask_value_string(ECUModLetstRev,"object_string",&ecuModobjStr);
			printf("\n ECU Module Object String is  :%s\n",ecuModobjStr);fflush(stdout);

			//Creation of VCID

			ITK_CALL(TCTYPE_find_type("T5_CCID", "Item", &VIDCreateTag));
			ITK_CALL(TCTYPE_construct_create_input(VIDCreateTag, &item_create_input_tag));
			ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", "0001233668"));
			//ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_revision_id", "A;1"));
			ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", "Initial VCID"));
			ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
			ITK_CALL(AOM_save (object));


			ifail = ITEM_find_item ("0001233668", &newlyCreatedVCIDTag);
			ifail = ITEM_ask_latest_rev (newlyCreatedVCIDTag, &LatestVCIDRevTag);
		
			ITK_CALL(AOM_set_value_string(LatestVCIDRevTag, "item_revision_id", "A;1"));
			ITK_CALL(AOM_save (LatestVCIDRevTag));

			ITK_CALL(AOM_refresh(ECUModLetstRev,1));
			ITK_CALL(GRM_create_relation(ECUModLetstRev, LatestVCIDRevTag, isMemOfVCID, NULLTAG,&newRelation));
			ITK_CALL(GRM_save_relation(newRelation));
			ITK_CALL(AOM_save(ECUModLetstRev));
			ITK_CALL(AOM_refresh(ECUModLetstRev,0));
			printf("\n\t ****Relation is created with ECU MODULE  and Latest VCID revision.*****\n");fflush(stdout);



		}
	}
	else
	{
		printf("\n Given Vehicle does not have ECU Module.");fflush(stdout);
	}


	return ifail;
}
