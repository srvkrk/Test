	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;




void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* proj_code						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	proj_code 			= ITK_ask_cli_argument("-proj_code=");

	tag_t	ProQryContObj			 = NULLTAG;
	int		n_Input					 = 2;
	tag_t *ProjCnObj				 = NULL;
	int    ProjCount				 = 0;
	char	*info1					 = NULL;
	char* useInfo1 =NULL;
	char* useInfo2 =NULL;
	char* useInfo3 =NULL;
	char* useInfo4 =NULL;
	char* useInfo5 =NULL;
	char* useInfo6 =NULL;
	char* useInfo7 =NULL;
	char* useInfo8 =NULL;
	char* useInfo9 =NULL;
	char* useInfo10 =NULL;

	char *usrinfoAllStr		=NULL;

	int status = 0;
		
	char	*qry_Input[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_ProjVal[2] = {"CCID", "PROJCT"};
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 )
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	//Code Starts: 

	int i= 0;

	

	if(QRY_find2("ControlObjQry", &ProQryContObj));
	if(ProQryContObj)
	{
		if(QRY_execute(ProQryContObj, n_Input, qry_Input, qry_ProjVal, &ProjCount, &ProjCnObj));
		printf("\n CONT Objects for CCID == %d", ProjCount);fflush(stdout);
	}
	else
	{
		printf("\n ContrlObj not found for CCID");fflush(stdout);
	}

	if(ProjCount >0)
	{
		usrinfoAllStr = (char *) MEM_alloc(5000 * sizeof(char *));

		for(i =0; i < ProjCount ;i++)
		{

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo1",&useInfo1));
			printf("\n\t useInfo1 string value: %s",useInfo1);

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo2",&useInfo2));
			printf("\n\t useInfo2 string value: %s",useInfo2);

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo3",&useInfo3));
			printf("\n\t useInfo3 string value: %s",useInfo3);

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo4",&useInfo4));
			printf("\n\t useInfo4 string value: %s",useInfo4);

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo5",&useInfo5));
			printf("\n\t useInfo5 string value: %s",useInfo5);

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo6",&useInfo6));
			printf("\n\t useInfo6 string value: %s",useInfo6);

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo7",&useInfo7));
			printf("\n\t useInfo7 string value: %s",useInfo7);

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo8",&useInfo8));
			printf("\n\t useInfo8 string value: %s",useInfo8);

			(AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo9",&useInfo9));
			printf("\n\t useInfo9 string value: %s",useInfo9);

			(AOM_ask_value_string(ProjCnObj[i],"t5_userinfo10",&useInfo10));
			printf("\n\t useInfo10 string value: %s",useInfo10);

			if(tc_strstr(useInfo1,proj_code)!=NULL || tc_strstr(useInfo2,proj_code)!=NULL || tc_strstr(useInfo3,proj_code)!=NULL || tc_strstr(useInfo4,proj_code)!=NULL || tc_strstr(useInfo5,proj_code)!=NULL || tc_strstr(useInfo6,proj_code)!=NULL ||
				tc_strstr(useInfo7,proj_code)!=NULL || tc_strstr(useInfo8,proj_code)!=NULL || tc_strstr(useInfo9,proj_code)!=NULL || tc_strstr(useInfo10,proj_code)!=NULL )
			{
				printf("\n CCID Project matches\n"); fflush(stdout);
				//CheckFlag=1;
				break;
			}
		
		}
	}
	

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


