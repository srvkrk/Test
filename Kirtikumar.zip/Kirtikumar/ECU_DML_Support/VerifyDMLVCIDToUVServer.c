	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
char* removeUnwantedChar(char*,char*);
int CreateDataforVCIDCheck(char*,int,tag_t*);
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dml						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dml 			= ITK_ask_cli_argument("-dml=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dml)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	
	//ifail = read_value_from_file(file);
	
	ifail = check_rel_status(dml);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				//printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	tag_t *attachments	   = NULLTAG;
	tag_t DMLRevTag		   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	tag_t DMLToTaskRel	   = NULLTAG;
	tag_t* Tsk_objects	   = NULLTAG;
	tag_t part_tsk_rel	   = NULLTAG;

	char* parent_name=NULL;
	char* dmlNo=NULL;
	char* dmlProj=NULL;
	char * username			= NULL;
	char * object_type		= NULL;
	char* Taskobject_type	= NULL;
	char* taks_id			= NULL;
	char* dmlReltype		= NULL;

	tag_t	HasNewCCIDRel		    = NULLTAG;
	tag_t	HasMemCCIDRel		    = NULLTAG;
	tag_t	CCVCHasECUModRel		    = NULLTAG;
	tag_t* PartsTag						= NULLTAG;

	int AttachmentCount=0;
	int Dml_cnt=0,t=0,count=0,m=0;;
	int tsk_cnt = 0; 
	int partcnt =0;
	
	char* VCItemRevId = NULL;
	char* VCItemId =NULL;
	tag_t CCvcItemRevTag =NULLTAG;
	char* CCvcItemRevID =NULL;

	FILE	*fptr1;
	char	*FileName				= NULL;



	int status;
	tag_t			item_tag					= NULLTAG;
	tag_t			*rev_list					= NULL;


	ITK_CALL(POM_get_user_id (&username));
	//printf("\n Add_ECU_Module_Veh Session User is : %s\n",username); fflush(stdout);

	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
	CHECK_FAIL;	

	if(count > 0)
	{
		char* DML_No=NULL;

		AOM_ask_value_string(rev_list[0],"object_type",&object_type);
		//printf("\n object_type is :%s\n",object_type);fflush(stdout);

		AOM_ask_value_string(rev_list[0],"item_id",&DML_No);
		//printf("\n DML_No is :%s\n",DML_No);fflush(stdout);
		AOM_ask_value_string(rev_list[0],"t5_rlstype",&dmlReltype);
		printf("\n dmlReltype is :%s\n",dmlReltype);fflush(stdout);

		if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
		{
			DMLRevTag = rev_list[0];

			tag_t*	Dml_ccids		    = NULL;
			int Dml_ccid=0,ic=0;
			ITK_CALL(GRM_find_relation_type("T5_HasNewCCID", &HasNewCCIDRel));
			ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,HasNewCCIDRel,&Dml_ccid,&Dml_ccids));
			printf("\n  Dml_ccid count is : [%d] \n",Dml_ccid);fflush(stdout);
			
			if(Dml_ccid > 0)
			{
				if((tc_strcmp(dmlReltype,"EP")==0) || (tc_strcmp(dmlReltype,"BKC")==0))
				{
					printf("\n Calling...CreateDataforVCIDCheck \n");
					CreateDataforVCIDCheck(DML_No,Dml_ccid,Dml_ccids);
				}
				
			}
			
			// For VCID update DML :
			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
			ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects));
			for (m=0;m<tsk_cnt ;m++ )
			{
				ITK_CALL(AOM_ask_value_string(Tsk_objects[m],"object_type",&Taskobject_type));
			   	printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);
				if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(Tsk_objects[m],"item_id",&taks_id));
			   		printf("\n taks_id is :%s\n",taks_id);fflush(stdout);
					
					if(tc_strstr(taks_id,"_16")!=NULL)
					{
						ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
						ITK_CALL(GRM_list_secondary_objects_only(Tsk_objects[m], part_tsk_rel, &partcnt, &PartsTag));
						printf("\n  partcnt.:%d\n",partcnt);fflush(stdout);

						if(partcnt >0 ) 
						{
							if(tc_strcmp(dmlReltype,"CCU")==0)
							{
								printf("\n Calling...CreateDataforVCIDCheck \n");
								CreateDataforVCIDCheck(DML_No,partcnt,PartsTag);
							}
							
						}
						
					}
				}

			}

			
		}	
	}

	return ifail;
}

int CreateDataforVCIDCheck(char* dmlNo,int vcidCount,tag_t* vcidTags)
{
	FILE	*fptr1;
	char	*FileName				= NULL;
	int ic =0;

	FileName =(char *) MEM_alloc(150);
	printf("\n CREATING CSV  \n");fflush(stdout);

	tc_strcpy(FileName,"/tmp/");
	tc_strcat(FileName,dmlNo);
	tc_strcat(FileName,"_DataChk.csv");

	fptr1 = fopen(FileName,"w");
	if(fptr1==NULL)
	{
		printf("Error! in File opening...%s",FileName);  fflush(stdout);
		return 1;
		//exit(1);
	}
	for (ic=0;ic<vcidCount;ic++)
	{
				tag_t*	EcuMods				= NULL;

				int EcuModCnt=0;
				tag_t	CCid				= NULLTAG;
				tag_t RefCVVRel		   = NULLTAG;

				int secObjCount			= 0;
				tag_t * secObjTag		= NULLTAG;

				CCid=	vcidTags[ic];
				char* CCID_No=NULL;
				char* CCID_item_id			= NULL;
				char* CCID_item_revision_id	= NULL;
				char* finalCCID_itemID		= NULL;
				char* finalCCID_RevSeq		= NULL;
				char* seprator1				="_";
				char* seprator2				=";";

				char IsRefCVVAvl[17]			="Ref_CVV";
				char IsRefCVVNotAvl[21]			="No_Ref_CCV";

				AOM_ask_value_string(CCid,"item_id",&CCID_item_id);
				//printf("\n CCID item_id is :%s\n",CCID_item_id);fflush(stdout);

				AOM_ask_value_string(CCid,"item_revision_id",&CCID_item_revision_id);
				//printf("\n CCID item_revision_id is :%s\n",CCID_item_revision_id);fflush(stdout);

				GRM_find_relation_type("T5_ReferencesCCV", &RefCVVRel);
				GRM_list_secondary_objects_only(CCid,RefCVVRel,&secObjCount,&secObjTag);

				

				finalCCID_itemID		= (char *) MEM_alloc( 20 * sizeof(char) );
				finalCCID_RevSeq		= (char *) MEM_alloc( 10 * sizeof(char) );

				finalCCID_itemID = removeUnwantedChar(CCID_item_id,seprator1);
				finalCCID_RevSeq = removeUnwantedChar(CCID_item_revision_id,seprator2);

				printf("\n finalCCID_itemID :%s\n",finalCCID_itemID);fflush(stdout);
				printf("\n finalCCID_RevSeq :%s\n",finalCCID_RevSeq);fflush(stdout);
				printf("\n Total No. of Ref CVV found :%d\n",secObjCount);fflush(stdout);
				

				if(secObjCount > 0)
				{
					printf("\n IsRefCVVAvl :%s\n",IsRefCVVAvl);fflush(stdout);
					fprintf(fptr1,"%s,%s,%s \n",finalCCID_itemID,finalCCID_RevSeq,IsRefCVVAvl);fflush(fptr1);
				}
				else
				{
					printf("\n IsRefCVVNotAvl :%s\n",IsRefCVVNotAvl);fflush(stdout);
					fprintf(fptr1,"%s,%s,%s \n",finalCCID_itemID,finalCCID_RevSeq,IsRefCVVNotAvl);fflush(fptr1);
				}

	}

	fclose(fptr1);
	return 0;
}

char* removeUnwantedChar(char* Input_Str,char* seprator)
{
	int i, j, fsl, ssl, temp, chk = 0;

	fsl = strlen(Input_Str);
	ssl = strlen(seprator);
	

	//printf("\n Input_Str :%s\n",Input_Str);fflush(stdout);
	//printf("\n seprator :%s\n",seprator);fflush(stdout);

	for (i = 0; i < fsl; i++) {
    temp = i;
    for (j = 0; j < ssl; j++) {
      if (Input_Str[i] == seprator[j])
        i++;
    }
    chk = i - temp;
    if (chk == ssl) {
      i = temp;
      for (j = i; j < (fsl - ssl); j++)
        Input_Str[j] = Input_Str[j + ssl];
      fsl = fsl - ssl;
      Input_Str[j] = '\0';
    }
  }
  
  /*Finally, printing the result. */
  //printf("\nNew String = %s", Input_Str);

  return Input_Str;

}