	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int AddRemovePartss(char*,char*,char*);
int addPartsToSnapShot(char*,char*,char*);
void parseGivenString(const char* ,char** ,char** ,char** );

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 						= NULL;
	char			* password						= NULL;
	char			* group							= NULL;
	char			* file_vcid						= NULL;
	char			* file_part1					= NULL;
	char			* file_part2					= NULL;

	char			Data[100]						= "";
	char			outputFile[200]					= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file_vcid 		= ITK_ask_cli_argument("-file_vcids=");
	file_part1 		= ITK_ask_cli_argument("-file_part1=");
	file_part2 		= ITK_ask_cli_argument("-file_part2=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 )
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = AddRemovePartss(file_vcid,file_part1,file_part2);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int AddRemovePartss(char* file_vcid,char* file_part1,char* file_part2)
{
	int ifail = ITK_ok;

	char 			temp[200];
	char 			*vcId				= NULL;

	FILE* fp1 = NULL;
	FILE* fp2 = NULL;
	FILE* fp3 = NULL;

	fp1 = fopen(file_vcid,"r");
	//fp2 = fopen(file_part1,"r");
	//fp3 = fopen(file_part2,"r");

	if (fp1 != NULL)
	{
		while (fgets(temp, 200, fp1)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				vcId = strtok(temp, " ");
				//printf("\nInput VCID:%s",vcId);
				
				ifail = addPartsToSnapShot(vcId,file_part1,file_part2);

				printf("**************************^^^^^^^^^^^^^^^************************************\n");
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}

	return ifail;
}
int addPartsToSnapShot(char* vcid,char* file1,char* file2)
{
	int				ifail = ITK_ok;
	char 			temp1[200];
	char 			temp2[200];
	int status =0;

	tag_t vcid_tag = NULLTAG;
	int count =0;
	int snapShotCout = 0;

	tag_t vcidRevtag = NULLTAG;
	tag_t vcIDrevTag = NULLTAG;
	tag_t	HasSnapshotType = NULLTAG;
	tag_t *snapShotTag = NULL;
	char* vcidRevObjStr = NULL;

	tag_t addPartTag = NULLTAG;
	tag_t removePartTag = NULLTAG;

	char* token1 = NULL;
	char* token2 = NULL;
	char* token3 = NULL;
	char* tempRevSeq = NULL;

	char* AddPart	 = NULL;
	char* RemovePart = NULL;

	char* addPartObjstr = NULL;
	char* removePartStrt = NULL;

	char* ErrorText = NULL;

	FILE* fp1		= NULL;
	FILE* fp2		= NULL;

	fp1 = fopen(file1,"r");
	fp2 = fopen(file2,"r");

	//Getting Tag of VCID

	//ifail = ITEM_find_rev(vcid,);

	//printf("vcid  : %s",vcid);

	parseGivenString(vcid,&token1,&token2,&token3);

	tempRevSeq=(char *)MEM_alloc(5);

	tc_strcpy(tempRevSeq,"");
	tc_strcat(tempRevSeq,token2);
	tc_strcat(tempRevSeq,";");
	tc_strcat(tempRevSeq,token3);

	if(token1 != NULL && token2 !=NULL && token3 != NULL)
	{
		//printf("token1  : %s\n",token1);
		//printf("token2  : %s\n",token2);
		//printf("token3  : %s\n",token3);

		//Getting Tag of VCID
		ifail = ITEM_find_rev(token1,tempRevSeq,&vcIDrevTag);
		if(vcIDrevTag)
		{
			if(AOM_ask_value_string(vcIDrevTag,"object_string",&vcidRevObjStr)==ITK_ok);
			printf("vcidRevObjStr  = [%s]\n", vcidRevObjStr);fflush(stdout);

			ifail = (GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
			ifail = (GRM_list_secondary_objects_only(vcIDrevTag, HasSnapshotType, &snapShotCout, &snapShotTag));//3 sept
			printf("snapShotCout %d \n",snapShotCout);fflush(stdout);

			//Here Need to add required parts and remove parts as we have snapshot Tag
			//Add:: 
			if (fp1 != NULL)
			{
				while (fgets(temp1, 1000, fp1)!= NULL)
				{
					tc_strcpy(temp1,stripBlanks(temp1));

					if (tc_strlen(temp1) > 0 && tc_strcmp(temp1, NULL) != 0)
					{
						AddPart = strtok(temp1, " ");
						printf("\n****AddPart:%s\n",AddPart);
						//Logic for add::
						char* AddPartTok1 = NULL;
						char* AddPartTok2 = NULL;
						char* AddPartTok3 = NULL;
						char* tempAddPartRevSeq  = NULL;
						
						parseGivenString(AddPart,&AddPartTok1,&AddPartTok2,&AddPartTok3);

						tempAddPartRevSeq=(char *)MEM_alloc(5);

						tc_strcpy(tempAddPartRevSeq,"");
						tc_strcat(tempAddPartRevSeq,AddPartTok2);
						tc_strcat(tempAddPartRevSeq,";");
						tc_strcat(tempAddPartRevSeq,AddPartTok3);


					 	ifail = ITEM_find_rev(AddPartTok1,tempAddPartRevSeq,&addPartTag);
						
						if(addPartTag)
						{
							if(AOM_ask_value_string(addPartTag,"object_string",&addPartObjstr)==ITK_ok);
							printf("addPartObjstr  = [%s]\n", addPartObjstr);fflush(stdout);

							printf("\nkk.Part to be Add is : [%s]\n",AddPart);fflush(stdout);

							ITK_CALL(AOM_lock(snapShotTag[0]));
							ifail = (FL_insert(snapShotTag[0],addPartTag,999));
							if(ifail != ITK_ok)
							{
								//printf("\nErrorText :::: [Error in adding part in Snapshot]\n\n");fflush(stdout);
								EMH_ask_error_text(ifail,&ErrorText);
								printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);
							}
							
							ITK_CALL(AOM_save(snapShotTag[0]));
							ITK_CALL(AOM_refresh(snapShotTag[0],0));
							ITK_CALL(AOM_unlock(snapShotTag[0]));


						}
						

						
						
					}			
					tc_strcpy(temp1, "");
				}
			}
			else 
			{
				printf("File Unable to Open...!!");
			}
			// Remove :

			if (fp2 != NULL)
			{
				while (fgets(temp2, 1000, fp2)!= NULL)
				{
					tc_strcpy(temp2,stripBlanks(temp2));

					if (tc_strlen(temp2) > 0 && tc_strcmp(temp2, NULL) != 0)
					{
						RemovePart = strtok(temp2, " ");
						printf("\n*******RemovePart:%s \n",RemovePart);
						// Logic for remove ::

						char* RemovePartTok1 = NULL;
						char* RemovePartTok2 = NULL;
						char* RemovePartTok3 = NULL;
						char* tempRemovePartRevSeq  = NULL;


						
						parseGivenString(RemovePart,&RemovePartTok1,&RemovePartTok2,&RemovePartTok3);

						printf("RemovePartTok1  : %s\n",RemovePartTok1);
						printf("RemovePartTok2  : %s\n",RemovePartTok2);
						printf("RemovePartTok3  : %s\n",RemovePartTok3);

						tempRemovePartRevSeq=(char *)MEM_alloc(5);

						tc_strcpy(tempRemovePartRevSeq,"");
						tc_strcat(tempRemovePartRevSeq,RemovePartTok2);
						tc_strcat(tempRemovePartRevSeq,";");
						tc_strcat(tempRemovePartRevSeq,RemovePartTok3);


					 	ifail = ITEM_find_rev(RemovePartTok1,tempRemovePartRevSeq,&removePartTag);
						
						if(removePartTag)
						{
							if(AOM_ask_value_string(removePartTag,"object_string",&removePartStrt)==ITK_ok);
							printf("removePartStrt  = [%s]\n", removePartStrt);fflush(stdout);


							ITK_CALL(AOM_lock(snapShotTag[0]));
							ifail = (FL_remove(snapShotTag[0],removePartTag));
							if(ifail != ITK_ok)
							{
								//printf("\nErrorText :::: [Error in removing part in Snapshot]\n\n");fflush(stdout);
								EMH_ask_error_text(ifail,&ErrorText);
								printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);
							}
							
							ITK_CALL(AOM_save(snapShotTag[0]));
							ITK_CALL(AOM_refresh(snapShotTag[0],0));
							ITK_CALL(AOM_unlock(snapShotTag[0]));


						}	
						
					}			
					tc_strcpy(temp2, "");
				}
			}
			else 
			{
				printf("File Unable to Open...!!");
			}

			
		}
		else
		{
			printf("Input VCID is not found !!");
		}
		

	}


	return ifail;

}
void parseGivenString(const char* input,char** tok1,char** tok2,char** tok3)
{
	//printf("I am in String Parsing function \n");
	//printf("input %s\n",input);

	const char* slashPos = strchr(input,'/');
	const char* semiColonPos = strchr(input,';');

	//printf("slashPos %s\n",slashPos);
	//printf("semiColonPos %s\n",semiColonPos);

	

	if(slashPos == NULL || semiColonPos == NULL )
	{
		*tok1 = *tok2 = *tok3 = NULL;
		return;
	}

	size_t tokenLen1	= slashPos - input;
	size_t tokenLen2	= semiColonPos - (slashPos + 1);
	size_t tokenLen3	= strlen(semiColonPos +1);

	*tok1	=(char *) MEM_alloc(tokenLen1 + 1);
	*tok2	=(char *) MEM_alloc(tokenLen2 + 1);
	*tok3	=(char *) MEM_alloc(tokenLen3 + 1);

	strncpy(*tok1,input,tokenLen1);
	(*tok1)[tokenLen1] = '\0';

	strncpy(*tok2,slashPos + 1,tokenLen2);
	(*tok2)[tokenLen2] = '\0';

	strncpy(*tok3,semiColonPos + 1 ,tokenLen3);
	(*tok3)[tokenLen3] = '\0';



}