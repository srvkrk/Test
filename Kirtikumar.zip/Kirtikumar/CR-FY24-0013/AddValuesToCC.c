#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 500
#define NUMWORDS 11

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;


	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = read_value_from_file(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[350];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 350, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				//item_id = strtok(temp, ",");
				item_id = strtok(temp, "#");
				//printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	//fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    
********************************************************************************************/
int check_rel_status(char* item_id)
{


	char *archCCNode = (char *) MEM_alloc( 2000 * sizeof(char) );
	char *option = (char *) MEM_alloc( 2000 * sizeof(char) );
	char *value = (char *) MEM_alloc( 2000 * sizeof(char) );

	char *token		  = NULL;
	char data[NUMWORDS][STRSIZE];
	char *buffer;
    int i;

	char		    *qry_entries[2]			= {"Name","Type"};

	char		    **qry_values			= (char **) MEM_alloc(2000 * sizeof(char *));
	char		    **qry_valuesForOptValue			= (char **) MEM_alloc(2000 * sizeof(char *));
	int		          resultCount			= 0;
	int		          resultCountOptValue			= 0;
	tag_t		      queryTag				= NULLTAG;
	tag_t		     *outPutValues			= NULLTAG;
	tag_t		     *outPutValuesOpt			= NULLTAG;
	int				  n_entries				= 2;
	char*			optionAkaFamilyName     = NULL;
	tag_t			archCCNodetag			= NULLTAG;
	char*			ccNodeName				= NULL;
	char*			optValueName			= NULL;
	tag_t			optValuesFamilyNameTag		= NULL;
	char*			optValuesFamilyName		= NULL;
	int  			number_of_types;
	int  			number_of_typesV;
	int				i1						=	0;

	
	tag_t * 	type_tag4;
	tag_t * 	type_tag4V;
	tag_t object_create_input_tag			= NULLTAG;
	tag_t object_create_input_tagV			= NULLTAG;
	tag_t new_object						= NULLTAG;
	tag_t new_objectValue						= NULLTAG;

	printf("\n\tInput is: %s\n\t",item_id);

	buffer = strtok(item_id, ";");
	i = 0;
	 while (buffer != NULL) {
        strcpy(data[i], buffer);

        //printf("data[%i] = %s\n\t", i+1, data[i]);
        buffer = strtok(NULL, ";");
        i++;
    }

	tc_strcpy(archCCNode, data[0]);
	tc_strcpy(option, data[1]);
	tc_strcpy(value, data[2]);

	printf("\n\t ArchCCNode :%s", archCCNode);
    printf("\n\t Option :%s", option);
	printf("\n\t Value :%s\n\n", value);

	
	//Getting TAG of CC
	ifail = ITEM_find_item (archCCNode, &archCCNodetag);
	
	if(archCCNodetag != NULLTAG)
	{
			ITK_CALL(AOM_ask_value_string(archCCNodetag,"object_name",&ccNodeName));
			printf("\n\tccNodeName : =%s \n\n",ccNodeName);fflush(stdout);
			//ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);

			qry_values[0] = option;
			qry_values[1] = "Family";
			QRY_find("General...", &queryTag);
			if (queryTag) 
			{
				printf("\n\t Found Query \n\n");fflush(stdout);
			}
			else 
			{
				printf("\n\t Not Found Query\n");fflush(stdout);
				return -1;
			}

			if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&outPutValues));
			if(resultCount > 0) 
			{
				ITK_CALL(AOM_ask_value_string(outPutValues[0],"object_name",&optionAkaFamilyName));
				printf("\n\t *******optionAkaFamilyName********** : =%s \n\n",optionAkaFamilyName);fflush(stdout);

		//		//Adding OptionAkaFamily to CC node.

//				ITK_CALL(TCTYPE_find_types_for_class("Cfg0Allocation",&number_of_types,&type_tag4));
//				ITK_CALL(TCTYPE_construct_create_input(type_tag4[0], &object_create_input_tag));
//				ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",optionAkaFamilyName));
//				ITK_CALL(AOM_set_value_string(object_create_input_tag,"cfg0ObjectId",optionAkaFamilyName));
//				ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0Target",outPutValues[0]));
//				ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0ProductItem",archCCNodetag));
//				ITK_CALL(TCTYPE_create_object(object_create_input_tag, &new_object));
//				if(new_object)
//				{
//					printf("\n t5CreateObject : object created.\n");
//					ITK_CALL(AOM_save(new_object));
//					ITK_CALL(AOM_unlock(new_object));
//				}
				
				// Getting Values for OptionAkaFamily::
				int strLength = strlen(value);

				char* tempStr = (char*)MEM_alloc (strLength + 1);
				const char delimeiter ='$';
				
				int i1 = 0;
				int j1 = 0;
				int	k1 = 0;

				for(i1 =0 ; i1<= strLength; i1++)
				{
					if(value[i1] != delimeiter && value[i1] != '\0')
					{
						tempStr[j1++] = value[i1];	
					}
					else
					{
						tempStr[j1] ='\0';
						printf("\n\t ****%s*****\n",tempStr);
						
						if(tc_strlen(tempStr) >0)
						{
							qry_valuesForOptValue[0] = tempStr;
							qry_valuesForOptValue[1] = "Feature";
							
							if(QRY_execute(queryTag,n_entries,qry_entries,qry_valuesForOptValue,&resultCountOptValue,&outPutValuesOpt));
							if(resultCountOptValue > 0)
							{
								printf("\n\t ***resultCountOptValue : =%d \n\n",resultCountOptValue);fflush(stdout);

								for(k1= 0; k1 < resultCountOptValue ;k1++)
								{
									ITK_CALL(AOM_ask_value_string(outPutValuesOpt[k1],"object_name",&optValueName));
									printf("\n\t optValueName : =%s \n\n",optValueName);fflush(stdout);

									ITK_CALL(AOM_ask_value_tag(outPutValuesOpt[k1],"cfg0Family",&optValuesFamilyNameTag));
									ITK_CALL(AOM_ask_value_string(optValuesFamilyNameTag,"object_name",&optValuesFamilyName));
									printf("\n\t optValuesFamilyName : =%s \n\n",optValuesFamilyName);fflush(stdout);
									//Adding Values to OptionAkaFamily
										
										if(tc_strstr(optValuesFamilyName,optionAkaFamilyName)!= NULL)
										{
												printf("\n\t Correct Value found for Option :: %s\n\n",optionAkaFamilyName);fflush(stdout);

												ITK_CALL(TCTYPE_find_types_for_class("Cfg0Allocation",&number_of_typesV,&type_tag4V));
												ITK_CALL(TCTYPE_construct_create_input(type_tag4V[0], &object_create_input_tagV));
							
												ITK_CALL(AOM_set_value_string(object_create_input_tagV,"object_name",optValueName));
												ITK_CALL(AOM_set_value_string(object_create_input_tagV,"cfg0ObjectId",optValueName));
												ITK_CALL(AOM_set_value_tag(object_create_input_tagV,"cfg0Target",outPutValuesOpt[k1]));
												ITK_CALL(AOM_set_value_tag(object_create_input_tagV,"cfg0ProductItem",archCCNodetag));
												ITK_CALL(TCTYPE_create_object(object_create_input_tagV, &new_objectValue));
												if(new_objectValue)
												{
													printf("\n t5CreateObject : object created. Value is added.\n");
													ITK_CALL(AOM_save(new_objectValue));
													ITK_CALL(AOM_unlock(new_objectValue));
												}
										}	

								} // for loop for Features

								
							}
							else
							{
								printf("\n\t -------***Unable to find :: Value :%s***-----------------", tempStr);
							}


						}
						j1=0;
					}
				}
				MEM_free(tempStr);
				
			}
			else
			{
				printf("\n\t -------***Unable to find :: Option :%s***-----------------", option);
			}
	}
	else
	{
		printf("\n\t -------***Unable to find :: ArchCCNode :%s", archCCNode);
				
	}

	return ifail;

}

