#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
char* getCCMailIDs(char *mail1, char *mail2, char *mail3, char *mail4, char *mail5,char *mail6,char *mail7,char *mail8,char *mail9);


//FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*,char*);
int check_rel_status(char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			timeStamp[100]					= "";
	//char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(timeStamp,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",timeStamp);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	
	ifail = read_value_from_file(file,timeStamp);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename,char* timeStamp)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\n\n\tInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id,timeStamp);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	//fclose(output);
	//remove(output);

	return ifail;
}


int check_rel_status(char* item_id, char* timeStamp)
{
	int		i 							= 0;
	int		j 							= 0;
	int		count 						= 0;
	int		count_status				= 0;
	int		participant_count_TR_Manager= 0;
	int		participant_count_TR_ChfEng = 0;
	int		participant_count_TR_VatsRev= 0;


	
	tag_t		item_tag					= NULLTAG;
	tag_t		*status_list				= NULL;
	tag_t		latest_rev					= NULL;
	
	char		*status_name				= NULL;
	char		command[512]				="";
	
	char		*tr_item_id					= NULL;
	tag_t		Patricipant_Type_TR_Manager	= NULLTAG;
	tag_t		Patricipant_Type_TR_ChfEng	= NULLTAG;
	tag_t		Patricipant_Type_TR_VatsRev	= NULLTAG;

	tag_t		*participant_list_TR_Manager= NULLTAG;
	tag_t		*participant_list_TR_ChfEng= NULLTAG;
	tag_t		*participant_list_TR_VatsRev= NULLTAG;

	char		*emailID					=NULL;
	tag_t		TR_owner					=NULLTAG;
	tag_t		TR_owner_person_tag			=NULLTAG;
	char*		person_name					=NULL;
	char*		TR_owner_email				=NULL;
	char*		error_text					=NULL;
	
	char	*CC_MailList				    = (char*)MEM_alloc(sizeof(char) * 2000);
	tag_t	queryTag;
	tag_t *CCmailIDTag;
	int n_entries								= 2;
	int	resultCount;
	char *userEntry[2]			={"Name","Type"};
	char **Value				=(char **) MEM_alloc(100 * sizeof(char *));

	char *CC_Mail1				=NULL;
	char *CC_Mail2				=NULL;
	char *CC_Mail3				=NULL;
	char *CC_Mail4				=NULL;
	char *CC_Mail5				=NULL;
	char *CC_Mail6				=NULL;
	char *CC_Mail7				=NULL;
	char *CC_Mail8				=NULL;
	char *CC_Mail9				=NULL;
	char *file_Path				=NULL;


	//This is task Names, This we need to get from workflow using handler
	char        *managerReiew				="Manager_Review";
	char        *chiefEngineerReiew			="Chief_Engineer_Review";
	char        *vatsReiew					="VATS_Review_Task_1";


	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_ask_latest_rev(item_tag,&latest_rev);
	CHECK_FAIL;


	ifail =	AOM_ask_value_string(item_tag,"item_id",&tr_item_id);
	CHECK_FAIL;
	printf("\n\n\tItem ID :%s",tr_item_id);

	//Getting owener of TR and TR Owner Mail
	ifail = AOM_ask_owner(latest_rev,&TR_owner);
	if(ifail ==ITK_ok){

	} else 
	{
		EMH_ask_error_text(ifail,&error_text);
		printf("\nError %s", error_text);
	}
	ifail = SA_ask_user_person(TR_owner,&TR_owner_person_tag);
	if(ifail ==ITK_ok){

	} else 
	{
		EMH_ask_error_text(ifail,&error_text);
		printf("\nError %s", error_text);
	}
	ifail =SA_ask_person_name2(TR_owner_person_tag,&person_name);
	printf("\n\n\tPerson Name %s \n",person_name);
	//fprintf(output,"TR_Creator		%s\n",person_name);
	ifail =SA_ask_person_email_address(TR_owner_person_tag,&TR_owner_email);
	printf("\n\n\tTR Creator's e mail:-- %s \n",TR_owner_email);
	///fprintf(output,"Creator Mail		%s\n",object_owner_email);
	
	//Getting Mails for CC
	ifail = QRY_find2("General...", & queryTag);
	CHECK_FAIL;

	Value[0]="TDM_Mail_Approval_Support_Group_And_Paths";
	Value[1]="Control Object";
	ifail = QRY_execute(queryTag, n_entries, userEntry, Value, & resultCount, &CCmailIDTag);
	if(ifail ==ITK_ok){

	} else 
	{
		EMH_ask_error_text(ifail,&error_text);
		printf("\nError %s", error_text);
	}
	printf("\n\n\tNo. of Cnt Obj for -->TDM_Mail_Approval_Support_Group_And_Paths: %d\n", resultCount);
	//Shell Path
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_userinfo10",&file_Path);

	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo1",&CC_Mail1);
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo2",&CC_Mail2);
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo3",&CC_Mail3);
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo4",&CC_Mail4);
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo5",&CC_Mail5);
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo6",&CC_Mail6);
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo7",&CC_Mail7);
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo8",&CC_Mail8);
	ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo9",&CC_Mail9);
	if(ifail ==ITK_ok){

	} else 
	{
		EMH_ask_error_text(ifail,&error_text);
		printf("\nError %s", error_text);
	}
	CHECK_FAIL;

	CC_MailList = getCCMailIDs(CC_Mail1,CC_Mail2,CC_Mail3,CC_Mail4,CC_Mail5,CC_Mail6,CC_Mail7,CC_Mail8,CC_Mail9);
	if (tc_strlen(TR_owner_email) != 0)
	{
		tc_strcat(CC_MailList,",");
		tc_strcat(CC_MailList,TR_owner_email);
	}
	//tc_strcat(CC_MailList,TR_owner_email);
	printf("\n\n\tCC_MailList %s \n",CC_MailList);fflush(stdout);

	//Note: In handler we have to check for different type of review task, Now we are checking for Manager Reivew
	EPM_get_participanttype ("T5_TR_Manager",&Patricipant_Type_TR_Manager);
	EPM_get_participanttype ("T5_TR_ChfEng",&Patricipant_Type_TR_ChfEng);
	EPM_get_participanttype ("T5_TR_VatsRev",&Patricipant_Type_TR_VatsRev);

	//Comparing task name 
	if(tc_strcmp(managerReiew,"Manager_Review")==0)
	{
		//This is to get  mail Ids of Partticipants
		ifail = ITEM_rev_ask_participants(latest_rev,Patricipant_Type_TR_Manager,&participant_count_TR_Manager,&participant_list_TR_Manager);
		printf("\n\n\tNumber Of participant_count_TR_Manager:---[%d]\n",participant_count_TR_Manager);fflush(stdout);
		CHECK_FAIL;
		
		for(i=0;i<participant_count_TR_Manager;i++)
		{
			ifail = AOM_ask_value_string(participant_list_TR_Manager[i],"fnd0AssigneeEmail",&emailID);
			printf("\n\n\tMail ID of Manager: %s\n",emailID);
			//Preparing the command
			//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/email_approval/tm_tdm_approval.sh %s %s %s %s %s %s",timeStamp,tr_item_id,TR_owner_email,emailID,managerReiew,CC_MailList);
			tc_strcat(command,file_Path);
			tc_strcat(command,"tm_tdm_approval.sh");
			tc_strcat(command," ");
			tc_strcat(command,timeStamp); //1
			tc_strcat(command," ");
			tc_strcat(command,tr_item_id); //2
			tc_strcat(command," ");
			tc_strcat(command,TR_owner_email); //3
			tc_strcat(command," ");
			tc_strcat(command,emailID); //4
			tc_strcat(command," ");
			tc_strcat(command,managerReiew); //5
			tc_strcat(command," ");
			tc_strcat(command,CC_MailList); //6
			system(command);

		}

	}
	if(tc_strcmp(managerReiew,"Chief_Engineer_Review")==0)
	{
			ifail = ITEM_rev_ask_participants(latest_rev,Patricipant_Type_TR_ChfEng,&participant_count_TR_ChfEng,&participant_list_TR_ChfEng);
			printf("\nNumber Of participant_count_TR_ChfEng:---[%d]",participant_count_TR_ChfEng);fflush(stdout);
			CHECK_FAIL;

	}
	if(tc_strcmp(managerReiew,"VATS_Review_Task_1")==0)
	{
			ifail = ITEM_rev_ask_participants(latest_rev,Patricipant_Type_TR_VatsRev,&participant_count_TR_VatsRev,&participant_list_TR_VatsRev);
			printf("\nNumber Of participant_count_TR_VatsRev:---[%d]",participant_count_TR_VatsRev);fflush(stdout);
			CHECK_FAIL;


	}

	return ifail;
}

char* getCCMailIDs(char *mail1, char *mail2, char *mail3, char *mail4, char *mail5, char *mail6, char *mail7, char *mail8, char *mail9)
{
	char *tmp_cc_list = (char*)MEM_alloc(sizeof(char) * 10000);
	//printf("\n In Get CC Mail List function.");

   if (tc_strlen(mail1) != 0)
   {
      tc_strcpy(tmp_cc_list, mail1);
   }

   if (tc_strlen(mail2) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail2);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail2);
      }
   }

   if (tc_strlen(mail3) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail3);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail3);
      }
   }

   if (tc_strlen(mail4) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail4);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail4);
      }
   }

   if (tc_strlen(mail5) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail5);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail5);
      }
   }
   if (tc_strlen(mail6) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail6);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail6);
      }
   }
   if (tc_strlen(mail7) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail7);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail7);
      }
   }
    if (tc_strlen(mail8) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail8);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail8);
      }
   }
   if (tc_strlen(mail9) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail9);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail9);
      }
   }
   //printf("\n CC Mail List : %s",tmp_cc_list);
   return tmp_cc_list;
}