/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
char* getCCMailIDsForMailApproval(char *mail1, char *mail2, char *mail3, char *mail4, char *mail5, char *mail6, char *mail7, char *mail8, char *mail9);
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	//time_t 	now;
	//struct 	tm when;
	
	//time(&now);
	//when = *localtime(&now);
	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	//output = fopen(outputFile, "a");
	//if (output == NULL)
	//{
		//printf("ERROR: Cannot open File\n");
	//return -1;
	//}
	//else
	//{
	///	//printf("File opened successfully.\n");
	//}
	
	ifail = read_value_from_file(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	//fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	int				ifail				= 0;
	//int				count				= 0;
	tag_t			root_task			= NULLTAG;
	tag_t			*attachments		= NULLTAG;
	tag_t			class_id			= NULL;
	char			*class_name			= NULL;
	char*			CurrentTask			= NULL;
	char*			parent_name			= NULL;
	tag_t			tr_revisoin         = NULLTAG;
	char*			tr_rev_name			= NULL;

	int		i 							= 0;
	int		j 							= 0;
	int		count 						= 0;
	int		count_status				= 0;
	int		participant_count_TR_Manager= 0;
	int		participant_count_TR_ChfEng = 0;
	int		participant_count_TR_VatsRev= 0;


	
	tag_t		item_tag					= NULLTAG;
	tag_t		*status_list				= NULL;
	tag_t		latest_rev					= NULL;
	
	char		*status_name				= NULL;
	
	
	char		*tr_item_id					= NULL;
	char		*test_req_no				= NULL;
	tag_t		Patricipant_Type_TR_Manager	= NULLTAG;
	tag_t		Patricipant_Type_TR_ChfEng	= NULLTAG;
	tag_t		Patricipant_Type_TR_VatsRev	= NULLTAG;

	tag_t		*participant_list_TR_Manager= NULLTAG;
	tag_t		*participant_list_TR_ChfEng= NULLTAG;
	tag_t		*participant_list_TR_VatsRev= NULLTAG;

	tag_t		TR_owner					=NULLTAG;
	tag_t		TR_owner_person_tag			=NULLTAG;
	char*		person_name					=NULL;
	char*		TR_owner_email				=NULL;
	char*		error_text					=NULL;
	
	char	*CC_MailList				    = (char*)MEM_alloc(sizeof(char) * 2000);
	tag_t	queryTag;
	tag_t *CCmailIDTag;
	int n_entries								= 2;
	int	resultCount;
	char *userEntry[2]			={"Name","Type"};
	char **Value				=(char **) MEM_alloc(100 * sizeof(char *));
	char		*managerReiew				="Manager_Review";
	char        *chiefEngineerReiew			="Chief_Engineer_Review";
	char        *vatsReiew					="VATS_Review_Task_1";

	char *CC_Mail1				=NULL;
	char *CC_Mail2				=NULL;
	char *CC_Mail3				=NULL;
	char *CC_Mail4				=NULL;
	char *CC_Mail5				=NULL;
	char *CC_Mail6				=NULL;
	char *CC_Mail7				=NULL;
	char *CC_Mail8				=NULL;
	char *CC_Mail9				=NULL;
	char *file_Path				=NULL;
	char timeStamp[100]					= "";


	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_ask_latest_rev(item_tag,&latest_rev);
	CHECK_FAIL;


	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(timeStamp,100,"%d_%b_%Y_%H_%M_%S",&when);

	tr_revisoin  = latest_rev;

	ifail = AOM_ask_value_string(tr_revisoin,"object_string",&tr_rev_name);
	printf("\n\n\tObject Name :---%s\n", tr_rev_name);

	ifail = POM_class_of_instance(tr_revisoin,&class_id);
	ifail = POM_name_of_class(class_id,&class_name);
	printf("\n\n\t class_name of Task :%s",class_name);fflush(stdout);

	if(tc_strcmp(class_name,"T5_TestRqRevision")==0)
	{
			// To get Participent type
			EPM_get_participanttype ("T5_TR_Manager",&Patricipant_Type_TR_Manager);
			EPM_get_participanttype ("T5_TR_ChfEng",&Patricipant_Type_TR_ChfEng);
			EPM_get_participanttype ("T5_TR_VatsRev",&Patricipant_Type_TR_VatsRev);

			ifail =	AOM_ask_value_string(tr_revisoin,"item_id",&tr_item_id);
			CHECK_FAIL;
			printf("\n\n\tItem ID :%s",tr_item_id);
			//This is modified TR no
			STRNG_replace_str(tr_item_id,"/","_",&test_req_no);
			printf("\n\n\tTest Request no :%s",test_req_no);

			//Getting owener of TR and TR Owner Mail
			ifail = AOM_ask_owner(tr_revisoin,&TR_owner);
			CHECK_FAIL;
			ifail = SA_ask_user_person(TR_owner,&TR_owner_person_tag);
			CHECK_FAIL;
			ifail =SA_ask_person_name2(TR_owner_person_tag,&person_name);
			printf("\n\n\tPerson Name %s \n",person_name);
			CHECK_FAIL;

			ifail =SA_ask_person_email_address(TR_owner_person_tag,&TR_owner_email);
			printf("\n\n\tTR Creator's e mail:-- %s \n",TR_owner_email);

			//Getting Mails for CC
			ifail = QRY_find2("General...", & queryTag);
			CHECK_FAIL;
			Value[0]="TDM_Mail_Approval_Support_Group_And_Paths";
			Value[1]="Control Object";
			ifail = QRY_execute(queryTag, n_entries, userEntry, Value, & resultCount, &CCmailIDTag);
			if(ifail ==ITK_ok){

			} else 
			{
				EMH_ask_error_text(ifail,&error_text);
				printf("\nError %s", error_text);
			}
			printf("\n\n\tNo. of Cnt Obj for -->TDM_Mail_Approval_Support_Group_And_Paths: %d\n", resultCount);
			//Shell path:
			//if control object not found , E mail Approval is Off:
			if(resultCount > 0)
			{
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_userinfo10",&file_Path);
				printf("\n\n\tfile_Path: %s\n", file_Path);

				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo1",&CC_Mail1);
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo2",&CC_Mail2);
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo3",&CC_Mail3);
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo4",&CC_Mail4);
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo5",&CC_Mail5);
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo6",&CC_Mail6);
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo7",&CC_Mail7);
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo8",&CC_Mail8);
				ifail = AOM_ask_value_string(CCmailIDTag[0],"t5_Userinfo9",&CC_Mail9);
				CHECK_FAIL;

				CC_MailList = getCCMailIDsForMailApproval(CC_Mail1,CC_Mail2,CC_Mail3,CC_Mail4,CC_Mail5,CC_Mail6,CC_Mail7,CC_Mail8,CC_Mail9);
				if (tc_strlen(TR_owner_email) != 0)
				{
					tc_strcat(CC_MailList,",");
					tc_strcat(CC_MailList,TR_owner_email);
				}
				printf("\n\n\tCC_MailList for Mail Approval %s \n",CC_MailList);fflush(stdout);

				if(tc_strcmp("Manager Review","Manager Review1111")==0)
				{
					printf("\n\n\t *******In Manager Review********\n");
					//This is to get  mail Ids of Partticipants
					ifail = ITEM_rev_ask_participants(tr_revisoin,Patricipant_Type_TR_Manager,&participant_count_TR_Manager,&participant_list_TR_Manager);
					printf("\n\n\tNumber Of participant_count_TR_Manager:---[%d]\n",participant_count_TR_Manager);fflush(stdout);
					CHECK_FAIL;
					
					for(i=0;i<participant_count_TR_Manager;i++)
					{
						char		*command			=(char*)MEM_alloc(sizeof(char) * 512);
						char		*emailIDMgr					=NULL;
						ifail = AOM_ask_value_string(participant_list_TR_Manager[i],"fnd0AssigneeEmail",&emailIDMgr);
						printf("\n\n\tMail ID of Manager [%d]: %s\n",i,emailIDMgr);
						//Preparing the command
						//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/email_approval/tm_tdm_approval.sh %s %s %s %s %s %s",timeStamp,tr_item_id,TR_owner_email,emailID,managerReiew,CC_MailList);
						tc_strcpy(command,"");
						tc_strcat(command,file_Path);
						tc_strcat(command,"tm_tdm_approval.sh");
						tc_strcat(command," ");
						tc_strcat(command,timeStamp);
						tc_strcat(command," ");
						tc_strcat(command,test_req_no);
						tc_strcat(command," ");
						tc_strcat(command,TR_owner_email);
						tc_strcat(command," ");
						tc_strcat(command,emailIDMgr);
						tc_strcat(command," ");
						tc_strcat(command,managerReiew);
						tc_strcat(command," ");
						tc_strcat(command,CC_MailList);
						system(command);
						printf("\n\n\tShell Executed successfully.\n");

					}


				}
				if(tc_strcmp("Chief Engineer Review","Chief Engineer Review111")==0)
				{
					printf("\n\n\t *******Chief Engineer Review********\n");
					ifail = ITEM_rev_ask_participants(tr_revisoin,Patricipant_Type_TR_ChfEng,&participant_count_TR_ChfEng,&participant_list_TR_ChfEng);
					printf("\nNumber Of participant_count_TR_ChfEng:---[%d]",participant_count_TR_ChfEng);fflush(stdout);
					CHECK_FAIL;
					for(i=0;i<participant_count_TR_ChfEng;i++)
					{
						char		*command			=(char*)MEM_alloc(sizeof(char) * 512);
						char		*emailIDChefEng				=NULL;

						ifail = AOM_ask_value_string(participant_list_TR_ChfEng[i],"fnd0AssigneeEmail",&emailIDChefEng);
						printf("\n\n\tMail ID of Chief Engineer [%d]: %s\n",i,emailIDChefEng);
						
						tc_strcpy(command,"");
						tc_strcat(command,file_Path);
						tc_strcat(command,"tm_tdm_approval.sh");
						tc_strcat(command," ");
						tc_strcat(command,timeStamp);
						tc_strcat(command," ");
						tc_strcat(command,test_req_no);
						tc_strcat(command," ");
						tc_strcat(command,TR_owner_email);
						tc_strcat(command," ");
						tc_strcat(command,emailIDChefEng);
						tc_strcat(command," ");
						tc_strcat(command,chiefEngineerReiew);
						tc_strcat(command," ");
						tc_strcat(command,CC_MailList);
						system(command);

						printf("\n\n\tShell Executed successfully.\n");
						//if(command != NULL)
							//MEM_free(command);
						//if(emailIDChefEng != NULL)
						//	MEM_free(emailIDChefEng);

					}

				}
				if(tc_strcmp("VATS Review Task 1","VATS Review Task 1")==0)
				{
					printf("\n\n\t *******VATS Review Task 1********\n");
					ifail = ITEM_rev_ask_participants(tr_revisoin,Patricipant_Type_TR_VatsRev,&participant_count_TR_VatsRev,&participant_list_TR_VatsRev);
					printf("\nNumber Of participant_count_TR_VatsRev:---[%d]",participant_count_TR_VatsRev);fflush(stdout);
					CHECK_FAIL;
					for(i=0;i<participant_count_TR_VatsRev;i++)
					{
						char	*command					=(char*)MEM_alloc(sizeof(char) * 512);
						char	*emailIDVats			    =NULL;
		
						ifail = AOM_ask_value_string(participant_list_TR_VatsRev[i],"fnd0AssigneeEmail",&emailIDVats);
						printf("\n\n\tMail ID of VATS Reviewer [%d]: %s\n",i,emailIDVats);

						if(tc_strcmp(emailIDVats,"") ==0)
						{
							tc_strcpy(emailIDVats,"mailid_not_found");

						}else 
						{

						}
						tc_strcpy(command,"");
						tc_strcat(command,file_Path);
						tc_strcat(command,"tm_tdm_approval.sh");
						tc_strcat(command," ");
						tc_strcat(command,timeStamp);
						tc_strcat(command," ");
						tc_strcat(command,test_req_no);
						tc_strcat(command," ");
						tc_strcat(command,TR_owner_email);
						tc_strcat(command," ");
						tc_strcat(command,emailIDVats);
						tc_strcat(command," ");
						tc_strcat(command,vatsReiew);
						tc_strcat(command," ");
						tc_strcat(command,CC_MailList);
						system(command);
						
						printf("\n\n\tShell Executed successfully.\n");
						//printf("\n\n\tCommand is : %s\n",command);


					}

				}	

			}// control object: TDM_Mail_Approval_Support_Group_And_Paths if ends 
			else
			{	
						//printf("\n\n\tNo. of Cnt Obj for -->: %d\n", resultCount);
						printf("\n\n\t Control object not found");
						printf("\n\n\t*****E mail Approval is OFF now*****\n");
			}
	

	}
	printf("\n\n\t return %d \n",ifail);
	return ifail;
}
char* getCCMailIDsForMailApproval(char *mail1, char *mail2, char *mail3, char *mail4, char *mail5, char *mail6, char *mail7, char *mail8, char *mail9)
{
	char *tmp_cc_list = (char*)MEM_alloc(sizeof(char) * 10000);
	//printf("\n In Get CC Mail List function.");

   if (tc_strlen(mail1) != 0)
   {
      tc_strcpy(tmp_cc_list, mail1);
   }

   if (tc_strlen(mail2) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail2);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail2);
      }
   }

   if (tc_strlen(mail3) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail3);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail3);
      }
   }

   if (tc_strlen(mail4) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail4);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail4);
      }
   }

   if (tc_strlen(mail5) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail5);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail5);
      }
   }
   if (tc_strlen(mail6) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail6);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail6);
      }
   }
   if (tc_strlen(mail7) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail7);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail7);
      }
   }
    if (tc_strlen(mail8) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail8);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail8);
      }
   }
   if (tc_strlen(mail9) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail9);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail9);
      }
   }
   //printf("\n CC Mail List : %s",tmp_cc_list);
   return tmp_cc_list;
}
