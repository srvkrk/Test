#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* testRequestNo				= NULL;
	char			* timeStamp					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	testRequestNo 	= ITK_ask_cli_argument("-tr_no=");
	timeStamp 		= ITK_ask_cli_argument("-t=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",timeStamp);
	//tc_strcpy(outputFile,"/user/testcmi/Dev/devgroups/Kirtikumar/email_approval/Reports/");
	//sprintf(outputFile,"%s","/user/testcmi/Dev/devgroups/Kirtikumar/email_approval/Reports/");
	sprintf(outputFile,"%s_output.txt",testRequestNo);
	
	//tc_strcpy(outputFile,testRequestNo);
	//tc_strcat(outputFile,"_output.txt");

	
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(testRequestNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	printf("\nOutput file name : %s",outputFile);
	//printf("\nData  : %s",Data);

	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(testRequestNo);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

int read_value_from_file(char* testRequestNo)
{

	// TR Properties
	char* Rq_Domain								=NULL;
	char* BU									=NULL;
	char* TR_id									=NULL;
	char* project_code							=NULL;
	char* proj_desc								=NULL;
	char* wbs_details							=NULL;
	char* dr_status								=NULL;
	char* veh_sys_stage							=NULL;
	char* aggregate								=NULL;
	char* testing_sub_group						=NULL;
	char* inv_type								=NULL;
	char* bacg_history							=NULL;
	char* creator								=NULL;
	char* request_dept							=NULL;


	tag_t		testRequestTag		= NULLTAG;
	tag_t		latest_tr_revTag	= NULLTAG;
	tag_t		object_owner		= NULLTAG;
	tag_t		person_tag			= NULLTAG;
	char*		person_name			= NULL;
	char*		TestRqObjNm1		= NULL;

	STRNG_replace_str(testRequestNo,"_","/",&TestRqObjNm1);
	ifail = ITEM_find_item (TestRqObjNm1, &testRequestTag);
	CHECK_FAIL;

	ifail = ITEM_ask_latest_rev(testRequestTag,&latest_tr_revTag);
	CHECK_FAIL;

	ifail = AOM_ask_owner(latest_tr_revTag,&object_owner);
	CHECK_FAIL;
	ifail = SA_ask_user_person(object_owner,&person_tag);
	CHECK_FAIL;
	ifail =SA_ask_person_name2(person_tag,&person_name);
	CHECK_FAIL;
	printf("\nCreator Name %s",person_name);



	// Getting all TR data
	//Getting Requried Properties of TR for shell.
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqDomain",&Rq_Domain);
	///fprintf(output,"t5_RqDomain		%s\n",Rq_Domain);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_BU",&BU);
	//fprintf(output,"t5_BU			%s\n",BU);
	ifail = AOM_ask_value_string(latest_tr_revTag,"object_string",&TR_id);
	//fprintf(output,"item_id			%s\n",TR_id);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqProjCode",&project_code);
	//fprintf(output,"t5_RqProjCode		%s\n",project_code);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqProjDes",&proj_desc);
	//fprintf(output,"t5_RqProjDes		%s\n",proj_desc);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_WBS",&wbs_details);
	//fprintf(output,"t5_WBS			%s\n",wbs_details);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqDesStatus",&dr_status);
	//fprintf(output,"t5_RqDesStatus		%s\n",dr_status);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqVehStage",&veh_sys_stage);
	//fprintf(output,"t5_RqVehStage		%s\n",veh_sys_stage);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqAggregate",&aggregate);
	//fprintf(output,"t5_RqAggregate		%s\n",aggregate);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_TestSubGrp",&testing_sub_group);
	//fprintf(output,"t5_TestSubGrp		%s\n",testing_sub_group);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqInvType",&inv_type);
	//fprintf(output,"t5_RqInvType		%s\n",inv_type);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqBGHistory",&bacg_history);
	ifail = AOM_ask_value_string(latest_tr_revTag,"t5_RqReqDep",&request_dept);
	//fprintf(output,"t5_RqReqDep		%s\n",request_dept);

	// Creating i/p file for shell
	fprintf(output,"Request_Domain=%s\n",Rq_Domain);
	fprintf(output,"Business_Unit=%s\n",BU);
	fprintf(output,"Request_Number=%s\n",TR_id);
	fprintf(output,"Project_Code=%s\n",project_code);
	fprintf(output,"Project_Description=%s\n",proj_desc);
	fprintf(output,"WBS_details=%s\n",wbs_details);
	fprintf(output,"Design_Status=%s\n",dr_status);
	fprintf(output,"Vehicle_System=%s\n",veh_sys_stage);
					
	fprintf(output,"Aggregates=%s\n",aggregate);
	fprintf(output,"Testing_Sub_Group=%s\n",testing_sub_group);
	fprintf(output,"Investigation_Type=%s\n",inv_type);
	fprintf(output,"Background/History=%s\n",bacg_history);
	fprintf(output,"Creator=%s\n",person_name);
	fprintf(output,"Requesting_Dept=%s\n",request_dept);

	//fclose(fp);
	fclose(output);

	if(Rq_Domain !=NULL)
		MEM_free(Rq_Domain);
	if(BU !=NULL)
		MEM_free(BU);
	if(TR_id !=NULL)
		MEM_free(TR_id);
	if(project_code !=NULL)
		MEM_free(project_code);
	if(proj_desc !=NULL)
		MEM_free(proj_desc);
	if(wbs_details !=NULL)
		MEM_free(wbs_details);
	if(dr_status !=NULL)
		MEM_free(dr_status);
	if(veh_sys_stage !=NULL)
		MEM_free(veh_sys_stage);
	if(aggregate !=NULL)
		MEM_free(aggregate);
	if(testing_sub_group !=NULL)
		MEM_free(testing_sub_group);
	if(inv_type !=NULL)
		MEM_free(inv_type);
	if(bacg_history !=NULL)
		MEM_free(bacg_history);
	if(creator !=NULL)
		MEM_free(creator);
	if(request_dept !=NULL)
		MEM_free(request_dept);						

	return ifail;
}
