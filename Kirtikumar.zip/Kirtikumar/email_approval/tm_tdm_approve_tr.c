/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define ITK_err (EMH_USER_error_base + 2)

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		char *error_msg_string;

		EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
		printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
		TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
		printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* testReqNo					= NULL;
	char			* descision					= NULL;
	char			* mailID					= NULL;
	char			* assignment				= NULL;
	char			* comment					= NULL;

	char			Data[100]					= "";
	char			outputFile[200]				= "";
	char		    rejectComment[500]			="";
	char		    ApproveComment[500]			="";
	char*			taskType					=NULL;
	char*			ReviewTaskType				=NULL;
	char*			sub_taskType				=NULL;
	char*			task_name					=NULL;
	char			*Assignee					=NULL;
	char			jobTypeName[TCTYPE_name_size_c+1];
	char			*jobName					=NULL;
	char			*parent_name				=NULL;

	tag_t			testReqNoTag				= NULLTAG;
	tag_t			testReqLatestRevTag			= NULLTAG;
	tag_t			job_Tag						=NULLTAG;
	tag_t			jobtype_Tag					=NULLTAG;
	tag_t			rootTask					= NULLTAG;
	
	int				tskcount					=0;
	int				i							=0;
	int				j							=0;
	int				k							=0;
	int				rvwSubTaskCnt				=0;
	
	int				attachmentCount				=0;
	tag_t*			taskAttachments				=NULLTAG;
	tag_t*			reviewSubTasks				=NULLTAG;
	tag_t*			subtask						=NULLTAG;
	tag_t			MilestoneqryTag				= NULLTAG;

	char*			Manager_Review =  (char *) MEM_alloc(10 * sizeof(char *));
	char*			Chief_Engineer_Review =  (char *) MEM_alloc(10 * sizeof(char *));
	char*			VATS_Review_Task_1 =  (char *) MEM_alloc(10 * sizeof(char *));

	//Desicion
	CR_signoff_decision_t apprDecision_e=CR_approve_decision;
	CR_signoff_decision_t rejectDecision_e=CR_reject_decision;

	int     Milston_rsltCount					 = 0;
	int     Milston_n_entry						 = 1;
	tag_t	*MilstonCntrlObjectTag				 = NULLTAG;
	//tag_t	MilestoneqryTag						 = NULLTAG;
	char*	Milstoninfo1 = NULL;

	char    *Milston_qry_entry[1]  = {"E-Mail Address"};
	char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	testReqNo 		= ITK_ask_cli_argument("-tr=");
	descision 		= ITK_ask_cli_argument("-d=");
	mailID 			= ITK_ask_cli_argument("-m=");
	assignment 		= ITK_ask_cli_argument("-a=");
	comment 		= ITK_ask_cli_argument("-c=");

	
	//time_t 	now;
	//struct 	tm when;
	//time(&now);
	//when = *localtime(&now);
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
	printf("\n \n \t ****assignment is*******: %s",assignment);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	

	ifail = QRY_find("PersonFromEmailID", &MilestoneqryTag);
	if (MilestoneqryTag)
	{
		printf("\n P1:Found Query MilestoneqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n P2:Not Found Query MilestoneqryTag \n");fflush(stdout);
	}
	Milston_qry_values2[0] = mailID;
	if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	printf(" \n P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	if(Milston_rsltCount > 0)
	{
		ifail = AOM_ask_value_string(MilstonCntrlObjectTag[0],"user_name",&Milstoninfo1);
		printf("\n P4:Milstoninfo1 is : [%s]\n", Milstoninfo1);fflush(stdout);

	}

	// Comment form Approver is added
	tc_strcpy(rejectComment,"");
	tc_strcat(rejectComment,"Task rejected by ");
	tc_strcat(rejectComment,Milstoninfo1);
	tc_strcat(rejectComment," through email facility.");
	tc_strcat(rejectComment," Reject Comment :");
	tc_strcat(rejectComment,comment);

	tc_strcpy(ApproveComment,"");
	tc_strcat(ApproveComment,"Task Approved by ");
	tc_strcat(ApproveComment,Milstoninfo1);
	tc_strcat(ApproveComment," through email facility.");
	tc_strcat(ApproveComment,"Approve Comment:");
	tc_strcat(ApproveComment,comment);

	//Logic for Approval of Test Request
	ifail =	ITEM_find_item(testReqNo, &testReqNoTag);
	ifail =	ITEM_ask_latest_rev(testReqNoTag,&testReqLatestRevTag);
	CHECK_FAIL;

	if(testReqLatestRevTag != NULLTAG)
	{
		

		ifail =	EPM_get_current_job(testReqLatestRevTag,&job_Tag,&jobtype_Tag);
		ifail =	TCTYPE_ask_name(jobtype_Tag,jobTypeName);
		ifail =	AOM_ask_value_string(job_Tag,"object_name",&jobName) ;
		printf("\nInside  %s %s \n",jobTypeName,jobName);fflush(stdout);

		ifail =	EPM_ask_root_task(job_Tag,&rootTask);
		ifail =	EPM_ask_sub_tasks(rootTask,&tskcount,&subtask);
		ifail =	AOM_ask_value_string(rootTask,"object_name",&parent_name);
		printf("\nParent Name: %s",parent_name);fflush(stdout);
		printf("\nNo of subtasks = %d\n",tskcount);fflush(stdout);
		
		if( tc_strcmp(assignment,"Manager_Review") ==0)
		{	
			tc_strcpy(Manager_Review,"");
			tc_strcpy(Manager_Review,"Manager Review");

		} else if (tc_strcmp(assignment,"Chief_Engineer_Review") ==0)
		{
			tc_strcpy(Chief_Engineer_Review,"");
			tc_strcpy(Chief_Engineer_Review,"Chief Engineer Review");

		} else if (tc_strcmp(assignment,"VATS_Review_Task_1") ==0)
		{
			tc_strcpy(VATS_Review_Task_1,"");
			tc_strcpy(VATS_Review_Task_1,"VATS Review Task 1");

		}
		
		for(i =0; i<tskcount;i++) 
		{
			ifail = AOM_ask_value_string (subtask[i],"task_type",&taskType);
			ifail = AOM_ask_value_string(subtask[i],"object_name",&task_name);
			//printf("\ntask type = %s\n",taskType);fflush(stdout);
			//printf("\ntask name = %s\n",task_name);fflush(stdout);

			if(tc_strcmp(taskType,"EPMReviewTask")==0)
			{	
				//Manager Review Or Chief Engineer Review or VATS Review Task 1
				//if( tc_strcmp(task_name,"Manager Review") ==0 || tc_strcmp(task_name,"Chief Engineer Review") ==0 || tc_strcmp(task_name,"VATS Review Task 1"))
				if( tc_strcmp(task_name,Manager_Review) ==0 )
				{
					//printf("\nIn Manager Review::\n");
					ifail = EPM_ask_sub_tasks(subtask[i],&rvwSubTaskCnt,&reviewSubTasks);
					for (j=0;j < rvwSubTaskCnt; j++)
					{
						ifail = AOM_ask_value_string (reviewSubTasks[j],"task_type",&ReviewTaskType);

						if(tc_strcmp(ReviewTaskType,"EPMPerformSignoffTask")==0)
						{
							ifail = EPM_ask_attachments(reviewSubTasks[j],EPM_signoff_attachment,&attachmentCount,&taskAttachments);
							printf("No of signoff attachments is = %d\n",attachmentCount);
							if(attachmentCount>0)		//Assuming only one approval is sufficient for SignOff task to complete.
							{
								for(k=0;k<attachmentCount;k++)
								{
									ifail = AOM_UIF_ask_value (taskAttachments[k],"fnd0Assignee",&Assignee);
									printf("Assignee is= %s\n",Assignee);fflush(stdout);
									//Checking the Assingnee
									if(tc_strstr(Assignee,Milstoninfo1) != NULL)
									{
										ifail = EPM_refresh_entire_job(job_Tag);
										CHECK_FAIL;
										if(tc_strcmp(descision,"APPROVE")==0)
										{
												ifail = EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],apprDecision_e,ApproveComment);
												CHECK_FAIL;
												
												printf("Task is APPROVED\n");
												break;

										}
										if(tc_strcmp(descision,"REJECT")==0)
										{
												//ifail = EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],rejectDecision_e,rejectComment);
												//CHECK_FAIL;
												ITK_CALL(EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],rejectDecision_e,rejectComment));
												printf("Task is REJECTED\n");
												break;
										}  
									}
									
								}
							}
						}

					}
				}
				//Chief Engineer Review
				if( tc_strcmp(task_name,Chief_Engineer_Review) ==0)
				{
					printf("\nIn Chief Engineer Review::\n");
					ifail = EPM_ask_sub_tasks(subtask[i],&rvwSubTaskCnt,&reviewSubTasks);
					for (j=0;j < rvwSubTaskCnt; j++)
					{
						ifail = AOM_ask_value_string (reviewSubTasks[j],"task_type",&ReviewTaskType);

						if(tc_strcmp(ReviewTaskType,"EPMPerformSignoffTask")==0)
						{
							ifail = EPM_ask_attachments(reviewSubTasks[j],EPM_signoff_attachment,&attachmentCount,&taskAttachments);
							printf("No of signoff attachments is = %d\n",attachmentCount);
							if(attachmentCount>0)		//Assuming only one approval is sufficient for SignOff task to complete.
							{
								for(k=0;k<attachmentCount;k++)
								{
									ifail = AOM_UIF_ask_value (taskAttachments[k],"fnd0Assignee",&Assignee);
									printf("Assignee is= %s\n",Assignee);fflush(stdout);
									//Checking the Assingnee
									if(tc_strstr(Assignee,Milstoninfo1) != NULL)
									{
										ifail = EPM_refresh_entire_job(job_Tag);
										CHECK_FAIL;
										if(tc_strcmp(descision,"APPROVE")==0)
										{
												ifail = EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],apprDecision_e,ApproveComment);
												CHECK_FAIL;
												
												printf("Task is APPROVED\n");
												break;

										}
										if(tc_strcmp(descision,"REJECT")==0)
										{
												//ifail = EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],rejectDecision_e,rejectComment);
												//CHECK_FAIL;
												ITK_CALL(EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],rejectDecision_e,rejectComment));
												printf("Task is REJECTED\n");
												break;
										}  
									}
									
								}
							}
						}

					}
				}
				//VATS Review
				if( tc_strcmp(task_name,VATS_Review_Task_1) ==0)
				{
					printf("\nIn VATS Review::\n");
					ifail = EPM_ask_sub_tasks(subtask[i],&rvwSubTaskCnt,&reviewSubTasks);
					for (j=0;j < rvwSubTaskCnt; j++)
					{
						ifail = AOM_ask_value_string (reviewSubTasks[j],"task_type",&ReviewTaskType);

						if(tc_strcmp(ReviewTaskType,"EPMPerformSignoffTask")==0)
						{
							ifail = EPM_ask_attachments(reviewSubTasks[j],EPM_signoff_attachment,&attachmentCount,&taskAttachments);
							printf("No of signoff attachments is = %d\n",attachmentCount);
							if(attachmentCount>0)		//Assuming only one approval is sufficient for SignOff task to complete.
							{
								for(k=0;k<attachmentCount;k++)
								{
									ifail = AOM_UIF_ask_value (taskAttachments[k],"fnd0Assignee",&Assignee);
									printf("Assignee is= %s\n",Assignee);fflush(stdout);
									//Checking the Assingnee
									if(tc_strstr(Assignee,Milstoninfo1) != NULL)
									{
										ifail = EPM_refresh_entire_job(job_Tag);
										CHECK_FAIL;
										if(tc_strcmp(descision,"APPROVE")==0)
										{
												ifail = EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],apprDecision_e,ApproveComment);
												CHECK_FAIL;
												
												printf("Task is APPROVED\n");
												break;

										}
										if(tc_strcmp(descision,"REJECT")==0)
										{
												//ifail = EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],rejectDecision_e,rejectComment);
												//CHECK_FAIL;
												ITK_CALL(EPM_set_task_decision2(reviewSubTasks[j],taskAttachments[k],rejectDecision_e,rejectComment));
												printf("Task is REJECTED\n");
												break;
										}  
									}
									
								}
							}
						}

					}
				}
			}

		}

	}	
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}