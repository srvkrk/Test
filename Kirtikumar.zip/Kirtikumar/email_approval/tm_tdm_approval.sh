#!/bin/bash
echo **************In TDM_Mail_Approval Shell******************
echo $1
echo $2
echo $3
echo $4
echo $5
echo $6

if [ -f "${2}_output.txt" ]
then
	echo "*****${2}_output.txt***** file found."
else
	echo "*****${2}_output.txt*****, File not found. Running report utility for TR Report."
	#/user/testcmi/devgroups/Kirtikumar/email_approval/tm_tdm_TR_Report -u=ercpsup -p=XYT1ESA -g=dba -tr_no=$2 -t=$1
	/user/testcmi/Dev/devgroups/Kirtikumar/email_approval/tm_tdm_TR_Report -u=ercpsup -p=XYT1ESA -g=dba -tr_no=$2 -t=$1
fi
#/user/testcmi/devgroups/Kirtikumar/email_approval/tm_tdm_TR_Report -u=ercpsup -p=XYT1ESA -g=dba -tr_no=$2 -t=$1
while read line; do
	if [[ $line == *"Request_Domain="* ]]; then
	Request_Domain=$(echo $line| cut -d'=' -f 2)
	fi
	
	if [[ $line == *"Business_Unit="* ]]; then
	Business_Unit=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Request_Number="* ]]; then
	Request_Number=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"WBS_details="* ]]; then
	WBS_details=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Design_Status="* ]]; then
	Design_Status=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Vehicle_System="* ]]; then
	Vehicle_System=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Aggregates="* ]]; then
	Aggregates=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Testing_Sub_Group"* ]]; then
	Testing_Sub_Group=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Investigation_Type"* ]]; then
	Investigation_Type=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Background/History="* ]]; then
	Background_History=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Creator="* ]]; then
	Creator=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Requesting_Dept="* ]]; then
	Requesting_Dept=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Project_Code="* ]]; then
	Project_Code=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"Project_Description="* ]]; then
	Project_Description=$(echo $line| cut -d'=' -f 2)
	fi

done < ${2}_output.txt
echo $Request_Domain
echo $Business_Unit
echo $Request_Number
echo $WBS_details
echo $Design_Status
echo $Vehicle_System
#echo $Vehicle_System
echo $Aggregates
echo $Investigation_Type
echo $Background_History
echo $Creator
echo $Requesting_Dept
echo $Project_Code
echo $Project_Description
(
echo 'Content-Type: multipart/mixed; boundary="-q1w2e3r4t5"'
echo "To:$4"
echo "CC:$6"
echo "SUBJECT:Test Request is for $5:$Request_Number."
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
echo "<html>"
    echo "<head></head>"
    echo "<body>"
        echo "<table width='600px' border='1px' style='border-color: #256fab;border-style: none;'>"
            echo "<table width='100%'>"
                echo "<tr style='background:#256fab;height:60px;'>"
                    echo "<td colspan='3'>"
                        echo "<strong>"
                            echo "<p style=' color: #FFF;text-align: center;font-size: 20px;text-transform: uppercase;'>FIR Request/Test Request is in $5"
                            echo "</p>"
                        echo "</strong>"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'><strong>Dear Sir,</strong></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'>A new FIR Request/Test Request task has come to your PLM worklist for review. Please Approve/Reject the task by clicking the link below:</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Request Domain</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Request_Domain"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Business Unit</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Business_Unit"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Request Number</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Request_Number"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Project Code</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Project_Code"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Project description</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Project_Description"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>WBS detail</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        #echo "P.20.ED.106"
                        echo "$WBS_details"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Design Status</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Design_Status"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Vehicle/System Stage(Mule,Alpha,Beta,PO,PP etc)</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Vehicle_System"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Aggregates</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Aggregates"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Testing Sub Group</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Testing_Sub_Group"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Investigation Type/Reason for Test</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Investigation_Type"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Background/History</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
			echo "$Background_History"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Creator</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Creator"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Requesting Department</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Requesting_Dept"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'>Regards,<br>Team PLM.</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'>"
                        echo "<hr>"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:10px;' colspan='3'>"

			echo "<a style='color:#37823a;' href='mailto:FirRequestReview@tatamotors.com?cc=$6&subject=TestRequestReview-$5-Decision:%20$2%20APPROVE&body=Hi,%0D%0A
							    $Request_Number is Approved.
							    %0D%0A%0D%0AThanks%0D%0A PLM Team.%0D%0A%0D%0ANote :By sending this mail, system will approve the object in PLM. It require some time to update in PLM.'>Click to Approve</a>"
			echo "&nbsp;&nbsp;&nbsp;&nbsp;" 
                        echo "<a style='color:#c71010;' href='mailto:FirRequestReview@tatamotors.com?cc=$6&subject=TestRequestReview-$5-Decision:%20$2%20REJECT&body=Hi,%0D%0A
							    $Request_Number is Rejected.%0D%0A
							    Reject Comment:
							    %0D%0A%0D%0AThanks%0D%0A PLM Team.%0D%0A%0D%0ANote :By sending this mail, system will reject the object in PLM. It require some time to update in PLM.'>Click to Reject</a>"

                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#256fab;height:60px;'>"
                    echo "<td colspan='3'></td>"
                echo "</tr>"
                echo "</td></tr>"
            echo "</table>"
        echo "</table>"
    echo "</body>"
echo "</html>"
) | /usr/sbin/sendmail -f "$3" -t "$4"