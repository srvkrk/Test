#!/bin/bash
echo I am in Read mail for TR shell
java -cp :.:./mail-1.4.7.jar:./jsoup-1.11.2.jar com.java.mail.TestRequsetMailReader