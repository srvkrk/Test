#!/bin/bash
echo input file is: $1

while read line; do
	if [[ $line == *"item_id="* ]]; then
	item_id=$(echo $line| cut -d'=' -f 2)
	fi
	
	if [[ $line == *"rev_id="* ]]; then
	rev_id=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"to_mail="* ]]; then
	to_mail=$(echo $line| cut -d'=' -f 2)
	fi

	if [[ $line == *"cc_mail="* ]]; then
	cc_mail=$(echo $line| cut -d'=' -f 2)
	fi
done < ${1}_output.txt
echo $item_id
echo $rev_id
echo $to_mail
echo $cc_mail