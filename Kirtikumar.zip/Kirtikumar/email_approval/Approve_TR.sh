#!/bin/bash
echo In Approval TR shell, I am called from JAVA Code for Read mail for TR
/user/testcmi/devgroups/Kirtikumar/email_approval/tm_tdm_approve_tr -u=ercpsup -p=XYT1ESA -g=dba -tr=$2 -d=$3 -m=$4 -a=$1 -c=$5