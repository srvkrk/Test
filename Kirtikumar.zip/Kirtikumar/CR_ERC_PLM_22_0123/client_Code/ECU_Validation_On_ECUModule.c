/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
int VC_Multi_Get_Part_BOM_Lvl_Col_SW(int ,int ,tag_t , int *);
char* subString (char*  ,int ,int );
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
tag_t Get_CC_Dictionary();
tag_t Get_CC_From_Platform_ArchModule(char*,char*);
int OptionFamily_Create(char* ,tag_t* ,int );
int OptionValue_Create(char* ,tag_t ,tag_t* ,int );

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	char*	username				= NULL;
	tag_t	root_task				= NULLTAG;
	tag_t	*attachments			= NULLTAG;
	int		ifail					= 0;

	int				i 							= 0;
	int				j 							= 0;
	int				k 							= 0;
	int				l 							= 0;
	int				q							= 0;
	int				count1 						= 0;
	int				count 						= 0;
	int				n_attchs 					= 0;
	int				count_status				= 0;
	int				partcnt						= 0;
	int				sequence_id					= 0;
	//int             NR_REV_CHECK				= 0;

	tag_t			item_tag					= NULLTAG;
	tag_t			*status_list				= NULL;
	tag_t			DMLLcmTag					= NULL;
	tag_t			class_id					= NULL;
	tag_t			class_id1					= NULL;
	tag_t			tsk_dml_rel_type			= NULL;
	tag_t			*DMLRevision				= NULL;
	tag_t			*secondary_objects			= NULL;
	tag_t			*PartsTag					= NULL;
	tag_t			objTypeTag					= NULL;


	tag_t			DMLRevTag					= NULLTAG;
	tag_t			relation_type				= NULLTAG;
	tag_t			AssyTag						= NULLTAG;

	char			*status_name				= NULL;

	char			*rev_id						= NULL;
	char			*releaseType				= NULL;
	char			*t5current_name				= NULL;
	char			*s							= NULL;
	char			*class_name					= NULL;
	char			*class_name1				= NULL;
	char		   *projectname					= NULL;
	char		   *DMLNumber					= NULL;
	char		   *taskGrp					    = NULL;
	char		   *current_name				= NULL;
	char		   *t5current_name1				= NULL;
	char		   *object_type					= NULL;
	char		   *Part_no						= NULL;
	char		   *ProjCode						= NULL;
	char		   *tempPart_no					= NULL;
	char		   type_name[TCTYPE_name_size_c+1];
	char		   *NRRevCheck					= NULL;
	char		   *token						= NULL;
	char		  *masterObjStr =NULL;
	char		   *childWithNR_ERC_Review			 = NULL;

	EPM_decision_t decision						= EPM_go;
	tag_t	CCVCrelation_typeDR	= NULLTAG;
	tag_t	*CCVCTags		= NULLTAG;
	char* VCNO =NULL;
	char* vcObjStr =NULL;
	int CCVCCount =0;
	char    *PartType               = NULL;
	char *VCPartType				= NULL;


	tag_t	VCVehicalDesignMasterTag	= NULLTAG;
	int level 			       =    0;
	int containerCount         =    0;

	childWithNR_ERC_Review						=(char *)MEM_alloc(500);

	tc_strcpy(childWithNR_ERC_Review," ");
	tc_strcat(childWithNR_ERC_Review,"Part No : ");


	char		   *DMLtype						= NULL;
	char		   *DMLNo						= NULL;
	logical is_latest;
	logical VCVehNotAttach =true;
	logical alrozWay =false;
	logical hornbillWay =false;
	tag_t	MasterTag	= NULLTAG;

	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;

	//int  	options;
	int  	n_shared_sites;
	int  	ic=0;
	char	** shared_sites ;
	char* attributeValue		= NULL;
	char* attributeValue1		= NULL;
	tag_t Design_rev_cls_tag    = NULLTAG;
	char    *t5NoEcuDup             = NULL;
	int		t5NoEcuDupint  = 0;
	NRRevCheck=(char *)MEM_alloc(300);
	//

	////For Altroz way Control Object
	tag_t AltrozWayQuery			 = NULLTAG;
	int	   noOfInputAltWay			 = 2;
	char *qryInputForAltWay[2]       = {"SYSCD", "SUBSYSCD"};
	char *qryProjValForAltWay[2]     = {"Project", "AltrozWay"};
	int   AltWayCount				 = 0;
	tag_t *AltWayCnObj				 = NULL;
	char *info1AltrozWay			 = NULL;

	////For Hornbill VCs Control Object
	tag_t HornbillWayQuery			 = NULLTAG;
	int	   noOfInputHornbillWay			 = 2;
	char *qryInputForHornbillWay[2]       = {"SYSCD", "SUBSYSCD"};
	char *qryProjValForHornbillWay[2]     = {"Hornbill_Way_VC", "Hornbill_Way"};
	int   HornbillWayCount				 = 0;
	tag_t *HornbillWayCnObj				 = NULL;
	char *info1HornbillWay			 = NULL;

	CALLAPI(POM_get_user_id (&username));
	printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);
	if(tc_strcmp(username,"infodba"))
		//if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
    {
		//CALLAPI(EPM_ask_root_task(msg.task,&root_task));
		//printf("\n\n\t\t Root task found");

		//CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count1,&attachments));
		//printf("\n\n\t\t EPM_ask_attachments of :: %d",count1);

		int		count			=0;
		tag_t	item_tag		= NULLTAG;
		tag_t	*rev_list		= NULL;

	
		ifail = ITEM_find_item (item_id, &item_tag);
		CHECK_FAIL;
	
		ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
		CHECK_FAIL;

		if(count > 0)
		{
			DMLLcmTag = rev_list[0];
	    }
		ifail = AOM_ask_value_string(DMLLcmTag,"current_id",&t5current_name);
		printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);

		 if ( ifail != ITK_ok)
		 {
			 EMH_ask_error_text( ifail, &s);
			 printf("Error with AOM_ask_value_string : %s \n",s);
			 MEM_free(s);
			 return ifail;
		 }

		 ifail = POM_class_of_instance(DMLLcmTag,&class_id);
		 ifail = POM_name_of_class(class_id,&class_name);
		 printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout);
		 if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
		 {
			ifail = GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
			if (tsk_dml_rel_type!=NULLTAG)
			{
				ifail = GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count,&DMLRevision);
				printf("\n\n\t\t ***********DML Revision from Task **********: %d",count);fflush(stdout);
				for (i=0;i<count ;i++ )
				{
					ifail = ITEM_rev_sequence_is_latest(DMLRevision[i],&is_latest);
					printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
					if(is_latest != true)
					{
						printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);

					} else
					{
						DMLRevTag = DMLRevision[i];

						ifail = AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname);
						printf("\n\n\t\t Projectname from leftObject : %s\n",projectname);fflush(stdout);

						printf("\n\n\t\t is_latest is  true .....\n");fflush(stdout);
						ifail = AOM_ask_value_string(DMLRevTag,"current_name",&current_name);
						printf("\n\n\t\t current_name is :%s\n",current_name);fflush(stdout);

						DMLNumber = strtok( current_name, "_" );
						taskGrp	  = strtok ( NULL, "_" );

						printf("\n\n\t\t DMLNumber is :%s",DMLNumber); fflush(stdout);
						printf("\n\n\t\t taskGrp is :%s",taskGrp); fflush(stdout);

						ifail = AOM_ask_value_int(DMLRevTag,"sequence_id",&sequence_id);
						printf("\n\n\t\t sequence_id is :%d\n",sequence_id);fflush(stdout);

						ifail = POM_class_of_instance(DMLRevTag,&class_id1);
						ifail = POM_name_of_class(class_id1,&class_name1);
						printf("\n\n\t\t class_name found1 :%s",class_name1);

						ifail = AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype);
						printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);

						if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
						{
							if(strcmp(DMLtype,"")==0)
							{
								printf("\n\n\t\t t5_rlstype is NULL\n");fflush(stdout);
								//EMH_clear_errors();
								//EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "ERC-DML Type IsNULL, plz update release type as required");
								//decision = EPM_nogo;
								//eturn decision;

							} //If for DML Type check ends
							else
							{
								ifail = AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo);
								printf("\n\n\t\t DMLNo is :%s",DMLNo);fflush(stdout);

								if((strcmp(DMLtype,"EP")==0))
								{

									// Validation check for ECU Part release DML only
									ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation_type);
									if (relation_type!=NULLTAG)
									{
										ifail = GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects);
										printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);

										if(n_attchs>0)
										{
											 for (j=0;j<n_attchs;j++ )
											 {
													  ifail = AOM_ask_value_string(secondary_objects[j],"current_id",&t5current_name1);
												   printf("\n\n\t\t t5current_name1 is :%s",t5current_name1);fflush(stdout);
												   if ( ifail != ITK_ok)
												   {
													 //EMH_ask_error_text( status, &s);
													 printf("Error with AOM_ask_value_string2 : %s \n",s);
													// MEM_free(s);
													 //return status;
												   }
												   else
												   {
													   ifail = AOM_ask_value_string(secondary_objects[j],"object_type",&object_type);
														printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
														if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
														{
															ifail = AOM_ask_value_tags(secondary_objects[j],"CMHasSolutionItem",&partcnt,&PartsTag);
															printf("\n\n\t\t No. of Part in Solution Folder :%d \n",partcnt);fflush(stdout);

															if (partcnt>0)
															{
																//This is the loop for Solution items present in Solution folder of DML:
																for (k=0;k<partcnt ;k++ )
																{
																		AssyTag=PartsTag[k];
																		ifail = AOM_ask_value_string(AssyTag,"object_string",&Part_no);
																		printf("\n\n\t\t Part_no  is :%s \n",Part_no);	fflush(stdout);

																		ProjCode=subString(Part_no,0,4); 
																		printf("\n  ProjCode is ------------- [%s]\n",ProjCode);fflush(stdout);

																		ifail = TCTYPE_ask_object_type(AssyTag,&objTypeTag);
																		ifail = TCTYPE_ask_name(objTypeTag,type_name);
																		printf("\n\n\t\t AssyTag type_name := %s \n",type_name);fflush(stdout);

																		ITEM_ask_item_of_rev(AssyTag,&MasterTag);
																		ifail = AOM_ask_value_string(MasterTag,"object_string",&masterObjStr);

																		ifail = AOM_ask_value_string(AssyTag,"t5_PartType",&PartType);
																		printf("\n\n\t\t t5_PartType := %s \n",PartType);fflush(stdout);

																		if(strcmp(PartType,"EM")==0)
																		{

																			printf("\n ******* ECU Module Found ************");
																			ifail = GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_typeDR);
																			ifail = GRM_list_primary_objects_only(MasterTag,CCVCrelation_typeDR,&CCVCCount,&CCVCTags);
																			if(CCVCCount >0 )
																			{
																				for(q=0;q <CCVCCount ;q++)
																				{
																					alrozWay =false;
																					hornbillWay =false;
																					////22-Nov-2022 Control ojbect for Altroz Way
																					if(QRY_find2("ControlObjQry", &AltrozWayQuery));
																					if(AltrozWayQuery)
																					{
																						 if(QRY_execute(AltrozWayQuery, noOfInputAltWay, qryInputForAltWay, qryProjValForAltWay, &AltWayCount, &AltWayCnObj));
																						 printf("\n CONT for AltozWay CntrlObj == %d\n", AltWayCount);fflush(stdout);
																					}
																					else
																					{
																						printf("\n ContrlObj for AltozWay not found.");fflush(stdout);
																					}
																					if(AltWayCount >0)
																					{
																						if (AOM_ask_value_string(AltWayCnObj[0],"t5_Userinfo1",&info1AltrozWay)!=ITK_ok);
																						printf("\n Altroz Way Project Codes List [%s]",info1AltrozWay); fflush(stdout);
																					}

																					//222-Nov-2022 Control object for Hornbill VCs
																					if(QRY_find2("ControlObjQry", &HornbillWayQuery));
																					if(HornbillWayQuery)
																					{
																						 if(QRY_execute(HornbillWayQuery, noOfInputHornbillWay, qryInputForHornbillWay, qryProjValForHornbillWay, &HornbillWayCount, &HornbillWayCnObj));
																						 printf("\n CONT for HornbillWay CntrlObj == %d\n", HornbillWayCount);fflush(stdout);
																					}
																					else
																					{
																						printf("\n ContrlObj for HornbillWay not found.");fflush(stdout);
																					}
																					if(HornbillWayCount >0)
																					{
																						if (AOM_ask_value_string(HornbillWayCnObj[0],"t5_Userinfo1",&info1HornbillWay)!=ITK_ok);
																						printf("\n info1HornbillWay Project Codes List [%s]",info1HornbillWay); fflush(stdout);
																					}
				
																					VCVehNotAttach =true;

																					if(AOM_ask_value_string(CCVCTags[q],"object_string",&vcObjStr)==ITK_ok);
																					printf("\n  VC vcObjStr  is  = [%s]\n", vcObjStr);fflush(stdout);

																					if(AOM_ask_value_string(CCVCTags[q],"item_id",&VCNO)==ITK_ok);
																					printf("\n  VC item_id  is  = [%s]\n", VCNO);fflush(stdout);

																					AOM_ask_value_string(CCVCTags[q],"t5_PartType",&VCPartType);
																					printf("\n  VC t5_PartType  is  = [%s]\n", VCPartType);fflush(stdout);
																					
																					//Here Altroz way and Hornbill way logic will come
																					if((tc_strstr(info1HornbillWay,VCNO) != NULL || tc_strcmp(ProjCode,"5445")==0) && tc_strcmp(VCPartType,"CCVC")==0)
																					{
																						printf("\n inside Hornwill way, VC with proj %s \n",ProjCode);fflush(stdout);
																						//VehVcTag = DesignRevTag;	
																						hornbillWay =true;

																					}
																					//else if(tc_strstr(info1AltrozWay,ProjDup) != NULL || tc_strcmp(ProjDup,"5477")==0 && tc_strcmp(VCPartType,"V")==0)
																					else if((tc_strstr(info1AltrozWay,ProjCode) != NULL || tc_strcmp(ProjCode,"5477")==0) && tc_strcmp(VCPartType,"V")==0)
																					{
																						printf("\n inside Altroz way, VC with proj %s \n",ProjCode);

																						alrozWay =true;
																						//VehVcTag = DesignRevTag;
																						//sTmpNum=subString(VCnumber,0,8);
																						//tc_strcpy(VCnumberDup,sTmpNum);
																						//tc_strcat(VCnumberDup,"000R");
																						//printf("\nConcatenated VC number is [%s]\n",VCnumberDup);fflush(stdout);
																					}
																					else
																					{
																						printf("\nContinuing...\n");  fflush(stdout);
																						continue;
																					}
																					//Hornbill way , Altroze way condition:
																					if(hornbillWay && tc_strcmp(VCPartType,"CCVC")==0)
																					{
																						ITEM_ask_item_of_rev(CCVCTags[q],&VCVehicalDesignMasterTag);
																						CALLAPI(ICS_keylov_get_keylov("-8226",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));

																						printf("\n VC validation key_lov_name===[%s]--- n_lov_entries===[%d]--- options===[%d]\n",key_lov_name,n_lov_entries,options); fflush(stdout);
																						for(ic=0;ic<n_lov_entries;ic++)
																						{
																							printf("\n lov_keys=[%s] lov_values=[%s]\n",lov_keys[ic],lov_values[ic]); fflush(stdout);
																							(ICS_ask_classification_object(VCVehicalDesignMasterTag,&Design_rev_cls_tag));

																							(ICS_ask_attribute_value	(Design_rev_cls_tag,"8226",&attributeValue));

																							printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);
																							if(tc_strcmp(attributeValue,lov_keys[ic])==0)
																							{
																								printf("\n Value of classified object: \n Mascot lov_keys=%s lov_values=%s",lov_keys[ic],lov_values[ic]); fflush(stdout);

																								t5NoEcuDup		   =(char *) MEM_alloc(20);
																								tc_strcpy(t5NoEcuDup,lov_values[ic]);

																								printf("\n******************** ECU COUNT IS ************ =%s",t5NoEcuDup); fflush(stdout);//10

																								t5NoEcuDupint=atoi(t5NoEcuDup);

																								printf("\n *******************final ECU COUNT is t5NoEcuDupint *********** =%d",t5NoEcuDupint); fflush(stdout);//10

																							}

																						}
																					}
																					else if(alrozWay && tc_strcmp(VCPartType,"V")==0)
																					{
																						ITEM_ask_item_of_rev(CCVCTags[q],&VCVehicalDesignMasterTag);
																						CALLAPI(ICS_keylov_get_keylov("-8226",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));

																						printf("\n VC validation key_lov_name===[%s]--- n_lov_entries===[%d]--- options===[%d]\n",key_lov_name,n_lov_entries,options); fflush(stdout);
																						for(ic=0;ic<n_lov_entries;ic++)
																						{
																							printf("\n lov_keys=[%s] lov_values=[%s]\n",lov_keys[ic],lov_values[ic]); fflush(stdout);
																							(ICS_ask_classification_object(VCVehicalDesignMasterTag,&Design_rev_cls_tag));

																							(ICS_ask_attribute_value	(Design_rev_cls_tag,"8226",&attributeValue));

																							printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);
																							if(tc_strcmp(attributeValue,lov_keys[ic])==0)
																							{
																								printf("\n Value of classified object: \n Mascot lov_keys=%s lov_values=%s",lov_keys[ic],lov_values[ic]); fflush(stdout);

																								t5NoEcuDup		   =(char *) MEM_alloc(20);
																								tc_strcpy(t5NoEcuDup,lov_values[ic]);

																								printf("\n******************** ECU COUNT IS ************ =%s",t5NoEcuDup); fflush(stdout);//10

																								t5NoEcuDupint=atoi(t5NoEcuDup);

																								printf("\n *******************final ECU COUNT is t5NoEcuDupint *********** =%d",t5NoEcuDupint); fflush(stdout);//10

																							}

																						}
																						

																					}
																					else 
																					{
																							if(hornbillWay)
																							{
																								printf("This VC is Hornbill way, i.e Part type should be 'CCVC'");
																								//Give Error 
																							}
																							if (alrozWay)
																							{
																								printf("This VC is alrozWay way, i.e Part type should be 'V'");
																								//Give Error
																							}
																					}
																					
																				}// VC For Loop ends 
																			}
																			else 
																			{
																				 printf("\n No CCVC / V is attached to ECU Module."); fflush(stdout);
																				 VCVehNotAttach =false;
																			}
																			//If CCVC or V is attached then apply this check.
																			if(VCVehNotAttach)
																			{
																				  VC_Multi_Get_Part_BOM_Lvl_Col_SW(99,level,AssyTag,&containerCount);
																				  printf("\n ******************final count of containers  is  ****************** [%d] \n",containerCount);fflush(stdout);

																				  if(containerCount==t5NoEcuDupint)
																				  {
																					  printf("\n count matching well done S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
																				  }
																				  else
																				  {
																					printf("\n count does not match S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
																					printf("\n VCNO is : %s \n",VCNO);fflush(stdout);
																					printf("\n ModulNo is : %s \n",Part_no);fflush(stdout);

																					//if (tc_strcmp(ECUCountErr,"NULL") !=0) MEM_free(ECUCountErr);
																					//ECUCountErr=(char *)MEM_alloc(600);
																					//tc_strcpy(ECUCountErr,"For ");
																					//tc_strcat(ECUCountErr,VCnumber);
																					//tc_strcat(ECUCountErr," the Value of Attribute - number of ECU's -is not matching with the actual number of containers in ECU module ");
																					//tc_strcat(ECUCountErr,ModulNo);

																					//printf("\n ECUCountErr= [%s] \n",ECUCountErr);fflush(stdout);

																					//EMH_clear_errors();
																					//EMH_store_error_s1(EMH_severity_error,ITK_err,ECUCountErr);
																					//decision = EPM_nogo;
																					//return decision;
																				  }

																			}// if for VC Vech Attached

																		}// ECU Module Check 
																		
																	containerCount = 0;
																	t5NoEcuDupint = 0;		
																}// For loop for Solution Items end:
															}

														}//If for T5_ChangeTaskRevision ends
												   }
											 }
										}
									}

								}// If for EP DML Type ends
							}

						}// if for ChangeRequestRevision class check ends

					}

				}// For DML Revision end

			} //if for tsk_dml_rel_type relation null check

		 } //If for T5_ChangeTaskRevision ends

	}// If of DBA Users ends
	printf("\n\n\t\t End of function Check_ECUCountValidaitonForECU_Module... \n");fflush(stdout);
	
	return ifail;
}

int GValue=1000;
int VC_Multi_Get_Part_BOM_Lvl_Col_SW(int reqLevel,int level,tag_t Mod_rev_tag, int *containerCount)
{
	int ifail;
	int status = 0;
    int iChildItemTag=0;
	char * ItemName;
	int k		    =0;
    int n_Cnt	    =0;
    int assbvr	    =0;
    int flagBVR	    =0;
	int n_values_bvr=0;

	tag_t   t_ChildItemRev;
	//tag_t	window 	    = NULLTAG;

	tag_t	top_line    = NULLTAG;
	int bvrfound		= 0;
	tag_t  *children	= NULLTAG;
	char* partNumber 	= NULL;
	char* PartType      = NULL;
	char* EE_PartType      = NULL;
	char* LatChildName      = NULL;
	char* ObjType       = NULL;
	char* BLObjType     = NULL;
	tag_t	sn_rule		= NULLTAG;
	tag_t	window		= NULLTAG;

	


	printf("\n INSIDE MULTI LEVEL EXP FUNCTION \n");fflush(stdout);

	if(level == reqLevel) goto CLEANUP;
	ITK_CALL(BOM_create_window (&window)); //3 sept

	ITK_CALL(BOM_set_window_pack_all (window, true));//3 sept

	ITK_CALL(CFM_find("ERC Review And Above", &sn_rule ));

	ITK_CALL(BOM_set_window_config_rule( window, sn_rule ));

	ITK_CALL(BOM_set_window_top_line (window, null_tag,Mod_rev_tag,null_tag, &top_line));

	ITK_CALL(BOM_window_show_suppressed (window));

	printf("\n after BOM_set_window_top_line in VC_Multi_Get_Part_BOM_Lvl_1 \n");fflush(stdout);

	ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));// 3 sept
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	ITK_CALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children)); //3 sept
	printf("\n\n\t\t **** No of child objects are n level :: %d :: %d\n",level, n_Cnt);fflush(stdout);

	if(n_Cnt == 0) goto CLEANUP;
	for (k = 0; k < n_Cnt; k++)
	  {
		BOM_line_unpack (children[k]);
		//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
		//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);

		if( AOM_ask_value_tag(children[k],"bl_line_object",&t_ChildItemRev)!=ITK_ok);

		if(t_ChildItemRev!=NULLTAG)
		{
			//if( AOM_ask_value_string(children[k],"bl_T5_EE_PartRevision_t5_SwPartType",&PartType)!=ITK_ok);
			if( AOM_ask_value_string(children[k],"bl_T5_EE_PartRevision_t5_SwPartType",&PartType)!=ITK_ok);
			if( AOM_ask_value_string(children[k],"bl_T5_EE_PartRevision_t5_EE_PartType",&EE_PartType)!=ITK_ok);

			printf("\n t_ChildItemRev Part type  ===>%s\n",PartType);fflush(stdout);

			if( AOM_ask_value_string(children[k],"bl_item_item_id",&LatChildName)!=ITK_ok);
			printf("\n  LatChildName Parts Id : [%s] \n",LatChildName);

			char   dRftSpectype_name[TCTYPE_name_size_c+1];
			tag_t  DrftSpecTypeTag = NULLTAG;

			if(TCTYPE_ask_object_type(t_ChildItemRev,&DrftSpecTypeTag));
			if(TCTYPE_ask_name(DrftSpecTypeTag,dRftSpectype_name));

			printf("\n t_ChildItemRev tag found ===>%s\n",dRftSpectype_name);fflush(stdout);
			
			if((GValue==777)&&(tc_strcmp(PartType,"CON")==0))
				{
					*containerCount=*containerCount+1;
				    printf("\n count after is [%d] -- %s for part number -%s\n",*containerCount, PartType,LatChildName);fflush(stdout);
					GValue=0;
				}
			
			if(tc_strcmp(EE_PartType,"G")==0)    //first find G value
			{
				//Expand and check if Container is there or not
				GValue=777;
				VC_Multi_Get_Part_BOM_Lvl_Col_SW(reqLevel,level,t_ChildItemRev,containerCount); //3 sept
				
			}
			else if(tc_strcmp(PartType,"CON")==0)
			{
				*containerCount=*containerCount+1;
				printf("\n count after is [%d] -- %s for part number -%s\n",*containerCount, PartType,LatChildName);fflush(stdout);
			}

			VC_Multi_Get_Part_BOM_Lvl_Col_SW(reqLevel,level,t_ChildItemRev,containerCount); //3 sept
		 }
	  }
	level = level + 1;

	window = NULLTAG;

	CLEANUP:
		printf("\n Inside VC_Multi_Get_Part_BOM_Lvl_1 function CLEANUP\n");fflush(stdout);

	return 0;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}