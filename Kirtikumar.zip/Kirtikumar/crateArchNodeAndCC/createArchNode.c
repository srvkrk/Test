#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 50
#define NUMWORDS 3

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = read_value_from_file(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				//item_id = strtok(temp, ",");
				item_id = strtok(temp, "#");
				//printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	//fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    
********************************************************************************************/
int check_rel_status(char* item_id)
{
	tag_t item_type_tag				= NULLTAG;
	tag_t item_create_input_tag		= NULLTAG;
	tag_t cfg_item_create_input_tag = NULLTAG;
	tag_t object					= NULLTAG;
	tag_t cfg_object				= NULLTAG;
	tag_t cfg_item_type_tag			= NULLTAG;
	tag_t relation_type				= NULLTAG;
	tag_t new_relation				= NULLTAG;
	char* error_str					= NULL;
	tag_t cc_item_tag    = NULLTAG;;
	tag_t cc_item_Rev_tag = NULLTAG;;


	char *object_name = (char *) MEM_alloc( 2000 * sizeof(char) );
	char *obj_item_id = (char *) MEM_alloc( 2000 * sizeof(char) );
	char *token		  = NULL;
	char data[NUMWORDS][STRSIZE];
	char *buffer;
    int i;
	//boolean ccValue = true;

	char *cc_id =  (char *) MEM_alloc( 2000 * sizeof(char) );;
	char *temp	=  (char *) MEM_alloc( 2000 * sizeof(char) );;


	printf("\n\tInput Item ID is: %s\n\t",item_id);

	buffer = strtok(item_id, ";");
	i = 0;
	 while (buffer != NULL) {
        strcpy(data[i], buffer);

        //printf("data[%i] = %s\n\t", i+1, data[i]);
        buffer = strtok(NULL, ";");
        i++;
    }

	tc_strcpy(obj_item_id, data[0]);
	tc_strcpy(object_name, data[1]);

	printf("\n\t obj_item_id :%s", obj_item_id);
    printf("\n\t object_name :%s", object_name);

	printf("\n\t *****Creating the Arch Module******");

	ITK_CALL(TCTYPE_find_type("T5_ArchModule", "Item", &item_type_tag));
	ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
	ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_id));
	ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
	ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
	ITK_CALL(AOM_save (object));

	//Now creating the CC for Arch Module.
	printf("\n\t *****Creating the Configurator Context ******");
	tc_strcpy(temp, obj_item_id);
	tc_strcat(temp,"_CC");
	tc_strcpy(cc_id, temp);
	
	printf("\n\t Config Context ID :%s", cc_id);

	ITK_CALL(TCTYPE_find_type("Cfg0ProductItem","Item",&cfg_item_type_tag));
	if(cfg_item_type_tag == NULLTAG)
	{
		printf("\n\t Cfg0ConfContext type not found.");
		return ifail;
	}
	ITK_CALL(TCTYPE_construct_create_input(cfg_item_type_tag, &cfg_item_create_input_tag));
	ITK_CALL(AOM_set_value_logical(cfg_item_create_input_tag, "cfg0PosBiasedVariantAvail", true));
	ITK_CALL(AOM_set_value_string(cfg_item_create_input_tag, "item_id", cc_id));
	ITK_CALL(AOM_set_value_string(cfg_item_create_input_tag, "object_name", object_name));
	ITK_CALL(TCTYPE_create_object (cfg_item_create_input_tag, &cfg_object));
	ITK_CALL(AOM_save (cfg_object));

	printf("\n\t *****Creating relation of Arch Module and Configuration Context ******");
	ITK_CALL(GRM_find_relation_type ("Smc0HasVariantConfigContext", &relation_type));
	ITK_CALL(GRM_create_relation (object, cfg_object, relation_type, NULLTAG, &new_relation));
	ITK_CALL(GRM_save_relation (new_relation));
	ITK_CALL(AOM_save (object));

	if(object_name != NULL)
		MEM_free(object_name);

	if(obj_item_id != NULL)
		MEM_free(obj_item_id);

	if(buffer != NULL)
		MEM_free(buffer);

	if(cc_id != NULL)
		MEM_free(cc_id);

	if(temp != NULL)
		MEM_free(temp);

	return ifail;
}
