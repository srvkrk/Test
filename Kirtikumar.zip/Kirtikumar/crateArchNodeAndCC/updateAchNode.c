#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}

	//ifail = ITK_set_bypass(true);
    // if (ifail != ITK_ok)
	//{
	//printf("\nUser is not Privileged Admin User \n\n");
	//return -1;
	//}	
	
	ifail = read_value_from_file(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Arch Node is  :%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	//fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	int				i 							= 0;
	int				j 							= 0;
	int				count 						= 0;
	int				count_status				= 0;
	int				num							= 0;
	int*			state_token;
	tag_t			item_tag					= NULLTAG;
	//tag_t			*status_list				= NULL;
	tag_t			rev_list					= NULLTAG;
	//tag_t *			allWorkflow					= NULL;
	//tag_t			tp_close_status_tag;
	//tag_t			date_released_attr			= NULL;

	
	//char			*status						= NULL;
	char			*object_name				= NULL;
	//char			*workflowName				= NULL;
	//char			*wfEndDate;
	
	//char			*rev_id						= NULL;
	date_t			workflowEndDate;
	
	ITK_CALL(ITEM_find_item (item_id, &item_tag));
	ITK_CALL(ITEM_ask_latest_rev(item_tag,&rev_list));
	
	if(rev_list !=NULLTAG)
	{
		ITK_CALL(AOM_ask_value_string(rev_list,"object_string",&object_name));
		printf("\nArch Node Rev Name... %s\n", object_name);
		ITK_CALL(AOM_refresh(rev_list,1));
		ITK_CALL(AOM_set_value_string(rev_list,"t5_ArchProjectCode","5171"));
		ITK_CALL(AOM_save(rev_list));
		ITK_CALL(AOM_refresh(rev_list,0));

	}
	CHECK_FAIL;	
	
	return ifail;
}
