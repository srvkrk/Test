#include <time.h>
#include <tc/tc.h>
#include <ae/dataset.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <itk/mem.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pom/pom/pom.h>
#include <tccore/grm.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <unistd.h>
#include <tc/folder.h>

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

int read_value_from_file(char*);
int getAggrigatevalues(char* PartNo,char *ModuleAddress);
int getModuleGroup(char* PartNo,char *Aggregates,char *ModuleAddress,char* AggregateGroup);
int GetModuleValue(char* PartNo,char *Aggregates,char * ModuleAddress,char*ModuleGroup,char* AggregateGroup );
int UpdateModuleAttributes(char *PartNo, char* ModuleAddress	,char* AggregateGroup  ,char* Aggregate,char* ModuleGroup	,char* Module, char* ModuleName);
char* subString (char* mainStringf ,int fromCharf,int toCharf);
char* getDesignGroup (char* ModuleAddress);


static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
void print_requirement()
{
	printf(
	"\nHELP:\n"
	"getModuledata -u=<username> -pf=<password file path> -g=<group> -file=<input filename>\n"
	"--------------------------------------------------------------------------------------------\n\n"
	);
}

int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	int				ifail						=ITK_ok;
		
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);


	printf("\nuserid:%s\n\n",userid);
	printf("\npassword:%s\n\n",password);
	printf("\ngroup:%s\n\n",group);
	printf("\nfile:%s\n\n",file);

	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
//	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
//	{
//		print_requirement();
//		return -1;
//	}
	ifail =	ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	
	ifail = read_value_from_file(file);
	printf("\n\t I am in read_value_from_file call... ifail: %d\n",ifail);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}
int read_value_from_file(char* Filename)
{

	
	int				ifail 					= ITK_ok;
	int				result 					= ITK_ok;
	int				count	 				= 0;
	
	char 			*itemid					= NULL;	
	char			*attr_value1			= NULL;
	char 			temp[500];
	//char			*temp					= NULL;
	//char			**info2_values			= (char **) MEM_alloc(20 * sizeof(char *));
	int				array_count				= 0;
	char			*ModuleAddDup			= NULL;
	char			*PartNumberDup			= NULL;
	char 			*ErrorString			= NULL;

	

	FILE* fp = NULL;
	
	fp = fopen(Filename, "r");
	
	printf("IN \n");
	if (fp != NULL)
	{
		printf("IN file 1\n");
		while (fgets(temp, 500, fp)!= NULL)
		{
			printf("\n\t************Temp************ : %s",temp);

			char*			PartNo					= NULL;
			char*			ModuleAddress			= NULL;
			
			if(temp != NULL)
			{
				char *token1 = strtok(temp, "^"); 
				PartNo = token1;
				printf("Part No=%s\n", PartNo); 
				ModuleAddress = strtok(NULL, "^");	
													
				printf("\nInput Module Address Dup:%s\n\n",ModuleAddress);
				
				result = getAggrigatevalues(PartNo,ModuleAddress);
				printf("\n\t I am in getAggrigatevalues call... ifail: %d\n",ifail);

				if(result != ifail)
				{
					printf("Values Not Foud for Module Address or something wrong with getAggrigatevalues = %s\n",ModuleAddress);
				}
			}
			else
			{
				
				printf("Data not found I am at read_value_from_file function");
			}

		}
	}
	else 
	{
		printf("File Unable to Open...!!");
		return 0;
	}

	fclose(fp);
	return ifail;
}
int getAggrigatevalues(char* PartNo,char *ModuleAddress)
{
	char			**Agg_group_values		= (char **) MEM_alloc(10 * sizeof(char *));
	char		    *qry_entries[1]			= {"SYSCD"};
	char			**qry_values			= (char **) MEM_alloc(10 * sizeof(char *));
	char			**info1_values			= (char **) MEM_alloc(10 * sizeof(char *));

	
	tag_t			*NewPartsSet			= NULLTAG;
	tag_t			PrjCdObj				= NULLTAG;
	char*			Model_Information		= NULL;
	int				n_entries = 1;
	int				resultCount				= 0;
    tag_t			queryTag				= NULLTAG;
	int				isFound					= 0;
	char			*strStart 				= (char*) malloc(50*sizeof(char));
	int				result					= ITK_ok;
	int				ifail =0;
	char*			AggregateGroup   	    = NULL;
	char*			Aggregates  			= NULL;

	printf("\n\tI am in getAggrigatevalues function now.\n");
	
	*(strStart+0) = *(ModuleAddress + 2);
	*(strStart+1) = '\0';
	
	Agg_group_values[0] ="B-BIW";
	Agg_group_values[1] ="T-TRIM";
	Agg_group_values[2] ="C-CHASSIS";
	Agg_group_values[3] ="E-E&E";
	Agg_group_values[4] ="P-POWERTRAIN";
	Agg_group_values[5] ="Z-DEV MODULE";

	if(ModuleAddress[1]=='B')
	{
		qry_values[0] = Agg_group_values[0];
		AggregateGroup = Agg_group_values[0];
	}
    else if(ModuleAddress[1]=='T')
	{
		qry_values[0] = Agg_group_values[1];
		AggregateGroup = Agg_group_values[1];
	}
	 else if(ModuleAddress[1]=='C')
	{
		qry_values[0] = Agg_group_values[2];
		AggregateGroup = Agg_group_values[2];
	}
	 else if(ModuleAddress[1]=='E')
	{
		qry_values[0] = Agg_group_values[3];
		AggregateGroup = Agg_group_values[3];
	}
	 else if(ModuleAddress[1]=='P')
	{
		qry_values[0] = Agg_group_values[4];
		AggregateGroup = Agg_group_values[4];
	}
	 else if(ModuleAddress[1]=='Z')
	{
		qry_values[0] = Agg_group_values[5];
		AggregateGroup = Agg_group_values[5];
	}
	//Ouery Find (Control Object)
	ITK_CALL(QRY_find("Control Objects...", &queryTag));
	if (queryTag) 
	{
		printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Not Found Query\n");fflush(stdout);
		return -1;
	}
	
	//Query Execute .................
	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	printf("First Query Object Count, I am in  getAggrigatevalues %d \n\n",resultCount);
	int i;
	if(resultCount > 0)
	{
		for (i=0;i<resultCount ;i++ )
		{
			
			ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo1",&Model_Information));

			printf("ObJect Content Value In Information 1=%s \n\n",Model_Information);
		}
	}

	
	int array_count = 0 ; //here array size vary so we use variable to get size
	if(Model_Information != NULL)
	{
		char *token = strtok(Model_Information, ";"); 
		//char *token = NULL;
		while (token != NULL) 
		{ 
			info1_values[array_count]= token;
			printf("%s\n", token); 
			token = strtok(NULL, ";"); 
			array_count ++;
		} 
	}
	printf("\n\n" );

	int j ;
	for (j=0;j<array_count ;j++ )
	{
		if(strstr(info1_values[j],strStart))
		{
			Aggregates = info1_values[j];
			printf("Aggregates = %s \n\n",Aggregates);
			isFound = 1;
			break;
		}
	}
	 if(isFound == 1){

		ifail = getModuleGroup(PartNo,Aggregates,ModuleAddress,AggregateGroup);
		printf("\n\t I am in getModuleGroup after call... ifail: %d\n",ifail);

   }
   else
   {
		printf("Aggregates Not Found = %s \n\n");
		return -1;
   }
   return  ifail;
}
int getModuleGroup(char* PartNo,char *Aggregates,char *ModuleAddress,char* AggregateGroup )
{
	int				i;
	int				array_count				= 0 ; 
	tag_t			*NewPartsSet			= NULLTAG;
	tag_t			PrjCdObj				= NULLTAG;
	int				n_entries = 1;
	int				resultCount				= 0;
    tag_t			queryTag				= NULLTAG;
	char		    *qry_entries[1]			= {"Information-1"};
	char			**qry_values			= (char **) MEM_alloc(10 * sizeof(char *));
	char			**info2_values			= (char **) MEM_alloc(20 * sizeof(char *));
	char			*Info2StringOp			= NULL;
	int				isFound					= 0;
	int				ifail = 0;
	char*			ModuleGroup  			= NULL;

	printf("\n\tI am in getModuleGroup function now.\n");

	qry_values[0] = Aggregates;
	QRY_find("Control Objects...", &queryTag);
	if (queryTag) 
	{
		printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Not Found Query ,I am in getModuleGroup\n");fflush(stdout);
		return -1;
	}
	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	if(resultCount > 0)
	{
		printf("Second Query Count,I am in getModuleGroup %d \n\n",resultCount);
		for (i=0;i<resultCount ;i++ )
		{
			ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo2",&Info2StringOp));
			printf("ObJect Content Value In Information 2=%s \n\n",Info2StringOp);fflush(stdout);

			if(Info2StringOp != NULL)
			{
				char *token1 = strtok(Info2StringOp, ";"); 
				//char *token = NULL;
				while (token1 != NULL) 
				{ 
					//printf("%d\n",array_count);
					info2_values[array_count]= token1;
					printf("%s\n", token1); 
					token1 = strtok(NULL, ";"); 
					array_count ++;
					//printf("%d\n",array_count);
				}
				//strcat(var, "-");
				//printf("concate String value %s",var);
				int j ;
				for (j=0;j<array_count ;j++ )
				{
					char *temp = info2_values[j];
					//if(strstr(info2_values[j],"A-"))
					if(temp[0]==ModuleAddress[3])
					{
						ModuleGroup = info2_values[j];
						printf("O/p ModuleGroup=== %s \n\n",info2_values[j]);fflush(stdout);
						isFound = 1;
						break;
					}
				}
			}

		}
	}
	else
	{
		printf("Second Query Count null \n\n");
	}
	if(isFound == 1){
		
		printf("\nPartNo :  %s",PartNo);
		printf("\nAggregates :%s",Aggregates);
		printf("\nModuleAddress : %s",ModuleAddress);
		printf("\nModuleGroup : %s",ModuleGroup);
		printf("\nAggregateGroup : %s",AggregateGroup);
		
		ifail = GetModuleValue(PartNo,Aggregates,ModuleAddress,ModuleGroup,AggregateGroup);
		//printf("\n\t I am in GetModuleValue after call... ifail: %d\n",ifail);

	}
	else
	{
		return -1;
	}

	return ifail;
}
int GetModuleValue(char* PartNo, char *Aggregates ,char * ModuleAddress,char* ModuleGroup,char* AggregateGroup)
{
	
	int				i						= 0;
	int				j						= 0;
	int				array_count				= 0 ; 
	tag_t			*NewPartsSet			= NULLTAG;
	tag_t			PrjCdObj				= NULLTAG;
	int				n_entries				= 1;
	int				resultCount				= 0;
    tag_t			queryTag				= NULLTAG;
	char		    *qry_entries[1]			= {"Information-1"};
	char			**qry_values			= (char **) MEM_alloc(2000 * sizeof(char *));
	char			**info2_values			= (char **) MEM_alloc(2000 * sizeof(char *));
	char			*ModuleValueString		= NULL;
	char			*InformationString1		= NULL;
	//char			*QUeryValue				= NULL;
	char			*MAddSubStr				= NULL;
	char			*AggAndModuleGrp		=(char*) malloc(1000*sizeof(char));
	char			*QUeryValue				=(char*) malloc(1000*sizeof(char));
	char			*Info2StringOp			 = NULL;
	char			*Info2StringOp_temp		=NULL;
	char			*Info3StringOp			= NULL;
	char			*Info4StringOp			= NULL;
	char			*Info5StringOp			= NULL;
	char			*Info6StringOp			= NULL;
	char			*Info7StringOp			= NULL;
	char			*Info8StringOp			= NULL;
	char			*Info9StringOp			= NULL;
	
	
	int				isFound					= 0;
	char			PT_module_name[1000]		= "";
	int				ifail = 0;
	char*			Module				    =   NULL;
	char*			ModuleName				=   NULL;
	
	printf("\n\tI am in GetModuleValue function now.\n");
	
	strcpy(QUeryValue,"");
	strcat(QUeryValue,Aggregates);
	printf("Aggregates1 = %s \n\n",Aggregates);
	//String Concate
	strcat(QUeryValue,"*"); 
	printf("Concate = %s \n\n",QUeryValue);
	printf("Aggregates2 = %s \n\n",Aggregates);


	//SubString
	MAddSubStr = subString(ModuleAddress,4,5);
	
	//MAddSubStr="02";
	
	printf("substring = %s \n\n",MAddSubStr);

	//Concate Agg and ModuleGroup With ~ 
	//AggAndModuleGrp = Aggregates;
	strcpy(AggAndModuleGrp,"");
	strcat(AggAndModuleGrp,Aggregates);
	strcat(AggAndModuleGrp,"~");
	strcat(AggAndModuleGrp,ModuleGroup);

	printf("Agg and Module group concate =%s\n\n",AggAndModuleGrp);fflush(stdout);
	
	qry_values[0] = QUeryValue;
	QRY_find("Control Objects...", &queryTag);
	if (queryTag) 
	{
		printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Not Found Query\n");fflush(stdout);
		return -1;
	}

	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));

	if(resultCount > 0) 
	{
		printf("Third Query Count ,I am in GetModuleValue%d \n\n",resultCount);fflush(stdout);
		for (i=0;i<resultCount ;i++ )
		{
			AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo1",&ModuleValueString);
			//printf("\n\t t5_Userinfo1 : %s \n\n",ModuleValueString);fflush(stdout);
			if(ModuleValueString !=NULL) 
			{
				if(strstr(ModuleValueString,AggAndModuleGrp))
				{
						printf("MAtch Obj No = %d\n",i);fflush(stdout);

						ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo2",&Info2StringOp));
						printf("\n\t Info2StringOp string value: %s",Info2StringOp);

						ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo3",&Info3StringOp));
						printf("\n\t Info3StringOp string value: %s",Info3StringOp);

						ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo4",&Info4StringOp));
						printf("\n\tInfo4StringOp string value: %s",Info4StringOp);

						ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo5",&Info5StringOp));
						printf("\n\t Info5StringOp string value: %s",Info5StringOp);

						ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo6",&Info6StringOp));
						printf("\n\t Info6StringOp string value: %s",Info6StringOp);

						ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo7",&Info7StringOp));
						printf("\n\t Info7StringOp string value: %s",Info7StringOp);

						ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo8",&Info8StringOp));
						printf("\n\t Info8StringOp string value: %s",Info8StringOp);

						ITK_CALL(AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo9",&Info9StringOp));
						printf("\n\t Info9StringOp string value: %s",Info9StringOp);

						if(Info2StringOp == NULL)
						{
							tc_strcat(Info2StringOp,"");
						}
						
						if(Info3StringOp == NULL)
						{
							tc_strcat(Info3StringOp,"");
						}
						if(Info4StringOp == NULL)
						{
							tc_strcat(Info4StringOp,"");
						}
						if(Info5StringOp == NULL)
						{
							tc_strcat(Info5StringOp,"");
						}
						if(Info6StringOp == NULL)
						{
							tc_strcat(Info6StringOp,"");
						}
						if(Info7StringOp == NULL)
						{
							tc_strcat(Info7StringOp,"");
						}
						if(Info8StringOp == NULL)
						{
							tc_strcat(Info8StringOp,"");
						}
						if(Info9StringOp == NULL)
						{
							tc_strcat(Info9StringOp,"");
						}
						//Adding all control object value:
						Info2StringOp_temp = (char *) MEM_alloc(2000 * sizeof(char *));
						
						tc_strcpy(Info2StringOp_temp,"");
						tc_strcat(Info2StringOp_temp,Info2StringOp);
						tc_strcat(Info2StringOp_temp,Info3StringOp);
						tc_strcat(Info2StringOp_temp,Info4StringOp);
						tc_strcat(Info2StringOp_temp,Info5StringOp);
						tc_strcat(Info2StringOp_temp,Info6StringOp);
						tc_strcat(Info2StringOp_temp,Info7StringOp);
						tc_strcat(Info2StringOp_temp,Info8StringOp);
						tc_strcat(Info2StringOp_temp,Info9StringOp);
						
						printf("\n\t Info2StringOp_temp string value After concat: %s\n \n",Info2StringOp_temp);
						
						if(Info2StringOp_temp != NULL)
						{

//							char *token1 = strtok(Info2StringOp_temp, ";"); 
//								//char *token = NULL;
//								while (token1 != NULL) 
//								{ 
//									info2_values[array_count]= token1;
//									printf("%s\n", token1); 
//									token1 = strtok(NULL, ";"); 
//									array_count ++;
//								}
//								//strcat(var, "-");
//								//printf("concate String value %s",var);
//								int j ;
//								for (j=0;j<array_count ;j++ )
//								{
//									if(strstr(info2_values[j],MAddSubStr))
//									//if(strstr(ModuleValueString,AggAndModuleGrp))
//									{
//										
//										printf("O/p Module=== %s \n\n",info2_values[j]);fflush(stdout);
//										Module = info2_values[j];
//										break;
//									}
//								}
							 char *token;
							 char* temp = NULL;

							 token = strtok(Info2StringOp_temp,";");
							  while( token != NULL ) {

								  printf("%s\n", token);
							      printf("%s\n", MAddSubStr);

								   if(strstr(token,stripBlanks(MAddSubStr))!= NULL)
								   {
									     Module =(char*) malloc(100*sizeof(char*));
										 tc_strcpy(Module,"");
										 tc_strcpy(Module,token);
										 printf("%s\n", token);
										 printf("%s\n", MAddSubStr);
										 break;
								   }

								  token = strtok(NULL, ";");
							  }
				        }
				}
			}

		}
		
	}

	if(Module !=NULL)
	{
		if(strlen(Module) > 0)
		{
			for(j=3; j<strlen(Module); j++)
			{
				PT_module_name[j-3] = Module[j];
			}
			PT_module_name[j-3] = '\0';
			printf("\nPT_module_name:%s", PT_module_name);

			ModuleName = PT_module_name;
		}
	}
	
	printf("\n \t\t ------All Values------ \n");
	if(PartNo !=NULL)
		printf(" Part Number   =%s\n",PartNo);
	if(ModuleAddress !=NULL)
		printf(" ModuleAddress   =%s\n",ModuleAddress);
	if(AggregateGroup !=NULL)
		printf(" AggregateGroup   =%s\n",AggregateGroup);
	if(Aggregates !=NULL)
		printf(" Aggregates   =%s\n",Aggregates);
	if(ModuleGroup !=NULL)
		printf(" ModuleGroup   =%s\n",ModuleGroup);
	if(Module !=NULL)
		printf(" Module   =%s\n",Module);
	if(ModuleName !=NULL)
		printf(" ModuleName   =%s\n",ModuleName);/**/

	
	//printf(" ModuleAddress =%s\n",ModuleAddress);
	////printf(" AggregateGroup=%s\n",AggregateGroup);
	//printf(" Aggregates    =%s\n",Aggregates);
	//printf(" ModuleGroup   =%s\n",ModuleGroup);
	////printf(" Module        =%s\n",Module);
	//printf(" Module Name   =%s\n",ModuleName);

	ifail = UpdateModuleAttributes(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,ModuleName);

	printf("\n\t I am in UpdateModuleAttributes after call... ifail: %d\n",ifail);


	//write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module, Module,ModuleName);
	
	//if(qry_values != NULL)
		//MEM_free(qry_values);
		
	//if(info2_values != NULL)
		//MEM_free(info2_values);
		
	//if(AggAndModuleGrp != NULL)
		//MEM_free(AggAndModuleGrp);
		
	//if(QUeryValue != NULL)
		//MEM_free(QUeryValue);


	return ifail;
}
int UpdateModuleAttributes(char *PartNo, char* ModuleAddress	,char* AggregateGroup  ,char* Aggregate,char* ModuleGroup	,char* Module, char* ModuleName)
{
	int				ifail 						= ITK_ok;
	int				ifail_1						= ITK_ok;
	int				ifail_dup 				    = ITK_ok;
	int				i		 					= 0;
	
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	tag_t			*rev_list					= NULL;
	char*			strDesignGroup				= NULL;
	
	char 			*prt_type					= NULL;
	char 			*type						= "Module";
	char 			*rev_id						= NULL;
	char			*ObjType					= NULL;
	char			*revision_no				= NULL;
	//char			*Info2StringOp			= NULL;
	char* temModuleAddress =NULL;

	printf("\n Inside Update Method ...Below are the values to be set:::\n");

	char *token;
	token = strtok(ModuleAddress,"\n");

//	while( token != NULL ) {

     // printf( " %s\n", token );
    
     // token = strtok(NULL, "\n");
  // }


	printf(" PartNo   =[%s]\n",PartNo);
	printf(" ModuleAddress   =[%s]\n",token);
	printf(" AggregateGroup   =[%s]\n",AggregateGroup);
	printf(" Aggregate   =[%s]\n",Aggregate);
	printf(" ModuleGroup   =[%s]\n",ModuleGroup);
	printf(" Module   =[%s]\n",Module);
	printf(" ModuleName   =[%s]\n",ModuleName);





	ITK_CALL(ITEM_find_item (PartNo, &item_tag));
	CHECK_FAIL;
	
	ITK_CALL(ITEM_ask_latest_rev (item_tag, &rev_tag));
	//ifail = ITEM_list_all_revs (item_tag, &r_count, &rev_list);

	//AOM_ask_value_string(rev_tag,"object_type",&ObjType);

	ITK_CALL(AOM_get_value_string(rev_tag,"object_type",&ObjType));

	printf("\n Object Type =%s \n",ObjType);
	if(rev_tag == NULLTAG)
	{
		printf("Object not found in Teamcenter...!!\n");
		
		return 0;
	}
	else
	{
		//AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo1",&ModuleValueString);
		//AOM_ask_value_string(rev_tag,"item_revision_id",&rev_id);
		ITK_CALL(AOM_UIF_ask_value (rev_tag, "item_revision_id", &revision_no));
		printf("\nObject Found...!!  \n Revision is = %s\n",revision_no);
		//write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,revision_no);

		ITK_CALL(AOM_refresh (rev_tag, 1));
		/* if(ifail == ITK_ok)
		{ */
			printf("Here is ok");
			if(strcmp(ObjType,"T5_ArchModuleRevision") == 0)
			{
				printf("\n this is architecture Module \n");

				strDesignGroup = getDesignGroup (ModuleAddress);

				printf("\n Desgin group = %s",strDesignGroup);

				printf("\n stripBlanks(ModuleAddress) = %s",stripBlanks(ModuleAddress));
				printf("\n ModuleAddress = %s\n",ModuleAddress);
	
				 ifail = AOM_lock( rev_tag ); 
				 AOM_UIF_set_value (rev_tag, "t5_ArchAggregateGroup",AggregateGroup);
				 AOM_UIF_set_value (rev_tag, "t5_ArchAggregate", Aggregate);
				 AOM_UIF_set_value (rev_tag, "t5_ArchModuleGroup", ModuleGroup);
				 AOM_UIF_set_value (rev_tag, "t5_ArchModule", Module);
				 AOM_UIF_set_value (rev_tag, "t5_ArchModuleName",ModuleName);
				 AOM_UIF_set_value (rev_tag, "t5_ArchModuleAddress",token);
				 /**/
				 AOM_UIF_set_value (rev_tag, "t5_CategoryName",stripBlanks(ModuleName));
				 

				 if((strcmp(strDesignGroup," ") != 0) && (strcmp(strDesignGroup,"0") != 0))
				 {
					 printf("\n Design group is ok\n");
					 AOM_UIF_set_value (rev_tag, "t5_ArchDesignGrp", strDesignGroup);
				 }
				 
				 ifail = AOM_save (rev_tag);
				 AOM_unlock(rev_tag);
				 
				 ifail = AOM_refresh (rev_tag, 0);
				
				 if(ifail == ITK_ok)
				 {
					//write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,revision_no,ModuleName);
					printf("All value found And successfully Stamped for ArcModule");
				 }
				 else
				 {
					 return 0;
				 }
			}
			else
			{
				 printf("After Refresh\n");
				 AOM_UIF_set_value (rev_tag, "t5_AggregateGroup", AggregateGroup);
				 AOM_UIF_set_value (rev_tag, "t5_Aggregate", Aggregate);
				 AOM_UIF_set_value (rev_tag, "t5_Module_Group", ModuleGroup);
				 AOM_UIF_set_value (rev_tag, "t5_Module", Module);
				 AOM_UIF_set_value (rev_tag, "t5_ModuleName", ModuleName);
				 AOM_UIF_set_value (rev_tag, "t5_ModuleAddress", token);
				 //t5_ModuleAddress
				 ifail_1 = AOM_save (rev_tag);
				 AOM_unlock(rev_tag);

				 ifail_1 = AOM_refresh (rev_tag, 0);
				
				 if(ifail_1 == ITK_ok)
				 {
					//write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,revision_no,ModuleName);
					printf("All value found And successfully Stamped");
				 }
				 else
				 {
					 return 0;
				 }
			}
		/*}
		else
		{
			return 0;
		}*/

	}

	//write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,revision_no);
	return ifail;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
char* getDesignGroup (char* ModuleAddress)
{
	
	int				ifail 					= ITK_ok;
	int				iPartCount				=0;

	char			*sProjectCode			= NULL;
	char			*sDsignGrpId			= NULL;
	
	char			**Agg_group_values		= (char **) MEM_alloc(10 * sizeof(char *));
	char		    *qry_entries[1]			= {"SYSCD"};
	char			**qry_values			= (char **) MEM_alloc(10 * sizeof(char *));
	
	tag_t			*NewPartsSet			= NULLTAG;
	tag_t			PrjCdObj				= NULLTAG;
	tag_t			rev_tag					= NULLTAG;
	char*			Model_Information		= NULL;
	int				n_entries				= 1;
	int				resultCount				= 0;
    tag_t			queryTag				= NULLTAG;
	
	char			*inputValue 			= (char*) malloc(50*sizeof(char));
	int				result					= ITK_ok;
	int				i						= 0;
	
	tc_strcpy(inputValue,ModuleAddress);

	QRY_find("Control Objects...", &queryTag);
	if (queryTag) 
	{
		printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Not Found Query\n");fflush(stdout);
		goto EXIT;
	}
	
	qry_values[0]=inputValue;
	printf("inputValue  ::%s",qry_values[0]);fflush(stdout);
	printf("ModuleAddress  ::%s",ModuleAddress);fflush(stdout);


	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	
	printf("Result count = %d ",resultCount);
	if(resultCount > 0)
	{
		for (i=0;i<resultCount ;i++ )
		{
			
			AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo1",&sDsignGrpId);

			printf("ObJect Content Value In Information 1=%s \n\n",sDsignGrpId);

			return sDsignGrpId;
		}
		
	}
	else 
	{
		goto EXIT;
	}
	
	EXIT:
	
	return " ";

}