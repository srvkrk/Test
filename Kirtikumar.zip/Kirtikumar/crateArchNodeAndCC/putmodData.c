#include <time.h>
#include <tc/tc.h>
#include <ae/dataset.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <itk/mem.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pom/pom/pom.h>
#include <tccore/grm.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <unistd.h>
#include <tc/folder.h>

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

FILE 		*output 			= NULL;
char		*sep				= ",";

char*			PartNo					= NULL;
char*		    ModuleAddress			= NULL;
char*			AggregateGroup   	    = NULL;
char*			Aggregates  			= NULL;
char*			ModuleGroup				= NULL;
char*			Module					= NULL;
char 			Data[100]    			= "";
char 			OutputFile[200]    		= "";
char*			revision_no				= NULL;
char*			ModuleName				= NULL;
char*			FileData				= NULL;

/* Methods declaration */
int getAggrigatevalues(char *ModuleAddress);
int getModuleGroup(char *Aggregates,char *ModuleAddress);
int GetModuleValue(char *Aggregates,char * ModuleAddress );
char* subString (char* mainStringf ,int fromCharf,int toCharf);
int read_value_from_file(char* Filename);
int write_info(char *PartNo, char* ModuleAddress,char* AggregateGroup  ,char* Aggregates,char* ModuleGroup	,char* Module,char* revision_no,char* ModuleName);
int UpdateModuleAttributes(char *PartNo, char* ModuleAddress	,char* AggregateGroup  ,char* Aggregate,char* ModuleGroup	,char* Module ,char* ModuleName);
int writeErrorMsgInFile(char *Messsage);
char* getDesignGroup (char* ModuleAddress);


//All Methods Declair Here

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"getModuledata -u=<username> -pf=<password file path> -g=<group> -file=<input filename>\n"
	"--------------------------------------------------------------------------------------------\n\n"
	);
}
/******************************************************
command to run:
** getModuledata -u=<username> -p=<password> -g=<group> -file=<Filename>
Uadev = getModuleData -u=infodba -pf=infodba -g=dba -file=

UA Prod = ./getModuleData -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -file=

UAProd = getModuleData -u=ercpsup -pf=ERCpsup2019 -g=Engineering -file=input_30_Jan_2020.txt

new 

UAProd = getModuleData  -file=input_30_Jan_2020.txt

scp -rp getModuleData bsd05818@172.22.97.12:/user/bsd05818/harshad/ModulStamping

CMITest - ./getModuleData -u=ercpsup -pf=XYT1ESA -g=dba -file=
******************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int			ifail					= 0;
	int			result					= ITK_ok;
	char		* userid 				= NULL;
	char		* password				= NULL;
	char		* group					= NULL;
	
	char*		Filename				= NULL;

	//Filename = "inputfile_module.txt"; ITK_init_module

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
	
	
	printf("username %s \n",userid);
	printf("pass %s \n",password);
	printf("group %s \n",group);
	printf("File name %s \n",Filename);
		
	/*
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}*/

	if(tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}

	printf("\n \n Before Auto Login Result =\n\n");
	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login( );
	//ITK_set_journalling(TRUE);

	//ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	//ifail = ITK_init_module("ercpsup", "XYT1ESA", "dba"); //testcmi Login
	//ifail = ITK_init_module("ercpsup", "ERCpsup2019", "Engineering"); //Uaprod Login
	//ifail = ITK_init_module("ard661971", "ard661971", "dba");

	if(ifail == ITK_ok)
	{
		printf("Login successfull. .........\n\n");
	}
    else
	{	  
	  printf("\n*** Error with ITK_init_module ***\n");fflush(stdout);
	  return ifail;
	}
	ifail = ITK_set_bypass(true);
	time_t now;
	struct tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(OutputFile,"%s_output.txt",Data);
	
	puts(OutputFile);

	output = fopen(OutputFile,"a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
	{
		printf("File opened successfully.\n");
	}	
	
	result = read_value_from_file(Filename);
	if (result == ITK_ok)
	{
		printf("\n\n.............All Parts Are Stamped.......................\n\n");
	}
	
   
	return 1;
}

int getAggrigatevalues(char *ModuleAddress)
{
	char			**Agg_group_values		= (char **) MEM_alloc(10 * sizeof(char *));
	char		    *qry_entries[1]			= {"SYSCD"};
	char			**qry_values			= (char **) MEM_alloc(10 * sizeof(char *));
	char			**info1_values			= (char **) MEM_alloc(10 * sizeof(char *));

	
	tag_t			*NewPartsSet			= NULLTAG;
	tag_t			PrjCdObj				= NULLTAG;
	char*			Model_Information		= NULL;
	int				n_entries = 1;
	int				resultCount				= 0;
    tag_t			queryTag				= NULLTAG;
	int				isFound					= 0;
	char			*strStart 				= (char*) malloc(50*sizeof(char));
	int				result					= ITK_ok;
	//char			strStart[2];

	/* int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;*/

	printf("getAggrigatevalues");
	
	*(strStart+0) = *(ModuleAddress + 2);
	*(strStart+1) = '\0';
	
	//strStart[0] = ModuleAddress[2];
	//strStart[1] = '\0';

	//printf("Neww Test = %s ",strStart);

	Agg_group_values[0] ="B-BIW";
	Agg_group_values[1] ="T-TRIM";
	Agg_group_values[2] ="C-CHASSIS";
	Agg_group_values[3] ="E-E&E";
	Agg_group_values[4] ="P-POWERTRAIN";
	Agg_group_values[5] ="Z-DEV MODULE";

	if(ModuleAddress[1]=='B')
	{
		qry_values[0] = Agg_group_values[0];
		AggregateGroup = Agg_group_values[0];
	}
    else if(ModuleAddress[1]=='T')
	{
		qry_values[0] = Agg_group_values[1];
		AggregateGroup = Agg_group_values[1];
	}
	 else if(ModuleAddress[1]=='C')
	{
		qry_values[0] = Agg_group_values[2];
		AggregateGroup = Agg_group_values[2];
	}
	 else if(ModuleAddress[1]=='E')
	{
		qry_values[0] = Agg_group_values[3];
		AggregateGroup = Agg_group_values[3];
	}
	 else if(ModuleAddress[1]=='P')
	{
		qry_values[0] = Agg_group_values[4];
		AggregateGroup = Agg_group_values[4];
	}
	 else if(ModuleAddress[1]=='Z')
	{
		qry_values[0] = Agg_group_values[5];
		AggregateGroup = Agg_group_values[5];
	}

	//Ouery Find (Control Object)
	QRY_find("Control Objects...", &queryTag);
	if (queryTag) 
	{
		printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Not Found Query\n");fflush(stdout);
		goto EXIT;
	}

	//Query Execute .................
	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	
	printf("Query Object Count %d \n\n",resultCount);
	int i;
	if(resultCount > 0)
	{
		for (i=0;i<resultCount ;i++ )
		{
			
			AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo1",&Model_Information);

			printf("ObJect Content Value In Information 1=%s \n\n",Model_Information);
		}
	}


	
	int array_count = 0 ; //here array size vary so we use variable to get size
	if(Model_Information != NULL)
	{
		char *token = strtok(Model_Information, ";"); 
		//char *token = NULL;
		while (token != NULL) 
		{ 
			info1_values[array_count]= token;
			printf("%s\n", token); 
			token = strtok(NULL, ";"); 
			array_count ++;
		} 
	}
	
	printf("\n\n" );

	
	int j ;
	for (j=0;j<array_count ;j++ )
	{
		if(strstr(info1_values[j],strStart))
		{
			Aggregates = info1_values[j];
			printf("Aggregates = %s \n\n",Aggregates);
			isFound = 1;
			goto BREAKLOOP;
		}
	}

   BREAKLOOP:
   if(isFound == 1){

		getModuleGroup(Aggregates,ModuleAddress);
   }
   else
	{
		return 0;
	}
   EXIT:
   return ITK_ok;
}

int getModuleGroup(char *Aggregates,char *ModuleAddress)
{
	int				i;
	int				array_count				= 0 ; 
	tag_t			*NewPartsSet			= NULLTAG;
	tag_t			PrjCdObj				= NULLTAG;
	int				n_entries = 1;
	int				resultCount				= 0;
    tag_t			queryTag				= NULLTAG;
	char		    *qry_entries[1]			= {"Information-1"};
	char			**qry_values			= (char **) MEM_alloc(10 * sizeof(char *));
	char			**info2_values			= (char **) MEM_alloc(20 * sizeof(char *));
	char			*Info2StringOp			= NULL;
	int				isFound					= 0;
	
	qry_values[0] = Aggregates;


	QRY_find("Control Objects...", &queryTag);
	if (queryTag) 
	{
		printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Not Found Query\n");fflush(stdout);
		goto EXIT;
	}
	//printf("SartWith %c  %s\n\n",ModuleAddress[3],StartWith);

	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));

	if(resultCount > 0)
	{
		printf("Second Query Count %d \n\n",resultCount);
		for (i=0;i<resultCount ;i++ )
		{
			
			AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo2",&Info2StringOp);

			printf("ObJect Content Value In Information 2=%s \n\n",Info2StringOp);fflush(stdout);

			if(Info2StringOp != NULL)
			{
				char *token1 = strtok(Info2StringOp, ";"); 
				//char *token = NULL;
				while (token1 != NULL) 
				{ 
					//printf("%d\n",array_count);
					info2_values[array_count]= token1;
					printf("%s\n", token1); 
					token1 = strtok(NULL, ";"); 
					array_count ++;
					//printf("%d\n",array_count);
				}
				
				
				//strcat(var, "-");
				//printf("concate String value %s",var);
				int j ;
				for (j=0;j<array_count ;j++ )
				{
					char *temp = info2_values[j];
					//if(strstr(info2_values[j],"A-"))
					if(temp[0]==ModuleAddress[3])
					{
						ModuleGroup = info2_values[j];
						printf("O/p ModuleGroup=== %s \n\n",info2_values[j]);fflush(stdout);
						isFound = 1;
						goto BREAKLOOP;
					}
				}
			}
		}
		
	}
	else
	{
		printf("Second Query Count null \n\n");
	}

	BREAKLOOP:
	if(isFound == 1){
		GetModuleValue(Aggregates,ModuleAddress);
	}
	else
	{
		return 0;
	}

	EXIT:
	return 1;
}
//ReviewStartDate=subString(value,0,17);
int GetModuleValue(char *Aggregates ,char * ModuleAddress)
{
	int				i						= 0;
	int				j						= 0;
	int				array_count				= 0 ; 
	tag_t			*NewPartsSet			= NULLTAG;
	tag_t			PrjCdObj				= NULLTAG;
	int				n_entries				= 1;
	int				resultCount				= 0;
    tag_t			queryTag				= NULLTAG;
	char		    *qry_entries[1]			= {"Information-1"};
	char			**qry_values			= (char **) MEM_alloc(10 * sizeof(char *));
	char			**info2_values			= (char **) MEM_alloc(20 * sizeof(char *));
	char			*ModuleValueString		= NULL;
	char			*InformationString1		= NULL;
	//char			*QUeryValue				= NULL;
	char			*MAddSubStr				= NULL;
	char			*AggAndModuleGrp		=(char*) malloc(100*sizeof(char));
	char			*QUeryValue				=(char*) malloc(50*sizeof(char));
	//char			*Info2StringOp			= NULL;
	int				isFound					= 0;
	char			PT_module_name[100]		= "";

	char			*Info2StringOp			= NULL;
	char			*Info3StringOp			= NULL;
	char			*Info4StringOp			= NULL;
	char			*Info5StringOp			= NULL;
	char			*Info6StringOp			= NULL;
	char			*Info7StringOp			= NULL;
	char			*Info8StringOp			= NULL;
	char			*Info9StringOp			= NULL;

	int ifail =0;

	strcpy(QUeryValue,"");
	strcat(QUeryValue,Aggregates);
	printf("Aggregates1 = %s \n\n",Aggregates);
	//String Concate
	strcat(QUeryValue,"*"); 
	printf("Concate = %s \n\n",QUeryValue);
	printf("Aggregates2 = %s \n\n",Aggregates);


	//SubString
	MAddSubStr = subString(ModuleAddress,4,5);
	printf("substring = %s \n\n",MAddSubStr);

	//Concate Agg and ModuleGroup With ~ 
	//AggAndModuleGrp = Aggregates;
	strcpy(AggAndModuleGrp,"");
	strcat(AggAndModuleGrp,Aggregates);
	strcat(AggAndModuleGrp,"~");
	strcat(AggAndModuleGrp,ModuleGroup);

	printf("Agg and Module group concate =%s\n\n",AggAndModuleGrp);fflush(stdout);
	
	qry_values[0] = QUeryValue;
	QRY_find("Control Objects...", &queryTag);
	if (queryTag) 
	{
		printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Not Found Query\n");fflush(stdout);
		goto EXIT;
	}

	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));

	if(resultCount > 0) 
	{
		printf("Third Query Count %d \n\n",resultCount);fflush(stdout);
		for (i=0;i<resultCount ;i++ )
		{
			AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo1",&ModuleValueString);
			
			if(strstr(ModuleValueString,AggAndModuleGrp))
			{
				printf("MAtch Obj No = %d\n",i);fflush(stdout);
				
			
						ifail = AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo2",&Info2StringOp);
						printf("\n\t Info2StringOp string value: %s",Info2StringOp);

						ifail = AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo3",&Info3StringOp);
						printf("\n\t Info3StringOp string value: %s",Info3StringOp);

						ifail = AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo4",&Info4StringOp);
						printf("\n\tInfo4StringOp string value: %s",Info4StringOp);

						ifail = AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo5",&Info5StringOp);
						printf("\n\t Info5StringOp string value: %s",Info5StringOp);

						ifail = AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo6",&Info6StringOp);
						printf("\n\t Info6StringOp string value: %s",Info6StringOp);

						ifail = AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo7",&Info7StringOp);
						printf("\n\t Info7StringOp string value: %s",Info7StringOp);

						ifail = AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo8",&Info8StringOp);
						printf("\n\t Info8StringOp string value: %s",Info8StringOp);

						ifail = AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo9",&Info9StringOp);
						printf("\n\t Info9StringOp string value: %s",Info9StringOp);
						
						if(Info3StringOp == NULL)
						{
							tc_strcat(Info3StringOp,"");
						}
						if(Info4StringOp == NULL)
						{
							tc_strcat(Info4StringOp,"");
						}
						if(Info5StringOp == NULL)
						{
							tc_strcat(Info5StringOp,"");
						}
						if(Info6StringOp == NULL)
						{
							tc_strcat(Info6StringOp,"");
						}
						if(Info7StringOp == NULL)
						{
							tc_strcat(Info7StringOp,"");
						}
						if(Info8StringOp == NULL)
						{
							tc_strcat(Info8StringOp,"");
						}
						if(Info9StringOp == NULL)
						{
							tc_strcat(Info9StringOp,"");
						}
						//Adding all control object value:
						if(Info2StringOp != NULL)
						{
							tc_strcat(Info2StringOp,Info3StringOp);
							tc_strcat(Info2StringOp,Info4StringOp);
							tc_strcat(Info2StringOp,Info5StringOp);
							tc_strcat(Info2StringOp,Info6StringOp);
							tc_strcat(Info2StringOp,Info7StringOp);
							tc_strcat(Info2StringOp,Info8StringOp);
							tc_strcat(Info2StringOp,Info9StringOp);
						}
						printf("\n\t Info2StringOp string value After concat: %s",Info2StringOp);

				if(Info2StringOp != NULL)
				{
					char *token1 = strtok(Info2StringOp, ";"); 
					//char *token = NULL;
					while (token1 != NULL) 
					{ 
						info2_values[array_count]= token1;
						//printf("%s\n", token1); 
						token1 = strtok(NULL, ";"); 
						array_count ++;
					}
					//strcat(var, "-");
					//printf("concate String value %s",var);
					int j ;
					for (j=0;j<array_count ;j++ )
					{
						if(strstr(info2_values[j],MAddSubStr))
						//if(strstr(ModuleValueString,AggAndModuleGrp))
						{
							
							//printf("O/p Module=== %s \n\n",info2_values[j]);fflush(stdout);
							Module = info2_values[j];
							goto BREAKLOOP;
						}
					}
				}
			}


		}
	}
	
	BREAKLOOP:
	
	
	if(strlen(Module) > 0)
	{
		for(j=3; j<strlen(Module); j++)
		{
			PT_module_name[j-3] = Module[j];
		}
		PT_module_name[j-3] = '\0';
		printf("\nPT_module_name:%s", PT_module_name);

		ModuleName = PT_module_name;
	}

	printf("\n \t\t ------All Values------ \n");
	printf(" Part Number   =%s\n",PartNo);
	printf(" ModuleAddress =%s\n",ModuleAddress);
	printf(" AggregateGroup=%s\n",AggregateGroup);
	printf(" Aggregates    =%s\n",Aggregates);
	printf(" ModuleGroup   =%s\n",ModuleGroup);
	printf(" Module        =%s\n",Module);
	printf(" Module Name   =%s\n",ModuleName);

	UpdateModuleAttributes(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,ModuleName);

	//write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module, Module,ModuleName);

	EXIT:
	return 1;
}


//SubString Function(MB1A01 =01)
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


int read_value_from_file(char* Filename)
{

	
	int				ifail 					= ITK_ok;
	int				result 					= ITK_ok;
	int				count	 				= 0;
	
	char 			*itemid					= NULL;	
	char			*attr_value1			= NULL;
	char 			temp[500];
	//char			*temp					= NULL;
	//char			**info2_values			= (char **) MEM_alloc(20 * sizeof(char *));
	int				array_count				= 0;
	char			*ModuleAddDup			= NULL;
	char			*PartNumberDup			= NULL;
	char 			*ErrorString			= NULL;

	FILE* fp = NULL;
	
	fp = fopen(Filename, "r");
	
	printf("IN \n");
	if (fp != NULL)
	{
		printf("IN file 1\n");
		while (fgets(temp, 500, fp)!= NULL)
		{
			printf("Temp = %s\n",temp);
			
			if(temp != NULL)
			{
				char *token1 = strtok(temp, "^"); 
				
			
				PartNo = token1;
				
				printf("Part No=%s\n", PartNo); 

				
				ModuleAddress = strtok(NULL, "^");	
													
				printf("\nInput Module Address Dup:%s\n\n",ModuleAddress);
					
				
				result = getAggrigatevalues(ModuleAddress);
				if(result != ifail)
				{
					printf("Values Not Foud for Module Address = %s\n",ModuleAddress);
				}
			}
			else
			{
				ErrorString ="data not found in line";
				printf("data not found in line for %s \n",ModuleAddress);
				//writeErrorMsgInFile(ErrorString);
				//return 0;
			}

		}
	}
	else 
	{
		printf("File Unable to Open...!!");
		return 0;
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


int write_info(char *PartNo, char* ModuleAddress	,char* AggregateGroup  ,char* Aggregate,char* ModuleGroup	,char* Module,char* revision_no,char* ModuleName)
{
	

	int			ifail 				= ITK_ok;
	
	char 		*test2 				= (char*)MEM_alloc(sizeof(char) * 500);
	char		*final2				= (char*)MEM_alloc(sizeof(char) * 500);
	//printf("write_info 1 \n");
	
	tc_strcpy(test2, "");
	tc_strcat(test2,PartNo);
	printf("PartNo =%s\n",test2);
	tc_strcat(test2,sep);
	tc_strcat(test2,ModuleAddress);
	tc_strcat(test2,sep);
	tc_strcat(test2,AggregateGroup);
	tc_strcat(test2,sep);
	tc_strcat(test2,Aggregates);
	tc_strcat(test2,sep);
	tc_strcat(test2,ModuleGroup);
	tc_strcat(test2,sep);
	tc_strcat(test2,Module);
	tc_strcat(test2,sep);
	tc_strcat(test2,ModuleName);
	tc_strcat(test2,sep);
	tc_strcat(test2,revision_no);
	//tc_strcat(test2,sep);
	
	printf("All String =%s\n",test2);
	//tc_strcpy(final2,test2);
	
	fprintf(output,"%s\n",test2);	
	
	MEM_free(test2);	
	MEM_free(final2);	

	//return ifail;
		

	return 1;
}

int writeErrorMsgInFile(char *Messsage)
{
	int			ifail 				= ITK_ok;
	printf("Error Msg %s \n",Messsage);
	fprintf(output,"%s\n",Messsage);

}

int UpdateModuleAttributes(char *PartNo, char* ModuleAddress	,char* AggregateGroup  ,char* Aggregate,char* ModuleGroup	,char* Module, char* ModuleName)
{
	int				ifail 						= ITK_ok;
	int				ifail_1						= ITK_ok;
	int				ifail_dup 				    = ITK_ok;
	int				i		 					= 0;
	
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	tag_t			*rev_list					= NULL;
	char*			strDesignGroup				= NULL;
	
	char 			*prt_type					= NULL;
	char 			*type						= "Module";
	char 			*rev_id						= NULL;
	char			*ObjType					= NULL;

	//char			*Info2StringOp			= NULL;

	printf("\n Inside Update Method \n",ObjType);

	ifail = ITEM_find_item (PartNo, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_ask_latest_rev (item_tag, &rev_tag);
	//ifail = ITEM_list_all_revs (item_tag, &r_count, &rev_list);

	//AOM_ask_value_string(rev_tag,"object_type",&ObjType);

	AOM_get_value_string(rev_tag,"object_type",&ObjType);

	printf("\n Object Type =%s \n",ObjType);
	
	
	if(ifail != ITK_ok)
	{
		printf("Object not found in Teamcenter...!!\n");
		
		return 0;
	}
	else
	{
		//AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo1",&ModuleValueString);
		//AOM_ask_value_string(rev_tag,"item_revision_id",&rev_id);
		AOM_UIF_ask_value (rev_tag, "item_revision_id", &revision_no);
		printf("\nObject Found...!!  \n Revision is = %s\n",revision_no);
		//write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,revision_no);

		ifail = AOM_refresh (rev_tag, 1);
		/* if(ifail == ITK_ok)
		{ */
			printf("Here is ok");
			if(strcmp(ObjType,"T5_ArchModuleRevision") == 0)
			{
				printf("\n this is architecture Module \n");

				strDesignGroup = getDesignGroup (ModuleAddress);

				printf("\n Desgin group = %s",strDesignGroup);

				
				 ifail = AOM_lock( rev_tag ); 
				 AOM_UIF_set_value (rev_tag, "t5_ArchAggregateGroup", AggregateGroup);
				 AOM_UIF_set_value (rev_tag, "t5_ArchAggregate", Aggregates);
				 AOM_UIF_set_value (rev_tag, "t5_ArchModuleGroup", ModuleGroup);
				 AOM_UIF_set_value (rev_tag, "t5_ArchModule", Module);
				 AOM_UIF_set_value (rev_tag, "t5_ArchModuleName", ModuleName);
				 AOM_UIF_set_value (rev_tag, "t5_ArchModuleAddress", ModuleAddress);
				/* */
				 AOM_UIF_set_value (rev_tag, "t5_CategoryName", ModuleName);
				 

				 if((strcmp(strDesignGroup," ") != 0) && (strcmp(strDesignGroup,"0") != 0))
				 {
					 printf("\n Design group is ok\n");
					 AOM_UIF_set_value (rev_tag, "t5_ArchDesignGrp", strDesignGroup);
				 }
				 
				 ifail = AOM_save (rev_tag);
				 AOM_unlock(rev_tag);
				 
				 ifail = AOM_refresh (rev_tag, 0);
				
				 if(ifail == ITK_ok)
				 {
					write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,revision_no,ModuleName);
					printf("All value found And successfully Stamped for ArcModule");
				 }
				 else
				 {
					 return 0;
				 }
			}
			else
			{
				 printf("After Refresh\n");
				 AOM_UIF_set_value (rev_tag, "t5_AggregateGroup", AggregateGroup);
				 AOM_UIF_set_value (rev_tag, "t5_Aggregate", Aggregates);
				 AOM_UIF_set_value (rev_tag, "t5_Module_Group", ModuleGroup);
				 AOM_UIF_set_value (rev_tag, "t5_Module", Module);
				 AOM_UIF_set_value (rev_tag, "t5_ModuleName", ModuleName);
				 AOM_UIF_set_value (rev_tag, "t5_ModuleAddress", ModuleAddress);
				 //t5_ModuleAddress
				 ifail_1 = AOM_save (rev_tag);
				 AOM_unlock(rev_tag);

				 ifail_1 = AOM_refresh (rev_tag, 0);
				
				 if(ifail_1 == ITK_ok)
				 {
					write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,revision_no,ModuleName);
					printf("All value found And successfully Stamped");
				 }
				 else
				 {
					 return 0;
				 }
			}
		/*}
		else
		{
			return 0;
		}*/

	}
	


	//write_info(PartNo,ModuleAddress	, AggregateGroup  ,Aggregates,ModuleGroup, Module,revision_no);
	return ifail;
}


char* getDesignGroup (char* ModuleAddress)
{
	
	int				ifail 					= ITK_ok;
	int				iPartCount				=0;

	char			*sProjectCode			= NULL;
	char			*sDsignGrpId			= NULL;
	
	char			**Agg_group_values		= (char **) MEM_alloc(10 * sizeof(char *));
	char		    *qry_entries[1]			= {"SYSCD"};
	char			**qry_values			= (char **) MEM_alloc(10 * sizeof(char *));
	
	tag_t			*NewPartsSet			= NULLTAG;
	tag_t			PrjCdObj				= NULLTAG;
	tag_t			rev_tag					= NULLTAG;
	char*			Model_Information		= NULL;
	int				n_entries				= 1;
	int				resultCount				= 0;
    tag_t			queryTag				= NULLTAG;
	
	char			*inputValue 			= (char*) malloc(50*sizeof(char));
	int				result					= ITK_ok;
	int				i						= 0;
	
	tc_strcpy(inputValue,ModuleAddress);

	QRY_find("Control Objects...", &queryTag);
	if (queryTag) 
	{
		printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Not Found Query\n");fflush(stdout);
		goto EXIT;
	}
	
	qry_values[0]=inputValue;


	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	
	printf("Result count = %d ",resultCount);
	if(resultCount > 0)
	{
		for (i=0;i<resultCount ;i++ )
		{
			
			AOM_ask_value_string(NewPartsSet[i],"t5_Userinfo1",&sDsignGrpId);

			printf("ObJect Content Value In Information 1=%s \n\n",sDsignGrpId);

			return sDsignGrpId;
		}
		
	}
	else 
	{
		goto EXIT;
	}
	
	EXIT:
	
	return " ";

}

//char* ModuleAddress	,char* AggregateGroup  ,char* Aggregates,char* ModuleGroup	,char* Module				

