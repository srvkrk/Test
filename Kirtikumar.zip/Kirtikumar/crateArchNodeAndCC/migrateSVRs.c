#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 50
#define NUMWORDS 3

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*,char*);
int check_rel_status(char*,tag_t);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			* platformID				= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	platformID 		= ITK_ask_cli_argument("-pf_id=");
	file 			= ITK_ask_cli_argument("-file=");
		
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = read_value_from_file(file,platformID);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename,char* platformID)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];

	//Getting the tag of Platform
	int		No_of_Entry = 1 ;
	char    *Q_Entry[1]  = {"Item ID"};
	char	**Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
	int platformCount = 0;
	tag_t   Qry_tag     = NULLTAG;
	tag_t *platform_tag = NULLTAG;
	tag_t type_tag		= NULLTAG;
	char* type_Name     =NULL;

	if(QRY_find("Item ID", &Qry_tag));
	if (Qry_tag)
	{
		printf("\n Item ID Query Found \n");fflush(stdout);
		Q_Value[0]=platformID;

		if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &platformCount, &platform_tag));
		printf("\n No of Platform Found = %d\n",platformCount);fflush(stdout);

		ITK_CALL(TCTYPE_ask_object_type(platform_tag[0],&type_tag));
		ITK_CALL(TCTYPE_ask_name2(type_tag,&type_Name));
		printf("\n PF Object Type is : %s \n",type_Name);fflush(stdout);
		if(tc_strcmp(type_Name,"Cfg0ProductItem") !=0)
		{
			printf("\n Wrong Object Type found ....\n");
			return -1;
		}

	}
	if(platform_tag == NULLTAG)
	{
		printf("\nPlatform Tag not found....");fflush(stdout);
		return -1;
	}
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				//item_id = strtok(temp, "#");
				//printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id,platform_tag[0]);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	//fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    
********************************************************************************************/
int check_rel_status(char* item_id,tag_t platformTag)
{
	char* object_string_pf		= NULL;
	tag_t relation_type			= NULLTAG;
	tag_t new_relation			= NULLTAG;

	ITK_CALL(AOM_ask_value_string(platformTag,"object_string",&object_string_pf));
	printf("\n Platform Object String is  : %s",object_string_pf);fflush(stdout);
	printf("\n Input SVR is   : %s\n",item_id);fflush(stdout);

	//Getting tag of SVR
	//Getting the tag of Platform
	int		No_of_Entry = 1 ;
	char    *Q_Entry[1]  = {"Name"};
	char	**Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
	int svrCount = 0;
	tag_t   Qry_tag     = NULLTAG;
	tag_t *SVR_tag = NULLTAG;

	if(QRY_find("Variant Rules", &Qry_tag));
	if (Qry_tag)
	{

		printf("\n Variant Rules Query Found \n");fflush(stdout);
		Q_Value[0]=item_id;

		if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &svrCount, &SVR_tag));
		printf("\n No of SVR Found = %d\n",svrCount);fflush(stdout);

		if(SVR_tag !=NULLTAG)
		{
			printf("\n\t *****Creating Relationship of Platform and SVR ******");
			ITK_CALL(AOM_refresh(platformTag,1));
			ITK_CALL(GRM_find_relation_type ("IMAN_reference", &relation_type));
			ITK_CALL(GRM_create_relation (platformTag, SVR_tag[0], relation_type, NULLTAG, &new_relation));
			ITK_CALL(GRM_save_relation (new_relation));
			ITK_CALL(AOM_save (platformTag));
			ITK_CALL(AOM_refresh(platformTag,0));

		}

	}
	else
	{
		printf("\n Variant Rules Query NOT Found \n");fflush(stdout);

	}

	return ifail;
}
