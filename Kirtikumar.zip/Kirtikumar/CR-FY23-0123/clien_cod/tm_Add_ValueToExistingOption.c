/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
tag_t Get_CC_Dictionary();
tag_t Get_CC_From_Platform_ArchModule(char*,char*);
int OptionFamily_Create(char* ,tag_t* ,int );
int OptionValue_Create(char* ,tag_t ,tag_t* ,int );

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	tag_t *attachments				= NULL;
	tag_t DMLRevTag					= NULLTAG;
	tag_t rootTask					= NULLTAG;
	tag_t rel_type					= NULLTAG;
	tag_t reference_rel_type_tag	= NULLTAG;
	char*		type_name			 =NULL;

	char* parent_name=NULL;
	char* dmlNo=NULL;
	char* dmlProj=NULL;
	char * username			= NULL;
	
	tag_t*	Dml_OptFmS		    = NULL;
	tag_t*	valuesTag		    = NULL;
	
	char * object_type			= NULL;

	int AttachmentCount=0;
	int t=0,Dml_OptFmCnt=0,ic=0,iCTX=0;
	int valuesInRefCount =0;
	int ij = 0;
	int status; 


	ITK_CALL(POM_get_user_id (&username));
	printf("\n MDM_CreOptVal Session User is : %s\n",username); fflush(stdout);

	int		count			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;

	
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
	CHECK_FAIL;

	//ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

	//ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	//printf("\n MDM_CreOptVal Parent Name: %s",parent_name);fflush(stdout);

	//ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
	//printf("\n MDM_CreOptVal Target Attachment:%d",AttachmentCount);fflush(stdout);

	if(count > 0)
	{

		for(t=0;t<count;t++)
		{
			char* DML_No=NULL;
			
			AOM_ask_value_string(rev_list[t],"object_type",&object_type);
			printf("\n object_type is :%s\n",object_type);fflush(stdout);

			AOM_ask_value_string(rev_list[t],"item_id",&DML_No);
			printf("\n DML_No is :%s\n",DML_No);fflush(stdout);


			if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
			{
				DMLRevTag = rev_list[t];
				GRM_find_relation_type("CMReferences",&rel_type);

				ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,rel_type,&Dml_OptFmCnt,&Dml_OptFmS));

				printf("\n  validation Dml_OptFmCnt count is : [%d] \n",Dml_OptFmCnt);fflush(stdout);

				for (ic=0;ic<Dml_OptFmCnt;ic++)
				{
					tag_t	OptFm_Tg		    = NULLTAG;
					tag_t	value_tag		    = NULLTAG;
					tag_t	ConfigCtxtag		    = NULLTAG;
					tag_t	ConfigCtxDicttag		    = NULLTAG;
					tag_t	ConfigCtxTAGS[1000];
					OptFm_Tg=	Dml_OptFmS[ic];
					char* OptFm_No=NULL;
					int num=0;
					tag_t *configContext;

					AOM_ask_value_string(OptFm_Tg,"object_name",&OptFm_No);  //T5_Opt_Family_Value
					printf("\nCre OptFm_No is :%s\n",OptFm_No);fflush(stdout);

					ITK_CALL (AOM_ask_value_string(OptFm_Tg,"object_type",&type_name));
					printf("\n Cre MDM type is:%s \n", type_name);fflush(stdout);

					if(tc_strcmp(type_name,"T5_FamilyMDMRevision")==0)
					{
						//Getting Family Tag and the respection CC attached.
					
						char **valuesFam = (char **) MEM_alloc(10 * sizeof(char *));
						tag_t* tags_found_fam=NULL;
						tag_t FamTag=NULLTAG;
						tag_t Optfmly_tag=NULLTAG;
						int n_tags_found_fam=0;
						int n_entriesP=1;
						char **qry_entries1 = (char **) MEM_alloc(10 * sizeof(char *));
						qry_entries1[0] = "Thread ID";
						valuesFam[0] = OptFm_No;
						char* objString =NULL;
						int mn =0;
						int mo =0;
						char* SmCrIDContext=NULL;

						ITK_CALL(QRY_find("__Cfg0OptionFamiliesFromIDs", &FamTag)); 
						//Getting Dictionary Tag
						ConfigCtxDicttag=Get_CC_Dictionary();
						if (ConfigCtxDicttag)
						{
							ConfigCtxTAGS[iCTX]=ConfigCtxDicttag;
							iCTX++;
						}

						if (FamTag)
						{
							ITK_CALL(QRY_execute(FamTag, n_entriesP, qry_entries1, valuesFam, &n_tags_found_fam, &tags_found_fam));
							printf("\n Query __Cfg0OptionFamiliesFromIDs %d <---- %s\n",n_tags_found_fam,OptFm_No); fflush(stdout);
							if (n_tags_found_fam>0)
							{
								Optfmly_tag=tags_found_fam[0];
								AOM_ask_value_string(Optfmly_tag,"object_name",&objString);
								printf("\n objString :%s\n",objString);fflush(stdout);

								//Getting all CC of Family
								AOM_ask_value_tags(Optfmly_tag,"cfg0ProductItems",&num,&configContext);
								printf("\nNo of CC attaced to Family is  :%d\n",num);fflush(stdout);
								for(mn =0;mn <num; mn++)
								{
									ConfigCtxTAGS[iCTX]=configContext[mn];
									iCTX++;
								}
							}
							else
							{
								printf("\n  OPTFamily %s not found  \n",OptFm_No); fflush(stdout);
							}
						}
						else
						{
							printf("\n  Query __Cfg0OptionFamiliesFromIDs not found  \n"); fflush(stdout);

						}

						for (mo=0;mo<iCTX;mo++)
						{
							//ITK_CALL(AOM_ask_value_string(ConfigCtxTAGS[ic],"object_string",&SmVCContext));
							//printf("\n\t MDM SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);
							ITK_CALL(AOM_ask_value_string(ConfigCtxTAGS[mo],"current_id",&SmCrIDContext));
							printf("\n\t FInal MDM SmCrIDContext Object String Type is :%s \n",SmCrIDContext);	fflush(stdout);
						}

						//Need to get Value attahced to Family with Reference Relation
						GRM_find_relation_type("IMAN_reference",&reference_rel_type_tag);
						ITK_CALL(GRM_list_secondary_objects_only(OptFm_Tg,reference_rel_type_tag,&valuesInRefCount,&valuesTag));
						printf("\n  No of Values added in Reference folder of Family  : [%d] \n",valuesInRefCount);fflush(stdout);

						for(ij=0;ij< valuesInRefCount;ij++)
						{
							char* ValueName =NULL;
							char* type_name1 =NULL;

							AOM_ask_value_string(valuesTag[ij],"object_name",&ValueName);
							printf("\nValueName :%s\n",ValueName);fflush(stdout);

							ITK_CALL (AOM_ask_value_string(valuesTag[ij],"object_type",&type_name1));
							printf("\n type_name1 is:%s \n", type_name1);fflush(stdout);
							OptionValue_Create(ValueName,Optfmly_tag,ConfigCtxTAGS,iCTX);

						}

					} // if for family type check
				} // for for DML count
			}// if ChangeRequestRevision
		}// For for Item count

	} // Item count 
	

	return ITK_ok;
}
tag_t Get_CC_Dictionary()
{
	int ifail=0;

	//__Configuration_Item_Name_or_ID

	tag_t CC_DICT_tag=NULLTAG;
	tag_t QryTag=NULLTAG;
	tag_t *tags_found=NULL;

	char **values= (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_entries= (char **) MEM_alloc(10 * sizeof(char *));
	int n_entries = 1;
	qry_entries[0] = "ID";//change it as per  QRy Builder entry
	int n_tags_found = 0;
	if(QRY_find("__Configuration_Item_Name_or_ID", &QryTag));
	if (QryTag) 
	{ 
		printf("\nFound Query QryTag"); fflush(stdout);

		values[0] = "TML OPTIONS DICTIONARY";
		if(QRY_execute(QryTag, n_entries, qry_entries, values, &n_tags_found, &tags_found));
		printf("\n\n\n CC DICT count is-------->  : %d",n_tags_found);fflush(stdout);
		if (n_tags_found > 0)
		{
			CC_DICT_tag = tags_found[0];
			
		}else 
		{ 
			printf ("\n Platform tag not found\n"); fflush(stdout);	
		}
	}else 
	{
		printf("\nNot Found Query QryTag"); fflush(stdout);
	}
	return CC_DICT_tag;

}
tag_t Get_CC_From_Platform_ArchModule(char* InputPart,char* Class)
{
	//MT start
	int ifail=0;
	tag_t   OutPutTag     = NULLTAG;
	tag_t   ConfigCtx     = NULLTAG;
	tag_t   relation_dep     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	char* SmVCContext=NULL;
	char* SmCrIDContext=NULL;
	

	int countConfigCtx=0;
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	tag_t *ConfigCtxSecObject = NULL;

	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	printf("\n MDM:part no :%s.", InputPart);fflush(stdout);
	CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));

	if (tc_strcmp(Class,"T5_Platform")==0)
	{
		
		const char *attrs2[2];
		const char *values2[2];
		attrs2[0] ="item_id";
		attrs2[1] ="object_type";
		values2[0] = (char *)InputPart;
		values2[1] = "T5_Platform";
		if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
		printf("\n MDM:T5_Platform part count :%d.", n_tags_foundd3);fflush(stdout);

		if (n_tags_found2>0)
		{


			OutPutTag= tags_found2[0];
		}
	}
	else if(tc_strcmp(Class,"T5_ArchModule")==0)
	{
		printf("\n MDM:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
		attrss3[0] ="item_id";
		attrss3[1] ="object_type";
		valuess3[0] = (char *)InputPart;
		valuess3[1] = "T5_ArchModule";
		if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
		printf("\n MDM:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
		if (n_tags_foundd3>0)
		{
			OutPutTag= tags_foundd3[0];
		}
	}
	else
	{

	}

	if (OutPutTag)
	{
		CALLAPI(GRM_list_secondary_objects_only(OutPutTag,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
		printf("\n\t Configuration Context count is : %d",countConfigCtx);

		if(countConfigCtx>0)
		{
			  ConfigCtx=ConfigCtxSecObject[0];


			  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
			  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

			  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
			  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);
		}
	}


	return ConfigCtx;	
}
int OptionFamily_Create(char* OptFamName,tag_t* ConfigCtxtTags,int Nos_ConfigCtxt)
{
	int status;	
	int  	number_of_types;
	int  	number_of_types1;
	tag_t * 	type_tag4;
	tag_t 	CfgTag=NULLTAG;
	tag_t 	context_tag=NULLTAG;
	tag_t * 	type_tag3;
	tag_t * 	tags_found;
	tag_t	 	thread_tag;
	int cfg_cnt=0;
	tag_t object_create_input_tag,new_object,object_create_input_tag3,family_tag;

	char **valuesCfg = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_entries10 = (char **) MEM_alloc(10 * sizeof(char *));

	


		ITK_CALL(TCTYPE_find_types_for_class("Cfg0LiteralValueFamily",&number_of_types1,&type_tag3));
		printf("\n number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);

		ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0ObjectId",OptFamName));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",OptFamName));								
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0FamilyNamespace","Teamcenter"));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0ValueDataType","String"));
		ITK_CALL(AOM_set_value_logical(object_create_input_tag3,"cfg0HasFreeFormValues",false));
		ITK_CALL(AOM_set_value_logical(object_create_input_tag3,"cfg0IsDiscretionary",false));
		ITK_CALL(AOM_set_value_logical(object_create_input_tag3,"cfg0IsMultiselect",false));
		for (cfg_cnt=0;cfg_cnt<Nos_ConfigCtxt;cfg_cnt++)
		{
			context_tag=ConfigCtxtTags[cfg_cnt];
			ITK_CALL(AOM_set_value_tag_at(object_create_input_tag3,"cfg0ProductItems",cfg_cnt,context_tag));
		}
			
		ITK_CALL(AOM_set_value_int(object_create_input_tag3,"cfg0Sequence",0));
		ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &family_tag));
		if(family_tag)
		{
			printf("\n Option Value is created......\n");
			ITK_CALL(AOM_save(family_tag));
			ITK_CALL(AOM_unlock(family_tag));
		}

		//Added Option Values to Option family
		for (cfg_cnt=0;cfg_cnt<Nos_ConfigCtxt;cfg_cnt++)
		{
			context_tag=ConfigCtxtTags[cfg_cnt];
			ITK_CALL(TCTYPE_find_types_for_class("Cfg0Allocation",&number_of_types,&type_tag4));
			ITK_CALL(TCTYPE_construct_create_input(type_tag4[0], &object_create_input_tag));
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",OptFamName));
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"cfg0ObjectId",OptFamName));
			ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0Target",family_tag));
			ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0ProductItem",context_tag));
			ITK_CALL(TCTYPE_create_object(object_create_input_tag, &new_object));
			if(new_object)
			{
				printf("\n t5CreateObject : object created.\n");
				ITK_CALL(AOM_save(new_object));
				ITK_CALL(AOM_unlock(new_object));
			}
		}
}
int OptionValue_Create(char* OptValName,tag_t Optfmly_tag,tag_t* ConfigCtxtTags,int Nos_ConfigCtxt)
{
	int status;	
	int  	number_of_types;
	int  	number_of_types1;
	tag_t * 	type_tag4;
	tag_t 	CfgTag=NULLTAG;
	tag_t 	context_tag=NULLTAG;
	tag_t * 	type_tag3;
	int cfg_cnt =0;
	tag_t	 	thread_tag;
	tag_t object_create_input_tag,new_object,object_create_input_tag3,value_tag;

	char **valuesCfg = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_entries10 = (char **) MEM_alloc(10 * sizeof(char *));

	



		ITK_CALL(TCTYPE_find_types_for_class("Cfg0LiteralOptionValue",&number_of_types1,&type_tag3));
		printf("\n number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);

		ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0ObjectId",OptValName));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",OptValName));
		if(Optfmly_tag != NULLTAG)
		{
			ITK_CALL(AOM_get_value_tag(Optfmly_tag,"wso_thread", &thread_tag));
			if(thread_tag != NULLTAG) {
				printf("\n\t go thread.......\n\n"); fflush(stdout);
			}else {
				printf("\n\t thread error.......\n\n"); fflush(stdout);
			}
		}else {
			printf("\n\t family error.......\n\n"); fflush(stdout);
		}
		//ITK_CALL(AOM_set_value_tag(object_create_input_tag3,"cfg0OptionFamily ",Optfmly_tag));
		ITK_CALL(AOM_set_value_tag(object_create_input_tag3,"cfg0OptionFamilyThread",thread_tag));
		//ITK_CALL(AOM_set_value_string(object_create_input_tag3,"cfg0FamilyObjectId",OptValName));

		for (cfg_cnt=0;cfg_cnt<Nos_ConfigCtxt;cfg_cnt++)
		{
			context_tag=ConfigCtxtTags[cfg_cnt];
			ITK_CALL(AOM_set_value_tag_at(object_create_input_tag3,"cfg0ProductItems",cfg_cnt,context_tag));
		}
			
		ITK_CALL(AOM_set_value_int(object_create_input_tag3,"cfg0Sequence",0));
		ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &value_tag));
		if(value_tag)
		{
			printf("\n Option Value is created......\n");
			ITK_CALL(AOM_save(value_tag));
			ITK_CALL(AOM_unlock(value_tag));
		}

		//Added Option Values to Option family
		for (cfg_cnt=0;cfg_cnt<Nos_ConfigCtxt;cfg_cnt++)
		{
			context_tag=ConfigCtxtTags[cfg_cnt];
			ITK_CALL(TCTYPE_find_types_for_class("Cfg0Allocation",&number_of_types,&type_tag4));
			ITK_CALL(TCTYPE_construct_create_input(type_tag4[0], &object_create_input_tag));
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",OptValName));
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"cfg0ObjectId",OptValName));
			ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0Target",value_tag));
			ITK_CALL(AOM_set_value_tag(object_create_input_tag,"cfg0ProductItem",context_tag));
			ITK_CALL(TCTYPE_create_object(object_create_input_tag, &new_object));
			if(new_object)
			{
				printf("\n t5CreateObject : object created.\n");
				ITK_CALL(AOM_save(new_object));
				ITK_CALL(AOM_unlock(new_object));
			}
		}
}