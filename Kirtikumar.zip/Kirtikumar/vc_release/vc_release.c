/*
Code Description : Reference Items folder will get scanned for SVR and Platform. SVR will be applied on platform to get the unit BOM and BOM completeness check.
If released VC is present as per SVR name then it will get revised.
*/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <unidefs.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <property/prop.h>
#include <pie/pie.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <textsrv/textserver.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_errStore2 (EMH_USER_error_base + 6)
#define ITK_errErr1 (EMH_USER_error_base + 4)
#define ITK_errErr (EMH_USER_error_base + 99)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}
#define VOO_HASH_SIZE 4099
#define MAX_INT_LENGTH 10      //maximum no of characters required to hold an integer

typedef struct
{
    int     size;
    int     capacity;
    int     increment;
    void  **content;
} vector_t;

struct modstruct
 {  
	   //part details

		char parent_part[100];
		int child;

 } childstr[10000];

typedef vector_t *variant_rule_option_data_t[VOO_HASH_SIZE];
static vector_t *vector_new( int capacity, int increment );
static vector_t *vector_add( vector_t *v, void *element );
static vector_t *vector_add_n( vector_t *v, int n, void *elements[] );
static vector_t *vector_ensure_capacity( vector_t *v, int n );
static vector_t *vector_free( vector_t *v );
static vector_t *vector_insert( vector_t *in, void *element );
static vector_t *vector_insert_n_at( vector_t *in, int n, void *elements[], int at );
static void *vector_get( const vector_t *v, int index );
static int vector_size( const vector_t *v );
static int vector_rem_at( vector_t *in, int n );
static int vector_rem_n_at( vector_t *in, int n, int at );
static int       VOO_debug                     = FALSE;
static char     *VOO_prog                      = (char *)"UnitBOM";



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static double token_to_double ( const char *str )
{
    return strtod( str, NULL);
}

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

  
extern EPM_decision_t DLLAPI ECUCount_Valid16RTPL (EPM_rule_message_t msg)
{

char    *key_lov_name;
char    *owning_site;
int  	options;
int  	n_lov_entries;
char    **lov_keys;
char	**lov_values;
logical * deprecated_staus;
//int  	options;
int  	n_shared_sites;
int  	ic=0;
char	** shared_sites ;											 
char* attributeValue		= NULL;
char* attributeValue1		= NULL;
tag_t Design_rev_cls_tag    = NULLTAG;

EPM_decision_t decision;

int ifail;
int status;
int iStatus	=0;
int DMLCount=0;
int tsk_cnt	=0;
int t		=0;
int i		=0;
int p		=0;
int partcnt =0;
int ecuRlzStatusCnt =0;

int level 			       =    0;				
int con				       =    0;
int containerCount         =    0;


tag_t	*DMLObj					= NULLTAG;
tag_t	*Tsk_objects			= NULLTAG;
tag_t	*PartsTag				= NULLTAG;
tag_t   *ecu_Rlz_St_list        = NULL; 

char	*DMLprojcode            = NULL;
char	*Rel_type               = NULL;
char	*Taskobject_type        = NULL;
char    *RevIDNo_Org            = NULL;
char    *VCnumberDup            = NULL;
char    *VCnumber               = NULL;
char    *PartNo                 = NULL;
char    *PartType               = NULL;
char    *req_item               = NULL;
char    *t5NoEcuDup             = NULL;

tag_t	DMLRevTag				= NULLTAG;
tag_t	DMLToTaskRel		    = NULLTAG;
tag_t	part_tsk_rel		    = NULLTAG;
tag_t	ProQryDMLObj			= NULLTAG;
tag_t	DesignrevTag			= NULLTAG;
tag_t	LatestVC				= NULLTAG;
tag_t	CCVCrelation_type		= NULLTAG;
tag_t	LatestModRevTag			= NULLTAG;
tag_t	sn_rule					= NULLTAG; 

int		n_Input	       = 2;
int		t5NoEcuDupint  = 0;
int		Modcnt	       = 0;

tag_t	window 	        = NULLTAG;
tag_t	*Modattachments	= NULLTAG;	
tag_t   Mod_rev_tag     = NULLTAG;
tag_t   DML_tag			= NULLTAG;
tag_t	top_line	    = NULLTAG;
tag_t	DesignMasterTag	= NULLTAG; 

char * username			= NULL;
char * parent_name		= NULL;
char * dmlTaskNo		= NULL;
char * ModulNo			= NULL;
char * ECUCountErr		= NULL;

int AttachmentCount		= 0;

tag_t *attachments		= NULLTAG;
tag_t DMLTaskTag		= NULLTAG;
tag_t rootTask			= NULLTAG;

tag_t   Mod_rev_tag_mstr = NULLTAG; //3 sept
char*   ModulRevid     =NULL;      //3 sept

decision = EPM_go;// 9 SEPT

//Added by ajinkya for DVP in VC//
tag_t	CCVCrelation_typeDv		= NULLTAG;
tag_t	*ModattachmentsDv		= NULLTAG;
tag_t   Mod_rev_tag_mstrDv      = NULLTAG; 
tag_t   Mod_rev_tagDv			= NULLTAG;
tag_t   class_id                =NULLTAG;
tag_t   *DMLRevision			= NULLTAG;
tag_t	NewDMLRevTag			= NULLTAG;
tag_t  *children				= NULLTAG;
tag_t	bl_Child_dv				= NULLTAG;
tag_t   tsk_dml_rel_type;
char * ModulNoDv			    = NULL;
char*   ModulRevidDv            =NULL; 
char 	*BusUnitDV				= NULL;
char	*DMLDRdvp				= NULL;
char*	partNumber 				= NULL;
char*	ModPartType				= NULL;
char	*LatChildName			=	NULL;
char   *class_name;
int		ModcntDv                = 0;
int     jdv 	                =0;
int     jt  	                =0;
int		n_Cnt					=0;
int     jcnt					=0;
logical is_latest;
char  type_name[TCTYPE_name_size_c+1];
	tag_t objTypeTagdv  = NULLTAG;
	tag_t reln_typeDvp  = NULLTAG;
	tag_t SolnItemTag   = NULLTAG;
	tag_t EE_tag		= NULLTAG;
	tag_t EEparent_rev   = NULLTAG;
	int n_attchs_dvp     = 0;
	int  dvp             = 0; 
	int  ddi             = 0;
	char    * dataset_name1 = NULL; 
	char    * Item_id_EE = NULL; 
	GRM_relation_t *secondary_dvp;
	tag_t	new_Child_tg			= NULLTAG;
	tag_t  *childrenee	= NULLTAG;

	int	n_entriesWe = 2;
	int n_foundWe = 0;
	char *qry_entriesWe[2] = {"SYSCD", "SUBSYSCD"};
    char *qry_valuesWe[2] = {"VC", "DVP"};
	tag_t   *dvpCtrObj      = NULLTAG;
	tag_t TagWeControl = NULLTAG;

	int  dvpflag = 0; 
//END for DVP//


ITK_CALL(POM_get_user_id (&username));
printf("\n ECUCount_Valid16RTPL Session User is : %s\n",username); fflush(stdout);

if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
{
   ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

   ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
   printf("\n ECUCount_Valid16RTPL Parent Name: %s",parent_name);fflush(stdout);

   ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
   printf("\n ECUCount_Valid16RTPL Target Attachment:%d",AttachmentCount);fflush(stdout);

   if(AttachmentCount > 0)
	{
		DMLTaskTag = attachments[0];

		if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
		printf("\n ECUCount_Valid16RTPL dmlTaskNo: [%s]",dmlTaskNo);fflush(stdout);
	  
		// if(ITEM_find_item(dmlTaskNo, &DML_tag)!=ITK_ok)PrintErrorStack();

		tag_t *tags_found = NULL;
		int n_tags_found= 0;
		int n_rev= 0;

		const char **attrs = (const char **) MEM_alloc(1 * sizeof(char *));
        const char **values = (const char **) MEM_alloc(1 * sizeof(char *));

		attrs[0] ="item_id";
		values[0] = (char *) dmlTaskNo;

		ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
		MEM_free(attrs);
		MEM_free(values);
		CHECK_FAIL;

		if (n_tags_found == 0)
		{
			printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", dmlTaskNo); fflush(stdout);
			exit (0);
		}

		DML_tag = tags_found[0];
		printf("\n after  DML_tag XXXXXXXXXX :\n");fflush(stdout);

		ITK_CALL(ITEM_ask_latest_rev(DML_tag,&DMLRevTag));
		
	
//
//		if (DMLRevTag != NULLTAG)
//		  {
//			printf("\n DMLRevTag FOUND XXXXXXXXXXXX:\n");fflush(stdout);
//			//if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
//
//			if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
//			printf("\n CCIDSignoff_Validationt DML Rel_type: [%s]", Rel_type);fflush(stdout);
//
//		   if((tc_strcmp(Rel_type,"Vehicle Release")==0)||(tc_strcmp(Rel_type,"Veh")==0))	
//			{
//			   ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
//			   ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects));
//
//			   printf("\n  VC validation Task count is : [%d] \n",tsk_cnt);fflush(stdout);
//
//				  if (tsk_cnt>0)
//					{
//					  for (t=0;t<tsk_cnt ;t++ )
//						{
//						   ITK_CALL(AOM_ask_value_string(Tsk_objects[t],"object_type",&Taskobject_type)); //3 sept
						   ITK_CALL(AOM_ask_value_string(DMLTaskTag,"object_type",&Taskobject_type));//3 sept
						   printf("\n  VC validation Taskobject_type is :[%s]\n",Taskobject_type);fflush(stdout);
						   if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
						     {
						       printf("\n tm_ECURefSnapshot inside T5_ChangeTaskRevision :\n");fflush(stdout);
						       ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
 
						       if (part_tsk_rel!=NULLTAG)
							     {
							       //ITK_CALL(GRM_list_secondary_objects_only(Tsk_objects[t], part_tsk_rel, &partcnt, &PartsTag));//3 sept
							       ITK_CALL(GRM_list_secondary_objects_only(DMLTaskTag, part_tsk_rel, &partcnt, &PartsTag));//3 sept
							       printf("\n  VC validation partcnt.:%d\n",partcnt);fflush(stdout);

							        if (partcnt>0)
								     {
								       for (p=0;p<partcnt;p++)
									     {	
											DesignrevTag=PartsTag[p];

											ITEM_ask_item_of_rev(DesignrevTag,&DesignMasterTag); //find master here

											//ITK_CALL(ITEM_ask_latest_rev(DesignrevTag,&LatestVC));
											if( AOM_ask_value_string(DesignrevTag,"item_id",&VCnumber)!=ITK_ok);
											//tc_strcpy(VCnumberDup,VCnumber);
											printf("\n VCnumber is [%s]  \n",VCnumber); fflush(stdout);


											if(AOM_ask_value_string(DesignrevTag,"item_id",&PartNo)==ITK_ok);
											printf("\n  VC validation PartNo is  = [%s]\n", PartNo);fflush(stdout);
											
											if(AOM_ask_value_string(DesignrevTag,"item_revision_id",&RevIDNo_Org)==ITK_ok);
											printf("\n  VC validation RevIDNo is  = [%s]\n", RevIDNo_Org);fflush(stdout);

											if(AOM_ask_value_string(DesignrevTag,"t5_PartType",&PartType)==ITK_ok); 
											printf("\n  VC validation PartType is  = [%s]\n", PartType);fflush(stdout);
									
											if((tc_strcmp(PartType,"Configurable VC")==0)||(tc_strcmp(PartType,"CCVC")==0))
											{

	  											ITK_CALL(ICS_keylov_get_keylov("-8226",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
												printf("\n VC validation key_lov_name===[%s]--- n_lov_entries===[%d]--- options===[%d]\n",key_lov_name,n_lov_entries,options); fflush(stdout);

												for(ic=0;ic<n_lov_entries;ic++)								
												{	 
													printf("\n lov_keys=[%s] lov_values=[%s]\n",lov_keys[ic],lov_values[ic]); fflush(stdout);
													(ICS_ask_classification_object(DesignMasterTag,&Design_rev_cls_tag));

													(ICS_ask_attribute_value	(Design_rev_cls_tag,"8226",&attributeValue));

													printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);
														
													if(tc_strcmp(attributeValue,lov_keys[ic])==0)
													{
														printf("\n Value of classified object: \n Mascot lov_keys=%s lov_values=%s",lov_keys[ic],lov_values[ic]); fflush(stdout);

														t5NoEcuDup		   =(char *) MEM_alloc(20);
														tc_strcpy(t5NoEcuDup,lov_values[ic]);

														printf("\n ECU COUNT IS  =%s",t5NoEcuDup); fflush(stdout);//10
 
														t5NoEcuDupint=atoi(t5NoEcuDup);

														printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);//10
															
													}									
												}


												ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_type)); 
												printf("\n   CCVC has ECU module REL FOUND \n");fflush(stdout);

												ITK_CALL(GRM_list_secondary_objects_only(DesignrevTag,CCVCrelation_type,&Modcnt,&Modattachments));							
												printf("\n Modcnt ============= [%d]  \n",Modcnt); fflush(stdout);	

												if (Modcnt > 0)
												 {
													//Mod_rev_tag = Modattachments[0];
													Mod_rev_tag_mstr = Modattachments[0]; // 3 sept

													ITK_CALL(ITEM_ask_latest_rev(Mod_rev_tag_mstr,&Mod_rev_tag));// 3 sept

													if(AOM_ask_value_string(Mod_rev_tag,"item_id",&ModulNo)==ITK_ok);
											        printf("\n  VC validation ModulNo is  = [%s]\n", ModulNo);fflush(stdout);

													if(AOM_ask_value_string(Mod_rev_tag,"item_revision_id",&ModulRevid)==ITK_ok); //3 sept
											        printf("\n  VC validation ModulRevid is  = [%s]\n", ModulRevid);fflush(stdout);//3 sept

													printf("\n Mod_rev_tagP \n"); fflush(stdout);	
													//VC_Multi_Get_Part_BOM_Lvl_Col_1(window,99,level,LatestModRevTag,containerCount);
													VC_Multi_Get_Part_BOM_Lvl_Col_SW(99,level,Mod_rev_tag,&containerCount);


												}
												printf("\n final count of containers  is [%d] \n",containerCount);fflush(stdout);
												
												if(containerCount==t5NoEcuDupint)
												  {
													  printf("\n count matching well done S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
												  }
												  else
												  {
													printf("\n count does not match S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
											
													if (tc_strcmp(ECUCountErr,"NULL") !=0) MEM_free(ECUCountErr);
													ECUCountErr=(char *)MEM_alloc(600);
													tc_strcpy(ECUCountErr,"For ");
													tc_strcat(ECUCountErr,VCnumber);
													tc_strcat(ECUCountErr," the Value of Attribute - number of ECU's -is not matching with the actual number of containers in ECU module ");
													tc_strcat(ECUCountErr,ModulNo);

													printf("\n ECUCountErr= [%s] \n",ECUCountErr);fflush(stdout);

													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_error,ITK_err,ECUCountErr);
													decision = EPM_nogo;
													return decision;							
												  }										  

												containerCount = 0;
												t5NoEcuDupint = 0;
										      }

											  //Code added by ajinkya for DVP Report validation on 10 sep ............ //
											printf("\n  DVP-VC validation for VC started now \n");fflush(stdout);
											if(QRY_find2("ControlObjQry", &TagWeControl));

											if(QRY_execute(TagWeControl, n_entriesWe, qry_entriesWe, qry_valuesWe, &n_foundWe, &dvpCtrObj));
											printf("\n Control Object found for WE parts == %d\n", n_foundWe);fflush(stdout);

											if(n_foundWe==1)
											{
												printf("\n  Control Object found for DVP == %d  \n", n_foundWe);fflush(stdout);
											if (DMLRevTag != NULLTAG)
                                    		{
										      printf("\n As DMLRevTag not null \n");fflush(stdout);	
											  
											  ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id));
											  ITK_CALL(POM_name_of_class(class_id,&class_name));
											  printf("\n\n DVP-VC  class_name of Task :%s \n",class_name);fflush(stdout);

											   if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
											   {
												    printf("\n\n Task class_name find ---:%s \n",class_name);fflush(stdout);
													ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
													if (tsk_dml_rel_type!=NULLTAG)
													{
														printf("\n\n Relationship tag class_name find  \n");fflush(stdout);
														ITK_CALL(GRM_list_primary_objects_only(DMLRevTag,tsk_dml_rel_type,&jdv,&DMLRevision));
														printf("\n\n\t\t DML Revision from Task : %d \n",jdv);fflush(stdout);

														for (jt=0;jt<jdv ;jt++ )
														{
															printf("\n\n Inside for DML Latest revision  ---:%d \n",jdv);fflush(stdout);
															ITK_CALL(ITEM_rev_sequence_is_latest(DMLRevision[jt],&is_latest));
															printf("\n\n\t\t is_latest : %d \n",is_latest);fflush(stdout);

															if(is_latest != true)
															{
																printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
															}else
															{
																printf("\n\n INSIDE DML FIND  code \n");fflush(stdout);
																NewDMLRevTag = DMLRevision[jt];

																ITK_CALL(AOM_ask_value_string(NewDMLRevTag,"t5_ERCBusiUt",&BusUnitDV));
																printf("\n IN VC DML business unit for DVP :%s \n",BusUnitDV);fflush(stdout);

																ITK_CALL(AOM_ask_value_string(NewDMLRevTag,"t5_cDRstatus",&DMLDRdvp));
																printf("\n IN VC DML DR status  for DVP :%s \n",DMLDRdvp);fflush(stdout);

															}

														}

													}

											    }

											printf("\n IN VC DML DR status--(%s) and Bussiness Unit  for DVP :(%s) \n",BusUnitDV, DMLDRdvp);fflush(stdout);
											
											if((strcmp(BusUnitDV,"PVBU")==0) && (strcmp(DMLDRdvp,"DR4")==0))
											{
											  printf("\n  DVP-VC validation PartType is  = [%s] \n", PartType);fflush(stdout);
											  if ((tc_strcmp(PartType,"CCVC")==0)||(tc_strcmp(PartType,"V")==0))
											  {
												printf("\n Part TYPE Inside DVP-VC ============= [%s]  \n",PartType); fflush(stdout);
												ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_typeDv)); 
												printf("\n  DVP-VC CCVC has ECU module REL FOUND \n");fflush(stdout);

												ITK_CALL(GRM_list_secondary_objects_only(DesignrevTag,CCVCrelation_typeDv,&ModcntDv,&ModattachmentsDv));							
												printf("\n DVP-VC ModcntDv ============= [%d]  \n",ModcntDv); fflush(stdout);
												
												if (ModcntDv > 0)
												 {
													printf("\n Inside DVP-VC ModcntDv ============= [%d]  \n",ModcntDv); fflush(stdout);
													Mod_rev_tag_mstrDv = ModattachmentsDv[0]; 

													ITK_CALL(ITEM_ask_latest_rev(Mod_rev_tag_mstrDv,&Mod_rev_tagDv)); 

													if(AOM_ask_value_string(Mod_rev_tagDv,"item_id",&ModulNoDv)==ITK_ok);
											        printf("\n  DVP-VC validation ModulNoDv is  = [%s] \n", ModulNoDv);fflush(stdout);

													if(AOM_ask_value_string(Mod_rev_tagDv,"item_revision_id",&ModulRevidDv)==ITK_ok); //3 sept
											        printf("\n DVP-VC validation ModulRevidDv is  = [%s] \n", ModulRevidDv);fflush(stdout);//3 sept

													printf("\n Mod_rev_tagP \n"); fflush(stdout);

													//code for Module expand//
													ITK_CALL(BOM_create_window (&window)); //3 sept	
													ITK_CALL(BOM_set_window_pack_all (window, true));//3 sept
													ITK_CALL(CFM_find("ERC Review And Above", &sn_rule ));
													ITK_CALL(BOM_set_window_config_rule( window, sn_rule )); 
														
													ITK_CALL(BOM_set_window_top_line (window, null_tag,Mod_rev_tagDv,null_tag, &top_line));

													ITK_CALL(BOM_window_show_suppressed (window));

													printf("\n DVP-VC after BOM_set_window_top_line in VC_Multi_Get_Part_BOM_Lvl_1 \n");fflush(stdout);

													ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));// 3 sept
													printf("\n DVP-VC Part number===>%s \n",partNumber);fflush(stdout);

													ITK_CALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children)); //3 sept
													printf("\n\n\t\t **** DVP-VC No of child objects are :: %d \n", n_Cnt);fflush(stdout);

													if (n_Cnt>0)
													{
														printf("\n\n\t\t Inside DVP-VC No of child objects are :: %d \n", n_Cnt);fflush(stdout);
														for (jcnt=0;jcnt<n_Cnt;jcnt++)
														{
															printf("\n\n\t\t Inside for loop \n");fflush(stdout);

															bl_Child_dv=children[jcnt];

															ITK_CALL(AOM_ask_value_string( bl_Child_dv,"bl_item_item_id",&LatChildName));
															printf("\n DVP-VC LatChildName Parts Id : [%s] \n",LatChildName);

															if( AOM_ask_value_string(bl_Child_dv,"bl_T5_EE_PartRevision_t5_SwPartType",&ModPartType)!=ITK_ok);
															printf("\n DVP-VC t_ChildItemRev tag found ===>%s \n",ModPartType);fflush(stdout);

												   //check for dvp report //
													if(strcmp(ModPartType,"CON")==0)
													{
														printf("\n Inside container part found ===>%s \n",ModPartType);fflush(stdout);
														ITK_CALL(ITEM_find_item(LatChildName,&EE_tag));
														printf("\n Function called FOR EE_tag \n");fflush(stdout);

														if( AOM_ask_value_string(EE_tag,"item_id",&Item_id_EE)!=ITK_ok);
													
														printf("\n  DVP-VC Item ID is  ---->%s \n",Item_id_EE); fflush(stdout);
													
														ITK_CALL(ITEM_ask_latest_rev(EE_tag,&EEparent_rev));

														if(TCTYPE_ask_object_type(EEparent_rev,&objTypeTagdv));
														if(TCTYPE_ask_name(objTypeTagdv,type_name));
														printf("\n\n\t\t DVP-VC EEparent_rev type_name := %s \n", type_name);fflush(stdout);

														 if(strcmp(type_name,"T5_EE_PartRevision")==0) 
														 {
															 printf("\n\n\t\t For DVP-VC part type is  %s \n", type_name);fflush(stdout);

															 ITK_CALL(GRM_find_relation_type("IMAN_specification",&reln_typeDvp));
															 printf("\n\n\t\t DVP for IMAN_specification......... \n");fflush(stdout);
															 
																   if(reln_typeDvp != NULLTAG)
																   {
																	 printf("\n\n\t\t DVP-VC relation_type   is not null........ \n");fflush(stdout);
																	 
																	  ITK_CALL(GRM_list_secondary_objects(EEparent_rev,reln_typeDvp,&n_attchs_dvp,&secondary_dvp));

																	 printf("\n\n\t\t DVP-VC After GRM_list_secondary_objects count : %d \n",n_attchs_dvp);fflush(stdout);


																	  if(n_attchs_dvp>0)
																	  {
																		for(ddi=0;ddi<n_attchs_dvp;ddi++)
																		{
																			dvpflag=0;
																		 printf("\n\n\t\t DVP-VC Inside data set for DVP-VC found ........ \n");fflush(stdout);
																		  
																		   SolnItemTag = secondary_dvp[ddi].secondary;
																		  
																		  ITK_CALL(AOM_ask_value_string(SolnItemTag,"object_name",&dataset_name1));
																		  printf("\n\n\t\t DVP-VC Data set name for DVP----%s ........ \n",dataset_name1 );fflush(stdout);

																		   if(strstr(dataset_name1,"DVP") != NULL)
																		  {
																			   printf("\n\n\t\t DVP-VC Inside Flag set as Data set name for DVP----%s ........\n",dataset_name1 );fflush(stdout);

																				dvpflag=1;
																				break;
																		  }
																		}
																		  printf("\n DVP-VC OUTSIDE for loop dvpflag  flag for dvp find ----- :%d  \n",dvpflag);fflush(stdout);
																		  if (dvpflag==1)
																		  {
																			printf("\n DVP-VC Inside dvpflag  flag for dvp find ----- :%d  \n",dvpflag);fflush(stdout);
																		  }
																		  else
																		   {
																			printf("\n\n DVP-VC Inside else as DVP report NOT found attached Container as flag value  %d \n" ,dvpflag );fflush(stdout);
																			
																			EMH_clear_errors();
																			EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "Please Attach DVP Validation Report to Container Part in Specification \n Give Report Name which Start with DVP Word" );
																			decision = EPM_nogo;
																			return decision;
																																							
																		   }
																											
																	  }
																	  else
																	  {
																		   printf("\n\n DVP-VC As no data set found, GIVE THE ERROR Please attach DVP validation report to Container.. (%d) \n",n_attchs_dvp );fflush(stdout);
																		   EMH_clear_errors();
																		   EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "No Dataset Found for Container Part.Please Attach DVP Validation Report to Container in Specification \n Give Report Name which Start with DVP Word" );
																		   decision = EPM_nogo;
																		   return decision;	
																	  }

																   }

															 }
															 else
															{
																	printf("\n\n\t\t DVP-VC Else part type EEparent_rev type_name := %s \n", type_name);fflush(stdout);
															}
									  
								                          }
														 else
														{
															 printf("\n DVP-VC Else container part Not found ===>%s \n",ModPartType);fflush(stdout);
														}
														
												      }
													}

													//end
												 }

											  }
											  else
											  {
												printf("\n Else Part TYPE  DVP-VC  ============= [%s]  \n",PartType); fflush(stdout);
											  }

											 }
											 else
											{
												 printf("\n Else VC DML DR status--(%s) and Bussiness Unit  for DVP :(%s) \n",BusUnitDV, DMLDRdvp);fflush(stdout);

											}

										   }

										 }
										 else
										 {
											printf("\n Else Control Object Not found for DVP not FOUND == %d  \n", n_foundWe);fflush(stdout);
									     }
										   printf("\n Outside fot DVP report check on VC code \n");fflush(stdout);
											  //end for dvp// 
									     }
								      }
							      }
						      }
//					      }  //3 sept
//					  }
//				  }
//				  else
//				  {
//					printf("\n Release type is not Veh release it is [%s]\n",Rel_type);fflush(stdout);
//				  }
//	         }
		}
	}


return decision;
}

int UpdateAllowForm(tag_t  itemRev,char* Toupd)
{

	
	tag_t  *attachments = NULLTAG;
	tag_t  relation_type   = NULLTAG;
	tag_t  user_tag = NULLTAG;
	tag_t  dataset		= NULLTAG;
	char   *ObjectClassType		= NULL;
	char   *gov_class = NULL;
	char   *itemId = NULL;
	int    stat     = ITK_ok;
	int    n_found     = 0;
		  tag_t boTag= NULLTAG;
   	  tag_t creInputTag_r= NULLTAG;
 	  tag_t boTypeTag= NULLTAG;
 	  tag_t  relation_type1   = NULLTAG;
 	  tag_t  tRelationExist  = NULLTAG;
 	  tag_t  Rel_task        = NULLTAG;
	  int status;
 	 char *s;
	int    cnt      = 0;
	int    ij       = 0;
	int    ifail	= 0;

			TCTYPE_find_type("T5_UpdForm", NULL, &boTypeTag);

			if (AOM_ask_value_string(itemRev,"object_name",&itemId)!=ITK_ok);   

			TCTYPE_construct_create_input (boTypeTag, &creInputTag_r);
			if(creInputTag_r != NULLTAG)
					printf("\nInput Tag Created for item id. \n", n_found);fflush(stdout);
			boTypeTag = NULLTAG;

			if(AOM_set_value_string(creInputTag_r, "object_name", itemId));
			if(AOM_set_value_string(creInputTag_r, "t5_IsUpdAllowed", "N"));

			 status = TCTYPE_create_object (creInputTag_r, &boTag) ;
			if(status != ITK_ok)
			{
					EMH_ask_error_text( status, &s);
					printf("\n*** Error with ITK_init_module: %s ***\n",s);fflush(stdout);
					MEM_free(s);
					return status;
			}
			
			creInputTag_r = NULLTAG;
			if(boTag != NULLTAG) printf("\n Update form created. \n");fflush(stdout);
			if(AOM_save(boTag));
			if(AOM_unlock(boTag));


			

				if(GRM_find_relation_type("T5_PartHasUpdForm",&relation_type1));
				if(GRM_find_relation(itemRev,boTag,relation_type1,&tRelationExist));
					if (tRelationExist==NULLTAG)
					   {
							   //###  Creating Relation between DML and Task  ###

							   printf("\n Now Creating Relation Between Design Revision and Update Form \n");fflush(stdout);
							   if(GRM_create_relation(itemRev,boTag,relation_type1,NULLTAG,&Rel_task));
							   if(GRM_save_relation  (Rel_task));
							   printf("\nRelation Created Successfully\n");fflush(stdout);
					   }



	if(GRM_list_secondary_objects_only(itemRev,relation_type,&cnt,&attachments));
				printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
				printf("Update form value  [%s]\n",Toupd); fflush(stdout);
			
				for(ij=0;ij<cnt;ij++)
				{
						dataset = attachments[ij];
						if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   
						printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

						if (strcmp(ObjectClassType,"T5_UpdForm")==0)
						{
							if( AOM_set_value_string(dataset,"t5_IsUpdAllowed",Toupd));
							if(AOM_save(dataset));
							if(AOM_unlock(dataset));

							if( AOM_ask_value_string(dataset,"t5_IsUpdAllowed",&gov_class));
							printf("\n\n Update for value updated to:%s\n",gov_class);fflush(stdout);

						}
				}
	return ITK_ok;
}

int t5removeAllReleaseStatus (tag_t rev)
{
	
	int			status_count;
	tag_t*		status_list;
	int			st_relList_count		= 0; 
	int			Rel_cnt					= 0; 
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ; 
	tag_t		tReleaseStatusList		= NULLTAG; 
	int			n_values				= 0; 
	int			cunt1					= 0; 
	tag_t*		attr_tags				= NULLTAG; 
	logical		*is_it_null				= NULL; 
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;
	int         stat                    = ITK_ok;
	int   ifail				= 0;
	

	
	CALLAPI(WSOM_ask_release_status_list(rev,&status_count,&status_list));

	printf("No of Status == %d\n",status_count);fflush(stdout);
	if(status_count>0) 
	{
		CALLAPI(POM_class_of_instance(rev,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));
		CALLAPI(POM_unload_instances (1,&rev));
		CALLAPI(POM_load_instances(1,&rev,class_id,1));
		CALLAPI(POM_is_loaded(rev,&log1));
		if(log1 == 1)
		{
			 printf("Load Success\n" );fflush(stdout);
		}
		else
		printf("Load Failure\n");fflush(stdout);

		CALLAPI( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
		if(n_values>0)
		{
			CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("Status removal started\n");fflush(stdout);
				CALLAPI(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
				CALLAPI(POM_save_instances(1,&rev,1));
				CALLAPI(POM_refresh_instances(1,&rev,class_id,2));
				CALLAPI(AOM_lock(rev));
				
				CALLAPI(AOM_save(rev));
				CALLAPI(AOM_refresh(rev,1));
				printf("Status removal completed\n");fflush(stdout);

				CALLAPI(POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
				printf("Updated Status Count is :%d\n",n_values);fflush(stdout);
				CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
				cunt1=cunt1-1;
			}
			CALLAPI(AOM_unlock(rev));
		}
		printf("All Statuses removed\n");;fflush(stdout);

	}
	return ITK_ok;	
}
int AssignProject(tag_t  itemRev,char* projectcode)
{

	
	tag_t  projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;
	int         stat                    = ITK_ok;
	int   ifail				= 0;

	// ITK_CALL(AOM_lock(itemRev));
	printf("Projectcode [%s]\n",projectcode); fflush(stdout);
	CALLAPI(PROJ_find(projectcode,&projobj));
	//printf("\n Assigned to Project\n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		//POM_get_user(&username,&user_tag);
		//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		CALLAPI(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
		printf("Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n Project not found\n");fflush(stdout);
	}
	//   ITK_CALL(AOM_save(itemRev));
	//  ITK_CALL(AOM_unlock(itemRev));
	return ITK_ok;
}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );
static int VOO_show_wso
    ( tag_t       wso                         /* <I> */
    );

	static char *VOO_time_stamp
    ();

static int VOO_list_saved_variant_rules
    ( tag_t       itemRev,                    /* <I> */
      int *       nVRules,                    /* <O> */
      tag_t **    vRules                      /* <OF> */
    );
static logical VOO_option_value_hash
    ( int         hash_size,                  /* <I> */
      vector_t *  hash[],                     /* <I> */
      tag_t       option_rev,                 /* <I> */
      int         option_rev_value_index,     /* <I> */
      int         add_if_new                  /* <I> */
    );
static int VOO_variant_expression
    ( tag_t        v1,                        /* <I> */
      int          op,                        /* <I> */
      tag_t        v2,                        /* <I> */
      const char * text,                      /* <I> */
      tag_t      * ve,                        /* <O> */
      logical    * was_new                    /* <O> */
    );
static int VOO_expression_hash
    ( int          hash_size,                 /* <I> */
      vector_t   * hash[],                    /* <I> */
      tag_t        val1,                      /* <I> */
      int          oper,                      /* <I> */
      tag_t        val2,                      /* <I> */
      const char * text,                      /* <I> */
      logical      add_if_new,                /* <I> */
      tag_t      * var_exp,                   /* <O> */
      logical    * was_new                    /* <O> */
    );




int bom_complete( EPM_action_message_t msg )
{

		int   ifail				= 0;
		int   cnt				= 0;
		int   i				= 0;
		int   j				= 0;
		int   ju				= 0;
		int         stat                    = ITK_ok;
		char *objecttype=NULL;
		char *objectname=NULL;
		char   *TempVal			=NULL;
		tag_t DMLTag = NULLTAG;
		tag_t rev1 = NULLTAG;
		tag_t primary1 = NULLTAG;
		int    noAttachment=0;
			tag_t			*attachments			=NULLTAG;
			tag_t			*attachments1			=NULLTAG;
			tag_t			rootTask				=NULLTAG;
			tag_t			relation_type							= NULLTAG;
			tag_t        rev                    = NULLTAG;
   // tag_t        rev1                    = NULLTAG;
	tag_t		 view_type				= NULLTAG;
    tag_t *bom_views=NULL;
	 tag_t  *OptionValue=NULL;
        tag_t  *option_revs=NULL;
	tag_t  item=NULLTAG;
	int    n_bom_views=0;
			int countConfigCtx = 0;
			char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;
	char AllOptions[700];
	char AllOptionValues[700];
	 tag_t	queryTag	= NULLTAG;
	int n_entries = 1;
	char *qry_entries[1] = {"ID"};
	int resultCount=0;
	tag_t        bom_view                = NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
	char*	 ContextobjName			= NULL;
	tag_t			relation_type1							= NULLTAG;
	char			relation_name[TCTYPE_name_size_c+1];
	tag_t  relation_dep	= NULLTAG;
	char *Varruletxt=NULL;
	TempVal=(char *) MEM_alloc(1000);

       
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

		CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0)
			{
			    DMLTag = attachments[0];			    	
			}

    	CALLAPI(GRM_find_relation_type("CMReferences",&relation_type));

		if(relation_type != NULLTAG)
	{
		CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
		printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&cnt,&attachments1));
		printf("\n Checkin- impacted items:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
		  printf("\n to find impacted items\n");fflush(stdout);
		  rev1 = attachments1[i]; 
		  	  if(AOM_ask_value_string(rev1,"object_type",&objecttype));
		  	  if(AOM_ask_value_string(rev1,"object_name",&objectname));
			  if (strcmp(objecttype,"VariantRule")==0)
			{
				  strcpy(TempVal,objectname);
				  primary1=rev1;
				  if(AOM_ask_value_string(rev1,"cfg0VariantRuleText",&Varruletxt));
				  printf("\n Variant rule text is :%s\n",Varruletxt);fflush(stdout);
			}
		}

			  for(j=0;j<cnt;j++)
		{
		  printf("\n to find impacted items\n");fflush(stdout);
		  rev = attachments1[j]; 
		  	  if(AOM_ask_value_string(rev,"object_type",&objecttype));
		  	  if(AOM_ask_value_string(rev,"object_name",&objectname));
			 
	
		  //if(AOM_ask_value_string(rev,"object_type",&objecttype));
		



	if (strcmp(objecttype,"T5_PlatformRevision")==0)
	{
		printf( "\n INside platform\n"); fflush(stdout);

				if ( rev !=NULLTAG )
			{
				CALLAPI ( PS_find_view_type( "view", &view_type ));
				printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

				if ( NULLTAG != view_type )
				{
					CALLAPI ( ITEM_ask_item_of_rev( rev, &item ));
					CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

					bom_view = bom_views[0];
				}
				else
				printf("\nView not found check.......\n"); fflush(stdout);
			}

                  tc_strcpy(AllOptions,"");
                  tc_strcpy(AllOptionValues,"");
				  CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
												if(relation_dep != NULLTAG)
												{
													printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);	
												}																	
												 
												CALLAPI(GRM_list_secondary_objects_only(item,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
												printf("\n\t Configuration Context count is : %d",countConfigCtx);

												if(countConfigCtx>0)
												{
													  ConfigCtx=ConfigCtxSecObject[0];
													  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
													  CALLAPI(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));	  
													  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
													  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);	 

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
													  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

													  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
													  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
													  if (queryTag)
													  {
														printf("\n\tFound Query");fflush(stdout);
													  }else
													  {
														printf("\n\tNot Found Query");fflush(stdout);
													  }									  	 

													  qry_values[0] = SmCrIDContext;

													  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &OptionValue));
													  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);	
													  
													   for (ju=0;ju<resultCount;ju++ )
																  {
																	 Optfmly_tag = OptionValue[ju];
																	 CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
																	 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
																	 tc_strcat(AllOptions,",");
															tc_strcat(AllOptions,ContextobjName);

												}
												}

			}
	
		  
		}
	}
	char *token = strtok(Varruletxt, "='");

	while (token != NULL)
    {
        printf("%s\n", token); fflush(stdout);	

        token = strtok(NULL, "='");
		if(tc_strstr(AllOptions,token)==NULL)
		{
			tc_strcat(AllOptionValues,"\n");
			tc_strcat(AllOptionValues,token);
			printf("option Values are:%s",AllOptionValues); fflush(stdout); 
		}
		else
		{
			
           printf("option found are:"); fflush(stdout); 
		}
    }



}

int vc_release( EPM_action_message_t msg )
{	
	
		int   ifail				= 0;
			int         stat                    = ITK_ok;
    char        *ItemId                 = NULL;
    char        *RevId                  = NULL;
	char        *VCItemId                 = NULL;
	char        *SVRType                  = NULL;

    tag_t        rev                    = NULLTAG;
    tag_t        rev1                    = NULLTAG;
	tag_t		 view_type				= NULLTAG;

	int    n_bom_views=0;
	int    j=0;
	tag_t *bom_views=NULL;
	tag_t  bom_view_type=NULLTAG;
	int    bom_view_index=0;
	int    noAttachment=0;
	tag_t  item=NULLTAG;
	tag_t        bom_view                = NULLTAG;
	tag_t			*attachments			=NULLTAG;
	tag_t			*attachments12			=NULLTAG;

	tag_t   e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	tag_t   Childobject=NULLTAG;
	tag_t   Childobject1=NULLTAG;
	tag_t   Childobject3=NULLTAG;
	tag_t   Childobject4=NULLTAG;
	tag_t   Childobject33=NULLTAG;
	tag_t			dataset									= NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int     n_options=0;
	int     errorflag=0;
	int     errorflag4=0;
	int     errorflag1=0;
	int     ernew=0;
	int     errorflag2=0;
	int     errorflag34=0;
	tag_t  *options=NULL;
	char   *v2_text=NULL;
	//tag_t  *option_revs=NULL;
	int     option_value_index=-1;
	tag_t   option1=NULLTAG;
	tag_t  *option1_rev=NULL;
	int    *option1_value_index=NULL;
	tag_t   option2=NULLTAG;
	tag_t  *option2_rev=NULL;
	int    *option2_value_index=NULL;
	int     inx, jnx, knx;
	int     n_option_data=0,p1=0;
	tag_t topline = NULLTAG;
	void  **option_data=NULL;
	variant_rule_option_data_t *variant_rule_option_data=NULL;
	variant_rule_option_data_t option_value_dictionary={NULL};
	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	int     n_ves_2_save=0;
	int     n_lines2=0;
	int     n_lines3=0;
	int     n_lines4=0;
	int     p2=0;
	int     ss=0;
	int     p36=0;
	
	int     p4=0;
	tag_t  *ves_2_save=NULL;
	tag_t   toggle_ve=NULLTAG;
	int n_lines,n_lines1,Item_ID = 0;
	tag_t *lines = NULL;
	tag_t *lines2 = NULL;
	tag_t *lines3 = NULL;
	tag_t *lines4 = NULL;
	tag_t *Newlines = NULL;
	char *Item_ID_str=NULL;
	tag_t			relation_type							= NULLTAG;
	tag_t			relation_type1							= NULLTAG;
	char			relation_name[TCTYPE_name_size_c+1];
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *child_bl_formula=NULL;
	char *child_bl_formula23=NULL;
	char *objecttype=NULL;
	char *objectname=NULL;
	char *objectdesc=NULL;
	logical modB=FALSE;
	char *tempmat=NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	//char *MulModule= NULL;
	char Fresh[1900];
	char NoModule[1900];
	char RevMisMatch[900];

	
	
	//int ifail = ITK_ok;
	int cnt = 0;
	int cnt12 = 0;
	int cnt33 = 0;
	int ko = 0;
	int p3 = 0;
	int i = 0;
	int status_count = 0;
	tag_t  v1=NULLTAG;
	tag_t  primary=NULLTAG;
	tag_t  primary1=NULLTAG;
	tag_t	tRelationExist	= NULLTAG;
	tag_t	tRelationExist1	= NULLTAG;
	tag_t	tRelationExist2	= NULLTAG;
	tag_t	tRelationExist3	= NULLTAG;
	tag_t	tRelationExist4	= NULLTAG;
	//const tag_t * 	primary1;
	int ix=0;
	char *option_item_s     =NULL;
	char *option_s          =NULL;
	char *option_eq_s       =NULL;
	char *option_val_s      =NULL;
	tag_t  item1=NULLTAG;
    tag_t			rootTask				=NULLTAG;
	char *tempmat1=NULL;
	tag_t option;
	tag_t option_rev;
	
	tag_t  objTypeTagDi=NULLTAG;
	tag_t  objTypeTagDi1=NULLTAG;
	tag_t  opt_tag=NULLTAG;
	tag_t  master_tag=NULLTAG;
	tag_t  Itemmaster_tag=NULLTAG;
	tag_t  *opts=NULLTAG;
	tag_t  *rootLine=NULL;
	tag_t * 	bom_variant_config=NULL;
	tag_t  *opt_revs=NULLTAG;
	tag_t  *secondaries=NULL;
	tag_t  *occs=NULL;
	tag_t  relation_dep	= NULLTAG;
	tag_t *occsal;
	tag_t  *secondary_objects	= NULLTAG;
	tag_t  *secondary_objects1	= NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	tag_t   *status_list          = NULLTAG;
	double mat[4][4];
	//double * mat1;
	double divInt=1000;
	int imat=0;
	int jmat=0;
	int IntAtr5=0;
	int n_occs=0;
	int iy=0;
	int p34=0;
	int countConfigCtx = 0;
	char * spcPrefName = NULL;
	logical lNull = false, lEmpty = false;
	 int         n_instances;
    tag_t           *instances;
	//int n_occs=0;
        int    n_instances1     = 0;
        int        *instance_levels;
        int        *instance_where_found;
        int    *class_levels;
		 tag_t class_id = NULL;
		 tag_t class_idr = NULL;
		 char *class_name=NULL;
        int    *class_where_found;
		logical         log1;
		tag_t attr_idDR ;
        int    n_classes                = 0;
        tag_t  *ref_classes             = NULLTAG;
        tag_t  *ref_instances   = NULLTAG;
        tag_t  *ref_instances1  = NULLTAG;
        tag_t  *ref_instancesTemp       = NULLTAG;
        tag_t  *ref_instancesTemp1      = NULLTAG;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;
	char*	 itemId12			= NULL;
	char*	 itemId123			= NULL;
	char*	 itemId1234			= NULL;
	char*	 itemId12345			= NULL;
	 tag_t	queryTag	= NULLTAG;
	int n_entries = 1;
	char *qry_entries[1] = {"ID"};
	int resultCount=0;
	
	tag_t Optfmly_tag = NULLTAG;
	char*	 ContextobjName			= NULL;
	int    opcode=-1;
	tag_t  v2=NULLTAG;
	char  *str=NULL;
	char  *object_type=NULL;
	char  *find_option_name_p=NULL;
    char  *find_option_desc_p=NULL;
	char  *Context_Str=NULL;
	char *toggle_value=NULL;
     tag_t toggle_option=NULLTAG;
     tag_t *toggle_option_rev=NULLTAG;
     int   toggle_value_index=-1;
	tag_t *ves=NULL;
	int *ind=NULL;
	int *ind1=NULL;
	int int_qunt=0;
	int    n_ves,n_opts,k=0,k1=0,Opt1=0,n_values1=0,n_secondaries=0,countDep,countDep1=0;
	tag_t owning_item = NULLTAG;
	tag_t			*attachments1							= NULLTAG;
	char *name = NULL;
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char*			username				=NULL;
	 char **rulename = NULL;
    char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	int xform_matrix1 = 0;
	int blqu = 0;
	char *blqu_str = NULL;
	char *xform_matrix_str = NULL;
	char ***ite = NULL;
	char ***opt = NULL;
	char ***descr = NULL;
	char ***value = NULL;
	 tag_t  *OptionValue=NULL;
        tag_t  *option_revs=NULL;
	char *CurrentRelStatus = NULL;
	int  count=0;
	char   *TempVal			=NULL;
	char   *VehName			=NULL;
	char   *DMLDRstatus			=NULL;
	tag_t  	VCrev;
	tag_t  	objTypeTag=NULLTAG;
	tag_t  	Itemrev;
	tag_t ItemRev = NULLTAG;
	tag_t ItemRev1 = NULLTAG;
	tag_t	Rel_task		= NULLTAG;
	tag_t RevNewSeqTag = NULLTAG;
	tag_t        parent_master           = NULLTAG;
	tag_t        parent_master1           = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;                              
	tag_t item_type_tag = NULLTAG;
	tag_t *closurerule = NULL;
	tag_t item_create_input_tag = NULLTAG;
	 logical retain=false;
	 tag_t   status2=NULLTAG;
	 tag_t   status3=NULLTAG;
	 tag_t   status4=NULLTAG;
	tag_t rev_type_tag = NULLTAG;
		tag_t tsk_dml_rel_type;
		tag_t DMLRevTag = NULLTAG;
		char *class_name1;
		char* DMLtype		= NULL;	
		//tag_t  *ref_instancesTemp       = NULLTAG;
		
		char PartNum[300];
		int Childstrcnt		= 0;	
	int p=0;
	int ju=0;
	int DMLSTVALUT=0;
	int jy=0;
	int v_entr=0;
	tag_t class_id1=NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *bvs, *bvrs;
    int    bv_count, bvr_count;
	tag_t        bv,bvr,parentBvr,bv1,bvr1       = NULLTAG;
	tag_t        Childrev                = NULLTAG;
	tag_t			user_tag				=NULLTAG;
	int rulefound= 0;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t cond_ve;
	tag_t loadif_ve;
	int structcount=0;
	tag_t veb;
	logical is_latest;
	tag_t *tags_found = NULL;
    int n_tags_found = 0;
	tag_t *tags_found1 = NULL;
    int n_tags_found1 = 0;
	tag_t *tags_found3 = NULL;
    int n_tags_found3 = 0;
	tag_t close_tag;
	tag_t ** 	variant_rule_list= NULLTAG;
	tag_t top_bomline;
	tag_t clause_list = NULLTAG; 
	TempVal=(char *) MEM_alloc(1000);
	//moh
	char* DMLDRStrT		= NULL;	
	char* PRTDRStr		= NULL;	
	char* PrtDRstus		= NULL;	
	char* PrtProjj		= NULL;	
	char* Obj_PrtTyp		= NULL;	
	char ERCRelErrStrng[1500];
	int PRTSTVALU=0;
	int DRstusFlag=0;
	int add=0;
	//moh



	tc_strcpy(ERCRelErrStrng,"");
		POM_get_user(&username,&user_tag);
		printf("\nStarting for taskbreskdownnn :%s....\n",username);fflush(stdout);	
		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

		CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0)
			{
			    DMLTag = attachments[0];			    	
			}

    	CALLAPI(GRM_find_relation_type("CMReferences",&relation_type));
    	CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_type1));



		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
			if (tsk_dml_rel_type!=NULLTAG)
			{		
			  CALLAPI(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&count,&DMLRevision));
			  printf("\n\n\t\t DML Revision from Task for MR : %d",count);fflush(stdout);	
			  for (jy=0;jy<count ;jy++ )
			  {	
				CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[jy],&is_latest));
				printf("\n\n\t\t is_latest MR is : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{	
					DMLRevTag = DMLRevision[jy];
					CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
					CALLAPI(POM_name_of_class(class_id1,&class_name1));
					printf("\n\n\t\t class_name found1 MR :%s",class_name1);
					
					CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));
					DMLDRStrT=NULL;
					DMLSTVALUT=0;
					DMLDRStrT=subString(DMLDRstatus, 2, 1);
					printf("\n DML DR status: DMLDRStrT: %s and ",DMLDRStrT);fflush(stdout);
					DMLSTVALUT=atoi(DMLDRStrT);
					printf("DML DR status: DMLSTVALUT: %d \n",DMLSTVALUT);fflush(stdout);

				}
			  }
			}


		//if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DMLDRstatus));

	if(relation_type != NULLTAG)
	{
		CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
		printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&cnt,&attachments1));
		printf("\n Checkin- impacted items:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
		  printf("\n to find impacted items\n");fflush(stdout);
		  rev1 = attachments1[i]; 
		  	  if(AOM_ask_value_string(rev1,"object_type",&objecttype));
		  	  if(AOM_ask_value_string(rev1,"object_name",&objectname));
			  if (strcmp(objecttype,"T5_PlatformRevision")==0)
			{
				  //strcpy(TempVal,objectname);
				  primary1=rev1;

			}
	
		  //if(AOM_ask_value_string(rev,"object_type",&objecttype));
		}
		
	

		  printf("\n object type......:%s\n",objecttype ); fflush(stdout);


		  for(j=0;j<cnt;j++)
		{
		  printf("\n to find impacted items\n");fflush(stdout);
		  rev = attachments1[j]; 
		  	  if(AOM_ask_value_string(rev,"object_type",&objecttype));
		  	  if(AOM_ask_value_string(rev,"object_name",&objectname));
			 
	
		  //if(AOM_ask_value_string(rev,"object_type",&objecttype));
		



	if (strcmp(objecttype,"VariantRule")==0)
	{
		if(AOM_ask_value_string(rev,"object_desc",&objectdesc));
		strcpy(TempVal,objectname);
		printf( "\n INside platform\n"); fflush(stdout);

				if ( primary1 !=NULLTAG )
				{
					CALLAPI ( PS_find_view_type( "view", &view_type ));
					printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

					if ( view_type != NULLTAG )
					{
						CALLAPI ( ITEM_ask_item_of_rev( primary1, &item ));
						CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

						bom_view = bom_views[0];
					}
					else
					printf("\nView not found check.......\n"); fflush(stdout);
				}

			//printf(  "%s %s: Revision is ", VOO_prog, VOO_time_stamp() );
			//CALLAPI ( VOO_show_wso( rev ) );fflush(stdout);
			//printf(  "%s %s: BOMView  is ", VOO_prog, VOO_time_stamp() );
			//CALLAPI ( VOO_show_wso( bom_view ));fflush(stdout);

			 if ( bom_view != NULLTAG )
				{
					printf(" before BOM_create_window..\n");	fflush(stdout);	
					CALLAPI ( BOM_create_window( &bom_window ));
					//CALLAPI(CFM_find( "ERC release and above", &rule ))
					CALLAPI(CFM_find( "Latest Working", &rule ))
					CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
					
					
					CALLAPI(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
					
					printf ("rule count %d \n",rulefound);fflush(stdout);
					 if (rulefound > 0)
					 {
									close_tag = closurerule[0];
									printf ("closure rule found \n");fflush(stdout);
								   // MEM_free(tags_found);
					 }
					 CALLAPI(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
					
					CALLAPI(BOM_set_window_pack_all(bom_window, FALSE));
					CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, primary1, NULLTAG, &top_line ));
					printf( " After BOM_set_window_top_line..\n");fflush(stdout);
					
					CALLAPI ( BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
					printf( " BOM_window_ask_variant_rule..\n");fflush(stdout);

					//ITK ( ITEM_ask_rev_variants ( rev, &e_block ) )
                    
					CALLAPI(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
					CALLAPI(TCTYPE_ask_name(objTypeTag,type_name));	


				//	CALLAPI(AOM_UIF_ask_value(primary1,"expression_block",&rulename));
				//	fprintf( stderr, " BOM_window_ask_variant_rule..%s\n",rulename);

					CALLAPI ( ITEM_ask_rev_variants ( primary1, &e_block ));
					printf(  " ITEM_ask_rev_variants..\n");fflush(stdout);
					
					if(top_line!=NULLTAG)
					{
						CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
						printf("\n Before setting option n_lines: %d and Item_ID_str :%s\n", n_lines,Item_ID_str);
						CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
										CALLAPI(BOM_window_show_variants(bom_window))   ;
										//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config))   ;
										//if(BOM_variant_config_apply (bom_variant_config))   ;

										//if(BOM_variant_rule_apply(primary1))   ;	
										printf("\n After inside bom_window-----\n"); fflush(stdout);			
										CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&rev))   ;
										printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

										//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
										CALLAPI(BOM_window_hide_variants(bom_window))   ;

										CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));

						if (n_lines >0)
						{
							structcount=0;
							for (p1=0;p1<n_lines ;p1++ )
							{
								if(Childobject) Childobject=NULLTAG;
								Childobject=lines[p1];
								CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
								printf(  " child_item_id ..:%s\n",child_item_id);

								CALLAPI(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));

								printf(  " child_item_no ..:%d\n",n_lines2);fflush(stdout);
                                structcount++;
                                
								tc_strcpy(childstr[p1].parent_part,child_item_id); 
								childstr[p1].child=n_lines2; 
								printf("\n Part no IS: %s %d \n",childstr[p1].parent_part,childstr[p1].child);fflush(stdout);
								


								//ITK ( VOO_show_wso( Childobject ));
							}
						}	
					}


					// start

					CALLAPI(CFM_find( "ERC release and above", &rule ))
					//CALLAPI(CFM_find( "Latest Working", &rule ))
					CALLAPI(BOM_set_window_config_rule( bom_window, rule ));

                        memset( &option_value_dictionary, 0, sizeof ( option_value_dictionary ) );

								   CALLAPI ( BOM_variant_rule_ask_options( bom_variant_rule, &v_entr, &options, &option_revs ) )
									     printf("\n No of Option values in the rule:%d\n",v_entr);fflush(stdout);

                        



				if ( top_line!=NULLTAG )
					{
						 printf("\n %s %s: inside topline Revision is \n", VOO_prog, VOO_time_stamp() ); fflush(stdout);
						
						 fprintf( stderr, "\n print rev first .\n");
						 CALLAPI ( VOO_show_wso( primary1 )) ;

						// CALLAPI ( ITEM_find_item( ItemId, &master_tag ));
						 fprintf( stderr, "\n print Master second .\n");
						
									CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
									printf("\n before hiide LLlast Before setting option n_lines1: %d \n", n_lines1);
									if(bom_window != NULLTAG)
									{
										printf("\n before inside bom_window-----\n"); fflush(stdout);																	
										CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
										CALLAPI(BOM_window_show_variants(bom_window))   ;
										//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config))   ;
										//if(BOM_variant_config_apply (bom_variant_config))   ;

										//if(BOM_variant_rule_apply(primary1))   ;	
										printf("\n After inside bom_window-----\n"); fflush(stdout);			
										CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&rev))   ;
										printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

										//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
										CALLAPI(BOM_window_hide_variants(bom_window))   ;
										CALLAPI(BOM_window_ask_is_modified(bom_window,&modB))   ;
										if(modB)
										{
											fprintf( stderr, "\n modified bom window:..\n");fflush(stdout);
										}
										else
										{
											fprintf( stderr, "\n not modfiifed ..\n");fflush(stdout);
										}																	

										CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));

										CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
												if(relation_dep != NULLTAG)
												{
													printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);	
												}																	
												 
												CALLAPI(GRM_list_secondary_objects_only(item,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
												printf("\n\t Configuration Context count is : %d",countConfigCtx);

												if(countConfigCtx>0)
												{
													  ConfigCtx=ConfigCtxSecObject[0];
													  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
													  CALLAPI(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));	  
													  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
													  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);	 

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
													  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

													  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
													  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
													  if (queryTag)
													  {
														printf("\n\tFound Query");fflush(stdout);
													  }else
													  {
														printf("\n\tNot Found Query");fflush(stdout);
													  }									  	 

													  qry_values[0] = SmCrIDContext;

													  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &OptionValue));
													  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);						
												}

										printf("\n 2nd time LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

										printf("\n.....mulmodule is start..%s\n",MulModule);fflush(stdout);

										EMH_clear_errors();

										if (n_lines1 >0)
										{
											//MulModule = (char *)MEM_alloc (1024 * sizeof(char));
											tc_strcpy(MulModule,"");
											tc_strcpy(NoModule,"");
											tc_strcpy(RevMisMatch,"");
											for (p3=0;p3<n_lines1 ;p3++ )
											{
												if(Childobject1) Childobject1=NULLTAG;
												Childobject1=lines[p3];
												CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
												//fprintf( stderr, " child_item_id ..:%s\n",child_item_id);

												

												CALLAPI(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));

												fprintf( stderr, " child_item_no ..:%d\n",n_lines3);fflush(stdout);
 /* for structure
												for (p36=0;p36<structcount ;p36++ )
												{
													if((childstr[p36].parent_part)!=NULL) 
														tc_strcpy(PartNum,childstr[p36].parent_part);
													Childstrcnt = (childstr[p36].child);
													printf("\n Part no IS in loop: %s %d \n",PartNum,Childstrcnt);fflush(stdout);
													if ((tc_strcmp(PartNum,child_item_id1)==0) && n_lines3== Childstrcnt)
													{
                                                        printf("\nmatching found\n");fflush(stdout);
														break;
													}
													else if ((tc_strcmp(PartNum,child_item_id1)==0) && n_lines3!= Childstrcnt)
													{
															tc_strcat(RevMisMatch,"[");
															tc_strcat(RevMisMatch,child_item_id1);
															tc_strcat(RevMisMatch,"]");
															tc_strcat(RevMisMatch,",");
															errorflag34=errorflag34+1;
                                                       
													}
													
												}

												end structure */


												

												


										//				if (n_lines3 >0)
											//				{
										//						for (p34=0;p34<n_lines3 ;p34++ )
											//					{
//																	if(Childobject33) Childobject33=NULLTAG;
//																	Childobject33=lines3[p34];
//																	CALLAPI(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
//																	CALLAPI(AOM_ask_value_string(Childobject33, "bl_formula", &child_bl_formula23 ));
//																	fprintf( stderr, " child_bl_formula--------------> %s\n",child_bl_formula23);

//																	if(tc_strcmp(child_bl_formula23,"")==0 && resultCount >0)
//																	{
//																		printf("\n CC available Variant formula not available \n"); fflush(stdout);
//																		EMH_store_error_s2(EMH_severity_error,ITK_err, "No Variant formula found for module",child_item_id15);
//																		//return ITK_err;		
//																	}
//																	else
//																	{ 
//																	  int cnt33=0;
//
//																	  for (ju=0;ju<resultCount;ju++ )
//																	  {
//																		 Optfmly_tag = OptionValue[ju];
//																		 CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
//																		 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
//																															 
//																		 if(ContextobjName)
//																		 {
//																			// printf("\n\t Variant formula is incompleteeeee :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
//																			  printf("\n\t child_bl_formula value:%s",child_bl_formula23);
//																			 printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(child_bl_formula23,ContextobjName)); fflush(stdout);
//
//																			
//																			if(tc_strstr(child_bl_formula23,ContextobjName)==NULL)
//																			{
//																				printf("\n inside iff \n"); fflush(stdout);
//																				cnt33++;
//																				
//																			}
//																			else
//																			 {
//																				printf("\n inside else \n"); fflush(stdout);
//																			
//																			 }
//																		 }
//																	  }
//
//																	  printf("\n cnt value is at end for loop :%d\n",cnt33); fflush(stdout);
//																	  if (cnt33>0)
//																	  {
//																				 printf("\n cnt greator than 1 :%d\n",cnt33); fflush(stdout);
//																				//EMH_clear_errors();
//																				EMH_store_error_s2(EMH_severity_error,ITK_err, "All SVR option not utilised in the variant formula for module",child_item_id15);
//																				return ITK_err;	
//																	  }
//
//															/		}
														//		}
														//	}
                                                  

												  		if (n_lines3 >0)
														{
															for (p34=0;p34<n_lines3 ;p34++ )
															{
															if(Childobject33) Childobject33=NULLTAG;
															Childobject33=lines3[p34];
															CALLAPI(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
															CALLAPI(BOM_line_look_up_attribute ("bl_rev_last_release_status",&IntAtr5));
															CALLAPI(BOM_line_ask_attribute_string(Childobject33, IntAtr5, &child_bl_formula23)); 

															if((tc_strstr(child_bl_formula23,"ERC Released")==NULL) || (tc_strstr(child_bl_formula23,"T5_LcsErcRlzd")==NULL) )
																{
																fprintf( stderr, "\n Valid release status \n");

																}
																else
																{
																EMH_clear_errors();
																EMH_store_error_s3(EMH_severity_error,ITK_errErr1,"These ",child_item_id15," does not have ERC Released status");
																return ITK_errErr1;
																}

																if (p34>0)
																{


																 if (tc_strcmp(MulChild,child_item_id15)==0)
																 {
																	tc_strcpy(MulChild,"");
																	tc_strcat(MulChild,child_item_id15);
                                                                  continue;
																 }
																 else
																 {
																	 errorflag2=errorflag2+1;
																	 break;
																 }
																}

															tc_strcpy(MulChild,"");
															tc_strcat(MulChild,child_item_id15);

															printf("\n.....i am inside diff child .%s\n",MulChild);fflush(stdout);

															//CALLAPI ( ITEM_ask_latest_rev( parent_master, &VCrev ));
															//CALLAPI (WSOM_ask_release_status_list(VCrev,&status_count,&status_list));

																//Checking DR-validation for Modules:start.

																CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design_t5_RevPartType", &Obj_PrtTyp));
																CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design Revision_t5_ProjectCode", &PrtProjj));
																CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design Revision_t5_PartStatus", &PrtDRstus));
																printf("\n Part: %s type: %s project: %s PrtDRstus: %s DML DR: %s Relstatus: %s",child_item_id15,Obj_PrtTyp,PrtProjj,PrtDRstus,DMLDRstatus,child_bl_formula23);fflush(stdout);
																PRTDRStr=NULL;
																PRTSTVALU=0;
																PRTDRStr=subString(PrtDRstus, 2, 1);
																printf("\n Part DR status: PRTDRStr: %s",PRTDRStr);fflush(stdout);
																PRTSTVALU=atoi(PRTDRStr);
																printf("Part DR status: PRTSTVALU: %d \n",PRTSTVALU);fflush(stdout);
																if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																{
																	printf("\n Skipping dummy part.%s\n",child_item_id15);fflush(stdout);
																}
																else
																{
																	DRstusFlag=0;
																	DRstusFlag = ChkFrstLvlModuleDRstus(child_item_id15,DMLSTVALUT);
																	printf("GMD::B:DRstusFlag: %d",DRstusFlag);fflush(stdout);
																	if (DRstusFlag >0)
																	{
																		printf("\n GMD::B:Released module part is OKKK.:%s ", child_item_id15);fflush(stdout);
																	}
																	else
																	{
																		//ADD PART NUMBER3.
																		if ((add==10)||(add==20)||(add==30)||(add==40)||(add==50)||(add==60)||(add==70)||(add==80)||(add==90)||(add==100))
																		{
																			tc_strcat(ERCRelErrStrng,"\n");
																		}
																		tc_strcat(ERCRelErrStrng,child_item_id15);
																		tc_strcat(ERCRelErrStrng,",");
																		add++;
																		printf("\n Rel module part added to ERCRelErrStrng:%d:%s ",add, child_item_id15);fflush(stdout);
																	}
																}
																//Checking DR-validation for Modules:start.
															}
															if(tc_strcmp(ERCRelErrStrng,"")!=0)
															{
																printf("\n DR:ERRORRR.:%s", ERCRelErrStrng);fflush(stdout);
																EMH_clear_errors();
																EMH_store_error_s2(EMH_severity_error,ITK_err,"Below mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision.\n",ERCRelErrStrng);	
																return ITK_err;
															}
														}


														if (n_lines3 > 1)
														{
															printf("\n.....mulmodule is before..%s\n",MulModule);fflush(stdout);
															printf("\n.....child_item_id1 is before..%s\n",child_item_id1);fflush(stdout);
															tc_strcat(MulModule,"[");
															tc_strcat(MulModule,child_item_id1);
															tc_strcat(MulModule,"]");
															tc_strcat(MulModule,",");
															errorflag=errorflag+1;
															printf("\n.....show error for mul....%d\n",n_lines3);fflush(stdout);
															printf("\n.....mulmodule is after..%s\n",MulModule);fflush(stdout);
															//tc_strcpy(Fresh,MulModule);
															//printf("\n.....Fresh is after..%s\n",Fresh);fflush(stdout);

															
														}	

													if (n_lines3 == 0)
														{
															
															tc_strcat(NoModule,"[");
															tc_strcat(NoModule,child_item_id1);
															tc_strcat(NoModule,"]");
															tc_strcat(NoModule,",");
															errorflag1=errorflag1+1;
															printf("\n.....show error....");fflush(stdout);
															printf("\n.....show error for no mul....%d\n",n_lines3);fflush(stdout);
															
														}	


														
														


												//ITK ( VOO_show_wso( Childobject ));
											}
											if ((errorflag>0) && (errorflag1>0) && (errorflag2>0))
											{
												printf("\n.....child_item_id1 show error....length :%d and value : %s",tc_strlen(child_item_id1),child_item_id1);fflush(stdout);
												printf("\n.....show error....length :%d and value : %s",tc_strlen(MulModule),MulModule);fflush(stdout);
												MulModule[1899] = '\0';
												//printf("\n.....show error....length :%d and value fresh : %s",tc_strlen(Fresh),Fresh);fflush(stdout);
                                                EMH_clear_errors();
												EMH_store_initial_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");

												return ITK_Prjerr;

												//EMH_store_error_s3(EMH_severity_error,ITK_errErr,"No module is present under ",NoModule," please verify the SVR");
												
												
												//return ITK_errErr;
											}
											if ((errorflag>0) && (errorflag1==0))
											{
												printf("\n.....show error....");fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
												//EMH_store_error_s3(EMH_severity_error,ITK_errErr,"No module is present under ",NoModule," please verify the SVR");
												//return ITK_errErr;
												return ITK_Prjerr;
											}
											if ((errorflag==0) && (errorflag1>0))
											{
												printf("\n.....show error....");fflush(stdout);
												EMH_clear_errors();
												//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
												EMH_store_error_s3(EMH_severity_information,ITK_errErr,"No module is present under **",NoModule," please verify the SVR");
												//return ITK_errErr;
												//return ITK_Prjerr;
											}
											if ((errorflag34>0) && ((tc_strcmp(DMLDRstatus,"DR3")==0) || (tc_strcmp(DMLDRstatus,"DR4")==0) || (tc_strcmp(DMLDRstatus,"DR5")==0)))
											{
												printf("\n.....show error....");fflush(stdout);
												EMH_clear_errors();
												//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
											//	EMH_store_error_s3(EMH_severity_information,ITK_errErr,"No released module is present under ",RevMisMatch," please verify the SVR");
												//return ITK_errErr;
												//return ITK_Prjerr;
											}
											
										}	
										
									}
									else
									{
										fprintf( stderr, "\n no bom window found here \n");
									}

									//break;					
							}

						
						
							
										  
										 
									
							}
							errorflag4=0;
							printf("\n VCItemId := %s\n\n", TempVal); fflush(stdout);
							VehName=(char *) MEM_alloc(20);
							itemId12 = tc_strtok(TempVal,"_");
							RevId=tc_strtok(NULL,"_");
							itemId123=subString(itemId12,0,8);
							itemId1234=subString(itemId12,0,4);
							itemId12345=subString(itemId12,11,1);
							tc_strcpy(VehName,"");
							tc_strcpy(VehName,itemId123);
                            tc_strcat(VehName,itemId12345);
							printf("\n itemId12 is .%s \n",itemId12); fflush(stdout);
							printf("\n ritemId1234 is  Found.%s \n",itemId1234); fflush(stdout);
							//printf("\n rev_type_tag Tag Found.");

								//const char **attrs = (char **) MEM_alloc(2 * sizeof(char **));
								//const char **values = (char **) MEM_alloc(2 * sizeof(char **));
								const char *attrs[2];
								const char *values[2];

								attrs[0] ="item_id";
								attrs[1] ="object_type";
								values[0] = (char *)itemId12;
								values[1] = "Design";

								CALLAPI(ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found));
								MEM_free(attrs);
								MEM_free(values);

								printf( "\n VC found count %d\n",n_tags_found); fflush(stdout);

                           // CALLAPI(ITEM_find_item(itemId12, &parent_master1))

								if (n_tags_found == 0)
								{
									errorflag4=errorflag4+1; 
								}


								if (errorflag4>0)
								{
                                     TCTYPE_find_type("Design Revision", NULL, &rev_type_tag);
															if(rev_type_tag)
															{
																	printf("\n rev_type_tag Tag Found."); fflush(stdout);
															}
															TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
															AOM_set_value_string(rev_create_input_tag, "object_name", itemId12);
															AOM_set_value_string(rev_create_input_tag, "object_desc", objectdesc);
															AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1");
															CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_ProjectCode", itemId1234)); 
															CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_DesignGrp", "00"));       
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartType","VC"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DocRemarks","NA"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_MThickness","NA"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnDept","Pune-Design"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnOwn","PROPUN"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_ColourInd","Y"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PrtCatCode","VEHICLE"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartStatus",DMLDRstatus));         
															/* Construct a CreateInput object for Item */
															TCTYPE_find_type("Design", NULL, &item_type_tag);
															if(item_type_tag)
															{
																	printf("\n item_type_tag Tag Found."); fflush(stdout);
															}
															TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

															AOM_set_value_string(item_create_input_tag, "item_id", itemId12);
															AOM_set_value_string(item_create_input_tag, "object_name", itemId12);
															AOM_set_value_string(item_create_input_tag, "object_desc", objectdesc);
															AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

															//Create Design Object and Design Revision
															TCTYPE_create_object(item_create_input_tag, &parent_master1);
															if(parent_master1)
															{
																	printf("\n Design Revision created."); fflush(stdout);
																		 
																	AOM_save(parent_master1);
																	
																	
																	
																   // *item1 = item;
															}

															CALLAPI ( ITEM_ask_latest_rev( parent_master1, &ItemRev ));
																	 CALLAPI(AOM_lock(parent_master1));
																	 CALLAPI(AOM_lock(ItemRev));
																	
																	  CALLAPI(AOM_save(ItemRev));
																	  CALLAPI(AOM_unlock(ItemRev));
																	  AOM_unlock(parent_master1);

																	//  CALLAPI (CR_create_release_status("T5_LcsWorking",&status2));
																	//printf("\n release status find.");fflush(stdout);
																	//CALLAPI(EPM_add_release_status(status2,1,&ItemRev,retain));

																	CALLAPI(UpdateAllowForm(ItemRev,"Y"));

																	printf("\n before project assign.");fflush(stdout);
																	CALLAPI(AssignProject(ItemRev,itemId1234));
																	printf("\n after project assign.");fflush(stdout); 

																	CALLAPI(ITEM_list_bom_views(parent_master1,&bv_count, &bvs))

																		CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master1,&bv1 ));
																		CALLAPI(AOM_save( bv1 ))
																		CALLAPI( AOM_save( parent_master1 ))
																		CALLAPI( AOM_unlock( parent_master1 ))
																		fprintf( stderr, "\n inside PS_create_bom_view..\n");	

																		CALLAPI(PS_create_bvr( bv1, "", "", false, ItemRev,&bvr1) )
																		if(bvr !=NULLTAG)
																		{							
																			CALLAPI( AOM_save( bvr1) )
																			CALLAPI (AOM_save( ItemRev ))
																			CALLAPI( AOM_unlock( ItemRev )) 
																			fprintf( stderr, "\n inside  PS_create_bvr..\n"); 
																		}

																		

														 printf("\n\t VC not found loop..........");fflush(stdout); fflush(stdout);
								}

                                //char **attrs1 = (char **) MEM_alloc(2 * sizeof(char *));
								//char **values1 = (char **) MEM_alloc(2 * sizeof(char *));
								const char *attrs1[2];
								const char * values1[2];

								attrs1[0] ="item_id";
								attrs1[1] ="object_type";
								values1[0] = (char *)VehName;
								values1[1] = "Design";

								CALLAPI(ITEM_find_items_by_key_attributes(2,attrs1, values1, &n_tags_found1, &tags_found1));
								MEM_free(attrs1);
								MEM_free(values1);

						//	CALLAPI(ITEM_find_item(VehName, &parent_master))
							printf( "\n parent_master found...........\n"); fflush(stdout);

							printf( "\n parent master count %d\n",n_tags_found1); fflush(stdout);

							//if(parent_master !=NULLTAG)
							if (n_tags_found1 == 1)
							{
								parent_master = tags_found1[0];
								CALLAPI(ITEM_list_bom_views(parent_master,&bv_count, &bvs))
								printf( "\n bv_count :%d..\n",bv_count); fflush(stdout);
								CALLAPI ( ITEM_ask_latest_rev( parent_master, &VCrev ));
								CALLAPI (WSOM_ask_release_status_list(VCrev,&status_count,&status_list));

								 if (status_count > 0)  /* No Status, so the Item is not yet Released */
									{
											for(ss=0; ss<status_count ; ss++)
											{
													CALLAPI(AOM_ask_value_string(status_list[0],"object_name",&CurrentRelStatus));
													printf("\n CurrentRelStatus: %s",CurrentRelStatus);fflush(stdout);
													if((tc_strstr(CurrentRelStatus,"ERC Released")==NULL) || (tc_strstr(CurrentRelStatus,"T5_LcsErcRlzd")==NULL) )
													{
														
														CALLAPI(ITEM_copy_rev(VCrev,NULL,&RevNewSeqTag));
                                                        //t5removeAllReleaseStatus (RevNewSeqTag);
														CALLAPI(UpdateAllowForm(RevNewSeqTag,"Y"));
														CALLAPI(AssignProject(RevNewSeqTag,itemId1234));

														CALLAPI(AOM_lock( RevNewSeqTag ));
														CALLAPI ( AOM_set_value_string(RevNewSeqTag,"t5_PartStatus",DMLDRstatus));
														CALLAPI ( AOM_set_value_string(RevNewSeqTag, "object_desc", objectdesc));
																		CALLAPI(AOM_save( RevNewSeqTag) )
																		CALLAPI(AOM_refresh(RevNewSeqTag,1));
																		CALLAPI(AOM_unlock(RevNewSeqTag));
														
														
														//CALLAPI (CR_create_release_status("T5_LcsWorking",&status2));
																	//printf("\n release status find.");fflush(stdout);
																	//CALLAPI(EPM_add_release_status(status2,1,&RevNewSeqTag,retain));
													   
													
       													if (bv_count)
														{
															bv = bvs[0];
															MEM_free(bvs);
														}else
														{
															CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master,&bv ));
															CALLAPI(AOM_save( bv ))
															CALLAPI( AOM_save( parent_master ))
															CALLAPI( AOM_unlock( parent_master ))
															printf(  "\n inside PS_create_bom_view..\n"); fflush(stdout);				
														}
														
														
														fprintf( stderr, "\n ITEM_ask_latest_rev.........\n");

														CALLAPI ( VOO_show_wso( RevNewSeqTag ) )
														CALLAPI(ITEM_rev_list_bom_view_revs(RevNewSeqTag,&bvr_count, &bvrs))
														printf(  "\n bvr_count of Rev :%d..\n",bvr_count); fflush(stdout);
														if (bvr_count)

														{
															bvr = bvrs[0];
															 CALLAPI(AOM_lock( bvr ));


															CALLAPI(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));

													//		 for (iy = 0; iy<n_occs; iy++)
													//		{
																
													//			CALLAPI(PS_delete_occurrence( bvr, occsal[iy] ));
													//		}

													CALLAPI(POM_class_of_instance (bvr,&class_idr));
													CALLAPI(POM_unload_instances (1,&bvr));
																CALLAPI(POM_load_instances(1,&bvr,class_idr,1));
																CALLAPI(POM_is_loaded(bvr,&log1));
																if(log1 == 1)
																{
																		 printf(" Load Success\n " );
																}
																else
																printf("Load Failure\n"  );

													   CALLAPI(POM_referencers_of_instance(bvr, 1,POM_in_db_only,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
//fprintf(fptr2,"\n Found....n_instances. FOR ITEM REVISION.......Guruji.........:%d\n",n_instances);
															for(iy=0;iy<n_instances;iy++)
															{
															CALLAPI(POM_class_of_instance (ref_instances[iy],&class_id));

															CALLAPI(POM_name_of_class (class_id,&class_name));

															 


															if(strcmp(class_name,"PSOccurrence")==0 )
																{

																CALLAPI (POM_attr_id_of_attr("t5_CurrentViewMaskC", "PSOccurrence", &attr_idDR));
																CALLAPI (POM_ask_attr_string(ref_instances[iy] , attr_idDR, &spcPrefName, &lNull, &lEmpty));

																if (lNull == 0)
																	
																{
																	printf(" \n CarViewMask %s %d\n ",spcPrefName,lNull); fflush(stdout);
																//printf(" \n CarViewMask %s \n ",spcPrefName); fflush(stdout);

																if(strcmp(spcPrefName,"-12")==0 )
																{

																	printf(" \n skiping for car mask indexx %s \n ",spcPrefName); fflush(stdout);

																	//CALLAPI(POM_delete_instances(1,ref_instances)); fflush(stdout);
																}
																else
																	{
																	 	ref_instancesTemp = malloc( sizeof(1) );
																	ref_instancesTemp[0]=ref_instances[iy];
																	 CALLAPI(POM_delete_instances(1,ref_instancesTemp)); 
																	 ref_instancesTemp = NULL; 
																	}
																}
																	
																		else

																	{
																	ref_instancesTemp = malloc( sizeof(1) );
																	ref_instancesTemp[0]=ref_instances[iy];
																	 CALLAPI(POM_delete_instances(1,ref_instancesTemp)); 
																	 ref_instancesTemp = NULL;
																	}

															}
															}
//															CALLAPI(PS_create_bvr( bv, "", "", false, RevNewSeqTag,&bvr) )
//																if(bvr !=NULLTAG)
//															{							
//																CALLAPI( AOM_save( bvr) )
//																CALLAPI (AOM_save( RevNewSeqTag ))
//																CALLAPI( AOM_unlock( RevNewSeqTag ))
//																fprintf( stderr, "\n inside  PS_create_bvr..\n");
//															}
															MEM_free(bvrs);
														}else
														{
															CALLAPI(PS_create_bvr( bv, "", "", false, RevNewSeqTag,&bvr) )
															if(bvr !=NULLTAG)
															{							
																CALLAPI( AOM_save( bvr) )
																CALLAPI (AOM_save( RevNewSeqTag ))
																CALLAPI( AOM_unlock( RevNewSeqTag ))
																printf(  "\n inside  PS_create_bvr..\n"); fflush(stdout);
															}
														}
														printf( "\n After PS_create_bvr..\n"); fflush(stdout);
														 CALLAPI(POM_save_instances(1,&bvr,FALSE));
														 CALLAPI(AOM_unlock(bvr));

														 //CALLAPI(POM_refresh_instances(1,&bvr,class_idr,2));

														break;
													 }
													 else
														{ 

														 CALLAPI(ITEM_rev_list_bom_view_revs(VCrev,&bvr_count, &bvrs))
															  //t5removeAllReleaseStatus (VCrev);
                                                         CALLAPI(UpdateAllowForm(VCrev,"Y"));
														CALLAPI(AssignProject(VCrev,itemId1234));
															 //CALLAPI (CR_create_release_status("T5_LcsWorking",&status2));
															//		printf("\n release status find.");fflush(stdout);
															//		CALLAPI(EPM_add_release_status(status2,1,&VCrev,retain));
														printf( "\n bvr_count of Rev :%d..\n",bvr_count); fflush(stdout);
														if (bvr_count)

														{
															bvr = bvrs[0];
															 CALLAPI(AOM_lock( bvr ));

/*
															CALLAPI(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));

															 for (iy = 0; iy<n_occs; iy++)
															{
																
																CALLAPI(PS_delete_occurrence( bvr, occsal[iy] ));
															}
//															*/
															CALLAPI(POM_class_of_instance (bvr,&class_idr));
															 CALLAPI(POM_unload_instances (1,&bvr));
																CALLAPI(POM_load_instances(1,&bvr,class_idr,1));
																CALLAPI(POM_is_loaded(bvr,&log1));
																if(log1 == 1)
																{
																		 printf(" Load Success\n " );
																}
																else
																printf("Load Failure\n"  );

                                                       CALLAPI(POM_referencers_of_instance(bvr, 1,POM_in_db_only,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
//fprintf(fptr2,"\n Found....n_instances. FOR ITEM REVISION.......Guruji.........:%d\n",n_instances);
															for(iy=0;iy<n_instances;iy++)
															{
															CALLAPI(POM_class_of_instance (ref_instances[iy],&class_id));

															CALLAPI(POM_name_of_class (class_id,&class_name));

															if(strcmp(class_name,"PSOccurrence")==0 )
																{

																CALLAPI (POM_attr_id_of_attr("t5_CurrentViewMaskC", "PSOccurrence", &attr_idDR));
																CALLAPI (POM_ask_attr_string(ref_instances[iy] , attr_idDR, &spcPrefName, &lNull, &lEmpty));
																if (lNull == 0)
																	
																{
																	printf(" \n CarViewMask %s %d\n ",spcPrefName,lNull); fflush(stdout);
																//printf(" \n CarViewMask %s \n ",spcPrefName); fflush(stdout);

																if(strcmp(spcPrefName,"-12")==0 )
																{

																	printf(" \n skiping for car mask indexx %s \n ",spcPrefName); fflush(stdout);

																	//CALLAPI(POM_delete_instances(1,ref_instances)); fflush(stdout);
																}
																else
																	{
																	ref_instancesTemp = malloc( sizeof(1) );
																	ref_instancesTemp[0]=ref_instances[iy];
																	 CALLAPI(POM_delete_instances(1,ref_instancesTemp)); 
																	 ref_instancesTemp = NULL;
																	}
																}
																	
																		else

																	{
																		ref_instancesTemp = malloc( sizeof(1) );
																	ref_instancesTemp[0]=ref_instances[iy];
																		CALLAPI(POM_delete_instances(1,ref_instancesTemp)); 
																		ref_instancesTemp = NULL;
																	}

															}
															}


															MEM_free(bvrs);
														}else
														{
															CALLAPI(PS_create_bvr( bv, "", "", false, VCrev,&bvr) )
															if(bvr !=NULLTAG)
															{							
																CALLAPI( AOM_save( bvr) )
																CALLAPI (AOM_save( VCrev ))
																CALLAPI( AOM_unlock( VCrev ))
																printf(  "\n inside  PS_create_bvr..\n"); fflush(stdout);
															}
														}

														 CALLAPI(POM_save_instances(1,&bvr,FALSE));
														 CALLAPI(AOM_unlock(bvr));

														 //CALLAPI(POM_refresh_instances(1,&bvr,class_idr,2));
														// printf("\n\t Released VC not found loop..........");fflush(stdout);
														// EMH_store_error_s1(EMH_severity_warning,ITK_errStore1,"Released VC with same name as that of SVR not present in TCUA. please get released VC loaded from TCE");	
														//	return ITK_errStore1;
														break;

														}
																	}
															}
													}
													 else
														{ 


														 TCTYPE_find_type("Design Revision", NULL, &rev_type_tag);
															if(rev_type_tag)
															{
																	printf("\n rev_type_tag Tag Found."); fflush(stdout);
															}
															TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
															AOM_set_value_string(rev_create_input_tag, "object_name", VehName);
															AOM_set_value_string(rev_create_input_tag, "object_desc", objectdesc);
															AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1");
															CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_ProjectCode", itemId1234)); 
															CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_DesignGrp", "00"));       
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartType","V"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DocRemarks","NA"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_MThickness","NA"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnDept","Pune-Design"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnOwn","PROPUN"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_ColourInd","Y"));         
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PrtCatCode","VEHICLE"));   
															CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartStatus",DMLDRstatus));
															/* Construct a CreateInput object for Item */
															TCTYPE_find_type("Design", NULL, &item_type_tag);
															if(item_type_tag)
															{
																	printf("\n item_type_tag Tag Found."); fflush(stdout);
															}
															TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

															AOM_set_value_string(item_create_input_tag, "item_id", VehName);
															AOM_set_value_string(item_create_input_tag, "object_name", VehName);
															AOM_set_value_string(item_create_input_tag, "object_desc", objectdesc);
															AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

															//Create Design Object and Design Revision
															TCTYPE_create_object(item_create_input_tag, &parent_master);
															if(parent_master)
															{
																	printf("\n Design Revision created."); fflush(stdout);
																		 
																	AOM_save(parent_master);
																	
																	
																	
																   // *item1 = item;
															}

															CALLAPI ( ITEM_ask_latest_rev( parent_master, &ItemRev1 ));
																	 CALLAPI(AOM_lock(parent_master));
																	 CALLAPI(AOM_lock(ItemRev1));
																	
																	  CALLAPI(AOM_save(ItemRev1));
																	  CALLAPI(AOM_unlock(ItemRev1));
																	  AOM_unlock(parent_master);

																	   // t5removeAllReleaseStatus (ItemRev1);
																	   CALLAPI(UpdateAllowForm(ItemRev1,"Y"));
																	CALLAPI(AssignProject(ItemRev1,itemId1234));

																	//  CALLAPI (CR_create_release_status("T5_LcsWorking",&status2));
																	//printf("\n release status find.");fflush(stdout);
																	//CALLAPI(EPM_add_release_status(status2,1,&ItemRev1,retain));

																	CALLAPI(ITEM_list_bom_views(parent_master,&bv_count, &bvs))

																		CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master,&bv ));
																		CALLAPI(AOM_save( bv ))
																		CALLAPI( AOM_save( parent_master ))
																		CALLAPI( AOM_unlock( parent_master ))
																		printf( "\n inside PS_create_bom_view..\n");	 fflush(stdout);

																		CALLAPI(PS_create_bvr( bv, "", "", false, ItemRev1,&bvr) )
																		if(bvr !=NULLTAG)
																		{							
																			CALLAPI( AOM_save( bvr) )
																			CALLAPI (AOM_save( ItemRev1 ))
																			CALLAPI( AOM_unlock( ItemRev1 ))
																			printf(  "\n inside  PS_create_bvr..\n"); fflush(stdout);
																		}
                                                                     if (bvr1)
                                                                     {
                                                                     
																		CALLAPI(AOM_lock( bvr1 ));
																		CALLAPI(PS_create_occurrences( bvr1, ItemRev1, NULLTAG,1, &occs ))
																		//CALLAPI(PS_set_occurrence_qty(bvr1, occs[0], int_qunt));
																		CALLAPI(AOM_save( bvr1) )
																		CALLAPI(AOM_refresh(bvr1,1));
																		CALLAPI(AOM_unlock(bvr1));
																	 }



																	 

														 printf("\n\t VC not found loop..........");fflush(stdout);
													//	 EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"VC with same name as that of SVR not present in TCUA. please get it loaded from TCE or create in TCUA and check-In");	
													//		return ITK_errStore1;

														}

														

							 if(top_line!=NULLTAG)
							 {

								// CALLAPI(BOM_line_unpack(top_line));
								

								 CALLAPI( BOM_line_look_up_attribute ("bl_quantity",&blqu));
								 xform_matrix1=0;
								// CALLAPI( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix1));
								 CALLAPI( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix1));
									CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
									printf("\n LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

									//if(n_lines1 == n_lines)
									//{
										if (n_lines1 >0)
										{
											for (p1=0;p1<n_lines1 ;p1++ )
											{
												if(Childobject4) Childobject4=NULLTAG;
												Childobject4=lines[p1];
												//CALLAPI(BOM_line_unpack(Childobject4));

												CALLAPI(BOM_line_ask_child_lines(Childobject4, &n_lines4, &lines4));

												if (n_lines4 >0)
													{
														for (p4=0;p4<n_lines4 ;p4++ )
														{
															if(Childobject3) Childobject3=NULLTAG;
															Childobject3=lines4[p4];

															

															CALLAPI(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
															CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name2));	  
								
															CALLAPI(AOM_ask_value_string(Childobject3, "bl_item_item_id", &child_item_id ));
															fprintf( stderr, " Last child_item_id ..:%s and type_name2 :%s\n",child_item_id,type_name2);

															CALLAPI(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &child_item_revision_id ));
															fprintf( stderr, " bl_rev_item_revision_id--------------> %s\n",child_item_revision_id);

															CALLAPI(AOM_ask_value_string(Childobject3, "bl_formula", &child_bl_formula ));
															fprintf( stderr, " child_bl_formula 2--------------> %s\n",child_bl_formula);

															printf("\n***********xform_matrix1:%d\n",xform_matrix1);
															CALLAPI(BOM_line_ask_attribute_string(Childobject3, xform_matrix1, &xform_matrix_str));
															printf( " child xform matrix 11--------------> %s\n",xform_matrix_str);fflush(stdout);

															tempmat1=tc_strtok(xform_matrix_str," ");

													for(imat=0;imat<4;imat++)
													{
														for(jmat=0;jmat<4;jmat++)
														{
															if(imat==0 && jmat==0)
															{
																printf("\n inside if"); fflush(stdout);
																mat[imat][jmat]=strtod(tempmat1,NULL);
															}else
															{
																printf("\n inside else"); fflush(stdout);
																tempmat=tc_strtok(NULL," ");
																mat[imat][jmat]=strtod(tempmat,NULL);
															}
														}
													}

															
															CALLAPI(BOM_line_ask_attribute_string(Childobject3, blqu, &blqu_str));

															fprintf( stderr, " child quantity matrix--------------> %s\n",blqu_str);

															int_qunt=atoi(blqu_str);

															fprintf( stderr, " child quantity int-------------> %d\n",int_qunt);

															    //char **attrs3 = (char **) MEM_alloc(2 * sizeof(char *));
															//	char **values3 = (char **) MEM_alloc(2 * sizeof(char *));
																const char *attrs3[2];
																const char *values3[2];

																attrs3[0] ="item_id";
																attrs3[1] ="object_type";
																values3[0] = (char *)child_item_id;
																values3[1] = "Design";
																//ifail = ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found);
																CALLAPI(ITEM_find_item_revs_by_key_attributes(2,attrs3, values3,child_item_revision_id, &n_tags_found3, &tags_found3))
																MEM_free(attrs3);
																MEM_free(values3);

                                                            if (n_tags_found3>0)
                                                            {
                                                            Childrev= tags_found3[0];
															}
															

															//CALLAPI ( ITEM_find_rev( child_item_id, child_item_revision_id, &Childrev ) )
															if(Childrev!=NULLTAG)
															{
																//CALLAPI(POM_load_instances(1,&bvr,class_idr,1));
																CALLAPI(POM_is_loaded(bvr,&log1));
																if(log1 == 1)
																{
																		 printf(" Load Success\n " );
																}
																else
																printf("Load Failure\n"  );
																//CALLAPI ( VOO_show_wso( Childrev ) )
																printf(  " before lock-------------->\n");fflush(stdout);
																 
																CALLAPI(AOM_lock( bvr ));
																
																printf( " after lock--------------> \n");fflush(stdout);
																CALLAPI(PS_create_occurrences( bvr, Childrev, NULLTAG,1, &occs ))
																	printf( " before creating occurrence--------------> \n");fflush(stdout);
																CALLAPI(PS_set_occurrence_qty(bvr, occs[0], int_qunt));

                                                                int_qunt = 0;

//															for(imat=0;imat<3;imat++)
//															{
//																mat[3][imat]=(double)(mat[3][imat]/divInt);
//															}

															for(imat=0;imat<4;imat++)
																{
																	for(jmat=0;jmat<4;jmat++)
																	{
																		printf("%10lf,",mat[imat][jmat]);
																	}
																	printf("\n");
																}

																CALLAPI(PS_set_plmxml_transform(bvr, occs[0], *mat));

																//	CALLAPI(AOM_lock(bvr));
														      printf( " before saving occurrence11--------------> \n");fflush(stdout);
															 // CALLAPI(POM_save_instances(1,&occs[0],1));

																// CALLAPI(POM_refresh_instances(1,&occs[0],class_idr,2));
																 //CALLAPI(AOM_lock( bvr ));
																CALLAPI(AOM_save( bvr) )
																	printf( " after creating occurrence34--------------> \n");fflush(stdout);
																	CALLAPI(AOM_refresh(bvr,1));
																CALLAPI(AOM_unlock(bvr));
															}
														}
												}
											}
										}	
//									else
//									{
//										printf(  " Rules not applied successfully check again:\n"); fflush(stdout);
//
//									}
							 }
//							if (bv)
//							{
//								CALLAPI(AOM_lock(bv));
//							}
//							
//							
//							
//							
//							
//							 
//							 if (bv)
//							{
//								CALLAPI(AOM_save( bv) );
//							}
//							
//							
//						
//							
//							
//
//							if (bv)
//							{
//								 CALLAPI(AOM_unlock(bv));
//							}
//							
							
							
							
							
                                            if (ItemRev1)
										{
							                //t5removeAllReleaseStatus (ItemRev1);
											CALLAPI (CR_create_release_status("T5_LcsReview",&status3));
											printf("\n release status find 1.");fflush(stdout);
											CALLAPI(EPM_add_release_status(status3,1,&ItemRev1,retain));
											CALLAPI(UpdateAllowForm(ItemRev1,"N"));
										}

											if (ItemRev)
										{
                                           // t5removeAllReleaseStatus (ItemRev);
											CALLAPI (CR_create_release_status("T5_LcsReview",&status4));
											printf("\n release status find 2 .");fflush(stdout);
											CALLAPI(EPM_add_release_status(status4,1,&ItemRev,retain));
											CALLAPI(UpdateAllowForm(ItemRev,"N"));
										}

										 if (RevNewSeqTag)
										{
								            //t5removeAllReleaseStatus (RevNewSeqTag);
											ernew=ernew+1;
											CALLAPI (CR_create_release_status("T5_LcsReview",&status3));
											printf("\n release status find 4.");fflush(stdout);
											//CALLAPI(EPM_add_release_status(status3,1,&RevNewSeqTag,retain));
											CALLAPI(UpdateAllowForm(RevNewSeqTag,"N"));
										}

										if (ernew == 0)
										{
											if (VCrev)
												{
							                //t5removeAllReleaseStatus (VCrev);
											CALLAPI (CR_create_release_status("T5_LcsReview",&status3));
											printf("\n release status find 3.");fflush(stdout);
											//CALLAPI(EPM_add_release_status(status3,1,&VCrev,retain));
											CALLAPI(UpdateAllowForm(VCrev,"N"));
										}
										}		 
							 
							 CALLAPI(BOM_save_window(bom_window))
							 CALLAPI(BOM_close_window(bom_window))
					}
				}


				if(relation_type1 != NULLTAG)
					
				{

					CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type1,&cnt12,&attachments12));
					printf("\n Checkin- impacted items:%d\n",cnt12);fflush(stdout);
					//if (cnt12 == 0)
					//{
						if (RevNewSeqTag)
						{
						
						GRM_find_relation(DMLTag,RevNewSeqTag,relation_type1,&tRelationExist);  
							if (tRelationExist==NULLTAG)
							{
								//###  Creating Relation between DML and Task  ###

								printf("\n Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,RevNewSeqTag,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task)); 
								printf("\nRelation Created Successfully\n");fflush(stdout);							
							}
						}
                       if (ernew == 0)
					{
						 if(VCrev)
						{
							GRM_find_relation(DMLTag,VCrev,relation_type1,&tRelationExist1);  
							if (tRelationExist1==NULLTAG)
							{
								//###  Creating Relation between DML and Task  ###

								printf("\n Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,VCrev,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task)); 
								printf("\nRelation Created Successfully\n");fflush(stdout);							
							}

						}
					}
						if(ItemRev1)
						{
							GRM_find_relation(DMLTag,ItemRev1,relation_type1,&tRelationExist2);  
							if (tRelationExist2==NULLTAG)
							{
								//###  Creating Relation between DML and Task  ###

								printf("\n Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,ItemRev1,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task)); 
								printf("\nRelation Created Successfully\n");fflush(stdout);							
							}
						}

						if(ItemRev)
						{
							GRM_find_relation(DMLTag,ItemRev,relation_type1,&tRelationExist3);  
							if (tRelationExist3==NULLTAG)
							{
								//###  Creating Relation between DML and Task  ###

								printf("\n Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,ItemRev,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task)); 
								printf("\nRelation Created Successfully\n");fflush(stdout);							
							}
						}
/*
						GRM_find_relation(DMLTag,parent_master1,relation_type1,&tRelationExist4);  
							if (tRelationExist4==NULLTAG)
							{
								//###  Creating Relation between DML and Task  ###

								printf("\n Now Creating Relation Between DML Task and VC Object 11\n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,parent_master1,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task)); 
								printf("\nRelation Created Successfully\n");fflush(stdout);							
							}
			*/
					//}
//					else
//					{
//						 EMH_store_error_s1(EMH_severity_error,ITK_errStore2,"Solution Items of DML Task already contains the object. please get it cleared first");	
//						 return ITK_errStore2;
//					}
//				
	               
				   


					// end
				}
		return ITK_ok;
	}
}
  



extern int vc_release_register_method(int *decision, va_list args)
{
   

    int ifail=0;
    *decision = ALL_CUSTOMIZATIONS;
	tag_t objTag = va_arg(args, tag_t);

   

  
   if( ITK_ok == EPM_register_action_handler("vc_release", "", vc_release))
   {
		printf("\t\n Registered Action Handler vc_release_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler vc_release_register_method\n");fflush(stdout);
   }

    if( ITK_ok == EPM_register_action_handler("bom_complete", "", bom_complete))
   {
		printf("\t\n Registered Action Handler bom_complete_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler bom_complete_register_method\n");fflush(stdout);
   }
   
   if( ITK_ok ==  EPM_register_rule_handler ("ECUCount_Valid16RTPL","Compare_ecu_count16RTPL", (EPM_rule_handler_t) ECUCount_Valid16RTPL))
   {
		printf("\t\n Registered rule  Handler ECUCount_Valid16RTPL\n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register rule Handler ECUCount_Valid16RTPL\n");fflush(stdout);
   }

	
   /***************************delete_msg*****************************************/
   

   /***************************end*****************************************/
   
   return ITK_ok;
}

extern DLLAPI int vc_release_register_callbacks()
{     
	 CUSTOM_register_exit("vc_release", "USER_init_module", (CUSTOM_EXIT_ftn_t) vc_release_register_method);

     printf("\n registered function erc_dml_assign\n");	fflush(stdout);

	 return ( ITK_ok );
}

static void handle_itk_error
    ( int stat,                           /* <I> */
      int source_code_line,               /* <I> */
      const char *source_code_file_name   /* <I> */
    )
{
    if ( VOO_debug )
    {
        int          n_ifails=0;
        const int   *severities=NULL;
        const int   *ifails=NULL;
        const char **texts=NULL;
        char        *errstring=NULL;

        fprintf( stderr, "Error detected\n" );
        fflush( stderr);
        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
        if ( n_ifails && texts != NULL )
        {
            if ( ifails[n_ifails-1] == stat )
            {
                fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (texts[n_ifails-1]==NULL?"null":texts[n_ifails-1]) );
            }
            else
            {
                EMH_ask_error_text( stat, &errstring );
                fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (errstring==NULL?"null":errstring) );
                MEM_free( errstring );
            }
        }
        else
        {
            EMH_ask_error_text( stat, &errstring );
            fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (errstring==NULL?"null":errstring) );
            MEM_free( errstring );
        }
        fprintf( stderr, "%s %s: Error: Line %d in %s\n", VOO_prog, VOO_time_stamp(), source_code_line, source_code_file_name );
    }
}

static int VOO_show_wso ( tag_t wso ) {
    int                  stat=ITK_ok;
    tag_t                instance_class=NULLTAG;
    static tag_t         wso_class=NULLTAG;
    static tag_t         ve_class=NULLTAG;
    static int           not_initialized=TRUE;
    logical              is_wso=FALSE;

    // fprintf( stderr, "inside function VOO_show_wso");

	if ( not_initialized ) {
        ITK ( POM_class_id_of_class ( "WorkspaceObject", &wso_class ) );
        ITK ( POM_class_id_of_class ( "VariantExpression", &ve_class ) );
        not_initialized = FALSE;
    }

    if ( NULLTAG == wso ) {
        fprintf( stderr, "VOO_show_wso: Can't show info for a NULLTAG\n" );
        return stat;
    }

    ITK ( POM_class_of_instance ( wso, &instance_class ) );
    ITK ( POM_is_descendant ( wso_class, instance_class, &is_wso ) );
    if ( ! is_wso ) {
        logical is_ve=FALSE;

        ITK ( POM_is_descendant ( ve_class, instance_class, &is_ve ) );
        if ( is_wso ) {
            char *t=NULL;

            ITK ( BOM_variant_expression_as_text( wso, &t ) );
            fprintf( stderr, "%s %s: VariantExpression: %s: ", VOO_prog, VOO_time_stamp(), (NULL==t?"null":t) );
            MEM_free( t );
        }
        else
        {
            char    *class_name=NULL;

            ITK ( POM_name_of_class ( instance_class, &class_name ) );
            fprintf( stderr, "%s", (NULL==class_name?"null":class_name) );
        }
    }
    else
    {
        char              *obj_id=NULL;
        WSO_description_t  wso_desc;

        ITK ( WSOM_describe ( wso, &wso_desc ) );
        ITK ( WSOM_ask_object_id_string ( wso, &obj_id ) );
        if ( stat == ITK_ok ) {
            fprintf( stderr, "obj_id=%s", (NULL==obj_id?"null":obj_id) );
            MEM_free( obj_id );
/*            fprintf( stderr, ", name=%s", wso_desc.object_name );                             */
/*            fprintf( stderr, ", description=%s", wso_desc.description );                      */
            fprintf( stderr, ", type=%s", wso_desc.object_type );

        }
    }
    fprintf( stderr, "\n" );
    return stat;
}

static char *VOO_time_stamp()
{
    time_t now;
    static char time_stamp[512];

    time( &now );
    sprintf( time_stamp, "%s", ctime( &now ) );
    time_stamp[tc_strlen(time_stamp)-1] = '\0'; /* strip off new line */
    return time_stamp;
}

static int VOO_list_saved_variant_rules
    ( tag_t    itemRev,
      int *    n_variant_rules,
      tag_t ** variant_rules
    )
{
    int         n_secondaries=0;
    tag_t      *secondaries=NULL;
    int         stat=ITK_ok;

    *variant_rules = NULL;
    *n_variant_rules = 0;

	//   fprintf( stderr, "inside functionss VOO_list_saved_variant_rules" );

    ITK ( GRM_list_secondary_objects_only( itemRev, NULLTAG, &n_secondaries, &secondaries ) )
	
//	fprintf( stderr, "n_secondaries :%d" ,n_secondaries	);

    /*  Collect together all the variant_rules */

    if ( n_secondaries )
    {
        *variant_rules = (tag_t *)MEM_alloc( n_secondaries * sizeof ( tag_t ) );
        if ( NULL == variant_rules )
        {
            ITK ( SS_NOMEM )
        }
        else
        {
            int inx;
            tag_t varRuleClass=NULLTAG;

            ITK ( POM_class_id_of_class ( "VariantRule", &varRuleClass ) )
            for ( inx = 0; inx < n_secondaries; inx++ )
            {
                tag_t   classId=NULLTAG;
                logical isVRule=FALSE;

                ITK ( POM_class_of_instance( secondaries[inx], &classId ) )
                ITK ( POM_is_descendant( varRuleClass, classId, &isVRule ) )
                if ( isVRule )
                {
                    (*variant_rules)[(*n_variant_rules)++] = secondaries[inx];
                }
            }
        }
    }
    MEM_free( secondaries );
    return stat;
}

static logical VOO_option_value_hash
    ( int       hash_size,               /* <I> */
      vector_t *hash[],                  /* <I> */
      tag_t     option_rev,              /* <I> */
      int       option_rev_value_index,  /* <I> */
      int       add_if_new               /* <I> */
    )
{
    logical was_new=TRUE;
    int     key;
    int     inx;
    tag_t * hashed_option_rev=NULL;
    int   * hashed_option_rev_value_index=NULL;

    if ( option_rev != NULLTAG )
    {
        key = option_rev % hash_size;
        if ( NULL != hash[key] )
        {
            for ( inx=vector_size( hash[key] )-2; inx>=0; inx-=2 )
            {
                hashed_option_rev             = (tag_t *)vector_get( hash[key], inx );
                hashed_option_rev_value_index = (int *)  vector_get( hash[key], inx+1 );
                if ( *hashed_option_rev == option_rev && *hashed_option_rev_value_index == option_rev_value_index )
                {
                    was_new = FALSE;
                    break;
                }
            }
        }
        if ( was_new && add_if_new )
        {
            if ( NULL == hash[key] )
                hash[key] = vector_new( 10, 10 );
            if ( (hashed_option_rev = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_option_rev = option_rev;
            if ( (hashed_option_rev_value_index = (int *)MEM_alloc( sizeof ( int ) )) != NULL )
                *hashed_option_rev_value_index = option_rev_value_index;
            hash[key] = vector_add( hash[key], hashed_option_rev );
            hash[key] = vector_add( hash[key], hashed_option_rev_value_index );
        }
    }
    else /* flush hash table */
    {
        for ( key=0; key<hash_size; key++ )
        {
            if ( NULL != hash[key] )
            {
                for ( inx=vector_size( hash[key] )-1; inx>=0; inx-- )
                    MEM_free( vector_get( hash[key], inx ) );
                hash[key] = vector_free( hash[key] );
            }
        }
    }
    return !was_new;
}

static int VOO_variant_expression
    ( tag_t        v1,               /* <I> */
      int          op,               /* <I> */
      tag_t        v2,               /* <I> */
      const char * text,             /* <I> */
      tag_t      * ve,               /* <O> */
      logical    * was_new           /* <O> */
    )
{
    static variant_rule_option_data_t expression_hash={NULL};

    return VOO_expression_hash( VOO_HASH_SIZE, expression_hash, v1, op, v2, text, TRUE, ve, was_new );
}

static int VOO_expression_hash
    ( int          hash_size,            /* <I> */
      vector_t   * hash[],               /* <I> */
      tag_t        val1,                 /* <I> */
      int          oper,                 /* <I> */
      tag_t        val2,                 /* <I> */
      const char * text,                 /* <I> */
      logical      add_if_new,           /* <I> */
      tag_t      * var_exp,              /* <O> */
      logical    * was_new               /* <O> */
    )
{
    int     stat=ITK_ok;
    int     key;
    int     inx;
    tag_t * hashed_val1=NULL;
    int   * hashed_oper=NULL;
    tag_t * hashed_val2=NULL;
    char  * hashed_text=NULL;
    tag_t * hashed_var_exp=NULL;

    *was_new = TRUE;
    if ( val1 != NULLTAG )
    {
        key = (val1+val2) % hash_size;
        if ( NULL != hash[key] )
        {
            for ( inx=vector_size( hash[key] )-5; inx>=0; inx-=5 )
            {
                hashed_val1 = (tag_t *)vector_get( hash[key], inx );
                hashed_oper = (int *)  vector_get( hash[key], inx+1 );
                hashed_val2 = (tag_t *)vector_get( hash[key], inx+2 );
                hashed_text = (char *) vector_get( hash[key], inx+3 );
                if ( *hashed_val1 == val1 &&
                     *hashed_oper == oper &&
                     *hashed_val2 == val2 &&
                     0 == tc_strcmp( hashed_text, text ) )
                {
                    hashed_var_exp = (tag_t *)vector_get( hash[key], inx+4 );
                    *was_new = FALSE;
                    break;
                }
            }
        }
        if ( *was_new && add_if_new )
        {
            if ( NULL == hash[key] )
                hash[key] = vector_new( 50, 50 );
            if ( (hashed_val1 = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_val1 = val1;
            if ( (hashed_oper = (int *)MEM_alloc( sizeof ( int ) )) != NULL )
                *hashed_oper = oper;
            if ( (hashed_val2 = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_val2 = val2;
            if ( NULL == text )
                hashed_text = NULL;
            else
                hashed_text = MEM_string_copy( text );
            if ( (hashed_var_exp = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                ITK ( BOM_new_variant_expression( val1, oper, val2, text, hashed_var_exp ) )
            hash[key] = vector_add( hash[key], hashed_val1 );
            hash[key] = vector_add( hash[key], hashed_oper );
            hash[key] = vector_add( hash[key], hashed_val2 );
            hash[key] = vector_add( hash[key], hashed_text );
            hash[key] = vector_add( hash[key], hashed_var_exp );
        }
    }
    else /* flush hash table */
    {
        for ( key=0; key<hash_size; key++ )
        {
            if ( NULL != hash[key] )
            {
                for ( inx=vector_size( hash[key] )-1; inx>=0; inx-- )
                    MEM_free( vector_get( hash[key], inx ) );
                hash[key] = vector_free( hash[key] );
            }
        }
    }
    *var_exp = (hashed_var_exp==NULL?NULLTAG:*hashed_var_exp);
    if ( VOO_debug )
    {
        char *t=NULL;

        ITK ( BOM_variant_expression_as_text( *var_exp, &t ) )
        fprintf( stderr, "%s %s: %s variant expression %s\n", VOO_prog, VOO_time_stamp(), (*was_new?"new":"re-using"), (NULL==t?"null":t) );
        MEM_free( t );
    }
    return stat;
}

/*==================================================================================================
      vector stuff
==================================================================================================*/
/**********************************************************************************
 * Function:          vector_new
 *
 * Purpose:           allocates new vector, inital capacity=`capacity'
 *
 * Description:       returns a pointer to a dynamically allocated vector or
 *                    NULL if no memory can be allocated. On success, the
 *                    vector has a initial capacity of `capacity' and will
 *                    grow in steps of `increment'.
 *
 * Parameters:        int capacity;    initial capacity
 *                    int increment;    incremental growth rate when needed
 *
 * Example:           v = vector_new ( 100, 10 );
 *
 * Return Value:      pointer to a dynamically allocated vector
 *                    NULL if no memory can be allocated
 *
 *********************************************************************************/
static vector_t *vector_new ( int capacity, int increment )
{
    vector_t *vector;

    vector = (vector_t *)MEM_alloc( sizeof ( vector_t ) );
    if ( vector == NULL ) {
        return NULL;
    }
    vector->size = 0;
    vector->capacity = capacity;
    vector->increment = increment;
    vector->content = (void **)MEM_alloc( capacity * sizeof ( void * ) );
    if ( vector->content == NULL ) {
        MEM_free( vector );
        return NULL;
    }
    return vector;
}

/***********************************************************************************
 * Function:          vector_add
 *
 * Purpose:           appaends one pointer at the end of the vector
 *
 * Description:       convenient form of vector_add_n(), calls vector_add_n().
 *
 * Parameters:        vector_t *in;    vector to which the element is added
 *                    void *element;    pointer to the element to be added
 *
 * Example:           v = vector_add ( v, "line 1" );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_add ( vector_t *in, void *element )
{
    return vector_add_n ( in, 1, &element );
}

/***********************************************************************************
 * Function:          vector_add_n
 *
 * Purpose:           appaends n pointers at the end of the vector
 *
 * Description:       extend vector `in' if necessary and append n pointers
 *                    to the (possibly reallocated) vector `in'.
 *
 * Parameters:        vector_t *in;        vector to which the element is added
 *                    int n;                number of elements to append
 *                    void *elements[];    array of pointers to elements to add
 *
 * Example:           v = vector_add_n ( v, argc, (void **)argv );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_add_n ( vector_t *in, int n, void *elements[] )
{
    vector_t *out;

    out = vector_ensure_capacity ( in, n );
    if ( out == NULL ) {
        return NULL;
    }
    memcpy ( &out->content[out->size], elements, n * sizeof ( void * ) );
    out->size += n;
    out->capacity -= n;
    return out;
}

/***********************************************************************************
 * Function:          vector_rem_at
 *
 * Purpose:           removes 1 pointer at position `at'
 *
 * Description:       convenient form of vector_rem_n_at, calls vector_rem_n_at()
 *
 * Parameters:        vector_t *in;        vector of which the element is removed
 *                    int at;                position of the element to be removed
 *
 * Example:           v = vector_add_n ( v, 0 );
 *
 * Return Value:      0     if `at' is within bounds [0,`size')
 *                    2     if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static int vector_rem_at ( vector_t *in, int at )
{
    return vector_rem_n_at ( in, 1, at );
}

/***********************************************************************************
 * Function:          vector_rem_n_at
 *
 * Purpose:           removes n pointers from position `at' on
 *
 * Description:       removes `n' pointers beginning at position `at'. Elements
 *                    beyond position `n'+`at' are block moved upward so that
 *                    their sequence is not changed.
 *
 * Parameters:        vector_t *in;        vector of which the elements are removed
 *                    int n;                number of elements to remove
 *                    int at;                position of 1st element to remove
 *
 * Example:           v = vector_add_n ( v, 1, 0 );
 *
 * Return Value:      0   if `at' is within bounds [0,`size')
 *                    2   if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static int vector_rem_n_at ( vector_t *in, int n, int at )
{
    int ret;

    if ( at + n <= in->size ) {
        int i;

        for ( i=at; i<in->size - n; i++ ) {
            in->content[i] = in->content[i+n];
        }
        in->size -= n;
        in->capacity += n;
        ret = 0;
    }
    else {
        fprintf( stderr, "vector_rem_n_at: cannot remove %d elements from position %d in a vector of %d elements\n",
                    n, at, in->size );
        ret = 2;
    }
    return ret;
}

/***********************************************************************************
 * Function:          vector_insert
 *
 * Purpose:           inserts 1 pointer at position 0
 *
 * Description:       inserts 1 pointer at position 0
 *
 * Parameters:        vector_t *in;        vector the elements are to be inserted in
 *                    void *elements;      element to insert
 *
 * Example:           v = vector_insert ( v, (void *)argv[1] );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_insert ( vector_t *in, void *element )
{
    return vector_insert_n_at ( in, 1, &element, 0 );
}

/***********************************************************************************
 * Function:          vector_insert_n_at
 *
 * Purpose:           inserts `n' pointers at position `at'.
 *
 * Description:       inserts `n' pointers at position `at'.
 *
 * Parameters:        vector_t *in;        vector the elements are to be inserted in
 *                    int n;               number of elements to insert
 *                    void *elements[];    elements to insert
 *                    int at;              position of 1st element to insert
 *
 * Example:           v = vector_add_n ( v, argc, (void **)argv, 0 );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_insert_n_at ( vector_t *in, int n, void *elements[], int at )
{
    vector_t *out;

    if ( at <= in->size ) {
        int i;

        out = vector_ensure_capacity ( in, n );
        for ( i=in->size-1; i>=at; i-- ) {
            out->content[i+n] = out->content[i];
        }
        for ( i=0; i<n; i++ ) {
            out->content[i+at] = elements[i];
        }
        out->size += n;
        out->capacity -= n;
    }
    else {
        fprintf( stderr, "vector_rem_n_at: cannot add %d elements from position %d in a vector of %d elements\n",
                    n, at, in->size );
        out = in;
    }
    return out;
}

/***********************************************************************************
 * Function:          vector_ensure_capacity
 *
 * Purpose:           ensures capacity for `n' more elements
 *
 * Description:       If the current capacity does not allow for `n' more elements
 *                    the vector is reallocated with the minimum amount of more
 *                    memory to allow for `n' more elements.
 *
 * Parameters:        vector_t *in;        vector of which the elements are removed
 *                    int n;                number of elements to remove
 *                    int at;                position of 1st element to remove
 *
 * Example:           v = vector_ensure_capacity( v, 5 );
 *
 * Return Value:      0   if `at' is within bounds [0,`size')
 *                    2   if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static vector_t *vector_ensure_capacity ( vector_t *in, int n )
{
    vector_t *out;

    if ( in->capacity < n ) {
        n = ( n + in->increment - 1 ) / in->increment;
        out = vector_new ( in->size + ( n * in->increment ), in->increment );
        if ( out == NULL ) {
            return NULL;
        }
        out->size = in->size;
        out->capacity = n * in->increment;
        memcpy ( out->content, in->content, in->size * sizeof ( void * ) );
        vector_free ( in );
    }
    else {
        out = in;
    }
    return out;
}

/***********************************************************************************
 * Function:          vector_get
 *
 * Purpose:           returns element at position `index'
 *
 * Description:       returns element at position `index'
 *
 * Parameters:        vector_t *in;        vector of which the elements is returned
 *                    int index;            position of the elements to return
 *
 * Example:           printf ( "Element is: %s\n", (char *)vector_get ( v, 0 ) );
 *
 * Return Value:      pointer to the element at position `index'
 *
 ***********************************************************************************/
static void *vector_get ( const vector_t *in, int index )
{
    return in->content[index];
}

/***********************************************************************************
 * Function:          vector_size
 *
 * Purpose:           returns the current number of stored elements in the vector
 *
 * Description:       returns the current number of stored elements in the vector
 *
 * Parameters:        vector_t *in;        vector of which the size is returned
 *
 * Example:           for ( i=0; i<vector_size ( v ); i++ ) ;
 *
 * Return Value:      current number of stored elements in the vector
 *
 ***********************************************************************************/
static int vector_size ( const vector_t *in )
{
    return in->size;
}

/***********************************************************************************
 * Function:          vector_free
 *
 * Purpose:           frees memory of a vector (does not free the elements!)
 *
 * Description:       frees all dynamically allocated memory in structure
 *                    vector_t for the vector `in'. This does not free the
 *                    memory for the elements for which this vector held
 *                    pointers!
 *
 * Parameters:        vector_t *in;        vector to be freed
 *
 * Example:           v = vector_free ( v );
 *
 * Return Value:      NULL
 *
 ***********************************************************************************/
static vector_t *vector_free ( vector_t *in )
{
    if ( in != NULL )
    {
        MEM_free( in->content );
        MEM_free( in );
    }
    return NULL;
}

int ChkFrstLvlModuleDRstus(char* p_child_item_id, int DMLSTVALUT)
{
	int cr =0;
	int crr =0;
	int DROKFlag =0;
	int n_tags_found2 =0;
	int PRTSTVALU =0;
	int Child_Rev_count =0;
	int Chld_Rel_Stus_Cunt =0;
	tag_t	Child_All_Rev		= NULLTAG;
	tag_t*	Child_rev_list		= NULLTAG;
	tag_t*	Child_status_lst	= NULLTAG;
	tag_t*	tags_found2	= NULLTAG;
	char*	 Chld_Rel_Stus = NULL;
	char*	 Child_Prt_DR = NULL;
	char*	 Child_rev_idd = NULL;
	char*	 PRTDRStr = NULL;

	//GETTING RELEASED REVISION

	    //char **attrs2 = (char **) MEM_alloc(2 * sizeof(char *));
        //char **values2 = (char **) MEM_alloc(2 * sizeof(char *));
		const char *attrs2[2];
		const char *values2[2];

        attrs2[0] ="item_id";
        attrs2[1] ="object_type";
        values2[0] = (char *)p_child_item_id;
        values2[1] = "Design";
        if ( ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
        MEM_free(attrs2);
        MEM_free(values2);

   if (n_tags_found2 == 1)
	{

	   Child_All_Rev=tags_found2[0];
	}

	//if(ITEM_find_item (p_child_item_id, &Child_All_Rev)!=ITK_ok)PrintErrorStack();
	if(ITEM_list_all_revs (Child_All_Rev, &Child_Rev_count, &Child_rev_list)!=ITK_ok)PrintErrorStack();
	printf("\n DR:Total Child rev found: %d, DMLSTVALUT:%d", Child_Rev_count,DMLSTVALUT);fflush(stdout);
	if(Child_Rev_count > 0)
	{
		cr=0;
		DROKFlag=0;
		for(cr=Child_Rev_count-1;cr>=0;cr--)
		{
			Chld_Rel_Stus_Cunt=0;
			DROKFlag=0;
			Child_rev_idd=NULL;
			if(AOM_UIF_ask_value (Child_rev_list[cr], "item_revision_id", &Child_rev_idd)!=ITK_ok)PrintErrorStack();
			printf("\n DR:Latest released rev is:%s.", Child_rev_idd);fflush(stdout);

			if(WSOM_ask_release_status_list (Child_rev_list[cr], &Chld_Rel_Stus_Cunt, &Child_status_lst)!=ITK_ok)PrintErrorStack();
			printf("\n DR:Chld_Rel_Stus_Cunt is:%d.", Chld_Rel_Stus_Cunt);fflush(stdout);
			if(Chld_Rel_Stus_Cunt > 0)
			{
				crr=0;
				for(crr=0;crr<Chld_Rel_Stus_Cunt;crr++)
				{
					DROKFlag=0;
					if(AOM_ask_value_string (Child_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
					printf("\n DR: Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
					if((tc_strstr(Chld_Rel_Stus,"Released")!=NULL)||(tc_strstr(Chld_Rel_Stus,"Rlzd")!=NULL)||(tc_strstr(Chld_Rel_Stus,"ERC Released")!=NULL) ||(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL))
					{
						DROKFlag=0;
						Child_Prt_DR=NULL;
						if(AOM_ask_value_string(Child_rev_list[cr],"t5_PartStatus",&Child_Prt_DR)!=ITK_ok)PrintErrorStack();
						printf("\n DR:RelStatus:%s  Child_rev_idd:%s DR Status:%s\n", Chld_Rel_Stus, Child_rev_idd,Child_Prt_DR);fflush(stdout);
						PRTDRStr=NULL;
						PRTSTVALU=0;
						PRTDRStr=subString(Child_Prt_DR, 2, 1);
						printf("\n DR:A:PRTDRStr: %s and ",PRTDRStr);fflush(stdout);
						PRTSTVALU=atoi(PRTDRStr);
						printf(":PRTSTVALU: %d",PRTSTVALU);fflush(stdout);
						if (PRTSTVALU >= DMLSTVALUT)
						{
							DROKFlag=1;
							break;
						}
					}
				}
				if (DROKFlag >0)
				{
					break;
				}
			}
		}
		printf("\n DR:DROKFlag: %d",DROKFlag);fflush(stdout);
		if (DROKFlag >0)
		{
			printf("\n DR:Released revison having valid DR-status.:%s ", p_child_item_id);fflush(stdout);
			return 1;
		}
		else
		{
			return 0;
		}
	}

	return 0;	
}
