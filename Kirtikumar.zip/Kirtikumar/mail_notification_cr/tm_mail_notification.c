#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>


#define TC_MAJOR_VERSION 2007

#if TC_MAJOR_VERSION <= 10
#define TC_master_form_rtype IMAN_master_form_rtype
#endif

#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

////CR-FY22-0259: Added on 28-04-2022 By Kirtikumar Thakur
int Mail_Notification( EPM_action_message_t msg )
{

	int count,i = 0;
	tag_t root_task=NULLTAG;
	EPM_decision_t decision= EPM_go;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;

	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
 	char*	CurrentTask				=NULL;	
	char*	parent_name				=NULL; 
	char  	type_name[TCTYPE_name_size_c+1];
	int ifail=0;

	FILE			*output 			= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";


	POM_get_user(&username,&user_tag);
	printf("\n\t Starting for username ANALYST CHECK :%s....\n",username);fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&root_task)); 

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);	

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);fflush(stdout);	 
	if(count>0)
	{

		//For OutPut File
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
		sprintf(outputFile,"/home/uadev/devgroups/Kirtikumar/mail_notification/%s_output.txt",Data);

		output = fopen(outputFile, "a");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
			printf("File opened successfully.\n");
			fprintf(output,"File opened successfully. %s\n","");
		}

	}
	fclose(output);
	return ifail;

}
//This method will retrun complete mailIds of participants

extern int TDM_register_method(int *decision, va_list args)
{
   

   int ifail=0;
   //METHOD_id_t  method1 ;
   METHOD_id_t  method_DesRevRel ;
   METHOD_id_t  method_Fir ;
   *decision = ALL_CUSTOMIZATIONS;
   tag_t objTag = va_arg(args, tag_t); 

   //CR-FY22-0259: Added on 28-04-2022 By Kirtikumar Thakur
   if(ITK_ok ==  EPM_register_action_handler ("TDM_Mail_Notification","Mail notification for close looping", (EPM_action_handler_t) Mail_Notification))
   {
		printf("\t\n Registered action Handler TDM_Mail_Notification\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler TDM_Mail_Notification\n");fflush(stdout);
   }

   
   return ITK_ok;
}
extern DLLAPI int tm_tdm_register_callbacks()
{     
	 CUSTOM_register_exit("tm_mail_notification", "USER_init_module", (CUSTOM_EXIT_ftn_t) TDM_register_method);
     printf("\n registered function tm_tdm\n");	fflush(stdout);

	 return ( ITK_ok );
}
