#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <sa/user.h>	
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <tccore/tctype.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}




char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
char* getMailIDs(int,tag_t*);
char* getCCMailIDs(char*,char*,char*,char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	//time_t 	now;
	//struct 	tm when;
	
	//time(&now);
	//when = *localtime(&now);
	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	//output = fopen(outputFile, "a");
	//if (output == NULL)
	//{
		//printf("ERROR: Cannot open File\n");
		//return -1;
	//}
	//else
	//	{
			//printf("File opened successfully.\n");
		//}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	//remove(outputFile);
	
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	int				i 							= 0;
	int				j 							= 0;
	int				a=0,b=0,c=0,d=0,e=0,f=0,g=0,h=0,k=0;
	int				count 						= 0;
	int				count_status				= 0;
	int				num							= 0;
	int*			state_token;

	FILE		*output 			= NULL;

	tag_t			item_tag					= NULLTAG;
	tag_t			*status_list				= NULL;
	tag_t			*rev_list					= NULL;
	tag_t *			allWorkflow					= NULL;
	tag_t			tp_close_status_tag;
	tag_t			date_released_attr			= NULL;

	
	date_t			workflowEndDate;

	//This is for TR
	tag_t	Patricipant_Type_TR_Manager			= NULLTAG;
	tag_t	Patricipant_Type_TR_ChfEng			= NULLTAG;
	tag_t	Patricipant_Type_TR_VatsRev			= NULLTAG;
	tag_t	Patricipant_Type_TR_GrpHd			= NULLTAG;
	tag_t	Patricipant_Type_TR_ClstrHd			= NULLTAG;
	tag_t	Patricipant_Type_TP_Analyst			= NULLTAG;
	
	// This is for FIR
	tag_t	Patricipant_Type_FIR_Analyst		= NULLTAG;
	tag_t	Patricipant_Type_FIR_Grphd			= NULLTAG;
	tag_t	Patricipant_Type_FIR_ClstrHd		= NULLTAG;
	tag_t	Patricipant_Type_FIR_DeptRev		= NULLTAG;
	
	// This is for Green Report
	tag_t	Patricipant_Type_GR_Analyst			= NULLTAG;
	tag_t	Patricipant_Type_GR_Grphd			= NULLTAG;
	tag_t	Patricipant_Type_GR_ClstrHd			= NULLTAG;
	tag_t	Patricipant_Type_GR_DeptRev			= NULLTAG;


	
	tag_t  ObjTypTag							=NULLTAG;
	
	//This is for TR
	int	    participant_count_TR_Manager		=0;
	int	    participant_count_TR_ChfEng			=0;
	int	    participant_count_TR_VatsRev		=0;
	int	    participant_count_TR_GrpHd			=0;
	int	    participant_count_TR_ClstrHd		=0;
	int	    participant_count_TP_Analyst		=0;

	//This is for FIR
	int	    participant_count_FIR_Analyst		=0;
	int	    participant_count_FIR_Grphd			=0;
	int	    participant_count_FIR_ClstrHd		=0;
	int	    participant_count_FIR_DeptRev		=0;

	//This is for GRN

	int	    participant_count_GR_Analyst		=0;
	int	    participant_count_GR_Grphd			=0;
	int	    participant_count_GR_ClstrHd		=0;
	int	    participant_count_GR_DeptRev		=0;

	int secendaryObjectCount					=0;
	int secendaryObjectCountGrn					=0;



	//This is for TR
	tag_t	*participant_list_TR_Manager        = NULLTAG;
	tag_t	*participant_list_TR_ChfEng			= NULLTAG;
	tag_t	*participant_list_TR_VatsRev		= NULLTAG;
	tag_t	*participant_list_TR_GrpHd			= NULLTAG;
	tag_t	*participant_list_TR_ClstrHd		= NULLTAG;
	tag_t	*participant_list_TP_Analyst		= NULLTAG;

	//This is for FIR
	tag_t	*participant_list_FIR_Analyst       = NULLTAG;
	tag_t	*participant_list_FIR_Grphd			= NULLTAG;
	tag_t	*participant_list_FIR_ClstrHd		= NULLTAG;
	tag_t	*participant_list_FIR_DeptRev		= NULLTAG;


	//This is for GRN
	tag_t	*participant_list_GR_Analyst        = NULLTAG;
	tag_t	*participant_list_GR_Grphd			= NULLTAG;
	tag_t	*participant_list_GR_ClstrHd		= NULLTAG;
	tag_t	*participant_list_GR_DeptRev		= NULLTAG;

	char			ObjTyp[TCTYPE_name_size_c+1];

	char			*status						= NULL;
	char			*object_name				= NULL;
	char			*workflowName				= NULL;
	char			*wfEndDate					= NULL;
	
	char			*rev_id						= NULL;
	//This is for TR
	char	*emailID_TR_Manager					=(char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_TR_ChfEng					= (char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_TR_VatsRev					= (char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_TR_GrpHd					= (char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_TR_ClstrHd					= (char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_TP_Analyst					= (char *) MEM_alloc( 10000 * sizeof(char) );

	//This is for FIR
	char	*emailID_FIR_Analyst				=(char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_FIR_Grphd					= (char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_FIR_ClstrHd				= (char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_FIR_DeptRev				= (char *) MEM_alloc( 10000 * sizeof(char) );

	//This is for GRN
	char	*emailID_GR_Analyst					=(char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_GR_Grphd					= (char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_GR_ClstrHd					= (char *) MEM_alloc( 10000 * sizeof(char) );
	char	*emailID_GR_DeptRev					= (char *) MEM_alloc( 10000 * sizeof(char) );

	char	*CC_MailList						= (char*)MEM_alloc(sizeof(char) * 10000);

	//This is for to get maild IDs from control Object
	int n_entries								= 2;
	int	resultCount;
	char *userEntry[2]			={"Name","Type"};
	char **Value				=(char **) MEM_alloc(100 * sizeof(char *));
	char *file_Path				=NULL;

	//char *userEntry1							= "Name";
	//char *value1								= "TDM_Mail_Notification_Group";
	//char *userEntry2							= "Type";
	//char *value2								= "Control Object";
	//char**  entries								= NULL;
	//char**  values								= NULL;

	tag_t	queryTag;
	tag_t	*mailsTag							= NULLTAG;
	char	*cntrObjName						= NULL;
	char	*mail_ID_1							= NULL;
	char	*mail_ID_2							= NULL;
	char	*mail_ID_3							= NULL;
	char	*mail_ID_4							= NULL;
	char	*mail_ID_5							= NULL;
	char	*mail_ID_6							= NULL;
	char	*mail_ID_7							= NULL;
	char	*mail_ID_8							= NULL;
	char	*mail_ID_9							= NULL;
	char	*mail_ID_10							= NULL;



	// TR Properties
	char* Rq_Domain								=NULL;
	char* BU									=NULL;
	char* TR_id									=NULL;
	char* project_code							=NULL;
	char* proj_desc								=NULL;
	char* wbs_details							=NULL;
	char* dr_status								=NULL;
	char* veh_sys_stage							=NULL;
	char* aggregate								=NULL;
	char* testing_sub_group						=NULL;
	char* inv_type								=NULL;
	char* bacg_history							=NULL;
	

	char* request_dept							=NULL;
	char* fir_name								=NULL;
	char* grn_name								=NULL;
	char* releaseStatus							=NULL;

	char* error_text							=NULL;
	char *person_name							=NULL;
	
	char *fir_object_Name						=NULL; 
	char *grn_object_Name						=NULL;
	char *tr_status_name						=NULL;
	char *object_owner_email					=NULL;
	char *TestRequestNo							=NULL;
	char command[512]							="";
	char inPutFile[512]                         ="";


	tag_t	object_owner						= NULLTAG;
	tag_t	object_owner_person					= NULLTAG;
	tag_t	fir_tag								= NULLTAG;
	tag_t	grn_tag								= NULLTAG;
	tag_t   creator								= NULLTAG;
	tag_t   creator_grp							= NULLTAG;
	

	tag_t fir_relation							=NULLTAG;
	tag_t grn_relation							=NULLTAG;
	
	tag_t *fir_obj_tag							=NULLTAG;
	tag_t *grn_obj_tag							=NULLTAG;
	
	tag_t test_request_tag						=NULLTAG;
	tag_t test_request_rev_tag					=NULLTAG;
	
	
	//const char *shellCMD						=&command;
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
	CHECK_FAIL;

	
	for(i=0;i<count;i++)
	{

			ifail = TCTYPE_ask_object_type(rev_list[i],&ObjTypTag);
			ifail = TCTYPE_ask_name(ObjTypTag,ObjTyp);
			printf("\n Objet Type :---%s\n", ObjTyp);
			//fprintf(output,"ObjectType		%s\n",ObjTyp);
			CHECK_FAIL;

			ifail = AOM_ask_value_string(rev_list[i],"object_string",&object_name);
			printf("\nObject Name :---%s\n", object_name);
			//fprintf(output,"ObjectName		%s\n",object_name);

			ifail = AOM_ask_owner(rev_list[i],&object_owner);
			if(ifail ==ITK_ok){

			} else 
			{
				EMH_ask_error_text(ifail,&error_text);
				printf("\nError %s", error_text);
			}
			ifail = SA_ask_user_person(object_owner,&object_owner_person);
			if(ifail ==ITK_ok){

			} else 
			{
				EMH_ask_error_text(ifail,&error_text);
				printf("\nError %s", error_text);
			}

			
			ifail =SA_ask_person_name2(object_owner_person,&person_name);
			printf("\nPerson Name %s",person_name);
			//fprintf(output,"TR_Creator		%s\n",person_name);

			ifail =SA_ask_person_email_address(object_owner_person,&object_owner_email);
			printf("\nObject Creator's e mail:-- %s\n",object_owner_email);
			//fprintf(output,"Creator Mail		%s\n",object_owner_email);

			ifail = QRY_find2("General...", & queryTag);
			CHECK_FAIL;

			//******************************This is to get mail IDs form Control Object***********************************************************************
			Value[0]="TDM_Mail_Notification_Group";
			Value[1]="Control Object";

			ifail = QRY_execute(queryTag, n_entries, userEntry, Value, & resultCount, &mailsTag);
			if(ifail ==ITK_ok){

			} else 
			{
				EMH_ask_error_text(ifail,&error_text);
				printf("\nError %s", error_text);
			}
			printf("\nNo. of Cnt Obj for -->TDM_Mail_Notification_Group-- %d\n", resultCount);
			//******************************This is to get mail IDs form Control Object Ends***********************************************************************
			ifail = AOM_ask_value_string(mailsTag[0],"object_name",&cntrObjName);
			CHECK_FAIL;
			//File Path, is added in t5_userinfo10:
			///user/ktt920157/mail_notification_cr/
			ifail = AOM_ask_value_string(mailsTag[0],"t5_userinfo10",&file_Path);
			CHECK_FAIL;
			printf("\nFile Path of Shell and OutPut File : %s\n", file_Path);

			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo1",&mail_ID_1);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo2",&mail_ID_2);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo3",&mail_ID_3);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo4",&mail_ID_4);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo5",&mail_ID_5);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo6",&mail_ID_6);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo7",&mail_ID_7);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo8",&mail_ID_8);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo9",&mail_ID_9);
			CHECK_FAIL;


			//Opening File 
			//For OutPut File
			char			Data[100]					= "";
			char			outputFile[200]				= "";
			time_t 	now;
			struct 	tm when;
			time(&now);
			when = *localtime(&now);
			strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);

			//printf("\nData :: %s\n", Data);
			//sprintf(outputFile,"/user/testcmi/devgroups/Kirtikumar/mail_notification_cr/%s_output.txt",Data);
			//printf("\nOUTPUT FILE :: %s\n", outputFile);

			tc_strcat(outputFile,file_Path);
			tc_strcat(outputFile,Data);
			tc_strcat(outputFile,"_output.txt");

			printf("\nAfter Concatination of File path from crontrol object :: %s\n",outputFile);


			output = fopen(outputFile, "a");
			if (output == NULL)
			{
				printf("ERROR: Cannot open File\n");
				return -1;
			}
			else
			{
				printf("File opened successfully.\n");
			}

			//This is for Test Requset
			if ((tc_strcmp(ObjTyp,"T5_TestRqRevision")==0))
			{		
					printf("\n******************** Target Object is :::: Test Request*********************\n");
					//Getting all Participants for TR
					EPM_get_participanttype ("T5_TR_Manager",&Patricipant_Type_TR_Manager);
					EPM_get_participanttype ("T5_TR_ChfEng",&Patricipant_Type_TR_ChfEng);
					EPM_get_participanttype ("T5_TR_VatsRev",&Patricipant_Type_TR_VatsRev);
					EPM_get_participanttype ("T5_TR_GrpHd",&Patricipant_Type_TR_GrpHd);
					EPM_get_participanttype ("T5_TR_ClstrHd",&Patricipant_Type_TR_ClstrHd);
					EPM_get_participanttype ("T5_TR_Analyst",&Patricipant_Type_TP_Analyst);
					CHECK_FAIL;

					//This is to get proper mails of Partticipants
					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_TR_Manager,&participant_count_TR_Manager,&participant_list_TR_Manager);
					printf("\n Number Of participant_count_TR_Manager:---[%d]\n",participant_count_TR_Manager);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_TR_ChfEng,&participant_count_TR_ChfEng,&participant_list_TR_ChfEng);
					printf("\n Number Of participant_count_TR_ChfEng:---[%d]\n",participant_count_TR_ChfEng);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_TR_VatsRev,&participant_count_TR_VatsRev,&participant_list_TR_VatsRev);
					printf("\n Number Of participant_count_TR_VatsRev:---[%d]\n",participant_count_TR_VatsRev);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_TR_GrpHd,&participant_count_TR_GrpHd,&participant_list_TR_GrpHd);
					printf("\n Number Of participant_count_TR_GrpHd:---[%d]\n",participant_count_TR_GrpHd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_TR_ClstrHd,&participant_count_TR_ClstrHd,&participant_list_TR_ClstrHd);
					printf("\n Number Of participant_count_TR_ClstrHd:---[%d]\n",participant_count_TR_ClstrHd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_TP_Analyst,&participant_count_TP_Analyst,&participant_list_TP_Analyst);
					printf("\n Number Of participant_count_TP_Analyst:---[%d]\n",participant_count_TP_Analyst);fflush(stdout);
					CHECK_FAIL;

					//This code is to get respective mail IDs
					//Manager 
					emailID_TR_Manager = getMailIDs(participant_count_TR_Manager,participant_list_TR_Manager);
					printf("\nemailID_TR_Manager :---%s\n", emailID_TR_Manager);

					//Chief Engineer
					emailID_TR_ChfEng = getMailIDs(participant_count_TR_ChfEng,participant_list_TR_ChfEng);
					printf("\nemailID_TR_ChfEng :---%s\n", emailID_TR_ChfEng);
					
					//VATS
					emailID_TR_VatsRev = getMailIDs(participant_count_TR_VatsRev,participant_list_TR_VatsRev);
					printf("\nemailID_TR_VatsRev :---%s\n", emailID_TR_VatsRev);
					
					//Group Head
					emailID_TR_GrpHd = getMailIDs(participant_count_TR_GrpHd,participant_list_TR_GrpHd);
					printf("\nemailID_TR_GrpHd :---%s\n", emailID_TR_GrpHd);
					
					// Cluster Head
					emailID_TR_ClstrHd = getMailIDs(participant_count_TR_ClstrHd,participant_list_TR_ClstrHd);
					printf("\nemailID_TR_ClstrHd :---%s\n", emailID_TR_ClstrHd);
					
					//TP Analyst
					emailID_TP_Analyst = getMailIDs(participant_count_TP_Analyst,participant_list_TP_Analyst);
					printf("\nemailID_TP_Analyst :---%s\n", emailID_TP_Analyst);
					
					tc_strcpy(CC_MailList,"");
					CC_MailList = getCCMailIDs(emailID_TR_Manager,emailID_TR_ChfEng,emailID_TR_VatsRev,emailID_TR_GrpHd,emailID_TR_ClstrHd);

					if (tc_strlen(mail_ID_1) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_1);
					}
						
					if (tc_strlen(mail_ID_2) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_2);
					}

					if (tc_strlen(mail_ID_3) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_3);
					}

					if (tc_strlen(mail_ID_4) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_4);
					}

					if (tc_strlen(mail_ID_5) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_5);
					}

					if (tc_strlen(mail_ID_6) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_6);
					}

					if (tc_strlen(mail_ID_7) != 0)
					{
							tc_strcat(CC_MailList, ",");
							tc_strcat(CC_MailList, mail_ID_7);
					}
					if (tc_strlen(mail_ID_8) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_8);
					}

					if (tc_strlen(mail_ID_9) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_9);
					}

					if (tc_strlen(mail_ID_10) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_10);
					}

					printf("\nCC Mail List : %s\n",CC_MailList);

					//Getting the data of TR
					//tc_strcat(emailID_TP_Analyst, ",");

					//Getting Requried Properties of TR for shell.
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqDomain",&Rq_Domain);
					///fprintf(output,"t5_RqDomain		%s\n",Rq_Domain);
					ifail = AOM_ask_value_string(rev_list[i],"t5_BU",&BU);
					//fprintf(output,"t5_BU			%s\n",BU);
					ifail = AOM_ask_value_string(rev_list[i],"object_string",&TR_id);
					//fprintf(output,"item_id			%s\n",TR_id);
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqProjCode",&project_code);
					//fprintf(output,"t5_RqProjCode		%s\n",project_code);
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqProjDes",&proj_desc);
					//fprintf(output,"t5_RqProjDes		%s\n",proj_desc);
					ifail = AOM_ask_value_string(rev_list[i],"t5_WBS",&wbs_details);
					//fprintf(output,"t5_WBS			%s\n",wbs_details);
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqDesStatus",&dr_status);
					//fprintf(output,"t5_RqDesStatus		%s\n",dr_status);
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqVehStage",&veh_sys_stage);
					//fprintf(output,"t5_RqVehStage		%s\n",veh_sys_stage);
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqAggregate",&aggregate);
					//fprintf(output,"t5_RqAggregate		%s\n",aggregate);
					ifail = AOM_ask_value_string(rev_list[i],"t5_TestSubGrp",&testing_sub_group);
					//fprintf(output,"t5_TestSubGrp		%s\n",testing_sub_group);
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqInvType",&inv_type);
					//fprintf(output,"t5_RqInvType		%s\n",inv_type);
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqBGHistory",&bacg_history);
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqReqDep",&request_dept);
					//fprintf(output,"t5_RqReqDep		%s\n",request_dept);
					
					//this is to get release status
					ifail = WSOM_ask_release_status_list (rev_list[i], &count_status, &status_list);
					if(count_status > 0)
					{
						for(h=0;h<count_status;h++)
						{
							ifail = AOM_ask_value_string (status_list[h], "object_name", &tr_status_name);
						}
					}
					
					//fprintf(output,"t5_TR_Status		%s\n",tr_status_name);
	
					// This is to get FIR Details
					ifail = GRM_find_relation_type("T5_TR_FIR_REL",&fir_relation);
					ifail = GRM_list_secondary_objects_only(rev_list[i],fir_relation,&secendaryObjectCount,&fir_obj_tag);
					for(g=0;g<secendaryObjectCount;g++)
					{
							ifail = AOM_ask_value_string(fir_obj_tag[g],"object_name",&fir_object_Name);
					
					}
					//fprintf(output,"FIR number		%s\n",fir_object_Name);

					//This is to get Grn Report 
					ifail = GRM_find_relation_type("T5_TR_GR_REL",&grn_relation);
					ifail = GRM_list_secondary_objects_only(rev_list[i],grn_relation,&secendaryObjectCountGrn,&grn_obj_tag);
					for(k=0;g<secendaryObjectCountGrn;k++)
					{
							ifail = AOM_ask_value_string(grn_obj_tag[k],"object_name",&grn_object_Name);

					}
		
					/// Creating i/p file for shell
					fprintf(output,"To:%s\n",object_owner_email);
					fprintf(output,"CC:%s\n",CC_MailList);
					fprintf(output,"Subject: Test Request Closed :%s\n",TR_id);
					fprintf(output,"Dear Sir,\n\n","");
					fprintf(output,"Test Request Closed					: %s\n\n\n",TR_id);
					fprintf(output,"Request Domain					: %s\n",Rq_Domain);
					fprintf(output,"Business Unit						: %s\n",BU);
					fprintf(output,"Request Number					: %s\n",TR_id);
					fprintf(output,"Project Code						: %s\n",project_code);
					fprintf(output,"Project Description					: %s\n",proj_desc);
					fprintf(output,"WBS details						: %s\n",wbs_details);
					fprintf(output,"Design Status						: %s\n",dr_status);
					fprintf(output,"Vehicle/System Stage/n(mule,alpha,Beta,PO,PP,etc)	: %s\n",veh_sys_stage);
					
					fprintf(output,"Aggregates						: %s\n",aggregate);
					fprintf(output,"Testing Sub Group					: %s\n",testing_sub_group);
					fprintf(output,"Investigation Type/Reason for Test			: %s\n",inv_type);
					fprintf(output,"Background/History					: %s\n",bacg_history);
					fprintf(output,"Creator							: %s\n",person_name);
					fprintf(output,"Requesting Dept					: %s\n",request_dept);
					fprintf(output,"FIR number						: %s\n",fir_object_Name);
					fprintf(output,"Green Report						: %s\n",grn_object_Name);
					fprintf(output,"Request Pending with					: %s\n","---");
					fprintf(output,"Test Request Status					: %s\n\n\n\n",tr_status_name);
					fprintf(output,"Thanks and Regards,\n","");
					fprintf(output,"PLM Team ","");
					
					//tc_strcpy(inPutFile,"");
					//tc_strcpy(inPutFile,"/user/");
					//tc_strcat(inPutFile,"testcmi/");
					//tc_strcat(inPutFile,"devgroups/");
					//tc_strcat(inPutFile,"Kirtikumar/");
					//tc_strcat(inPutFile,"mail_notification_cr/");
					//tc_strcat(inPutFile,outputFile);
					//printf("\n\tInput file Path : %s", inPutFile);
					
					//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/testSendMail.sh %s %s %s > myoutput.txt &",inPutFile,emailID_TP_Analyst,object_owner_email);
					//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/mail_notification_cr/testSendMail.sh %s %s %s > myoutput.txt &",outputFile,emailID_TP_Analyst,object_owner_email);

					tc_strcat(command,file_Path);
					tc_strcat(command,"testSendMail.sh");
					tc_strcat(command," ");
					tc_strcat(command,outputFile);
					tc_strcat(command," ");
					tc_strcat(command,emailID_TP_Analyst);
					tc_strcat(command," ");
					tc_strcat(command,object_owner_email);
					tc_strcat(command," > myoutput.txt &");


					printf("\n\tCommand : %s", command);
					system(command);

					printf("\n*************************End of Handler*********************\n");

			}
			//This is for FIR
			if ((tc_strcmp(ObjTyp,"T5_FirRevision")==0))
			{
					printf("\n******************** Target Object is ::::FIR *********************\n");
					//To Get Owener of TR
					tag_t TR_Owner			=	NULLTAG;
					tag_t TR_Owner_person	=	NULLTAG;
					char* person_name		=	NULL;
					char* TR_owner_email	=	NULL;

					EPM_get_participanttype ("T5_FIR_Analyst",&Patricipant_Type_FIR_Analyst);
					EPM_get_participanttype ("T5_FIR_Grphd",&Patricipant_Type_FIR_Grphd);
					EPM_get_participanttype ("T5_FIR_ClstrHd",&Patricipant_Type_FIR_ClstrHd);
					EPM_get_participanttype ("T5_FIR_DeptRev",&Patricipant_Type_FIR_DeptRev);
					CHECK_FAIL;
					

					//This is to get proper mails of Partticipants
					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_FIR_Analyst,&participant_count_FIR_Analyst,&participant_list_FIR_Analyst);
					printf("\n Number Of participant_count_FIR_Analyst:---[%d]\n",participant_count_FIR_Analyst);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_FIR_Grphd,&participant_count_FIR_Grphd,&participant_list_FIR_Grphd);
					printf("\n Number Of participant_count_FIR_Grphd:---[%d]\n",participant_count_FIR_Grphd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_FIR_ClstrHd,&participant_count_FIR_ClstrHd,&participant_list_FIR_ClstrHd);
					printf("\n Number Of participant_count_FIR_ClstrHd:---[%d]\n",participant_count_FIR_ClstrHd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_FIR_DeptRev,&participant_count_FIR_DeptRev,&participant_list_FIR_DeptRev);
					printf("\n Number Of participant_count_FIR_DeptRev:---[%d]\n",participant_count_FIR_DeptRev);fflush(stdout);
					CHECK_FAIL;

					// Getting respective mail IDs
					
					//FIR Analyst
					emailID_FIR_Analyst = getMailIDs(participant_count_FIR_Analyst,participant_list_FIR_Analyst);
					printf("\nemailID_FIR_Analystr :---%s\n", emailID_FIR_Analyst);
					
					//FIR GRPHD
					emailID_FIR_Grphd = getMailIDs(participant_count_FIR_Grphd,participant_list_FIR_Grphd);
					printf("\nemailID_FIR_Grphd :---%s\n", emailID_FIR_Grphd);
					
					//FIR CLSTRHD
					emailID_FIR_ClstrHd = getMailIDs(participant_count_FIR_ClstrHd,participant_list_FIR_ClstrHd);
					printf("\nemailID_FIR_ClstrHd :---%s\n", emailID_FIR_ClstrHd);
					
					//FIR DEPT REV
					emailID_FIR_DeptRev = getMailIDs(participant_count_FIR_DeptRev,participant_list_FIR_DeptRev);
					printf("\nemailID_FIR_DeptRev :---%s\n", emailID_FIR_DeptRev);

					// Preparting the CC List 
					//char *CC_MailList = (char*)MEM_alloc(sizeof(char) * 1500);
					CC_MailList = getCCMailIDs(emailID_FIR_Grphd,emailID_FIR_ClstrHd,emailID_FIR_DeptRev,"","");
					
					if (tc_strlen(mail_ID_1) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_1);
					}
						
					if (tc_strlen(mail_ID_2) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_2);
					}

					if (tc_strlen(mail_ID_3) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_3);
					}

					if (tc_strlen(mail_ID_4) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_4);
					}

					if (tc_strlen(mail_ID_5) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_5);
					}

					if (tc_strlen(mail_ID_6) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_6);
					}

					if (tc_strlen(mail_ID_7) != 0)
					{
							tc_strcat(CC_MailList, ",");
							tc_strcat(CC_MailList, mail_ID_7);
					}
					if (tc_strlen(mail_ID_8) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_8);
					}

					if (tc_strlen(mail_ID_9) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_9);
					}

					if (tc_strlen(mail_ID_10) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_10);
					}

					printf("\nCC Mail List %s",CC_MailList);

					//Getting TR no from FIR
					ifail = AOM_ask_value_string(rev_list[i],"t5_FirReqNo",&TestRequestNo);
					
					if(tc_strlen(TestRequestNo) == 0)
					{
						printf("*****\n No Test reqeuest no. found in FIR ******\n");
						return ifail;

					}
					//Getting TR Tag
					ifail = ITEM_find_item (TestRequestNo, &test_request_tag);
					CHECK_FAIL;
					//Getting TR latest Rev Tag
					ifail = ITEM_ask_latest_rev(test_request_tag,&test_request_rev_tag);
					CHECK_FAIL;

					//Need to get Owner of TR
					ifail = AOM_ask_owner(test_request_rev_tag,&TR_Owner);
					if(ifail ==ITK_ok){

					} else 
					{
						EMH_ask_error_text(ifail,&error_text);
						printf("\nError %s", error_text);
					}
					ifail = SA_ask_user_person(TR_Owner,&TR_Owner_person);
					if(ifail ==ITK_ok){

					} else 
					{
						EMH_ask_error_text(ifail,&error_text);
						printf("\nError %s", error_text);
					}
					
					ifail =SA_ask_person_name2(TR_Owner_person,&person_name);
					printf("\nPerson Name %s",person_name);
					//fprintf(output,"TR_Creator		%s\n",person_name);

					ifail =SA_ask_person_email_address(TR_Owner_person,&TR_owner_email);
					printf("\nTR Owner's e-mail:-- %s",TR_owner_email);


					//Getting Requried Properties of TR for shell.
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqDomain",&Rq_Domain);
					///fprintf(output,"t5_RqDomain		%s\n",Rq_Domain);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_BU",&BU);
					//fprintf(output,"t5_BU			%s\n",BU);
					ifail = AOM_ask_value_string(test_request_rev_tag,"object_string",&TR_id);
					//fprintf(output,"item_id			%s\n",TR_id);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqProjCode",&project_code);
					//fprintf(output,"t5_RqProjCode		%s\n",project_code);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqProjDes",&proj_desc);
					//fprintf(output,"t5_RqProjDes		%s\n",proj_desc);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_WBS",&wbs_details);
					//fprintf(output,"t5_WBS			%s\n",wbs_details);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqDesStatus",&dr_status);
					//fprintf(output,"t5_RqDesStatus		%s\n",dr_status);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqVehStage",&veh_sys_stage);
					//fprintf(output,"t5_RqVehStage		%s\n",veh_sys_stage);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqAggregate",&aggregate);
					//fprintf(output,"t5_RqAggregate		%s\n",aggregate);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_TestSubGrp",&testing_sub_group);
					//fprintf(output,"t5_TestSubGrp		%s\n",testing_sub_group);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqInvType",&inv_type);
					//fprintf(output,"t5_RqInvType		%s\n",inv_type);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqBGHistory",&bacg_history);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqReqDep",&request_dept);
					//fprintf(output,"t5_RqReqDep		%s\n",request_dept);
					
					//this is to get release status
					ifail = WSOM_ask_release_status_list (test_request_rev_tag, &count_status, &status_list);
					if(count_status > 0)
					{
						for(h=0;h<count_status;h++)
						{
							ifail = AOM_ask_value_string (status_list[h], "object_name", &tr_status_name);
						}
					}
					ifail = AOM_ask_value_string(rev_list[i],"object_string",&fir_object_Name);
					tc_strcpy(grn_object_Name,"");

					/// Creating i/p file for shell
					fprintf(output,"To:%s\n",TR_owner_email);
					fprintf(output,"CC:%s\n",CC_MailList);
					fprintf(output,"Subject: FIR Released for :%s\n",TR_id);
					fprintf(output,"Dear Sir,\n\n","");
					fprintf(output,"FIR released against					: %s\n\n\n",TR_id);
					fprintf(output,"Request Domain					: %s\n",Rq_Domain);
					fprintf(output,"Business Unit						: %s\n",BU);
					fprintf(output,"Request Number					: %s\n",TR_id);
					fprintf(output,"Project Code						: %s\n",project_code);
					fprintf(output,"Project Description					: %s\n",proj_desc);
					fprintf(output,"WBS details						: %s\n",wbs_details);
					fprintf(output,"Design Status						: %s\n",dr_status);
					fprintf(output,"Vehicle/System Stage/n(mule,alpha,Beta,PO,PP,etc)	: %s\n",veh_sys_stage);
					
					fprintf(output,"Aggregates						: %s\n",aggregate);
					fprintf(output,"Testing Sub Group					: %s\n",testing_sub_group);
					fprintf(output,"Investigation Type/Reason for Test			: %s\n",inv_type);
					fprintf(output,"Background/History					: %s\n",bacg_history);
					fprintf(output,"Creator							: %s\n",person_name);
					fprintf(output,"Requesting Dept					: %s\n",request_dept);
					fprintf(output,"FIR number						: %s\n",fir_object_Name);
					fprintf(output,"Green Report						: %s\n",grn_object_Name);
					fprintf(output,"Request Pending with					: %s\n","---");
					fprintf(output,"Test Request Status					: %s\n\n\n\n",tr_status_name);
					fprintf(output,"Thanks and Regards,\n","");
					fprintf(output,"PLM Team ","");
					
					//tc_strcpy(inPutFile,"");
					////tc_strcpy(inPutFile,"/user/");
					//tc_strcat(inPutFile,"testcmi/");
					//tc_strcat(inPutFile,"devgroups/");
					//tc_strcat(inPutFile,"Kirtikumar/");
					//tc_strcat(inPutFile,"mail_notification_cr/");
					//tc_strcat(inPutFile,outputFile);
					///sprintf(command,"/user/testcmi/devgroups/Kirtikumar/testSendMail.sh %s %s %s > myoutput.txt &",inPutFile,emailID_FIR_Analyst,TR_owner_email);
					
					tc_strcat(command,file_Path);
					tc_strcat(command,"testSendMail.sh");
					tc_strcat(command," ");
					tc_strcat(command,outputFile);
					tc_strcat(command," ");
					tc_strcat(command,emailID_FIR_Analyst);
					tc_strcat(command," ");
					tc_strcat(command,TR_owner_email);
					tc_strcat(command," > myoutput.txt &");

					system(command);

					printf("\n*************************End of Handler*********************\n");
				

			}
			// This is for Green Report
			if ((tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0))
			{	
					printf("\n******************* Target Object is ::::GREEN REPORT **********************\n");

					//To Get Owener of TR
					tag_t TR_Owner			=	NULLTAG;
					tag_t TR_Owner_person	=	NULLTAG;
					char* person_name		=	NULL;
					char* TR_owner_email	=	NULL;

					EPM_get_participanttype ("T5_GR_Analyst",&Patricipant_Type_GR_Analyst);
					EPM_get_participanttype ("T5_GR_Grphd",&Patricipant_Type_GR_Grphd);
					EPM_get_participanttype ("T5_GR_ClstrHd",&Patricipant_Type_GR_ClstrHd);
					EPM_get_participanttype ("T5_GR_DeptRev",&Patricipant_Type_GR_DeptRev);
					CHECK_FAIL;


					//This is to get proper mails of Partticipants
					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_GR_Analyst,&participant_count_GR_Analyst,&participant_list_GR_Analyst);
					printf("\n Number Of participant_count_GR_Analyst:---[%d]\n",participant_count_GR_Analyst);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_GR_Grphd,&participant_count_GR_Grphd,&participant_list_GR_Grphd);
					printf("\n Number Of participant_count_GR_Grphd:---[%d]\n",participant_count_GR_Grphd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_GR_ClstrHd,&participant_count_GR_ClstrHd,&participant_list_GR_ClstrHd);
					printf("\n Number Of participant_count_GR_ClstrHd:---[%d]\n",participant_count_GR_ClstrHd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list[i],Patricipant_Type_GR_DeptRev,&participant_count_GR_DeptRev,&participant_list_GR_DeptRev);
					printf("\n Number Of participant_count_GR_DeptRev:---[%d]\n",participant_count_GR_DeptRev);fflush(stdout);
					CHECK_FAIL;

					// Getting respective mail IDs
					//GRN Analyst
					emailID_GR_Analyst = getMailIDs(participant_count_GR_Analyst,participant_list_GR_Analyst);
					printf("\nemailID_GR_Analyst :---%s\n", emailID_GR_Analyst);
					
					//GRN  GRPHD
					emailID_GR_Grphd = getMailIDs(participant_count_GR_Grphd,participant_list_GR_Grphd);
					printf("\nemailID_GR_Grphd :---%s\n", emailID_GR_Grphd);
					
					//GRN CLSTRHD
					emailID_GR_ClstrHd = getMailIDs(participant_count_GR_ClstrHd,participant_list_GR_ClstrHd);
					printf("\nemailID_GR_ClstrHd :---%s\n", emailID_GR_ClstrHd);
					
					//GRN DEPT REV
					emailID_GR_DeptRev = getMailIDs(participant_count_GR_DeptRev,participant_list_GR_DeptRev);
					printf("\nemailID_GR_DeptRev :---%s\n", emailID_GR_DeptRev);

					// Preparting the CC List 
					//char *CC_MailList = (char*)MEM_alloc(sizeof(char) * 1500);
					CC_MailList = getCCMailIDs(emailID_GR_Grphd,emailID_GR_ClstrHd,emailID_GR_DeptRev,"","");
					
					if (tc_strlen(mail_ID_1) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_1);
					}
						
					if (tc_strlen(mail_ID_2) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_2);
					}

					if (tc_strlen(mail_ID_3) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_3);
					}

					if (tc_strlen(mail_ID_4) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_4);
					}

					if (tc_strlen(mail_ID_5) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_5);
					}

					if (tc_strlen(mail_ID_6) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_6);
					}

					if (tc_strlen(mail_ID_7) != 0)
					{
							tc_strcat(CC_MailList, ",");
							tc_strcat(CC_MailList, mail_ID_7);
					}
					if (tc_strlen(mail_ID_8) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_8);
					}

					if (tc_strlen(mail_ID_9) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_9);
					}

					if (tc_strlen(mail_ID_10) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_10);
					}

					printf("\nCCMail List %s",CC_MailList);

					//Getting TR no from GRN 
					ifail = AOM_ask_value_string(rev_list[i],"t5_RqNosGr",&TestRequestNo);
					
					if(tc_strlen(TestRequestNo) == 0)
					{
						printf("*****\n No Test reqeuest no. found in GRN ******\n");
						return ifail;

					}
					//Getting TR Tag
					ifail = ITEM_find_item (TestRequestNo, &test_request_tag);
					CHECK_FAIL;
					//Getting TR latest Rev Tag
					ifail = ITEM_ask_latest_rev(test_request_tag,&test_request_rev_tag);
					CHECK_FAIL;

					//Need to get Owner of TR
					ifail = AOM_ask_owner(test_request_rev_tag,&TR_Owner);
					if(ifail ==ITK_ok){

					} else 
					{
						EMH_ask_error_text(ifail,&error_text);
						printf("\nError %s", error_text);
					}
					ifail = SA_ask_user_person(TR_Owner,&TR_Owner_person);
					if(ifail ==ITK_ok){

					} else 
					{
						EMH_ask_error_text(ifail,&error_text);
						printf("\nError %s", error_text);
					}
					
					ifail =SA_ask_person_name2(TR_Owner_person,&person_name);
					printf("\nPerson Name %s",person_name);
					//fprintf(output,"TR_Creator		%s\n",person_name);

					ifail =SA_ask_person_email_address(TR_Owner_person,&TR_owner_email);
					printf("\nTR Owner's e-mail:-- %s",TR_owner_email);

					//Getting Requried Properties of TR for shell.
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqDomain",&Rq_Domain);
					///fprintf(output,"t5_RqDomain		%s\n",Rq_Domain);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_BU",&BU);
					//fprintf(output,"t5_BU			%s\n",BU);
					ifail = AOM_ask_value_string(test_request_rev_tag,"object_string",&TR_id);
					//fprintf(output,"item_id			%s\n",TR_id);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqProjCode",&project_code);
					//fprintf(output,"t5_RqProjCode		%s\n",project_code);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqProjDes",&proj_desc);
					//fprintf(output,"t5_RqProjDes		%s\n",proj_desc);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_WBS",&wbs_details);
					//fprintf(output,"t5_WBS			%s\n",wbs_details);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqDesStatus",&dr_status);
					//fprintf(output,"t5_RqDesStatus		%s\n",dr_status);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqVehStage",&veh_sys_stage);
					//fprintf(output,"t5_RqVehStage		%s\n",veh_sys_stage);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqAggregate",&aggregate);
					//fprintf(output,"t5_RqAggregate		%s\n",aggregate);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_TestSubGrp",&testing_sub_group);
					//fprintf(output,"t5_TestSubGrp		%s\n",testing_sub_group);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqInvType",&inv_type);
					//fprintf(output,"t5_RqInvType		%s\n",inv_type);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqBGHistory",&bacg_history);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqReqDep",&request_dept);
					//fprintf(output,"t5_RqReqDep		%s\n",request_dept);
					
					//this is to get release status
					ifail = WSOM_ask_release_status_list (test_request_rev_tag, &count_status, &status_list);
					if(count_status > 0)
					{
						for(h=0;h<count_status;h++)
						{
							ifail = AOM_ask_value_string (status_list[h], "object_name", &tr_status_name);
						}
					}
					ifail = AOM_ask_value_string(rev_list[i],"object_string",&grn_object_Name);
					tc_strcpy(fir_object_Name,"");

					/// Creating i/p file for shell
					fprintf(output,"To:%s\n",TR_owner_email);
					fprintf(output,"CC:%s\n",CC_MailList);
					fprintf(output,"Subject: Green Report released for :%s\n",TR_id);
					fprintf(output,"Dear Sir,\n\n","");
					fprintf(output,"Green Report is released against				: %s\n",TR_id);
					fprintf(output,"Request Domain					: %s\n",Rq_Domain);
					fprintf(output,"Business Unit						: %s\n",BU);
					fprintf(output,"Request Number					: %s\n",TR_id);
					fprintf(output,"Project Code						: %s\n",project_code);
					fprintf(output,"Project Description					: %s\n",proj_desc);
					fprintf(output,"WBS details						: %s\n",wbs_details);
					fprintf(output,"Design Status						: %s\n",dr_status);
					fprintf(output,"Vehicle/System Stage/n(mule,alpha,Beta,PO,PP,etc)	: %s\n",veh_sys_stage);
					
					fprintf(output,"Aggregates						: %s\n",aggregate);
					fprintf(output,"Testing Sub Group					: %s\n",testing_sub_group);
					fprintf(output,"Investigation Type/Reason for Test			: %s\n",inv_type);
					fprintf(output,"Background/History					: %s\n",bacg_history);
					fprintf(output,"Creator							: %s\n",person_name);
					fprintf(output,"Requesting Dept					: %s\n",request_dept);
					fprintf(output,"FIR number						: %s\n",fir_object_Name);
					fprintf(output,"Green Report						: %s\n",grn_object_Name);
					fprintf(output,"Request Pending with					: %s\n","---");
					fprintf(output,"Test Request Status					: %s\n\n\n\n",tr_status_name);
					fprintf(output,"Thanks and Regards,\n","");
					fprintf(output,"PLM Team ","");
					
					
					// Executing the shell
					//tc_strcpy(inPutFile,"");
					//tc_strcpy(inPutFile,"/user/");
					//tc_strcat(inPutFile,"testcmi/");
					//tc_strcat(inPutFile,"devgroups/");
					//tc_strcat(inPutFile,"Kirtikumar/");
					//tc_strcat(inPutFile,"mail_notification_cr/");
					//tc_strcat(inPutFile,outputFile);
					//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/testSendMail.sh %s %s %s > myoutput.txt &",inPutFile,emailID_GR_Analyst,TR_owner_email);

					tc_strcat(command,file_Path);
					tc_strcat(command,"testSendMail.sh");
					tc_strcat(command," ");
					tc_strcat(command,outputFile);
					tc_strcat(command," ");
					tc_strcat(command,emailID_GR_Analyst);
					tc_strcat(command," ");
					tc_strcat(command,TR_owner_email);
					tc_strcat(command," > myoutput.txt &");

					system(command);
					printf("\n*************************End of Handler*********************\n");

			}
			
	}

		
		if(person_name != NULL)
			MEM_free(person_name);
	
		if(object_name != NULL)
			MEM_free(object_name);

		if(participant_list_TR_Manager != NULL)
			MEM_free(participant_list_TR_Manager);

		if(participant_list_TR_ChfEng != NULL)
			MEM_free(participant_list_TR_ChfEng);

		if(participant_list_TR_VatsRev != NULL)
			MEM_free(participant_list_TR_VatsRev);

		if(participant_list_TR_GrpHd != NULL)
			MEM_free(participant_list_TR_GrpHd);

		if(participant_list_TR_ClstrHd != NULL)
			MEM_free(participant_list_TR_ClstrHd);

		if(participant_list_TP_Analyst != NULL)
			MEM_free(participant_list_TP_Analyst);

		if(emailID_TR_Manager != NULL)
			MEM_free(emailID_TR_Manager);

		if(emailID_TR_ChfEng != NULL)
			MEM_free(emailID_TR_ChfEng);

		if(emailID_TR_VatsRev != NULL)
			MEM_free(emailID_TR_VatsRev);

		if(emailID_TR_GrpHd != NULL)
			MEM_free(emailID_TR_GrpHd);

		if(emailID_TR_ClstrHd != NULL)
			MEM_free(emailID_TR_ClstrHd);

		if(emailID_TP_Analyst != NULL)
			MEM_free(emailID_TP_Analyst);


		if(emailID_FIR_Analyst != NULL)
			MEM_free(emailID_FIR_Analyst);

		if(emailID_FIR_Grphd != NULL)
			MEM_free(emailID_FIR_Grphd);

		if(emailID_FIR_ClstrHd != NULL)
			MEM_free(emailID_FIR_ClstrHd);

		if(emailID_FIR_DeptRev != NULL)
			MEM_free(emailID_FIR_DeptRev);

		if(emailID_GR_Analyst != NULL)
			MEM_free(emailID_GR_Analyst);

		if(emailID_GR_Grphd != NULL)
			MEM_free(emailID_GR_Grphd);

		if(emailID_GR_ClstrHd != NULL)
			MEM_free(emailID_GR_ClstrHd);

		if(emailID_GR_DeptRev != NULL)
			MEM_free(emailID_GR_DeptRev);

		if(CC_MailList != NULL)
			MEM_free(CC_MailList);

		if(Rq_Domain != NULL)
			MEM_free(Rq_Domain);

		if(BU != NULL)
			MEM_free(BU);

		if(TR_id != NULL)
			MEM_free(TR_id);

		if(project_code != NULL)
			MEM_free(project_code);

		if(proj_desc != NULL)
			MEM_free(proj_desc);

		if(wbs_details != NULL)
			MEM_free(wbs_details);

		if(dr_status != NULL)
			MEM_free(dr_status);

		if(veh_sys_stage != NULL)
			MEM_free(veh_sys_stage);

		if(aggregate != NULL)
			MEM_free(aggregate);

		if(testing_sub_group != NULL)
			MEM_free(testing_sub_group);

		if(inv_type != NULL)
			MEM_free(inv_type);

		if(bacg_history != NULL)
			MEM_free(bacg_history);
		//MEM_free(creator);
		if(request_dept != NULL)
			MEM_free(request_dept);

		if(tr_status_name != NULL)
			MEM_free(tr_status_name);
			
		if(fir_object_Name != NULL)
			MEM_free(fir_object_Name);

		if(grn_object_Name != NULL)
			MEM_free(grn_object_Name);
		if(mailsTag != NULL)
			MEM_free(mailsTag);


	fclose(output);
	
	return ifail;

}
//This method will retrun complete mailIds of participants

char* getMailIDs(int participants_count, tag_t *participants_list)
{
   char *tempMail = (char*) MEM_alloc(sizeof(char) *10000);
   char *mailID = (char*) MEM_alloc(sizeof(char) *10000);
   int a = 0;
   int ifail = ITK_ok;

   for (a = 0; a < participants_count; a++)
   {
      ifail = AOM_ask_value_string(participants_list[a], "fnd0AssigneeEmail", &tempMail);

      if (tc_strlen(mailID) == 0)
      {
         if (tc_strlen(tempMail) == 0) {}
         else
         {
            tc_strcpy(mailID, tempMail);
         }

      }
      else
      {
         if (tc_strlen(tempMail) == 0) {}
         else
         {
            tc_strcat(mailID, ",");
            tc_strcat(mailID, tempMail);
         }
      }
   }
   //printf("\nIn getMailIDs funtion %s",mailID);
   return mailID;
}

//This method will retrun the mail ID of CC List 
char* getCCMailIDs(char *mail1, char *mail2, char *mail3, char *mail4, char *mail5)
{
	char *tmp_cc_list = (char*)MEM_alloc(sizeof(char) * 10000);
	//printf("\n In Get CC Mail List function.");

   if (tc_strlen(mail1) != 0)
   {
      tc_strcpy(tmp_cc_list, mail1);
   }

   if (tc_strlen(mail2) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail2);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail2);
      }
   }

   if (tc_strlen(mail3) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail3);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail3);
      }
   }

   if (tc_strlen(mail4) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail4);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail4);
      }
   }

   if (tc_strlen(mail5) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail5);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail5);
      }
   }
   //printf("\n CC Mail List : %s",tmp_cc_list);
   return tmp_cc_list;
}