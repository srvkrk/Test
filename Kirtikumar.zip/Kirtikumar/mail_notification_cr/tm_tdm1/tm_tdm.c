#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>


#define TC_MAJOR_VERSION 2007

#if TC_MAJOR_VERSION <= 10
#define TC_master_form_rtype IMAN_master_form_rtype
#endif

#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


char* getMailIDs(int,tag_t*);
char* getCCMailIDs(char*,char*,char*,char*,char*);
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
} 

static void handle_ifail( char * file, int line )
/*  Prints out the full error stack.*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "ERROR: (%s:%d)\n", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf( "    %6d: %s\n", ifails[i], messages[i] );
    }
    exit( EXIT_FAILURE );
}
;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

int TDM_ReportITK( tag_t TDM_rev_tag )
{
	int status;
	int				ifail 						= ITK_ok;
	char			*TestRqObjNm					= NULL;
	char			*output						= NULL;
	char			*FileStr						= NULL;
	char			*ExePath						= NULL;
	char mainFile[300];
	char command[1000];
	char docFile[300];
	char docFileM[300];
	const char *cTemp="item_id";
	tag_t *tags_found = NULL;
	int n_tags_found= 0;
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	FileStr=MEM_alloc(1000);
	tag_t *transfermodes=NULLTAG;
	int transfermodeCnt=0;
	tag_t PLMSession=NULLTAG;
	//tag_t TDM_rev_tag= NULLTAG;
	char* TestRqObjNm1=NULL;
	char* TestRqObjNm2=NULL;

	tag_t objTypeTag = NULLTAG;
	char  	TestRqType[TCTYPE_name_size_c+1];


	//USERARG_get_string_argument(&TestRqObjNm);
	//USERARG_get_string_argument(&TestRqType);

	//ITK_set_bypass(true);



	printf("\n in TDM_ReportITK function3 change1");fflush(stdout);


	
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;

	ifail = POM_get_user(&username,&user_tag);
	printf("\n\t Starting  TDM_ReportFun for username :%s....\n",username);fflush(stdout);

	if (TDM_rev_tag)
	{
		
		//CALLAPI(ITEM_find_revision(tags_found[0],"A*1",&TDM_rev_tag)) ;
		//CALLAPI(ITEM_ask_latest_rev (tags_found[0], &TDM_rev_tag)) ;

		CALLAPI(TCTYPE_ask_object_type (TDM_rev_tag, &objTypeTag));
		CALLAPI(TCTYPE_ask_name( objTypeTag, TestRqType));
		printf("\n\n\t\t type_name ==> %s\n", TestRqType);fflush(stdout);

		CALLAPI(AOM_ask_value_string(TDM_rev_tag,"item_id",&TestRqObjNm));
		if (TDM_rev_tag!=NULLTAG)
		{
			
			STRNG_replace_str(TestRqObjNm,"/","_",&TestRqObjNm1);
			STRNG_replace_str(TestRqObjNm1,"(","_",&TestRqObjNm2);
			STRNG_replace_str(TestRqObjNm2,")","_",&FileStr);
			printf("\n TDM_ReportFun1 function %s",FileStr);fflush(stdout);
			
			tc_strcpy(mainFile,"");
			tc_strcat(mainFile,"/tmp/");
			tc_strcat(mainFile,FileStr);
			tc_strcat(mainFile,".xml");
			TC_write_syslog("Main File = %s\n",mainFile);

			tc_strcpy(docFile,"");
			tc_strcat(docFile,"/tmp/");
			tc_strcat(docFile,FileStr);
			tc_strcat(docFile,".pdf");
			TC_write_syslog("Doc File = %s\n",docFile);

			printf("\n TDM_ReportFun function <%s> <%s>",mainFile,docFile);fflush(stdout);



			

			CALLAPI(PIE_create_session(&PLMSession));
			CALLAPI(PIE_session_set_file(PLMSession,mainFile));
			if (tc_strcmp(TestRqType,"T5_TestRqRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_TestRequest_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}
			else if (tc_strcmp(TestRqType,"T5_TestPlanRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_TestPlan_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}
			else if (tc_strcmp(TestRqType,"T5_CTRRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_CTR_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}
			else if (tc_strcmp(TestRqType,"T5_FirRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_FIR_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}
			else if (tc_strcmp(TestRqType,"T5_GrnRepRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_GrnRep_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}

			
			CALLAPI(PIE_session_set_transfer_mode(PLMSession,transfermodes[0]));
			CALLAPI(PIE_session_export_objects(PLMSession,1,&TDM_rev_tag));

			tag_t TagQryContObj = NULLTAG,*cntr_objects = NULL;
			int	n_entries = 2;
			int n_found = 0;

			char *qry_entries[2] = {"SYSCD", "SUBSYSCD"};
			char *qry_values[2] = {"TDM", "ReportPath"};

			if(QRY_find2("ControlObjQry", &TagQryContObj));

			if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
			printf("\n Objects for Query ControlObjQry == %d", n_found);fflush(stdout);

			if(n_found==1)
			{
				if( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&ExePath));
				printf("\n Information 1 Value == [%s]", ExePath);fflush(stdout);

				sprintf(command,"%s %s %s %s %s",ExePath,mainFile,docFile,TestRqType,FileStr);
				printf("\n Command to be run  == <%s>", command);fflush(stdout);
				system(command);

				if(access(docFile,F_OK)!=-1)
				{
					tag_t specRelationType_t=NULLTAG;
					tag_t PdfType=NULLTAG;
					tag_t PdfDataset=NULLTAG;
					tag_t PdfLatestDat_t=NULLTAG;
					tag_t specificationRel_t=NULLTAG;
					tag_t *DATASET=NULL;
					char* PdfObjdesc=NULL;
					char* PdfObjName=NULL;
					int DsCnt=0;

					printf("Doc file created successfully\n");fflush(stdout);
					CALLAPI(AE_find_datasettype2("PDF",&PdfType));
					if(PdfType == NULLTAG)
					{
						printf("Could not find Dataset Type PDF. Please check data model\n");fflush(stdout);
						
					}
					int Icnt=0;
					tag_t RelationDS=NULLTAG;
					
					CALLAPI(GRM_find_relation_type("TC_Attaches",&specRelationType_t));

					CALLAPI(GRM_list_secondary_objects_only(TDM_rev_tag,specRelationType_t,&DsCnt,&DATASET));
					printf("\n TR DsCnt: %d",DsCnt);fflush(stdout);	
					for (Icnt=0;Icnt<DsCnt ;Icnt++ )
					{
						CALLAPI(AOM_ask_value_string(DATASET[Icnt],"object_desc",&PdfObjdesc));
						CALLAPI(AOM_ask_value_string(DATASET[Icnt],"object_name",&PdfObjName));

						printf("\n TR DsCnt: <%s>   <%s>",PdfObjName,PdfObjdesc);fflush(stdout);	
						if ((tc_strcmp(PdfObjdesc,"TDM Pdf Report")==0) && (tc_strcmp(PdfObjName,FileStr)==0))
						{
							CALLAPI(GRM_find_relation(TDM_rev_tag,DATASET[Icnt],specRelationType_t,&RelationDS));
							if (RelationDS)
							{
								CALLAPI(GRM_delete_relation(RelationDS));
							}
						}
					}

					CALLAPI(AE_create_dataset_with_id(PdfType,FileStr,"TDM Pdf Report","","",&PdfDataset));
					CALLAPI(AE_save_myself(PdfDataset));
					CALLAPI(GRM_create_relation(TDM_rev_tag,PdfDataset,specRelationType_t,NULLTAG,&specificationRel_t));
					CALLAPI(AOM_load(specificationRel_t));
					CALLAPI(GRM_save_relation(specificationRel_t));
					CALLAPI(AE_ask_dataset_latest_rev(PdfDataset,&PdfLatestDat_t));
					CALLAPI(AOM_refresh(PdfLatestDat_t,TRUE));
					CALLAPI(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference",docFile,NULL,SS_BINARY));
					//CALLAPI(AE_save_myself(PdfLatestDat_t));

					AOM_save(PdfLatestDat_t);
					AOM_refresh(PdfLatestDat_t, FALSE);
					AOM_unload(PdfLatestDat_t);
					remove(docFile);
					output = "Report Generated Successfully and attached to revision in Attaches relationship";
				}			
				else
				{
					  printf("\n file object not found \n");fflush(stdout);
					  output = "Report not generated. Please contact PLM support team";
				}

			}
			else
			{
				  printf("\n Control object not found \n");fflush(stdout);
				  output = "Report not generated. Please contact PLM support team";
			}

			
			

			printf("\n End of program.....!!\n\n");fflush(stdout);
			
			//output = "Report fired Successfully";	

		}
		else
		{
			  printf("\n Item revision not not found \n");fflush(stdout);
			  output = "Report not generated. Please contact PLM support team";
		}
	}
	else
	{
		  printf("\n Item not found \n");fflush(stdout);
		  output = "Report not generated. Please contact PLM support team";
	}

	printf("\n End of program..... Change1!!  %s \n\n",output);fflush(stdout);
	
	if (tc_strcmp(TestRqType,"T5_FirRevision")==0 || tc_strcmp(TestRqType,"T5_GrnRepRevision")==0 )
	{
		if (tc_strstr(output,"Successfully"))
		{
			tag_t attachRelationType=NULLTAG;
			tag_t specRelationType=NULLTAG;
			char   refname[AE_reference_size_c + 1];
			int AttCnt=0,iA=0,iS=0,refnumfnd_S=0,jS=0,SpecCnt=0,jA=0,refnumfnd_A=0;
			tag_t *DATASET_attch=NULL;
			tag_t *DATASET_spec=NULL;
			AE_reference_type_t     reftypeSpec;
			AE_reference_type_t     reftypeAttach;
			tag_t refobjectSpec=NULLTAG;
			tag_t refobjectAttach=NULLTAG;
			char   pathname[SS_MAXPATHLEN + 1];
			char   pathnameA[SS_MAXPATHLEN + 1];
			char   orig_nameSpec[IMF_filename_size_c + 1];
			char   orig_nameAttach[IMF_filename_size_c + 1];

			char *token = (char *) MEM_alloc( 10000 * sizeof(char) );
			printf("\n Inside merging Report.....!!  %s \n\n",TestRqType);fflush(stdout);

			tc_strcpy(token,"/tmp/");
			tc_strcat(token,FileStr);
			tc_strcat(token,"/");
			tc_strcat(token,FileStr);
			tc_strcat(token,"_Merge.pdf ");


			CALLAPI(GRM_find_relation_type("TC_Attaches",&attachRelationType));
			CALLAPI(GRM_find_relation_type("IMAN_specification",&specRelationType));
			CALLAPI(GRM_list_secondary_objects_only(TDM_rev_tag,attachRelationType,&AttCnt,&DATASET_attch));
			CALLAPI(GRM_list_secondary_objects_only(TDM_rev_tag,specRelationType,&SpecCnt,&DATASET_spec));

			printf("\n Inside merging Report.....!!  %d  %d \n\n",AttCnt,SpecCnt);fflush(stdout);
			
			for (iA=0;iA<AttCnt;iA++)
			{
				CALLAPI(AE_ask_dataset_ref_count(DATASET_attch[iA],&refnumfnd_A));
				printf("\n NMRef found......%d",refnumfnd_A);fflush(stdout);
				for(jA=0;jA<refnumfnd_A;jA++)
				{
					CALLAPI(AE_find_dataset_named_ref(DATASET_attch[iA],jA,refname,&reftypeAttach,&refobjectAttach));
					CALLAPI( IMF_ask_original_file_name(refobjectAttach,orig_nameAttach));
					printf("\n NMRef found str......%s",orig_nameAttach);fflush(stdout);
					sprintf(pathnameA,"/tmp/%s/%s",FileStr,orig_nameAttach);
					printf("\n pathnameA=%s\n",pathnameA);fflush(stdout);
					CALLAPI(IMF_export_file(refobjectAttach,pathnameA));
					tc_strcat(token,pathnameA);
					tc_strcat(token," ");
				}
				
			}
			for (iS=0;iS<SpecCnt;iS++ )
			{
				CALLAPI(AE_ask_dataset_ref_count(DATASET_spec[iS],&refnumfnd_S));
				printf("\n NMRef found......%d",refnumfnd_S);fflush(stdout);
				for(jS=0;jS<refnumfnd_S;jS++)
				{
					CALLAPI(AE_find_dataset_named_ref(DATASET_spec[iS],jS,refname,&reftypeSpec,&refobjectSpec));
					CALLAPI( IMF_ask_original_file_name(refobjectSpec,orig_nameSpec));
					sprintf(pathname,"/tmp/%s/%s",FileStr,orig_nameSpec);
					printf("\n pathnameJT=%s\n",pathname);fflush(stdout);
					CALLAPI(IMF_export_file(refobjectSpec,pathname));
					tc_strcat(token,pathname);
					tc_strcat(token," ");
				}
			}


			printf("\n File Name.....!!  %s \n\n",token);fflush(stdout);


			tag_t TagQryContObj1 = NULLTAG,*cntr_objects1 = NULL;
			int	n_entries1 = 2;
			int n_found1 = 0;
			char *ExePath						= NULL;

			char *qry_entries1[2] = {"SYSCD", "SUBSYSCD"};
			char *qry_values1[2] = {"TDM", "MergeReportPath"};

			if(QRY_find2("ControlObjQry", &TagQryContObj1));

			if(QRY_execute(TagQryContObj1, n_entries1, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
			printf("\n Objects for Query ControlObjQry == %d", n_found1);fflush(stdout);

			if(n_found1==1)
			{


				tc_strcpy(docFileM,"");
				tc_strcat(docFileM,"/tmp/");
				tc_strcat(docFileM,FileStr);
				tc_strcat(docFileM,"/");
				tc_strcat(docFileM,FileStr);
				tc_strcat(docFileM,"_Merge.pdf");
				TC_write_syslog("Doc docFileM = %s\n",docFileM);

				if( AOM_ask_value_string(cntr_objects1[0],"t5_Userinfo1",&ExePath));
				printf("\n Information 1 Value == [%s]", ExePath);fflush(stdout);
				char command1[10000];
				sprintf(command1,"%s %s",ExePath,token);
				printf("\n Command to be run 1 == <%s>", command1);fflush(stdout);
				system(command1);

				if(access(docFileM,F_OK)!=-1)
				{
					tag_t attcRelationType_M=NULLTAG;
					tag_t PdfType_M=NULLTAG;
					tag_t PdfDataset_M=NULLTAG;
					tag_t PdfLatestDat_M=NULLTAG;
					tag_t AttRel_M=NULLTAG;
					tag_t *DATASET_M=NULL;
					char* PdfObjdesc_M=NULL;
					char* PdfObjName_M=NULL;
					int DsCnt_M=0;

					printf("Doc file created successfully\n");fflush(stdout);
					CALLAPI(AE_find_datasettype2("PDF",&PdfType_M));
					if(PdfType_M == NULLTAG)
					{
						printf("Could not find Dataset Type PDF. Please check data model\n");fflush(stdout);
						
					}

					CALLAPI(GRM_find_relation_type("TC_Attaches",&attcRelationType_M));

					CALLAPI(GRM_list_secondary_objects_only(TDM_rev_tag,attcRelationType_M,&DsCnt_M,&DATASET_M));
					printf("\n TR DsCnt_M: %d",DsCnt_M);fflush(stdout);	
					int Icnt_M=0;
					tag_t RelationDS=NULLTAG;
					for (Icnt_M=0;Icnt_M<DsCnt_M ;Icnt_M++ )
					{
						CALLAPI(AOM_ask_value_string(DATASET_M[Icnt_M],"object_desc",&PdfObjdesc_M));
						CALLAPI(AOM_ask_value_string(DATASET_M[Icnt_M],"object_name",&PdfObjName_M));

						printf("\n TR DsCnt_M: <%s>   <%s>",PdfObjName_M,PdfObjdesc_M);fflush(stdout);	
						if ((tc_strcmp(PdfObjdesc_M,"TDM Pdf Report")==0) && (tc_strcmp(PdfObjName_M,FileStr)==0))
						{
							CALLAPI(GRM_find_relation(TDM_rev_tag,DATASET_M[Icnt_M],attcRelationType_M,&RelationDS));
							if (RelationDS)
							{
								CALLAPI(GRM_delete_relation(RelationDS));
							}
						}
					}

					CALLAPI(AE_create_dataset_with_id(PdfType_M,FileStr,"TDM Pdf Report","","",&PdfDataset_M));
					CALLAPI(AE_save_myself(PdfDataset_M));
					CALLAPI(GRM_create_relation(TDM_rev_tag,PdfDataset_M,attcRelationType_M,NULLTAG,&AttRel_M));
					CALLAPI(AOM_load(AttRel_M));
					CALLAPI(GRM_save_relation(AttRel_M));
					CALLAPI(AE_ask_dataset_latest_rev(PdfDataset_M,&PdfLatestDat_M));
					CALLAPI(AOM_refresh(PdfLatestDat_M,TRUE));
					CALLAPI(AE_import_named_ref(PdfLatestDat_M,"PDF_Reference",docFileM,NULL,SS_BINARY));
					//CALLAPI(AE_save_myself(PdfLatestDat_M));
					AOM_save(PdfLatestDat_M);
					AOM_refresh(PdfLatestDat_M, FALSE);
					AOM_unload(PdfLatestDat_M);
					remove(docFileM);
					output = "Report Generated Successfully and attached to revision in Attaches relationship"; 


				}			
				else
				{
					  printf("\n file object not found \n");fflush(stdout);
					  output = "Report not generated. Please contact PLM support team";
				}
			}



		}
		else
		{

		}
	}
	//ITK_set_bypass(false);
	return ifail;
	/* Program Logic End*/
}


extern EPM_decision_t DLLAPI Chk_TR_active(EPM_rule_message_t msg) 
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;	
	logical			t5InProcess;
	char*			procedure_name				=NULL;	
	char*			Tr_Domain_Approved				=NULL;	
	char*			TR_Domain				=NULL;	
	char  	type_name[TCTYPE_name_size_c+1];

	tag_t *attachments = NULLTAG;

	tag_t *parents = NULLTAG;
	tag_t TrLcmTag = NULLTAG;
	tag_t objTypeTag = NULLTAG;


	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\ninside svr_chk_dmlactive\n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nSVR DML CurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  of attachments:%d",count);	

	if(count > 0)
	{
		TrLcmTag = attachments[0];
		CALLAPI(AOM_ask_value_string(TrLcmTag,"current_name",&t5current_name));
		printf("\n TR name:%s",t5current_name);fflush(stdout); 

		CALLAPI(EPM_ask_active_job_for_target(TrLcmTag,&n_parents,&parents));
		printf("\n TR lifecycle count :%d\n",n_parents); fflush(stdout);

		if (n_parents>1)
		{
		CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
		printf("\n TR lifecycle procedure:%s\n",procedure_name); fflush(stdout);

			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Test Request Object already submitted in Lifecycle");
			decision = EPM_nogo;
			return decision;
		}else
		{
			decision = EPM_go;
		}

		
		CALLAPI(TCTYPE_ask_object_type (TrLcmTag, &objTypeTag));
		CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
		printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

		if(tc_strcmp(type_name,"T5_TestRqRevision")==0)				
		{
			CALLAPI(AOM_ask_value_string(TrLcmTag,"t5_RqDomain",&TR_Domain));
			printf("\n TR: RqDomain: [%s]", TR_Domain);fflush(stdout);

			if (tc_strlen(TR_Domain)==0)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_warning,ITK_err," Request Domain is Empty. Please contact PLM Support TEAM");
				decision = EPM_nogo;
				return decision;
			}
			else
			{
				if (tc_strcmp(TR_Domain,"Testing-Indoor")==0 || tc_strcmp(TR_Domain,"Testing-Metallurgy")==0  || tc_strcmp(TR_Domain,"Testing-Outdoor")==0)
				{
					char* TR_Subgrp=NULL;
					CALLAPI(AOM_ask_value_string(TrLcmTag,"t5_TestSubGrp",&TR_Subgrp));
					printf("\n TR: TR_Subgrp: [%s]", TR_Subgrp);fflush(stdout);
					if (tc_strlen(TR_Subgrp)==0)
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_warning,ITK_err,"Testing Sub group is Empty. Please contact PLM Support TEAM");
						decision = EPM_nogo;
						return decision;
					}
				}
			}

				tag_t TagQryContObj = NULLTAG,*cntr_objects = NULL;
				int	n_entries = 2;
				int n_found = 0;
				printf("\nSVR DML CurrentTask:%s\n",CurrentTask);
				char *qry_entries[2] = {"SYSCD", "SUBSYSCD"};
				char *qry_values[2] = {"TDM", CurrentTask};

				if(QRY_find2("ControlObjQry", &TagQryContObj));

				if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
				printf("\n Objects for Query ControlObjQry == %d", n_found);fflush(stdout);
				if (n_found>0)
				{
					if( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&Tr_Domain_Approved));
					printf("\n Tr_Domain_Approved Information 1 Value == [%s]", Tr_Domain_Approved);fflush(stdout);

					if (!tc_strstr(Tr_Domain_Approved,TR_Domain))
					{
						EMH_clear_errors();
						EMH_store_error_s3(EMH_severity_warning,ITK_err,Tr_Domain_Approved," Request Domain is allowed for the Template ",CurrentTask);
						decision = EPM_nogo;
						return decision;
					}
				}

				
		}
		else
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err," Please select Test Request Revision and then Submit it in the workflow.");
			decision = EPM_nogo;
			return decision;
		}
 
	}  
		
	
		
	return decision;
}

extern EPM_decision_t DLLAPI TR_chk_TR_Closed(EPM_rule_message_t msg)
{
		int count,i = 0;
		tag_t root_task=NULLTAG;
		EPM_decision_t decision;
		tag_t *attachments = NULL;
		tag_t objTypeTag = NULLTAG;
	
		 
		char  	type_name[TCTYPE_name_size_c+1];
		int ifail=0;

		CALLAPI(EPM_ask_root_task(msg.task,&root_task));

		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);	 
		if(count>0)
		{
		  for(i=0;i<count;i++)
		  {			
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_TestRqRevision")==0)				
			{
				
				tag_t* FIR = NULL;
				tag_t* Grnrep = NULL;
				tag_t	ObjTypFIR	= NULLTAG;
				tag_t	ObjTypGrnrep	= NULLTAG;
				char   type_name8[TCTYPE_name_size_c+1];
				char   type_name9[TCTYPE_name_size_c+1];
				int FirCnt =0,Icnt=0,Cnt=0,Grncnt=0;
				tag_t TR_FIR_rel_type = NULLTAG;
				tag_t TR_GRN_rel_type = NULLTAG;
				char* FirObjNos=NULL;
				char* GrnObjNos=NULL;
				char* GrnLcstate=NULL;
				char* FirLcstate=NULL;
				if(GRM_find_relation_type("T5_TR_FIR_REL", &TR_FIR_rel_type)!=ITK_ok)PrintErrorStack();
				if(GRM_find_relation_type("T5_TR_GR_REL", &TR_GRN_rel_type)!=ITK_ok)PrintErrorStack();

				if (TR_FIR_rel_type!=NULLTAG)
				{
					
					if(GRM_list_secondary_objects_only(attachments[i],TR_FIR_rel_type,&FirCnt,&FIR)!=ITK_ok)PrintErrorStack();
					printf("\n TR FIR: %d",FirCnt);fflush(stdout);	
					for (Icnt=0;Icnt<FirCnt ;Icnt++ )
					{	
					
						if(TCTYPE_ask_object_type(FIR[Icnt],&ObjTypFIR));
						if(TCTYPE_ask_name(ObjTypFIR,type_name8));

						if(AOM_ask_value_string(FIR[Icnt],"item_id",&FirObjNos)!=ITK_ok)PrintErrorStack();
						
					
						if (strcmp(type_name8,"T5_FirRevision")==0)
						{
							AOM_UIF_ask_value(FIR[Icnt],"release_status_list",&FirLcstate);
							printf("\n TR:FIR Number: [%s]. FirLcstate [%s]", FirObjNos,FirLcstate);fflush(stdout);
							if (!tc_strstr(FirLcstate,"Closed"))
							{
								EMH_store_error_s2(EMH_severity_error,ITK_err,"Following FIR is not Closed. Please close all the FIR and Green report first then close TR \n",FirObjNos); 	
								return ITK_err;	
							}

						}
					}
				}

				if (TR_GRN_rel_type!=NULLTAG)
				{
					if(GRM_list_secondary_objects_only(attachments[i],TR_GRN_rel_type,&Grncnt,&Grnrep)!=ITK_ok)PrintErrorStack();
					printf("\n TR Grncnt: %d",Grncnt);fflush(stdout);	
					for (Cnt=0;Cnt<Grncnt ;Cnt++ )
					{	
					
						if(TCTYPE_ask_object_type(Grnrep[Cnt],&ObjTypGrnrep));
						if(TCTYPE_ask_name(ObjTypGrnrep,type_name9));

						if(AOM_ask_value_string(Grnrep[Cnt],"item_id",&GrnObjNos)!=ITK_ok)PrintErrorStack();
						
					
						if (strcmp(type_name9,"T5_GrnRepRevision")==0)
						{

							AOM_UIF_ask_value(Grnrep[Cnt],"release_status_list",&GrnLcstate);
							printf("\n TR:FIR Number: [%s]     GrnLcstate [%s]", GrnObjNos,GrnLcstate);fflush(stdout);
							if (!tc_strstr(GrnLcstate,"Closed"))
							{
								EMH_store_error_s2(EMH_severity_error,ITK_err,"Following Green Report is not Closed. Please close all the FIR and Green report first, then close TR \n",GrnObjNos); 	
								return ITK_err;	
							}

						}
					}
				}


			}
		  }
		}

		decision = EPM_go;
		return decision;

}
extern EPM_decision_t DLLAPI TR_CHK_TP(EPM_rule_message_t msg)
{
		int count,i = 0;
		tag_t root_task=NULLTAG;
		EPM_decision_t decision;
		tag_t *attachments = NULL;
		tag_t objTypeTag = NULLTAG;
		tag_t objTypeTagTP = NULLTAG;
	
		 
		char  	type_name[TCTYPE_name_size_c+1];
		char  	type_nameTP[TCTYPE_name_size_c+1];
		int ifail=0;

		CALLAPI(EPM_ask_root_task(msg.task,&root_task));

		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);	 
		if(count>0)
		{
		  for(i=0;i<count;i++)
		  {			
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_TestRqRevision")==0)				
			{
				
				tag_t* TP = NULL;
				
				
				
				int TpCnt =0;
				tag_t TR_TP_rel_type = NULLTAG;
				
				char* TRObjNos=NULL;
				
				
				char* FirLcstate=NULL;
				if(GRM_find_relation_type("T5_TR_TP_REL", &TR_TP_rel_type)!=ITK_ok)PrintErrorStack();
				

				if (TR_TP_rel_type!=NULLTAG)
				{
					if(AOM_ask_value_string(attachments[i],"item_id",&TRObjNos)!=ITK_ok)PrintErrorStack();
					if(GRM_list_secondary_objects_only(attachments[i],TR_TP_rel_type,&TpCnt,&TP)!=ITK_ok)PrintErrorStack();
					printf("\n TR TP: %d",TpCnt);fflush(stdout);
					
					if (TpCnt==0)
					{
						EMH_store_error_s2(EMH_severity_error,ITK_err,"TestPlan Revision is not created for the following TestRequest. Complete Action not allowed\n",TRObjNos); 	
						return ITK_err;	
					}
					else if (TpCnt==1)
					{
						CALLAPI(TCTYPE_ask_object_type (TP[i], &objTypeTagTP));
						CALLAPI(TCTYPE_ask_name( objTypeTagTP, type_nameTP));
						printf("\n\n\t\t type_name ==> %s\n", type_nameTP);fflush(stdout);
						if(tc_strcmp(type_nameTP,"T5_TestPlanRevision")!=0)				
						{
							EMH_store_error_s2(EMH_severity_error,ITK_err,"TestPlan Revision is not attached for the following TestRequest. Complete Action not allowed\n",TRObjNos); 	
							return ITK_err;	
						}
					}
					else
					{
						EMH_store_error_s2(EMH_severity_error,ITK_err,"More than 1 TestPlan Revision is not allowed for given TestRequest. Complete Action not allowed\n",TRObjNos); 	
						return ITK_err;	
					}

				}
			}
		  }
		}

		decision = EPM_go;
		return decision;

}

extern EPM_decision_t DLLAPI TR_CHK_FIR_GR(EPM_rule_message_t msg)
{
		int count,i = 0;
		tag_t root_task=NULLTAG;
		EPM_decision_t decision;
		tag_t *attachments = NULL;
		tag_t objTypeTag = NULLTAG;
		tag_t objTypeTagFIR = NULLTAG;
		tag_t objTypeTagGR = NULLTAG;
	
		 
		char  	type_name[TCTYPE_name_size_c+1];
		char  	type_nameFIR[TCTYPE_name_size_c+1];
		char  	type_nameGR[TCTYPE_name_size_c+1];
		int ifail=0;

		CALLAPI(EPM_ask_root_task(msg.task,&root_task));

		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);	 
		if(count>0)
		{
		  for(i=0;i<count;i++)
		  {			
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_TestRqRevision")==0)				
			{
				
				tag_t* GR = NULL;
				tag_t* FIR = NULL;
				
				
				
				int FirCnt =0;
				int GRCnt =0;
				tag_t TR_Fir_rel_type = NULLTAG;
				tag_t TR_GR_rel_type = NULLTAG;
				
				char* TRObjNos=NULL;
				
				
				char* FirLcstate=NULL;
				CALLAPI(GRM_find_relation_type("T5_TR_FIR_REL", &TR_Fir_rel_type));
				CALLAPI(GRM_find_relation_type("T5_TR_GR_REL", &TR_GR_rel_type));
				if(AOM_ask_value_string(attachments[i],"item_id",&TRObjNos)!=ITK_ok)PrintErrorStack();

				if (TR_Fir_rel_type!=NULLTAG )
				{
					
					if(GRM_list_secondary_objects_only(attachments[i],TR_Fir_rel_type,&FirCnt,&FIR)!=ITK_ok)PrintErrorStack();
					printf("\n TR FirCnt: %d",FirCnt);fflush(stdout);

					for (i=0;i<FirCnt; i++)
					{
						CALLAPI(TCTYPE_ask_object_type (FIR[i], &objTypeTagFIR));
						CALLAPI(TCTYPE_ask_name( objTypeTagFIR, type_nameFIR));
						printf("\n\n\t\t type_name ==> %s\n", type_nameFIR);fflush(stdout);

						if(tc_strcmp(type_nameFIR,"T5_FirRevision")!=0)				
						{
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Other than FIR Revision is  attached to TestRequest in 'Testrequest has FIR' relationship. Complete Action not allowed\n",TRObjNos); 	
							return ITK_err;	
						}
					}
				}

				if (TR_GR_rel_type!=NULLTAG )
				{
					
					if(GRM_list_secondary_objects_only(attachments[i],TR_GR_rel_type,&GRCnt,&GR)!=ITK_ok)PrintErrorStack();
					printf("\n TR GRCnt: %d",GRCnt);fflush(stdout);

					for (i=0;i<GRCnt; i++)
					{
						CALLAPI(TCTYPE_ask_object_type (GR[i], &objTypeTagGR));
						CALLAPI(TCTYPE_ask_name( objTypeTagGR, type_nameGR));
						printf("\n\n\t\t type_name ==> %s\n", type_nameGR);fflush(stdout);

						if(tc_strcmp(type_nameGR,"T5_GrnRepRevision")!=0)				
						{
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Other than Green Report Revision is  attached to TestRequest in 'Testrequest has Green Report' relationship. Complete Action not allowed\n",TRObjNos); 	
							return ITK_err;	
						}
					}
				}
				printf("\n TR FirCnt: %d ----  TR GRCnt: %d",FirCnt,GRCnt);fflush(stdout);
				if (FirCnt==0   && GRCnt==0)
				{
					
					EMH_store_error_s2(EMH_severity_error,ITK_err,"FIR/Green Report Revision is not created for the following TestRequest. Complete Action not allowed\n",TRObjNos); 	
					return ITK_err;	
				}


			}
		  }
		}

		decision = EPM_go;
		return decision;

}
extern EPM_decision_t DLLAPI TR_chk_assigned_participants(EPM_rule_message_t msg)
{
		int count,i = 0;
		tag_t root_task=NULLTAG;
		EPM_decision_t decision;
		tag_t *attachments = NULL;
		tag_t objTypeTag = NULLTAG;
	

		char*	username				=NULL;
		tag_t	user_tag				=NULLTAG;
 		char*	CurrentTask				=NULL;	
		char*	parent_name				=NULL; 
		char  	type_name[TCTYPE_name_size_c+1];
		int ifail=0;
		
		POM_get_user(&username,&user_tag);
		printf("\n\t Starting for username :%s....\n",username);fflush(stdout);		

		CALLAPI(EPM_ask_root_task(msg.task,&root_task)); 

		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);	

		CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
		printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

		if(strstr(CurrentTask,"Assign Manager and Chief Engineer")!=NULL)
		{
			CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
			printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);	 
			if(count>0)
			{
			  for(i=0;i<count;i++)
			  {			
				CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
				CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
				printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

				if(tc_strcmp(type_name,"T5_TestRqRevision")==0)				
				{				
					tag_t Tsk_CRB_rel_type = NULLTAG;
					tag_t* TskCRB = NULL;
				 
					tag_t	ObjTypTskCRB	= NULLTAG;
					char   type_name8[TCTYPE_name_size_c+1];
					int CRBcunt =0;
					int d=0;
					int ceflag=0;
					int Manflag=0;

					if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
					if (Tsk_CRB_rel_type!=NULLTAG)
					{
							//printf("\n SVR:inside DML HasParticipant \n");fflush(stdout);
							if(GRM_list_secondary_objects_only(attachments[i],Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
							printf("\nSVR:Task Participants: %d",CRBcunt);fflush(stdout);	
							for (d=0;d<CRBcunt ;d++ )
							{	
							//	printf("\nSVR:d:%d\n",d);fflush(stdout); 
								if(TCTYPE_ask_object_type(TskCRB[d],&ObjTypTskCRB));
								if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
							//	printf("\n SVR:DML: type_name8 :: %s\n", type_name8);fflush(stdout);
								if (strcmp(type_name8,"T5_TR_ChfEng")==0)
								{
									printf("\n TR - Chief Engineer present \n"); fflush(stdout); 
									ceflag=1;
								}
								if (strcmp(type_name8,"T5_TR_Manager")==0)
								{
									printf("\n TR - Manager present \n"); fflush(stdout); 
									Manflag=1;
								}
							}
					}
					if(Manflag!=1)
					{						
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Manager to the Test request","\nHelp: Select Test Request: Tools->Assign Participant->Manager option"); 	
						return ITK_err;					
					}
					if(ceflag!=1)
					{						
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Chief Engineer to the Test request","\nHelp: Select Test Request: Tools->Assign Participant->Chief Engineer option"); 	
						return ITK_err;					
					}
				
				}
			  }
			}
		}

		decision = EPM_go;
		return decision;
}


extern EPM_decision_t DLLAPI TR_chk_assigned_TrAnalyst(EPM_rule_message_t msg)
{
		int count,i = 0;
		tag_t root_task=NULLTAG;
		EPM_decision_t decision= EPM_go;
		tag_t *attachments = NULLTAG;
		tag_t objTypeTag = NULLTAG;
		//EPM_signoff_decision_t decision_Task;
		//char*	comments; 
		//date_t 	decision_date;
	

		char*	username				=NULL;
		tag_t	user_tag				=NULLTAG;
 		char*	CurrentTask				=NULL;	
		char*	parent_name				=NULL; 
		char  	type_name[TCTYPE_name_size_c+1];
		int ifail=0;
		
		POM_get_user(&username,&user_tag);
		printf("\n\t Starting for username ANALYST CHECK :%s....\n",username);fflush(stdout);		

		CALLAPI(EPM_ask_root_task(msg.task,&root_task)); 

		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);	

		CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
		printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

		 //CALLAPI(EPM_ask_decision(msg.task,user_tag,&decision_Task,&comments,&decision_date ));
		 //printf("\n\n\t\t decision_Task of :: %s\n",decision_Task);fflush(stdout);	 


		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);fflush(stdout);	 
		if(count>0)
		{
		  for(i=0;i<count;i++)
		  {			
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_TestRqRevision")==0)				
			{				
				tag_t Tsk_CRB_rel_type = NULLTAG;
				tag_t* TskCRB = NULL;
			 
				tag_t	ObjTypTskCRB	= NULLTAG;
				char   type_name8[TCTYPE_name_size_c+1];
				int CRBcunt =0;
				int d=0;
			
				int Analystflag=0;

				if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
				if (Tsk_CRB_rel_type!=NULLTAG)
				{
						//printf("\n SVR:inside DML HasParticipant \n");fflush(stdout);
						if(GRM_list_secondary_objects_only(attachments[i],Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
						printf("\nSVR:Task Participants: %d",CRBcunt);fflush(stdout);	
						for (d=0;d<CRBcunt ;d++ )
						{	
						//	printf("\nSVR:d:%d\n",d);fflush(stdout); 
							if(TCTYPE_ask_object_type(TskCRB[d],&ObjTypTskCRB));
							if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
						//	printf("\n SVR:DML: type_name8 :: %s\n", type_name8);fflush(stdout);
							if (strcmp(type_name8,"T5_TR_Analyst")==0)
							{
								printf("\n TR - Analyst present \n"); fflush(stdout); 
								Analystflag=1;
							}
						}
				}
				printf("\n TR -Analystflag  %d\n",Analystflag); fflush(stdout); 
				if(Analystflag!=1)
				{						
					EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Analyst to the Test request","\nHelp: Select Test Request: Tools->Assign Participant->TR Analyst option"); 	
					decision = EPM_nogo;
					return decision;				
				}
			}
		  }
		}
		decision = EPM_go;
		return decision;
}



int Assign_Particpants_TP_FIR_GR( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	ObjTypTR			=NULLTAG;
	tag_t	ObjTypTR_Ana			=NULLTAG;
	tag_t	TypeTag			=NULLTAG;
	tag_t	Ana_Tag_TR			=NULLTAG;
	tag_t	CH_Tag_TR			=NULLTAG;
	tag_t	GH_Tag_TR			=NULLTAG;
	tag_t	TestRqTag			=NULLTAG;
	tag_t	*attachments		=NULL;
	tag_t	*tags_found		=NULL;
	tag_t	*list_GH		=NULL;
	tag_t	*list_CH		=NULL;
	tag_t	*list_Ana		=NULL;
	char   ObjTyp[TCTYPE_name_size_c+1];
	char   type_name7[TCTYPE_name_size_c+1];
	char   type_name_Ana[TCTYPE_name_size_c+1];
	char   type_name[TCTYPE_name_size_c+1];
	tag_t   TR_TP_rel_type;
	char* TestReqNos=NULL;
	char* ObjNos=NULL;
	char* UserGh=NULL;
	char* UserRoleGh=NULL;
	char* UserGroupGh=NULL;
	char* Arch_obj=NULL;
	char* TestReqNosCpy=NULL;
	tag_t	*TR_Particpant		=NULL;
	tag_t	*TR_Reviewr		=NULL;
	int count=0,i=0,PrtCount=0,n_TR=0,jd=0;
	tag_t TR_Particpant_rel_type;

	char*  AnalystTyp=NULL;
	char*  CH_Typ=NULL;
	char*  GH_Typ=NULL;
	AnalystTyp = (char	*)MEM_alloc(100);
	CH_Typ = (char	*)MEM_alloc(100);
	GH_Typ = (char	*)MEM_alloc(100);

	//int *levels = 0;
	tag_t *TR_Tags = NULL;
	
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n TR Release No of attachments	1 :%d",count);	

	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&ObjNos)!=ITK_ok)PrintErrorStack();
			printf("\n TR:DML/Task Number: [%s].", ObjNos);fflush(stdout);
			
			if(GRM_find_relation_type("HasParticipant", &TR_Particpant_rel_type)!=ITK_ok)PrintErrorStack();

			//if(PS_where_used_all(objTag,1,&n_parents,&levels,&parents))PrintErrorStack();
			//printf("\n\t  Test request where_used count of objects  : %d",n_parents); fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_TestPlanRevision")==0)   /// expanding to test request
			{

				CALLAPI(GRM_find_relation_type("T5_TR_TP_REL", &TR_TP_rel_type));
				if (TR_TP_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(objTag,TR_TP_rel_type,&n_TR,&TR_Tags));
					printf("\n\t\t Test Request from Testplan : %d",n_TR);fflush(stdout);
				}
			}
			else if(tc_strcmp(ObjTyp,"T5_FirRevision")==0) /// expanding to test request
			{

				CALLAPI(GRM_find_relation_type("T5_TR_FIR_REL", &TR_TP_rel_type));
				if (TR_TP_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(objTag,TR_TP_rel_type,&n_TR,&TR_Tags));
					printf("\n\t\t Test Request from Testplan : %d",n_TR);fflush(stdout);
				}
			}
			else if(tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0) /// expanding to test request
			{

				CALLAPI(GRM_find_relation_type("T5_TR_GR_REL", &TR_TP_rel_type));
				if (TR_TP_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(objTag,TR_TP_rel_type,&n_TR,&TR_Tags));
					printf("\n\t\t Test Request from Testplan : %d",n_TR);fflush(stdout);
				}
			}

			if(n_TR>0)
			{
				for (jd=0;jd<n_TR;jd++ )
				{
					
					if(AOM_ask_value_string(TR_Tags[jd],"item_id",&Arch_obj))PrintErrorStack();    
					printf("\n\t Where used object is :%s",Arch_obj);	fflush(stdout);

					if(TCTYPE_ask_object_type(TR_Tags[jd],&TypeTag))PrintErrorStack();
					if(TCTYPE_ask_name(TypeTag,type_name))PrintErrorStack();
					printf("\n\t Type Name is := %s", type_name);fflush(stdout);

					if (tc_strcmp(type_name,"T5_TestRqRevision")==0)
					{	
						printf("\n\t Testrequest found :%s",Arch_obj);	fflush(stdout);
						TestRqTag=TR_Tags[jd];
						break;
					}
				}
			}

			if (TestRqTag)    /// Getting Analyst, cluster head group head from the test request
			{
				if(AOM_ask_value_string(TestRqTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
				printf("\n TR:TestReqNos: [%s].", TestReqNos);fflush(stdout);

				tag_t	queryTag	= NULLTAG;
				tag_t	*GpHdTags	= NULL;
				tag_t	*ClstrHdTags	= NULL;
				tag_t	*TR_ParticpantAna	= NULL;
				char **qry_values = (char **) MEM_alloc(40 * sizeof(char *));
				char **qry_valuesCH = (char **) MEM_alloc(40 * sizeof(char *));
				int n_entries = 3;
				int resultCount=0;
				int resultCountCH=0;
				int PrtCountAna=0;
				int nos_Ana=0,nos_CH=0,nos_GH=0;
				char *qry_entries[3] = {"Job Name","Event Type","Name"};
				char*  UserGh=NULL;
				char*  UserRoleGh=NULL;
				char*  UserGroupGh=NULL;
				char*  UserCh=NULL;
				char*  UserRoleCh=NULL;
				char*  UserGroupCh=NULL;
				char*  TR_Analyst=NULL;
				char*  TR_Analyst_Grp=NULL;
				char*  TR_Analyst_Tok=NULL;

				char*  TR_Analyst_Role=NULL;

				TestReqNosCpy = (char	*)MEM_alloc(100);
				tc_strcpy(TestReqNosCpy,TestReqNos);
				tc_strcat(TestReqNosCpy,"*");
				printf("\n TR:TestReqNosCpy: [%s].", TestReqNosCpy);fflush(stdout);
		

				if(QRY_find("tm_Audit_Workflow_Signoff", &queryTag))PrintErrorStack();
				printf("\n\t After tm_Audit_Workflow_Signoff : QRY_find");fflush(stdout);
				if (queryTag)
				{
					printf("\n\t tm_Audit_Workflow_Signoff Found Query");fflush(stdout);
				}else
				{
					printf("\n\t tm_Audit_Workflow_Signoff Not Found Query");fflush(stdout);
				}

				qry_values[0] = TestReqNosCpy;
				qry_values[1] = "Approve";
				qry_values[2] = "*Group Head Review*";

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &GpHdTags))PrintErrorStack();
				printf("\n\t resultCount GH : %d\n", resultCount); fflush(stdout);
				if (resultCount > 0)
				{
					//fnd0SignoffGroupName fnd0SignoffRoleName fnd0SignoffUserID
					if(AOM_ask_value_string(GpHdTags[0],"fnd0SignoffUserID",&UserGh)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(GpHdTags[0],"fnd0SignoffRoleName",&UserRoleGh)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(GpHdTags[0],"fnd0SignoffGroupName",&UserGroupGh)!=ITK_ok)PrintErrorStack();

					printf("\n\t GpHdTags : %s %s  %s\n", UserGh,UserRoleGh,UserGroupGh); fflush(stdout);

					if(SA_find_groupmember_by_rolename	(UserRoleGh,UserGroupGh,UserGh,&nos_GH,&list_GH)!=ITK_ok)PrintErrorStack();
					printf("\n TR GH: nos_GH: %d",nos_GH);fflush(stdout);

					if (nos_GH > 0)
					{
						GH_Tag_TR=list_GH[0];
					}
				}

				qry_valuesCH[0] = TestReqNosCpy;
				qry_valuesCH[1] = "Approve";
				qry_valuesCH[2] = "*Cluster Head Review*";

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_valuesCH, &resultCountCH, &ClstrHdTags))PrintErrorStack();
				printf("\n\t resultCountCH : %d\n", resultCountCH); fflush(stdout);
				if (resultCountCH > 0)
				{
					//fnd0SignoffGroupName fnd0SignoffRoleName fnd0SignoffUserID
					if(AOM_ask_value_string(ClstrHdTags[0],"fnd0SignoffUserID",&UserCh)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(ClstrHdTags[0],"fnd0SignoffRoleName",&UserRoleCh)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(ClstrHdTags[0],"fnd0SignoffGroupName",&UserGroupCh)!=ITK_ok)PrintErrorStack();

					printf("\n\t ClstrHdTags : %s %s  %s\n", UserCh,UserRoleCh,UserGroupCh); fflush(stdout);

					if(SA_find_groupmember_by_rolename	(UserRoleCh,UserGroupCh,UserCh,&nos_CH,&list_CH)!=ITK_ok)PrintErrorStack();
					printf("\n TR CH: nos_CH: %d",nos_CH);fflush(stdout);
					if (nos_CH > 0)
					{
						CH_Tag_TR=list_CH[0];
					}
				}

				if(GRM_list_secondary_objects_only(TestRqTag,TR_Particpant_rel_type,&PrtCountAna,&TR_ParticpantAna)!=ITK_ok)PrintErrorStack();
				printf("\n TR Ana: PrtCount count: %d",PrtCountAna);fflush(stdout);

				//T5_TR_Analyst
				int jj=0;
				for (jj=0;jj<PrtCountAna ;jj++ )
				{
					tag_t TR_PartTag = TR_ParticpantAna[jj];
					if(TCTYPE_ask_object_type(TR_PartTag,&ObjTypTR_Ana));
					if(TCTYPE_ask_name(ObjTypTR_Ana,type_name_Ana));
					printf("\n TR:DML:2 Participants Name: %s", type_name_Ana);fflush(stdout);

					if (tc_strcmp(type_name_Ana,"T5_TR_Analyst")==0)
					{
						if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeUser",&TR_Analyst)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeGroup",&TR_Analyst_Grp)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeRole",&TR_Analyst_Role)!=ITK_ok)PrintErrorStack();
						printf("\n TR:Analyst 1 : [%s] [%s] [%s] ",TR_Analyst,TR_Analyst_Grp,TR_Analyst_Role);fflush(stdout);
						
						tc_strtok(TR_Analyst,"(");
						TR_Analyst_Tok=tc_strtok(NULL,")");
						printf("\n TR_Analyst_Tok => %s ",TR_Analyst_Tok );fflush(stdout);

						if(SA_find_groupmember_by_rolename	(TR_Analyst_Role,TR_Analyst_Grp,TR_Analyst_Tok,&nos_Ana,&list_Ana)!=ITK_ok)PrintErrorStack();
						printf("\n TR Ana1: nos_Ana: %d",nos_Ana);fflush(stdout);

						if (nos_Ana > 0)
						{
							Ana_Tag_TR=list_Ana[0];
						}
						break;
					}
				}

				printf("\n\t GpHdTags : %s %s  %s\n", UserGh,UserRoleGh,UserGroupGh); fflush(stdout);
				printf("\n\t ClstrHdTags : %s %s  %s\n", UserCh,UserRoleCh,UserGroupCh); fflush(stdout);
				printf("\n TR:Analyst: [%s] [%s] [%s] ",TR_Analyst,TR_Analyst_Grp,TR_Analyst_Role);fflush(stdout);
			}
			else
			{
				printf("\n Test Request Nos found.. \n");fflush(stdout);
			}

			if(tc_strcmp(ObjTyp,"T5_TestPlanRevision")==0)   /// deleting the older particpant
			{

				if(GRM_list_secondary_objects_only(objTag,TR_Particpant_rel_type,&PrtCount,&TR_Particpant)!=ITK_ok)PrintErrorStack();
				printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);	
				int jk=0;
				for (jk=0;jk<PrtCount ;jk++ )
				{
					tag_t TR_PartTag = TR_Particpant[jk];
					if(TCTYPE_ask_object_type(TR_PartTag,&ObjTypTR));
					if(TCTYPE_ask_name(ObjTypTR,type_name7));
					printf("\n TR:DML:2 Participants Name: %s", type_name7);fflush(stdout);

					///Removal of  Reviewer   T5_TP_Analyst   T5_TP_ClstrHd T5_TP_GrpHd

					if (tc_strcmp(type_name7,"T5_TP_Analyst")==0  || tc_strcmp(type_name7,"T5_TP_ClstrHd")==0  || tc_strcmp(type_name7,"T5_TP_GrpHd")==0 )
					{
						if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeUser",&TR_Reviewr)!=ITK_ok)PrintErrorStack();
						printf("\n TR:Removing GH or CH Reviewer: [%s] ",TR_Reviewr);fflush(stdout);
						AOM_lock(objTag);
						ITEM_rev_remove_participant (objTag,TR_PartTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_save(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_unlock(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_refresh (objTag,TRUE);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
					}
				}

				tc_strcpy(AnalystTyp,"T5_TP_Analyst");
				tc_strcpy(CH_Typ,"T5_TP_ClstrHd");
				tc_strcpy(GH_Typ,"T5_TP_GrpHd");

				printf("\n Particpant AnalystTyp [%s] CH_Typ  [%s] GH_Typ  [%s] \n",AnalystTyp,CH_Typ,GH_Typ);fflush(stdout);
			}
			else if(tc_strcmp(ObjTyp,"T5_FirRevision")==0)   /// deleting the older particpant
			{
				// T5_FIR_Analyst  T5_FIR_ClstrHd   T5_FIR_DeptRev   T5_FIR_Grphd

				if(GRM_list_secondary_objects_only(objTag,TR_Particpant_rel_type,&PrtCount,&TR_Particpant)!=ITK_ok)PrintErrorStack();
				printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);	
				int jm=0;
				for (jm=0;jm<PrtCount ;jm++ )
				{
					tag_t TR_PartTag = TR_Particpant[jm];
					if(TCTYPE_ask_object_type(TR_PartTag,&ObjTypTR));
					if(TCTYPE_ask_name(ObjTypTR,type_name7));
					printf("\n TR:DML:2 Participants Name: %s", type_name7);fflush(stdout);

					///Removal of  Reviewer   T5_TP_Analyst   T5_TP_ClstrHd T5_TP_GrpHd

					if (tc_strcmp(type_name7,"T5_FIR_Analyst")==0  || tc_strcmp(type_name7,"T5_FIR_ClstrHd")==0  || tc_strcmp(type_name7,"T5_FIR_DeptRev")==0 || tc_strcmp(type_name7,"T5_FIR_Grphd")==0 )
					{
						if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeUser",&TR_Reviewr)!=ITK_ok)PrintErrorStack();
						printf("\n TR:Removing GH or CH Reviewer: [%s] ",TR_Reviewr);fflush(stdout);
						AOM_lock(objTag);
						ITEM_rev_remove_participant (objTag,TR_PartTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_save(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_unlock(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_refresh (objTag,TRUE);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
					}


				}



				tc_strcpy(AnalystTyp,"T5_FIR_Analyst");
				tc_strcpy(CH_Typ,"T5_FIR_ClstrHd");
				tc_strcpy(GH_Typ,"T5_FIR_Grphd");
				printf("\n Particpant AnalystTyp [%s] CH_Typ  [%s] GH_Typ  [%s] \n",AnalystTyp,CH_Typ,GH_Typ);fflush(stdout);
				

			}
			else if(tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0)    /// deleting the older particpant
			{
				// T5_GR_Analyst  T5_GR_Grphd    T5_GR_DeptRev   T5_GR_ClstrHd

				if(GRM_list_secondary_objects_only(objTag,TR_Particpant_rel_type,&PrtCount,&TR_Particpant)!=ITK_ok)PrintErrorStack();
				printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);	
				int jn=0;
				for (jn=0;jn<PrtCount ;jn++ )
				{
					tag_t TR_PartTag = TR_Particpant[jn];
					if(TCTYPE_ask_object_type(TR_PartTag,&ObjTypTR));
					if(TCTYPE_ask_name(ObjTypTR,type_name7));
					printf("\n TR:DML:2 Participants Name: %s", type_name7);fflush(stdout);

					if (tc_strcmp(type_name7,"T5_GR_Analyst")==0  || tc_strcmp(type_name7,"T5_GR_Grphd")==0  || tc_strcmp(type_name7,"T5_GR_DeptRev")==0  || tc_strcmp(type_name7,"T5_GR_ClstrHd")==0)
					{
						if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeUser",&TR_Reviewr)!=ITK_ok)PrintErrorStack();
						printf("\n TR:Removing GH or CH Reviewer: [%s] ",TR_Reviewr);fflush(stdout);
						AOM_lock(objTag);
						ITEM_rev_remove_participant (objTag,TR_PartTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_save(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_unlock(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_refresh (objTag,TRUE);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
					}

				}

				tc_strcpy(AnalystTyp,"T5_GR_Analyst");
				tc_strcpy(CH_Typ,"T5_GR_ClstrHd");
				tc_strcpy(GH_Typ,"T5_GR_Grphd");
				printf("\n Particpant AnalystTyp [%s] CH_Typ  [%s] GH_Typ  [%s] \n",AnalystTyp,CH_Typ,GH_Typ);fflush(stdout);

			}

			
			printf("\n Before assigning Particpant AnalystTyp [%s] CH_Typ  [%s] GH_Typ  [%s] \n",AnalystTyp,CH_Typ,GH_Typ);fflush(stdout);
			if (Ana_Tag_TR)  ///Asigning Analyst to TestPlan FIR and Green Report
			{
				printf("\n TP:Assign Ana PARTICIPALNTS Start.. \n");fflush(stdout);
				tag_t	TP_Ana_Patri_Type			=NULLTAG;
				tag_t	TP_Ana_Party			=NULLTAG;
				if(EPM_get_participanttype (AnalystTyp,&TP_Ana_Patri_Type)!=ITK_ok)PrintErrorStack();
				if(EPM_create_participant(Ana_Tag_TR,TP_Ana_Patri_Type,&TP_Ana_Party)!=ITK_ok)PrintErrorStack();
				AOM_lock(objTag);			
				if(ITEM_rev_add_participant(objTag,TP_Ana_Party)!=ITK_ok)PrintErrorStack();
				AOM_save(objTag);
				AOM_unlock(objTag);
				printf("\n TP:Assign Ana PARTICIPALNTS End.. \n");fflush(stdout);
				AOM_refresh ( objTag,TRUE);
			}
			if (CH_Tag_TR) ///Asigning Cluster Head to TestPlan FIR and Green Report
			{
				printf("\n TP:Assign CH PARTICIPALNTS Start.. \n");fflush(stdout);
				tag_t	TP_CH_Patri_Type			=NULLTAG;
				tag_t	TP_CH_Party			=NULLTAG;
				if(EPM_get_participanttype (CH_Typ,&TP_CH_Patri_Type)!=ITK_ok)PrintErrorStack();
				if(EPM_create_participant(CH_Tag_TR,TP_CH_Patri_Type,&TP_CH_Party)!=ITK_ok)PrintErrorStack();
				AOM_lock(objTag);			
				if(ITEM_rev_add_participant(objTag,TP_CH_Party)!=ITK_ok)PrintErrorStack();
				AOM_save(objTag);
				AOM_unlock(objTag);
				printf("\n TP:Assign CH PARTICIPALNTS End.. \n");fflush(stdout);
				AOM_refresh ( objTag,TRUE);
			}
			if (GH_Tag_TR) ///Asigning Group Head to TestPlan FIR and Green Report
			{
				printf("\n TP:Assign GH PARTICIPALNTS Start.. \n");fflush(stdout);
				tag_t	TP_GH_Patri_Type			=NULLTAG;
				tag_t	TP_GH_Party			=NULLTAG;
				if(EPM_get_participanttype (GH_Typ,&TP_GH_Patri_Type)!=ITK_ok)PrintErrorStack();
				if(EPM_create_participant(GH_Tag_TR,TP_GH_Patri_Type,&TP_GH_Party)!=ITK_ok)PrintErrorStack();
				AOM_lock(objTag);			
				if(ITEM_rev_add_participant(objTag,TP_GH_Party)!=ITK_ok)PrintErrorStack();
				AOM_save(objTag);
				AOM_unlock(objTag);
				printf("\n TP:Assign GH PARTICIPALNTS End.. \n");fflush(stdout);
				AOM_refresh ( objTag,TRUE);
			}

			
			///Asigning Dept head to FIR and Green Report
			if (tc_strcmp(ObjTyp,"T5_FirRevision")==0  || tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0)
			{
				char*	ReqDomain=NULL;
				tag_t	groupName_tag		=  NULLTAG;
				tag_t	roleName_tag			=  NULLTAG;
				tag_t	TR_DptHd_Party			=  NULLTAG;
				tag_t	TR_DptHd_Patri_Type			=  NULLTAG;
				tag_t	*DptHd_Tags			=  NULL;
				int NoDptHd=0;
				int iii=0;

				if(AOM_ask_value_string(TestRqTag,"t5_RqDomain",&ReqDomain))PrintErrorStack();
				printf("\n Request Domain: [%s] \n",ReqDomain);fflush(stdout);

				if (ReqDomain)
				{
					if(SA_find_group(ReqDomain,&groupName_tag)!=ITK_ok)PrintErrorStack();
					if(SA_find_role2("Department_Head",&roleName_tag)!=ITK_ok)PrintErrorStack();
					if(SA_find_groupmember_by_role(roleName_tag,groupName_tag,&NoDptHd,&DptHd_Tags)!=ITK_ok)PrintErrorStack();
					printf("\n TR: NoDptHd :[%d]",NoDptHd);  fflush(stdout);
					if(NoDptHd>0)
					{
						if (tc_strcmp(ObjTyp,"T5_FirRevision")==0)
						{
							if(EPM_get_participanttype ("T5_FIR_DeptRev",&TR_DptHd_Patri_Type)!=ITK_ok)PrintErrorStack();
						}
						if (tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0)
						{
							if(EPM_get_participanttype ("T5_GR_DeptRev",&TR_DptHd_Patri_Type)!=ITK_ok)PrintErrorStack();
						}
						
						for(iii=0;iii<NoDptHd;iii++)
						{	
							printf("\n TR:PCBU: NoDptHd no [%d]",iii);fflush(stdout);
							if(EPM_create_participant(DptHd_Tags[iii],TR_DptHd_Patri_Type,&TR_DptHd_Party)!=ITK_ok)PrintErrorStack();
							AOM_lock(objTag);			
							if(ITEM_rev_add_participant(objTag,TR_DptHd_Party)!=ITK_ok)PrintErrorStack();
							AOM_save(objTag);
							AOM_unlock(objTag);
						}
					}
					AOM_refresh ( objTag,TRUE);
					MEM_free(DptHd_Tags);
				}


			}

		}//loop
	}
	return ITK_ok;

}
int Assign_Particpants_TestReqRev( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	ObjTypTR			=NULLTAG;
	tag_t	*attachments		=NULL;
	tag_t	*tags_found		=NULL;
	tag_t	*TR_Particpant		=NULL;
	tag_t	*TR_Reviewr		=NULL;

	int i=0,j=0,count=0,PrtCount=0,n_tags_found=0;
	logical is_latest;
	char *TestReqNos=NULL;
	char *dmlrelease_type=NULL;
	char *TR_Project=NULL;
	char *TR_Project_Program=NULL;
	char   ObjTyp[TCTYPE_name_size_c+1];
	char   type_name7[TCTYPE_name_size_c+1];
	tag_t TR_Particpant_rel_type;
	int iii=0;
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n TR:DML/Task Number: [%s].", TestReqNos);fflush(stdout);
			
			if(GRM_find_relation_type("HasParticipant", &TR_Particpant_rel_type)!=ITK_ok)PrintErrorStack();
			if(tc_strcmp(ObjTyp,"T5_TestRqRevision")==0)
			{
				
				printf("\n TR:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
				if(GRM_list_secondary_objects_only(objTag,TR_Particpant_rel_type,&PrtCount,&TR_Particpant)!=ITK_ok)PrintErrorStack();
				printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);	
				int jk=0;
				for (jk=0;jk<PrtCount ;jk++ )
				{
					tag_t TR_PartTag = TR_Particpant[jk];
					if(TCTYPE_ask_object_type(TR_PartTag,&ObjTypTR));
					if(TCTYPE_ask_name(ObjTypTR,type_name7));
					printf("\n TR:DML:2 Participants Name: %s", type_name7);fflush(stdout);

					///Removal of VATS Reviewer

					if (tc_strcmp(type_name7,"T5_TR_VatsRev")==0  || tc_strcmp(type_name7,"T5_TR_GrpHd")==0  || tc_strcmp(type_name7,"T5_TR_ClstrHd")==0 )
					{
						if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeUser",&TR_Reviewr)!=ITK_ok)PrintErrorStack();
						printf("\n TR:Removing GH or CH Reviewer: [%s] ",TR_Reviewr);fflush(stdout);
						AOM_lock(objTag);
						ITEM_rev_remove_participant (objTag,TR_PartTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_save(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_unlock(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_refresh (objTag,TRUE);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
					}
				}


				/// Addition of VATS Reviewer

				if (tc_strstr(TestReqNos,"Testing-Indoor") || tc_strstr(TestReqNos,"Testing-Metallurgy"))
				{

					printf("\n TR:ADD PARTICIPALNTS START.. \n");fflush(stdout);
					if(AOM_ask_value_string(objTag,"t5_RqProgram",&TR_Project_Program)!=ITK_ok)PrintErrorStack();
					printf("\n TR:TestReqNos: [%s] TR_Program: [%s]", TestReqNos,TR_Project_Program);fflush(stdout);
					
					char	*groupName_VATS			=  NULL;
					char	*roleName_VATS			=  NULL;
					tag_t	groupName_VATS_tag		=  NULLTAG;
					tag_t	roleName_VATS_tag			=  NULLTAG;
					tag_t	TR_VATS_Party			=  NULLTAG;
					tag_t	TR_VATS_Patri_Type			=  NULLTAG;
					tag_t	*VATS_Tags			=  NULL;
					int No_VATS=0;
					

		
					
					printf("\n TR:TR_Project_Program: [%s] ", TR_Project_Program);fflush(stdout);
					groupName_VATS = (char	*)MEM_alloc(100);
					tc_strcpy(groupName_VATS,"VATS_Group");

					roleName_VATS = (char	*)MEM_alloc(100);
					tc_strcpy(roleName_VATS,TR_Project_Program);
					tc_strcat(roleName_VATS,"_Reviewer");

					printf("\n TR:groupName_VATS  1111: [%s] roleName_VATS: [%s]", groupName_VATS,roleName_VATS);fflush(stdout);


					printf("\n TR: Setting  VATS...");fflush(stdout);
					if(SA_find_group(groupName_VATS,&groupName_VATS_tag)!=ITK_ok)PrintErrorStack();
					if(SA_find_role2(roleName_VATS,&roleName_VATS_tag)!=ITK_ok)PrintErrorStack();
					if(SA_find_groupmember_by_role(roleName_VATS_tag,groupName_VATS_tag,&No_VATS,&VATS_Tags)!=ITK_ok)PrintErrorStack();
					printf("\n TR: No_VATS :[%d]",No_VATS);  fflush(stdout);
					if(No_VATS>0)
					{
						
						for(iii=0;iii<No_VATS;iii++)
						{	
							printf("\n TR:PCBU: VATS Reviewer no [%d]",iii);fflush(stdout);
							if(EPM_get_participanttype ("T5_TR_VatsRev",&TR_VATS_Patri_Type)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(VATS_Tags[iii],TR_VATS_Patri_Type,&TR_VATS_Party)!=ITK_ok)PrintErrorStack();
							AOM_lock(objTag);			
							if(ITEM_rev_add_participant(objTag,TR_VATS_Party)!=ITK_ok)PrintErrorStack();
							AOM_save(objTag);
							AOM_unlock(objTag);
						}
					}
					AOM_refresh ( objTag,TRUE);
					MEM_free(VATS_Tags);
				}


				/// Addition of GroupHead Reviewer

				printf("\n TR:ADD PARTICIPALNTS START.. \n");fflush(stdout);

				
				char	*groupName			=  NULL;
				char	*groupName_CH			=  NULL;
				char	*roleName_GH			=  NULL;
				char	*roleName_CH			=  NULL;
				char	*TR_SubGrp_Tok			=  NULL;
				char	*TR_SubGrp			=  NULL;
				char	*TR_Domain			=  NULL;
				char	*TR_BU			=  NULL;
				tag_t	groupName_tag		=  NULLTAG;
				tag_t	groupName_tag_CH		=  NULLTAG;
				tag_t	roleName_GH_tag			=  NULLTAG;
				tag_t	roleName_CH_tag			=  NULLTAG;
				tag_t	TR_GH_Party			=  NULLTAG;
				tag_t	TR_CH_Party			=  NULLTAG;
				tag_t	TR_GH_Patri_Type			=  NULLTAG;
				tag_t	TR_CH_Patri_Type			=  NULLTAG;
				tag_t	*GH_Tags			=  NULL;
				tag_t	*CH_Tags			=  NULL;
				int No_GH=0;
				int No_CH=0;
				

				if (tc_strstr(TestReqNos,"Testing-Indoor") || tc_strstr(TestReqNos,"Testing-Metallurgy")|| tc_strstr(TestReqNos,"CAE-") || tc_strstr(TestReqNos,"Testing-Outdoor") || tc_strstr(TestReqNos,"Testing-Crash") || tc_strstr(TestReqNos,"Testing-Climate")|| tc_strstr(TestReqNos,"Testing-NVH"))
				{
					if(AOM_ask_value_string(objTag,"t5_TestSubGrp",&TR_SubGrp)!=ITK_ok)PrintErrorStack();
					printf("\n TR:TestReqNos: [%s] TR_SubGrp: [%s]", TestReqNos,TR_SubGrp);fflush(stdout);

					if(AOM_ask_value_string(objTag,"t5_RqDomain",&TR_Domain)!=ITK_ok)PrintErrorStack();
					printf("\n TR:TestReqNos: [%s] TR_Domain: [%s]", TestReqNos,TR_Domain);fflush(stdout);
 
					groupName = (char	*)MEM_alloc(100);
					
					roleName_CH = (char	*)MEM_alloc(100);
					roleName_GH = (char	*)MEM_alloc(100);
					tc_strcpy(roleName_GH,"Group_Head");

					if (tc_strstr(TestReqNos,"Testing-Indoor") || tc_strstr(TestReqNos,"Testing-Metallurgy"))
					{

						TR_SubGrp_Tok=tc_strtok(TR_SubGrp,"-");
						printf("\n TR_SubGrp_Tok => %s ",TR_SubGrp_Tok );fflush(stdout);

						tc_strcpy(groupName,TR_SubGrp_Tok);
						tc_strcat(groupName,".");
						tc_strcat(groupName,TR_Domain);
						tc_strcpy(roleName_CH,"Cluster_Head");  
					}
					else if (tc_strstr(TestReqNos,"CAE-"))
					{
						tc_strcpy(groupName,TR_Domain);
						tc_strcpy(roleName_CH,"Department_Head");  //Department_Head
					}
					else if (tc_strstr(TestReqNos,"Testing-Crash") || tc_strstr(TestReqNos,"Testing-NVH") || tc_strstr(TestReqNos,"Testing-Climate") )
					{
						tc_strcpy(groupName,TR_Domain);   
					}
					else if (tc_strstr(TestReqNos,"Testing-Outdoor"))
					{
						groupName_CH = (char	*)MEM_alloc(100);
						if(AOM_ask_value_string(objTag,"t5_BU",&TR_BU)!=ITK_ok)PrintErrorStack();
						printf("\n TR:TestReqNos: [%s] TR_BU: [%s]", TestReqNos,TR_BU);fflush(stdout);

						TR_SubGrp_Tok=tc_strtok(TR_SubGrp,"-");
						printf("\n TR_SubGrp_Tok => %s ",TR_SubGrp_Tok );fflush(stdout);

						tc_strcpy(groupName,TR_SubGrp_Tok);
						tc_strcat(groupName,".");
						tc_strcat(groupName,TR_Domain);
						tc_strcat(groupName,"_");
						tc_strcat(groupName,TR_BU);
						tc_strcpy(roleName_CH,"Project_Head");  //Project_Head


						tc_strcpy(groupName_CH,TR_Domain);
						tc_strcat(groupName_CH,"_");
						tc_strcat(groupName_CH,TR_BU);

						printf("\n groupName => %s groupName_CH => %s",groupName,groupName_CH );fflush(stdout);
					}
					
					



					
					

					

					printf("\n TR:groupName  1111: [%s] roleName_GH: [%s]  roleName_CH: [%s]", groupName,roleName_GH,roleName_CH);fflush(stdout);


					printf("\n TR: Setting  GH...");fflush(stdout);
					if(SA_find_group(groupName,&groupName_tag)!=ITK_ok)PrintErrorStack();
					if (groupName_CH)
					{
						if(SA_find_group(groupName_CH,&groupName_tag_CH)!=ITK_ok)PrintErrorStack();
					}
					
					if(SA_find_role2(roleName_GH,&roleName_GH_tag)!=ITK_ok)PrintErrorStack();
					if(SA_find_role2(roleName_CH,&roleName_CH_tag)!=ITK_ok)PrintErrorStack();

					if(SA_find_groupmember_by_role(roleName_GH_tag,groupName_tag,&No_GH,&GH_Tags)!=ITK_ok)PrintErrorStack();
					printf("\n TR: No_GH :[%d]",No_GH);  fflush(stdout);
					if(No_GH>0)
					{
						
						for(iii=0;iii<No_GH;iii++)
						{	
							printf("\n TR: GH Reviewer no [%d]",iii);fflush(stdout);
							if(EPM_get_participanttype ("T5_TR_GrpHd",&TR_GH_Patri_Type)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(GH_Tags[iii],TR_GH_Patri_Type,&TR_GH_Party)!=ITK_ok)PrintErrorStack();
							AOM_lock(objTag);			
							if(ITEM_rev_add_participant(objTag,TR_GH_Party)!=ITK_ok)PrintErrorStack();
							AOM_save(objTag);
							AOM_unlock(objTag);
						}
					}
					AOM_refresh ( objTag,TRUE);
					MEM_free(GH_Tags);

					if (tc_strstr(TestReqNos,"Testing-Outdoor"))
					{
						if(SA_find_groupmember_by_role(roleName_CH_tag,groupName_tag_CH,&No_CH,&CH_Tags)!=ITK_ok)PrintErrorStack();
					}
					else if (tc_strstr(TestReqNos,"Testing-Crash") || tc_strstr(TestReqNos,"Testing-NVH") || tc_strstr(TestReqNos,"Testing-Climate"))
					{
						printf("\n TR:Skipping for Testing Crash/NAV/Climate \n");  fflush(stdout);
					}
					else
					{
						if(SA_find_groupmember_by_role(roleName_CH_tag,groupName_tag,&No_CH,&CH_Tags)!=ITK_ok)PrintErrorStack();
					}

				
					printf("\n TR: No_CH :[%d]",No_CH);  fflush(stdout);
					if(No_CH>0)
					{
						
						for(iii=0;iii<No_CH;iii++)
						{	
							printf("\n TR: GH Reviewer no [%d]",iii);fflush(stdout);
							if(EPM_get_participanttype ("T5_TR_ClstrHd",&TR_CH_Patri_Type)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(CH_Tags[iii],TR_CH_Patri_Type,&TR_CH_Party)!=ITK_ok)PrintErrorStack();
							AOM_lock(objTag);			
							if(ITEM_rev_add_participant(objTag,TR_CH_Party)!=ITK_ok)PrintErrorStack();
							AOM_save(objTag);
							AOM_unlock(objTag);
						}
						AOM_refresh ( objTag,TRUE);
						MEM_free(CH_Tags);
					}

				}
				else 
				{
					printf("\n >>>>>>>>>>>>>>>>TR :[%s] NOT MAPPED <<<<<<<<<<<<<<",TestReqNos);  fflush(stdout);
				}
			}
		}

	}
return ITK_ok;
}
;

int Assign_Particpants_CTR( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	ObjTypTR			=NULLTAG;
	tag_t	*attachments		=NULL;
	
	tag_t	*TR_Particpant		=NULL;
	tag_t	*TR_Reviewr		=NULL;

	int i=0,j=0,count=0,PrtCount=0,n_tags_found=0;
	
	char *TestReqNos=NULL;
	
	
	
	char   ObjTyp[TCTYPE_name_size_c+1];
	char   type_name7[TCTYPE_name_size_c+1];
	tag_t TR_Particpant_rel_type;
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n TR:DML/Task Number: [%s].", TestReqNos);fflush(stdout);
			
			if(GRM_find_relation_type("HasParticipant", &TR_Particpant_rel_type)!=ITK_ok)PrintErrorStack();
			if(tc_strcmp(ObjTyp,"T5_CTRRevision")==0)
			{
				
				printf("\n TR:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
				if(GRM_list_secondary_objects_only(objTag,TR_Particpant_rel_type,&PrtCount,&TR_Particpant)!=ITK_ok)PrintErrorStack();
				printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);	
				int jk=0;
				for (jk=0;jk<PrtCount ;jk++ )
				{
					tag_t TR_PartTag = TR_Particpant[jk];
					if(TCTYPE_ask_object_type(TR_PartTag,&ObjTypTR));
					if(TCTYPE_ask_name(ObjTypTR,type_name7));
					printf("\n TR:DML:2 Participants Name: %s", type_name7);fflush(stdout);

					///Removal of VATS Reviewer

					if (tc_strcmp(type_name7,"T5_CtrGrpHead")==0  )
					{
						if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeUser",&TR_Reviewr)!=ITK_ok)PrintErrorStack();
						printf("\n TR:Removing GH or CH Reviewer: [%s] ",TR_Reviewr);fflush(stdout);
						AOM_lock(objTag);
						ITEM_rev_remove_participant (objTag,TR_PartTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_save(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_unlock(objTag);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						AOM_refresh (objTag,TRUE);
						printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
					}
				}





				/// Addition of GroupHead Reviewer

				printf("\n TR:ADD PARTICIPALNTS START.. \n");fflush(stdout);

				
				char	*groupName			=  NULL;
				char	*roleName_GH			=  NULL;
				
				char	*TR_SubGrp_Tok			=  NULL;
				char	*TR_SubGrp			=  NULL;
				char	*TR_Domain			=  NULL;
				
				tag_t	groupName_tag		=  NULLTAG;
				tag_t	roleName_GH_tag			=  NULLTAG;
				tag_t	TR_GH_Party			=  NULLTAG;
				tag_t	TR_GH_Patri_Type			=  NULLTAG;
				tag_t	*GH_Tags			=  NULL;
				int No_GH=0;
				int iii=0;

				


				if(AOM_ask_value_string(objTag,"t5_CtrSubGrp",&TR_SubGrp)!=ITK_ok)PrintErrorStack();
				printf("\n CTR:ReqNos: [%s] TR_Program: [%s]", TestReqNos,TR_SubGrp);fflush(stdout);


				TR_SubGrp_Tok=tc_strtok(TR_SubGrp,"-");
				printf("\n CTR_SubGrp_Tok => %s ",TR_SubGrp_Tok );fflush(stdout);


				if(AOM_ask_value_string(objTag,"t5_RqDomain",&TR_Domain)!=ITK_ok)PrintErrorStack();
				printf("\n CTR_Domain => %s ",TR_Domain );fflush(stdout);


				
				groupName = (char	*)MEM_alloc(200);
				tc_strcpy(groupName,TR_SubGrp_Tok);
				tc_strcat(groupName,".");
				tc_strcat(groupName,TR_Domain);
				//tc_strcpy(groupName,TR_Domain);


				roleName_GH = (char	*)MEM_alloc(100);
				//tc_strcpy(roleName_GH,TR_SubGrp_Tok);
				tc_strcpy(roleName_GH,"Group_Head");
				

				printf("\n TR:groupName  1111: [%s] roleName_GH: [%s]  ", groupName,roleName_GH);fflush(stdout);


				printf("\n TR: Setting  GH...");fflush(stdout);
				if(SA_find_group(groupName,&groupName_tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_role2(roleName_GH,&roleName_GH_tag)!=ITK_ok)PrintErrorStack();
			

				if(SA_find_groupmember_by_role(roleName_GH_tag,groupName_tag,&No_GH,&GH_Tags)!=ITK_ok)PrintErrorStack();
				printf("\n TR: No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					
					for(iii=0;iii<No_GH;iii++)
					{	
						printf("\n TR: GH Reviewer no [%d]",iii);fflush(stdout);
						if(EPM_get_participanttype ("T5_CtrGrpHead",&TR_GH_Patri_Type)!=ITK_ok)PrintErrorStack();
						if(EPM_create_participant(GH_Tags[iii],TR_GH_Patri_Type,&TR_GH_Party)!=ITK_ok)PrintErrorStack();
						AOM_lock(objTag);			
						if(ITEM_rev_add_participant(objTag,TR_GH_Party)!=ITK_ok)PrintErrorStack();
						AOM_save(objTag);
						AOM_unlock(objTag);
					}
				}
				AOM_refresh ( objTag,TRUE);
				MEM_free(GH_Tags);
								
			}
		}

	}
return ITK_ok;
}
;


extern DLLAPI int  createDesRevRelPre(METHOD_message_t *msg, va_list args)
{
		int		error_code				=	ITK_ok;
		int ifail=0;
		tag_t	objTag					=	va_arg(args, tag_t);
		tag_t	objTypeTag				=	NULLTAG;
		tag_t	priObjTag				=	NULLTAG;
		tag_t	priObjTypeTag			=	NULLTAG;
		tag_t	secObjTag				=	NULLTAG;
		tag_t	secObjTypeTag			=	NULLTAG;
		char *sdrpdSVRname				=	NULL;
		char *DrwNos				=	NULL;
		char *object_name				=	NULL;
		
		tag_t		ref_type		= NULLTAG;
		tag_t		DataSetTag		= NULLTAG;
		int			n_attchs,i		= 0;
		int FlagPDF=0,FlagJT=0;
		tag_t*    secondary_list	 = NULL;	

		char   type_name[TCTYPE_name_size_c+1];
		char   type_name1[TCTYPE_name_size_c+1];
		char   type_name2[TCTYPE_name_size_c+1];
		char   *type_name3;
		char   *RqDomain;
		char *FinalDrw=(char *)MEM_alloc(1000 * sizeof(char));

      
	printf("\n createDesRevRelPost:: Design Revision and test request relation \n");fflush(stdout);


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	printf("\n save_method_20::type_name :%s\n", type_name);fflush(stdout);


	if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
	printf("\n save_method_20::pri_type_name :%s\n", type_name1);fflush(stdout);

	if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
	printf("\n save_method_20::sec_type_nameAPPown :%s\n", type_name2);fflush(stdout);

	if( AOM_ask_value_string(secObjTag,"object_name",&sdrpdSVRname)!=ITK_ok); PrintErrorStack();
	printf("\n  Design rev name %s\n", sdrpdSVRname);fflush(stdout);
	
	
	CALLAPI(AOM_ask_value_string(priObjTag,"t5_RqDomain",&RqDomain));

	if(GRM_find_relation_type("IMAN_Rendering",&ref_type)!= ITK_ok);
	if(GRM_list_secondary_objects_only(secObjTag,ref_type,&n_attchs,&secondary_list) != ITK_ok);

	for (i= 0; i < n_attchs; i++)
	{
		DataSetTag = secondary_list[i];

		AOM_ask_value_string(DataSetTag,"object_type",&type_name3);
		AOM_ask_value_string(DataSetTag,"object_name",&object_name);
		
		printf("\n  Design type_name %s\n", type_name3);fflush(stdout);
		if(tc_strcmp(type_name3,"PDF") ==0)
		{
			FlagPDF=1;
		}
		if(tc_strcmp(type_name3,"DirectModel") ==0)
		{
			FlagJT=1;
		}
	}

	printf("\n  FlagPDF %d  FlagJT %d \n", FlagPDF,FlagJT);fflush(stdout);

	if (FlagJT==0 && FlagPDF ==0)
	{
		EMH_store_error_s1( EMH_severity_error,ITK_err,"Dropped Design Revision does not have PDF/JT. Relation creation is failed");
		return ITK_err;
	}

	if (FlagJT==0  && tc_strstr(RqDomain,"CAE"))
	{
		EMH_store_error_s1( EMH_severity_error,ITK_err,"Dropped Design Revision does not have JT, For CAE Test request JT is must. Relation creation is failed");
		return ITK_err;
	}


     return error_code;
}
extern DLLAPI int  createDesRevRelPost(METHOD_message_t *msg, va_list args)
{

		int		error_code				=	ITK_ok;
		int ifail=0;
		tag_t	objTag					=	va_arg(args, tag_t);
		tag_t	objTypeTag				=	NULLTAG;
		tag_t	priObjTag				=	NULLTAG;
		tag_t	priObjTypeTag			=	NULLTAG;
		tag_t	secObjTag				=	NULLTAG;
		tag_t	secObjTypeTag			=	NULLTAG;
		char *sdrpdSVRname				=	NULL;
		char *DrwNos				=	NULL;
		char *object_name				=	NULL;
		
		tag_t		ref_type		= NULLTAG;
		tag_t		DataSetTag		= NULLTAG;
		int			n_attchs,i		= 0;
		tag_t*    secondary_list	 = NULL;	

		char   type_name[TCTYPE_name_size_c+1];
		char   type_name1[TCTYPE_name_size_c+1];
		char   type_name2[TCTYPE_name_size_c+1];
		char   *type_name3;
		char *FinalDrw=(char *)MEM_alloc(1000 * sizeof(char));

      
	printf("\n createDesRevRelPost:: Design Revision and test request relation \n");fflush(stdout);

	
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;

	ifail = POM_get_user(&username,&user_tag);
	printf("\n\t Starting  TDM for username :%s....\n",username);fflush(stdout);


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	printf("\n save_method_20::type_name :%s\n", type_name);fflush(stdout);


	if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
	printf("\n save_method_20::pri_type_name :%s\n", type_name1);fflush(stdout);

	if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
	printf("\n save_method_20::sec_type_nameAPPown :%s\n", type_name2);fflush(stdout);

	if( AOM_ask_value_string(secObjTag,"object_name",&sdrpdSVRname)!=ITK_ok); PrintErrorStack();
	printf("\n  Design rev name %s\n", sdrpdSVRname);fflush(stdout);
	
	

	if(GRM_find_relation_type("IMAN_Rendering",&ref_type)!= ITK_ok);
	if(GRM_list_secondary_objects_only(secObjTag,ref_type,&n_attchs,&secondary_list) != ITK_ok);

	for (i= 0; i < n_attchs; i++)
	{
		DataSetTag = secondary_list[i];

		AOM_ask_value_string(DataSetTag,"object_type",&type_name3);
		AOM_ask_value_string(DataSetTag,"object_name",&object_name);
		
		printf("\n  Design type_name %s\n", type_name3);fflush(stdout);
		if(tc_strcmp(type_name3,"PDF") ==0)
		{
			CALLAPI(AOM_ask_value_string(priObjTag,"t5_CtrDrwNo",&DrwNos));
			printf("\n  Design rev name %s\n", DrwNos);fflush(stdout);
			if(DrwNos != NULL)
			{
				printf("\n  NOT NULL \n");fflush(stdout);
				if (!tc_strstr(DrwNos,object_name))
				{
					tc_strcpy(FinalDrw,DrwNos);
					tc_strcat(FinalDrw,", ");
					tc_strcat(FinalDrw,object_name);
					AOM_lock(priObjTag);
					AOM_set_value_string(priObjTag,"t5_CtrDrwNo",FinalDrw);
					AOM_save(priObjTag);
					AOM_unlock(priObjTag);
					AOM_refresh (priObjTag,TRUE);
				}
			}
			else
			{
				printf("\n   NULL \n");fflush(stdout);
				//ITK_set_bypass(true);
				AOM_lock(priObjTag);
				AOM_set_value_string(priObjTag,"t5_CtrDrwNo",object_name);
				AOM_save(priObjTag);
				AOM_unlock(priObjTag);
				AOM_refresh (priObjTag,TRUE);
				//ITK_set_bypass(false);
			}
		}
	}
		

      return error_code;
}
;

int Stamp_GH( EPM_action_message_t msg )
{
	int		error_code				=	ITK_ok;
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;

	tag_t	*attachments		=NULL;


		
	tag_t user_tag =NULLTAG;
	char *FinalName=(char *)MEM_alloc(1000 * sizeof(char));

	int i=0,j=0,count=0,PrtCount=0,n_tags_found=0;

	char *username = NULL;
	char *user_id = NULL;
	
	char personNm[SA_person_name_size_c+1] ;
	char *TestReqNos=NULL;

	char   ObjTyp[TCTYPE_name_size_c+1];


	
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR Release No of attachments:%d",count);	

	POM_get_user(&username,&user_tag);
	POM_get_user_id	(&user_id);	

	printf("\n\nStarting for TDM  ID:%s....",user_id);fflush(stdout);

	//if(AOM_ask_value_string(user_tag,"person_name",&personNm)!=ITK_ok)PrintErrorStack();
	SA_ask_user_person_name (user_tag,personNm);
	printf("\n\nStarting for TDM Name:%s....",personNm);fflush(stdout);
	printf("\n\nStarting for TDM Name POM:%s....",username);fflush(stdout);

	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n TDM OBJ ID: [%s].", TestReqNos);fflush(stdout);
			//t5_RptGrpHead

			if ((tc_strcmp(ObjTyp,"T5_TestRqRevision")==0) || (tc_strcmp(ObjTyp,"T5_TestPlanRevision")==0) || (tc_strcmp(ObjTyp,"T5_FirRevision")==0) || (tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0) || tc_strcmp(ObjTyp,"T5_CTRRevision")==0)
			{
				tc_strcpy(FinalName,personNm);
				tc_strcat(FinalName,"(");
				tc_strcat(FinalName,user_id);
				tc_strcat(FinalName,")");

				printf("\n TDM OBJGH UsrName: [%s].", FinalName);fflush(stdout);
				//ITK_set_bypass(true);
				AOM_lock(objTag);
				AOM_set_value_string(objTag,"t5_RptGrpHead",FinalName);
				AOM_save(objTag);
				AOM_unlock(objTag);
				AOM_refresh (objTag,TRUE);
				//ITK_set_bypass(false);
				
			}
			else if (tc_strcmp(ObjTyp,"T5_CTRRevision")==0)
			{
				
			}

		}
	}

	 return error_code;
}

int Stamp_CH( EPM_action_message_t msg )
{
	int		error_code				=	ITK_ok;
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;

	tag_t	*attachments		=NULL;


		
	tag_t user_tag =NULLTAG;
	char *FinalName=(char *)MEM_alloc(1000 * sizeof(char));

	int i=0,j=0,count=0,PrtCount=0,n_tags_found=0;

	char *username = NULL;
	char *user_id = NULL;
	
	char personNm[SA_person_name_size_c+1] ;
	char *TestReqNos=NULL;

	char   ObjTyp[TCTYPE_name_size_c+1];


	
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR Release No of attachments:%d",count);	

	POM_get_user(&username,&user_tag);
	POM_get_user_id	(&user_id);	

	printf("\n\nStarting for TDM  ID:%s....",user_id);fflush(stdout);

	//if(AOM_ask_value_string(user_tag,"person_name",&personNm)!=ITK_ok)PrintErrorStack();
	SA_ask_user_person_name (user_tag,personNm);
	printf("\n\nStarting for TDM Name:%s....",personNm);fflush(stdout);
	printf("\n\nStarting for TDM Name POM:%s....",username);fflush(stdout);

	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n TDM OBJ ID: [%s].", TestReqNos);fflush(stdout);
			//t5_RptGrpHead

			if ((tc_strcmp(ObjTyp,"T5_TestRqRevision")==0) || (tc_strcmp(ObjTyp,"T5_TestPlanRevision")==0) || (tc_strcmp(ObjTyp,"T5_FirRevision")==0) || (tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0))
			{
				tc_strcpy(FinalName,personNm);
				tc_strcat(FinalName,"(");
				tc_strcat(FinalName,user_id);
				tc_strcat(FinalName,")");

				printf("\n TDM OBJ CH UsrName: [%s].", FinalName);fflush(stdout);
				
				//ITK_set_bypass(true);
				AOM_lock(objTag);
				AOM_set_value_string(objTag,"t5_RptClstrHead",FinalName);
				AOM_save(objTag);
				AOM_unlock(objTag);
				AOM_refresh (objTag,TRUE);
				//ITK_set_bypass(false);
				
			}
			else if (tc_strcmp(ObjTyp,"T5_CTRRevision")==0)
			{
				
			}

		}
	}

	 return error_code;
}
int Stamp_Analyst( EPM_action_message_t msg )
{
	int		error_code				=	ITK_ok;
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;

	tag_t	*attachments		=NULL;


		
	tag_t user_tag =NULLTAG;
	char *FinalName= NULL;
		
	//(char *)MEM_alloc(1000 * sizeof(char));

	int i=0,j=0,count=0,PrtCount=0,n_tags_found=0;

	char *username = NULL;
	char *user_id = NULL;
	
	char personNm[SA_person_name_size_c+1] ;
	char *TestReqNos=NULL;

	char   ObjTyp[TCTYPE_name_size_c+1];


	
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR Release No of attachments:%d",count);	

	POM_get_user(&username,&user_tag);
	POM_get_user_id	(&user_id);	

	printf("\n\nStarting for TDM  ID:%s....",user_id);fflush(stdout);

	//if(AOM_ask_value_string(user_tag,"person_name",&personNm)!=ITK_ok)PrintErrorStack();
	SA_ask_user_person_name (user_tag,personNm);
	printf("\n\nStarting for TDM Name:%s....",personNm);fflush(stdout);
	printf("\n\nStarting for TDM Name POM:%s....",username);fflush(stdout);

	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n TDM OBJ ID: [%s].", TestReqNos);fflush(stdout);
			//t5_RptGrpHead

			if ((tc_strcmp(ObjTyp,"T5_TestRqRevision")==0))
			{
				
				tag_t Tsk_CRB_rel_type = NULLTAG;
				tag_t* TskCRB = NULL;
			 
				tag_t	ObjTypTskCRB	= NULLTAG;
				char   type_name8[TCTYPE_name_size_c+1];
				int CRBcunt =0;
				int d=0;
			
				int Analystflag=0;

				if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
				if (Tsk_CRB_rel_type!=NULLTAG)
				{
						//printf("\n SVR:inside DML HasParticipant \n");fflush(stdout);
						if(GRM_list_secondary_objects_only(objTag,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
						printf("\nSVR:Task Participants: %d",CRBcunt);fflush(stdout);	
						for (d=0;d<CRBcunt ;d++ )
						{	
						//	printf("\nSVR:d:%d\n",d);fflush(stdout); 
							if(TCTYPE_ask_object_type(TskCRB[d],&ObjTypTskCRB));
							if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
						//	printf("\n SVR:DML: type_name8 :: %s\n", type_name8);fflush(stdout);
							if (strcmp(type_name8,"T5_TR_Analyst")==0)
							{
								printf("\n TR - Analyst present \n"); fflush(stdout); 

								if(AOM_UIF_ask_value(TskCRB[d],"fnd0AssigneeUser",&FinalName)!=ITK_ok)PrintErrorStack();
								printf("\n TR - Analyst present %s \n",FinalName); fflush(stdout);
								Analystflag=1;
								break;
							}
						}
				}
				//tc_strcpy(FinalName,personNm);
				//tc_strcat(FinalName,"(");
				//tc_strcat(FinalName,user_id);
				///tc_strcat(FinalName,")");

				printf("\n TDM OBJ CH UsrName: [%s].", FinalName);fflush(stdout);
				if (Analystflag==1)
				{
					//ITK_set_bypass(true);
					AOM_lock(objTag);
					AOM_set_value_string(objTag,"t5_PrtFIREng",FinalName);
					AOM_save(objTag);
					AOM_unlock(objTag);
					AOM_refresh (objTag,TRUE);
					//ITK_set_bypass(false);
				}

				
			}


		}
	}

	 return error_code;
}
int Auto_Report( EPM_action_message_t msg )
{
	int		error_code				=	ITK_ok;
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;

	tag_t	*attachments		=NULL;


		
	tag_t user_tag =NULLTAG;
	char *FinalName=(char *)MEM_alloc(1000 * sizeof(char));

	int i=0,j=0,count=0,PrtCount=0,n_tags_found=0;

	char *username = NULL;
	char *user_id = NULL;
	
	char personNm[SA_person_name_size_c+1] ;
	char *TestReqNos=NULL;
	char *TR_Domain=NULL;

	char   ObjTyp[TCTYPE_name_size_c+1];


	
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n TDM No of attachments:%d",count);	

	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n TDM OBJ ID: [%s].", TestReqNos);fflush(stdout);
			//t5_RptGrpHead
			
			if ((tc_strcmp(ObjTyp,"T5_TestRqRevision")==0) || (tc_strcmp(ObjTyp,"T5_TestPlanRevision")==0) || (tc_strcmp(ObjTyp,"T5_FirRevision")==0) || (tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0) )
			{
				CALLAPI(AOM_ask_value_string(objTag,"t5_RqDomain",&TR_Domain));
				printf("\n TR: RqDomain for auto Report: [%s]", TR_Domain);fflush(stdout);
			}


			if ((tc_strcmp(ObjTyp,"T5_TestRqRevision")==0) || ((tc_strcmp(ObjTyp,"T5_TestPlanRevision")==0) && ((tc_strcmp(TR_Domain,"Testing-Outdoor")==0) || (tc_strcmp(TR_Domain,"Testing-Indoor")==0) || (tc_strcmp(TR_Domain,"Testing-Metallurgy")==0)))  || ((tc_strcmp(ObjTyp,"T5_FirRevision")==0) && ((tc_strcmp(TR_Domain,"Testing-Indoor")==0) || (tc_strcmp(TR_Domain,"Testing-Metallurgy")==0))) || (tc_strcmp(ObjTyp,"T5_GrnRepRevision")==0) || (tc_strcmp(ObjTyp,"T5_CTRRevision")==0))
			{

				TDM_ReportITK(objTag);
			}


		}
	}

	 return error_code;
}
////CR-FY22-0259: Added on 28-04-2022 By Kirtikumar Thakur
int Mail_Notification( EPM_action_message_t msg )
{

	int				ifail				= 0;
	int				count				= 0;
	tag_t			root_task			= NULLTAG;
	tag_t			*attachments		= NULLTAG;
	tag_t			class_id			= NULL;
	char			*class_name			= NULL;

	FILE			*output 			= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";

	tag_t			rev_list					= NULL;
	int				i 							= 0;
	int				j 							= 0;
	int				a=0,b=0,c=0,d=0,e=0,f=0,g=0,h=0,k=0;
	int				count_status				= 0;
	int				num							= 0;
	int*			state_token;

	tag_t			item_tag					= NULLTAG;
	tag_t			*status_list				= NULL;
	tag_t *			allWorkflow					= NULL;
	tag_t			tp_close_status_tag;
	tag_t			date_released_attr			= NULL;

	
	date_t			workflowEndDate;

	//This is for TR
	tag_t	Patricipant_Type_TR_Manager			= NULLTAG;
	tag_t	Patricipant_Type_TR_ChfEng			= NULLTAG;
	tag_t	Patricipant_Type_TR_VatsRev			= NULLTAG;
	tag_t	Patricipant_Type_TR_GrpHd			= NULLTAG;
	tag_t	Patricipant_Type_TR_ClstrHd			= NULLTAG;
	tag_t	Patricipant_Type_TP_Analyst			= NULLTAG;
	
	// This is for FIR
	tag_t	Patricipant_Type_FIR_Analyst		= NULLTAG;
	tag_t	Patricipant_Type_FIR_Grphd			= NULLTAG;
	tag_t	Patricipant_Type_FIR_ClstrHd		= NULLTAG;
	tag_t	Patricipant_Type_FIR_DeptRev		= NULLTAG;
	
	// This is for Green Report
	tag_t	Patricipant_Type_GR_Analyst			= NULLTAG;
	tag_t	Patricipant_Type_GR_Grphd			= NULLTAG;
	tag_t	Patricipant_Type_GR_ClstrHd			= NULLTAG;
	tag_t	Patricipant_Type_GR_DeptRev			= NULLTAG;


	
	tag_t  ObjTypTag							=NULLTAG;
	
	//This is for TR
	int	    participant_count_TR_Manager		=0;
	int	    participant_count_TR_ChfEng			=0;
	int	    participant_count_TR_VatsRev		=0;
	int	    participant_count_TR_GrpHd			=0;
	int	    participant_count_TR_ClstrHd		=0;
	int	    participant_count_TP_Analyst		=0;

	//This is for FIR
	int	    participant_count_FIR_Analyst		=0;
	int	    participant_count_FIR_Grphd			=0;
	int	    participant_count_FIR_ClstrHd		=0;
	int	    participant_count_FIR_DeptRev		=0;

	//This is for GRN

	int	    participant_count_GR_Analyst		=0;
	int	    participant_count_GR_Grphd			=0;
	int	    participant_count_GR_ClstrHd		=0;
	int	    participant_count_GR_DeptRev		=0;

	int secendaryObjectCount					=0;
	int secendaryObjectCountGrn					=0;



	//This is for TR
	tag_t	*participant_list_TR_Manager        = NULLTAG;
	tag_t	*participant_list_TR_ChfEng			= NULLTAG;
	tag_t	*participant_list_TR_VatsRev		= NULLTAG;
	tag_t	*participant_list_TR_GrpHd			= NULLTAG;
	tag_t	*participant_list_TR_ClstrHd		= NULLTAG;
	tag_t	*participant_list_TP_Analyst		= NULLTAG;

	//This is for FIR
	tag_t	*participant_list_FIR_Analyst       = NULLTAG;
	tag_t	*participant_list_FIR_Grphd			= NULLTAG;
	tag_t	*participant_list_FIR_ClstrHd		= NULLTAG;
	tag_t	*participant_list_FIR_DeptRev		= NULLTAG;


	//This is for GRN
	tag_t	*participant_list_GR_Analyst        = NULLTAG;
	tag_t	*participant_list_GR_Grphd			= NULLTAG;
	tag_t	*participant_list_GR_ClstrHd		= NULLTAG;
	tag_t	*participant_list_GR_DeptRev		= NULLTAG;

	char			ObjTyp[TCTYPE_name_size_c+1];

	char			*status						= NULL;
	char			*object_name				= NULL;
	char			*workflowName				= NULL;
	char			*wfEndDate					= NULL;
	
	char			*rev_id						= NULL;
	//This is for TR
	char	*emailID_TR_Manager					=(char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_TR_ChfEng					= (char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_TR_VatsRev					= (char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_TR_GrpHd					= (char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_TR_ClstrHd					= (char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_TP_Analyst					= (char *) MEM_alloc( 2000 * sizeof(char) );

	//This is for FIR
	char	*emailID_FIR_Analyst				=(char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_FIR_Grphd					= (char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_FIR_ClstrHd				= (char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_FIR_DeptRev				= (char *) MEM_alloc( 2000 * sizeof(char) );

	//This is for GRN
	char	*emailID_GR_Analyst					=(char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_GR_Grphd					= (char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_GR_ClstrHd					= (char *) MEM_alloc( 2000 * sizeof(char) );
	char	*emailID_GR_DeptRev					= (char *) MEM_alloc( 2000 * sizeof(char) );

	char	*CC_MailList						= (char*)MEM_alloc(sizeof(char) * 2000);

	//This is for to get maild IDs from control Object
	//int n_entries								= 2;
	//int	resultCount;
	//char *userEntry1							= "Name";
	//char *value1								= "TDM_Mail_Notification_Group";
	//char *userEntry2							= "Type";
	//char *value2								= "Control Object";
	//char**  entries							= NULL;
	//char**  values							= NULL;

	//This is for to get maild IDs from control Object
	int n_entries								= 2;
	int	resultCount;
	char *userEntry[2]			={"Name","Type"};
	char **Value				=(char **) MEM_alloc(100 * sizeof(char *));
	char *file_Path				=NULL;

	tag_t	queryTag;
	tag_t	*mailsTag							= NULLTAG;
	char	*cntrObjName						= NULL;
	char	*mail_ID_1							= NULL;
	char	*mail_ID_2							= NULL;
	char	*mail_ID_3							= NULL;
	char	*mail_ID_4							= NULL;
	char	*mail_ID_5							= NULL;
	char	*mail_ID_6							= NULL;
	char	*mail_ID_7							= NULL;
	char	*mail_ID_8							= NULL;
	char	*mail_ID_9							= NULL;
	char	*mail_ID_10							= NULL;



	// TR Properties
	char* Rq_Domain								=NULL;
	char* BU									=NULL;
	char* TR_id									=NULL;
	char* project_code							=NULL;
	char* proj_desc								=NULL;
	char* wbs_details							=NULL;
	char* dr_status								=NULL;
	char* veh_sys_stage							=NULL;
	char* aggregate								=NULL;
	char* testing_sub_group						=NULL;
	char* inv_type								=NULL;
	char* bacg_history							=NULL;
	

	char* request_dept							=NULL;
	char* fir_name								=NULL;
	char* grn_name								=NULL;
	char* releaseStatus							=NULL;

	char* error_text							=NULL;
	char *person_name							=NULL;
	
	char *fir_object_Name						=NULL; 
	char *grn_object_Name						=NULL;
	char *tr_status_name						=NULL;
	char *object_owner_email					=NULL;
	char *TestRequestNo							=NULL;
	char command[512]							="";
	char inPutFile[512]                         ="";


	tag_t	object_owner						= NULLTAG;
	tag_t	object_owner_person					= NULLTAG;
	tag_t	fir_tag								= NULLTAG;
	tag_t	grn_tag								= NULLTAG;
	tag_t   creator								= NULLTAG;
	tag_t   creator_grp							= NULLTAG;
	

	tag_t fir_relation							=NULLTAG;
	tag_t grn_relation							=NULLTAG;
	
	tag_t *fir_obj_tag							=NULLTAG;
	tag_t *grn_obj_tag							=NULLTAG;
	
	tag_t test_request_tag						=NULLTAG;
	tag_t test_request_rev_tag					=NULLTAG;
	
	//For OutPut File
	//time_t 	now;
	//struct 	tm when;
	//time(&now);
	//when = *localtime(&now);
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"/user/testcmi/devgroups/Kirtikumar/mail_notification_cr/%s_output.txt",Data);

	//output = fopen(outputFile, "a");
	//if (output == NULL)
	//{
		//printf("ERROR: Cannot open File\n");
		//return -1;
	//}
	//else
	//{
		//printf("File opened successfully.\n");
	//}

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n\n\t\t Root task found");

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n TDM No of attachments:%d",count);
	
	if(count>0)
	{
		rev_list = attachments[0];
		ifail = AOM_ask_value_string(rev_list,"object_string",&object_name);
		printf("\nObject Name :---%s\n", object_name);

		ifail = AOM_ask_owner(rev_list,&object_owner);
		if(ifail ==ITK_ok){

		} else 
		{
			EMH_ask_error_text(ifail,&error_text);
			printf("\nError %s", error_text);
		}
		ifail = SA_ask_user_person(object_owner,&object_owner_person);
		if(ifail ==ITK_ok){

		} else 
		{
			EMH_ask_error_text(ifail,&error_text);
			printf("\nError %s", error_text);
		}

		ifail =SA_ask_person_name2(object_owner_person,&person_name);
		printf("\nPerson Name %s",person_name);
		//fprintf(output,"TR_Creator		%s\n",person_name);
		ifail =SA_ask_person_email_address(object_owner_person,&object_owner_email);
		printf("\n TR Creator's e mail:-- %s",object_owner_email);

		ifail = POM_class_of_instance(rev_list,&class_id);
		ifail = POM_name_of_class(class_id,&class_name);
		printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout);

		ifail = QRY_find2("General...", & queryTag);
		CHECK_FAIL;

		//******************************This is to get mail IDs form Control Object***********************************************************************
		Value[0]="TDM_Mail_Notification_Group";
		Value[1]="Control Object";

		ifail = QRY_execute(queryTag, n_entries, userEntry, Value, & resultCount, &mailsTag);
		if(ifail ==ITK_ok){

		} else 
		{
			EMH_ask_error_text(ifail,&error_text);
			printf("\nError %s", error_text);
		}
		printf("\nNo. of Cnt Obj for -->TDM_Mail_Notification_Group-- %d\n", resultCount);

		//******************************This is to get mail IDs form Control Object Ends***********************************************************************
			ifail = AOM_ask_value_string(mailsTag[0],"object_name",&cntrObjName);
			CHECK_FAIL;
			//File Path, is added in t5_userinfo10:
			ifail = AOM_ask_value_string(mailsTag[0],"t5_userinfo10",&file_Path);
			CHECK_FAIL;
			printf("\nFile Path of Shell and OutPut File : %s\n", file_Path);

			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo1",&mail_ID_1);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo2",&mail_ID_2);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo3",&mail_ID_3);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo4",&mail_ID_4);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo5",&mail_ID_5);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo6",&mail_ID_6);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo7",&mail_ID_7);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo8",&mail_ID_8);
			CHECK_FAIL;
			ifail = AOM_ask_value_string(mailsTag[0],"t5_Userinfo9",&mail_ID_9);
			CHECK_FAIL;
			//******************************Opening File***********************************************************************
			//Opening File 
			//For OutPut File
			char			Data[100]					= "";
			char			outputFile[200]				= "";
			time_t 	now;
			struct 	tm when;
			time(&now);
			when = *localtime(&now);
			strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);

			//printf("\nData :: %s\n", Data);
			//sprintf(outputFile,"/user/testcmi/devgroups/Kirtikumar/mail_notification_cr/%s_output.txt",Data);
			//printf("\nOUTPUT FILE :: %s\n", outputFile);

			tc_strcat(outputFile,file_Path);
			tc_strcat(outputFile,Data);
			tc_strcat(outputFile,"_output.txt");

			printf("\nAfter Concatination of File path from crontrol object :: %s\n",outputFile);


			output = fopen(outputFile, "a");
			if (output == NULL)
			{
				printf("ERROR: Cannot open File\n");
				return -1;
			}
			else
			{
				printf("File opened successfully.\n");
			}
			//******************************Opening File ends***********************************************************************

		//For Test Request
		if(tc_strcmp(class_name,"T5_TestRqRevision")==0)
		{
					printf("\n******************** Target Object is :::: Test Request*********************\n");
					//Getting all Participants for TR
					EPM_get_participanttype ("T5_TR_Manager",&Patricipant_Type_TR_Manager);
					EPM_get_participanttype ("T5_TR_ChfEng",&Patricipant_Type_TR_ChfEng);
					EPM_get_participanttype ("T5_TR_VatsRev",&Patricipant_Type_TR_VatsRev);
					EPM_get_participanttype ("T5_TR_GrpHd",&Patricipant_Type_TR_GrpHd);
					EPM_get_participanttype ("T5_TR_ClstrHd",&Patricipant_Type_TR_ClstrHd);
					EPM_get_participanttype ("T5_TR_Analyst",&Patricipant_Type_TP_Analyst);
					CHECK_FAIL;

					//This is to get proper mails of Partticipants
					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_TR_Manager,&participant_count_TR_Manager,&participant_list_TR_Manager);
					printf("\n Number Of participant_count_TR_Manager:---[%d]",participant_count_TR_Manager);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_TR_ChfEng,&participant_count_TR_ChfEng,&participant_list_TR_ChfEng);
					printf("\n Number Of participant_count_TR_ChfEng:---[%d]",participant_count_TR_ChfEng);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_TR_VatsRev,&participant_count_TR_VatsRev,&participant_list_TR_VatsRev);
					printf("\n Number Of participant_count_TR_VatsRev:---[%d]",participant_count_TR_VatsRev);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_TR_GrpHd,&participant_count_TR_GrpHd,&participant_list_TR_GrpHd);
					printf("\n Number Of participant_count_TR_GrpHd:---[%d]",participant_count_TR_GrpHd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_TR_ClstrHd,&participant_count_TR_ClstrHd,&participant_list_TR_ClstrHd);
					printf("\n Number Of participant_count_TR_ClstrHd:---[%d]",participant_count_TR_ClstrHd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_TP_Analyst,&participant_count_TP_Analyst,&participant_list_TP_Analyst);
					printf("\n Number Of participant_count_TP_Analyst:---[%d]",participant_count_TP_Analyst);fflush(stdout);
					CHECK_FAIL;

					//This code is to get respective mail IDs
					//Manager 
					emailID_TR_Manager = getMailIDs(participant_count_TR_Manager,participant_list_TR_Manager);
					printf("\nemailID_TR_Manager :---%s\n", emailID_TR_Manager);

					//Chief Engineer
					emailID_TR_ChfEng = getMailIDs(participant_count_TR_ChfEng,participant_list_TR_ChfEng);
					printf("\nemailID_TR_ChfEng :---%s\n", emailID_TR_ChfEng);
					
					//VATS
					emailID_TR_VatsRev = getMailIDs(participant_count_TR_VatsRev,participant_list_TR_VatsRev);
					printf("\nemailID_TR_VatsRev :---%s\n", emailID_TR_VatsRev);
					
					//Group Head
					emailID_TR_GrpHd = getMailIDs(participant_count_TR_GrpHd,participant_list_TR_GrpHd);
					printf("\nemailID_TR_GrpHd :---%s\n", emailID_TR_GrpHd);
					
					// Cluster Head
					emailID_TR_ClstrHd = getMailIDs(participant_count_TR_ClstrHd,participant_list_TR_ClstrHd);
					printf("\nemailID_TR_ClstrHd :---%s\n", emailID_TR_ClstrHd);
					
					//TP Analyst
					emailID_TP_Analyst = getMailIDs(participant_count_TP_Analyst,participant_list_TP_Analyst);
					printf("\nemailID_TP_Analyst :---%s\n", emailID_TP_Analyst);

					tc_strcpy(CC_MailList,"");
					CC_MailList = getCCMailIDs(emailID_TR_Manager,emailID_TR_ChfEng,emailID_TR_VatsRev,emailID_TR_GrpHd,emailID_TR_ClstrHd);

					if (tc_strlen(mail_ID_1) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_1);
					}
						
					if (tc_strlen(mail_ID_2) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_2);
					}

					if (tc_strlen(mail_ID_3) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_3);
					}

					if (tc_strlen(mail_ID_4) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_4);
					}

					if (tc_strlen(mail_ID_5) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_5);
					}

					if (tc_strlen(mail_ID_6) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_6);
					}

					if (tc_strlen(mail_ID_7) != 0)
					{
							tc_strcat(CC_MailList, ",");
							tc_strcat(CC_MailList, mail_ID_7);
					}
					if (tc_strlen(mail_ID_8) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_8);
					}

					if (tc_strlen(mail_ID_9) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_9);
					}

					if (tc_strlen(mail_ID_10) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_10);
					}

					printf("\nCC Mail List : %s\n",CC_MailList);

					//Getting the data of TR
					//tc_strcat(emailID_TP_Analyst, ",");
					//Getting Requried Properties of TR for shell.
					ifail = AOM_ask_value_string(rev_list,"t5_RqDomain",&Rq_Domain);
					///fprintf(output,"t5_RqDomain		%s\n",Rq_Domain);
					ifail = AOM_ask_value_string(rev_list,"t5_BU",&BU);
					//fprintf(output,"t5_BU			%s\n",BU);
					ifail = AOM_ask_value_string(rev_list,"object_string",&TR_id);
					//fprintf(output,"item_id			%s\n",TR_id);
					ifail = AOM_ask_value_string(rev_list,"t5_RqProjCode",&project_code);
					//fprintf(output,"t5_RqProjCode		%s\n",project_code);
					ifail = AOM_ask_value_string(rev_list,"t5_RqProjDes",&proj_desc);
					//fprintf(output,"t5_RqProjDes		%s\n",proj_desc);
					ifail = AOM_ask_value_string(rev_list,"t5_WBS",&wbs_details);
					//fprintf(output,"t5_WBS			%s\n",wbs_details);
					ifail = AOM_ask_value_string(rev_list,"t5_RqDesStatus",&dr_status);
					//fprintf(output,"t5_RqDesStatus		%s\n",dr_status);
					ifail = AOM_ask_value_string(rev_list,"t5_RqVehStage",&veh_sys_stage);
					//fprintf(output,"t5_RqVehStage		%s\n",veh_sys_stage);
					ifail = AOM_ask_value_string(rev_list,"t5_RqAggregate",&aggregate);
					//fprintf(output,"t5_RqAggregate		%s\n",aggregate);
					ifail = AOM_ask_value_string(rev_list,"t5_TestSubGrp",&testing_sub_group);
					//fprintf(output,"t5_TestSubGrp		%s\n",testing_sub_group);
					ifail = AOM_ask_value_string(rev_list,"t5_RqInvType",&inv_type);
					//fprintf(output,"t5_RqInvType		%s\n",inv_type);
					ifail = AOM_ask_value_string(rev_list,"t5_RqBGHistory",&bacg_history);
					ifail = AOM_ask_value_string(rev_list,"t5_RqReqDep",&request_dept);
					//fprintf(output,"t5_RqReqDep		%s\n",request_dept);

					//this is to get release status
					ifail = WSOM_ask_release_status_list (rev_list, &count_status, &status_list);
					if(count_status > 0)
					{
						for(h=0;h<count_status;h++)
						{
							ifail = AOM_ask_value_string (status_list[h], "object_name", &tr_status_name);
						}
					}

					//fprintf(output,"t5_TR_Status		%s\n",tr_status_name);
	
					// This is to get FIR Details
					ifail = GRM_find_relation_type("T5_TR_FIR_REL",&fir_relation);
					ifail = GRM_list_secondary_objects_only(rev_list,fir_relation,&secendaryObjectCount,&fir_obj_tag);
					for(g=0;g<secendaryObjectCount;g++)
					{
							ifail = AOM_ask_value_string(fir_obj_tag[g],"object_name",&fir_object_Name);
					
					}
					//fprintf(output,"FIR number		%s\n",fir_object_Name);
					//This is to get Grn Report 
					ifail = GRM_find_relation_type("T5_TR_GR_REL",&grn_relation);
					ifail = GRM_list_secondary_objects_only(rev_list,grn_relation,&secendaryObjectCountGrn,&grn_obj_tag);
					for(k=0;g<secendaryObjectCountGrn;k++)
					{
							ifail = AOM_ask_value_string(grn_obj_tag[k],"object_name",&grn_object_Name);

					}

					/// Creating i/p file for shell
					fprintf(output,"To:%s\n",object_owner_email);
					fprintf(output,"CC:%s\n",CC_MailList);
					fprintf(output,"Subject: Test Request Closed :%s\n",TR_id);
					fprintf(output,"Dear Sir,\n\n","");
					fprintf(output,"Test Request Closed					: %s\n\n\n",TR_id);
					fprintf(output,"Request Domain					: %s\n",Rq_Domain);
					fprintf(output,"Business Unit						: %s\n",BU);
					fprintf(output,"Request Number					: %s\n",TR_id);
					fprintf(output,"Project Code						: %s\n",project_code);
					fprintf(output,"Project Description					: %s\n",proj_desc);
					fprintf(output,"WBS details						: %s\n",wbs_details);
					fprintf(output,"Design Status						: %s\n",dr_status);
					fprintf(output,"Vehicle/System Stage/n(mule,alpha,Beta,PO,PP,etc)	: %s\n",veh_sys_stage);
					
					fprintf(output,"Aggregates						: %s\n",aggregate);
					fprintf(output,"Testing Sub Group					: %s\n",testing_sub_group);
					fprintf(output,"Investigation Type/Reason for Test			: %s\n",inv_type);
					fprintf(output,"Background/History					: %s\n",bacg_history);
					fprintf(output,"Creator							: %s\n",person_name);
					fprintf(output,"Requesting Dept					: %s\n",request_dept);
					fprintf(output,"FIR number						: %s\n",fir_object_Name);
					fprintf(output,"Green Report						: %s\n",grn_object_Name);
					fprintf(output,"Request Pending with					: %s\n","---");
					fprintf(output,"Test Request Status					: %s\n\n\n\n",tr_status_name);
					fprintf(output,"Thanks and Regards,\n","");
					fprintf(output,"PLM Team ","");
					
					//Calling shell for send mail
					//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/mail_notification_cr/testSendMail.sh %s %s %s > myoutput.txt &",outputFile,emailID_TP_Analyst,object_owner_email);
					//Calling shell for send mail
					tc_strcat(command,file_Path);
					tc_strcat(command,"testSendMail.sh");
					tc_strcat(command," ");
					tc_strcat(command,outputFile);
					tc_strcat(command," ");
					tc_strcat(command,emailID_TP_Analyst);
					tc_strcat(command," ");
					tc_strcat(command,object_owner_email);
					tc_strcat(command," > myoutput.txt &");

					printf("\n\tCommand : %s", command);
					system(command);
					printf("\n*************************End of Handler*********************\n");

		}
		//For FIR
		if(tc_strcmp(class_name,"T5_FirRevision")==0)
		{
			printf("\n******************** Target Object is ::::FIR *********************\n");
					//To Get Owener of TR
					tag_t TR_Owner			=	NULLTAG;
					tag_t TR_Owner_person	=	NULLTAG;
					char* person_name		=	NULL;
					char* TR_owner_email	=	NULL;

					EPM_get_participanttype ("T5_FIR_Analyst",&Patricipant_Type_FIR_Analyst);
					EPM_get_participanttype ("T5_FIR_Grphd",&Patricipant_Type_FIR_Grphd);
					EPM_get_participanttype ("T5_FIR_ClstrHd",&Patricipant_Type_FIR_ClstrHd);
					EPM_get_participanttype ("T5_FIR_DeptRev",&Patricipant_Type_FIR_DeptRev);
					CHECK_FAIL;
					

					//This is to get proper mails of Partticipants
					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_FIR_Analyst,&participant_count_FIR_Analyst,&participant_list_FIR_Analyst);
					printf("\n Number Of participant_count_FIR_Analyst:---[%d]",participant_count_FIR_Analyst);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_FIR_Grphd,&participant_count_FIR_Grphd,&participant_list_FIR_Grphd);
					printf("\n Number Of participant_count_FIR_Grphd:---[%d]",participant_count_FIR_Grphd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_FIR_ClstrHd,&participant_count_FIR_ClstrHd,&participant_list_FIR_ClstrHd);
					printf("\n Number Of participant_count_FIR_ClstrHd:---[%d]",participant_count_FIR_ClstrHd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_FIR_DeptRev,&participant_count_FIR_DeptRev,&participant_list_FIR_DeptRev);
					printf("\n Number Of participant_count_FIR_DeptRev:---[%d]",participant_count_FIR_DeptRev);fflush(stdout);
					CHECK_FAIL;

					// Getting respective mail IDs
					
					//FIR Analyst
					emailID_FIR_Analyst = getMailIDs(participant_count_FIR_Analyst,participant_list_FIR_Analyst);
					printf("\nemailID_FIR_Analystr :---%s\n", emailID_FIR_Analyst);
					
					//FIR GRPHD
					emailID_FIR_Grphd = getMailIDs(participant_count_FIR_Grphd,participant_list_FIR_Grphd);
					printf("\nemailID_FIR_Grphd :---%s\n", emailID_FIR_Grphd);
					
					//FIR CLSTRHD
					emailID_FIR_ClstrHd = getMailIDs(participant_count_FIR_ClstrHd,participant_list_FIR_ClstrHd);
					printf("\nemailID_FIR_ClstrHd :---%s\n", emailID_FIR_ClstrHd);
					
					//FIR DEPT REV
					emailID_FIR_DeptRev = getMailIDs(participant_count_FIR_DeptRev,participant_list_FIR_DeptRev);
					printf("\nemailID_FIR_DeptRev :---%s\n", emailID_FIR_DeptRev);

					// Preparting the CC List 
					//char *CC_MailList = (char*)MEM_alloc(sizeof(char) * 1500);
					CC_MailList = getCCMailIDs(emailID_FIR_Grphd,emailID_FIR_ClstrHd,emailID_FIR_DeptRev,"","");
					
					if (tc_strlen(mail_ID_1) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_1);
					}
						
					if (tc_strlen(mail_ID_2) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_2);
					}

					if (tc_strlen(mail_ID_3) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_3);
					}

					if (tc_strlen(mail_ID_4) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_4);
					}

					if (tc_strlen(mail_ID_5) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_5);
					}

					if (tc_strlen(mail_ID_6) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_6);
					}

					if (tc_strlen(mail_ID_7) != 0)
					{
							tc_strcat(CC_MailList, ",");
							tc_strcat(CC_MailList, mail_ID_7);
					}
					if (tc_strlen(mail_ID_8) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_8);
					}

					if (tc_strlen(mail_ID_9) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_9);
					}

					if (tc_strlen(mail_ID_10) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_10);
					}

					printf("\nCC Mail List %s",CC_MailList);

					//Getting TR no from FIR
					ifail = AOM_ask_value_string(rev_list,"t5_FirReqNo",&TestRequestNo);
					
					if(tc_strlen(TestRequestNo) == 0)
					{
						printf("*****\n No Test reqeuest no. found in FIR ******\n");
						return ifail;

					}
					//Getting TR Tag
					ifail = ITEM_find_item (TestRequestNo, &test_request_tag);
					CHECK_FAIL;
					//Getting TR latest Rev Tag
					ifail = ITEM_ask_latest_rev(test_request_tag,&test_request_rev_tag);
					CHECK_FAIL;

					//Need to get Owner of TR
					ifail = AOM_ask_owner(test_request_rev_tag,&TR_Owner);
					if(ifail ==ITK_ok){

					} else 
					{
						EMH_ask_error_text(ifail,&error_text);
						printf("\nError %s", error_text);
					}
					ifail = SA_ask_user_person(TR_Owner,&TR_Owner_person);
					if(ifail ==ITK_ok){

					} else 
					{
						EMH_ask_error_text(ifail,&error_text);
						printf("\nError %s", error_text);
					}
					
					ifail =SA_ask_person_name2(TR_Owner_person,&person_name);
					printf("\nPerson Name %s",person_name);
					//fprintf(output,"TR_Creator		%s\n",person_name);

					ifail =SA_ask_person_email_address(TR_Owner_person,&TR_owner_email);
					printf("\nTR Owner's e-mail:-- %s",TR_owner_email);


					//Getting Requried Properties of TR for shell.
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqDomain",&Rq_Domain);
					///fprintf(output,"t5_RqDomain		%s\n",Rq_Domain);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_BU",&BU);
					//fprintf(output,"t5_BU			%s\n",BU);
					ifail = AOM_ask_value_string(test_request_rev_tag,"object_string",&TR_id);
					//fprintf(output,"item_id			%s\n",TR_id);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqProjCode",&project_code);
					//fprintf(output,"t5_RqProjCode		%s\n",project_code);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqProjDes",&proj_desc);
					//fprintf(output,"t5_RqProjDes		%s\n",proj_desc);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_WBS",&wbs_details);
					//fprintf(output,"t5_WBS			%s\n",wbs_details);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqDesStatus",&dr_status);
					//fprintf(output,"t5_RqDesStatus		%s\n",dr_status);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqVehStage",&veh_sys_stage);
					//fprintf(output,"t5_RqVehStage		%s\n",veh_sys_stage);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqAggregate",&aggregate);
					//fprintf(output,"t5_RqAggregate		%s\n",aggregate);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_TestSubGrp",&testing_sub_group);
					//fprintf(output,"t5_TestSubGrp		%s\n",testing_sub_group);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqInvType",&inv_type);
					//fprintf(output,"t5_RqInvType		%s\n",inv_type);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqBGHistory",&bacg_history);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqReqDep",&request_dept);
					//fprintf(output,"t5_RqReqDep		%s\n",request_dept);
					
					//this is to get release status
					ifail = WSOM_ask_release_status_list (test_request_rev_tag, &count_status, &status_list);
					if(count_status > 0)
					{
						for(h=0;h<count_status;h++)
						{
							ifail = AOM_ask_value_string (status_list[h], "object_name", &tr_status_name);
						}
					}
					ifail = AOM_ask_value_string(rev_list,"object_string",&fir_object_Name);
					tc_strcpy(grn_object_Name,"");

					/// Creating i/p file for shell
					fprintf(output,"To:%s\n",TR_owner_email);
					fprintf(output,"CC:%s\n",CC_MailList);
					fprintf(output,"Subject: FIR Released for :%s\n",TR_id);
					fprintf(output,"Dear Sir,\n\n","");
					fprintf(output,"FIR released against					: %s\n\n\n",TR_id);
					fprintf(output,"Request Domain					: %s\n",Rq_Domain);
					fprintf(output,"Business Unit						: %s\n",BU);
					fprintf(output,"Request Number					: %s\n",TR_id);
					fprintf(output,"Project Code						: %s\n",project_code);
					fprintf(output,"Project Description					: %s\n",proj_desc);
					fprintf(output,"WBS details						: %s\n",wbs_details);
					fprintf(output,"Design Status						: %s\n",dr_status);
					fprintf(output,"Vehicle/System Stage/n(mule,alpha,Beta,PO,PP,etc)	: %s\n",veh_sys_stage);
					
					fprintf(output,"Aggregates						: %s\n",aggregate);
					fprintf(output,"Testing Sub Group					: %s\n",testing_sub_group);
					fprintf(output,"Investigation Type/Reason for Test			: %s\n",inv_type);
					fprintf(output,"Background/History					: %s\n",bacg_history);
					fprintf(output,"Creator							: %s\n",person_name);
					fprintf(output,"Requesting Dept					: %s\n",request_dept);
					fprintf(output,"FIR number						: %s\n",fir_object_Name);
					fprintf(output,"Green Report						: %s\n",grn_object_Name);
					fprintf(output,"Request Pending with					: %s\n","---");
					fprintf(output,"Test Request Status					: %s\n\n\n\n",tr_status_name);
					fprintf(output,"Thanks and Regards,\n","");
					fprintf(output,"PLM Team ","");
					
					// Calling shell for send mail
					//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/mail_notification_cr/testSendMail.sh %s %s %s > myoutput.txt &",outputFile,emailID_FIR_Analyst,TR_owner_email);
					tc_strcat(command,file_Path);
					tc_strcat(command,"testSendMail.sh");
					tc_strcat(command," ");
					tc_strcat(command,outputFile);
					tc_strcat(command," ");
					tc_strcat(command,emailID_FIR_Analyst);
					tc_strcat(command," ");
					tc_strcat(command,TR_owner_email);
					tc_strcat(command," > myoutput.txt &");

					printf("\n\tCommand : %s", command);
					system(command);
					printf("\n*************************End of Handler*********************\n");

		}
		//For GRN Report
		if(tc_strcmp(class_name,"T5_GrnRepRevision")==0)
		{
			printf("\n******************* Target Object is ::::GREEN REPORT **********************\n");

					//To Get Owener of TR
					tag_t TR_Owner			=	NULLTAG;
					tag_t TR_Owner_person	=	NULLTAG;
					char* person_name		=	NULL;
					char* TR_owner_email	=	NULL;

					EPM_get_participanttype ("T5_GR_Analyst",&Patricipant_Type_GR_Analyst);
					EPM_get_participanttype ("T5_GR_Grphd",&Patricipant_Type_GR_Grphd);
					EPM_get_participanttype ("T5_GR_ClstrHd",&Patricipant_Type_GR_ClstrHd);
					EPM_get_participanttype ("T5_GR_DeptRev",&Patricipant_Type_GR_DeptRev);
					CHECK_FAIL;


					//This is to get proper mails of Partticipants
					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_GR_Analyst,&participant_count_GR_Analyst,&participant_list_GR_Analyst);
					printf("\n Number Of participant_count_GR_Analyst:---[%d]",participant_count_GR_Analyst);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_GR_Grphd,&participant_count_GR_Grphd,&participant_list_GR_Grphd);
					printf("\n Number Of participant_count_GR_Grphd:---[%d]",participant_count_GR_Grphd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_GR_ClstrHd,&participant_count_GR_ClstrHd,&participant_list_GR_ClstrHd);
					printf("\n Number Of participant_count_GR_ClstrHd:---[%d]",participant_count_GR_ClstrHd);fflush(stdout);
					CHECK_FAIL;

					ifail = ITEM_rev_ask_participants(rev_list,Patricipant_Type_GR_DeptRev,&participant_count_GR_DeptRev,&participant_list_GR_DeptRev);
					printf("\n Number Of participant_count_GR_DeptRev:---[%d]",participant_count_GR_DeptRev);fflush(stdout);
					CHECK_FAIL;

					// Getting respective mail IDs
					//GRN Analyst
					emailID_GR_Analyst = getMailIDs(participant_count_GR_Analyst,participant_list_GR_Analyst);
					printf("\nemailID_GR_Analyst :---%s\n", emailID_GR_Analyst);
					
					//GRN  GRPHD
					emailID_GR_Grphd = getMailIDs(participant_count_GR_Grphd,participant_list_GR_Grphd);
					printf("\nemailID_GR_Grphd :---%s\n", emailID_GR_Grphd);
					
					//GRN CLSTRHD
					emailID_GR_ClstrHd = getMailIDs(participant_count_GR_ClstrHd,participant_list_GR_ClstrHd);
					printf("\nemailID_GR_ClstrHd :---%s\n", emailID_GR_ClstrHd);
					
					//GRN DEPT REV
					emailID_GR_DeptRev = getMailIDs(participant_count_GR_DeptRev,participant_list_GR_DeptRev);
					printf("\nemailID_GR_DeptRev :---%s\n", emailID_GR_DeptRev);

					// Preparting the CC List 
					//char *CC_MailList = (char*)MEM_alloc(sizeof(char) * 1500);
					CC_MailList = getCCMailIDs(emailID_GR_Grphd,emailID_GR_ClstrHd,emailID_GR_DeptRev,"","");
					
					if (tc_strlen(mail_ID_1) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_1);
					}
						
					if (tc_strlen(mail_ID_2) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_2);
					}

					if (tc_strlen(mail_ID_3) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_3);
					}

					if (tc_strlen(mail_ID_4) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_4);
					}

					if (tc_strlen(mail_ID_5) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_5);
					}

					if (tc_strlen(mail_ID_6) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_6);
					}

					if (tc_strlen(mail_ID_7) != 0)
					{
							tc_strcat(CC_MailList, ",");
							tc_strcat(CC_MailList, mail_ID_7);
					}
					if (tc_strlen(mail_ID_8) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_8);
					}

					if (tc_strlen(mail_ID_9) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_9);
					}

					if (tc_strlen(mail_ID_10) != 0)
					{
						tc_strcat(CC_MailList, ",");
						tc_strcat(CC_MailList, mail_ID_10);
					}

					printf("\nCCMail List %s",CC_MailList);

					//Getting TR no from GRN 
					ifail = AOM_ask_value_string(rev_list,"t5_RqNosGr",&TestRequestNo);
					
					if(tc_strlen(TestRequestNo) == 0)
					{
						printf("*****\n No Test reqeuest no. found in GRN ******\n");
						return ifail;

					}
					//Getting TR Tag
					ifail = ITEM_find_item (TestRequestNo, &test_request_tag);
					CHECK_FAIL;
					//Getting TR latest Rev Tag
					ifail = ITEM_ask_latest_rev(test_request_tag,&test_request_rev_tag);
					CHECK_FAIL;

					//Need to get Owner of TR
					ifail = AOM_ask_owner(test_request_rev_tag,&TR_Owner);
					if(ifail ==ITK_ok){

					} else 
					{
						EMH_ask_error_text(ifail,&error_text);
						printf("\nError %s", error_text);
					}
					ifail = SA_ask_user_person(TR_Owner,&TR_Owner_person);
					if(ifail ==ITK_ok){

					} else 
					{
						EMH_ask_error_text(ifail,&error_text);
						printf("\nError %s", error_text);
					}
					
					ifail =SA_ask_person_name2(TR_Owner_person,&person_name);
					printf("\nPerson Name %s",person_name);
					//fprintf(output,"TR_Creator		%s\n",person_name);

					ifail =SA_ask_person_email_address(TR_Owner_person,&TR_owner_email);
					printf("\nTR Owner's e-mail:-- %s",TR_owner_email);

					//Getting Requried Properties of TR for shell.
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqDomain",&Rq_Domain);
					///fprintf(output,"t5_RqDomain		%s\n",Rq_Domain);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_BU",&BU);
					//fprintf(output,"t5_BU			%s\n",BU);
					ifail = AOM_ask_value_string(test_request_rev_tag,"object_string",&TR_id);
					//fprintf(output,"item_id			%s\n",TR_id);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqProjCode",&project_code);
					//fprintf(output,"t5_RqProjCode		%s\n",project_code);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqProjDes",&proj_desc);
					//fprintf(output,"t5_RqProjDes		%s\n",proj_desc);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_WBS",&wbs_details);
					//fprintf(output,"t5_WBS			%s\n",wbs_details);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqDesStatus",&dr_status);
					//fprintf(output,"t5_RqDesStatus		%s\n",dr_status);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqVehStage",&veh_sys_stage);
					//fprintf(output,"t5_RqVehStage		%s\n",veh_sys_stage);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqAggregate",&aggregate);
					//fprintf(output,"t5_RqAggregate		%s\n",aggregate);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_TestSubGrp",&testing_sub_group);
					//fprintf(output,"t5_TestSubGrp		%s\n",testing_sub_group);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqInvType",&inv_type);
					//fprintf(output,"t5_RqInvType		%s\n",inv_type);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqBGHistory",&bacg_history);
					ifail = AOM_ask_value_string(test_request_rev_tag,"t5_RqReqDep",&request_dept);
					//fprintf(output,"t5_RqReqDep		%s\n",request_dept);
					
					//this is to get release status
					ifail = WSOM_ask_release_status_list (test_request_rev_tag, &count_status, &status_list);
					if(count_status > 0)
					{
						for(h=0;h<count_status;h++)
						{
							ifail = AOM_ask_value_string (status_list[h], "object_name", &tr_status_name);
						}
					}
					ifail = AOM_ask_value_string(rev_list,"object_string",&grn_object_Name);
					tc_strcpy(fir_object_Name,"");

					/// Creating i/p file for shell
					fprintf(output,"To:%s\n",TR_owner_email);
					fprintf(output,"CC:%s\n",CC_MailList);
					fprintf(output,"Subject: Green Report released for :%s\n",TR_id);
					fprintf(output,"Dear Sir,\n\n","");
					fprintf(output,"Green Report is released against				: %s\n",TR_id);
					fprintf(output,"Request Domain					: %s\n",Rq_Domain);
					fprintf(output,"Business Unit						: %s\n",BU);
					fprintf(output,"Request Number					: %s\n",TR_id);
					fprintf(output,"Project Code						: %s\n",project_code);
					fprintf(output,"Project Description					: %s\n",proj_desc);
					fprintf(output,"WBS details						: %s\n",wbs_details);
					fprintf(output,"Design Status						: %s\n",dr_status);
					fprintf(output,"Vehicle/System Stage/n(mule,alpha,Beta,PO,PP,etc)	: %s\n",veh_sys_stage);
					
					fprintf(output,"Aggregates						: %s\n",aggregate);
					fprintf(output,"Testing Sub Group					: %s\n",testing_sub_group);
					fprintf(output,"Investigation Type/Reason for Test			: %s\n",inv_type);
					fprintf(output,"Background/History					: %s\n",bacg_history);
					fprintf(output,"Creator							: %s\n",person_name);
					fprintf(output,"Requesting Dept					: %s\n",request_dept);
					fprintf(output,"FIR number						: %s\n",fir_object_Name);
					fprintf(output,"Green Report						: %s\n",grn_object_Name);
					fprintf(output,"Request Pending with					: %s\n","---");
					fprintf(output,"Test Request Status					: %s\n\n\n\n",tr_status_name);
					fprintf(output,"Thanks and Regards,\n","");
					fprintf(output,"PLM Team ","");
				
					// Calling shell for send mail
					//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/mail_notification_cr/testSendMail.sh %s %s %s > myoutput.txt &",outputFile,emailID_GR_Analyst,TR_owner_email);
					tc_strcat(command,file_Path);
					tc_strcat(command,"testSendMail.sh");
					tc_strcat(command," ");
					tc_strcat(command,outputFile);
					tc_strcat(command," ");
					tc_strcat(command,emailID_GR_Analyst);
					tc_strcat(command," ");
					tc_strcat(command,TR_owner_email);
					tc_strcat(command," > myoutput.txt &");

					printf("\n\tCommand : %s", command);
					system(command);
					printf("\n*************************End of Handler*********************\n");
		}

	}
	// Need to free memory here
	if(person_name != NULL)
			MEM_free(person_name);
	
		if(object_name != NULL)
			MEM_free(object_name);

		if(participant_list_TR_Manager != NULL)
			MEM_free(participant_list_TR_Manager);

		if(participant_list_TR_ChfEng != NULL)
			MEM_free(participant_list_TR_ChfEng);

		if(participant_list_TR_VatsRev != NULL)
			MEM_free(participant_list_TR_VatsRev);

		if(participant_list_TR_GrpHd != NULL)
			MEM_free(participant_list_TR_GrpHd);

		if(participant_list_TR_ClstrHd != NULL)
			MEM_free(participant_list_TR_ClstrHd);

		if(participant_list_TP_Analyst != NULL)
			MEM_free(participant_list_TP_Analyst);

		if(emailID_TR_Manager != NULL)
			MEM_free(emailID_TR_Manager);

		if(emailID_TR_ChfEng != NULL)
			MEM_free(emailID_TR_ChfEng);

		if(emailID_TR_VatsRev != NULL)
			MEM_free(emailID_TR_VatsRev);

		if(emailID_TR_GrpHd != NULL)
			MEM_free(emailID_TR_GrpHd);

		if(emailID_TR_ClstrHd != NULL)
			MEM_free(emailID_TR_ClstrHd);

		if(emailID_TP_Analyst != NULL)
			MEM_free(emailID_TP_Analyst);


		if(emailID_FIR_Analyst != NULL)
			MEM_free(emailID_FIR_Analyst);

		if(emailID_FIR_Grphd != NULL)
			MEM_free(emailID_FIR_Grphd);

		if(emailID_FIR_ClstrHd != NULL)
			MEM_free(emailID_FIR_ClstrHd);

		if(emailID_FIR_DeptRev != NULL)
			MEM_free(emailID_FIR_DeptRev);

		if(emailID_GR_Analyst != NULL)
			MEM_free(emailID_GR_Analyst);

		if(emailID_GR_Grphd != NULL)
			MEM_free(emailID_GR_Grphd);

		if(emailID_GR_ClstrHd != NULL)
			MEM_free(emailID_GR_ClstrHd);

		if(emailID_GR_DeptRev != NULL)
			MEM_free(emailID_GR_DeptRev);

		if(CC_MailList != NULL)
			MEM_free(CC_MailList);

		if(Rq_Domain != NULL)
			MEM_free(Rq_Domain);

		if(BU != NULL)
			MEM_free(BU);

		if(TR_id != NULL)
			MEM_free(TR_id);

		if(project_code != NULL)
			MEM_free(project_code);

		if(proj_desc != NULL)
			MEM_free(proj_desc);

		if(wbs_details != NULL)
			MEM_free(wbs_details);

		if(dr_status != NULL)
			MEM_free(dr_status);

		if(veh_sys_stage != NULL)
			MEM_free(veh_sys_stage);

		if(aggregate != NULL)
			MEM_free(aggregate);

		if(testing_sub_group != NULL)
			MEM_free(testing_sub_group);

		if(inv_type != NULL)
			MEM_free(inv_type);

		if(bacg_history != NULL)
			MEM_free(bacg_history);
		//MEM_free(creator);
		if(request_dept != NULL)
			MEM_free(request_dept);

		if(tr_status_name != NULL)
			MEM_free(tr_status_name);
			
		if(fir_object_Name != NULL)
			MEM_free(fir_object_Name);

		if(grn_object_Name != NULL)
			MEM_free(grn_object_Name);
	
	//Closing and remvoing the file
	//remove(outputFile);
	fclose(output);
	return ifail;

}
//This method will retrun complete mailIds of participants

char* getMailIDs(int participants_count, tag_t *participants_list)
{
   char *tempMail = (char*) MEM_alloc(sizeof(char) *10000);
   char *mailID = (char*) MEM_alloc(sizeof(char) *10000);
   int a = 0;
   int ifail = ITK_ok;

   for (a = 0; a < participants_count; a++)
   {
      ifail = AOM_ask_value_string(participants_list[a], "fnd0AssigneeEmail", &tempMail);

      if (tc_strlen(mailID) == 0)
      {
         if (tc_strlen(tempMail) == 0) {}
         else
         {
            tc_strcpy(mailID, tempMail);
         }

      }
      else
      {
         if (tc_strlen(tempMail) == 0) {}
         else
         {
            tc_strcat(mailID, ",");
            tc_strcat(mailID, tempMail);
         }
      }
   }
   //printf("\nIn getMailIDs funtion %s",mailID);
   return mailID;
}

//This method will retrun the mail ID of CC List 
char* getCCMailIDs(char *mail1, char *mail2, char *mail3, char *mail4, char *mail5)
{
	char *tmp_cc_list = (char*)MEM_alloc(sizeof(char) * 10000);
	//printf("\n In Get CC Mail List function.");

   if (tc_strlen(mail1) != 0)
   {
      tc_strcpy(tmp_cc_list, mail1);
   }

   if (tc_strlen(mail2) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail2);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail2);
      }
   }

   if (tc_strlen(mail3) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail3);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail3);
      }
   }

   if (tc_strlen(mail4) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail4);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail4);
      }
   }

   if (tc_strlen(mail5) != 0)
   {
      if (tc_strlen(tmp_cc_list) != 0)
      {
         tc_strcat(tmp_cc_list, ",");
         tc_strcat(tmp_cc_list, mail5);

      }
      else
      {
         tc_strcpy(tmp_cc_list, mail5);
      }
   }
   //printf("\n CC Mail List : %s",tmp_cc_list);
   return tmp_cc_list;
}
extern int TDM_register_method(int *decision, va_list args)
{
   

   int ifail=0;
   //METHOD_id_t  method1 ;
   METHOD_id_t  method_DesRevRel ;
   METHOD_id_t  method_Fir ;
   *decision = ALL_CUSTOMIZATIONS;
   tag_t objTag = va_arg(args, tag_t); 


   if(ITK_ok ==  EPM_register_rule_handler ("TDM_CHK_CE_Manager","Validate the Assignment of  Assign CE Reviewer and Manger By Creator", (EPM_rule_handler_t) TR_chk_assigned_participants))
   {
		printf("\t\n Registered Rule Handler TDM_CHK_CE_Manager\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler TDM_CHK_CE_Manager\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("TDM_CHK_TR_ANALYST","Validate the Assignment of  Assign Analyst By GroupHead Reviewer", (EPM_rule_handler_t) TR_chk_assigned_TrAnalyst))
   {
		printf("\t\n Registered Rule Handler TDM_CHK_TR_ANALYST\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler TDM_CHK_TR_ANALYST\n");fflush(stdout);
   }

     if(ITK_ok ==  EPM_register_rule_handler ("TDM_CHK_TR_CLOSE","Validate for test Request Closed", (EPM_rule_handler_t) TR_chk_TR_Closed))
   {
		printf("\t\n Registered Rule Handler TDM_CHK_TR_CLOSE\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler TDM_CHK_TR_CLOSE\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("TDM_CHK_TR_Submit","Validate for TestRequest Submisson", (EPM_rule_handler_t) Chk_TR_active))
   {
		printf("\t\n Registered Rule Handler TDM_CHK_TR_Submit\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler TDM_CHK_TR_Submit\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("TDM_CHK_TR_TP","Validate the Assignment of  Create testplan ", (EPM_rule_handler_t) TR_CHK_TP))
   {
		printf("\t\n Registered Rule Handler TDM_CHK_TR_TP\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler TDM_CHK_TR_TP\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("TDM_CHK_TR_FIR_GR","Validate the Assignment of  Create FIR/Quality Documents ", (EPM_rule_handler_t) TR_CHK_FIR_GR))
   {
		printf("\t\n Registered Rule Handler TDM_CHK_TR_FIR_GR\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler TDM_CHK_TR_FIR_GR\n");fflush(stdout);
   }


   if(ITK_ok ==  EPM_register_action_handler ("TR_Assign_Particpants","Assign the Test Request Participants", (EPM_action_handler_t) Assign_Particpants_TestReqRev))
   {
		printf("\t\n Registered action Handler TR_Assign_Particpants\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler TR_Assign_Particpants\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_action_handler ("CTR_Assign_Particpants","Assign the CTR Participants", (EPM_action_handler_t) Assign_Particpants_CTR))
   {
		printf("\t\n Registered action Handler CTR_Assign_Particpants\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler CTR_Assign_Particpants\n");fflush(stdout);
   }

    if(ITK_ok ==  EPM_register_action_handler ("TDM_Assign_TP_FIR_GR","Assign the Test Plan/FIR/Green Report Participants", (EPM_action_handler_t) Assign_Particpants_TP_FIR_GR))
   {
		printf("\t\n Registered action Handler TDM_Assign_TP_FIR_GR\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler TDM_Assign_TP_FIR_GR\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_action_handler ("TDM_Stamp_GH","Stamp GH and CH on TDm Obj", (EPM_action_handler_t) Stamp_GH))
   {
		printf("\t\n Registered action Handler TDM_Stamp_GH_CH\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler TDM_Stamp_GH_CH\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_action_handler ("TDM_Stamp_CH","Stamp GH and CH on TDm Obj", (EPM_action_handler_t) Stamp_CH))
   {
		printf("\t\n Registered action Handler TDM_Stamp_CH\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler TDM_Stamp_CH\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_action_handler ("TDM_Stamp_ANLYST","Stamp Analyst on TDm Obj", (EPM_action_handler_t) Stamp_Analyst))
   {
		printf("\t\n Registered action Handler TDM_Stamp_CH\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler TDM_Stamp_CH\n");fflush(stdout);
   }

    if(ITK_ok ==  EPM_register_action_handler ("TDM_Auto_Report","Auto generation of Report", (EPM_action_handler_t) Auto_Report))
   {
		printf("\t\n Registered action Handler TDM_Auto_Report\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler TDM_Auto_Report\n");fflush(stdout);
   }
   //CR-FY22-0259: Added on 28-04-2022 By Kirtikumar Thakur
     if(ITK_ok ==  EPM_register_action_handler ("TDM_Mail_Notification","Mail notification for close looping", (EPM_action_handler_t) Mail_Notification))
   {
		printf("\t\n Registered action Handler TDM_Mail_Notification\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register action Handler TDM_Mail_Notification\n");fflush(stdout);
   }


	ifail = METHOD_find_method("T5_TR_DesRev_Rel", IMAN_save_msg, &method_DesRevRel);
	if (method_DesRevRel.id != NULLTAG)
	{
			ifail = METHOD_add_action(method_DesRevRel, METHOD_post_action_type, (METHOD_function_t) createDesRevRelPost, NULL)!=ITK_ok;
			
			printf("\nrrrrrrrrRegistered as Post-Action for T5_TR_TP_REL Creation\n");fflush(stdout);
	}
	else
	{
		printf("\nMethod not T5_TR_TP_REL found!TC_save_msg\n");fflush(stdout);
	}

	

   
   return ITK_ok;
}

int TDM_ReportFun( void *return_data )
{
	int status;
	int				ifail 						= ITK_ok;
	char			*TestRqObjNm					= NULL;
	char			*TestRqType					= NULL;
	char			*output						= NULL;
	char			*FileStr						= NULL;
	char			*ExePath						= NULL;
	char mainFile[300];
	char command[1000];
	char docFile[300];
	char docFileM[300];
	char docFileD[300];
	const char *cTemp="item_id";
	tag_t *tags_found = NULL;
	int n_tags_found= 0;
	//char **values = (char **) MEM_alloc(1 * sizeof(char *));
	FileStr=MEM_alloc(1000);
	tag_t *transfermodes=NULLTAG;
	int transfermodeCnt=0;
	tag_t PLMSession=NULLTAG;
	tag_t TDM_rev_tag= NULLTAG;
	char* TestRqObjNm1=NULL;
	char* TestRqObjNm2=NULL;


	USERARG_get_string_argument(&TestRqObjNm);
	USERARG_get_string_argument(&TestRqType);

	printf("\n in TDM_ReportFun function3");fflush(stdout);

	
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;

	ifail = POM_get_user(&username,&user_tag);
	printf("\n\t Starting  TDM_ReportFun for username :%s....\n",username);fflush(stdout);

	
	printf("\n Recieved Input argument in ITK TDM_ReportFun()3: %s | %s | ",TestRqObjNm,TestRqType);fflush(stdout);
	//ITK_set_bypass(true);
	const char *values[1];
	values[0] = TestRqObjNm;
				
	CALLAPI(ITEM_find_items_by_key_attributes(1,&cTemp, values, &n_tags_found, &tags_found));
	printf("\n TDM_ReportFun function obj1 count <%d>",n_tags_found);fflush(stdout);

	if (n_tags_found==1)
	{
		
		//CALLAPI(ITEM_find_revision(tags_found[0],"A*1",&TDM_rev_tag)) ;
		CALLAPI(ITEM_ask_latest_rev (tags_found[0], &TDM_rev_tag)) ;
		if (TDM_rev_tag!=NULLTAG)
		{
			
			STRNG_replace_str(TestRqObjNm,"/","_",&TestRqObjNm1);
			STRNG_replace_str(TestRqObjNm1,"(","_",&TestRqObjNm2);
			STRNG_replace_str(TestRqObjNm2,")","_",&FileStr);
			printf("\n TDM_ReportFun1 function %s",FileStr);fflush(stdout);
			
			tc_strcpy(mainFile,"");
			tc_strcat(mainFile,"/tmp/");
			tc_strcat(mainFile,FileStr);
			tc_strcat(mainFile,".xml");
			TC_write_syslog("Main File = %s\n",mainFile);

			tc_strcpy(docFile,"");
			tc_strcat(docFile,"/tmp/");
			tc_strcat(docFile,FileStr);
			tc_strcat(docFile,".pdf");
			TC_write_syslog("Doc File = %s\n",docFile);

			printf("\n TDM_ReportFun function <%s> <%s>",mainFile,docFile);fflush(stdout);



			

			CALLAPI(PIE_create_session(&PLMSession));
			CALLAPI(PIE_session_set_file(PLMSession,mainFile));
			if (tc_strcmp(TestRqType,"T5_TestRqRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_TestRequest_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}
			else if (tc_strcmp(TestRqType,"T5_TestPlanRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_TestPlan_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}
			else if (tc_strcmp(TestRqType,"T5_CTRRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_CTR_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}
			else if (tc_strcmp(TestRqType,"T5_FirRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_FIR_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}
			else if (tc_strcmp(TestRqType,"T5_GrnRepRevision")==0)
			{
				CALLAPI(PIE_find_transfer_mode2("tm_GrnRep_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			}

			
			CALLAPI(PIE_session_set_transfer_mode(PLMSession,transfermodes[0]));
			CALLAPI(PIE_session_export_objects(PLMSession,1,&TDM_rev_tag));

			tag_t TagQryContObj = NULLTAG,*cntr_objects = NULL;
			int	n_entries = 2;
			int n_found = 0;

			char *qry_entries[2] = {"SYSCD", "SUBSYSCD"};
			char *qry_values[2] = {"TDM", "ReportPath"};

			if(QRY_find2("ControlObjQry", &TagQryContObj));

			if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
			printf("\n Objects for Query ControlObjQry == %d", n_found);fflush(stdout);

			if(n_found==1)
			{
				if( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&ExePath));
				printf("\n Information 1 Value == [%s]", ExePath);fflush(stdout);

				sprintf(command,"%s %s %s %s %s",ExePath,mainFile,docFile,TestRqType,FileStr);
				printf("\n Command to be run 1 == <%s>", command);fflush(stdout);
				system(command);

				if(access(docFile,F_OK)!=-1)
				{
					tag_t specRelationType_t=NULLTAG;
					tag_t PdfType=NULLTAG;
					tag_t PdfDataset=NULLTAG;
					tag_t PdfLatestDat_t=NULLTAG;
					tag_t specificationRel_t=NULLTAG;
					tag_t *DATASET=NULL;
					char* PdfObjdesc=NULL;
					char* PdfObjName=NULL;
					int DsCnt=0;

					printf("Doc file created successfully\n");fflush(stdout);
					CALLAPI(AE_find_datasettype2("PDF",&PdfType));
					if(PdfType == NULLTAG)
					{
						printf("Could not find Dataset Type PDF. Please check data model\n");fflush(stdout);
						
					}

					CALLAPI(GRM_find_relation_type("TC_Attaches",&specRelationType_t));

					CALLAPI(GRM_list_secondary_objects_only(TDM_rev_tag,specRelationType_t,&DsCnt,&DATASET));
					printf("\n TR DsCnt: %d",DsCnt);fflush(stdout);	
					int Icnt=0;
					tag_t RelationDS=NULLTAG;
					for (Icnt=0;Icnt<DsCnt ;Icnt++ )
					{
						CALLAPI(AOM_ask_value_string(DATASET[Icnt],"object_desc",&PdfObjdesc));
						CALLAPI(AOM_ask_value_string(DATASET[Icnt],"object_name",&PdfObjName));

						printf("\n TR DsCnt: <%s>   <%s>",PdfObjName,PdfObjdesc);fflush(stdout);	
						if ((tc_strcmp(PdfObjdesc,"TDM Pdf Report")==0) && (tc_strcmp(PdfObjName,FileStr)==0))
						{
							CALLAPI(GRM_find_relation(TDM_rev_tag,DATASET[Icnt],specRelationType_t,&RelationDS));
							if (RelationDS)
							{
								CALLAPI(GRM_delete_relation(RelationDS));
							}
						}
					}

					CALLAPI(AE_create_dataset_with_id(PdfType,FileStr,"TDM Pdf Report","","",&PdfDataset));
					CALLAPI(AE_save_myself(PdfDataset));
					CALLAPI(GRM_create_relation(TDM_rev_tag,PdfDataset,specRelationType_t,NULLTAG,&specificationRel_t));
					CALLAPI(AOM_load(specificationRel_t));
					CALLAPI(GRM_save_relation(specificationRel_t));
					CALLAPI(AE_ask_dataset_latest_rev(PdfDataset,&PdfLatestDat_t));
					CALLAPI(AOM_refresh(PdfLatestDat_t,TRUE));
					CALLAPI(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference",docFile,NULL,SS_BINARY));
					//CALLAPI(AE_save_myself(PdfLatestDat_t));

					AOM_save(PdfLatestDat_t);
					AOM_refresh(PdfLatestDat_t, FALSE);
					AOM_unload(PdfLatestDat_t);
					remove(docFile);
					output = "Report Generated Successfully and attached to revision in Attaches relationship"; 
				}			
				else
				{
					  printf("\n file object not found \n");fflush(stdout);
					  output = "Report not generated. Please contact PLM support team";
				}

			}
			else
			{
				  printf("\n Control object not found \n");fflush(stdout);
				  output = "Report not generated. Please contact PLM support team";
			}

			
			

			printf("\n End of program.....!!\n\n");fflush(stdout);
			
			//output = "Report fired Successfully";	

		}
		else
		{
			  printf("\n Item revision not not found \n");fflush(stdout);
			  output = "Report not generated. Please contact PLM support team";
		}
	}
	else
	{
		  printf("\n Item not found \n");fflush(stdout);
		  output = "Report not generated. Please contact PLM support team";
	}

	printf("\n End of program.....!!  %s \n\n",output);fflush(stdout);

	if (tc_strcmp(TestRqType,"T5_FirRevision")==0 || tc_strcmp(TestRqType,"T5_GrnRepRevision")==0 )
	{
		if (tc_strstr(output,"Successfully"))
		{
			tag_t attachRelationType=NULLTAG;
			tag_t specRelationType=NULLTAG;
			char   refname[AE_reference_size_c + 1];
			int AttCnt=0,iA=0,iS=0,refnumfnd_S=0,jS=0,SpecCnt=0,jA=0,refnumfnd_A=0;
			tag_t *DATASET_attch=NULL;
			tag_t *DATASET_spec=NULL;
			AE_reference_type_t     reftypeSpec;
			AE_reference_type_t     reftypeAttach;
			tag_t refobjectSpec=NULLTAG;
			tag_t refobjectAttach=NULLTAG;
			char   pathname[SS_MAXPATHLEN + 1];
			char   pathnameA[SS_MAXPATHLEN + 1];
			char   orig_nameSpec[IMF_filename_size_c + 1];
			char   orig_nameAttach[IMF_filename_size_c + 1];

			char *token = (char *) MEM_alloc( 10000 * sizeof(char) );
			printf("\n Inside merging Report.....!!  %s \n\n",TestRqType);fflush(stdout);

			tc_strcpy(token,"/tmp/");
			tc_strcat(token,FileStr);
			tc_strcat(token,"/");
			tc_strcat(token,FileStr);
			tc_strcat(token,"_Merge.pdf ");


			CALLAPI(GRM_find_relation_type("TC_Attaches",&attachRelationType));
			CALLAPI(GRM_find_relation_type("IMAN_specification",&specRelationType));
			CALLAPI(GRM_list_secondary_objects_only(TDM_rev_tag,attachRelationType,&AttCnt,&DATASET_attch));
			CALLAPI(GRM_list_secondary_objects_only(TDM_rev_tag,specRelationType,&SpecCnt,&DATASET_spec));

			printf("\n Inside merging Report.....!!  %d  %d \n\n",AttCnt,SpecCnt);fflush(stdout);
			
			for (iA=0;iA<AttCnt;iA++)
			{
				CALLAPI(AE_ask_dataset_ref_count(DATASET_attch[iA],&refnumfnd_A));
				printf("\n NMRef found......%d",refnumfnd_A);fflush(stdout);
				for(jA=0;jA<refnumfnd_A;jA++)
				{
					CALLAPI(AE_find_dataset_named_ref(DATASET_attch[iA],jA,refname,&reftypeAttach,&refobjectAttach));
					CALLAPI( IMF_ask_original_file_name(refobjectAttach,orig_nameAttach));
					printf("\n NMRef found str......%s",orig_nameAttach);fflush(stdout);
					sprintf(pathnameA,"/tmp/%s/%s",FileStr,orig_nameAttach);
					printf("\n pathnameA=%s\n",pathnameA);fflush(stdout);
					CALLAPI(IMF_export_file(refobjectAttach,pathnameA));
					tc_strcat(token,pathnameA);
					tc_strcat(token," ");
				}
				
			}
			for (iS=0;iS<SpecCnt;iS++ )
			{
				CALLAPI(AE_ask_dataset_ref_count(DATASET_spec[iS],&refnumfnd_S));
				printf("\n NMRef found......%d",refnumfnd_S);fflush(stdout);
				for(jS=0;jS<refnumfnd_S;jS++)
				{
					CALLAPI(AE_find_dataset_named_ref(DATASET_spec[iS],jS,refname,&reftypeSpec,&refobjectSpec));
					CALLAPI( IMF_ask_original_file_name(refobjectSpec,orig_nameSpec));
					sprintf(pathname,"/tmp/%s/%s",FileStr,orig_nameSpec);
					printf("\n pathnameJT=%s\n",pathname);fflush(stdout);
					CALLAPI(IMF_export_file(refobjectSpec,pathname));
					tc_strcat(token,pathname);
					tc_strcat(token," ");
				}
			}


			printf("\n File Name.....!!  %s \n\n",token);fflush(stdout);


			tag_t TagQryContObj1 = NULLTAG,*cntr_objects1 = NULL;
			int	n_entries1 = 2;
			int n_found1 = 0;
			char *ExePath						= NULL;

			char *qry_entries1[2] = {"SYSCD", "SUBSYSCD"};
			char *qry_values1[2] = {"TDM", "MergeReportPath"};

			if(QRY_find2("ControlObjQry", &TagQryContObj1));

			if(QRY_execute(TagQryContObj1, n_entries1, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
			printf("\n Objects for Query ControlObjQry == %d", n_found1);fflush(stdout);

			if(n_found1==1)
			{


				tc_strcpy(docFileM,"");
				tc_strcat(docFileM,"/tmp/");
				tc_strcat(docFileM,FileStr);
				tc_strcat(docFileM,"/");
				tc_strcat(docFileM,FileStr);
				tc_strcat(docFileM,"_Merge.pdf");
				TC_write_syslog("Doc docFileM = %s\n",docFileM);

				if( AOM_ask_value_string(cntr_objects1[0],"t5_Userinfo1",&ExePath));
				printf("\n Information 1 Value == [%s]", ExePath);fflush(stdout);
				char command1[10000];
				sprintf(command1,"%s %s",ExePath,token);
				printf("\n Command to be run 1 == <%s>", command1);fflush(stdout);
				system(command1);

				if(access(docFileM,F_OK)!=-1)
				{
					tag_t attcRelationType_M=NULLTAG;
					tag_t PdfType_M=NULLTAG;
					tag_t PdfDataset_M=NULLTAG;
					tag_t PdfLatestDat_M=NULLTAG;
					tag_t AttRel_M=NULLTAG;
					tag_t *DATASET_M=NULL;
					char* PdfObjdesc_M=NULL;
					char* PdfObjName_M=NULL;
					int DsCnt_M=0;

					printf("Doc file created successfully\n");fflush(stdout);
					CALLAPI(AE_find_datasettype2("PDF",&PdfType_M));
					if(PdfType_M == NULLTAG)
					{
						printf("Could not find Dataset Type PDF. Please check data model\n");fflush(stdout);
						
					}

					CALLAPI(GRM_find_relation_type("TC_Attaches",&attcRelationType_M));

					CALLAPI(GRM_list_secondary_objects_only(TDM_rev_tag,attcRelationType_M,&DsCnt_M,&DATASET_M));
					printf("\n TR DsCnt_M: %d",DsCnt_M);fflush(stdout);	
					int Icnt_M=0;
					tag_t RelationDS=NULLTAG;
					for (Icnt_M=0;Icnt_M<DsCnt_M ;Icnt_M++ )
					{
						CALLAPI(AOM_ask_value_string(DATASET_M[Icnt_M],"object_desc",&PdfObjdesc_M));
						CALLAPI(AOM_ask_value_string(DATASET_M[Icnt_M],"object_name",&PdfObjName_M));

						printf("\n TR DsCnt_M: <%s>   <%s>",PdfObjName_M,PdfObjdesc_M);fflush(stdout);	
						if ((tc_strcmp(PdfObjdesc_M,"TDM Pdf Report")==0) && (tc_strcmp(PdfObjName_M,FileStr)==0))
						{
							CALLAPI(GRM_find_relation(TDM_rev_tag,DATASET_M[Icnt_M],attcRelationType_M,&RelationDS));
							if (RelationDS)
							{
								CALLAPI(GRM_delete_relation(RelationDS));
							}
						}
					}

					CALLAPI(AE_create_dataset_with_id(PdfType_M,FileStr,"TDM Pdf Report","","",&PdfDataset_M));
					CALLAPI(AE_save_myself(PdfDataset_M));
					CALLAPI(GRM_create_relation(TDM_rev_tag,PdfDataset_M,attcRelationType_M,NULLTAG,&AttRel_M));
					CALLAPI(AOM_load(AttRel_M));
					CALLAPI(GRM_save_relation(AttRel_M));
					CALLAPI(AE_ask_dataset_latest_rev(PdfDataset_M,&PdfLatestDat_M));
					CALLAPI(AOM_refresh(PdfLatestDat_M,TRUE));
					CALLAPI(AE_import_named_ref(PdfLatestDat_M,"PDF_Reference",docFileM,NULL,SS_BINARY));
					//CALLAPI(AE_save_myself(PdfLatestDat_M));
					AOM_save(PdfLatestDat_M);
					AOM_refresh(PdfLatestDat_M, FALSE);
					AOM_unload(PdfLatestDat_M);
					remove(docFileM);
					output = "Report Generated Successfully and attached to revision in Attaches relationship"; 


				}			
				else
				{
					  printf("\n file object not found \n");fflush(stdout);
					  output = "Report not generated. Please contact PLM support team";
				}
			}



		}
		else
		{

		}
	}
	//ITK_set_bypass(false);
	*((char **) return_data) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

	strcpy( *((char **) return_data), output); 
	
	return ifail;
	/* Program Logic End*/
}

extern DLLAPI int TDM_ReportModule(METHOD_message_t *msg, va_list args)
{   
 	int nargs=2;
	int *inputArgTypes;	
	int retValueType;
        
	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));	
	inputArgTypes[0]=USERARG_STRING_TYPE;
	inputArgTypes[1]=USERARG_STRING_TYPE;
	retValueType=USERARG_STRING_TYPE;
	
	printf("\n User Service Call SuffixSelection....");fflush(stdout);
	
    
	USERSERVICE_register_method("TDM_Report_Service",(USER_function_t) TDM_ReportFun, nargs, inputArgTypes, retValueType);
    return ITK_ok;
}

extern DLLAPI int tm_tdm_register_callbacks()
{     
	 CUSTOM_register_exit("tm_tdm", "USER_init_module", (CUSTOM_EXIT_ftn_t) TDM_register_method);
	 CUSTOM_register_exit ("tm_tdm", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)TDM_ReportModule);

     printf("\n registered function tm_tdm\n");	fflush(stdout);

	 return ( ITK_ok );
}
