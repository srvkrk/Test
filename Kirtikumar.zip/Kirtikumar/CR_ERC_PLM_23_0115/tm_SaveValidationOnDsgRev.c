/****************************************************************************************************
*  File                 :		tm_SaveValidationOnDsgRev.c
*  Created By     :		Sudhir Srivastava
*  Created On    :		05-Sept-2011
*  Purpose         :		 Remove extra character from Desciption of Design and Design Revision.
*					This is called at pre action of save.
*
*  Modification History :
*  S.No		Date			CR		Modified By			Modification Notes
*	1		15/06/2012				Sharvari Karale		Added save_method_5 and save_method_4 for Attribute Mapping of Design Reision/CMI2Drawing
*	2		04/05/2016				Muktesh Girdhani	Removed file createpost (createpost.so) and added code in this file, Updation of NR;1 Revision done in this file.
*	3		08/08/2018				Mohan Tayade		New DFM-A DML introduction and validations/Live for DR-validations.
*	4		12/09/2016				Mohan Tayade		DFM-A module should be attached under Architecture module.
*	5		28/04/2019				Ashwini Yedake		Migration from hexavalent Cr-coated fasteners to trivalent Cr-coated fasteners in line with the validation in TcE for PVBU
*   6		17/07/2019				Ashwini Yedake		Dummy Component/Dummy Assembly /Component  parttype not allowed if for 12-digit part 9th and 10th digit is 01. It has to be assembly.
*   7		18/07/2019				Rupali Rane			Added save_method_Design_3 for new upgradation of IPEM 11.5.2 and Creo4
*   8		14/11/2019				Ashwini Yedake		Revise API change from ITEM_find_item to ITEM_find_items_by_key_attributes
*   9		02/01/2020				Ashwini Yedake		Extension of Fasteners related check for Nexon to TcUA
******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define ITK_Prjerr (EMH_USER_error_base + 8)
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/project.h>
#include <tccore/tc_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <bom/bom_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <sa/workcontext.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/sa_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <tc/preferences.h> //MBOM implementation for CV TZ-1.69
#define ITK_err 919006
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errStore1 (EMH_USER_error_base + 7)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define GRM_create_msg           "GRM_create"
int customStrStr();
/************************* Adi ****************/

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


//Ashwini- to query Obsolete part from Table if exist
char* QueryObsPart_Uses(char* ProjctcdeS)
{
	tag_t queryTag		= NULLTAG;
	tag_t *NewPartsSet	= NULLTAG;
	tag_t PrjCdObj		= NULLTAG;

	int n_entries = 1;
	int resultCount =0;

	char *ProjectCodeValS	= NULL;
	char *ProjectCodeValS1	= NULL;
	//char *qry_entries[2] = {"t5_Obspno","t5_AltPartInd"};
	//char *qry_entries[2] = {"Obspno","Alt Part Ind"};
	char *qry_entries[1] = {"Obspno"};
	char **qry_values = (char **) MEM_alloc(20 * sizeof(char *));

	printf("\nIn QueryObsPart_Uses"); fflush(stdout);
	printf("\nIn QueryObsPart_Uses ProjctcdeS = %s",ProjctcdeS); fflush(stdout);
	qry_values[0]=ProjctcdeS;
	//qry_values[1]="DELMAT";
	//qry_values[1]="";

	if(QRY_find("Cntrl_t5ObmPrt", &queryTag));
	if (queryTag)
	{
		printf("\nCntrl_t5ObmPrt... Found Query ControlObjects ");
		fflush(stdout);
	}
	else
	{
		printf("\n General Cntrl_t5ObmPrt...:Not Found Query ControlObjects\n");
	}

	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	printf("\n11 Unique General... Query resultCount :%d:\n", resultCount); fflush(stdout);

	if (resultCount > 0)
	{
		PrjCdObj = NewPartsSet[0];
		if(AOM_ask_value_string(PrjCdObj,"t5_Proalpno",&ProjectCodeValS) != ITK_ok);
		printf("\nIn ProjectCodeValS = %s",ProjectCodeValS); fflush(stdout);
		if(strcmp(ProjectCodeValS,"")!=0)
		{
			ProjectCodeValS1=ProjectCodeValS;
		}
		else
		{
			ProjectCodeValS1="PrtDelete";
		}
	}
	else
	{
		printf("\nIn ELSE...\n");fflush(stdout);
		ProjectCodeValS1 = "QryNotFound";
		printf("\nIn ELSE ProjectCodeValS1 = %s...\n",ProjectCodeValS1);fflush(stdout);
	}

	printf("\nIn ProjectCodeValS1 = %s",ProjectCodeValS1); fflush(stdout);
	return ProjectCodeValS1;
}

//Ashwini- to query Obsolete part from Table if exist
char* QueryObsPartOSPREY_Uses(char* ProjctcdeS)
{
	tag_t queryTag		= NULLTAG;
	tag_t *NewPartsSet	= NULLTAG;
	tag_t PrjCdObj		= NULLTAG;

	int n_entries = 2;
	int resultCount =0;

	char *ProjectCodeValS	= NULL;
	char *ProjectCodeValS1	= NULL;
	//char *qry_entries[2] = {"t5_Obspno","t5_AltPartInd"};
	char *qry_entries[2] = {"Obspno","Alt Part Ind"};
	//char *qry_entries[1] = {"Obspno"};
	char **qry_values = (char **) MEM_alloc(20 * sizeof(char *));

	printf("\nIn QueryObsPart_Uses"); fflush(stdout);
	printf("\nIn QueryObsPart_Uses ProjctcdeS = %s",ProjctcdeS); fflush(stdout);
	qry_values[0]=ProjctcdeS;
	qry_values[1]="OSPREY";
	//qry_values[1]="";

	//if(QRY_find("Cntrl_t5ObmPrt", &queryTag));
	if(QRY_find("Cntrl_t5ObmPrt_OSPRY", &queryTag));
	if (queryTag)
	{
		printf("\nCntrl_t5ObmPrt... Found Query ControlObjects ");
		fflush(stdout);
	}
	else
	{
		printf("\n General Cntrl_t5ObmPrt...:Not Found Query ControlObjects\n");
	}

	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	printf("\n11 Unique General... Query resultCount :%d:\n", resultCount); fflush(stdout);

	if (resultCount > 0)
	{
		ProjectCodeValS1="OSPREYPresnt";
//		PrjCdObj = NewPartsSet[0];
//		if(AOM_ask_value_string(PrjCdObj,"t5_Proalpno",&ProjectCodeValS) != ITK_ok);
//		printf("\nIn ProjectCodeValS = %s",ProjectCodeValS); fflush(stdout);
//		if(strcmp(ProjectCodeValS,"")!=0)
//		{
//			ProjectCodeValS1=ProjectCodeValS;
//		}
//		else
//		{
//			ProjectCodeValS1="PrtDelete";
//		}
	}
	else
	{
		printf("\nIn ELSE...\n");fflush(stdout);
		ProjectCodeValS1 = "OSPREYNTPresnt";
	}

	printf("\nIn ProjectCodeValS1 = %s",ProjectCodeValS1); fflush(stdout);
	return ProjectCodeValS1;
}
/************************* Adi ****************/

char* subString (char* mainStringf, int fromCharf, int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


//Vitthal :START: Validate Part Creation
int Validate_On_Creation(tag_t DesignRevision)
{
	char* sPartType;
	char* sStartPrtProd;
	char *sUserInfoVal = NULL;
	char *sDesGrp = NULL;

	tag_t
		TagQryContObjDsgGrp = NULLTAG,
		*cntr_objects = NULL;
	int	n_entries = 2;
	int n_found = 0;

	char *qry_entries[2] = {"SYSCD", "SUBSYSCD"};
    char *qry_values[2] = {"TOOLTYPE", "DESIGNGROUP"};

	if (AOM_ask_value_string(DesignRevision,"t5_PartType",&sPartType)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(DesignRevision,"t5_StartPartProduct",&sStartPrtProd)!=ITK_ok)   PrintErrorStack();
	if(	AOM_ask_value_string(DesignRevision,"t5_DesignGrp",&sDesGrp)!=ITK_ok);PrintErrorStack();

	printf("\n AOM_ask_value_string sPartType  %s sStartPrtProd  %s \n",sPartType,sStartPrtProd);fflush(stdout);

	 if(QRY_find2("ControlObjFindCadToolBasedOnDesGrp", &TagQryContObjDsgGrp));

	 if(QRY_execute(TagQryContObjDsgGrp, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	 printf("\n Objects for Query ControlObjFindCadToolBasedOnDesGrp == %d", n_found);fflush(stdout);

	 if(n_found==1)
	 {
		if( AOM_ask_value_string(cntr_objects[0],"t5_userinfo10",&sUserInfoVal));
		 printf("\n Information 10 Value == [%s] and User Enter Design Group :[%s]", sUserInfoVal,sDesGrp);fflush(stdout);
		if(tc_strstr(sUserInfoVal, sDesGrp) != NULL)
		{
			if(((strcmp(sPartType,"A")==0) ||(strcmp(sPartType,"C")==0) ||(strcmp(sPartType,"T")==0) ||(strcmp(sPartType,"G")==0)) && (tc_strcmp(sStartPrtProd,"")==0))return 1;
		}
	 }
	return 0;
}
//Vitthal :END: Validate Part Creation

// check milestone live project START
// int CheckMilestoneLive(char* sProject)
// {
	// int     Milston_rsltCount    = 0;
	// int     Milston_n_entry    = 1;
	// tag_t     *MilstonCntrlObjectTag                = NULLTAG;
	// tag_t     MilestoneqryTag                              = NULLTAG;
	// char    *Milston_qry_entry[1]  = {"SYSCD"};
	// char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	// char*     Milstoninfo1 = NULL;
	// char*     Milstoninfo2 = NULL;

	// printf("\n P: CheckMilestoneLive for project: %s \n", sProject);fflush(stdout);
	// //GETTING mileston obj.
	// if(QRY_find("ControlObjects", &MilestoneqryTag));
	// if (MilestoneqryTag)
	// {
		// printf("\n P1:Found Query MilestoneqryTag \n");fflush(stdout);
	// }
	// else
	// {
		// printf("\n P2:Not Found Query MilestoneqryTag \n");fflush(stdout);
	// }

	// Milston_qry_values2[0] = "Milston";
	// if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	// printf(" \n P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	// if(Milston_rsltCount > 0)
	// {
		// if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo1",&Milstoninfo1)!=ITK_ok)   PrintErrorStack();
		// printf("\n P4:Milstoninfo1 is : [%s]\n", Milstoninfo1);fflush(stdout);

		// if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo2",&Milstoninfo2)!=ITK_ok)   PrintErrorStack();
		// printf("\n P4:Milstoninfo2 is : [%s]\n", Milstoninfo2);fflush(stdout);

		// if((tc_strstr(Milstoninfo1,sProject)!=NULL)|| (tc_strstr(Milstoninfo2,sProject)!=NULL))
		// {
			// printf("\n P: It is MilestoneLive project: %s \n", sProject);fflush(stdout);
			// return 1;
		// }
		// else
		// {
			// printf("\n P: It is not MilestoneLive project: %s \n", sProject);fflush(stdout);
		// return 0;
		// }


		// return 0;
	// }
// }

int CheckMilestoneLive(char* sProject)
{
	int     Milston_rsltCount    = 0;
	int     Milston_n_entry    = 1;
	tag_t     *MilstonCntrlObjectTag                = NULLTAG;
	tag_t     MilstonCntrlObj                = NULLTAG;
	tag_t     MilestoneqryTag                              = NULLTAG;
	char    *Milston_qry_entry[1]  = {"SYSCD"};
	char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char*     Milstoninfo1 = NULL;
	char*     Milstoninfo2 = NULL;

	printf("\n P: CheckMilestoneLive for project: %s \n", sProject);fflush(stdout);
	//GETTING mileston obj.
	if(QRY_find("ControlObjects", &MilestoneqryTag));
	if (MilestoneqryTag)
	{
		printf("\n P1:Found Query MilestoneqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n P2:Not Found Query MilestoneqryTag \n");fflush(stdout);
	}

	Milston_qry_values2[0] = "Milston";
	if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	printf(" \n P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	int     MLPrjLive    = 0;
	if(Milston_rsltCount > 0)
	{
		for (MLPrjLive=0;MLPrjLive<Milston_rsltCount;MLPrjLive++ )
		{
			MilstonCntrlObj = MilstonCntrlObjectTag[MLPrjLive];
			if (AOM_ask_value_string(MilstonCntrlObj,"t5_Userinfo1",&Milstoninfo1)!=ITK_ok)   PrintErrorStack();
			printf("\n P4:Milstoninfo1 is : [%s]\n", Milstoninfo1);fflush(stdout);

			if (AOM_ask_value_string(MilstonCntrlObj,"t5_Userinfo2",&Milstoninfo2)!=ITK_ok)   PrintErrorStack();
			printf("\n P4:Milstoninfo2 is : [%s]\n", Milstoninfo2);fflush(stdout);

			if((tc_strstr(Milstoninfo1,sProject)!=NULL)|| (tc_strstr(Milstoninfo2,sProject)!=NULL))
			{
				printf("\n P: It is MilestoneLive project: %s \n", sProject);fflush(stdout);
				return 1;
				break;
			}
			else
			{
				printf("\n P: It is not MilestoneLive project: %s \n", sProject);fflush(stdout);
				return 0;
			}
		}
		return 0;
	}
	return 0;
}
// check milestone live project END
//start added on 29June2023 CR-FY24-0030
int CheckERCAccessLogin(tag_t Usr_tag)
{
	int     ac    = 0;
	int     Accessflag    = 0;
	int     AccessCount    = 0;
	
	char*	 AccessFound_name = NULL;
	tag_t	AccessFound_tg = NULLTAG;
	tag_t	*AccessFound = NULLTAG;

	tag_t	ERCGrpqryTag		= NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	int n_entry    = 1;
	int  rsltCount      =  0;
	char *ERCGrpinfo1 = NULL;
	char *ERCGrpinfo2 = NULL;
		
		if(QRY_find("ControlObjects", &ERCGrpqryTag));
		if (ERCGrpqryTag)
		{
			printf("\n CheckERCAccessLogin:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n CheckERCAccessLogin:Not Found Query ControlObjects \n");fflush(stdout);
		}

		qry_values2[0] = "CheckUserGrpRole";
		if(QRY_execute(ERCGrpqryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n CheckERCAccessLogin:rsltCount[%d]", rsltCount); fflush(stdout);
		
	if(rsltCount > 0)
	{
		if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&ERCGrpinfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n ERCGrpinfo1 is : [%s]\n", ERCGrpinfo1);fflush(stdout);

		//if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&ERCGrpinfo2)!=ITK_ok)   PrintErrorStack();
		//printf("\n ERCGrpinfo2 is : [%s]\n", ERCGrpinfo2);fflush(stdout);
		
		
		if (SA_find_groupmember_by_user(Usr_tag,&AccessCount,&AccessFound)!=ITK_ok)PrintErrorStack();
		printf("\n count of AccessCount: [%d]", AccessCount);fflush(stdout);
		for(ac=0;ac<AccessCount;ac++)
		{
			AccessFound_tg = AccessFound[ac];
			if (AOM_ask_value_string(AccessFound_tg,"object_name",&AccessFound_name)!=ITK_ok)   PrintErrorStack();
			printf("\n Actual Group Member AccessFound_name: [%s]", AccessFound_name);fflush(stdout);
			//if((tc_strstr(AccessFound_name,Supportinfo1)!=NULL)|| (tc_strstr(AccessFound_name,ERCGrpinfo2)!=NULL))
			//if(tc_strstr(AccessFound_name,Supportinfo1)!=NULL)
			if(tc_strstr(AccessFound_name, ERCGrpinfo1) != NULL)
			{
				Accessflag++;
				printf("\n AccessFound_name----: [%s][%d]", AccessFound_name,Accessflag);fflush(stdout);
				break;
			}
		}
		if(Accessflag >0)
		{
			printf("\n ERC access found.\n");fflush(stdout);
			return 0;
		}
		else
		{
			printf("\n ERC access not found. \n");fflush(stdout);
			return 1;
		}
	}

	return 0;
}

//end added on 29June2023 CR-FY24-0030

// Validate DR-MileStone START
int tm_PreviousRev_Milestone_Validate(tag_t rev_tag, char* value)
{
	int     count1    = 0;
	int     iij    = 0;
	char*     rev_id = NULL;
	char*     rev_num = NULL;
	char*     rell_status = NULL;
	char*     ML_Staus = NULL;
	tag_t 	*rev_listt 	= NULL;
	tag_t 	Partrev 	= NULLTAG;
	tag_t 	ITEM_tag 	= NULLTAG;

	if(AOM_ask_value_tag(rev_tag,"items_tag",&ITEM_tag)!=ITK_ok)   PrintErrorStack();

	if (ITEM_tag==NULLTAG)
	{
		printf("\n tm_PreviousRev_Milestone_Validate ITEM not found \n");fflush(stdout);
		return 0;
	}
		if(ITEM_list_all_revs(ITEM_tag, &count1, &rev_listt)!=ITK_ok)   PrintErrorStack();
		if(count1 > 0)
		{
			iij=0;
			for(iij=count1-1;iij>=0;iij--)
			{
				printf("\n Total rev rev_listt: %d.", count1);fflush(stdout);
				Partrev = rev_listt[iij];

				if(AOM_UIF_ask_value(Partrev,"item_id", &rev_num)!=ITK_ok)   PrintErrorStack();
				if(AOM_UIF_ask_value(Partrev,"item_revision_id", &rev_id)!=ITK_ok)   PrintErrorStack();
				if (AOM_UIF_ask_value(Partrev,"release_status_list", &rell_status)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(Partrev,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();

				printf("\n rev_id:%s and rell_status:%s", rev_id,rell_status);fflush(stdout);
				if(tc_strstr(rell_status, "ERC Released") !=NULL && tc_strcmp(value,ML_Staus)==0)
				{
					printf("\n for %s %s  milestone %s ",rev_num,rev_id,ML_Staus);fflush(stdout);
					return 1;
				}
			}
		}
		return 0;
}
// int tm_Validate_DR_Milestone_OnPart(tag_t rev_tag)
// {
	// int flag=0;
	// char *PrtDR = NULL;
	// char *ML_Staus = NULL;
	// char *ObjProject = NULL;
	// char *desRev = NULL;
	// char *DRinfo4 = NULL;
	// int IsMilestoneLiveFlag=0;
	// int n_entry    = 1;
	// int  rsltCount      =  0;

	// tag_t   qryTag     = NULLTAG;
	// tag_t   *CntrlObjectTag      = NULLTAG;
	// char   *qry_entry[1]  = {"SYSCD"};
	// char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	// if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok)PrintErrorStack();
	// //if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok)PrintErrorStack();

	// printf("\nProject stamped is : %s\n",ObjProject);fflush(stdout);
	// IsMilestoneLiveFlag=0;
	// IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	// printf("\n P3:IsMilestoneLiveFlag: %d",IsMilestoneLiveFlag);fflush(stdout);
	// if (IsMilestoneLiveFlag >0)
	// {
		// printf("\n project is live check part level Milestone validations");fflush(stdout);
		// if(QRY_find("ControlObjects", &qryTag));
		// if (qryTag)
		// {
			// printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
		// }
		// else
		// {
			// printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
		// }

		// qry_values2[0] = "CREVali";
		// if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		// printf(" \n CREVali:rsltCount 44:%d:", rsltCount); fflush(stdout);
		// if(rsltCount > 0)
		// {
			// if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&DRinfo4)!=ITK_ok)   PrintErrorStack();

			// printf("\n CREVali:DRinfo4:%s",DRinfo4);fflush(stdout);
		// }
		// if(tc_strstr(DRinfo4,"AHCHK1")==NULL)
		// {
			// /*UNV0        corresponds to DR1
			// UNV1      corresponds to DR1
			// Pre-UPV0       corresponds to DR1
			// UNV2           corresponds to DR2
			// UPV0           corresponds to DR2
			// UNV3          corresponds to DR2
			// UPV1           corresponds to DR2
			// UPV2                corresponds to DR2
			// UPV3            corresponds to DR3*/

			// printf("\n here0 ");fflush(stdout);
			// if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
			// if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();
			// if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
			// printf("\n  PrtDR: [%s] ML_Staus:[%s] REV [%s] \n",PrtDR,ML_Staus,desRev);fflush(stdout);
			// if (tc_strcmp(ML_Staus,"")==0)
			// {

				// flag=1;
				// return flag;
				// /*EMH_clear_errors();
				// EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
				// return ITK_err;*/
			// }
			// if(tc_strstr(desRev,"NR")!=NULL)
			// //if (tc_strcmp(desRev,"NR")==0)
			// {
				// // Check the initial value from controm object for initial value
				// int     Milston_rsltCount    = 0;
				// int     Milston_n_entry    = 1;
				// tag_t     *MilstonCntrlObjectTag                = NULLTAG;
				// tag_t     MilestoneqryTag                              = NULLTAG;
				// char    *Milston_qry_entry[1]  = {"SYSCD"};
				// char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
				// char*     Milstoninfo4 = NULL;

				// printf("\n P: CheckMileston initial value for project\n");fflush(stdout);
				// //GETTING mileston obj.
				// if(QRY_find("ControlObjects", &MilestoneqryTag));
				// if (MilestoneqryTag)
				// {
					// printf("\n Query MilestoneqryTag \n");fflush(stdout);
				// }
				// else
				// {
					// printf("\n Not Found Query MilestoneqryTag \n");fflush(stdout);
				// }

				// Milston_qry_values2[0] = "Milston";
				// if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
				// printf(" \n P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
				// if(Milston_rsltCount > 0)
				// {
					// if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo4",&Milstoninfo4)!=ITK_ok)   PrintErrorStack();
					// printf("\n P4:Milstoninfo4 is : [%s]\n", Milstoninfo4);fflush(stdout);

				// }

				// //
				// if(tc_strstr(Milstoninfo4,ML_Staus) !=NULL)
				// {
					// printf("\n Milestone ok update DR Value  \n"); fflush(stdout);
					// if(AOM_refresh(rev_tag,TRUE)!=ITK_ok);PrintErrorStack();

					// if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
					// {
						// //if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR1")!=ITK_ok);PrintErrorStack();
						// if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok);PrintErrorStack();
					// }
					// if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
					// {
						// //if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR2")!=ITK_ok);PrintErrorStack();
						// if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok);PrintErrorStack();
					// }
					// if(tc_strcmp(ML_Staus,"UPV3")==0)
					// {
						// //if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR3")!=ITK_ok);PrintErrorStack();
						// if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR3")!=ITK_ok);PrintErrorStack();
					// }
					// if(AOM_save(rev_tag)!=ITK_ok);PrintErrorStack();
					// if(AOM_refresh(rev_tag,FALSE)!=ITK_ok);PrintErrorStack();
					// if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					// printf("\n Milestone is [%s] and  Part DR is updated to [%s]  \n",ML_Staus,PrtDR);fflush(stdout);

				// }

				// else
				// {
					// //error since info4 value and milestone is not matching
					// /*EMH_clear_errors();
					// EMH_store_error_s1(EMH_severity_error,ITK_err," for NR revision Milestone Status should be as per Standards provided by PLM Team");
					// return ITK_err;*/
					// flag=5;
					// return flag;
				// }
			// }
			// else
			// {
					// printf("\n Milestone ok, update DR Value for other than NR  \n"); fflush(stdout);
					// //if(AOM_refresh(rev_tag,TRUE)!=ITK_ok);PrintErrorStack();
					// //if(AOM_refresh(rev_tag,TRUE)!=ITK_ok);PrintErrorStack();
					// if (AOM_lock(rev_tag)!=ITK_ok);PrintErrorStack();

					// if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
					// {
						// if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR1")!=ITK_ok);PrintErrorStack();
					// }
					// if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
					// {
						// if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR2")!=ITK_ok);PrintErrorStack();
					// }
					// if(tc_strcmp(ML_Staus,"UPV3")==0)
					// {
						// if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR3")!=ITK_ok);PrintErrorStack();
					// }
					// if(AOM_save(rev_tag)!=ITK_ok);PrintErrorStack();
					// if(AOM_unlock(rev_tag)!=ITK_ok);PrintErrorStack();
					// if(AOM_refresh(rev_tag,0)!=ITK_ok);PrintErrorStack();

					// if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
					// printf("\n for non NR Milestone is [%s] and  Part DR is updated to [%s]  \n",ML_Staus,PrtDR);fflush(stdout);
					// flag=0;
					// return flag;


			// }
		// }
	// }
// }

int tm_Update_DR_AsPerMilestone_OnPart(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *Revinfo2 = NULL;
	char *MLStatusinfo3 = NULL;
	char *MLStatusinfo4 = NULL;
	char *MLStatusinfo5 = NULL;
	char *PrjCodeinfo1 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok)PrintErrorStack();

	printf("\nProject stamped is : %s\n",ObjProject);fflush(stdout);

		printf("\n project is live check part level Milestone validations");fflush(stdout);
		if(QRY_find("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n PrtRevMilstonVal:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n PrtRevMilstonVal:Not Found Query ControlObjects \n");fflush(stdout);
		}

		qry_values2[0] = "PrtRevMilstonVal";

		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PrtRevMilstonVal:rsltCount 44:%d:", rsltCount); fflush(stdout);

		int PrtRevMilstonValFl=0;
		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			PrtRevMilstonValFl=0;
			tag_t CntrlObjectObj = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjectObj = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&PrjCodeinfo1)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO1 for project code: 44:%s:", PrjCodeinfo1); fflush(stdout);
				if(tc_strcmp(PrjCodeinfo1,ObjProject)==0)
				{
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&Revinfo2)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo3",&MLStatusinfo3)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo4",&MLStatusinfo4)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo5",&MLStatusinfo5)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO2 for revision:%s:", Revinfo2); fflush(stdout);
				printf(" \n INFORMATIO3 for MLStatusinfo3: 44:%s:", MLStatusinfo3); fflush(stdout);
				printf(" \n Starting milestone value MLStatusinfo4 %s MLStatusinfo5:%5:", MLStatusinfo4,MLStatusinfo5); fflush(stdout);
				PrtRevMilstonValFl=1;
				break;
				}
			}
		}
		if(PrtRevMilstonValFl>0)
		{
			printf("\n for compare project code: [%s] MLStatusinfo3:[%s] Revinfo2 [%s] \n",PrjCodeinfo1,MLStatusinfo3,Revinfo2);fflush(stdout);
			printf(" \n Final Starting milestone value MLStatusinfo4 %s MLStatusinfo5:%5:", MLStatusinfo4,MLStatusinfo5); fflush(stdout);
			if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
			if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
			printf("\n  PrtDR: [%s] ML_Staus:[%s] REV [%s] \n",PrtDR,ML_Staus,desRev);fflush(stdout);
			if(tc_strstr(desRev,Revinfo2)!=NULL)
			{

				printf("\n here compare ");fflush(stdout);

				if (tc_strcmp(ML_Staus,"")==0)
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
					return 1;
				}
				else if(tc_strstr(MLStatusinfo3,ML_Staus)==NULL)
				{
					char *t5MlStRevErr=NULL;

					t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
					strcpy(t5MlStRevErr,"");
					strcpy(t5MlStRevErr,"For Project ");
					strcat(t5MlStRevErr,ObjProject);
					strcat(t5MlStRevErr," and NR revision UN milestone must be '");
					strcat(t5MlStRevErr,MLStatusinfo4);
					strcat(t5MlStRevErr," or below'");
					strcat(t5MlStRevErr," and UP milestone must be '");
					strcat(t5MlStRevErr,MLStatusinfo5);
					strcat(t5MlStRevErr," or below'.");
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
					return 1;
				}
				else
				{
					printf("\n Milestone ok update DR Value  \n"); fflush(stdout);
					if(AOM_refresh(rev_tag,TRUE)!=ITK_ok);PrintErrorStack();

					if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
					{
						if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok);PrintErrorStack();
						printf("\n Milestone is [%s] and  Part DR is updated to DR1  \n",ML_Staus);fflush(stdout);
					}
					if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
					{
						if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok);PrintErrorStack();
						printf("\n Milestone is [%s] and  Part DR is updated to DR2  \n",ML_Staus);fflush(stdout);
					}
					if(tc_strcmp(ML_Staus,"UPV3")==0)
					{
						if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR3")!=ITK_ok);PrintErrorStack();
						printf("\n Milestone is [%s] and  Part DR is updated to DR3  \n",ML_Staus);fflush(stdout);
					}
					if(AOM_save(rev_tag)!=ITK_ok);PrintErrorStack();
					if(AOM_refresh(rev_tag,FALSE)!=ITK_ok);PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					printf("\n Milestone is [%s] and  Part DR is updated to [%s]  \n",ML_Staus,PrtDR);fflush(stdout);
					return 0;
				}
			}
			else
			{
					printf("\n Milestone ok, update DR Value for other than NR  \n"); fflush(stdout);
					//if(AOM_refresh(rev_tag,TRUE)!=ITK_ok);PrintErrorStack();
					//if(AOM_refresh(rev_tag,TRUE)!=ITK_ok);PrintErrorStack();
					if (AOM_lock(rev_tag)!=ITK_ok);PrintErrorStack();

					if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
					{
						if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR1")!=ITK_ok);PrintErrorStack();
					}
					if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
					{
						if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR2")!=ITK_ok);PrintErrorStack();
					}
					if(tc_strcmp(ML_Staus,"UPV3")==0)
					{
						if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR3")!=ITK_ok);PrintErrorStack();
					}
					if(AOM_save(rev_tag)!=ITK_ok);PrintErrorStack();
					if(AOM_unlock(rev_tag)!=ITK_ok);PrintErrorStack();
					if(AOM_refresh(rev_tag,0)!=ITK_ok);PrintErrorStack();

					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
					printf("\n for non NR Milestone is [%s] and  Part DR is updated to [%s]  \n",ML_Staus,PrtDR);fflush(stdout);

					return 0;
			}
	    }
	return 0;
}
int tm_Update_DR_AsPerMilestone_OnPart_UpdLogic(tag_t rev_tag)
{

	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *PrtType = NULL;
	char *ObjProject = NULL;
	char *desRevItenId = NULL;
	char *item_id = NULL;
	char *MlVerinfo1 = NULL;
	char *MlPrtTypeinfo2 = NULL;
	char *desRev = NULL;
	int n_entry    = 1;
	int  rsltCount      =  0;
	char *sPrt_Tp = NULL;
	sPrt_Tp=(char *)MEM_alloc(20);

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok)PrintErrorStack();

		printf("\nProject stamped is : %s\n",ObjProject);fflush(stdout);

		if(QRY_find("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n PrtMilstonGen:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n PrtMilstonGen:Not Found Query ControlObjects \n");fflush(stdout);
		}

		qry_values2[0] = "PrtMilstonGen";

		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PrtMilstonGen:rsltCount 44:%d:", rsltCount); fflush(stdout);

		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			tag_t CntrlObjVer = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjVer = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo1",&MlVerinfo1)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO1 for mileston Generation:%s:", MlVerinfo1); fflush(stdout);

				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo2",&MlPrtTypeinfo2)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO2 for mileston Generation Part type:%s:", MlPrtTypeinfo2); fflush(stdout);

				if(tc_strcmp(MlVerinfo1,"Gen3")==0)
				{
					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_id",&desRevItenId)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n MilstonGen PrtDR: [%s] ML_Staus:[%s] PartNumber[%s] REV [%s] Part Type [%s] \n",PrtDR,ML_Staus,desRevItenId,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0)|| (tc_strcmp(PrtDR,"NA")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.DR Status cannot be NULL or NA.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else
						{
							printf("\n check Milestone Value for updating the DR status \n"); fflush(stdout);
							printf("\n Milestone status  is: [%s] and DR status  is: [%s] ",ML_Staus,PrtDR);fflush(stdout);

							if(tc_strcmp(ML_Staus,"Pre-UNVO")==0 || tc_strcmp(ML_Staus,"Pre-UPVO")==0||tc_strcmp(ML_Staus,"Pre-UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0|| tc_strcmp(ML_Staus,"UNV0")==0|| tc_strcmp(ML_Staus,"UNV1")==0|| tc_strcmp(ML_Staus,"UNV2")==0|| tc_strcmp(ML_Staus,"UPV0")==0|| tc_strcmp(ML_Staus,"UPV1")==0|| tc_strcmp(ML_Staus,"UPV2")==0|| tc_strcmp(ML_Staus,"UPV3")==0)
							{
								printf("\n Milestone ok update DR Value  \n"); fflush(stdout);

								if (AOM_lock(rev_tag)!=ITK_ok);PrintErrorStack();

								if(tc_strcmp(ML_Staus,"Pre-UNVO")==0 || tc_strcmp(ML_Staus,"Pre-UPVO")==0|| tc_strcmp(ML_Staus,"Pre-UNV0")==0|| tc_strcmp(ML_Staus,"Pre-UPV0")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR0")!=ITK_ok);PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR0  \n",ML_Staus);fflush(stdout);
								}
								if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0 || tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV0")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok);PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR1  \n",ML_Staus);fflush(stdout);
								}
								if(tc_strcmp(ML_Staus,"UPV1")==0|| tc_strcmp(ML_Staus,"UPV2")==0|| tc_strcmp(ML_Staus,"UPV3")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok);PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR2  \n",ML_Staus);fflush(stdout);
								}

								if(AOM_save(rev_tag)!=ITK_ok);PrintErrorStack();
								if(AOM_refresh(rev_tag,FALSE)!=ITK_ok);PrintErrorStack();
								if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
								printf("\n Milestone is [%s] and  Part DR is updated to [%s]  \n",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								printf("\n DR Status not updated as Milestone status  is: [%s] ",ML_Staus);fflush(stdout);
							}

							return 0;
						}
					}
					else
					{
						printf("\nMileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}

				}
				else if(tc_strcmp(MlVerinfo1,"Gen4")==0)
				{

					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_id",&desRevItenId)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n MilstonGen PrtDR: [%s] ML_Staus:[%s] PartNumber[%s] REV [%s] Part Type [%s] \n",PrtDR,ML_Staus,desRevItenId,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0)|| (tc_strcmp(PrtDR,"NA")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.DR Status cannot be NULL or NA.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else
						{
							printf("\n check Milestone Value for updating the DR status \n"); fflush(stdout);
							printf("\n Milestone status  is: [%s] and DR status  is: [%s] ",ML_Staus,PrtDR);fflush(stdout);

							if(tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0||tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UNV2")==0|| tc_strcmp(ML_Staus,"UPV2")==0|| tc_strcmp(ML_Staus,"UNV3")==0|| tc_strcmp(ML_Staus,"UPV3")==0)
							{
								printf("\n Milestone ok update DR Value  \n"); fflush(stdout);

								if (AOM_lock(rev_tag)!=ITK_ok);PrintErrorStack();

								if(tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR0")!=ITK_ok);PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR0  \n",ML_Staus);fflush(stdout);
								}
								if(tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV2")==0 || tc_strcmp(ML_Staus,"UNV3")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok);PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR1  \n",ML_Staus);fflush(stdout);
								}
								if(tc_strcmp(ML_Staus,"UPV3")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok);PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR2  \n",ML_Staus);fflush(stdout);
								}

								if(AOM_save(rev_tag)!=ITK_ok);PrintErrorStack();
								if(AOM_refresh(rev_tag,FALSE)!=ITK_ok);PrintErrorStack();
								if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
								printf("\n Milestone is [%s] and  Part DR is updated to [%s]  \n",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								printf("\n DR Status not updated as Milestone status  is: [%s] ",ML_Staus);fflush(stdout);
							}

							return 0;
						}
					}
					else
					{
						printf("\nMileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}

				}
				else
				{
					printf("\n Milestone version logic is off");fflush(stdout);
				}
			}
		}


	return 0;
}
//added on 14Apr2023
int tm_MilestoneValAsPerDRStatus_OnPartUpd(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *PrtType = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *Revinfo2 = NULL;
	char *MLStatusinfo3 = NULL;
	char *MLStatusinfo4 = NULL;
	char *MLStatusinfo5 = NULL;
	char *MlVerinfo1 = NULL;
	char *MlPrtTypeinfo2 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;
	char *sPrt_Tp = NULL;
	sPrt_Tp=(char *)MEM_alloc(20);

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok)PrintErrorStack();
	printf("\n calling function tm_MilestoneValAsPerDRStatus_OnPartUpd");fflush(stdout);
	printf("\nProject stamped is : %s\n",ObjProject);fflush(stdout);
	IsMilestoneLiveFlag=0;
	IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	printf("\n project %s IsMilestoneLiveFlag: %d",ObjProject,IsMilestoneLiveFlag);fflush(stdout);
	if (IsMilestoneLiveFlag >0)
	{
		printf("\n project is live check part level Milestone validations");fflush(stdout);
		if(QRY_find("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n PrtMilstonGen:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n PrtMilstonGen:Not Found Query ControlObjects \n");fflush(stdout);
		}

		qry_values2[0] = "PrtMilstonGen";

		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PrtMilstonGen:rsltCount 44:%d:", rsltCount); fflush(stdout);

		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			tag_t CntrlObjVer = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjVer = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo1",&MlVerinfo1)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO1 for mileston Version:%s:", MlVerinfo1); fflush(stdout);

				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo2",&MlPrtTypeinfo2)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO2 for mileston Part type:%s:", MlPrtTypeinfo2); fflush(stdout);

				if(tc_strcmp(MlVerinfo1,"Gen3")==0)
				{

					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n  PrtDR: [%s] ML_Staus:[%s] REV [%s] Part Type [%s] \n",PrtDR,ML_Staus,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.DR Status cannot bes NULL or NA.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else if ((tc_strcmp(PrtDR,"DR0")==0)|| (tc_strcmp(PrtDR,"AR0")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV1")==0)|| (tc_strcmp(ML_Staus,"UPV0")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV1,UPV0' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR1")==0)|| (tc_strcmp(PrtDR,"AR1")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV2")==0)|| (tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV1")==0)|| (tc_strcmp(ML_Staus,"UPV2")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV2,UNV3,UPV1,UPV2' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR2")==0)|| (tc_strcmp(PrtDR,"AR2")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR3")==0)|| (tc_strcmp(PrtDR,"AR3")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR4")==0)|| (tc_strcmp(PrtDR,"AR4")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR5")==0)|| (tc_strcmp(PrtDR,"AR5")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR3P")==0)|| (tc_strcmp(PrtDR,"AR3P")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else
						{
							printf("\n Part Type[%s],Part DR Status[%s],Part Milston Status[%s]",sPrt_Tp,PrtDR,ML_Staus);fflush(stdout);
						}
					}
					else
					{
						printf("\nMileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}

				}
				else
				{
					printf("\n Milestone version logic is off");fflush(stdout);
				}
			}
		}
	}
	return 0;
}
//end on 14Apr2023
int tm_MilestoneValAsPerDRStatus_OnPart(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *PrtType = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *Revinfo2 = NULL;
	char *MLStatusinfo3 = NULL;
	char *MLStatusinfo4 = NULL;
	char *MLStatusinfo5 = NULL;
	char *MlVerinfo1 = NULL;
	char *MlPrtTypeinfo2 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;
	char *sPrt_Tp = NULL;
	sPrt_Tp=(char *)MEM_alloc(20);

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok)PrintErrorStack();

	printf("\nProject stamped is : %s\n",ObjProject);fflush(stdout);
	IsMilestoneLiveFlag=0;
	IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	printf("\n project %s IsMilestoneLiveFlag: %d",ObjProject,IsMilestoneLiveFlag);fflush(stdout);
	if (IsMilestoneLiveFlag >0)
	{
		printf("\n project is live check part level Milestone validations");fflush(stdout);
		if(QRY_find("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n PrtRevMilstonVersion:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n PrtRevMilstonVersion:Not Found Query ControlObjects \n");fflush(stdout);
		}

		qry_values2[0] = "PrtRevMilstonVersion";

		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PrtRevMilstonVersion:rsltCount 44:%d:", rsltCount); fflush(stdout);

		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			tag_t CntrlObjVer = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjVer = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo1",&MlVerinfo1)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO1 for mileston Version:%s:", MlVerinfo1); fflush(stdout);

				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo2",&MlPrtTypeinfo2)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO2 for mileston Part type:%s:", MlPrtTypeinfo2); fflush(stdout);

				if(tc_strcmp(MlVerinfo1,"VERSION8")==0)
				{

					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n  PrtDR: [%s] ML_Staus:[%s] REV [%s] Part Type [%s] \n",PrtDR,ML_Staus,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0)|| (tc_strcmp(PrtDR,"NA")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.DR Status cannot bes NULL or NA.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else if ((tc_strcmp(PrtDR,"DR0")==0)|| (tc_strcmp(PrtDR,"AR0")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV0")==0)|| (tc_strcmp(ML_Staus,"Pre-UPV0")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr," Milestone Status must be UNV0 or Pre-UPV0.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR1")==0)|| (tc_strcmp(PrtDR,"AR1")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV0")==0)|| (tc_strcmp(ML_Staus,"UNV1")==0)|| (tc_strcmp(ML_Staus,"Pre-UPV0")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr," Milestone Status must be UNV0,UNV1 or Pre-UPV0.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR2")==0)|| (tc_strcmp(PrtDR,"AR2")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV2")==0)|| (tc_strcmp(ML_Staus,"UPV0")==0)|| (tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV1")==0)|| (tc_strcmp(ML_Staus,"UPV2")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UPV0,UPV1,UPV2,UNV2 or UNV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR3")==0)|| (tc_strcmp(PrtDR,"AR3")==0))
						{
							if ((tc_strcmp(ML_Staus,"UPV3")==0)|| (tc_strcmp(ML_Staus,"UNV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR3P")==0)|| (tc_strcmp(PrtDR,"AR3P")==0)|| (tc_strcmp(PrtDR,"DR4")==0)|| (tc_strcmp(PrtDR,"AR4")==0)|| (tc_strcmp(PrtDR,"DR5")==0)|| (tc_strcmp(PrtDR,"AR5")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
					}
					else
					{
						printf("\nMileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}

				}
				else if(tc_strcmp(MlVerinfo1,"VERSION9")==0)
				{
					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n  PrtDR: [%s] ML_Staus:[%s] REV [%s] Part Type [%s]\n",PrtDR,ML_Staus,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0)|| (tc_strcmp(PrtDR,"NA")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.Please select valid DR Status of Part.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else if ((tc_strcmp(PrtDR,"DR0")==0)|| (tc_strcmp(PrtDR,"AR0")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV1")==0)|| (tc_strcmp(ML_Staus,"UPV0")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr," Milestone Status must be UNV1 or UPV0.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR1")==0)|| (tc_strcmp(PrtDR,"AR1")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV1")==0)|| (tc_strcmp(ML_Staus,"UNV2")==0)|| (tc_strcmp(ML_Staus,"UPV0")==0)|| (tc_strcmp(ML_Staus,"UPV1")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr," Milestone Status must be UNV1,UNV2,UPV0 or UPV1.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR2")==0)|| (tc_strcmp(PrtDR,"AR2")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV2")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3,UPV2 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR3")==0)|| (tc_strcmp(PrtDR,"AR3")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR3P")==0)|| (tc_strcmp(PrtDR,"AR3P")==0)|| (tc_strcmp(PrtDR,"DR4")==0)|| (tc_strcmp(PrtDR,"AR4")==0)|| (tc_strcmp(PrtDR,"DR5")==0)|| (tc_strcmp(PrtDR,"AR5")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
					}
					else
					{
						printf("\nMileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}

				}
				else
				{
					printf("\n Milestone version logic is off");fflush(stdout);
				}
			}
		}
	}
	return 0;
}

// Validate DR-MileStone END
// Validate Parts's Revision-MileStone START
int tm_Validate_Rev_Milestone_OnPart(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *Revinfo2 = NULL;
	char *MLStatusinfo3 = NULL;
	char *MLStatusinfo4 = NULL;
	char *MLStatusinfo5 = NULL;
	char *PrjCodeinfo1 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok)PrintErrorStack();

	printf("\nProject stamped is : %s\n",ObjProject);fflush(stdout);
	IsMilestoneLiveFlag=0;
	IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	printf("\n project %s IsMilestoneLiveFlag: %d",ObjProject,IsMilestoneLiveFlag);fflush(stdout);
	if (IsMilestoneLiveFlag >0)
	{
		printf("\n project is live check part level Milestone validations");fflush(stdout);
		if(QRY_find("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n PrtRevMilstonVal:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n PrtRevMilstonVal:Not Found Query ControlObjects \n");fflush(stdout);
		}

		qry_values2[0] = "PrtRevMilstonVal";

		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PrtRevMilstonVal:rsltCount 44:%d:", rsltCount); fflush(stdout);

		int PrtRevMilstonValFl=0;
		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			PrtRevMilstonValFl=0;
			tag_t CntrlObjectObj = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjectObj = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&PrjCodeinfo1)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO1 for project code: 44:%s:", PrjCodeinfo1); fflush(stdout);
				if(tc_strcmp(PrjCodeinfo1,ObjProject)==0)
				{
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&Revinfo2)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo3",&MLStatusinfo3)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo4",&MLStatusinfo4)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo5",&MLStatusinfo5)!=ITK_ok)   PrintErrorStack();
				printf(" \n INFORMATIO2 for revision:%s:", Revinfo2); fflush(stdout);
				printf(" \n INFORMATIO3 for MLStatusinfo3: 44:%s:", MLStatusinfo3); fflush(stdout);
				printf(" \n Starting milestone value MLStatusinfo4 %s MLStatusinfo5:%5:", MLStatusinfo4,MLStatusinfo5); fflush(stdout);
				PrtRevMilstonValFl=1;
				break;
				}
			}
		}
		if(PrtRevMilstonValFl>0)
		{
			printf("\n for compare project code: [%s] MLStatusinfo3:[%s] Revinfo2 [%s] \n",PrjCodeinfo1,MLStatusinfo3,Revinfo2);fflush(stdout);
			printf(" \n Final Starting milestone value MLStatusinfo4 %s MLStatusinfo5:%5:", MLStatusinfo4,MLStatusinfo5); fflush(stdout);
			if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
			if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
			printf("\n  PrtDR: [%s] ML_Staus:[%s] REV [%s] \n",PrtDR,ML_Staus,desRev);fflush(stdout);
			if(tc_strstr(desRev,Revinfo2)!=NULL)
			{

				printf("\n here compare ");fflush(stdout);

				if (tc_strcmp(ML_Staus,"")==0)
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
					return 1;
				}
				else if(tc_strstr(MLStatusinfo3,ML_Staus)==NULL)
				{
					char *t5MlStRevErr=NULL;

					t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
					strcpy(t5MlStRevErr,"");
					strcpy(t5MlStRevErr,"For Project ");
					strcat(t5MlStRevErr,ObjProject);
					strcat(t5MlStRevErr," and NR revision UN milestone must be '");
					strcat(t5MlStRevErr,MLStatusinfo4);
					strcat(t5MlStRevErr," or below'");
					strcat(t5MlStRevErr," and UP milestone must be '");
					strcat(t5MlStRevErr,MLStatusinfo5);
					strcat(t5MlStRevErr," or below'.");
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
					return 1;
				}
				else
				{
					printf("\n bye ");fflush(stdout);
				}
			}
	    }
	}
	return 0;
}
// Validate Parts's Revision-MileStone END

int tm_check_MilesStoneStatusSame_OnPart(tag_t rev_tag)
{
	char *rev_tagItemID = NULL;
	char *Prevrev_tagItemID = NULL;
	char *PreVrevMLStatus = NULL;
	char *PrtMLStatus = NULL;
	char *PrevDgMLInitials = NULL;
	char *DgMLInitials = NULL;
	char *Prevrev_id = NULL;
	char *rev_tagvrev_id = NULL;
	tag_t		Prevrev_tag			= NULLTAG;
	tag_t		*rev_list_set		= NULLTAG;
	int			rev_cnt				= 0;
	int			iij				= 0;

	printf("\n in function tm_check_MilesStoneStatusSame_OnPart");fflush(stdout);

	if( AOM_ask_value_string(rev_tag,"item_id",&rev_tagItemID)!=ITK_ok);PrintErrorStack();
	printf("\n current Item Id %s ",rev_tagItemID);fflush(stdout);

	if(AOM_UIF_ask_value(rev_tag,"item_revision_id", &rev_tagvrev_id)!=ITK_ok)   PrintErrorStack();
	printf("\n current revision Item Id %s ",rev_tagvrev_id);fflush(stdout);

	if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&PrtMLStatus)!=ITK_ok)   PrintErrorStack();
	printf("\n current Part ML Status [%s] ",PrtMLStatus);fflush(stdout);

	if (tc_strcmp(PrtMLStatus,"")==0)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
		return 1;
	}
	else
	{
		if (tc_strcmp(PrtMLStatus,"Pre-UPV0")==0)
		{
			printf("\n its Pre-UPV0 %s ",PrtMLStatus);fflush(stdout);
			DgMLInitials=subString(PrtMLStatus, 4, 2);
		}
		else
		{
			DgMLInitials=subString(PrtMLStatus, 0, 2);
		}
		printf("\n Current Part intials of Design MilesStone %s ",DgMLInitials);fflush(stdout);

		ITK_CALL(ITEM_find_item(rev_tagItemID, &Prevrev_tag ));
		ITK_CALL(ITEM_list_all_revs(Prevrev_tag,&rev_cnt,&rev_list_set));

		printf("\n Total rev rev_listt: %d.", rev_cnt);fflush(stdout);

		if(rev_cnt != 0)
		{
			for(iij=rev_cnt-1;iij>=0;iij--)
			{
				if( AOM_ask_value_string(rev_list_set[iij],"item_id",&Prevrev_tagItemID)!=ITK_ok);PrintErrorStack();
				printf("\n Previous revision Item Id %s ",Prevrev_tagItemID);fflush(stdout);

				if(AOM_UIF_ask_value(rev_list_set[iij],"item_revision_id", &Prevrev_id)!=ITK_ok)   PrintErrorStack();
				printf("\n Previous revision Item Id %s ",Prevrev_id);fflush(stdout);

					if (tc_strcmp(rev_tagvrev_id,Prevrev_id)==0)
					{
						printf("\n Same part Currect rev Item ID %s -- Perv Item ID %s",rev_tagItemID,Prevrev_tagItemID);fflush(stdout);
						printf("\n Same part Currect rev Item RevID %s -- Perv Item RevID %s",rev_tagvrev_id,Prevrev_id);fflush(stdout);
						continue;
					}
					else
					{
						printf("\n Just previsous part");fflush(stdout);
						printf("\n Currect rev Item ID %s -- Perv Item ID %s",rev_tagItemID,Prevrev_tagItemID);fflush(stdout);
						printf("\n Currect rev Item RevID %s -- Perv Item RevID %s",rev_tagvrev_id,Prevrev_id);fflush(stdout);

						if (AOM_ask_value_string(rev_list_set[iij],"t5_DesignMilestoneStatus",&PreVrevMLStatus)!=ITK_ok)   PrintErrorStack();
						printf("\n Part ML Status [%s] ",PreVrevMLStatus);fflush(stdout);

						if (tc_strcmp(PreVrevMLStatus,"")!=0)
						{

							if (tc_strcmp(PreVrevMLStatus,"Pre-UPV0")==0)
							{
								PrevDgMLInitials=subString(PreVrevMLStatus, 4, 2);
							}
							else
							{
							PrevDgMLInitials=subString(PreVrevMLStatus, 0, 2);
							}

							printf("\n intials of Design MilesStone Previous %s ",PrevDgMLInitials);fflush(stdout);

							if (tc_strcmp(DgMLInitials,PrevDgMLInitials)!=0)
							{
								printf("\n intials of Design MilesStone %s ",DgMLInitials);fflush(stdout);
								char *t5MlStIntialErr=NULL;

								t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStIntialErr,"");
								strcpy(t5MlStIntialErr,"Please select Design Milestone value starting with ");
								strcat(t5MlStIntialErr,PrevDgMLInitials);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
								return 1;
							}
						}
						else
						{
							printf("\n Previous revision part miles Stone status is blank");fflush(stdout);
							printf("\n Part ML Status [%s] ",PreVrevMLStatus);fflush(stdout);
						}
					}
				break;
			}
		}
	}

	return 0;
}

extern DLLAPI int  save_method_3(METHOD_message_t *msg, va_list args)
{

      int error_code = ITK_ok;
      tag_t objTag = va_arg(args, tag_t);
      //logical flag = va_arg(args, logical);
      tag_t objTypeTag = NULLTAG;
      char   type_name[TCTYPE_name_size_c+1];

      char   *desid=NULL;

      char   *DesRevDesc=NULL;
      char   *ReplacedDesRevDesc=NULL;
      char   *NewReplacedDescription=NULL;
	char   *ItemMaterial=NULL;

int desclength= 0;
int revdesccnt= 0;


      EPM_decision_t decision=EPM_go;

      printf("\n save_method_3::It's the time to save ItemRevision \n");fflush(stdout);


      if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
      if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
      if(strcmp(type_name,"Design")==0 || strcmp(type_name,"T5_SparKit")==0)//T5_SparKit
      {
            if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);PrintErrorStack();

            if( AOM_ask_value_string(objTag,"object_desc",&DesRevDesc)!=ITK_ok);PrintErrorStack();

	  // if( AOM_ask_value_string(objTag,"t5Material",&ItemMaterial)!=ITK_ok);

            printf("\n save_method_3::Design Revision Item ID %s and ItemMaterial :%s\n", desid,ItemMaterial);fflush(stdout);

	



		if(strcmp(DesRevDesc,"")!=0)
		{
		desclength = strlen(DesRevDesc);
		for(revdesccnt=0;revdesccnt<desclength;revdesccnt++)
		{
			if(DesRevDesc[revdesccnt]=='\n')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='`')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='~')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='|')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='$')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='#')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='@')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='^')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='!')
				DesRevDesc[revdesccnt] =' ';
			printf("\n [%c]\n",DesRevDesc[revdesccnt]);fflush(stdout);
		}
		ReplacedDesRevDesc = (char *)MEM_alloc (desclength * sizeof(char));
		strcpy(ReplacedDesRevDesc,DesRevDesc);



			printf("\n AFTER SET SAVE_METHOD_1::ReplacedDesRevDesc=====>[%s]\n",ReplacedDesRevDesc);fflush(stdout);
			if(ReplacedDesRevDesc)
			{
			if(AOM_set_value_string(objTag,"object_desc",ReplacedDesRevDesc)!=ITK_ok);PrintErrorStack();
			if(AOM_save(objTag)!=ITK_ok);PrintErrorStack();
			if( AOM_ask_value_string(objTag,"object_desc",&NewReplacedDescription)!=ITK_ok);PrintErrorStack();
			printf("\n AFTER SET SAVE_METHOD_1::NewReplacedDescription==>[%s]\n", NewReplacedDescription);fflush(stdout);
			}
	 }

      }
      return error_code;
}
extern DLLAPI int  save_method_Design_3(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;

	tag_t objTag = va_arg(args, tag_t);
	logical  isNew = va_arg(args, int);
	tag_t LatestRev = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t attr_id = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t form_attr_id = NULLTAG;
	tag_t status_rel = NULLTAG;

	tag_t *attachments = NULLTAG;
	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *DRinfo4 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	char type_name[TCTYPE_name_size_c+1];
	char *desid=NULL;
	char *desRev=NULL;
	char *PrtPrj=NULL;
	char *ObjectClassType = NULL;
	char *ObjectName = NULL;
	char* oojname = NULL;
	/*Start New Part Request Validation Calling Sudhir!!!!!!!*/
	char
        *qry_entries3[2] = {"Name","Type"},
        *qry_values3[2]	= {"*","*"};

	char
        *npr_qry_entries[2] = {"Tml Part Number","Type"},
        *npr_qry_values[2]	= {"*","*"};

	char
        *ctrl_qry_entries2[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values2[2]	= {"*","*"};

	char
        *ctrl_qry_entries3[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values3[2]	= {"*","*"};

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	tag_t query = NULLTAG;
	tag_t ctrlquery2 = NULLTAG;
	tag_t ctrlquery3 = NULLTAG;
	tag_t *NewProjObj = NULLTAG;
	tag_t *setOfUsrDbObjsda = NULLTAG;
	tag_t *setOfPVBUObjspv = NULLTAG;
	tag_t *PartNewObjs = NULLTAG;
	tag_t master = NULLTAG;
	tag_t latestitemrev = NULLTAG;
	tag_t NPRQuery = NULLTAG;


	char	*ProjectNewNameS		= NULL;
	char	*BussiNameS				= NULL;
	char	*ProjectTypeS			= NULL;
	char	*DsgGrup1S				= NULL;
	char	*subpart91				= NULL;
	char	*sesOrgUsrName1Dup				= NULL;
	char	*NewPrtTypeS				= NULL;
	char	*subpart5				= NULL;
	char	*subpart6				= NULL;
	char	*subpart4				= NULL;
	char	*t5ColourIndicatorS				= NULL;
	char	*t5CoatedS				= NULL;
	char *t5Userinfo1DupS=NULL;
    char *t5Userinfo1S=NULL;
	 char *t5Userinfo2DupS=NULL;
    char *t5Userinfo2S=NULL;
	 char *t5Userinfo3DupS=NULL;
    char *t5Userinfo3S=NULL;
	 char *t5Userinfo4DupS=NULL;
    char *t5Userinfo4S=NULL;
    char *t5Userinfo1PV=NULL;
    char *t5PV1S=NULL;
	char *t5Userinfo2PV=NULL;
    char *t5PV2S=NULL;
	char *t5Userinfo3PV=NULL;
    char *t5PV3S=NULL;
	char *t5Userinfo4PV=NULL;
    char *t5PV4S=NULL;
    char *NewPartS=NULL;
    char *nwLifeCycleS=NULL;
    char *nwRaisedbydS=NULL;
    char *t5NwPartSessionNotMatchRaised=NULL;
    char *t5NwPartAppNeeded=NULL;
    char *NewPartS1=NULL;
    char *t5Userinfo5DupS=NULL;
    char *t5Userinfo5S=NULL;

	int	n_found	=0;
	int	n_tags_found	=0;
	int	ctrl_n_found2	=0;
	int	ctrl_n_found3	=0;
	int	CheckApplicable	=0;
	int	flagNewPrt	=0;
	int	NewPartlength	=0;
	int	npr_n_found	=0;
	//logical isNew = 0;
	/*END New Part Request Validation Calling Sudhir!!!!!!!*/

	int cnt = 0;
	int ij = 0;

	logical retain = 0;

	printf("\n Design--METHOD_post_action_type---save_method_Design_3--Start....."); fflush(stdout);
	printf("\n save_method_Design_3::It's the time to save Item/Design---");fflush(stdout);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();

	if(strcmp(type_name,"Design")==0 || strcmp(type_name,"T5_SparKit")==0)//T5_SparKit
	{
		if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);PrintErrorStack();
		printf("\n save_method_Design_3::Design ItemID: [%s]", desid);fflush(stdout);
		if(ITEM_ask_latest_rev(objTag,&LatestRev)!=ITK_ok) PrintErrorStack();
		if (LatestRev!=NULLTAG)
		{
			if( AOM_ask_value_string(LatestRev,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
		}
		printf("\n save_method_Design_3::desRev: [%s]", desRev);fflush(stdout);
		/*Start New Part Request Validation Calling Sudhir!!!!!!!*/
	NewPartlength = strlen(desid);
	printf("\n save_method_Design_3::NewPartlength==>[%d]\n", NewPartlength);fflush(stdout);
	if(NewPartlength==12 && isNew==true)
	{
	subpart5=subString(desid,6,2);
	subpart6=subString(desid,8,1);
	subpart91=subString(desid,8,2);
	subpart4=subString(desid,4,2);
	printf("\n save_method_Design_3::subpart5==>[%s]\n", subpart5);fflush(stdout);
	printf("\n save_method_Design_3::subpart6==>[%s]\n", subpart6);fflush(stdout);
	printf("\n save_method_Design_3::subpart91==>[%s]\n", subpart91);fflush(stdout);
	printf("\n save_method_Design_3::subpart4==>[%s]\n", subpart4);fflush(stdout);
	AOM_ask_value_string(LatestRev,"t5_ProjectCode",&ProjectNewNameS);
	AOM_ask_value_string(LatestRev,"t5_DesignGrp",&DsgGrup1S);
	AOM_ask_value_string(LatestRev,"t5_PartType",&NewPrtTypeS);
	printf("\n save_method_Design_3::ProjectNewNameS==>[%s]\n", ProjectNewNameS);fflush(stdout);
	printf("\n save_method_Design_3::DsgGrup1S==>[%s]\n", DsgGrup1S);fflush(stdout);
	printf("\n save_method_Design_3::NewPrtTypeS==>[%s]\n", NewPrtTypeS);fflush(stdout);
	if(strcmp(subpart5,"CK") == 0)
	{
		printf("\n #############7th and 8th digit are CK hence bypassing New Part Request  ############## \n");fflush(stdout);
	}
	else
	{
		if (( strcmp(subpart6,"Z") == 0) || ( strcmp(subpart6,"C") == 0))
		{
			printf("\n ********** 9th and 10th digit are Z OR C hence bypassing New Part Request  ********\n");fflush(stdout);
		}
		else
		{
			AOM_ask_value_string(LatestRev,"t5_ColourInd",&t5ColourIndicatorS);
			AOM_ask_value_string(LatestRev,"t5_PrtCatCode",&t5CoatedS);

			if(strcmp(t5ColourIndicatorS,"C") == 0 || strcmp(t5CoatedS,"C") == 0)
			{
				printf("\nByPass for Objects with Colour Indicator as C\n");fflush(stdout);
			}
			else
			{
				if((strcmp(NewPrtTypeS,"A")==0) || (strcmp(NewPrtTypeS,"C")==0))
				{
				qry_values3[0]	= ProjectNewNameS;
				qry_values3[1]	= "Project";
				QRY_find("General...", &query);
				QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &NewProjObj);
				printf("\n save_method_Design_3::n_found =[%d]",n_found);fflush(stdout);
				if(n_found>0)
				{
					AOM_ask_value_string(NewProjObj[0],"t5_BussUnitType",&BussiNameS);
					printf("\n save_method_Design_3::BussiNameS====>[%s]", BussiNameS);fflush(stdout);
					AOM_ask_value_string(NewProjObj[0],"t5_ProjectType",&ProjectTypeS);
					printf("\n save_method_Design_3::Proj_typ====>[%s]", ProjectTypeS);fflush(stdout);

					if( (strcmp(ProjectTypeS,"E")==0) || (strcmp(ProjectTypeS,"G")==0))
					{
						printf("\n In engine gear box Project code ---- %s\n", ProjectNewNameS);fflush(stdout);
						printf("\n  In Assyvalidation Inside the project type as Engine or GearBox \n");fflush(stdout);
						if(strcmp(ProjectTypeS,"E")==0)
						{
								printf("\n In save_method_Design_3:: Inside the project type as->(%s) Design-(%s) Designation ID- (%s)\n",ProjectTypeS,DsgGrup1S,subpart91);fflush(stdout);

								  if(strcmp(DsgGrup1S,"50")==0)
								{
									 if(strcmp(subpart91,"33")==0)
									{
										CheckApplicable=1;
										printf("\nIn save_method_Design_3::  Check is applicable to design group 50 and designation id -33 \n");fflush(stdout);
									}

								}
								else if(strcmp(DsgGrup1S,"23")==0)
								{
									if((strcmp(subpart91,"33")==0) || (strcmp(subpart91,"37")==0) || (strcmp(subpart91,"38")==0))
									{
										CheckApplicable=1;
										printf("\nIn save_method_Design_3:: Check is applicable to design group 23 and designation id -33/37/38 \n");fflush(stdout);
									}

								}
								printf("\n In save_method_Design_3:: Engine-Outside the project type as ---->(%s) \n",ProjectTypeS);fflush(stdout);
						}
						else if(strcmp(ProjectTypeS,"G")==0)
						{
							printf("\nIn save_method_Design_3::  GB-Project type as ---->(%s) and Design group -(%s) and Designation ID-(%s) \n",ProjectTypeS,DsgGrup1S,subpart91);fflush(stdout);
								if(strcmp(DsgGrup1S,"26")==0)
								{
									 if((strcmp(subpart91,"31")==0) || (strcmp(subpart91,"77")==0) || (strcmp(subpart91,"78")==0) || (strcmp(subpart91,"86")==0) ||(strcmp(subpart91,"65")==0))
									{
										CheckApplicable=1;
										printf("\nIn save_method_Design_3::  Gear-Box Check is applicable to design group 26 and designation id -33 \n");fflush(stdout);
									}

								}
								else if(strcmp(DsgGrup1S,"35")==0)
								{
									if((strcmp(subpart91,"31")==0) || (strcmp(subpart91,"77")==0) || (strcmp(subpart91,"78")==0) || (strcmp(subpart91,"86")==0) ||(strcmp(subpart91,"65")==0))
									{
										CheckApplicable=1;
										printf("\nIn save_method_Design_3::  Gear-Box Check is applicable to design group 35 and designation id -33/37/38 \n");fflush(stdout);
									}

								}
								printf("\n In save_method_Design_3:: GB Outside the project type as ---->(%s) \n",ProjectTypeS);fflush(stdout);
						}
					}
					if((strcmp(BussiNameS,"CVBU")==0) || (strcmp(BussiNameS,"PCBU")==0) || (strcmp(BussiNameS,"PCBU and CVBU Both")==0))
					{
						ctrl_qry_values2[0]	= "NwPrtReq";
						ctrl_qry_values2[1]	= BussiNameS;
						QRY_find("ControlObjQry", &ctrlquery2);
						QRY_execute(ctrlquery2, 1, ctrl_qry_entries2, ctrl_qry_values2, &ctrl_n_found2, &setOfUsrDbObjsda);
						printf("\n save_method_Design_3::ctrl_n_found2 =[%d]",ctrl_n_found2);fflush(stdout);
						if(ctrl_n_found2>0)
						{
							AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo1",&t5Userinfo1DupS);
							t5Userinfo1S = strdup(t5Userinfo1DupS);
							AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo2",&t5Userinfo2DupS);
							t5Userinfo2S = strdup(t5Userinfo2DupS);
							AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo3",&t5Userinfo3DupS);
							t5Userinfo3S = strdup(t5Userinfo3DupS);
							AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo4",&t5Userinfo4DupS);
							t5Userinfo4S = strdup(t5Userinfo4DupS);
							AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo5",&t5Userinfo5DupS);
							t5Userinfo5S = strdup(t5Userinfo5DupS);
							printf("\n In save_method_Design_3:::: Control object row 1===> %s\n",t5Userinfo1S);fflush(stdout);
							printf("\n In save_method_Design_3:::: Control object row 2 ===> %s\n",t5Userinfo2S);fflush(stdout);
							printf("\n In save_method_Design_3:::: Control object row 3===> %s\n",t5Userinfo3S);fflush(stdout);
							printf("\n In save_method_Design_3:::: Control object row 4 ===> %s\n",t5Userinfo4S);fflush(stdout);
							printf("\n In save_method_Design_3:::: Control object row 5 ===> %s\n",t5Userinfo5S);fflush(stdout);
							printf("\n In save_method_Design_3:::: ProjectNewNameS ===> %s\n",ProjectNewNameS);fflush(stdout);
							printf("\n save_method_Design_3::Vlaue of CheckApplicable %d \n",CheckApplicable);fflush(stdout);
							if(tc_strstr(t5Userinfo5S,ProjectNewNameS)!=NULL)
							{
							if(CheckApplicable== 0)
							{
								if(strcmp(BussiNameS,"CVBU")==0)
								{
									printf("\n In save_method_Design_3:: Inside the CVBU \n");fflush(stdout);
									if(strstr(t5Userinfo1S, subpart4) != NULL || strstr(t5Userinfo2S, subpart4) != NULL || strstr(t5Userinfo3S, subpart4) != NULL || strstr(t5Userinfo4S, subpart4) != NULL)
									{
										printf("\n#### Do nothing after checking 5th and 6th digit in save_method_Design_3::\n");fflush(stdout);
										flagNewPrt=1;
									}

								}
								else
								{
									if(strcmp(BussiNameS,"PCBU")==0)
									{
										ctrl_qry_values3[0]	= "PVB";
										ctrl_qry_values3[1]	= "DesGrp";
										QRY_find("ControlObjQry", &ctrlquery3);
										QRY_execute(ctrlquery3, 1, ctrl_qry_entries3, ctrl_qry_values3, &ctrl_n_found3, &setOfPVBUObjspv);
										printf("\n ctrl_n_found3 =[%d]",ctrl_n_found3);fflush(stdout);
										if(ctrl_n_found3>0)
										{
											AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo1",&t5Userinfo1PV);
											t5PV1S = strdup(t5Userinfo1PV);
											AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo2",&t5Userinfo2PV);
											t5PV2S = strdup(t5Userinfo2PV);
											AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo3",&t5Userinfo3PV);
											t5PV3S = strdup(t5Userinfo3PV);
											AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo4",&t5Userinfo4PV);
											t5PV4S = strdup(t5Userinfo4PV);
											printf("\n In save_method_Design_3:::::: Control object row 1===> %s\n",t5PV1S);fflush(stdout);
											printf("\n In save_method_Design_3:::::: Control object row 2 ===> %s\n",t5PV2S);fflush(stdout);
											printf("\n In save_method_Design_3:::::: Control object row 3===> %s\n",t5PV3S);fflush(stdout);
											printf("\n In save_method_Design_3:::::: Control object row 4 ===> %s\n",t5PV4S);fflush(stdout);
											printf("\n#### INSIDE THE PCBU CONDITION Designation id -%s and Design Group --(%s) !!!!!!!\n", subpart91,DsgGrup1S);fflush(stdout);

											printf("\n#### New part is not applicable for PVBU for designation ID-%s ###\n", subpart91);fflush(stdout);

											if(strstr(t5PV1S, subpart4) != NULL || strstr(t5PV2S, subpart4) != NULL || strstr(t5PV3S, subpart4) != NULL || strstr(t5PV4S, subpart4) != NULL)
											{
												printf("\n#### PVBU control object Do nothing after checking Design group digit in save_method_Design_3:::: file  ###\n");fflush(stdout);
												flagNewPrt=1;
											}
											else
											{
												printf("\n Inside else as design grp-(%s) not in control object for PVBU ~~~~~~~~~~\n",subpart4);fflush(stdout);
												if(strcmp(DsgGrup1S,"54")==0)
												{
													if((strstr(subpart91,"82") != NULL) || (strstr(subpart91,"99") != NULL) || (strstr(subpart91,"63") != NULL) || (strstr(subpart91,"33") != NULL))
													{
														flagNewPrt=0;
														printf("\n ***** Flag Set to 0 for 82 ~~~~~~~~~\n");fflush(stdout);
													}
													else
													{
														printf("\n !!!!! Design group -(%s) CONDITION Designation id -(%s) ###\n",DsgGrup1S, subpart91);fflush(stdout);
														flagNewPrt=1;
														printf("\n ***** Flag Set to 1 ~~~~~~~~~\n");fflush(stdout);
													}

												}
												else
												{
													if(strstr(t5Userinfo1S, subpart91) != NULL || strstr(t5Userinfo2S, subpart91) != NULL || strstr(t5Userinfo3S, subpart91) != NULL || strstr(t5Userinfo4S, subpart91) != NULL )
													{
														flagNewPrt=1;
														printf("\n outside the 54 design grp condition -%s  \n",DsgGrup1S );fflush(stdout);
													}
												}
											 }
										}
									}
								}
								if((strcmp(BussiNameS,"PCBU and CVBU Both")==0) && (CheckApplicable== 0))
								{
									printf("\n !!!!!! AAAA !!! Inside the CheckApplicable--- %d \n",CheckApplicable );fflush(stdout);
									printf("\n !!!!!! AAAA !!! Vlaue of bussiness unit--- %s \n",BussiNameS );fflush(stdout);
									flagNewPrt=1;
									printf("\n flagNewPrt Value attt  -%d \n",flagNewPrt );fflush(stdout);
								}
							}
							printf("\n Inside the assyvalidation file flagNewPrt -%d  \n",flagNewPrt );fflush(stdout);
							if(CheckApplicable==1)
							{
								flagNewPrt=1;
								printf("\n @@ Else Inside t5assyvalidation value of CheckApplicable - %d\n", CheckApplicable);fflush(stdout);
								printf("\n @@ Elseinside CheckApplicable=!0 condition -- Designation Id of part is  (%s) and design grp -%s\n",subpart91,DsgGrup1S);fflush(stdout);
								printf("\n  @@ Else Inside PrtNm Value issssssss ----->>> (%s)###\n",desid);fflush(stdout);
								NewPartS = (char *) MEM_alloc( 100 * sizeof(char) );
								strcpy(NewPartS,"*");
								strcat(NewPartS,desid);
								strcat(NewPartS,"*");
								printf("\n @@ Else PrtNm Value after string copy is  ----->>> (%s)###\n",NewPartS);fflush(stdout);

								npr_qry_values[0]	= NewPartS;
								npr_qry_values[1]	= "New Part Request";
								QRY_find("tm_NewPartRequest", &NPRQuery);
								QRY_execute(NPRQuery, 1, npr_qry_entries, npr_qry_values, &npr_n_found, &PartNewObjs);

								printf("\n save_method_Design_3:: npr_n_found==>%d",npr_n_found);fflush(stdout);
								if(npr_n_found>0)
								{
									AOM_ask_value_string(PartNewObjs[0],"t5_NwLCState",&nwLifeCycleS);
									printf("\n save_method_Design_3::nwLifeCycleS====>[%s]", nwLifeCycleS);fflush(stdout);

									AOM_ask_value_string(PartNewObjs[0],"t5_NwRaisedBy",&nwRaisedbydS);
									printf("\n save_method_Design_3::NwRaisedBy====>[%s]", nwRaisedbydS);fflush(stdout);
									if((nlsStrCmp(nwRaisedbydS,sesOrgUsrName1Dup)==0))
									{
										printf("\n @@ Else Session User Name and Raised by User Login Name is same. Hence Allowed to Created the TC part \n");fflush(stdout);
									}
									else
									{
										printf("\n@@ Else Inside the Condition of Raised by User Login Name missmatch with Session user Login\n");fflush(stdout);
										t5NwPartSessionNotMatchRaised = (char *) MEM_alloc( 1000 * sizeof(char) );
										strcpy(t5NwPartSessionNotMatchRaised,"You Can not Create the TC Part Number.As New Part Request Raised by Login ");
										strcat(t5NwPartSessionNotMatchRaised,nwRaisedbydS);
										strcat(t5NwPartSessionNotMatchRaised,"is Different.");
										strcat(t5NwPartSessionNotMatchRaised,"Your Current Login is ");
										strcat(t5NwPartSessionNotMatchRaised,sesOrgUsrName1Dup);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err, t5NwPartSessionNotMatchRaised);
										return ITK_err;
									}
									if(strcmp(nwLifeCycleS,"LcsNwAppr")==0)
									{
										printf("\n @@ Else Request is approved. \n");fflush(stdout);
									}
								}
								else
								{
										printf("\n @@ Else Inside the approval condition for new part\n");fflush(stdout);
										t5NwPartAppNeeded = (char *) MEM_alloc( 1000 * sizeof(char) );
										strcpy(t5NwPartAppNeeded,"New Part Request is Not Approved for Newly Created TC Part Number ");
										strcat(t5NwPartAppNeeded,"Raise the New Part Request in Creo or Catia for TC Part which is having Cad Data For SPARE-KIT,Please Use the Option Crete-->New Part Request. Fill the Form and Submit to LifeCycle [New Part Request]");
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err, t5NwPartAppNeeded);
										return ITK_err;
								}
							}
							printf("\n 11111 Inside the assyvalidation file  flagNewPrt  -%d  \n",flagNewPrt );fflush(stdout);
							if(flagNewPrt !=1)
							{
								printf("\n inside flagNewPrt=!1 condition -- Designation Id of part is  (%s) and design grp -%s\n",subpart91,DsgGrup1S);fflush(stdout);
								printf("\n#### PrtNm Value issssssss ----->>> (%s)###\n",desid);fflush(stdout);
								NewPartS = (char *) MEM_alloc( 100 * sizeof(char) );
								strcpy(NewPartS,"*");
								strcat(NewPartS,desid);
								strcat(NewPartS,"*");
								printf("\n @@ Else PrtNm Value after string copy is  ----->>> (%s)###\n",NewPartS);fflush(stdout);
								npr_qry_values[0]	= NewPartS;
								npr_qry_values[1]	= "New Part Request";
								QRY_find("tm_NewPartRequest", &NPRQuery);
								QRY_execute(NPRQuery, 1, npr_qry_entries, npr_qry_values, &npr_n_found, &PartNewObjs);
								printf("\n save_method_Design_3:: npr_n_found==>%d",npr_n_found);fflush(stdout);
								if(npr_n_found>0)
								{
									AOM_ask_value_string(PartNewObjs[0],"t5_NwLCState",&nwLifeCycleS);
									printf("\n save_method_Design_3::nwLifeCycleS====>[%s]", nwLifeCycleS);fflush(stdout);

									AOM_ask_value_string(PartNewObjs[0],"t5_NwRaisedBy",&nwRaisedbydS);
									printf("\n save_method_Design_3::NwRaisedBy====>[%s]", nwRaisedbydS);fflush(stdout);
									if((nlsStrCmp(nwRaisedbydS,sesOrgUsrName1Dup)==0))
									{
										printf("\n @@ Else Session User Name and Raised by User Login Name is same. Hence Allowed to Created the TC part \n");fflush(stdout);
									}
									else
									{
										printf("\n@@ Else Inside the Condition of Raised by User Login Name missmatch with Session user Login\n");fflush(stdout);
										t5NwPartSessionNotMatchRaised = (char *) MEM_alloc( 1000 * sizeof(char) );
										strcpy(t5NwPartSessionNotMatchRaised,"You Can not Create the TC Part Number.As New Part Request Raised by Login ");
										strcat(t5NwPartSessionNotMatchRaised,nwRaisedbydS);
										strcat(t5NwPartSessionNotMatchRaised,"is Different.");
										strcat(t5NwPartSessionNotMatchRaised,"Your Current Login is ");
										strcat(t5NwPartSessionNotMatchRaised,sesOrgUsrName1Dup);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err, t5NwPartSessionNotMatchRaised);
										return ITK_err;
									}
									if(strcmp(nwLifeCycleS,"LcsNwAppr")==0)
									{
										printf("\n @@ Else Request is approved. \n");fflush(stdout);
									}
								}
								else
								{
										printf("\n @@ Else Inside the approval condition for new part\n");fflush(stdout);
										t5NwPartAppNeeded = (char *) MEM_alloc( 1000 * sizeof(char) );
										strcpy(t5NwPartAppNeeded,"New Part Request is Not Approved for Newly Created TC Part Number ");
										strcat(t5NwPartAppNeeded,"Raise the New Part Request in Creo or Catia for TC Part which is having Cad Data For SPARE-KIT,Please Use the Option Crete-->New Part Request. Fill the Form and Submit to LifeCycle [New Part Request]");
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err, t5NwPartAppNeeded);
										return ITK_err;
								}
							}///
							}
						}
					}
		//
		//					///////////////////////////test message !!!!!!
					//NewPartS1 = (char *) MEM_alloc( 100 * sizeof(char) );
					//strcpy(NewPartS1,"*");
					//strcat(NewPartS1,desid);
					//strcat(NewPartS1,"*");
					//printf("\n @@ NewPartS1 is  ----->>> (%s)###\n",NewPartS1);fflush(stdout);
					//npr_qry_values[0]	= NewPartS1;
					//npr_qry_values[1]	= "New Part Request";
					//QRY_find("New Part Request", &NPRQuery);
					//QRY_execute(NPRQuery, 1, npr_qry_entries, npr_qry_values, &npr_n_found, &PartNewObjs);
					//printf("\n TEST------save_method_Design_3:: n_tags_found==>%d",npr_n_found);fflush(stdout);
					//if(npr_n_found==0)
					//{
					//	EMH_clear_errors();
					//	EMH_store_error_s1(EMH_severity_error,ITK_err, "New Part Request Not found!!!!");
					//	return ITK_err;
					//}


				}
				  }
			}
		}
	}

	  }
	 /*End New Part Request Validation Calling Sudhir!!!!!!!*/

		if(ITEM_ask_latest_rev(objTag,&LatestRev)!=ITK_ok);PrintErrorStack();
		if (LatestRev!=NULLTAG)
		{
			if( AOM_ask_value_string(LatestRev,"item_revision_id",&desRev)!=ITK_ok);PrintErrorStack();
		}
		printf("\n save_method_Design_3::desRev: [%s]", desRev);fflush(stdout);

		if(tc_strcmp(desRev,"NR")==0)
		{
			if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();

			printf("\n  C--Inside NR check----");fflush(stdout);
			if(AOM_lock(LatestRev));
			if(POM_set_attr_string(1,&LatestRev,attr_id,"NR;1")) PrintErrorStack();
			if(AOM_save(LatestRev))PrintErrorStack();
			if(AOM_unlock(LatestRev))PrintErrorStack();
			if(AOM_refresh(LatestRev,1))PrintErrorStack();
			if(AOM_refresh(objTag,1))PrintErrorStack();
			printf("\n  NR;1 updated");fflush(stdout);

			if(GRM_list_secondary_objects_only(LatestRev,relation_type,&cnt,&attachments))PrintErrorStack();
			printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);

			for(ij=0;ij<cnt;ij++)
			{
				dataset = attachments[ij];
				if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
				printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

				if (strcmp(ObjectClassType,"Design Revision Master")==0 || strcmp(ObjectClassType,"T5_SparKitRevisionMaster")==0)//T5_SparKitRevisionMaster
				{
					if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
					printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
					oojname=strtok(ObjectName,"/");
					strcat(oojname,"/");
					strcat(oojname,"NR;1");
					printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);

					if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();

					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)) PrintErrorStack();
					if(AOM_save(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
					break;
				}
			}
			//if (CR_create_release_status("ERC Review",&status_rel))PrintErrorStack();
			//if(EPM_add_release_status(status_rel,1,&LatestRev,retain))PrintErrorStack();
		}

	}
	printf("\n Design--METHOD_ppost_action_type---save_method_Design_3--End.....\n"); fflush(stdout);

	return error_code;
}

//Added by kalpesh(23_aug_2018)[Modified on 14_aug2019]

extern DLLAPI int  save_method_ee_part(METHOD_message_t *msg, va_list args)
{
	int error_code			= ITK_ok;
	tag_t objTag			= va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char *desid				= NULL;
	char *Desc				= NULL;
	char *NewDesc			= NULL;
	char *DerRoleNme		= NULL;
	char *DerRoleNme1		= NULL;
	char *NewDescription	= NULL;
	tag_t rev				= NULLTAG;
	char *objname			= NULL;

	tag_t*   resultTags		= NULLTAG;
	char *DrwName           = NULL;
	char *DrwName1          = NULL;
	char *parent_name       = NULL;
	char *group_name        = NULL;
	char *Role_name         = NULL;
	char *Grp_name          = NULL;
	char *Desc_obj2         = NULL;
	char *item_rev_id       = NULL;
	char *currpro           = NULL;
	tag_t attr_id ;
	int cnt=0;

	tag_t	*attachments    = NULLTAG;
	int		ij				=0;
	int		jk				=0;
	int		jkl				=0;
	int		Rolflag			=0;
	int		dsflag			=0;
	char
	*qry_entries[2]						= {"Name","Type"},
	*qry_values[2]						= {"*","CMI2Drawing"};
	int index,resultCount=0,j=0;
	char		*ObjectClassType        = NULL;
	char		*ObjectName             = NULL;
	char		*desi_grp               = NULL;
	char*		oojname = NULL;
	tag_t		form_attr_id ;
	tag_t		relation_type            = NULLTAG;
	tag_t		DesRolTag                = NULLTAG;
	tag_t		Currproj                 = NULLTAG;
	tag_t		GroupMem                 = NULLTAG;
	tag_t		Roletag                  = NULLTAG;
	tag_t		grptag                                                                                                                   = NULLTAG;
	tag_t		projobj;
	tag_t		dataset                = NULLTAG;
	tag_t		ActGm                  = NULLTAG;
	tag_t		ActGm1                 = NULLTAG;
	tag_t		status_rel             = NULLTAG;
	tag_t		projid                 = NULLTAG;
	tag_t		tagItem=NULLTAG;
	logical		checkout				= 0;
	logical		checkoutp				= 0;
	logical		retain					= 0;
	logical    promem                   = 0;

	char		*ee_weight				= NULL;
	char		*ee_desc				= NULL;
	char		*ee_keyword				= NULL;
	char		*ee_ecutype				= NULL;
	char		*ee_AppforEOL			= NULL;
	char		*ee_EPreadable			= NULL;
	char		*ee_swPartType			= NULL;

	tag_t		reln_type				= NULLTAG;
	tag_t		*secondary_objects		= NULLTAG;
	char		*username;
	tag_t		user_tag				=NULLTAG;
	const char		reason;
	const char		reason1;
	const char		change_id;
	const char		change_id1;
	const char		dir_name;
	const char		dir_name1;
	char			*ObjProject			= NULL;
	char			*dst_name			= NULL;
	char			*objPartType		= NULL;
	char			*object_typeDS		= NULL;

	char type_name2[TCTYPE_name_size_c+1];
	double objWeightVal ;
	double roundedWtVal ;
	char wgtstr[100];
	//1.25
	tag_t   qryTag     = NULLTAG;
	int     n_entry    = 1;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	int     rsltCount      =  0;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char       *DesgTyp            = NULL;
	char       *info1   = NULL;
	char       *MPart_Desg    = NULL;
	char       *Part_DegGrp   = NULL;
	char       *Part_prj             = NULL;
	char       *DesgNo             = NULL;
	char       *sDesgNoG        = NULL;
	char       *sDesgNoT         = NULL;
	char       *sDesgNoVC      = NULL;
	char       *sDesgNoV        = NULL;
	char       *sDesgNoVCCR = NULL;
	char       *PrtProj               = NULL;
	char       *info2   = NULL;
	char       *PrtDR  = NULL;
	char       *sDesgNoD        = NULL;
	char       *Part_Desg        = NULL;
	char       *Part_Proj          = NULL;
	char       *Proj_typ                            = NULL;
	tag_t     Project_t                             = NULLTAG;
	tag_t     ObjTypProj         = NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	//1.25
	//char **val=NULL;
	                //Amol
	tag_t TagQryContObjSite = NULLTAG;
	//tag_t *cntr_objects = NULL;
	char   *desidForTRL=NULL;
	char   *sLastThreeChar=NULL;
	char   *NewIDTRL=NULL;
	int CntrCount = 0;
	int           n_Input = 2;

	char   *RepalcedID=NULL;
	char       *DesgTypTRL     = NULL;
	//Amol

	int iTemp=0;

	int desclength = 0,index1=0;
	int desccnt = 0,n_entries=2;
	int c_attchs = 0,p=0;
	tag_t                                     primary               = NULLTAG;
	tag_t latest_datas=NULLTAG;
	tag_t                                     objTypeTagDi         = NULLTAG;
	//tag_t                                     latest_rev         = NULLTAG;

	tag_t query = NULLTAG, *cntr_objects = NULL;
	//int n_found = 0;
	char *value=NULL;
	char *value_desc=NULL;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username,&user_tag);
	printf("\npart type is = %s", type_name);
	if(strcmp(type_name,"T5_EE_PartRevision")==0)
	 {
		error_code = AOM_UIF_ask_value(objTag, "t5_DesignGrp", &value);
		//printf("Design group:%s\n", value);
		if(tc_strcmp(value, "16") != 0)
		{
			printf("\n Unable to create part, design group must be 16 \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, design group must be 16");
			return ITK_err;
		}

		error_code = AOM_UIF_ask_value(objTag, "object_desc", &value_desc);
		if(tc_strcmp(value_desc, "") == 0 || tc_strlen(value_desc) == 0)
		{
			printf("\nPlease provide description...!!\n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, description should be filled.");
			return ITK_err;
		}
		else
		{
			printf("\nDescription of part is filled(Non-Empty), hence EE part is created.\n");fflush(stdout);
		}

		printf("\n Inside preaction type Save Validation 4 design revison Session user %s \n",username);fflush(stdout);
		char *projcodeList=NULL;
		char *projcode=NULL;
		tag_t   projobj1;
		if( AOM_ask_value_string(objTag,"project_ids",&projcodeList)==ITK_ok)
		if( AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)==ITK_ok)
		printf("\n Save Validation 10 Project : <%s> ProjectList : <%s> %d\n",projcode,projcodeList,strlen(projcodeList));fflush(stdout);
		if(strcmp(projcodeList,"")==0 || strlen(projcodeList) < 4) //project_list
		{
			if(strcmp(projcode,"")==0) //project_list
			{
				printf("\n Save Validation 10 Project is  NULL \n");fflush(stdout);
			}
			else
			{
				printf("\n Save Validation 10 TCDCProject from Object in else : %s\n",projcode);fflush(stdout);

				if (PROJ_find(projcode,&projobj1) !=ITK_ok)PrintErrorStack();

				if(projobj1 != NULLTAG)
				{
	//				printf("\nTCDCGetting Master Object for Project\n");fflush(stdout);
	//				if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok)PrintErrorStack();
	//				printf("\nTCDCAfter Master Object for Project\n");fflush(stdout);
					if (PROJ_assign_objects(1 ,&projobj1 ,1 ,&objTag )!=ITK_ok)PrintErrorStack();
					printf("\n Save Validation 10 Assigned to Project\n");fflush(stdout);
				}
				else
				{
					printf("\n Save Validation 10 Project not found\n");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n Projectlist already assigned Project : <%s> ProjectList : <%s>\n",projcode,projcodeList);fflush(stdout);
		}
	    //1.25 t5_PartType

	     if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
	     printf("\n Desc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);

	     if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();

	     if(strcmp(Desc_obj2,"NR;1")==0 )
	     {
	        if(AOM_lock(objTag))PrintErrorStack();
	        printf("\n Before Modification Description for NR;1\n");fflush(stdout);
	        //if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
	        printf("\n After Modification Description for NR;1\n");fflush(stdout);
	        if(AOM_save(objTag))PrintErrorStack();
	        if(AOM_unlock(objTag));PrintErrorStack();
	        if(AOM_refresh(objTag,1))PrintErrorStack();
	     }

	     if(strcmp(Desc_obj2,"NR")==0 )
	     {
	          if(AOM_lock(objTag))PrintErrorStack();
	          printf("\n Before Modification Description\n");fflush(stdout);
	          //if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
	          printf("\n After Modification Description\n");fflush(stdout);
	          if(AOM_save(objTag))PrintErrorStack();
	          if(AOM_unlock(objTag));PrintErrorStack();
	          if(AOM_refresh(objTag,1))PrintErrorStack();

	          printf("\n A--inside NR check\n");fflush(stdout);
	          if(AOM_lock(objTag));
	          if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")) PrintErrorStack();
	          if(AOM_save(objTag))PrintErrorStack();
	          if(AOM_unlock(objTag))PrintErrorStack();
	          printf("\n  NR;1 updated\n");fflush(stdout);

	          if(GRM_list_secondary_objects_only(objTag,relation_type,&cnt,&attachments))PrintErrorStack();
	          printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);

	          for(ij=0;ij<cnt;ij++)
	          {
	              dataset = attachments[ij];
	              if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
	              printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

	              if (strcmp(ObjectClassType,"T5_PeAsmRevisionMaster")==0)
	              {
	                   if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
	                   printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
	                   oojname=strtok(ObjectName,"/");
	                   strcat(oojname,"/");
	                   strcat(oojname,"NR;1");
	                   printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);

	                   if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();

	                   if(AOM_lock(dataset));
	                   if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)) PrintErrorStack();
	                   if(AOM_save(dataset))PrintErrorStack();
	                   if(AOM_unlock(dataset))PrintErrorStack();
	                   break;
	              }
	          }
	          if (CR_create_release_status("ERC Review",&status_rel))PrintErrorStack();
	          if(EPM_add_release_status(status_rel,1,&objTag,retain))PrintErrorStack();
	     }

	     if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);PrintErrorStack();
	     if( AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok);PrintErrorStack();

	     if(strcmp(Desc,"")!=0)
	     {
			desclength = strlen(Desc);
			for(desccnt=0;desccnt<desclength;desccnt++)
			{
				if(Desc[desccnt]=='\n')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='`')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='~')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='|')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='$')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='#')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='@')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='^')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='!')
				                Desc[desccnt] =' ';
				printf("\n [%c]\n",Desc[desccnt]);fflush(stdout);
			}
			//val=(char **)MEM_alloc(sizeof(char **));
			NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
			strcpy(NewDesc,Desc);

			printf("\n !!!!!!!!!!!!!!!!! save_method_10:::::::NewDesc[%s]!!!!!!!!!!!!!!!!!!!\n", NewDesc);fflush(stdout);

			if(NewDesc)
			{
				//AOM_lock(objTag);
				if(AOM_set_value_string(objTag,"object_desc",NewDesc)!=ITK_ok);PrintErrorStack();
				if(AOM_save(objTag)!=ITK_ok);PrintErrorStack();
				//AOM_unlock(objTag);
				if( AOM_ask_value_string(objTag,"object_desc",&NewDescription)!=ITK_ok);PrintErrorStack();
				printf("\n !!!!!!!!!!!!!!!!! save_method_ee_part:::::::NewDescription[%s]!!!!!!!!!!!!!!!!!!!\n", NewDescription);fflush(stdout);
			}
		}
         //}
	}
    return error_code;
}

//16_sept19(EE Parttype update)
extern DLLAPI int ee_part_post(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;
	tag_t		objTag				= va_arg(args, tag_t);

	char		*ee_parttype		= NULL;
	char		type_name[TCTYPE_name_size_c+1];
	tag_t		objTypeTag			= NULLTAG;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	printf("\nPart type is:%s", type_name);
	if(strcmp(type_name,"T5_EE_PartRevision")==0)
	{
		error_code = AOM_UIF_ask_value(objTag, "t5_EE_PartType", &ee_parttype);
		printf("\nEE Part Type:%s\n", ee_parttype);

		if(AOM_lock(objTag))PrintErrorStack();
		printf("\n Before setting EE Part Type\n");fflush(stdout);
		if( AOM_set_value_string(objTag,"t5_PartType",ee_parttype))PrintErrorStack();
		printf("\n After setting EE Part Type\n");fflush(stdout);
		if(AOM_save(objTag))PrintErrorStack();
		if(AOM_unlock(objTag));PrintErrorStack();
		if(AOM_refresh(objTag,1))PrintErrorStack();
	}
	return error_code;
}
//End(kalpesh)

extern DLLAPI int  save_Post_DesRev(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTypeTag;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t objTag = va_arg(args, tag_t);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();



	if(strcmp(type_name,"Design Revision")==0)
	{
		char   *sPartType1	 =NULL;
		char   *sCatName	 =NULL;
		
		///
		
		char* desid=NULL;
		if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);PrintErrorStack();
		printf("\n IDDDD1==%s",desid);fflush(stdout);
		//D9Y01 A9Z01 CompCodeSet
            if(tc_strstr(desid,"D9Y01")!=NULL)
            {
			printf("\n IDDDD2==%s",desid);fflush(stdout);
			 if(AOM_lock(objTag));
                if(AOM_set_value_string(objTag,"t5_ColourInd","Y"))PrintErrorStack();
                if(AOM_save(objTag))PrintErrorStack();
                if(AOM_unlock(objTag))PrintErrorStack();
			
			
				
            if(AOM_lock(objTag));
                if(AOM_set_value_string(objTag,"t5_PrtCatCode","BODY_SHELL"))PrintErrorStack();
                if(AOM_save(objTag))PrintErrorStack();
                if(AOM_unlock(objTag))PrintErrorStack();
            }
            else if(tc_strstr(desid,"A9Z01")!=NULL)
            {
			
			printf("\n IDDDD2==%s",desid);fflush(stdout);
				 if(AOM_lock(objTag));
                if(AOM_set_value_string(objTag,"t5_ColourInd","Y"))PrintErrorStack();
                if(AOM_save(objTag))PrintErrorStack();
                if(AOM_unlock(objTag))PrintErrorStack();		
				
            if(AOM_lock(objTag));
            if(AOM_set_value_string(objTag,"t5_PrtCatCode","LOADBODY_SHELL"))PrintErrorStack();
            if(AOM_save(objTag))PrintErrorStack();
            if(AOM_unlock(objTag))PrintErrorStack();
            }
    // END D9Y01 A9Z01
		
		
		
		///

		if( AOM_ask_value_string(objTag,"t5_PartType",&sPartType1)!=ITK_ok);PrintErrorStack();
		if( AOM_ask_value_string(objTag,"t5_CategoryName",&sCatName)!=ITK_ok);PrintErrorStack();


		if((tc_strcmp(sPartType1,"A")==0 || tc_strcmp(sPartType1,"C")==0) || tc_strcmp(sPartType1,"SA")==0 || tc_strcmp(sPartType1,"SP")==0)
		{
			printf("\n	Keyword description :%s",sCatName);fflush(stdout);
			if(tc_strcmp(sCatName,"")==0)
			{
				printf("\n Keyword description is NULL\n");fflush(stdout);

			}
			else
			{
				if(AOM_lock(objTag))PrintErrorStack();
				printf("\n Before setting Description\n");fflush(stdout);
				if( AOM_set_value_string(objTag,"object_desc",sCatName))PrintErrorStack();
				printf("\n After setting Description\n");fflush(stdout);
				if(AOM_save(objTag))PrintErrorStack();
				if(AOM_unlock(objTag));PrintErrorStack();
				if(AOM_refresh(objTag,1))PrintErrorStack();
			}
		}


	}
	return error_code;
}

extern DLLAPI int  save_method_durafit(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];

	char* username = NULL;
	char* sDuraFitRefPart = NULL;
	char* sDuraFitModLvl = NULL;
	char* rlsstatus1 = NULL;
	char* ErrorString = NULL;
    tag_t user_tag=NULLTAG;
	int		n_tags_found	=	0;
	tag_t	*tags_found	=	NULLTAG;
	int		n_revtags_found	=	0;
	tag_t	*revtags_found	=	NULLTAG;
	int		count;
	int		NStatus=0;
	int		errordisplay=0;
	tag_t *status_list=NULLTAG;
	tag_t revstatus = NULLTAG;
	logical StatusFound=false;
	char  name[WSO_name_size_c+1]    = {'\0'};

	const char
        *attrs[1] = {"item_id"},
        *values[1]	= {"*"};


	const char
        *attrs2[1] = {"item_id"},
        *values2[1]	= {"*"};

	char    temp_parent_item_rev_id[10]= {'\0'};

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username,&user_tag);

	if(strcmp(type_name,"T5_DuraFitPartRevision")==0) //T5_DuraFitPartRevision
	{
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			if( AOM_ask_value_string(objTag,"t5_DuraFitRefPart",&sDuraFitRefPart)!=ITK_ok);PrintErrorStack();
			if( AOM_ask_value_string(objTag,"t5_DuraFitModLvl",&sDuraFitModLvl)!=ITK_ok);PrintErrorStack();
			printf("\n sDuraFitRefPart: [%s]",sDuraFitRefPart);fflush(stdout);
			printf("\n sDuraFitModLvl: [%s]",sDuraFitModLvl);fflush(stdout);

			values2[0] = sDuraFitRefPart;
			if(ITEM_find_items_by_key_attributes(1,attrs2, values2, &n_tags_found, &tags_found)!=ITK_ok)PrintErrorStack();
			printf("\n n_tags_found: [%d]",n_tags_found);fflush(stdout);
			if(n_tags_found>0)
			{
				printf("\n DuraFitRefPart: [%s] found!!",sDuraFitRefPart);fflush(stdout);
				tc_strcpy(temp_parent_item_rev_id,sDuraFitModLvl);
				tc_strcat(temp_parent_item_rev_id,"*");
				values[0] = sDuraFitRefPart;
				if(ITEM_find_item_revs_by_key_attributes(1,attrs, values, temp_parent_item_rev_id, &n_revtags_found, &revtags_found)!=ITK_ok)PrintErrorStack();
				printf("\n n_revtags_found: [%d]",n_revtags_found);fflush(stdout);
				if(n_revtags_found>0)
				{
					printf("\n sDuraFitModLvl: [%s] found!!",sDuraFitModLvl);fflush(stdout);
					WSOM_ask_release_status_list(revtags_found[0] ,&count,&status_list);
					if(count>0)
					{
						for(NStatus=0;NStatus<count;NStatus++)
						{
							CR_ask_release_status_type(status_list[NStatus],name);
							printf("\n name==>[%s] \n",name);fflush(stdout);

							if(tc_strcmp(name,"T5_LcsReview")==0 || tc_strcmp(name,"T5_LcsWorking")==0)
							{
								printf("\n sDuraFitModLvl: [%s] is not ERC Released!!",sDuraFitModLvl);fflush(stdout);
								StatusFound = true;
							}
							if(tc_strcmp(name,"T5_LcsErcRlzd")==0)
							{
								StatusFound = false;
								errordisplay = 1;
							}
						}
						if(StatusFound==true && errordisplay==0)
						{
							printf("\n Given Mod level is not ERC Released!! ");fflush(stdout);
							ErrorString=(char *) MEM_alloc(250);
							printf("After mem alloc\n");
							tc_strcpy (ErrorString, "Entered DuraFitReference Part:");
							strcat(ErrorString,sDuraFitRefPart);
							strcat(ErrorString," and Ref Mod level ");
							strcat(ErrorString,sDuraFitModLvl);
							strcat(ErrorString,"is not ERC Released!!. Please select other Refrence Part / Mod Level.");
							EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
							return ITK_err;
						}
					}
				}
				else
				{
					printf("\n sDuraFitModLvl: [%s] not found!!",sDuraFitModLvl);fflush(stdout);
					ErrorString=(char *) MEM_alloc(250);
					printf("After mem alloc\n");
					tc_strcpy(ErrorString,"Entered Mod Level :");
					strcat(ErrorString,sDuraFitModLvl);
					strcat(ErrorString,"for DuraFitReference Part :");
					strcat(ErrorString,sDuraFitRefPart);
					strcat (ErrorString, "is not available!!");
					strcat(ErrorString,". Please select other DuraFitReference Mod level");
					EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
					return ITK_err;
				}
			}
			else
			{
				printf("\n DuraFitRefPart: [%s] not found!!",sDuraFitRefPart);fflush(stdout);
				ErrorString=(char *) MEM_alloc(150);
				printf("After mem alloc\n");
				tc_strcpy(ErrorString,sDuraFitRefPart);
				strcat (ErrorString, ": Entered DuraFitReference Part is not available!!");
				strcat(ErrorString,". Please select other DuraFitReference Part");
				EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
				return ITK_err;
			}
		}
		MEM_free(tags_found);
		MEM_free(revtags_found);
		MEM_free(ErrorString);
	}
	return error_code;
}
extern DLLAPI int  save_method_4(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag = NULLTAG , item_tag = NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char *desid = NULL;
	char *Desc = NULL;
	char *NewDesc = NULL;
	char *DerRoleNme = NULL;
	char *DerRoleNme1 = NULL;
	char *NewDescription = NULL;
	tag_t rev=NULLTAG;
	char *objname = NULL;
	char *objMat = NULL;
	char *objMatThickness = NULL;
	char *objOppHandDrg = NULL;
	char *objRefDrw = NULL;
	char *objSurfStd = NULL;
	char *ActGmName = NULL;
	char *ActGmName1 = NULL;
	double objWeight ;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	tag_t	queryTag	= NULLTAG;

	tag_t*	resultTags =NULLTAG;
	char *DrwName		= NULL;
	char *DrwName1		= NULL;
	char *parent_name	= NULL;
	char *group_name	= NULL;
	char *Role_name		= NULL;
	char *Grp_name		= NULL;
	char *Desc_obj2		= NULL;
	char *item_rev_id	= NULL;
	char *currpro		= NULL;
	tag_t attr_id = NULLTAG;
	int				cnt=0;
	int				Rolflag1=0;
	int				Gmcnt=0;
	int				Gmcnt1=0;
	int				Gmcnt2=0;
	int				Gmcnt3=0;
	tag_t			*attachments								= NULLTAG;
	tag_t			*GmFound								= NULLTAG;
	tag_t			*GmFound1								= NULLTAG;
	tag_t			*GmFound2								= NULLTAG;
	tag_t			*GmFound3								= NULLTAG;
	int				ij=0;
	int				jk=0;
	int				jkl=0;
	int				Rolflag=0;
	int				dsflag=0;
	char
        *qry_entries[2] = {"Name","Type"},
        *qry_values[2]	= {"*","CMI2Drawing"};
	int     index,resultCount=0,j=0;
	char		   *ObjectClassType		= NULL;
	char		   *ObjectName		= NULL;
	char		   *desi_grp		= NULL;
	char* oojname = NULL;
	tag_t form_attr_id ;
	tag_t			relation_type								= NULLTAG;
	tag_t			DesRolTag								= NULLTAG;
	tag_t			Currproj								= NULLTAG;
	tag_t			GroupMem								= NULLTAG;
	tag_t			Roletag								= NULLTAG;
	tag_t			grptag								= NULLTAG;
	tag_t   projobj = NULLTAG;
	tag_t			dataset		= NULLTAG;
	tag_t			ActGm		= NULLTAG;
	tag_t			ActGm1		= NULLTAG;
	tag_t			status_rel					= NULLTAG;
	tag_t			projid					= NULLTAG;
	tag_t    tagItem=NULLTAG;
	logical	checkout				= 0;
	logical	checkoutp				= 0;
	logical			retain							= 0;

	logical	promem				= 0;

	tag_t reln_type =NULLTAG;
	tag_t *secondary_objects=NULLTAG;
	char* username = NULL;
	tag_t user_tag=NULLTAG;
	const char	   reason;
	const char	   reason1;
	const char     change_id;
	const char     change_id1;
	const char     dir_name;
	const char     dir_name1;
	char	*ObjProject= NULL;
	 char *dst_name = NULL;
	char *objPartType = NULL;
	char		   *object_typeDS		= NULL;

	char type_name2[TCTYPE_name_size_c+1];
	double objWeightVal ;
	double roundedWtVal ;
	char wgtstr[100];

	char *DesignGrp = "60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,54,16";//Adi
	char *DesignGrpCatia = NULL;//Adi
		char *Rev_id			= NULL;//Adi
	char *Rev_Sub			= NULL;//Adi
	char *Rev_Sub1			= NULL;//Adi
	int   Rev_idlength		= 0;	   //Adi
	char *PartTypeDR		= 0;	   //Adi

	/************ Adi 1.35 ***********/
	//tag_t	Attdataset		= NULLTAG;
	tag_t  *DiAttached		= NULLTAG;
	int	    pp				= 0;
	int     catcnt			= 0;
	char   *ObjectTypeX		= NULL;
	tag_t	rev1			= NULLTAG;
	char	*Desc_obj		= NULL;
	tag_t   relation_typeX  = NULLTAG;
	int		PrtChkFlag		=	0;
	int		PrdChkFlag		=	0;

	/************ Adi 1.35 ***********/

	tag_t	objMasterTag	= NULLTAG;					//Adi 1.35
	int count1				= 0;						//Adi 1.35
	tag_t * rev_list1		= NULLTAG;					//Adi 1.35

	char	*STDesGrp		= NULL;						//Adi ST

	//1.25
	tag_t   qryTag     = NULLTAG;
	tag_t   qryTag1     = NULLTAG;
	int     n_entry    = 1;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values3     =  (char **) MEM_alloc(10 * sizeof(char *));

	int     rsltCount      =  0;
	int     ValCnt      =  0;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   *CntrlObjectTag11      = NULLTAG;
	tag_t   *ValCntrlObjectTag1     = NULLTAG;
	char	*DesgTyp	= NULL;
	char	*info1	= NULL;
	char	*MPart_Desg	= NULL;
	char	*Part_DegGrp	= NULL;
	char	*Part_type		= NULL;
	char	*Part_prj	= NULL;
	char	*DesgNo	= NULL;
	char	*sDesgNoG	= NULL;
	char	*sDesgNoT	= NULL;
	char	*sDesgNoTN	= NULL;
	char	*sDesgNoVC	= NULL;
	char	*sDesgNoV	= NULL;
	char	*sDesgNoVCCR	= NULL;
	char	*PrtProj	= NULL;
	char	*info2	= NULL;
	char	*Prttyp	= NULL;
	char	*PrtDR	= NULL;
	char	*sDesgNoD	= NULL;
	char	*Part_Desg	= NULL;
	char	*Part_Proj	= NULL;
	char 	*Proj_typ		= NULL;
	char    *ThirdBarrel    = NULL;
	char    *ForthBarrel    = NULL;
	char    *SpareCrit      = NULL;
	tag_t	Project_t		= NULLTAG;
	tag_t	ObjTypProj	= NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	//1.25
	//char **val=NULL;
		//Amol
	tag_t TagQryContObjSite = NULLTAG;
	//tag_t *cntr_objects = NULLTAG;
	char   *desidForTRL=NULL;
	char   *sLastThreeChar=NULL;
	char   *NewIDTRL=NULL;
	int CntrCount = 0,ByPasQCount = 0,CheckBypasFlag=0;
	int	n_Input = 2;
	char *qry_Input[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_InputVal[2] = {"TRILIX", "TRILIX"};
	char *qry_BypVal[2] = {"VALDBYPASS", "DSGPROJ"};
	char   *RepalcedID=NULL;
	char	*DesgTypTRL	= NULL;
	//Amol
	char	*info4	= NULL;
	char *PrtCol = NULL;
	char *PrtClass = NULL;
	tag_t  	PrtCls =	NULLTAG;
	int DRValiFlag=0;
	int iTemp=0;
	char *release_status = NULL;
	int desclength = 0,index1=0;
	int desccnt = 0,n_entries=2;
	int c_attchs = 0,p=0;
	tag_t			primary					= NULLTAG;
	tag_t latest_datas=NULLTAG;
	tag_t			objTypeTagDi				= NULLTAG;
	tag_t  CurrentRoleTag = NULLTAG;
	char roleName[SA_name_size_c+1];

	char    **qry_dfqCtrObjct     =  (char **) MEM_alloc(10 * sizeof(char *));
	int n_dfqentry = 1;
	int rsltDfqCount = 0;
	char	*info3		= NULL;
	char	*info5		= NULL;
	char	*info6		= NULL;
	char	*info7		= NULL;
	char	*info8		= NULL;
	char	*info9		= NULL;
	char	*info10		= NULL;

	//mbb_start
	int			Key_qry_entry		= 1;
	int			CntlObjCount		= 0;
	int			intDay				= 0;
	int			intMonth			= 0;
	int			intYear				= 0;
	int			rev_cnt				= 0;
	int			iji					= 0;
	int			FlagKey				= 0;
	char		*DitemRev_ID		= NULL;
	char		*Ditem_ID			= NULL;
	char		*Ditem_ID2			= NULL;
	char		*CreationDate		= NULL;
	char		*rlstatus			= NULL;
	char		*AhdMkByInd			= NULL;
	char		*CarMkByInd			= NULL;
	char		*DwdMkByInd			= NULL;
	char		*JsrMkByInd			= NULL;
	char		*JdlMkByInd			= NULL;
	char		*LkoMkByInd			= NULL;
	char		*PnrMkByInd			= NULL;
	char		*PCBUMkByInd		= NULL;
	char		*PuneMkByInd		= NULL;
	char		*PuneUVMkByInd		= NULL;
	char		*SrgMkByInd			= NULL;
	char		*R_Date				= NULL;
	char		*month				= NULL;
	char		*day				= NULL;
	char		*Year				= NULL;
	char		*ReqKeyWord			= NULL;
	char		*PrevKeyWord		= NULL;
	tag_t		CntrlObjQry			= NULLTAG;
	tag_t		DItem_tag			= NULLTAG;
	tag_t		LatestRev_tag		= NULLTAG;
	tag_t		*CntObj_Tag2		= NULLTAG;
	tag_t		*rev_list_set		= NULLTAG;

	char		*QryCntr_entry[1]	= {"SYSCD"};
	char		**QryCntr_values    = (char **) MEM_alloc(10 * sizeof(char *));
	//mbb_end

	// ClrIndicator =C  Should not be allowed on Non Color Revision
	int		ClrBomEtry				= 1;
	int		ClrBOMQryC				=0;
	int		PrtClassFlag			=0;
	tag_t	ClrInd_CtrObjQryTag		= NULLTAG;
	tag_t	*ClrBOMCtrObj			=NULLTAG;
	char	*info1_value			= NULL;
	char	*token					= NULL;
	char	*ClrIndicator			= NULL;
	char    *ClrBomQryEtry[1]		= {"SYSCD"};
	char    **ClrBOMQryVal			=  (char **) MEM_alloc(100 * sizeof(char *));
	//ClrInd End

		//Amol K
	tag_t TagQryPartyPart = NULLTAG;
	int outobjcnt = 0;
	int	n_InputC = 2;
	tag_t  *Res_des_objs = NULLTAG;
	//char *qryParty_Input[2] = {"ID", "Ref Part Number"};//MBOM implementation for CV TZ-1.69
	char *qryParty_Input[2] = {"ID", "Party Part Number"};//MBOM implementation for CV TZ-1.69
	char	*RefPartNumber	= NULL;
	char	*DesgNoFound	= NULL;
	char *ErrorString = NULL;
	tag_t	Destag		= NULLTAG;
	char	*DesRNo	= NULL;
	int MilStflg=0;
	int   iPPRid		= 0;
	char	*DesgTypPPR	= NULL;
	char   *desidForPPR=NULL;
	char   *sLastFourChar=NULL;
	//End Amol K
	char *ProSubStr =NULL;
	char *BussiNameS =NULL; // Added By Sudhir...
	tag_t query = NULLTAG, *cntr_objects = NULLTAG;
	//int n_found = 0;
	char
         *qry_entries1[2] = {"SUBSYSCD", "SYSCD"},
        *qry_values1[2] =  {"*", "MATCLS"};
  int	PartCreationBypassFlag = 0;

  //CR/ERC/PLM/22/0027 , Validation for Module Address Added on Design Revision. 05-02-2022
  char* moduleAddress = NULL;


//	//Rohit Starts

	//	tag_t		*bvrss			=	NULLTAG;
	//	tag_t		bvr				=	NULLTAG;
	//	tag_t		*occsal			=	NULLTAG;
	//	tag_t		*Effobbj		=	NULLTAG;
	//	tag_t		nChildItem		=	NULLTAG;
	//	tag_t		nbvrchild		=	NULLTAG;
	//	tag_t		tagref			=	NULLTAG;
	//	tag_t		*referencersV	=	NULLTAG;
	//	tag_t		objTypeTagV		=	NULLTAG;
	//	tag_t		status_reviewV	=	NULLTAG;
	//
	//	int    bvr_count	=	0;
	//	int n_occs=0;
	//	int iy	=	0;
	//	int iz	=	0;
	//	int occsal_arr	=	0;
	//	int		effcnt = 0;
	//	int	n_parentsV = 0;
	//	int *levelsV	   = 0;
	//	int il		= 0;
	//	int n_referencersV = 0;
	//
	//
	//	char *CItem_ID		= NULL;
	//	char *PItem_ID		= NULL;
	//	char *P_type		= NULL;
	//	char *DML_task		= NULL;
	//	char *C_DsgGrp		= NULL;
	//	char *C_item_id		= NULL;
	//	char *bvrItem_ID	= NULL;
	//	char *bvrDsgGrp		= NULL;
	//	char *occurrence_name = NULL;
	//	char *nocc_item_id	= NULL;
	//	char *nocc_rev_id	= NULL;
	//	char **relationsRefV = NULL;
	//	char  type_nameV[TCTYPE_name_size_c+1];
	//
	//
	//
	//	tag_t cvprod_CntrlOBJB		=	NULLTAG;
	//	tag_t *CntrlObject_cvprodB	=	NULLTAG;
	//
	//	int cvprod_entriesB			=	1;
	//	int	cvprod_foundB			=	0;
	//
	//	char	*info6cv			=	NULL;
	//
	//	char *qry_cvprodcntrlB[1] = {"SYSCD"};
	//	char **qry_valuescvprodB = (char **) MEM_alloc(10 * sizeof(char *));
	//
	//	qry_valuescvprodB[0] = "CVBUBOMCntrlObjCOPY";
	//Rohit Ends


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username,&user_tag);

	if (AOM_ask_value_string(objTag,"item_id",&DesgNo)!=ITK_ok); PrintErrorStack();

	//Sagar Start
	printf("\n In save_method_4...type_name = [%s]  DesgNo: [%s] \n",type_name,DesgNo);fflush(stdout);

	//neha -- color Ind

	//neha

	tag_t nt_Window		= NULLTAG;
	tag_t t_RRule		= NULLTAG;
	tag_t ItemTag		= NULLTAG;
	tag_t t_TLine		= NULLTAG;
	tag_t UseMaster		= NULLTAG;
	tag_t Nrev			= NULLTAG;
	tag_t t_Childobject = NULLTAG;
	tag_t TagCtrlQryContObj = NULLTAG;
	tag_t *t_PrtChldren = NULLTAG;
	char *ColInd_str	= NULL;
	char *cp_ItemID_str	= NULL;
	char *ColIndicator	= NULL;
	char *ColIndYPrt	= NULL;
	int ChildCount,iChPrts,iItemId = 0;
	tag_t objTagg = va_arg(args, tag_t);

	//end neha
	char *ctrlQryEntries[2] = {"SYSCD", "SUBSYSCD"};
	char *ctrlQryValues[2] = {"ColIndValSave", "ColIndValSave1"};
	tag_t TagCtrlQryObj = NULLTAG,*ctrlCntrObj = NULL;
	int		nEntr		= 2;
	int		nFnd		= 0;

	if(QRY_find2("ControlObjQry", &TagCtrlQryObj));
	if(QRY_execute(TagCtrlQryObj, nEntr, ctrlQryEntries, ctrlQryValues, &nFnd, &ctrlCntrObj));
	printf("\n save_method_4::Objects for Query ControlObjQry from structure manager validation of save method 4 : %d", nFnd);fflush(stdout);

	if(nFnd > 0)
	{

		if(BOM_create_window (&nt_Window) !=ITK_ok) PrintErrorStack();
		printf("\nAfter nt_Window\n");fflush(stdout);
		if(CFM_find( "Latest Working", &t_RRule )!=ITK_ok) PrintErrorStack();
		printf("\nAfter t_RRule\n");fflush(stdout);
		if(BOM_set_window_config_rule(nt_Window, t_RRule )!=ITK_ok) PrintErrorStack();
		printf("\nAfter BOM_set_window_config_rule\n");fflush(stdout);
		if(BOM_set_window_pack_all (nt_Window, true)!=ITK_ok) PrintErrorStack();
		printf("\nAfter BOM_set_window_pack_all\n");fflush(stdout);
		if(BOM_set_window_top_line (nt_Window, ItemTag, objTag, NULLTAG, &t_TLine)!=ITK_ok) PrintErrorStack();
		printf("\nAfter BOM_set_window_top_line\n");fflush(stdout);
		if(t_TLine!=NULLTAG)
		{
			printf("\nInside t_Tline\n");fflush(stdout);
			if(BOM_line_ask_child_lines (t_TLine, &ChildCount, &t_PrtChldren)!=ITK_ok) PrintErrorStack();
			printf("\nAfter BOM_line_ask_child_lines\n");fflush(stdout);
		}
		printf("\n Child Parts Found in BomLine are :: [%d]\n",ChildCount);fflush(stdout);

		//tag_t window1=NULLTAG;
		//tag_t rule1=NULLTAG;
		//tag_t top_line1 =NULLTAG;
		//int n_BL1=0;
		//tag_t *child1= NULL;
		//
		///*Getting ChildParts through BOM LINE*/
		//if(BOM_create_window (&window1)!=ITK_ok)PrintErrorStack();
		//if(CFM_find( "Latest Working", &rule1 )!=ITK_ok)PrintErrorStack();
		//if(BOM_set_window_config_rule( window1, rule1 )!=ITK_ok)PrintErrorStack();
		//if(BOM_set_window_pack_all (window1, false)!=ITK_ok)PrintErrorStack();
		//if(BOM_set_window_top_line (window1, null_tag,objTag, null_tag, &top_line1)!=ITK_ok)PrintErrorStack();
		//printf("\n\t Before the if condition");fflush(stdout);
		//if(top_line1!=NULLTAG)
		//{
		//	if(BOM_line_ask_child_lines(top_line1, &n_BL1, &child1))PrintErrorStack();
		//	printf("\n\t No of child objects are n : %d",n_BL1);fflush(stdout);
		//}

		if(ChildCount > 0)
		{
			for (iChPrts = 0; iChPrts < ChildCount; iChPrts++)
			{
				if(t_Childobject) t_Childobject=NULLTAG;
				t_Childobject=t_PrtChldren[iChPrts];
				ITK_CALL(AOM_ask_value_string(objTag,"t5_ColourInd",&ColInd_str));
				printf("\n Color Indicator is----------------------------------> [%s]\n",ColInd_str);

				if(BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
				if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str));
				printf("\n cp_ItemIDD_str is----------------------------------> [%s]\n",cp_ItemID_str);

				ITK_CALL(ITEM_find_item(cp_ItemID_str,&UseMaster));
				printf("\n UseMaster found------>");

				ITK_CALL(ITEM_ask_latest_rev(UseMaster, &Nrev));
				if(nFnd>0)
				{
					if(AOM_UIF_ask_value(Nrev,"t5_ColourInd",&ColIndicator)==ITK_ok)
					{
						printf("\n Inside Colour Ind : %s \n",ColIndicator);fflush(stdout);
						if(tc_strcmp(ColInd_str,"N")==0 && tc_strcmp(ColIndicator,"Y")==0)
						{
							printf("\n Inside if condition \n");fflush(stdout);
							ColIndYPrt=(char *)MEM_alloc(200);
							tc_strcpy(ColIndYPrt,"");
							tc_strcat(ColIndYPrt,cp_ItemID_str);

							//EMH_clear_errors();
							//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr, "The child part : ",ColIndYPrt, " with colour indicator Y, cannot go below assembly with colour ind N. This is invalid combination of colour ind.");

							//return ITK_errStore;
							printf("\n Inside if condition 1\n");fflush(stdout);

							EMH_store_error_s1(EMH_severity_error,ITK_err,"The child part with colour indicator Y, cannot go below assembly with colour ind N. This is invalid combination of colour ind");
							return ITK_err;
							printf("\nOne of the child part color indicator is Y\n");fflush(stdout);

						}
					}
				}
			}
		}
	}
	//end

//Rohit validation Starts

		tag_t		*bvrss			=	NULLTAG;
		tag_t		bvr				=	NULLTAG;
		tag_t		*occsal			=	NULLTAG;
		tag_t		*Effobbj		=	NULLTAG;
		tag_t		nChildItem		=	NULLTAG;
		tag_t		nbvrchild		=	NULLTAG;
		tag_t		tagref			=	NULLTAG;
		tag_t		*referencersV	=	NULLTAG;
		tag_t		objTypeTagV		=	NULLTAG;
		tag_t		status_reviewV	=	NULLTAG;

		int    bvr_count	=	0;
		int n_occs=0;
		int iy	=	0;
		int iz	=	0;
		int occsal_arr	=	0;
		int		effcnt = 0;
		int	n_parentsV = 0;
		int *levelsV	   = 0;
		int il		= 0;
		int n_referencersV = 0;


		char *CItem_ID		= NULL;
		char *PItem_ID		= NULL;
		char *P_type		= NULL;
		char *DML_task		= NULL;
		char *C_DsgGrp		= NULL;
		char *C_item_id		= NULL;
		char *bvrItem_ID	= NULL;
		char *bvrDsgGrp		= NULL;
		char *occurrence_name = NULL;
		char *nocc_item_id	= NULL;
		char *nocc_rev_id	= NULL;
		char **relationsRefV = NULL;
		char  type_nameV[TCTYPE_name_size_c+1];



		tag_t cvprod_CntrlOBJB		=	NULLTAG;
		tag_t *CntrlObject_cvprodB	=	NULLTAG;

		int cvprod_entriesB			=	1;
		int	cvprod_foundB			=	0;

		char	*info6cv			=	NULL;

		char *qry_cvprodcntrlB[1] = {"SYSCD"};
		char **qry_valuescvprodB = (char **) MEM_alloc(10 * sizeof(char *));

		qry_valuescvprodB[0] = "CVBUBOMCntrlObjCOPY";
	//Rohit Ends

		//Rohit New declaration Starts
		
		char	*objID	=	NULL;
		char	*objrevID	=	NULL;
		char	*latest_objIDstr	=	NULL;
		char	*latest_objrevstr	=	NULL;
	
	
		tag_t	latest_objID		=	NULLTAG;
		tag_t	latest_objrev		=	NULLTAG;
		tag_t	t_Window			=	NULLTAG;
		tag_t	t_revrule			=	NULLTAG;
		tag_t	topline_tbom		=	NULLTAG;
		tag_t   *tbom_childs		=	NULLTAG;
		tag_t	tc_Childobject = NULLTAG;
	
		int ChildCount_c = 0;
		int iChPrts_c		=	0;
	
		//Rohit New declaration Ends
	
		if(QRY_find("Control Objects...",&cvprod_CntrlOBJB));
		if(QRY_execute(cvprod_CntrlOBJB, cvprod_entriesB, qry_cvprodcntrlB, qry_valuescvprodB, &cvprod_foundB, &CntrlObject_cvprodB));
		printf("\n\n  CVPROD Control Object SYSCD :[ %d ]\n",cvprod_foundB);	fflush(stdout);	
	
		if(cvprod_foundB > 0)
		{
			printf("\n\n  CVPROD Control Object for SAVE AS functionality found\n");	fflush(stdout);	
			ITK_CALL(AOM_ask_value_string(objTag,"item_id",&objID)); //Rohit BOM
			ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&objrevID)); //Rohit BOM
	
			ITK_CALL(ITEM_find_item(objID,&latest_objID)); //Rohit BOM
			ITK_CALL(ITEM_ask_latest_rev(latest_objID,&latest_objrev)); //Rohit BOM
	
			ITK_CALL(AOM_ask_value_string(latest_objID,"item_id",&latest_objIDstr)); //Rohit BOM
			ITK_CALL(AOM_ask_value_string(latest_objrev,"item_revision_id",&latest_objrevstr)); //Rohit BOM

			ITK_CALL(AOM_ask_value_string(objTag,"t5_PartType",&P_type));	
			printf("\nType of parent is [%s] \n",P_type);fflush(stdout); 

			if(tc_strcmp(P_type,"V")==0)
			{	
				printf("\n\n Expanding BOM as part type is vehicle for SAVE AS functionality\n");	fflush(stdout);	
				ITK_CALL(BOM_create_window(&t_Window));
				ITK_CALL(CFM_find("Latest Working", &t_revrule));
				ITK_CALL(BOM_set_window_config_rule( t_Window, t_revrule));
				ITK_CALL(BOM_set_window_pack_all(t_Window, true));
				ITK_CALL(BOM_set_window_top_line(t_Window,latest_objID,latest_objrev,NULLTAG,&topline_tbom));
				ITK_CALL(BOM_line_ask_child_lines(topline_tbom,&ChildCount_c,&tbom_childs));
				printf("\nLatest Item ID and Rev ID is [%s] and [%s] and child count is [%d]\n",latest_objIDstr,latest_objrevstr,ChildCount_c); fflush(stdout);
	
				if(ChildCount_c > 0)
				{
					for (iChPrts_c = 0; iChPrts_c < ChildCount_c; iChPrts_c++)
					{
						if(AOM_ask_value_string(CntrlObject_cvprodB[0],"t5_Userinfo6",&info6cv));
						printf("\n\nUser Information 6 is : %s",info6cv);	fflush(stdout);
	
						if(tc_Childobject) tc_Childobject=NULLTAG;
						tc_Childobject=tbom_childs[iChPrts_c];
	
						ITK_CALL(AOM_ask_value_string(tc_Childobject,"bl_item_item_id",&CItem_ID));
						ITK_CALL(AOM_ask_value_string(tc_Childobject,"bl_Design Revision_t5_DesignGrp",&C_DsgGrp));	
						
					
						printf("\n Item ID of Child is-------------------> [%s] and its design group is [%s]\n",CItem_ID,C_DsgGrp);
	
						ITK_CALL(ITEM_rev_list_bom_view_revs(objTag,&bvr_count,&bvrss));
						ITK_CALL(PS_list_occurrences_of_bvr(bvrss[0], &n_occs, &occsal));
	
						if(n_occs > 0)
						{
							 ITK_CALL(AOM_lock(bvrss[0]));
							 for (iz = 0; iz<n_occs; iz++)
							 {
								 ITK_CALL(PS_ask_occurrence_child(bvrss[0],occsal[iz], &nChildItem, &nbvrchild));
								 ITK_CALL(AOM_ask_value_string(nChildItem, "item_id", &nocc_item_id));
								if (tc_strcmp(nocc_item_id,CItem_ID)==0)
								{
									if (tc_strstr(info6cv,C_DsgGrp) !=NULL)
									{
										printf("\n nocc_item_id & child_item_id  is [%s] and [%s] \n\n",nocc_item_id,C_DsgGrp);fflush(stdout);
										ITK_CALL(PS_delete_occurrence(bvrss[0], occsal[iz]));
	
										ITK_CALL(AOM_save( bvrss[0] ));
										ITK_CALL(AOM_unlock( bvrss[0] ));
										printf("\n Deleted Successfuly \n\n");fflush(stdout);
									}
								}
	
							 }
	
						}
	
						logical       retain_released_date =TRUE;
						
						printf("\n BEFORE stamping Review status\n");fflush(stdout);
						ITK_CALL(CR_create_release_status("T5_LcsReview",&status_reviewV));
						ITK_CALL(EPM_add_release_status(status_reviewV,1,&objTag,retain_released_date));
						printf("\n After stamping Review status\n");fflush(stdout);		
	
					}
	
					//printf("\nClosing Bom Window\n");fflush(stdout);
					//if(BOM_close_window (t_Window));
					//printf("\nAfter Closing Bom Window\n");fflush(stdout);
				}
			}
		}


	//Rohit validation Ends


//	if(strcmp(type_name,"Design Revision")==0)
//	{
//		char *PartNo   = NULL;
//		char *ProjCode   = NULL;
//		char *CurrentRole = NULL;
//		tag_t   Qry_tag     = NULLTAG;
//		int error_code	= ITK_ok;
//		int No_of_Entry = 2 ;
//		int ControlObj_count = 0;
//		char    *Q_Entry[2]  = {"Name","SUBSYSCD"};
//		char	**Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
//		tag_t *ControlObject_tag = NULLTAG;
//		logical	DelIndicator	= false;
//		char *Error_Msg = (char*)MEM_alloc(sizeof(char) * 3000);
//		tag_t CurrentRole_Tag = NULLTAG;
//		AOM_ask_value_string( objTag, "item_id", &PartNo);
//		AOM_ask_value_string( objTag, "t5_ProjectCode", &ProjCode);
//
//		printf("\n PartNo = %s, Project Code =  %s\n",PartNo,ProjCode);fflush(stdout);
//
//		if(QRY_find("Control Objects...", &Qry_tag));
//
//		if (Qry_tag)
//		{
//			printf("\n Control Object Query Found \n");fflush(stdout);
//
//			Q_Value[0]="PlantDML";
//			Q_Value[1]=ProjCode;
//
//			if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &ControlObj_count, &ControlObject_tag));
//			printf("\n No of Control object Found = %d\n",ControlObj_count);fflush(stdout);
//			if (ControlObj_count > 0)
//			{
//				printf("\n Control Object Found for Plant and Project \n");fflush(stdout);
//				AOM_ask_value_logical( ControlObject_tag[0],"t5_DelInd",&DelIndicator);
//
//				if (DelIndicator == true)
//				{
//					printf("\n Selected project code < %s > is not made live for plant. Part creation is allowed only for Live projects.  \n",ProjCode);fflush(stdout);
//
//					tc_strcpy(Error_Msg,"Selected project code< ");
//					tc_strcat(Error_Msg,ProjCode);
//					tc_strcat(Error_Msg," > is not made live for plant. Part creation is allowed only for Live projects. ");
//
//					EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Error_Msg);
//					return ITK_errStore1;
//				}
//				else
//				{
//					printf("\n Selected Project code is Live for Plant \n");fflush(stdout);
//				}
//			}
//			else
//			{
//				printf("\n Control Object Not Found for Plant and Project \n");fflush(stdout);
//				printf("\n Selected project code < %s > is not made live for plant. Part creation is allowed only for Live projects. \n",ProjCode);fflush(stdout);
//
//				tc_strcpy(Error_Msg,"Selected project code < ");
//				tc_strcat(Error_Msg,ProjCode);
//				tc_strcat(Error_Msg," > is not made live for plant. Part creation is allowed only for Live projects.");
//
//				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Error_Msg);
//				return ITK_errStore1;
//			}
//		}
//
//	}
	//Sagar End

	//CR/ERC/PLM/22/0027 , Validation for Module Address Added on Design Revision. 05-02-2022
	if(tc_strcmp(type_name,"Design Revision")==0)
	{
		if( AOM_ask_value_string(objTag,"t5_PartType",&Part_type)==ITK_ok) PrintErrorStack();
			printf("\n save_method_4::Type found:%s\n", Part_type);
			if(tc_strcmp(Part_type, "M") == 0 || tc_strcmp(Part_type, "EM") == 0)
			{
				//Bypassing this check for DBA users
				//10-June-2022 //CR/ERC/PLM/22/0027 - Removing Loader from bypass
				if((tc_strcmp(username,"infodba")!=0))
				{
					if( AOM_ask_value_string(objTag,"t5_ModuleAddress",&moduleAddress)==ITK_ok) PrintErrorStack();
					if (tc_strlen(moduleAddress)==0)
					{
							printf("\n save_method_4::Design revision cannot be created as Module Address is not Found.\n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Design revision cannot be created, As Module Address (t5_ModuleAddress) is not present.");
							return ITK_err;
					}

				}
			}
	}
	//kalpesh(12_sept19)
	//CR/ERC/PLM/22/0061
	int No_of_Entry = 2 ;
	char    *Q_Entry[2]  = {"Name","SUBSYSCD"};
	char	 **Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
	tag_t   Qry_tag     = NULLTAG;
	int ControlObj_count = 0;
	tag_t *ControlObject_tag = NULLTAG;

	if(QRY_find("Control Objects...", &Qry_tag));

	if(tc_strcmp(type_name,"Design Revision")==0)
	{
		if( AOM_ask_value_string(objTag,"t5_DesignGrp",&Part_DegGrp)==ITK_ok) PrintErrorStack();
		if(tc_strcmp(Part_DegGrp, "16") == 0)
		{
			if( AOM_ask_value_string(objTag,"t5_PartType",&Part_type)==ITK_ok) PrintErrorStack();
			printf("\n save_method_4::B.Type found:%s\n", Part_type);
			if(tc_strcmp(Part_type, "M") == 0 || tc_strcmp(Part_type, "EM") == 0)
			{
				printf("\n save_method_4::B.Bypass for Module and ECU Module.\n");
			}
			else
			{
				if (Qry_tag!=NULLTAG)
				{
						printf("\n save_method_4::B.Control Object Query Found \n");fflush(stdout);

						Q_Value[0]="DESG_REV_EE_Part_Validation";
						Q_Value[1]="DESG_REV_EE_Part_Validation";

						if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &ControlObj_count, &ControlObject_tag));
						printf("\n No of Control object Found = %d\n",ControlObj_count);fflush(stdout);
						if (ControlObj_count > 0)
						{
							printf("\n Control Object Found \n");fflush(stdout);
							//CR/ERC/PLM/22/0061 07-08-2022
							if((tc_strcmp(username,"loader") == 0))
							{
								printf("\nDesign revision cannot be created with 16 design group.\n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Design revision cannot be created with 16 design group.");
								return ITK_err;
							}

						}
			    }
		   }
		}
	}//End

	// ClrIndicator =C  Should not be allowed on Non Color Revision
	printf("\n\t Inside of ClrIndicator Updation validation \n");fflush(stdout);

	if(QRY_find("ControlObjQry", &ClrInd_CtrObjQryTag)!=ITK_ok)PrintErrorStack();
	ClrBOMQryVal[0] = "ClriNdC";
	if(QRY_execute(ClrInd_CtrObjQryTag, ClrBomEtry, ClrBomQryEtry, ClrBOMQryVal, &ClrBOMQryC, &ClrBOMCtrObj)!=ITK_ok)PrintErrorStack();
	printf("\n\t ClrBOMQryC-Control object found = [%d] \n",ClrBOMQryC);fflush(stdout);

	if(ClrBOMQryC>0)
	{
		if(AOM_ask_value_string(ClrBOMCtrObj[0],"t5_Userinfo1",&info1_value)!=ITK_ok)PrintErrorStack();

		PrtClassFlag =0;
		token= tc_strtok(info1_value,";");
		while (token != NULL)
		{
			printf("\n\t  Patrt Class is %s\n", token);
			if(tc_strcmp(type_name,token)==0)
			{
				PrtClassFlag=1;
				printf("\n\t  PrtClassFlag updated to [%d]\n", PrtClassFlag);
			}
			token = tc_strtok(NULL,";");
		}

		if(PrtClassFlag==1)
		{
			if( AOM_ask_value_string(objTag,"t5_ColourInd",&ClrIndicator)!=ITK_ok) PrintErrorStack();
			if(tc_strcmp(ClrIndicator, "C") == 0)
			{
				EMH_store_error_s2(EMH_severity_error,ITK_err,"Color Indicator 'C' is not valid with Non Color Part.","kindly select Color Indicator either 'Y' or 'N'");
				return ITK_err;
			}
		}
	}
	//ClrInd End

	//mbb_start
	if(strcmp(type_name,"Design Revision")==0)
	{
		printf("\n\t save_method_4::B.Inside of Updation of Keyword validation \n");fflush(stdout);

		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			if( AOM_ask_value_string(objTag,"item_id",&Ditem_ID)!=ITK_ok);PrintErrorStack();
			if( AOM_ask_value_string(objTag,"item_revision_id",&DitemRev_ID)!=ITK_ok);PrintErrorStack();

			printf("\n\t save_method_4::B.Part: [%s] with Revision [%s] \n",Ditem_ID,DitemRev_ID);fflush(stdout);

			if(tc_strstr(DitemRev_ID,"NR")==NULL)
			{
				if(QRY_find("ControlObjects", &CntrlObjQry));
				if (CntrlObjQry)
				{
					printf("\n\t save_method_4::B.ControlObjects Query Found \n");fflush(stdout);
				}
				else
				{
					printf("\n\t ControlObjects Query Not Found \n");fflush(stdout);
				}

				QryCntr_values[0] = "KeyJan19" ;

				if(QRY_execute(CntrlObjQry, Key_qry_entry, QryCntr_entry, QryCntr_values, &CntlObjCount, &CntObj_Tag2));
				printf("\n\t save_method_4::B.ControlObjects Count = %d \n",CntlObjCount);fflush(stdout);

				if(CntlObjCount>0)
				{
					ITK_CALL(ITEM_find_item( Ditem_ID, &DItem_tag ));
					if(DItem_tag != NULLTAG )		//MBOM implementation for CV TZ-1.69
					{

						ITK_CALL(ITEM_list_all_revs(DItem_tag,&rev_cnt,&rev_list_set));
						//if(rev_cnt != 0)	//MBOM implementation for CV TZ-1.69
						if(rev_cnt > 0)	//MBOM implementation for CV TZ-1.69
						{
							for(iji=(rev_cnt-1);iji>=0;iji--)
							{
								ITK_CALL(AOM_UIF_ask_value(rev_list_set[iji],"release_status_list",&rlstatus));
								if(rlstatus)
								{
									if(strstr(rlstatus,"ERC Released"))
									{
										 LatestRev_tag= rev_list_set[iji];
										 FlagKey=1;
										break;
									}
								}
							}
						}
					}

					printf("\n\t FlagKey = [%d] \n",FlagKey);fflush(stdout);

					if(FlagKey==1)
					{
						if( AOM_ask_value_string(objTag,"item_id",&Ditem_ID2)!=ITK_ok);PrintErrorStack();
						printf("\n\t  Ditem_ID2 [%s] \n",Ditem_ID2);fflush(stdout);

						if( AOM_UIF_ask_value(LatestRev_tag,"creation_date",&CreationDate)!=ITK_ok);PrintErrorStack();

						printf("\n\t  creation date [%s] \n",CreationDate);fflush(stdout);



						 day=subString(CreationDate,0,2);
						 month=subString(CreationDate,3,3);
						 Year=subString(CreationDate,7,4);

						 printf("\n\t day =  [%s]  month =  [%s]  Year =  [%s]  \n",day,month,Year);fflush(stdout);

						if (tc_strcmp(month,"Jan")==0)
						{
							intMonth=1;
						}
						else if (tc_strcmp(month,"Feb")==0)
						{
							intMonth=2;
						}
						else if (tc_strcmp(month,"Mar")==0)
						{
							intMonth=3;
						}
						else if (tc_strcmp(month,"Apr")==0)
						{
							intMonth=4;
						}
						else if (tc_strcmp(month,"May")==0)
						{
							intMonth=5;
						}
						else if (tc_strcmp(month,"Jun")==0)
						{
							intMonth=6;
						}
						else if (tc_strcmp(month,"Jul")==0)
						{
							intMonth=7;
						}
						else if (tc_strcmp(month,"Aug")==0)
						{
							intMonth=8;
						}
						else if (tc_strcmp(month,"Sep")==0)
						{
							intMonth=9;
						}
						else if (tc_strcmp(month,"Oct")==0)
						{
							intMonth=10;
						}
						else if (tc_strcmp(month,"Nov")==0)
						{
							intMonth=11;
						}
						else if (tc_strcmp(month,"Dec")==0)
						{
							intMonth=12;
						}

						 printf("\n intMonth: [%d]  \n",intMonth);fflush(stdout);

						 intDay = atoi(day);
						 intYear = atoi(Year);

						  printf("\n intDay = [%d] \t intMonth = [%d] \t intYear =[%d] \n",intDay,intMonth,intYear);fflush(stdout);

						 if (intYear>=2019 && intMonth>=1 && intYear>=1)
						 {
							printf("\n Indside validation \n");fflush(stdout);

							ITK_CALL(AOM_ask_value_string(objTag,"t5_AhdMakeBuyIndicator",&AhdMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_CarMakeBuyIndicator",&CarMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_DwdMakeBuyIndicator",&DwdMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_JsrMakeBuyIndicator",&JsrMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_JdlMakeBuyIndicator",&JdlMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_LkoMakeBuyIndicator",&LkoMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_PnrMakeBuyIndicator",&PnrMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_PunPCBUMakeBuyIndicator",&PCBUMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_PunMakeBuyIndicator",&PuneMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_PunUVMakeBuyIndicator",&PuneUVMkByInd));
							ITK_CALL(AOM_ask_value_string(objTag,"t5_SgrMakeBuyIndicator",&SrgMkByInd));

							if((tc_strcmp(AhdMkByInd,"F")==0 ) || (tc_strcmp(CarMkByInd,"F")==0 ) || (tc_strcmp(DwdMkByInd,"F")==0 ) || (tc_strcmp(JsrMkByInd,"F")==0 ) || (tc_strcmp(JdlMkByInd,"F")==0 ) || (tc_strcmp(LkoMkByInd,"F")==0 )
									|| (tc_strcmp(PnrMkByInd,"F")==0 ) || (tc_strcmp(PCBUMkByInd,"F")==0 ) || (tc_strcmp(PuneMkByInd,"F")==0 ) || (tc_strcmp(PuneUVMkByInd,"F")==0 ) || (tc_strcmp(SrgMkByInd,"F")==0 )	)
							{

								ITK_CALL(AOM_ask_value_string(objTag,"t5_CategoryName",&ReqKeyWord));
								ITK_CALL(AOM_ask_value_string(LatestRev_tag,"t5_CategoryName",&PrevKeyWord));

								printf("\n\t ReqKeyWord =[%s] \t PrevKeyWord [%s] \n",ReqKeyWord,PrevKeyWord);fflush(stdout);

								if(strcmp(ReqKeyWord,PrevKeyWord)==0)
								{
									printf("\n\t No change in Keyword \n");fflush(stdout);
								}
								else
								{
									printf("\n\t  Giving the error message for keyword not matching \n");fflush(stdout);

									EMH_store_error_s2(EMH_severity_error,ITK_err,"Updation of Keyword of Current Revision is Not Allowed as it is Buyable Part and Created After 1st Jan 2019.","If Still you Want the Same Keyowrd Description then Please Contact Bom Proecss Team.");
									return ITK_err;
								}
							}
							else
							{
								printf("\n\t  In else as Make buy indicator, No error \n");fflush(stdout);
							}

						 }
						 else
						{
							printf("\n\t  Previous official Rev is created before 1-Jan-2019 \n");fflush(stdout);
						}

					}

				}

			}
			else
			{
				printf("\n\t Revision is NR \n");fflush(stdout);
			}
		}
		printf("\n\t END of Updation of Keyword validation \n");fflush(stdout);
	}
	//mbb_end
	char *PrtPrj=NULL;
	char *desRev=NULL;
	char *ML_Staus=NULL;
	logical			checkoutrev;
	char *DRinfo4=NULL;
	int IsMilestoneLiveFlag=0;
	tag_t   qryTag12     = NULLTAG;
	char   *qry_entry1[1]  = {"SYSCD"};
	char   **qry_values21     =  (char **) MEM_alloc(10 * sizeof(char *));
	int     rsltCount1      =  0;
	tag_t   *CntrlObjectTag1      = NULLTAG;



	if( AOM_ask_value_string(objTag,"item_revision_id",&desRev)!=ITK_ok);PrintErrorStack();

	//if(RES_is_checked_out(objTag,&checkoutrev)!=ITK_ok);PrintErrorStack();
	//printf("\n aMilestone %d \n",checkoutrev);fflush(stdout);
	//if (checkoutrev==1)
	//{
		printf("aMilestone for design revisionn");fflush(stdout);
		if (tc_strcmp(type_name,"Design Revision")==0)
		{
				// if Design revision is NR then checking DR-Milestone mapping
				if(AOM_get_value_string(objTag,"t5_ProjectCode",&PrtPrj))PrintErrorStack();
				printf("\nProject stamped is : %s\n",PrtPrj);fflush(stdout);
				IsMilestoneLiveFlag=0;
				IsMilestoneLiveFlag = CheckMilestoneLive(PrtPrj);
				printf("\n P3:IsMilestoneLiveFlag: %d",IsMilestoneLiveFlag);fflush(stdout);

				// if (IsMilestoneLiveFlag >0)
				// {
						// int MilStRev=0;
						// printf("\n going to call function tm_Validate_Rev_Milestone_OnPart  %d \n",MilStRev); fflush(stdout);
						// MilStRev = tm_Validate_Rev_Milestone_OnPart(objTag);
						// printf("\n after calling tm_Validate_Rev_Milestone_OnPart checking %d \n",MilStRev); fflush(stdout);
						// if (MilStRev >0)
						// {
							// printf("\n Part miles status error");fflush(stdout);
							// return ITK_err;
						// }
				// }

				// if (IsMilestoneLiveFlag >0)
				// {
					// printf("\n project is live check part level Milestone validations");fflush(stdout);
					// if(QRY_find("ControlObjects", &qryTag12));
					// if (qryTag12)
					// {
						// printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
					// }
					// else
					// {
						// printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
					// }

					// qry_values21[0] = "CREVali";
					// if(QRY_execute(qryTag12, n_entry, qry_entry1, qry_values21, &rsltCount1, &CntrlObjectTag1));
					// printf(" \n CREVali:rsltCount 11:%d:", rsltCount1); fflush(stdout);
					// if(rsltCount1 > 0)
					// {
						// if (AOM_ask_value_string(CntrlObjectTag1,"t5_Userinfo4",&DRinfo4)!=ITK_ok)   PrintErrorStack();
						// printf("\n CREVali:DRinfo4:%s ",DRinfo4);fflush(stdout);
					// }
					// if(tc_strstr(DRinfo4,"AHCHKNR")==NULL)
					// {
						// printf("\n AHCHKNR is null \n",MilStflg); fflush(stdout);
						// MilStflg = tm_Validate_DR_Milestone_OnPart(objTag);
						// printf("\n after milestone checking %d \n",MilStflg); fflush(stdout);
						// if(MilStflg==1)
						// {
							// EMH_clear_errors();
							// EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							// return ITK_err;
						// }
						// else if (MilStflg==5)
						// {
							// EMH_clear_errors();
							// EMH_store_error_s1(EMH_severity_error,ITK_err," for NR revision Milestone Status should be as per Standards provided by PLM Team");
							// return ITK_err;
						// }
					// }
				// }
				// if (IsMilestoneLiveFlag >0)
				// {
					// printf("\n project is live check part level Milestone validations and update DR Status");fflush(stdout);

					// MilStflg = tm_Update_DR_AsPerMilestone_OnPart(objTag);

					// if (MilStflg >0)
						// {
							// printf("\n Part DR updated as per miles status error");fflush(stdout);
							// return ITK_err;
						// }
				// }

				//added on 14Apr2023
				char *PrtDRStatus = NULL;

				if(AOM_get_value_string(objTag,"t5_PartStatus",&PrtDRStatus))PrintErrorStack();
				printf("\n PrtDRStatus : %s\n",PrtDRStatus);fflush(stdout);

				char *SupportUsername9 = NULL;
				tag_t SessionUser9_tag=NULLTAG;
				int     SupportFlag      =  0;

				SupportFlag=0;
				POM_get_user(&SupportUsername9,&SessionUser9_tag);
				if(SessionUser9_tag!=NULLTAG)
				{
					SupportFlag=0;
					SupportFlag = CheckSupportLogin(SessionUser9_tag);
					printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
				}
				if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
				{
					if ((tc_strcmp(PrtDRStatus,"Pre-KO")==0)|| (tc_strcmp(PrtDRStatus,"KO")==0)|| (tc_strcmp(PrtDRStatus,"NA")==0))
					{
						printf("\n Milestone bypass for DRStatus[%s]",PrtDRStatus);fflush(stdout);
					}
					else
					{
						int MilStOnDrFlg=0;
						if (IsMilestoneLiveFlag >0)
						{
							printf("\n project is live check part level Milestone validations as per DR Status");fflush(stdout);
							
							int ERCUserFlag=0;
							char *SessionUsername;
							tag_t Usertag=NULLTAG;
							POM_get_user(&SessionUsername,&Usertag);
							
							char *t5userId1=NULL;
							ITK_CALL(AOM_ask_value_string(Usertag, "user_id", &t5userId1));
							printf( "\n session user is t5userId1:[%s]", t5userId1);fflush(stdout);
							
							if(Usertag!=NULLTAG)
							{
								ERCUserFlag=0;
								ERCUserFlag = CheckERCAccessLogin(Usertag);
								printf("\n ERCUserFlag..: %d",ERCUserFlag);fflush(stdout);
							}
							
							if(ERCUserFlag==0)
							{
								printf("\n Check Milston status user is:[%s] in ERC Group ERCUserFlag..: [%d]",t5userId1,ERCUserFlag);fflush(stdout);
								
								printf("\n calling tm_MilestoneValAsPerDRStatus_OnPartUpd ");fflush(stdout);
								MilStOnDrFlg = tm_MilestoneValAsPerDRStatus_OnPartUpd(objTag);
								printf("\n end calling tm_MilestoneValAsPerDRStatus_OnPartUpd ");fflush(stdout);
								if (MilStOnDrFlg >0)
								{
									printf("\n Milesston status validation as per  DR status error.");fflush(stdout);
									return ITK_err;
								}
							}
							else
							{
								printf("\n NOT Check Milston status user is:[%s] in ERC Group ERCUserFlag..: [%d]",t5userId1,ERCUserFlag);
							}
							
							
						}
					}
				}
				else
				{
					printf("\n It Support team or Super user [%s] SupportFlag.: %d,",username,SupportFlag);fflush(stdout);
				}
				//end on 14Apr2023

				// char *PrtDRStatus = NULL;

				// if(AOM_get_value_string(objTag,"t5_PartStatus",&PrtDRStatus))PrintErrorStack();
				// printf("\n PrtDRStatus : %s\n",PrtDRStatus);fflush(stdout);

				// char *SupportUsername9 = NULL;
				// tag_t SessionUser9_tag=NULLTAG;
				// int     SupportFlag      =  0;

				// SupportFlag=0;
				// POM_get_user(&SupportUsername9,&SessionUser9_tag);
				// if(SessionUser9_tag!=NULLTAG)
				// {
					// SupportFlag=0;
					// SupportFlag = CheckSupportLogin(SessionUser9_tag);
					// printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
				// }
				// if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
				// {
					// if ((tc_strcmp(PrtDRStatus,"Pre-KO")==0)|| (tc_strcmp(PrtDRStatus,"KO")==0))
					// {
						// printf("\n Milestone bypass for DRStatus[%s]",PrtDRStatus);fflush(stdout);
					// }
					// else
					// {
						// if (IsMilestoneLiveFlag >0)
						// {
							// printf("\n project is live check part level Milestone validations and update DR Status");fflush(stdout);
							// MilStflg=0;
							// MilStflg = tm_Update_DR_AsPerMilestone_OnPart_UpdLogic(objTag);

							// if (MilStflg >0)
								// {
									// printf("\n Part DR updated as per miles status error");fflush(stdout);
									// return ITK_err;
								// }
								// else
								// {
									// printf("\n Part DR updated as per miles status ");fflush(stdout);
								// }
						// }
					// }
				// }
				// else
				// {
					// printf("\n It Support team or Super user [%s] SupportFlag.: %d,",username,SupportFlag);fflush(stdout);
				// }

				// char *PrtDRStatus = NULL;

				// if(AOM_get_value_string(objTag,"t5_PartStatus",&PrtDRStatus))PrintErrorStack();
				// printf("\n PrtDRStatus : %s\n",PrtDRStatus);fflush(stdout);

				// char *SupportUsername9 = NULL;
				// tag_t SessionUser9_tag=NULLTAG;
				// int     SupportFlag      =  0;

				// SupportFlag=0;
				// POM_get_user(&SupportUsername9,&SessionUser9_tag);
				// if(SessionUser9_tag!=NULLTAG)
				// {
					// SupportFlag=0;
					// SupportFlag = CheckSupportLogin(SessionUser9_tag);
					// printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
				// }
				// if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
				// {
					// if ((tc_strcmp(PrtDRStatus,"Pre-KO")==0)|| (tc_strcmp(PrtDRStatus,"KO")==0))
					// {
						// printf("\n Milestone bypass for DRStatus[%s]",PrtDRStatus);fflush(stdout);
					// }
					// else
					// {
						// int MilStOnDrFlg=0;
						// if (IsMilestoneLiveFlag >0)
						// {
							// printf("\n project is live check part level Milestone validations as per DR Status");fflush(stdout);
							// printf("\n calling tm_MilestoneValAsPerDRStatus_OnPart ");fflush(stdout);
							// MilStOnDrFlg = tm_MilestoneValAsPerDRStatus_OnPart(objTag);
							// printf("\n end calling tm_MilestoneValAsPerDRStatus_OnPart ");fflush(stdout);
							// if (MilStOnDrFlg >0)
								// {
									// printf("\n Milesston status validation as per  DR status error.");fflush(stdout);
									// return ITK_err;
								// }
						// }
					// }
				// }
				// else
				// {
					// printf("\n It Support team or Super user [%s] SupportFlag.: %d,",username,SupportFlag);fflush(stdout);
				// }
				// if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
				// {
					// if ((tc_strcmp(PrtDRStatus,"Pre-KO")==0)|| (tc_strcmp(PrtDRStatus,"KO")==0))
					// {
						// printf("\n Milestone bypass for DRStatus[%s]",PrtDRStatus);fflush(stdout);
					// }
					// else
					// {
						// int MilStflgSame=0;
						// if (IsMilestoneLiveFlag >0)
						// {
							// printf("\n calling tm_check_MilesStoneStatusSame_OnPart ");fflush(stdout);
							// MilStflgSame = tm_check_MilesStoneStatusSame_OnPart(objTag);
							// printf("\n end calling tm_check_MilesStoneStatusSame_OnPart ");fflush(stdout);
							// if (MilStflgSame >0)
								// {
									// printf("\n Part  miles status is not same for all rev/seq");fflush(stdout);
									// return ITK_err;
								// }
						// }
					// }
				// }
				// else
				// {
					// printf("\n It Support team or Super user [%s] SupportFlag.: %d,",username,SupportFlag);fflush(stdout);
				// }
		}
	//}

	if(strcmp(type_name,"Design Revision")==0 || strcmp(type_name,"T5_SparKitRevision")==0) //T5_SparKitRevision
	{
		printf("\n save_method_4::A-Inside preaction type Save Validation 4 design revison Session user [%s] \n",username);fflush(stdout);
		char *projcodeList=NULL;
		char *projcode=NULL;
		char *ItemIdV=NULL;
		char *sRevID=NULL;
		tag_t projobj1 = NULLTAG;

		if (objTag!=NULLTAG)
		{
			if( AOM_ask_value_string(objTag,"item_id",&ItemIdV)!=ITK_ok);PrintErrorStack();
			if( AOM_ask_value_string(objTag,"item_revision_id",&sRevID)!=ITK_ok);PrintErrorStack();
			if( AOM_ask_value_string(objTag,"project_ids",&projcodeList)==ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)==ITK_ok)  PrintErrorStack();
			if( AOM_ask_value_string(objTag,"t5_DesignGrp",&Part_DegGrp)==ITK_ok) PrintErrorStack();
		}
		printf("\n save_method_4::A-Project : <%s> ProjectList : <%s> %d\n",projcode,projcodeList,strlen(projcodeList));fflush(stdout);

		// Check Is Part Available in TCE.
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			printf("\n save_method_4::A-sRevID: [%s] so check availability in TCE\n",sRevID);fflush(stdout);

			if(tc_strcmp(sRevID,"NR")==0)
			{
				printf("\n save_method_4::A-sRevID: [%s] so check availability in TCE\n",sRevID);fflush(stdout);

				int		IsAvailInUA			=	0;
				int		IsAvailInTCE		=	0;
				int		ValCntT				=	0;
				tag_t*	ValCntrlObjectTagT	=	NULLTAG;
				tag_t	qryTagT				=	NULLTAG;
				char    **qry_valuesT		=	(char **) MEM_alloc(10 * sizeof(char *));
				int		n_entryT			=	1;
				char    *qry_entryT[1]		=	{"SYSCD"};


				if(QRY_find("ControlObjects", &qryTagT));
				if (qryTagT)
				{
					printf("\n Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n Not Found Query ControlObjects \n");fflush(stdout);
				}

				qry_valuesT[0] = "PartInTCE" ;
				if(QRY_execute(qryTagT, n_entryT, qry_entryT, qry_valuesT, &ValCntT, &ValCntrlObjectTagT));
				printf(" \n PartInTCE:ValCnt :%d:", ValCntT); fflush(stdout);

				if(ValCntT>0)
				{
					IsAvailInUA = IsDesignRevisionAvail(ItemIdV);

					if(IsAvailInUA == 0)
					{
					IsAvailInTCE = FunToCheckPartAvailInICE(ValCntrlObjectTagT[0],ItemIdV);
					if(IsAvailInTCE==2)
					{
					printf("\n PART [%s] AVAILABLE IN TCE \n",ItemIdV);fflush(stdout);
					EMH_clear_errors();
					EMH_store_initial_error_s1(EMH_severity_error,ITK_err,"Part is already available in TCE, Please get it loaded from PLM Team");
					return ITK_err;
					}
					else
					{
					printf("\n Part not present in both TCUA and TCE. Please proceed. \n");fflush(stdout);
					}
					}
					else
					{
						printf("\n Part present in TCUA, so skip to check in TCE");fflush(stdout);
					}
				}
			}
		}
		printf("\n save_method_4::B-Project : <%s> ProjectList : <%s> %d\n",projcode,projcodeList,strlen(projcodeList));fflush(stdout);
		if(strcmp(projcodeList,"")==0 || strlen(projcodeList) < 4) //project_list
		{
			if(strcmp(projcode,"")==0) //project_list
			{
				printf("\n Save Validation 4 Project is  NULL \n");fflush(stdout);
			}
			else
			{
				printf("\n Save Validation 4 TCDCProject from Object in else : %s\n",projcode);fflush(stdout);

				if (PROJ_find(projcode,&projobj1) !=ITK_ok)PrintErrorStack();

				if(projobj1 != NULLTAG)
				{
	//				printf("\nTCDCGetting Master Object for Project\n");fflush(stdout);
	//				if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok)PrintErrorStack();
	//				printf("\nTCDCAfter Master Object for Project\n");fflush(stdout);
					if (PROJ_assign_objects(1 ,&projobj1 ,1 ,&objTag )!=ITK_ok)PrintErrorStack();
					printf("\n Save Validation 4 Assigned to Project\n");fflush(stdout);
				}
				else
				{
					printf("\n Save Validation 4 Project not found\n");fflush(stdout);
				}
			}
		}
		else
		{
				printf("\n Projectlist already assigned Project : <%s> ProjectList : <%s>\n",projcode,projcodeList);fflush(stdout);
		}

		//Bypass Revision Creation Validations If Found in SYSCD=VALDBYPASS Control Object
		if(QRY_find2("ControlObjQry", &TagQryContObjSite));
		if(TagQryContObjSite)
		{
			 if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_BypVal, &ByPasQCount, &cntr_objects));
			 printf("\nObjects for Query VALDBYPASS == %d", ByPasQCount);fflush(stdout);
		}
		else
		{
			printf("\nContrlObj not found for SYSCD=VALDBYPASS");fflush(stdout);
		}

		if(ByPasQCount >0)
		{
			printf("\nPart Project Code [%s] Design Group :[%s]",projcode,Part_DegGrp);fflush(stdout);
			if (AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
			if (AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();//Project Code

			printf("\nBypass Project Codes List [%s]",info2); fflush(stdout);
			printf("\nBypass Design  Group List [%s]",info1); fflush(stdout);

			if(tc_strstr(info2,projcode)!=NULL || tc_strstr(info1,Part_DegGrp)!=NULL)
			{
				CheckBypasFlag=1;	//If not found in Control Object Creation check will be applied.
			}
		}

		//  Added by Aashish_w Start

			char *sValOutput=NULL;
			char *userinfo11=NULL;
			int IsValidProjNType =0;
			int n_entries11 =2;
			tag_t	Cntl_obj_Qtag11	=	NULLTAG;
			char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
			int resultCount11=0;
			tag_t *qry_cntrlobj11= NULLTAG;
			char *rlsstatus1=NULL;

			if(QRY_find("Control Objects...", &Cntl_obj_Qtag11));

					qry_values11[0] = "PRTCATMAIN" ;
					qry_values11[1] = "PRTCATMAIN" ;

					ITK_CALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
					if (resultCount11 > 0)
	{
			AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo11);
			if(tc_strcmp(userinfo11,"Y") ==0 )
		{
			printf("\n User Info 1 of Main Control Object is valid... \n");fflush(stdout);

			if( AOM_UIF_ask_value(objTag,"release_status_list",&rlsstatus1)!=ITK_ok);PrintErrorStack();
			printf("\n release_status_list -----------> %s \n",rlsstatus1);fflush(stdout);
		//if(strstr(rlsstatus1,"ERC Released"))
			{
				printf("\n **************** Calling Function t5_partcategory  t5_partcategory $Welcome$ to Revise operation **************** \n");

				IsValidProjNType = t5_partcategory(objTag,&sValOutput);		//added by Aashish_w...

				if(IsValidProjNType==1)
				{
				printf("\n Part category is invalid... \n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, sValOutput);
				return ITK_err;
				}
				else
				{
				printf("\n Part Category is Valid... Please proceed. \n");fflush(stdout);
				}
			}
		//else
			{
				printf("\n Object is NOT Released........ \n");fflush(stdout);
			}
		}
		else
		{
			printf("\n User Info 1 of Main Control Object is NOT valid... \n");fflush(stdout);
			printf("\n Hence skipping the Part Category Rationalization... \n");fflush(stdout);
		}
	}
		// Added by Aashish_w End

		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			char *sValOutput=NULL;
			int IsValidProjNType =0;

			// Validation: which part type is allowed to create for selected project code.

			IsValidProjNType = FunToValidateProjectCodeNPartType(objTag,&sValOutput);

			if(IsValidProjNType==1)
			{
			printf("\n Part type is invalid for selected project code \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, sValOutput);
			return ITK_err;
			}
			else
			{
			printf("\n Part type is valid for selected project code. Please proceed. \n");fflush(stdout);
			}

			// Add validation for TMETC and Trilix Site before creation of specific project code parts.
			ProSubStr=subString(ItemIdV,0,4);
			char *sOutput=NULL;
			int	ValidProj=0;
			printf("\n save_method_4::Call SiteViseProjectValidationCheck:11:ProSubStr: [%s]\n",ProSubStr);fflush(stdout);
			ValidProj = SiteViseProjectValidationCheck(projcode,ProSubStr,&sOutput);
			printf("\n save_method_4::End SiteViseProjectValidationCheck: [%s]\n",sOutput);fflush(stdout);

			if(ValidProj==1)
			{
			printf("\n Project code is invalid for this Site.  \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, sOutput);
			return ITK_err;
			}
			else
			{
			printf("\n Project code is valid for this Site. Please proceed.  \n");fflush(stdout);
			}
		}

		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
		printf("\n\n  dss roleName : %s\n",roleName); fflush(stdout);
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0) && CheckBypasFlag==0)
		{

			//char   *sPartType1	 =NULL;
			//char   *sCatName	 =NULL;
			//char   *sDesignGrp	 =NULL;
			//if( AOM_ask_value_string(objTag,"t5_PartType",&sPartType1)!=ITK_ok);PrintErrorStack();
			//if( AOM_ask_value_string(objTag,"t5_CategoryName",&sCatName)!=ITK_ok);PrintErrorStack();
			//if(	AOM_UIF_ask_value(objTag,"t5_DesignGrp",&sDesignGrp)!=ITK_ok);PrintErrorStack();

			//if((tc_strcmp(sPartType1,"A")==0 || tc_strcmp(sPartType1,"C")==0))
			//{
				//printf("\n	Keyword description :%s",sCatName);fflush(stdout);
				//if(tc_strcmp(sCatName,"")==0)
				//{

					//printf("\n For  Part [%s]  Keyword description cannot be NULL\n");fflush(stdout);
					//EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description cannot be NULL for parttype Assembly and Component");
					//return ITK_err;
				//}
				//else
				//{
					//printf("\n	Keyword description :%s, Design Group : %s",sCatName,sDesignGrp);fflush(stdout);
					//char *qry_entries[2] = {"Name","ext_1"};
					//int n_entries= 2,n_found;
					//tag_t query = NULLTAG, *cntr_objects = NULL;
					//char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

					//qry_values[0] = sCatName ;
					//qry_values[1] = sDesignGrp;
					//QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &query);
					//QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects);
					//printf("\nKeyword n_found:%d", n_found);fflush(stdout);
					//if(n_found==0)
					//{
						//EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description for Design Revision is not matched as per given Design Group of Design Revision");
						//return ITK_err;
					//}
				//}
			//}
				//Amol K

				//Added By Dhanashri for PPR part type validation for 14 digit


					if ( (strstr(roleName,"APL"))|| (strstr(roleName,"MBOM"))) //MBOM implementation for CV TZ-1.69
					{
						if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTypPPR)!=ITK_ok)   PrintErrorStack();
						 printf("\n dss DesgTypPPR is  = [%s]\n", DesgTypPPR);fflush(stdout);

						 if( AOM_ask_value_string(objTag,"item_id",&desidForPPR)!=ITK_ok);PrintErrorStack();
							 printf("\n dss desidForPPR is  = [%s]\n", desidForPPR);fflush(stdout);

							 sLastFourChar=subString(desidForPPR, strlen(desidForPPR)-4,4);
							 printf("\n dss sLastFourChar == %s", sLastFourChar);fflush(stdout);


						  if(tc_strcmp(DesgTypPPR,"PPR")==0)
							 {
								 if(tc_strcmp(sLastFourChar,"_PPR")!=0)
								 {
									printf("\n dss For Part type Process Planning Resource 14 digit Partnumber should end with _PPR: \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part Type 'Process Planning Resource', 14 digit PartNumber should end with '_PPR'.");
									return ITK_err;
								 }
								else
								 {
									iPPRid = strlen(desidForPPR);
									 printf("\n dss iPPRid == %d", iPPRid);fflush(stdout);
									if((iPPRid)!=18)
									 {
										printf("\n dss For Part type Process Planning Resource, Part Number should be 14 digit before '_PPR'. \n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part type 'Process Planning Resource', PartNumber should be 14 digits before '_PPR'.");
										return ITK_err;
									 }
								}

							 }

							 if( (tc_strcmp(sLastFourChar,"_PPR")==0) && (tc_strcmp(DesgTypPPR,"PPR")!=0) )
							  {
									printf("\n dss Item contains _PPR but partype diff \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type should be 'Process Planning Resource' Since Item ID ends with '_PPR'.");
									return ITK_err;
							  }

					}
					else
					{
					   //Amol K for PPR part type validation
						if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTypPPR)!=ITK_ok)   PrintErrorStack();
						 printf("\n DesgTypPPR is  = [%s]\n", DesgTypPPR);fflush(stdout);
						 if( AOM_ask_value_string(objTag,"item_id",&desidForPPR)!=ITK_ok);PrintErrorStack();
							sLastFourChar=subString(desidForPPR, strlen(desidForPPR)-4,4);
							printf("\n sLastFourChar == %s", sLastFourChar);fflush(stdout);

						  if(tc_strcmp(DesgTypPPR,"PPR")==0)
							 {
								 if(tc_strcmp(sLastFourChar,"_PPR")!=0)
								 {
									printf("\n For Part type Process Planning Resource 12 digits part number should end with _PPR: \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part type Process Planning Resource 12 digits part number should end with '_PPR'.");
									return ITK_err;
								 }
								else
								 {
									iPPRid = strlen(desidForPPR);
									 printf("\n iPPRid == %d", iPPRid);fflush(stdout);
									if((iPPRid)!=16)
									 {
										printf("\n For Part type Process Planning Resource, Part Number should be 12 digits before '_PPR'. \n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part type Process Planning Resource, Part Number should be 12 digits before '_PPR'.");
										return ITK_err;
									 }
								}

							 }

							 if( (tc_strcmp(sLastFourChar,"_PPR")==0) && (tc_strcmp(DesgTypPPR,"PPR")!=0) )
							  {
									printf("\n Amol check Item contains _PPR but partype diff \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type should be 'Process Planning Resource' Since Item ID ends with '_PPR'.");
									return ITK_err;
							  }
						//end Amol K for PPR part type validation
					}
				//End of code Added By Dhanashri for PPR part type validation for 14 digit
				//Aadarsh
				tag_t Partypartctrlobj		=	NULLTAG;
				tag_t *CntrlObject_Partypart	=	NULLTAG;
				int Partypart_entries			=	1;
				int	Partypart_found			=	0;
				char *qry_Partypartcntrl[1]	= {"SYSCD"};
				char **qry_valuesPartypart		= (char **) MEM_alloc(10 * sizeof(char *));
				qry_valuesPartypart[0]			= "PartypartERCbypass";
				ITK_CALL(QRY_find("Control Objects...",&Partypartctrlobj));
				//printf("\n\n CVBUBOMCntrlObj Query Found\n\n");	fflush(stdout);


				ITK_CALL(QRY_execute(Partypartctrlobj, Partypart_entries, qry_Partypartcntrl, qry_valuesPartypart, &Partypart_found, &CntrlObject_Partypart));
				printf("\n\n  PartyPartCntrlObj Control Object SYSCD :%d\n",Partypart_found);	fflush(stdout);

				if(Partypart_found > 0)
			   {
				if (AOM_ask_value_string(objTag,"item_id",&DesgNo)!=ITK_ok)   PrintErrorStack();
				printf("\n DesgNo is  = [%s]\n", DesgNo);fflush(stdout);
				if (AOM_ask_value_string(objTag,"t5_RefPartNumber",&RefPartNumber)!=ITK_ok)   PrintErrorStack();
				printf("\n RefPartNumber is  = [%s]\n", RefPartNumber);fflush(stdout);
				//Bypass for APL user

				if ( (strstr(roleName,"APL")==NULL) || (strstr(roleName,"MBOM")==NULL)) //MBOM implementation for CV TZ-1.69
				{
					//if(RefPartNumber)		//
					if(tc_strcmp(RefPartNumber,"")!=0)	 //MBOM implementation for CV TZ-1.69
					{
					char *qryParty_InputVal[2] = {DesgNo,RefPartNumber};
					if(QRY_find2("QryDesRevUsgPartyPart", &TagQryPartyPart));
						//if(TagQryPartyPart)	 //MBOM implementation for CV TZ-1.69
						 if (TagQryPartyPart!=NULLTAG) //MBOM implementation for CV TZ-1.69
						  {
							 if(QRY_execute(TagQryPartyPart, n_InputC, qryParty_Input, qryParty_InputVal, &outobjcnt, &Res_des_objs));
							 printf("\n Objects for Query TagQryPartyPart == %d", outobjcnt);fflush(stdout);
							 if(outobjcnt >0)
							  {
								if (AOM_ask_value_string(Res_des_objs[0],"item_id",&DesgNoFound)!=ITK_ok)   PrintErrorStack();
								printf("\n DesgNoFound is  = [%s]\n", DesgNoFound);fflush(stdout);
								ErrorString=(char *) MEM_alloc(150);
								printf("After mem alloc\n");
								tc_strcpy (ErrorString, "Party/Vendor Part ");
								strcat(ErrorString,RefPartNumber);
								strcat(ErrorString," is already used with Design ");
								strcat(ErrorString,DesgNoFound);
								strcat(ErrorString,". Please select other Party/Vendor Part.");
								EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
								return ITK_err;
							  }

						  }
						  else
						  {
							  printf("\n QryDesRevUsgPartyPart query not found");fflush(stdout);
						  }
					}
				}
		}

			char* sPartColInd=NULL;
			if( AOM_ask_value_string(objTag,"t5_ColourInd",&sPartColInd)!=ITK_ok);PrintErrorStack();
			printf("\n	color indicator :%s",sPartColInd);fflush(stdout);

			/*
			if((tc_strcmp(sPartColInd,"Y")==0))
			{
				printf("\n	color indicator of part is Y");fflush(stdout);
				char* sPrtCompCode=NULL;
				if( AOM_ask_value_string(objTag,"t5_PrtCatCode",&sPrtCompCode)!=ITK_ok);PrintErrorStack();
				if(tc_strcmp(sPrtCompCode,"")==0)
				{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For Color Indicator 'Y', COMP CODE should not be NULL");
						return ITK_err;
				}
			}
			*/

			if((tc_strcmp(sPartColInd,"N")==0))
			{
				printf("\n	color indicator of part is => N\n\n");fflush(stdout);
				char* nPrtCompCode=NULL;
				if( AOM_ask_value_string(objTag,"t5_PrtCatCode",&nPrtCompCode)!=ITK_ok);PrintErrorStack();
				printf("\n	nPrtCompCode of part is => %s\n\n",nPrtCompCode);fflush(stdout);

				if(tc_strcmp(nPrtCompCode,"")!=0)
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"For Color Indicator 'N', COMP CODE should be NULL");
					return ITK_err;
				}
			}

			if(QRY_find2("ControlObjQry", &TagQryContObjSite));
			if(TagQryContObjSite)
			{
				 if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_InputVal, &CntrCount, &cntr_objects));
				 printf("\n Objects for Query ControlBasedOnSite == %d", CntrCount);fflush(stdout);
			}else
			  {
				  printf("\n ContrlObjQry query not found");fflush(stdout);
			  }

			if (AOM_ask_value_string(objTag,"item_id",&DesRNo)!=ITK_ok)   PrintErrorStack();
			printf("\n DesRNo is  = [%s]\n", DesRNo);fflush(stdout);
			//if(ITEM_find_item(DesRNo,&Destag)!=ITK_ok)PrintErrorStack();//Revise - Ashwini

			printf("\n Revise API Change and call  IsDesignRevisionAvail() for [%s] Item\n", DesRNo);fflush(stdout);
			int		IsRAvailInUA			=	0;
			IsRAvailInUA = IsDesignRevisionAvail(DesRNo);

			printf("\n Revise IsRAvailInUA= [%d] \n", IsRAvailInUA);fflush(stdout);

			//if(Destag==NULLTAG)
			if(IsRAvailInUA==0)
			{
				printf("\n Destag is NULL");fflush(stdout);
				 if(CntrCount >0 )
				 {
					 if( AOM_ask_value_string(objTag,"item_id",&desidForTRL)!=ITK_ok);PrintErrorStack();
					 sLastThreeChar=subString(desidForTRL, strlen(desidForTRL)-4,4);
					 printf("\n sLastThreeChar == %s", sLastThreeChar);fflush(stdout);
					 if(tc_strcmp(sLastThreeChar,"_TRL")!=0)
					 {
						  printf("\n For TRILIX SITE part number should end with _TRL: validation removed as per CR-FY20-0028  \n");fflush(stdout);
						//EMH_store_error_s1(EMH_severity_error,ITK_err,"For TRILIX site, Part number should end with '_TRL'.");
						//return ITK_err;

					 }

				if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTypTRL)!=ITK_ok)   PrintErrorStack();
				 printf("\n DesgTyp is  = [%s]\n", DesgTypTRL);fflush(stdout);
				  if(tc_strcmp(DesgTypTRL,"D")!=0)
					 {
						  printf("\n For TRILIX site, Part Type should be 'Dummy': validation removed as per CR-FY20-0028 \n");fflush(stdout);
						//EMH_store_error_s1(EMH_severity_error,ITK_err,"For TRILIX site, Part Type should be 'Dummy'.");
						//return ITK_err;

					 }


				 }
			}


			if(QRY_find("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
			}

			qry_values2[0] = "CREVali" ;
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n CREVali:rsltCount 22:%d:", rsltCount); fflush(stdout);
			if(rsltCount>0)
			{
				if ( (strstr(roleName,"APL")==NULL) || (strstr(roleName,"MBOM")==NULL)) //MBOM implementation for CV TZ-1.69
				{
					if (AOM_ask_value_string(objTag,"item_id",&DesgNo)!=ITK_ok)   PrintErrorStack();
					printf("\n DesgNo is  = [%s]\n", DesgNo);fflush(stdout);

					if (AOM_ask_value_string(objTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
					printf("\n Part_prj is  = [%s]\n", Part_prj);fflush(stdout);	//ADI ST

					if (AOM_ask_value_string(objTag,"t5_DesignGrp",&STDesGrp)!=ITK_ok)   PrintErrorStack(); //ADI ST
					printf("\n STDesGrp is  = [%s]\n", STDesGrp);fflush(stdout);								//ADI ST

					if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
					printf("\n DesgTyp is  = [%s]\n", DesgTyp);fflush(stdout);
					if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
					printf("\n info1 is  = [%s]\n", info1);fflush(stdout);
					ITKCALL(SA_ask_current_role(&CurrentRoleTag));
					ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
					printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

					//if(((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0))&& (strlen(DesgNo) !=12)&& (strlen(DesgNo) !=11) &&  ( (!strstr(roleName,"APL"))  ||  (!strstr(roleName,"MBOM")) ))  //MBOM implementation for CV TZ-1.69
					//Added Hrishikesh TZ1.70 02.06.2023 (Added CKC and 14 digit)
					if(((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0))&& ((strlen(DesgNo) !=12)&& (strlen(DesgNo) !=11) && (strlen(DesgNo) !=14) && (tc_strstr(DesgNo,"CK")==NULL)) &&  ( (!strstr(roleName,"APL"))  ||  (!strstr(roleName,"MBOM")) ))  //MBOM implementation for CV TZ-1.69
					{
						printf("\n Assembly or component must be 12 digit: [%s]\n", DesgNo);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For part type assembly or component, part number must be 12 digit.");
						return ITK_err;
					}

					//Ashwini - Dummy Component/Dummy Assembly /Component � parttype not allowed if for 12-digit part 9th and 10th digit is 01. It has to be assembly.
					//printf("\nPart_prj=%s,STDesGrp = %s \n",Part_prj,STDesGrp);fflush(stdout);
					PartCreationBypassFlag = 0;
					if(tc_strcmp(STDesGrp,"ST")==0)
					{
						PartCreationBypassFlag = 1;
					}

					qry_dfqCtrObjct[0] = "TMETC_ProjectCdeList_allow_PartCreation";
					if(QRY_execute(qryTag, n_dfqentry,	qry_entry, qry_dfqCtrObjct, &rsltDfqCount, &CntrlObjectTag11));
					printf(" \nPart Creation Bypass TMETC_ProjectCdeList_allow_PartCreation:rsltDfqCount :%d:\n", rsltDfqCount); fflush(stdout);
					if(rsltDfqCount > 0)
					{
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
						printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
						printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
						printf("\n info3 is.:[%s]\n", info3);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
						printf("\n info4 is.:[%s]\n", info4);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
						printf("\n info5 is.:[%s]\n", info5);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
						printf("\n info6 is.:[%s]\n", info6);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
						printf("\n info7 is.:[%s]\n", info7);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
						printf("\n info8 is.:[%s]\n", info8);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
						printf("\n info9 is.:[%s]\n", info9);fflush(stdout);
						if((tc_strstr(info1,Part_prj)!=NULL) || (tc_strstr(info2,Part_prj)!=NULL) || (tc_strstr(info3,Part_prj)!=NULL) || (tc_strstr(info4,Part_prj)!=NULL) || (tc_strstr(info5,Part_prj)!=NULL) || (tc_strstr(info6,Part_prj)!=NULL) || (tc_strstr(info7,Part_prj)!=NULL) || (tc_strstr(info8,Part_prj)!=NULL) || (tc_strstr(info9,Part_prj)!=NULL))
						{
							printf("\n%s Project Code control object found for TMETC %s...\n",Part_prj);fflush(stdout);
							PartCreationBypassFlag = 1;
						}
					}
					printf("PartCreationBypassFlag = %d",PartCreationBypassFlag);fflush(stdout);
					if(PartCreationBypassFlag != 1)
					{
						if(strlen(DesgNo) == 12)
						{
							sDesgNoTN=subString(DesgNo,8,2);
							printf("\n9th and 10th digit of Design [%s] and Lenth = [%d] and Type = [%s]\n",sDesgNoTN,strlen(DesgNo),DesgTyp);fflush(stdout);
							if(tc_strcmp(sDesgNoTN,"01") == 0)
							{
								if(tc_strcmp(DesgTyp,"A")!= 0)
								{
									printf("\n Assembly or component must be 12 digit: [%s]\n", DesgNo);fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Lenght is 12 digit and 9th and 10th digit are 01. Please select Part Type as 'Assembly'");
									return ITK_err;
								}
								else
								{
									printf("\n12 digit part type with assembly allow to create part because 9th and 10th digits are 01..\n");fflush(stdout);
								}
							}
						}
					}
//
//					if(((tc_strcmp(DesgTyp,"DC")== 0) || (tc_strcmp(DesgTyp,"DA")== 0) || (tc_strcmp(DesgTyp,"C")== 0)) && (strlen(DesgNo) == 12))
//					{
//					}
					//Ashwini - TC part having space in the name
					if(tc_strstr(DesgNo," ") != 0)
					{
						printf("\n TC part having space in the name: [%s]\n", DesgNo);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Space Not allowed in Part Number");
						return ITK_err;
					}
					if (tc_strcmp(DesgTyp,"T")==0)
					{
						//TPL should be 11 digit and end with R/L
						sDesgNoT=subString(DesgNo, 10, 1);
						printf("\n TPL last digit: [%s]\n", sDesgNoT);fflush(stdout);
						if ((strlen(DesgNo) ==11)&& ((tc_strcmp(sDesgNoT,"R")==0)||(tc_strcmp(sDesgNoT,"L")==0)))
						{
							printf("\n TPL is 11 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n TPL is not 11 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For part type TPL, part number must be 11 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"M")==0)
					{
						//Module should be 14 digit.
						printf("\n TPL last digit\n");fflush(stdout);
						if (strlen(DesgNo) ==14)
						{
							printf("\n Module is 14 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n Module is not 14 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Module must be 14 digit.");
							return ITK_err;
						}
					}
					//if (strcmp(DesgTyp,"G")==0)
					//{
					//	//Work for frist digit should be G and and part length should be 7 digit
					//	sDesgNoG=subString(DesgNo, 0, 1);
					//	printf("\n Group ID first digit: [%s]\n", sDesgNoG);fflush(stdout);
					//	if ((strlen(DesgNo) ==7)&& (strcmp(sDesgNoG,"G")==0))
					//	{
					//		printf("\n Group ID is 7 digit: [%s]\n", DesgNo);fflush(stdout);
					//	}
					//	else
					//	{
					//		printf("\n Group Id is not 7 digit: [%s]\n", DesgNo);fflush(stdout);
					//		EMH_store_error_s1(EMH_severity_error,ITK_err,"For Group Id, part number must be 7 digit and Start with G.");
					//		return ITK_err;
					//	}
					//}
					if (tc_strcmp(DesgTyp,"V")==0)
					{
						//vehicle should be 9 digit and end with R/L
						sDesgNoV=subString(DesgNo, 8, 1);
						printf("\n Vehicle last digit: [%s]\n", sDesgNoV);fflush(stdout);
						if ((strlen(DesgNo) ==9)&& ((tc_strcmp(sDesgNoV,"R")==0)||(tc_strcmp(sDesgNoV,"L")==0)))
						{
							printf("\n Vehicle is 9 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n Vehicle is not 9 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For vehicle, part number must be 9 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"VC")==0)
					{
						//VC should be 12 digit and end with R/L
						sDesgNoVC=subString(DesgNo, 11, 1);
						printf("\n VC last digit: [%s]\n", sDesgNoVC);fflush(stdout);
						if ((strlen(DesgNo) ==12)&& ((tc_strcmp(sDesgNoVC,"R")==0)||(tc_strcmp(sDesgNoVC,"L")==0)))
						{
							printf("\n VC is 12 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n VC is not 9 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For VC, part number must be 12 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"VCCR")==0)
					{
						//VCCR should be 12 digit and end with R/L
						sDesgNoVCCR=subString(DesgNo, 11, 1);
						printf("\n VCCR last digit: [%s]\n", sDesgNoVCCR);fflush(stdout);
						if ((strlen(DesgNo) ==12)&& ((tc_strcmp(sDesgNoVCCR,"R")==0)||(tc_strcmp(sDesgNoVCCR,"L")==0)))
						{
							printf("\n VCCR is 12 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n VCCR is not 9 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For VCCR, part number must be 12 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"D")==0 && CntrCount==0 )//bypassed for trilix site
					{
						//Dummy part should be 12 digit and 9th and 10th digit should be 00/04

						if(tc_strcmp(STDesGrp,"ST")!=0) //ADI ALIAS
						{
							sDesgNoD=subString(DesgNo, 8, 2);
							printf("\n VCCR last digit: [%s]\n", sDesgNoD);fflush(stdout);
							if (strlen(DesgNo) ==12)
							{
								if ((tc_strcmp(sDesgNoD,"04")!=0)&&(tc_strcmp(sDesgNoD,"00")!=0))
								{
									printf("\n Dummy is 12 digit: [%s]\n", DesgNo);fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"For 12 digit Dummy part, 9th and 10th digit of part number must be 00/04.");
									return ITK_err;
								}
							}
						}
					   else
						{
							printf("\n design group ST hence bypassing dummy part validation \n" );fflush(stdout); //ADI ALIAS
						}
					}

					if((tc_strcmp(DesgTyp,"A")==0 || tc_strcmp(DesgTyp,"C")==0 || tc_strcmp(DesgTyp,"D")==0) && strlen(DesgNo)==12)
					{
						// If Design Revision Number - XXXX XX 16 XX XX
						ThirdBarrel = subString(DesgNo,6,2);
						if (AOM_ask_value_string(objTag,"t5_SpareCriteria",&SpareCrit)!=ITK_ok)   PrintErrorStack();
						printf("\nPart [%s] ThirdBarrel [%s] SpareCriteria [%s]\n", DesgNo,ThirdBarrel,SpareCrit);fflush(stdout);

						if(tc_strcmp(ThirdBarrel,"16")==0 && (tc_strcmp(SpareCrit,"TSD")!=0 || strlen(SpareCrit)==0))
						{
							//Hard Check To Select TSD
							printf("\nIf Part [%s] and ThirdBarrel [%s] Please select SpareCriteria Value : TSD\n",DesgNo,ThirdBarrel);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Parts Numbers Third Barrel is 16, SpareCriteria Value Should be TSD : TML specification drawing");
							return ITK_err;
						}
					}

					// When new TC Part created with 9th and 10 th digit as 00 or 04 then Part type should be Info Fitment Drawing or Table Drawing

					if(QRY_find("ControlObjects", &qryTag1));
					if (qryTag1)
					{
						printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
					}

					qry_values3[0] = "IFDNTDVal" ;
					if(QRY_execute(qryTag1, n_entry, qry_entry, qry_values3, &ValCnt, &ValCntrlObjectTag1));
					printf(" \n IFDNTDVal:ValCnt :%d:", ValCnt); fflush(stdout);

					if(ValCnt>0)
					{
						if((tc_strcmp(DesgTyp,"IFD")==0) && strlen(DesgNo)==12)
						{
							if(tc_strcmp(STDesGrp,"ST")!=0) //skip ALIAS
							{

							printf("\n validation for Info Fitment Drawing or Table Drawing");fflush(stdout);
							// If Design Revision Number - XXXX XX XX 00/04 XX
							ForthBarrel = subString(DesgNo,8,2);
							printf("\n ForthBarrel: [%s]",ForthBarrel);fflush(stdout);
							if(tc_strcmp(ForthBarrel,"00")==0)
							{
								printf("\n ForthBarrel is: [%s], so you can create IFD ",ForthBarrel);fflush(stdout);
							}
							else
							{
								printf("\nIf Part [%s] and ForthBarrel [%s] Please select Part Type: IFD\n",DesgNo,ForthBarrel);fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part Type IFD [Info Fitment Drawing], 9th and 10th digit should be 00");
								return ITK_err;
							}
							}
						}
						if((tc_strcmp(DesgTyp,"TD")==0) && strlen(DesgNo)==12)
						{
							if(tc_strcmp(STDesGrp,"ST")!=0) //skip ALIAS
							{
							printf("\n validation for Table Drawing");fflush(stdout);
							// If Design Revision Number - XXXX XX XX 00/04 XX
							ForthBarrel = subString(DesgNo,8,2);
							printf("\n ForthBarrel: [%s]",ForthBarrel);fflush(stdout);
							if(tc_strcmp(ForthBarrel,"04")==0)
							{
								printf("\n ForthBarrel is: [%s], so you can create TD ",ForthBarrel);fflush(stdout);
							}
							else
							{
								printf("\nIf Part [%s] and ForthBarrel [%s] Please select Part Type: TD\n",DesgNo,ForthBarrel);fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part Type TD [Table Drawing], 9th and 10th digit should be 04");
								return ITK_err;
							}
							}
						}
					}

					if (AOM_ask_value_string(objTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(objTag,"t5_DesignGrp",&Part_DegGrp)!=ITK_ok)   PrintErrorStack();
					printf("\n Part Project code is  = [%s] DsgGrp [%s]\n", Part_prj,Part_DegGrp);fflush(stdout);
					Part_Proj=subString(DesgNo, 0, 4);
					Part_Desg=subString(DesgNo, 4, 2);
					printf("\n Part first 4 digit: [%s], 5 and 6th digit [%s]\n", Part_Proj,Part_Desg);fflush(stdout);
					if(strlen(DesgNo) !=11)
					{
						//Checking project/design group Start
						printf("\n Item ID is not 11 digit, so check validations...\n");fflush(stdout);
						if((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0)|| (tc_strcmp(DesgTyp,"CM")==0)||(tc_strcmp(DesgTyp,"M")==0))
						{
							printf("\n 1.Part type is:[%s] \n",DesgTyp);fflush(stdout);
							if (strcmp(Part_Proj,Part_prj)!=0)
							{
								printf("\n Part first 4 digit are not same as project code.\n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"First 4 digits of part number should be same as project code.");
								return ITK_err;
							}
						}
						//Design group check.
						if((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0)||(tc_strcmp(DesgTyp,"CM")==0))
						{
							printf("\n 2.Part type is:[%s] \n",DesgTyp);fflush(stdout);
							if (strcmp(Part_Desg,Part_DegGrp)!=0)
							{
								printf("\n Part 5th and 6th digit are not same as Desgin group.\n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"5th and 6th digits of part number should be same as design group.");
								return ITK_err;
							}
						}
						else if (tc_strcmp(DesgTyp,"M")==0)
						{
							printf("\n 3.Part type is:[%s] \n",DesgTyp);fflush(stdout);

							MPart_Desg=subString(DesgNo, 9, 2);
							printf("\n MPart_Desg: [%s]\n", MPart_Desg);fflush(stdout);
							if (strcmp(MPart_Desg,Part_DegGrp)!=0)
							{
								printf("\n Part 5th and 6th digit are not same as Desgin group.\n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"10th and 11th digits of part number should be same as design group.");
								return ITK_err;
							}
						}
						//Checking project/design group end.
					}
					else
					{
						printf("\n std parts..\n");fflush(stdout);
					}

					//DR Validation 1.30 start..
					if(strlen(DesgNo) !=11)
					{
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
						printf("\n DRVali:info2 is  = [%s]\n", info2);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
						printf("\n info4 is  = [%s]\n", info4);fflush(stdout);

						if (AOM_ask_value_string(objTag,"t5_ColourInd",&PrtCol)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(objTag,"t5_PartType",&Prttyp)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(objTag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
						if (AOM_UIF_ask_value(objTag,"release_status_list",&release_status)!=ITK_ok)   PrintErrorStack();
						printf("\n DRVali:Prttyp: [%s] PrtDR: [%s] PrtCol:[%s] release_status:[%s]\n",Prttyp,PrtDR,PrtCol,release_status);fflush(stdout);
						if(POM_class_of_instance(objTag,&PrtCls)!=ITK_ok) PrintErrorStack();
						if(POM_name_of_class(PrtCls,&PrtClass)!=ITK_ok) PrintErrorStack();
						printf("\n DRVali:PrtClass :%s",PrtClass); fflush(stdout);
						if (AOM_ask_value_string(objTag,"t5_ProjectCode",&PrtProj)!=ITK_ok)   PrintErrorStack();
						printf("\n DRVali:PrtProj is  = [%s]\n", PrtProj);fflush(stdout);
						DRValiFlag=0;
						if(tc_strcmp(release_status,"")!=0)
						{
							if(tc_strstr(info4,release_status) != NULL)
							{
								DRValiFlag=1;
								printf("\n DRVali:DRValiFlag..:[%d]\n", DRValiFlag);fflush(stdout);
							}
						}
						else
						{
							printf("\n DRVali:DRValiFlag:[%d]\n", DRValiFlag);fflush(stdout);
						}
						if((tc_strcmp(PrtProj,"")!=0)&&(DRValiFlag==0))
						{
							if(ITEM_find_item(PrtProj,&Project_t)!=ITK_ok)PrintErrorStack();
							if (Project_t!=NULLTAG)
							{
								if(TCTYPE_ask_object_type(Project_t,&ObjTypProj));
								if(TCTYPE_ask_name(ObjTypProj,type_Proj));
								printf("\n DRVali:DML: type_Proj :: %s\n", type_Proj);fflush(stdout);
								if (strcmp(type_Proj,"T5_Project")==0)
								{
									if(AOM_ask_value_string(Project_t,"t5_ProjectType",&Proj_typ)!=ITK_ok)PrintErrorStack();
									printf("\n DRVali:Proj_typ :[%s]\n",Proj_typ);   fflush(stdout);
									// START SUDHIR IS ADDED FOR VALIDATION OF DVPT....
									if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&BussiNameS)!=ITK_ok) PrintErrorStack();
									printf("\n SSSSSSSSSSSSSSS DRVali:BussiNameS :[%s]\n",BussiNameS);   fflush(stdout);
									if(tc_strcmp(BussiNameS,"CVBU")== 0 || tc_strcmp(BussiNameS,"PCBU")== 0)
									{
										printf("\n SSSSSSSSSSSSSSS:Prttype :[%s]\n",Prttyp);fflush(stdout);
										printf("\n SSSSSSSSSSSSSSS:PrtDRStatus :[%s]\n",PrtDR);fflush(stdout);
										if(tc_strcmp(Prttyp,"DTPL")==0)
										{
											if(tc_strcmp(PrtDR,"DVPT"))
											{
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type Dummy TPL can have DR as DVPT only.");
												return ITK_err;
											}

										}
										if(tc_strcmp(PrtDR,"DVPT")==0)
										{
											char	*part_DsgnOwn	=	NULL;
											if(tc_strcmp(Prttyp,"DTPL"))
											{
												EMH_store_error_s1(EMH_severity_error,ITK_err,"DR Status as DVPT can have Part Type Dummy TPL only.");
												return ITK_err;
											}

											if (AOM_ask_value_string(objTag,"t5_DsgnOwn",&part_DsgnOwn)!=ITK_ok) PrintErrorStack();
											printf("\n SSSSSSSSSSSSSSS:part_DsgnOwn :[%s]\n",part_DsgnOwn);fflush(stdout);
											if(tc_strstr(part_DsgnOwn,"PRO") == NULL)
											{
												EMH_store_error_s1(EMH_severity_error,ITK_err,"DR Status as DVPT can have PROPUN/PROJSR/PROLKO only.");
												return ITK_err;
											}

										}
									}
									// END SUDHIR IS ADDED FOR VALIDATION OF DVPT....
									if((tc_strcmp(PrtDR,"")!=0) && (tc_strcmp(PrtDR,"NA")!=0))
									{
										if((tc_strcmp(Proj_typ,"E")==0)||(tc_strcmp(Proj_typ,"G")==0)||(tc_strcmp(Proj_typ,"H")==0)||(tc_strcmp(Proj_typ,"A")==0))
										{
											if((tc_strcmp(PrtDR,"AR0")!=0) && (tc_strcmp(PrtDR,"AR1")!=0)  && (tc_strcmp(PrtDR,"AR2")!=0) &&
											(tc_strcmp(PrtDR,"AR3")!=0) && (tc_strcmp(PrtDR,"AR4")!=0)  &&  (tc_strcmp(PrtDR,"AR5")!=0) &&  (tc_strcmp(PrtDR,"AR3P")!=0))
											{
												printf("\n DRVali:ERROR:1.\n"); fflush(stdout);
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid AR-status from AR0/AR1/AR2/AR3/AR3P/AR4/AR5.\n Part project type-Engine/GearBox/Clutch/Axles should have AR-value.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
												return ITK_err;
											}
										}
										else
										{
											if((tc_strcmp(PrtDR,"DR0")!=0) && (tc_strcmp(PrtDR,"DR1")!=0) && (tc_strcmp(PrtDR,"DR2")!=0) &&
												(tc_strcmp(PrtDR,"DR3")!=0) && (tc_strcmp(PrtDR,"DR4")!=0) && (tc_strcmp(PrtDR,"DR5")!=0) && (tc_strcmp(PrtDR,"DR3P")!=0) &&
												(tc_strcmp(PrtDR,"AR0")!=0) && (tc_strcmp(PrtDR,"AR1")!=0) && (tc_strcmp(PrtDR,"AR2")!=0) && (tc_strcmp(PrtDR,"AR3")!=0) &&
												(tc_strcmp(PrtDR,"AR3P")!=0) && (tc_strcmp(PrtDR,"AR4")!=0) && (tc_strcmp(PrtDR,"AR5")!=0) && (tc_strcmp(PrtDR,"DVPT")!=0) &&
												(tc_strcmp(PrtDR,"Pre-KO")!=0) && (tc_strcmp(PrtDR,"KO")!=0))
											{
												printf("\n DRVali:ERROR:2.\n"); fflush(stdout);
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid DR-status from DR0/DR1/DR2/DR3/DR3P/DR4/DR5/AR0/AR1/AR2/AR3/AR3P/AR4/AR5/DVPT/Pre-KO/KO.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
												return ITK_err;
											}
										}

									}
									else
									{
										//Check Part type
										//if(((tc_strcmp(Prttyp,"V")==0) || (tc_strcmp(Prttyp,"VCCR")==0)|| (tc_strcmp(Prttyp,"A")==0) || (tc_strcmp(Prttyp,"T")==0) || (tc_strcmp(Prttyp,"C")==0) ||
										//(tc_strcmp(Prttyp,"M")==0)||(tc_strcmp(Prttyp,"G")==0)) && ((tc_strcmp(PrtCol,"Y")==0) || (tc_strcmp(PrtCol,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0))
										//Added Hrishikesh and Shrivardhan TZ1.70 02.06.2023
										if(((tc_strcmp(Prttyp,"V")==0) || (tc_strcmp(Prttyp,"VCCR")==0)|| (tc_strcmp(Prttyp,"A")==0) || (tc_strcmp(Prttyp,"T")==0) || (tc_strcmp(Prttyp,"C")==0) ||
										(tc_strcmp(Prttyp,"M")==0)||(tc_strcmp(Prttyp,"G")==0)) && ((tc_strcmp(PrtCol,"Y")==0) || (tc_strcmp(PrtCol,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0) && (tc_strstr(DesgNo,"CK")==NULL))
										{
											printf("\n DRVali:ERROR:3..\n"); fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid DR-status from drop down list.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
											return ITK_err;
										}
									}
								}
							}
						}
					}
					//DR Validation 1.30 End
				}
			}
			else
			{
				// skip as control object is not present.
				printf("\n Validation skiped as control object is not present. \n");fflush(stdout);
			}

		//Vitthal :START: Validate Part Creation
			if( (strstr(roleName,"APL")==NULL) || (strstr(roleName,"MBOM")==NULL) )//MBOM implementation for CV TZ-1.69
			{
				if (AOM_ask_value_string(objTag,"item_revision_id",&item_rev_id)!=ITK_ok)   PrintErrorStack();
				printf("\n item_rev_id  = [%s]\n", item_rev_id);fflush(stdout);
				if(strcmp(item_rev_id,"NR")==0)
				{
					printf("\n item_rev_id  is NR so inside if \n");fflush(stdout);
					iTemp=Validate_On_Creation(objTag);
					if(iTemp>0)
					{
						if(iTemp==1)EMH_store_error_s1(EMH_severity_error,ITK_err,"Start Part/Product is Mandatory for Part Type Assembly,Component,TPL and GID for CATIA Design group");
						return ITK_err;
					}
				}
			}
		//Vitthal :END: Validate Part Creation

	/****************Adi TZ 1.32 Validation on Design Rev creation *************************/

				if(AOM_ask_value_string(objTag,"item_revision_id",&Rev_id));
			printf("\n Rev_id  => %s\n", Rev_id);fflush(stdout);

		    if(AOM_ask_value_string(objTag,"t5_DesignGrp",&DesignGrpCatia));
			printf("\n DesignGrpCatia => %s\n",DesignGrpCatia);fflush(stdout);

			if(AOM_ask_value_string(objTag,"t5_PartType",&PartTypeDR));
			printf("\n PartTypeDR => %s\n",PartTypeDR);fflush(stdout);

			printf("\n DesignGrp => %s\n",DesignGrp);fflush(stdout);

            if(tc_strstr(DesignGrp,DesignGrpCatia)!=NULL)
			  {
			   printf("\n catia design group so proceed => %s\n",DesignGrpCatia);fflush(stdout);

			    //if((strcmp(PartTypeDR,"A")==0)||(strcmp(PartTypeDR,"C")==0)||(strcmp(PartTypeDR,"M")==0)) //Adi 1.35 commented to extend functionality to all part types
				//{																							//Adi 1.35 commented
					if(tc_strstr(Rev_id,"NR")!=NULL)
					{
						Rev_idlength = strlen(Rev_id);

						if((Rev_idlength)>2)
						{
							Rev_Sub=subString(Rev_id,0,3);
							printf("\n Rev_Sub => %s\n",Rev_Sub);fflush(stdout);

							if(tc_strcmp(Rev_Sub,"NR;")==0) //&& checked out ==Y OR erc REVIEW LIFECYCLE STATE ?
							{
								printf("\n PROCEED   2222222222 \n");fflush(stdout);
							}
							else
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter Revision value either as NR; followed by sequence OR simply NR");
								return ITK_err;
							}

						}
						else if((Rev_idlength)==2)
						{
						   Rev_Sub1=subString(Rev_id,0,2);
						   printf("\n Rev_Sub1 is => %s\n",Rev_Sub1);fflush(stdout);

							if(tc_strcmp(Rev_Sub1,"NR")==0)
							{
								printf("\n PROCEED   3333333333 \n");fflush(stdout);
							}
							else
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter Revision value either as NR; followed by sequence OR simply NR");
								return ITK_err;
							}
						}
						printf("\n PROCEED   44444444 \n");fflush(stdout);
					}
				   else /************* Adi TZ 1.35 Begin do not allow creation of higher rev if NR does not exist*********************/
				    {
					   if (ITEM_ask_item_of_rev(objTag,&objMasterTag)!=ITK_ok)PrintErrorStack();

					   ITEM_list_all_revs(objMasterTag,&count1,&rev_list1);
					   printf("\n count1   IS ------- %d \n",count1);fflush(stdout);

					   if(count1>=1)
						{
							  printf("\n count 1 or greater so Proceed");fflush(stdout);
						}
						else
						{
							   EMH_store_error_s1(EMH_severity_error,ITK_err,"Please create initial revision as NR. Please enter Revision value either as NR; followed by sequence OR simply NR");
							   return ITK_err;
						}

				    } /*************Adi TZ 1.35 End do not allow creation of higher rev if NR does not exist*********************/
				//}																							//Adi 1.35 commented

			}
			else
			{
				printf("\n not a catia design group so continue===== \n");fflush(stdout);
			}


		/****************Adi TZ 1.32  Validation on Design Rev creation ENDS ***********************/
		}
		//1.25 t5_PartType

		if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
		printf("\n Desc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);

		if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();
		 printf("\n before NR check\n");fflush(stdout);
		 //weight rounding
		 if( AOM_ask_value_double(objTag,"t5_Weight",&objWeightVal)==ITK_ok)
			  printf("\n user entered weight :%f\n",objWeightVal);fflush(stdout);
		if ((strstr(roleName,"APL")==NULL) || (strstr(roleName,"MBOM")==NULL)) //MBOM implementation for CV TZ-1.69
		{
			if (objWeightVal > 0)
			{
				sprintf(wgtstr,"%0.3f",objWeightVal);
				roundedWtVal = atof(wgtstr);
				printf("\n rounded weight :%f\n",roundedWtVal);fflush(stdout);

				if(AOM_lock(objTag))PrintErrorStack();
				printf("\n Before weight update\n");fflush(stdout);
				if( AOM_set_value_double(objTag,"t5_Weight",roundedWtVal)!=ITK_ok);PrintErrorStack();
				printf("\n After weight update\n");fflush(stdout);
				if(AOM_save(objTag))PrintErrorStack();
				if(AOM_unlock(objTag));PrintErrorStack();
				if(AOM_refresh(objTag,1))PrintErrorStack();
			}
		}

		 //weight rounding

		if(strcmp(Desc_obj2,"NR;1")==0 )
		{
			if(AOM_lock(objTag))PrintErrorStack();
			printf("\n Before Modification Description for NR;1\n");fflush(stdout);
			if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
			printf("\n After Modification Description for NR;1\n");fflush(stdout);
			if(AOM_save(objTag))PrintErrorStack();
			if(AOM_unlock(objTag));PrintErrorStack();
			if(AOM_refresh(objTag,1))PrintErrorStack();
		}

		if(strcmp(Desc_obj2,"NR")==0 )
		{

			 if(AOM_lock(objTag))PrintErrorStack();
			printf("\n Before Modification Description\n");fflush(stdout);
			if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
			printf("\n After Modification Description\n");fflush(stdout);
			if(AOM_save(objTag))PrintErrorStack();
			if(AOM_unlock(objTag));PrintErrorStack();
			if(AOM_refresh(objTag,1))PrintErrorStack();

//TCUA 1.47-Start
/*
			 printf("\n B--inside NR check\n");fflush(stdout);
			if(AOM_lock(objTag));
			if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")) PrintErrorStack();
			if(AOM_save(objTag))PrintErrorStack();
			if(AOM_unlock(objTag))PrintErrorStack();
			printf("\n  NR;1 updated\n");fflush(stdout);


			if(GRM_list_secondary_objects_only(objTag,relation_type,&cnt,&attachments))PrintErrorStack();
			printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);

			for(ij=0;ij<cnt;ij++)
			{
					dataset = attachments[ij];
					if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
					printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

					if (strcmp(ObjectClassType,"Design Revision Master")==0 || strcmp(ObjectClassType,"T5_SparKitRevisionMaster")==0)//T5_SparKitRevisionMaster
					{
						if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
							oojname=strtok(ObjectName,"/");
							strcat(oojname,"/");
							strcat(oojname,"NR;1");
							printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);


							if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();

							if(AOM_lock(dataset));
							if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)) PrintErrorStack();
							if(AOM_save(dataset))PrintErrorStack();
							if(AOM_unlock(dataset))PrintErrorStack();
							break;
					}
			}


			if (CR_create_release_status("ERC Review",&status_rel))PrintErrorStack();
			if(EPM_add_release_status(status_rel,1,&objTag,retain))PrintErrorStack();
*/
//TCUA 1.47-End



			// bhaskar starts

			SA_ask_current_groupmember(&GroupMem);
			 if(GroupMem !=NULLTAG)
								{
								if (AOM_ask_value_string(GroupMem,"object_name",&group_name)!=ITK_ok)PrintErrorStack();
								printf("\ngroup_name session is pare  : %s\n",group_name);fflush(stdout);

									if (SA_ask_groupmember_role(GroupMem,&Roletag) !=ITK_ok)PrintErrorStack();
									if (SA_ask_groupmember_group(GroupMem,&grptag) !=ITK_ok)PrintErrorStack();
									 if((Roletag !=NULLTAG) && (Roletag !=NULLTAG))
								{
								if (AOM_ask_value_string(Roletag,"object_name",&Role_name)!=ITK_ok)PrintErrorStack();
								if (AOM_ask_value_string(grptag,"object_name",&Grp_name)!=ITK_ok)PrintErrorStack();
								printf("\nRole_name session is pare  : %s %s\n",Role_name,Grp_name);fflush(stdout);
								    if (AOM_ask_value_string(objTag,"t5_DesignGrp",&desi_grp)!=ITK_ok)   PrintErrorStack();

									printf("\n Design group  = [%s]\n", desi_grp);fflush(stdout);

									DerRoleNme=NULL;DerRoleNme=malloc(50);
									strcpy(DerRoleNme,desi_grp);
									strcat(DerRoleNme,"_Designers");
									printf("\n Role name required   = [%s]\n", DerRoleNme);fflush(stdout);

									if (SA_find_role(DerRoleNme,&DesRolTag)!=ITK_ok)PrintErrorStack();

									if (SA_find_groupmember_by_user(user_tag,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();

									//if (SA_find_groupmember_by_rolename (DerRoleNme,"Engineering",username,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();
									printf("\n count of  Gmcnt = [%d]", Gmcnt);fflush(stdout);


									ITKCALL(SA_ask_current_role(&CurrentRoleTag));
									ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
									printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


									for(jk=0;jk<Gmcnt;jk++)
										{
											ActGm = GmFound[jk];
											if (AOM_ask_value_string(ActGm,"object_name",&ActGmName)!=ITK_ok)   PrintErrorStack();
											printf("\n ERC/APL Actual Group Member name  = [%s]", ActGmName);fflush(stdout);
											//if (strstr(ActGmName,DerRoleNme)|| strstr(roleName,"APL") ) //DEEPTI ADDED TZ1.42
											if (strstr(ActGmName,DerRoleNme) && ((tc_strstr(roleName,"APL")==NULL) || (tc_strstr(roleName,"MBOM")==NULL) )) //DEEPTI ADDED TZ1.42//MBOM implementation for CV TZ-1.69
											{
                                             Rolflag++;
                                             DerRoleNme1=NULL;DerRoleNme1=malloc(100);
											 strcpy(DerRoleNme1,ActGmName);
											 //break;
											}
											else if (tc_strstr(ActGmName,roleName)!=NULL)
											{
												printf("\n\n  Inside APL"); fflush(stdout);
												Rolflag++;
												DerRoleNme1=NULL;DerRoleNme1=malloc(100);
												strcpy(DerRoleNme1,ActGmName);
												break;

											}

										}
										printf("\n count of  Rolflag = [%d]\n", Rolflag);fflush(stdout);
										printf("\n DerRoleNme1 is  = [%s]\n", DerRoleNme1);fflush(stdout);
										if ((Rolflag==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
											{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
											return ITK_err;
											}
								}
								}

			if (AOM_get_value_string(objTag,"t5_ProjectCode",&ObjProject))PrintErrorStack();
			 printf("\nProject stamped is  : %s\n",ObjProject);fflush(stdout);

			if(strcmp(ObjProject,"")!=0)
						 {
							if (PROJ_find(ObjProject,&projobj) !=ITK_ok)PrintErrorStack();

							if(projobj !=NULLTAG)
							{
								//if (TCTYPE_ask_object_type(projobj,&projobj1)!=ITK_ok)PrintErrorStack();

								//if (TCTYPE_ask_name(projobj1,Ptype_name1)!=ITK_ok)PrintErrorStack();
								//printf("\n Proj type_name = %s\n", Ptype_name1);
								printf("\nAssigned to Projecttttttt33\n");fflush(stdout);



								SA_ask_current_project(&Currproj);

                                 if(Currproj !=NULLTAG)
								{
								if (AOM_ask_value_string(Currproj,"object_name",&parent_name)!=ITK_ok)PrintErrorStack();
								printf("\nProject session is pare  : %s\n",parent_name);fflush(stdout);
								//if (AOM_UIF_ask_value(Currproj,"workcontext_name",&currpro)!=ITK_ok)PrintErrorStack();
								// if (POM_attr_id_of_attr( "project", "TC_WorkContext", &projid )!=ITK_ok)PrintErrorStack();



			//							if (strcmp(parent_name,ObjProject)==0)
			//							{
			//								printf("\nAssigned to Projecttttttt\n");fflush(stdout);
			//							}
			//							else
							{
  								if (PROJ_is_user_a_member(projobj,user_tag,&promem)!=ITK_ok)PrintErrorStack();

								 if(promem==1)
						              {
						                printf("\nsetting session project as t5_projectcode attribute\n");fflush(stdout);
										//EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly set same project in session details as per entered project code for Part");
										//return ITK_err;
										SA_set_current_project(projobj);
									if (PROJ_ask_team(projobj,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok)PrintErrorStack();

								       for(jkl=0;jkl<Gmcnt1;jkl++)
										{
											ActGm1 = GmFound1[jkl];
											if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
											printf("\n Actual Group Member name1  = [%s]", ActGmName1);fflush(stdout);
                                        if(DerRoleNme1)
											{
											if (strcmp (ActGmName1,DerRoleNme1) == 0)
											{
                                               printf("---Valid user to create the part\n");fflush(stdout);
											   Rolflag1++;
											}
											}
										}
											if ((Rolflag1==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
											{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
											return ITK_err;
											}

						              }
									  else
						              {
						                      printf("\ncall error ITK ok2\n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not member for this project. kindly get access from TCUA Admin and set same project in session details");
										return ITK_err;
						              }



							}
							printf("\nAssigned to Project\n");fflush(stdout);
							}
							else
							 {
							if (PROJ_is_user_a_member(projobj,user_tag,&promem)!=ITK_ok)PrintErrorStack();

								 if(promem==1)
						              {
						                printf("\nsetting session project as t5_projectcode attribute\n");fflush(stdout);
										//EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly set same project in session details as per entered project code for Part");
										//return ITK_err;
										SA_set_current_project(projobj);

										if (PROJ_ask_team(projobj,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok)PrintErrorStack();

								       for(jkl=0;jkl<Gmcnt1;jkl++)
										{
											ActGm1 = GmFound1[jkl];
											if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
											printf("\n Actual Group Member name1  = [%s]\n", ActGmName1);fflush(stdout);
                                        if(DerRoleNme1)
											{
											if (strcmp (ActGmName1,DerRoleNme1) == 0)
											{
                                               printf("\nValid user to create the part\n");fflush(stdout);
											   Rolflag1++;
											}
											}
										}
											if ((Rolflag1 == 0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
											{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
											return ITK_err;
											}


						              }
									  else
						              {
						                      printf("\ncall error ITK ok2\n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not member for this project. kindly get access from TCUA Admin and set same project in session details");
										return ITK_err;
						              }
							 }

						}
						 }
						else
								{
									printf("\ncall error ITK ok2\n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter the Project code and set the same project in session details");
									   return ITK_err;
								}
// bhaskar ends

//			if(AOM_load(objTag))PrintErrorStack();
//			if(AOM_lock(objTag))PrintErrorStack();
//			printf("\n Before Modification Description\n");fflush(stdout);
//			if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
//			printf("\n After Modification Description\n");fflush(stdout);
//			if(AOM_save(objTag))PrintErrorStack();
//			if(AOM_unlock(objTag));PrintErrorStack();
//			if(AOM_unload(objTag))PrintErrorStack();
//			if(AOM_refresh(objTag,1))PrintErrorStack();

//			if(RES_is_checked_out(objTag,&checkout))PrintErrorStack();
//			if (checkout==0)
//			{
//				if (RES_checkout(objTag,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
//
//				printf("\n**********After Check Out DR in createpost***************\n");fflush(stdout);
//				if(GRM_list_secondary_objects_only(objTag,reln_type,&c_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
//				printf("\nc_attchs :%d\n",c_attchs);fflush(stdout);
//				if(c_attchs>0)
//				{
//					for (p= 0; p < c_attchs; p++)
//					{
//						primary=secondary_objects[p];
//						if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
//						if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
//						if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0|| strcmp(type_name2,"ProDrw")==0)
//						{
//							  if(RES_is_checked_out(primary,&checkoutp))PrintErrorStack();
//							   if (checkoutp==0)
//							 {
//								if (RES_checkout(primary,&reason1,&change_id1,&dir_name1,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
//								printf("\n**********After Check Out Dataset in createpost***************\n");fflush(stdout);
//							 }
//
//						}
//
//
//					}
//				}
//			}
		}

		if (objTag!=NULLTAG)
		{
			if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);PrintErrorStack();
			if( AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok);PrintErrorStack();

		if(strcmp(Desc,"")!=0)
		{
			desclength = strlen(Desc);
			for(desccnt=0;desccnt<desclength;desccnt++)
			{
				if(Desc[desccnt]=='\n')
					Desc[desccnt] =' ';

				if(Desc[desccnt]=='`')
					Desc[desccnt] =' ';

				if(Desc[desccnt]=='~')
					Desc[desccnt] =' ';

				if(Desc[desccnt]=='|')
					Desc[desccnt] =' ';

				if(Desc[desccnt]=='$')
					Desc[desccnt] =' ';

				if(Desc[desccnt]=='#')
					Desc[desccnt] =' ';

				if(Desc[desccnt]=='@')
					Desc[desccnt] =' ';

				if(Desc[desccnt]=='^')
					Desc[desccnt] =' ';

				if(Desc[desccnt]=='!')
					Desc[desccnt] =' ';
				printf("\n [%c]\n",Desc[desccnt]);fflush(stdout);
			}
			//val=(char **)MEM_alloc(sizeof(char **));
			NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
			strcpy(NewDesc,Desc);

			printf("\n !!!!!!!!!!!!!!!!! save_method_4:::::::NewDesc[%s]!!!!!!!!!!!!!!!!!!!\n", NewDesc);fflush(stdout);

			if(NewDesc!=NULL)
			{
				//AOM_lock(objTag);
				if(AOM_set_value_string(objTag,"object_desc",NewDesc)!=ITK_ok);PrintErrorStack();
				if(AOM_save(objTag)!=ITK_ok);PrintErrorStack();
				//AOM_unlock(objTag);
				if( AOM_ask_value_string(objTag,"object_desc",&NewDescription)!=ITK_ok);PrintErrorStack();
				printf("\n !!!!!!!!!!!!!!!!! save_method_4:::::::NewDescription[%s]!!!!!!!!!!!!!!!!!!!\n", NewDescription);fflush(stdout);
			}
		}
	}

	//Add by Hanuman in TZ 1.54
	char *Desc_RevID=NULL;
	char *DescTD=NULL;
	printf("\n save_method_4::DesgNo is => [%s] ", DesgNo);fflush(stdout);
	if(AOM_ask_value_string(objTag,"item_revision_id",&Desc_RevID)!=ITK_ok)   PrintErrorStack();
	printf("\n save_method_4::Desc_RevID  = [%s] ", Desc_RevID);fflush(stdout);
	if(strstr(Desc_RevID,"NR")!=NULL)
	{
		if( AOM_ask_value_string(objTag,"object_desc",&DescTD)!=ITK_ok);PrintErrorStack();
		printf("\n save_method_4::DescTD  = [%s] ", DescTD);fflush(stdout);
		if(DescTD!=NULL)
		{
			if(strstr(DescTD,"TABLE DRG.")!=NULL || strstr(DescTD,"TABLE DRG")!=NULL || strstr(DescTD,"TABLE DRAWING")!=NULL || strstr(DescTD,"TABLE OFFER DRAWING")!=NULL || strstr(DescTD,"TABLE DRW")!=NULL || strstr(DescTD,"TABLE OFFER DRG.")!=NULL || strstr(DescTD,"TABLE DRWG")!=NULL || strstr(DescTD,"TBL DRG.")!=NULL || strstr(DescTD,"TBL DRG")!=NULL || strstr(DescTD,"TBL.DRG.")!=NULL || strstr(DescTD,"TBL.DRG")!=NULL || strstr(DescTD,"TBLE_DRG")!=NULL || strstr(DescTD,"TBL DRAWING")!=NULL || strstr(DescTD,"TABLE-DRG.")!=NULL || strstr(DescTD,"TABLE-DRAWING")!=NULL || strstr(DescTD,"TABLE-DRG")!=NULL)
			{
				ForthBarrel = subString(DesgNo,8,2);
				printf("\n ForthBarrel: [%s]",ForthBarrel);fflush(stdout);
				if(tc_strcmp(ForthBarrel,"04")==0)
				{
					printf("\n ForthBarrel is: [%s], so you can create TD ",ForthBarrel);fflush(stdout);
				}else
				{
					printf("\nIf Part [%s] and ForthBarrel [%s] Please select 9th and 10th digit should be 04 \n",DesgNo,ForthBarrel);fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"For Description Table Drawing 3rd barrel of 12 digit number should be 04. Please choose correct Part number or change the current Dscription accordingly.");
					return ITK_err;
				}
			}else
			{
				printf("\n DescTD:[%s] Can't cantain TABLE DRAWING so you can create TD\n",DescTD);fflush(stdout);
			}
		}
	}else
	{
		printf("\n save_method_4::Checked-in Design Revision is other than NR= [%s]\n",Desc_RevID);fflush(stdout);
	}

	//Added by hanuman
	if(AOM_ask_value_string(objTag,"t5_PartType", &objPartType)!=ITK_ok); PrintErrorStack();
	printf("\n save_method_4::Create Design Revision of Type :: [%s]\n", objPartType);fflush(stdout);

	if(tc_strcmp(objPartType,"T")==0)
	{
		if((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0))
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"TPL creation should not be allowed from front end.");
			return ITK_err;
		}
	}

	//	if(desid)
	//	{
//
//				printf("\n before  QRY_find : QRY_find \n");
//				 if(QRY_find("Dataset1", &queryTag));PrintErrorStack();
//				printf("\n After IFERR_REPORT : QRY_find \n");
//				if (queryTag)
//				{
//					printf("Found Query\n");
//
//				}
//				else
//				{
//					printf("Not Found Query");
//				}
//
//			    if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &resultTags));PrintErrorStack();
//			    printf("resultCount **** %d", resultCount);


		 printf("save_method_4::After mem1 alloc\n");
				 dst_name = NULL;
				 dst_name=(char *) MEM_alloc(200);
				 printf("After mem alloc\n");

									tc_strcpy (dst_name, desid);
									strcat(dst_name,"/");
									strcat(dst_name,"NR;1");

					//
							// if ( AE_find_datasettype (dst_name, &a_datasettype)!=ITK_ok);PrintErrorStack();
							 printf("After find  dataset\n");


								 //printf("drawign name %s,%s",DrwName1,DrwName);
					//if( AE_find_all_datasets_by_id(a_datasettype, "000138", &resultCount, &resultTags)!=ITK_ok);PrintErrorStack();
					if( AE_find_all_datasets(dst_name, &resultCount, &resultTags)!=ITK_ok);PrintErrorStack();
					 printf("resultCount **** %d\n", resultCount);

					if (resultCount == 0 )
					{
						tc_strcpy (dst_name, "");
						tc_strcpy (dst_name, desid);
						strcat(dst_name,"/");
						strcat(dst_name,"NR");
						printf("After find  dataset..2\n");
						if( AE_find_all_datasets(dst_name, &resultCount, &resultTags)!=ITK_ok);PrintErrorStack();
						printf("resultCount:::::: %d", resultCount);
					}

						if (resultCount  > 0 )
						{

							for (j=0;j<resultCount;j++ )
							{

								item_tag = resultTags[j];


								if( AE_ask_dataset_latest_rev(item_tag, &latest_datas)!=ITK_ok);PrintErrorStack();


								if( AOM_ask_value_string(latest_datas,"object_name",&DrwName)!=ITK_ok);PrintErrorStack();
								DrwName1=strtok(DrwName,"/");
								printf ( "DrwName%s and desid :%s\n", DrwName1,desid);fflush(stdout);
								if( AOM_ask_value_string(latest_datas,"object_type",&object_typeDS)!=ITK_ok);PrintErrorStack();

								//if( AE_ask_dataset_id_rev(latest_datas, &dataset_id, &dataset_rev )!=ITK_ok);PrintErrorStack();
								printf ( "dataset object_typeDS :%s\n", object_typeDS);fflush(stdout);

								if(tc_strcmp(object_typeDS,"CMI2Drawing")==0)
								{

								if ((dsflag == 0) && (strcmp(DrwName1,desid) ==0))
								{

									if( AOM_ask_value_string(objTag,"t5_Material",&objname)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_string(objTag,"t5_MThickness",&objMatThickness)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_string(objTag,"t5_OppHandDrg",&objOppHandDrg)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_string(objTag,"t5_RefDrawing",&objRefDrw)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_string(objTag,"t5_SurfPrtStd",&objSurfStd)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_double(objTag,"t5_Weight",&objWeight)!=ITK_ok);PrintErrorStack();

									printf ( "t5_PartMaterial for rev is  %s , t5_OppHandDrg :%s and objRefDrw :%s and objMatThickness :%s \n", objname,objOppHandDrg,objRefDrw,objMatThickness);fflush(stdout);
									AOM_lock(item_tag);
									if( AOM_set_value_string(item_tag,"t5_PartMaterial",objname)!=ITK_ok);PrintErrorStack();
									if( AOM_set_value_string(item_tag,"t5_MThickness",objMatThickness)!=ITK_ok);PrintErrorStack();
									// if(strcmp(objOppHandDrg,"")==0)
									//{
										if( AOM_set_value_string(item_tag,"t5_OppHandDrg",objOppHandDrg)!=ITK_ok);PrintErrorStack();
									//}
									// if(strcmp(objRefDrw,"")==0)
									//{
										if( AOM_set_value_string(item_tag,"t5_RefDrawing",objRefDrw)!=ITK_ok);PrintErrorStack();
									//}
									if( AOM_set_value_string(item_tag,"t5_SurfPrtStd",objSurfStd)!=ITK_ok);PrintErrorStack();
									if( AOM_set_value_double(item_tag,"t5_Weight",objWeight)!=ITK_ok);PrintErrorStack();
									if(AOM_save(item_tag))PrintErrorStack();
									if(AOM_unlock(item_tag))PrintErrorStack();
									dsflag++;
									break;
								}

								}
							}

						}
		//}


	}

	return error_code;
}
//Ashish -

int IsDesignRevisionAvail(char* InputPart)
{
	int		IsAvailInUA		=	0;
	tag_t   OutPutTag		=	NULLTAG;
	int		n_tags_found2	=	0;
	tag_t	*tags_found2	=	NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int		n_tags_foundd2	=	0;
	tag_t	*tags_foundd2	=	NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	//MT end
	printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
		IsAvailInUA = 1;
		printf("\n Part found in TCUA:");fflush(stdout);
	}
	else
	{
		printf("\n Part not found in TCUA:");fflush(stdout);
		IsAvailInUA = 0;
	}
	return IsAvailInUA;
}

int FunToCheckPartAvailInICE(tag_t cntrl_objTCE,char *Item_ID)
{
	int IsAvailTCE = 0;

	// Added code to consume web service

	printf("\n consuming web service start \n"); fflush(stdout);

	char*syscommand=NULL;
	char*ExePath=NULL;
	char*UsrP=NULL;
	char*PwdP=NULL;
	char*roleP=NULL;

	// Added code to consume web service

	printf("\n consuming web service start: \n"); fflush(stdout);

	if (AOM_ask_value_string(cntrl_objTCE,"t5_Userinfo1",&ExePath)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(cntrl_objTCE,"t5_Userinfo2",&UsrP)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(cntrl_objTCE,"t5_Userinfo3",&PwdP)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(cntrl_objTCE,"t5_Userinfo4",&roleP)!=ITK_ok)   PrintErrorStack();
	printf("\n cntrl_objTCE: ExePath is  = [%s] PwdP = [%s]\n", ExePath,PwdP);fflush(stdout);

	syscommand=(char *) MEM_alloc(200);
	tc_strcpy(syscommand,ExePath);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,UsrP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,PwdP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,roleP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,Item_ID);

	printf("\n  start Calling exe using system syscommand: [%s]\n",syscommand); fflush(stdout);

	int rc;
	FILE *pipe = NULL;
	int i;
	char buffer[3000];


	sprintf(buffer, "%s",syscommand);
	if ((pipe = popen(buffer, "r")) == NULL) {
	perror("popen");
	return 1;
	}
	while (fgets(buffer, 3000, pipe) != NULL)

	printf("buffer: %s",  buffer);

	if (pclose(pipe) == -1) {
	perror("pclose");
	return 1;
	}
	printf("\n consuming web service end \n"); fflush(stdout);

	if(strstr(buffer,"[NA]")!=NULL)
		{
			printf("\n Checked in TCE, part is not present in TCE  \n"); fflush(stdout);
			IsAvailTCE =0;
		}
		else
		{
			printf("\n Checked in TCE, part is present in TCE \n"); fflush(stdout);
			IsAvailTCE =2;
		}

	return IsAvailTCE;
}
int FunToCheckGroupIDRefInICE(tag_t CntrlObj_tag,char* Item_id,char*GroupID)
{
	int IsAvailTCE = 0;
	char*syscommand=NULL;
	char*ExePath=NULL;
	char*UsrP=NULL;
	char*PwdP=NULL;
	char*roleP=NULL;

	// Added code to consume web service

	printf("\n consuming web service start: \n"); fflush(stdout);

	if (AOM_ask_value_string(CntrlObj_tag,"t5_Userinfo1",&ExePath)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(CntrlObj_tag,"t5_Userinfo2",&UsrP)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(CntrlObj_tag,"t5_Userinfo3",&PwdP)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(CntrlObj_tag,"t5_Userinfo4",&roleP)!=ITK_ok)   PrintErrorStack();
	printf("\n CntrlObj_tag: ExePath is  = [%s] PwdP = [%s]\n", ExePath,PwdP);fflush(stdout);

	syscommand=(char *) MEM_alloc(200);
	tc_strcpy(syscommand,ExePath);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,UsrP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,PwdP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,roleP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,Item_id);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,GroupID);

	printf("\n  start Calling exe using system syscommand: [%s]\n",syscommand); fflush(stdout);

	int rc;
	FILE *pipe = NULL;
	int i;
	char buffer[3000];

	sprintf(buffer, "%s",syscommand);
	if ((pipe = popen(buffer, "r")) == NULL) {
	perror("popen");
	return 1;
	}
	while (fgets(buffer, 3000, pipe) != NULL)

	printf("buffer: %s",  buffer);

	if (pclose(pipe) == -1) {
	perror("pclose");
	return 1;
	}
	printf("\n consuming web service end \n"); fflush(stdout);

	if(strstr(buffer,"[NA]")!=NULL)
		{
			printf("\n $$$ Checked in TCE, part is not present in TCE  $$$ \n"); fflush(stdout);
			IsAvailTCE =0;
		}
		else
		{
			printf("\n $$$ Checked in TCE, part is present in TCE \n $$$"); fflush(stdout);
			IsAvailTCE =2;
		}

	return IsAvailTCE;
}
int FunToValidateProjectCodeNPartType(tag_t Des_Rev_tag,char **OutputStr)
{
	int		IsValidFlag			=	0;
	char	*sProjCode			=	NULL;
	char	*sPrtType			=	NULL;
	char*	sUsrInfo2			=	NULL;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	int     n_entry				=	3;
	int		IntCntlObj			=	0;
	tag_t   *CntrlObject_Tag    =	NULLTAG;
	char	*PartTypeVal		=	NULL;
	char    *qry_sys_entry[3]	=	{"SYSCD","SUBSYSCD","Information-1"};
	char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));

	*OutputStr=(char *) MEM_alloc(250);
	PartTypeVal=(char *) MEM_alloc(250);

	strcpy(*OutputStr,"");
	strcpy(PartTypeVal,"");

	printf("\n Inside save_method_4:FunToValidateProjectCodeNPartType \n");fflush(stdout);

	if( AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&sProjCode)==ITK_ok)  PrintErrorStack();
	if( AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&sPrtType)==ITK_ok) PrintErrorStack();

	printf("\n Project Code:[%s] Part Type:[%s] \n",sProjCode,sPrtType);fflush(stdout);

	// create control object having info1 == project code and info2 == part type
	// if project code in info1 check it's accessibility for the part types in info2.

	if(QRY_find("Control Objects...", &Cntl_obj_Qtag));
	if (Cntl_obj_Qtag)
	{
		printf("\n save_method_4:FunToValidateProjectCodeNPartType::Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n save_method_4:FunToValidateProjectCodeNPartType::Not Found Query ControlObjects \n");fflush(stdout);
	}
	qry_sys_values[0] = "ProCodeNPrtTypeVal";
	qry_sys_values[1] = "ProCodeNPrtTypeVal";
	qry_sys_values[2] =	 sProjCode;
	if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
	printf(" \n save_method_4:FunToValidateProjectCodeNPartType:IntCntlObj:[%d]",IntCntlObj); fflush(stdout);
	if(IntCntlObj>0)
	{
		if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo2",&sUsrInfo2)!=ITK_ok);PrintErrorStack();
		strcat(PartTypeVal,"[");
		strcat(PartTypeVal,sPrtType);
		strcat(PartTypeVal,"]");
		printf(" \n save_method_4:FunToValidateProjectCodeNPartType:sUsrInfo2:[%s]:PartType:[%s]",sUsrInfo2,PartTypeVal); fflush(stdout);
		if(strstr(sUsrInfo2,PartTypeVal)!=NULL)
		{
			printf(" \n inside if."); fflush(stdout);
			IsValidFlag = 0;
		}
		else
		{
			printf(" \n inside else."); fflush(stdout);
			IsValidFlag =1;
			strcat(*OutputStr,"Part Type ");
			strcat(*OutputStr,sPrtType);
			strcat(*OutputStr," is invalid for selected project code: ");
			strcat(*OutputStr,sProjCode);
		}
	}
	else
	{
	printf(" \n save_method_4:FunToValidateProjectCodeNPartType: Control object not found for:syscd[ProCodeNPrtTypeVal],subsyscd[ProCodeNPrtTypeVal],info1[%s]",sProjCode); fflush(stdout);
	}

	return IsValidFlag;
}

		/******************************************************* Added by Aashish_w Start *******************************************************/
int t5_partcategory(tag_t Des_Rev_tag,char **OutputStr)
{
	int		IsValidFlag			=	0;
	char *partcatgry = NULL;
	partcatgry=(char *) MEM_alloc(1000);
	char *parttype = NULL;
	char *prjcode = NULL;
	char *designGrp = NULL;
	char *itemid;
	itemid=(char *) MEM_alloc(1000);
	char *itemid_toked;
	itemid_toked=(char *) MEM_alloc(1000);
	char *itemid_toked1;
	itemid_toked1=(char *) MEM_alloc(1000);
	int itemidlength = 0;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	tag_t   Cntl_obj_Qtag2		=	NULLTAG;
	int n_entries1 = 3;
	int n_entries2 = 3;
	char *qry_entries1[3] = {"Name","SYSCD","SUBSYSCD"};
	char *qry_entries2[3] = {"Information-1","SYSCD","SUBSYSCD"};
	char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values2 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount1=0;
	int resultCount2=0;
	tag_t *qry_cntrlobj= NULLTAG;
	tag_t *qry_cntrlobj2= NULLTAG;
	char *userinfo1;

	*OutputStr=(char *) MEM_alloc(250);
	strcpy(*OutputStr,"");

	printf("\n Inside save_method_4:t5_partcategory \n");fflush(stdout);

	printf("\n Welcome to PLM World \n");fflush(stdout);

	if( AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry)==ITK_ok)  PrintErrorStack();
	printf(" Part Category --------> %s \n",partcatgry);fflush(stdout);
	//if (partcatgry != NULL)
	if (tc_strlen(partcatgry)!=0)
{
	if(QRY_find("Control Objects...", &Cntl_obj_Qtag));
	if (Cntl_obj_Qtag)
	{
		printf("\n Query Found : Control Objects... \n");fflush(stdout);
	}
	else
	{
		printf("\n Query NOT Found : Control Objects... \n");fflush(stdout);
	}
//************************************ 1.Designer has to mandatorily select the part categories from the available dropdown while creating TC part. ************************************
					qry_values1[0] = partcatgry ;
					qry_values1[1] = "PRTCAT" ;
					qry_values1[2] = "PRTCAT" ;

					ITK_CALL(QRY_execute(Cntl_obj_Qtag, n_entries1, qry_entries1, qry_values1, &resultCount1, &qry_cntrlobj));
					printf("\n Count of Control object found while save validation ------------------>  %d \n",resultCount1);
	if (resultCount1 > 0)
	{
					printf("\n Inside my IF \n");fflush(stdout);
			AOM_ask_value_string(qry_cntrlobj[0],"t5_Userinfo1",&userinfo1);

			ITK_CALL(AOM_refresh(Des_Rev_tag,1));

			ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria",userinfo1));

			ITK_CALL( AOM_save(Des_Rev_tag));

			ITK_CALL(AOM_refresh(Des_Rev_tag,0));

			IsValidFlag =0;

			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry));
			printf(" Part Category after save --------> %s \n",partcatgry);fflush(stdout);


			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
			printf(" Item ID --------> %s \n",itemid);fflush(stdout);
//******************** 2.CON- Consumable parts will be needed. Check will be put in not to use this part category for 12 digit ERC part. *******************
			if (tc_strcmp(partcatgry,"CON")==0)
			{
					printf("\n inside Part Category CON check \n");fflush(stdout);
				if (tc_strlen(itemid) == 12)
				{
					printf("\n CON Lov BreakDown...\n");fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"Part Category CON:Consumable parts is invalid for 12 digit parts.");
				}
			}
//******************** 3.As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
			printf("\n Part Type is ----> %s \n",parttype);fflush(stdout);
			if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0)
			{
				printf("\n Inside Part Type Dummy check \n");fflush(stdout);
				ITK_CALL(AOM_refresh(Des_Rev_tag,1));

				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));

				ITK_CALL( AOM_save(Des_Rev_tag));

				ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
				printf(" Project Code of Part --------> %s \n",prjcode);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
				printf(" Design Group of Part --------> %s \n",designGrp);fflush(stdout);

//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
					//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
			//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
//******************** 4.System should not allow STD & CON for parts other than project code "1111" & design group "11". ********************
			if (tc_strcmp(partcatgry,"STD")==0 || tc_strcmp(partcatgry,"CON")==0 )
			{
				printf("\n inside project code 1111 & design group 11 check \n");fflush(stdout);

				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
			//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
			//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				else
				{
					if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
				{
						printf("\n Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
				else
				{
					printf("\n STD & CON Lov BreakDown...\n");fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"Part Category STD:Standard Part & CON:Consumable parts is valid only for Project Code 1111 & Design Group 11 & 54.Please select other value.");
				}
				}
			}
//******************** 5.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************
			if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
				{
						printf("\n Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
//******************** 6.Part type Vehicle , TPL, VC, Group ID, Dummy, Dummy TPL,VC CR must carry PHN (PHN:Phantom Assembly). ********************
				if (tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"VCCR")==0 )
			{
				printf("\n Inside Part type Vehicle , TPL, VC CR, VC, Group ID, Dummy, Dummy TPL must carry PHN check \n");fflush(stdout);
				ITK_CALL(AOM_refresh(Des_Rev_tag,1));
				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
				ITK_CALL( AOM_save(Des_Rev_tag));
				ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}
//******************** 7.Part number having third barrel �16� must carry TSD:TML Specification Document. ********************
			itemid_toked1=subString(itemid,6,2);
			printf("itemid_toked1 of 3rd baral ------> %s",itemid_toked1);
			if (tc_strcmp(itemid_toked,"16")==0)
				{
					printf("\n Inside Part number having third barrel �16� must carry TSD:TML Specification Document check \n");fflush(stdout);
					if (tc_strcmp(partcatgry,"TSD-Black")==0 || tc_strcmp(partcatgry,"TSD-Gray")==0)
					{
							printf("\n Inside Part number having third barrel �16� must carry TSD:TML Specification Document check Sucessful\n");fflush(stdout);
					}
					else
					{
						printf("\n third barrel 16 Lov BreakDown...\n");fflush(stdout);
						IsValidFlag =1;
						strcat(*OutputStr,"Please Select Part Category as TSD-Black or TSD-Gray.");
					}
				}
	}
	else
	{
		if(QRY_find("Control Objects...", &Cntl_obj_Qtag2));
					qry_values2[0] = partcatgry ;
					qry_values2[1] = "PRTCAT" ;
					qry_values2[2] = "PRTCAT" ;
		ITK_CALL(QRY_execute(Cntl_obj_Qtag2, n_entries2, qry_entries2, qry_values2, &resultCount2, &qry_cntrlobj2));
		printf("\n Count of Control object 2222 found while save validation ------------------>  %d \n",resultCount2);
	if (resultCount2 > 0)
	{
				IsValidFlag =0;
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry));
				printf(" Part Category after save --------> %s \n",partcatgry);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
				printf(" Item ID --------> %s \n",itemid);fflush(stdout);
//******************** 2.CON- Consumable parts will be needed. Check will be put in not to use this part category for 12 digit ERC part. *******************
			if (tc_strcmp(partcatgry,"CON")==0)
			{
					printf("\n inside Part Category CON check \n");fflush(stdout);
				if (tc_strlen(itemid) == 12)
				{
					printf("\n CON Lov BreakDown...\n");fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"Part Category CON:Consumable parts is invalid for 12 digit parts.");
				}
			}
//******************** 3.As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
			printf("\n Part Type is ----> %s \n",parttype);fflush(stdout);
			if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0)
			{
			printf("\nInside Part Type Dummy check \n");fflush(stdout);
				ITK_CALL(AOM_refresh(Des_Rev_tag,1));

				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));

				ITK_CALL( AOM_save(Des_Rev_tag));

				ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
				printf(" Project Code of Part --------> %s \n",prjcode);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
				printf(" Design Group of Part --------> %s \n",designGrp);fflush(stdout);
//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
					//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
			//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
//******************** 4.System should not allow STD & CON for parts other than project code "1111" & design group "11". ********************
			if (tc_strcmp(partcatgry,"STD")==0 || tc_strcmp(partcatgry,"CON")==0 )
			{
				printf("\n inside project code 1111 & design group 11 check \n");fflush(stdout);

				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
			//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
			//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				else
				{
					if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
				{
						printf("\n Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
				else
				{
					printf("\n STD & CON Lov BreakDown...\n");fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"Part Category STD:Standard Part & CON:Consumable parts is valid only for Project Code 1111 & Design Group 11.Please select other value.");
				}
				}
			}
//******************** 5.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************
			if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
				{
						printf("\n Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
//******************** 6.Part type Vehicle , TPL, VC, Group ID, Dummy, Dummy TPL,VC CR must carry PHN (PHN:Phantom Assembly). ********************
		   if (tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"VCCR")==0 )
			{
				printf("\n Inside Part type Vehicle,TPL,VC_CR,VC,Group_ID,Dummy,Dummy_TPL must carry PHN check \n");fflush(stdout);
				ITK_CALL(AOM_refresh(Des_Rev_tag,1));
				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
				ITK_CALL( AOM_save(Des_Rev_tag));
				ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}
//******************** 7.Part number having third barrel �16� must carry TSD:TML Specification Document. ********************
			itemid_toked1=subString(itemid,6,2);
			printf("itemid_toked1 of 3rd baral ------> %s",itemid_toked1);
			if (tc_strcmp(itemid_toked,"16")==0)
				{
					printf("\n Inside Part number having third barrel �16� must carry TSD:TML Specification Document check \n");fflush(stdout);
					if (tc_strcmp(partcatgry,"TSD-Black")==0 || tc_strcmp(partcatgry,"TSD-Gray")==0)
					{
							printf("\n Inside Part number having third barrel �16� must carry TSD:TML Specification Document check Sucessful\n");fflush(stdout);
					}
					else
					{
						printf("\n third barrel 16 Lov BreakDown...\n");fflush(stdout);
						IsValidFlag =1;
						strcat(*OutputStr,"Please Select Part Category as TSD-Black or TSD-Gray.");
					}
				}
	}
	else
	{
		printf("\n Suggestive LOV Breakdown...\n");fflush(stdout);
		IsValidFlag =1;
		strcat(*OutputStr,"Please select values of Part Category from Dropdown List Only.");
	}
	}
}
else
{
		//******************** As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
			printf("\n Part Type is ----> %s \n",parttype);fflush(stdout);
		if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"VCCR")==0 )
			{
				printf("\nInside Part Type Dummy check \n");fflush(stdout);
				ITK_CALL(AOM_refresh(Des_Rev_tag,1));

				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));

				ITK_CALL( AOM_save(Des_Rev_tag));

				ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}
		else
	{
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
				printf(" Project Code of Part --------> %s \n",prjcode);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
				printf(" Design Group of Part --------> %s \n",designGrp);fflush(stdout);
		//******************** Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************
			if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
				{
						printf("\n Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
				else
				{
					ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
		//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
		//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
		//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				else
					{

						IsValidFlag =1;
						strcat(*OutputStr,"Please find List of Mandatory Attributes,*Part Category*.");
					}
				}
	}
	}
	return IsValidFlag;
}
		/******************************************************* Added by Aashish_w End *******************************************************/

int SiteViseProjectValidationCheck(char *sProjectCode,char *FrstBarrel,char **OutputStr)
{
	int 	index				=	0;
	char *  SiteName			=	NULL;
	char*	sUsrInfo			=	NULL;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	int     n_entry				=	1;
	char    *qry_sys_entry[1]	=	{"SYSCD"};
	char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
	int		IntCntlObj			=	0;
	int		IsValidFlag			=	0;
	tag_t   *CntrlObject_Tag    =	NULLTAG;

	*OutputStr=(char *) MEM_alloc(250);

	strcpy(*OutputStr,"");
	printf("\n Inside save_method_4:SiteViseProjectValidationCheck: [%s]\n",FrstBarrel);fflush(stdout);

 	if(QRY_find("ControlObjects", &Cntl_obj_Qtag));
	if (Cntl_obj_Qtag)
	{
		printf("\n save_method_4:SiteViseProjectValidationCheck::Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n save_method_4:SiteViseProjectValidationCheck::Not Found Query ControlObjects \n");fflush(stdout);
	}

	if(PREF_ask_char_value("tm_TC_site_name",index,&SiteName)!=ITK_ok);PrintErrorStack();
	printf("\n SiteViseProjectValidationCheck SiteName :%s\n",SiteName);fflush(stdout); //MBOM implementation for CV TZ-1.69

	if(strcmp(SiteName,"cmitest")==0) // if uaprod then not allow to create 9001/9002.... 9020
	{
		qry_sys_values[0] = "cmitest_Proj" ;
		if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
		printf(" \n save_method_4:SiteViseProjectValidationCheck:SiteName:[%s]:IntCntlObj:[%d]",SiteName,IntCntlObj); fflush(stdout);
		if(IntCntlObj>0)
		{
			if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo1",&sUsrInfo)!=ITK_ok);PrintErrorStack();
			// if project found in info1 then allow tmetc user only to create part.
			printf(" \n save_method_4:SiteViseProjectValidationCheck:sUsrInfo:[%s]:sProjectCode:[%s]",sUsrInfo,sProjectCode); fflush(stdout);
			if(strstr(sUsrInfo,sProjectCode)!=NULL) // if(tc_strstr(sUserInfoVal, sDesGrp) != NULL)
			{
				IsValidFlag =0;
				printf(" \n Selected project code is allowed to create at tmetc site only."); fflush(stdout);
				//strcat(*OutputStr,"Selected project code is allowed to create at tmetc site only.");
				// check starting 4 digits are from list i.e. 9001/9002/9003 etc
				if(strstr(sUsrInfo,FrstBarrel)!=NULL)
				{
					IsValidFlag =0;
					printf(" \n inside if."); fflush(stdout);
				}
				else
				{
					printf(" \n inside else."); fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"First Barrel code [First 4 digit] of TC Part is invalid.");
					strcat(*OutputStr,"Valid digits are ");
					strcat(*OutputStr,sUsrInfo);
					strcat(*OutputStr," only.");
				}
			}
			else
			{
				IsValidFlag =1;
				printf(" \n Selected project code is not allowed to create at tmetc site only."); fflush(stdout);
				strcat(*OutputStr,"Selected Project code ");
				strcat(*OutputStr,sProjectCode);
				strcat(*OutputStr," is not allowed to create at tmetc site.");

			}
		}
	}
	else if(strcmp(SiteName,"TMETC")==0)
	{
		qry_sys_values[0] = "TMETC_Proj" ;
		if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
		printf(" \n save_method_4:SiteViseProjectValidationCheck:SiteName:[%s]:IntCntlObj:[%d]",SiteName,IntCntlObj); fflush(stdout);
		if(IntCntlObj>0)
		{
			if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo1",&sUsrInfo)!=ITK_ok);PrintErrorStack();
			// if project found in info1 then allow tmetc user only to create part.
			printf(" \n save_method_4:SiteViseProjectValidationCheck:sUsrInfo:[%s]:sProjectCode:[%s]",sUsrInfo,sProjectCode); fflush(stdout);
			if(strstr(sUsrInfo,sProjectCode)!=NULL) // if(tc_strstr(sUserInfoVal, sDesGrp) != NULL)
			{
				IsValidFlag =0;
				printf(" \n Selected project code is allowed to create at tmetc site only."); fflush(stdout);
				//strcat(*OutputStr,"Selected project code is allowed to create at tmetc site only.");
				// check starting 4 digits are from list i.e. 9001/9002/9003 etc
				if(strstr(sUsrInfo,FrstBarrel)!=NULL)
				{
					IsValidFlag =0;
					printf(" \n inside if."); fflush(stdout);
				}
				else
				{
					printf(" \n inside else."); fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"First Barrel code [First 4 digit] of TC Part is invalid.");
					strcat(*OutputStr,"Valid digits are ");
					strcat(*OutputStr,sUsrInfo);
					strcat(*OutputStr," only.");
				}
			}
			else
			{
				IsValidFlag =1;
				printf(" \n Selected project code is not allowed to create at tmetc site only."); fflush(stdout);
				strcat(*OutputStr,"Selected Project code ");
				strcat(*OutputStr,sProjectCode);
				strcat(*OutputStr," is not allowed to create at tmetc site.");

			}
		}
	}
	else if(strcmp(SiteName,"Trilix")==0)
	{
		qry_sys_values[0] = "Trilix_Proj" ;
		if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
		printf(" \n save_method_4:SiteViseProjectValidationCheck:SiteName:[%s]:IntCntlObj:[%d]",SiteName,IntCntlObj); fflush(stdout);
		if(IntCntlObj>0)
		{
			if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo1",&sUsrInfo)!=ITK_ok);PrintErrorStack();
			// if project found in info1 then allow trilix user only to create part.
			printf(" \n save_method_4:SiteViseProjectValidationCheck:sUsrInfo:[%s]:sProjectCode:[%s]",sUsrInfo,sProjectCode); fflush(stdout);
			if(strstr(sUsrInfo,sProjectCode)!=NULL)
			{
				IsValidFlag =0;
				printf(" \n Selected project code is allowed to create at trilix site only."); fflush(stdout);
				//strcat(*OutputStr,"Selected project code is allowed to create at trilix site only.");

				// check starting 4 digits are from list i.e. 9011 etc
				if(strstr(sUsrInfo,FrstBarrel)!=NULL)
				{
					IsValidFlag =0;
					printf(" \n inside if."); fflush(stdout);
				}
				else
				{
					printf(" \n inside else."); fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"First Barrel code [First 4 digit] of TC Part is invalid.");
					strcat(*OutputStr,"Valid digits are ");
					strcat(*OutputStr,sUsrInfo);
					strcat(*OutputStr," only.");
				}
			}
			else
			{
				IsValidFlag =1;
				printf(" \n Selected project code is not allowed to create at trilix site only."); fflush(stdout);
				strcat(*OutputStr,"Selected Project code ");
				strcat(*OutputStr,sProjectCode);
				strcat(*OutputStr," is not allowed to create at trilix site.");
			}
		}

	}

	return IsValidFlag;
}
int BLFormula_Validate(tag_t ConfigCtx,char* child_bl_formula,char* othermodule_bl_formula)
{

	printf( "\n\t**********In BLFormula_Validate funtion now ***************");
	//Need to add custom strstr function

	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;

	if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
	if(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));
	printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

	if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
	printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);fflush(stdout);

	if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
	printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);fflush(stdout);


	char *qry_entriesOptFam[] = {"ID"};
	char **qry_valuesOptFam = (char **) MEM_alloc(50 * sizeof(char *));
	tag_t Optfmly_tag = NULLTAG;
	tag_t queryTagOptFam = NULLTAG;
	tag_t *revOptFam=NULL;
	int resultCountOptFam=0,n_entriesOptFam=1,j=0;

	char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
	char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t OptfmlyVal_tag = NULLTAG;
	tag_t queryTagOptFamVal = NULLTAG;
	tag_t *revOptFamVal=NULL;
	int resultCountOptFamVal=0,n_entriesOptFamVal=2,i=0;
	char* OptValName=NULL;
	char* OptfmlyName=NULL;
	char* VariantFormulaStr=NULL;
	char* VariantFormulaStrOptionVal=NULL;
	VariantFormulaStr=(char *)MEM_alloc(300);
	VariantFormulaStrOptionVal=(char *)MEM_alloc(300);

	if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTagOptFam));
	printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
	if (queryTagOptFam)
	{
		printf("2.Found Query \n");fflush(stdout);
	}
	else
	{
		printf("Not Found Query");fflush(stdout);
	}
	 qry_valuesOptFam[0] = SmCrIDContext;
	if(QRY_execute(queryTagOptFam, n_entriesOptFam, qry_entriesOptFam, qry_valuesOptFam, &resultCountOptFam, &revOptFam));
	printf(" \n resultCountOptFam : %d\n", resultCountOptFam); fflush(stdout);

	for (j=0;j<resultCountOptFam;j++ )
	{
		printf( "\n\t****************In option family loop now *************");

		int Flag_child_bl_Found=0;
		int Flag_other_bl_Found=0;
		Optfmly_tag = revOptFam[j];
		ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName));
		printf("\n\t OptfmlyName Object String Type is :%s",OptfmlyName);	fflush(stdout);
		tc_strcpy(VariantFormulaStr,"");
		if (tc_strstr(OptfmlyName," ")!=NULL)
		{
			tc_strcat(VariantFormulaStr,"'");
			tc_strcat(VariantFormulaStr,OptfmlyName);
			tc_strcat(VariantFormulaStr,"'");
		}
		else
		{
			tc_strcat(VariantFormulaStr,OptfmlyName);
		}
		tc_strcat(VariantFormulaStr," = ");
		printf("\n\t VariantFormulaStr is :<%s>",VariantFormulaStr);	fflush(stdout);



		if(QRY_find("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTagOptFamVal));
		printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
		if (queryTagOptFamVal)
		{
			printf("Found Query __Cfg0OptionValuesFromOptionFamilyIDs \n");fflush(stdout);
		}
		else
		{
			printf("Not Found Query __Cfg0OptionValuesFromOptionFamilyIDs ");fflush(stdout);
		}
		qry_valuesOptFamVal[0]= OptfmlyName;
		qry_valuesOptFamVal[1]= SmCrIDContext;
		if(QRY_execute(queryTagOptFamVal, n_entriesOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &resultCountOptFamVal, &revOptFamVal));
		for (i=0;i<resultCountOptFamVal;i++ )
		{
			printf("\n\t***************** In option value loop now *******************");

			OptfmlyVal_tag = revOptFamVal[i];
			ITK_CALL(AOM_ask_value_string(OptfmlyVal_tag,"object_name",&OptValName));
			printf("\n\t Value Object String  is :%s",OptValName);	fflush(stdout);

			tc_strcpy(VariantFormulaStrOptionVal,"");
			tc_strcat(VariantFormulaStrOptionVal,VariantFormulaStr);

			if (tc_strstr(OptValName," ")!=NULL)
			{
				tc_strcat(VariantFormulaStrOptionVal,"'");
				tc_strcat(VariantFormulaStrOptionVal,OptValName);
				tc_strcat(VariantFormulaStrOptionVal,"'");
			}
			else
			{
				tc_strcat(VariantFormulaStrOptionVal,OptValName);
			}

			printf("\n\t Final VariantFormulaStr is :<%s> \n",VariantFormulaStrOptionVal);	fflush(stdout);

			//Custom strstr added to fix duplicate VF save issue
			//if (tc_strstr(child_bl_formula,VariantFormulaStrOptionVal)!=NULL)
			if (customStrStr(child_bl_formula, VariantFormulaStrOptionVal) > 0)
			{
				printf("\n\t child_bl_formula =[%s] &&  VariantFormulaStrOptionVal = [%s] \n",child_bl_formula,VariantFormulaStrOptionVal);

				printf("\n\t Matched for VariantFormulaStr is :<%s> \n",VariantFormulaStrOptionVal);	fflush(stdout);
				Flag_child_bl_Found++;


				//if (tc_strstr(othermodule_bl_formula,VariantFormulaStrOptionVal)!=NULL)
				if (customStrStr(othermodule_bl_formula, VariantFormulaStrOptionVal) > 0)
				{
						printf("\n\t othermodule_bl_formula =[%s] &&  VariantFormulaStrOptionVal = [%s] \n",othermodule_bl_formula,VariantFormulaStrOptionVal);
						Flag_other_bl_Found++;
				}

			}
			else
			{

			}

		}/// end of option value loop
		printf("\n\t Value for <%s> Match %d other match %d \n",OptfmlyName,Flag_child_bl_Found,Flag_other_bl_Found);	fflush(stdout);

		if (Flag_child_bl_Found > 0 && Flag_other_bl_Found==0)
		{
			return 1;
		}

	}/// end of option family loop

	return 0;
}
//Custom strstr Added by Kirtikumar
int customStrStr(char* strEdited, char* strDefault) {

	printf("\n **************Inside customStrStr function********************");
	printf("\n bl_formula -: %s", strEdited);
	printf("\n VariantFormulaStrOptionVal -: %s", strDefault);
	printf("\n\n\n");
	char* tmpEdited = strEdited;
	char* tmpDefault = strDefault;
	int isFullTraversed = 0;
	int matchCnt = 0;
	int partialMatchCnt = 0;
	int exactMatchCnt = 0;
	while(*tmpEdited != '\0') {
		if(*tmpEdited == *tmpDefault) {
			isFullTraversed = 1;
			while(*tmpDefault != '\0') {
				if(*tmpEdited == *tmpDefault) {
					//printf("\n %c", *tmpEdited);
				} else {
					//printf("\n Not matched successive chars");
					isFullTraversed = 0;
					tmpDefault = strDefault;
					break;
				}
				tmpEdited ++;
				tmpDefault ++;
			}
			if(isFullTraversed) {
				if(((*tmpEdited == ' ') && (*(tmpEdited+1) == '|' || *(tmpEdited+1) == '&')) || (*tmpEdited == ')')){
					exactMatchCnt ++;
				} else {
					partialMatchCnt ++;
				}
				tmpDefault = strDefault;
				matchCnt ++;
			}
		}
		tmpEdited ++;
	}
	printf("\n matchCnt -: %d", matchCnt);
	printf("\n partialMatchCnt -: %d", partialMatchCnt);
	printf("\n exactMatchCnt -: %d\n", exactMatchCnt);

	return exactMatchCnt;
}
//Prachi - Added function to validate Variant Formula
extern DLLAPI int  check_vf_module(METHOD_message_t *msg, va_list args)
{
 	char *child_rev_id = NULL;
 	char *child_rev_seq = NULL;
	char *child_rev_stat = NULL;
	char *child_objType = NULL;
	char *mod_addr = NULL;
 	int			revid			= 0;
 	int			revseq			= 0;
 	int			revstat			= 0;
 	int			blobjType		= 0;
	int			PartTypeI		= 0;
 	int			PartTypeCI		= 0;
 	int			modadd			= 0;
	int	ifail = 0;
	char *username;
	char *group_name;
	char *userid;
	tag_t user_tag=NULLTAG;
	tag_t group_tag=NULLTAG;
	char *designer_role = NULL;
	char *manager_role = NULL;
	int designer_found=0,manager_found=0;
	tag_t * 	list;
	tag_t window=NULLTAG;
	tag_t top_bom_line=NULLTAG;
	//ass915906
	int     fndidlatest			=0;
	char   *child_fndid_latest	= NULL;
	int		Variantflag			= 0;
 	int		Variantflag1		= 0;
	char *child_PartType = NULL;
	char *child_ColorIndicator = NULL;

	tag_t	qry_t1	= NULLTAG;
	tag_t	Module	= NULLTAG;
	tag_t	ModuleIDRev	= NULLTAG;
	char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
	int n_entr1 = 1;
	char    *qry_entr1[1]  = {"SYSCD"};
	int rsltCunt1=0;
	tag_t *CntrlObjTag1=NULLTAG;
	char	*info1r	= NULL;
	char	*ModuleGroup_Name	= NULL;
	//ass915906

	tag_t bomline = msg->object_tag;

	tag_t BL_targ=va_arg(args, tag_t);
	char * BL_FormulaEdited=va_arg(args, char *);
	printf("\n!!!!!!!!!!!!!!!!! check_vf_module!!!!!!!!!!  <<<%s>>>\t\n",BL_FormulaEdited);fflush(stdout);
	POM_ask_group(&group_name, &group_tag);
	printf ("Logged in group:%s\n",group_name);fflush(stdout);
	if(bomline != NULLTAG)
	{
 		printf("\n Validate VF\n");fflush(stdout);
 		if(BOM_line_look_up_attribute("bl_item_item_id",&revid))PrintErrorStack();
 		if(BOM_line_look_up_attribute("bl_rev_item_revision_id",&revseq))PrintErrorStack();
		if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat))PrintErrorStack();
		if(BOM_line_look_up_attribute ("bl_item_object_type",&blobjType))PrintErrorStack();
		if(BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&PartTypeI))PrintErrorStack();
		if(BOM_line_look_up_attribute ("bl_Design Revision_t5_ColourInd",&PartTypeCI))PrintErrorStack();
		if(BOM_line_ask_attribute_string(bomline,revid,&child_rev_id))PrintErrorStack();
		if(BOM_line_ask_attribute_string(bomline,revseq,&child_rev_seq))PrintErrorStack();
		if(BOM_line_ask_attribute_string(bomline, revstat, &child_rev_stat))PrintErrorStack();
		if(BOM_line_ask_attribute_string(bomline, blobjType, &child_objType))PrintErrorStack();
		if(BOM_line_ask_attribute_string(bomline, PartTypeI, &child_PartType))PrintErrorStack();
		if(BOM_line_ask_attribute_string(bomline, PartTypeCI, &child_ColorIndicator))PrintErrorStack();

		if(BOM_line_ask_attribute_string(bomline, PartTypeCI, &child_ColorIndicator))PrintErrorStack();
		printf("\n Part:%s %s Status:%s  child_objType <%s> \n",child_rev_id,child_rev_seq,child_rev_stat,child_objType);fflush(stdout);

		 ITEM_find_item(child_rev_id,&Module);
		 ITEM_ask_latest_rev(Module,&ModuleIDRev);
		 AOM_UIF_ask_value(ModuleIDRev,"owning_group",&ModuleGroup_Name);


		//ass915906
		/*bl_config = 0;
		if( BOM_line_look_up_attribute ("bl_rev_fnd0DSState",&bl_config));
		printf(" bl_config= [%d]\n", bl_config);

		if(BOM_line_ask_attribute_logical(bomline, bl_config, &bl_config_log));
		printf("bl_config_log= [%d]\n",bl_config_log);*/

		if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
		if(BOM_line_ask_attribute_string(bomline,fndidlatest,&child_fndid_latest));
		printf("\n child_fndid_latest===============>>>>>> %s\n",child_fndid_latest);fflush(stdout);
		//ass915906

		if (tc_strcmp(child_objType,"Colour Part")!=0)
		{


		if(BOM_line_ask_window(bomline,&window))PrintErrorStack();
		if(window != NULLTAG)
		{
			  if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
			  if(top_bom_line != NULLTAG)
			  {
				  if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType))PrintErrorStack();
				  if(BOM_line_ask_attribute_string(top_bom_line, blobjType, &child_objType))PrintErrorStack();
				  if (tc_strcmp(child_objType,"T5_PlatformRevision")==0)
				  {
			    	POM_get_user(&username,&user_tag);
					SA_ask_user_identifier2	(user_tag,&userid)	;
					printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);

					char *SupportUsername9 = NULL;
					tag_t SessionUser9_tag=NULLTAG;
					int     SupportFlag      =  0;

					SupportFlag=0;
					POM_get_user(&SupportUsername9,&SessionUser9_tag);
					if(SessionUser9_tag!=NULLTAG)
					{
						SupportFlag=0;
						SupportFlag = CheckSupportLogin(SessionUser9_tag);
						printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
					}
					//if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0)
					if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
					{
						printf("\n Variant formula with X4 Context Not Allowed \n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated at platform level","Send architecture node separately to Structure Manager to edit variant formula of the module");
						return ITK_errStore;
					}
				  }
			  }
		}
		//ass915906
		if(QRY_find("ControlObjects", &qry_t1));
		if (qry_t1)
		{
			printf("\n ControlObjects:.Found Query ControlObjects in UVF\n");fflush(stdout);
		}
		else
		{
			printf("\n ControlObjects:.Not Found Query ControlObjects in UVF\n");fflush(stdout);
		}

		qry_val3[0] = "UVFCROBJ";
		if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &CntrlObjTag1));
		printf(" \n UVFCROBJ:rsltCunt1:::: in UVF>>> :%d:", rsltCunt1); fflush(stdout);
		if(rsltCunt1>0)
		{
			if (AOM_ask_value_string(CntrlObjTag1[0],"t5_Userinfo1",&info1r)!=ITK_ok)   PrintErrorStack();
			printf("  UVF info1r is = [%s]\n", info1r);fflush(stdout);

			if (tc_strcmp(info1r,"ON")==0)
			{
				printf ("Inside control OBJ ON\n");fflush(stdout);
				POM_get_user(&username,&user_tag);
				SA_ask_user_identifier2	(user_tag,&userid)	;
				printf ("Logged in user Inside control OBJ ON-->:%s %s\n",userid,username);fflush(stdout);

				if((tc_strstr(child_rev_stat,"Release") != NULL))
				{
					printf ("\n 1111 Allowed to updte as child_rev_stat:- ERC Release & child_rev_seq:- not NR \n");fflush(stdout);
					//allowed if child_fndid_latest value is "False"
					if	(tc_strcmp(child_fndid_latest,"False")==0)
					{
						Variantflag++;
					}
					else if  ( ((tc_strstr(group_name,"APL") != NULL)&&(tc_strstr(ModuleGroup_Name,"APL") != NULL)) || ((tc_strstr(group_name,"MBOM") != NULL)) )  //MBOM implementation for CV TZ-1.69
					{

						printf ("for APL Create Module VF is allowed to update by APL user \n");fflush(stdout);

					}
					else
					{
						char *SupportUsername9 = NULL;
						tag_t SessionUser9_tag=NULLTAG;
						int     SupportFlag      =  0;

						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);
						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin(SessionUser9_tag);
							printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
						}
						//if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"infodba") !=0) && (tc_strcmp(userid,"loader") !=0) && (tc_strcmp(userid,"ercpsup") !=0))
						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "Master_Data_Mgmt") != 0))
						{
						printf("\n Inside child_fndid_latest::Flag 111111::>>> True \n"); fflush(stdout);
						EMH_clear_errors();
						//EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated as module is already in update Variant formula workflow for updatation",child_rev_id);
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated as module is already released, please take variant formula update DML to update variant formula.",child_rev_id);
						return ITK_errStore;
						}
					}
				}

				else if(((tc_strcmp(child_rev_stat,"ERC Review") == 0) || (tc_strstr(child_rev_stat,"Working") != NULL)) && (tc_strstr(child_rev_seq,"NR") == NULL))
				{
					printf ("\n 2222 NOT Allowed to updte Variant Formula as child_rev_stat:- ERC Review/ERC Working & child_rev_seq:- is not NR \n");fflush(stdout);
					Variantflag1++;
				}

				else if(((tc_strcmp(child_rev_stat,"ERC Review") == 0) || (tc_strstr(child_rev_stat,"Working") != NULL)) && (tc_strstr(child_rev_seq,"NR") != NULL))
				{
					printf ("\n 3333 Allowed to updte child_rev_stat:- ERC Reviev/ERC Working & child_rev_seq:-NR \n");fflush(stdout);
					Variantflag++;

				}

//				else if((tc_strstr(child_rev_stat,"Release") != NULL) && (tc_strstr(child_rev_seq,"NR") == NULL))
//				{
//					printf ("\n 2222 Allowed to updte as child_rev_stat:- ERC Release & child_rev_seq:- not NR \n");fflush(stdout);
//					//allowed if child_fndid_latest value is "False"
//					if	(tc_strcmp(child_fndid_latest,"False")==0)
//					{
//						Variantflag++;
//					}
//					else
//					{
//						if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"infodba") !=0) && (tc_strcmp(userid,"loader") !=0) && (tc_strcmp(userid,"ercpsup") !=0))
//						{
//						printf("\n Inside child_fndid_latest::Flag 111111::>>> True \n"); fflush(stdout);
//						EMH_clear_errors();
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated as module is already in update Variant formula workflow for updatation",child_rev_id);
//						return ITK_errStore;
//						}
//					}
//				}
			}
			else
			{
				if(tc_strstr(child_rev_stat,"Release") != NULL)
				{
					POM_get_user(&username,&user_tag);
					SA_ask_user_identifier2	(user_tag,&userid)	;
					printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);

					char *SupportUsername9 = NULL;
					tag_t SessionUser9_tag=NULLTAG;
					int     SupportFlag      =  0;

					SupportFlag=0;
					POM_get_user(&SupportUsername9,&SessionUser9_tag);
					if(SessionUser9_tag!=NULLTAG)
					{
						SupportFlag=0;
						SupportFlag = CheckSupportLogin(SessionUser9_tag);
						printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
					}
					//if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"ercpsup")!=0))
					if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "Master_Data_Mgmt") != 0))
					{
						printf("\n Released Part, Variant Formula change is not allowed:%s %s\n",child_rev_id,child_rev_seq);fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s3(EMH_severity_error,ITK_err,"\nVariant formula can't be updated for released part","Part or Module is already released ",child_rev_id);
						return ITK_errStore;
					}
				}
				else //review or working
				{
					Variantflag++;
				}
			}
		}
	//ass915906
		//if(tc_strstr(child_rev_stat,"Release") != NULL)
		if (Variantflag1>0)
		{
			POM_get_user(&username,&user_tag);
			SA_ask_user_identifier2	(user_tag,&userid)	;
 			printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
			char *SupportUsername9 = NULL;
			tag_t SessionUser9_tag=NULLTAG;
			int     SupportFlag      =  0;

			SupportFlag=0;
			POM_get_user(&SupportUsername9,&SessionUser9_tag);
			if(SessionUser9_tag!=NULLTAG)
			{
				SupportFlag=0;
				SupportFlag = CheckSupportLogin(SessionUser9_tag);
				printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
			}
 			//if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"infodba")!=0) && (tc_strcmp(userid,"ercpsup")!=0))
 			if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "Master_Data_Mgmt") != 0) && ((tc_strstr(ModuleGroup_Name,"APL") == NULL) || (tc_strstr(ModuleGroup_Name,"MBOM") == NULL))) //MBOM implementation for CV TZ-1.69
			{
				printf("\n Released Part, Variant Formula change is not allowed:%s %s\n",child_rev_id,child_rev_seq);fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s3(EMH_severity_error,ITK_err,"\nVariant formula updation is allowed if Module Revision =NR and Release Status =ERC Review","For Revision other than NR kindly take Update variant formula type DML",child_rev_id);
				return ITK_errStore;
			}
		}

		if (Variantflag>0)
		{
			POM_get_user(&username,&user_tag);
			SA_ask_user_identifier2	(user_tag,&userid)	;
 			printf ("Logged in user:%s\n",userid);fflush(stdout);

			if((tc_strcmp(group_name,"Master_Data_Mgmt")!=0)) //&& (tc_strcmp(userid,"infodba")!=0)
			{
					if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd))PrintErrorStack();
					if(modadd > 0)
					{
						if(BOM_line_ask_attribute_string(bomline, modadd, &mod_addr))PrintErrorStack();
						printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
						if(mod_addr != NULL && strlen(mod_addr) > 0)
						{

							designer_role = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Designers")) * sizeof(char));
							strcpy(designer_role,mod_addr);
							strcat(designer_role,"_Designers");
							manager_role  = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Managers")) * sizeof(char));
							strcpy(manager_role,mod_addr);
							strcat(manager_role,"_Managers");
							printf("\nsearch for role:%s OR %s\n",designer_role,manager_role);fflush(stdout);

							if(SA_find_groupmember_by_rolename(designer_role,"ERC_Designers_Group",userid,&designer_found,&list))PrintErrorStack();
							if(SA_find_groupmember_by_rolename(manager_role,"ERC_Designers_Group",userid,&manager_found,&list))PrintErrorStack();
							printf("\n designer_found:%d manager_found:%d\n",designer_found,manager_found); fflush(stdout);
							if(designer_found == 0 && manager_found == 0 && ( (tc_strstr(ModuleGroup_Name,"APL") == NULL) || (tc_strstr(ModuleGroup_Name,"MBOM") ))) //MBOM implementation for CV TZ-1.69
							{
								EMH_clear_errors();
								EMH_store_error_s3(EMH_severity_error,ITK_err,"\nYou don't have access to update variant formula for this module","Contact PLM Admin to get access",userid);
								return ITK_errStore;
							}

						}
						else
						{
								EMH_clear_errors();
								EMH_store_error_s3(EMH_severity_error,ITK_err,"\nModule Address is blank for this module","Contact PLM Team to update Module Address",userid);
								return ITK_errStore;

						}
					}
					else
					{
								EMH_clear_errors();
								EMH_store_error_s3(EMH_severity_error,ITK_err,"\nModule Address not found for this module","Contact PLM Team to update Module Address",userid);
								return ITK_errStore;
					}
			}
		}



					/////////Module Variant Formula  Validation////////

		int parent_item_seq=0;
		tag_t itemrev =NULLTAG;
		char* Trgt_bl_formula=NULL;
		char*  Part_no =NULL;
		int n_parents=0;
		int *levels = 0;
		tag_t *parents = NULL;
		int jd=0;
		tag_t ArchAssyTag =NULLTAG;
		char* Arch_obj= NULL;
		tag_t ArchobjTypeTag=NULLTAG;
		char   Archtype_name[TCTYPE_name_size_c+1];
		tag_t window=NULLTAG;
		tag_t  rule=NULLTAG;
		tag_t top_line =NULLTAG;
		int n_BL=0;
		tag_t *children1= NULL;
		int p1=0;
		tag_t Childobject=NULLTAG;
		char* child_item_id = NULL;
		char* chidl_moduleAddress =NULL;
		char* child_bl_formula_cmp = NULL;
		char* child_bl_formula = NULL;
		tag_t  	master =	NULLTAG;
		char*  Arch_obj_str = NULL;
		tag_t relation_dep=	NULLTAG;
		int countConfigCtx = 0;
		tag_t  *ConfigCtxSecObject	= NULLTAG;
		tag_t ConfigCtx = NULLTAG;
		tag_t  ConfigCtxObjTypeTag=NULLTAG;
		char   Config_CtxType[TCTYPE_name_size_c+1];
		char*	 SmVCContext			= NULL;
		char*	 SmCrIDContext			= NULL;
		char*	 ContextobjName			= NULL;

		tag_t	qry_t1	= NULLTAG;
		char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
		int n_entr1 = 1;
		char    *qry_entr1[1]  = {"SYSCD"};
		int rsltCunt1=0;
		tag_t *CntrlObjTag1=NULLTAG;

		tag_t	queryTag	= NULLTAG;
		char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
		int n_entries = 1;
		int resultCount=0;
		char *qry_entries[1] = {"ID"};

		tag_t *ConId  = NULL;
		int j=0;
		tag_t Optfmly_tag = NULLTAG;

		int dmlIncnt =0;
		int CmpleteVrf=0;
		char *username_vf =NULL;
		tag_t user_tag_vf =NULLTAG;

		//PV CV Changes:: 18-04-2023
		tag_t	qry_cv_bypass	= NULLTAG;
		char **qry_cv_bypass_val = (char **) MEM_alloc(35 * sizeof(char *));
		int n_entr_cv_bypass = 1;
		char    *qry_entr_cv_bypass[1]  = {"SYSCD"};
		int rsltCunt_cv_bypass=0;
		tag_t *CntrlObjTag_cv_bypass=NULLTAG;
		logical isCVProd =false;
		int iqo = 0;

		char* useInfo1 =NULL;
		char* useInfo2 =NULL;
		char* useInfo3 =NULL;
		char* useInfo4 =NULL;
		char* useInfo5 =NULL;
		char* useInfo6 =NULL;
		char* useInfo7 =NULL;
		char* useInfo8 =NULL;
		char* useInfo9 =NULL;
		char* useInfo10 =NULL;

		char *modAddressFinalStr		=NULL;

		POM_get_user(&username_vf,&user_tag_vf);
		printf ("Logged in user in VF validation function : %s\n",username_vf);fflush(stdout);

		if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq))PrintErrorStack();
		if(BOM_line_ask_attribute_tag(bomline, parent_item_seq, &itemrev))PrintErrorStack();

		//if(AOM_ask_value_string(bomline, "bl_formula", &Trgt_bl_formula ))PrintErrorStack();
		//printf("\n\t child_bl_formula--------------> %s\n",Trgt_bl_formula); fflush(stdout);

		if(AOM_ask_value_string(itemrev,"item_id",&Part_no))PrintErrorStack();
		printf("\n\n\t CP Part_no  is :%s",Part_no);fflush(stdout);

		if(PS_where_used_all(itemrev,1,&n_parents,&levels,&parents))PrintErrorStack();
		printf("\n\t CP where_used count of objects are Drag Drop : %d",n_parents); fflush(stdout); // 1

		if(top_bom_line != NULLTAG)
		{
			if(BOM_line_ask_attribute_tag(top_bom_line, parent_item_seq, &ArchAssyTag))PrintErrorStack();
			printf("\n\t Inside top bomline"); fflush(stdout);



		  if(ArchAssyTag)
		  {

			//ArchAssyTag=parents[jd];
			if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))PrintErrorStack();
			printf("\n\t Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

			if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))PrintErrorStack();
			if(TCTYPE_ask_name(ArchobjTypeTag,Archtype_name))PrintErrorStack();
			printf("\n\t Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

			if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
			{
				 printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);

				  if(ITEM_ask_item_of_rev(ArchAssyTag, &master));
				 if(AOM_ask_value_string(master,"item_id",&Arch_obj_str))PrintErrorStack();
				 printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

				 if(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep))PrintErrorStack();
				 if(relation_dep != NULLTAG)
				 {
				 	printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
				 }

				 if(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject))PrintErrorStack();
				 printf("\n\t Configuration Context count is : %d",countConfigCtx);


				if(countConfigCtx>0)
				{
					ConfigCtx=ConfigCtxSecObject[0];
					if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
					if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
					if(top_line!=NULLTAG)
					{
						if(BOM_line_ask_child_lines(top_line, &n_BL, &children1))PrintErrorStack();
						printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
						if (n_BL >0)
						{


							if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag))PrintErrorStack();
							if(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType))PrintErrorStack();
							printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

							if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext))PrintErrorStack();
							printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

							if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext))PrintErrorStack();
							printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

							if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag))PrintErrorStack();
							printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
							if (queryTag)
							{
								printf("\n\tFound Query");fflush(stdout);
							}else
							{
								printf("\n\tNot Found Query");fflush(stdout);
							}

							qry_values[0] = SmCrIDContext;

							if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ConId))PrintErrorStack();
							printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);


							if(tc_strcmp(BL_FormulaEdited,"")==0 && resultCount >0)
							{
								printf("\n CC available Variant formula not available \n"); fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",Part_no);
								return ITK_errStore;
							}
							else
							{
							  for (j=0;j<resultCount;j++ )
							  {
								 Optfmly_tag = ConId[j];
								 if(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName))PrintErrorStack();
								 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family

								 if(ContextobjName)
								 {
									printf("\n\t child_bl_formula value:%s",BL_FormulaEdited);
									printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(BL_FormulaEdited,ContextobjName)); fflush(stdout);

									if(tc_strstr(BL_FormulaEdited,ContextobjName)==NULL)
									{
										printf("\n inside iff \n"); fflush(stdout);
										dmlIncnt++;
									}
									else
									 {
										printf("\n inside else \n"); fflush(stdout);
										CmpleteVrf++;
									 }
								 }
							  }

							  printf("\n dmlIncnt value is at end for loop :%d\n",dmlIncnt); fflush(stdout);
							  if (dmlIncnt>0)
							  {
								  // Validation is baypass for loader
								  if((tc_strcmp(username_vf,"loader")!=0))
								  {
									    printf("\n dmlIncnt greator than 1 :%d\n",dmlIncnt); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,ITK_err, "Variant formula is not complete for Module",Part_no);
										return ITK_errStore;
								  }
								  else
								  {

								  }

							  }

							}
							//PV CV Changes::
							if(QRY_find("ControlObjects", &qry_cv_bypass));
							if (qry_cv_bypass)
							{
								printf("\n ControlObjects:.Found Query qry_cv_bypass \n");fflush(stdout);
							}
							else
							{
								printf("\n ControlObjects:.Not Found Query qry_cv_bypass \n");fflush(stdout);
							}

							qry_cv_bypass_val[0] = "CV_ValidationByPassWithModuleAdd";
							if(QRY_execute(qry_cv_bypass, n_entr_cv_bypass, qry_entr_cv_bypass, qry_cv_bypass_val, &rsltCunt_cv_bypass, &CntrlObjTag_cv_bypass));
							printf(" \n CV_ValidationByPassWithModuleAdd::::>>> :%d:", rsltCunt_cv_bypass); fflush(stdout);
							if(rsltCunt_cv_bypass>0)
							{
								isCVProd =true;
							}

							modAddressFinalStr = (char *) MEM_alloc(5000 * sizeof(char *));

							for(iqo =0 ;iqo < rsltCunt_cv_bypass ;iqo++)
							{
										printf("\n\t Value of iqo :: is [%d]",iqo);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo1",&useInfo1));
										printf("\n\t useInfo1 string value: %s",useInfo1);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo2",&useInfo2));
										printf("\n\t useInfo2 string value: %s",useInfo2);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo3",&useInfo3));
										printf("\n\t useInfo3 string value: %s",useInfo3);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo4",&useInfo4));
										printf("\n\t useInfo4 string value: %s",useInfo4);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo5",&useInfo5));
										printf("\n\t useInfo5 string value: %s",useInfo5);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo6",&useInfo6));
										printf("\n\t useInfo6 string value: %s",useInfo6);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo7",&useInfo7));
										printf("\n\t useInfo7 string value: %s",useInfo7);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo8",&useInfo8));
										printf("\n\t useInfo8 string value: %s",useInfo8);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo9",&useInfo9));
										printf("\n\t useInfo9 string value: %s",useInfo9);

										ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_userinfo10",&useInfo10));
										printf("\n\t useInfo10 string value: %s",useInfo10);

										if(useInfo1 == NULL)
										{
											tc_strcat(useInfo1,"");
										}
										if(useInfo2 == NULL)
										{
											tc_strcat(useInfo2,"");
										}
										if(useInfo3 == NULL)
										{
											tc_strcat(useInfo3,"");
										}
										if(useInfo4 == NULL)
										{
											tc_strcat(useInfo4,"");
										}
										if(useInfo5 == NULL)
										{
											tc_strcat(useInfo5,"");
										}
										if(useInfo6 == NULL)
										{
											tc_strcat(useInfo6,"");
										}
										if(useInfo7 == NULL)
										{
											tc_strcat(useInfo7,"");
										}
										if(useInfo8 == NULL)
										{
											tc_strcat(useInfo8,"");
										}
										if(useInfo9 == NULL)
										{
											tc_strcat(useInfo9,"");
										}
										if(useInfo10 == NULL)
										{
											tc_strcat(useInfo10,"");
										}

										if(modAddressFinalStr == NULL)
										{
											tc_strcpy(modAddressFinalStr,"");
											tc_strcat(modAddressFinalStr,useInfo1);
											tc_strcat(modAddressFinalStr,useInfo2);
											tc_strcat(modAddressFinalStr,useInfo3);
											tc_strcat(modAddressFinalStr,useInfo4);
											tc_strcat(modAddressFinalStr,useInfo5);
											tc_strcat(modAddressFinalStr,useInfo6);
											tc_strcat(modAddressFinalStr,useInfo7);
											tc_strcat(modAddressFinalStr,useInfo8);
											tc_strcat(modAddressFinalStr,useInfo9);
											tc_strcat(modAddressFinalStr,useInfo10);
										}
										else
										{
											tc_strcat(modAddressFinalStr,useInfo1);
											tc_strcat(modAddressFinalStr,useInfo2);
											tc_strcat(modAddressFinalStr,useInfo3);
											tc_strcat(modAddressFinalStr,useInfo4);
											tc_strcat(modAddressFinalStr,useInfo5);
											tc_strcat(modAddressFinalStr,useInfo6);
											tc_strcat(modAddressFinalStr,useInfo7);
											tc_strcat(modAddressFinalStr,useInfo8);
											tc_strcat(modAddressFinalStr,useInfo9);
											tc_strcat(modAddressFinalStr,useInfo10);
										}
							}

							printf("\n\t modAddressFinalStr string value After concat: %s\n \n",modAddressFinalStr);

							for (p1=0;p1<n_BL ;p1++ )
							{
								int Result=1;
								if(Childobject) Childobject=NULLTAG;
								Childobject=children1[p1];
								if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ))PrintErrorStack();
								printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

								if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ModuleAddress", &chidl_moduleAddress ))PrintErrorStack();
								printf("\n\t Revision_t5_ModuleAddress ===> :: %s",chidl_moduleAddress); fflush(stdout);

								if(isCVProd==false || (isCVProd && tc_strstr(modAddressFinalStr,chidl_moduleAddress)==0))
								{
										if(tc_strcmp(Part_no,child_item_id))
										{

											if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula_cmp ))PrintErrorStack();
											printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula_cmp); fflush(stdout);

											if (tc_strcmp(child_bl_formula_cmp,BL_FormulaEdited)==0)
											{
												printf("\nDuplicate Variant Formula found,change is not allowed:%s %s\n",Part_no,child_item_id);fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s4(EMH_severity_error,ITK_err,"\nDuplicate Variant formula  found for ",Part_no,"  and ",child_item_id);
												return ITK_errStore;
											}

											/// checkin for OR condition

											if(QRY_find("ControlObjects", &qry_t1));
											if (qry_t1)
											{
												printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
											}
											else
											{
												printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
											}

											qry_val3[0] = "Modulewith_OR1";
											if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &CntrlObjTag1));
											printf(" \n ModulewithOR:rsltCunt1::::>>> :%d:", rsltCunt1); fflush(stdout);
											if(rsltCunt1>0)
											{
												Result=BLFormula_Validate(ConfigCtx,BL_FormulaEdited,child_bl_formula_cmp);
												printf(" \n ModulewithOR:Result::::>>> :%d:", Result); fflush(stdout);
												if (Result==0)
												{
													EMH_store_error_s4(EMH_severity_error,ITK_err,"\nError :BLFormula_Validate: Duplicate Variant formula  found for ",Part_no,"  and ",child_item_id);
													return ITK_errStore;
												}
											}
									}
								}

							}
						}//
					}
				}
			}
		  }
		}


		//Added by Deepti in TZ1.54 for APLModule

		char *Part_no_rev =NULL;
		char *sFourFiveChar =NULL;
		char *ModuleErr =NULL;
		char *plantName =NULL;
		int control_number_found_mod=0;
		int FlagModFnd=0;
		int count_task=0;
		int cnt_tk=0;
		tag_t	*list_of_WSO_cntrlPrj_mod_tags	=	NULLTAG;
		char	**qry_valuesCntrlA= (char **) MEM_alloc(6 * sizeof(char *));
		tag_t   qryTagCntrl			=	NULLTAG;
		int     n_entryCntrl		=	4;
		char    *qry_entryCntrl[4]  = {"Name","SUBSYSCD","Delete Indicator","Information-1"};
		tag_t	  		relation_type_PrtToTsk	=	NULLTAG;
		tag_t*			PartTaskTags		= NULLTAG;
		tag_t	  		TaskTag_class	=	NULLTAG;
		char			Task_class[TCTYPE_name_size_c+1];
		char*			TaskId				=	NULL;
		char GetPlant[40];
		tag_t	  		PartTskTag			=	NULLTAG;


		if(AOM_ask_value_string(itemrev,"item_id",&Part_no))PrintErrorStack();
		printf("\n\n\t CP Part_no  is :%s",Part_no);fflush(stdout);

		if(AOM_ask_value_string(itemrev,"item_revision_id",&Part_no_rev))PrintErrorStack();
		printf("\n\n\t CP Part_no_rev  is :%s",Part_no_rev);fflush(stdout);

		sFourFiveChar	=	subString(Part_no,4,5);

		if(QRY_find("Control Objects...", &qryTagCntrl));

		if (qryTagCntrl!=NULLTAG)
		{

			qry_valuesCntrlA[0]	=	"BIW_APL_MODULE";
			qry_valuesCntrlA[1]	=	"APL";
			qry_valuesCntrlA[2]	=	"0";
			qry_valuesCntrlA[3]	=	sFourFiveChar;

			printf("\n sFourFiveChar: %s\n",sFourFiveChar);fflush(stdout);
			if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrlA, &control_number_found_mod, &list_of_WSO_cntrlPrj_mod_tags));
			printf("\n CompCodeAPLPrj=>control_number_found_mod is : %d\n",control_number_found_mod);fflush(stdout);
			if(control_number_found_mod>0)
			{
				FlagModFnd=1;
			}
			if(FlagModFnd==1)
			{

				 ITKCALL(AOM_ask_value_string(list_of_WSO_cntrlPrj_mod_tags[0], "t5_Userinfo2", &plantName));
				 printf("\n plantName: %s\n",plantName);fflush(stdout);

				GRM_find_relation_type("CMHasSolutionItem",&relation_type_PrtToTsk);
				GRM_list_primary_objects_only(itemrev,relation_type_PrtToTsk,&count_task,&PartTaskTags);

				printf("\n count_task: %d \n",count_task); fflush(stdout);

				if(count_task>0)
				{
					for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
					{
						PartTskTag=PartTaskTags[cnt_tk];
						ITKCALL (TCTYPE_ask_object_type(PartTskTag,&TaskTag_class));
						ITKCALL (TCTYPE_ask_name(TaskTag_class,Task_class));

						printf("\t  Task_class ...%s\n", Task_class); fflush(stdout);
						if(tc_strcmp(Task_class,"T5_APLTaskRevision")==0)
						{
							ITKCALL(AOM_ask_value_string(PartTskTag, "item_id",&TaskId));
							printf("\n TaskId %s.....\n",TaskId); fflush(stdout);

							GetPlantForDMLORTask(TaskId,GetPlant);

							printf("\n GetPlant %s.plantName %s ....\n",GetPlant,plantName); fflush(stdout);
							if(tc_strcmp(GetPlant,plantName)==0)
							{
								printf("\nInside error if DML alreadt attached"); fflush(stdout);
								ModuleErr	=	NULL;
								ModuleErr	=	(char *)MEM_alloc(200);
								tc_strcpy(ModuleErr,"");
								tc_strcat(ModuleErr,"Module ");
								tc_strcat(ModuleErr,Part_no);
								tc_strcat(ModuleErr,";");
								tc_strcat(ModuleErr,Part_no_rev);
								tc_strcat(ModuleErr," are attached to Task ");
								tc_strcat(ModuleErr,TaskId);
								tc_strcat(ModuleErr,".Hence not allowed to update Variant formula.");
								tc_strcat(ModuleErr,".\n");

								printf("\nModuleErr %s",ModuleErr); fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,ModuleErr);
								return ITK_errStore;
								break;

							}

						}
					}
				}


			}
		}

		//End of Deepti in TZ1.54 for APLModule

		/*
		//Added by Hanuman in TZ 1.52
		printf("\n BOMLine PartType :%s and Colour Indicator is :%s\n",child_PartType,child_ColorIndicator);fflush(stdout);
		if((tc_strstr(child_PartType,"Module")!= NULL) && (tc_strstr(child_ColorIndicator,"Y")!= NULL))
		{
			if(BL_FormulaEdited!=NULL)
			{
				printf("\n Going To Check Variant Formula =>%s\t\n",BL_FormulaEdited); fflush(stdout);
				if((tc_strstr(BL_FormulaEdited,"COLOUR-BOM")!= NULL) && (tc_strstr(BL_FormulaEdited,"SCHEME-NO")!= NULL))
				{
					if((tc_strstr(BL_FormulaEdited,"[Teamcenter]COLOUR-BOM = N")!= NULL) && (tc_strstr(BL_FormulaEdited,"[Teamcenter]COLOUR-BOM = Y")!= NULL))
					{
						printf("\n Both [Teamcenter]COLOUR-BOM = N & [Teamcenter]COLOUR-BOM = Y are Present in Variant Formula---------------->\t\n"); fflush(stdout);
					}else
					{
						EMH_clear_errors();
						EMH_store_error_s3(EMH_severity_error,ITK_err,"Colour-related Both Options Values for COLOUR-BOM = N and COLOUR-BOM = Y are Mandatory in Variant Formula","Please Update Variant Formula for Both Options with Proper Values for Module ==>",child_rev_id);
						return ITK_errStore;
					}
				}else
				{
					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,ITK_err,"Colour-related Options Values for (COLOUR-BOM=>Y & N and SCHEME-NO Both Mandatory) are not mapped for the parent architecture node of this module. Please take up with the Master Data Management team to get these options populated","Only then the change in colour indicator will be allowed to proceed");
					return ITK_errStore;
				}
			}
		}
		*/
	}
 }
  	return ITK_ok;
}




extern DLLAPI int  save_method_5(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag ,item_tag= NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char *desid = NULL;
	char *objname = NULL;
	char *Desc = NULL;
	char *NewDesc = NULL;
	char *NewDescription = NULL;
	const char *item_name = NULL;
	char *object_type = NULL;
	char *ItemName = NULL;
	char *objdesc	   = NULL;
	char *objMat = NULL;
	char *objMatThickness = NULL;
	char *objOppHandDrg = NULL;
	char *objRefDrw = NULL;
	char *objSurfStd = NULL;
	double  objWeight ;
	tag_t rev=NULLTAG;
	char* item_revision_id=NULL;
	char* item_name_copy=NULL;
	int ItmNamelength = 0;
	const char *cTemp="item_id";
	WSO_description_t     desc;

	//char **val=NULL;

	int desclength = 0;
	int desccnt = 0,n_tags_found=0;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_5:::::::::type_name[%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"CMI2Drawing")==0)
	{

		//item_name = (char *)MEM_alloc (50 * sizeof(char));
		if( AOM_ask_value_string(objTag,"current_name",&item_name)!=ITK_ok);PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_type",&object_type)!=ITK_ok);PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok);PrintErrorStack();

		ItmNamelength = strlen(item_name);
		item_name_copy = (char *)MEM_alloc (ItmNamelength * sizeof(char));
		strcpy(item_name_copy,item_name);
		printf("\n item_name_copy  :%s and item_name :%s\n",item_name_copy,item_name);fflush(stdout);

		item_name=strtok(item_name_copy,"/");

		if(item_name)
		{
						tag_t *tags_found = NULL;
						int n_tags_found= 0;
						printf("\n values[0] for parent is  :%s\n",item_name);fflush(stdout);
						//if(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found) !=ITK_ok);PrintErrorStack();
						if(ITEM_find_items_by_key_attributes(1,&cTemp, &item_name, &n_tags_found, &tags_found) !=ITK_ok);PrintErrorStack();

						if (n_tags_found > 1)
						{
							MEM_free(tags_found);
							EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
							printf ( "More than one items matched with id %s\n", item_name);fflush(stdout);
							exit (0);
						}
						else if (n_tags_found == 1)
						{
								printf ( "only one items matched with id %s\n", item_name);fflush(stdout);

							item_tag = tags_found[0];

							if(ITEM_find_revision(item_tag,item_name,&rev));PrintErrorStack();
							if(ITEM_ask_latest_rev(item_tag,&rev));PrintErrorStack();

							if(rev != NULLTAG)
							{


								if( AOM_ask_value_string(rev,"t5_Material",&objname)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_string(rev,"object_desc",&objdesc)!=ITK_ok);PrintErrorStack();

								if( AOM_ask_value_string(rev,"t5_MThickness",&objMatThickness)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_string(rev,"t5_OppHandDrg",&objOppHandDrg)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_string(rev,"t5_RefDrawing",&objRefDrw)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_string(rev,"t5_SurfPrtStd",&objSurfStd)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_double(rev,"t5_Weight",&objWeight)!=ITK_ok);PrintErrorStack();

								//AOM_save(objTag);
								if( AOM_set_value_string(objTag,"t5_PartMaterial",objname)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"object_desc",objdesc)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5_MThickness",objMatThickness)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5_OppHandDrg",objOppHandDrg)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5_RefDrawing",objRefDrw)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5_SurfPrtStd",objSurfStd)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_double(objTag,"t5_Weight",objWeight)!=ITK_ok);PrintErrorStack();


							}
							else
							{
									 printf(" Null rev tag \n");fflush(stdout);
							}
						}
						else if (n_tags_found == 0)
						{
							printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", item_name);fflush(stdout);
							//exit (0);
						}

          }


	}

	return error_code;
}


//Amol
extern DLLAPI int  save_method_Vendor(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag ,item_tag= NULLTAG;
	char *username;
	tag_t user_tag=NULLTAG;
	tag_t * 	list;
	char * 	userid;
	int number_found=0;

	char   type_name[TCTYPE_name_size_c+1];


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_Vendor:::::::::type_name[%s]\n",type_name);fflush(stdout);

	POM_get_user(&username,&user_tag);
	printf ("logged in user in vendor Creation :: %s\n",username);fflush(stdout);
	SA_ask_user_identifier2	(user_tag,&userid)	;
	printf ("logged in userid in vendor Creation :: %s\n",userid);fflush(stdout);

		SA_find_groupmember_by_rolename	("vendor_create","VendorCreationGroup",userid,&number_found,&list);
		printf ("number_found:: %d\n",number_found);fflush(stdout);

		if(number_found == 0)
		{
			printf ("logged in user is not in vendor creation group:: %s\n",username);fflush(stdout);

			EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not allowed to create Vendor. Please contact BOM Process Team to create vendor");
			return ITK_err;
		}



			return error_code;
}

///saurabh
extern DLLAPI int  save_method_Para_Rel(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int		ifail							= 0;

	tag_t objTypeTag ,item_tag= NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];

	tag_t RelobjTag = va_arg(args, tag_t);
	int	isNew = va_arg(args, int);



	if (TCTYPE_ask_object_type(RelobjTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_Para_Rel:::::::::type_name[%s]  [%d] \n",type_name,isNew);fflush(stdout);

	if (isNew)
	{
		printf("\n!!!!!!!!!!!!!!!!! save_method_Para_Rel::::::::: Revise or Checkedout!!!!!!!! \n");fflush(stdout);
		return error_code;
	}


	int		ii;
	int  	count,count1;

	tag_t	primary_object					= NULLTAG;
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= NULLTAG;
	tag_t	secondary_obj_type_tag			= NULLTAG;

	tag_t  	rel_type;
	tag_t	*sec_objects;
	tag_t	tsk_dml_rel_type;
	tag_t	DML_rev_tag						= NULLTAG;
	tag_t	*DMLRevision					= NULL;

	char	type_name1[WSO_name_size_c+1];
	char	type_name2[WSO_name_size_c+1];
	char	*obj_type_name2					= NULL;
	char	*objectvalue1					= NULL;
	char	*objectvalue2					= NULL;
	char	*TaskDsgGrp						= NULL;
	char	*username						= NULL;
	char	*PartType						= NULL;
	char	*TskNm							= NULL;
	char	*rls_type;

	logical	check_out = 0;
	ifail=GRM_ask_primary(RelobjTag,&primary_object);
	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name(primary_obj_type_tag,type_name1);
	printf("\nECU Primary_object type_name is:%s",type_name1);fflush(stdout);

	ifail=GRM_ask_secondary(RelobjTag,&secondary_object);
	ifail=TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag);
	ifail=TCTYPE_ask_name(secondary_obj_type_tag,type_name2);
	printf("\nECU secondary_object type_name is:%s",type_name2);fflush(stdout);
	POM_get_user_id (&username);
	printf("\nLogged in user:%s\n",username); fflush(stdout);

	char *SupportUsername9 = NULL;
	tag_t SessionUser9_tag=NULLTAG;
	int     SupportFlag      =  0;

	SupportFlag=0;
	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin(SessionUser9_tag);
		printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
	}

	//if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"ercpsup") !=0) //544216261202  5442165555555/NR;2
	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
	{
		if(tc_strcmp(type_name2,"T5_EPara") == 0 || tc_strcmp(type_name2,"T5_EParaRevision") == 0)
		{
			printf("\n*****INSIDE T5_EPara(Clause)*****\n");fflush(stdout);

			if(tc_strcmp(type_name1,"T5_EE_PartRevision") == 0)
			{
				printf("\n*****INSIDE T5_EE_PartRevision*****\n");fflush(stdout);

				char* SwPart=NULL;
				AOM_ask_value_string(primary_object,"t5_SwPartType",&SwPart);
				printf("\n*****INSIDE T5_EE_PartRevision***** <%s>\n",SwPart);fflush(stdout);


				if (tc_strcmp(SwPart,"PRM")==0)
				{

					if(RES_is_checked_out(primary_object, &check_out)!=ITK_ok)PrintErrorStack();
					printf("\n*****After RES_is_checked_out***** [%d]\n",check_out);fflush(stdout);
					if(check_out != 0)
					{
						printf("\nPart is checked-out, so Updated...!!\n");fflush(stdout);
					}
					else
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Update not allowed on Checked-In Part.Please check-out the EE Part first.");
						printf("\nPlease check-out the EE Part first...!!\n");fflush(stdout);
						return ITK_err;
					}
				}
			}
		}
	}
	return error_code;
}
extern DLLAPI int  save_method_SVR(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag ,item_tag= NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char *objname = NULL;
	char *Desc = NULL;
	const char *item_name = NULL;
	char *objdesc	   = NULL;
	char *VcNos	   = NULL;
	char *Svr_Token	   = NULL;
	char *Svr_Rev	   = NULL;
	char *Svr_VC_Suffix	   = NULL;
	char *svrObjString	   = NULL;
	char* subStrProjectCode = NULL;
	char* usrInfo1			= NULL;
	char* errorMsgCCVCVal = NULL;
	int ItmNamelength = 0;
	tag_t*    status_list_SVR=NULLTAG;

	//char **val=NULL;

	int desclength = 0,st_count_SVR=0;
	int desccnt = 0,n_tags_found=0;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::type_name[%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"VariantRule")==0)
	{
		//object_desc
		//object_name
		if( AOM_ask_value_string(objTag,"object_name",&objname)!=ITK_ok);PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_desc",&objdesc)!=ITK_ok);PrintErrorStack();
		ItmNamelength = strlen(objname);
		printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::obj_name[%s] obj_desc [%s]\n Item length%d \n",objname,objdesc,ItmNamelength);fflush(stdout);

		if (ItmNamelength > 15 )
		{
			/// 21826536000R_NR 21826536000R_A
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
			return ITK_err;
		}
		else if (ItmNamelength < 14)
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
			return ITK_err;
		}
		else
		{
			VcNos=subString(objname,0,12);      // "21826536000R"
			Svr_Token=subString(objname,12,1);  // "_"
			Svr_VC_Suffix=subString(objname,8,4); // "000R" or "000L"
			printf("\n save_method_SVR VcNos [%s] Svr_Token [%s]  Svr_VC_Suffix [%s]\n",VcNos,Svr_Token,Svr_VC_Suffix);fflush(stdout);
			if(strcmp(Svr_VC_Suffix,"000R") &&  strcmp(Svr_VC_Suffix,"000L") && strcmp(Svr_Token,"_") )
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
				return ITK_err;
			}
			if (ItmNamelength == 15)
			{

				Svr_Rev=subString(objname,13,2);
				printf("\nInside Character SVR %s\n",Svr_Rev);fflush(stdout);
				if(strcmp(Svr_Rev,"NR")  )
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
					return ITK_err;
				}

			}
			else if (ItmNamelength == 14)
			{
				Svr_Rev=subString(objname,13,1);
				printf("\nInside Character SVR %s %c %d\n",Svr_Rev,Svr_Rev[0],Svr_Rev[0]);fflush(stdout);
				if (Svr_Rev[0] >= 'A' && Svr_Rev[0] <= 'Z')
				{
					printf("\nInside Character SVR\n");fflush(stdout);
				}
				else
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
					return ITK_err;
				}
			}
		}

		desclength = strlen(objdesc);
		if (desclength > 27 )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"SVR Description is greater than 27 character.");
			return ITK_err;
		}

		if( WSOM_ask_release_status_list(objTag,&st_count_SVR,&status_list_SVR)!=ITK_ok);PrintErrorStack();
		logical			retain							= 0;
		tag_t			primary					= NULLTAG;
		tag_t			status_rel					= NULLTAG;
		tag_t			objTypeTagDi					= NULLTAG;
		char*			WSO_Name					= NULL;
		char   type_name3[TCTYPE_name_size_c+1];
		int				cnt=0,countDep=0,k;
		tag_t  *secondary_objects1	= NULLTAG;

		printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::obj_name[%s] Status count [%d]\n",objname,st_count_SVR);fflush(stdout);

		if( GRM_list_primary_objects_only(objTag,NULLTAG,&countDep,&secondary_objects1)!=ITK_ok)PrintErrorStack();
		printf("\n count found %d \n ",countDep);fflush(stdout);

			for (k=0;k<countDep;k++)
			{

				primary=secondary_objects1[k];
				if(TCTYPE_ask_object_type(primary,&objTypeTagDi)!=ITK_ok)PrintErrorStack();
				if(TCTYPE_ask_name(objTypeTagDi,type_name3)!=ITK_ok)PrintErrorStack();
				printf( "\n type_name3 :%s ..\n",type_name3);
			}

		if(st_count_SVR>0)
		{
			for (cnt=0;cnt< st_count_SVR;cnt++ )
			{
				if(AOM_ask_name(status_list_SVR[cnt],&WSO_Name)!=ITK_ok)PrintErrorStack();
				printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
			}
		}
		else
		{
			printf("\n count found %d \n ",countDep);fflush(stdout);
			if (countDep == 0)
			{
//				printf("\n >>>>>>>>>>>>>>>>>>>>Inside Creating ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
//				if (CR_create_release_status("ERC Review",&status_rel))PrintErrorStack();
//				printf("\n >>>>>>>>>>>>>>>>>>> Adding ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
//	//			if(EPM_add_release_status(status_rel,1,&objTag,retain))PrintErrorStack();
//				if(RELSTAT_add_release_status(status_rel,1,&objTag,retain))PrintErrorStack();
//				printf("\n >>>>>>>>>>>>>>>>>>> After ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
			}
		}
		//Thhis is added by Kirtikumar,15-Dec-2022
		//Control Obj for On and Off Validation.
		tag_t	qry_t1_sVrVal			= NULLTAG;
		char **qry_val3_sVrVal			= (char **) MEM_alloc(100 * sizeof(char *));
		char    *qry_entr1_sVrVal[1]   = {"SYSCD"};
		int n_entr1_sVrVal				= 1;
		int rsltCunt1_sVrVal			= 0;
		tag_t *CntrlObjTag1_sVrVal		= NULLTAG;

		// To get Revision of SVR
		char data[2][50];
		char *buffer;
		int i;

		char *SVR_ID = (char *) MEM_alloc( 30 * sizeof(char) );
		char *SVR_REV = (char *) MEM_alloc( 30 * sizeof(char) );


		ITK_CALL(AOM_ask_value_string(objTag,"object_string",&svrObjString));
		printf("\n\t SVR Object String is : %s \n",svrObjString);
		//Getting project code from SVR Obj String.
		subStrProjectCode=subString(svrObjString, 0, 4);
		printf("\n\t subStrProjectCode is : %s \n",subStrProjectCode);


		buffer = strtok(svrObjString, "_");
		i = 0;
		 while (buffer != NULL) {
			strcpy(data[i], buffer);

			//printf("data[%i] = %s\n\t", i+1, data[i]);
			buffer = strtok(NULL, "_");
			i++;
		}

		tc_strcpy(SVR_ID, data[0]);
		tc_strcpy(SVR_REV, data[1]);

		printf("\n\t SVR_ID :%s", SVR_ID);
		printf("\n\t SVR_REV :%s", SVR_REV);

		if(strcmp(SVR_REV,"NR")==0)
		{
				//Control Object for Validation on and Off. And Project Code for validation.
				if(QRY_find("ControlObjects", &qry_t1_sVrVal));
				if (qry_t1_sVrVal)
				{
					printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
				}
				qry_val3_sVrVal[0] = "CCVC/SVR Check";
				if(QRY_execute(qry_t1_sVrVal, n_entr1_sVrVal, qry_entr1_sVrVal, qry_val3_sVrVal, &rsltCunt1_sVrVal, &CntrlObjTag1_sVrVal));

				if(rsltCunt1_sVrVal>0)
				{
					ITK_CALL(AOM_ask_value_string(CntrlObjTag1_sVrVal[0],"t5_Userinfo1",&usrInfo1));
					if((tc_strstr(usrInfo1,subStrProjectCode) != NULL))
					{

							errorMsgCCVCVal=(char *)MEM_alloc(200);
							printf("After mem alloc\n");
							tc_strcpy (errorMsgCCVCVal, "SVR, ");
							//strcat(errorMsgCCVCVal,item_rev_id);
							strcat(errorMsgCCVCVal," of Project code : ");
							strcat(errorMsgCCVCVal,subStrProjectCode);
							strcat(errorMsgCCVCVal,", is not allowed to create.");
							//Not allowed give error here.
							EMH_store_error_s1(EMH_severity_error,ITK_err,errorMsgCCVCVal);
							return ITK_err;
					}
					else
					{
						printf("\n Project code is not lock. Allowed to create SVR. \n");fflush(stdout);
					}

				}
				else
				{
					printf("\n Control Object no found, Validation is OFF , this is for SVR \n");fflush(stdout);
				}
		}

	}// object type if ends

	return error_code;
}

//extern DLLAPI int  save_method_6(METHOD_message_t *msg, va_list args)
//{
//
//	int error_code = ITK_ok;
//	tag_t objTag = va_arg(args, tag_t);
//	//logical flag = va_arg(args, logical);
//	tag_t objTypeTag = NULLTAG;
//	char   type_name[TCTYPE_name_size_c+1];
//
//
//	int checked_out_user = 0;
//	//logical	checkoutp				= 0;
//
//	char *username;
//	char *cp_ChildChkOutValue = NULL;
//	char *Item_ID_str = NULL;
//	char *ischek = NULL;
//	char *Item_ID_Rev_str = NULL;
//	int    Item_ID,Item_Revision = 0;
//	tag_t user_tag=NULLTAG;
//	tag_t rev_tag=NULLTAG;
//	tag_t paritem=NULLTAG;
//	char *objecttype = NULL;
//	char *PartType = NULL;
//	int n_parents = 0;
//	int index = 0;
//	int *levels = 0;
//	tag_t *parents = NULL;
//	int	chkflg=0;
//
//	//char **val=NULL;
//
//	//int desclength = 0;
//	//int desccnt = 0,n_tags_found=0;
//
//	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
//	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
//	POM_get_user(&username,&user_tag);
//
//	printf("\n!!!!!!!!!!!!!!!!! save_method_6:::::::::type_name[%s]\n",type_name);fflush(stdout);
//
//	if(strcmp(type_name,"BOMLine")==0)
//	{
//
//		//item_name = (char *)MEM_alloc (50 * sizeof(char));
//		// if(RES_is_checked_out(objTag,&checkoutp))PrintErrorStack();
//
//			if(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_user))PrintErrorStack();
//			if(BOM_line_ask_attribute_string (objTag, checked_out_user, &cp_ChildChkOutValue))PrintErrorStack();
//
//		if(  BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision))PrintErrorStack();
//	    if(  BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID))PrintErrorStack();
//		if(BOM_line_ask_attribute_string(objTag, Item_ID, &Item_ID_str))PrintErrorStack();
//		if(BOM_line_ask_attribute_string(objTag, Item_Revision, &Item_ID_Rev_str))PrintErrorStack();
//
//		printf("\n ItemRevision is [%s] and ItemID is: [%s]\n",Item_ID_Rev_str,Item_ID_str);
//		if(ITEM_find_rev(Item_ID_str,Item_ID_Rev_str,&rev_tag))PrintErrorStack();
//
//		if(PS_where_used_all(rev_tag,1,&n_parents,&levels,&parents))PrintErrorStack();
//
//		if(AOM_ask_value_string(rev_tag,"object_type",&objecttype));
//		printf("\n\t object type => %s\n",objecttype);fflush(stdout);
//
//		if(AOM_ask_value_string(rev_tag,"t5_PartType",&PartType));
//		printf("\n\t PartType => %s\n",PartType);fflush(stdout);
//		printf("\n\t no of parents and levels => %d,%d\n",n_parents,levels);fflush(stdout);
//
//		if(strcmp(objecttype,"Design Revision")==0)
//		{
//
//		 if(n_parents > 0)
//				 {
//					 for( index=0; index<=1; index++)
//					 {
//                        paritem = parents[index];
//						if( AOM_ask_value_string(paritem,"checked_out",&ischek)!=ITK_ok);
//						printf("\n\t parent checkout status => %s\n",ischek);fflush(stdout);
//						if(strcmp(ischek,"Y")==0)
//						 {
//                              chkflg++;
//						 }
//					 }
//				 }
//				 printf("\n\t chkflg => %d\n",chkflg);fflush(stdout);
//
//				 if ((chkflg==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
//				{
//				EMH_store_error_s1(EMH_severity_error,ITK_err,"Parent is not checked out, so you cannot delete the child from BOM");
//				return ITK_err;
//				}
//		}
//
//
//
//	}
//
//	return error_code;
//}
//Vitthal :START: Validation on Architecture Module Revision Address and Module Address.
int BomLineModuleValidaion(tag_t tag_bomLineParent,tag_t tag_child)
{
	int   Status			 = ITK_ok;
	char *sDesModuleAddress  = NULL;
	char *sArModAddress		 = NULL;
	char *sPartType			 = NULL;
	char *sObjectTypeArch	 = NULL;
	char *sObjectTypeModule	 = NULL;
	tag_t ChildTagLatestRev	 = NULLTAG;

	if(ITEM_ask_latest_rev(tag_child,&ChildTagLatestRev));
	if((tag_bomLineParent) && (ChildTagLatestRev))
	{
		if(AOM_ask_value_string(tag_bomLineParent,"object_type",&sObjectTypeArch));
		if(AOM_ask_value_string(ChildTagLatestRev,"object_type",&sObjectTypeModule));
		if(AOM_ask_value_string(ChildTagLatestRev,"t5_PartType",&sPartType));
		printf("\n FILE NAME:BOMLineValidation.c, FUNCTION NAME:BomLineModuleValidaion(), \n sObjectTypeArch => %s\n sObjectTypeModule=>%s\n Module t5_PartType=>%s",sObjectTypeArch,sObjectTypeModule,sPartType);fflush(stdout);
		if((tc_strcmp(sObjectTypeArch,"T5_ArchModuleRevision")==0) && (tc_strcmp(sObjectTypeModule,"Design Revision")==0) &&  (tc_strcmp(sPartType,"M")==0))
		{
			if(AOM_ask_value_string(tag_bomLineParent,"t5_ArchModuleAddress",&sArModAddress));
			if(AOM_ask_value_string(ChildTagLatestRev,"t5_ModuleAddress",&sDesModuleAddress));
			printf("\nFILE NAME:BOMLineValidation.c, FUNCTION NAME:BomLineModuleValidaion(), \n t5_ArchModuleAddress => %s\n t5_ModuleAddress=>%s",sArModAddress,sDesModuleAddress);fflush(stdout);
			if(tc_strcmp(sArModAddress,sDesModuleAddress)!=0)
			{
				return 1;
			}
		}
	}
	printf("\n Architecture Module Revision Address and Module Address is same, \n t5_ArchModuleAddress => %s\n t5_ModuleAddress=>%s",sArModAddress,sDesModuleAddress);fflush(stdout);
	return 0;
}
//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.
extern DLLAPI int  save_method_7(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t  item_tag		= va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag = NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	int checked_out_user = 0;
	//logical	checkoutp				= 0;
	char *username;
	char *cp_ChildChkOutValue = NULL;
	char *Item_ID_str = NULL;
	char *Item_ID_Rev_str = NULL;
	char *DesignGrp = "60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,54,16";
	int   Item_ID,Item_Revision = 0;
	tag_t user_tag=NULLTAG;
	tag_t rev_tag=NULLTAG;
	char *objecttype = NULL;
	char *PartType = NULL;
	char *t5_DesignGrp = NULL;
	char *ChildPartType = NULL;
	//int ItmNamelength = 0;
	//const char *cTemp="item_id";
	//WSO_description_t     desc;
	//char **val=NULL;
	//int desclength = 0;
	//int desccnt = 0,n_tags_found=0;

	//added by ajinkya on 2 march//
	char *objecttypeRight = NULL;
	tag_t ChildTagLatestRevt	 = NULLTAG;
	char *sObjectTypeModulet	 = NULL;
	char *Item_id_par=NULL;
	char *Modultyp=NULL;
	char   *ninethteenth=NULL;
	char	*designRev_id	= NULL;
	int item_idlength =0;
	tag_t  CurrentRoleTag = NULLTAG;
	char roleName[SA_name_size_c+1];
	//end

	//Ashwini
	char *Item_Pcde_str = NULL;
	char *qry_entriesObs[2] = {"Name","Type"};
	char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));
	char *ProjectCodeValS		= NULL;
	char *CItem_id_par			= NULL;
	char *CItem_ProjctCdeS		= NULL;
	char *CItem_DsgnGrpS		= NULL;
	char *AlternatePrtS			= NULL;
	char *ChildCpyAltS			= NULL;
	char *ChildOSPRENTS			= NULL;
	char *CPartQryLst			= NULL;
	char *CStrtngWth1			= NULL;

	char *CItem_SWparttype		= NULL;//Kalpesh(EEPart_Hardware)
	char *CItem_Prj_code		= NULL;//Kalpesh(for project code)

	char *group_name;
	tag_t group_tag=NULLTAG;

	tag_t queryTagObs		= NULLTAG;
	tag_t *NewPartsSetObs	= NULL;
	tag_t PrjCdObj			= NULLTAG;

	int n_entriesObs = 2;
	int resultCountObs =0;
	int Cpartlength =0,Item_Pcde;


	tag_t TagControlObs14 = NULLTAG,
	*cntr_objectsObs14 = NULL;
	int	n_entriesObs14 = 1;
	int n_foundObs14 = 0;
	char *qry_entriesObs14[1] = {"SYSCD"};
	char *qry_valuesObs14[1] = {"Obsolete_PrjCde_allow"};

	char	*info1		= NULL;
	char	*info2		= NULL;
	char	*info3		= NULL;
	char	*info4		= NULL;
	char	*info5		= NULL;
	char	*info6		= NULL;
	char	*info7		= NULL;
	char	*info8		= NULL;
	char	*info9		= NULL;
	char	*info10		= NULL;
	//Ashwini End.

	int ref1				=	0;
	int n_refs				=	0;
	int *n_lvls;
	int groupidflag=0;
	tag_t *refs_tag;
	char *sObjStr			=	NULL;
	char *sPrtType			=	NULL;
	char *sPartID			=	NULL;
	char **rel_char			=	NULL;
	char* Response			=	NULL ;
	tag_t ref_objTypTag		=	NULLTAG;
	tag_t Ref_Item_tag		=	NULLTAG;
	char ref_type_name[TCTYPE_name_size_c+1];

	//neha
	tag_t t_Window1 = NULLTAG;
	tag_t t_RRule1 = NULLTAG;
	tag_t ItemTag1 = NULLTAG;
	tag_t t_TLine1 = NULLTAG;
	tag_t t_Childobject = NULLTAG;
	int ChildCount1= 0;
	int iChldPrts=0;
	int	iItemId=0;
	int n_fnd = 0;
	int n_entry = 1;
	char *cp_ItemID_str1=NULL;
	tag_t *t_PrtChldren1;
	char *Err =NULL;
	char *ctrlQryE[2]		= {"SYSCD", "SUBSYSCD"};
	char *ctrlQryV[2]		= {"PltArchM", "PltArchMM"};
	tag_t TagQryCtrlObj		= NULLTAG;
	tag_t *cntr_obj = NULLTAG;
	//neha

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username,&user_tag);
	POM_ask_group(&group_name, &group_tag);

	printf("\n!!!!!!!!!!!!!!!!! save_method_7:::::::::type_name[%s]\n",type_name);fflush(stdout);
	printf("\n  Printf added for testing [%s]\n",type_name);fflush(stdout);




	if(strcmp(type_name,"BOMLine")==0)
	{
		//item_name = (char *)MEM_alloc (50 * sizeof(char));
		// if(RES_is_checked_out(objTag,&checkoutp))PrintErrorStack();

		if(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_user))PrintErrorStack();
		if(BOM_line_ask_attribute_string (objTag, checked_out_user, &cp_ChildChkOutValue))PrintErrorStack();
		if(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision))PrintErrorStack();
	    if(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID))PrintErrorStack();
		if(BOM_line_ask_attribute_string(objTag, Item_ID, &Item_ID_str))PrintErrorStack();
		if(BOM_line_ask_attribute_string(objTag, Item_Revision, &Item_ID_Rev_str))PrintErrorStack();

		printf("\n ItemRevision is [%s] and ItemID is: [%s]\n",Item_ID_Rev_str,Item_ID_str);
		if(ITEM_find_rev(Item_ID_str,Item_ID_Rev_str,&rev_tag))PrintErrorStack();

		if(AOM_ask_value_string(rev_tag,"object_type",&objecttype));
		printf("\n\t object type at 1657 line **************** => %s\n",objecttype);fflush(stdout);

		if(AOM_ask_value_string(rev_tag,"t5_PartType",&PartType));
		printf("\n\t PartType => %s\n",PartType);fflush(stdout);

		if(AOM_ask_value_string(rev_tag,"t5_DesignGrp",&t5_DesignGrp));
		printf("\n\t t5_DesignGrp => %s\n",t5_DesignGrp);fflush(stdout);

		if(BOM_line_look_up_attribute ("bl_T5_ClrPartRevision_t5_ProjectCode",&Item_Pcde))PrintErrorStack();//Need to change attributes
		if(BOM_line_ask_attribute_string(objTag, Item_Pcde, &Item_Pcde_str))PrintErrorStack();
		printf("\n QtyOccur_str is----------------------------------> [%s]\n",Item_Pcde_str);

		//added in TZ 1.34
		if(AOM_ask_value_string(rev_tag,"item_id",&designRev_id));
		printf("\n\t designRev_id => %s\n",designRev_id);fflush(stdout);

		ninethteenth = subString(designRev_id, 8, 2);
		printf("\n\t 9th & 10th digit is :: [%s]\n", ninethteenth);fflush(stdout);

		item_idlength = strlen(designRev_id);
		printf("\n\t Lenght of ItemID is => %d\n",item_idlength);fflush(stdout);

		printf ("logged in user,status of BOMLine :: %s,%s\n",username,cp_ChildChkOutValue);fflush(stdout);

		if(item_tag != NULLTAG)
		{
			// added by ajinkya on 2 march//
			if(AOM_ask_value_string(item_tag,"object_type",&objecttypeRight));
			printf("\n\t Finding Right object type => %s\n",objecttypeRight);fflush(stdout);

			//added on 20 march //

			if(ITEM_ask_latest_rev(item_tag,&ChildTagLatestRevt));
		}
		else
		{
			//Added by Prachi
			printf("\n\tinside else\n");fflush(stdout);
			ChildTagLatestRevt = va_arg(args, tag_t);
			if(ChildTagLatestRevt != NULLTAG)
			{
				printf("\ngot ChildTagLatestRev not null\n");fflush(stdout);
			}
			else
			{
				printf("\nnull revision tag\n");fflush(stdout);
			}

		}
		if(AOM_ask_value_string(ChildTagLatestRevt,"object_type",&sObjectTypeModulet));
		printf("\n\t Added for finding latest Arch Revision => %s\n",sObjectTypeModulet);fflush(stdout);

		if(AOM_ask_value_string(ChildTagLatestRevt,"t5_PartType",&ChildPartType));
		printf("\n\t ChildPartType => %s\n",ChildPartType);fflush(stdout);

		if( AOM_ask_value_string(ChildTagLatestRevt,"item_id",&Item_id_par)!=ITK_ok);
		printf("\n  Dropping Right Object Item ID is  ---->%s \n",Item_id_par); fflush(stdout);

		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			if(tc_strcmp(objecttype,"Design Revision")==0 || tc_strcmp(objecttype,"T5_SparKitRevision")==0)
			{
				if((tc_strcmp(PartType,"CM")==0))
				{
					printf("\n Inside CM  \n");fflush(stdout);
					if(tc_strcmp(ChildPartType,"M") && tc_strcmp(ChildPartType,"D")&& tc_strcmp(ChildPartType,"DC") && tc_strcmp(ChildPartType,"DA")) //Adi for DC & DA
					{
						printf("\n Contextual Product can have only module or dummy parts  \n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"CAD Module should  contain Module or Dummy Parts only");
						return ITK_err;
					}
				}
				// Add validation on selection group id, check child part adding to parent is not attached to other groupid.
				else if((tc_strcmp(PartType,"G")==0))
				{
					printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7() : Validation for Part type GroupID \n");fflush(stdout);

					int 	n_levels;
					int  	n_parents;
					int * 	levels;
					tag_t * 	parents	;

					//if(WSOM_where_referenced(ChildTagLatestRevt,WSO_where_ref_any_depth,&n_refs,&n_lvls,&refs_tag,&rel_char));
					if(PS_where_used_all(ChildTagLatestRevt,1,&n_parents,&levels,&parents));

					printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7() : n_parents: [%d]  \n",n_parents);fflush(stdout);

					if(n_parents>0)
					{
						for (ref1=0; ref1<n_parents;ref1++ )
						{
							if (TCTYPE_ask_object_type(parents[ref1],&ref_objTypTag));
							if (TCTYPE_ask_name(ref_objTypTag,ref_type_name));



							printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7() : ref1[%d]ref_type_name: [%s]\n",ref1,ref_type_name);fflush(stdout);

							if(tc_strcmp(ref_type_name,"Design Revision")==0)
							{
								if( AOM_ask_value_string(parents[ref1],"t5_PartType",&sPrtType)!=ITK_ok);

								if( AOM_ask_value_string(parents[ref1],"object_string",&sObjStr)!=ITK_ok);
								printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7(): sObjStr:[%s] sPrtType [%s]\n",sObjStr,sPrtType);fflush(stdout);

								//sPartID = strtok(sObjStr,"/");

								//printf("\n\t sPartID: [%s]\n",sPartID);fflush(stdout);

								//if(ITEM_find_item(sPartID,&Ref_Item_tag));

								//if(AOM_ask_value_string(Ref_Item_tag,"t5_RevPartType",&sPrtType)!=ITK_ok);

								//if(tc_strcmp(sPrtType,"G")==0)

								printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7(): sPrtType:[%s]\n",sPrtType);fflush(stdout);

								if(tc_strcmp(sPrtType,"G")==0)
								{
									groupidflag=1;
									break;
								}
							}
						}
					}
					if(groupidflag==1)
					{

						printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7(): This Child Part %s already exists for other GroupID %s \n",Item_id_par,sObjStr);fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s4(EMH_severity_error,ITK_err,"\n This Child Part ",Item_id_par," already exists for other GroupID ",sObjStr);
						return ITK_err;
					}
					else if(groupidflag==0)
					{
						printf("\n  check group id validation in TCE here.\n"); fflush(stdout);

						int ValCnt1=0;
						int GrpIDInICE = 0;
						tag_t*	ValCntrlObjectTag2=NULLTAG;
						tag_t qryTag2 =NULLTAG;
						char    **qry_values4     =  (char **) MEM_alloc(10 * sizeof(char *));
						int n_entry1=1;
						char    *qry_entry1[1]  = {"SYSCD"};


						if(QRY_find("ControlObjects", &qryTag2));
						if (qryTag2)
						{
							printf("\n Found Query ControlObjects \n");fflush(stdout);
						}
						else
						{
							printf("\n Not Found Query ControlObjects \n");fflush(stdout);
						}

						qry_values4[0] = "GIDINTCE" ;
						if(QRY_execute(qryTag2, n_entry1, qry_entry1, qry_values4, &ValCnt1, &ValCntrlObjectTag2));
						printf(" \n GIDINTCE:ValCnt :%d:", ValCnt1); fflush(stdout);

						if(ValCnt1>0)
						{
							GrpIDInICE = FunToCheckGroupIDRefInICE(ValCntrlObjectTag2[0],Item_id_par,Item_ID_str);
							printf("\n  End Calling exe using system command\n"); fflush(stdout);

							if(GrpIDInICE==2)
							{
							printf("\n PART IS ATTACHED TO OTHER GROUPID IN TCE \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_initial_error_s1(EMH_severity_error,ITK_err,"Part you are trying to attach is attached to other GroupID in TCE. Please get it loaded from PLM Team.");
							return ITK_err;
							}
							else
							{
							printf("\n Please proceed to attach part to groupID. \n");fflush(stdout);
							}
							printf("\n ------------------------Done------------- \n");fflush(stdout);
							}
						else
						{
							printf("\n\t control object GIDINTCE not found. \n");fflush(stdout);
						}
					}
				}
			}
			if(tc_strcmp(objecttype,"T5_PlatformRevision")==0)
			{
				printf("\n\t Inside the left object at ------------------->>>>>>>>=> %s\n",objecttype);fflush(stdout);

				//Neha(CR-FY23-0166)
				if(QRY_find2("ControlObjQry", &TagQryCtrlObj));
				if(QRY_execute(TagQryCtrlObj, n_entry, ctrlQryE, ctrlQryV, &n_fnd, &cntr_obj));
				printf("\n PltArchM control object nfound variable size == %d", n_fnd);fflush(stdout);

				if(n_fnd>0)
				{

					if((tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision")==0))
					{
							if(BOM_create_window (&t_Window1) !=ITK_ok) PrintErrorStack();
							if(CFM_find( "Latest Working", &t_RRule1 )!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_config_rule( t_Window1, t_RRule1 )!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_pack_all (t_Window1, true)!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_top_line (t_Window1, ItemTag1, rev_tag, null_tag, &t_TLine1)!=ITK_ok) PrintErrorStack();
							if(BOM_line_ask_child_lines (t_TLine1, &ChildCount1, &t_PrtChldren1)!=ITK_ok) PrintErrorStack();
							printf("\nChild Parts Found in BomLine are :: [%d]\n",ChildCount1);fflush(stdout);

							if((ChildCount1 > 0))
							{
								for (iChldPrts = 0; iChldPrts < ChildCount1; iChldPrts++)
								{
									if(t_Childobject) t_Childobject=NULLTAG;
									t_Childobject=t_PrtChldren1[iChldPrts];

									if(BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
									if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str1));
									printf("\n ItemID_is -> [%s]\n",cp_ItemID_str1);

									if(tc_strcmp(Item_id_par,cp_ItemID_str1)==0)
									{
										printf("\n Same architecture module found \n");fflush(stdout);
										Err	=	NULL;
										Err	=	(char *)MEM_alloc(200);
										tc_strcpy(Err,"");
										tc_strcat(Err,Item_id_par);
										tc_strcat(Err,":");
										tc_strcat(Err,"architecture module are already attached to Platform");
										tc_strcat(Err,".Kindly check.");

										printf("\nErr %s",Err); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,Err);
										return ITK_errStore;
									}
								}
							}
					}
				}

			 //if(tc_strcmp(objecttypeRight,"T5_ArchModule")!=0)
			 if((tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision")!=0))
				{
					printf("\n Inside the error -Platform shall have only Architecture Modules as immediate child \n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Platform shall have only Architecture Modules as immediate child");
					//EMH_store_error_s1(EMH_severity_error,ITK_err,"Child parts can't be added to Checked-in/ERC Review part");
					return ITK_err;
				}
				//Added by kalpesh(13-Jun-19)
				else
				{
					//if(tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision") == 0 && tc_strcmp(username, "su_mdm") == 0)
					if(tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision") == 0 && tc_strcmp(group_name, "Master_Data_Mgmt") == 0)
					{
					}
					else
					{
						printf("\nOnly user having Group (Master_Data_Mgmt) can attach Architecture Modules to Platform BOM Structure.\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nOnly user having Group (Master_Data_Mgmt)can attach Architecture Modules to Platform BOM Structure.");
						//EMH_store_error_s1(EMH_severity_error,ITK_err,"Child parts can't be added to Checked-in/ERC Review part");
						return ITK_err;
					}
				}//End
			}
		}
		//Ashwini - Check Obsolete Part and Give Hard check..
		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			printf("\nUses Parts Starts................................................\n");fflush(stdout);
			printf("\n QtyOccur_str is----------------------------------> [%s]\n",Item_Pcde_str);
			if(QRY_find("General...", &queryTagObs));
			if (queryTagObs)
			{
				printf("\nGeneral... Found Query ControlObjects ");
				fflush(stdout);
			}
			else
			{
				printf("\n General...:Not Found Query ControlObjects \n");
				fflush(stdout);
			}
			qry_valuesObs[0] = Item_Pcde_str ;
			qry_valuesObs[1] = "Project" ;

			if(QRY_execute(queryTagObs,n_entriesObs,qry_entriesObs,qry_valuesObs,&resultCountObs,&NewPartsSetObs));
			printf("\n11 Unique General... Query resultCount :%d:\n", resultCountObs); fflush(stdout);

			if (resultCountObs > 0)
			{
				PrjCdObj = NewPartsSetObs[0];
				if(AOM_ask_value_string(PrjCdObj,"t5_BussUnitType",&ProjectCodeValS) != ITK_ok);
				printf("\nIN function QueryProject t5_BussUnitType = %s..\n",ProjectCodeValS);fflush(stdout);
			}
			//Query Project
			//Child
			if(tc_strcmp(ProjectCodeValS,"PCBU") == 0)
			{
				if(AOM_ask_value_string(ChildTagLatestRevt,"item_id",&CItem_id_par)!=ITK_ok);
				printf("\n  Dropping Right Object Item ID is  ---->%s \n",CItem_id_par); fflush(stdout);

				if(AOM_ask_value_string(ChildTagLatestRevt,"t5_ProjectCode",&CItem_ProjctCdeS)!=ITK_ok);
				printf("\n  Dropping Right Object Item ID is  ---->%s \n",CItem_ProjctCdeS); fflush(stdout);

				if(AOM_ask_value_string(ChildTagLatestRevt,"t5_DesignGrp",&CItem_DsgnGrpS)!=ITK_ok);
				printf("\n  Dropping Right Object Item ID is  ---->%s \n",CItem_DsgnGrpS); fflush(stdout);

				CStrtngWth1=subString(CItem_id_par,0,1);
				Cpartlength = tc_strlen(CItem_id_par);

				if(Cpartlength == 11 && tc_strcmp(CItem_DsgnGrpS,"11")==0 && tc_strcmp(CItem_ProjctCdeS,"1111")==0 && tc_strcmp(CStrtngWth1,"1")==0)
				{

					if(QRY_find2("ControlObjQry", &TagControlObs14));
					if(QRY_execute(TagControlObs14, n_entriesObs14, qry_entriesObs14, qry_valuesObs14, &n_foundObs14, &cntr_objectsObs14));
					printf("\n Project Code Control Object found == %d\n", n_foundObs14);fflush(stdout);

					if(n_foundObs14==1)
					{
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
						printf("\nBypass Design  Group List [%s] and project code = %s",info1,Item_Pcde_str); fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
						printf("\n info2 is.:[%s] and Project code = %s\n", info2,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
						printf("\n info3 is.:[%s] and project code = %s\n", info3,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
						printf("\n info4 is.:[%s] and Project code = %s\n", info4,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
						printf("\n info5 is.:[%s] and project code = %s\n", info5,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
						printf("\n info6 is.:[%s] and project code = %s\n", info6,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
						printf("\n info7 is.:[%s] and project code = %s\n", info7,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
						printf("\n info8 is.:[%s] and project code = %s\n", info8,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
						printf("\n info9 is.:[%s] and project code = %s\n", info9,Item_Pcde_str);fflush(stdout);

						if((tc_strstr(info1,Item_Pcde_str)!=NULL) || (tc_strstr(info2,Item_Pcde_str)!=NULL) || (tc_strstr(info3,Item_Pcde_str)!=NULL) || (tc_strstr(info4,Item_Pcde_str)!=NULL) || (tc_strstr(info5,Item_Pcde_str)!=NULL) || (tc_strstr(info6,Item_Pcde_str)!=NULL) || (tc_strstr(info7,Item_Pcde_str)!=NULL) || (tc_strstr(info8,Item_Pcde_str)!=NULL) || (tc_strstr(info9,Item_Pcde_str)!=NULL))
						{
							printf("\n%s Project code present in Control object \n",Item_Pcde_str);fflush(stdout);
							//}
							//if(tc_strcmp(Item_Pcde_str,"5438")==0)
							//{//Start
							printf("\n123 Extension of Fasteners related check for Nexon to TcUA - 5438 project\n"); //

							ChildOSPRENTS=(char *) MEM_alloc(850);
							printf("\nProject PCBU Obsolete Uses Parts..\n");fflush(stdout);
							tc_strcpy(ChildOSPRENTS,"");
							strcat(ChildOSPRENTS,"----Below List of fasteners used from outside the list----\nPlease note that check-in in PLM will be unsuccessful if the 11-digit standard fasteners are not in line with the list of fasteners maintained specifically for Nexon project.For any requirement beyond this list, a DCR needs to be raised. \n'Query--->Cntrl_t5ObmPrt_OSPRY---> Alt Part Ind = OSPREY and Obsolte Part =ChildPart Number' ");

							printf("\nPart is OBSOLETE Do check-in....\n");fflush(stdout);
							AlternatePrtS=QueryObsPartOSPREY_Uses(CItem_id_par);
							printf("\nAlternatePrtS = %s\n",AlternatePrtS);fflush(stdout);
							if(strcmp(AlternatePrtS,"OSPREYPresnt")==0)
							{
								printf("\nOSPREY present in table allow Uses parts Creation.....\n");fflush(stdout);
							}
							else
							{
								if(strcmp(AlternatePrtS,"OSPREYNTPresnt")==0)
								{
									printf("\n%s OSPREY NOT Present %s\n",CItem_id_par,AlternatePrtS);
									strcat(ChildOSPRENTS,CItem_id_par );
									strcat(ChildOSPRENTS,",");
									EMH_store_error_s1(EMH_severity_error,ITK_err,ChildOSPRENTS);
									return ITK_err;
								}
							}
						}
					}
					ChildCpyAltS=(char *) MEM_alloc(650);
					CPartQryLst=(char *) MEM_alloc(650);
					printf("\nProject PCBU Obsolete Check-in..\n");fflush(stdout);
					tc_strcpy(ChildCpyAltS,"");
					strcat(ChildCpyAltS,"This part is hexavalent Cr-coated and can not be used. You may use the suggested alternate in its place ");

					tc_strcpy(CPartQryLst,"");
					strcat(CPartQryLst,"This part is hexavalent Cr-coated. You can not use it in your structure definition ");

					printf("\nChild Name Lenght = %d and Child Part starts with = %s\n",Cpartlength,CStrtngWth1);
					//if(Cpartlength == 13 && tc_strcmp(CItem_DsgnGrpS,"16")==0 && tc_strcmp(CItem_ProjctCdeS,"5442")==0)
//					if(Cpartlength == 11 && tc_strcmp(CItem_DsgnGrpS,"11")==0 && tc_strcmp(CItem_ProjctCdeS,"1111")==0 && tc_strcmp(CStrtngWth1,"1")==0)
//					{
					printf("\nPart is OBSOLETE Do check-in....\n");fflush(stdout);
					AlternatePrtS=QueryObsPart_Uses(CItem_id_par);
					printf("\nAlternatePrtS = %s\n",AlternatePrtS);fflush(stdout);
					if(strcmp(AlternatePrtS,"PrtDelete")==0)
					{
						printf("\n%s have Alternate Part PrtDelete %s\n",CItem_id_par,AlternatePrtS);
						strcat(CPartQryLst,CItem_id_par);
						strcat(CPartQryLst,"," );
						EMH_store_error_s1(EMH_severity_error,ITK_err,CPartQryLst);
						return ITK_err;
					}
					if(strcmp(AlternatePrtS,"PrtDelete") != 0)
					{
						if(strcmp(AlternatePrtS,"QryNotFound")!=0 && (tc_strlen(AlternatePrtS)!=0))
						{
							printf("\n%s have Alternate Part %s\n",CItem_id_par,AlternatePrtS);
							strcat(ChildCpyAltS,CItem_id_par );
							strcat(ChildCpyAltS,"--->" );
							strcat(ChildCpyAltS,AlternatePrtS);
							EMH_store_error_s1(EMH_severity_error,ITK_err,ChildCpyAltS);
							return ITK_err;
						}
					}
					//}
				//}
				}
			}
			printf("\nUses Parts ENDS.........................................................\n");fflush(stdout);
		}

		//Added by kalpesh(21st_June_2018)//Modified_23rd_june19(IFD Module)//Modified_25_july19(T5_ClrPartRevision)
		//Modified_28_Aug19(ECU Module)

		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			if(tc_strcmp(objecttype,"T5_ArchModuleRevision")==0)
			{
				printf("\n\t Inside the left object at ------------------->>>>>>>>=> %s\n",objecttype);fflush(stdout);

				char* child_type = NULL;
				if(AOM_UIF_ask_value(ChildTagLatestRevt,"t5_PartType",&child_type));
				printf("\n\t ChildPartType => %s sObjectTypeModulet => %s\n",child_type,sObjectTypeModulet);fflush(stdout);

				if(tc_strcmp(sObjectTypeModulet,"Design Revision") == 0 || tc_strcmp(sObjectTypeModulet,"T5_ClrPartRevision") == 0)
				{
					if((tc_strcmp(child_type, "Module") == 0) || (tc_strcmp(child_type, "IFD Module") == 0) || (tc_strcmp(child_type, "ECU Module") == 0) || (tc_strcmp(child_type, "CAD Module") == 0))
					{
						if(AOM_ask_value_string(ChildTagLatestRevt,"t5_ModuleType",&Modultyp)!=ITK_ok)PrintErrorStack();
						printf("\n dorping Modultyp:%s ...\n",Modultyp);fflush(stdout);
						//below DFA-M validation reverted in sept 2018.
						/*if(tc_strcmp(Modultyp,"")!=0)
						{
							if(tc_strcmp(Modultyp,"DFM-A")==0)
							{
								printf("\n Inside error for DFM-A. \n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"\n DFM-A modules cannot be added under Architecture Modules as immediate child.");
								return ITK_err;
							}
						}*/
					}
					else
					{
						if(tc_strcmp(sObjectTypeModulet,"T5_ClrPartRevision") == 0)
						{
						}
						else
						{
							printf("\nArch_Module Rev. should have only Module,IFD Module,ECU Module and color part as immediate child.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Module,IFD Module,ECU Module and color part can be attached to Arch Module as immediate child");
							return ITK_err;
						}
					}
				}
				else
				{
					printf("\nArch_Module Rev. should have only Module,IFD Module,ECU Module and color part as immediate child.\n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Module,IFD Module,ECU Module and color part can be attached to Arch Module as immediate child");
					return ITK_err;
				}
			}
		}

		//ECU Module Validation(24_oct2019)//Kalpesh
		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			//Only EE Parts should get attached under ECU Module
			printf("\nChild_Object_Type:%s", sObjectTypeModulet);
			if(tc_strcmp(sObjectTypeModulet,"T5_EE_PartRevision") == 0)
			{
				if(AOM_ask_value_string(ChildTagLatestRevt,"t5_ProjectCode",&CItem_Prj_code)!=ITK_ok);
				printf("\n EE Part project_code is---->%s \n",CItem_Prj_code); fflush(stdout);
				if(tc_strcmp(CItem_Prj_code,"9002") == 0 || tc_strcmp(CItem_Prj_code,"9011") == 0)
				{
					printf("\nEE Part is bypassed for project code(9002 & 9011)...!!\n");
				}
				else
				{
					if(tc_strcmp(objecttype,"Design Revision") == 0)
					{
						printf("\nParent_Object_Type:%s\n Parent_Part_Type:%s\n",objecttype, PartType);fflush(stdout);
						if(tc_strcmp(PartType,"EM") == 0)
						{
							printf("\nEE Part got attached under ECU Module\n");
						}
						else
						{
							//Modified on (20-Dec-2019) for bypassing hardware parts.

							if(AOM_ask_value_string(ChildTagLatestRevt,"t5_DesignGrp",&CItem_DsgnGrpS)!=ITK_ok);
							printf("\n EE Part design_group is  ---->%s \n",CItem_DsgnGrpS); fflush(stdout);

							if(tc_strcmp(CItem_DsgnGrpS, "16") == 0)
							{
								if(AOM_ask_value_string(ChildTagLatestRevt,"t5_SwPartType",&CItem_SWparttype)!=ITK_ok);
								printf("\n EE Part SW_parttype---->%s \n",CItem_SWparttype); fflush(stdout);

								if(tc_strcmp(CItem_SWparttype, "HWC") == 0 || tc_strcmp(CItem_SWparttype, "CON") == 0)//Modified for bypassing Container parts.(18th_june2020)
								{
									printf("\nHardware parts and Container parts are bypassed.\n");
								}
								else
								{
									printf("\nEE parts should be attached under ECU Module only.\n");fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err, "EE parts should be attached under ECU Module only.");
									return ITK_err;
								}
							}
						}
					}
				}
			}
			//Only EE Parts should get attached under EE Part
			if(tc_strcmp(objecttype,"T5_EE_PartRevision") == 0)
			{
				printf("\nInside parent part(EE_Part_Revision)...!!");
				printf("\nParent Object Type:%s",objecttype);fflush(stdout);
				printf("\nChild Object Type:%s", sObjectTypeModulet);
				if(tc_strcmp(sObjectTypeModulet,"T5_EE_PartRevision") == 0)
				{
					printf("\nEE Part got attached under EE Part\n");
				}
				else
				{
					if(AOM_ask_value_string(ChildTagLatestRevt,"t5_ProjectCode",&CItem_Prj_code)!=ITK_ok);
					printf("\n EE Part project_code is---->%s \n",CItem_Prj_code); fflush(stdout);
					if(tc_strcmp(CItem_Prj_code,"9002") == 0 || tc_strcmp(CItem_Prj_code,"9011") == 0)
					{
						printf("\nEE Part is bypassed for project code(9002 & 9011)...!!\n");
					}
					else
					{
						printf("\nEE Parts should have only EE Part as immediate child.\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err, "EE Parts should have only EE Part as immediate child.");
						return ITK_err;
					}
				}
			}
		}
		//Kalpesh(End of ECU Module validation)
             	/// Starts Added By Nana to Restrict Quick Add Button

						tag_t   CntobjQKAddVld		=	NULLTAG;

						char    *qry_QKaddVld_entry[2]	=	{"SYSCD","SUBSYSCD"};
						char    **qry_QKaddVld_values    =  (char **) MEM_alloc(10 * sizeof(char *));
						int     QKaddVld_entry				=	2;
						int		QKaddVldCntlObj			=	0;
						tag_t   *QKaddVldCntrlObj_Tags    =	NULLTAG;

						if(QRY_find("Control Objects...", &CntobjQKAddVld));
						if (CntobjQKAddVld)
						{
							printf("\n Found Query ControlObjects for Quick Add Button validation \n");fflush(stdout);
						}
						else
						{
							printf("\n Not Found Query ControlObjects for Quick Add Button validation  \n");fflush(stdout);
						}

						qry_QKaddVld_values[0] = "QuickAddCntrl";
						qry_QKaddVld_values[1] = "QKAddCntrobj";
						if(QRY_execute(CntobjQKAddVld, QKaddVld_entry, qry_QKaddVld_entry, qry_QKaddVld_values, &QKaddVldCntlObj, &QKaddVldCntrlObj_Tags));
						printf(" \n Quick Add Button validation:QKaddVldCntlObj:[%d]",QKaddVldCntlObj); fflush(stdout);
						int iLCS,cntLcs=0;
						int st_count=0;
						 char* class_name=NULL;
						 tag_t *status_list=NULLTAG;

						if (QKaddVldCntlObj>0)
						{
									ITKCALL(WSOM_ask_release_status_list(rev_tag,&st_count,&status_list));
								    printf("\n st_count :%d is\n",st_count);fflush(stdout);

						 for (iLCS=0;iLCS<st_count ;iLCS++ )
							{

									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);

									if(tc_strcmp(class_name,"T5_LcsErcRlzd")!=0) //TZ3.46
										{

											if (tc_strstr(class_name,"Rlzd")!=NULL)
											{
												cntLcs++;
												printf("\n REls count flag :%d is\n",cntLcs);fflush(stdout);

											}

											//break;
										}

							}
						}

						/// ENd Added By Nana to Restrict Quick Add Button

		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName));
		printf("\n\n  roleName1 : %s\n",roleName); fflush(stdout);


				//Addition by Rohit Bhosale Starts for CR-FY23-0184 :

		printf("\nInside BOM Validation by Rohit Before declaration\n");	fflush(stdout);

		tag_t cvprod_CntrlOBJ		=	NULLTAG;
		tag_t *CntrlObject_cvprod	=	NULLTAG;
		tag_t *refs_bomtag			=	NULLTAG;
		tag_t *referencersV			=	NULLTAG;
		tag_t *referencersC			=	NULLTAG;
		tag_t class_idV				=	NULL;
		tag_t class_idC				=	NULL;
		tag_t user_tagR				=	NULLTAG;
		tag_t PGmrelation_type		=	NULLTAG;
		tag_t *secondary_Pobjects	=	NULLTAG;
		tag_t PDML_tag				=	NULLTAG;
		tag_t DMLtaskTag			=	NULLTAG;
		tag_t DMLRevTag1			=	NULLTAG;
		tag_t PDMLTypeTag			=	NULLTAG;
		tag_t latest_parentID		=	NULLTAG; //Rohit BOM
		tag_t latest_revV			=	NULLTAG; //Rohit BOM
		tag_t bom_cv				=	NULLTAG; //Rohit BOM
		tag_t cv_revrule			=	NULLTAG; //Rohit BOM
		tag_t topline_cvbom			=	NULLTAG; //Rohit BOM
		tag_t *cvbom_childs			=	NULLTAG; //Rohit BOM
		tag_t cv_childtag			=	NULLTAG; //Rohit BOM
		

		int cvprod_entries			=	1;
		int	cvprod_found			=	0;
		int jcv						=	0;
		int n_bomrefs				=	0;
		int *n_bomlvls				=	0;
		int n_bomlevels				;
		int sv						=	0;
		int n_referencersV			=   0;
		int n_referencersC			=   0;
		int *levelsV				=	0;
		int *levelsC				=	0;
		int flag1					=	0;
		int sc						=	0;
		int flagDMLattach			=	0;
		int Pn_attchs				=   0;
		int lt						=	0;
		int toplinecvbom_count		=	0;	//Rohit BOM
		int	CVC						=	0;	//Rohit BOM
		int cvchildline_ID			=	0;	//Rohit BOM
		int cvchildline_rev			=	0;  //Rohit BOM
		int cvchildline_designgrp	=	0;	//Rohit BOM

		char	*info1cv			=	NULL;
		char	*cvchild			=	NULL;
		char	*dmlownerparent		=	NULL;
		char	*dmlownerchild		=	NULL;
		char	*cvchilddsggrp		=	NULL;
		char	*taskTempLTV		=	NULL;
		char	**referenced_char	=	NULL;
		char	*class_nameV		=	NULL;
		char	*class_nameC		=	NULL;
		char	*MPartNoV			=	NULL;
		char	*MPartNoC			=	NULL;
		char	*ItemIDV			=	NULL;
		char	*ItemIDC			=	NULL;
		char    **relationsRefV		=	NULL;
		char    **relationsRefC		=	NULL;
		char    *usernameR			=	NULL;
		char	*DmlAnalyst_name	=	NULL;
		char	*useridR			=	NULL;
		char	*vrlsstatus			=   NULL;
		char	*PartRelStatusC		=	NULL;
		char	*childrlsstat		=	NULL;
		char  allclsname[4900]		= { 0 };
		char *qry_cvprodcntrl[1]	= {"SYSCD"};
		char **qry_valuescvprod		= (char **) MEM_alloc(10 * sizeof(char *));
		qry_valuescvprod[0]			= "CVBUBOMCntrlObj";
		char	*TokDMLId			=	NULL;
		char	*DMLItem_id			=	NULL;
		char	*task_id			=	NULL;
		char	*DMLtaskID			=	NULL;
		char	*value				=	NULL;
		DMLtaskID=(char *)MEM_alloc(3000);
		char	*all_tasks			=	NULL;
		char PDMLtype_name[TCTYPE_name_size_c+1];

		char *parentID				=	NULL; //Rohit BOM
		char *parentrevID			=	NULL; //Rohit BOM
		char *latest_parentIDstr	=	NULL; //Rohit BOM
		char *latest_revVstr		=	NULL; //Rohit BOM
		char *cv_ItemID_str			=	NULL; //Rohit BOM
		char *cv_ItemRev_str		=	NULL; //Rohit BOM
		char *cv_designgrp_str		=	NULL; //Rohit BOM
		char alldsggrp[1900]		=	{ 0 }; //Rohit BOM

		char	*ErrorMsgF			= NULL;	//Rohit BOM
		ErrorMsgF = (char	*)MEM_alloc(500);	//Rohit BOM


		printf("\nInside BOM Validation by Rohit After declaration\n");	fflush(stdout); //rev_tag
		ITK_CALL(QRY_find("Control Objects...",&cvprod_CntrlOBJ));
		//printf("\n\n CVBUBOMCntrlObj Query Found\n\n");	fflush(stdout);


		ITK_CALL(QRY_execute(cvprod_CntrlOBJ, cvprod_entries, qry_cvprodcntrl, qry_valuescvprod, &cvprod_found, &CntrlObject_cvprod));
		printf("\n\n  CVBUBOMCntrlObj Control Object SYSCD :%d\n",cvprod_found);	fflush(stdout);

		if(cvprod_found > 0)
		{
			if(tc_strcmp(cp_ChildChkOutValue,"Y")!=0)
			{
				if (((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)) && (tc_strstr(roleName,"STD")==NULL) && (tc_strstr(roleName,"APL")==NULL) && (tc_strstr(roleName,"MBOM")==NULL) && (tc_strstr(roleName,"Support")==NULL)) //MBOM implementation for CV TZ-1.70 Backend Fixes
				{
				POM_get_user(&usernameR,&user_tagR);
				SA_ask_user_identifier2	(user_tagR,&useridR)	;
				printf ("Logged in user for Vehicle attaching functinality : [%s] [%s]\n",useridR,usernameR);fflush(stdout);
				printf("Role Name for the logged in user is [%s]",roleName);fflush(stdout);


				ITK_CALL(AOM_ask_value_string(CntrlObject_cvprod[0],"t5_Userinfo1",&info1cv));
				printf("\n\nUser Information 1 is : %s",info1cv);	fflush(stdout);
				ITK_CALL(AOM_UIF_ask_value(rev_tag,"release_status_list",&vrlsstatus));
				printf("\n Released status for parent is [%s] \n",vrlsstatus); fflush(stdout);

				ITK_CALL(AOM_UIF_ask_value(rev_tag,"item_id",&parentID)); //Rohit BOM
				ITK_CALL(AOM_UIF_ask_value(rev_tag,"item_revision_id",&parentrevID)); //Rohit BOM

				ITK_CALL(ITEM_find_item(parentID,&latest_parentID)); //Rohit BOM
				ITK_CALL(ITEM_ask_latest_rev(latest_parentID,&latest_revV)); //Rohit BOM

				ITK_CALL(AOM_ask_value_string(latest_parentID,"item_id",&latest_parentIDstr)); //Rohit BOM
				ITK_CALL(AOM_ask_value_string(latest_revV,"item_revision_id",&latest_revVstr)); //Rohit BOM

				printf("\n Parent ID and Rev ID is [%s] and [%s] \n",latest_parentIDstr,latest_revVstr); fflush(stdout); //Rohit BOM

				ITK_CALL(AOM_ask_value_string(ChildTagLatestRevt,"current_id",&cvchild));
				ITK_CALL(AOM_ask_value_string(ChildTagLatestRevt,"t5_DesignGrp",&cvchilddsggrp));
				ITK_CALL(AOM_UIF_ask_value(ChildTagLatestRevt,"release_status_list",&childrlsstat));
				printf("\n Released status for child is [%s] \n",childrlsstat); fflush(stdout);

				printf("\n\nParent ID is [%s] and its part Type is [%s]",designRev_id,PartType);	fflush(stdout); //Parent Attributes ==> rev_tag
				printf("\n\nChild ID is [%s] and its Design group is [%s]",cvchild,cvchilddsggrp);	fflush(stdout); //Childs tag ==> ChildTagLatestRevt

				ITK_CALL(WSOM_where_referenced(rev_tag,2,&n_referencersV,&levelsV,&referencersV,&relationsRefV));
				printf("\n WSOM_where_referenced n_referencers count is [%d] \n",n_referencersV); fflush(stdout);

				if(n_referencersV>0)
				{
					for (sv=0;sv<n_referencersV;sv++ )
					{
						//flag1=0;
						printf("\nInside FOR loooop for n_referencersV of Parent\n",class_nameV);fflush(stdout);
						POM_class_of_instance(referencersV[sv],&class_idV);
						POM_name_of_class(class_idV,& class_nameV);

						WSOM_ask_name2(referencersV[sv],&MPartNoV);

						WSOM_ask_object_id_string(referencersV[sv],&ItemIDV);
						printf("\n Item Id for Parent to find DML is ==> [%s]\n",ItemIDV);fflush(stdout);

						//ITK_CALL(AOM_UIF_ask_value(referencersV[sv],"owning_user",&dmlownerparent));
						//printf("\n Owner of DML to which parent is attached is [%s]\n",dmlownerparent);fflush(stdout);

						if(strcmp(class_nameV,"T5_ChangeTaskRevision")==0)
						{
							ITK_CALL(AOM_UIF_ask_value(referencersV[sv],"fnd0ActuatedInteractiveTsks",&taskTempLTV));
							printf("\n primary taskTempLTV is [%s]\n",taskTempLTV);fflush(stdout);

							if(tc_strstr(ItemIDV,"_00") != NULL)  //Assignment need to be added
							{
								printf("\nPaaarent Loop is finished and DML is [%s]\n",ItemIDV); fflush(stdout);

								strcpy(DMLtaskID,"");
								strcpy(DMLtaskID,ItemIDV);

								TokDMLId = tc_strtok(ItemIDV,"_");
								printf("\nDML is : [%s]\n",TokDMLId); fflush(stdout);

								ITK_CALL(ITEM_find_item(TokDMLId,&PDML_tag));

								//ITK_CALL(AOM_ask_value_string(PDML_tag,"current_revision_id",&DMLItem_id)); //T5_DMLTaskRelation

								ITK_CALL(ITEM_ask_latest_rev(PDML_tag,&DMLRevTag1));

								//ITK_CALL(AOM_ask_value_string(DMLRevTag1,"T5_DMLTaskRelation",&all_tasks));

								//printf("\nDMLItem_id id is [%s]\n",DMLItem_id); fflush(stdout);
								//printf("\nall_tasks id is [%s]\n",all_tasks); fflush(stdout);

								//printf("\n After token DML DMLItem_id is : %s\n",DMLItem_id,all_tasks);fflush(stdout);

								ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &PGmrelation_type));
								ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag1,PGmrelation_type,&Pn_attchs,&secondary_Pobjects));
								//ITK_CALL(AOM_ask_value_tags(DMLRevTag1,"T5_DMLTaskRelation",&Pn_attchs,&secondary_Pobjects));

								printf("Count of tasks is : %d",Pn_attchs); fflush(stdout);
								if(Pn_attchs>0)
								{
									for (lt=0;lt<Pn_attchs ;lt++ )
									{
										DMLtaskTag = secondary_Pobjects[lt];
										ITK_CALL(AOM_UIF_ask_value(DMLtaskTag,"item_id",&task_id));

											 char* delimiter = strrchr(task_id, '_');

											 if (delimiter != NULL)
												 {

												   char* value = delimiter + 1;
												   printf("\nLast occurence is [%s]\n", value);

													 if (tc_strcmp(cvchilddsggrp,"00")==0)
													 {												   
														 if(tc_strstr(value,"0E") != NULL)
														 {
															ITK_CALL(AOM_UIF_ask_value(DMLtaskTag,"Analyst",&DmlAnalyst_name));
															printf("\n\n\t\t Parent DML task ID is :[%s] and its Analyst is [%s]",task_id,DmlAnalyst_name);fflush(stdout);
														 }
													 }
													 else if (tc_strstr(value,cvchilddsggrp) != NULL)
														{
															ITK_CALL(AOM_UIF_ask_value(DMLtaskTag,"Analyst",&DmlAnalyst_name));
															printf("\n\nELSE IF loop Parent DML task ID is :[%s] and its Analyst is [%s]",task_id,DmlAnalyst_name);fflush(stdout);
														}
												 }
									}
								}

							}
							break;
						}


					}


				} //Parent References Loop Ends

				//Rohit BOM logic starts

				ITK_CALL(BOM_create_window(&bom_cv));
				ITK_CALL(CFM_find("Latest Working", &cv_revrule));
				ITK_CALL(BOM_set_window_config_rule( bom_cv, cv_revrule));
				ITK_CALL(BOM_set_window_pack_all(bom_cv, true));
				ITK_CALL(BOM_set_window_top_line(bom_cv,latest_parentID,latest_revV,NULLTAG,&topline_cvbom));
				ITK_CALL(BOM_line_ask_child_lines(topline_cvbom,&toplinecvbom_count,&cvbom_childs));

				printf("\nCount of Children present under Vehicle %s is [%d]\n",latest_parentIDstr,toplinecvbom_count); fflush(stdout);

				if(toplinecvbom_count > 0)
				{
					for(CVC = 0 ; CVC < toplinecvbom_count ; CVC++)
					{

						cv_childtag = cvbom_childs[CVC];

						ITK_CALL(BOM_line_look_up_attribute ("bl_item_item_id",&cvchildline_ID));
						ITK_CALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&cvchildline_rev));
						ITK_CALL(BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&cvchildline_designgrp));

						ITK_CALL(BOM_line_ask_attribute_string(cv_childtag, cvchildline_ID, &cv_ItemID_str));
						ITK_CALL(BOM_line_ask_attribute_string(cv_childtag, cvchildline_rev, &cv_ItemRev_str));
						ITK_CALL(BOM_line_ask_attribute_string(cv_childtag, cvchildline_designgrp, &cv_designgrp_str));

						printf("\nChild ID already present under Vehicle , its Rev ID and its Design Group is [%s] , [%s] and [%s]\n",cv_ItemID_str,cv_ItemRev_str,cv_designgrp_str); fflush(stdout);

						//tc_strcpy(alldsggrp,"");
						tc_strcat(alldsggrp,cv_designgrp_str);
						tc_strcat(alldsggrp,",");

						printf("\nAll Design group for child present in BOM are : [%s]\n",alldsggrp); fflush(stdout);

					}
				}

				printf("\nPrinting Design Group of all childs inside BOM outside loop ======>>>>>>> %s\n",alldsggrp); fflush(stdout);


				//Rohit BOM logic ends

				if ((tc_strcmp(PartType,"V")==0) && (tc_strstr(vrlsstatus,"ERC Review") != NULL))
				{
					printf("\nParent part type is vehicle and it is in ERC Review\n"); fflush(stdout);

					if(tc_strstr(info1cv,cvchilddsggrp) != NULL)
					{
						printf("\nPart Type is vehicle and is in erc review and control object matches and is attached to task : [%s]\n",DMLtaskID); fflush(stdout);
						//printf("\n Already Present Design Groups : [%s]\n",tc_strstr(alldsggrp,cvchilddsggrp)); fflush(stdout);
						
						if(tc_strstr(alldsggrp,cvchilddsggrp) == NULL) //Rohit BOM												
						{							
							if(tc_strstr(DMLtaskID,"_00") != NULL)
							{
								if (tc_strcmp(taskTempLTV,"Add solution items")==0)
								{
									if(tc_strstr(childrlsstat,"ERC Released") != NULL)
									{
										if(tc_strstr(DmlAnalyst_name,usernameR) != NULL) //Remove condition
										{
											printf("\nAddition of part in Vehicle is successful\n"); fflush(stdout);
										}
										else
										{
											printf("\nDML Analyst and Logged In user sesssion does not match. [%s] and [%s]\n",DmlAnalyst_name,usernameR); fflush(stdout);
											//flagDMLattach=1;
											EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot modify BOM for checked-in part as DML Analyst and Logged In user sesssion does not match.");
											return ITK_err;
										}
									}
									else
									{

										printf("\n\n You cannot modify BOM for checked-in part as part you are trying to add is not Released\n"); fflush(stdout);
										//flagDMLattach=1;
										EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot modify BOM for checked-in part as part you are trying to add is not Released");
										return ITK_err;
									}
								}
								else
								{
									printf("\n\n  Task is not at Add solution items task\n"); fflush(stdout);
									//flagDMLattach=1;
									EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot modify BOM for checked-in Vehicle as Task is not at Add solution items task");
									return ITK_err;
								}
							}
							else
							{
								printf("\nYou cannot modify BOM for checked-in part as parent (Vehicle) is not attached to DML\n"); fflush(stdout);
								//flagDMLattach=1;
								EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot modify BOM for checked-in part as parent (Vehicle) is not attached to DML");
								return ITK_err;
							}
						}
						else
						{
							tc_strcpy(ErrorMsgF,"");
							tc_strcat(ErrorMsgF,"Child part with Design Group [");
							tc_strcat(ErrorMsgF,cvchilddsggrp);
							tc_strcat(ErrorMsgF,"] is already present under Vehicle.");
							printf("\nChild part with Design Group [%s] is already present under Vehicle.\n",cvchilddsggrp); fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorMsgF);
							return ITK_err;
						}
					}
					else
					{
						printf("\nDesign group of child does not match with 00,16,21,50\n"); fflush(stdout);
						flagDMLattach=1;
					}
				}
				else
				{
					printf("\nPart type is not Vehicle or it is not in ERC Review stage\n"); fflush(stdout);
					flagDMLattach=1;
				}



			}//Infodba Access LOOP

			} //Checked-out value loop

		} //Control Object loop
		else
		{
			flagDMLattach=1;
		}

		//Addition by Rohit Bhosale Ends for CR-FY23-0184

		if(tc_strcmp(objecttype,"Design Revision")==0 || tc_strcmp(objecttype,"T5_SparKitRevision")==0)
		{
			if( (!strstr(roleName,"APL")) || (!strstr(roleName,"MBOM")))     //MBOM implementation for CV TZ-1.69
			{
				printf("\n\n  inside roleName1111 : %s\n",roleName); fflush(stdout);
				if(tc_strcmp(roleName,"Colour_Designer")!=0)
				{
					printf("\n\nflagDMLattach value is [%d]\n",flagDMLattach); fflush(stdout);
					if(tc_strcmp(cp_ChildChkOutValue,"Y")==0)
					{
						printf("\nPart is already checked-out...........\n");fflush(stdout);
						if((tc_strcmp(PartType,"C")==0) && ((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)))
						{
							printf("\nPartType is Cmponent & username is ---> %s\n",username);fflush(stdout);
							if(tc_strstr(DesignGrp,t5_DesignGrp)!=NULL) //go inside
							{
								printf("\nDesignGrp of part found in set of String..\n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s3(EMH_severity_error,ITK_err,"\n Component can't have structure","please check PartType of",Item_id_par);
								return ITK_err;
							}else
							{
								if(tc_strcmp(ChildPartType,"D")!=0)
								{
									EMH_clear_errors();
									EMH_store_error_s3(EMH_severity_error,ITK_err,"\n Component can't have structure","please check PartType of",Item_id_par);
									return ITK_err;
								}else
								{
									printf("\ncomponent for Barrel-3 with part designation is 69..\n");fflush(stdout);
								}
							}
						}
					}
					else if (((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)) && (tc_strstr(roleName,"STD")==NULL) && (tc_strstr(roleName,"APL")==NULL) && (tc_strstr(roleName,"MBOM")==NULL) && (tc_strstr(roleName,"Support")==NULL) && flagDMLattach==1) //MBOM implementation for CV TZ-1.70 Backend Fixes
					{
						printf("\n\n  Inside LOADER/INFODBA loop\n"); fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Child parts can't be added to Checked-in/ERC Review part");
						return ITK_err;

					}
				}
			}else if (tc_strstr(roleName,"Support")==NULL)
			{

				int count_DML=0;
				int d=0;
				tag_t	  		dml_task_rel_type	=	NULLTAG;
				tag_t*			DMtaskRevision			= NULLTAG;
				tag_t*			DMLRevision			= NULLTAG;
				tag_t			prtTask1			= NULLTAG;
				tag_t			DMLRev			= NULLTAG;
				tag_t			tsk_dml_rel_type			= NULLTAG;
				char	*TaskDMLNumberr	= NULL;
				char	*releasest_name	= NULL;
				char	*ECNType	= NULL;


				tag_t		*status_list =	NULLTAG;
				int st_count=0;
				int iLCS1=0;
				int releaseStatusFnd=0;

             //rev_tag

			 printf("\n Going to Check APL rest Task :");fflush(stdout);

			ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&dml_task_rel_type));
			ITK_CALL(GRM_list_primary_objects_only(rev_tag,dml_task_rel_type,&count_DML,&DMtaskRevision));
		if (count_DML>0)
		{
			for (d=0;d<count_DML ;d++ )
			{

					prtTask1=	DMtaskRevision[d];

				ITK_CALL( AOM_ask_value_string(prtTask1,"item_id",&TaskDMLNumberr));
				printf("\n TaskDMLNumberr : %s",TaskDMLNumberr);fflush(stdout);
				if (tc_strstr(TaskDMLNumberr,"AM")!=NULL||tc_strstr(TaskDMLNumberr,"SM")!=NULL)
				{

				  ITK_CALL(WSOM_ask_release_status_list(prtTask1,&st_count,&status_list));


				releasest_name	=	NULL;
				for (iLCS1=0; iLCS1< st_count ; iLCS1++)
				{

				ITK_CALL(AOM_ask_value_string(status_list[iLCS1],"object_name",&releasest_name));
				printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
				//if(tc_strcmp(releasest_name,"T5_LcsAPLWrkg")==0)
			 if (tc_strstr(releasest_name,"Rlzd")==NULL)
				{

				ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					ITK_CALL(GRM_list_primary_objects_only(prtTask1,tsk_dml_rel_type,&count_DML,&DMLRevision));

					if (count_DML>0)
					{
						DMLRev=	DMLRevision[0];
						ITK_CALL( AOM_ask_value_string(DMLRev,"t5_EcnType",&ECNType));
						if (tc_strcmp(ECNType,"APLSTR")==0)
						{
							 releaseStatusFnd++;
						}
						else if (tc_strstr(TaskDMLNumberr,"SM")!=NULL)
						{
							releaseStatusFnd++;
						}

					}

				}
				}

			}
			  }


	}

		if (releaseStatusFnd==1)
				{
		            printf("\n Allowed to do Add part as Assy is attached to APL Rest DML %s\n",releasest_name);fflush(stdout);

				}
				else if (releaseStatusFnd==0)
				{
					if((tc_strcmp(username,"infodba")==0) || (tc_strcmp(username,"loader")==0)|| (tc_strcmp(username,"aplloader")==0))
					{
						printf("\n Allowed to do Add part as User is Infodba or loader \n");fflush(stdout);

					}
					else
					{

					if (QKaddVldCntlObj==0)
					{
						printf("\n Quick Add  control object not Live \n");fflush(stdout);

					}
					else
						{
						if (cntLcs>0)
						{
							     EMH_store_error_s1(EMH_severity_error,ITK_err,"You can not add parts in APL View withouth Restructuring DML");

								return ITK_err;
						}


						}

					}
				}
		}



		}
		if(tc_strcmp(objecttype,"T5_ClrPartRevision")==0)
		{
		if (QKaddVldCntlObj>0)
			{


			int colrpartflg,st_countc=0;
			int count_DMLC,dc,iLCS1C=0;
			char	*TaskDMLNumberrC =	NULL;
			char	*releasest_nameC =	NULL;

			tag_t   dml_task_rel_typeC		=	NULLTAG;
			tag_t   prtTask1C		=	NULLTAG;
			tag_t   *DMtaskRevisionC		=	NULLTAG;
			tag_t*    status_listc =NULLTAG;

            ITK_CALL(GRM_find_relation_type("CMReferences",&dml_task_rel_typeC));
			ITK_CALL(GRM_list_primary_objects_only(rev_tag,dml_task_rel_typeC,&count_DMLC,&DMtaskRevisionC));
		if (count_DMLC>0)
			{
		for (dc=0;dc<count_DMLC ;dc++ )
				{

					prtTask1C=	DMtaskRevisionC[dc];

				ITK_CALL( AOM_ask_value_string(prtTask1C,"item_id",&TaskDMLNumberrC));
				printf("\n TaskDMLNumberrC : %s",TaskDMLNumberrC);fflush(stdout);
				if (tc_strstr(TaskDMLNumberrC,"AM")!=NULL||tc_strstr(TaskDMLNumberrC,"SM")!=NULL)
				{

				  ITK_CALL(WSOM_ask_release_status_list(prtTask1C,&st_countc,&status_listc));


				releasest_nameC	=	NULL;
				for (iLCS1C=0; iLCS1C< st_countc ; iLCS1C++)
				  {
						ITK_CALL(AOM_ask_value_string(status_listc[iLCS1C],"object_name",&releasest_nameC));
				           printf("\n releasest_nameC: %s\n",releasest_nameC);fflush(stdout);

						    if (tc_strstr(releasest_nameC,"Rlzd")==NULL)
					        {
								colrpartflg++;

							}

				  }
				}
			}

		    }

          if (tc_strstr(roleName,"Support")!=NULL || (tc_strcmp(username,"infodba")==0) || (tc_strcmp(username,"loader")==0)|| (tc_strcmp(username,"aplloader")==0))
			{

			  printf("\n Allowed to do Add part as User is Infodba or loader \n");fflush(stdout);


		    }
			else
			{

				if (QKaddVldCntlObj==0)
					{
						printf("\n Quick Add  control object not Live \n");fflush(stdout);

					}
					else
						{
						if (colrpartflg==0)
						{

						if (cntLcs>0)
							{
			 EMH_store_error_s1(EMH_severity_error,ITK_err,"You can not add parts in APL View directly in color Assembly,do APL restructuring of Non Color Revision");
			 return ITK_err;
							}
						}
						}

			}
		}


		}
		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			printf("\n DURA FIT BOM PROCESS CHECK VALIDATION PARENT PART OBJECT TYPE IS=>[%s]\n",objecttype);fflush(stdout); // parent object type
			printf("\n DURA FIT BOM PROCESS CHECK VALIDATION CHILD PART OBJECT TYPE IS=>[%s]\n",sObjectTypeModulet);fflush(stdout); // child part object type
			printf("\n\t ChildPartType => %s\n",ChildPartType);fflush(stdout); // child part parttype
			printf("\n  Child Part Number ---->[%s] \n",Item_id_par); fflush(stdout);
			if(tc_strcmp(objecttype,"Design Revision")==0)
			{
				if(tc_strcmp(sObjectTypeModulet,"T5_DuraFitPartRevision")==0)
				{
					EMH_store_error_s3(EMH_severity_error,ITK_err,"Dura Fit part no ", Item_id_par," is not allowed to attach under Design Revision BOM!!");
					return ITK_err;
				}
			}
			if(tc_strcmp(objecttype,"T5_DuraFitPartRevision")==0)
			{
				if(tc_strcmp(sObjectTypeModulet,"Design Revision")==0 && tc_strcmp(ChildPartType,"V")!=0)
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Other Than Vehicle under Durafit is not allowed!!");
					return ITK_err;
				}
			}
		}
	}

	//Vitthal :START: Validation on Architecture Module Revision Address and Module Address.
	//POM_get_user(&username,&user_tag);
	if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
	{
		printf("\n\n  BomLineModuleValidaion calling.."); fflush(stdout);
		if((rev_tag != NULLTAG) && (BomLineModuleValidaion(rev_tag,item_tag)>0) )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Architecture Module Revision Address and Module Address is not same.");
			return ITK_errStore;
		}
	}
	else
	{
		printf("\n\t BYPASS:Architecture Module Revision Address and Module Address Validaion for infodba and loader Login\n Cureent Login:%s ",username);fflush(stdout);
	}
	//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.


	return error_code;
}

//********Added by Kalpesh**********(Post_action//30th_june_2018)

extern DLLAPI int save_method_qty_updt(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;
	int			child_attr			= 0;
	int			Item_attr			= 0;
	int			Rev_attr			= 0;
	int			bl_abs_xform		= 0;
	int			bl_relative_xform	= 0;
	char		*child_qty			= NULL;
	char		*Item_id			= NULL;
	char		*Item_rev_id		= NULL;
	char		*child_part_type	= NULL;
	char		*child_obj_type		= NULL;
	char		*parent_obj_type	= NULL;
	char		*child_item_id2		= NULL;
	char		*child_item_id		= NULL;
	char		*ApplnOwner			= NULL;
	char		*child_abs_xform	= NULL;
	char		*child_relv_xform	= NULL;
	char		*child_rev_id		= NULL;
	tag_t		revision_tag		= NULLTAG;
	tag_t		parent_tag			= va_arg(args, tag_t);
	tag_t		child_tag			= va_arg(args, tag_t);
	tag_t		child_rev_tag		= va_arg(args, tag_t);
	tag_t		bv_tag				= va_arg(args, tag_t);
	char*		occ_type			= va_arg(args, char*);
	tag_t*		child_bline_tag		= va_arg(args, tag_t*);

	if(BOM_line_look_up_attribute ("bl_item_item_id",&Item_attr))PrintErrorStack();
	if(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Rev_attr))PrintErrorStack();

	if(BOM_line_ask_attribute_string(parent_tag, Item_attr, &Item_id))PrintErrorStack();
	if(BOM_line_ask_attribute_string(parent_tag, Rev_attr, &Item_rev_id))PrintErrorStack();

	if(ITEM_find_rev(Item_id,Item_rev_id,&revision_tag))PrintErrorStack();

	if(AOM_ask_value_string(revision_tag,"object_type",&parent_obj_type));
	printf("\n\t Parent_bomline => %s\n",parent_obj_type);fflush(stdout);

	//RRR: TCUA 1.43 - START: Add -90 Degree rotation T-matrix for ProE modules based on application owner while attaching/saving Architecture node
	if (child_rev_tag == NULLTAG)
	{
		if(BOM_line_ask_attribute_string(child_bline_tag[0], Item_attr, &child_item_id2))PrintErrorStack();
		if(BOM_line_ask_attribute_string(child_bline_tag[0], Rev_attr, &child_rev_id))PrintErrorStack();

		printf("\n\t 1...child_item_id2 => %s \n\t child_rev_id => %s\n",child_item_id2,child_rev_id);fflush(stdout);

		if(ITEM_find_rev(child_item_id2,child_rev_id,&child_rev_tag))PrintErrorStack();
	}
	//RRR: TCUA 1.43 - END: Add -90 Degree rotation T-matrix for ProE modules based on application owner while attaching/saving Architecture node

	if(AOM_ask_value_string(child_rev_tag,"t5_PartType",&child_part_type));
	if(AOM_ask_value_string(child_rev_tag,"object_type",&child_obj_type));
	if(AOM_ask_value_string(child_rev_tag,"item_id",&child_item_id));

	printf("\n\t ChildPartType => %s \n\t child_obj_type => %s\n",child_part_type,child_obj_type);fflush(stdout);

	if(tc_strcmp(parent_obj_type,"T5_ArchModuleRevision")==0)
	{
		printf("\n\t Inside the left object at------------>>>>>>>>=> %s\n",parent_obj_type);fflush(stdout);

		if((tc_strcmp(child_obj_type,"Design Revision")==0) && (tc_strcmp(child_part_type, "M") == 0))
		{
			if(BOM_line_look_up_attribute ("bl_quantity",&child_attr))PrintErrorStack();
			if(BOM_line_ask_attribute_string (child_bline_tag[0], child_attr, &child_qty))PrintErrorStack();
			if(tc_strcmp(child_qty, "0") == 0 || tc_strlen(child_qty) == 0)
			{
				if(AOM_set_value_string(child_bline_tag[0], "bl_quantity", "1") != ITK_ok);PrintErrorStack();
				printf("\nQuantity set to 1\n");fflush(stdout);
			}

			//RRR: TCUA 1.43 - START: Add -90 Degree rotation T-matrix for ProE modules based on application owner while attaching/saving Architecture node
			if( AOM_ask_value_string(child_bline_tag[0],"t5_ApplicationOwner",&ApplnOwner)!=ITK_ok);
			printf("\n\t [%s] Right Object's ApplicationOwner ---->[%s] \n",child_item_id,ApplnOwner); fflush(stdout);

			if((tc_strcmp(ApplnOwner,"ProEAsm")==0) || (tc_strcmp(ApplnOwner,"ProEPart")==0) || ((strlen(ApplnOwner)==0)&&((tc_strcmp(subString(child_item_id,4,1),"C")==0)||(tc_strcmp(subString(child_item_id,4,1),"P")==0))) )
			{
				tag_t   qryTag = NULLTAG;
				tag_t   *CntrolObjectTag = NULLTAG;
				char	*info9r	= NULL;
				int     n_entry    = 1;
				int     rsltCount  =  0;
				char    *qry_entry[1]  = {"SYSCD"};
				char    **qry_values     =  (char **) MEM_alloc(10 * sizeof(char *));

				if(QRY_find("ControlObjects", &qryTag));
				if (qryTag)
				{
					//printf("\n Eff:Found Query ControlObjects ");
					fflush(stdout);
				}
				else
				{
					printf("\n Eff:Not Found Query ControlObjects \n");
					fflush(stdout);
				}
				if (qryTag)
				{
					printf("\n Found Query ControlObjects... ");fflush(stdout);
					qry_values[0] = "ERCVali";
					if(QRY_execute(qryTag, n_entry, qry_entry, qry_values, &rsltCount, &CntrolObjectTag));
					printf("\t rsltCount :%d:", rsltCount); fflush(stdout);
					if(rsltCount > 0)
					{
						if (AOM_ask_value_string(CntrolObjectTag[0],"t5_Userinfo9",&info9r)!=ITK_ok)   PrintErrorStack();
						printf("\t info9r is = [%s] \n", info9r);fflush(stdout);
					}
				}
				if (tc_strcmp(info9r,"MATRIXON")==0)
				{
					printf("\n\t Dropping ProE Module as Right Object "); fflush(stdout);

					if(BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&bl_abs_xform))PrintErrorStack();
					if(BOM_line_ask_attribute_string (child_bline_tag[0], bl_abs_xform, &child_abs_xform)) PrintErrorStack();
					if(BOM_line_look_up_attribute ("bl_plmxml_occ_xform",&bl_relative_xform))PrintErrorStack();
					if(BOM_line_ask_attribute_string (child_bline_tag[0], bl_relative_xform, &child_relv_xform)) PrintErrorStack();

					printf("\n\t child_abs_xform:[%s]   child_relv_xform:[%s] ",child_abs_xform,child_relv_xform); fflush(stdout);

					if (tc_strcmp(child_abs_xform,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1") == 0)
					{
						printf("== -90 Degree T-matrix is rotated..[%s] [%s]",child_item_id,ApplnOwner); fflush(stdout);
						if ((tc_strcmp(child_relv_xform,"") == 0) || (tc_strcmp(child_abs_xform,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1") == 0))
						{
							printf("--Updating -90 roatation for RelativeMatrix...\n"); fflush(stdout);
							if(BOM_line_set_attribute_string(child_bline_tag[0], bl_relative_xform, "1 0 0 0 0 0 1 0 0 -1 0 0 0 0 0 1")) PrintErrorStack();
							//if(BOM_line_set_attribute_string(child_bline_tag[0], bl_abs_xform, "1 0 0 0 0 0 1 0 0 -1 0 0 0 0 0 1") != ITK_ok);PrintErrorStack();
						}
					}
				}
			}
			//RRR: TCUA 1.43 - END: Add -90 Degree rotation T-matrix for ProE modules based on application owner while attaching/saving Architecture node
		}
	}
	// Ashish: UA1.46 Start - Quantity set to 0 if part type of child revision is IFD
	else if(tc_strcmp(parent_obj_type,"Design Revision")==0)
	{
		printf("\n\t BOMLine_Add-post action:  %s\n",parent_obj_type);fflush(stdout);

		if((tc_strcmp(child_obj_type,"Design Revision")==0) && (tc_strcmp(child_part_type, "IFD") == 0))
		{
			if(BOM_line_look_up_attribute ("bl_quantity",&child_attr))PrintErrorStack();
			if(BOM_line_ask_attribute_string (child_bline_tag[0], child_attr, &child_qty))PrintErrorStack();
			//if(tc_strcmp(child_qty, "1") == 0)
			//{
				printf("\n If part type of child part is IFD then set quantity as 0, Quantity set to 0\n");fflush(stdout);
				if(AOM_set_value_string(child_bline_tag[0], "bl_quantity", "0") != ITK_ok);PrintErrorStack();
				printf("\n Quantity set to 0 \n");fflush(stdout);
			//}
		}
	}
	// Ashish: UA1.46 End - Quantity set to 0 if part type of child revision is IFD

	return error_code;
}
//End ******(kalpesh)

/******************************************************************************************
*   Function name			:	arch_module_access_fun
*   Description				:	This function provides the access to su_mdm user only
*								while creating Architecture module.
*
*	Date				Modified By				Modification Notes
*	06/05/2019			Kalpesh Gondhali		1.45:
******************************************************************************************/
extern DLLAPI int arch_module_access_fun(METHOD_message_t *msg, va_list args)
{
	int				error_code					= ITK_ok;
    tag_t			objTag						= va_arg(args, tag_t);
	tag_t			objTypeTag					= NULLTAG;
	tag_t			user_tag					= NULLTAG;

	char			*username					= NULL;
	char			type_name[TCTYPE_name_size_c+1];

	char			*group_name					=NULL;
	tag_t			group_tag					=NULLTAG;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username, &user_tag);
	POM_ask_group(&group_name, &group_tag);
	printf("\nUser name is:%s", username);
	printf("\nPart type is:%s", type_name);

	if(strcmp(type_name, "T5_ArchModuleRevision") == 0)
		{
			//if(tc_strcmp(username, "su_mdm") != 0)
		if(tc_strcmp(group_name, "Master_Data_Mgmt") != 0)
			{
				printf("\nUnable to create part, as only user having group (Master_Data_Mgmt) having access to create this object.\n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, as only user having group (Master_Data_Mgmt) having access to create this object.");
				return ITK_err;
			}
		}
	return error_code;
}

/******************************************************************************************
*   Function name			:	platform_access_fun
*   Description				:	This function provides access to su_mdm user only
*								while creating platform.
*
*	Date				Modified By				Modification Notes
*	06/05/2019			Kalpesh Gondhali		1.45:
******************************************************************************************/
extern DLLAPI int platform_access_fun(METHOD_message_t *msg, va_list args)
{
	int				error_code					= ITK_ok;
    tag_t			objTag						= va_arg(args, tag_t);
	tag_t			objTypeTag					= NULLTAG;
	tag_t			user_tag					= NULLTAG;
	char			*group_name					=NULL;
	tag_t			group_tag					=NULLTAG;

	char			*username					= NULL;
	char			type_name[TCTYPE_name_size_c+1];

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username, &user_tag);
	POM_ask_group(&group_name, &group_tag);
	printf("\nUser name is:%s", username);
	printf("\nPart type is:%s", type_name);

	if(strcmp(type_name, "T5_PlatformRevision") == 0)
		{
		if(tc_strcmp(group_name, "Master_Data_Mgmt") != 0)
			{
				printf("\nUnable to create part, as only user having Group (Master_Data_Mgmt) having access to create this object.\n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, as only user having Group (Master_Data_Mgmt) having access to create this object.");
				return ITK_err;
			}
		}
	return error_code;
}

/******************************************************************************************
*   Function name			:	bomline_cut_method
*   Description				:	This function provides access to su_mdm user only to
*								cut the bomline from Structure.
*
*	Date				Modified By				Modification Notes
*	13/06/2019			Kalpesh Gondhali		1.46:
******************************************************************************************/
extern DLLAPI int bomline_cut_method(METHOD_message_t *msg, va_list args)
{
	int			error_code					= ITK_ok;
	int			blobjType					= 0;
	int			line_name					= 0;
	int			parent_nm					= 0;
	int			modadd						= 0;
	int			attr_id						= 0;
	int			rev_attr_id					= 0;
	int			rel_stat					= 0;
	int			n_parents					= 0;
	int			*levels						= 0;

	int			designer_found				= 0;
	int			manager_found				= 0;

	char		*userid						= NULL;
	char		*mod_addr					= NULL;
	char		*objType					= NULL;
	char		*username					= NULL;
	char		*bcm_type_name				= NULL;
	char		*rev_type_name				= NULL;
	char		*bcm_username				= NULL;
	char		*bomline_objType			= NULL;
	char		*bomline_name				= NULL;
	char		*parent_string				= NULL;
	char		*bcm_release_status			= NULL;

	char		*designer_role				= NULL;
	char		*manager_role				= NULL;

	char		*part						= NULL;
	char		*rev						= NULL;
	char		*group_name					=NULL;
	tag_t		group_tag					=NULLTAG;

	tag_t		*list;
	tag_t		*parents					= NULL;
	tag_t		window						= NULLTAG;
	tag_t		user_tag					= NULLTAG;
	tag_t		top_bom_line				= NULLTAG;

	tag_t		rev_tag						= NULLTAG;
	tag_t		objTypeTag					= NULLTAG;
	tag_t		bcm_user_tag				= NULLTAG;
	tag_t		bomline_tag					= va_arg(args, tag_t);

	//if (TCTYPE_ask_object_type(bomline_tag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	//if (TCTYPE_ask_name2(objTypeTag,&bcm_type_name)!=ITK_ok);PrintErrorStack();
	//if (AOM_UIF_ask_value(bomline_tag, "bl_item_object_type", &bcm_type_name)!=ITK_ok);PrintErrorStack();

	if(BOM_line_ask_window(bomline_tag,&window))PrintErrorStack();
		if(window != NULLTAG)
		{
			if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
			if(top_bom_line != NULLTAG)
			{
				if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType))PrintErrorStack();
				if(BOM_line_ask_attribute_string(top_bom_line, blobjType, &bomline_objType))PrintErrorStack();
				printf("\nTop_Bomline obj_type:%s", bomline_objType);
				if (tc_strcmp(bomline_objType,"T5_PlatformRevision") == 0)
				{
					if (BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok);PrintErrorStack();
					if (BOM_line_ask_attribute_string(bomline_tag, attr_id, &bcm_type_name)!=ITK_ok);PrintErrorStack();
					printf("\nChild_Bomline obj_type:%s", bcm_type_name);

					POM_get_user(&bcm_username, &bcm_user_tag);
					POM_ask_group(&group_name, &group_tag);

					printf("\nbcm_user_name is:%s", bcm_username);

					if(tc_strcmp(bcm_type_name, "T5_ArchModuleRevision") == 0)
					{
						if((tc_strcmp(group_name, "Master_Data_Mgmt") != 0) && (tc_strcmp(username,"infodba")!=0))
						{
							printf("\nOnly user having (Master_Data_Mgmt ) group can cut the Bomline.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error, ITK_err, "Only user having (Master_Data_Mgmt ) group can cut the Bomline.");
							return ITK_err;
						}
					}
				}
			}
		}
		/*if(BOM_line_ask_window(bomline_tag,&window))PrintErrorStack();
		if(window != NULLTAG)
		{
			if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
			if(top_bom_line != NULLTAG)
			{*/
		printf("\nInside parent check...!!");
		if(BOM_line_look_up_attribute ("bl_formatted_parent_name",&parent_nm))PrintErrorStack();
		if(BOM_line_ask_attribute_string(bomline_tag, parent_nm, &parent_string))PrintErrorStack();
		printf("\nparent_str:%s", parent_string);

		/*part = strtok(parent_string, "/");
		rev =  strtok(NULL, " ");
		printf("\npart:%s Rev:%s", part, rev);

		if(ITEM_find_rev(part, rev, &rev_tag))PrintErrorStack();
		if(AOM_UIF_ask_value(rev_tag, "object_type", &objType))PrintErrorStack();
		printf("\nObj_type:%s", objType);*/

//		if (tc_strcmp(objType,"Architecture Module Revision") == 0)
//			{
		if(tc_strstr(parent_string, "X4M") != NULL)
			{
//		if(PS_where_used_all(bomline_tag,1,&n_parents,&levels,&parents))PrintErrorStack();
//		{
//			if(n_parents > 0)
//			{
//				if(BOM_line_look_up_attribute ("bl_line_name",&line_name))PrintErrorStack();
//				if(BOM_line_ask_attribute_string(parents[0], line_name, &bomline_name))PrintErrorStack();
//				printf("\nBomline_name:%s\n", bomline_name);
//
//				if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType))PrintErrorStack();
//				if(BOM_line_ask_attribute_string(parents[0], blobjType, &bomline_objType))PrintErrorStack();
//				printf("\nTop_Bomline obj_type:%s\n", bomline_objType);
//				if (tc_strcmp(bomline_objType,"T5_ArchModuleRevision") == 0)
//				{
					if (BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok);PrintErrorStack();
					if (BOM_line_ask_attribute_string(bomline_tag, attr_id, &bcm_type_name)!=ITK_ok);PrintErrorStack();
					if (BOM_line_look_up_attribute("bl_Design_t5_RevPartType", &rev_attr_id)!=ITK_ok);PrintErrorStack();
					if (BOM_line_ask_attribute_string(bomline_tag, rev_attr_id, &rev_type_name)!=ITK_ok);PrintErrorStack();
					if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&rel_stat))PrintErrorStack();
					if(BOM_line_ask_attribute_string(bomline_tag, rel_stat, &bcm_release_status))PrintErrorStack();

					if (tc_strcmp(bcm_type_name,"Design Revision") == 0 && tc_strcmp(rev_type_name,"Module") == 0)
					{
						if(tc_strstr(bcm_release_status,"Release") != NULL)
						{
							POM_get_user(&username,&user_tag);
							POM_ask_group(&group_name, &group_tag);
							SA_ask_user_identifier2	(user_tag,&userid);
							printf ("\nLogged in user:%s %s\n",userid, username);fflush(stdout);
							if((tc_strcmp(group_name,"Master_Data_Mgmt")!=0) && (tc_strcmp(username,"infodba")!=0))
							{
								printf("\n Released Part, bomline cut not allowed:%s %s\n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"\nBomline cut not allowed, Module is already released");
								return ITK_err;
							}
						}
						else //review or working
						{
							POM_get_user(&username,&user_tag);
							POM_ask_group(&group_name, &group_tag);
							SA_ask_user_identifier2	(user_tag,&userid);
							printf ("\nLogged in user:%s %s\n",userid, username);fflush(stdout);
							//if((tc_strcmp(username,"su_mdm")!=0) && (tc_strcmp(username,"infodba")!=0))
							if((tc_strcmp(group_name,"Master_Data_Mgmt")!=0) && (tc_strcmp(username,"infodba")!=0))
							{
								if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd))PrintErrorStack();
								if(modadd > 0)
								{
									if(BOM_line_ask_attribute_string(bomline_tag, modadd, &mod_addr))PrintErrorStack();
									printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
									if(mod_addr != NULL && strlen(mod_addr) > 0)
									{
										designer_role = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Designers")) * sizeof(char));
										strcpy(designer_role,mod_addr);
										strcat(designer_role,"_Designers");
										manager_role  = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Managers")) * sizeof(char));
										strcpy(manager_role,mod_addr);
										strcat(manager_role,"_Managers");
										printf("\nsearch for role:%s OR %s\n",designer_role,manager_role);fflush(stdout);

										if(SA_find_groupmember_by_rolename(designer_role,"ERC_Designers_Group",userid,&designer_found,&list))PrintErrorStack();
										if(SA_find_groupmember_by_rolename(manager_role,"ERC_Designers_Group",userid,&manager_found,&list))PrintErrorStack();
										printf("\n designer_found:%d manager_found:%d\n",designer_found,manager_found); fflush(stdout);
										if(designer_found == 0 && manager_found == 0)
										{
											printf("\nYou don't have access to cut the bomline...!!\n");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_err,"\nYou don't have access to cut the bomline.");
											return ITK_err;
										}
									}
									else
									{
										printf("\nModule Address is blank, hence cannot cut the bomline...!!\n");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\nModule Address is blank, hence cannot cut the bomline.");
										return ITK_err;

									}
								}
								else
								{
									printf("\nModule Address not found, hence cannot cut the bomline...!!\n");fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"\nModule Address not found, hence cannot cut the bomline.");
									return ITK_err;
								}
							}
						}
					}
				//}
			//}
		}
	return error_code;
}


/******************************************************************************************
*   Function name			:	prop_bl_quantity_check
*   Description				:	This function provides access to su_mdm user only to
*								update the bl_quantity from Platform Structure.
*
*	Date				Modified By				Modification Notes
*	17/06/2019			Kalpesh Gondhali		1.46:
******************************************************************************************/
extern DLLAPI int prop_bl_quantity_check(METHOD_message_t *msg, va_list args)
{
	int			error_code					= ITK_ok;
	int			modadd						= 0;
	int			blobjType					= 0;
	int			blrelease					= 0;
	int			child_blobjType				= 0;

	int			attr_id						= 0;
	int			line_name					= 0;
	int			parent_nm					= 0;
	int			rev_attr_id					= 0;
	int			rel_stat					= 0;
	int			designer_found				= 0;
	int			manager_found				= 0;
	int			n_parents					= 0;
	int			*levels						= 0;
	int			child_attr			= 0;
	char		*child_qty			= NULL;

	char		*mod_addr					= NULL;
	char		*objType					= NULL;
 	char		*item_id					= NULL;
 	char		*rev_id						= NULL;
 	char		*userid						= NULL;
 	char		*username					= NULL;
	char		*bomline_objType			= NULL;
	char		*topBomLineRelease			= NULL;
	char		*bomline_name				= NULL;
	char		*child_bomline_objType		= NULL;
	char		*bcm_type_name				= NULL;
	char		*rev_type_name				= NULL;
	char		*bcm_username				= NULL;
	char		*parent_string				= NULL;
	char		*bcm_release_status			= NULL;

	char		*designer_role				= NULL;
	char		*manager_role				= NULL;

	char		*part						= NULL;
	char		*rev						= NULL;
	char		*group_name					=NULL;
	tag_t		group_tag					=NULLTAG;

	tag_t		*list;
	tag_t		*parents					= NULL;
	tag_t		rev_tag						= NULLTAG;
	tag_t		window						= NULLTAG;
	tag_t		user_tag					= NULLTAG;
	tag_t		top_bom_line				= NULLTAG;

	char* prop_value						=NULL;
	tag_t prop_tag							=NULLTAG;

	char *ctrlQryEnt[2]		= {"SYSCD", "SUBSYSCD"};
	char *ctrlQryVal[2]		= {"PltArchMQty", "PltArchMQtyy"};
	tag_t TagQryCtrlObjj		= NULLTAG;
	tag_t *cntr_objj = NULLTAG;
	int n_fndd = 0;
	int n_entryy = 1;

	tag_t bomline = msg->object_tag;

	prop_tag = va_arg(args, tag_t);
	prop_value = va_arg(args, char*);

	printf("\nInside prop_bl_quantity_check method...!!");

	if(BOM_line_ask_window(bomline,&window))PrintErrorStack();
	if(window != NULLTAG)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
		if(top_bom_line != NULLTAG)
		{
			if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&blrelease))PrintErrorStack();
			if(BOM_line_ask_attribute_string(top_bom_line, blrelease, &topBomLineRelease))PrintErrorStack();
			printf("\nTop_Bomline topBomLineRelease:%s", topBomLineRelease);
		}
	}
	int errorCode = BOMLineCheck(bomline);
	if (errorCode)
	{
			if(tc_strstr(topBomLineRelease,"Release") != NULL)
			{
				printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
				return ITK_err;
			}
	}

	POM_get_user(&username,&user_tag);
	POM_ask_group(&group_name, &group_tag);
	if(BOM_line_ask_window(bomline,&window))PrintErrorStack();
	if(window != NULLTAG)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
		if(top_bom_line != NULLTAG)
		{
			if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType))PrintErrorStack();
			if(BOM_line_ask_attribute_string(top_bom_line, blobjType, &bomline_objType))PrintErrorStack();
			printf("\nTop_Bomline obj_type:%s", bomline_objType);
			if (tc_strcmp(bomline_objType,"T5_PlatformRevision") == 0)
			{
				if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&child_blobjType))PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline, child_blobjType, &child_bomline_objType))PrintErrorStack();
				printf("\nChild_Bomline obj_type:%s\n", child_bomline_objType);
			 	if (tc_strcmp(child_bomline_objType,"T5_ArchModuleRevision") == 0)
				{
					SA_ask_user_identifier2	(user_tag,&userid);
					printf ("\nLogged in user:%s %s\n",userid, username);fflush(stdout);

					//Neha(CR-FY23-0166)
					if(QRY_find2("ControlObjQry", &TagQryCtrlObjj));
					if(QRY_execute(TagQryCtrlObjj, n_entryy, ctrlQryEnt, ctrlQryVal, &n_fndd, &cntr_objj));
					printf("\n PltArchMQty control object nfound variable size == %d", n_fndd);fflush(stdout);

					if(n_fndd>0)
					{
						if((tc_strcmp(group_name, "Master_Data_Mgmt") != 0) && (tc_strcmp(username,"infodba")!=0))
						{
							printf("\nOnly (Master_Data_Mgmt) group user can update the quantity of Arch. Module.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error, ITK_err, "You can't update the quantity of Arch. Module.");
							return ITK_err;
						}
					}

					//if((tc_strcmp(group_name, "Master_Data_Mgmt") != 0) && (tc_strcmp(username,"infodba")!=0))
					//{
						printf("\nOnly (Master_Data_Mgmt) group user can update the quantity of Arch. Module.\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "You can't update the quantity of Arch. Module.");
						return ITK_err;
					//}
				}
			}
		}
	}

	/*if(BOM_line_ask_window(bomline,&window))PrintErrorStack();
	if(window != NULLTAG)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
		if(top_bom_line != NULLTAG)
		{*/


		printf("\nInside parent check...!!");
		if(BOM_line_look_up_attribute ("bl_formatted_parent_name",&parent_nm))PrintErrorStack();
		if(BOM_line_ask_attribute_string(bomline, parent_nm, &parent_string))PrintErrorStack();
		printf("\nparent_str:%s", parent_string);

	/*part = strtok(parent_string, "/");
	rev =  strtok(NULL, "-");

	if(ITEM_find_rev(part, rev, &rev_tag))PrintErrorStack();
	if(AOM_UIF_ask_value(rev_tag, "object_type", &objType))PrintErrorStack();

	if (tc_strcmp(objType,"Architecture Module Revision") == 0)
			{*/
	if(tc_strstr(parent_string, "X4M") != NULL || tc_strcmp(bomline_objType,"T5_ArchModuleRevision") == 0)
	{
//	if(PS_where_used_all(bomline,1,&n_parents,&levels,&parents))PrintErrorStack();
//	{
//		printf("\ncount_parent:%d\n", n_parents);
//		if(n_parents > 0)
//		{
//			if(BOM_line_look_up_attribute ("bl_line_name",&line_name))PrintErrorStack();
//			if(BOM_line_ask_attribute_string(parents[0], line_name, &bomline_name))PrintErrorStack();
//			printf("\nBomline_name:%s\n", bomline_name);
//
//			if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType))PrintErrorStack();
//			if(BOM_line_ask_attribute_string(top_bom_line, blobjType, &bomline_objType))PrintErrorStack();
//			printf("\nTop_Bomline obj_type:%s", bomline_objType);
//			if (tc_strcmp(bomline_objType,"T5_ArchModuleRevision") == 0)
//			{
				if(BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok);PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline, attr_id, &bcm_type_name)!=ITK_ok);PrintErrorStack();
				if(BOM_line_look_up_attribute("bl_Design_t5_RevPartType", &rev_attr_id)!=ITK_ok);PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline, rev_attr_id, &rev_type_name)!=ITK_ok);PrintErrorStack();
				if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&rel_stat))PrintErrorStack();
				if(BOM_line_ask_attribute_string(bomline, rel_stat, &bcm_release_status))PrintErrorStack();
				printf("\nObject_type:%s and Part_type:%s\n", bcm_type_name, rev_type_name);
				if (tc_strcmp(bcm_type_name,"Design Revision") == 0 && tc_strcmp(rev_type_name,"Module") == 0)
				{
					if(tc_strstr(bcm_release_status,"Release") != NULL)
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid);
						printf ("\nLogged in user:%s %s\n",userid, username);fflush(stdout);
						char *SupportUsername9 = NULL;
						tag_t SessionUser9_tag=NULLTAG;
						int     SupportFlag      =  0;

						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);
						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin(SessionUser9_tag);
							printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
						}
						//if((tc_strcmp(username,"su_mdm")!= 0) && (tc_strcmp(username,"infodba")!=0) && (tc_strcmp(userid,"ercpsup")!=0))
						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "Master_Data_Mgmt") != 0))
						{
							printf("\n Released Part, not allowed to update the quantity:%s %s\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\nCan't update bomline quantity, Module is already released");
							return ITK_err;
						}
					}
					else //review or working
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid);
						printf ("Logged in user:%s %s\n",userid, username);fflush(stdout);
						if((tc_strcmp(group_name,"Master_Data_Mgmt")!= 0) && (tc_strcmp(username,"infodba")!=0))
						{
							if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd))PrintErrorStack();
							if(modadd > 0)
							{
								if(BOM_line_ask_attribute_string(bomline, modadd, &mod_addr))PrintErrorStack();
								printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
								if(mod_addr != NULL && strlen(mod_addr) > 0)
								{

									designer_role = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Designers")) * sizeof(char));
									strcpy(designer_role,mod_addr);
									strcat(designer_role,"_Designers");
									manager_role  = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Managers")) * sizeof(char));
									strcpy(manager_role,mod_addr);
									strcat(manager_role,"_Managers");
									printf("\nsearch for role:%s OR %s\n",designer_role,manager_role);fflush(stdout);

									if(SA_find_groupmember_by_rolename(designer_role,"ERC_Designers_Group",userid,&designer_found,&list))PrintErrorStack();
									if(SA_find_groupmember_by_rolename(manager_role,"ERC_Designers_Group",userid,&manager_found,&list))PrintErrorStack();
									printf("\n designer_found:%d manager_found:%d\n",designer_found,manager_found); fflush(stdout);
									if(designer_found == 0 && manager_found == 0)
									{
										printf("\nYou don't have access to update the quantity of bomline.\n");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\nYou don't have access to update the quantity of bomline.");
										return ITK_err;
									}

								}
								else
								{
									printf("\nModule Address is blank, hence cannot update the quantity of bomline.\n");fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"\nModule Address is blank, hence cannot update the quantity of bomline.");
									return ITK_err;

								}
							}
							else
							{
								printf("\nModule Address not found, hence cannot update the quantity of bomline.\n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"\nModule Address not found, hence cannot update the quantity of bomline.");
								return ITK_err;
							}
						}
					}
					printf("\nUser is trying to update : prop_value : -- %s",prop_value);
					//if(BOM_line_look_up_attribute ("bl_quantity",&child_attr))PrintErrorStack();
					//if(BOM_line_ask_attribute_string (bomline, child_attr, &child_qty))PrintErrorStack();
					//printf("\n Child Qty is===============>>>>>> %s\n",child_qty);fflush(stdout);
					if(tc_strcmp(prop_value,"0") == 0 || tc_strlen(prop_value) == 0)
					{
						printf("\nZero OR blank Quantity is not allowed.\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nZero OR blank Quantity is not allowed.");
						return ITK_err;
					}
				}
			//}
		//}
	}
	return error_code;
}
//neha(CR-FY23-0145)
int BOMLineCheck(tag_t bomline)
{
	int			revstat				= 0;
	int			SupportFlag			= 0;
	int			n_entries			= 2;
	int			n_found				= 0;
	char		*child_rev_stat		= NULL;
	char		*SupportUsername9	= NULL;
	char		*ctrlQryEnt[2]		= {"SYSCD", "SUBSYSCD"};
	char		*ctrlQryVal[2]		= {"bomLineVal", "bomLineVal1"};
	tag_t		window				= NULLTAG;
	tag_t		SessionUser9_tag	= NULLTAG;
	tag_t		TagQryContObj		= NULLTAG,*cntr_objects = NULL;
	char		*group_name					=NULL;
	tag_t		group_tag					=NULLTAG;

	if(QRY_find2("ControlObjQry", &TagQryContObj));

	if(QRY_execute(TagQryContObj, n_entries, ctrlQryEnt, ctrlQryVal, &n_found, &cntr_objects));
	printf("\n bomLineVal control object nfound variable size == %d", n_found);fflush(stdout);

	if(n_found>0)
	{
		if(BOM_line_ask_window(bomline,&window))PrintErrorStack();
		if(window != NULLTAG)
		{
			if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat))PrintErrorStack();
			if(BOM_line_ask_attribute_string(bomline, revstat, &child_rev_stat))PrintErrorStack();
			printf("\n Release status of : [%s] \n",child_rev_stat);fflush(stdout);

			POM_get_user(&SupportUsername9,&SessionUser9_tag);
			POM_ask_group(&group_name, &group_tag);

			printf("\n Group name of %s : [%s] \n",SupportUsername9,group_name);fflush(stdout);


			if((tc_strcmp(group_name, "DML_Participants_Group") == 0) || (tc_strcmp(group_name, "ERC_Designers_Group") == 0)||
				(tc_strcmp(group_name, "Vehicle_Integration") == 0)) //|| (tc_strcmp(group_name, "dba") == 0))//DBA for uadev
			{
				//if((tc_strstr(child_rev_stat,"Review") != NULL)) //for uadev testing
				if((tc_strstr(child_rev_stat,"Release") != NULL))
				{
					return 1;
				}
			}
		}
	}
	return 0;
}

extern DLLAPI int prop_bl_tag_UOM_check(METHOD_message_t *msg, va_list args)
{
	int			error_code					= ITK_ok;

	printf("\nInside prop_bl_tag_UOM_check method...!!");

	return error_code;
}
//neha

extern DLLAPI int prop_bl_method_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}





extern DLLAPI int prop_bl_method_ColInd_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_ColInd_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}


extern DLLAPI int prop_bl_method_CompCode_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_CompCode_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}


extern DLLAPI int prop_bl_method_EnvDim_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_EnvDim_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_DesGrp_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_DesGrp_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_SpareCri_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_SpareCri_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_SpareInd_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_SpareInd_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_MatCls_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_MatCls_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_Material_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_Material_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_PrtTyp_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_PrtTyp_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_ProjCode_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_ProjCode_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_RevPrtTyp_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_RevPrtTyp_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_Weight_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_Weight_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;

}
extern DLLAPI int prop_bl_method_RolledupWt_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_RolledupWt_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;

}

extern DLLAPI int prop_bl_method_UOM_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_UOM_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_AhdMakeBuyInd_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_AhdMakeBuyInd_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;

}

extern DLLAPI int prop_bl_method_CarMakeBuyInd_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_CarMakeBuyInd_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_PunPCBUMakeBuyInd_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_PunPCBUMakeBuyInd_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;

}
extern DLLAPI int prop_bl_method_PunUvMakeBuyInd_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	printf("\n ***INSIDE prop_bl_method_PunUvMakeBuyInd_check*** \n");fflush(stdout);

	tag_t bomline = msg->object_tag;
	int errorCode = BOMLineCheck(bomline);

	if (errorCode)
	{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
			return ITK_err;
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_KeyDesc_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;
	int			revstat				= 0;
	int			SupportFlag			= 0;
	char		*child_rev_stat		= NULL;
	char		*parent_rev_stat	= NULL;
	char		*SupportUsername9	= NULL;
	tag_t		window				= NULLTAG;
	tag_t		SessionUser9_tag	= NULLTAG;
	tag_t		top_bom_line		= NULLTAG;

	char *ctrlQryEntries[2] = {"SYSCD", "SUBSYSCD"};
	char *ctrlQryValues[2] = {"bom_keyDes", "bom_keyDes1"};
	tag_t TagCtrlQryObj = NULLTAG,*ctrlCntrObj = NULL;
	tag_t TagCtrlQryContObj = NULLTAG;
	int		nEntr		= 2;
	int		nFnd		= 0;

	char ref_type_name[TCTYPE_name_size_c+1];


	printf("\n ***INSIDE prop_bl_method_KeyDesc_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;

	if(BOM_line_ask_window(bomline,&window))PrintErrorStack();
	if(window != NULLTAG)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
		if(top_bom_line != NULLTAG)
		{
			if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat))PrintErrorStack();
			if(BOM_line_ask_attribute_string(top_bom_line, revstat, &parent_rev_stat))PrintErrorStack();
			printf("\n Release status of Parent : [%s] \n",parent_rev_stat);fflush(stdout);

			if(BOM_line_ask_attribute_string(bomline, revstat, &child_rev_stat))PrintErrorStack();
			printf("\n Release status of child : [%s] \n",child_rev_stat);fflush(stdout);
		}
	}


	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin(SessionUser9_tag);
		printf("\n SupportFlag............: %d",SupportFlag);fflush(stdout);
	}

	if(SupportFlag==0)
	{
		if(QRY_find2("ControlObjQry", &TagCtrlQryObj));
		if(QRY_execute(TagCtrlQryContObj, nEntr, ctrlQryEntries, ctrlQryValues, &nFnd, &ctrlCntrObj));
		printf("\n bom_keyDes ControlObjQry : %d", nFnd);fflush(stdout);
		if(nFnd>0)
		{
			if((tc_strstr(child_rev_stat,"Release") != NULL))
			//if((tc_strstr(child_rev_stat,"Review") != NULL))
			{
				printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence  attribute updation not allowed");
				return ITK_err;
			}
		}
	}

	return error_code;

}


//Added by kalpesh for validation of Parameter part and it's clause.
int para_clause_attach_method(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE para_clause_attach_method*** \n");fflush(stdout);

	int		ifail							= 0;
	int		svrFlag							= 0;
	int		ii;
	int  	count,count1;

	tag_t	primary_object					= va_arg(args, tag_t);
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= va_arg(args, tag_t);
	tag_t	secondary_obj_type_tag			= NULLTAG;

	tag_t  	rel_type;
	tag_t	*sec_objects;
	tag_t	tsk_dml_rel_type;
	tag_t	DML_rev_tag						= NULLTAG;
	tag_t	*DMLRevision					= NULL;

	char	type_name1[WSO_name_size_c+1];
	char	type_name2[WSO_name_size_c+1];
	char	*obj_type_name2					= NULL;
	char	*objectvalue1					= NULL;
	char	*objectvalue2					= NULL;
	char	*TaskDsgGrp						= NULL;
	char	*username						= NULL;
	char	*PartType						= NULL;
	char	*TskNm							= NULL;
	char	*rls_type;

	logical	check_out = 0;

	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name(primary_obj_type_tag,type_name1);
	printf("\nERC DML Primary_object type_name is:%s",type_name1);fflush(stdout);

	ifail=TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag);
	ifail=TCTYPE_ask_name(secondary_obj_type_tag,type_name2);
	printf("\nERC DML secondary_object type_name is:%s",type_name2);fflush(stdout);
	POM_get_user_id (&username);
	printf("\nLogged in user:%s\n",username); fflush(stdout);

	char *SupportUsername9 = NULL;
	tag_t SessionUser9_tag=NULLTAG;
	int     SupportFlag      =  0;

	SupportFlag=0;
	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin(SessionUser9_tag);
		printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
	}

	//if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"ercpsup") !=0)
	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
	{
		if(tc_strcmp(type_name2,"T5_EPara") == 0 || tc_strcmp(type_name2,"T5_EParaRevision") == 0)
		{
			printf("\n*****INSIDE T5_EPara(Clause)*****\n");fflush(stdout);

			if(tc_strcmp(type_name1,"T5_EE_PartRevision") == 0)
			{
				printf("\n*****INSIDE T5_EE_PartRevision*****\n");fflush(stdout);

				if(RES_is_checked_out(primary_object, &check_out)!=ITK_ok)PrintErrorStack();
				if(check_out != 0)
				{
					printf("\nPart is checked-out, so relation created...!!\n");fflush(stdout);
				}
				else
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please check-out the EE Part first.");
					printf("\nPlease check-out the EE Part first...!!\n");fflush(stdout);
					return ITK_err;
				}
			}
		}
	}
	return ifail;
}
//End of Parametere clause validation.

extern DLLAPI int  save_method_8(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	int i = 0;
	tag_t objTypeTag = NULLTAG;
	tag_t user_tag=NULLTAG;

	logical	checkout1 = 0;

	char *object_name = NULL;
	char   *type_name = NULL;
	char* username = NULL;

	const char		*reason	= "";
	const char		*change_id	= "";
	const char		*dir_name = "";

	tag_t datasetTypeTag = va_arg(args, tag_t);
	const 	char* datasetName = va_arg(args, const 	char* );
	const 	char* datasetDescription = va_arg(args, const 	char* );
	const 	char* datasetID = va_arg(args, const 	char* );
	const 	char* datasetRevision = va_arg(args, const 	char* );
	tag_t 	newDataset = va_arg(args, tag_t );

	//tag_t	LatestRev = NULLTAG;  //Adi Alias         // commented by Adi
	//tag_t	ref_item = NULLTAG;   //Adi Alias        // commented by Adi
	//char* RevL = NULL;			  //Adi Alias   // commented by Adi
	//char *AliasTransFileName=NULL;//Adi Alias    // commented by Adi
	char* ObjNum1 = NULL;		  //Adi CMI
	char* username1 = NULL;		  //Adi CMI

	tag_t *tags_found = NULL;
	tag_t item_tag= NULLTAG, rev=NULLTAG;
	const char *item_name = NULL;
	char *SetType = NULL;
	char *USetType = NULL;
	const char *cTemp="item_id";
	int n_tags_found=0,len=0;
	char* itemName = NULL;
	char* startPart = NULL;
//	char* PartTypeCAT = NULL; //Adi 1.35

	printf("\nsave_method_8 ::  Inside Function\n");

	ObjNum1 =malloc(150);		  //Adi CMI

	if(newDataset != NULLTAG)
	{
		if (TCTYPE_ask_object_type(newDataset,&objTypeTag)!=ITK_ok) PrintErrorStack();
		if(objTypeTag != NULLTAG)
		{
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
//		}
//		else
//		{
//			printf("\nsave_method_8 :: objTypeTag is NULLTAG\n");
//		}

		AOM_get_value_string(newDataset, "object_name", &object_name);

		printf("\n!!!!!!!!!!!!!!!!! save_method_8:::::::::type_name[%s] -- %s\n",type_name, object_name);fflush(stdout);

		 if(tc_strcmp(type_name,"CATProduct")==0 || tc_strcmp(type_name,"CATPart")==0 || tc_strcmp(type_name,"CATDrawing")==0)
		{
			printf("\n!!:::type_name not allowed[%s] -- %s\n",type_name, object_name);fflush(stdout);
			EMH_store_error_s3(EMH_severity_error,ITK_err,"Dataset of type", type_name," Not allowed to create");
			return ITK_err;
		}


		if(strcmp(type_name,"ProPrt")==0 || strcmp(type_name,"ProAsm")==0 || strcmp(type_name,"ProDrw")==0)
		{
			POM_get_user(&username,&user_tag);
			printf("\nSession username == %s\n", username);fflush(stdout);
			//if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
			if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"aplloader")!=0))
			{
				printf("\nsave_method_8 :: Inside ProPrt | ProAsm | ProDrw Condition.\n");fflush(stdout);
				if(RES_is_checked_out(newDataset,&checkout1) !=ITK_ok) PrintErrorStack();
				if (checkout1==0)
				{
					if (RES_checkout(newDataset,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
					printf("\nsave_method_8 :: DataSet Checked Out \n");fflush(stdout);

				}
				else
				{
					printf("\nsave_method_8 ::  Skipping as DataSet already Checked Out\n");fflush(stdout);
				}
			}
		}


		/**************************** Adi CATIA 1.32 CMI dataset should not have rev or seq **********************************/

		else if(((tc_strcmp(type_name,"CMI2Product")==0)|| (tc_strcmp(type_name,"CMI2Part")==0)|| (tc_strcmp(type_name,"CMI2Drawing")==0)|| (tc_strcmp(type_name,"CMI2DesignTable")==0)))
		{
			POM_get_user(&username1,&user_tag);
			printf("\n Session username1 == %s\n", username1);
			//if((tc_strcmp(username1,"infodba")!=0) && (tc_strcmp(username1,"loader")!=0))
			if(tc_strcmp(username,"loader")!=0)
			{
				if(tc_strcmp(type_name,"CMI2Drawing")!=0)	//skiping for CMI2Drawing
				{
					item_name=strtok(object_name,"/");
					if(item_name)
					{
						printf("\nItem Name %s ",item_name);fflush(stdout);

						if(ITEM_find_items_by_key_attributes(1,&cTemp, &item_name, &n_tags_found, &tags_found) !=ITK_ok);PrintErrorStack();

						if (n_tags_found > 1)
						{
							MEM_free(tags_found);
							EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
							printf("More than one items matched with id %s\n", item_name);fflush(stdout);
							exit (0);
						}
						else if (n_tags_found == 1)
						{
							printf("only one items matched with id %s\n", item_name);fflush(stdout);
							item_tag = tags_found[0];
							if(ITEM_ask_latest_rev(item_tag,&rev)); PrintErrorStack();

							if(rev != NULLTAG)
							{
								if( AOM_ask_value_string(rev,"item_id",&itemName)!=ITK_ok);
								if( AOM_ask_value_string(rev,"t5_StartPartProduct",&startPart)!=ITK_ok);
								printf("\nt5_Material %s StartPartProduct %s \n",itemName,startPart);fflush(stdout);
								//if( AOM_ask_value_string(rev,"t5_PartType",&PartTypeCAT));  //Adi 1.35 commented
								if(strcmp(startPart,"")!=0)
								{
									SetType=strtok(type_name,"CMI2");
									tc_strupr(SetType,&USetType);
									printf("\n*****DataSet Type [%s] \n",USetType);

									if(tc_strstr(startPart,USetType)!=NULL)
									{
										printf("\nStartPart and DataSet Type Match..[%s] \n",USetType);
									}
									else
									{
										printf("\nStartPart %s and DataSet Type %s Not Matching\n",startPart,USetType);
										EMH_store_error_s4(EMH_severity_error,ITK_err,"Start Part of Design Revision and Dataset Type Not Matching..", startPart," Not Matching with Dataset", type_name);
										return ITK_err;
									}
									//if((tc_strcmp(PartTypeCAT,"A")==0)&&(tc_strcmp(USetType,"PART")==0)) //Adi 1.35
									//{
									//	EMH_store_error_s1(EMH_severity_error,ITK_err,"Part type Assembly cannot have CMI2Part as an attachment");	//Adi 1.35
									//	return ITK_err;

									//}
									//else if((tc_strcmp(PartTypeCAT,"C")==0)&&(tc_strcmp(USetType,"PRODUCT")==0))//Adi 1.35
									//{
									//	EMH_store_error_s1(EMH_severity_error,ITK_err,"Part type Component cannot have CMI2Product as an attachment"); //Adi 1.35
									//	return ITK_err;
									//}
								}
							}

						}
					}
				}

				printf("\n save_method_8:: Inside CMI Condition \n");fflush(stdout);

				ObjNum1=strtok(object_name,"/");

				if(AOM_lock(newDataset));
				printf("\n after locking catia dataset \n");fflush(stdout);

				AOM_set_value_string(newDataset,"object_name", ObjNum1);

				if(AOM_save(newDataset));
				if(AOM_unlock(newDataset));
				printf("\n after unlocking catia dataset \n");fflush(stdout);
			}
		}
		  /******************************* Adi CATIA 1.32 ends *************************************/



		  /********************************* Adi ALIAS 1.32 *************************************/
       // commented by Adi
		/*else if (((strcmp(type_name,"T5_Alias")==0) || (strcmp(type_name,"WIRE")==0)||(strcmp(type_name,"T5_Wire")==0)))
		{
			printf("\n DATASET NAME IS [%s] , [%s]\n" ,object_name,type_name);fflush(stdout);

			if(ITEM_find_item(object_name,&ref_item));
			printf("\n ITEM_find_item AAA-------------- \n");fflush(stdout);

			if(ITEM_ask_latest_rev(ref_item,&LatestRev));
			printf("\n ITEM_ask_latest_rev AAA------------- \n");fflush(stdout);

			if( AOM_ask_value_string(LatestRev,"item_revision_id",&RevL)==ITK_ok)
			printf("\n RevL AAA--------------%s \n",RevL);fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(primaryA,"object_name",&DatasetNameAlias));
			AliasTransFileName=malloc(2000);
			strcpy(AliasTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
			//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

			strcat(AliasTransFileName,object_name);
			strcat(AliasTransFileName," ");
			strcat(AliasTransFileName,"-r='");

			strcat(AliasTransFileName,RevL);
			strcat(AliasTransFileName,"'");
			strcat(AliasTransFileName," ");

			strcat(AliasTransFileName,"-dt=T5_Alias  -dn='");
			strcat(AliasTransFileName,object_name);
			strcat(AliasTransFileName,"'");
			strcat(AliasTransFileName," ");

			strcat(AliasTransFileName,"-pr=1 -pn=SIEMENS   -tn=aliastocatpart -ty=COMMAND_LINE");
			printf("\n AliasTransFileName  T5_Alias before system is  =>%s\n", AliasTransFileName);fflush(stdout);

			system(AliasTransFileName);

			printf("\n After T5_Alias dispatcher_create_rqst shell =>%s\n", AliasTransFileName);fflush(stdout);*/

		//}   /****************************** Adi ALIAS 1.32  ***************************************/
	}
		else
		{
			printf("\nsave_method_8 :: objTypeTag is NULLTAG\n");
		}
	}
	printf("\nsave_method_8 ::  Exiting Function\n");
	return error_code;
}

/*********** Adi for CREO AND CATIA ********************/

extern DLLAPI int  save_method_9(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int i = 0;
	tag_t objTypeTag = NULLTAG;
	tag_t user_tag=NULLTAG;

	logical	checkout1 = 0;

	char *object_name = NULL;
	char *object_type = NULL;
	char   *type_name = NULL;
	char   *type_name3 = NULL;
	char   *ObjNum = NULL;
	char   *ObjNum1 = NULL;
	char* username = NULL;

	const char		*reason	= "";
	const char		*change_id	= "";
	const char		*dir_name = "";

	char * catiasynch	 = NULL;
	tag_t	queryTag	 = NULLTAG;
	int		n_entries	 = 1;
	int		countDep	 = 0;
	char *qry_entries[1] = {"SYSCD"};
	char **qry_values    = (char **) MEM_alloc(10 * sizeof(char *));
	int		resultCount	 = 0;
	int		k			= 0;
	tag_t	*rev		 = NULLTAG;
	char	*itemId		 = NULL;
	char	*RevL		 = NULL;
	tag_t			objTypeTagDi				= NULLTAG;
	tag_t *CntrlObjectTag=NULLTAG;
	tag_t			primary					= NULLTAG;
	tag_t  *secondary_objects3	= NULLTAG;
	tag_t	LatestRev = NULLTAG;
	tag_t	LatestRev1 = NULLTAG;
	tag_t	ref_item = NULLTAG;

	//char cmi_name[TCTYPE_name_size_c+1];

	/*tag_t datasetTypeTag = va_arg(args, tag_t);
	const 	char* datasetName = va_arg(args, const 	char* );
	const 	char* datasetDescription = va_arg(args, const 	char* );
	const 	char* datasetID = va_arg(args, const 	char* );
	const 	char* datasetRevision = va_arg(args, const 	char* );*/
	tag_t 	newDataset = va_arg(args, tag_t );
	ObjNum =malloc(150);
	ObjNum1 =malloc(150);
	//ObjNum1 =malloc(100);


	//printf("\n save_method_9 ::  Inside Function \n");

		if (TCTYPE_ask_object_type(newDataset,&objTypeTag)!=ITK_ok) PrintErrorStack();
		if(objTypeTag != NULLTAG)
		{
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
		}
		else
		{
			printf("\n save_method_9 :: objTypeTag is NULLTAG\n");
		}

		AOM_get_value_string(newDataset,"object_name", &object_name);

		printf("\n!!!!!!!!!!!!!!!!! save_method_9:::::::::type_name[%s] -- %s\n",type_name, object_name);fflush(stdout);

		POM_get_user(&username,&user_tag);

		printf("\n Session username == %s\n", username);

		//if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		if(tc_strcmp(username,"loader")!=0)
		{
			if(((tc_strcmp(type_name,"ProPrt")==0) || (tc_strcmp(type_name,"ProAsm")==0) || (tc_strcmp(type_name,"ProDrw")==0)))
			{

				printf("\n save_method_9 :: Inside ProPrt | ProAsm | ProDrw Condition.\n");

				if (tc_strstr(object_name,"/") || (tc_strstr(object_name,";")))
				{
					printf("\n ERROR: save_method_9 :: DataSet  \n");
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please remove '/' , ';' ,Revision and Seq from Object Name ");
					return ITK_err;

				}
				else
				{
					printf("\n save_method_9 ::  Skipping as DataSet \n");fflush(stdout);
				}

			}
			/*else if(((tc_strcmp(type_name,"CMI2Product")==0)|| (tc_strcmp(type_name,"CMI2Part")==0)|| (tc_strcmp(type_name,"CMI2Drawing")==0)))
			{
				printf("\n ADI for CATIA datasets \n");

				if(QRY_find("ControlObjects", &queryTag));

				if (queryTag)
				{
					printf("\n Found Query CMI \n");fflush(stdout);
				}
				else
				{
					printf("\n Not Found Query CMI \n");fflush(stdout);
				}

				qry_values[0] = "CatData" ;

				ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &CntrlObjectTag));

				printf(" \n resultCount :%d:", resultCount); fflush(stdout);

				if(resultCount>0)
				{
					printf("\n CatData control object found-------------- \n");fflush(stdout);

					//if( GRM_list_primary_objects_only(newDataset,NULLTAG,&countDep,&secondary_objects3)!=ITK_ok)PrintErrorStack();
					//printf("\n count found %d \n ",countDep);fflush(stdout);

					strcpy(ObjNum,object_name);
					ObjNum1=strtok(ObjNum,"/");

					if(ITEM_find_item(ObjNum1,&ref_item));
					//printf("\n ITEM_find_item AAA-------------- \n");fflush(stdout);

					if(ITEM_ask_latest_rev(ref_item,&LatestRev));
					printf("\n ITEM_ask_latest_rev AAA------------- \n");fflush(stdout);

					if( AOM_ask_value_string(LatestRev,"item_id",&RevL)==ITK_ok)
					printf("\n RevL AAA--------------%s \n",RevL);fflush(stdout);

					AOM_get_value_string(LatestRev,"object_type", &object_type);
					printf("\n object_type AAA--------------%s \n",object_type);fflush(stdout);

					if(tc_strcmp(object_type,"Design Revision")==0 )
					{
						if( AOM_ask_value_string(LatestRev,"t5_IsCatSynch",&catiasynch)==ITK_ok)

						printf("\n catiasynch value is -------------- %s \n",catiasynch);fflush(stdout);

						if(tc_strcmp(catiasynch ,"Y")==0)
						{
						    printf("\n part has been synched from catia--- so no issues \n");fflush(stdout);
						}
						else
						{
							printf("\n catiasynch VALUE IS N OR NULL \n");fflush(stdout);

							if (tc_strstr(object_name,"/") || (tc_strstr(object_name,";")))
							{
								printf("\n Part has not been synchronised from Catia \n");fflush(stdout);
								//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Please remove '/' , ';' ,Revision and Seq from Object Name");

								return ITK_errStore;
							}
							else
							{
								printf("\n / OR ; does not exist for Catia dataset \n");fflush(stdout);
							}
						}
					}
				}
				else
				{
					 printf("\n Pl create CatData control object  -------------- \n");fflush(stdout);
				}
			}*/
		}


	printf("\nsave_method_9 ::  Exiting Function\n");
	return error_code;
}

/*************Adi for CREO AND CATIA ********************/




//upp Start

extern DLLAPI int qauntity_handled_as_per_uom (METHOD_message_t *msg, va_list args)
{
	//tag_t    object;
	int ifail = ITK_ok;
	char  object_type[WSO_name_size_c+1] ;
	//char* uomValue;
	char* sPartType;
	char	*sDesgNoD	= NULL;
	char	*DesgNo	= NULL;


	tag_t parent_bvr=va_arg(args, tag_t);
	tag_t child_item=va_arg(args, tag_t);
	tag_t child_bom_view=va_arg(args, tag_t);
	int n_occurrences=va_arg(args, int);
	tag_t** occ_thread_tags=va_arg(args, tag_t**);

	printf("Upendra...99=====n_occurrences=%d",n_occurrences);fflush(stdout);
	WSOM_ask_object_type  (child_item, object_type);
	printf("Object Name upp=%s \n",object_type);fflush(stdout);

	if (strcmp(object_type,"T5_ClrPart")==0)
	{
		printf("\nT5_ClrPart--for UOM set Qty=1 ...");fflush(stdout);
		if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok);PrintErrorStack();
	}
	else
	{
		if( AOM_UIF_ask_value(child_item,"t5_RevPartType",&sPartType)!=ITK_ok);PrintErrorStack();
		printf("\nPart Type :%s",sPartType);fflush(stdout);
		if( AOM_UIF_ask_value(child_item,"item_id",&DesgNo)!=ITK_ok);PrintErrorStack();
		printf("\nComponent part Num :%s",DesgNo);fflush(stdout);

		if ((strcmp(sPartType,"Dummy")==0) || (strcmp(sPartType,"Information Fitment Drawing")==0))
		{
			//IFD-Dummy part should be 12 digit and 9th and 10th digit should be 00/04
			sDesgNoD=subString(DesgNo, 8, 2);
			printf("\n IFD-Dummy part 9th and 10th digit [%s]\n", sDesgNoD);fflush(stdout);

			if (((strlen(DesgNo) ==12) && ((tc_strcmp(sDesgNoD,"04")==0) || (tc_strcmp(sDesgNoD,"00")==0))) || (tc_strlen(DesgNo) ==14))
			{
				printf("\n 12 digit Dummy part-9th and 10th digit is 00/04: [%s]\n", DesgNo);fflush(stdout);
				if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],0)!=ITK_ok);PrintErrorStack();
			}
			else
			{
			   printf("\nDummy part is other than IFD");fflush(stdout);
			   if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok);PrintErrorStack();
			}
		}
		else if((strcmp(sPartType,"CAD Module")==0))
		{
			if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],0)!=ITK_ok);PrintErrorStack();
		}
		else
		{
			printf("\nfor UOM set Qty=1 ...");fflush(stdout);
			if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok);PrintErrorStack();
		}

		/*
		if( AOM_UIF_ask_value(child_item,"t5_uom",&uomValue)!=ITK_ok);PrintErrorStack();
		printf("\n CUSTOM UOM name is = %s",uomValue);fflush(stdout);

		else if (strcmp(uomValue,"4-Nos")==0)
		{
			printf("UOM is 4-nos and Qty=1 ...");
			if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok);PrintErrorStack();
		}
		else
		{
			printf("UOM is other than 4-nos and Qty=0 ...");
			if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],0)!=ITK_ok);PrintErrorStack();
		}*/
	}
	return ifail ;
}

int ECU_Para_PreCond_Func(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE ECU_Para_PreCond_Func*** \n");fflush(stdout);

	int		ifail							= 0;

	 tag_t objTag = va_arg(args, tag_t);
     int isNew = va_arg(args, int);
	 char* username=NULL;

	if (!isNew)
	{
		printf("\n!!!!!!!!!!!!!!!!! ECU_Para_PreCond_Func::::::::: not first time creation!!!!!!!! \n");fflush(stdout);
		return ifail;
	}

	POM_get_user_id (&username);
	printf("\nLogged in user:%s\n",username); fflush(stdout);



	int n_entries11 =2;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;

	tag_t *qry_cntrlobj11= NULLTAG;
	char* userinfo_TPL_ECU=NULL;

	if(QRY_find("Control Objects...", &Cntl_obj_Qtag11));


	qry_values11[0] = "ECU_Parameter_Cre" ;
	qry_values11[1] = "ECU_Parameter_Cre" ;

	ITK_CALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	if (resultCount11 > 0)
	{
		//printf("\n***** CONTROL OBJECT found for ECU_Parameter_Cre*****\n");fflush(stdout);
		AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo_TPL_ECU);

		printf("\n***** CONTROL OBJECT found for ECU_Parameter_Cre***** %s \n", userinfo_TPL_ECU);fflush(stdout);

		if(!tc_strstr(userinfo_TPL_ECU,username))
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"ECU Parameter creation is disabled from user side.Please contact Support team for more information");
			return ITK_err;
		}

	}

	return ifail;

}
int CCV_ECU_PreCond_Func(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE para_clause_attach_method*** \n");fflush(stdout);

	int		ifail							= 0;

	tag_t	primary_object					= va_arg(args, tag_t);
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= va_arg(args, tag_t);
	tag_t	secondary_obj_type_tag			= NULLTAG;




	tag_t	LatestRev					= NULLTAG;

	char	type_name1[WSO_name_size_c+1];
	char	type_name2[WSO_name_size_c+1];




	char	*username						= NULL;
	char	*PartType						= NULL;
	char	*DesGroup						= NULL;
	char	*ProjCode						= NULL;

	logical	check_out = 0;

	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name(primary_obj_type_tag,type_name1);
	printf("\nERC DML Primary_object type_name is:%s",type_name1);fflush(stdout);

	ifail=TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag);
	ifail=TCTYPE_ask_name(secondary_obj_type_tag,type_name2);
	printf("\nERC DML secondary_object type_name is:%s",type_name2);fflush(stdout);
	POM_get_user_id (&username);
	printf("\nLogged in user:%s\n",username); fflush(stdout);

	char *SupportUsername9 = NULL;
	tag_t SessionUser9_tag=NULLTAG;
	int     SupportFlag      =  0;

	SupportFlag=0;
	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin(SessionUser9_tag);
		printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
	}

	//if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"ercpsup") !=0)
	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
	{
		int Errorflag=0;
		if(tc_strcmp(type_name2,"Design") == 0 )
		{
			printf("\n*****INSIDE Design*****\n");fflush(stdout);

			//t5_DesignGrp
			//t5_PartType

			if(ITEM_ask_latest_rev(secondary_object,&LatestRev)!=ITK_ok) PrintErrorStack();
			if (LatestRev!=NULLTAG)
			{
				if( AOM_ask_value_string(LatestRev,"t5_DesignGrp",&DesGroup)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(LatestRev,"t5_PartType",&PartType)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(LatestRev,"t5_ProjectCode",&ProjCode)!=ITK_ok) PrintErrorStack();

				printf("\n*****INSIDE Design***** <%s> <%s> <%s> \n",DesGroup,PartType,ProjCode);fflush(stdout);

				if (tc_strcmp(DesGroup,"16")==0)
				{

					int n_entries11 =2;
					tag_t	Cntl_obj_Qtag11	=	NULLTAG;
					char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
					char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
					int resultCount11=0;
					int TplBypassflag=0;
					tag_t *qry_cntrlobj11= NULLTAG;
					char* userinfo_TPL_ECU=NULL;

					if(QRY_find("Control Objects...", &Cntl_obj_Qtag11));


					qry_values11[0] = ProjCode ;
					qry_values11[1] = "CCV_ECU_REL_ATTACH" ;

					ITK_CALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
					if (resultCount11 > 0)
					{
						printf("\n***** CONTROL OBJECT found for PROJECT TPL*****\n");fflush(stdout);
						AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo_TPL_ECU);
						TplBypassflag=1;
					}

					printf("\n*****INSIDE Design***** <%s>  \n",userinfo_TPL_ECU);fflush(stdout);


					if (TplBypassflag==1)
					{
						if (tc_strstr(userinfo_TPL_ECU,PartType) != NULL)
						{
							printf("\n*****TPL*****\n");fflush(stdout);
						}
						else
						{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Only 16R TPL/EM Master can be attached in CCVC has ECU module relationship");
								return ITK_err;
						}

					}
					else
					{
						if (tc_strcmp(PartType,"EM")==0)
						{
							printf("\n*****EM PartType*****\n");fflush(stdout);

						}
						else
						{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Only ECU Module Master can be attached in CCVC has ECU module relationship");
								return ITK_err;
						}
					}

				}
				else
				{
					printf("\n*****NOT 16 Design Group*****\n");fflush(stdout);
					Errorflag=1;
				}
			}
			else
			{
				printf("\n*****NOT Latest Design*****\n");fflush(stdout);
				Errorflag=1;
			}
		}
		else
		{
			printf("\n*****NOT Design*****\n");fflush(stdout);

			Errorflag=1;
		}

		if (Errorflag==1)
		{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Only ECU Module or 16R TPL can be attached ( Master only, not Revision) ");
				return ITK_err;
		}
	}
	return ifail;
}
//upp End

//Added by Kirtikumar Thakur for SVR validation
int SVR_PreCond_Validation_Func(METHOD_message_t *msg, va_list args)
{

	printf("\n ***INSIDE SVR_PreCond_Validation_Func*** \n");fflush(stdout);

	int		ifail							= 0;

	tag_t	primary_object					= va_arg(args, tag_t);
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= va_arg(args, tag_t);
	tag_t	secondary_obj_type_tag			= NULLTAG;

	char	primary_obj_type_name[WSO_name_size_c+1];
	char	secondary_obj_type_name[WSO_name_size_c+1];

	char	*username						= NULL;

	tag_t Smc0HasVariantConfigContext_Rel_tag =NULLTAG;
	int platformCount						  =0;
	tag_t* paltFormTag						  =NULLTAG;
	tag_t platFormNodeTag					  =NULLTAG;
	char* platFormItemID                      =NULL;
	char* secObjString						  =NULL;
	char* platFormObject_string				  =NULL;

	//To Get control object:
	int		n_entries		=3;
	tag_t	Cntl_obj_Qtag	=	NULLTAG;
	char	*qry_entries[3] = {"SYSCD","SUBSYSCD","Information-1"};
	char	**qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	int		resultCount=0;
	tag_t	*qry_cntrlobj= NULLTAG;

	//char* userinfo_1=NULL;
	char* userinfo_2=NULL;
	char* userinfo_3=NULL;

	char* projectCode =NULL;
	char* subStrProjectCode =NULL;
	char* errorMsg =NULL;





	ITK_CALL(TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag));
	ITK_CALL(TCTYPE_ask_name(primary_obj_type_tag,primary_obj_type_name));
	printf("\nPrimary_object type_name is:%s",primary_obj_type_name);fflush(stdout);

	if((tc_strcmp(primary_obj_type_name,"Cfg0ProductItem") == 0))
	{
		ITK_CALL(TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag));
		ITK_CALL(TCTYPE_ask_name(secondary_obj_type_tag,secondary_obj_type_name));
		printf("\n Secondary_object type_name is:%s",secondary_obj_type_name);fflush(stdout);

		if((tc_strcmp(secondary_obj_type_name,"VariantRule") == 0))
		{
			POM_get_user_id (&username);
			printf("\nLogged in user:%s\n",username); fflush(stdout);

			char *SupportUsername9 = NULL;
			tag_t SessionUser9_tag=NULLTAG;
			int     SupportFlag      =  0;

			SupportFlag=0;
			POM_get_user(&SupportUsername9,&SessionUser9_tag);
			if(SessionUser9_tag!=NULLTAG)
			{
				SupportFlag=0;
				SupportFlag = CheckSupportLogin(SessionUser9_tag);
				printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
			}
			//Bypass for dba users
			if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
			{
				ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&Smc0HasVariantConfigContext_Rel_tag));
				printf("\n after finding Smc0HasVariantConfigContext \n");fflush(stdout);

				//Finding platform attached to Config Context i.e. primaray object
				ITK_CALL(GRM_list_primary_objects_only(primary_object, Smc0HasVariantConfigContext_Rel_tag, &platformCount, &paltFormTag));
				printf("\n  platformCount.:%d\n",platformCount);fflush(stdout);

				if(platformCount >0)
				{

					platFormNodeTag = paltFormTag[0];

					ITK_CALL(AOM_ask_value_string(platFormNodeTag,"item_id",&platFormItemID));
					ITK_CALL(AOM_ask_value_string(platFormNodeTag,"object_string",&platFormObject_string));

					ITK_CALL(AOM_ask_value_string(secondary_object,"object_string",&secObjString));

					printf("\n platFormItemID is: %s \n",platFormItemID);fflush(stdout);

					//Querying the Control Objects.
					if(QRY_find("Control Objects...", &Cntl_obj_Qtag));

					qry_values[0] = "SPLIT_PLATFORM";
					qry_values[1] = "SPLIT_PLATFORM_SVR_CHECK";
					qry_values[2] = platFormItemID;

					ITK_CALL(QRY_execute(Cntl_obj_Qtag, n_entries, qry_entries, qry_values, &resultCount, &qry_cntrlobj));
					if (resultCount > 0)
					{
						printf("\n***** CONTROL OBJECT found*****\n");fflush(stdout);
						//Reading project code from Cntrl Object;

						ITK_CALL(AOM_ask_value_string(qry_cntrlobj[0],"t5_Userinfo2",&userinfo_2));
						printf("userinfo_2 is : %s \n",userinfo_2);

						//In sub string 0 is starting position and 4 is no of char
						subStrProjectCode=subString(secObjString, 0, 4);
						printf("subStrProjectCode is : %s \n",subStrProjectCode);

						if((tc_strstr(userinfo_2,subStrProjectCode)==NULL))
						{
							//Error msg:
							errorMsg=(char *)MEM_alloc(200);
							printf("After mem alloc\n");
							tc_strcpy (errorMsg, "SVR :");
							strcat(errorMsg,secObjString);
							strcat(errorMsg," of Project code : ");
							strcat(errorMsg,subStrProjectCode);
							strcat(errorMsg,", is not applicable for selected configurator context.");
							//Not allowed give error here.
							EMH_store_error_s1(EMH_severity_error,ITK_err,errorMsg);
							return ITK_err;
						}

					}
					else
					{
						printf("\n\t Control Object Not Found");
					}

				}
				else
				{
					printf("\n\t NO Platform Found");
				}

			}

		}
		else
		{
			printf("\n\t Validation is not requrired for this type of object, I am in secondary obj if.");
		}

	}
	else
	{
		printf("\n\t Validation is not requrired for this type of object");

	}

	return ifail;

}
//16-03-2023
int bom_WindowSave_Validation(METHOD_message_t *msg, va_list args)
{

	printf("\n ***************** I am in ::bom_WindowSave_Validation:: ********************");fflush(stdout);

		int			child_attr			= 0;
		int			child_attr1			= 0;
		int			Item_attr			= 0;
		int			blobjType			= 0;
		int			bl_Child_objType			= 0;
		int			Rev_attr			= 0;
		int			bl_abs_xform		= 0;
		int			bl_relative_xform	= 0;
		int			chlidLine_Count		= 0;
		int			i					= 0;
		int			error_code			= ITK_ok;
		char		*child_qty			= NULL;
		char		*child_PartType			= NULL;
		char		*child_qty1			= NULL;
		char		*Item_id			= NULL;
		char		*Item_rev_id		= NULL;

		char		*child_Item_id			= NULL;
		char		*child_Item_rev_id		= NULL;
		char		*topLineObjectType		= NULL;

		char		*child_part_type	= NULL;
		char		*child_obj_type		= NULL;
		char		*parent_obj_type	= NULL;
		char		*child_item_id2		= NULL;
		char		*child_item_id		= NULL;
		char		*ApplnOwner			= NULL;
		char		*child_abs_xform	= NULL;
		char		*child_relv_xform	= NULL;
		char		*child_rev_id		= NULL;

		//

		tag_t top_bom_line				= NULLTAG;
		tag_t *childLines				= NULLTAG;
		tag_t		revision_tag		= NULLTAG;

		tag_t window_tag = va_arg( args, tag_t );

		//Control Obj for On and Off Validation.
		tag_t	qry_t1_bomSave			= NULLTAG;
		char **qry_val3_bomSave			= (char **) MEM_alloc(100 * sizeof(char *));
		char    *qry_entr1_bomSave[1]   = {"SYSCD"};
		int n_entr1_bomSave				= 1;
		int rsltCunt1_bomSave			= 0;
		tag_t *CntrlObjTag1_bomSave		= NULLTAG;

		char* usrInfo1_bomSave			= NULL;
		char* usrInfo2_bomSave			= NULL;


		if(QRY_find("ControlObjects", &qry_t1_bomSave));
		if (qry_t1_bomSave)
		{
			printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
		}
		qry_val3_bomSave[0] = "BOMWindowSaveEvent";
		if(QRY_execute(qry_t1_bomSave, n_entr1_bomSave, qry_entr1_bomSave, qry_val3_bomSave, &rsltCunt1_bomSave, &CntrlObjTag1_bomSave));

		if(rsltCunt1_bomSave>0)
		{

			ITKCALL(BOM_ask_window_top_line(window_tag,&top_bom_line));
			ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_attr))PrintErrorStack();
			ITKCALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Rev_attr))PrintErrorStack();
			ITKCALL(BOM_line_look_up_attribute ("bl_quantity",&child_attr))PrintErrorStack();

			ITKCALL(BOM_line_ask_attribute_string(top_bom_line, Item_attr, &Item_id))PrintErrorStack();
			ITKCALL(BOM_line_ask_attribute_string(top_bom_line, Rev_attr, &Item_rev_id))PrintErrorStack();

			ITKCALL(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType))PrintErrorStack();

			ITKCALL(BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&bl_Child_objType))PrintErrorStack();
			ITKCALL(BOM_line_ask_attribute_string(top_bom_line, blobjType, &topLineObjectType))PrintErrorStack();


			printf("\n\t topLineObjectType => [%s]\n",topLineObjectType);fflush(stdout);


			ITKCALL(AOM_ask_value_string(CntrlObjTag1_bomSave[0],"t5_Userinfo1",&usrInfo1_bomSave));
			printf("\n\t ****usrInfo1_bomSave => %s*****\n",usrInfo1_bomSave);fflush(stdout);

			//if (tc_strcmp(topLineObjectType,"T5_ArchModuleRevision")==0)
			if((tc_strstr(usrInfo1_bomSave,topLineObjectType) != NULL))
			{
					 printf("\n\t *****Parent_bomline ID => %s*****\n",Item_id);fflush(stdout);
					 printf("\n\t *****Parent_bomline Rev ID => %s*****\n",Item_rev_id);fflush(stdout);


					 ITKCALL(AOM_ask_value_string(CntrlObjTag1_bomSave[0],"t5_Userinfo2",&usrInfo2_bomSave));
					 printf("\n\t ****usrInfo2_bomSave => %s*****\n",usrInfo2_bomSave);fflush(stdout);

					//Getting all child of Top Line
					ITKCALL(BOM_line_ask_child_lines(top_bom_line,&chlidLine_Count,&childLines));
					for(i =0; i < chlidLine_Count;i++)
					{
						ITKCALL(BOM_line_ask_attribute_string(childLines[i], Item_attr, &child_Item_id))PrintErrorStack();
						ITKCALL(BOM_line_ask_attribute_string(childLines[i], Rev_attr, &child_Item_rev_id))PrintErrorStack();
						ITKCALL(BOM_line_ask_attribute_string(childLines[i], child_attr, &child_qty))PrintErrorStack();
						ITKCALL(BOM_line_ask_attribute_string(childLines[i], bl_Child_objType, &child_PartType))PrintErrorStack();

						printf("\n\t child_PartType => [%s]\n",child_PartType);fflush(stdout);

						//if (tc_strcmp(child_PartType,"Module")==0 || tc_strcmp(child_PartType,"M") ==0)
						if((tc_strstr(usrInfo2_bomSave,child_PartType) != NULL))
						{
								printf("\n\t **child_Item_id=> [%s]**\n",child_Item_id);fflush(stdout);
								printf("\n\t **child_Item_rev_id => [%s]**\n",child_Item_rev_id);fflush(stdout);
								printf("\n\t **child_qty => [%s]**\n",child_qty);fflush(stdout);

								if(tc_strcmp(child_qty, "0") == 0 || tc_strlen(child_qty) == 0)
								{
									ITKCALL(AOM_UIF_set_value(childLines[i], "bl_quantity", "1") != ITK_ok);PrintErrorStack();
									printf("\nQuantity set to 1\n");fflush(stdout);
								}

						}
					}

			 }
		}
		else
		{
			printf("\n bom_WindowSave_Validation is OFF !! \n");fflush(stdout);

		}


	return error_code;
}
int carryMastSlvRelationOnReviseForEEPartRev(METHOD_message_t *msg, va_list args)
{
	printf("\n ***************** I am in ::carryMastSlvRelationOnReviseForEEPartRev:: ********************");fflush(stdout);

	//int			error_code					= ITK_ok;

	//Control Obj for On and Off Validation.
	tag_t	qry_t1MastSlv			= NULLTAG;
	char **qry_val3MastSlv			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1MastSlv[1]   = {"SYSCD"};
	int n_entr1MastSlv				= 1;
	int rsltCunt1MastSlv			= 0;
	tag_t *CntrlObjTag1MastSlv		= NULLTAG;
	
	//
	
	int			error_code					= ITK_ok;
	tag_t        source_rev					= va_arg( args, tag_t );
	const char*  rev_id						= va_arg( args, const char* );
	tag_t*       new_rev					= va_arg( args,  tag_t* );
	tag_t        item_rev_master_form		= va_arg( args, tag_t );

	char* source_revObject_string  = NULL;
	char* new_revObject_string	 = NULL;
	tag_t MastSlvRelTag	 = NULL;


	
	int			masterCout					= 0;
	tag_t*		masterTag					= NULLTAG;
	int			i1							= 0;
	int			j1							= 0;

	int			slaveCount					= 0;
	tag_t*		SlaveTag					= NULLTAG;

	char*			slaveObjStr					= NULL;
	tag_t		    relationTag					= NULLTAG;
	tag_t			newRelation					= NULLTAG;
	char*			MasterItemRevId				= NULLTAG;
	char*			MasterObject_string				= NULLTAG;
	tag_t			masterItemTag				= NULLTAG;
	tag_t			MasterLatestItemRevTag		= NULLTAG;
	char*			MasterLatestItemRevID		= NULLTAG;



	if(QRY_find("ControlObjects", &qry_t1MastSlv));
	if (qry_t1MastSlv)
	{
		printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
	}
	qry_val3MastSlv[0] = "MasterSlavContRelForRevise";
	if(QRY_execute(qry_t1MastSlv, n_entr1MastSlv, qry_entr1MastSlv, qry_val3MastSlv, &rsltCunt1MastSlv, &CntrlObjTag1MastSlv));

	printf("\n\t ****rsltCunt1MastSlv => %d*****\n",rsltCunt1MastSlv);fflush(stdout);

	if(rsltCunt1MastSlv>0)
	{
		ITKCALL(AOM_ask_value_string(source_rev,"object_string",&source_revObject_string));
		ITKCALL(AOM_ask_value_string(*new_rev,"object_string",&new_revObject_string));

	    printf("\n\t ****source_revObject_string => %s*****\n",source_revObject_string);fflush(stdout);
	    printf("\n\t ****new_revObject_string => %s*****\n",new_revObject_string);fflush(stdout);

		ITK_CALL(GRM_find_relation_type("T5_ContHasSlave",&MastSlvRelTag));
		printf("\n after finding MastSlvRelTag \n");fflush(stdout);

		ITK_CALL(GRM_list_primary_objects_only(source_rev, MastSlvRelTag, &masterCout, &masterTag));
		printf("\n  masterCout.:%d\n",masterCout);fflush(stdout);

		if(masterCout > 0)
	    {
			printf("\n\t ****Slave has Master container*****\n");fflush(stdout);
			for(i1= 0 ;i1 < masterCout; i1++)
		    {

				ITKCALL(AOM_ask_value_string(masterTag[i1],"object_string",&MasterObject_string));
				printf("\n MasterObject_string is :%s\n",MasterObject_string);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(masterTag[i1],"item_revision_id",&MasterItemRevId));
				printf("\n MasterItemRevId is :%s\n",MasterItemRevId);fflush(stdout);

				ITK_CALL(ITEM_ask_item_of_rev(masterTag[i1],&masterItemTag));
				ITK_CALL(ITEM_ask_latest_rev(masterItemTag,&MasterLatestItemRevTag));

				ITK_CALL(AOM_ask_value_string(MasterLatestItemRevTag,"item_revision_id",&MasterLatestItemRevID));
				printf("\n MasterLatestItemRevID :%s\n",MasterLatestItemRevID);fflush(stdout);
				//CHEK FOR ONLY LATEST  REV OF MASTER CONTAINER
				//if(strcmp(MasterItemRevId,MasterLatestItemRevID)==0)
				//{
				ITK_CALL(GRM_list_secondary_objects_only(masterTag[i1], MastSlvRelTag, &slaveCount, &SlaveTag));
				printf("\n  slaveCount.:%d\n",slaveCount);fflush(stdout);

				 if(slaveCount > 0)
				 {
					  for(j1 =0; j1 < slaveCount; j1++)
					  {
						 ITKCALL(AOM_ask_value_string(SlaveTag[j1],"object_string",&slaveObjStr));
						 printf("\n\t ****slaveObjStr => %s*****\n",slaveObjStr);fflush(stdout);

//						 if((tc_strcmp(source_revObject_string,slaveObjStr) == 0))
//						 {
//							 ITK_CALL(GRM_find_relation(masterTag[i1], SlaveTag[j1], MastSlvRelTag, &relationTag));
//							 if(relationTag)
//							 {
//								ITK_CALL(GRM_delete_relation(relationTag));
//								printf("\n\t ****OLD Slave Revision has been removed.*****\n");fflush(stdout);
//
//							 }
//
//						 }

					  }
				 }
				 ITK_CALL(AOM_refresh(masterTag[i1],1));
				 ITK_CALL(GRM_create_relation(masterTag[i1], *new_rev, MastSlvRelTag, NULLTAG,&newRelation));
				 ITK_CALL(GRM_save_relation(newRelation));
				 ITK_CALL(AOM_save(masterTag[i1]));
				 ITK_CALL(AOM_refresh(masterTag[i1],0));
				 printf("\n\t ****Relation is created with Master and Latest slave revision.*****\n");fflush(stdout);
				//}

			}

		}

	}
	else
	{
		printf("\n Auto Relation Carryforword is OFF !! \n");fflush(stdout);

	}

	return error_code;

}
int carryMastSlvRelationOnCheckOutForEEPartRev(METHOD_message_t *msg, va_list args)
{
	 printf("\n ***************** I am in ::carryMastSlvRelationOnCheckOutForEEPartRev:: ********************");fflush(stdout);
	 int			error_code					= ITK_ok;

	 tag_t objTag = va_arg(args, tag_t);

	 char* ObjStr = NULL;
	 tag_t objTypeTag,item_tag = NULLTAG;
	 char  type_name[TCTYPE_name_size_c+1];
	 char* itemRevIDObj =	NULL;
	 tag_t			ItemTag				= NULLTAG;
	 char*			ObjStrItem			= NULLTAG;
	 int			count1				= 0;
	 tag_t *		rev_list1			= NULLTAG;
	 int			i1					=	0;
	 int			j1					=	0;
	 int			k1					=   0;

	 char*			Prevrev_tagItemRevID	= NULL;
	 char*			Prevrev_tagObjStr		= NULL;
	 tag_t			MastSlvRelTag			=  NULLTAG;
	 int			masterCout					= 0;
	 tag_t*			masterTag					= NULLTAG;

	//char*			slaveObjStr					= NULL;
	//tag_t		    relationTag					= NULLTAG;
	//tag_t			newRelation					= NULLTAG;

	char*			MasterItemRevId				= NULLTAG;
	char*			MasterObject_string				= NULLTAG;
	tag_t			masterItemTag				= NULLTAG;
	tag_t			MasterLatestItemRevTag		= NULLTAG;
	char*			MasterLatestItemRevID		= NULLTAG;

	int			    slaveCount					= 0;
	tag_t*		    SlaveTag					= NULLTAG;
	char*			slaveObjStr					= NULL;
	tag_t		    relationTag					= NULLTAG;
	tag_t			newRelation					= NULLTAG;

	 //Control Obj for On and Off Validation.
	tag_t	qry_t1MastSlv			= NULLTAG;
	char **qry_val3MastSlv			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1MastSlv[1]   = {"SYSCD"};
	int n_entr1MastSlv				= 1;
	int rsltCunt1MastSlv			= 0;
	tag_t *CntrlObjTag1MastSlv		= NULLTAG;


	ITKCALL(AOM_ask_value_string(objTag,"object_string",&ObjStr));
	printf("\n\t ****ObjStr => %s*****\n",ObjStr);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok) PrintErrorStack();

	if(tc_strcmp(type_name,"T5_EE_PartRevision")==0)
	{
			if(QRY_find("ControlObjects", &qry_t1MastSlv));
			if (qry_t1MastSlv)
			{
				printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
			}
			qry_val3MastSlv[0] = "MasterSlavContRelForCheckOut";
			if(QRY_execute(qry_t1MastSlv, n_entr1MastSlv, qry_entr1MastSlv, qry_val3MastSlv, &rsltCunt1MastSlv, &CntrlObjTag1MastSlv));
			printf("\n\t ****rsltCunt1MastSlv => %d*****\n",rsltCunt1MastSlv);fflush(stdout);


			if(rsltCunt1MastSlv>0)
			{

					ITK_CALL(GRM_find_relation_type("T5_ContHasSlave",&MastSlvRelTag));
					printf("\n after finding MastSlvRelTag \n");fflush(stdout);

					printf("\n\t ****T5_EE_PartRevision Found..*****\n");fflush(stdout);

					ITKCALL(AOM_ask_value_string(objTag,"item_revision_id",&itemRevIDObj));
					printf("\n\t ****itemRevIDObj => %s*****\n",itemRevIDObj);fflush(stdout);

					ITK_CALL(ITEM_ask_item_of_rev(objTag,&ItemTag));

					ITKCALL(AOM_ask_value_string(ItemTag,"object_string",&ObjStrItem));
					printf("\n\t ****ObjStrItem => %s*****\n",ObjStrItem);fflush(stdout);
					ITKCALL(ITEM_list_all_revs(ItemTag,&count1,&rev_list1));

					printf("\n\t **** Total Rev count is :: => %d*****\n",count1);fflush(stdout);

				   for(i1=count1-1;i1>=0;i1--)
				   {
						  printf("\n  -- :: i1  ::-- %d ",i1);fflush(stdout);

						  if( AOM_ask_value_string(rev_list1[i1],"object_string",&Prevrev_tagObjStr)!=ITK_ok);PrintErrorStack();
						  if( AOM_ask_value_string(rev_list1[i1],"item_revision_id",&Prevrev_tagItemRevID)!=ITK_ok);PrintErrorStack();

						  printf("\n Prevrev_tagObjStr  ::-- %s ",Prevrev_tagObjStr);fflush(stdout);
						  printf("\n Previous revision Item Rev Id %s ",Prevrev_tagItemRevID);fflush(stdout);

						  ITK_CALL(GRM_list_primary_objects_only(rev_list1[i1], MastSlvRelTag, &masterCout, &masterTag));
						  printf("\n  masterCout.:%d\n",masterCout);fflush(stdout);

						  if(masterCout > 0)
						  {
								printf("\n\t ****Slave has Master container*****\n");fflush(stdout);
								for(j1= 0 ;j1 < masterCout; j1++)
								{

									ITKCALL(AOM_ask_value_string(masterTag[j1],"object_string",&MasterObject_string));
									printf("\n MasterObject_string is :%s\n",MasterObject_string);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(masterTag[j1],"item_revision_id",&MasterItemRevId));
									printf("\n MasterItemRevId is :%s\n",MasterItemRevId);fflush(stdout);

									ITK_CALL(ITEM_ask_item_of_rev(masterTag[j1],&masterItemTag));
									ITK_CALL(ITEM_ask_latest_rev(masterItemTag,&MasterLatestItemRevTag));

									ITK_CALL(AOM_ask_value_string(MasterLatestItemRevTag,"item_revision_id",&MasterLatestItemRevID));
									printf("\n MasterLatestItemRevID :%s\n",MasterLatestItemRevID);fflush(stdout);
									//CHEK FOR ONLY LATEST  REV OF MASTER CONTAINER
									//if(strcmp(MasterItemRevId,MasterLatestItemRevID)==0)
									//{

									ITK_CALL(GRM_list_secondary_objects_only(masterTag[j1], MastSlvRelTag, &slaveCount, &SlaveTag));
									printf("\n  slaveCount.:%d\n",slaveCount);fflush(stdout);

									if(slaveCount > 0)
									{
										 for(k1 =0; k1 < slaveCount; k1++)
										 {

											   ITKCALL(AOM_ask_value_string(SlaveTag[k1],"object_string",&slaveObjStr));
											   printf("\n\t ****slaveObjStr => %s*****\n",slaveObjStr);fflush(stdout);
//												if((tc_strcmp(Prevrev_tagObjStr,slaveObjStr) == 0))
//												{
//													 ITK_CALL(GRM_find_relation(masterTag[j1], SlaveTag[k1], MastSlvRelTag, &relationTag));
//													 if(relationTag)
//													 {
//														ITK_CALL(GRM_delete_relation(relationTag));
//														printf("\n\t ****OLD Slave Revision has been removed.*****\n");fflush(stdout);
//
//													 }
//
//												}

										  }

									 } // if for slave count.

									 ITK_CALL(AOM_refresh(masterTag[j1],1));
									 ITK_CALL(GRM_create_relation(masterTag[j1], objTag, MastSlvRelTag, NULLTAG,&newRelation));
									 ITK_CALL(GRM_save_relation(newRelation));
									 ITK_CALL(AOM_save(masterTag[j1]));
									 ITK_CALL(AOM_refresh(masterTag[j1],0));
									 printf("\n\t ****Relation is created with Master and Latest slave revision.*****\n");fflush(stdout);


									//}// if for latest master rev check.


								} // for for master count

						  }// if for Master count

						  //Just need to consider previous revision only.
						 int tempCount = 0;
						 tempCount = count1 -2;
						 printf("\n\t **** tempCount :: => %d*****\n",tempCount);fflush(stdout);
						 if(tempCount == i1)
						 {
							break;
						 }
						 // break;

				   } // for for Rev List


			}
			else
			{
				printf("\n Auto Relation Carryforword is OFF  :: RES CheckOutMsg !! \n");fflush(stdout);
				
			}

	}
	else
	{
		printf("\n Not a Valid Obj Type for  :: carryMastSlvRelationOnCheckOutForEEPartRev !! \n");fflush(stdout);
	}
	return error_code;

}

//CCVC_PreAction_Validation
/*int CCVC_PreAction_Validation(METHOD_message_t *msg, va_list args)
{

	printf("\n *************INSIDE CCVC_PreAction_Validation******************** \n");fflush(stdout);
	int		ifail							= 0;

	//char* item_id				= va_arg(args, char*);
	//char* item_name				= va_arg(args, char*);
	//char* type_name				= va_arg(args, char*);
	//char* item_rev_id			= va_arg(args, char*);

	//tag_t* new_item				=va_arg(args, tag_t*);
	//tag_t* new_rev				=va_arg(args, tag_t*);
	//tag_t* item_master_form		=va_arg(args, tag_t*);
	//tag_t* item_rev_master_form	=va_arg(args, tag_t*);

	tag_t objTypeTag = NULLTAG;
	char  type_name[TCTYPE_name_size_c+1];

	tag_t objTag = va_arg(args, tag_t);

	//Control Obj for On and Off Validation.
	tag_t	qry_t1_CCVCVal			= NULLTAG;
	char **qry_val3_CCVCVal			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1_CCVCVal[1]   = {"SYSCD"};
	int n_entr1_CCVCVal				= 1;
	int rsltCunt1_CCVCVal			= 0;
	tag_t *CntrlObjTag1_CCVCVal		= NULLTAG;

	//tag_t new_rev_type_tag = NULL;
	//char new_rev_obj_type_name[WSO_name_size_c+1];
	char    *PartType               = NULL;
	char    *ProjectCode               = NULL;
	char*	 usrInfo1				= NULL;
	char* errorMsgCCVCVal =NULL;
	char* colourInd =NULL;
	char* objectString =NULL;
	char* itemRevID =NULL;


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();


	printf("\n type_name is:%s",type_name);fflush(stdout);

	//This check is applicable for only Desg Rev
	if((tc_strcmp(type_name,"Design Revision") == 0))
	{
		ITK_CALL(AOM_ask_value_string(objTag,"t5_PartType",&PartType));
		ITK_CALL(AOM_ask_value_string(objTag,"t5_ProjectCode",&ProjectCode));
		ITK_CALL(AOM_ask_value_string(objTag,"t5_ColourInd",&colourInd));
		ITK_CALL(AOM_ask_value_string(objTag,"object_string",&objectString));
		ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&itemRevID));


		printf("\n\n\t\t t5_PartType := %s \n",PartType);fflush(stdout);
		printf("\n\n\t\t t5_ProjectCode := %s \n",ProjectCode);fflush(stdout);
		printf("\n\n\t\t t5_ColourInd := %s \n",colourInd);fflush(stdout);
		printf("\n\n\t\t objectString := %s \n",objectString);fflush(stdout);
		printf("\n\n\t\t item_revision_id := %s \n",itemRevID);fflush(stdout);

		//Part type check.
		if((tc_strcmp(PartType,"CCVC") == 0) || (tc_strcmp(PartType,"V") == 0) )
		{
			//This validation is applicable for only non colour objects
			if((tc_strcmp(colourInd,"N") == 0))
			{
				if((tc_strcmp(itemRevID,"NR;1") == 0))
				{

					if(QRY_find("ControlObjects", &qry_t1_CCVCVal));
					if (qry_t1_CCVCVal)
					{
						printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
					}
					qry_val3_CCVCVal[0] = "CCVC/SVR Check";
					if(QRY_execute(qry_t1_CCVCVal, n_entr1_CCVCVal, qry_entr1_CCVCVal, qry_val3_CCVCVal, &rsltCunt1_CCVCVal, &CntrlObjTag1_CCVCVal));

					if(rsltCunt1_CCVCVal>0)
					{
						printf("\n Part type CCVC / V found \n");fflush(stdout);
						ITK_CALL(AOM_ask_value_string(CntrlObjTag1_CCVCVal[0],"t5_Userinfo1",&usrInfo1));

							if((tc_strstr(usrInfo1,ProjectCode) != NULL))
							{
									// Need to give error, design rev should not create here
									errorMsgCCVCVal=(char *)MEM_alloc(200);
									printf("After mem alloc\n");
									tc_strcpy (errorMsgCCVCVal, "CCVC/V : ");
									strcat(errorMsgCCVCVal,objectString);
									strcat(errorMsgCCVCVal,",of Project code : ");
									strcat(errorMsgCCVCVal,ProjectCode);
									strcat(errorMsgCCVCVal,", is not allowed to create.");
									//Not allowed give error here.
									EMH_store_error_s1(EMH_severity_error,ITK_err,errorMsgCCVCVal);
									return ITK_err;

						    }
							else
							{
								printf("\n CCVC_PreAction_Validation ::Object creation is allowed, As Porject code is not LOCK for creation. \n");fflush(stdout);
							}

					}
					else
					{
						printf("\n CCVC_PreAction_Validation:: Control Object no found, Validation is OFF \n");fflush(stdout);
					}
				}
				else
				{
					printf("\n\n\t\t CCVC_PreAction_Validation:: Validation is not applicable, Rev Seq is not NR1");fflush(stdout);
				}
			}
			else
			{
					printf("\n\n\t\t CCVC_PreAction_Validation:: Validation is not applicable, Colour indicator is Y");fflush(stdout);
			}

		}
		else
		{
			printf("\n\n\t\t CCVC_PreAction_Validation :: Validation is not applicable for :  t5_PartType := %s \n",PartType);fflush(stdout);
		}


	  }
	return ifail;

}
*/
extern int t8save_design_custom_exit(int *decision, va_list args)
{
	int ifail = ITK_ok;
	METHOD_id_t  method ;
	METHOD_id_t  method1 ;
	METHOD_id_t  method2 ;
	METHOD_id_t  method3 ;
	METHOD_id_t  method4 ; //Adi
	METHOD_id_t  methodSVR ;
	METHOD_id_t  methodVendor ;
	METHOD_id_t  methodBOM ;
 	METHOD_id_t  methodVF ;
	//Neha (CR-FY23-0145)
	METHOD_id_t  methodDR ;
	METHOD_id_t  methodColInd ;
	METHOD_id_t  methodCompCode ;
	METHOD_id_t  methodEnvDim ;
	METHOD_id_t	 methodDesGrp ;
	METHOD_id_t	 methodSpareCri ;
	METHOD_id_t  methodSpareInd ;
	METHOD_id_t  methodMatCls ;
	METHOD_id_t  methodMaterial ;
	METHOD_id_t  methodPrtTyp ;
	METHOD_id_t  methodProjCode ;
	METHOD_id_t  methodRevPrtTyp ;
	METHOD_id_t  methodWeight ;
	METHOD_id_t  methodRolledupWt ;
	METHOD_id_t  methodUom ;
	METHOD_id_t  methodAhdMakeBuyInd ;
	METHOD_id_t  methodCarMakeBuyInd ;
	METHOD_id_t  methodPunPCBUMakeBuyInd ;
	METHOD_id_t	 methodPunUvMakeBuyInd ;
	METHOD_id_t	 methodKeyDesc ;
	//v2
	METHOD_id_t	 methodARDRSts ;
	METHOD_id_t	 methodAddOnDes ;
	METHOD_id_t	 methodDesignGrp ;
	METHOD_id_t  methodDesignMileStone;
	METHOD_id_t  methodEEMatCls;
	METHOD_id_t  methodEEPrtPara;
	METHOD_id_t  methodEEPrtMileStone;
	METHOD_id_t  methodEEPrtTyp;
	METHOD_id_t  methodEEEcuTyp;
	METHOD_id_t  methodKeyDescClPrt;
	METHOD_id_t  methodKeyDescDesign;
	METHOD_id_t  methodModDescDesRev;
	METHOD_id_t  methodModDescClPrt;
	METHOD_id_t  methodModule;
	METHOD_id_t  methodAddr;
	METHOD_id_t  methodModGrp;
	METHOD_id_t  methodModNme;
	METHOD_id_t  methodModTyp;
	METHOD_id_t  methodPrtMaterial;
	METHOD_id_t  methodPrtType;
	METHOD_id_t  methodProCode;
	METHOD_id_t  methodProIds;
	METHOD_id_t  methodSWPrtTyp;
	METHOD_id_t  methodUnitofMeasure;
	METHOD_id_t  methodUOMDesign;

	METHOD_id_t  methodDesc;
	METHOD_id_t  methodDescEE;
	METHOD_id_t  methodDrawingInd;
	METHOD_id_t  methodDrawingIndClr;
	METHOD_id_t  methodDrawingNo;
	METHOD_id_t  methodLoc;
	METHOD_id_t  methodMainSrl;
	METHOD_id_t  methodRemrk;
	METHOD_id_t  methodDesgnGrp;
	METHOD_id_t  methodDmlNo;
	METHOD_id_t  methodColIndClr;
	METHOD_id_t  methodCoated;
	METHOD_id_t  methodCoatedClr;
	METHOD_id_t  methodWtClr;
	METHOD_id_t  methodWtEE;
	METHOD_id_t  methodMatClsClr;
	METHOD_id_t  methodCompCodeClr;
	METHOD_id_t  methodRolledUpWeight;
	METHOD_id_t  methodOwnerDesignUnt;
	METHOD_id_t  methodOwnerDesignUntClr;
	METHOD_id_t  methodHomoInd;
	METHOD_id_t  methodCMVR;
	METHOD_id_t  methodSurfAra;
	METHOD_id_t  methodTT;
	METHOD_id_t  methodSupplierNme;
	//Neha

	//Kalpesh
	METHOD_id_t		method_ee_part;
	METHOD_id_t		method_arch_module_access;
	METHOD_id_t		method_platform_access;
 	METHOD_id_t		method_bl_cut;
	METHOD_id_t		method_quantity;
	METHOD_id_t		method_para_clause;
	METHOD_id_t		method_durafit;
	METHOD_id_t		method_para_Save;
	METHOD_id_t		method_CCV_ECU;
	METHOD_id_t		method_Ecu_para_Save;

	//Kirtikumar 10/10/2022
	METHOD_id_t		method_svr_validation;
	METHOD_id_t		method_ccvc_validation;
	//METHOD_id_t		method_ccvc_validation1;
	//16-March-2023
	METHOD_id_t		method_bom_windowSave_validation;

	METHOD_id_t		method_ee_Part_Revise;
	METHOD_id_t		method_ee_Part_checkOut;

	*decision = ALL_CUSTOMIZATIONS;

	/* do something useful here, for now just return */
	printf("\n\n CreateDesign.c:it, via Custom User Exit.\n");fflush(stdout);
	if ( METHOD_find_method("Design", IMAN_save_msg, &method) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("Design Revision", IMAN_save_msg, &method1) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("CMI2Drawing", AE_save_dataset_msg, &method2) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("BOMLine", BOMLine_add_msg, &method3) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("VariantRule", IMAN_save_msg, &methodSVR) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("Vendor", IMAN_save_msg, &methodVendor) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("BOMView Revision","PS_bvr_create_occs",&methodBOM) !=ITK_ok);PrintErrorStack();//uppp
	if ( METHOD_find_prop_method("BOMLine","bl_formula", PROP_set_value_tag_msg,&methodVF) !=ITK_ok);PrintErrorStack();   //Prachi
	//Neha(CR-FY23-0145)
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PartStatus", PROP_set_value_string_msg, &methodDR) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ColourInd", PROP_set_value_string_msg, &methodColInd) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PrtCatCode", PROP_set_value_string_msg, &methodCompCode) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_EnvelopeDimensions", PROP_set_value_string_msg, &methodEnvDim) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DesignGrp", PROP_set_value_string_msg, &methodDesGrp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_SpareCriteria", PROP_set_value_string_msg, &methodSpareCri) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_SpareInd", PROP_set_value_string_msg, &methodSpareInd) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_MatlClass", PROP_set_value_string_msg, &methodMatCls) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Material", PROP_set_value_string_msg, &methodMaterial) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PartType", PROP_set_value_string_msg, &methodPrtTyp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ProjectCode", PROP_set_value_string_msg, &methodProjCode) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design_t5_RevPartType", PROP_set_value_string_msg, &methodRevPrtTyp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Weight", PROP_set_value_string_msg, &methodWeight) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_RolledupWt", PROP_set_value_string_msg, &methodRolledupWt) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_uom", PROP_set_value_string_msg, &methodUom) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_AhdMakeBuyIndicator", PROP_set_value_string_msg, &methodAhdMakeBuyInd) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_CarMakeBuyIndicator", PROP_set_value_string_msg, &methodCarMakeBuyInd) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PunPCBUMakeBuyIndicator", PROP_set_value_string_msg, &methodPunPCBUMakeBuyInd) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PunUVMakeBuyIndicator", PROP_set_value_string_msg, &methodPunUvMakeBuyInd) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_CategoryName", PROP_set_value_string_msg, &methodKeyDesc) !=ITK_ok);PrintErrorStack();
	//v2
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_PartStatus", PROP_set_value_string_msg, &methodARDRSts) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_SimVal", PROP_set_value_string_msg, &methodAddOnDes) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_DesignGrp", PROP_set_value_string_msg, &methodDesignGrp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DesignMilestoneStatus", PROP_set_value_string_msg, &methodDesignMileStone) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_EE_MatClass", PROP_set_value_string_msg, &methodEEMatCls) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_T5_EEPrm", PROP_set_value_string_msg, &methodEEPrtPara) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_EEPartMilestoneStatus", PROP_set_value_string_msg, &methodEEPrtMileStone) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_EE_PartType", PROP_set_value_string_msg, &methodEEPrtTyp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_EcuType", PROP_set_value_string_msg, &methodEEEcuTyp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_CategoryName", PROP_set_value_string_msg, &methodKeyDescClPrt) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design_t5_RevCategoryName", PROP_set_value_string_msg, &methodKeyDescDesign) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DocRemarks", PROP_set_value_string_msg, &methodModDescDesRev) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_DocRemarks", PROP_set_value_string_msg, &methodModDescClPrt) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Module", PROP_set_value_string_msg, &methodModule) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ModuleAddress", PROP_set_value_string_msg, &methodAddr) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Module_Group", PROP_set_value_string_msg, &methodModGrp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ModuleName", PROP_set_value_string_msg, &methodModNme) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ModuleType", PROP_set_value_string_msg, &methodModTyp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_Material", PROP_set_value_string_msg, &methodPrtMaterial) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_PartType", PROP_set_value_string_msg, &methodPrtType) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_ProjectCode", PROP_set_value_string_msg, &methodProCode) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_rorev_project_ids", PROP_set_value_string_msg, &methodProIds) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_SwPartType", PROP_set_value_string_msg, &methodSWPrtTyp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design_t5_uom", PROP_set_value_string_msg, &methodUOMDesign) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_uom", PROP_set_value_tag_msg, &methodUnitofMeasure) !=ITK_ok);PrintErrorStack();

	if ( METHOD_find_prop_method("BOMLine", "bl_rorev_object_desc", PROP_set_value_string_msg, &methodDesc) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_Description", PROP_set_value_string_msg, &methodDescEE) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DrawingInd", PROP_set_value_string_msg, &methodDrawingInd) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_DrawingInd", PROP_set_value_string_msg, &methodDrawingIndClr) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DrawingNo", PROP_set_value_string_msg, &methodDrawingNo) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_occ_t5_Location", PROP_set_value_string_msg, &methodLoc) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_occ_t5_MainSerial", PROP_set_value_string_msg, &methodMainSrl) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_occ_t5_Remark", PROP_set_value_string_msg, &methodRemrk) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_rev_t5designgroup", PROP_set_value_string_msg, &methodDesgnGrp) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_occ_t5_WbsID", PROP_set_value_string_msg, &methodDmlNo) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_ColourInd", PROP_set_value_string_msg, &methodColIndClr) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Coated", PROP_set_value_string_msg, &methodCoated) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_Coated", PROP_set_value_string_msg, &methodCoatedClr) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_Weight", PROP_set_value_string_msg, &methodWtClr) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Mfg0MEEquipmentRevision_mfg0Weight", PROP_set_value_string_msg, &methodWtEE) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_MatlClass", PROP_set_value_string_msg, &methodMatClsClr) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_PrtCatCode", PROP_set_value_string_msg, &methodCompCodeClr) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_RolledupWt", PROP_set_value_string_msg, &methodRolledUpWeight) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DsgnOwn", PROP_set_value_string_msg, &methodOwnerDesignUnt) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_DsgnOwn", PROP_set_value_string_msg, &methodOwnerDesignUntClr) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_HomologationReqd", PROP_set_value_string_msg, &methodHomoInd) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_CMVRCertificationReqd", PROP_set_value_string_msg, &methodCMVR) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_SurfaceArea", PROP_set_value_string_msg, &methodSurfAra) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_TrackTrace", PROP_set_value_string_msg, &methodTT) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Mfg0MEEquipmentRevision_mfg0Supplier", PROP_set_value_string_msg, &methodSupplierNme) !=ITK_ok);PrintErrorStack();
	//Neha

	//Added by kalpesh(23_aug_2018)
	if ( METHOD_find_method("BOMLine", BOMLine_cut_msg, &method_bl_cut) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("T5_EEPrm", GRM_create_msg, &method_para_clause) != ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("T5_EEPrm", IMAN_save_msg, &method_para_Save) != ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("T5_EPara", IMAN_save_msg, &method_Ecu_para_Save) != ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("T5_EE_PartRevision", IMAN_save_msg, &method_ee_part) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("T5_PlatformRevision", IMAN_save_msg, &method_platform_access) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("T5_ArchModuleRevision", IMAN_save_msg, &method_arch_module_access) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_quantity", PROP_set_value_tag_msg, &method_quantity) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("T5_CCVCHasECUModule", GRM_create_msg, &method_CCV_ECU) != ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("T5_DuraFitPartRevision", IMAN_save_msg, &method_durafit) !=ITK_ok);PrintErrorStack();

	//Kirtikumar 10/10/2022
	if ( METHOD_find_method("IMAN_reference", GRM_create_msg, &method_svr_validation) !=ITK_ok);PrintErrorStack();
	//Use this to add validation on BOMWindow Save action
	if ( METHOD_find_method("BOMWindow", BOMWindow_save_msg, &method_bom_windowSave_validation) !=ITK_ok);PrintErrorStack();
	//if ( METHOD_find_method("Design", ITEM_create_msg, &method_ccvc_validation) !=ITK_ok);PrintErrorStack();
	//if ( METHOD_find_method("Design Revision", IMAN_save_msg, &method_ccvc_validation1) !=ITK_ok);PrintErrorStack();

	if ( METHOD_find_method("T5_EE_PartRevision", ITEM_copy_rev_msg, &method_ee_Part_Revise) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method(RES_Type, RES_checkout_msg , &method_ee_Part_checkOut) !=ITK_ok);PrintErrorStack();


	//For EE Part Pre-action validation.
	if (method_ee_part.id != NULLTAG)
	{
		if( METHOD_add_action(method_ee_part, METHOD_pre_action_type, (METHOD_function_t)save_method_ee_part, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_ee_part not found...!!*****************\n");
	}

	//For EE Part Post-action validation.(16_sept19)
	if (method_ee_part.id != NULLTAG)
	{
		if( METHOD_add_action(method_ee_part, METHOD_post_action_type, (METHOD_function_t) ee_part_post, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method ee_part_post not found...!!*****************\n"); fflush(stdout);
	}

	//For architecture module access...!!(T5_ArchModuleRevision)(06_may_2019)
	if (method_arch_module_access.id != NULLTAG)
	{
		if( METHOD_add_action(method_arch_module_access, METHOD_pre_action_type, (METHOD_function_t)arch_module_access_fun, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_arch_module_access not found...!!*****************\n");
	}
	//For Platform revision access...!!(T5_PlatformRevision)
	if (method_platform_access.id != NULLTAG)
	{
		if( METHOD_add_action(method_platform_access, METHOD_pre_action_type, (METHOD_function_t)platform_access_fun, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_platform_access not found...!!*****************\n");
	}
	//Validation on bomline cut.
	if (method_bl_cut.id != NULLTAG)
	{
		if( METHOD_add_action(method_bl_cut, METHOD_pre_action_type, (METHOD_function_t) bomline_cut_method, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_bl_cut not found...!!*****************\n");
	}
	//Validation on bomline_quantity update.
	if (method_quantity.id != NULLTAG)
	{
		printf("\nInside method_quantity...!!\n");
		if( METHOD_add_action(method_quantity, METHOD_pre_action_type, (METHOD_function_t) prop_bl_quantity_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_quantity\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_quantity tag not found...!!*****************\n");
	}


	if (methodDR.id != NULLTAG)
	{
		printf("\nInside methodDR...!!\n");
		if( METHOD_add_action(methodDR, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDR\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDR tag not found...!!*****************\n");
	}

	if (methodARDRSts.id != NULLTAG)
	{
		printf("\nInside methodARDRSts...!!\n");
		if( METHOD_add_action(methodARDRSts, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodARDRSts\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodARDRSts tag not found...!!*****************\n");
	}

	if (methodAddOnDes.id != NULLTAG)
	{
		printf("\nInside methodAddOnDes...!!\n");
		if( METHOD_add_action(methodAddOnDes, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAddOnDes\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAddOnDes tag not found...!!*****************\n");
	}

	if (methodDesignGrp.id != NULLTAG)
	{
		printf("\nInside methodDesignGrp...!!\n");
		if( METHOD_add_action(methodDesignGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesignGrp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesignGrp tag not found...!!*****************\n");
	}

	if (methodDesignMileStone.id != NULLTAG)
	{
		printf("\nInside methodDesignMileStone...!!\n");
		if( METHOD_add_action(methodDesignMileStone, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesignMileStone\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesignMileStone tag not found...!!*****************\n");
	}


	if (methodEEMatCls.id != NULLTAG)
	{
		printf("\nInside methodEEMatCls...!!\n");
		if( METHOD_add_action(methodEEMatCls, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEMatCls\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEMatCls tag not found...!!*****************\n");
	}

	if (methodEEPrtPara.id != NULLTAG)
	{
		printf("\nInside methodEEPrtPara...!!\n");
		if( METHOD_add_action(methodEEPrtPara, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEPrtPara\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEPrtPara tag not found...!!*****************\n");
	}

	if (methodEEPrtMileStone.id != NULLTAG)
	{
		printf("\nInside methodEEPrtMileStone...!!\n");
		if( METHOD_add_action(methodEEPrtMileStone, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEPrtMileStone\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEPrtMileStone tag not found...!!*****************\n");
	}

	if (methodEEPrtTyp.id != NULLTAG)
	{
		printf("\nInside methodEEPrtTyp...!!\n");
		if( METHOD_add_action(methodEEPrtTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEPrtTyp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEPrtTyp tag not found...!!*****************\n");
	}

	if (methodEEEcuTyp.id != NULLTAG)
	{
		printf("\nInside methodEEEcuTyp...!!\n");
		if( METHOD_add_action(methodEEEcuTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEEcuTyp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEEcuTyp tag not found...!!*****************\n");
	}

	if (methodKeyDescClPrt.id != NULLTAG)
	{
		printf("\nInside methodKeyDescClPrt...!!\n");
		if( METHOD_add_action(methodKeyDescClPrt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodKeyDescClPrt\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodKeyDescClPrt tag not found...!!*****************\n");
	}

	if (methodKeyDescDesign.id != NULLTAG)
	{
		printf("\nInside methodKeyDescDesign...!!\n");
		if( METHOD_add_action(methodKeyDescDesign, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodKeyDescDesign\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodKeyDescDesign tag not found...!!*****************\n");
	}

	if (methodModDescDesRev.id != NULLTAG)
	{
		printf("\nInside methodModDescDesRev...!!\n");
		if( METHOD_add_action(methodModDescDesRev, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModDescDesRev\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModDescDesRev tag not found...!!*****************\n");
	}

	if (methodModDescClPrt.id != NULLTAG)
	{
		printf("\nInside methodModDescClPrt...!!\n");
		if( METHOD_add_action(methodModDescClPrt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModDescClPrt\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModDescClPrt tag not found...!!*****************\n");
	}


	if (methodModule.id != NULLTAG)
	{
		printf("\nInside methodModule...!!\n");
		if( METHOD_add_action(methodModule, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModule\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModule tag not found...!!*****************\n");
	}

	if (methodAddr.id != NULLTAG)
	{
		printf("\nInside methodAddr...!!\n");
		if( METHOD_add_action(methodAddr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAddr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAddr tag not found...!!*****************\n");
	}


	if (methodModGrp.id != NULLTAG)
	{
		printf("\nInside methodModGrp...!!\n");
		if( METHOD_add_action(methodModGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModGrp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModGrp tag not found...!!*****************\n");
	}

	if (methodModNme.id != NULLTAG)
	{
		printf("\nInside methodModNme...!!\n");
		if( METHOD_add_action(methodModNme, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModNme\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModNme tag not found...!!*****************\n");
	}

	if (methodModTyp.id != NULLTAG)
	{
		printf("\nInside methodModTyp...!!\n");
		if( METHOD_add_action(methodModTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModTyp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModTyp tag not found...!!*****************\n");
	}


	if (methodPrtMaterial.id != NULLTAG)
	{
		printf("\nInside methodPrtMaterial...!!\n");
		if( METHOD_add_action(methodPrtMaterial, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPrtMaterial\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPrtMaterial tag not found...!!*****************\n");
	}

	if (methodPrtType.id != NULLTAG)
	{
		printf("\nInside methodPrtType...!!\n");
		if( METHOD_add_action(methodPrtType, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPrtType\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPrtType tag not found...!!*****************\n");
	}

	if (methodProCode.id != NULLTAG)
	{
		printf("\nInside methodProCode...!!\n");
		if( METHOD_add_action(methodProCode, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodProCode\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodProCode tag not found...!!*****************\n");
	}

	if (methodProIds.id != NULLTAG)
	{
		printf("\nInside methodProIds...!!\n");
		if( METHOD_add_action(methodProIds, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodProIds\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodProIds tag not found...!!*****************\n");
	}


	if (methodSWPrtTyp.id != NULLTAG)
	{
		printf("\nInside methodSWPrtTyp...!!\n");
		if( METHOD_add_action(methodSWPrtTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSWPrtTyp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSWPrtTyp tag not found...!!*****************\n");
	}

	if (methodUnitofMeasure.id != NULLTAG)
	{
		printf("\nInside methodUnitofMeasure...!!\n");
		if( METHOD_add_action(methodUnitofMeasure, METHOD_pre_action_type, (METHOD_function_t) prop_bl_tag_UOM_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodUnitofMeasure\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodUnitofMeasure tag not found...!!*****************\n");
	}


	if (methodUOMDesign.id != NULLTAG)
	{
		printf("\nInside methodUOMDesign...!!\n");
		if( METHOD_add_action(methodUOMDesign, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodUOMDesign\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodUOMDesign tag not found...!!*****************\n");
	}

	if (methodDesc.id != NULLTAG)
	{
		printf("\nInside methodDesc...!!\n");
		if( METHOD_add_action(methodDesc, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesc\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesc tag not found...!!*****************\n");
	}

	if (methodDescEE.id != NULLTAG)
	{
		printf("\nInside methodDescEE...!!\n");
		if( METHOD_add_action(methodDescEE, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDescEE\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDescEE tag not found...!!*****************\n");
	}

	if (methodDrawingInd.id != NULLTAG)
	{
		printf("\nInside methodDrawingInd...!!\n");
		if( METHOD_add_action(methodDrawingInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDrawingInd\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDrawingInd tag not found...!!*****************\n");
	}

	if (methodDrawingIndClr.id != NULLTAG)
	{
		printf("\nInside methodDrawingIndClr...!!\n");
		if( METHOD_add_action(methodDrawingIndClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDrawingIndClr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDrawingIndClr tag not found...!!*****************\n");
	}

	if (methodDrawingIndClr.id != NULLTAG)
	{
		printf("\nInside methodDrawingIndClr...!!\n");
		if( METHOD_add_action(methodDrawingIndClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDrawingIndClr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDrawingIndClr tag not found...!!*****************\n");
	}

	if (methodDrawingNo.id != NULLTAG)
	{
		printf("\nInside methodDrawingNo...!!\n");
		if( METHOD_add_action(methodDrawingNo, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDrawingNo\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDrawingNo tag not found...!!*****************\n");
	}

	if (methodLoc.id != NULLTAG)
	{
		printf("\nInside methodLoc...!!\n");
		if( METHOD_add_action(methodLoc, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodLoc\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodLoc tag not found...!!*****************\n");
	}

	if (methodMainSrl.id != NULLTAG)
	{
		printf("\nInside methodMainSrl...!!\n");
		if( METHOD_add_action(methodMainSrl, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodMainSrl\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodMainSrl tag not found...!!*****************\n");
	}

	if (methodRemrk.id != NULLTAG)
	{
		printf("\nInside methodRemrk...!!\n");
		if( METHOD_add_action(methodRemrk, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodRemrk\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodRemrk tag not found...!!*****************\n");
	}
	if (methodDesgnGrp.id != NULLTAG)
	{
		printf("\nInside methodDesgnGrp...!!\n");
		if( METHOD_add_action(methodDesgnGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesgnGrp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesgnGrp tag not found...!!*****************\n");
	}

	if (methodDmlNo.id != NULLTAG)
	{
		printf("\nInside methodDmlNo...!!\n");
		if( METHOD_add_action(methodDmlNo, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDmlNo\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDmlNo tag not found...!!*****************\n");
	}

	if (methodColIndClr.id != NULLTAG)
	{
		printf("\nInside methodColIndClr...!!\n");
		if( METHOD_add_action(methodColIndClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodColIndClr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodColIndClr tag not found...!!*****************\n");
	}

	if (methodCoated.id != NULLTAG)
	{
		printf("\nInside methodCoated...!!\n");
		if( METHOD_add_action(methodCoated, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCoated\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCoated tag not found...!!*****************\n");
	}

	if (methodCoatedClr.id != NULLTAG)
	{
		printf("\nInside methodCoatedClr...!!\n");
		if( METHOD_add_action(methodCoatedClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCoatedClr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCoatedClr tag not found...!!*****************\n");
	}

	if (methodWtClr.id != NULLTAG)
	{
		printf("\nInside methodWtClr...!!\n");
		if( METHOD_add_action(methodWtClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodWtClr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodWtClr tag not found...!!*****************\n");
	}

	if (methodWtEE.id != NULLTAG)
	{
		printf("\nInside methodWtEE...!!\n");
		if( METHOD_add_action(methodWtEE, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodWtEE\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodWtEE tag not found...!!*****************\n");
	}

	if (methodWtEE.id != NULLTAG)
	{
		printf("\nInside methodWtEE...!!\n");
		if( METHOD_add_action(methodWtEE, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodWtEE\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodWtEE tag not found...!!*****************\n");
	}

	if (methodMatClsClr.id != NULLTAG)
	{
		printf("\nInside methodMatClsClr...!!\n");
		if( METHOD_add_action(methodMatClsClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodMatClsClr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodMatClsClr tag not found...!!*****************\n");
	}

	if (methodCompCodeClr.id != NULLTAG)
	{
		printf("\nInside methodCompCodeClr...!!\n");
		if( METHOD_add_action(methodCompCodeClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCompCodeClr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCompCodeClr tag not found...!!*****************\n");
	}

	if (methodRolledUpWeight.id != NULLTAG)
	{
		printf("\nInside methodRolledUpWeight...!!\n");
		if( METHOD_add_action(methodRolledUpWeight, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodRolledUpWeight\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodRolledUpWeight tag not found...!!*****************\n");
	}

	if (methodOwnerDesignUnt.id != NULLTAG)
	{
		printf("\nInside methodOwnerDesignUnt...!!\n");
		if( METHOD_add_action(methodOwnerDesignUnt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodOwnerDesignUnt\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodOwnerDesignUnt tag not found...!!*****************\n");
	}
	if (methodOwnerDesignUntClr.id != NULLTAG)
	{
		printf("\nInside methodOwnerDesignUntClr...!!\n");
		if( METHOD_add_action(methodOwnerDesignUntClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodOwnerDesignUntClr\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodOwnerDesignUntClr tag not found...!!*****************\n");
	}
	if (methodHomoInd.id != NULLTAG)
	{
		printf("\nInside methodHomoInd...!!\n");
		if( METHOD_add_action(methodHomoInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodHomoInd\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodHomoInd tag not found...!!*****************\n");
	}
	if (methodCMVR.id != NULLTAG)
	{
		printf("\nInside methodCMVR...!!\n");
		if( METHOD_add_action(methodCMVR, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCMVR\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCMVR tag not found...!!*****************\n");
	}

	if (methodSurfAra.id != NULLTAG)
	{
		printf("\nInside methodSurfAra...!!\n");
		if( METHOD_add_action(methodSurfAra, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSurfAra\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSurfAra tag not found...!!*****************\n");
	}
	if (methodTT.id != NULLTAG)
	{
		printf("\nInside methodTT...!!\n");
		if( METHOD_add_action(methodTT, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodTT\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodTT tag not found...!!*****************\n");
	}
	if (methodSupplierNme.id != NULLTAG)
	{
		printf("\nInside methodSupplierNme...!!\n");
		if( METHOD_add_action(methodSupplierNme, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSupplierNme\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSupplierNme tag not found...!!*****************\n");
	}

	if (methodColInd.id != NULLTAG)
	{
		printf("\nInside methodColInd...!!\n");
		if( METHOD_add_action(methodColInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_ColInd_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodColInd\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodColInd tag not found...!!*****************\n");
	}

	if (methodCompCode.id != NULLTAG)
	{
		printf("\nInside methodCompCode...!!\n");
		if( METHOD_add_action(methodCompCode, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_CompCode_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCompCode\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCompCode tag not found...!!*****************\n");
	}

	if (methodEnvDim.id != NULLTAG)
	{
		printf("\nInside methodEnvDim...!!\n");
		if( METHOD_add_action(methodEnvDim, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_EnvDim_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEnvDim\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEnvDim tag not found...!!*****************\n");
	}

	if (methodDesGrp.id != NULLTAG)
	{
		printf("\nInside methodDesGrp...!!\n");
		if( METHOD_add_action(methodDesGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_DesGrp_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesGrp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesGrp tag not found...!!*****************\n");
	}

	if (methodSpareCri.id != NULLTAG)
	{
		printf("\nInside methodSpareCri...!!\n");
		if( METHOD_add_action(methodSpareCri, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_SpareCri_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSpareCri\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSpareCri tag not found...!!*****************\n");
	}

	if (methodSpareInd.id != NULLTAG)
	{
		printf("\nInside methodSpareInd...!!\n");
		if( METHOD_add_action(methodSpareInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_SpareInd_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSpareInd\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSpareInd tag not found...!!*****************\n");
	}

	if (methodMatCls.id != NULLTAG)
	{
		printf("\nInside methodMatCls...!!\n");
		if( METHOD_add_action(methodMatCls, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_MatCls_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodMatCls\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodMatCls tag not found...!!*****************\n");
	}


	if (methodMaterial.id != NULLTAG)
	{
		printf("\nInside methodMaterial...!!\n");
		if( METHOD_add_action(methodMaterial, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_Material_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodMaterial\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodMaterial tag not found...!!*****************\n");
	}

	if (methodPrtTyp.id != NULLTAG)
	{
		printf("\nInside methodPrtTyp...!!\n");
		if( METHOD_add_action(methodPrtTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_PrtTyp_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPrtTyp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPrtTyp tag not found...!!*****************\n");
	}

	if (methodProjCode.id != NULLTAG)
	{
		printf("\nInside methodProjCode...!!\n");
		if( METHOD_add_action(methodProjCode, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_ProjCode_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodProjCode\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodProjCode tag not found...!!*****************\n");
	}

	if (methodRevPrtTyp.id != NULLTAG)
	{
		printf("\nInside methodRevPrtTyp...!!\n");
		if( METHOD_add_action(methodRevPrtTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_RevPrtTyp_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodRevPrtTyp\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodRevPrtTyp tag not found...!!*****************\n");
	}

	if (methodWeight.id != NULLTAG)
	{
		printf("\nInside methodWeight...!!\n");
		if( METHOD_add_action(methodWeight, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_Weight_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodWeight\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodWeight tag not found...!!*****************\n");
	}


	if (methodRolledupWt.id != NULLTAG)
	{
		printf("\nInside methodRolledupWt...!!\n");
		if( METHOD_add_action(methodRolledupWt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_RolledupWt_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodRolledupWt\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodRolledupWt tag not found...!!*****************\n");
	}
	if (methodUom.id != NULLTAG)
	{
		printf("\nInside methodUom...!!\n");
		if( METHOD_add_action(methodUom, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_UOM_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodUom\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodUom tag not found...!!*****************\n");
	}

	if (methodAhdMakeBuyInd.id != NULLTAG)
	{
		printf("\nInside methodAhdMakeBuyInd...!!\n");
		if( METHOD_add_action(methodAhdMakeBuyInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_AhdMakeBuyInd_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAhdMakeBuyInd\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAhdMakeBuyInd tag not found...!!*****************\n");
	}

	if (methodCarMakeBuyInd.id != NULLTAG)
	{
		printf("\nInside methodCarMakeBuyInd...!!\n");
		if( METHOD_add_action(methodCarMakeBuyInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_CarMakeBuyInd_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCarMakeBuyInd\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCarMakeBuyInd tag not found...!!*****************\n");
	}

	if (methodPunPCBUMakeBuyInd.id != NULLTAG)
	{
		printf("\nInside methodPunPCBUMakeBuyInd...!!\n");
		if( METHOD_add_action(methodPunPCBUMakeBuyInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_PunPCBUMakeBuyInd_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPunPCBUMakeBuyInd\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPunPCBUMakeBuyInd tag not found...!!*****************\n");
	}

	if (methodPunUvMakeBuyInd.id != NULLTAG)
	{
		printf("\nInside methodPunUvMakeBuyInd...!!\n");
		if( METHOD_add_action(methodPunUvMakeBuyInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_PunUvMakeBuyInd_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPunUvMakeBuyInd\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPunUvMakeBuyInd tag not found...!!*****************\n");
	}

	if (methodKeyDesc.id != NULLTAG)
	{
		printf("\nInside methodKeyDesc...!!\n");
		if( METHOD_add_action(methodKeyDesc, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_KeyDesc_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodKeyDesc\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodKeyDesc tag not found...!!*****************\n");
	}


	//Validation on Parameter part and it's clause.
	if (method_para_clause.id != NULLTAG)
	{
		printf("\nInside method_para_clause...!!\n");
		if( METHOD_add_pre_condition(method_para_clause, (METHOD_function_t) para_clause_attach_method, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_para_clause\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_para_clause tag not found...!!*****************\n");
	}
	//End (kalpesh)

	if (method.id != NULLTAG)
	{
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) save_method_3, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	    else
	    {
			printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");
	    }

	//TCUA 1.47-Start
	if (method.id != NULLTAG)
	{
		if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) save_method_Design_3, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n !!!!!!!!!!!save_method_Design_3 not found!!!!!!!!!!\n"); fflush(stdout);
	}
	//TCUA 1.47-End

	if (method1.id != NULLTAG)
	{
		if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) save_method_4, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	    else
	    {
			printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");
	    }

	if (method1.id != NULLTAG)
	{
		if( METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) save_Post_DesRev, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n !!!!!!!!!!!Method not found save_Post_DesRev!!!!!!!!!!\n");
	}
    	if (method2.id != NULLTAG)
	{
		if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) save_method_5, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method2 not found!!!!!!!!!!\n");
    }

	if (methodSVR.id != NULLTAG)
	{
		if( METHOD_add_action(methodSVR, METHOD_pre_action_type, (METHOD_function_t) save_method_SVR, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!! methodSVR not found!!!!!!!!!!\n");
    }
	if (methodVendor.id != NULLTAG)
	{
		if( METHOD_add_action(methodVendor, METHOD_pre_action_type, (METHOD_function_t) save_method_Vendor, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!! methodVendor not found!!!!!!!!!!\n");
    }

	//Pro-E specific Customization to Check-Out Dataset on Create.
	if ( METHOD_find_method("Dataset", AE_create_dataset_msg, &method2) !=ITK_ok) PrintErrorStack();
    if (method2.id != NULLTAG)
	{
		printf("\nInside Method 2\n");
		if( METHOD_add_action(method2, METHOD_post_action_type, (METHOD_function_t) save_method_8, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method2 for AE_create_dataset_msg Post not found!!!!!!!!!!\n");
    }
	//End of Pro-E specific Customization to Check-Out Dataset on Create.

	 if (method3.id != NULLTAG)
	{
		if( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) save_method_7, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method3 not found!!!!!!!!!!\n");
    }

	 if (method3.id != NULLTAG)
	{
		if( METHOD_add_action(method3, METHOD_post_action_type, (METHOD_function_t) save_method_qty_updt, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method3 not found!!!!!!!!!!\n");
    }

	/* Adi for CREO  */

	if ( METHOD_find_method("Dataset", AE_save_dataset_msg , &method4) !=ITK_ok) PrintErrorStack();
    if (method4.id != NULLTAG)
	{
		printf("\nInside Method 2\n");

		if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) save_method_9, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method4 for AE_save_dataset_msg Post not found!!!!!!!!!!\n");
    }


	    if (methodBOM.id != NULLTAG)///upp
	{
		printf("\nInside methodBOM\n");
		if( METHOD_add_action(methodBOM, METHOD_post_action_type, (METHOD_function_t) qauntity_handled_as_per_uom, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n methodBOM not found\n");
    }

	if (methodVF.id != NULLTAG) //Prachi
	{
		printf("\nInside methodVF for vf tag\n");
		if( METHOD_add_action(methodVF, METHOD_pre_action_type, (METHOD_function_t) check_vf_module, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\n error  methodVF\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n methodVF tag not found\n");
    }


	if (method_durafit.id != NULLTAG)
	{
		if( METHOD_add_action(method_durafit, METHOD_pre_action_type, (METHOD_function_t) save_method_durafit, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");
	}

	if (method_para_Save.id != NULLTAG)
	{
		if( METHOD_add_action(method_para_Save, METHOD_pre_action_type, (METHOD_function_t)save_method_Para_Rel, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_para_Save not found...!!*****************\n");
	}

	if (method_CCV_ECU.id != NULLTAG)
	{
		printf("\nInside method_CCV_ECU...!!\n");
		if( METHOD_add_pre_condition(method_CCV_ECU, (METHOD_function_t) CCV_ECU_PreCond_Func, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_CCV_ECU\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_CCV_ECU tag not found...!!*****************\n");
	}

	if (method_Ecu_para_Save.id != NULLTAG)
	{
		printf("\nInside method_Ecu_para_Save...!!\n");
		if( METHOD_add_pre_condition(method_Ecu_para_Save, (METHOD_function_t) ECU_Para_PreCond_Func, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_Ecu_para_Save\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_Ecu_para_Save tag not found...!!*****************\n");
	}
	// Added by Kirtikumar
	if (method_svr_validation.id != NULLTAG)
	{
		printf("\nInside method_svr_validation...!!\n");
		if( METHOD_add_pre_condition(method_svr_validation, (METHOD_function_t) SVR_PreCond_Validation_Func, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_svr_validation\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_svr_validation tag not found...!!*****************\n");
	}
	//16-03-2023
	 if (method_bom_windowSave_validation.id != NULLTAG)
	{
		if( METHOD_add_action(method_bom_windowSave_validation, METHOD_post_action_type, (METHOD_function_t) bom_WindowSave_Validation, NULL)!=ITK_ok);PrintErrorStack();
		//if( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) save_method_qty_updt, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!method_bom_windowSave_validation not found!!!!!!!!!!\n");
    }
	if (method_ee_Part_Revise.id != NULLTAG)
	{
		printf("\nInside method_ee_Part_Revise...!!\n");
		if( METHOD_add_action(method_ee_Part_Revise, METHOD_post_action_type, (METHOD_function_t) carryMastSlvRelationOnReviseForEEPartRev, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_ee_Part_Revise\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_ee_Part_Revise tag not found...!!*****************\n");
	}

	if (method_ee_Part_checkOut.id != NULLTAG)
	{
		printf("\nInside method_ee_Part_checkOut...!!\n");
		if( METHOD_add_action(method_ee_Part_checkOut, METHOD_post_action_type, (METHOD_function_t) carryMastSlvRelationOnCheckOutForEEPartRev, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_ee_Part_checkOut\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_ee_Part_checkOut tag not found...!!*****************\n");
	}
	// Added by Kirtikumar
	/*
	if (method_ccvc_validation1.id != NULLTAG)
	{
		printf("\nInside method_ccvc_validation1...!!\n");
		//if( METHOD_add_pre_condition(method_ccvc_validation, (METHOD_function_t) CCVC_PreCon_Validation, NULL)!=ITK_ok) PrintErrorStack();
		//if( METHOD_add_action(method_ccvc_validation1, METHOD_post_action_type, (METHOD_function_t) CCVC_PreCon_Validation, NULL)!=ITK_ok) PrintErrorStack();
		if( METHOD_add_action(method_ccvc_validation1, METHOD_pre_action_type, (METHOD_function_t) CCVC_PreAction_Validation, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_ccvc_validation1\n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_ccvc_validation1 tag not found...!!*****************\n");
	}*/
	/* Adi for CREO  */


//       if (method4.id != NULLTAG)
//	{
//		if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) save_method_6, NULL)!=ITK_ok);PrintErrorStack();
//
//		if( ifail != ITK_ok )
//		{
//				EMH_store_error( EMH_severity_error, ifail );
//		}
//	}
//    else
//    {
//		printf("\n !!!!!!!!!!!Method4 not found!!!!!!!!!!\n");
//    }
	   printf("\n\n CreateDesign.c:it, t8save_design_custom_exit end .\n");fflush(stdout);

    return ifail;
}


extern DLLAPI int tm_SaveValidationOnDsgRev_register_callbacks ()
{
     printf("\n \n tm_SaveValidationOnDsgRev.c :::Hello Teamcenter, via Custom User Exit\n");fflush(stdout);

      CUSTOM_register_exit ( "tm_SaveValidationOnDsgRev", "USER_init_module", (CUSTOM_EXIT_ftn_t) t8save_design_custom_exit);

      return ( ITK_ok );
}
