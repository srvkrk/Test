#!/bin/bash
To_ADD="kt.ttl@tatamotors.com"
FROM_ADD="kt.ttl@tatamotors.com"
SUB="This is the test Mail"
BODY="This is test mail send using script"
echo ${BODY} | mail -s ${SUB} ${TO_ADD}
