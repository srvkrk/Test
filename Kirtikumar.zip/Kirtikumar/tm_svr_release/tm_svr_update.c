/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
char* EE_Part_BOM_Validation_for_NR_Rev(char*,int,tag_t*);
char* GetSvrString(char* optFamily,char* OptFm_Value,char* String_FamVal);
char* AddAndSvrString(char* SVR);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	char			*error_text					= NULL;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		if(ifail != ITK_ok)
		{
			EMH_ask_error_text(ifail,&error_text);
			printf("\n Error Text os %s \n",error_text);
		}
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s\n",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	
	tag_t	item_tag				=	NULLTAG;
	tag_t	DMLLcmTag				=	NULLTAG;
	tag_t	rel_type				=	NULLTAG;
	tag_t	*Dml_OptFamiliesTag		=	NULLTAG;

	char*   object_type				=	NULL;
	char*   type_name				=	NULL;
	char*   DML_No					=	NULL;

	int Dml_Option_Family_Cnt	= 0;
	int i						= 0;

	char *qry_entries[1] = {"Name"};
    char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	int num_Opt=0;
	int iSVR=0;
	int IOpt=0;
	int icn=0;
	int iindx=0;
	int num_OptSvr=0;
	char **OpTValueList;
	char **OpTValueSVRList;
	char* SVRList[1000];
	int SVRListIndx=0;
	tag_t OptVal_Tg=NULLTAG;
	char *OptFm_Value			= NULL;

	char* String_SVR_Final=NULL;
	char *error_text =			NULL;
	
	

	char* String_FamVal=NULL;

	
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_ask_latest_rev(item_tag,&DMLLcmTag);
	CHECK_FAIL;	
	
	AOM_ask_value_string(DMLLcmTag,"object_type",&object_type);
	printf("\n object_type is :%s\n",object_type);fflush(stdout);

	AOM_ask_value_string(DMLLcmTag,"item_id",&DML_No);
	printf("\n DML_No is :%s\n",DML_No);fflush(stdout);

	if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
	{
		ifail = GRM_find_relation_type("CMReferences",&rel_type);
		CHECK_FAIL;
		ifail = GRM_list_secondary_objects_only(DMLLcmTag,rel_type,&Dml_Option_Family_Cnt,&Dml_OptFamiliesTag);
		CHECK_FAIL;
		printf("\nDml_Option_Family_Cnt count is : [%d] \n",Dml_Option_Family_Cnt);fflush(stdout);
		
		//
		for (i=0;i<Dml_Option_Family_Cnt;i++)
		{
			tag_t	OptFm_Tg		    = NULLTAG;
			tag_t	value_tag		    = NULLTAG;

			OptFm_Tg=	Dml_OptFamiliesTag[i];

			tag_t		objTypeTag			= NULLTAG;
			tag_t		*OptVal_TAGS		= NULL;
			char*		OptFm_No			= NULL;
			int			OptValCnt			= 0;
	
			ifail = AOM_ask_value_string(OptFm_Tg,"object_type",&type_name);
			CHECK_FAIL;
			printf("\n 1 MDM type is:%s \n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_FamilyMDMRevision")==0)
			{
				tag_t		rel_type_1			= NULLTAG;

				ifail = GRM_find_relation_type("T5_MDM_Fam_Val",&rel_type_1);

				ifail = AOM_ask_value_string(OptFm_Tg,"object_name",&OptFm_No);  //T5_Opt_Family_Value
				printf("\n OptFm_No is :%s\n",OptFm_No);fflush(stdout);

				
				ifail = AOM_ask_value_strings(OptFm_Tg,"t5_OptionValueMDM",&num_Opt,&OpTValueList);
				CHECK_FAIL;
				printf("\n  num_Opt  , %d\n",num_Opt); fflush(stdout);

				ifail = GRM_list_secondary_objects_only(OptFm_Tg,rel_type_1,&OptValCnt,&OptVal_TAGS);
				CHECK_FAIL;

				for (IOpt=0;IOpt<OptValCnt;IOpt++ )///optionvalue
				{
					OptVal_Tg=OptVal_TAGS[IOpt];
					ifail = AOM_ask_value_strings(OptVal_Tg,"t5_AppSVR",&num_OptSvr,&OpTValueSVRList);
					CHECK_FAIL;
					printf("\n  num_OptSvr  , %d\n",num_OptSvr); fflush(stdout);
							
					for (iSVR=0;iSVR<num_OptSvr;iSVR++)///svr
					{
							int FlagMatchSvr=0;
							if (SVRListIndx !=0)
							{
								for (icn=0;icn<SVRListIndx;icn++ )///checking for any duplicate svr
								{
									if (tc_strcmp(OpTValueSVRList[iSVR],SVRList[icn])==0)
									{

										FlagMatchSvr=1;
										break;
									}
								}
							}
							if (FlagMatchSvr==0)
							{
								printf("\n  OpTValueSVRList[iSVR]  , %s\n",OpTValueSVRList[iSVR]); fflush(stdout);

								SVRList[SVRListIndx]=OpTValueSVRList[iSVR];
								SVRListIndx++;
							}
			
					}
				}
				printf("\n SVRListIndx is :%d\n",SVRListIndx);fflush(stdout);

				for (iindx=0;iindx< SVRListIndx;iindx++ )
				{
					char* String_FamVal=NULL;
					printf("\n\n\n SVR PROCESSING >>>>>>>>>>>>>>>>>>>>>>>%s<<<<<<<<<<<<<<<<<<<\n",SVRList[iindx]); fflush(stdout);

							for (IOpt=0;IOpt<OptValCnt;IOpt++ )///optionvalue
							{
								int FlagMatchValue=0;
								OptVal_Tg=OptVal_TAGS[IOpt];
								ifail = AOM_ask_value_strings(OptVal_Tg,"t5_AppSVR",&num_OptSvr,&OpTValueSVRList);
								printf("\n  num_OptSvr  , %d\n",num_OptSvr); fflush(stdout);

								ifail = AOM_ask_value_string(OptVal_Tg,"object_name",&OptFm_Value);  //T5_Opt_Family_Value
								printf("\n OptFm_Value is : %s------>>%s\n",OptFm_No,OptFm_Value);fflush(stdout);
								
								for (iSVR=0;iSVR<num_OptSvr;iSVR++)///svr
								{

									if (tc_strcmp(OpTValueSVRList[iSVR],SVRList[iindx])==0)
									{
										printf("\n OpTValueSVRList[iSVR],Svr is : <%s><%s>\n",OpTValueSVRList[iSVR],SVRList[iindx]);fflush(stdout);
											FlagMatchValue=1;
											break;
										
									}
								}

								if (FlagMatchValue==1)
								{
									String_FamVal=GetSvrString(OptFm_No,OptFm_Value,String_FamVal);
									printf("\n OptFm_Value is : <%s>\n",String_FamVal);fflush(stdout);
								}
							}
							char* String_SVR_Final=NULL;
							String_SVR_Final=AddAndSvrString(String_FamVal);
							tag_t	queryTag	= NULLTAG;
							int n_entries = 1;
							int resultCount=0;
							tag_t *svrobj=NULLTAG;
							if(QRY_find("VariantRule1", &queryTag));
							qry_values[0] = SVRList[iindx] ;

							if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &svrobj));
							printf("\n resultCount : %d\n", resultCount); fflush(stdout);

							if (resultCount>0)
							{
								char* Context_VRuleText2=NULL;
								char* Context_VRuleText=NULL;
								int countPrdCnfg=0;
								tag_t* PrdCnfgTags=NULL;
								tag_t vrule=NULLTAG;
								tag_t rel_typeSvr=NULLTAG;
								vrule=svrobj[0];
								ifail =BSLV_get_variant_expression(NULLTAG,vrule,&Context_VRuleText2 );
								
								ifail =GRM_find_relation_type("IMAN_reference",&rel_typeSvr);
								ifail =GRM_list_primary_objects_only(vrule,rel_typeSvr,&countPrdCnfg,&PrdCnfgTags);
								printf("\n countPrdCnfg : %d\n", countPrdCnfg); fflush(stdout);

								if (countPrdCnfg>0)
								{
									printf("\n  Prd Cnfg  FouND \n"); fflush(stdout);
									printf("\n Context_VRuleText2 : \n\n\n%s\n\n\n", Context_VRuleText2); fflush(stdout);

									STRNG_replace_str(Context_VRuleText2,"(((",String_SVR_Final,&Context_VRuleText);
									printf("\n Context_VRuleText2 : \n\n\n%s\n\n\n", Context_VRuleText); fflush(stdout);
									ifail = BSLV_set_variant_expression(PrdCnfgTags[0],NULLTAG,vrule,Context_VRuleText );
									if(ifail != ITK_ok)
									{
										EMH_ask_error_text(ifail,&error_text);
										printf("\n Error Text os %s \n",error_text);
									}

								}
								else
								{
									printf("\n ERROR Prd Cnfg not FouND \n"); fflush(stdout);
								}
						}
				 } 
 
			}
		}
	}
	
}
char* GetSvrString(char* optFamily,char* OptFm_Value,char* String_FamVal)
{
	char* optFamily_Dup=NULL;
	char* optValue_Dup=NULL;
	char* FinalStr=NULL;
	optFamily_Dup = (char	*)MEM_alloc(1000);
	optValue_Dup = (char	*)MEM_alloc(1000);
	FinalStr = (char	*)MEM_alloc(5000);
	if (tc_strstr(optFamily," "))
	{
		tc_strcpy(optFamily_Dup,"'");
		tc_strcat(optFamily_Dup,optFamily);
		tc_strcat(optFamily_Dup,"'");
	}
	else
	{
		tc_strcpy(optFamily_Dup,optFamily);
	}
	printf("\n optFamily_Dup -- %s \n",optFamily_Dup);fflush(stdout);
	if (tc_strstr(OptFm_Value," "))
	{
		tc_strcpy(optValue_Dup,"'");
		tc_strcat(optValue_Dup,OptFm_Value);
		tc_strcat(optValue_Dup,"'");
	}
	else
	{
		tc_strcpy(optValue_Dup,OptFm_Value);
	}
	printf("\n optValue_Dup -- %s \n",optValue_Dup);fflush(stdout);
	

		printf("\n String_FamVal -- %s \n",String_FamVal);fflush(stdout);

		if (String_FamVal==NULL)
		{
			tc_strcpy(FinalStr,"((([Teamcenter]");
			tc_strcat(FinalStr,optFamily_Dup);
			tc_strcat(FinalStr," = ");
			tc_strcat(FinalStr,optValue_Dup);
			printf("\n FinalStr1 -- %s \n",FinalStr);fflush(stdout);
			
		}
		else
		{	
			if (!tc_strstr(String_FamVal,"|"))
			{
				tc_strcpy(FinalStr,"(");
				tc_strcat(FinalStr,String_FamVal);
			}
			else
			{
				tc_strcpy(FinalStr,String_FamVal);
			}
			
			tc_strcat(FinalStr," | ");
			tc_strcat(FinalStr,"[Teamcenter]");
			tc_strcat(FinalStr,optFamily_Dup);
			tc_strcat(FinalStr," = ");
			tc_strcat(FinalStr,optValue_Dup);
			printf("\n FinalStr2 -- %s \n",FinalStr);fflush(stdout);
			
		}

		printf("\n FinalStr -- %s \n",FinalStr);fflush(stdout);
		return FinalStr;

}
char* AddAndSvrString(char* SVR)
{
	char* SVR_F=NULL;
	SVR_F = (char	*)MEM_alloc(5000);
	tc_strcpy(SVR_F,SVR);
	if (tc_strstr(SVR,"(((("))
	{
		tc_strcat(SVR_F,")");
	}
	tc_strcat(SVR_F," & ");
	return SVR_F;
}

