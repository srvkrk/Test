#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>

int TransferCCIDToUVServer(void* return_data)
{
	
		char	*CCID_NO	= NULL;
		char	*REV		= NULL;
		char	*SEQ		= NULL;
		char    *ShellPath	= NULL;
		char	*RevSeq		= NULL;
		
		char	*output						= NULL;
		
		int		result=0;
		char	*shellpathname	= NULL;
		char    *command		= NULL;
		
		char	*user_name_string = NULL;
		
		shellpathname=MEM_alloc(150);
		RevSeq		=MEM_alloc(10);

		tc_strcpy(RevSeq,"");
		tc_strcat(RevSeq,REV);
		tc_strcat(RevSeq,";");
		tc_strcat(RevSeq,SEQ);

		printf("\n **********In User servie for CCID Transfer**********\n");fflush(stdout);
		printf("\n **********TransferCCIDToUVServer**********\n");fflush(stdout);	
		output = "**********TransferCCIDToUVServer**********"; 
		ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
		ITK_auto_login( );
		ITK_set_journalling( TRUE );
		printf("\n ITK_auto_login success---->\n");fflush(stdout);
		output = "ITK_auto_login success---->"; 

		USERARG_get_string_argument(&CCID_NO);
		USERARG_get_string_argument(&REV);
		USERARG_get_string_argument(&SEQ);
		USERARG_get_string_argument(&ShellPath);
				
		printf("\n CCID_NO-------->  : %s",CCID_NO);fflush(stdout);
		printf("\n REV-------->  : %s",REV);fflush(stdout);
		printf("\n SEQ-------->  : %s",SEQ);fflush(stdout);
		printf("\n ShellPath-------->  : %s",ShellPath);fflush(stdout);
		
		POM_get_user_id(&user_name_string);
		printf("\n Session user_name_string : %s",user_name_string);fflush(stdout);

		strcpy(shellpathname,ShellPath);
		printf("\n shellpathname-------->  : %s\n",shellpathname);fflush(stdout);
		
		//printf("\n%s %s %s \n",shellpathname,Vrule,ClrschemeRev);fflush(stdout);
		//sprintf(command,"%s %s %s",shellpathname,Vrule,ClrschemeRev);
		command = malloc(1500);

		tc_strcpy(command,"");
		tc_strcat(command,shellpathname);
		tc_strcat(command," ");
		tc_strcat(command,CCID_NO);
		tc_strcat(command," ");
		tc_strcat(command,"'");
		tc_strcat(command,RevSeq);   //BSL_UA_UV_Transfer.sh  5442EZ0110_10  'A;1' 
		tc_strcat(command,"'");
		
		system(command);

		printf("\n TransferCCIDToUVServer function return Successfully---->\n");fflush(stdout);
		output ="After command execution,TransferCCIDToUVServer function return Successfully";

		*((char **) return_data) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

		strcpy( *((char **) return_data), output); 
		return result;
}

extern DLLAPI int PLM_UV_Transfer_register_userservices()
{   
 	int nargs=4;
	int *inputArgTypes;	
	int retValueType;
        
	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));
	
	inputArgTypes[0]=USERARG_STRING_TYPE;
	inputArgTypes[1]=USERARG_STRING_TYPE;
	inputArgTypes[2]=USERARG_STRING_TYPE;
	inputArgTypes[3]=USERARG_STRING_TYPE;
	
	retValueType=USERARG_TAG_TYPE;	

	printf("\n User Service tm_CCIDTrasnferUserService get Call....");fflush(stdout);
	USERSERVICE_register_method("TransferCCIDToUVServer",(USER_function_t) TransferCCIDToUVServer, nargs, inputArgTypes, retValueType);
    return ITK_ok;
}

extern int PLM_UV_Transfer(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	PLM_UV_Transfer_register_userservices();
	
	return ifail;
	
}

extern DLLAPI int tm_CCIDTrasnferUserService_register_callbacks()
{
   printf("\n **************tm_CCIDTrasnferUserService_register_callbacks*********"); 
   printf("\n Before registration of  userservice....");
   CUSTOM_register_exit("tm_CCIDTrasnferUserService","USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)PLM_UV_Transfer);
   printf("\n After registration of user service....");
   return ITK_ok;
}
