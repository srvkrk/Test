#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>

int PLMUVService_Function(void* return_data)
{
		int		status;	
		int		length =0;
		char** CCIDs =NULL;
		int i=0;

	
		char			*output						= NULL;
		int		result=0,resultDMLNo	= 0;
		//char *shellpathname = NULL;
		char    command[512];
		char *user_name_string = NULL;

	
		//shellpathname=MEM_alloc(150);
		printf("\n PLMUVService_Function Starting---->\n");fflush(stdout);	
		//output = "PLMUVService_Function---->"; 
		ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
		ITK_auto_login();
		ITK_set_journalling(TRUE);
		printf("\n ITK_auto_login success---->\n");fflush(stdout);
		//output = "ITK_auto_login success---->"; 

		USERARG_get_string_array_argument(&length,&CCIDs);
		printf("Total No of CCIDs are:--> %d",length);
		for(i=0;i< length;i++)
		{
			printf("CCID Pass from RAC are::: -->>>> %s",CCIDs[i]);
		}

		output = "Successfully"; 
		
		*((char **) return_data) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

		strcpy( *((char **) return_data), output); 
		return result;
}

extern DLLAPI int PLMUVService_register_userservices()
{   
 	int nargs=1;
	int *inputArgTypes;	
	int retValueType;
        
	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));	
	inputArgTypes[0]=USERARG_ARRAY_TYPE;
	
	retValueType=USERARG_STRING_TYPE;	
	printf("\n UserService tmRollUpWeightService get Call....");fflush(stdout);
	USERSERVICE_register_method("PLMUVService_Function",(USER_function_t) PLMUVService_Function, nargs, inputArgTypes, retValueType);
    return ITK_ok;
}

extern int PLMUVService(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	PLMUVService_register_userservices();
	
	return ifail;
	
}

extern DLLAPI int tm_PLMUVService_register_callbacks()
{
   printf("\n tm_PLMUVService_register_callbacks..."); 
   printf("\n Before registoring userservice....");
   CUSTOM_register_exit("tm_PLMUVService","USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)PLMUVService);
   printf("\n After registoring userservice....");
   return ITK_ok;
}
