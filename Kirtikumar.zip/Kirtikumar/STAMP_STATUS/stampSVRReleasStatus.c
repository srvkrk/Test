#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
;

FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail =	ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ";");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	int ifail	= 0;

	//Control Obj for On and Off Validation.
	tag_t	qry_t1_CCVCVal			= NULLTAG;
	char **qry_val3_CCVCVal			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1_CCVCVal[3]   = {"Name","Type","Release Status"};
	int n_entr1_CCVCVal				= 2;
	int rsltCunt1_CCVCVal			= 0;
	tag_t *CntrlObjTag1_CCVCVal		= NULLTAG;

	tag_t new_rev_type_tag = NULL;
	char new_rev_obj_type_name[WSO_name_size_c+1];
	char    *PartType               = NULL;
	char    *ProjectCode               = NULL;
	char*	 usrInfo1				= NULL;
	char* errorMsgCCVCVal =NULL;
	char* colourInd =NULL;
	char* objectString =NULL;
	int statusCount =0;
	tag_t			*status_list				= NULL;
	//tag_t tAttRelStatus;
	tag_t attRelStatus;
	tag_t tp_close_status_tag;

	if(GRM_find_relation_type("Release Status",&s_relation_type));
	if (s_relation_type != NULLTAG)
	{
		printf("\n Release Status Relation found \n");fflush(stdout);
	}
	else
	{
		printf("\n Release Status Relation Not found \n");fflush(stdout);
	}


	if(QRY_find("General...", &qry_t1_CCVCVal));
	if (qry_t1_CCVCVal)
	{
		printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
	}
	qry_val3_CCVCVal[0] = item_id;
	qry_val3_CCVCVal[1] = "VariantRule";
	//qry_val3_CCVCVal[2] = "T5_LcsErcRlzd";

	if(QRY_execute(qry_t1_CCVCVal, n_entr1_CCVCVal, qry_entr1_CCVCVal, qry_val3_CCVCVal, &rsltCunt1_CCVCVal, &CntrlObjTag1_CCVCVal));
	printf("\n rsltCunt1_CCVCVal:....%d \n",rsltCunt1_CCVCVal);fflush(stdout);

	if(rsltCunt1_CCVCVal>0)
	{
		CHECK_FAIL(AOM_ask_value_string(CntrlObjTag1_CCVCVal[0],"object_string",&usrInfo1));

		printf("\n object_string:....% s \n",usrInfo1);fflush(stdout);

		//Clearing Previous release status::
		CHECK_FAIL(WSOM_ask_release_status_list(CntrlObjTag1_CCVCVal[0],&statusCount,&status_list));

		if(status_list !=NULL)
		{
			CHECK_FAIL(ITK_set_bypass(true));
			CHECK_FAIL(POM_attr_id_of_attr("release_status_list","WorkspaceObject",&attRelStatus));
			CHECK_FAIL(POM_refresh_instances_any_class(1,&CntrlObjTag1_CCVCVal[0], POM_modify_lock));
			CHECK_FAIL(POM_clear_attr(1,&CntrlObjTag1_CCVCVal[0],attRelStatus));
			CHECK_FAIL(POM_save_instances(1,&CntrlObjTag1_CCVCVal[0],true));
			CHECK_FAIL(POM_refresh_instances_any_class(1,status_list,POM_delete_lock));
			CHECK_FAIL(POM_delete_instances(1,status_list));
		}
		else
		{
			printf("No previous release status found");
		}
		//Creating release status:
		ifail = RELSTAT_create_release_status("ERC Review",&tp_close_status_tag);
		ifail = AOM_refresh(CntrlObjTag1_CCVCVal[0],0);
		ifail = RELSTAT_add_release_status(tp_close_status_tag,1,&CntrlObjTag1_CCVCVal[0],false);
		ifail = AOM_save(CntrlObjTag1_CCVCVal[0]);
		ifail = AOM_refresh(CntrlObjTag1_CCVCVal[0],1);
		/**/


	}

	return ifail;
}
