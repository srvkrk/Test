/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
int IsCCIDLatest(char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;

	int status;
	char* error;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		if(ifail != ITK_ok)	
		{
			EMH_ask_error_text(ifail,&error);
			printf("Error:: %s",error);
		}
		//ITK_CALL(read_value_from_file(file));
		//CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{

	int status;
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char *CurrentTask		= NULL;
	char *BusUnitDV			= NULL;
	char *DMLDRdvp			= NULL;
	char *dmlNo             =NULL;
	char* DMLtype		    = NULL;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	char  *Partnumber       = NULL;
	char   *Prt_object_type =NULL;
	char *DatasetName	    = NULL;
	char  *mdmclass_name;

	tag_t    Cciditemrev   = NULLTAG;
	tag_t	DML_tag				= NULLTAG;
	tag_t	DMLRevTag			= NULLTAG;

	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;

	tag_t	MdmDMLRevTag		= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t   class_id            =NULLTAG;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	tag_t  *MdmPartsTag          =NULLTAG;
	tag_t	Mdm_tsk_rel		    = NULLTAG;
	tag_t	DesignrMdmTag		= NULLTAG;
	tag_t	part_tsk_relc		    = NULLTAG;

	int     noAttachment      = 0;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcnt		       = 0;

	char * username				= NULL;
	char * parent_name			= NULL;
	char * dmlTaskNo			= NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;
	int		partcntrf	        = 0;
	int		pr					= 0;

	int	n_entriesMdm = 2;
	int n_foundMdm = 0;
	int p = 0;
	char *qry_entriesMdm[2] = {"SYSCD", "SUBSYSCD"};
    char *qry_valuesMdm[2]  = {"CCU", "DML"};
	tag_t   *MdmCtrObj      = NULLTAG;
	tag_t   *PartsTagrf       = NULLTAG;
	tag_t  TagMdmControl     = NULLTAG;
	tag_t	DesignrevTagR	 = NULLTAG;
	tag_t  reln_typeMdm       = NULLTAG;
	tag_t  Mdmrelation        =NULLTAG;

	//

	char*	Cciditem_rev  = NULL;
	char *  PartItemRevIdSn =NULL;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t*	 snapchild				= NULL;
	tag_t  *addPartsTag          =NULLTAG;
	tag_t	 SnChild			  = NULLTAG;
	tag_t	 Part_tobeAdd	    = NULLTAG;
	tag_t	CcidADDTag		= NULLTAG;
	tag_t	CcidADD_MasterTag =NULLTAG;
	tag_t	RevTag =NULLTAG;
	int		CCID 	        = 0;
	int		snapcount 	        = 0;
	int		sn 	        = 0;

	int		partaddcnt				= 0;
	int		zr				= 0;
	int		in				= 0;
	int		ss				= 0;
	int   n_referencers					 = 0;
	int   *levels					 = 0;
	int				n_entries = 2;
	int				n_entccid = 1;
	int				n_entccids = 1;
	int				resultCount				= 0;
	int				CcidCount				= 0;
	int urt =0;
	int EndStrCount=0;
	int CcidCounts =0;
	int  num_to_sort = 1;
	char *keys[1] = {"creation_date"};
	int  	 orders[1]  ={2};
	int st =0;
	int		attccidcntMem     = 0;
	int revCount = 0;
	int rc =0;
	int rs=0;
	int statusCont =0;
	tag_t *ccidTagrf=NULLTAG;
	char *  PartItemIdSn      =NULL;
	char  *AddPartnumber       = NULL;
	char *Dml_idn=NULL;
	char   *PartRevID =NULL;
	char ** relationsRef;
	char *class_name1=NULL;
	char*    MPartNo				 = NULL;
	char * ItemIDn;
	char *RefItem_id=NULL;
	char *RefItem_idEnd=NULL;
	char *ObjStrRefItemLatRev=NULL;
	char *Dml_id=NULL;

	char *CcidNumber            =NULL;
	char *CcidNumbers           =NULL;
	char *Ccidfinal           =NULL;

	char *DataSet=NULL;
	char *TokCcidNum=NULL;
	char *CCID_Item_ID=NULL;
	char *StrCcidNum=NULL;
	char *AftertokCCid = NULL;
	char *CCID_No = NULL;
	tag_t *	referencers;
	tag_t class_id1 = NULL;
	tag_t	Ccidtag	= NULLTAG;
	tag_t	CcidTags	= NULLTAG;
	tag_t CcidN	   = NULLTAG;
	tag_t CcidNs	   = NULLTAG;
	tag_t			*CcidDatas			= NULL;
	tag_t			*CcidData			= NULL;
	tag_t	LatestRev = NULLTAG;
	tag_t	LatestRevEnd = NULLTAG;
	tag_t	LatestDmlRev = NULLTAG;
	tag_t	ref_item = NULLTAG;
	tag_t	ref_itemLatestRev = NULLTAG;
	tag_t	ref_itemh = NULLTAG;
	tag_t	DmlTag = NULLTAG;
	tag_t	CadTag = NULLTAG;
	tag_t* CcidADD_All_rev_List =NULL;
	tag_t* statusList =NULL;
	char 			*rev_rel_status				= NULL;

	char*  RefRevSeq = NULL;
	char*  RefRevSeqEnd = NULL;
	char	*tok = NULL;
	char	*tok1 = NULL;
	char *Ccidset=NULL;
	char **	AStringList =NULL;
	char **	FinalCcidsetList =NULL;
	
	char **	BStringList =NULL;
	int piStringCount =0;
	int FinalCcidsetCount =0;
	tag_t	 HasRefCCIDRelType		 = NULLTAG;
	tag_t   CCIDRefRel_task		     = NULLTAG;
	
	char		    *qry_entccid[1]			= {"ID"};
	char		    *qry_entccids[1]			= {"ID"};
	char			**qry_values			= (char **) MEM_alloc(10 * sizeof(char *));
	char			**qry_valccid			= (char **) MEM_alloc(10 * sizeof(char *));
	char			**qry_valccids			= (char **) MEM_alloc(10 * sizeof(char *));

	char *FinalCcidsetToAttachDML=NULL;
	FinalCcidsetToAttachDML =  (char *) MEM_alloc(3000 * sizeof(char));

	tag_t	ccidToattach = NULLTAG;
	tag_t	ccidToattachLatRev = NULLTAG;
	char*	ccidToattachLatRevObjStr =NULL;
	char* object_stringRevTag = NULL;

	char* error_string =NULL;
	
	

	//added



	//end
	int		count			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;

	//ifail = ITEM_find_item (item_id, &item_tag);
	//CHECK_FAIL;
	ITK_CALL(ITEM_find_item (item_id, &item_tag));
	
	//ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
	//CHECK_FAIL;.
	ITK_CALL(ITEM_list_all_revs (item_tag, &count, &rev_list));

	 if(count > 0)
	    {
			DMLTaskTag = rev_list[0];

			if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
			printf("\n  BKC DML dmlTaskNo: [%s]",dmlTaskNo);fflush(stdout);

			//if(ITEM_find_item(dmlTaskNo, &DML_tag)!=ITK_ok)PrintErrorStack();

			tag_t *tags_found = NULL;
			int n_tags_found= 0;
			int n_rev= 0;

			const char **attrs = (const char **) MEM_alloc(1 * sizeof(char *));
			const char **values = (const char **) MEM_alloc(1 * sizeof(char *));

			attrs[0] ="item_id";
			values[0] = (char *) dmlTaskNo;

			//ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
			ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
			MEM_free(attrs);
			MEM_free(values);
			//CHECK_FAIL;

			if (n_tags_found == 0)
			{
				printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", dmlTaskNo); fflush(stdout);
				return ifail;
			}

			DML_tag = tags_found[0];

			ITK_CALL(ITEM_ask_latest_rev(DML_tag,&DMLRevTag));

			MEM_free(tags_found);
			printf("\n BKC LATEST dml tag found  \n");fflush(stdout);

			if (DMLRevTag != NULLTAG)
			{
				printf("\n Inside BKC LATEST dml tag found  \n");fflush(stdout);
				ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"item_id",&Dml_idn));

				printf("\n Dml Name find as - \n", Dml_idn);fflush(stdout);

				ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &MdmDMLToTaskRel));
				  ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));

				  printf("\n Finding the BKC DML Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);

				   if (Mdmtsk_cnt>0)
				  {
					  printf("\n Inside task count for BKC DML --- %d \n" ,Mdmtsk_cnt); fflush(stdout);

					 for (in=0;in<Mdmtsk_cnt ;in++ )
					{
						 printf("\n Now inside the task find as Task count is for BKC DML-- %d \n",Mdmtsk_cnt);fflush(stdout);
						 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[in],"object_type",&Taskobj_type));
						 printf("\n Now BKC DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);

						 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[in],"item_id",&TskNmMdm));
						 printf("\n Now BKC DML -Task name  is :%s \n",TskNmMdm);fflush(stdout);

						 ITK_CALL(GRM_find_relation_type("IMAN_reference", &Part_tobeAdd));

						   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Part_tobeAdd, &partaddcnt, &addPartsTag));
						   printf("\n  No of part attached to task in  BKC DML  -: %d \n",partaddcnt);fflush(stdout);

							if (partaddcnt>0)
							{
							   printf("\n Inside part found in BKC  attached to task in BKC DML -: %d \n",partaddcnt);fflush(stdout);
							   for (zr=0;zr<partaddcnt;zr++)
							   {
									CcidADDTag=addPartsTag[zr];
								    AddPartnumber =(char *) MEM_alloc(20 * sizeof(char *));
									if( AOM_ask_value_string(CcidADDTag,"item_id",&AddPartnumber)!=ITK_ok);
									printf("\n BKC  PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);
									if(AOM_ask_value_string(CcidADDTag,"item_revision_id",&PartRevID)!=ITK_ok);//JULY 28
									printf("\n BKC  Revision of part -------> %s \n", PartRevID);fflush(stdout);//JULY 28
									//Toget Maseter of attached parts
									ITK_CALL(ITEM_ask_item_of_rev(CcidADDTag,&CcidADD_MasterTag));
									//Getting All Revisions of Master
									ITK_CALL(ITEM_list_all_revs(CcidADD_MasterTag,&revCount,&CcidADD_All_rev_List));
									for(rc=0;rc<revCount;rc++)
									{

										Ccidset     =  (char *) MEM_alloc(2000 * sizeof(char));
										RevTag = CcidADD_All_rev_List[rc];
										ITK_CALL(AOM_ask_value_string(RevTag,"object_string",&object_stringRevTag));
										//printf("\n object_stringRevTag [%s]  \n",object_stringRevTag); fflush(stdout);

										ITK_CALL(AOM_UIF_ask_value (RevTag, "release_status_list", &rev_rel_status));
										//printf("\nRev. Release Status:%s\n",rev_rel_status);
										// check rev which have status ERC Release and above.
										if((tc_strstr(rev_rel_status,"ERC Released")!=NULL))
										{

											
											//Process this revision
											printf("\n  ERC Released Rev :: object_stringRevTag [%s]  \n",object_stringRevTag); fflush(stdout);
											//ITKCALL(WSOM_where_referenced	(CcidADDTag,2,&n_referencers,&levels,&referencers,&relationsRef);
											ITKCALL(WSOM_where_referenced	(RevTag,1,&n_referencers,&levels,&referencers,&relationsRef);
											printf("\n\t WSOM_where_referenced n_referencers-->%d \n",n_referencers)); fflush(stdout);
											if(n_referencers>0)
											{
												for (ss=0;ss<n_referencers;ss++ )
												{
													printf("***********ss****:: %d",ss);
													 ifail =POM_class_of_instance	(referencers[ss],&class_id1);
													 if(ifail != ITK_ok)	
													 {
															EMH_ask_error_text(ifail,&error_string);
															printf("Error:: %s",error_string);
													 }

													  ifail =POM_name_of_class	(class_id1,& class_name1);
													  if(ifail != ITK_ok)	
													  {
															EMH_ask_error_text(ifail,&error_string);
															printf("Error:: %s",error_string);
													  }
													 //printf("\n CLASS NAME FOR ITEM ==%s\n",class_name1);fflush(stdout);

													 ifail=  (WSOM_ask_name2(referencers[ss],&MPartNo));
													 if(ifail != ITK_ok)	
													  {
															EMH_ask_error_text(ifail,&error_string);
															printf("Error:: %s",error_string);
													  }
													 //printf("\n Name of refered data is  ==%s\n",MPartNo);fflush(stdout);

													 ITK_CALL(WSOM_ask_object_id_string(referencers[ss],&ItemIDn));PrintErrorStack();
													 printf("\n Item Id ==%s\n",ItemIDn);fflush(stdout);

													 if(ItemIDn != NULL)
													 {
														 if(tc_strstr(class_name1,"Snapshot") != NULL)
														 {
																printf("\n Snapshot  find   ==%s\n",ItemIDn);fflush(stdout);

																tok = strtok(ItemIDn, "-");
																printf("\n Snapshot  name after tok   ==%s\n",tok);fflush(stdout);

																//tok1 = strtok(tok, "/");
																//printf("\n Second tok ccid revision name after tok   ==%s\n",tok1);fflush(stdout);


																if((Ccidset==NULL)|| (tc_strcmp(Ccidset,"")==0))
																{
																	tc_strcpy (Ccidset,"" );
																	tc_strcat (Ccidset,tok);
																	printf("\n In if condition for Ccidset. %s",tok);	fflush(stdout);
																}
																else
																{
																	if(strstr(Ccidset,tok)==NULL)
																	{
																		tc_strcat (Ccidset,"," );
																		tc_strcat (Ccidset,tok);
																		printf("\n Else add part in Ccidset.. %s",tok);	fflush(stdout);
																	}
																}
														 }

													  }
													  else 
													  {
														  printf("\n ItemIDn is NULL Found ...!!");
													  }

													  

												}

											}
											tt=0;
											piStringCount=0;
											if(EPM__parse_string(Ccidset,",",&piStringCount,&AStringList)!=ITK_ok)PrintErrorStack();

											printf("\n For Part no  [%s] :: Total Ref Snapshot found are : %d  \n",AddPartnumber,piStringCount); fflush(stdout);

											printf("\n piStringCount -%d \n",piStringCount);fflush(stdout);

											for (tt=0;tt<piStringCount ;tt++ )
											{

												printf("\n Int count -%d  --  Ccidset Part:%s \n",tt, AStringList[tt]);fflush(stdout);

												char data[4][20];
												char *buffer;

												char *ccid= (char *) MEM_alloc( 30 * sizeof(char) );
												char *ccid_rev = (char *) MEM_alloc( 30 * sizeof(char) );
												char *tempCCID_ID = (char *) MEM_alloc( 40 * sizeof(char) );

												buffer = strtok(AStringList[tt], "_");

												int op = 0;
												 while (buffer != NULL) {
													strcpy(data[op], buffer);

													//printf("data[%i] = %s\n\t", i+1, data[i]);
													buffer = strtok(NULL, "_");
													op++;
												}

												tc_strcpy(ccid, data[0]);
												tc_strcpy(ccid_rev, data[1]);

												tc_strcpy(tempCCID_ID,"");
												tc_strcpy(tempCCID_ID,ccid);
												tc_strcat(tempCCID_ID,"_");
												tc_strcat(tempCCID_ID,ccid_rev);

												printf("\n CCID_Item_ID after strtok :%s \n",tempCCID_ID);fflush(stdout);
												if(ITEM_find_item (tempCCID_ID, &ref_item)!=ITK_ok)PrintErrorStack();
												//printf("\n  NOT NULL TAG  \n");fflush(stdout);
												if(ref_item!=NULLTAG)
												{

															ITK_CALL(AOM_UIF_ask_value(ref_item,"item_id",&RefItem_id));
															printf("\n Item ID of CCID : %s\n", RefItem_id);fflush(stdout);

															TokCcidNum=(char *)MEM_alloc(60);
															StrCcidNum=(char *)MEM_alloc(60);

															tc_strcpy (TokCcidNum,"" );
															tc_strcat (TokCcidNum,RefItem_id);

															AftertokCCid = strtok(TokCcidNum, "_");
															CCID_No		 = strtok(NULL, "_");

															//  code for larger number //
															printf("\n AftertokCCid   ==%s\n",AftertokCCid);fflush(stdout);
															printf("\n Aftertok CCID_No   ==%s\n",CCID_No);fflush(stdout);

															tc_strcpy (StrCcidNum,"" );
															tc_strcpy (StrCcidNum,AftertokCCid);
															tc_strcat (StrCcidNum,"*");

															printf("\n  New StrCcidNum= %s \n",StrCcidNum);fflush(stdout);
															// Need function for check this CCID is latest or not
															int isCCIDLatestOne =0;
															isCCIDLatestOne = IsCCIDLatest(StrCcidNum,CCID_No);
															if(isCCIDLatestOne == 1)
															{
																printf("\n CCID  is not Latest:::= %s \n",AStringList[tt]);fflush(stdout);
																printf("\n *******CCID to be attached at HasRef folder of DML is :::::   ==%s\n",RefItem_id);fflush(stdout);

																if((FinalCcidsetToAttachDML==NULL)|| (tc_strcmp(FinalCcidsetToAttachDML,"")==0))
																{
																	tc_strcpy (FinalCcidsetToAttachDML,"" );
																	tc_strcat (FinalCcidsetToAttachDML,RefItem_id);
																	
																}
																else
																{
																	if(strstr(FinalCcidsetToAttachDML,RefItem_id)==NULL)
																	{
																		tc_strcat (FinalCcidsetToAttachDML,"," );
																		tc_strcat (FinalCcidsetToAttachDML,RefItem_id);
																		
																	}
																}
															}
															else
															{
																	printf("\n CCID  is >>>> Latest::: <<<<<= %s \n",AStringList[tt]);fflush(stdout);
															}
													}

											}
										}

									}// for loop for all Revisions of parts added in Ref folder			
								
							   } // for loop for Part attached in Ref folder of DML task

								if(EPM__parse_string(FinalCcidsetToAttachDML,",",&FinalCcidsetCount,&FinalCcidsetList)!=ITK_ok)PrintErrorStack();
								printf("\n FinalCcidsetCount -%d \n",FinalCcidsetCount);fflush(stdout);
								int kt=0;
								
								//Creation Has Ref Relation of CCIDs to DML
								ITK_CALL(GRM_find_relation_type("T5_HasReferenceCCID",&HasRefCCIDRelType));
								printf("\n after finding HasRefCCIDRelType \n");fflush(stdout);
								
								for (kt=0;kt<FinalCcidsetCount ;kt++ )
								{
									ccidToattach				= NULLTAG;
									ccidToattachLatRev			= NULLTAG;
									ccidToattachLatRevObjStr	= NULL;
									CCIDRefRel_task				= NULLTAG;     

									printf("\n Int  count -%d  --  CCID List :%s \n",kt, FinalCcidsetList[kt]);fflush(stdout);

									ITK_CALL(ITEM_find_item (FinalCcidsetList[kt], &ccidToattach)!=ITK_ok)PrintErrorStack();
									ITK_CALL(ITEM_ask_latest_rev(ccidToattach,&ccidToattachLatRev));
									ITK_CALL(AOM_UIF_ask_value(ccidToattachLatRev,"object_string",&ccidToattachLatRevObjStr));
									printf("\n *******CCID  Rev to be attached at HasRef folder of DML is :::::   ==%s\n",ccidToattachLatRevObjStr);fflush(stdout);

									ITK_CALL(GRM_create_relation(DMLRevTag,ccidToattachLatRev,HasRefCCIDRelType,NULLTAG,&CCIDRefRel_task));
									ITK_CALL(GRM_save_relation(CCIDRefRel_task));
									ITK_CALL(AOM_refresh(DMLRevTag,1));
									ITK_CALL(AOM_save(DMLRevTag));
									ITK_CALL(AOM_refresh(DMLRevTag,0));


								}
								printf("\n outside bkc dml after ccid relation creation is has reference  \n");fflush(stdout);

							}// count if for Part attached in Ref folder of DML task

					   }// for loop of DML task
				
				}// count for DML task
			
			}// if for DML Tag

		}// DML 
	return ifail;
}
int IsCCIDLatest(char*InputCCIDstr,char* CCIDSeq)
{

	printf("\n****** I am in IsCCIDLatest function.*************\n");
	int latestCCID = 0;
	tag_t	CcidTags	= NULLTAG;
	char    **qry_valccids			= (char **) MEM_alloc(10 * sizeof(char *));
	int				n_entccids = 1;
	char		    *qry_entccids[1]			= {"ID"};
	int  num_to_sort = 1;
	char *keys[1] = {"creation_date"};
	int  	 orders[1]  ={2};
	int CcidCounts =0;
	tag_t			*CcidDatas			= NULL;
	int st =0;
	char *Ccid_Item_ID           =NULL;
	int	status =0;

	char *TokCcidID=NULL;
	char *TokCcidNum=NULL;

	//Incrementing the CCIDSeq by1
	int ccIdseqInt = 0;
	int ccidseqIncMentalValue =0;
	char ccIdseqCharInc[20];
	char *tempccIdseqCharInc =NULL;

	ccIdseqInt =atoi(CCIDSeq);
	printf("After conversion to Int data type :: %d\n",ccIdseqInt);
	ccidseqIncMentalValue = ccIdseqInt+1;
	printf("After Inc ccidseqIncMentalValue   :: %d\n",ccidseqIncMentalValue);

	//Converting incremented value in to string again for Cmp.
	 sprintf(ccIdseqCharInc,"%d",ccidseqIncMentalValue);
	 printf("After conversion to Char data type :: %s\n",ccIdseqCharInc);
	
	//if CCID seq is less then 9
	 if(ccidseqIncMentalValue <= 9)
	 {
		tempccIdseqCharInc = (char *)MEM_alloc(20);
		tc_strcpy(tempccIdseqCharInc,"");
		tc_strcat(tempccIdseqCharInc,"0");
		tc_strcat(tempccIdseqCharInc,ccIdseqCharInc);
	 }
	 else
	{
		tempccIdseqCharInc = (char *)MEM_alloc(20);
		tc_strcpy(tempccIdseqCharInc,"");
		tc_strcat(tempccIdseqCharInc,ccIdseqCharInc);
	}

	printf("Final tempccIdseqCharInc to be use :: %s\n",tempccIdseqCharInc);

	QRY_find("cciddes", &CcidTags);
	if (CcidTags)
	{
		//printf("\n For second query tag found\n\n");fflush(stdout);
	}
	else
	{
		printf("\n Second query not CCID Found Query\n");fflush(stdout);

	}

	qry_valccids[0]=InputCCIDstr;

	//printf("\n For Query input is :  %s \n",qry_valccids[0]);fflush(stdout);

	if(QRY_execute(CcidTags,n_entccids,qry_entccids,qry_valccids,&CcidCounts,&CcidDatas));
	//QRY_execute_with_sort(CcidTags, n_entccids, qry_entccids, qry_valccids, num_to_sort, keys, orders, &CcidCounts, &CcidDatas);
	if(CcidCounts >0)
	{
		for (st=0;st<CcidCounts ;st++ )
		{
			ITK_CALL(AOM_ask_value_string(CcidDatas[st],"item_id",&Ccid_Item_ID));
			//printf("\n I am in IsCCIDLatest function.\n");
			printf("\n CCID Item Id  :%s\n",Ccid_Item_ID);fflush(stdout);

			TokCcidID	=strtok(Ccid_Item_ID, "_");
			TokCcidNum	= strtok(NULL, "_");

			printf("\n TokCcidID  :%s\n",TokCcidID);fflush(stdout);
			printf("\n TokCcidNum  :%s\n",TokCcidNum);fflush(stdout);

			if(tc_strcmp(tempccIdseqCharInc,TokCcidNum) == 0)
			{
				printf("\nCCID is not latest..... CCID : %s and it's Seq : %s",InputCCIDstr,CCIDSeq);fflush(stdout);
				latestCCID =1;
				break;
			}
			
		}
	}
	//if(qry_valccids != NULL)
			//MEM_free(qry_valccids);
	//if(keys != NULL)
			//MEM_free(keys);

	return latestCCID;
}