	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int RemoveAndRenameSnapshot(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = RemoveAndRenameSnapshot(dmlNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int RemoveAndRenameSnapshot(char* dmlNo)
{
	int ifail = ITK_ok;
	int status =0;
	
	tag_t *attachments	   = NULLTAG;
	tag_t DMLRevTag	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;

	char* parent_name=NULL;
	//char* dmlNo=NULL;
	char* dmlProj=NULL;
	char * username			= NULL;
	char * object_type			= NULL;
	tag_t	HasNewCCIDRel		    = NULLTAG;
	tag_t	HasSnapshotType		    = NULLTAG;
	tag_t	HasMemCCIDRel		    = NULLTAG;
	tag_t	CCVCHasECUModRel		    = NULLTAG;

	int AttachmentCount=0;
	int Dml_cnt=0,t=0,count=0;
	
	char* VCItemRevId = NULL;
	char* VCItemId =NULL;
	tag_t CCvcItemRevTag =NULLTAG;
	char* CCvcItemRevID =NULL;

	char* SnapShotNameTem = NULL;
	char* SnapShotName	=NULL;
	char* SnapShotNameUpdated	=NULL;

	int		count1			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;

	ifail = ITEM_find_item (dmlNo, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_list_all_revs (item_tag, &count1, &rev_list);
	CHECK_FAIL;

	//Folder Query//Getting the tag of SnapShot
	int		No_of_EntryFolder = 1 ;
	char    *Q_EntryFolder[1]  = {"Name"};
	char	**Q_ValueFolder = (char **) MEM_alloc(5 * sizeof(char *));
	int SnapShotCountFolder = 0;
	tag_t   Qry_tagFolder     = NULLTAG;
	tag_t *SnapShot_tagFolder = NULLTAG;
	tag_t type_tagFolder		= NULLTAG;
	char* type_NameFolder     =NULL;

	if(QRY_find("folder custom", &Qry_tagFolder));
	if (Qry_tagFolder)
	{
		printf("\n folder custom Found \n");fflush(stdout);
		Q_ValueFolder[0]="EP_Release_DML_BKP_SnapShot";

		if(QRY_execute(Qry_tagFolder, No_of_EntryFolder, Q_EntryFolder, Q_ValueFolder, &SnapShotCountFolder, &SnapShot_tagFolder));
		printf("\n No of SnapShotCountFolder = %d\n",SnapShotCountFolder);fflush(stdout);

	}

	if(count1 > 0)
	{
		char* DML_No=NULL;

		AOM_ask_value_string(rev_list[0],"object_type",&object_type);
		printf("\n object_type is :%s\n",object_type);fflush(stdout);

		AOM_ask_value_string(rev_list[0],"item_id",&DML_No);
		printf("\n DML_No is :%s\n",DML_No);fflush(stdout);

		if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
		{
			DMLRevTag = rev_list[0];

			tag_t*	Dml_ccids		    = NULL;
			int Dml_ccid=0,ic=0;

			ITK_CALL(GRM_find_relation_type("T5_HasNewCCID", &HasNewCCIDRel));
			ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,HasNewCCIDRel,&Dml_ccid,&Dml_ccids));

			ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
			//printf("\n tm_ECUNewSnapshot after finding HasSnapshotType \n");fflush(stdout);

			printf("\n  Total No of VCIDs in Has NewVCID Folder : [%d] \n",Dml_ccid);fflush(stdout);
			for (ic=0;ic<Dml_ccid;ic++)
			{
				tag_t*	EcuMods		    = NULL;
				tag_t	Rel_tag		    = NULLTAG;
				int		snapcount =	0;
				tag_t* snapShotTag	= NULLTAG;

				int EcuModCnt=0;
				tag_t	CCid		    = NULLTAG;
				CCid=	Dml_ccids[ic];
				char* CCID_No=NULL;

				AOM_ask_value_string(CCid,"object_string",&CCID_No);
				printf("\n CCID_No is :%s\n",CCID_No);fflush(stdout);

				ITK_CALL(GRM_list_secondary_objects_only(CCid, HasSnapshotType, &snapcount, &snapShotTag));
				if(snapcount > 0)
				{
					ITK_CALL(AOM_ask_value_string(snapShotTag[0],"object_string",&SnapShotName));
					printf("\n SnapShotName is : %s \n",SnapShotName);fflush(stdout);

					SnapShotNameTem=(char *) MEM_alloc(30 * sizeof(char *));
					tc_strcpy (SnapShotNameTem,"" );
					tc_strcat (SnapShotNameTem,SnapShotName);
					tc_strcat (SnapShotNameTem,"_OLD_SNP_BKP");

					ITK_CALL(AOM_refresh(snapShotTag[0],1));
					ITK_CALL(AOM_set_value_string(snapShotTag[0],"object_name",SnapShotNameTem));
					ITK_CALL(AOM_save (snapShotTag[0]));
					ITK_CALL(AOM_refresh(snapShotTag[0],0));

					printf("\n SnapShotName is changed NOW");fflush(stdout);
					ITK_CALL(AOM_ask_value_string(snapShotTag[0],"object_string",&SnapShotNameUpdated));
					printf("\n SnapShotName is : %s \n",SnapShotNameUpdated);fflush(stdout);
					

					ITK_CALL(GRM_find_relation(CCid, snapShotTag[0],HasSnapshotType,&Rel_tag));
					if (Rel_tag)
					{
							printf("\n Deleting Relation of Snapshot with VCID");fflush(stdout);
							ITK_CALL(GRM_delete_relation(Rel_tag));

							//After Modification attaching it to Seprate Folder.
							ITK_CALL(AOM_lock(SnapShot_tagFolder[0]));
							ITK_CALL(FL_insert(SnapShot_tagFolder[0],snapShotTag[0],999));//new added
							ITK_CALL(AOM_save(SnapShot_tagFolder[0]));
							ITK_CALL(AOM_refresh(SnapShot_tagFolder[0],0));
							ITK_CALL(AOM_unlock(SnapShot_tagFolder[0]));
					}
				}
				else
				{
					printf("\n No Snapsnot found under VCID");fflush(stdout);

				}


			}

		}

	}

	return ifail;
}
