/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	int				i 							= 0;
	int				j 							= 0;
	int				count 						= 0;
	int				count_status				= 0;
	
	tag_t			item_tag					= NULLTAG;
	tag_t			*status_list				= NULL;
	tag_t			*latestRev					= NULL;
	
	char			*status_name				= NULL;
	
	char			*rev_id						= NULL;

		tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char *CurrentTask		= NULL;
	char *BusUnitDV			= NULL;
	char *DMLDRdvp			= NULL;
	char *dmlNo             =NULL;
	char* DMLtype		    = NULL;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	char  *Partnumber       = NULL;
	char   *Prt_object_type =NULL;
	char *DatasetName	    = NULL;
	char  *mdmclass_name;
	
	tag_t    Cciditemrev   = NULLTAG;
	tag_t	DML_tag				= NULLTAG;
	//Stag_t	DMLRevTag			= NULLTAG;
	
	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;

	tag_t	MdmDMLRevTag		= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t   class_id            =NULLTAG;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	tag_t  *MdmPartsTag          =NULLTAG;
	tag_t	Mdm_tsk_rel		    = NULLTAG;
	tag_t	DesignrMdmTag		= NULLTAG;
	tag_t	part_tsk_relc		    = NULLTAG;
	tag_t *attccidTag	          = NULLTAG;
	
	int     noAttachment      = 0;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcnt		       = 0;

	char * username				= NULL;
	char * parent_name			= NULL;
	char * dmlTaskNo			= NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;
	int		partcntrf	        = 0;
	int		pr					= 0;

	int	n_entriesMdm = 2;
	int n_foundMdm = 0;
	int p = 0;
	char *qry_entriesMdm[2] = {"SYSCD", "SUBSYSCD"};
    char *qry_valuesMdm[2]  = {"CCU", "DML"};
	tag_t   *MdmCtrObj      = NULLTAG;
	tag_t   *PartsTagrf       = NULLTAG;
	tag_t  TagMdmControl     = NULLTAG;
	tag_t	DesignrevTagR	 = NULLTAG;
	tag_t  reln_typeMdm       = NULLTAG;
	tag_t  Mdmrelation        =NULLTAG;
	tag_t	DMLRevTag			= NULLTAG;

	//

	char*	Cciditem_rev  = NULL;
	char *  PartItemRevIdSn =NULL;
	char *Dml_idn=NULL;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t	 HasRefCCIDRelTypen		 = NULLTAG;
	tag_t*	 snapchild				= NULL;
	tag_t  *addPartsTag          =NULLTAG;
	tag_t	 SnChild			  = NULLTAG;
	tag_t	 Part_tobeAdd	    = NULLTAG;
	tag_t	CcidADDTag		= NULLTAG;
	tag_t	latest_Cciditem	= NULLTAG;
	tag_t	latestRevRefCCV	= NULLTAG;
	tag_t	latestRevModule	= NULLTAG;
	tag_t	 IsMemberOfCCID   = NULLTAG;
	tag_t	 ReferencesCCV   = NULLTAG;
	tag_t	 CCVHasECUModule = NULLTAG;
	tag_t*	attccidTagMem		 = NULLTAG;
	tag_t	Mod_tag			= NULLTAG;
	tag_t*  RefCCVsTag =NULLTAG;
	tag_t*  moduleTags =NULLTAG;
	char*	 CCIDNo= NULL;
	char*	 itemIDRefCCV= NULL;
	char*	 latestRevID= NULL;
	char*   modObjStr =NULL;
	
	char*	 latestModRevObjstr= NULL;
	
	char*	 CCIDNoRev= NULL;
	int		CCID 	        = 0;
	int		snapcount 	        = 0;
	int		sn 	        = 0;
	int		attccidcnt     = 0; 
	int		icnt     = 0; 
	int		attccidcntMem     = 0;
	int		id_count	= 0;
	int		RefCCVcount =	0;
	int		moduleCount =	0;
	tag_t	 window;
	tag_t	sn_rule	= NULLTAG;
	tag_t	 top_line;
	char	**rev_seq	= NULL;
	char*	 SnapshotNo				 = NULL;

	//added 
	tag_t	ProQrySSObj			= NULLTAG;
	char	*values1[1];
	int		n_Input1					 = 1;
	tag_t	*snapObj		  = NULLTAG;
	int		SnapshotCount     = 0; 
	tag_t	 snapshot				 = NULLTAG;
	char	*qry_Input1[1]	  = {"Name"}; 
	tag_t	 Rel_task			  = NULLTAG;
	char  *AddPartnumber       = NULL;
	char *  PartItemIdSn      =NULL;
	char* itemIDOfModule	  =NULL;

	
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_ask_latest_rev (item_tag,&latest_Cciditem);
	CHECK_FAIL;	

	if(AOM_ask_value_string(latest_Cciditem,"item_id",&CCIDNo)==ITK_ok);	
	printf("\n\n\t In has new CCIDNo.:[%s]\n",CCIDNo);fflush(stdout);

	if(AOM_ask_value_string(latest_Cciditem,"item_revision_id",&CCIDNoRev)==ITK_ok);	
	printf("\n\n\t In has new CCIDNo revision -:[%s]\n",CCIDNoRev);fflush(stdout);

	ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&IsMemberOfCCID));
	printf("\n\n\t after finding IsMemberOfCCID \n");fflush(stdout);
						
	ITK_CALL(GRM_list_primary_objects_only(latest_Cciditem, IsMemberOfCCID, &attccidcntMem, &attccidTagMem));
	printf("\n\n\t attccidcntMem.:%d\n",attccidcntMem);fflush(stdout);

	if (attccidcntMem>0)
	{	
				//ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&ReferencesCCV));
				//printf("\n\n\t after finding T5_ReferencesCCV \n");fflush(stdout);
				//ITK_CALL(GRM_list_secondary_objects_only(latest_Cciditem,ReferencesCCV,&RefCCVcount,&RefCCVsTag));
				//if(RefCCVcount >0)
				//{
					//if(AOM_ask_value_string(RefCCVsTag[0],"item_id",&itemIDRefCCV)==ITK_ok);	
					//printf("\n\n\t Ref CCV ID.:[%s]\n",itemIDRefCCV);fflush(stdout);
					//ifail = ITEM_ask_latest_rev (RefCCVsTag[0],&latestRevRefCCV);

					//if(AOM_ask_value_string(latestRevRefCCV,"object_string",&latestRevID)==ITK_ok);
					//printf("\n\n\t Latest Rev of Ref CCV.:[%s]\n",latestRevID);fflush(stdout);

					//ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVHasECUModule));
					//ITK_CALL(GRM_list_secondary_objects_only(latestRevRefCCV,CCVHasECUModule,&moduleCount,&moduleTags));

					//if(moduleCount>0)
					//{
						//if(AOM_ask_value_string(moduleTags[0],"item_id",&itemIDOfModule)==ITK_ok);	
						//printf("\n\n\t itemIDOfModule.:[%s]\n",itemIDOfModule);fflush(stdout);
						//ifail = ITEM_ask_latest_rev (moduleTags[0],&latestRevModule);
						//if(AOM_ask_value_string(latestRevModule,"object_string",&latestModRevObjstr)==ITK_ok);	
						//printf("\n\n\t latestModRevObjstr.:[%s]\n",latestModRevObjstr);fflush(stdout);
					//}

				//}
		Mod_tag=attccidTagMem[0];
		if(AOM_ask_value_string(Mod_tag,"object_string",&modObjStr)==ITK_ok);
		printf("\n\n\t MOD Obj String:[%s]\n",modObjStr);fflush(stdout);

		ifail = BOM_create_window (&window);
		//ITK_CALL(CFM_find("ERC Review And Above", &sn_rule ));	//NEW 9 JULY 2020
		ITK_CALL(CFM_find("ERC release and above", &sn_rule ));	//NEW 9 JULY 2020
		ITK_CALL(BOM_set_window_config_rule( window, sn_rule )); //NEW 9 JULY 2020

		//ifail = BOM_set_window_top_line (window, null_tag, latest_Cciditem, null_tag, &top_line);
		//Adding latest module rev as top line
		ifail = BOM_set_window_top_line (window, null_tag, Mod_tag, null_tag, &top_line);

		ifail = BOM_window_show_suppressed (window);
		ITK_CALL(BOM_set_window_pack_all(window, FALSE));
		ITK_CALL(EPM__parse_string(CCIDNoRev, ";", &id_count, &rev_seq));//removed
		if(top_line!=NULLTAG)
		{
				 printf(" Snapshot dml inside top line ECU:\n");fflush(stdout);

                                     SnapshotNo	=NULL; 
									 SnapshotNo=(char *) MEM_alloc(30);

									 tc_strcpy(SnapshotNo,CCIDNo);   
									 tc_strcat(SnapshotNo,"_");
									 tc_strcat(SnapshotNo,rev_seq[0]);  
									 tc_strcat(SnapshotNo,"_");
									 tc_strcat(SnapshotNo,rev_seq[1]); 
									 printf("\n\n\t Snapshot dml SnapshotNo is ------->[%s]\n",SnapshotNo);fflush(stdout);
									 if(SnapshotNo)	/**********JULY 30************/
									 {
										 values1[0] = SnapshotNo;
										 if(QRY_find2("SnapShot", &ProQrySSObj));//PRODUCTION
										 if(ProQrySSObj)
										 {
												if(QRY_execute(ProQrySSObj, n_Input1, qry_Input1, values1, &SnapshotCount, &snapObj));
											    printf("\n\n\t qUERY for SnapshotCount count== %d", SnapshotCount);fflush(stdout);
												if (SnapshotCount == 0)
												{
													printf ("\n\n\t XXXXXXX SnapshotNoCount  =0 hence creating snapshot %s\n", SnapshotNo); fflush(stdout);
													if(BOM_create_snapshot(window,SnapshotNo,"Snapshot for ECU",&snapshot));
													if(snapshot!=NULLTAG)
													 {
														if(AOM_lock(snapshot))
														 printf("\n after snapshot creation :\n");fflush(stdout);
														 if(AOM_save( snapshot))
														 if(AOM_refresh(snapshot,1));
														 if(AOM_unlock(snapshot));
									
														 printf("\n\n\t Snapshot dml snapshot unlocked :\n");fflush(stdout);

														 ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide 
														 printf("\n\n\t Snapshot after finding HasSnapshotType \n");fflush(stdout);
														 if(HasSnapshotType!=NULLTAG)
														 {
																  printf("\n\n\t creating relation between ccid and snapshot \n");fflush(stdout);
																  if(GRM_create_relation(latest_Cciditem,snapshot,HasSnapshotType,NULLTAG,&Rel_task));
																  //if(GRM_create_relation(DesignrevTag,snapshot,SnapshotRelationType,NULLTAG,&Rel_task));
																  if(GRM_save_relation (Rel_task));
																  ITK_CALL(AOM_refresh(latest_Cciditem,1));
																  ITK_CALL(AOM_save(latest_Cciditem));
																  ITK_CALL(AOM_refresh(latest_Cciditem,0));

																  
																  ITK_CALL(AOM_ask_value_tags(snapshot,"contents",&snapcount,&snapchild));//added
																  printf("\n\n\t snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

																  printf("\n\n\t 444  CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);
																  if(snapcount >0)
																  {
																		for (sn=0;sn<snapcount;sn++)
																		 {
																			SnChild=snapchild[sn];

																			if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
																			printf("\n\n\t Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout); 

																			ITK_CALL(AOM_lock(snapshot));
																			ITK_CALL(FL_remove(snapshot,SnChild));
																			printf("\n\n\t  after fl remove AA \n");fflush(stdout);
																
																			ITK_CALL(AOM_save(snapshot));
																				
																			ITK_CALL(AOM_refresh(snapshot,0));

																			ITK_CALL(AOM_unlock(snapshot));

																			printf("\n\n\t all relationship deleted   \n");fflush(stdout);
																		 }// for snapcount ends

																  }// if for snapcount ends 

														 }// if for HasSnapshotType ends 

													 }// if for snapshot ends 

												} //if for SnapshotCount ends

										 }//if for ProQrySSObj ends 

									 }// if for SnapshotNo ends
		}



	}
	return ifail;
}
