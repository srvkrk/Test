/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
int IsCCIDLatest(char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
	printf("\n\t *******Input CCID is : %s************",item_id);

		tag_t CCID_with_Rev_tag =NULLTAG;
		char* objSringCCID =NULL;
		int   n_referencers					 = 0;
		int   *levels					 = 0;
		tag_t *	referencers;
		char ** relationsRef;
		int ss =0;
		int z =0;
		int status;
		tag_t class_id1 = NULL;
		char *class_name1=NULL;
		char*    MPartNo= NULL;
		char * ItemIDn;
		char* Taskobj_type =NULL;
		tag_t	 Part_tobeAdd	    = NULLTAG;
		int		partaddcnt				= 0;
		tag_t  *addPartsTag          =NULLTAG;
		char* AllworkFlow =NULL;
		tag_t Ref_Item_Part = NULLTAG;
		char* Ref_ItemNumber =NULL;
		char* ccid_item_id =NULL;
		char* ccid_item_rev_id=NULL;

		char* ccid_item_id_ref =NULL;
		char* ccid_item_rev_id_ref=NULL;

		int snpShotCount = 0;
		tag_t* snapShotTag =NULLTAG;

		int snpShotCount_Ref = 0;
		tag_t* snapShotTag_Ref =NULLTAG;

		int snapshotChildCount =0;
		tag_t* snapshotChildTag =NULLTAG;

		int snapshotChildCount_Ref =0;
		tag_t* snapshotChildTag_Ref =NULLTAG;

		tag_t imanRefRel_tag =NULLTAG;
		int partcntInRefFolder =0;

		tag_t* refFolderPartTag =NULLTAG;

		tag_t refFolderPart = NULLTAG;
		char* refFolderPartNo = NULL;

		tag_t	 SnChild			  = NULLTAG;
		char *  PartItemIdSn      =NULL;
		char *  PartItemRevIdSn =NULL;

		tag_t HasSnapshotType = NULL;

		char* ErrorText = NULL;



		char *CCID_No = (char *) MEM_alloc( 20 * sizeof(char) );
		char *CCID_Rev = (char *) MEM_alloc( 5 * sizeof(char) );

		char *token		  = NULL;
		char data[2][20];
		char *buffer;
		int i =0;
		int st =0;
		int sn =0;

		buffer = strtok(item_id, "/");

	    while (buffer != NULL) {
			strcpy(data[i], buffer);

			//printf("data[%i] = %s\n\t", i+1, data[i]);
			buffer = strtok(NULL, "/");
			i++;
       }

	   tc_strcpy(CCID_No, data[0]);
	   tc_strcpy(CCID_Rev, data[1]);

	  printf("\n\t CCID_No :%s\n\n", CCID_No);
      printf("\n\t CCID_Rev :%s\n\n", CCID_Rev);

	 

	  ITK_CALL(ITEM_find_rev(CCID_No,CCID_Rev,&CCID_with_Rev_tag));
	  ITK_CALL(AOM_ask_value_string(CCID_with_Rev_tag,"object_string",&objSringCCID));

	  printf("\n\t objSringCCID :%s\n\n", objSringCCID);
	  ITK_CALL(WSOM_where_referenced(CCID_with_Rev_tag,2,&n_referencers,&levels,&referencers,&relationsRef));

	  printf("\n\t  NO of Ref Found :: n_referencers :%d\n\n", n_referencers);


	  if(n_referencers>0)
	  {
			for (ss=0;ss<n_referencers;ss++ )
			{
			     POM_class_of_instance	(referencers[ss],&class_id1);
			     POM_name_of_class	(class_id1,& class_name1);
				 WSOM_ask_name2(referencers[ss],&MPartNo);
				 WSOM_ask_object_id_string(referencers[ss],&ItemIDn);
				  
				 if(tc_strstr(class_name1,"T5_ChangeTaskRevision") != NULL)
				 {
					
					ITK_CALL(AOM_UIF_ask_value(referencers[ss],"fnd0AllWorkflows",&AllworkFlow));
					printf("\n AllworkFlow :%s \n",AllworkFlow);fflush(stdout);

					if((tc_strstr(AllworkFlow,"CCID Update")!=NULL))
					{
						ITK_CALL(AOM_ask_value_string(referencers[ss],"object_type",&Taskobj_type));
						printf("\n Now CCU DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);
						printf("\n ItemIDn :%s \n",ItemIDn);fflush(stdout);
						
						// Part Addition code is starts::

						ITK_CALL(GRM_find_relation_type("EC_reference_item_rel", &Part_tobeAdd));
						ITK_CALL(GRM_list_secondary_objects_only(referencers[ss], Part_tobeAdd, &partaddcnt, &addPartsTag));

						printf("\n  No of part attached to task in Ref Item Folder  -: %d \n",partaddcnt);fflush(stdout);

						if (partaddcnt>0)
						{
							 for (z=0;z<partaddcnt;z++)
							 {
								Ref_Item_Part = addPartsTag[z];
								if( AOM_ask_value_string(Ref_Item_Part,"item_id",&Ref_ItemNumber)!=ITK_ok);
								printf("\n Ref Item Part No ,which needs to add in Snapshot of CCID [%s]  \n",Ref_ItemNumber); fflush(stdout);

								
								if(AOM_ask_value_string(CCID_with_Rev_tag,"item_id",&ccid_item_id)!=ITK_ok);
								printf("\n CCID Item ID to be update :[%s] \n",ccid_item_id);fflush(stdout);

								if(AOM_ask_value_string(CCID_with_Rev_tag,"item_revision_id",&ccid_item_rev_id)!=ITK_ok);
								printf("\n  CCID Item rev to be update [%s]\n",ccid_item_rev_id);fflush(stdout);


								ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
								printf("\n Part addition code - finding HasSnapshotType \n");fflush(stdout);

								ITK_CALL(GRM_list_secondary_objects_only(CCID_with_Rev_tag, HasSnapshotType, &snpShotCount, &snapShotTag));//3 sept
							    printf("\n Part addition code -Find the SNAPSHOT of CCID ---.:%d \n",snpShotCount);fflush(stdout);

								if(snpShotCount > 0)
								{
									ITK_CALL(AOM_ask_value_tags(snapShotTag[0],"contents",&snapshotChildCount,&snapshotChildTag));//added
									printf("\n Part addition code- snapshotChildCount -------> [%d] \n",snapshotChildCount);fflush(stdout);
									
									printf("\n *** Part is going to Update in Snapshot of CCIDS is ::  [%s]  \n",Ref_ItemNumber); fflush(stdout);

									ITK_CALL(AOM_lock(snapShotTag[0]));
									//ITK_CALL(FL_insert(ccidTagrf[0],CcidADDTag,999));//new added
									ifail = FL_insert(snapShotTag[0],Ref_Item_Part,999);
									if(ifail != ITK_ok)
									{
										EMH_ask_error_text(ifail,&ErrorText);
										printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);
									}
									printf("\n  Part addition code- after fl add AA \n %d",ifail);fflush(stdout);

									ITK_CALL(AOM_save(snapShotTag[0]));

									ITK_CALL(AOM_refresh(snapShotTag[0],0));

									ITK_CALL(AOM_unlock(snapShotTag[0]));

									printf("\n Part is Added in snapshot.\n");fflush(stdout);
								}
								else
								{
									printf("\n  No snapshot found\n");fflush(stdout);

								}

							 }
						}// Addition code ends::

						// Part removal code starts::
						 ITK_CALL(GRM_find_relation_type("IMAN_reference", &imanRefRel_tag));

						 ITK_CALL(GRM_list_secondary_objects_only(referencers[ss], imanRefRel_tag, &partcntInRefFolder, &refFolderPartTag));
						 printf("\n  No of part attached to Ref Folder of task -: %d \n",partcntInRefFolder);fflush(stdout);

						 if(partcntInRefFolder >0)
						 {
								for (st=0;st<partcntInRefFolder;st++)
								{
									refFolderPart = refFolderPartTag[st];

									if( AOM_ask_value_string(refFolderPart,"item_id",&refFolderPartNo)!=ITK_ok);
									printf("\n Part attached to task in Ref folder  refFolderPartNo- [%s]  \n",refFolderPartNo); fflush(stdout);

									if(AOM_ask_value_string(CCID_with_Rev_tag,"item_id",&ccid_item_id_ref)!=ITK_ok);
									printf("\n CCID Item  to be update [%s] \n",ccid_item_id_ref);fflush(stdout);

									if(AOM_ask_value_string(CCID_with_Rev_tag,"item_revision_id",&ccid_item_rev_id_ref)!=ITK_ok);
									printf("\n  CCID Item  rev to be update [%s]\n",ccid_item_rev_id_ref);fflush(stdout);

									//ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
									//printf("\n tm_ECUNewSnapshot after finding HasSnapshotType \n");fflush(stdout);

									 ITK_CALL(GRM_list_secondary_objects_only(CCID_with_Rev_tag, HasSnapshotType, &snpShotCount_Ref, &snapShotTag_Ref));//3 sept
									 printf("\nNo of Snapshot  ---.:[%d] \n",snpShotCount_Ref);fflush(stdout);

									 if(snpShotCount_Ref > 0)
									 {
										 ITK_CALL(AOM_ask_value_tags(snapShotTag_Ref[0],"contents",&snapshotChildCount_Ref,&snapshotChildTag_Ref));//added
										 printf("\n  snapcount  contents -------> [%d] \n",snapshotChildCount_Ref);fflush(stdout);
										 if(snapshotChildCount_Ref >0 )
										 {
											  for (sn=0;sn<snapshotChildCount_Ref;sn++)
											  {
													SnChild = snapshotChildTag_Ref[sn];

													if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
													printf("\n Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout);

													if(AOM_ask_value_string(SnChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok);//JULY 28
													printf("\n  Revision of part -------> %s \n", PartItemRevIdSn);fflush(stdout);//JULY 28

													printf("\n Part number attached to ref fol of  task -> %s \n", refFolderPartNo);fflush(stdout);//JULY 28

													if(tc_strcmp(PartItemIdSn,refFolderPartNo)==0)
													{
														printf("\n ***Part No is Matched ::: ********* \n");fflush(stdout);

														ITK_CALL(AOM_lock(snapShotTag_Ref[0]));
														ITK_CALL(FL_remove(snapShotTag_Ref[0],SnChild));
														printf("\n  after fl remove AA \n");fflush(stdout);

														ITK_CALL(AOM_save(snapShotTag_Ref[0]));

														ITK_CALL(AOM_refresh(snapShotTag_Ref[0],0));

														ITK_CALL(AOM_unlock(snapShotTag_Ref[0]));

														printf("\n  Matched part is removed from snapshot..\n");fflush(stdout);
														break;

													}

											  }
										 }
									 }
									

								}
						 }// Part removal Code is ends::
					}
					
				 }
			}
	  }


	
	return ITK_ok;
}
