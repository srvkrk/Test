/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
void tm_find_Prev_Official_Rev(char	*,tag_t , tag_t* );
int setFindStr1(int *,char ***,char* );
void setAddStr(int *,char ***,char* );
int setFindStr1(int *,char ***,char* );
char* EE_Part_BOM_Validation_for_NR_Rev(char*,int,tag_t*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -pf=<teamcenter password file> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{
		char*	username				= NULL;
	tag_t	root_task				= NULLTAG;
	tag_t	*attachments			= NULLTAG;
	int		ifail					= 0;
	int	  status;

	int				i 							= 0;
	int				j 							= 0;
	int				k 							= 0;
	int				l 							= 0;
	int				count1 						= 0;
	int				count 						= 0;
	int				n_attchs 					= 0;
	int				count_status				= 0;
	int				partcnt						= 0;
	int				sequence_id					= 0;
	//int             NR_REV_CHECK				= 0;

	tag_t			item_tag					= NULLTAG;
	tag_t			*status_list				= NULL;
	tag_t			DMLLcmTag					= NULL;
	tag_t			class_id					= NULL;
	tag_t			class_id1					= NULL;
	tag_t			tsk_dml_rel_type			= NULL;
	tag_t			*DMLRevision				= NULL;
	tag_t			*secondary_objects			= NULL;
	tag_t			*PartsTag					= NULL;
	tag_t			objTypeTag					= NULL;


	tag_t			DMLRevTag					= NULLTAG;
	tag_t			relation_type				= NULLTAG;
	tag_t			AssyTag						= NULLTAG;

	char			*status_name				= NULL;

	char			*rev_id						= NULL;
	char			*releaseType				= NULL;
	char			*t5current_name				= NULL;
	char			*s							= NULL;
	char			*class_name					= NULL;
	char			*class_name1				= NULL;
	char		   *projectname					= NULL;
	char		   *DMLNumber					= NULL;
	char		   *taskGrp					    = NULL;
	char		   *current_name				= NULL;
	char		   *t5current_name1				= NULL;
	char		   *object_type					= NULL;
	char		   *Part_no						= NULL;
	char		   *tempPart_no					= NULL;
	char		   type_name[TCTYPE_name_size_c+1];
	char		   *NRRevCheck					= NULL;
	char		   *token						= NULL;

	char		   *childWithNR_ERC_Review			 = NULL;

	EPM_decision_t decision						= EPM_go;

	childWithNR_ERC_Review						=(char *)MEM_alloc(500);

	tc_strcpy(childWithNR_ERC_Review," ");
	tc_strcat(childWithNR_ERC_Review,"Part No : ");


	char		   *DMLtype						= NULL;
	char		   *DMLNo						= NULL;
	logical is_latest;

	int		count123			=0;
	tag_t	item_tag1		= NULLTAG;
	tag_t	*rev_list		= NULL;


	NRRevCheck=(char *)MEM_alloc(300);

	CALLAPI(POM_get_user_id (&username));
	printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);
//	if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
//    {
		//CALLAPI(EPM_ask_root_task(msg.task,&root_task));
		//printf("\n\n\t\t Root task found");

		//CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count1,&attachments));
		//printf("\n\n\t\t EPM_ask_attachments of :: %d",count1);

		ITK_CALL(ITEM_find_item (item_id, &item_tag1));
		ITK_CALL(ITEM_list_all_revs (item_tag1, &count123, &rev_list));

		if(count123 > 0)
		{
			DMLLcmTag = rev_list[0];
	    }
		ifail = AOM_ask_value_string(DMLLcmTag,"current_id",&t5current_name);
		printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);

		 if ( ifail != ITK_ok)
		 {
			 EMH_ask_error_text( ifail, &s);
			 printf("Error with AOM_ask_value_string : %s \n",s);
			 MEM_free(s);
			 return ifail;
		 }

		 ifail = POM_class_of_instance(DMLLcmTag,&class_id);
		 ifail = POM_name_of_class(class_id,&class_name);
		 printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout);
		 if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
		 {
			ifail = GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
			if (tsk_dml_rel_type!=NULLTAG)
			{
				ifail = GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count,&DMLRevision);
				printf("\n\n\t\t ***********DML Revision from Task **********: %d",count);fflush(stdout);
				for (i=0;i<count ;i++ )
				{
					ifail = ITEM_rev_sequence_is_latest(DMLRevision[i],&is_latest);
					printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
					if(is_latest != true)
					{
						printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);

					} else
					{
						DMLRevTag = DMLRevision[i];

						ifail = AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname);
						printf("\n\n\t\t Projectname from leftObject : %s\n",projectname);fflush(stdout);

						printf("\n\n\t\t is_latest is  true .....\n");fflush(stdout);
						ifail = AOM_ask_value_string(DMLRevTag,"current_name",&current_name);
						printf("\n\n\t\t current_name is :%s\n",current_name);fflush(stdout);

						DMLNumber = strtok( current_name, "_" );
						taskGrp	  = strtok ( NULL, "_" );

						printf("\n\n\t\t DMLNumber is :%s",DMLNumber); fflush(stdout);
						printf("\n\n\t\t taskGrp is :%s",taskGrp); fflush(stdout);

						ifail = AOM_ask_value_int(DMLRevTag,"sequence_id",&sequence_id);
						printf("\n\n\t\t sequence_id is :%d\n",sequence_id);fflush(stdout);

						ifail = POM_class_of_instance(DMLRevTag,&class_id1);
						ifail = POM_name_of_class(class_id1,&class_name1);
						printf("\n\n\t\t class_name found1 :%s",class_name1);

						ifail = AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype);
						printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);

						if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
						{
							if(strcmp(DMLtype,"")==0)
							{
								printf("\n\n\t\t t5_rlstype is NULL\n");fflush(stdout);
								//EMH_clear_errors();
								//EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "ERC-DML Type IsNULL, plz update release type as required");
								//decision = EPM_nogo;
								return -1;

							} //If for DML Type check ends
							else
							{
								ifail = AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo);
								printf("\n\n\t\t DMLNo is :%s",DMLNo);fflush(stdout);

								if((strcmp(DMLtype,"EP")==0))
								{

									// Validation check for ECU Part release DML only
									ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation_type);
									if (relation_type!=NULLTAG)
									{
										ifail = GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects);
										printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);

										if(n_attchs>0)
										{
											 for (j=0;j<n_attchs;j++ )
											 {
													  ifail = AOM_ask_value_string(secondary_objects[j],"current_id",&t5current_name1);
												   printf("\n\n\t\t t5current_name1 is :%s",t5current_name1);fflush(stdout);
												   if ( ifail != ITK_ok)
												   {
													 //EMH_ask_error_text( status, &s);
													 printf("Error with AOM_ask_value_string2 : %s \n",s);
													// MEM_free(s);
													 //return status;
												   }
												   else
												   {
													   ifail = AOM_ask_value_string(secondary_objects[j],"object_type",&object_type);
														printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
														if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
														{
															ifail = AOM_ask_value_tags(secondary_objects[j],"CMHasSolutionItem",&partcnt,&PartsTag);
															printf("\n\n\t\t No. of Part in Solution Folder :%d \n",partcnt);fflush(stdout);

															if (partcnt>0)
															{
																//This is the loop for Solution items present in Solution folder of DML:
																for (k=0;k<partcnt ;k++ )
																{
																		AssyTag=PartsTag[k];
																		ifail = AOM_ask_value_string(AssyTag,"item_id",&Part_no);
																		printf("\n\n\t\t Part_no  is :%s \n",Part_no);	fflush(stdout);

																		ifail = TCTYPE_ask_object_type(AssyTag,&objTypeTag);
																		ifail = TCTYPE_ask_name(objTypeTag,type_name);
																		printf("\n\n\t\t AssyTag type_name := %s \n",type_name);fflush(stdout);
																		if(strcmp(type_name,"T5_EE_PartRevision") == 0)
																		{
																				printf("\n\n\t\t Inside Validation for EE Parts.\n");	fflush(stdout);
																				//Get child of Assembly having Rev ID NR
																				NRRevCheck = EE_Part_BOM_Validation_for_NR_Rev(Part_no,partcnt,PartsTag);
																				if(tc_strcmp(NRRevCheck,"")==0)//if(NRRevCheck)//
																				{
																					printf("\n\n\t\t No NR Rev Child Part found... \n");fflush(stdout);
																					//EPM_go;
																				}
																				else
																				{

//																					tc_strcat(childWithNR_ERC_Review,Part_no);
//																					tc_strcat(childWithNR_ERC_Review,",");
//																					tc_strcat(childWithNR_ERC_Review,"have child part(s)[");
//																					tc_strcat(childWithNR_ERC_Review,NRRevCheck);
//																					tc_strcat(childWithNR_ERC_Review,"]");
//																					tc_strcat(childWithNR_ERC_Review,"with NR Revision and Status ERC Review.And not found in solution item folder of DML,Please add this parts to solution folder,to procced further");

																					printf("\n\n\t\t chlidPartNos with NR Rev := %s \n",NRRevCheck);fflush(stdout);
//																					EMH_clear_errors();
//																					EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,childWithNR_ERC_Review);
//																					decision = EPM_nogo;
																					return -1;
																					//EPM_nogo;
																				}
																	   }

																}// For loop for Solution Items end:
															}

														}//If for T5_ChangeTaskRevision ends
												   }
											 }
										}
									}

								}// If for EP DML Type ends
							}

						}// if for ChangeRequestRevision class check ends

					}

				}// For DML Revision end

			} //if for tsk_dml_rel_type relation null check

		 } //If for T5_ChangeTaskRevision ends

	//}// If of DBA Users ends
	printf("\n\n\t\t End of function Check_NR_Rev_with_ERC_Reivew... \n");fflush(stdout);

	return ITK_ok;
}
int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;

	//tmp = sizeof(*strset);

	for(j=0;j<*count;j++)
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

		//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
		if(tc_strcmp((*strset)[j],str)==0) //check this
		//if(tc_strcmp(*strset[j],str)==0)

		return j;

	}
	return -1;
 }
 void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void tm_find_Prev_Official_Rev(char	*req_item,tag_t t_currentRevision, tag_t* t_previousRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		ii					=	0;
	int		n_tags_found		=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);

	if(Item_count > 0)
	{
		RevFlag		=	0;
		PreRevFlag	=	0;

		for(ii=Item_count-1;ii>=0;ii--)
		{
			RevOnly		=	NULL;
			PreRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				RevOnly		= strtok( Part_Rev_copy, ";" );
				PreRevOnly	= strtok( Part_rev_Id, ";" );
				printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				if(tc_strcmp(RevOnly,PreRevOnly)!=0)
				{
					PreRevFlag = 1;

				}
				if(PreRevFlag == 1)
				{
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_prev_rev_Id));
					printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
					*t_previousRevision	=	rev_list[ii];
					break;
				}
			}
		}
		if(PreRevFlag == 0)
		{
			*t_previousRevision	=	t_currentRevision;
		}
	}
}

//method for EE Part child validation. Added by Kirtikumar For NR Rev and ERC Reveiw check
char* EE_Part_BOM_Validation_for_NR_Rev(char *item_id,int partcnt,tag_t *PartsTag)
{
	int			chlid_count			= 0;
	int			i					= 0;
	int			j					= 0;
	int			ifail				= 0;
	int			attrReleaseStatusID = 0;
	int			attrRevID			= 0;
	tag_t		item_tag		= NULLTAG;
	tag_t		latestRev		= NULLTAG;
	tag_t		window			= NULLTAG;
	tag_t		rule			= NULLTAG;
	tag_t		top_line		= NULLTAG;
	tag_t		*children1		= NULLTAG;
	tag_t		statusTag		= NULLTAG;
	tag_t		RevIDTag		= NULLTAG;

	//char 	statusName[WSO_name_size_c+1];
	char 	RevName[WSO_name_size_c+1];

	char		*statusName		= NULL;
	char		*RevID			= NULL;
	char		*bomID			= NULL;
	//char		*PartWithNR_rev	= NULL;
	char 		*tempNRRevID	= NULL;
	char		*PartWithNR_rev				= (char *) MEM_alloc( 100 * sizeof(char) );
	char		*tempPart_no	= NULL;
	logical isChildPresentInSolutionFolder  = false;

	printf("\n\n\t\t In EE_Part_BOM_Validation_for_NR_Rev_function.");fflush(stdout);
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_ask_latest_rev(item_tag,&latestRev);

	ifail = BOM_create_window (&window);
	ifail = CFM_find( "Latest Working", &rule );
	ifail = BOM_set_window_config_rule( window, rule );
	ifail = BOM_set_window_pack_all (window, false);
	ifail = BOM_set_window_top_line (window, null_tag,latestRev , null_tag, &top_line);
	ifail = BOM_line_ask_child_lines (top_line, &chlid_count, &children1);
	CHECK_FAIL;

	printf("\n\n\t\t No of child foud : %d.",chlid_count);fflush(stdout);

	tc_strcpy(PartWithNR_rev,"");

	for (i=0;i< chlid_count; i++)
	{
		ifail = AOM_UIF_ask_value(children1[i],"bl_rev_release_status_list",&statusName);
		ifail = AOM_UIF_ask_value(children1[i],"bl_rev_item_revision_id",&RevID);
		ifail = AOM_UIF_ask_value(children1[i],"bl_item_item_id",&bomID);

		printf("\n\n\t\t ID of child is :%s",bomID);fflush(stdout);
		printf("\n\n\t\t statusName is :%s",statusName);fflush(stdout);
		printf("\n\n\t\t RevName is :%s",RevID);fflush(stdout);

		tempNRRevID = strtok(RevID, ";");

		//Condition for NR rev with ERC Review status
		if(tc_strcmp(tempNRRevID,"NR")==0 && tc_strcmp(statusName,"ERC Review")==0)
		{

			printf("\n\n\t\t ******NR Rev Part Found*****");

			for (j=0; j<partcnt; j++ )
			{
				ifail = AOM_ask_value_string(PartsTag[j],"item_id",&tempPart_no);
				if(tc_strcmp(bomID,tempPart_no)==0)
				{
					printf("\n\n\t\t chlidPartNo is Present in Solution item folder %s\n",bomID);fflush(stdout);
					isChildPresentInSolutionFolder =true;
					break;
				}
				//else
				//{
					//printf("\n\n\t\t chlidPartNo is NOT Present in Solution item folder %s\n",bomID);fflush(stdout);
				//}
			}
			if(isChildPresentInSolutionFolder)
			{
				printf("\n\n\t\t isChildPresentInSolutionFolder is TRUE");

			}
			else {

				printf("\n\n\t\t chlidPartNo is NOT Present in Solution item folder %s\n",bomID);fflush(stdout);
				if(tc_strcmp(PartWithNR_rev,"") == 0)
				{
					tc_strcpy(PartWithNR_rev,bomID);
					printf("\n\n\t\t PartWithNR_rev %s\n",PartWithNR_rev);
				}
				else
				{
					tc_strcat(PartWithNR_rev, ",");
					tc_strcat(PartWithNR_rev, bomID);
					printf("\n\n\t\t PartWithNR_re %s\n",PartWithNR_rev);
				}
			}

		}
		//
		isChildPresentInSolutionFolder =false;
	}
	return PartWithNR_rev;
}