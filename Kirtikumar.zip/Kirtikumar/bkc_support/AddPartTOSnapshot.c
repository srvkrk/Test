#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 50
#define NUMWORDS 3

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*,char*,char*,char*);
int check_rel_status(char*,tag_t,tag_t,tag_t);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	//char			* dmlNo						= NULL;
	char			* part1						= NULL;
	char			* part2						= NULL;
	char			* part3						= NULL;

	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	part1 			= ITK_ask_cli_argument("-part1=");
	part2 			= ITK_ask_cli_argument("-part2=");
	part3 			= ITK_ask_cli_argument("-part3=");
	file 			= ITK_ask_cli_argument("-file=");
		
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail =	ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = read_value_from_file(file,part1,part2,part3);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename,char* part1,char* part2,char* part3)
{
	//Need to have tag of latest rev of all input parts::
	tag_t part1Tag = NULLTAG;
	tag_t part2Tag = NULLTAG;
	tag_t part3Tag = NULLTAG;

	tag_t part1LatestRev =NULLTAG;
	tag_t part2LatestRev =NULLTAG;
	tag_t part3LatestRev =NULLTAG;

	char* object_string_p1 = NULL;
	char* object_string_p2 = NULL;
	char* object_string_p3 = NULL;

	ITK_CALL(ITEM_find_item(part1,&part1Tag));
	ITK_CALL(ITEM_find_item(part2,&part2Tag));
	ITK_CALL(ITEM_find_item(part3,&part3Tag));

	
	ITK_CALL(ITEM_ask_latest_rev(part1Tag,&part1LatestRev));
	ITK_CALL(ITEM_ask_latest_rev(part2Tag,&part2LatestRev));
	ITK_CALL(ITEM_ask_latest_rev(part3Tag,&part3LatestRev));

	
	ITK_CALL(AOM_ask_value_string(part1LatestRev,"object_string",&object_string_p1));
	ITK_CALL(AOM_ask_value_string(part2LatestRev,"object_string",&object_string_p2));
	ITK_CALL(AOM_ask_value_string(part3LatestRev,"object_string",&object_string_p3));


	printf("\n  object_string_p1  : %s",object_string_p1);fflush(stdout);
	printf("\n  object_string_p2  : %s",object_string_p2);fflush(stdout);	
	printf("\n  object_string_p3  : %s",object_string_p3);fflush(stdout);



	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				//item_id = strtok(temp, "#");
				//printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id,part1LatestRev,part2LatestRev,part3LatestRev);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	//fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    
********************************************************************************************/
int check_rel_status(char* item_id,tag_t part1LatestRev,tag_t part2LatestRev,tag_t part3LatestRev)
{
	char* object_string_pf		= NULL;
	tag_t relation_type			= NULLTAG;
	tag_t new_relation			= NULLTAG;
	tag_t	 HasSnapshotType	= NULLTAG;
	tag_t latestCCIDRev			= NULLTAG;
	tag_t   CCIDRefRel_task		= NULLTAG;
	char* latestCCIDRevOBJStr =NULL;
	int snapshot_count =0;
	tag_t snapshotTag =NULLTAG;

	//ITK_CALL(AOM_ask_value_string(dmlTag,"object_string",&object_string_pf));
	//printf("\n  Object String is  : %s",object_string_pf);fflush(stdout);
	printf("\n Input CCID is   : %s\n",item_id);fflush(stdout);
	
	//ITK_CALL(GRM_find_relation_type("T5_HasReferenceCCID",&HasRefCCIDRelType));
	//printf("\n after finding HasRefCCIDRelType \n");fflush(stdout);

	
	int		No_of_Entry = 1 ;
	char    *Q_Entry[1]  = {"Item ID"};
	char	**Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
	int ccidCount = 0;
	tag_t   Qry_tag     = NULLTAG;
	tag_t *ccid_tag = NULLTAG;

	if(QRY_find("Item ID", &Qry_tag));
	if (Qry_tag)
	{

		printf("\n Item ID Query Found \n");fflush(stdout);
		Q_Value[0]=item_id;

		if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &ccidCount, &ccid_tag));
		printf("\n No of ccid Found = %d\n",ccidCount);fflush(stdout);

		if(ccid_tag !=NULLTAG)
		{
			printf("\n\t *****Creating Relationship of parts  and ccid ******");
			ITK_CALL(ITEM_ask_latest_rev(ccid_tag[0],&latestCCIDRev));
			ITK_CALL(AOM_ask_value_string(latestCCIDRev,"object_string",&latestCCIDRevOBJStr));
			printf("\n  Object String CCID is  : %s",latestCCIDRevOBJStr);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));
			printf("\n tm_ECUNewSnapshot after finding HasSnapshotType \n");fflush(stdout);

			ITK_CALL(GRM_list_secondary_objects_only(latestCCIDRev, HasSnapshotType, &snapshot_count, &snapshotTag));//3 sept
			printf("\n Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);

			if(snapshot_count)
			{

			}



		
		}
		else
		{
			printf("\n\t CCID Tag Not found...!!");
		}

	}
	return ifail;
}
