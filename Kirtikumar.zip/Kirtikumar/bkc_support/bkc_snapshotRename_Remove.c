#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 50
#define NUMWORDS 3

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			* platformID				= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	//platformID 		= ITK_ask_cli_argument("-pf_id=");
	file 			= ITK_ask_cli_argument("-file=");
		
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = read_value_from_file(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];

	
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, " ");
				//item_id = strtok(temp, "#");
				//printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);
	//fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    
********************************************************************************************/
int check_rel_status(char* item_id)
{
	//Getting the tag of SnapShot
	int		No_of_Entry = 1 ;
	char    *Q_Entry[1]  = {"Name"};
	char	**Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
	int SnapShotCount = 0;
	tag_t   Qry_tag     = NULLTAG;
	tag_t *SnapShot_tag = NULLTAG;
	tag_t type_tag		= NULLTAG;
	char* type_Name     =NULL;
	char* SnapShotName =NULL;
	char* SnapShotNameTem = NULL;


	//Folder Query//Getting the tag of SnapShot
	int		No_of_EntryFolder = 1 ;
	char    *Q_EntryFolder[1]  = {"Name"};
	char	**Q_ValueFolder = (char **) MEM_alloc(5 * sizeof(char *));
	int SnapShotCountFolder = 0;
	tag_t   Qry_tagFolder     = NULLTAG;
	tag_t *SnapShot_tagFolder = NULLTAG;
	tag_t type_tagFolder		= NULLTAG;
	char* type_NameFolder     =NULL;

	if(QRY_find("folder custom", &Qry_tagFolder));
	if (Qry_tagFolder)
	{
		printf("\n folder custom Found \n");fflush(stdout);
		Q_ValueFolder[0]="BKC_DML_SUPPORT";

		if(QRY_execute(Qry_tagFolder, No_of_EntryFolder, Q_EntryFolder, Q_ValueFolder, &SnapShotCountFolder, &SnapShot_tagFolder));
		printf("\n No of SnapShotCountFolder = %d\n",SnapShotCountFolder);fflush(stdout);

	}



	if(QRY_find("SnapShot", &Qry_tag));
	if (Qry_tag)
	{
		printf("\n SnapShot Query Found \n");fflush(stdout);
		Q_Value[0]=item_id;

		if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &SnapShotCount, &SnapShot_tag));
		printf("\n No of SnapShot Found = %d\n",SnapShotCount);fflush(stdout);

		ITK_CALL(TCTYPE_ask_object_type(SnapShot_tag[0],&type_tag));
		ITK_CALL(TCTYPE_ask_name2(type_tag,&type_Name));
		printf("\n Object Type is : %s \n",type_Name);fflush(stdout);
		if(tc_strcmp(type_Name,"Snapshot") ==0)
		{
			printf("\n Correct Type found ....\n");
			ITK_CALL(AOM_ask_value_string(SnapShot_tag[0],"object_string",&SnapShotName));
			printf("\n SnapShotName is : %s \n",SnapShotName);fflush(stdout);
			
			SnapShotNameTem=(char *) MEM_alloc(30 * sizeof(char *));
			tc_strcpy (SnapShotNameTem,"" );
			tc_strcat (SnapShotNameTem,SnapShotName);
			tc_strcat (SnapShotNameTem,"_OLD_BKC");
															
			ITK_CALL(AOM_refresh(SnapShot_tag[0],1));
			ITK_CALL(AOM_set_value_string(SnapShot_tag[0],"object_name",SnapShotNameTem));
			ITK_CALL(AOM_save (SnapShot_tag[0]));
			ITK_CALL(AOM_refresh(SnapShot_tag[0],0));

			//After Modification attaching it to Seprate Folder.
			ITK_CALL(AOM_lock(SnapShot_tagFolder[0]));
			ITK_CALL(FL_insert(SnapShot_tagFolder[0],SnapShot_tag[0],999));//new added
			ITK_CALL(AOM_save(SnapShot_tagFolder[0]));
			ITK_CALL(AOM_refresh(SnapShot_tagFolder[0],0));
			ITK_CALL(AOM_unlock(SnapShot_tagFolder[0]));
			
		}
	}

	return ifail;
}